<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-21 02:10:44 --> Config Class Initialized
INFO - 2016-12-21 02:10:44 --> Hooks Class Initialized
DEBUG - 2016-12-21 02:10:44 --> UTF-8 Support Enabled
INFO - 2016-12-21 02:10:44 --> Utf8 Class Initialized
INFO - 2016-12-21 02:10:44 --> URI Class Initialized
DEBUG - 2016-12-21 02:10:44 --> No URI present. Default controller set.
INFO - 2016-12-21 02:10:44 --> Router Class Initialized
INFO - 2016-12-21 02:10:44 --> Output Class Initialized
INFO - 2016-12-21 02:10:44 --> Security Class Initialized
DEBUG - 2016-12-21 02:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-21 02:10:44 --> Input Class Initialized
INFO - 2016-12-21 02:10:44 --> Language Class Initialized
INFO - 2016-12-21 02:10:44 --> Loader Class Initialized
INFO - 2016-12-21 02:10:44 --> Database Driver Class Initialized
INFO - 2016-12-21 02:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-21 02:10:45 --> Controller Class Initialized
INFO - 2016-12-21 02:10:45 --> Helper loaded: url_helper
DEBUG - 2016-12-21 02:10:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-21 02:10:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-21 02:10:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-21 02:10:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-21 02:10:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-21 02:10:45 --> Final output sent to browser
DEBUG - 2016-12-21 02:10:45 --> Total execution time: 1.5710
INFO - 2016-12-21 02:10:57 --> Config Class Initialized
INFO - 2016-12-21 02:10:57 --> Hooks Class Initialized
DEBUG - 2016-12-21 02:10:57 --> UTF-8 Support Enabled
INFO - 2016-12-21 02:10:57 --> Utf8 Class Initialized
INFO - 2016-12-21 02:10:57 --> URI Class Initialized
INFO - 2016-12-21 02:10:57 --> Router Class Initialized
INFO - 2016-12-21 02:10:57 --> Output Class Initialized
INFO - 2016-12-21 02:10:57 --> Security Class Initialized
DEBUG - 2016-12-21 02:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-21 02:10:57 --> Input Class Initialized
INFO - 2016-12-21 02:10:57 --> Language Class Initialized
INFO - 2016-12-21 02:10:57 --> Loader Class Initialized
INFO - 2016-12-21 02:10:57 --> Database Driver Class Initialized
INFO - 2016-12-21 02:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-21 02:10:57 --> Controller Class Initialized
INFO - 2016-12-21 02:10:57 --> Helper loaded: url_helper
DEBUG - 2016-12-21 02:10:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-21 02:10:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-21 02:10:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-21 02:10:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-21 02:10:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-21 02:10:57 --> Final output sent to browser
DEBUG - 2016-12-21 02:10:57 --> Total execution time: 0.0147
INFO - 2016-12-21 06:36:36 --> Config Class Initialized
INFO - 2016-12-21 06:36:36 --> Hooks Class Initialized
DEBUG - 2016-12-21 06:36:36 --> UTF-8 Support Enabled
INFO - 2016-12-21 06:36:36 --> Utf8 Class Initialized
INFO - 2016-12-21 06:36:36 --> URI Class Initialized
INFO - 2016-12-21 06:36:36 --> Router Class Initialized
INFO - 2016-12-21 06:36:36 --> Output Class Initialized
INFO - 2016-12-21 06:36:36 --> Security Class Initialized
DEBUG - 2016-12-21 06:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-21 06:36:36 --> Input Class Initialized
INFO - 2016-12-21 06:36:36 --> Language Class Initialized
INFO - 2016-12-21 06:36:36 --> Loader Class Initialized
INFO - 2016-12-21 06:36:36 --> Database Driver Class Initialized
INFO - 2016-12-21 06:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-21 06:36:36 --> Controller Class Initialized
INFO - 2016-12-21 06:36:37 --> Helper loaded: date_helper
DEBUG - 2016-12-21 06:36:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-21 06:36:37 --> Helper loaded: url_helper
INFO - 2016-12-21 06:36:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-21 06:36:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2016-12-21 06:36:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2016-12-21 06:36:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-21 06:36:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-21 06:36:37 --> Final output sent to browser
DEBUG - 2016-12-21 06:36:37 --> Total execution time: 1.4421
INFO - 2016-12-21 16:57:01 --> Config Class Initialized
INFO - 2016-12-21 16:57:01 --> Hooks Class Initialized
DEBUG - 2016-12-21 16:57:01 --> UTF-8 Support Enabled
INFO - 2016-12-21 16:57:01 --> Utf8 Class Initialized
INFO - 2016-12-21 16:57:01 --> URI Class Initialized
INFO - 2016-12-21 16:57:01 --> Router Class Initialized
INFO - 2016-12-21 16:57:01 --> Output Class Initialized
INFO - 2016-12-21 16:57:01 --> Security Class Initialized
DEBUG - 2016-12-21 16:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-21 16:57:01 --> Input Class Initialized
INFO - 2016-12-21 16:57:01 --> Language Class Initialized
INFO - 2016-12-21 16:57:01 --> Loader Class Initialized
INFO - 2016-12-21 16:57:02 --> Database Driver Class Initialized
INFO - 2016-12-21 16:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-21 16:57:02 --> Controller Class Initialized
INFO - 2016-12-21 16:57:02 --> Helper loaded: date_helper
DEBUG - 2016-12-21 16:57:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-21 16:57:02 --> Helper loaded: url_helper
INFO - 2016-12-21 16:57:02 --> Helper loaded: download_helper
INFO - 2016-12-21 16:57:02 --> Config Class Initialized
INFO - 2016-12-21 16:57:02 --> Hooks Class Initialized
DEBUG - 2016-12-21 16:57:02 --> UTF-8 Support Enabled
INFO - 2016-12-21 16:57:02 --> Utf8 Class Initialized
INFO - 2016-12-21 16:57:02 --> URI Class Initialized
DEBUG - 2016-12-21 16:57:02 --> No URI present. Default controller set.
INFO - 2016-12-21 16:57:02 --> Router Class Initialized
INFO - 2016-12-21 16:57:02 --> Output Class Initialized
INFO - 2016-12-21 16:57:02 --> Security Class Initialized
DEBUG - 2016-12-21 16:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-21 16:57:02 --> Input Class Initialized
INFO - 2016-12-21 16:57:02 --> Language Class Initialized
INFO - 2016-12-21 16:57:02 --> Loader Class Initialized
INFO - 2016-12-21 16:57:02 --> Database Driver Class Initialized
INFO - 2016-12-21 16:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-21 16:57:02 --> Controller Class Initialized
INFO - 2016-12-21 16:57:02 --> Helper loaded: url_helper
DEBUG - 2016-12-21 16:57:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-21 16:57:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-21 16:57:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-21 16:57:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-21 16:57:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-21 16:57:03 --> Final output sent to browser
DEBUG - 2016-12-21 16:57:03 --> Total execution time: 0.2648

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-29 10:15:21 --> Config Class Initialized
INFO - 2016-12-29 10:15:21 --> Hooks Class Initialized
DEBUG - 2016-12-29 10:15:21 --> UTF-8 Support Enabled
INFO - 2016-12-29 10:15:21 --> Utf8 Class Initialized
INFO - 2016-12-29 10:15:21 --> URI Class Initialized
DEBUG - 2016-12-29 10:15:21 --> No URI present. Default controller set.
INFO - 2016-12-29 10:15:21 --> Router Class Initialized
INFO - 2016-12-29 10:15:21 --> Output Class Initialized
INFO - 2016-12-29 10:15:21 --> Security Class Initialized
DEBUG - 2016-12-29 10:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 10:15:21 --> Input Class Initialized
INFO - 2016-12-29 10:15:21 --> Language Class Initialized
INFO - 2016-12-29 10:15:21 --> Loader Class Initialized
INFO - 2016-12-29 10:15:21 --> Database Driver Class Initialized
INFO - 2016-12-29 10:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 10:15:22 --> Controller Class Initialized
INFO - 2016-12-29 10:15:22 --> Helper loaded: url_helper
DEBUG - 2016-12-29 10:15:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 10:15:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 10:15:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 10:15:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 10:15:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 10:15:22 --> Final output sent to browser
DEBUG - 2016-12-29 10:15:22 --> Total execution time: 1.7090
INFO - 2016-12-29 13:35:28 --> Config Class Initialized
INFO - 2016-12-29 13:35:28 --> Hooks Class Initialized
DEBUG - 2016-12-29 13:35:28 --> UTF-8 Support Enabled
INFO - 2016-12-29 13:35:28 --> Utf8 Class Initialized
INFO - 2016-12-29 13:35:28 --> URI Class Initialized
DEBUG - 2016-12-29 13:35:28 --> No URI present. Default controller set.
INFO - 2016-12-29 13:35:28 --> Router Class Initialized
INFO - 2016-12-29 13:35:28 --> Output Class Initialized
INFO - 2016-12-29 13:35:28 --> Security Class Initialized
DEBUG - 2016-12-29 13:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 13:35:28 --> Input Class Initialized
INFO - 2016-12-29 13:35:28 --> Language Class Initialized
INFO - 2016-12-29 13:35:28 --> Loader Class Initialized
INFO - 2016-12-29 13:35:28 --> Database Driver Class Initialized
INFO - 2016-12-29 13:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 13:35:29 --> Controller Class Initialized
INFO - 2016-12-29 13:35:29 --> Helper loaded: url_helper
DEBUG - 2016-12-29 13:35:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 13:35:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 13:35:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 13:35:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 13:35:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 13:35:29 --> Final output sent to browser
DEBUG - 2016-12-29 13:35:29 --> Total execution time: 1.1195
INFO - 2016-12-29 13:44:27 --> Config Class Initialized
INFO - 2016-12-29 13:44:27 --> Hooks Class Initialized
DEBUG - 2016-12-29 13:44:27 --> UTF-8 Support Enabled
INFO - 2016-12-29 13:44:27 --> Utf8 Class Initialized
INFO - 2016-12-29 13:44:27 --> URI Class Initialized
DEBUG - 2016-12-29 13:44:27 --> No URI present. Default controller set.
INFO - 2016-12-29 13:44:27 --> Router Class Initialized
INFO - 2016-12-29 13:44:27 --> Output Class Initialized
INFO - 2016-12-29 13:44:27 --> Security Class Initialized
DEBUG - 2016-12-29 13:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 13:44:27 --> Input Class Initialized
INFO - 2016-12-29 13:44:27 --> Language Class Initialized
INFO - 2016-12-29 13:44:27 --> Loader Class Initialized
INFO - 2016-12-29 13:44:27 --> Database Driver Class Initialized
INFO - 2016-12-29 13:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 13:44:27 --> Controller Class Initialized
INFO - 2016-12-29 13:44:27 --> Helper loaded: url_helper
DEBUG - 2016-12-29 13:44:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 13:44:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 13:44:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 13:44:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 13:44:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 13:44:27 --> Final output sent to browser
DEBUG - 2016-12-29 13:44:27 --> Total execution time: 0.0129
INFO - 2016-12-29 16:56:25 --> Config Class Initialized
INFO - 2016-12-29 16:56:25 --> Hooks Class Initialized
DEBUG - 2016-12-29 16:56:26 --> UTF-8 Support Enabled
INFO - 2016-12-29 16:56:26 --> Utf8 Class Initialized
INFO - 2016-12-29 16:56:26 --> URI Class Initialized
DEBUG - 2016-12-29 16:56:26 --> No URI present. Default controller set.
INFO - 2016-12-29 16:56:26 --> Router Class Initialized
INFO - 2016-12-29 16:56:26 --> Output Class Initialized
INFO - 2016-12-29 16:56:26 --> Security Class Initialized
DEBUG - 2016-12-29 16:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 16:56:26 --> Input Class Initialized
INFO - 2016-12-29 16:56:26 --> Language Class Initialized
INFO - 2016-12-29 16:56:26 --> Loader Class Initialized
INFO - 2016-12-29 16:56:26 --> Database Driver Class Initialized
INFO - 2016-12-29 16:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 16:56:26 --> Controller Class Initialized
INFO - 2016-12-29 16:56:26 --> Helper loaded: url_helper
DEBUG - 2016-12-29 16:56:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 16:56:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 16:56:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 16:56:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 16:56:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 16:56:26 --> Final output sent to browser
DEBUG - 2016-12-29 16:56:26 --> Total execution time: 1.1046
INFO - 2016-12-29 17:47:09 --> Config Class Initialized
INFO - 2016-12-29 17:47:09 --> Hooks Class Initialized
DEBUG - 2016-12-29 17:47:09 --> UTF-8 Support Enabled
INFO - 2016-12-29 17:47:09 --> Utf8 Class Initialized
INFO - 2016-12-29 17:47:09 --> URI Class Initialized
DEBUG - 2016-12-29 17:47:10 --> No URI present. Default controller set.
INFO - 2016-12-29 17:47:10 --> Router Class Initialized
INFO - 2016-12-29 17:47:10 --> Output Class Initialized
INFO - 2016-12-29 17:47:10 --> Security Class Initialized
DEBUG - 2016-12-29 17:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 17:47:10 --> Input Class Initialized
INFO - 2016-12-29 17:47:10 --> Language Class Initialized
INFO - 2016-12-29 17:47:10 --> Loader Class Initialized
INFO - 2016-12-29 17:47:10 --> Database Driver Class Initialized
INFO - 2016-12-29 17:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 17:47:11 --> Controller Class Initialized
INFO - 2016-12-29 17:47:11 --> Helper loaded: url_helper
DEBUG - 2016-12-29 17:47:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 17:47:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 17:47:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 17:47:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 17:47:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 17:47:11 --> Final output sent to browser
DEBUG - 2016-12-29 17:47:11 --> Total execution time: 1.4880
INFO - 2016-12-29 17:47:11 --> Config Class Initialized
INFO - 2016-12-29 17:47:11 --> Hooks Class Initialized
DEBUG - 2016-12-29 17:47:11 --> UTF-8 Support Enabled
INFO - 2016-12-29 17:47:11 --> Utf8 Class Initialized
INFO - 2016-12-29 17:47:11 --> URI Class Initialized
INFO - 2016-12-29 17:47:11 --> Router Class Initialized
INFO - 2016-12-29 17:47:11 --> Output Class Initialized
INFO - 2016-12-29 17:47:11 --> Security Class Initialized
DEBUG - 2016-12-29 17:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 17:47:11 --> Input Class Initialized
INFO - 2016-12-29 17:47:11 --> Language Class Initialized
INFO - 2016-12-29 17:47:11 --> Loader Class Initialized
INFO - 2016-12-29 17:47:11 --> Database Driver Class Initialized
INFO - 2016-12-29 17:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 17:47:11 --> Controller Class Initialized
INFO - 2016-12-29 17:47:11 --> Helper loaded: url_helper
DEBUG - 2016-12-29 17:47:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 17:47:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 17:47:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 17:47:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 17:47:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 17:47:11 --> Final output sent to browser
DEBUG - 2016-12-29 17:47:11 --> Total execution time: 0.0144
INFO - 2016-12-29 17:47:12 --> Config Class Initialized
INFO - 2016-12-29 17:47:12 --> Hooks Class Initialized
DEBUG - 2016-12-29 17:47:12 --> UTF-8 Support Enabled
INFO - 2016-12-29 17:47:12 --> Utf8 Class Initialized
INFO - 2016-12-29 17:47:12 --> URI Class Initialized
INFO - 2016-12-29 17:47:12 --> Router Class Initialized
INFO - 2016-12-29 17:47:12 --> Output Class Initialized
INFO - 2016-12-29 17:47:12 --> Security Class Initialized
DEBUG - 2016-12-29 17:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 17:47:12 --> Input Class Initialized
INFO - 2016-12-29 17:47:12 --> Language Class Initialized
INFO - 2016-12-29 17:47:12 --> Loader Class Initialized
INFO - 2016-12-29 17:47:12 --> Database Driver Class Initialized
INFO - 2016-12-29 17:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 17:47:12 --> Controller Class Initialized
INFO - 2016-12-29 17:47:12 --> Helper loaded: url_helper
DEBUG - 2016-12-29 17:47:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 17:47:12 --> Final output sent to browser
DEBUG - 2016-12-29 17:47:12 --> Total execution time: 0.0136
INFO - 2016-12-29 17:47:12 --> Config Class Initialized
INFO - 2016-12-29 17:47:12 --> Hooks Class Initialized
DEBUG - 2016-12-29 17:47:12 --> UTF-8 Support Enabled
INFO - 2016-12-29 17:47:12 --> Utf8 Class Initialized
INFO - 2016-12-29 17:47:12 --> URI Class Initialized
INFO - 2016-12-29 17:47:12 --> Router Class Initialized
INFO - 2016-12-29 17:47:12 --> Output Class Initialized
INFO - 2016-12-29 17:47:12 --> Security Class Initialized
DEBUG - 2016-12-29 17:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 17:47:12 --> Input Class Initialized
INFO - 2016-12-29 17:47:12 --> Language Class Initialized
INFO - 2016-12-29 17:47:12 --> Loader Class Initialized
INFO - 2016-12-29 17:47:12 --> Database Driver Class Initialized
INFO - 2016-12-29 17:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 17:47:12 --> Controller Class Initialized
INFO - 2016-12-29 17:47:12 --> Helper loaded: url_helper
DEBUG - 2016-12-29 17:47:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 17:47:12 --> Final output sent to browser
DEBUG - 2016-12-29 17:47:12 --> Total execution time: 0.0133
INFO - 2016-12-29 17:47:12 --> Config Class Initialized
INFO - 2016-12-29 17:47:12 --> Hooks Class Initialized
DEBUG - 2016-12-29 17:47:12 --> UTF-8 Support Enabled
INFO - 2016-12-29 17:47:12 --> Utf8 Class Initialized
INFO - 2016-12-29 17:47:12 --> URI Class Initialized
INFO - 2016-12-29 17:47:12 --> Router Class Initialized
INFO - 2016-12-29 17:47:12 --> Output Class Initialized
INFO - 2016-12-29 17:47:12 --> Security Class Initialized
DEBUG - 2016-12-29 17:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 17:47:12 --> Input Class Initialized
INFO - 2016-12-29 17:47:12 --> Language Class Initialized
INFO - 2016-12-29 17:47:12 --> Loader Class Initialized
INFO - 2016-12-29 17:47:12 --> Database Driver Class Initialized
INFO - 2016-12-29 17:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 17:47:12 --> Controller Class Initialized
INFO - 2016-12-29 17:47:12 --> Helper loaded: url_helper
DEBUG - 2016-12-29 17:47:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 17:47:12 --> Final output sent to browser
DEBUG - 2016-12-29 17:47:12 --> Total execution time: 0.0136
INFO - 2016-12-29 17:47:12 --> Config Class Initialized
INFO - 2016-12-29 17:47:12 --> Hooks Class Initialized
DEBUG - 2016-12-29 17:47:12 --> UTF-8 Support Enabled
INFO - 2016-12-29 17:47:12 --> Utf8 Class Initialized
INFO - 2016-12-29 17:47:12 --> URI Class Initialized
INFO - 2016-12-29 17:47:12 --> Router Class Initialized
INFO - 2016-12-29 17:47:12 --> Output Class Initialized
INFO - 2016-12-29 17:47:12 --> Security Class Initialized
DEBUG - 2016-12-29 17:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 17:47:12 --> Input Class Initialized
INFO - 2016-12-29 17:47:12 --> Language Class Initialized
INFO - 2016-12-29 17:47:12 --> Loader Class Initialized
INFO - 2016-12-29 17:47:12 --> Database Driver Class Initialized
INFO - 2016-12-29 17:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 17:47:12 --> Controller Class Initialized
INFO - 2016-12-29 17:47:12 --> Helper loaded: url_helper
DEBUG - 2016-12-29 17:47:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 17:47:12 --> Final output sent to browser
DEBUG - 2016-12-29 17:47:12 --> Total execution time: 0.0148
INFO - 2016-12-29 17:47:12 --> Config Class Initialized
INFO - 2016-12-29 17:47:12 --> Hooks Class Initialized
DEBUG - 2016-12-29 17:47:12 --> UTF-8 Support Enabled
INFO - 2016-12-29 17:47:12 --> Utf8 Class Initialized
INFO - 2016-12-29 17:47:12 --> URI Class Initialized
INFO - 2016-12-29 17:47:12 --> Router Class Initialized
INFO - 2016-12-29 17:47:12 --> Output Class Initialized
INFO - 2016-12-29 17:47:12 --> Security Class Initialized
DEBUG - 2016-12-29 17:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 17:47:12 --> Input Class Initialized
INFO - 2016-12-29 17:47:12 --> Language Class Initialized
INFO - 2016-12-29 17:47:12 --> Loader Class Initialized
INFO - 2016-12-29 17:47:12 --> Database Driver Class Initialized
INFO - 2016-12-29 17:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 17:47:12 --> Controller Class Initialized
INFO - 2016-12-29 17:47:12 --> Helper loaded: url_helper
DEBUG - 2016-12-29 17:47:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 17:47:12 --> Final output sent to browser
DEBUG - 2016-12-29 17:47:12 --> Total execution time: 0.0389
INFO - 2016-12-29 17:47:12 --> Config Class Initialized
INFO - 2016-12-29 17:47:12 --> Hooks Class Initialized
DEBUG - 2016-12-29 17:47:12 --> UTF-8 Support Enabled
INFO - 2016-12-29 17:47:12 --> Utf8 Class Initialized
INFO - 2016-12-29 17:47:12 --> URI Class Initialized
DEBUG - 2016-12-29 17:47:12 --> No URI present. Default controller set.
INFO - 2016-12-29 17:47:12 --> Router Class Initialized
INFO - 2016-12-29 17:47:12 --> Output Class Initialized
INFO - 2016-12-29 17:47:12 --> Security Class Initialized
DEBUG - 2016-12-29 17:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 17:47:12 --> Input Class Initialized
INFO - 2016-12-29 17:47:12 --> Language Class Initialized
INFO - 2016-12-29 17:47:12 --> Loader Class Initialized
INFO - 2016-12-29 17:47:12 --> Database Driver Class Initialized
INFO - 2016-12-29 17:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 17:47:12 --> Controller Class Initialized
INFO - 2016-12-29 17:47:12 --> Helper loaded: url_helper
DEBUG - 2016-12-29 17:47:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 17:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 17:47:12 --> Final output sent to browser
DEBUG - 2016-12-29 17:47:12 --> Total execution time: 0.0134
INFO - 2016-12-29 17:47:13 --> Config Class Initialized
INFO - 2016-12-29 17:47:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 17:47:13 --> UTF-8 Support Enabled
INFO - 2016-12-29 17:47:13 --> Utf8 Class Initialized
INFO - 2016-12-29 17:47:13 --> URI Class Initialized
INFO - 2016-12-29 17:47:13 --> Router Class Initialized
INFO - 2016-12-29 17:47:13 --> Output Class Initialized
INFO - 2016-12-29 17:47:13 --> Security Class Initialized
DEBUG - 2016-12-29 17:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 17:47:13 --> Input Class Initialized
INFO - 2016-12-29 17:47:13 --> Language Class Initialized
INFO - 2016-12-29 17:47:13 --> Loader Class Initialized
INFO - 2016-12-29 17:47:13 --> Database Driver Class Initialized
INFO - 2016-12-29 17:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 17:47:13 --> Controller Class Initialized
INFO - 2016-12-29 17:47:13 --> Helper loaded: url_helper
DEBUG - 2016-12-29 17:47:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 17:47:13 --> Final output sent to browser
DEBUG - 2016-12-29 17:47:13 --> Total execution time: 0.0135
INFO - 2016-12-29 17:47:13 --> Config Class Initialized
INFO - 2016-12-29 17:47:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 17:47:13 --> UTF-8 Support Enabled
INFO - 2016-12-29 17:47:13 --> Utf8 Class Initialized
INFO - 2016-12-29 17:47:13 --> URI Class Initialized
INFO - 2016-12-29 17:47:13 --> Router Class Initialized
INFO - 2016-12-29 17:47:13 --> Output Class Initialized
INFO - 2016-12-29 17:47:13 --> Security Class Initialized
DEBUG - 2016-12-29 17:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 17:47:13 --> Input Class Initialized
INFO - 2016-12-29 17:47:13 --> Language Class Initialized
INFO - 2016-12-29 17:47:13 --> Loader Class Initialized
INFO - 2016-12-29 17:47:13 --> Database Driver Class Initialized
INFO - 2016-12-29 17:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 17:47:13 --> Controller Class Initialized
INFO - 2016-12-29 17:47:13 --> Helper loaded: url_helper
DEBUG - 2016-12-29 17:47:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 17:47:13 --> Final output sent to browser
DEBUG - 2016-12-29 17:47:13 --> Total execution time: 0.0138
INFO - 2016-12-29 17:47:13 --> Config Class Initialized
INFO - 2016-12-29 17:47:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 17:47:13 --> UTF-8 Support Enabled
INFO - 2016-12-29 17:47:13 --> Utf8 Class Initialized
INFO - 2016-12-29 17:47:13 --> URI Class Initialized
INFO - 2016-12-29 17:47:13 --> Router Class Initialized
INFO - 2016-12-29 17:47:13 --> Output Class Initialized
INFO - 2016-12-29 17:47:13 --> Security Class Initialized
DEBUG - 2016-12-29 17:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 17:47:13 --> Input Class Initialized
INFO - 2016-12-29 17:47:13 --> Language Class Initialized
INFO - 2016-12-29 17:47:13 --> Loader Class Initialized
INFO - 2016-12-29 17:47:13 --> Database Driver Class Initialized
INFO - 2016-12-29 17:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 17:47:13 --> Controller Class Initialized
INFO - 2016-12-29 17:47:13 --> Helper loaded: url_helper
DEBUG - 2016-12-29 17:47:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 17:47:13 --> Final output sent to browser
DEBUG - 2016-12-29 17:47:13 --> Total execution time: 0.0141
INFO - 2016-12-29 17:47:13 --> Config Class Initialized
INFO - 2016-12-29 17:47:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 17:47:13 --> UTF-8 Support Enabled
INFO - 2016-12-29 17:47:13 --> Utf8 Class Initialized
INFO - 2016-12-29 17:47:13 --> URI Class Initialized
INFO - 2016-12-29 17:47:13 --> Router Class Initialized
INFO - 2016-12-29 17:47:13 --> Output Class Initialized
INFO - 2016-12-29 17:47:13 --> Security Class Initialized
DEBUG - 2016-12-29 17:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 17:47:13 --> Input Class Initialized
INFO - 2016-12-29 17:47:13 --> Language Class Initialized
INFO - 2016-12-29 17:47:13 --> Loader Class Initialized
INFO - 2016-12-29 17:47:13 --> Database Driver Class Initialized
INFO - 2016-12-29 17:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 17:47:13 --> Controller Class Initialized
INFO - 2016-12-29 17:47:13 --> Helper loaded: url_helper
DEBUG - 2016-12-29 17:47:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 17:47:13 --> Final output sent to browser
DEBUG - 2016-12-29 17:47:13 --> Total execution time: 0.0135
INFO - 2016-12-29 17:47:13 --> Config Class Initialized
INFO - 2016-12-29 17:47:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 17:47:13 --> UTF-8 Support Enabled
INFO - 2016-12-29 17:47:13 --> Utf8 Class Initialized
INFO - 2016-12-29 17:47:13 --> URI Class Initialized
INFO - 2016-12-29 17:47:13 --> Router Class Initialized
INFO - 2016-12-29 17:47:13 --> Output Class Initialized
INFO - 2016-12-29 17:47:13 --> Security Class Initialized
DEBUG - 2016-12-29 17:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 17:47:13 --> Input Class Initialized
INFO - 2016-12-29 17:47:13 --> Language Class Initialized
INFO - 2016-12-29 17:47:13 --> Loader Class Initialized
INFO - 2016-12-29 17:47:13 --> Database Driver Class Initialized
INFO - 2016-12-29 17:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 17:47:13 --> Controller Class Initialized
INFO - 2016-12-29 17:47:13 --> Helper loaded: url_helper
DEBUG - 2016-12-29 17:47:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 17:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 17:47:13 --> Final output sent to browser
DEBUG - 2016-12-29 17:47:13 --> Total execution time: 0.0141
INFO - 2016-12-29 17:47:14 --> Config Class Initialized
INFO - 2016-12-29 17:47:14 --> Hooks Class Initialized
DEBUG - 2016-12-29 17:47:14 --> UTF-8 Support Enabled
INFO - 2016-12-29 17:47:14 --> Utf8 Class Initialized
INFO - 2016-12-29 17:47:14 --> URI Class Initialized
INFO - 2016-12-29 17:47:14 --> Router Class Initialized
INFO - 2016-12-29 17:47:14 --> Output Class Initialized
INFO - 2016-12-29 17:47:14 --> Security Class Initialized
DEBUG - 2016-12-29 17:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 17:47:14 --> Input Class Initialized
INFO - 2016-12-29 17:47:14 --> Language Class Initialized
INFO - 2016-12-29 17:47:14 --> Loader Class Initialized
INFO - 2016-12-29 17:47:14 --> Database Driver Class Initialized
INFO - 2016-12-29 17:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 17:47:14 --> Controller Class Initialized
INFO - 2016-12-29 17:47:14 --> Helper loaded: url_helper
DEBUG - 2016-12-29 17:47:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 17:47:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 17:47:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 17:47:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 17:47:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 17:47:14 --> Final output sent to browser
DEBUG - 2016-12-29 17:47:14 --> Total execution time: 0.0156
INFO - 2016-12-29 19:09:32 --> Config Class Initialized
INFO - 2016-12-29 19:09:32 --> Hooks Class Initialized
DEBUG - 2016-12-29 19:09:32 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:09:32 --> Utf8 Class Initialized
INFO - 2016-12-29 19:09:32 --> URI Class Initialized
DEBUG - 2016-12-29 19:09:32 --> No URI present. Default controller set.
INFO - 2016-12-29 19:09:32 --> Router Class Initialized
INFO - 2016-12-29 19:09:32 --> Output Class Initialized
INFO - 2016-12-29 19:09:32 --> Security Class Initialized
DEBUG - 2016-12-29 19:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:09:33 --> Input Class Initialized
INFO - 2016-12-29 19:09:33 --> Language Class Initialized
INFO - 2016-12-29 19:09:33 --> Loader Class Initialized
INFO - 2016-12-29 19:09:33 --> Database Driver Class Initialized
INFO - 2016-12-29 19:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 19:09:33 --> Controller Class Initialized
INFO - 2016-12-29 19:09:33 --> Helper loaded: url_helper
DEBUG - 2016-12-29 19:09:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 19:09:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 19:09:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 19:09:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 19:09:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 19:09:33 --> Final output sent to browser
DEBUG - 2016-12-29 19:09:33 --> Total execution time: 1.0910
INFO - 2016-12-29 19:09:34 --> Config Class Initialized
INFO - 2016-12-29 19:09:34 --> Hooks Class Initialized
DEBUG - 2016-12-29 19:09:34 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:09:34 --> Utf8 Class Initialized
INFO - 2016-12-29 19:09:34 --> URI Class Initialized
INFO - 2016-12-29 19:09:34 --> Router Class Initialized
INFO - 2016-12-29 19:09:34 --> Output Class Initialized
INFO - 2016-12-29 19:09:34 --> Security Class Initialized
DEBUG - 2016-12-29 19:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:09:34 --> Input Class Initialized
INFO - 2016-12-29 19:09:34 --> Language Class Initialized
ERROR - 2016-12-29 19:09:34 --> 404 Page Not Found: Imagenes_portada/Galeria0.jpg
INFO - 2016-12-29 19:09:36 --> Config Class Initialized
INFO - 2016-12-29 19:09:36 --> Hooks Class Initialized
DEBUG - 2016-12-29 19:09:36 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:09:36 --> Utf8 Class Initialized
INFO - 2016-12-29 19:09:36 --> URI Class Initialized
INFO - 2016-12-29 19:09:36 --> Router Class Initialized
INFO - 2016-12-29 19:09:36 --> Output Class Initialized
INFO - 2016-12-29 19:09:36 --> Security Class Initialized
DEBUG - 2016-12-29 19:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:09:36 --> Input Class Initialized
INFO - 2016-12-29 19:09:36 --> Language Class Initialized
ERROR - 2016-12-29 19:09:36 --> 404 Page Not Found: Imagenes_portada/Galeria2.jpg
INFO - 2016-12-29 19:09:36 --> Config Class Initialized
INFO - 2016-12-29 19:09:36 --> Hooks Class Initialized
DEBUG - 2016-12-29 19:09:36 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:09:36 --> Utf8 Class Initialized
INFO - 2016-12-29 19:09:36 --> URI Class Initialized
INFO - 2016-12-29 19:09:36 --> Router Class Initialized
INFO - 2016-12-29 19:09:36 --> Output Class Initialized
INFO - 2016-12-29 19:09:36 --> Security Class Initialized
DEBUG - 2016-12-29 19:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:09:36 --> Input Class Initialized
INFO - 2016-12-29 19:09:36 --> Language Class Initialized
ERROR - 2016-12-29 19:09:36 --> 404 Page Not Found: Imagenes_portada/Galeria3.jpg
INFO - 2016-12-29 19:09:36 --> Config Class Initialized
INFO - 2016-12-29 19:09:36 --> Hooks Class Initialized
DEBUG - 2016-12-29 19:09:36 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:09:36 --> Utf8 Class Initialized
INFO - 2016-12-29 19:09:36 --> URI Class Initialized
INFO - 2016-12-29 19:09:36 --> Router Class Initialized
INFO - 2016-12-29 19:09:36 --> Output Class Initialized
INFO - 2016-12-29 19:09:36 --> Security Class Initialized
DEBUG - 2016-12-29 19:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:09:36 --> Input Class Initialized
INFO - 2016-12-29 19:09:36 --> Language Class Initialized
ERROR - 2016-12-29 19:09:36 --> 404 Page Not Found: Imagenes_portada/Galeria4.jpg
INFO - 2016-12-29 19:09:36 --> Config Class Initialized
INFO - 2016-12-29 19:09:36 --> Hooks Class Initialized
DEBUG - 2016-12-29 19:09:36 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:09:36 --> Utf8 Class Initialized
INFO - 2016-12-29 19:09:36 --> URI Class Initialized
INFO - 2016-12-29 19:09:36 --> Router Class Initialized
INFO - 2016-12-29 19:09:36 --> Output Class Initialized
INFO - 2016-12-29 19:09:36 --> Security Class Initialized
DEBUG - 2016-12-29 19:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:09:36 --> Input Class Initialized
INFO - 2016-12-29 19:09:36 --> Language Class Initialized
ERROR - 2016-12-29 19:09:36 --> 404 Page Not Found: Imagenes_portada/Galeria5.jpg
INFO - 2016-12-29 19:09:36 --> Config Class Initialized
INFO - 2016-12-29 19:09:36 --> Hooks Class Initialized
DEBUG - 2016-12-29 19:09:36 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:09:36 --> Utf8 Class Initialized
INFO - 2016-12-29 19:09:36 --> URI Class Initialized
INFO - 2016-12-29 19:09:36 --> Router Class Initialized
INFO - 2016-12-29 19:09:36 --> Output Class Initialized
INFO - 2016-12-29 19:09:36 --> Security Class Initialized
DEBUG - 2016-12-29 19:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:09:36 --> Input Class Initialized
INFO - 2016-12-29 19:09:36 --> Language Class Initialized
ERROR - 2016-12-29 19:09:36 --> 404 Page Not Found: Imagenes_portada/Galeria6.jpg
INFO - 2016-12-29 19:09:39 --> Config Class Initialized
INFO - 2016-12-29 19:09:39 --> Hooks Class Initialized
DEBUG - 2016-12-29 19:09:39 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:09:39 --> Utf8 Class Initialized
INFO - 2016-12-29 19:09:39 --> URI Class Initialized
INFO - 2016-12-29 19:09:39 --> Router Class Initialized
INFO - 2016-12-29 19:09:39 --> Output Class Initialized
INFO - 2016-12-29 19:09:39 --> Security Class Initialized
DEBUG - 2016-12-29 19:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:09:39 --> Input Class Initialized
INFO - 2016-12-29 19:09:39 --> Language Class Initialized
INFO - 2016-12-29 19:09:39 --> Loader Class Initialized
INFO - 2016-12-29 19:09:39 --> Database Driver Class Initialized
INFO - 2016-12-29 19:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 19:09:39 --> Controller Class Initialized
INFO - 2016-12-29 19:09:39 --> Helper loaded: url_helper
DEBUG - 2016-12-29 19:09:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 19:09:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 19:09:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 19:09:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 19:09:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 19:09:39 --> Final output sent to browser
DEBUG - 2016-12-29 19:09:39 --> Total execution time: 0.0133
INFO - 2016-12-29 19:26:15 --> Config Class Initialized
INFO - 2016-12-29 19:26:15 --> Hooks Class Initialized
DEBUG - 2016-12-29 19:26:15 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:26:15 --> Utf8 Class Initialized
INFO - 2016-12-29 19:26:15 --> URI Class Initialized
DEBUG - 2016-12-29 19:26:16 --> No URI present. Default controller set.
INFO - 2016-12-29 19:26:16 --> Router Class Initialized
INFO - 2016-12-29 19:26:16 --> Output Class Initialized
INFO - 2016-12-29 19:26:16 --> Security Class Initialized
DEBUG - 2016-12-29 19:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:26:16 --> Input Class Initialized
INFO - 2016-12-29 19:26:16 --> Language Class Initialized
INFO - 2016-12-29 19:26:16 --> Loader Class Initialized
INFO - 2016-12-29 19:26:16 --> Database Driver Class Initialized
INFO - 2016-12-29 19:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 19:26:16 --> Controller Class Initialized
INFO - 2016-12-29 19:26:16 --> Helper loaded: url_helper
DEBUG - 2016-12-29 19:26:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 19:26:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 19:26:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 19:26:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 19:26:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 19:26:16 --> Final output sent to browser
DEBUG - 2016-12-29 19:26:16 --> Total execution time: 0.9788
INFO - 2016-12-29 19:26:16 --> Config Class Initialized
INFO - 2016-12-29 19:26:16 --> Hooks Class Initialized
DEBUG - 2016-12-29 19:26:16 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:26:16 --> Utf8 Class Initialized
INFO - 2016-12-29 19:26:16 --> URI Class Initialized
INFO - 2016-12-29 19:26:16 --> Router Class Initialized
INFO - 2016-12-29 19:26:16 --> Output Class Initialized
INFO - 2016-12-29 19:26:16 --> Security Class Initialized
DEBUG - 2016-12-29 19:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:26:16 --> Input Class Initialized
INFO - 2016-12-29 19:26:16 --> Language Class Initialized
ERROR - 2016-12-29 19:26:16 --> 404 Page Not Found: Imagenes_portada/Galeria0.jpg
INFO - 2016-12-29 19:26:17 --> Config Class Initialized
INFO - 2016-12-29 19:26:17 --> Hooks Class Initialized
DEBUG - 2016-12-29 19:26:17 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:26:17 --> Utf8 Class Initialized
INFO - 2016-12-29 19:26:17 --> URI Class Initialized
INFO - 2016-12-29 19:26:17 --> Router Class Initialized
INFO - 2016-12-29 19:26:17 --> Output Class Initialized
INFO - 2016-12-29 19:26:17 --> Security Class Initialized
DEBUG - 2016-12-29 19:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:26:17 --> Input Class Initialized
INFO - 2016-12-29 19:26:17 --> Language Class Initialized
ERROR - 2016-12-29 19:26:17 --> 404 Page Not Found: Imagenes_portada/Galeria0.jpg
INFO - 2016-12-29 19:26:17 --> Config Class Initialized
INFO - 2016-12-29 19:26:17 --> Hooks Class Initialized
DEBUG - 2016-12-29 19:26:17 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:26:17 --> Utf8 Class Initialized
INFO - 2016-12-29 19:26:17 --> URI Class Initialized
INFO - 2016-12-29 19:26:17 --> Router Class Initialized
INFO - 2016-12-29 19:26:17 --> Output Class Initialized
INFO - 2016-12-29 19:26:17 --> Security Class Initialized
DEBUG - 2016-12-29 19:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:26:17 --> Input Class Initialized
INFO - 2016-12-29 19:26:17 --> Language Class Initialized
ERROR - 2016-12-29 19:26:17 --> 404 Page Not Found: Imagenes_portada/Galeria2.jpg
INFO - 2016-12-29 19:26:17 --> Config Class Initialized
INFO - 2016-12-29 19:26:17 --> Hooks Class Initialized
DEBUG - 2016-12-29 19:26:17 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:26:17 --> Utf8 Class Initialized
INFO - 2016-12-29 19:26:17 --> URI Class Initialized
INFO - 2016-12-29 19:26:17 --> Router Class Initialized
INFO - 2016-12-29 19:26:17 --> Output Class Initialized
INFO - 2016-12-29 19:26:17 --> Security Class Initialized
DEBUG - 2016-12-29 19:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:26:17 --> Input Class Initialized
INFO - 2016-12-29 19:26:17 --> Language Class Initialized
ERROR - 2016-12-29 19:26:17 --> 404 Page Not Found: Imagenes_portada/Galeria3.jpg
INFO - 2016-12-29 19:26:17 --> Config Class Initialized
INFO - 2016-12-29 19:26:17 --> Hooks Class Initialized
DEBUG - 2016-12-29 19:26:17 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:26:17 --> Utf8 Class Initialized
INFO - 2016-12-29 19:26:17 --> URI Class Initialized
INFO - 2016-12-29 19:26:17 --> Router Class Initialized
INFO - 2016-12-29 19:26:17 --> Output Class Initialized
INFO - 2016-12-29 19:26:17 --> Security Class Initialized
INFO - 2016-12-29 19:26:17 --> Config Class Initialized
INFO - 2016-12-29 19:26:17 --> Hooks Class Initialized
INFO - 2016-12-29 19:26:17 --> Config Class Initialized
INFO - 2016-12-29 19:26:17 --> Hooks Class Initialized
DEBUG - 2016-12-29 19:26:17 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:26:17 --> Utf8 Class Initialized
INFO - 2016-12-29 19:26:17 --> URI Class Initialized
INFO - 2016-12-29 19:26:17 --> Router Class Initialized
INFO - 2016-12-29 19:26:17 --> Output Class Initialized
INFO - 2016-12-29 19:26:17 --> Security Class Initialized
DEBUG - 2016-12-29 19:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:26:17 --> Input Class Initialized
INFO - 2016-12-29 19:26:17 --> Language Class Initialized
ERROR - 2016-12-29 19:26:17 --> 404 Page Not Found: Imagenes_portada/Galeria5.jpg
DEBUG - 2016-12-29 19:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:26:17 --> Input Class Initialized
INFO - 2016-12-29 19:26:17 --> Language Class Initialized
ERROR - 2016-12-29 19:26:17 --> 404 Page Not Found: Imagenes_portada/Galeria6.jpg
DEBUG - 2016-12-29 19:26:17 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:26:17 --> Utf8 Class Initialized
INFO - 2016-12-29 19:26:17 --> URI Class Initialized
INFO - 2016-12-29 19:26:17 --> Router Class Initialized
INFO - 2016-12-29 19:26:17 --> Output Class Initialized
INFO - 2016-12-29 19:26:17 --> Security Class Initialized
DEBUG - 2016-12-29 19:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:26:17 --> Input Class Initialized
INFO - 2016-12-29 19:26:17 --> Language Class Initialized
ERROR - 2016-12-29 19:26:17 --> 404 Page Not Found: Imagenes_portada/Galeria4.jpg
INFO - 2016-12-29 19:26:17 --> Config Class Initialized
INFO - 2016-12-29 19:26:17 --> Hooks Class Initialized
DEBUG - 2016-12-29 19:26:17 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:26:17 --> Utf8 Class Initialized
INFO - 2016-12-29 19:26:17 --> URI Class Initialized
INFO - 2016-12-29 19:26:17 --> Router Class Initialized
INFO - 2016-12-29 19:26:17 --> Output Class Initialized
INFO - 2016-12-29 19:26:17 --> Security Class Initialized
DEBUG - 2016-12-29 19:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:26:17 --> Input Class Initialized
INFO - 2016-12-29 19:26:17 --> Language Class Initialized
INFO - 2016-12-29 19:26:17 --> Loader Class Initialized
INFO - 2016-12-29 19:26:17 --> Database Driver Class Initialized
INFO - 2016-12-29 19:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 19:26:17 --> Controller Class Initialized
INFO - 2016-12-29 19:26:17 --> Helper loaded: url_helper
DEBUG - 2016-12-29 19:26:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 19:26:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 19:26:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 19:26:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 19:26:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 19:26:17 --> Final output sent to browser
DEBUG - 2016-12-29 19:26:17 --> Total execution time: 0.0145
INFO - 2016-12-29 19:27:27 --> Config Class Initialized
INFO - 2016-12-29 19:27:27 --> Hooks Class Initialized
DEBUG - 2016-12-29 19:27:27 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:27:27 --> Utf8 Class Initialized
INFO - 2016-12-29 19:27:27 --> URI Class Initialized
DEBUG - 2016-12-29 19:27:27 --> No URI present. Default controller set.
INFO - 2016-12-29 19:27:27 --> Router Class Initialized
INFO - 2016-12-29 19:27:27 --> Output Class Initialized
INFO - 2016-12-29 19:27:27 --> Security Class Initialized
DEBUG - 2016-12-29 19:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:27:27 --> Input Class Initialized
INFO - 2016-12-29 19:27:27 --> Language Class Initialized
INFO - 2016-12-29 19:27:27 --> Loader Class Initialized
INFO - 2016-12-29 19:27:27 --> Database Driver Class Initialized
INFO - 2016-12-29 19:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 19:27:27 --> Controller Class Initialized
INFO - 2016-12-29 19:27:27 --> Helper loaded: url_helper
DEBUG - 2016-12-29 19:27:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 19:27:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 19:27:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 19:27:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 19:27:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 19:27:27 --> Final output sent to browser
DEBUG - 2016-12-29 19:27:27 --> Total execution time: 0.0137
INFO - 2016-12-29 19:27:27 --> Config Class Initialized
INFO - 2016-12-29 19:27:27 --> Hooks Class Initialized
DEBUG - 2016-12-29 19:27:27 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:27:27 --> Utf8 Class Initialized
INFO - 2016-12-29 19:27:27 --> URI Class Initialized
INFO - 2016-12-29 19:27:27 --> Router Class Initialized
INFO - 2016-12-29 19:27:27 --> Output Class Initialized
INFO - 2016-12-29 19:27:27 --> Security Class Initialized
DEBUG - 2016-12-29 19:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:27:27 --> Input Class Initialized
INFO - 2016-12-29 19:27:27 --> Language Class Initialized
ERROR - 2016-12-29 19:27:27 --> 404 Page Not Found: Imagenes_portada/Galeria2.jpg
INFO - 2016-12-29 19:27:27 --> Config Class Initialized
INFO - 2016-12-29 19:27:27 --> Hooks Class Initialized
DEBUG - 2016-12-29 19:27:27 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:27:27 --> Utf8 Class Initialized
INFO - 2016-12-29 19:27:27 --> URI Class Initialized
INFO - 2016-12-29 19:27:27 --> Router Class Initialized
INFO - 2016-12-29 19:27:27 --> Output Class Initialized
INFO - 2016-12-29 19:27:27 --> Security Class Initialized
DEBUG - 2016-12-29 19:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:27:27 --> Input Class Initialized
INFO - 2016-12-29 19:27:27 --> Language Class Initialized
ERROR - 2016-12-29 19:27:27 --> 404 Page Not Found: Imagenes_portada/Galeria3.jpg
INFO - 2016-12-29 19:27:27 --> Config Class Initialized
INFO - 2016-12-29 19:27:27 --> Hooks Class Initialized
DEBUG - 2016-12-29 19:27:27 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:27:27 --> Utf8 Class Initialized
INFO - 2016-12-29 19:27:27 --> URI Class Initialized
INFO - 2016-12-29 19:27:27 --> Router Class Initialized
INFO - 2016-12-29 19:27:27 --> Output Class Initialized
INFO - 2016-12-29 19:27:27 --> Security Class Initialized
DEBUG - 2016-12-29 19:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:27:27 --> Input Class Initialized
INFO - 2016-12-29 19:27:27 --> Language Class Initialized
ERROR - 2016-12-29 19:27:27 --> 404 Page Not Found: Imagenes_portada/Galeria5.jpg
INFO - 2016-12-29 19:27:27 --> Config Class Initialized
INFO - 2016-12-29 19:27:27 --> Hooks Class Initialized
DEBUG - 2016-12-29 19:27:27 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:27:27 --> Utf8 Class Initialized
INFO - 2016-12-29 19:27:27 --> URI Class Initialized
INFO - 2016-12-29 19:27:27 --> Router Class Initialized
INFO - 2016-12-29 19:27:27 --> Output Class Initialized
INFO - 2016-12-29 19:27:27 --> Security Class Initialized
DEBUG - 2016-12-29 19:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:27:27 --> Input Class Initialized
INFO - 2016-12-29 19:27:27 --> Language Class Initialized
ERROR - 2016-12-29 19:27:27 --> 404 Page Not Found: Imagenes_portada/Galeria6.jpg
INFO - 2016-12-29 19:27:27 --> Config Class Initialized
INFO - 2016-12-29 19:27:27 --> Hooks Class Initialized
DEBUG - 2016-12-29 19:27:27 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:27:27 --> Utf8 Class Initialized
INFO - 2016-12-29 19:27:27 --> URI Class Initialized
INFO - 2016-12-29 19:27:27 --> Router Class Initialized
INFO - 2016-12-29 19:27:27 --> Output Class Initialized
INFO - 2016-12-29 19:27:27 --> Security Class Initialized
DEBUG - 2016-12-29 19:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:27:28 --> Input Class Initialized
INFO - 2016-12-29 19:27:28 --> Language Class Initialized
ERROR - 2016-12-29 19:27:28 --> 404 Page Not Found: Imagenes_portada/Galeria4.jpg
INFO - 2016-12-29 19:27:28 --> Config Class Initialized
INFO - 2016-12-29 19:27:28 --> Hooks Class Initialized
DEBUG - 2016-12-29 19:27:28 --> UTF-8 Support Enabled
INFO - 2016-12-29 19:27:28 --> Utf8 Class Initialized
INFO - 2016-12-29 19:27:28 --> URI Class Initialized
INFO - 2016-12-29 19:27:28 --> Router Class Initialized
INFO - 2016-12-29 19:27:28 --> Output Class Initialized
INFO - 2016-12-29 19:27:28 --> Security Class Initialized
DEBUG - 2016-12-29 19:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 19:27:28 --> Input Class Initialized
INFO - 2016-12-29 19:27:28 --> Language Class Initialized
INFO - 2016-12-29 19:27:28 --> Loader Class Initialized
INFO - 2016-12-29 19:27:28 --> Database Driver Class Initialized
INFO - 2016-12-29 19:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 19:27:28 --> Controller Class Initialized
INFO - 2016-12-29 19:27:28 --> Helper loaded: url_helper
DEBUG - 2016-12-29 19:27:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 19:27:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 19:27:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 19:27:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 19:27:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 19:27:28 --> Final output sent to browser
DEBUG - 2016-12-29 19:27:28 --> Total execution time: 0.0155
INFO - 2016-12-29 23:14:11 --> Config Class Initialized
INFO - 2016-12-29 23:14:11 --> Hooks Class Initialized
DEBUG - 2016-12-29 23:14:11 --> UTF-8 Support Enabled
INFO - 2016-12-29 23:14:11 --> Utf8 Class Initialized
INFO - 2016-12-29 23:14:11 --> URI Class Initialized
DEBUG - 2016-12-29 23:14:12 --> No URI present. Default controller set.
INFO - 2016-12-29 23:14:12 --> Router Class Initialized
INFO - 2016-12-29 23:14:12 --> Output Class Initialized
INFO - 2016-12-29 23:14:12 --> Security Class Initialized
DEBUG - 2016-12-29 23:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 23:14:12 --> Input Class Initialized
INFO - 2016-12-29 23:14:12 --> Language Class Initialized
INFO - 2016-12-29 23:14:12 --> Loader Class Initialized
INFO - 2016-12-29 23:14:12 --> Database Driver Class Initialized
INFO - 2016-12-29 23:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 23:14:12 --> Controller Class Initialized
INFO - 2016-12-29 23:14:12 --> Helper loaded: url_helper
DEBUG - 2016-12-29 23:14:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 23:14:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 23:14:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 23:14:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 23:14:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 23:14:13 --> Final output sent to browser
DEBUG - 2016-12-29 23:14:13 --> Total execution time: 1.2321
INFO - 2016-12-29 23:17:25 --> Config Class Initialized
INFO - 2016-12-29 23:17:25 --> Hooks Class Initialized
DEBUG - 2016-12-29 23:17:25 --> UTF-8 Support Enabled
INFO - 2016-12-29 23:17:25 --> Utf8 Class Initialized
INFO - 2016-12-29 23:17:25 --> URI Class Initialized
DEBUG - 2016-12-29 23:17:25 --> No URI present. Default controller set.
INFO - 2016-12-29 23:17:25 --> Router Class Initialized
INFO - 2016-12-29 23:17:25 --> Output Class Initialized
INFO - 2016-12-29 23:17:25 --> Security Class Initialized
DEBUG - 2016-12-29 23:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 23:17:25 --> Input Class Initialized
INFO - 2016-12-29 23:17:25 --> Language Class Initialized
INFO - 2016-12-29 23:17:25 --> Loader Class Initialized
INFO - 2016-12-29 23:17:26 --> Database Driver Class Initialized
INFO - 2016-12-29 23:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 23:17:26 --> Controller Class Initialized
INFO - 2016-12-29 23:17:26 --> Helper loaded: url_helper
DEBUG - 2016-12-29 23:17:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 23:17:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 23:17:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 23:17:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 23:17:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 23:17:26 --> Final output sent to browser
DEBUG - 2016-12-29 23:17:26 --> Total execution time: 1.1068
INFO - 2016-12-29 23:17:29 --> Config Class Initialized
INFO - 2016-12-29 23:17:29 --> Hooks Class Initialized
DEBUG - 2016-12-29 23:17:29 --> UTF-8 Support Enabled
INFO - 2016-12-29 23:17:29 --> Utf8 Class Initialized
INFO - 2016-12-29 23:17:29 --> URI Class Initialized
INFO - 2016-12-29 23:17:29 --> Config Class Initialized
INFO - 2016-12-29 23:17:29 --> Hooks Class Initialized
INFO - 2016-12-29 23:17:29 --> Router Class Initialized
DEBUG - 2016-12-29 23:17:29 --> UTF-8 Support Enabled
INFO - 2016-12-29 23:17:29 --> Utf8 Class Initialized
INFO - 2016-12-29 23:17:29 --> URI Class Initialized
INFO - 2016-12-29 23:17:29 --> Output Class Initialized
INFO - 2016-12-29 23:17:29 --> Router Class Initialized
INFO - 2016-12-29 23:17:29 --> Output Class Initialized
INFO - 2016-12-29 23:17:29 --> Security Class Initialized
INFO - 2016-12-29 23:17:29 --> Security Class Initialized
DEBUG - 2016-12-29 23:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 23:17:29 --> Input Class Initialized
DEBUG - 2016-12-29 23:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 23:17:29 --> Language Class Initialized
INFO - 2016-12-29 23:17:29 --> Input Class Initialized
INFO - 2016-12-29 23:17:29 --> Language Class Initialized
ERROR - 2016-12-29 23:17:29 --> 404 Page Not Found: Imagenes_portada/Galeria2.jpg
ERROR - 2016-12-29 23:17:29 --> 404 Page Not Found: Imagenes_portada/Galeria3.jpg
INFO - 2016-12-29 23:17:29 --> Config Class Initialized
INFO - 2016-12-29 23:17:29 --> Hooks Class Initialized
DEBUG - 2016-12-29 23:17:29 --> UTF-8 Support Enabled
INFO - 2016-12-29 23:17:29 --> Utf8 Class Initialized
INFO - 2016-12-29 23:17:29 --> URI Class Initialized
INFO - 2016-12-29 23:17:29 --> Router Class Initialized
INFO - 2016-12-29 23:17:29 --> Output Class Initialized
INFO - 2016-12-29 23:17:29 --> Security Class Initialized
DEBUG - 2016-12-29 23:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 23:17:29 --> Input Class Initialized
INFO - 2016-12-29 23:17:29 --> Language Class Initialized
ERROR - 2016-12-29 23:17:29 --> 404 Page Not Found: Imagenes_portada/Galeria4.jpg
INFO - 2016-12-29 23:17:29 --> Config Class Initialized
INFO - 2016-12-29 23:17:29 --> Hooks Class Initialized
DEBUG - 2016-12-29 23:17:29 --> UTF-8 Support Enabled
INFO - 2016-12-29 23:17:29 --> Utf8 Class Initialized
INFO - 2016-12-29 23:17:29 --> URI Class Initialized
INFO - 2016-12-29 23:17:29 --> Router Class Initialized
INFO - 2016-12-29 23:17:29 --> Output Class Initialized
INFO - 2016-12-29 23:17:29 --> Security Class Initialized
DEBUG - 2016-12-29 23:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 23:17:29 --> Input Class Initialized
INFO - 2016-12-29 23:17:29 --> Language Class Initialized
ERROR - 2016-12-29 23:17:29 --> 404 Page Not Found: Imagenes_portada/Galeria5.jpg
INFO - 2016-12-29 23:17:30 --> Config Class Initialized
INFO - 2016-12-29 23:17:30 --> Hooks Class Initialized
DEBUG - 2016-12-29 23:17:30 --> UTF-8 Support Enabled
INFO - 2016-12-29 23:17:30 --> Utf8 Class Initialized
INFO - 2016-12-29 23:17:30 --> URI Class Initialized
INFO - 2016-12-29 23:17:30 --> Router Class Initialized
INFO - 2016-12-29 23:17:30 --> Output Class Initialized
INFO - 2016-12-29 23:17:30 --> Security Class Initialized
DEBUG - 2016-12-29 23:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 23:17:30 --> Input Class Initialized
INFO - 2016-12-29 23:17:30 --> Language Class Initialized
ERROR - 2016-12-29 23:17:30 --> 404 Page Not Found: Imagenes_portada/Galeria6.jpg
INFO - 2016-12-29 23:17:46 --> Config Class Initialized
INFO - 2016-12-29 23:17:46 --> Hooks Class Initialized
DEBUG - 2016-12-29 23:17:46 --> UTF-8 Support Enabled
INFO - 2016-12-29 23:17:46 --> Utf8 Class Initialized
INFO - 2016-12-29 23:17:46 --> URI Class Initialized
INFO - 2016-12-29 23:17:46 --> Router Class Initialized
INFO - 2016-12-29 23:17:46 --> Output Class Initialized
INFO - 2016-12-29 23:17:46 --> Security Class Initialized
DEBUG - 2016-12-29 23:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 23:17:46 --> Input Class Initialized
INFO - 2016-12-29 23:17:46 --> Language Class Initialized
INFO - 2016-12-29 23:17:46 --> Loader Class Initialized
INFO - 2016-12-29 23:17:46 --> Database Driver Class Initialized
INFO - 2016-12-29 23:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 23:17:46 --> Controller Class Initialized
INFO - 2016-12-29 23:17:46 --> Helper loaded: url_helper
DEBUG - 2016-12-29 23:17:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 23:17:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 23:17:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 23:17:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 23:17:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 23:17:46 --> Final output sent to browser
DEBUG - 2016-12-29 23:17:46 --> Total execution time: 0.0144
INFO - 2016-12-29 23:26:33 --> Config Class Initialized
INFO - 2016-12-29 23:26:33 --> Hooks Class Initialized
DEBUG - 2016-12-29 23:26:33 --> UTF-8 Support Enabled
INFO - 2016-12-29 23:26:33 --> Utf8 Class Initialized
INFO - 2016-12-29 23:26:33 --> URI Class Initialized
DEBUG - 2016-12-29 23:26:33 --> No URI present. Default controller set.
INFO - 2016-12-29 23:26:34 --> Router Class Initialized
INFO - 2016-12-29 23:26:34 --> Output Class Initialized
INFO - 2016-12-29 23:26:34 --> Security Class Initialized
DEBUG - 2016-12-29 23:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 23:26:34 --> Input Class Initialized
INFO - 2016-12-29 23:26:34 --> Language Class Initialized
INFO - 2016-12-29 23:26:34 --> Loader Class Initialized
INFO - 2016-12-29 23:26:34 --> Database Driver Class Initialized
INFO - 2016-12-29 23:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 23:26:34 --> Controller Class Initialized
INFO - 2016-12-29 23:26:34 --> Helper loaded: url_helper
DEBUG - 2016-12-29 23:26:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 23:26:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 23:26:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 23:26:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 23:26:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 23:26:34 --> Final output sent to browser
DEBUG - 2016-12-29 23:26:34 --> Total execution time: 1.1130
INFO - 2016-12-29 23:26:35 --> Config Class Initialized
INFO - 2016-12-29 23:26:35 --> Hooks Class Initialized
DEBUG - 2016-12-29 23:26:35 --> UTF-8 Support Enabled
INFO - 2016-12-29 23:26:35 --> Utf8 Class Initialized
INFO - 2016-12-29 23:26:35 --> URI Class Initialized
INFO - 2016-12-29 23:26:35 --> Router Class Initialized
INFO - 2016-12-29 23:26:35 --> Output Class Initialized
INFO - 2016-12-29 23:26:35 --> Security Class Initialized
DEBUG - 2016-12-29 23:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 23:26:35 --> Input Class Initialized
INFO - 2016-12-29 23:26:35 --> Language Class Initialized
INFO - 2016-12-29 23:26:35 --> Loader Class Initialized
INFO - 2016-12-29 23:26:35 --> Database Driver Class Initialized
INFO - 2016-12-29 23:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 23:26:35 --> Controller Class Initialized
INFO - 2016-12-29 23:26:35 --> Helper loaded: url_helper
DEBUG - 2016-12-29 23:26:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 23:26:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 23:26:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 23:26:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 23:26:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 23:26:35 --> Final output sent to browser
DEBUG - 2016-12-29 23:26:35 --> Total execution time: 0.0331
INFO - 2016-12-29 23:26:36 --> Config Class Initialized
INFO - 2016-12-29 23:26:36 --> Hooks Class Initialized
DEBUG - 2016-12-29 23:26:36 --> UTF-8 Support Enabled
INFO - 2016-12-29 23:26:36 --> Utf8 Class Initialized
INFO - 2016-12-29 23:26:36 --> URI Class Initialized
INFO - 2016-12-29 23:26:36 --> Router Class Initialized
INFO - 2016-12-29 23:26:36 --> Output Class Initialized
INFO - 2016-12-29 23:26:36 --> Security Class Initialized
DEBUG - 2016-12-29 23:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 23:26:36 --> Input Class Initialized
INFO - 2016-12-29 23:26:36 --> Language Class Initialized
INFO - 2016-12-29 23:26:36 --> Loader Class Initialized
INFO - 2016-12-29 23:26:36 --> Database Driver Class Initialized
INFO - 2016-12-29 23:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 23:26:36 --> Controller Class Initialized
INFO - 2016-12-29 23:26:36 --> Helper loaded: url_helper
DEBUG - 2016-12-29 23:26:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 23:26:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 23:26:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 23:26:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 23:26:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 23:26:36 --> Final output sent to browser
DEBUG - 2016-12-29 23:26:36 --> Total execution time: 0.0147
INFO - 2016-12-29 23:26:36 --> Config Class Initialized
INFO - 2016-12-29 23:26:36 --> Hooks Class Initialized
DEBUG - 2016-12-29 23:26:36 --> UTF-8 Support Enabled
INFO - 2016-12-29 23:26:36 --> Utf8 Class Initialized
INFO - 2016-12-29 23:26:36 --> URI Class Initialized
INFO - 2016-12-29 23:26:36 --> Router Class Initialized
INFO - 2016-12-29 23:26:36 --> Output Class Initialized
INFO - 2016-12-29 23:26:36 --> Security Class Initialized
DEBUG - 2016-12-29 23:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 23:26:36 --> Input Class Initialized
INFO - 2016-12-29 23:26:36 --> Language Class Initialized
INFO - 2016-12-29 23:26:36 --> Loader Class Initialized
INFO - 2016-12-29 23:26:36 --> Database Driver Class Initialized
INFO - 2016-12-29 23:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 23:26:36 --> Controller Class Initialized
INFO - 2016-12-29 23:26:36 --> Helper loaded: url_helper
DEBUG - 2016-12-29 23:26:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 23:26:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 23:26:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 23:26:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 23:26:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 23:26:36 --> Final output sent to browser
DEBUG - 2016-12-29 23:26:36 --> Total execution time: 0.0137
INFO - 2016-12-29 23:26:36 --> Config Class Initialized
INFO - 2016-12-29 23:26:36 --> Hooks Class Initialized
DEBUG - 2016-12-29 23:26:36 --> UTF-8 Support Enabled
INFO - 2016-12-29 23:26:36 --> Utf8 Class Initialized
INFO - 2016-12-29 23:26:36 --> URI Class Initialized
INFO - 2016-12-29 23:26:36 --> Router Class Initialized
INFO - 2016-12-29 23:26:36 --> Output Class Initialized
INFO - 2016-12-29 23:26:36 --> Security Class Initialized
DEBUG - 2016-12-29 23:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 23:26:36 --> Input Class Initialized
INFO - 2016-12-29 23:26:36 --> Language Class Initialized
INFO - 2016-12-29 23:26:36 --> Loader Class Initialized
INFO - 2016-12-29 23:26:36 --> Database Driver Class Initialized
INFO - 2016-12-29 23:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 23:26:36 --> Controller Class Initialized
INFO - 2016-12-29 23:26:36 --> Helper loaded: url_helper
DEBUG - 2016-12-29 23:26:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 23:26:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 23:26:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 23:26:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 23:26:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 23:26:36 --> Final output sent to browser
DEBUG - 2016-12-29 23:26:36 --> Total execution time: 0.0150
INFO - 2016-12-29 23:26:37 --> Config Class Initialized
INFO - 2016-12-29 23:26:37 --> Hooks Class Initialized
DEBUG - 2016-12-29 23:26:37 --> UTF-8 Support Enabled
INFO - 2016-12-29 23:26:37 --> Utf8 Class Initialized
INFO - 2016-12-29 23:26:37 --> URI Class Initialized
INFO - 2016-12-29 23:26:37 --> Router Class Initialized
INFO - 2016-12-29 23:26:37 --> Output Class Initialized
INFO - 2016-12-29 23:26:37 --> Security Class Initialized
DEBUG - 2016-12-29 23:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 23:26:37 --> Input Class Initialized
INFO - 2016-12-29 23:26:37 --> Language Class Initialized
INFO - 2016-12-29 23:26:37 --> Loader Class Initialized
INFO - 2016-12-29 23:26:37 --> Database Driver Class Initialized
INFO - 2016-12-29 23:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 23:26:37 --> Controller Class Initialized
INFO - 2016-12-29 23:26:37 --> Helper loaded: url_helper
DEBUG - 2016-12-29 23:26:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 23:26:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 23:26:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 23:26:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 23:26:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 23:26:37 --> Final output sent to browser
DEBUG - 2016-12-29 23:26:37 --> Total execution time: 0.0133
INFO - 2016-12-29 23:26:37 --> Config Class Initialized
INFO - 2016-12-29 23:26:37 --> Hooks Class Initialized
DEBUG - 2016-12-29 23:26:37 --> UTF-8 Support Enabled
INFO - 2016-12-29 23:26:37 --> Utf8 Class Initialized
INFO - 2016-12-29 23:26:37 --> URI Class Initialized
INFO - 2016-12-29 23:26:37 --> Router Class Initialized
INFO - 2016-12-29 23:26:37 --> Output Class Initialized
INFO - 2016-12-29 23:26:37 --> Security Class Initialized
DEBUG - 2016-12-29 23:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 23:26:37 --> Input Class Initialized
INFO - 2016-12-29 23:26:37 --> Language Class Initialized
INFO - 2016-12-29 23:26:37 --> Loader Class Initialized
INFO - 2016-12-29 23:26:37 --> Database Driver Class Initialized
INFO - 2016-12-29 23:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 23:26:37 --> Controller Class Initialized
INFO - 2016-12-29 23:26:37 --> Helper loaded: url_helper
DEBUG - 2016-12-29 23:26:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 23:26:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 23:26:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 23:26:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 23:26:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 23:26:37 --> Final output sent to browser
DEBUG - 2016-12-29 23:26:37 --> Total execution time: 0.0131
INFO - 2016-12-29 23:26:38 --> Config Class Initialized
INFO - 2016-12-29 23:26:38 --> Hooks Class Initialized
DEBUG - 2016-12-29 23:26:38 --> UTF-8 Support Enabled
INFO - 2016-12-29 23:26:38 --> Utf8 Class Initialized
INFO - 2016-12-29 23:26:38 --> URI Class Initialized
INFO - 2016-12-29 23:26:38 --> Router Class Initialized
INFO - 2016-12-29 23:26:38 --> Output Class Initialized
INFO - 2016-12-29 23:26:38 --> Security Class Initialized
DEBUG - 2016-12-29 23:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 23:26:38 --> Input Class Initialized
INFO - 2016-12-29 23:26:38 --> Language Class Initialized
INFO - 2016-12-29 23:26:38 --> Loader Class Initialized
INFO - 2016-12-29 23:26:38 --> Database Driver Class Initialized
INFO - 2016-12-29 23:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 23:26:38 --> Controller Class Initialized
INFO - 2016-12-29 23:26:38 --> Helper loaded: url_helper
DEBUG - 2016-12-29 23:26:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 23:26:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 23:26:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 23:26:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 23:26:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 23:26:38 --> Final output sent to browser
DEBUG - 2016-12-29 23:26:38 --> Total execution time: 0.0134
INFO - 2016-12-29 23:26:38 --> Config Class Initialized
INFO - 2016-12-29 23:26:38 --> Hooks Class Initialized
DEBUG - 2016-12-29 23:26:38 --> UTF-8 Support Enabled
INFO - 2016-12-29 23:26:38 --> Utf8 Class Initialized
INFO - 2016-12-29 23:26:38 --> URI Class Initialized
INFO - 2016-12-29 23:26:38 --> Router Class Initialized
INFO - 2016-12-29 23:26:38 --> Output Class Initialized
INFO - 2016-12-29 23:26:38 --> Security Class Initialized
DEBUG - 2016-12-29 23:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 23:26:38 --> Input Class Initialized
INFO - 2016-12-29 23:26:38 --> Language Class Initialized
INFO - 2016-12-29 23:26:38 --> Loader Class Initialized
INFO - 2016-12-29 23:26:38 --> Database Driver Class Initialized
INFO - 2016-12-29 23:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 23:26:38 --> Controller Class Initialized
INFO - 2016-12-29 23:26:38 --> Helper loaded: url_helper
DEBUG - 2016-12-29 23:26:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 23:26:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 23:26:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 23:26:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 23:26:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 23:26:38 --> Final output sent to browser
DEBUG - 2016-12-29 23:26:38 --> Total execution time: 0.0134
INFO - 2016-12-29 23:26:39 --> Config Class Initialized
INFO - 2016-12-29 23:26:39 --> Hooks Class Initialized
DEBUG - 2016-12-29 23:26:39 --> UTF-8 Support Enabled
INFO - 2016-12-29 23:26:39 --> Utf8 Class Initialized
INFO - 2016-12-29 23:26:39 --> URI Class Initialized
INFO - 2016-12-29 23:26:39 --> Router Class Initialized
INFO - 2016-12-29 23:26:39 --> Output Class Initialized
INFO - 2016-12-29 23:26:39 --> Security Class Initialized
DEBUG - 2016-12-29 23:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 23:26:39 --> Input Class Initialized
INFO - 2016-12-29 23:26:39 --> Language Class Initialized
INFO - 2016-12-29 23:26:39 --> Loader Class Initialized
INFO - 2016-12-29 23:26:39 --> Database Driver Class Initialized
INFO - 2016-12-29 23:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 23:26:39 --> Controller Class Initialized
INFO - 2016-12-29 23:26:39 --> Helper loaded: url_helper
DEBUG - 2016-12-29 23:26:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 23:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 23:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 23:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 23:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 23:26:39 --> Final output sent to browser
DEBUG - 2016-12-29 23:26:39 --> Total execution time: 0.0278
INFO - 2016-12-29 23:26:39 --> Config Class Initialized
INFO - 2016-12-29 23:26:39 --> Hooks Class Initialized
DEBUG - 2016-12-29 23:26:39 --> UTF-8 Support Enabled
INFO - 2016-12-29 23:26:39 --> Utf8 Class Initialized
INFO - 2016-12-29 23:26:39 --> URI Class Initialized
INFO - 2016-12-29 23:26:39 --> Router Class Initialized
INFO - 2016-12-29 23:26:39 --> Output Class Initialized
INFO - 2016-12-29 23:26:39 --> Security Class Initialized
DEBUG - 2016-12-29 23:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 23:26:39 --> Input Class Initialized
INFO - 2016-12-29 23:26:39 --> Language Class Initialized
INFO - 2016-12-29 23:26:39 --> Loader Class Initialized
INFO - 2016-12-29 23:26:39 --> Database Driver Class Initialized
INFO - 2016-12-29 23:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 23:26:39 --> Controller Class Initialized
INFO - 2016-12-29 23:26:39 --> Helper loaded: url_helper
DEBUG - 2016-12-29 23:26:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 23:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 23:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 23:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 23:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 23:26:39 --> Final output sent to browser
DEBUG - 2016-12-29 23:26:39 --> Total execution time: 0.0134
INFO - 2016-12-29 23:26:39 --> Config Class Initialized
INFO - 2016-12-29 23:26:39 --> Hooks Class Initialized
DEBUG - 2016-12-29 23:26:39 --> UTF-8 Support Enabled
INFO - 2016-12-29 23:26:39 --> Utf8 Class Initialized
INFO - 2016-12-29 23:26:39 --> URI Class Initialized
INFO - 2016-12-29 23:26:39 --> Router Class Initialized
INFO - 2016-12-29 23:26:39 --> Output Class Initialized
INFO - 2016-12-29 23:26:39 --> Security Class Initialized
DEBUG - 2016-12-29 23:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 23:26:39 --> Input Class Initialized
INFO - 2016-12-29 23:26:39 --> Language Class Initialized
INFO - 2016-12-29 23:26:39 --> Loader Class Initialized
INFO - 2016-12-29 23:26:39 --> Database Driver Class Initialized
INFO - 2016-12-29 23:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 23:26:39 --> Controller Class Initialized
INFO - 2016-12-29 23:26:39 --> Helper loaded: url_helper
DEBUG - 2016-12-29 23:26:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 23:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 23:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 23:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 23:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 23:26:39 --> Final output sent to browser
DEBUG - 2016-12-29 23:26:39 --> Total execution time: 0.0141
INFO - 2016-12-29 23:26:40 --> Config Class Initialized
INFO - 2016-12-29 23:26:40 --> Hooks Class Initialized
DEBUG - 2016-12-29 23:26:40 --> UTF-8 Support Enabled
INFO - 2016-12-29 23:26:40 --> Utf8 Class Initialized
INFO - 2016-12-29 23:26:40 --> URI Class Initialized
INFO - 2016-12-29 23:26:40 --> Router Class Initialized
INFO - 2016-12-29 23:26:40 --> Output Class Initialized
INFO - 2016-12-29 23:26:40 --> Security Class Initialized
DEBUG - 2016-12-29 23:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-29 23:26:40 --> Input Class Initialized
INFO - 2016-12-29 23:26:40 --> Language Class Initialized
INFO - 2016-12-29 23:26:40 --> Loader Class Initialized
INFO - 2016-12-29 23:26:40 --> Database Driver Class Initialized
INFO - 2016-12-29 23:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-29 23:26:40 --> Controller Class Initialized
INFO - 2016-12-29 23:26:40 --> Helper loaded: url_helper
DEBUG - 2016-12-29 23:26:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-29 23:26:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-29 23:26:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-29 23:26:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-29 23:26:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-29 23:26:40 --> Final output sent to browser
DEBUG - 2016-12-29 23:26:40 --> Total execution time: 0.0138

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-27 01:13:35 --> Config Class Initialized
INFO - 2017-02-27 01:13:36 --> Hooks Class Initialized
DEBUG - 2017-02-27 01:13:36 --> UTF-8 Support Enabled
INFO - 2017-02-27 01:13:36 --> Utf8 Class Initialized
INFO - 2017-02-27 01:13:36 --> URI Class Initialized
DEBUG - 2017-02-27 01:13:36 --> No URI present. Default controller set.
INFO - 2017-02-27 01:13:36 --> Router Class Initialized
INFO - 2017-02-27 01:13:36 --> Output Class Initialized
INFO - 2017-02-27 01:13:36 --> Security Class Initialized
DEBUG - 2017-02-27 01:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 01:13:36 --> Input Class Initialized
INFO - 2017-02-27 01:13:36 --> Language Class Initialized
INFO - 2017-02-27 01:13:36 --> Loader Class Initialized
INFO - 2017-02-27 01:13:37 --> Database Driver Class Initialized
INFO - 2017-02-27 01:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 01:13:37 --> Controller Class Initialized
INFO - 2017-02-27 01:13:37 --> Helper loaded: url_helper
DEBUG - 2017-02-27 01:13:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 01:13:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 01:13:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 01:13:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 01:13:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 01:13:38 --> Final output sent to browser
DEBUG - 2017-02-27 01:13:38 --> Total execution time: 2.5258
INFO - 2017-02-27 01:14:02 --> Config Class Initialized
INFO - 2017-02-27 01:14:02 --> Hooks Class Initialized
DEBUG - 2017-02-27 01:14:02 --> UTF-8 Support Enabled
INFO - 2017-02-27 01:14:02 --> Utf8 Class Initialized
INFO - 2017-02-27 01:14:02 --> URI Class Initialized
INFO - 2017-02-27 01:14:02 --> Router Class Initialized
INFO - 2017-02-27 01:14:02 --> Output Class Initialized
INFO - 2017-02-27 01:14:02 --> Security Class Initialized
DEBUG - 2017-02-27 01:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 01:14:02 --> Input Class Initialized
INFO - 2017-02-27 01:14:02 --> Language Class Initialized
INFO - 2017-02-27 01:14:02 --> Loader Class Initialized
INFO - 2017-02-27 01:14:03 --> Database Driver Class Initialized
INFO - 2017-02-27 01:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 01:14:04 --> Controller Class Initialized
INFO - 2017-02-27 01:14:04 --> Helper loaded: url_helper
DEBUG - 2017-02-27 01:14:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 01:14:13 --> Config Class Initialized
INFO - 2017-02-27 01:14:13 --> Hooks Class Initialized
DEBUG - 2017-02-27 01:14:13 --> UTF-8 Support Enabled
INFO - 2017-02-27 01:14:13 --> Utf8 Class Initialized
INFO - 2017-02-27 01:14:13 --> URI Class Initialized
INFO - 2017-02-27 01:14:13 --> Router Class Initialized
INFO - 2017-02-27 01:14:13 --> Output Class Initialized
INFO - 2017-02-27 01:14:13 --> Security Class Initialized
DEBUG - 2017-02-27 01:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 01:14:13 --> Input Class Initialized
INFO - 2017-02-27 01:14:13 --> Language Class Initialized
INFO - 2017-02-27 01:14:13 --> Loader Class Initialized
INFO - 2017-02-27 01:14:14 --> Database Driver Class Initialized
INFO - 2017-02-27 01:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 01:14:14 --> Controller Class Initialized
INFO - 2017-02-27 01:14:14 --> Helper loaded: date_helper
DEBUG - 2017-02-27 01:14:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 01:14:14 --> Helper loaded: url_helper
INFO - 2017-02-27 01:14:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 01:14:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-27 01:14:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-27 01:14:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-27 01:14:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 01:14:15 --> Final output sent to browser
DEBUG - 2017-02-27 01:14:15 --> Total execution time: 1.4427
INFO - 2017-02-27 01:14:33 --> Config Class Initialized
INFO - 2017-02-27 01:14:33 --> Hooks Class Initialized
DEBUG - 2017-02-27 01:14:34 --> UTF-8 Support Enabled
INFO - 2017-02-27 01:14:34 --> Utf8 Class Initialized
INFO - 2017-02-27 01:14:34 --> URI Class Initialized
INFO - 2017-02-27 01:14:34 --> Router Class Initialized
INFO - 2017-02-27 01:14:35 --> Output Class Initialized
INFO - 2017-02-27 01:14:35 --> Security Class Initialized
DEBUG - 2017-02-27 01:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 01:14:35 --> Input Class Initialized
INFO - 2017-02-27 01:14:35 --> Language Class Initialized
INFO - 2017-02-27 01:14:36 --> Loader Class Initialized
INFO - 2017-02-27 01:14:36 --> Database Driver Class Initialized
INFO - 2017-02-27 01:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 01:14:36 --> Controller Class Initialized
INFO - 2017-02-27 01:14:36 --> Helper loaded: url_helper
DEBUG - 2017-02-27 01:14:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 01:14:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 01:14:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 01:14:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 01:14:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 01:14:38 --> Final output sent to browser
DEBUG - 2017-02-27 01:14:38 --> Total execution time: 7.7476
INFO - 2017-02-27 01:14:48 --> Config Class Initialized
INFO - 2017-02-27 01:14:48 --> Config Class Initialized
INFO - 2017-02-27 01:14:48 --> Hooks Class Initialized
INFO - 2017-02-27 01:14:48 --> Hooks Class Initialized
DEBUG - 2017-02-27 01:14:48 --> UTF-8 Support Enabled
INFO - 2017-02-27 01:14:48 --> Utf8 Class Initialized
DEBUG - 2017-02-27 01:14:48 --> UTF-8 Support Enabled
INFO - 2017-02-27 01:14:48 --> Utf8 Class Initialized
INFO - 2017-02-27 01:14:48 --> URI Class Initialized
INFO - 2017-02-27 01:14:48 --> URI Class Initialized
INFO - 2017-02-27 01:14:49 --> Router Class Initialized
INFO - 2017-02-27 01:14:49 --> Router Class Initialized
INFO - 2017-02-27 01:14:49 --> Output Class Initialized
INFO - 2017-02-27 01:14:49 --> Output Class Initialized
INFO - 2017-02-27 01:14:49 --> Security Class Initialized
INFO - 2017-02-27 01:14:49 --> Security Class Initialized
DEBUG - 2017-02-27 01:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 01:14:49 --> Input Class Initialized
INFO - 2017-02-27 01:14:49 --> Language Class Initialized
DEBUG - 2017-02-27 01:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 01:14:49 --> Input Class Initialized
INFO - 2017-02-27 01:14:49 --> Language Class Initialized
INFO - 2017-02-27 01:14:49 --> Loader Class Initialized
INFO - 2017-02-27 01:14:49 --> Loader Class Initialized
INFO - 2017-02-27 01:14:49 --> Database Driver Class Initialized
INFO - 2017-02-27 01:14:49 --> Database Driver Class Initialized
INFO - 2017-02-27 01:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 01:14:49 --> Controller Class Initialized
INFO - 2017-02-27 01:14:50 --> Helper loaded: date_helper
DEBUG - 2017-02-27 01:14:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 01:14:50 --> Helper loaded: url_helper
INFO - 2017-02-27 01:14:50 --> Helper loaded: download_helper
INFO - 2017-02-27 01:14:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 01:14:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-27 01:14:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-27 01:14:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-27 01:14:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 01:14:51 --> Final output sent to browser
DEBUG - 2017-02-27 01:14:51 --> Total execution time: 2.5708
INFO - 2017-02-27 01:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 01:14:51 --> Controller Class Initialized
INFO - 2017-02-27 01:14:52 --> Helper loaded: date_helper
DEBUG - 2017-02-27 01:14:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 01:14:52 --> Helper loaded: url_helper
INFO - 2017-02-27 01:14:52 --> Helper loaded: download_helper
INFO - 2017-02-27 01:14:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 01:14:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-27 01:14:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-27 01:14:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-27 01:14:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 01:14:52 --> Final output sent to browser
DEBUG - 2017-02-27 01:14:52 --> Total execution time: 3.4218
INFO - 2017-02-27 01:14:59 --> Config Class Initialized
INFO - 2017-02-27 01:14:59 --> Hooks Class Initialized
DEBUG - 2017-02-27 01:14:59 --> UTF-8 Support Enabled
INFO - 2017-02-27 01:14:59 --> Utf8 Class Initialized
INFO - 2017-02-27 01:14:59 --> URI Class Initialized
INFO - 2017-02-27 01:14:59 --> Router Class Initialized
INFO - 2017-02-27 01:14:59 --> Output Class Initialized
INFO - 2017-02-27 01:14:59 --> Security Class Initialized
DEBUG - 2017-02-27 01:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 01:14:59 --> Input Class Initialized
INFO - 2017-02-27 01:14:59 --> Language Class Initialized
INFO - 2017-02-27 01:14:59 --> Loader Class Initialized
INFO - 2017-02-27 01:15:00 --> Database Driver Class Initialized
INFO - 2017-02-27 01:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 01:15:00 --> Controller Class Initialized
INFO - 2017-02-27 01:15:00 --> Helper loaded: date_helper
DEBUG - 2017-02-27 01:15:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 01:15:00 --> Helper loaded: url_helper
INFO - 2017-02-27 01:15:00 --> Helper loaded: download_helper
INFO - 2017-02-27 01:15:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 01:15:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-27 01:15:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-27 01:15:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-27 01:15:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 01:15:00 --> Final output sent to browser
DEBUG - 2017-02-27 01:15:00 --> Total execution time: 1.2761
INFO - 2017-02-27 01:15:05 --> Config Class Initialized
INFO - 2017-02-27 01:15:05 --> Hooks Class Initialized
DEBUG - 2017-02-27 01:15:05 --> UTF-8 Support Enabled
INFO - 2017-02-27 01:15:05 --> Utf8 Class Initialized
INFO - 2017-02-27 01:15:05 --> URI Class Initialized
INFO - 2017-02-27 01:15:05 --> Router Class Initialized
INFO - 2017-02-27 01:15:05 --> Output Class Initialized
INFO - 2017-02-27 01:15:05 --> Security Class Initialized
DEBUG - 2017-02-27 01:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 01:15:05 --> Input Class Initialized
INFO - 2017-02-27 01:15:05 --> Language Class Initialized
INFO - 2017-02-27 01:15:05 --> Loader Class Initialized
INFO - 2017-02-27 01:15:06 --> Database Driver Class Initialized
INFO - 2017-02-27 01:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 01:15:06 --> Controller Class Initialized
INFO - 2017-02-27 01:15:06 --> Helper loaded: url_helper
DEBUG - 2017-02-27 01:15:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 01:15:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 01:15:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 01:15:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 01:15:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 01:15:06 --> Final output sent to browser
DEBUG - 2017-02-27 01:15:06 --> Total execution time: 1.2299
INFO - 2017-02-27 01:52:36 --> Config Class Initialized
INFO - 2017-02-27 01:52:36 --> Hooks Class Initialized
DEBUG - 2017-02-27 01:52:36 --> UTF-8 Support Enabled
INFO - 2017-02-27 01:52:36 --> Utf8 Class Initialized
INFO - 2017-02-27 01:52:36 --> URI Class Initialized
INFO - 2017-02-27 01:52:36 --> Router Class Initialized
INFO - 2017-02-27 01:52:36 --> Output Class Initialized
INFO - 2017-02-27 01:52:36 --> Security Class Initialized
DEBUG - 2017-02-27 01:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 01:52:37 --> Input Class Initialized
INFO - 2017-02-27 01:52:37 --> Language Class Initialized
INFO - 2017-02-27 01:52:37 --> Loader Class Initialized
INFO - 2017-02-27 01:52:37 --> Database Driver Class Initialized
INFO - 2017-02-27 01:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 01:52:37 --> Controller Class Initialized
INFO - 2017-02-27 01:52:37 --> Helper loaded: date_helper
INFO - 2017-02-27 01:52:38 --> Helper loaded: url_helper
DEBUG - 2017-02-27 01:52:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 01:52:38 --> Helper loaded: form_helper
INFO - 2017-02-27 01:52:38 --> Form Validation Class Initialized
INFO - 2017-02-27 01:52:38 --> Final output sent to browser
DEBUG - 2017-02-27 01:52:38 --> Total execution time: 1.7639
INFO - 2017-02-27 01:52:46 --> Config Class Initialized
INFO - 2017-02-27 01:52:46 --> Hooks Class Initialized
DEBUG - 2017-02-27 01:52:46 --> UTF-8 Support Enabled
INFO - 2017-02-27 01:52:46 --> Utf8 Class Initialized
INFO - 2017-02-27 01:52:46 --> URI Class Initialized
INFO - 2017-02-27 01:52:46 --> Router Class Initialized
INFO - 2017-02-27 01:52:46 --> Output Class Initialized
INFO - 2017-02-27 01:52:46 --> Security Class Initialized
DEBUG - 2017-02-27 01:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 01:52:46 --> Input Class Initialized
INFO - 2017-02-27 01:52:46 --> Language Class Initialized
INFO - 2017-02-27 01:52:46 --> Loader Class Initialized
INFO - 2017-02-27 01:52:46 --> Database Driver Class Initialized
INFO - 2017-02-27 01:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 01:52:46 --> Controller Class Initialized
INFO - 2017-02-27 01:52:46 --> Helper loaded: date_helper
DEBUG - 2017-02-27 01:52:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 01:52:46 --> Helper loaded: url_helper
INFO - 2017-02-27 01:52:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 01:52:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-02-27 01:52:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-27 01:52:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-02-27 01:52:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-02-27 01:52:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 01:52:46 --> Final output sent to browser
DEBUG - 2017-02-27 01:52:46 --> Total execution time: 0.3995
INFO - 2017-02-27 01:52:47 --> Config Class Initialized
INFO - 2017-02-27 01:52:47 --> Hooks Class Initialized
DEBUG - 2017-02-27 01:52:47 --> UTF-8 Support Enabled
INFO - 2017-02-27 01:52:47 --> Utf8 Class Initialized
INFO - 2017-02-27 01:52:47 --> URI Class Initialized
INFO - 2017-02-27 01:52:47 --> Router Class Initialized
INFO - 2017-02-27 01:52:47 --> Output Class Initialized
INFO - 2017-02-27 01:52:47 --> Security Class Initialized
DEBUG - 2017-02-27 01:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 01:52:47 --> Input Class Initialized
INFO - 2017-02-27 01:52:47 --> Language Class Initialized
INFO - 2017-02-27 01:52:47 --> Loader Class Initialized
INFO - 2017-02-27 01:52:47 --> Database Driver Class Initialized
INFO - 2017-02-27 01:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 01:52:47 --> Controller Class Initialized
INFO - 2017-02-27 01:52:47 --> Helper loaded: url_helper
DEBUG - 2017-02-27 01:52:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 01:52:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 01:52:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 01:52:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 01:52:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 01:52:47 --> Final output sent to browser
DEBUG - 2017-02-27 01:52:47 --> Total execution time: 0.2643
INFO - 2017-02-27 01:52:51 --> Config Class Initialized
INFO - 2017-02-27 01:52:51 --> Hooks Class Initialized
DEBUG - 2017-02-27 01:52:51 --> UTF-8 Support Enabled
INFO - 2017-02-27 01:52:51 --> Utf8 Class Initialized
INFO - 2017-02-27 01:52:51 --> URI Class Initialized
INFO - 2017-02-27 01:52:51 --> Router Class Initialized
INFO - 2017-02-27 01:52:51 --> Output Class Initialized
INFO - 2017-02-27 01:52:51 --> Security Class Initialized
DEBUG - 2017-02-27 01:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 01:52:51 --> Input Class Initialized
INFO - 2017-02-27 01:52:51 --> Language Class Initialized
INFO - 2017-02-27 01:52:51 --> Loader Class Initialized
INFO - 2017-02-27 01:52:51 --> Database Driver Class Initialized
INFO - 2017-02-27 01:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 01:52:51 --> Controller Class Initialized
INFO - 2017-02-27 01:52:51 --> Helper loaded: date_helper
DEBUG - 2017-02-27 01:52:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 01:52:51 --> Helper loaded: url_helper
INFO - 2017-02-27 01:52:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 01:52:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-27 01:52:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-27 01:52:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-27 01:52:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 01:52:51 --> Final output sent to browser
DEBUG - 2017-02-27 01:52:51 --> Total execution time: 0.0306
INFO - 2017-02-27 01:52:53 --> Config Class Initialized
INFO - 2017-02-27 01:52:53 --> Hooks Class Initialized
DEBUG - 2017-02-27 01:52:53 --> UTF-8 Support Enabled
INFO - 2017-02-27 01:52:53 --> Utf8 Class Initialized
INFO - 2017-02-27 01:52:53 --> URI Class Initialized
INFO - 2017-02-27 01:52:53 --> Router Class Initialized
INFO - 2017-02-27 01:52:53 --> Output Class Initialized
INFO - 2017-02-27 01:52:53 --> Security Class Initialized
DEBUG - 2017-02-27 01:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 01:52:53 --> Input Class Initialized
INFO - 2017-02-27 01:52:53 --> Language Class Initialized
INFO - 2017-02-27 01:52:53 --> Loader Class Initialized
INFO - 2017-02-27 01:52:53 --> Database Driver Class Initialized
INFO - 2017-02-27 01:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 01:52:53 --> Controller Class Initialized
INFO - 2017-02-27 01:52:53 --> Helper loaded: url_helper
DEBUG - 2017-02-27 01:52:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 01:52:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 01:52:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 01:52:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 01:52:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 01:52:53 --> Final output sent to browser
DEBUG - 2017-02-27 01:52:53 --> Total execution time: 0.0135
INFO - 2017-02-27 01:52:54 --> Config Class Initialized
INFO - 2017-02-27 01:52:54 --> Hooks Class Initialized
DEBUG - 2017-02-27 01:52:54 --> UTF-8 Support Enabled
INFO - 2017-02-27 01:52:54 --> Utf8 Class Initialized
INFO - 2017-02-27 01:52:54 --> URI Class Initialized
INFO - 2017-02-27 01:52:54 --> Router Class Initialized
INFO - 2017-02-27 01:52:54 --> Output Class Initialized
INFO - 2017-02-27 01:52:54 --> Security Class Initialized
DEBUG - 2017-02-27 01:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 01:52:54 --> Input Class Initialized
INFO - 2017-02-27 01:52:54 --> Language Class Initialized
INFO - 2017-02-27 01:52:54 --> Loader Class Initialized
INFO - 2017-02-27 01:52:54 --> Database Driver Class Initialized
INFO - 2017-02-27 01:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 01:52:54 --> Controller Class Initialized
INFO - 2017-02-27 01:52:54 --> Helper loaded: date_helper
DEBUG - 2017-02-27 01:52:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 01:52:54 --> Helper loaded: url_helper
INFO - 2017-02-27 01:52:54 --> Helper loaded: download_helper
INFO - 2017-02-27 01:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 01:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-27 01:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-27 01:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-27 01:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 01:52:54 --> Final output sent to browser
DEBUG - 2017-02-27 01:52:54 --> Total execution time: 0.0891
INFO - 2017-02-27 01:52:54 --> Config Class Initialized
INFO - 2017-02-27 01:52:54 --> Hooks Class Initialized
DEBUG - 2017-02-27 01:52:54 --> UTF-8 Support Enabled
INFO - 2017-02-27 01:52:54 --> Utf8 Class Initialized
INFO - 2017-02-27 01:52:54 --> URI Class Initialized
INFO - 2017-02-27 01:52:54 --> Router Class Initialized
INFO - 2017-02-27 01:52:54 --> Output Class Initialized
INFO - 2017-02-27 01:52:54 --> Security Class Initialized
DEBUG - 2017-02-27 01:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 01:52:54 --> Input Class Initialized
INFO - 2017-02-27 01:52:54 --> Language Class Initialized
INFO - 2017-02-27 01:52:54 --> Loader Class Initialized
INFO - 2017-02-27 01:52:54 --> Database Driver Class Initialized
INFO - 2017-02-27 01:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 01:52:54 --> Controller Class Initialized
INFO - 2017-02-27 01:52:54 --> Helper loaded: url_helper
DEBUG - 2017-02-27 01:52:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 01:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 01:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 01:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 01:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 01:52:54 --> Final output sent to browser
DEBUG - 2017-02-27 01:52:54 --> Total execution time: 0.0138
INFO - 2017-02-27 01:52:55 --> Config Class Initialized
INFO - 2017-02-27 01:52:55 --> Hooks Class Initialized
DEBUG - 2017-02-27 01:52:55 --> UTF-8 Support Enabled
INFO - 2017-02-27 01:52:55 --> Utf8 Class Initialized
INFO - 2017-02-27 01:52:55 --> URI Class Initialized
INFO - 2017-02-27 01:52:55 --> Router Class Initialized
INFO - 2017-02-27 01:52:55 --> Output Class Initialized
INFO - 2017-02-27 01:52:55 --> Security Class Initialized
DEBUG - 2017-02-27 01:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 01:52:55 --> Input Class Initialized
INFO - 2017-02-27 01:52:55 --> Language Class Initialized
INFO - 2017-02-27 01:52:55 --> Loader Class Initialized
INFO - 2017-02-27 01:52:55 --> Database Driver Class Initialized
INFO - 2017-02-27 01:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 01:52:55 --> Controller Class Initialized
INFO - 2017-02-27 01:52:55 --> Helper loaded: date_helper
DEBUG - 2017-02-27 01:52:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 01:52:55 --> Helper loaded: url_helper
INFO - 2017-02-27 01:52:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 01:52:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-27 01:52:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-27 01:52:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-27 01:52:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 01:52:55 --> Final output sent to browser
DEBUG - 2017-02-27 01:52:55 --> Total execution time: 0.0148
INFO - 2017-02-27 01:52:56 --> Config Class Initialized
INFO - 2017-02-27 01:52:56 --> Hooks Class Initialized
DEBUG - 2017-02-27 01:52:56 --> UTF-8 Support Enabled
INFO - 2017-02-27 01:52:56 --> Utf8 Class Initialized
INFO - 2017-02-27 01:52:56 --> URI Class Initialized
INFO - 2017-02-27 01:52:56 --> Router Class Initialized
INFO - 2017-02-27 01:52:56 --> Output Class Initialized
INFO - 2017-02-27 01:52:56 --> Security Class Initialized
DEBUG - 2017-02-27 01:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 01:52:56 --> Input Class Initialized
INFO - 2017-02-27 01:52:56 --> Language Class Initialized
INFO - 2017-02-27 01:52:56 --> Loader Class Initialized
INFO - 2017-02-27 01:52:56 --> Database Driver Class Initialized
INFO - 2017-02-27 01:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 01:52:56 --> Controller Class Initialized
INFO - 2017-02-27 01:52:56 --> Helper loaded: url_helper
DEBUG - 2017-02-27 01:52:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 01:52:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 01:52:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 01:52:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 01:52:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 01:52:56 --> Final output sent to browser
DEBUG - 2017-02-27 01:52:56 --> Total execution time: 0.0139
INFO - 2017-02-27 02:06:37 --> Config Class Initialized
INFO - 2017-02-27 02:06:37 --> Hooks Class Initialized
DEBUG - 2017-02-27 02:06:38 --> UTF-8 Support Enabled
INFO - 2017-02-27 02:06:38 --> Utf8 Class Initialized
INFO - 2017-02-27 02:06:38 --> URI Class Initialized
INFO - 2017-02-27 02:06:38 --> Router Class Initialized
INFO - 2017-02-27 02:06:38 --> Output Class Initialized
INFO - 2017-02-27 02:06:38 --> Security Class Initialized
DEBUG - 2017-02-27 02:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 02:06:38 --> Input Class Initialized
INFO - 2017-02-27 02:06:38 --> Language Class Initialized
INFO - 2017-02-27 02:06:38 --> Loader Class Initialized
INFO - 2017-02-27 02:06:38 --> Database Driver Class Initialized
INFO - 2017-02-27 02:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 02:06:39 --> Controller Class Initialized
INFO - 2017-02-27 02:06:39 --> Helper loaded: url_helper
DEBUG - 2017-02-27 02:06:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 02:06:39 --> Config Class Initialized
INFO - 2017-02-27 02:06:39 --> Hooks Class Initialized
DEBUG - 2017-02-27 02:06:39 --> UTF-8 Support Enabled
INFO - 2017-02-27 02:06:39 --> Utf8 Class Initialized
INFO - 2017-02-27 02:06:39 --> URI Class Initialized
INFO - 2017-02-27 02:06:39 --> Router Class Initialized
INFO - 2017-02-27 02:06:39 --> Output Class Initialized
INFO - 2017-02-27 02:06:39 --> Security Class Initialized
DEBUG - 2017-02-27 02:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 02:06:39 --> Input Class Initialized
INFO - 2017-02-27 02:06:39 --> Language Class Initialized
INFO - 2017-02-27 02:06:39 --> Loader Class Initialized
INFO - 2017-02-27 02:06:39 --> Database Driver Class Initialized
INFO - 2017-02-27 02:06:39 --> Config Class Initialized
INFO - 2017-02-27 02:06:39 --> Hooks Class Initialized
DEBUG - 2017-02-27 02:06:39 --> UTF-8 Support Enabled
INFO - 2017-02-27 02:06:39 --> Utf8 Class Initialized
INFO - 2017-02-27 02:06:39 --> URI Class Initialized
DEBUG - 2017-02-27 02:06:39 --> No URI present. Default controller set.
INFO - 2017-02-27 02:06:39 --> Router Class Initialized
INFO - 2017-02-27 02:06:39 --> Output Class Initialized
INFO - 2017-02-27 02:06:39 --> Security Class Initialized
DEBUG - 2017-02-27 02:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 02:06:39 --> Input Class Initialized
INFO - 2017-02-27 02:06:39 --> Language Class Initialized
INFO - 2017-02-27 02:06:39 --> Loader Class Initialized
INFO - 2017-02-27 02:06:39 --> Database Driver Class Initialized
INFO - 2017-02-27 02:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 02:06:39 --> Controller Class Initialized
INFO - 2017-02-27 02:06:39 --> Helper loaded: url_helper
DEBUG - 2017-02-27 02:06:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 02:06:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 02:06:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 02:06:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 02:06:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 02:06:40 --> Final output sent to browser
DEBUG - 2017-02-27 02:06:40 --> Total execution time: 0.2339
INFO - 2017-02-27 02:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 02:06:40 --> Controller Class Initialized
INFO - 2017-02-27 02:06:40 --> Helper loaded: url_helper
DEBUG - 2017-02-27 02:06:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 02:06:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 02:06:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 02:06:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 02:06:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 02:06:40 --> Final output sent to browser
DEBUG - 2017-02-27 02:06:40 --> Total execution time: 0.2374
INFO - 2017-02-27 03:12:26 --> Config Class Initialized
INFO - 2017-02-27 03:12:26 --> Hooks Class Initialized
DEBUG - 2017-02-27 03:12:26 --> UTF-8 Support Enabled
INFO - 2017-02-27 03:12:26 --> Utf8 Class Initialized
INFO - 2017-02-27 03:12:26 --> URI Class Initialized
DEBUG - 2017-02-27 03:12:26 --> No URI present. Default controller set.
INFO - 2017-02-27 03:12:26 --> Router Class Initialized
INFO - 2017-02-27 03:12:26 --> Output Class Initialized
INFO - 2017-02-27 03:12:26 --> Security Class Initialized
DEBUG - 2017-02-27 03:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 03:12:27 --> Input Class Initialized
INFO - 2017-02-27 03:12:27 --> Language Class Initialized
INFO - 2017-02-27 03:12:27 --> Loader Class Initialized
INFO - 2017-02-27 03:12:27 --> Database Driver Class Initialized
INFO - 2017-02-27 03:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 03:12:28 --> Controller Class Initialized
INFO - 2017-02-27 03:12:28 --> Helper loaded: url_helper
DEBUG - 2017-02-27 03:12:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 03:12:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 03:12:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 03:12:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 03:12:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 03:12:29 --> Final output sent to browser
DEBUG - 2017-02-27 03:12:29 --> Total execution time: 7.1406
INFO - 2017-02-27 03:12:41 --> Config Class Initialized
INFO - 2017-02-27 03:12:41 --> Hooks Class Initialized
DEBUG - 2017-02-27 03:12:41 --> UTF-8 Support Enabled
INFO - 2017-02-27 03:12:41 --> Utf8 Class Initialized
INFO - 2017-02-27 03:12:41 --> URI Class Initialized
INFO - 2017-02-27 03:12:41 --> Router Class Initialized
INFO - 2017-02-27 03:12:41 --> Output Class Initialized
INFO - 2017-02-27 03:12:41 --> Security Class Initialized
DEBUG - 2017-02-27 03:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 03:12:41 --> Input Class Initialized
INFO - 2017-02-27 03:12:41 --> Language Class Initialized
INFO - 2017-02-27 03:12:41 --> Loader Class Initialized
INFO - 2017-02-27 03:12:42 --> Database Driver Class Initialized
INFO - 2017-02-27 03:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 03:12:42 --> Controller Class Initialized
INFO - 2017-02-27 03:12:42 --> Helper loaded: url_helper
DEBUG - 2017-02-27 03:12:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 03:12:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 03:12:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 03:12:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 03:12:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 03:12:42 --> Final output sent to browser
DEBUG - 2017-02-27 03:12:42 --> Total execution time: 1.2224
INFO - 2017-02-27 03:12:51 --> Config Class Initialized
INFO - 2017-02-27 03:12:51 --> Hooks Class Initialized
DEBUG - 2017-02-27 03:12:51 --> UTF-8 Support Enabled
INFO - 2017-02-27 03:12:51 --> Utf8 Class Initialized
INFO - 2017-02-27 03:12:51 --> URI Class Initialized
INFO - 2017-02-27 03:12:51 --> Router Class Initialized
INFO - 2017-02-27 03:12:51 --> Output Class Initialized
INFO - 2017-02-27 03:12:51 --> Security Class Initialized
DEBUG - 2017-02-27 03:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 03:12:51 --> Input Class Initialized
INFO - 2017-02-27 03:12:51 --> Language Class Initialized
INFO - 2017-02-27 03:12:51 --> Loader Class Initialized
INFO - 2017-02-27 03:12:51 --> Database Driver Class Initialized
INFO - 2017-02-27 03:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 03:12:52 --> Controller Class Initialized
INFO - 2017-02-27 03:12:52 --> Helper loaded: url_helper
DEBUG - 2017-02-27 03:12:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-27 03:13:00 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-27 03:13:00 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Fatty R. Ramos')
INFO - 2017-02-27 03:13:00 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-27 03:13:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-27 03:13:01 --> Config Class Initialized
INFO - 2017-02-27 03:13:01 --> Hooks Class Initialized
DEBUG - 2017-02-27 03:13:01 --> UTF-8 Support Enabled
INFO - 2017-02-27 03:13:01 --> Utf8 Class Initialized
INFO - 2017-02-27 03:13:01 --> URI Class Initialized
INFO - 2017-02-27 03:13:01 --> Router Class Initialized
INFO - 2017-02-27 03:13:02 --> Output Class Initialized
INFO - 2017-02-27 03:13:02 --> Security Class Initialized
DEBUG - 2017-02-27 03:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 03:13:02 --> Input Class Initialized
INFO - 2017-02-27 03:13:02 --> Language Class Initialized
INFO - 2017-02-27 03:13:02 --> Loader Class Initialized
INFO - 2017-02-27 03:13:02 --> Database Driver Class Initialized
INFO - 2017-02-27 03:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 03:13:02 --> Controller Class Initialized
INFO - 2017-02-27 03:13:02 --> Helper loaded: url_helper
DEBUG - 2017-02-27 03:13:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-27 03:13:07 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-27 03:13:07 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Fatty R. Ramos')
INFO - 2017-02-27 03:13:07 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-27 03:13:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-27 03:13:08 --> Config Class Initialized
INFO - 2017-02-27 03:13:08 --> Hooks Class Initialized
DEBUG - 2017-02-27 03:13:09 --> UTF-8 Support Enabled
INFO - 2017-02-27 03:13:09 --> Utf8 Class Initialized
INFO - 2017-02-27 03:13:09 --> URI Class Initialized
INFO - 2017-02-27 03:13:09 --> Router Class Initialized
INFO - 2017-02-27 03:13:09 --> Output Class Initialized
INFO - 2017-02-27 03:13:09 --> Security Class Initialized
DEBUG - 2017-02-27 03:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 03:13:09 --> Input Class Initialized
INFO - 2017-02-27 03:13:09 --> Language Class Initialized
INFO - 2017-02-27 03:13:09 --> Loader Class Initialized
INFO - 2017-02-27 03:13:09 --> Database Driver Class Initialized
INFO - 2017-02-27 03:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 03:13:09 --> Controller Class Initialized
INFO - 2017-02-27 03:13:09 --> Helper loaded: url_helper
DEBUG - 2017-02-27 03:13:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-27 03:13:12 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-27 03:13:12 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Fatty R. Ramos')
INFO - 2017-02-27 03:13:12 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-27 03:13:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-27 03:13:14 --> Config Class Initialized
INFO - 2017-02-27 03:13:14 --> Hooks Class Initialized
DEBUG - 2017-02-27 03:13:15 --> UTF-8 Support Enabled
INFO - 2017-02-27 03:13:15 --> Utf8 Class Initialized
INFO - 2017-02-27 03:13:15 --> URI Class Initialized
INFO - 2017-02-27 03:13:15 --> Router Class Initialized
INFO - 2017-02-27 03:13:15 --> Output Class Initialized
INFO - 2017-02-27 03:13:15 --> Security Class Initialized
DEBUG - 2017-02-27 03:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 03:13:15 --> Input Class Initialized
INFO - 2017-02-27 03:13:15 --> Language Class Initialized
INFO - 2017-02-27 03:13:15 --> Loader Class Initialized
INFO - 2017-02-27 03:13:15 --> Database Driver Class Initialized
INFO - 2017-02-27 03:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 03:13:15 --> Controller Class Initialized
INFO - 2017-02-27 03:13:15 --> Helper loaded: url_helper
DEBUG - 2017-02-27 03:13:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 03:13:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 03:13:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 03:13:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 03:13:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 03:13:16 --> Final output sent to browser
DEBUG - 2017-02-27 03:13:16 --> Total execution time: 1.2309
INFO - 2017-02-27 03:13:17 --> Config Class Initialized
INFO - 2017-02-27 03:13:17 --> Hooks Class Initialized
DEBUG - 2017-02-27 03:13:17 --> UTF-8 Support Enabled
INFO - 2017-02-27 03:13:17 --> Utf8 Class Initialized
INFO - 2017-02-27 03:13:17 --> URI Class Initialized
DEBUG - 2017-02-27 03:13:17 --> No URI present. Default controller set.
INFO - 2017-02-27 03:13:17 --> Router Class Initialized
INFO - 2017-02-27 03:13:17 --> Output Class Initialized
INFO - 2017-02-27 03:13:17 --> Security Class Initialized
DEBUG - 2017-02-27 03:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 03:13:17 --> Input Class Initialized
INFO - 2017-02-27 03:13:17 --> Language Class Initialized
INFO - 2017-02-27 03:13:17 --> Loader Class Initialized
INFO - 2017-02-27 03:13:17 --> Database Driver Class Initialized
INFO - 2017-02-27 03:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 03:13:17 --> Controller Class Initialized
INFO - 2017-02-27 03:13:17 --> Helper loaded: url_helper
DEBUG - 2017-02-27 03:13:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 03:13:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 03:13:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 03:13:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 03:13:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 03:13:17 --> Final output sent to browser
DEBUG - 2017-02-27 03:13:17 --> Total execution time: 0.0543
INFO - 2017-02-27 03:13:18 --> Config Class Initialized
INFO - 2017-02-27 03:13:18 --> Hooks Class Initialized
DEBUG - 2017-02-27 03:13:18 --> UTF-8 Support Enabled
INFO - 2017-02-27 03:13:18 --> Utf8 Class Initialized
INFO - 2017-02-27 03:13:18 --> URI Class Initialized
INFO - 2017-02-27 03:13:18 --> Router Class Initialized
INFO - 2017-02-27 03:13:18 --> Output Class Initialized
INFO - 2017-02-27 03:13:18 --> Security Class Initialized
DEBUG - 2017-02-27 03:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 03:13:18 --> Input Class Initialized
INFO - 2017-02-27 03:13:18 --> Language Class Initialized
INFO - 2017-02-27 03:13:18 --> Loader Class Initialized
INFO - 2017-02-27 03:13:18 --> Database Driver Class Initialized
INFO - 2017-02-27 03:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 03:13:18 --> Controller Class Initialized
INFO - 2017-02-27 03:13:18 --> Helper loaded: url_helper
DEBUG - 2017-02-27 03:13:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 03:13:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 03:13:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 03:13:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 03:13:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 03:13:18 --> Final output sent to browser
DEBUG - 2017-02-27 03:13:18 --> Total execution time: 0.0709
INFO - 2017-02-27 03:13:53 --> Config Class Initialized
INFO - 2017-02-27 03:13:53 --> Hooks Class Initialized
DEBUG - 2017-02-27 03:13:53 --> UTF-8 Support Enabled
INFO - 2017-02-27 03:13:53 --> Utf8 Class Initialized
INFO - 2017-02-27 03:13:53 --> URI Class Initialized
INFO - 2017-02-27 03:13:53 --> Router Class Initialized
INFO - 2017-02-27 03:13:53 --> Output Class Initialized
INFO - 2017-02-27 03:13:53 --> Security Class Initialized
DEBUG - 2017-02-27 03:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 03:13:53 --> Input Class Initialized
INFO - 2017-02-27 03:13:53 --> Language Class Initialized
INFO - 2017-02-27 03:13:53 --> Loader Class Initialized
INFO - 2017-02-27 03:13:53 --> Database Driver Class Initialized
INFO - 2017-02-27 03:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 03:13:53 --> Controller Class Initialized
INFO - 2017-02-27 03:13:53 --> Helper loaded: url_helper
DEBUG - 2017-02-27 03:13:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 03:13:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 03:13:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 03:13:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 03:13:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 03:13:54 --> Final output sent to browser
DEBUG - 2017-02-27 03:13:54 --> Total execution time: 1.2626
INFO - 2017-02-27 03:13:55 --> Config Class Initialized
INFO - 2017-02-27 03:13:55 --> Hooks Class Initialized
DEBUG - 2017-02-27 03:13:55 --> UTF-8 Support Enabled
INFO - 2017-02-27 03:13:55 --> Utf8 Class Initialized
INFO - 2017-02-27 03:13:55 --> URI Class Initialized
INFO - 2017-02-27 03:13:55 --> Router Class Initialized
INFO - 2017-02-27 03:13:55 --> Output Class Initialized
INFO - 2017-02-27 03:13:55 --> Security Class Initialized
DEBUG - 2017-02-27 03:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 03:13:55 --> Input Class Initialized
INFO - 2017-02-27 03:13:55 --> Language Class Initialized
INFO - 2017-02-27 03:13:55 --> Loader Class Initialized
INFO - 2017-02-27 03:13:55 --> Database Driver Class Initialized
INFO - 2017-02-27 03:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 03:13:55 --> Controller Class Initialized
INFO - 2017-02-27 03:13:55 --> Helper loaded: url_helper
DEBUG - 2017-02-27 03:13:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 03:13:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 03:13:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 03:13:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 03:13:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 03:13:55 --> Final output sent to browser
DEBUG - 2017-02-27 03:13:55 --> Total execution time: 0.7967
INFO - 2017-02-27 03:14:14 --> Config Class Initialized
INFO - 2017-02-27 03:14:14 --> Hooks Class Initialized
DEBUG - 2017-02-27 03:14:14 --> UTF-8 Support Enabled
INFO - 2017-02-27 03:14:14 --> Utf8 Class Initialized
INFO - 2017-02-27 03:14:14 --> URI Class Initialized
INFO - 2017-02-27 03:14:14 --> Router Class Initialized
INFO - 2017-02-27 03:14:14 --> Output Class Initialized
INFO - 2017-02-27 03:14:14 --> Security Class Initialized
DEBUG - 2017-02-27 03:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 03:14:14 --> Input Class Initialized
INFO - 2017-02-27 03:14:14 --> Language Class Initialized
INFO - 2017-02-27 03:14:14 --> Loader Class Initialized
INFO - 2017-02-27 03:14:14 --> Database Driver Class Initialized
INFO - 2017-02-27 03:14:15 --> Config Class Initialized
INFO - 2017-02-27 03:14:15 --> Hooks Class Initialized
DEBUG - 2017-02-27 03:14:15 --> UTF-8 Support Enabled
INFO - 2017-02-27 03:14:15 --> Utf8 Class Initialized
INFO - 2017-02-27 03:14:15 --> URI Class Initialized
INFO - 2017-02-27 03:14:15 --> Router Class Initialized
INFO - 2017-02-27 03:14:15 --> Output Class Initialized
INFO - 2017-02-27 03:14:15 --> Security Class Initialized
DEBUG - 2017-02-27 03:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 03:14:15 --> Input Class Initialized
INFO - 2017-02-27 03:14:15 --> Language Class Initialized
INFO - 2017-02-27 03:14:15 --> Loader Class Initialized
INFO - 2017-02-27 03:14:15 --> Database Driver Class Initialized
INFO - 2017-02-27 03:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 03:14:15 --> Controller Class Initialized
INFO - 2017-02-27 03:14:15 --> Helper loaded: url_helper
DEBUG - 2017-02-27 03:14:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 03:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 03:14:15 --> Controller Class Initialized
INFO - 2017-02-27 03:14:15 --> Helper loaded: url_helper
DEBUG - 2017-02-27 03:14:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 03:14:17 --> Config Class Initialized
INFO - 2017-02-27 03:14:17 --> Hooks Class Initialized
DEBUG - 2017-02-27 03:14:17 --> UTF-8 Support Enabled
INFO - 2017-02-27 03:14:17 --> Utf8 Class Initialized
INFO - 2017-02-27 03:14:17 --> URI Class Initialized
INFO - 2017-02-27 03:14:17 --> Router Class Initialized
INFO - 2017-02-27 03:14:17 --> Output Class Initialized
INFO - 2017-02-27 03:14:17 --> Security Class Initialized
DEBUG - 2017-02-27 03:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 03:14:17 --> Input Class Initialized
INFO - 2017-02-27 03:14:17 --> Language Class Initialized
INFO - 2017-02-27 03:14:17 --> Loader Class Initialized
INFO - 2017-02-27 03:14:17 --> Database Driver Class Initialized
INFO - 2017-02-27 03:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 03:14:17 --> Controller Class Initialized
INFO - 2017-02-27 03:14:18 --> Helper loaded: date_helper
DEBUG - 2017-02-27 03:14:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 03:14:18 --> Helper loaded: url_helper
INFO - 2017-02-27 03:14:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 03:14:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-27 03:14:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-27 03:14:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-27 03:14:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 03:14:18 --> Final output sent to browser
DEBUG - 2017-02-27 03:14:18 --> Total execution time: 1.0016
INFO - 2017-02-27 03:14:18 --> Config Class Initialized
INFO - 2017-02-27 03:14:18 --> Hooks Class Initialized
DEBUG - 2017-02-27 03:14:18 --> UTF-8 Support Enabled
INFO - 2017-02-27 03:14:18 --> Utf8 Class Initialized
INFO - 2017-02-27 03:14:18 --> URI Class Initialized
INFO - 2017-02-27 03:14:18 --> Router Class Initialized
INFO - 2017-02-27 03:14:18 --> Output Class Initialized
INFO - 2017-02-27 03:14:18 --> Security Class Initialized
DEBUG - 2017-02-27 03:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 03:14:18 --> Input Class Initialized
INFO - 2017-02-27 03:14:18 --> Language Class Initialized
INFO - 2017-02-27 03:14:18 --> Loader Class Initialized
INFO - 2017-02-27 03:14:18 --> Database Driver Class Initialized
INFO - 2017-02-27 03:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 03:14:18 --> Controller Class Initialized
INFO - 2017-02-27 03:14:18 --> Helper loaded: url_helper
DEBUG - 2017-02-27 03:14:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 03:14:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 03:14:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 03:14:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 03:14:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 03:14:18 --> Final output sent to browser
DEBUG - 2017-02-27 03:14:18 --> Total execution time: 0.0399
INFO - 2017-02-27 04:01:04 --> Config Class Initialized
INFO - 2017-02-27 04:01:04 --> Hooks Class Initialized
DEBUG - 2017-02-27 04:01:04 --> UTF-8 Support Enabled
INFO - 2017-02-27 04:01:04 --> Utf8 Class Initialized
INFO - 2017-02-27 04:01:04 --> URI Class Initialized
DEBUG - 2017-02-27 04:01:04 --> No URI present. Default controller set.
INFO - 2017-02-27 04:01:04 --> Router Class Initialized
INFO - 2017-02-27 04:01:04 --> Output Class Initialized
INFO - 2017-02-27 04:01:04 --> Security Class Initialized
DEBUG - 2017-02-27 04:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 04:01:04 --> Input Class Initialized
INFO - 2017-02-27 04:01:04 --> Language Class Initialized
INFO - 2017-02-27 04:01:04 --> Loader Class Initialized
INFO - 2017-02-27 04:01:04 --> Database Driver Class Initialized
INFO - 2017-02-27 04:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 04:01:05 --> Controller Class Initialized
INFO - 2017-02-27 04:01:05 --> Helper loaded: url_helper
DEBUG - 2017-02-27 04:01:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 04:01:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 04:01:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 04:01:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 04:01:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 04:01:05 --> Final output sent to browser
DEBUG - 2017-02-27 04:01:05 --> Total execution time: 1.2793
INFO - 2017-02-27 04:01:46 --> Config Class Initialized
INFO - 2017-02-27 04:01:46 --> Hooks Class Initialized
DEBUG - 2017-02-27 04:01:46 --> UTF-8 Support Enabled
INFO - 2017-02-27 04:01:46 --> Utf8 Class Initialized
INFO - 2017-02-27 04:01:46 --> URI Class Initialized
INFO - 2017-02-27 04:01:46 --> Router Class Initialized
INFO - 2017-02-27 04:01:46 --> Output Class Initialized
INFO - 2017-02-27 04:01:46 --> Security Class Initialized
DEBUG - 2017-02-27 04:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 04:01:46 --> Input Class Initialized
INFO - 2017-02-27 04:01:46 --> Language Class Initialized
INFO - 2017-02-27 04:01:46 --> Loader Class Initialized
INFO - 2017-02-27 04:01:47 --> Database Driver Class Initialized
INFO - 2017-02-27 04:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 04:01:47 --> Controller Class Initialized
INFO - 2017-02-27 04:01:47 --> Helper loaded: url_helper
DEBUG - 2017-02-27 04:01:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 04:01:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 04:01:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 04:01:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 04:01:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 04:01:47 --> Final output sent to browser
DEBUG - 2017-02-27 04:01:47 --> Total execution time: 1.1844
INFO - 2017-02-27 04:02:20 --> Config Class Initialized
INFO - 2017-02-27 04:02:20 --> Hooks Class Initialized
DEBUG - 2017-02-27 04:02:20 --> UTF-8 Support Enabled
INFO - 2017-02-27 04:02:20 --> Utf8 Class Initialized
INFO - 2017-02-27 04:02:20 --> URI Class Initialized
DEBUG - 2017-02-27 04:02:20 --> No URI present. Default controller set.
INFO - 2017-02-27 04:02:20 --> Router Class Initialized
INFO - 2017-02-27 04:02:20 --> Output Class Initialized
INFO - 2017-02-27 04:02:20 --> Security Class Initialized
DEBUG - 2017-02-27 04:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 04:02:21 --> Input Class Initialized
INFO - 2017-02-27 04:02:21 --> Language Class Initialized
INFO - 2017-02-27 04:02:21 --> Loader Class Initialized
INFO - 2017-02-27 04:02:21 --> Database Driver Class Initialized
INFO - 2017-02-27 04:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 04:02:21 --> Controller Class Initialized
INFO - 2017-02-27 04:02:21 --> Helper loaded: url_helper
DEBUG - 2017-02-27 04:02:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 04:02:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 04:02:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 04:02:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 04:02:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 04:02:21 --> Final output sent to browser
DEBUG - 2017-02-27 04:02:21 --> Total execution time: 1.2594
INFO - 2017-02-27 04:04:09 --> Config Class Initialized
INFO - 2017-02-27 04:04:09 --> Hooks Class Initialized
DEBUG - 2017-02-27 04:04:09 --> UTF-8 Support Enabled
INFO - 2017-02-27 04:04:09 --> Utf8 Class Initialized
INFO - 2017-02-27 04:04:09 --> URI Class Initialized
DEBUG - 2017-02-27 04:04:09 --> No URI present. Default controller set.
INFO - 2017-02-27 04:04:09 --> Router Class Initialized
INFO - 2017-02-27 04:04:09 --> Output Class Initialized
INFO - 2017-02-27 04:04:09 --> Security Class Initialized
DEBUG - 2017-02-27 04:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 04:04:09 --> Input Class Initialized
INFO - 2017-02-27 04:04:09 --> Language Class Initialized
INFO - 2017-02-27 04:04:09 --> Loader Class Initialized
INFO - 2017-02-27 04:04:10 --> Database Driver Class Initialized
INFO - 2017-02-27 04:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 04:04:10 --> Controller Class Initialized
INFO - 2017-02-27 04:04:10 --> Helper loaded: url_helper
DEBUG - 2017-02-27 04:04:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 04:04:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 04:04:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 04:04:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 04:04:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 04:04:10 --> Final output sent to browser
DEBUG - 2017-02-27 04:04:10 --> Total execution time: 1.2627
INFO - 2017-02-27 04:34:58 --> Config Class Initialized
INFO - 2017-02-27 04:34:58 --> Hooks Class Initialized
DEBUG - 2017-02-27 04:34:58 --> UTF-8 Support Enabled
INFO - 2017-02-27 04:34:58 --> Utf8 Class Initialized
INFO - 2017-02-27 04:34:58 --> URI Class Initialized
INFO - 2017-02-27 04:34:58 --> Router Class Initialized
INFO - 2017-02-27 04:34:58 --> Output Class Initialized
INFO - 2017-02-27 04:34:58 --> Security Class Initialized
DEBUG - 2017-02-27 04:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 04:34:58 --> Input Class Initialized
INFO - 2017-02-27 04:34:58 --> Language Class Initialized
INFO - 2017-02-27 04:34:58 --> Loader Class Initialized
INFO - 2017-02-27 04:34:59 --> Database Driver Class Initialized
INFO - 2017-02-27 04:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 04:34:59 --> Controller Class Initialized
INFO - 2017-02-27 04:34:59 --> Helper loaded: url_helper
DEBUG - 2017-02-27 04:34:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 04:34:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 04:34:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 04:34:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 04:34:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 04:34:59 --> Final output sent to browser
DEBUG - 2017-02-27 04:34:59 --> Total execution time: 1.2333
INFO - 2017-02-27 04:35:06 --> Config Class Initialized
INFO - 2017-02-27 04:35:06 --> Hooks Class Initialized
DEBUG - 2017-02-27 04:35:06 --> UTF-8 Support Enabled
INFO - 2017-02-27 04:35:06 --> Utf8 Class Initialized
INFO - 2017-02-27 04:35:06 --> URI Class Initialized
DEBUG - 2017-02-27 04:35:06 --> No URI present. Default controller set.
INFO - 2017-02-27 04:35:06 --> Router Class Initialized
INFO - 2017-02-27 04:35:06 --> Output Class Initialized
INFO - 2017-02-27 04:35:06 --> Security Class Initialized
DEBUG - 2017-02-27 04:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 04:35:06 --> Input Class Initialized
INFO - 2017-02-27 04:35:06 --> Language Class Initialized
INFO - 2017-02-27 04:35:06 --> Loader Class Initialized
INFO - 2017-02-27 04:35:06 --> Database Driver Class Initialized
INFO - 2017-02-27 04:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 04:35:06 --> Controller Class Initialized
INFO - 2017-02-27 04:35:06 --> Helper loaded: url_helper
DEBUG - 2017-02-27 04:35:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 04:35:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 04:35:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 04:35:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 04:35:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 04:35:06 --> Final output sent to browser
DEBUG - 2017-02-27 04:35:06 --> Total execution time: 0.0357
INFO - 2017-02-27 07:22:37 --> Config Class Initialized
INFO - 2017-02-27 07:22:37 --> Hooks Class Initialized
DEBUG - 2017-02-27 07:22:37 --> UTF-8 Support Enabled
INFO - 2017-02-27 07:22:37 --> Utf8 Class Initialized
INFO - 2017-02-27 07:22:37 --> URI Class Initialized
INFO - 2017-02-27 07:22:37 --> Router Class Initialized
INFO - 2017-02-27 07:22:37 --> Output Class Initialized
INFO - 2017-02-27 07:22:37 --> Security Class Initialized
DEBUG - 2017-02-27 07:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 07:22:37 --> Input Class Initialized
INFO - 2017-02-27 07:22:37 --> Language Class Initialized
INFO - 2017-02-27 07:22:37 --> Loader Class Initialized
INFO - 2017-02-27 07:22:38 --> Database Driver Class Initialized
INFO - 2017-02-27 07:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 07:22:38 --> Controller Class Initialized
INFO - 2017-02-27 07:22:38 --> Helper loaded: url_helper
DEBUG - 2017-02-27 07:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 07:22:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 07:22:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 07:22:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 07:22:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 07:22:38 --> Final output sent to browser
DEBUG - 2017-02-27 07:22:38 --> Total execution time: 1.7473
INFO - 2017-02-27 07:23:40 --> Config Class Initialized
INFO - 2017-02-27 07:23:40 --> Hooks Class Initialized
DEBUG - 2017-02-27 07:23:40 --> UTF-8 Support Enabled
INFO - 2017-02-27 07:23:40 --> Utf8 Class Initialized
INFO - 2017-02-27 07:23:40 --> URI Class Initialized
DEBUG - 2017-02-27 07:23:41 --> No URI present. Default controller set.
INFO - 2017-02-27 07:23:41 --> Router Class Initialized
INFO - 2017-02-27 07:23:41 --> Output Class Initialized
INFO - 2017-02-27 07:23:41 --> Security Class Initialized
DEBUG - 2017-02-27 07:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 07:23:41 --> Input Class Initialized
INFO - 2017-02-27 07:23:41 --> Language Class Initialized
INFO - 2017-02-27 07:23:41 --> Loader Class Initialized
INFO - 2017-02-27 07:23:41 --> Database Driver Class Initialized
INFO - 2017-02-27 07:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 07:23:42 --> Controller Class Initialized
INFO - 2017-02-27 07:23:42 --> Helper loaded: url_helper
DEBUG - 2017-02-27 07:23:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 07:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 07:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 07:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 07:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 07:23:42 --> Final output sent to browser
DEBUG - 2017-02-27 07:23:42 --> Total execution time: 1.7470
INFO - 2017-02-27 10:43:13 --> Config Class Initialized
INFO - 2017-02-27 10:43:13 --> Hooks Class Initialized
DEBUG - 2017-02-27 10:43:14 --> UTF-8 Support Enabled
INFO - 2017-02-27 10:43:14 --> Utf8 Class Initialized
INFO - 2017-02-27 10:43:14 --> URI Class Initialized
INFO - 2017-02-27 10:43:14 --> Router Class Initialized
INFO - 2017-02-27 10:43:14 --> Output Class Initialized
INFO - 2017-02-27 10:43:14 --> Security Class Initialized
DEBUG - 2017-02-27 10:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 10:43:14 --> Input Class Initialized
INFO - 2017-02-27 10:43:14 --> Language Class Initialized
INFO - 2017-02-27 10:43:14 --> Loader Class Initialized
INFO - 2017-02-27 10:43:14 --> Database Driver Class Initialized
INFO - 2017-02-27 10:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 10:43:15 --> Controller Class Initialized
INFO - 2017-02-27 10:43:15 --> Helper loaded: url_helper
DEBUG - 2017-02-27 10:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 10:43:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 10:43:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 10:43:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 10:43:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 10:43:15 --> Final output sent to browser
DEBUG - 2017-02-27 10:43:15 --> Total execution time: 1.5467
INFO - 2017-02-27 10:44:44 --> Config Class Initialized
INFO - 2017-02-27 10:44:44 --> Hooks Class Initialized
DEBUG - 2017-02-27 10:44:44 --> UTF-8 Support Enabled
INFO - 2017-02-27 10:44:44 --> Utf8 Class Initialized
INFO - 2017-02-27 10:44:44 --> URI Class Initialized
DEBUG - 2017-02-27 10:44:44 --> No URI present. Default controller set.
INFO - 2017-02-27 10:44:44 --> Router Class Initialized
INFO - 2017-02-27 10:44:44 --> Output Class Initialized
INFO - 2017-02-27 10:44:44 --> Security Class Initialized
DEBUG - 2017-02-27 10:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 10:44:44 --> Input Class Initialized
INFO - 2017-02-27 10:44:44 --> Language Class Initialized
INFO - 2017-02-27 10:44:44 --> Loader Class Initialized
INFO - 2017-02-27 10:44:44 --> Database Driver Class Initialized
INFO - 2017-02-27 10:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 10:44:45 --> Controller Class Initialized
INFO - 2017-02-27 10:44:45 --> Helper loaded: url_helper
DEBUG - 2017-02-27 10:44:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 10:44:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 10:44:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 10:44:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 10:44:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 10:44:45 --> Final output sent to browser
DEBUG - 2017-02-27 10:44:45 --> Total execution time: 1.7370
INFO - 2017-02-27 15:27:07 --> Config Class Initialized
INFO - 2017-02-27 15:27:07 --> Hooks Class Initialized
DEBUG - 2017-02-27 15:27:08 --> UTF-8 Support Enabled
INFO - 2017-02-27 15:27:08 --> Utf8 Class Initialized
INFO - 2017-02-27 15:27:08 --> URI Class Initialized
INFO - 2017-02-27 15:27:08 --> Router Class Initialized
INFO - 2017-02-27 15:27:08 --> Output Class Initialized
INFO - 2017-02-27 15:27:08 --> Security Class Initialized
DEBUG - 2017-02-27 15:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 15:27:08 --> Input Class Initialized
INFO - 2017-02-27 15:27:08 --> Language Class Initialized
INFO - 2017-02-27 15:27:08 --> Loader Class Initialized
INFO - 2017-02-27 15:27:08 --> Database Driver Class Initialized
INFO - 2017-02-27 15:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 15:27:09 --> Controller Class Initialized
INFO - 2017-02-27 15:27:09 --> Helper loaded: url_helper
DEBUG - 2017-02-27 15:27:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 15:27:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 15:27:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 15:27:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 15:27:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 15:27:09 --> Final output sent to browser
DEBUG - 2017-02-27 15:27:09 --> Total execution time: 1.7445
INFO - 2017-02-27 15:27:27 --> Config Class Initialized
INFO - 2017-02-27 15:27:27 --> Hooks Class Initialized
DEBUG - 2017-02-27 15:27:27 --> UTF-8 Support Enabled
INFO - 2017-02-27 15:27:27 --> Utf8 Class Initialized
INFO - 2017-02-27 15:27:27 --> URI Class Initialized
DEBUG - 2017-02-27 15:27:27 --> No URI present. Default controller set.
INFO - 2017-02-27 15:27:27 --> Router Class Initialized
INFO - 2017-02-27 15:27:27 --> Output Class Initialized
INFO - 2017-02-27 15:27:27 --> Security Class Initialized
DEBUG - 2017-02-27 15:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 15:27:27 --> Input Class Initialized
INFO - 2017-02-27 15:27:27 --> Language Class Initialized
INFO - 2017-02-27 15:27:27 --> Loader Class Initialized
INFO - 2017-02-27 15:27:27 --> Database Driver Class Initialized
INFO - 2017-02-27 15:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 15:27:27 --> Controller Class Initialized
INFO - 2017-02-27 15:27:27 --> Helper loaded: url_helper
DEBUG - 2017-02-27 15:27:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 15:27:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 15:27:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 15:27:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 15:27:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 15:27:27 --> Final output sent to browser
DEBUG - 2017-02-27 15:27:27 --> Total execution time: 0.0201
INFO - 2017-02-27 16:40:54 --> Config Class Initialized
INFO - 2017-02-27 16:40:54 --> Hooks Class Initialized
DEBUG - 2017-02-27 16:40:54 --> UTF-8 Support Enabled
INFO - 2017-02-27 16:40:54 --> Utf8 Class Initialized
INFO - 2017-02-27 16:40:54 --> URI Class Initialized
DEBUG - 2017-02-27 16:40:54 --> No URI present. Default controller set.
INFO - 2017-02-27 16:40:54 --> Router Class Initialized
INFO - 2017-02-27 16:40:54 --> Output Class Initialized
INFO - 2017-02-27 16:40:54 --> Security Class Initialized
DEBUG - 2017-02-27 16:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 16:40:54 --> Input Class Initialized
INFO - 2017-02-27 16:40:54 --> Language Class Initialized
INFO - 2017-02-27 16:40:54 --> Loader Class Initialized
INFO - 2017-02-27 16:40:55 --> Database Driver Class Initialized
INFO - 2017-02-27 16:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 16:40:55 --> Controller Class Initialized
INFO - 2017-02-27 16:40:55 --> Helper loaded: url_helper
DEBUG - 2017-02-27 16:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 16:40:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 16:40:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 16:40:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 16:40:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 16:40:55 --> Final output sent to browser
DEBUG - 2017-02-27 16:40:55 --> Total execution time: 1.7543
INFO - 2017-02-27 18:40:00 --> Config Class Initialized
INFO - 2017-02-27 18:40:00 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:40:00 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:40:00 --> Utf8 Class Initialized
INFO - 2017-02-27 18:40:00 --> URI Class Initialized
DEBUG - 2017-02-27 18:40:00 --> No URI present. Default controller set.
INFO - 2017-02-27 18:40:00 --> Router Class Initialized
INFO - 2017-02-27 18:40:00 --> Output Class Initialized
INFO - 2017-02-27 18:40:00 --> Security Class Initialized
DEBUG - 2017-02-27 18:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:40:00 --> Input Class Initialized
INFO - 2017-02-27 18:40:00 --> Language Class Initialized
INFO - 2017-02-27 18:40:00 --> Loader Class Initialized
INFO - 2017-02-27 18:40:01 --> Database Driver Class Initialized
INFO - 2017-02-27 18:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:40:02 --> Controller Class Initialized
INFO - 2017-02-27 18:40:02 --> Helper loaded: url_helper
DEBUG - 2017-02-27 18:40:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 18:40:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 18:40:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 18:40:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 18:40:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 18:40:02 --> Final output sent to browser
DEBUG - 2017-02-27 18:40:02 --> Total execution time: 2.5857
INFO - 2017-02-27 18:40:09 --> Config Class Initialized
INFO - 2017-02-27 18:40:09 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:40:09 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:40:09 --> Utf8 Class Initialized
INFO - 2017-02-27 18:40:09 --> URI Class Initialized
INFO - 2017-02-27 18:40:09 --> Router Class Initialized
INFO - 2017-02-27 18:40:09 --> Output Class Initialized
INFO - 2017-02-27 18:40:09 --> Security Class Initialized
DEBUG - 2017-02-27 18:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:40:09 --> Input Class Initialized
INFO - 2017-02-27 18:40:09 --> Language Class Initialized
INFO - 2017-02-27 18:40:09 --> Loader Class Initialized
INFO - 2017-02-27 18:40:10 --> Database Driver Class Initialized
INFO - 2017-02-27 18:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:40:10 --> Controller Class Initialized
INFO - 2017-02-27 18:40:10 --> Helper loaded: url_helper
DEBUG - 2017-02-27 18:40:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 18:40:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 18:40:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 18:40:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 18:40:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 18:40:10 --> Final output sent to browser
DEBUG - 2017-02-27 18:40:10 --> Total execution time: 1.4951
INFO - 2017-02-27 20:37:12 --> Config Class Initialized
INFO - 2017-02-27 20:37:12 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:37:12 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:37:12 --> Utf8 Class Initialized
INFO - 2017-02-27 20:37:12 --> URI Class Initialized
INFO - 2017-02-27 20:37:12 --> Router Class Initialized
INFO - 2017-02-27 20:37:12 --> Output Class Initialized
INFO - 2017-02-27 20:37:12 --> Security Class Initialized
DEBUG - 2017-02-27 20:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:37:12 --> Input Class Initialized
INFO - 2017-02-27 20:37:12 --> Language Class Initialized
INFO - 2017-02-27 20:37:12 --> Loader Class Initialized
INFO - 2017-02-27 20:37:12 --> Database Driver Class Initialized
INFO - 2017-02-27 20:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:37:13 --> Controller Class Initialized
INFO - 2017-02-27 20:37:13 --> Helper loaded: date_helper
DEBUG - 2017-02-27 20:37:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 20:37:13 --> Helper loaded: url_helper
INFO - 2017-02-27 20:37:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 20:37:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-27 20:37:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-27 20:37:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-27 20:37:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 20:37:13 --> Final output sent to browser
DEBUG - 2017-02-27 20:37:13 --> Total execution time: 1.5127
INFO - 2017-02-27 20:37:19 --> Config Class Initialized
INFO - 2017-02-27 20:37:19 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:37:19 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:37:19 --> Utf8 Class Initialized
INFO - 2017-02-27 20:37:19 --> URI Class Initialized
INFO - 2017-02-27 20:37:19 --> Router Class Initialized
INFO - 2017-02-27 20:37:19 --> Output Class Initialized
INFO - 2017-02-27 20:37:19 --> Security Class Initialized
DEBUG - 2017-02-27 20:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:37:19 --> Input Class Initialized
INFO - 2017-02-27 20:37:19 --> Language Class Initialized
INFO - 2017-02-27 20:37:19 --> Loader Class Initialized
INFO - 2017-02-27 20:37:19 --> Database Driver Class Initialized
INFO - 2017-02-27 20:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:37:19 --> Controller Class Initialized
INFO - 2017-02-27 20:37:19 --> Helper loaded: url_helper
DEBUG - 2017-02-27 20:37:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 20:37:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 20:37:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 20:37:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 20:37:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 20:37:20 --> Final output sent to browser
DEBUG - 2017-02-27 20:37:20 --> Total execution time: 0.2341
INFO - 2017-02-27 20:59:39 --> Config Class Initialized
INFO - 2017-02-27 20:59:39 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:59:40 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:59:40 --> Utf8 Class Initialized
INFO - 2017-02-27 20:59:40 --> URI Class Initialized
INFO - 2017-02-27 20:59:40 --> Router Class Initialized
INFO - 2017-02-27 20:59:40 --> Output Class Initialized
INFO - 2017-02-27 20:59:40 --> Security Class Initialized
DEBUG - 2017-02-27 20:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:59:40 --> Input Class Initialized
INFO - 2017-02-27 20:59:40 --> Language Class Initialized
INFO - 2017-02-27 20:59:40 --> Loader Class Initialized
INFO - 2017-02-27 20:59:40 --> Database Driver Class Initialized
INFO - 2017-02-27 20:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:59:41 --> Controller Class Initialized
INFO - 2017-02-27 20:59:41 --> Helper loaded: date_helper
DEBUG - 2017-02-27 20:59:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 20:59:41 --> Helper loaded: url_helper
INFO - 2017-02-27 20:59:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 20:59:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-27 20:59:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-27 20:59:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-27 20:59:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 20:59:41 --> Final output sent to browser
DEBUG - 2017-02-27 20:59:41 --> Total execution time: 1.9793
INFO - 2017-02-27 20:59:49 --> Config Class Initialized
INFO - 2017-02-27 20:59:49 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:59:50 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:59:50 --> Utf8 Class Initialized
INFO - 2017-02-27 20:59:50 --> URI Class Initialized
INFO - 2017-02-27 20:59:50 --> Router Class Initialized
INFO - 2017-02-27 20:59:50 --> Output Class Initialized
INFO - 2017-02-27 20:59:50 --> Security Class Initialized
DEBUG - 2017-02-27 20:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:59:50 --> Input Class Initialized
INFO - 2017-02-27 20:59:50 --> Language Class Initialized
INFO - 2017-02-27 20:59:50 --> Loader Class Initialized
INFO - 2017-02-27 20:59:51 --> Database Driver Class Initialized
INFO - 2017-02-27 20:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:59:51 --> Controller Class Initialized
INFO - 2017-02-27 20:59:51 --> Helper loaded: url_helper
DEBUG - 2017-02-27 20:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 20:59:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 20:59:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 20:59:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 20:59:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 20:59:52 --> Final output sent to browser
DEBUG - 2017-02-27 20:59:52 --> Total execution time: 2.3009
INFO - 2017-02-27 21:01:21 --> Config Class Initialized
INFO - 2017-02-27 21:01:21 --> Hooks Class Initialized
DEBUG - 2017-02-27 21:01:22 --> UTF-8 Support Enabled
INFO - 2017-02-27 21:01:22 --> Utf8 Class Initialized
INFO - 2017-02-27 21:01:22 --> URI Class Initialized
DEBUG - 2017-02-27 21:01:22 --> No URI present. Default controller set.
INFO - 2017-02-27 21:01:22 --> Router Class Initialized
INFO - 2017-02-27 21:01:22 --> Output Class Initialized
INFO - 2017-02-27 21:01:22 --> Security Class Initialized
DEBUG - 2017-02-27 21:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 21:01:22 --> Input Class Initialized
INFO - 2017-02-27 21:01:22 --> Language Class Initialized
INFO - 2017-02-27 21:01:22 --> Loader Class Initialized
INFO - 2017-02-27 21:01:22 --> Database Driver Class Initialized
INFO - 2017-02-27 21:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 21:01:23 --> Controller Class Initialized
INFO - 2017-02-27 21:01:23 --> Helper loaded: url_helper
DEBUG - 2017-02-27 21:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 21:01:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 21:01:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 21:01:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 21:01:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 21:01:24 --> Final output sent to browser
DEBUG - 2017-02-27 21:01:24 --> Total execution time: 2.6007
INFO - 2017-02-27 21:01:48 --> Config Class Initialized
INFO - 2017-02-27 21:01:48 --> Hooks Class Initialized
DEBUG - 2017-02-27 21:01:49 --> UTF-8 Support Enabled
INFO - 2017-02-27 21:01:49 --> Utf8 Class Initialized
INFO - 2017-02-27 21:01:49 --> URI Class Initialized
INFO - 2017-02-27 21:01:49 --> Router Class Initialized
INFO - 2017-02-27 21:01:49 --> Output Class Initialized
INFO - 2017-02-27 21:01:49 --> Security Class Initialized
DEBUG - 2017-02-27 21:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 21:01:49 --> Input Class Initialized
INFO - 2017-02-27 21:01:49 --> Language Class Initialized
INFO - 2017-02-27 21:01:49 --> Loader Class Initialized
INFO - 2017-02-27 21:01:49 --> Database Driver Class Initialized
INFO - 2017-02-27 21:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 21:01:50 --> Controller Class Initialized
INFO - 2017-02-27 21:01:50 --> Helper loaded: url_helper
DEBUG - 2017-02-27 21:01:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 21:01:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 21:01:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 21:01:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 21:01:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 21:01:50 --> Final output sent to browser
DEBUG - 2017-02-27 21:01:50 --> Total execution time: 1.5535
INFO - 2017-02-27 21:02:36 --> Config Class Initialized
INFO - 2017-02-27 21:02:36 --> Hooks Class Initialized
DEBUG - 2017-02-27 21:02:37 --> UTF-8 Support Enabled
INFO - 2017-02-27 21:02:37 --> Utf8 Class Initialized
INFO - 2017-02-27 21:02:37 --> URI Class Initialized
INFO - 2017-02-27 21:02:37 --> Router Class Initialized
INFO - 2017-02-27 21:02:37 --> Output Class Initialized
INFO - 2017-02-27 21:02:37 --> Security Class Initialized
DEBUG - 2017-02-27 21:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 21:02:37 --> Input Class Initialized
INFO - 2017-02-27 21:02:37 --> Language Class Initialized
INFO - 2017-02-27 21:02:37 --> Loader Class Initialized
INFO - 2017-02-27 21:02:37 --> Database Driver Class Initialized
INFO - 2017-02-27 21:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 21:02:37 --> Controller Class Initialized
INFO - 2017-02-27 21:02:37 --> Helper loaded: url_helper
DEBUG - 2017-02-27 21:02:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 21:02:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 21:02:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 21:02:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 21:02:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 21:02:38 --> Final output sent to browser
DEBUG - 2017-02-27 21:02:38 --> Total execution time: 1.5475
INFO - 2017-02-27 21:02:43 --> Config Class Initialized
INFO - 2017-02-27 21:02:43 --> Hooks Class Initialized
DEBUG - 2017-02-27 21:02:43 --> UTF-8 Support Enabled
INFO - 2017-02-27 21:02:43 --> Utf8 Class Initialized
INFO - 2017-02-27 21:02:43 --> URI Class Initialized
INFO - 2017-02-27 21:02:43 --> Router Class Initialized
INFO - 2017-02-27 21:02:43 --> Output Class Initialized
INFO - 2017-02-27 21:02:43 --> Security Class Initialized
DEBUG - 2017-02-27 21:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 21:02:44 --> Input Class Initialized
INFO - 2017-02-27 21:02:44 --> Language Class Initialized
INFO - 2017-02-27 21:02:44 --> Loader Class Initialized
INFO - 2017-02-27 21:02:44 --> Database Driver Class Initialized
INFO - 2017-02-27 21:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 21:02:44 --> Controller Class Initialized
INFO - 2017-02-27 21:02:44 --> Helper loaded: url_helper
DEBUG - 2017-02-27 21:02:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 21:02:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 21:02:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 21:02:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 21:02:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 21:02:45 --> Final output sent to browser
DEBUG - 2017-02-27 21:02:45 --> Total execution time: 1.2989
INFO - 2017-02-27 21:04:30 --> Config Class Initialized
INFO - 2017-02-27 21:04:30 --> Hooks Class Initialized
DEBUG - 2017-02-27 21:04:30 --> UTF-8 Support Enabled
INFO - 2017-02-27 21:04:30 --> Utf8 Class Initialized
INFO - 2017-02-27 21:04:30 --> URI Class Initialized
INFO - 2017-02-27 21:04:30 --> Router Class Initialized
INFO - 2017-02-27 21:04:30 --> Output Class Initialized
INFO - 2017-02-27 21:04:30 --> Security Class Initialized
DEBUG - 2017-02-27 21:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 21:04:30 --> Input Class Initialized
INFO - 2017-02-27 21:04:30 --> Language Class Initialized
INFO - 2017-02-27 21:04:30 --> Loader Class Initialized
INFO - 2017-02-27 21:04:31 --> Database Driver Class Initialized
INFO - 2017-02-27 21:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 21:04:31 --> Controller Class Initialized
INFO - 2017-02-27 21:04:31 --> Helper loaded: url_helper
DEBUG - 2017-02-27 21:04:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 21:04:40 --> Config Class Initialized
INFO - 2017-02-27 21:04:40 --> Hooks Class Initialized
DEBUG - 2017-02-27 21:04:40 --> UTF-8 Support Enabled
INFO - 2017-02-27 21:04:40 --> Utf8 Class Initialized
INFO - 2017-02-27 21:04:40 --> URI Class Initialized
INFO - 2017-02-27 21:04:40 --> Router Class Initialized
INFO - 2017-02-27 21:04:40 --> Output Class Initialized
INFO - 2017-02-27 21:04:40 --> Security Class Initialized
DEBUG - 2017-02-27 21:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 21:04:40 --> Input Class Initialized
INFO - 2017-02-27 21:04:40 --> Language Class Initialized
INFO - 2017-02-27 21:04:41 --> Loader Class Initialized
INFO - 2017-02-27 21:04:41 --> Database Driver Class Initialized
INFO - 2017-02-27 21:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 21:04:41 --> Controller Class Initialized
INFO - 2017-02-27 21:04:41 --> Helper loaded: date_helper
DEBUG - 2017-02-27 21:04:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 21:04:41 --> Helper loaded: url_helper
INFO - 2017-02-27 21:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 21:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-27 21:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-27 21:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-27 21:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 21:04:41 --> Final output sent to browser
DEBUG - 2017-02-27 21:04:41 --> Total execution time: 1.5429
INFO - 2017-02-27 21:04:46 --> Config Class Initialized
INFO - 2017-02-27 21:04:46 --> Hooks Class Initialized
DEBUG - 2017-02-27 21:04:46 --> UTF-8 Support Enabled
INFO - 2017-02-27 21:04:46 --> Utf8 Class Initialized
INFO - 2017-02-27 21:04:46 --> URI Class Initialized
INFO - 2017-02-27 21:04:46 --> Router Class Initialized
INFO - 2017-02-27 21:04:46 --> Output Class Initialized
INFO - 2017-02-27 21:04:46 --> Security Class Initialized
DEBUG - 2017-02-27 21:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 21:04:46 --> Input Class Initialized
INFO - 2017-02-27 21:04:46 --> Language Class Initialized
INFO - 2017-02-27 21:04:46 --> Loader Class Initialized
INFO - 2017-02-27 21:04:46 --> Database Driver Class Initialized
INFO - 2017-02-27 21:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 21:04:47 --> Controller Class Initialized
INFO - 2017-02-27 21:04:47 --> Helper loaded: url_helper
DEBUG - 2017-02-27 21:04:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 21:04:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 21:04:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 21:04:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 21:04:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 21:04:47 --> Final output sent to browser
DEBUG - 2017-02-27 21:04:47 --> Total execution time: 1.9043
INFO - 2017-02-27 21:05:34 --> Config Class Initialized
INFO - 2017-02-27 21:05:34 --> Hooks Class Initialized
DEBUG - 2017-02-27 21:05:35 --> UTF-8 Support Enabled
INFO - 2017-02-27 21:05:35 --> Utf8 Class Initialized
INFO - 2017-02-27 21:05:35 --> URI Class Initialized
DEBUG - 2017-02-27 21:05:35 --> No URI present. Default controller set.
INFO - 2017-02-27 21:05:35 --> Router Class Initialized
INFO - 2017-02-27 21:05:35 --> Output Class Initialized
INFO - 2017-02-27 21:05:35 --> Security Class Initialized
DEBUG - 2017-02-27 21:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 21:05:35 --> Input Class Initialized
INFO - 2017-02-27 21:05:35 --> Language Class Initialized
INFO - 2017-02-27 21:05:35 --> Loader Class Initialized
INFO - 2017-02-27 21:05:35 --> Database Driver Class Initialized
INFO - 2017-02-27 21:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 21:05:36 --> Controller Class Initialized
INFO - 2017-02-27 21:05:36 --> Helper loaded: url_helper
DEBUG - 2017-02-27 21:05:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 21:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 21:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 21:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 21:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 21:05:36 --> Final output sent to browser
DEBUG - 2017-02-27 21:05:36 --> Total execution time: 1.7255
INFO - 2017-02-27 21:05:43 --> Config Class Initialized
INFO - 2017-02-27 21:05:43 --> Hooks Class Initialized
DEBUG - 2017-02-27 21:05:43 --> UTF-8 Support Enabled
INFO - 2017-02-27 21:05:43 --> Utf8 Class Initialized
INFO - 2017-02-27 21:05:43 --> URI Class Initialized
INFO - 2017-02-27 21:05:43 --> Router Class Initialized
INFO - 2017-02-27 21:05:43 --> Output Class Initialized
INFO - 2017-02-27 21:05:43 --> Security Class Initialized
DEBUG - 2017-02-27 21:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 21:05:43 --> Input Class Initialized
INFO - 2017-02-27 21:05:43 --> Language Class Initialized
INFO - 2017-02-27 21:05:43 --> Loader Class Initialized
INFO - 2017-02-27 21:05:44 --> Database Driver Class Initialized
INFO - 2017-02-27 21:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 21:05:44 --> Controller Class Initialized
INFO - 2017-02-27 21:05:44 --> Helper loaded: url_helper
DEBUG - 2017-02-27 21:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 21:05:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 21:05:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 21:05:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 21:05:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 21:05:44 --> Final output sent to browser
DEBUG - 2017-02-27 21:05:44 --> Total execution time: 1.5426
INFO - 2017-02-27 21:07:28 --> Config Class Initialized
INFO - 2017-02-27 21:07:28 --> Hooks Class Initialized
DEBUG - 2017-02-27 21:07:28 --> UTF-8 Support Enabled
INFO - 2017-02-27 21:07:28 --> Utf8 Class Initialized
INFO - 2017-02-27 21:07:28 --> URI Class Initialized
INFO - 2017-02-27 21:07:28 --> Router Class Initialized
INFO - 2017-02-27 21:07:28 --> Output Class Initialized
INFO - 2017-02-27 21:07:28 --> Security Class Initialized
DEBUG - 2017-02-27 21:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 21:07:29 --> Input Class Initialized
INFO - 2017-02-27 21:07:29 --> Language Class Initialized
INFO - 2017-02-27 21:07:29 --> Loader Class Initialized
INFO - 2017-02-27 21:07:29 --> Database Driver Class Initialized
INFO - 2017-02-27 21:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 21:07:29 --> Controller Class Initialized
INFO - 2017-02-27 21:07:29 --> Helper loaded: url_helper
DEBUG - 2017-02-27 21:07:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 21:07:31 --> Config Class Initialized
INFO - 2017-02-27 21:07:31 --> Hooks Class Initialized
DEBUG - 2017-02-27 21:07:32 --> UTF-8 Support Enabled
INFO - 2017-02-27 21:07:32 --> Utf8 Class Initialized
INFO - 2017-02-27 21:07:32 --> URI Class Initialized
INFO - 2017-02-27 21:07:32 --> Router Class Initialized
INFO - 2017-02-27 21:07:32 --> Output Class Initialized
INFO - 2017-02-27 21:07:32 --> Security Class Initialized
DEBUG - 2017-02-27 21:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 21:07:32 --> Input Class Initialized
INFO - 2017-02-27 21:07:32 --> Language Class Initialized
INFO - 2017-02-27 21:07:32 --> Loader Class Initialized
INFO - 2017-02-27 21:07:32 --> Database Driver Class Initialized
INFO - 2017-02-27 21:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 21:07:32 --> Controller Class Initialized
INFO - 2017-02-27 21:07:32 --> Helper loaded: date_helper
DEBUG - 2017-02-27 21:07:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 21:07:32 --> Helper loaded: url_helper
INFO - 2017-02-27 21:07:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 21:07:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-27 21:07:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-27 21:07:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-27 21:07:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 21:07:33 --> Final output sent to browser
DEBUG - 2017-02-27 21:07:33 --> Total execution time: 1.1500
INFO - 2017-02-27 21:07:41 --> Config Class Initialized
INFO - 2017-02-27 21:07:41 --> Hooks Class Initialized
INFO - 2017-02-27 21:07:41 --> Config Class Initialized
INFO - 2017-02-27 21:07:41 --> Hooks Class Initialized
DEBUG - 2017-02-27 21:07:41 --> UTF-8 Support Enabled
DEBUG - 2017-02-27 21:07:41 --> UTF-8 Support Enabled
INFO - 2017-02-27 21:07:41 --> Utf8 Class Initialized
INFO - 2017-02-27 21:07:41 --> Utf8 Class Initialized
INFO - 2017-02-27 21:07:41 --> URI Class Initialized
INFO - 2017-02-27 21:07:41 --> URI Class Initialized
INFO - 2017-02-27 21:07:41 --> Router Class Initialized
INFO - 2017-02-27 21:07:42 --> Output Class Initialized
INFO - 2017-02-27 21:07:42 --> Security Class Initialized
DEBUG - 2017-02-27 21:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 21:07:42 --> Input Class Initialized
DEBUG - 2017-02-27 21:07:42 --> No URI present. Default controller set.
INFO - 2017-02-27 21:07:42 --> Language Class Initialized
INFO - 2017-02-27 21:07:42 --> Router Class Initialized
INFO - 2017-02-27 21:07:42 --> Output Class Initialized
INFO - 2017-02-27 21:07:42 --> Security Class Initialized
DEBUG - 2017-02-27 21:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 21:07:42 --> Loader Class Initialized
INFO - 2017-02-27 21:07:42 --> Input Class Initialized
INFO - 2017-02-27 21:07:42 --> Language Class Initialized
INFO - 2017-02-27 21:07:42 --> Loader Class Initialized
INFO - 2017-02-27 21:07:42 --> Database Driver Class Initialized
INFO - 2017-02-27 21:07:42 --> Database Driver Class Initialized
INFO - 2017-02-27 21:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 21:07:42 --> Controller Class Initialized
INFO - 2017-02-27 21:07:42 --> Helper loaded: url_helper
DEBUG - 2017-02-27 21:07:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 21:07:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 21:07:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 21:07:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 21:07:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 21:07:43 --> Final output sent to browser
DEBUG - 2017-02-27 21:07:43 --> Total execution time: 1.5158
INFO - 2017-02-27 21:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 21:07:43 --> Controller Class Initialized
INFO - 2017-02-27 21:07:43 --> Helper loaded: url_helper
DEBUG - 2017-02-27 21:07:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 21:07:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 21:07:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 21:07:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 21:07:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 21:07:43 --> Final output sent to browser
DEBUG - 2017-02-27 21:07:43 --> Total execution time: 1.5187
INFO - 2017-02-27 21:07:48 --> Config Class Initialized
INFO - 2017-02-27 21:07:48 --> Config Class Initialized
INFO - 2017-02-27 21:07:48 --> Hooks Class Initialized
INFO - 2017-02-27 21:07:48 --> Hooks Class Initialized
DEBUG - 2017-02-27 21:07:48 --> UTF-8 Support Enabled
INFO - 2017-02-27 21:07:48 --> Utf8 Class Initialized
DEBUG - 2017-02-27 21:07:48 --> UTF-8 Support Enabled
INFO - 2017-02-27 21:07:48 --> URI Class Initialized
INFO - 2017-02-27 21:07:48 --> Utf8 Class Initialized
INFO - 2017-02-27 21:07:48 --> URI Class Initialized
INFO - 2017-02-27 21:07:48 --> Router Class Initialized
INFO - 2017-02-27 21:07:48 --> Router Class Initialized
INFO - 2017-02-27 21:07:48 --> Output Class Initialized
INFO - 2017-02-27 21:07:48 --> Output Class Initialized
INFO - 2017-02-27 21:07:48 --> Security Class Initialized
INFO - 2017-02-27 21:07:48 --> Security Class Initialized
DEBUG - 2017-02-27 21:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 21:07:48 --> Input Class Initialized
INFO - 2017-02-27 21:07:48 --> Language Class Initialized
DEBUG - 2017-02-27 21:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 21:07:48 --> Input Class Initialized
INFO - 2017-02-27 21:07:48 --> Language Class Initialized
INFO - 2017-02-27 21:07:49 --> Loader Class Initialized
INFO - 2017-02-27 21:07:49 --> Loader Class Initialized
INFO - 2017-02-27 21:07:49 --> Database Driver Class Initialized
INFO - 2017-02-27 21:07:49 --> Database Driver Class Initialized
INFO - 2017-02-27 21:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 21:07:49 --> Controller Class Initialized
INFO - 2017-02-27 21:07:49 --> Helper loaded: url_helper
DEBUG - 2017-02-27 21:07:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 21:07:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 21:07:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 21:07:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 21:07:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 21:07:49 --> Final output sent to browser
DEBUG - 2017-02-27 21:07:49 --> Total execution time: 1.3081
INFO - 2017-02-27 21:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 21:07:50 --> Controller Class Initialized
INFO - 2017-02-27 21:07:50 --> Helper loaded: date_helper
DEBUG - 2017-02-27 21:07:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 21:07:50 --> Helper loaded: url_helper
INFO - 2017-02-27 21:07:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 21:07:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-27 21:07:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-27 21:07:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-27 21:07:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 21:07:50 --> Final output sent to browser
DEBUG - 2017-02-27 21:07:50 --> Total execution time: 2.1925
INFO - 2017-02-27 21:56:28 --> Config Class Initialized
INFO - 2017-02-27 21:56:28 --> Hooks Class Initialized
DEBUG - 2017-02-27 21:56:28 --> UTF-8 Support Enabled
INFO - 2017-02-27 21:56:28 --> Utf8 Class Initialized
INFO - 2017-02-27 21:56:28 --> URI Class Initialized
INFO - 2017-02-27 21:56:28 --> Router Class Initialized
INFO - 2017-02-27 21:56:28 --> Output Class Initialized
INFO - 2017-02-27 21:56:28 --> Security Class Initialized
DEBUG - 2017-02-27 21:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 21:56:28 --> Input Class Initialized
INFO - 2017-02-27 21:56:28 --> Language Class Initialized
INFO - 2017-02-27 21:56:28 --> Loader Class Initialized
INFO - 2017-02-27 21:56:29 --> Database Driver Class Initialized
INFO - 2017-02-27 21:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 21:56:29 --> Controller Class Initialized
INFO - 2017-02-27 21:56:29 --> Helper loaded: url_helper
DEBUG - 2017-02-27 21:56:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 21:56:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 21:56:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 21:56:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 21:56:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 21:56:30 --> Final output sent to browser
DEBUG - 2017-02-27 21:56:30 --> Total execution time: 8.4253
INFO - 2017-02-27 21:56:45 --> Config Class Initialized
INFO - 2017-02-27 21:56:45 --> Hooks Class Initialized
DEBUG - 2017-02-27 21:56:46 --> UTF-8 Support Enabled
INFO - 2017-02-27 21:56:46 --> Utf8 Class Initialized
INFO - 2017-02-27 21:56:46 --> URI Class Initialized
DEBUG - 2017-02-27 21:56:46 --> No URI present. Default controller set.
INFO - 2017-02-27 21:56:46 --> Router Class Initialized
INFO - 2017-02-27 21:56:46 --> Output Class Initialized
INFO - 2017-02-27 21:56:46 --> Security Class Initialized
DEBUG - 2017-02-27 21:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 21:56:46 --> Input Class Initialized
INFO - 2017-02-27 21:56:46 --> Language Class Initialized
INFO - 2017-02-27 21:56:46 --> Loader Class Initialized
INFO - 2017-02-27 21:56:47 --> Database Driver Class Initialized
INFO - 2017-02-27 21:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 21:56:48 --> Controller Class Initialized
INFO - 2017-02-27 21:56:48 --> Helper loaded: url_helper
DEBUG - 2017-02-27 21:56:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 21:56:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 21:56:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 21:56:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 21:56:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 21:56:49 --> Final output sent to browser
DEBUG - 2017-02-27 21:56:49 --> Total execution time: 11.0073
INFO - 2017-02-27 23:15:01 --> Config Class Initialized
INFO - 2017-02-27 23:15:01 --> Hooks Class Initialized
DEBUG - 2017-02-27 23:15:01 --> UTF-8 Support Enabled
INFO - 2017-02-27 23:15:01 --> Utf8 Class Initialized
INFO - 2017-02-27 23:15:01 --> URI Class Initialized
INFO - 2017-02-27 23:15:01 --> Router Class Initialized
INFO - 2017-02-27 23:15:01 --> Output Class Initialized
INFO - 2017-02-27 23:15:01 --> Security Class Initialized
DEBUG - 2017-02-27 23:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 23:15:01 --> Input Class Initialized
INFO - 2017-02-27 23:15:01 --> Language Class Initialized
INFO - 2017-02-27 23:15:02 --> Loader Class Initialized
INFO - 2017-02-27 23:15:02 --> Database Driver Class Initialized
INFO - 2017-02-27 23:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 23:15:03 --> Controller Class Initialized
INFO - 2017-02-27 23:15:04 --> Helper loaded: date_helper
DEBUG - 2017-02-27 23:15:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 23:15:04 --> Helper loaded: url_helper
INFO - 2017-02-27 23:15:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 23:15:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-27 23:15:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-27 23:15:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-27 23:15:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 23:15:05 --> Final output sent to browser
DEBUG - 2017-02-27 23:15:05 --> Total execution time: 4.0572
INFO - 2017-02-27 23:15:10 --> Config Class Initialized
INFO - 2017-02-27 23:15:10 --> Hooks Class Initialized
DEBUG - 2017-02-27 23:15:10 --> UTF-8 Support Enabled
INFO - 2017-02-27 23:15:10 --> Utf8 Class Initialized
INFO - 2017-02-27 23:15:10 --> URI Class Initialized
INFO - 2017-02-27 23:15:10 --> Router Class Initialized
INFO - 2017-02-27 23:15:10 --> Output Class Initialized
INFO - 2017-02-27 23:15:10 --> Security Class Initialized
DEBUG - 2017-02-27 23:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 23:15:10 --> Input Class Initialized
INFO - 2017-02-27 23:15:10 --> Language Class Initialized
INFO - 2017-02-27 23:15:10 --> Loader Class Initialized
INFO - 2017-02-27 23:15:10 --> Database Driver Class Initialized
INFO - 2017-02-27 23:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 23:15:10 --> Controller Class Initialized
INFO - 2017-02-27 23:15:10 --> Helper loaded: url_helper
DEBUG - 2017-02-27 23:15:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-27 23:15:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-27 23:15:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-27 23:15:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-27 23:15:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-27 23:15:11 --> Final output sent to browser
DEBUG - 2017-02-27 23:15:11 --> Total execution time: 1.2659

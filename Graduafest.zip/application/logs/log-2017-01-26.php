<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-26 00:06:14 --> Config Class Initialized
INFO - 2017-01-26 00:06:14 --> Hooks Class Initialized
DEBUG - 2017-01-26 00:06:14 --> UTF-8 Support Enabled
INFO - 2017-01-26 00:06:14 --> Utf8 Class Initialized
INFO - 2017-01-26 00:06:14 --> URI Class Initialized
DEBUG - 2017-01-26 00:06:14 --> No URI present. Default controller set.
INFO - 2017-01-26 00:06:14 --> Router Class Initialized
INFO - 2017-01-26 00:06:14 --> Output Class Initialized
INFO - 2017-01-26 00:06:14 --> Security Class Initialized
DEBUG - 2017-01-26 00:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 00:06:14 --> Input Class Initialized
INFO - 2017-01-26 00:06:14 --> Language Class Initialized
INFO - 2017-01-26 00:06:14 --> Loader Class Initialized
INFO - 2017-01-26 00:06:14 --> Database Driver Class Initialized
INFO - 2017-01-26 00:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 00:06:14 --> Controller Class Initialized
INFO - 2017-01-26 00:06:14 --> Helper loaded: url_helper
DEBUG - 2017-01-26 00:06:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 00:06:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 00:06:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 00:06:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 00:06:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 00:06:14 --> Final output sent to browser
DEBUG - 2017-01-26 00:06:14 --> Total execution time: 0.2719
INFO - 2017-01-26 00:06:18 --> Config Class Initialized
INFO - 2017-01-26 00:06:18 --> Hooks Class Initialized
DEBUG - 2017-01-26 00:06:18 --> UTF-8 Support Enabled
INFO - 2017-01-26 00:06:18 --> Utf8 Class Initialized
INFO - 2017-01-26 00:06:18 --> URI Class Initialized
INFO - 2017-01-26 00:06:18 --> Router Class Initialized
INFO - 2017-01-26 00:06:18 --> Output Class Initialized
INFO - 2017-01-26 00:06:18 --> Security Class Initialized
DEBUG - 2017-01-26 00:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 00:06:18 --> Input Class Initialized
INFO - 2017-01-26 00:06:18 --> Language Class Initialized
INFO - 2017-01-26 00:06:18 --> Loader Class Initialized
INFO - 2017-01-26 00:06:18 --> Database Driver Class Initialized
INFO - 2017-01-26 00:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 00:06:18 --> Controller Class Initialized
INFO - 2017-01-26 00:06:18 --> Helper loaded: url_helper
DEBUG - 2017-01-26 00:06:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 00:06:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 00:06:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 00:06:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 00:06:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 00:06:18 --> Final output sent to browser
DEBUG - 2017-01-26 00:06:18 --> Total execution time: 0.0517
INFO - 2017-01-26 00:06:26 --> Config Class Initialized
INFO - 2017-01-26 00:06:26 --> Hooks Class Initialized
DEBUG - 2017-01-26 00:06:26 --> UTF-8 Support Enabled
INFO - 2017-01-26 00:06:26 --> Utf8 Class Initialized
INFO - 2017-01-26 00:06:26 --> URI Class Initialized
INFO - 2017-01-26 00:06:26 --> Router Class Initialized
INFO - 2017-01-26 00:06:26 --> Output Class Initialized
INFO - 2017-01-26 00:06:26 --> Security Class Initialized
DEBUG - 2017-01-26 00:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 00:06:26 --> Input Class Initialized
INFO - 2017-01-26 00:06:26 --> Language Class Initialized
INFO - 2017-01-26 00:06:26 --> Loader Class Initialized
INFO - 2017-01-26 00:06:26 --> Database Driver Class Initialized
INFO - 2017-01-26 00:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 00:06:26 --> Controller Class Initialized
INFO - 2017-01-26 00:06:26 --> Helper loaded: url_helper
DEBUG - 2017-01-26 00:06:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 00:06:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-26 00:06:26 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-26 00:06:26 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-26 00:06:26 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-26 00:06:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 00:06:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 00:06:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 00:06:26 --> Final output sent to browser
DEBUG - 2017-01-26 00:06:26 --> Total execution time: 0.0751
INFO - 2017-01-26 00:06:28 --> Config Class Initialized
INFO - 2017-01-26 00:06:28 --> Hooks Class Initialized
DEBUG - 2017-01-26 00:06:28 --> UTF-8 Support Enabled
INFO - 2017-01-26 00:06:28 --> Utf8 Class Initialized
INFO - 2017-01-26 00:06:28 --> URI Class Initialized
INFO - 2017-01-26 00:06:28 --> Router Class Initialized
INFO - 2017-01-26 00:06:28 --> Output Class Initialized
INFO - 2017-01-26 00:06:28 --> Security Class Initialized
DEBUG - 2017-01-26 00:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 00:06:28 --> Input Class Initialized
INFO - 2017-01-26 00:06:28 --> Language Class Initialized
INFO - 2017-01-26 00:06:28 --> Loader Class Initialized
INFO - 2017-01-26 00:06:28 --> Database Driver Class Initialized
INFO - 2017-01-26 00:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 00:06:28 --> Controller Class Initialized
INFO - 2017-01-26 00:06:28 --> Helper loaded: url_helper
DEBUG - 2017-01-26 00:06:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 00:06:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 00:06:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 00:06:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 00:06:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 00:06:28 --> Final output sent to browser
DEBUG - 2017-01-26 00:06:28 --> Total execution time: 0.0136
INFO - 2017-01-26 00:06:50 --> Config Class Initialized
INFO - 2017-01-26 00:06:50 --> Hooks Class Initialized
DEBUG - 2017-01-26 00:06:50 --> UTF-8 Support Enabled
INFO - 2017-01-26 00:06:50 --> Utf8 Class Initialized
INFO - 2017-01-26 00:06:50 --> URI Class Initialized
INFO - 2017-01-26 00:06:50 --> Router Class Initialized
INFO - 2017-01-26 00:06:50 --> Output Class Initialized
INFO - 2017-01-26 00:06:50 --> Security Class Initialized
DEBUG - 2017-01-26 00:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 00:06:50 --> Input Class Initialized
INFO - 2017-01-26 00:06:50 --> Language Class Initialized
INFO - 2017-01-26 00:06:50 --> Loader Class Initialized
INFO - 2017-01-26 00:06:50 --> Database Driver Class Initialized
INFO - 2017-01-26 00:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 00:06:50 --> Controller Class Initialized
INFO - 2017-01-26 00:06:50 --> Helper loaded: url_helper
DEBUG - 2017-01-26 00:06:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-26 00:06:51 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-26 00:06:51 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Fatty R. Ramos')
INFO - 2017-01-26 00:06:51 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-26 00:06:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-26 00:06:51 --> Config Class Initialized
INFO - 2017-01-26 00:06:51 --> Hooks Class Initialized
DEBUG - 2017-01-26 00:06:51 --> UTF-8 Support Enabled
INFO - 2017-01-26 00:06:51 --> Utf8 Class Initialized
INFO - 2017-01-26 00:06:51 --> URI Class Initialized
INFO - 2017-01-26 00:06:51 --> Router Class Initialized
INFO - 2017-01-26 00:06:51 --> Output Class Initialized
INFO - 2017-01-26 00:06:51 --> Security Class Initialized
DEBUG - 2017-01-26 00:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 00:06:51 --> Input Class Initialized
INFO - 2017-01-26 00:06:51 --> Language Class Initialized
INFO - 2017-01-26 00:06:51 --> Loader Class Initialized
INFO - 2017-01-26 00:06:51 --> Database Driver Class Initialized
INFO - 2017-01-26 00:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 00:06:51 --> Controller Class Initialized
INFO - 2017-01-26 00:06:51 --> Helper loaded: url_helper
DEBUG - 2017-01-26 00:06:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 00:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 00:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 00:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 00:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 00:06:51 --> Final output sent to browser
DEBUG - 2017-01-26 00:06:51 --> Total execution time: 0.0641
INFO - 2017-01-26 04:04:11 --> Config Class Initialized
INFO - 2017-01-26 04:04:11 --> Hooks Class Initialized
DEBUG - 2017-01-26 04:04:11 --> UTF-8 Support Enabled
INFO - 2017-01-26 04:04:11 --> Utf8 Class Initialized
INFO - 2017-01-26 04:04:11 --> URI Class Initialized
DEBUG - 2017-01-26 04:04:11 --> No URI present. Default controller set.
INFO - 2017-01-26 04:04:11 --> Router Class Initialized
INFO - 2017-01-26 04:04:11 --> Output Class Initialized
INFO - 2017-01-26 04:04:11 --> Security Class Initialized
DEBUG - 2017-01-26 04:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 04:04:11 --> Input Class Initialized
INFO - 2017-01-26 04:04:11 --> Language Class Initialized
INFO - 2017-01-26 04:04:11 --> Loader Class Initialized
INFO - 2017-01-26 04:04:11 --> Database Driver Class Initialized
INFO - 2017-01-26 04:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 04:04:11 --> Controller Class Initialized
INFO - 2017-01-26 04:04:11 --> Helper loaded: url_helper
DEBUG - 2017-01-26 04:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 04:04:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 04:04:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 04:04:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 04:04:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 04:04:11 --> Final output sent to browser
DEBUG - 2017-01-26 04:04:11 --> Total execution time: 0.0144
INFO - 2017-01-26 04:04:16 --> Config Class Initialized
INFO - 2017-01-26 04:04:16 --> Hooks Class Initialized
DEBUG - 2017-01-26 04:04:16 --> UTF-8 Support Enabled
INFO - 2017-01-26 04:04:16 --> Utf8 Class Initialized
INFO - 2017-01-26 04:04:16 --> URI Class Initialized
INFO - 2017-01-26 04:04:16 --> Router Class Initialized
INFO - 2017-01-26 04:04:16 --> Output Class Initialized
INFO - 2017-01-26 04:04:16 --> Security Class Initialized
DEBUG - 2017-01-26 04:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 04:04:16 --> Input Class Initialized
INFO - 2017-01-26 04:04:16 --> Language Class Initialized
INFO - 2017-01-26 04:04:16 --> Loader Class Initialized
INFO - 2017-01-26 04:04:16 --> Database Driver Class Initialized
INFO - 2017-01-26 04:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 04:04:17 --> Controller Class Initialized
INFO - 2017-01-26 04:04:17 --> Helper loaded: url_helper
DEBUG - 2017-01-26 04:04:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 04:04:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 04:04:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 04:04:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 04:04:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 04:04:17 --> Final output sent to browser
DEBUG - 2017-01-26 04:04:17 --> Total execution time: 0.0425
INFO - 2017-01-26 04:05:04 --> Config Class Initialized
INFO - 2017-01-26 04:05:04 --> Hooks Class Initialized
DEBUG - 2017-01-26 04:05:04 --> UTF-8 Support Enabled
INFO - 2017-01-26 04:05:04 --> Utf8 Class Initialized
INFO - 2017-01-26 04:05:04 --> URI Class Initialized
DEBUG - 2017-01-26 04:05:04 --> No URI present. Default controller set.
INFO - 2017-01-26 04:05:04 --> Router Class Initialized
INFO - 2017-01-26 04:05:04 --> Output Class Initialized
INFO - 2017-01-26 04:05:04 --> Security Class Initialized
DEBUG - 2017-01-26 04:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 04:05:04 --> Input Class Initialized
INFO - 2017-01-26 04:05:04 --> Language Class Initialized
INFO - 2017-01-26 04:05:04 --> Loader Class Initialized
INFO - 2017-01-26 04:05:04 --> Database Driver Class Initialized
INFO - 2017-01-26 04:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 04:05:04 --> Controller Class Initialized
INFO - 2017-01-26 04:05:04 --> Helper loaded: url_helper
DEBUG - 2017-01-26 04:05:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 04:05:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 04:05:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 04:05:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 04:05:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 04:05:04 --> Final output sent to browser
DEBUG - 2017-01-26 04:05:04 --> Total execution time: 0.0134
INFO - 2017-01-26 04:05:08 --> Config Class Initialized
INFO - 2017-01-26 04:05:08 --> Hooks Class Initialized
DEBUG - 2017-01-26 04:05:08 --> UTF-8 Support Enabled
INFO - 2017-01-26 04:05:08 --> Utf8 Class Initialized
INFO - 2017-01-26 04:05:08 --> URI Class Initialized
INFO - 2017-01-26 04:05:08 --> Router Class Initialized
INFO - 2017-01-26 04:05:08 --> Output Class Initialized
INFO - 2017-01-26 04:05:08 --> Security Class Initialized
DEBUG - 2017-01-26 04:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 04:05:08 --> Input Class Initialized
INFO - 2017-01-26 04:05:08 --> Language Class Initialized
INFO - 2017-01-26 04:05:08 --> Loader Class Initialized
INFO - 2017-01-26 04:05:08 --> Database Driver Class Initialized
INFO - 2017-01-26 04:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 04:05:08 --> Controller Class Initialized
INFO - 2017-01-26 04:05:08 --> Helper loaded: url_helper
DEBUG - 2017-01-26 04:05:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 04:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 04:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 04:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 04:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 04:05:08 --> Final output sent to browser
DEBUG - 2017-01-26 04:05:08 --> Total execution time: 0.0141
INFO - 2017-01-26 04:07:47 --> Config Class Initialized
INFO - 2017-01-26 04:07:47 --> Hooks Class Initialized
DEBUG - 2017-01-26 04:07:47 --> UTF-8 Support Enabled
INFO - 2017-01-26 04:07:47 --> Utf8 Class Initialized
INFO - 2017-01-26 04:07:47 --> URI Class Initialized
INFO - 2017-01-26 04:07:47 --> Router Class Initialized
INFO - 2017-01-26 04:07:47 --> Output Class Initialized
INFO - 2017-01-26 04:07:47 --> Security Class Initialized
DEBUG - 2017-01-26 04:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 04:07:47 --> Input Class Initialized
INFO - 2017-01-26 04:07:47 --> Language Class Initialized
INFO - 2017-01-26 04:07:47 --> Loader Class Initialized
INFO - 2017-01-26 04:07:47 --> Database Driver Class Initialized
INFO - 2017-01-26 04:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 04:07:47 --> Controller Class Initialized
INFO - 2017-01-26 04:07:47 --> Helper loaded: url_helper
DEBUG - 2017-01-26 04:07:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 04:07:49 --> Config Class Initialized
INFO - 2017-01-26 04:07:49 --> Hooks Class Initialized
DEBUG - 2017-01-26 04:07:49 --> UTF-8 Support Enabled
INFO - 2017-01-26 04:07:49 --> Utf8 Class Initialized
INFO - 2017-01-26 04:07:49 --> URI Class Initialized
INFO - 2017-01-26 04:07:49 --> Router Class Initialized
INFO - 2017-01-26 04:07:49 --> Output Class Initialized
INFO - 2017-01-26 04:07:49 --> Security Class Initialized
DEBUG - 2017-01-26 04:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 04:07:49 --> Input Class Initialized
INFO - 2017-01-26 04:07:49 --> Language Class Initialized
INFO - 2017-01-26 04:07:49 --> Loader Class Initialized
INFO - 2017-01-26 04:07:49 --> Database Driver Class Initialized
INFO - 2017-01-26 04:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 04:07:49 --> Controller Class Initialized
INFO - 2017-01-26 04:07:49 --> Helper loaded: date_helper
DEBUG - 2017-01-26 04:07:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 04:07:49 --> Helper loaded: url_helper
INFO - 2017-01-26 04:07:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 04:07:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-26 04:07:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-26 04:07:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-26 04:07:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 04:07:49 --> Final output sent to browser
DEBUG - 2017-01-26 04:07:49 --> Total execution time: 0.2719
INFO - 2017-01-26 04:07:51 --> Config Class Initialized
INFO - 2017-01-26 04:07:51 --> Hooks Class Initialized
DEBUG - 2017-01-26 04:07:51 --> UTF-8 Support Enabled
INFO - 2017-01-26 04:07:51 --> Utf8 Class Initialized
INFO - 2017-01-26 04:07:51 --> URI Class Initialized
INFO - 2017-01-26 04:07:51 --> Router Class Initialized
INFO - 2017-01-26 04:07:51 --> Output Class Initialized
INFO - 2017-01-26 04:07:51 --> Security Class Initialized
DEBUG - 2017-01-26 04:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 04:07:51 --> Input Class Initialized
INFO - 2017-01-26 04:07:51 --> Language Class Initialized
INFO - 2017-01-26 04:07:51 --> Loader Class Initialized
INFO - 2017-01-26 04:07:51 --> Database Driver Class Initialized
INFO - 2017-01-26 04:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 04:07:51 --> Controller Class Initialized
INFO - 2017-01-26 04:07:51 --> Helper loaded: url_helper
DEBUG - 2017-01-26 04:07:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 04:07:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 04:07:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 04:07:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 04:07:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 04:07:51 --> Final output sent to browser
DEBUG - 2017-01-26 04:07:51 --> Total execution time: 0.0139
INFO - 2017-01-26 04:08:04 --> Config Class Initialized
INFO - 2017-01-26 04:08:04 --> Hooks Class Initialized
DEBUG - 2017-01-26 04:08:04 --> UTF-8 Support Enabled
INFO - 2017-01-26 04:08:04 --> Utf8 Class Initialized
INFO - 2017-01-26 04:08:04 --> URI Class Initialized
INFO - 2017-01-26 04:08:04 --> Router Class Initialized
INFO - 2017-01-26 04:08:04 --> Output Class Initialized
INFO - 2017-01-26 04:08:04 --> Security Class Initialized
DEBUG - 2017-01-26 04:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 04:08:04 --> Input Class Initialized
INFO - 2017-01-26 04:08:04 --> Language Class Initialized
INFO - 2017-01-26 04:08:04 --> Loader Class Initialized
INFO - 2017-01-26 04:08:04 --> Database Driver Class Initialized
INFO - 2017-01-26 04:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 04:08:04 --> Controller Class Initialized
INFO - 2017-01-26 04:08:04 --> Helper loaded: url_helper
DEBUG - 2017-01-26 04:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 04:08:05 --> Config Class Initialized
INFO - 2017-01-26 04:08:05 --> Hooks Class Initialized
DEBUG - 2017-01-26 04:08:05 --> UTF-8 Support Enabled
INFO - 2017-01-26 04:08:05 --> Utf8 Class Initialized
INFO - 2017-01-26 04:08:05 --> URI Class Initialized
INFO - 2017-01-26 04:08:05 --> Router Class Initialized
INFO - 2017-01-26 04:08:05 --> Output Class Initialized
INFO - 2017-01-26 04:08:05 --> Security Class Initialized
DEBUG - 2017-01-26 04:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 04:08:05 --> Input Class Initialized
INFO - 2017-01-26 04:08:05 --> Language Class Initialized
INFO - 2017-01-26 04:08:05 --> Loader Class Initialized
INFO - 2017-01-26 04:08:05 --> Database Driver Class Initialized
INFO - 2017-01-26 04:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 04:08:05 --> Controller Class Initialized
INFO - 2017-01-26 04:08:05 --> Helper loaded: date_helper
DEBUG - 2017-01-26 04:08:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 04:08:05 --> Helper loaded: url_helper
INFO - 2017-01-26 04:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 04:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-26 04:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-26 04:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-26 04:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 04:08:05 --> Final output sent to browser
DEBUG - 2017-01-26 04:08:05 --> Total execution time: 0.0133
INFO - 2017-01-26 04:08:06 --> Config Class Initialized
INFO - 2017-01-26 04:08:06 --> Hooks Class Initialized
DEBUG - 2017-01-26 04:08:06 --> UTF-8 Support Enabled
INFO - 2017-01-26 04:08:06 --> Utf8 Class Initialized
INFO - 2017-01-26 04:08:06 --> URI Class Initialized
INFO - 2017-01-26 04:08:06 --> Router Class Initialized
INFO - 2017-01-26 04:08:06 --> Output Class Initialized
INFO - 2017-01-26 04:08:06 --> Security Class Initialized
DEBUG - 2017-01-26 04:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 04:08:06 --> Input Class Initialized
INFO - 2017-01-26 04:08:06 --> Language Class Initialized
INFO - 2017-01-26 04:08:06 --> Loader Class Initialized
INFO - 2017-01-26 04:08:06 --> Database Driver Class Initialized
INFO - 2017-01-26 04:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 04:08:06 --> Controller Class Initialized
INFO - 2017-01-26 04:08:06 --> Helper loaded: url_helper
DEBUG - 2017-01-26 04:08:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 04:08:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 04:08:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 04:08:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 04:08:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 04:08:06 --> Final output sent to browser
DEBUG - 2017-01-26 04:08:06 --> Total execution time: 0.0143
INFO - 2017-01-26 04:08:10 --> Config Class Initialized
INFO - 2017-01-26 04:08:10 --> Hooks Class Initialized
DEBUG - 2017-01-26 04:08:10 --> UTF-8 Support Enabled
INFO - 2017-01-26 04:08:10 --> Utf8 Class Initialized
INFO - 2017-01-26 04:08:10 --> URI Class Initialized
DEBUG - 2017-01-26 04:08:10 --> No URI present. Default controller set.
INFO - 2017-01-26 04:08:10 --> Router Class Initialized
INFO - 2017-01-26 04:08:10 --> Output Class Initialized
INFO - 2017-01-26 04:08:10 --> Security Class Initialized
DEBUG - 2017-01-26 04:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 04:08:10 --> Input Class Initialized
INFO - 2017-01-26 04:08:10 --> Language Class Initialized
INFO - 2017-01-26 04:08:10 --> Loader Class Initialized
INFO - 2017-01-26 04:08:10 --> Database Driver Class Initialized
INFO - 2017-01-26 04:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 04:08:10 --> Controller Class Initialized
INFO - 2017-01-26 04:08:10 --> Helper loaded: url_helper
DEBUG - 2017-01-26 04:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 04:08:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 04:08:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 04:08:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 04:08:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 04:08:10 --> Final output sent to browser
DEBUG - 2017-01-26 04:08:10 --> Total execution time: 0.0134
INFO - 2017-01-26 04:08:12 --> Config Class Initialized
INFO - 2017-01-26 04:08:12 --> Hooks Class Initialized
DEBUG - 2017-01-26 04:08:12 --> UTF-8 Support Enabled
INFO - 2017-01-26 04:08:12 --> Utf8 Class Initialized
INFO - 2017-01-26 04:08:12 --> URI Class Initialized
INFO - 2017-01-26 04:08:12 --> Router Class Initialized
INFO - 2017-01-26 04:08:12 --> Output Class Initialized
INFO - 2017-01-26 04:08:12 --> Security Class Initialized
DEBUG - 2017-01-26 04:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 04:08:12 --> Input Class Initialized
INFO - 2017-01-26 04:08:12 --> Language Class Initialized
INFO - 2017-01-26 04:08:12 --> Loader Class Initialized
INFO - 2017-01-26 04:08:12 --> Database Driver Class Initialized
INFO - 2017-01-26 04:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 04:08:12 --> Controller Class Initialized
INFO - 2017-01-26 04:08:12 --> Helper loaded: url_helper
DEBUG - 2017-01-26 04:08:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 04:08:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 04:08:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 04:08:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 04:08:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 04:08:12 --> Final output sent to browser
DEBUG - 2017-01-26 04:08:12 --> Total execution time: 0.0136
INFO - 2017-01-26 04:09:17 --> Config Class Initialized
INFO - 2017-01-26 04:09:17 --> Hooks Class Initialized
DEBUG - 2017-01-26 04:09:17 --> UTF-8 Support Enabled
INFO - 2017-01-26 04:09:17 --> Utf8 Class Initialized
INFO - 2017-01-26 04:09:17 --> URI Class Initialized
INFO - 2017-01-26 04:09:17 --> Router Class Initialized
INFO - 2017-01-26 04:09:17 --> Output Class Initialized
INFO - 2017-01-26 04:09:17 --> Security Class Initialized
DEBUG - 2017-01-26 04:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 04:09:17 --> Input Class Initialized
INFO - 2017-01-26 04:09:17 --> Language Class Initialized
INFO - 2017-01-26 04:09:17 --> Loader Class Initialized
INFO - 2017-01-26 04:09:17 --> Database Driver Class Initialized
INFO - 2017-01-26 04:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 04:09:17 --> Controller Class Initialized
INFO - 2017-01-26 04:09:17 --> Helper loaded: url_helper
DEBUG - 2017-01-26 04:09:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 04:09:18 --> Config Class Initialized
INFO - 2017-01-26 04:09:18 --> Hooks Class Initialized
DEBUG - 2017-01-26 04:09:18 --> UTF-8 Support Enabled
INFO - 2017-01-26 04:09:18 --> Utf8 Class Initialized
INFO - 2017-01-26 04:09:18 --> URI Class Initialized
INFO - 2017-01-26 04:09:18 --> Router Class Initialized
INFO - 2017-01-26 04:09:18 --> Output Class Initialized
INFO - 2017-01-26 04:09:18 --> Security Class Initialized
DEBUG - 2017-01-26 04:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 04:09:18 --> Input Class Initialized
INFO - 2017-01-26 04:09:18 --> Language Class Initialized
INFO - 2017-01-26 04:09:18 --> Loader Class Initialized
INFO - 2017-01-26 04:09:18 --> Database Driver Class Initialized
INFO - 2017-01-26 04:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 04:09:18 --> Controller Class Initialized
INFO - 2017-01-26 04:09:18 --> Helper loaded: date_helper
DEBUG - 2017-01-26 04:09:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 04:09:18 --> Helper loaded: url_helper
INFO - 2017-01-26 04:09:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 04:09:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-26 04:09:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-26 04:09:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-26 04:09:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 04:09:18 --> Final output sent to browser
DEBUG - 2017-01-26 04:09:18 --> Total execution time: 0.0140
INFO - 2017-01-26 04:09:20 --> Config Class Initialized
INFO - 2017-01-26 04:09:20 --> Hooks Class Initialized
DEBUG - 2017-01-26 04:09:20 --> UTF-8 Support Enabled
INFO - 2017-01-26 04:09:20 --> Utf8 Class Initialized
INFO - 2017-01-26 04:09:20 --> URI Class Initialized
INFO - 2017-01-26 04:09:20 --> Router Class Initialized
INFO - 2017-01-26 04:09:20 --> Output Class Initialized
INFO - 2017-01-26 04:09:20 --> Security Class Initialized
DEBUG - 2017-01-26 04:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 04:09:20 --> Input Class Initialized
INFO - 2017-01-26 04:09:20 --> Language Class Initialized
INFO - 2017-01-26 04:09:20 --> Loader Class Initialized
INFO - 2017-01-26 04:09:20 --> Database Driver Class Initialized
INFO - 2017-01-26 04:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 04:09:20 --> Controller Class Initialized
INFO - 2017-01-26 04:09:20 --> Helper loaded: url_helper
DEBUG - 2017-01-26 04:09:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 04:09:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 04:09:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 04:09:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 04:09:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 04:09:20 --> Final output sent to browser
DEBUG - 2017-01-26 04:09:20 --> Total execution time: 0.0141
INFO - 2017-01-26 04:09:25 --> Config Class Initialized
INFO - 2017-01-26 04:09:25 --> Hooks Class Initialized
DEBUG - 2017-01-26 04:09:25 --> UTF-8 Support Enabled
INFO - 2017-01-26 04:09:25 --> Utf8 Class Initialized
INFO - 2017-01-26 04:09:25 --> URI Class Initialized
DEBUG - 2017-01-26 04:09:25 --> No URI present. Default controller set.
INFO - 2017-01-26 04:09:25 --> Router Class Initialized
INFO - 2017-01-26 04:09:25 --> Output Class Initialized
INFO - 2017-01-26 04:09:25 --> Security Class Initialized
DEBUG - 2017-01-26 04:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 04:09:25 --> Input Class Initialized
INFO - 2017-01-26 04:09:25 --> Language Class Initialized
INFO - 2017-01-26 04:09:25 --> Loader Class Initialized
INFO - 2017-01-26 04:09:25 --> Database Driver Class Initialized
INFO - 2017-01-26 04:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 04:09:25 --> Controller Class Initialized
INFO - 2017-01-26 04:09:25 --> Helper loaded: url_helper
DEBUG - 2017-01-26 04:09:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 04:09:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 04:09:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 04:09:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 04:09:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 04:09:25 --> Final output sent to browser
DEBUG - 2017-01-26 04:09:25 --> Total execution time: 0.0151
INFO - 2017-01-26 04:09:29 --> Config Class Initialized
INFO - 2017-01-26 04:09:29 --> Hooks Class Initialized
DEBUG - 2017-01-26 04:09:29 --> UTF-8 Support Enabled
INFO - 2017-01-26 04:09:29 --> Utf8 Class Initialized
INFO - 2017-01-26 04:09:29 --> URI Class Initialized
INFO - 2017-01-26 04:09:29 --> Router Class Initialized
INFO - 2017-01-26 04:09:29 --> Output Class Initialized
INFO - 2017-01-26 04:09:29 --> Security Class Initialized
DEBUG - 2017-01-26 04:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 04:09:29 --> Input Class Initialized
INFO - 2017-01-26 04:09:29 --> Language Class Initialized
INFO - 2017-01-26 04:09:29 --> Loader Class Initialized
INFO - 2017-01-26 04:09:29 --> Database Driver Class Initialized
INFO - 2017-01-26 04:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 04:09:29 --> Controller Class Initialized
INFO - 2017-01-26 04:09:29 --> Helper loaded: url_helper
DEBUG - 2017-01-26 04:09:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 04:09:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 04:09:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 04:09:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 04:09:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 04:09:29 --> Final output sent to browser
DEBUG - 2017-01-26 04:09:29 --> Total execution time: 0.0147
INFO - 2017-01-26 04:14:53 --> Config Class Initialized
INFO - 2017-01-26 04:14:53 --> Hooks Class Initialized
DEBUG - 2017-01-26 04:14:53 --> UTF-8 Support Enabled
INFO - 2017-01-26 04:14:53 --> Utf8 Class Initialized
INFO - 2017-01-26 04:14:53 --> URI Class Initialized
DEBUG - 2017-01-26 04:14:53 --> No URI present. Default controller set.
INFO - 2017-01-26 04:14:53 --> Router Class Initialized
INFO - 2017-01-26 04:14:53 --> Output Class Initialized
INFO - 2017-01-26 04:14:53 --> Security Class Initialized
DEBUG - 2017-01-26 04:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 04:14:53 --> Input Class Initialized
INFO - 2017-01-26 04:14:53 --> Language Class Initialized
INFO - 2017-01-26 04:14:53 --> Loader Class Initialized
INFO - 2017-01-26 04:14:53 --> Database Driver Class Initialized
INFO - 2017-01-26 04:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 04:14:53 --> Controller Class Initialized
INFO - 2017-01-26 04:14:53 --> Helper loaded: url_helper
DEBUG - 2017-01-26 04:14:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 04:14:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 04:14:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 04:14:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 04:14:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 04:14:53 --> Final output sent to browser
DEBUG - 2017-01-26 04:14:53 --> Total execution time: 0.0136
INFO - 2017-01-26 06:06:37 --> Config Class Initialized
INFO - 2017-01-26 06:06:37 --> Hooks Class Initialized
DEBUG - 2017-01-26 06:06:37 --> UTF-8 Support Enabled
INFO - 2017-01-26 06:06:37 --> Utf8 Class Initialized
INFO - 2017-01-26 06:06:37 --> URI Class Initialized
INFO - 2017-01-26 06:06:37 --> Router Class Initialized
INFO - 2017-01-26 06:06:37 --> Output Class Initialized
INFO - 2017-01-26 06:06:37 --> Security Class Initialized
DEBUG - 2017-01-26 06:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 06:06:37 --> Input Class Initialized
INFO - 2017-01-26 06:06:37 --> Language Class Initialized
INFO - 2017-01-26 06:06:37 --> Loader Class Initialized
INFO - 2017-01-26 06:06:37 --> Database Driver Class Initialized
INFO - 2017-01-26 06:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 06:06:37 --> Controller Class Initialized
INFO - 2017-01-26 06:06:37 --> Helper loaded: url_helper
DEBUG - 2017-01-26 06:06:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 06:06:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 06:06:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 06:06:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 06:06:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 06:06:37 --> Final output sent to browser
DEBUG - 2017-01-26 06:06:37 --> Total execution time: 0.2391
INFO - 2017-01-26 15:04:41 --> Config Class Initialized
INFO - 2017-01-26 15:04:41 --> Hooks Class Initialized
DEBUG - 2017-01-26 15:04:41 --> UTF-8 Support Enabled
INFO - 2017-01-26 15:04:41 --> Utf8 Class Initialized
INFO - 2017-01-26 15:04:41 --> URI Class Initialized
INFO - 2017-01-26 15:04:41 --> Router Class Initialized
INFO - 2017-01-26 15:04:41 --> Output Class Initialized
INFO - 2017-01-26 15:04:41 --> Security Class Initialized
DEBUG - 2017-01-26 15:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 15:04:41 --> Input Class Initialized
INFO - 2017-01-26 15:04:41 --> Language Class Initialized
INFO - 2017-01-26 15:04:41 --> Loader Class Initialized
INFO - 2017-01-26 15:04:41 --> Database Driver Class Initialized
INFO - 2017-01-26 15:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 15:04:41 --> Controller Class Initialized
INFO - 2017-01-26 15:04:41 --> Helper loaded: url_helper
DEBUG - 2017-01-26 15:04:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 15:04:41 --> Helper loaded: form_helper
INFO - 2017-01-26 15:04:41 --> Form Validation Class Initialized
INFO - 2017-01-26 15:04:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-26 15:04:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-26 15:04:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-26 15:04:41 --> Final output sent to browser
DEBUG - 2017-01-26 15:04:41 --> Total execution time: 0.2138
INFO - 2017-01-26 15:04:41 --> Config Class Initialized
INFO - 2017-01-26 15:04:41 --> Hooks Class Initialized
DEBUG - 2017-01-26 15:04:41 --> UTF-8 Support Enabled
INFO - 2017-01-26 15:04:41 --> Utf8 Class Initialized
INFO - 2017-01-26 15:04:41 --> URI Class Initialized
INFO - 2017-01-26 15:04:41 --> Router Class Initialized
INFO - 2017-01-26 15:04:41 --> Output Class Initialized
INFO - 2017-01-26 15:04:41 --> Security Class Initialized
DEBUG - 2017-01-26 15:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 15:04:41 --> Input Class Initialized
INFO - 2017-01-26 15:04:41 --> Language Class Initialized
INFO - 2017-01-26 15:04:41 --> Loader Class Initialized
INFO - 2017-01-26 15:04:41 --> Database Driver Class Initialized
INFO - 2017-01-26 15:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 15:04:41 --> Controller Class Initialized
INFO - 2017-01-26 15:04:41 --> Helper loaded: url_helper
DEBUG - 2017-01-26 15:04:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 15:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 15:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 15:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 15:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 15:04:41 --> Final output sent to browser
DEBUG - 2017-01-26 15:04:41 --> Total execution time: 0.0141
INFO - 2017-01-26 16:20:21 --> Config Class Initialized
INFO - 2017-01-26 16:20:21 --> Hooks Class Initialized
DEBUG - 2017-01-26 16:20:21 --> UTF-8 Support Enabled
INFO - 2017-01-26 16:20:21 --> Utf8 Class Initialized
INFO - 2017-01-26 16:20:21 --> URI Class Initialized
DEBUG - 2017-01-26 16:20:21 --> No URI present. Default controller set.
INFO - 2017-01-26 16:20:21 --> Router Class Initialized
INFO - 2017-01-26 16:20:21 --> Output Class Initialized
INFO - 2017-01-26 16:20:21 --> Security Class Initialized
DEBUG - 2017-01-26 16:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 16:20:21 --> Input Class Initialized
INFO - 2017-01-26 16:20:21 --> Language Class Initialized
INFO - 2017-01-26 16:20:21 --> Loader Class Initialized
INFO - 2017-01-26 16:20:21 --> Database Driver Class Initialized
INFO - 2017-01-26 16:20:21 --> Config Class Initialized
INFO - 2017-01-26 16:20:21 --> Hooks Class Initialized
DEBUG - 2017-01-26 16:20:21 --> UTF-8 Support Enabled
INFO - 2017-01-26 16:20:21 --> Utf8 Class Initialized
INFO - 2017-01-26 16:20:21 --> URI Class Initialized
INFO - 2017-01-26 16:20:21 --> Router Class Initialized
INFO - 2017-01-26 16:20:21 --> Output Class Initialized
INFO - 2017-01-26 16:20:21 --> Security Class Initialized
DEBUG - 2017-01-26 16:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 16:20:21 --> Input Class Initialized
INFO - 2017-01-26 16:20:21 --> Language Class Initialized
INFO - 2017-01-26 16:20:21 --> Loader Class Initialized
INFO - 2017-01-26 16:20:21 --> Database Driver Class Initialized
INFO - 2017-01-26 16:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 16:20:21 --> Controller Class Initialized
INFO - 2017-01-26 16:20:21 --> Helper loaded: url_helper
DEBUG - 2017-01-26 16:20:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 16:20:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 16:20:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 16:20:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 16:20:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 16:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 16:20:21 --> Controller Class Initialized
INFO - 2017-01-26 16:20:21 --> Helper loaded: url_helper
DEBUG - 2017-01-26 16:20:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 16:20:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 16:20:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 16:20:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 16:20:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 16:20:21 --> Final output sent to browser
DEBUG - 2017-01-26 16:20:21 --> Total execution time: 0.1009
INFO - 2017-01-26 16:20:21 --> Final output sent to browser
DEBUG - 2017-01-26 16:20:21 --> Total execution time: 0.0664
INFO - 2017-01-26 17:41:14 --> Config Class Initialized
INFO - 2017-01-26 17:41:14 --> Hooks Class Initialized
DEBUG - 2017-01-26 17:41:14 --> UTF-8 Support Enabled
INFO - 2017-01-26 17:41:14 --> Utf8 Class Initialized
INFO - 2017-01-26 17:41:14 --> URI Class Initialized
DEBUG - 2017-01-26 17:41:14 --> No URI present. Default controller set.
INFO - 2017-01-26 17:41:15 --> Router Class Initialized
INFO - 2017-01-26 17:41:15 --> Output Class Initialized
INFO - 2017-01-26 17:41:15 --> Security Class Initialized
DEBUG - 2017-01-26 17:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 17:41:15 --> Input Class Initialized
INFO - 2017-01-26 17:41:15 --> Language Class Initialized
INFO - 2017-01-26 17:41:15 --> Loader Class Initialized
INFO - 2017-01-26 17:41:15 --> Database Driver Class Initialized
INFO - 2017-01-26 17:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 17:41:15 --> Controller Class Initialized
INFO - 2017-01-26 17:41:15 --> Helper loaded: url_helper
DEBUG - 2017-01-26 17:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 17:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 17:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 17:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 17:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 17:41:15 --> Final output sent to browser
DEBUG - 2017-01-26 17:41:15 --> Total execution time: 0.9131
INFO - 2017-01-26 18:06:51 --> Config Class Initialized
INFO - 2017-01-26 18:06:51 --> Hooks Class Initialized
DEBUG - 2017-01-26 18:06:51 --> UTF-8 Support Enabled
INFO - 2017-01-26 18:06:51 --> Utf8 Class Initialized
INFO - 2017-01-26 18:06:51 --> URI Class Initialized
INFO - 2017-01-26 18:06:51 --> Router Class Initialized
INFO - 2017-01-26 18:06:51 --> Output Class Initialized
INFO - 2017-01-26 18:06:51 --> Security Class Initialized
DEBUG - 2017-01-26 18:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 18:06:51 --> Input Class Initialized
INFO - 2017-01-26 18:06:51 --> Language Class Initialized
INFO - 2017-01-26 18:06:51 --> Loader Class Initialized
INFO - 2017-01-26 18:06:51 --> Database Driver Class Initialized
INFO - 2017-01-26 18:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 18:06:51 --> Controller Class Initialized
INFO - 2017-01-26 18:06:51 --> Helper loaded: date_helper
DEBUG - 2017-01-26 18:06:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 18:06:51 --> Helper loaded: url_helper
INFO - 2017-01-26 18:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 18:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-26 18:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-26 18:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-26 18:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 18:06:51 --> Final output sent to browser
DEBUG - 2017-01-26 18:06:51 --> Total execution time: 0.3539
INFO - 2017-01-26 18:06:56 --> Config Class Initialized
INFO - 2017-01-26 18:06:56 --> Hooks Class Initialized
DEBUG - 2017-01-26 18:06:56 --> UTF-8 Support Enabled
INFO - 2017-01-26 18:06:56 --> Utf8 Class Initialized
INFO - 2017-01-26 18:06:56 --> URI Class Initialized
INFO - 2017-01-26 18:06:56 --> Router Class Initialized
INFO - 2017-01-26 18:06:56 --> Output Class Initialized
INFO - 2017-01-26 18:06:56 --> Security Class Initialized
DEBUG - 2017-01-26 18:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 18:06:56 --> Input Class Initialized
INFO - 2017-01-26 18:06:56 --> Language Class Initialized
INFO - 2017-01-26 18:06:56 --> Loader Class Initialized
INFO - 2017-01-26 18:06:56 --> Database Driver Class Initialized
INFO - 2017-01-26 18:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 18:06:56 --> Controller Class Initialized
INFO - 2017-01-26 18:06:56 --> Helper loaded: url_helper
DEBUG - 2017-01-26 18:06:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 18:06:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 18:06:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 18:06:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 18:06:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 18:06:56 --> Final output sent to browser
DEBUG - 2017-01-26 18:06:56 --> Total execution time: 0.0136
INFO - 2017-01-26 18:21:27 --> Config Class Initialized
INFO - 2017-01-26 18:21:27 --> Hooks Class Initialized
DEBUG - 2017-01-26 18:21:27 --> UTF-8 Support Enabled
INFO - 2017-01-26 18:21:27 --> Utf8 Class Initialized
INFO - 2017-01-26 18:21:27 --> URI Class Initialized
DEBUG - 2017-01-26 18:21:27 --> No URI present. Default controller set.
INFO - 2017-01-26 18:21:27 --> Router Class Initialized
INFO - 2017-01-26 18:21:27 --> Output Class Initialized
INFO - 2017-01-26 18:21:27 --> Security Class Initialized
DEBUG - 2017-01-26 18:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 18:21:27 --> Input Class Initialized
INFO - 2017-01-26 18:21:27 --> Language Class Initialized
INFO - 2017-01-26 18:21:27 --> Loader Class Initialized
INFO - 2017-01-26 18:21:27 --> Database Driver Class Initialized
INFO - 2017-01-26 18:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 18:21:27 --> Controller Class Initialized
INFO - 2017-01-26 18:21:27 --> Helper loaded: url_helper
DEBUG - 2017-01-26 18:21:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 18:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 18:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 18:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 18:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 18:21:27 --> Final output sent to browser
DEBUG - 2017-01-26 18:21:27 --> Total execution time: 0.2807
INFO - 2017-01-26 18:21:57 --> Config Class Initialized
INFO - 2017-01-26 18:21:57 --> Hooks Class Initialized
DEBUG - 2017-01-26 18:21:57 --> UTF-8 Support Enabled
INFO - 2017-01-26 18:21:57 --> Utf8 Class Initialized
INFO - 2017-01-26 18:21:57 --> URI Class Initialized
DEBUG - 2017-01-26 18:21:57 --> No URI present. Default controller set.
INFO - 2017-01-26 18:21:57 --> Router Class Initialized
INFO - 2017-01-26 18:21:57 --> Output Class Initialized
INFO - 2017-01-26 18:21:57 --> Security Class Initialized
DEBUG - 2017-01-26 18:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 18:21:57 --> Input Class Initialized
INFO - 2017-01-26 18:21:57 --> Language Class Initialized
INFO - 2017-01-26 18:21:57 --> Loader Class Initialized
INFO - 2017-01-26 18:21:57 --> Database Driver Class Initialized
INFO - 2017-01-26 18:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 18:21:57 --> Controller Class Initialized
INFO - 2017-01-26 18:21:57 --> Helper loaded: url_helper
DEBUG - 2017-01-26 18:21:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 18:21:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 18:21:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 18:21:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 18:21:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 18:21:57 --> Final output sent to browser
DEBUG - 2017-01-26 18:21:57 --> Total execution time: 0.0130
INFO - 2017-01-26 18:22:32 --> Config Class Initialized
INFO - 2017-01-26 18:22:32 --> Hooks Class Initialized
DEBUG - 2017-01-26 18:22:32 --> UTF-8 Support Enabled
INFO - 2017-01-26 18:22:32 --> Utf8 Class Initialized
INFO - 2017-01-26 18:22:32 --> URI Class Initialized
INFO - 2017-01-26 18:22:32 --> Router Class Initialized
INFO - 2017-01-26 18:22:32 --> Output Class Initialized
INFO - 2017-01-26 18:22:32 --> Security Class Initialized
DEBUG - 2017-01-26 18:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 18:22:32 --> Input Class Initialized
INFO - 2017-01-26 18:22:32 --> Language Class Initialized
INFO - 2017-01-26 18:22:32 --> Loader Class Initialized
INFO - 2017-01-26 18:22:32 --> Database Driver Class Initialized
INFO - 2017-01-26 18:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 18:22:32 --> Controller Class Initialized
INFO - 2017-01-26 18:22:32 --> Helper loaded: url_helper
DEBUG - 2017-01-26 18:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 18:22:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 18:22:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 18:22:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 18:22:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 18:22:32 --> Final output sent to browser
DEBUG - 2017-01-26 18:22:32 --> Total execution time: 0.0137
INFO - 2017-01-26 18:22:39 --> Config Class Initialized
INFO - 2017-01-26 18:22:39 --> Hooks Class Initialized
DEBUG - 2017-01-26 18:22:39 --> UTF-8 Support Enabled
INFO - 2017-01-26 18:22:39 --> Utf8 Class Initialized
INFO - 2017-01-26 18:22:39 --> URI Class Initialized
INFO - 2017-01-26 18:22:39 --> Router Class Initialized
INFO - 2017-01-26 18:22:39 --> Output Class Initialized
INFO - 2017-01-26 18:22:39 --> Security Class Initialized
DEBUG - 2017-01-26 18:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 18:22:39 --> Input Class Initialized
INFO - 2017-01-26 18:22:39 --> Language Class Initialized
INFO - 2017-01-26 18:22:39 --> Loader Class Initialized
INFO - 2017-01-26 18:22:39 --> Database Driver Class Initialized
INFO - 2017-01-26 18:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 18:22:39 --> Controller Class Initialized
INFO - 2017-01-26 18:22:39 --> Helper loaded: url_helper
DEBUG - 2017-01-26 18:22:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 18:22:41 --> Config Class Initialized
INFO - 2017-01-26 18:22:41 --> Hooks Class Initialized
DEBUG - 2017-01-26 18:22:41 --> UTF-8 Support Enabled
INFO - 2017-01-26 18:22:41 --> Utf8 Class Initialized
INFO - 2017-01-26 18:22:41 --> URI Class Initialized
INFO - 2017-01-26 18:22:41 --> Router Class Initialized
INFO - 2017-01-26 18:22:41 --> Output Class Initialized
INFO - 2017-01-26 18:22:41 --> Security Class Initialized
DEBUG - 2017-01-26 18:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 18:22:41 --> Input Class Initialized
INFO - 2017-01-26 18:22:41 --> Language Class Initialized
INFO - 2017-01-26 18:22:41 --> Loader Class Initialized
INFO - 2017-01-26 18:22:41 --> Database Driver Class Initialized
INFO - 2017-01-26 18:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 18:22:41 --> Controller Class Initialized
INFO - 2017-01-26 18:22:41 --> Helper loaded: date_helper
DEBUG - 2017-01-26 18:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 18:22:41 --> Helper loaded: url_helper
INFO - 2017-01-26 18:22:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 18:22:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-26 18:22:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-26 18:22:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-26 18:22:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 18:22:41 --> Final output sent to browser
DEBUG - 2017-01-26 18:22:41 --> Total execution time: 0.0130
INFO - 2017-01-26 18:22:43 --> Config Class Initialized
INFO - 2017-01-26 18:22:43 --> Hooks Class Initialized
DEBUG - 2017-01-26 18:22:43 --> UTF-8 Support Enabled
INFO - 2017-01-26 18:22:43 --> Utf8 Class Initialized
INFO - 2017-01-26 18:22:43 --> URI Class Initialized
INFO - 2017-01-26 18:22:43 --> Router Class Initialized
INFO - 2017-01-26 18:22:43 --> Output Class Initialized
INFO - 2017-01-26 18:22:43 --> Security Class Initialized
DEBUG - 2017-01-26 18:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 18:22:43 --> Input Class Initialized
INFO - 2017-01-26 18:22:43 --> Language Class Initialized
INFO - 2017-01-26 18:22:43 --> Loader Class Initialized
INFO - 2017-01-26 18:22:43 --> Database Driver Class Initialized
INFO - 2017-01-26 18:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 18:22:43 --> Controller Class Initialized
INFO - 2017-01-26 18:22:43 --> Helper loaded: url_helper
DEBUG - 2017-01-26 18:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 18:22:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 18:22:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 18:22:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 18:22:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 18:22:43 --> Final output sent to browser
DEBUG - 2017-01-26 18:22:43 --> Total execution time: 0.0215
INFO - 2017-01-26 18:23:43 --> Config Class Initialized
INFO - 2017-01-26 18:23:43 --> Hooks Class Initialized
DEBUG - 2017-01-26 18:23:43 --> UTF-8 Support Enabled
INFO - 2017-01-26 18:23:43 --> Utf8 Class Initialized
INFO - 2017-01-26 18:23:43 --> URI Class Initialized
DEBUG - 2017-01-26 18:23:43 --> No URI present. Default controller set.
INFO - 2017-01-26 18:23:43 --> Router Class Initialized
INFO - 2017-01-26 18:23:43 --> Output Class Initialized
INFO - 2017-01-26 18:23:43 --> Security Class Initialized
DEBUG - 2017-01-26 18:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 18:23:43 --> Input Class Initialized
INFO - 2017-01-26 18:23:43 --> Language Class Initialized
INFO - 2017-01-26 18:23:43 --> Loader Class Initialized
INFO - 2017-01-26 18:23:43 --> Database Driver Class Initialized
INFO - 2017-01-26 18:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 18:23:43 --> Controller Class Initialized
INFO - 2017-01-26 18:23:43 --> Helper loaded: url_helper
DEBUG - 2017-01-26 18:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 18:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 18:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 18:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 18:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 18:23:43 --> Final output sent to browser
DEBUG - 2017-01-26 18:23:43 --> Total execution time: 0.0138
INFO - 2017-01-26 18:23:44 --> Config Class Initialized
INFO - 2017-01-26 18:23:44 --> Hooks Class Initialized
DEBUG - 2017-01-26 18:23:44 --> UTF-8 Support Enabled
INFO - 2017-01-26 18:23:44 --> Utf8 Class Initialized
INFO - 2017-01-26 18:23:44 --> URI Class Initialized
INFO - 2017-01-26 18:23:44 --> Router Class Initialized
INFO - 2017-01-26 18:23:44 --> Output Class Initialized
INFO - 2017-01-26 18:23:44 --> Security Class Initialized
DEBUG - 2017-01-26 18:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 18:23:44 --> Input Class Initialized
INFO - 2017-01-26 18:23:44 --> Language Class Initialized
INFO - 2017-01-26 18:23:44 --> Loader Class Initialized
INFO - 2017-01-26 18:23:44 --> Database Driver Class Initialized
INFO - 2017-01-26 18:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 18:23:44 --> Controller Class Initialized
INFO - 2017-01-26 18:23:44 --> Helper loaded: url_helper
DEBUG - 2017-01-26 18:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 18:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 18:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 18:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 18:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 18:23:44 --> Final output sent to browser
DEBUG - 2017-01-26 18:23:44 --> Total execution time: 0.0138
INFO - 2017-01-26 21:07:27 --> Config Class Initialized
INFO - 2017-01-26 21:07:27 --> Hooks Class Initialized
DEBUG - 2017-01-26 21:07:27 --> UTF-8 Support Enabled
INFO - 2017-01-26 21:07:27 --> Utf8 Class Initialized
INFO - 2017-01-26 21:07:27 --> URI Class Initialized
DEBUG - 2017-01-26 21:07:27 --> No URI present. Default controller set.
INFO - 2017-01-26 21:07:27 --> Router Class Initialized
INFO - 2017-01-26 21:07:27 --> Output Class Initialized
INFO - 2017-01-26 21:07:27 --> Security Class Initialized
DEBUG - 2017-01-26 21:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 21:07:27 --> Input Class Initialized
INFO - 2017-01-26 21:07:27 --> Language Class Initialized
INFO - 2017-01-26 21:07:27 --> Loader Class Initialized
INFO - 2017-01-26 21:07:27 --> Database Driver Class Initialized
INFO - 2017-01-26 21:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 21:07:27 --> Controller Class Initialized
INFO - 2017-01-26 21:07:27 --> Helper loaded: url_helper
DEBUG - 2017-01-26 21:07:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 21:07:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 21:07:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 21:07:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 21:07:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 21:07:27 --> Final output sent to browser
DEBUG - 2017-01-26 21:07:27 --> Total execution time: 0.0134
INFO - 2017-01-26 21:07:44 --> Config Class Initialized
INFO - 2017-01-26 21:07:44 --> Hooks Class Initialized
DEBUG - 2017-01-26 21:07:44 --> UTF-8 Support Enabled
INFO - 2017-01-26 21:07:44 --> Utf8 Class Initialized
INFO - 2017-01-26 21:07:44 --> URI Class Initialized
INFO - 2017-01-26 21:07:44 --> Router Class Initialized
INFO - 2017-01-26 21:07:44 --> Output Class Initialized
INFO - 2017-01-26 21:07:44 --> Security Class Initialized
DEBUG - 2017-01-26 21:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 21:07:44 --> Input Class Initialized
INFO - 2017-01-26 21:07:44 --> Language Class Initialized
INFO - 2017-01-26 21:07:44 --> Loader Class Initialized
INFO - 2017-01-26 21:07:44 --> Database Driver Class Initialized
INFO - 2017-01-26 21:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 21:07:44 --> Controller Class Initialized
INFO - 2017-01-26 21:07:44 --> Helper loaded: url_helper
DEBUG - 2017-01-26 21:07:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 21:07:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 21:07:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 21:07:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 21:07:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 21:07:44 --> Final output sent to browser
DEBUG - 2017-01-26 21:07:44 --> Total execution time: 0.0148
INFO - 2017-01-26 21:08:55 --> Config Class Initialized
INFO - 2017-01-26 21:08:55 --> Hooks Class Initialized
DEBUG - 2017-01-26 21:08:55 --> UTF-8 Support Enabled
INFO - 2017-01-26 21:08:55 --> Utf8 Class Initialized
INFO - 2017-01-26 21:08:55 --> URI Class Initialized
INFO - 2017-01-26 21:08:55 --> Router Class Initialized
INFO - 2017-01-26 21:08:55 --> Output Class Initialized
INFO - 2017-01-26 21:08:55 --> Security Class Initialized
DEBUG - 2017-01-26 21:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 21:08:55 --> Input Class Initialized
INFO - 2017-01-26 21:08:55 --> Language Class Initialized
INFO - 2017-01-26 21:08:55 --> Loader Class Initialized
INFO - 2017-01-26 21:08:55 --> Database Driver Class Initialized
INFO - 2017-01-26 21:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 21:08:55 --> Controller Class Initialized
INFO - 2017-01-26 21:08:55 --> Helper loaded: url_helper
DEBUG - 2017-01-26 21:08:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 21:08:58 --> Config Class Initialized
INFO - 2017-01-26 21:08:58 --> Hooks Class Initialized
DEBUG - 2017-01-26 21:08:58 --> UTF-8 Support Enabled
INFO - 2017-01-26 21:08:58 --> Utf8 Class Initialized
INFO - 2017-01-26 21:08:58 --> URI Class Initialized
INFO - 2017-01-26 21:08:58 --> Router Class Initialized
INFO - 2017-01-26 21:08:58 --> Output Class Initialized
INFO - 2017-01-26 21:08:58 --> Security Class Initialized
DEBUG - 2017-01-26 21:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 21:08:58 --> Input Class Initialized
INFO - 2017-01-26 21:08:58 --> Language Class Initialized
INFO - 2017-01-26 21:08:58 --> Loader Class Initialized
INFO - 2017-01-26 21:08:58 --> Database Driver Class Initialized
INFO - 2017-01-26 21:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 21:08:58 --> Controller Class Initialized
INFO - 2017-01-26 21:08:59 --> Helper loaded: date_helper
DEBUG - 2017-01-26 21:08:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 21:08:59 --> Helper loaded: url_helper
INFO - 2017-01-26 21:08:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 21:08:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-26 21:08:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-26 21:08:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-26 21:08:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 21:08:59 --> Final output sent to browser
DEBUG - 2017-01-26 21:08:59 --> Total execution time: 0.0796
INFO - 2017-01-26 21:09:01 --> Config Class Initialized
INFO - 2017-01-26 21:09:01 --> Hooks Class Initialized
DEBUG - 2017-01-26 21:09:01 --> UTF-8 Support Enabled
INFO - 2017-01-26 21:09:01 --> Utf8 Class Initialized
INFO - 2017-01-26 21:09:01 --> URI Class Initialized
INFO - 2017-01-26 21:09:01 --> Router Class Initialized
INFO - 2017-01-26 21:09:01 --> Output Class Initialized
INFO - 2017-01-26 21:09:01 --> Security Class Initialized
DEBUG - 2017-01-26 21:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 21:09:01 --> Input Class Initialized
INFO - 2017-01-26 21:09:01 --> Language Class Initialized
INFO - 2017-01-26 21:09:01 --> Loader Class Initialized
INFO - 2017-01-26 21:09:01 --> Database Driver Class Initialized
INFO - 2017-01-26 21:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 21:09:01 --> Controller Class Initialized
INFO - 2017-01-26 21:09:01 --> Helper loaded: url_helper
DEBUG - 2017-01-26 21:09:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 21:09:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 21:09:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 21:09:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 21:09:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 21:09:01 --> Final output sent to browser
DEBUG - 2017-01-26 21:09:01 --> Total execution time: 0.0136
INFO - 2017-01-26 21:09:11 --> Config Class Initialized
INFO - 2017-01-26 21:09:11 --> Hooks Class Initialized
DEBUG - 2017-01-26 21:09:11 --> UTF-8 Support Enabled
INFO - 2017-01-26 21:09:11 --> Utf8 Class Initialized
INFO - 2017-01-26 21:09:11 --> URI Class Initialized
DEBUG - 2017-01-26 21:09:11 --> No URI present. Default controller set.
INFO - 2017-01-26 21:09:11 --> Router Class Initialized
INFO - 2017-01-26 21:09:11 --> Output Class Initialized
INFO - 2017-01-26 21:09:11 --> Security Class Initialized
DEBUG - 2017-01-26 21:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 21:09:11 --> Input Class Initialized
INFO - 2017-01-26 21:09:11 --> Language Class Initialized
INFO - 2017-01-26 21:09:11 --> Loader Class Initialized
INFO - 2017-01-26 21:09:11 --> Database Driver Class Initialized
INFO - 2017-01-26 21:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 21:09:11 --> Controller Class Initialized
INFO - 2017-01-26 21:09:11 --> Helper loaded: url_helper
DEBUG - 2017-01-26 21:09:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 21:09:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 21:09:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 21:09:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 21:09:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 21:09:11 --> Final output sent to browser
DEBUG - 2017-01-26 21:09:11 --> Total execution time: 0.0133
INFO - 2017-01-26 21:09:16 --> Config Class Initialized
INFO - 2017-01-26 21:09:16 --> Hooks Class Initialized
DEBUG - 2017-01-26 21:09:16 --> UTF-8 Support Enabled
INFO - 2017-01-26 21:09:16 --> Utf8 Class Initialized
INFO - 2017-01-26 21:09:16 --> URI Class Initialized
INFO - 2017-01-26 21:09:16 --> Router Class Initialized
INFO - 2017-01-26 21:09:16 --> Output Class Initialized
INFO - 2017-01-26 21:09:16 --> Security Class Initialized
DEBUG - 2017-01-26 21:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 21:09:16 --> Input Class Initialized
INFO - 2017-01-26 21:09:16 --> Language Class Initialized
INFO - 2017-01-26 21:09:16 --> Loader Class Initialized
INFO - 2017-01-26 21:09:16 --> Database Driver Class Initialized
INFO - 2017-01-26 21:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 21:09:16 --> Controller Class Initialized
INFO - 2017-01-26 21:09:16 --> Helper loaded: url_helper
DEBUG - 2017-01-26 21:09:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 21:09:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 21:09:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 21:09:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 21:09:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 21:09:16 --> Final output sent to browser
DEBUG - 2017-01-26 21:09:16 --> Total execution time: 0.0169
INFO - 2017-01-26 22:11:09 --> Config Class Initialized
INFO - 2017-01-26 22:11:09 --> Hooks Class Initialized
DEBUG - 2017-01-26 22:11:09 --> UTF-8 Support Enabled
INFO - 2017-01-26 22:11:09 --> Utf8 Class Initialized
INFO - 2017-01-26 22:11:09 --> URI Class Initialized
DEBUG - 2017-01-26 22:11:09 --> No URI present. Default controller set.
INFO - 2017-01-26 22:11:09 --> Router Class Initialized
INFO - 2017-01-26 22:11:09 --> Output Class Initialized
INFO - 2017-01-26 22:11:09 --> Security Class Initialized
DEBUG - 2017-01-26 22:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 22:11:09 --> Input Class Initialized
INFO - 2017-01-26 22:11:09 --> Language Class Initialized
INFO - 2017-01-26 22:11:09 --> Loader Class Initialized
INFO - 2017-01-26 22:11:09 --> Database Driver Class Initialized
INFO - 2017-01-26 22:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 22:11:09 --> Controller Class Initialized
INFO - 2017-01-26 22:11:09 --> Helper loaded: url_helper
DEBUG - 2017-01-26 22:11:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 22:11:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 22:11:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 22:11:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 22:11:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 22:11:09 --> Final output sent to browser
DEBUG - 2017-01-26 22:11:09 --> Total execution time: 0.0174
INFO - 2017-01-26 22:11:11 --> Config Class Initialized
INFO - 2017-01-26 22:11:14 --> Hooks Class Initialized
DEBUG - 2017-01-26 22:11:14 --> UTF-8 Support Enabled
INFO - 2017-01-26 22:11:14 --> Utf8 Class Initialized
INFO - 2017-01-26 22:11:14 --> URI Class Initialized
INFO - 2017-01-26 22:11:14 --> Router Class Initialized
INFO - 2017-01-26 22:11:14 --> Output Class Initialized
INFO - 2017-01-26 22:11:14 --> Security Class Initialized
DEBUG - 2017-01-26 22:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 22:11:14 --> Input Class Initialized
INFO - 2017-01-26 22:11:14 --> Language Class Initialized
INFO - 2017-01-26 22:11:14 --> Loader Class Initialized
INFO - 2017-01-26 22:11:14 --> Database Driver Class Initialized
INFO - 2017-01-26 22:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 22:11:14 --> Controller Class Initialized
INFO - 2017-01-26 22:11:14 --> Helper loaded: url_helper
DEBUG - 2017-01-26 22:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 22:11:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 22:11:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 22:11:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 22:11:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 22:11:14 --> Final output sent to browser
DEBUG - 2017-01-26 22:11:14 --> Total execution time: 2.8823
INFO - 2017-01-26 22:17:29 --> Config Class Initialized
INFO - 2017-01-26 22:17:29 --> Hooks Class Initialized
DEBUG - 2017-01-26 22:17:29 --> UTF-8 Support Enabled
INFO - 2017-01-26 22:17:29 --> Utf8 Class Initialized
INFO - 2017-01-26 22:17:29 --> URI Class Initialized
INFO - 2017-01-26 22:17:29 --> Router Class Initialized
INFO - 2017-01-26 22:17:29 --> Output Class Initialized
INFO - 2017-01-26 22:17:29 --> Security Class Initialized
DEBUG - 2017-01-26 22:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 22:17:29 --> Input Class Initialized
INFO - 2017-01-26 22:17:29 --> Language Class Initialized
INFO - 2017-01-26 22:17:29 --> Loader Class Initialized
INFO - 2017-01-26 22:17:29 --> Database Driver Class Initialized
INFO - 2017-01-26 22:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 22:17:29 --> Controller Class Initialized
INFO - 2017-01-26 22:17:29 --> Helper loaded: url_helper
DEBUG - 2017-01-26 22:17:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 22:17:30 --> Config Class Initialized
INFO - 2017-01-26 22:17:30 --> Hooks Class Initialized
DEBUG - 2017-01-26 22:17:30 --> UTF-8 Support Enabled
INFO - 2017-01-26 22:17:30 --> Utf8 Class Initialized
INFO - 2017-01-26 22:17:30 --> URI Class Initialized
INFO - 2017-01-26 22:17:30 --> Router Class Initialized
INFO - 2017-01-26 22:17:30 --> Output Class Initialized
INFO - 2017-01-26 22:17:30 --> Security Class Initialized
DEBUG - 2017-01-26 22:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 22:17:30 --> Input Class Initialized
INFO - 2017-01-26 22:17:30 --> Language Class Initialized
INFO - 2017-01-26 22:17:30 --> Loader Class Initialized
INFO - 2017-01-26 22:17:30 --> Database Driver Class Initialized
INFO - 2017-01-26 22:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 22:17:30 --> Controller Class Initialized
INFO - 2017-01-26 22:17:30 --> Helper loaded: date_helper
DEBUG - 2017-01-26 22:17:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 22:17:30 --> Helper loaded: url_helper
INFO - 2017-01-26 22:17:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 22:17:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-26 22:17:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-26 22:17:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-26 22:17:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 22:17:30 --> Final output sent to browser
DEBUG - 2017-01-26 22:17:30 --> Total execution time: 0.0138
INFO - 2017-01-26 22:17:31 --> Config Class Initialized
INFO - 2017-01-26 22:17:31 --> Hooks Class Initialized
DEBUG - 2017-01-26 22:17:31 --> UTF-8 Support Enabled
INFO - 2017-01-26 22:17:31 --> Utf8 Class Initialized
INFO - 2017-01-26 22:17:31 --> URI Class Initialized
INFO - 2017-01-26 22:17:31 --> Router Class Initialized
INFO - 2017-01-26 22:17:31 --> Output Class Initialized
INFO - 2017-01-26 22:17:31 --> Security Class Initialized
DEBUG - 2017-01-26 22:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 22:17:31 --> Input Class Initialized
INFO - 2017-01-26 22:17:31 --> Language Class Initialized
INFO - 2017-01-26 22:17:31 --> Loader Class Initialized
INFO - 2017-01-26 22:17:31 --> Database Driver Class Initialized
INFO - 2017-01-26 22:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 22:17:31 --> Controller Class Initialized
INFO - 2017-01-26 22:17:31 --> Helper loaded: url_helper
DEBUG - 2017-01-26 22:17:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 22:17:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 22:17:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 22:17:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 22:17:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 22:17:31 --> Final output sent to browser
DEBUG - 2017-01-26 22:17:31 --> Total execution time: 0.0139
INFO - 2017-01-26 23:14:30 --> Config Class Initialized
INFO - 2017-01-26 23:14:30 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:14:30 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:14:30 --> Utf8 Class Initialized
INFO - 2017-01-26 23:14:30 --> URI Class Initialized
DEBUG - 2017-01-26 23:14:30 --> No URI present. Default controller set.
INFO - 2017-01-26 23:14:30 --> Router Class Initialized
INFO - 2017-01-26 23:14:30 --> Output Class Initialized
INFO - 2017-01-26 23:14:30 --> Security Class Initialized
DEBUG - 2017-01-26 23:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:14:30 --> Input Class Initialized
INFO - 2017-01-26 23:14:30 --> Language Class Initialized
INFO - 2017-01-26 23:14:30 --> Loader Class Initialized
INFO - 2017-01-26 23:14:30 --> Database Driver Class Initialized
INFO - 2017-01-26 23:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:14:30 --> Controller Class Initialized
INFO - 2017-01-26 23:14:30 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:14:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:14:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:14:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:14:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:14:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:14:30 --> Final output sent to browser
DEBUG - 2017-01-26 23:14:30 --> Total execution time: 0.0140
INFO - 2017-01-26 23:18:03 --> Config Class Initialized
INFO - 2017-01-26 23:18:03 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:18:03 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:18:03 --> Utf8 Class Initialized
INFO - 2017-01-26 23:18:03 --> URI Class Initialized
INFO - 2017-01-26 23:18:03 --> Router Class Initialized
INFO - 2017-01-26 23:18:03 --> Output Class Initialized
INFO - 2017-01-26 23:18:03 --> Security Class Initialized
DEBUG - 2017-01-26 23:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:18:03 --> Input Class Initialized
INFO - 2017-01-26 23:18:03 --> Language Class Initialized
INFO - 2017-01-26 23:18:03 --> Loader Class Initialized
INFO - 2017-01-26 23:18:03 --> Database Driver Class Initialized
INFO - 2017-01-26 23:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:18:03 --> Controller Class Initialized
INFO - 2017-01-26 23:18:03 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:18:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:18:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-26 23:18:03 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-26 23:18:03 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-26 23:18:03 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-26 23:18:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:18:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:18:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:18:03 --> Final output sent to browser
DEBUG - 2017-01-26 23:18:03 --> Total execution time: 0.0616
INFO - 2017-01-26 23:18:20 --> Config Class Initialized
INFO - 2017-01-26 23:18:20 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:18:20 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:18:20 --> Utf8 Class Initialized
INFO - 2017-01-26 23:18:20 --> URI Class Initialized
INFO - 2017-01-26 23:18:20 --> Router Class Initialized
INFO - 2017-01-26 23:18:20 --> Output Class Initialized
INFO - 2017-01-26 23:18:20 --> Security Class Initialized
DEBUG - 2017-01-26 23:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:18:20 --> Input Class Initialized
INFO - 2017-01-26 23:18:20 --> Language Class Initialized
INFO - 2017-01-26 23:18:20 --> Loader Class Initialized
INFO - 2017-01-26 23:18:20 --> Database Driver Class Initialized
INFO - 2017-01-26 23:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:18:20 --> Controller Class Initialized
INFO - 2017-01-26 23:18:20 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:18:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:18:21 --> Config Class Initialized
INFO - 2017-01-26 23:18:21 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:18:21 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:18:21 --> Utf8 Class Initialized
INFO - 2017-01-26 23:18:21 --> URI Class Initialized
INFO - 2017-01-26 23:18:21 --> Router Class Initialized
INFO - 2017-01-26 23:18:21 --> Output Class Initialized
INFO - 2017-01-26 23:18:21 --> Security Class Initialized
DEBUG - 2017-01-26 23:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:18:21 --> Input Class Initialized
INFO - 2017-01-26 23:18:21 --> Language Class Initialized
INFO - 2017-01-26 23:18:21 --> Loader Class Initialized
INFO - 2017-01-26 23:18:21 --> Database Driver Class Initialized
INFO - 2017-01-26 23:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:18:21 --> Controller Class Initialized
INFO - 2017-01-26 23:18:21 --> Helper loaded: date_helper
DEBUG - 2017-01-26 23:18:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:18:21 --> Helper loaded: url_helper
INFO - 2017-01-26 23:18:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:18:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-26 23:18:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-26 23:18:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-26 23:18:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:18:21 --> Final output sent to browser
DEBUG - 2017-01-26 23:18:21 --> Total execution time: 0.0146
INFO - 2017-01-26 23:18:42 --> Config Class Initialized
INFO - 2017-01-26 23:18:42 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:18:42 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:18:42 --> Utf8 Class Initialized
INFO - 2017-01-26 23:18:42 --> URI Class Initialized
DEBUG - 2017-01-26 23:18:42 --> No URI present. Default controller set.
INFO - 2017-01-26 23:18:42 --> Router Class Initialized
INFO - 2017-01-26 23:18:42 --> Output Class Initialized
INFO - 2017-01-26 23:18:42 --> Security Class Initialized
DEBUG - 2017-01-26 23:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:18:42 --> Input Class Initialized
INFO - 2017-01-26 23:18:42 --> Language Class Initialized
INFO - 2017-01-26 23:18:42 --> Loader Class Initialized
INFO - 2017-01-26 23:18:42 --> Database Driver Class Initialized
INFO - 2017-01-26 23:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:18:42 --> Controller Class Initialized
INFO - 2017-01-26 23:18:42 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:18:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:18:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:18:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:18:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:18:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:18:42 --> Final output sent to browser
DEBUG - 2017-01-26 23:18:42 --> Total execution time: 0.0146
INFO - 2017-01-26 23:19:31 --> Config Class Initialized
INFO - 2017-01-26 23:19:31 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:19:31 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:19:31 --> Utf8 Class Initialized
INFO - 2017-01-26 23:19:31 --> URI Class Initialized
INFO - 2017-01-26 23:19:31 --> Router Class Initialized
INFO - 2017-01-26 23:19:31 --> Output Class Initialized
INFO - 2017-01-26 23:19:31 --> Security Class Initialized
DEBUG - 2017-01-26 23:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:19:31 --> Input Class Initialized
INFO - 2017-01-26 23:19:31 --> Language Class Initialized
INFO - 2017-01-26 23:19:31 --> Loader Class Initialized
INFO - 2017-01-26 23:19:31 --> Database Driver Class Initialized
INFO - 2017-01-26 23:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:19:31 --> Controller Class Initialized
INFO - 2017-01-26 23:19:31 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:19:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:19:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:19:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:19:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:19:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:19:31 --> Final output sent to browser
DEBUG - 2017-01-26 23:19:31 --> Total execution time: 0.0140
INFO - 2017-01-26 23:19:44 --> Config Class Initialized
INFO - 2017-01-26 23:19:44 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:19:44 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:19:44 --> Utf8 Class Initialized
INFO - 2017-01-26 23:19:44 --> URI Class Initialized
DEBUG - 2017-01-26 23:19:44 --> No URI present. Default controller set.
INFO - 2017-01-26 23:19:44 --> Router Class Initialized
INFO - 2017-01-26 23:19:44 --> Output Class Initialized
INFO - 2017-01-26 23:19:44 --> Security Class Initialized
DEBUG - 2017-01-26 23:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:19:44 --> Input Class Initialized
INFO - 2017-01-26 23:19:44 --> Language Class Initialized
INFO - 2017-01-26 23:19:44 --> Loader Class Initialized
INFO - 2017-01-26 23:19:44 --> Database Driver Class Initialized
INFO - 2017-01-26 23:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:19:44 --> Controller Class Initialized
INFO - 2017-01-26 23:19:44 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:19:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:19:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:19:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:19:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:19:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:19:44 --> Final output sent to browser
DEBUG - 2017-01-26 23:19:44 --> Total execution time: 0.0140
INFO - 2017-01-26 23:19:55 --> Config Class Initialized
INFO - 2017-01-26 23:19:55 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:19:55 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:19:55 --> Utf8 Class Initialized
INFO - 2017-01-26 23:19:55 --> URI Class Initialized
INFO - 2017-01-26 23:19:55 --> Router Class Initialized
INFO - 2017-01-26 23:19:55 --> Output Class Initialized
INFO - 2017-01-26 23:19:55 --> Security Class Initialized
DEBUG - 2017-01-26 23:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:19:55 --> Input Class Initialized
INFO - 2017-01-26 23:19:55 --> Language Class Initialized
INFO - 2017-01-26 23:19:55 --> Loader Class Initialized
INFO - 2017-01-26 23:19:55 --> Database Driver Class Initialized
INFO - 2017-01-26 23:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:19:55 --> Controller Class Initialized
INFO - 2017-01-26 23:19:55 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:19:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:19:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:19:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:19:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:19:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:19:55 --> Final output sent to browser
DEBUG - 2017-01-26 23:19:55 --> Total execution time: 0.0295
INFO - 2017-01-26 23:20:11 --> Config Class Initialized
INFO - 2017-01-26 23:20:11 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:20:11 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:20:11 --> Utf8 Class Initialized
INFO - 2017-01-26 23:20:11 --> URI Class Initialized
INFO - 2017-01-26 23:20:11 --> Router Class Initialized
INFO - 2017-01-26 23:20:11 --> Output Class Initialized
INFO - 2017-01-26 23:20:11 --> Security Class Initialized
DEBUG - 2017-01-26 23:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:20:11 --> Input Class Initialized
INFO - 2017-01-26 23:20:11 --> Language Class Initialized
INFO - 2017-01-26 23:20:11 --> Loader Class Initialized
INFO - 2017-01-26 23:20:11 --> Database Driver Class Initialized
INFO - 2017-01-26 23:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:20:11 --> Controller Class Initialized
INFO - 2017-01-26 23:20:11 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:20:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:20:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-26 23:20:11 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-26 23:20:11 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-26 23:20:11 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-26 23:20:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:20:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:20:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:20:11 --> Final output sent to browser
DEBUG - 2017-01-26 23:20:11 --> Total execution time: 0.0561
INFO - 2017-01-26 23:20:55 --> Config Class Initialized
INFO - 2017-01-26 23:20:55 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:20:55 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:20:55 --> Utf8 Class Initialized
INFO - 2017-01-26 23:20:55 --> URI Class Initialized
DEBUG - 2017-01-26 23:20:55 --> No URI present. Default controller set.
INFO - 2017-01-26 23:20:55 --> Router Class Initialized
INFO - 2017-01-26 23:20:55 --> Output Class Initialized
INFO - 2017-01-26 23:20:55 --> Security Class Initialized
DEBUG - 2017-01-26 23:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:20:55 --> Input Class Initialized
INFO - 2017-01-26 23:20:55 --> Language Class Initialized
INFO - 2017-01-26 23:20:55 --> Loader Class Initialized
INFO - 2017-01-26 23:20:55 --> Database Driver Class Initialized
INFO - 2017-01-26 23:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:20:55 --> Controller Class Initialized
INFO - 2017-01-26 23:20:55 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:20:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:20:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:20:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:20:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:20:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:20:55 --> Final output sent to browser
DEBUG - 2017-01-26 23:20:55 --> Total execution time: 0.0140
INFO - 2017-01-26 23:21:00 --> Config Class Initialized
INFO - 2017-01-26 23:21:00 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:21:00 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:21:00 --> Utf8 Class Initialized
INFO - 2017-01-26 23:21:00 --> URI Class Initialized
DEBUG - 2017-01-26 23:21:00 --> No URI present. Default controller set.
INFO - 2017-01-26 23:21:00 --> Router Class Initialized
INFO - 2017-01-26 23:21:00 --> Output Class Initialized
INFO - 2017-01-26 23:21:00 --> Security Class Initialized
DEBUG - 2017-01-26 23:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:21:00 --> Input Class Initialized
INFO - 2017-01-26 23:21:00 --> Language Class Initialized
INFO - 2017-01-26 23:21:00 --> Loader Class Initialized
INFO - 2017-01-26 23:21:00 --> Database Driver Class Initialized
INFO - 2017-01-26 23:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:21:00 --> Controller Class Initialized
INFO - 2017-01-26 23:21:00 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:21:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:21:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:21:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:21:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:21:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:21:00 --> Final output sent to browser
DEBUG - 2017-01-26 23:21:00 --> Total execution time: 0.0139
INFO - 2017-01-26 23:21:54 --> Config Class Initialized
INFO - 2017-01-26 23:21:54 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:21:54 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:21:54 --> Utf8 Class Initialized
INFO - 2017-01-26 23:21:54 --> URI Class Initialized
INFO - 2017-01-26 23:21:54 --> Router Class Initialized
INFO - 2017-01-26 23:21:54 --> Output Class Initialized
INFO - 2017-01-26 23:21:54 --> Security Class Initialized
DEBUG - 2017-01-26 23:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:21:54 --> Input Class Initialized
INFO - 2017-01-26 23:21:54 --> Language Class Initialized
INFO - 2017-01-26 23:21:54 --> Loader Class Initialized
INFO - 2017-01-26 23:21:54 --> Database Driver Class Initialized
INFO - 2017-01-26 23:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:21:54 --> Controller Class Initialized
INFO - 2017-01-26 23:21:54 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:21:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:21:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:21:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:21:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:21:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:21:54 --> Final output sent to browser
DEBUG - 2017-01-26 23:21:54 --> Total execution time: 0.0139
INFO - 2017-01-26 23:23:14 --> Config Class Initialized
INFO - 2017-01-26 23:23:14 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:23:14 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:23:14 --> Utf8 Class Initialized
INFO - 2017-01-26 23:23:14 --> URI Class Initialized
INFO - 2017-01-26 23:23:14 --> Router Class Initialized
INFO - 2017-01-26 23:23:14 --> Output Class Initialized
INFO - 2017-01-26 23:23:14 --> Security Class Initialized
DEBUG - 2017-01-26 23:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:23:14 --> Input Class Initialized
INFO - 2017-01-26 23:23:14 --> Language Class Initialized
INFO - 2017-01-26 23:23:14 --> Loader Class Initialized
INFO - 2017-01-26 23:23:14 --> Database Driver Class Initialized
INFO - 2017-01-26 23:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:23:14 --> Controller Class Initialized
INFO - 2017-01-26 23:23:14 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:23:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-26 23:23:14 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-26 23:23:14 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-26 23:23:14 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-26 23:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:23:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:23:14 --> Final output sent to browser
DEBUG - 2017-01-26 23:23:14 --> Total execution time: 0.0142
INFO - 2017-01-26 23:23:16 --> Config Class Initialized
INFO - 2017-01-26 23:23:16 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:23:16 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:23:16 --> Utf8 Class Initialized
INFO - 2017-01-26 23:23:16 --> URI Class Initialized
INFO - 2017-01-26 23:23:16 --> Router Class Initialized
INFO - 2017-01-26 23:23:16 --> Output Class Initialized
INFO - 2017-01-26 23:23:16 --> Security Class Initialized
DEBUG - 2017-01-26 23:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:23:16 --> Input Class Initialized
INFO - 2017-01-26 23:23:16 --> Language Class Initialized
INFO - 2017-01-26 23:23:16 --> Loader Class Initialized
INFO - 2017-01-26 23:23:16 --> Database Driver Class Initialized
INFO - 2017-01-26 23:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:23:16 --> Controller Class Initialized
INFO - 2017-01-26 23:23:16 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:23:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:23:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:23:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:23:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:23:16 --> Final output sent to browser
DEBUG - 2017-01-26 23:23:16 --> Total execution time: 0.0160
INFO - 2017-01-26 23:23:18 --> Config Class Initialized
INFO - 2017-01-26 23:23:18 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:23:18 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:23:18 --> Utf8 Class Initialized
INFO - 2017-01-26 23:23:18 --> URI Class Initialized
INFO - 2017-01-26 23:23:18 --> Router Class Initialized
INFO - 2017-01-26 23:23:18 --> Output Class Initialized
INFO - 2017-01-26 23:23:18 --> Security Class Initialized
DEBUG - 2017-01-26 23:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:23:18 --> Input Class Initialized
INFO - 2017-01-26 23:23:18 --> Language Class Initialized
INFO - 2017-01-26 23:23:18 --> Loader Class Initialized
INFO - 2017-01-26 23:23:18 --> Database Driver Class Initialized
INFO - 2017-01-26 23:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:23:18 --> Controller Class Initialized
INFO - 2017-01-26 23:23:18 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:23:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:23:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-26 23:23:18 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-26 23:23:18 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-26 23:23:18 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-26 23:23:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:23:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:23:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:23:18 --> Final output sent to browser
DEBUG - 2017-01-26 23:23:18 --> Total execution time: 0.0551
INFO - 2017-01-26 23:23:25 --> Config Class Initialized
INFO - 2017-01-26 23:23:25 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:23:25 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:23:25 --> Utf8 Class Initialized
INFO - 2017-01-26 23:23:25 --> URI Class Initialized
INFO - 2017-01-26 23:23:25 --> Router Class Initialized
INFO - 2017-01-26 23:23:25 --> Output Class Initialized
INFO - 2017-01-26 23:23:25 --> Security Class Initialized
DEBUG - 2017-01-26 23:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:23:25 --> Input Class Initialized
INFO - 2017-01-26 23:23:25 --> Language Class Initialized
INFO - 2017-01-26 23:23:25 --> Loader Class Initialized
INFO - 2017-01-26 23:23:25 --> Database Driver Class Initialized
INFO - 2017-01-26 23:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:23:25 --> Controller Class Initialized
INFO - 2017-01-26 23:23:25 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:23:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:23:25 --> Final output sent to browser
DEBUG - 2017-01-26 23:23:25 --> Total execution time: 0.0589
INFO - 2017-01-26 23:23:31 --> Config Class Initialized
INFO - 2017-01-26 23:23:31 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:23:31 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:23:31 --> Utf8 Class Initialized
INFO - 2017-01-26 23:23:31 --> URI Class Initialized
INFO - 2017-01-26 23:23:31 --> Router Class Initialized
INFO - 2017-01-26 23:23:31 --> Output Class Initialized
INFO - 2017-01-26 23:23:31 --> Security Class Initialized
DEBUG - 2017-01-26 23:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:23:31 --> Input Class Initialized
INFO - 2017-01-26 23:23:31 --> Language Class Initialized
INFO - 2017-01-26 23:23:31 --> Loader Class Initialized
INFO - 2017-01-26 23:23:31 --> Database Driver Class Initialized
INFO - 2017-01-26 23:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:23:31 --> Controller Class Initialized
INFO - 2017-01-26 23:23:31 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:23:32 --> Config Class Initialized
INFO - 2017-01-26 23:23:32 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:23:32 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:23:32 --> Utf8 Class Initialized
INFO - 2017-01-26 23:23:32 --> URI Class Initialized
INFO - 2017-01-26 23:23:32 --> Router Class Initialized
INFO - 2017-01-26 23:23:32 --> Output Class Initialized
INFO - 2017-01-26 23:23:32 --> Security Class Initialized
DEBUG - 2017-01-26 23:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:23:32 --> Input Class Initialized
INFO - 2017-01-26 23:23:32 --> Language Class Initialized
INFO - 2017-01-26 23:23:32 --> Loader Class Initialized
INFO - 2017-01-26 23:23:32 --> Database Driver Class Initialized
INFO - 2017-01-26 23:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:23:32 --> Controller Class Initialized
INFO - 2017-01-26 23:23:32 --> Helper loaded: date_helper
DEBUG - 2017-01-26 23:23:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:23:32 --> Helper loaded: url_helper
INFO - 2017-01-26 23:23:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:23:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-26 23:23:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-26 23:23:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-26 23:23:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:23:32 --> Final output sent to browser
DEBUG - 2017-01-26 23:23:32 --> Total execution time: 0.0137
INFO - 2017-01-26 23:23:33 --> Config Class Initialized
INFO - 2017-01-26 23:23:33 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:23:33 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:23:33 --> Utf8 Class Initialized
INFO - 2017-01-26 23:23:33 --> URI Class Initialized
INFO - 2017-01-26 23:23:33 --> Router Class Initialized
INFO - 2017-01-26 23:23:33 --> Output Class Initialized
INFO - 2017-01-26 23:23:33 --> Security Class Initialized
DEBUG - 2017-01-26 23:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:23:33 --> Input Class Initialized
INFO - 2017-01-26 23:23:33 --> Language Class Initialized
INFO - 2017-01-26 23:23:33 --> Loader Class Initialized
INFO - 2017-01-26 23:23:33 --> Database Driver Class Initialized
INFO - 2017-01-26 23:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:23:33 --> Controller Class Initialized
INFO - 2017-01-26 23:23:33 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:23:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:23:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:23:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:23:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:23:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:23:33 --> Final output sent to browser
DEBUG - 2017-01-26 23:23:33 --> Total execution time: 0.0144
INFO - 2017-01-26 23:24:06 --> Config Class Initialized
INFO - 2017-01-26 23:24:06 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:24:06 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:24:06 --> Utf8 Class Initialized
INFO - 2017-01-26 23:24:06 --> URI Class Initialized
INFO - 2017-01-26 23:24:06 --> Router Class Initialized
INFO - 2017-01-26 23:24:06 --> Output Class Initialized
INFO - 2017-01-26 23:24:06 --> Security Class Initialized
DEBUG - 2017-01-26 23:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:24:06 --> Input Class Initialized
INFO - 2017-01-26 23:24:06 --> Language Class Initialized
INFO - 2017-01-26 23:24:06 --> Loader Class Initialized
INFO - 2017-01-26 23:24:06 --> Database Driver Class Initialized
INFO - 2017-01-26 23:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:24:06 --> Controller Class Initialized
INFO - 2017-01-26 23:24:06 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:24:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:24:08 --> Config Class Initialized
INFO - 2017-01-26 23:24:08 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:24:08 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:24:08 --> Utf8 Class Initialized
INFO - 2017-01-26 23:24:08 --> URI Class Initialized
INFO - 2017-01-26 23:24:08 --> Router Class Initialized
INFO - 2017-01-26 23:24:08 --> Output Class Initialized
INFO - 2017-01-26 23:24:08 --> Security Class Initialized
DEBUG - 2017-01-26 23:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:24:08 --> Input Class Initialized
INFO - 2017-01-26 23:24:08 --> Language Class Initialized
INFO - 2017-01-26 23:24:08 --> Loader Class Initialized
INFO - 2017-01-26 23:24:08 --> Database Driver Class Initialized
INFO - 2017-01-26 23:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:24:08 --> Controller Class Initialized
INFO - 2017-01-26 23:24:08 --> Helper loaded: date_helper
DEBUG - 2017-01-26 23:24:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:24:08 --> Helper loaded: url_helper
INFO - 2017-01-26 23:24:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:24:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-26 23:24:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-26 23:24:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-26 23:24:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:24:08 --> Final output sent to browser
DEBUG - 2017-01-26 23:24:08 --> Total execution time: 0.0136
INFO - 2017-01-26 23:24:18 --> Config Class Initialized
INFO - 2017-01-26 23:24:18 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:24:18 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:24:18 --> Utf8 Class Initialized
INFO - 2017-01-26 23:24:18 --> URI Class Initialized
DEBUG - 2017-01-26 23:24:18 --> No URI present. Default controller set.
INFO - 2017-01-26 23:24:18 --> Router Class Initialized
INFO - 2017-01-26 23:24:18 --> Output Class Initialized
INFO - 2017-01-26 23:24:18 --> Security Class Initialized
DEBUG - 2017-01-26 23:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:24:18 --> Input Class Initialized
INFO - 2017-01-26 23:24:18 --> Language Class Initialized
INFO - 2017-01-26 23:24:18 --> Loader Class Initialized
INFO - 2017-01-26 23:24:18 --> Database Driver Class Initialized
INFO - 2017-01-26 23:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:24:18 --> Controller Class Initialized
INFO - 2017-01-26 23:24:18 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:24:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:24:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:24:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:24:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:24:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:24:18 --> Final output sent to browser
DEBUG - 2017-01-26 23:24:18 --> Total execution time: 0.0439
INFO - 2017-01-26 23:24:19 --> Config Class Initialized
INFO - 2017-01-26 23:24:19 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:24:19 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:24:19 --> Utf8 Class Initialized
INFO - 2017-01-26 23:24:19 --> URI Class Initialized
INFO - 2017-01-26 23:24:19 --> Router Class Initialized
INFO - 2017-01-26 23:24:19 --> Output Class Initialized
INFO - 2017-01-26 23:24:19 --> Security Class Initialized
DEBUG - 2017-01-26 23:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:24:19 --> Input Class Initialized
INFO - 2017-01-26 23:24:19 --> Language Class Initialized
INFO - 2017-01-26 23:24:19 --> Loader Class Initialized
INFO - 2017-01-26 23:24:19 --> Database Driver Class Initialized
INFO - 2017-01-26 23:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:24:19 --> Controller Class Initialized
INFO - 2017-01-26 23:24:19 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:24:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:24:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:24:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:24:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:24:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:24:19 --> Final output sent to browser
DEBUG - 2017-01-26 23:24:19 --> Total execution time: 0.0405
INFO - 2017-01-26 23:24:26 --> Config Class Initialized
INFO - 2017-01-26 23:24:26 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:24:26 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:24:26 --> Utf8 Class Initialized
INFO - 2017-01-26 23:24:26 --> URI Class Initialized
INFO - 2017-01-26 23:24:26 --> Router Class Initialized
INFO - 2017-01-26 23:24:26 --> Output Class Initialized
INFO - 2017-01-26 23:24:26 --> Security Class Initialized
DEBUG - 2017-01-26 23:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:24:26 --> Input Class Initialized
INFO - 2017-01-26 23:24:26 --> Language Class Initialized
INFO - 2017-01-26 23:24:26 --> Loader Class Initialized
INFO - 2017-01-26 23:24:26 --> Database Driver Class Initialized
INFO - 2017-01-26 23:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:24:26 --> Controller Class Initialized
INFO - 2017-01-26 23:24:26 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:24:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:24:27 --> Config Class Initialized
INFO - 2017-01-26 23:24:27 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:24:27 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:24:27 --> Utf8 Class Initialized
INFO - 2017-01-26 23:24:27 --> URI Class Initialized
INFO - 2017-01-26 23:24:27 --> Router Class Initialized
INFO - 2017-01-26 23:24:27 --> Output Class Initialized
INFO - 2017-01-26 23:24:27 --> Security Class Initialized
DEBUG - 2017-01-26 23:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:24:27 --> Input Class Initialized
INFO - 2017-01-26 23:24:27 --> Language Class Initialized
INFO - 2017-01-26 23:24:27 --> Loader Class Initialized
INFO - 2017-01-26 23:24:27 --> Database Driver Class Initialized
INFO - 2017-01-26 23:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:24:27 --> Controller Class Initialized
INFO - 2017-01-26 23:24:27 --> Helper loaded: date_helper
DEBUG - 2017-01-26 23:24:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:24:27 --> Helper loaded: url_helper
INFO - 2017-01-26 23:24:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:24:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-26 23:24:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-26 23:24:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-26 23:24:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:24:27 --> Final output sent to browser
DEBUG - 2017-01-26 23:24:27 --> Total execution time: 0.0408
INFO - 2017-01-26 23:24:27 --> Config Class Initialized
INFO - 2017-01-26 23:24:27 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:24:27 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:24:27 --> Utf8 Class Initialized
INFO - 2017-01-26 23:24:27 --> URI Class Initialized
INFO - 2017-01-26 23:24:27 --> Router Class Initialized
INFO - 2017-01-26 23:24:27 --> Output Class Initialized
INFO - 2017-01-26 23:24:27 --> Security Class Initialized
DEBUG - 2017-01-26 23:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:24:27 --> Input Class Initialized
INFO - 2017-01-26 23:24:27 --> Language Class Initialized
INFO - 2017-01-26 23:24:27 --> Loader Class Initialized
INFO - 2017-01-26 23:24:27 --> Database Driver Class Initialized
INFO - 2017-01-26 23:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:24:27 --> Controller Class Initialized
INFO - 2017-01-26 23:24:27 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:24:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:24:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:24:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:24:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:24:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:24:27 --> Final output sent to browser
DEBUG - 2017-01-26 23:24:27 --> Total execution time: 0.0145
INFO - 2017-01-26 23:24:29 --> Config Class Initialized
INFO - 2017-01-26 23:24:29 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:24:29 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:24:29 --> Utf8 Class Initialized
INFO - 2017-01-26 23:24:29 --> URI Class Initialized
INFO - 2017-01-26 23:24:29 --> Router Class Initialized
INFO - 2017-01-26 23:24:29 --> Output Class Initialized
INFO - 2017-01-26 23:24:29 --> Security Class Initialized
DEBUG - 2017-01-26 23:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:24:29 --> Input Class Initialized
INFO - 2017-01-26 23:24:29 --> Language Class Initialized
INFO - 2017-01-26 23:24:29 --> Loader Class Initialized
INFO - 2017-01-26 23:24:29 --> Database Driver Class Initialized
INFO - 2017-01-26 23:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:24:29 --> Controller Class Initialized
INFO - 2017-01-26 23:24:29 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:24:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:24:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:24:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:24:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:24:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:24:29 --> Final output sent to browser
DEBUG - 2017-01-26 23:24:29 --> Total execution time: 0.0131
INFO - 2017-01-26 23:25:47 --> Config Class Initialized
INFO - 2017-01-26 23:25:47 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:25:47 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:25:47 --> Utf8 Class Initialized
INFO - 2017-01-26 23:25:47 --> URI Class Initialized
DEBUG - 2017-01-26 23:25:47 --> No URI present. Default controller set.
INFO - 2017-01-26 23:25:47 --> Router Class Initialized
INFO - 2017-01-26 23:25:47 --> Output Class Initialized
INFO - 2017-01-26 23:25:47 --> Security Class Initialized
DEBUG - 2017-01-26 23:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:25:47 --> Input Class Initialized
INFO - 2017-01-26 23:25:47 --> Language Class Initialized
INFO - 2017-01-26 23:25:47 --> Loader Class Initialized
INFO - 2017-01-26 23:25:47 --> Database Driver Class Initialized
INFO - 2017-01-26 23:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:25:47 --> Controller Class Initialized
INFO - 2017-01-26 23:25:47 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:25:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:25:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:25:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:25:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:25:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:25:47 --> Final output sent to browser
DEBUG - 2017-01-26 23:25:47 --> Total execution time: 0.0145
INFO - 2017-01-26 23:25:52 --> Config Class Initialized
INFO - 2017-01-26 23:25:52 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:25:52 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:25:52 --> Utf8 Class Initialized
INFO - 2017-01-26 23:25:52 --> URI Class Initialized
INFO - 2017-01-26 23:25:52 --> Router Class Initialized
INFO - 2017-01-26 23:25:52 --> Output Class Initialized
INFO - 2017-01-26 23:25:52 --> Security Class Initialized
DEBUG - 2017-01-26 23:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:25:52 --> Input Class Initialized
INFO - 2017-01-26 23:25:52 --> Language Class Initialized
INFO - 2017-01-26 23:25:52 --> Loader Class Initialized
INFO - 2017-01-26 23:25:52 --> Database Driver Class Initialized
INFO - 2017-01-26 23:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:25:52 --> Controller Class Initialized
INFO - 2017-01-26 23:25:52 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:25:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:25:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:25:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:25:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:25:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:25:52 --> Final output sent to browser
DEBUG - 2017-01-26 23:25:52 --> Total execution time: 0.0331
INFO - 2017-01-26 23:26:45 --> Config Class Initialized
INFO - 2017-01-26 23:26:45 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:26:45 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:26:45 --> Utf8 Class Initialized
INFO - 2017-01-26 23:26:45 --> URI Class Initialized
INFO - 2017-01-26 23:26:45 --> Router Class Initialized
INFO - 2017-01-26 23:26:45 --> Output Class Initialized
INFO - 2017-01-26 23:26:45 --> Security Class Initialized
DEBUG - 2017-01-26 23:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:26:45 --> Input Class Initialized
INFO - 2017-01-26 23:26:45 --> Language Class Initialized
INFO - 2017-01-26 23:26:45 --> Loader Class Initialized
INFO - 2017-01-26 23:26:45 --> Database Driver Class Initialized
INFO - 2017-01-26 23:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:26:45 --> Controller Class Initialized
INFO - 2017-01-26 23:26:45 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:26:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:26:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-26 23:26:45 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-26 23:26:45 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-26 23:26:45 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-26 23:26:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:26:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:26:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:26:45 --> Final output sent to browser
DEBUG - 2017-01-26 23:26:45 --> Total execution time: 0.0144
INFO - 2017-01-26 23:26:48 --> Config Class Initialized
INFO - 2017-01-26 23:26:48 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:26:48 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:26:48 --> Utf8 Class Initialized
INFO - 2017-01-26 23:26:48 --> URI Class Initialized
INFO - 2017-01-26 23:26:48 --> Router Class Initialized
INFO - 2017-01-26 23:26:48 --> Output Class Initialized
INFO - 2017-01-26 23:26:48 --> Security Class Initialized
DEBUG - 2017-01-26 23:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:26:48 --> Input Class Initialized
INFO - 2017-01-26 23:26:48 --> Language Class Initialized
INFO - 2017-01-26 23:26:48 --> Loader Class Initialized
INFO - 2017-01-26 23:26:48 --> Database Driver Class Initialized
INFO - 2017-01-26 23:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:26:48 --> Controller Class Initialized
INFO - 2017-01-26 23:26:48 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:26:48 --> Final output sent to browser
DEBUG - 2017-01-26 23:26:48 --> Total execution time: 0.0135
INFO - 2017-01-26 23:29:42 --> Config Class Initialized
INFO - 2017-01-26 23:29:42 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:29:42 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:29:42 --> Utf8 Class Initialized
INFO - 2017-01-26 23:29:42 --> URI Class Initialized
DEBUG - 2017-01-26 23:29:42 --> No URI present. Default controller set.
INFO - 2017-01-26 23:29:42 --> Router Class Initialized
INFO - 2017-01-26 23:29:42 --> Output Class Initialized
INFO - 2017-01-26 23:29:42 --> Security Class Initialized
DEBUG - 2017-01-26 23:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:29:42 --> Input Class Initialized
INFO - 2017-01-26 23:29:42 --> Language Class Initialized
INFO - 2017-01-26 23:29:42 --> Loader Class Initialized
INFO - 2017-01-26 23:29:42 --> Database Driver Class Initialized
INFO - 2017-01-26 23:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:29:42 --> Controller Class Initialized
INFO - 2017-01-26 23:29:42 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:29:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:29:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:29:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:29:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:29:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:29:42 --> Final output sent to browser
DEBUG - 2017-01-26 23:29:42 --> Total execution time: 0.0640
INFO - 2017-01-26 23:29:53 --> Config Class Initialized
INFO - 2017-01-26 23:29:53 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:29:53 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:29:53 --> Utf8 Class Initialized
INFO - 2017-01-26 23:29:53 --> URI Class Initialized
INFO - 2017-01-26 23:29:53 --> Router Class Initialized
INFO - 2017-01-26 23:29:53 --> Output Class Initialized
INFO - 2017-01-26 23:29:53 --> Security Class Initialized
DEBUG - 2017-01-26 23:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:29:53 --> Input Class Initialized
INFO - 2017-01-26 23:29:53 --> Language Class Initialized
INFO - 2017-01-26 23:29:53 --> Loader Class Initialized
INFO - 2017-01-26 23:29:53 --> Database Driver Class Initialized
INFO - 2017-01-26 23:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:29:53 --> Controller Class Initialized
INFO - 2017-01-26 23:29:53 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:29:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:29:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:29:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:29:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:29:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:29:53 --> Final output sent to browser
DEBUG - 2017-01-26 23:29:53 --> Total execution time: 0.0545
INFO - 2017-01-26 23:32:01 --> Config Class Initialized
INFO - 2017-01-26 23:32:01 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:32:01 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:32:01 --> Utf8 Class Initialized
INFO - 2017-01-26 23:32:01 --> URI Class Initialized
DEBUG - 2017-01-26 23:32:01 --> No URI present. Default controller set.
INFO - 2017-01-26 23:32:01 --> Router Class Initialized
INFO - 2017-01-26 23:32:01 --> Output Class Initialized
INFO - 2017-01-26 23:32:01 --> Security Class Initialized
DEBUG - 2017-01-26 23:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:32:01 --> Input Class Initialized
INFO - 2017-01-26 23:32:01 --> Language Class Initialized
INFO - 2017-01-26 23:32:01 --> Loader Class Initialized
INFO - 2017-01-26 23:32:01 --> Database Driver Class Initialized
INFO - 2017-01-26 23:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:32:01 --> Controller Class Initialized
INFO - 2017-01-26 23:32:01 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:32:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:32:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:32:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:32:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:32:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:32:01 --> Final output sent to browser
DEBUG - 2017-01-26 23:32:01 --> Total execution time: 0.0303
INFO - 2017-01-26 23:32:07 --> Config Class Initialized
INFO - 2017-01-26 23:32:07 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:32:07 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:32:07 --> Utf8 Class Initialized
INFO - 2017-01-26 23:32:07 --> URI Class Initialized
INFO - 2017-01-26 23:32:07 --> Router Class Initialized
INFO - 2017-01-26 23:32:07 --> Output Class Initialized
INFO - 2017-01-26 23:32:07 --> Security Class Initialized
DEBUG - 2017-01-26 23:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:32:07 --> Input Class Initialized
INFO - 2017-01-26 23:32:07 --> Language Class Initialized
INFO - 2017-01-26 23:32:07 --> Loader Class Initialized
INFO - 2017-01-26 23:32:07 --> Database Driver Class Initialized
INFO - 2017-01-26 23:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:32:07 --> Controller Class Initialized
INFO - 2017-01-26 23:32:07 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:32:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:32:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-26 23:32:07 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-26 23:32:07 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-26 23:32:07 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-26 23:32:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:32:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:32:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:32:07 --> Final output sent to browser
DEBUG - 2017-01-26 23:32:07 --> Total execution time: 0.0205
INFO - 2017-01-26 23:32:12 --> Config Class Initialized
INFO - 2017-01-26 23:32:12 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:32:12 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:32:12 --> Utf8 Class Initialized
INFO - 2017-01-26 23:32:12 --> URI Class Initialized
INFO - 2017-01-26 23:32:12 --> Router Class Initialized
INFO - 2017-01-26 23:32:12 --> Output Class Initialized
INFO - 2017-01-26 23:32:12 --> Security Class Initialized
DEBUG - 2017-01-26 23:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:32:12 --> Input Class Initialized
INFO - 2017-01-26 23:32:12 --> Language Class Initialized
INFO - 2017-01-26 23:32:12 --> Loader Class Initialized
INFO - 2017-01-26 23:32:12 --> Database Driver Class Initialized
INFO - 2017-01-26 23:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:32:12 --> Controller Class Initialized
INFO - 2017-01-26 23:32:12 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:32:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:32:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:32:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:32:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:32:12 --> Final output sent to browser
DEBUG - 2017-01-26 23:32:12 --> Total execution time: 0.0142
INFO - 2017-01-26 23:32:42 --> Config Class Initialized
INFO - 2017-01-26 23:32:42 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:32:42 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:32:42 --> Utf8 Class Initialized
INFO - 2017-01-26 23:32:42 --> URI Class Initialized
DEBUG - 2017-01-26 23:32:42 --> No URI present. Default controller set.
INFO - 2017-01-26 23:32:42 --> Router Class Initialized
INFO - 2017-01-26 23:32:42 --> Output Class Initialized
INFO - 2017-01-26 23:32:42 --> Security Class Initialized
DEBUG - 2017-01-26 23:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:32:42 --> Input Class Initialized
INFO - 2017-01-26 23:32:42 --> Language Class Initialized
INFO - 2017-01-26 23:32:42 --> Loader Class Initialized
INFO - 2017-01-26 23:32:42 --> Database Driver Class Initialized
INFO - 2017-01-26 23:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:32:42 --> Controller Class Initialized
INFO - 2017-01-26 23:32:42 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:32:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:32:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:32:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:32:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:32:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:32:42 --> Final output sent to browser
DEBUG - 2017-01-26 23:32:42 --> Total execution time: 0.0152
INFO - 2017-01-26 23:32:46 --> Config Class Initialized
INFO - 2017-01-26 23:32:46 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:32:46 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:32:46 --> Utf8 Class Initialized
INFO - 2017-01-26 23:32:46 --> URI Class Initialized
INFO - 2017-01-26 23:32:46 --> Router Class Initialized
INFO - 2017-01-26 23:32:46 --> Output Class Initialized
INFO - 2017-01-26 23:32:46 --> Security Class Initialized
DEBUG - 2017-01-26 23:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:32:46 --> Input Class Initialized
INFO - 2017-01-26 23:32:46 --> Language Class Initialized
INFO - 2017-01-26 23:32:46 --> Loader Class Initialized
INFO - 2017-01-26 23:32:46 --> Database Driver Class Initialized
INFO - 2017-01-26 23:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:32:46 --> Controller Class Initialized
INFO - 2017-01-26 23:32:46 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:32:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:32:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:32:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:32:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:32:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:32:46 --> Final output sent to browser
DEBUG - 2017-01-26 23:32:46 --> Total execution time: 0.0135
INFO - 2017-01-26 23:32:59 --> Config Class Initialized
INFO - 2017-01-26 23:32:59 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:32:59 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:32:59 --> Utf8 Class Initialized
INFO - 2017-01-26 23:32:59 --> URI Class Initialized
INFO - 2017-01-26 23:32:59 --> Router Class Initialized
INFO - 2017-01-26 23:32:59 --> Output Class Initialized
INFO - 2017-01-26 23:32:59 --> Security Class Initialized
DEBUG - 2017-01-26 23:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:32:59 --> Input Class Initialized
INFO - 2017-01-26 23:32:59 --> Language Class Initialized
INFO - 2017-01-26 23:32:59 --> Loader Class Initialized
INFO - 2017-01-26 23:32:59 --> Database Driver Class Initialized
INFO - 2017-01-26 23:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:32:59 --> Controller Class Initialized
INFO - 2017-01-26 23:32:59 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:32:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:33:00 --> Config Class Initialized
INFO - 2017-01-26 23:33:00 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:33:00 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:33:00 --> Utf8 Class Initialized
INFO - 2017-01-26 23:33:00 --> URI Class Initialized
INFO - 2017-01-26 23:33:00 --> Router Class Initialized
INFO - 2017-01-26 23:33:00 --> Output Class Initialized
INFO - 2017-01-26 23:33:00 --> Security Class Initialized
DEBUG - 2017-01-26 23:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:33:00 --> Input Class Initialized
INFO - 2017-01-26 23:33:00 --> Language Class Initialized
INFO - 2017-01-26 23:33:00 --> Loader Class Initialized
INFO - 2017-01-26 23:33:00 --> Database Driver Class Initialized
INFO - 2017-01-26 23:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:33:00 --> Controller Class Initialized
INFO - 2017-01-26 23:33:00 --> Helper loaded: date_helper
DEBUG - 2017-01-26 23:33:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:33:00 --> Helper loaded: url_helper
INFO - 2017-01-26 23:33:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:33:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-26 23:33:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-26 23:33:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-26 23:33:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:33:00 --> Final output sent to browser
DEBUG - 2017-01-26 23:33:00 --> Total execution time: 0.0502
INFO - 2017-01-26 23:33:03 --> Config Class Initialized
INFO - 2017-01-26 23:33:03 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:33:03 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:33:03 --> Utf8 Class Initialized
INFO - 2017-01-26 23:33:03 --> URI Class Initialized
INFO - 2017-01-26 23:33:03 --> Router Class Initialized
INFO - 2017-01-26 23:33:03 --> Output Class Initialized
INFO - 2017-01-26 23:33:03 --> Security Class Initialized
DEBUG - 2017-01-26 23:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:33:03 --> Input Class Initialized
INFO - 2017-01-26 23:33:03 --> Language Class Initialized
INFO - 2017-01-26 23:33:03 --> Loader Class Initialized
INFO - 2017-01-26 23:33:03 --> Database Driver Class Initialized
INFO - 2017-01-26 23:33:03 --> Config Class Initialized
INFO - 2017-01-26 23:33:03 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:33:03 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:33:03 --> Utf8 Class Initialized
INFO - 2017-01-26 23:33:03 --> URI Class Initialized
INFO - 2017-01-26 23:33:03 --> Router Class Initialized
INFO - 2017-01-26 23:33:03 --> Output Class Initialized
INFO - 2017-01-26 23:33:03 --> Security Class Initialized
DEBUG - 2017-01-26 23:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:33:03 --> Input Class Initialized
INFO - 2017-01-26 23:33:03 --> Language Class Initialized
INFO - 2017-01-26 23:33:03 --> Loader Class Initialized
INFO - 2017-01-26 23:33:03 --> Database Driver Class Initialized
INFO - 2017-01-26 23:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:33:03 --> Controller Class Initialized
INFO - 2017-01-26 23:33:03 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:33:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:33:03 --> Controller Class Initialized
INFO - 2017-01-26 23:33:03 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:33:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:33:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:33:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:33:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:33:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:33:03 --> Final output sent to browser
DEBUG - 2017-01-26 23:33:03 --> Total execution time: 0.0182
INFO - 2017-01-26 23:33:04 --> Config Class Initialized
INFO - 2017-01-26 23:33:04 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:33:04 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:33:04 --> Utf8 Class Initialized
INFO - 2017-01-26 23:33:04 --> URI Class Initialized
INFO - 2017-01-26 23:33:04 --> Router Class Initialized
INFO - 2017-01-26 23:33:04 --> Output Class Initialized
INFO - 2017-01-26 23:33:04 --> Security Class Initialized
DEBUG - 2017-01-26 23:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:33:04 --> Input Class Initialized
INFO - 2017-01-26 23:33:04 --> Language Class Initialized
INFO - 2017-01-26 23:33:04 --> Loader Class Initialized
INFO - 2017-01-26 23:33:04 --> Database Driver Class Initialized
INFO - 2017-01-26 23:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:33:04 --> Controller Class Initialized
INFO - 2017-01-26 23:33:04 --> Helper loaded: date_helper
DEBUG - 2017-01-26 23:33:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:33:04 --> Helper loaded: url_helper
INFO - 2017-01-26 23:33:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:33:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-26 23:33:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-26 23:33:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-26 23:33:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:33:04 --> Final output sent to browser
DEBUG - 2017-01-26 23:33:04 --> Total execution time: 0.0140
INFO - 2017-01-26 23:33:05 --> Config Class Initialized
INFO - 2017-01-26 23:33:05 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:33:05 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:33:05 --> Utf8 Class Initialized
INFO - 2017-01-26 23:33:05 --> URI Class Initialized
INFO - 2017-01-26 23:33:05 --> Router Class Initialized
INFO - 2017-01-26 23:33:05 --> Output Class Initialized
INFO - 2017-01-26 23:33:05 --> Security Class Initialized
DEBUG - 2017-01-26 23:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:33:05 --> Input Class Initialized
INFO - 2017-01-26 23:33:05 --> Language Class Initialized
INFO - 2017-01-26 23:33:05 --> Loader Class Initialized
INFO - 2017-01-26 23:33:05 --> Database Driver Class Initialized
INFO - 2017-01-26 23:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:33:05 --> Controller Class Initialized
INFO - 2017-01-26 23:33:05 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:33:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:33:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:33:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:33:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:33:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:33:05 --> Final output sent to browser
DEBUG - 2017-01-26 23:33:05 --> Total execution time: 0.0139
INFO - 2017-01-26 23:33:08 --> Config Class Initialized
INFO - 2017-01-26 23:33:08 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:33:08 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:33:08 --> Utf8 Class Initialized
INFO - 2017-01-26 23:33:08 --> URI Class Initialized
INFO - 2017-01-26 23:33:08 --> Router Class Initialized
INFO - 2017-01-26 23:33:08 --> Output Class Initialized
INFO - 2017-01-26 23:33:08 --> Security Class Initialized
DEBUG - 2017-01-26 23:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:33:08 --> Input Class Initialized
INFO - 2017-01-26 23:33:08 --> Language Class Initialized
INFO - 2017-01-26 23:33:08 --> Loader Class Initialized
INFO - 2017-01-26 23:33:08 --> Database Driver Class Initialized
INFO - 2017-01-26 23:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:33:08 --> Controller Class Initialized
INFO - 2017-01-26 23:33:08 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:33:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:33:08 --> Config Class Initialized
INFO - 2017-01-26 23:33:08 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:33:08 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:33:08 --> Utf8 Class Initialized
INFO - 2017-01-26 23:33:08 --> URI Class Initialized
INFO - 2017-01-26 23:33:08 --> Router Class Initialized
INFO - 2017-01-26 23:33:08 --> Output Class Initialized
INFO - 2017-01-26 23:33:08 --> Security Class Initialized
DEBUG - 2017-01-26 23:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:33:08 --> Input Class Initialized
INFO - 2017-01-26 23:33:08 --> Language Class Initialized
INFO - 2017-01-26 23:33:08 --> Loader Class Initialized
INFO - 2017-01-26 23:33:08 --> Database Driver Class Initialized
INFO - 2017-01-26 23:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:33:08 --> Controller Class Initialized
INFO - 2017-01-26 23:33:08 --> Helper loaded: date_helper
DEBUG - 2017-01-26 23:33:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:33:08 --> Helper loaded: url_helper
INFO - 2017-01-26 23:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-26 23:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-26 23:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-26 23:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:33:08 --> Final output sent to browser
DEBUG - 2017-01-26 23:33:08 --> Total execution time: 0.0138
INFO - 2017-01-26 23:33:09 --> Config Class Initialized
INFO - 2017-01-26 23:33:09 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:33:09 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:33:09 --> Utf8 Class Initialized
INFO - 2017-01-26 23:33:09 --> URI Class Initialized
INFO - 2017-01-26 23:33:09 --> Router Class Initialized
INFO - 2017-01-26 23:33:09 --> Output Class Initialized
INFO - 2017-01-26 23:33:09 --> Security Class Initialized
DEBUG - 2017-01-26 23:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:33:09 --> Input Class Initialized
INFO - 2017-01-26 23:33:09 --> Language Class Initialized
INFO - 2017-01-26 23:33:09 --> Loader Class Initialized
INFO - 2017-01-26 23:33:09 --> Database Driver Class Initialized
INFO - 2017-01-26 23:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:33:09 --> Controller Class Initialized
INFO - 2017-01-26 23:33:09 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:33:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:33:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:33:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:33:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:33:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:33:09 --> Final output sent to browser
DEBUG - 2017-01-26 23:33:09 --> Total execution time: 0.0139
INFO - 2017-01-26 23:33:12 --> Config Class Initialized
INFO - 2017-01-26 23:33:12 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:33:12 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:33:12 --> Utf8 Class Initialized
INFO - 2017-01-26 23:33:12 --> URI Class Initialized
INFO - 2017-01-26 23:33:12 --> Router Class Initialized
INFO - 2017-01-26 23:33:12 --> Output Class Initialized
INFO - 2017-01-26 23:33:12 --> Security Class Initialized
DEBUG - 2017-01-26 23:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:33:12 --> Input Class Initialized
INFO - 2017-01-26 23:33:12 --> Language Class Initialized
INFO - 2017-01-26 23:33:12 --> Loader Class Initialized
INFO - 2017-01-26 23:33:12 --> Database Driver Class Initialized
INFO - 2017-01-26 23:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:33:12 --> Controller Class Initialized
INFO - 2017-01-26 23:33:12 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:33:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:33:12 --> Config Class Initialized
INFO - 2017-01-26 23:33:12 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:33:12 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:33:12 --> Utf8 Class Initialized
INFO - 2017-01-26 23:33:12 --> URI Class Initialized
INFO - 2017-01-26 23:33:12 --> Router Class Initialized
INFO - 2017-01-26 23:33:12 --> Output Class Initialized
INFO - 2017-01-26 23:33:12 --> Security Class Initialized
DEBUG - 2017-01-26 23:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:33:12 --> Input Class Initialized
INFO - 2017-01-26 23:33:12 --> Language Class Initialized
INFO - 2017-01-26 23:33:12 --> Loader Class Initialized
INFO - 2017-01-26 23:33:12 --> Database Driver Class Initialized
INFO - 2017-01-26 23:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:33:12 --> Controller Class Initialized
INFO - 2017-01-26 23:33:12 --> Helper loaded: date_helper
DEBUG - 2017-01-26 23:33:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:33:12 --> Helper loaded: url_helper
INFO - 2017-01-26 23:33:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:33:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-26 23:33:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-26 23:33:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-26 23:33:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:33:12 --> Final output sent to browser
DEBUG - 2017-01-26 23:33:12 --> Total execution time: 0.0134
INFO - 2017-01-26 23:33:14 --> Config Class Initialized
INFO - 2017-01-26 23:33:14 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:33:14 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:33:14 --> Utf8 Class Initialized
INFO - 2017-01-26 23:33:14 --> URI Class Initialized
INFO - 2017-01-26 23:33:14 --> Router Class Initialized
INFO - 2017-01-26 23:33:14 --> Output Class Initialized
INFO - 2017-01-26 23:33:14 --> Security Class Initialized
DEBUG - 2017-01-26 23:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:33:14 --> Input Class Initialized
INFO - 2017-01-26 23:33:14 --> Language Class Initialized
INFO - 2017-01-26 23:33:14 --> Loader Class Initialized
INFO - 2017-01-26 23:33:14 --> Database Driver Class Initialized
INFO - 2017-01-26 23:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:33:14 --> Controller Class Initialized
INFO - 2017-01-26 23:33:14 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:33:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:33:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:33:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:33:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:33:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:33:14 --> Final output sent to browser
DEBUG - 2017-01-26 23:33:14 --> Total execution time: 0.0144
INFO - 2017-01-26 23:33:22 --> Config Class Initialized
INFO - 2017-01-26 23:33:22 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:33:22 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:33:22 --> Utf8 Class Initialized
INFO - 2017-01-26 23:33:22 --> URI Class Initialized
DEBUG - 2017-01-26 23:33:22 --> No URI present. Default controller set.
INFO - 2017-01-26 23:33:22 --> Router Class Initialized
INFO - 2017-01-26 23:33:22 --> Output Class Initialized
INFO - 2017-01-26 23:33:22 --> Security Class Initialized
DEBUG - 2017-01-26 23:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:33:22 --> Input Class Initialized
INFO - 2017-01-26 23:33:22 --> Language Class Initialized
INFO - 2017-01-26 23:33:22 --> Loader Class Initialized
INFO - 2017-01-26 23:33:22 --> Database Driver Class Initialized
INFO - 2017-01-26 23:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:33:22 --> Controller Class Initialized
INFO - 2017-01-26 23:33:22 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:33:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:33:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:33:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:33:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:33:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:33:22 --> Final output sent to browser
DEBUG - 2017-01-26 23:33:22 --> Total execution time: 0.0134
INFO - 2017-01-26 23:33:22 --> Config Class Initialized
INFO - 2017-01-26 23:33:22 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:33:22 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:33:22 --> Utf8 Class Initialized
INFO - 2017-01-26 23:33:22 --> URI Class Initialized
INFO - 2017-01-26 23:33:22 --> Router Class Initialized
INFO - 2017-01-26 23:33:22 --> Output Class Initialized
INFO - 2017-01-26 23:33:22 --> Security Class Initialized
DEBUG - 2017-01-26 23:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:33:22 --> Input Class Initialized
INFO - 2017-01-26 23:33:22 --> Language Class Initialized
INFO - 2017-01-26 23:33:22 --> Loader Class Initialized
INFO - 2017-01-26 23:33:22 --> Database Driver Class Initialized
INFO - 2017-01-26 23:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:33:22 --> Controller Class Initialized
INFO - 2017-01-26 23:33:22 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:33:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:33:23 --> Config Class Initialized
INFO - 2017-01-26 23:33:23 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:33:23 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:33:23 --> Utf8 Class Initialized
INFO - 2017-01-26 23:33:23 --> URI Class Initialized
DEBUG - 2017-01-26 23:33:23 --> No URI present. Default controller set.
INFO - 2017-01-26 23:33:23 --> Router Class Initialized
INFO - 2017-01-26 23:33:23 --> Output Class Initialized
INFO - 2017-01-26 23:33:23 --> Security Class Initialized
DEBUG - 2017-01-26 23:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:33:23 --> Input Class Initialized
INFO - 2017-01-26 23:33:23 --> Language Class Initialized
INFO - 2017-01-26 23:33:23 --> Loader Class Initialized
INFO - 2017-01-26 23:33:23 --> Database Driver Class Initialized
INFO - 2017-01-26 23:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:33:23 --> Controller Class Initialized
INFO - 2017-01-26 23:33:23 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:33:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:33:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:33:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:33:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:33:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:33:23 --> Final output sent to browser
DEBUG - 2017-01-26 23:33:23 --> Total execution time: 0.0862
INFO - 2017-01-26 23:33:25 --> Config Class Initialized
INFO - 2017-01-26 23:33:25 --> Hooks Class Initialized
DEBUG - 2017-01-26 23:33:25 --> UTF-8 Support Enabled
INFO - 2017-01-26 23:33:25 --> Utf8 Class Initialized
INFO - 2017-01-26 23:33:25 --> URI Class Initialized
INFO - 2017-01-26 23:33:25 --> Router Class Initialized
INFO - 2017-01-26 23:33:25 --> Output Class Initialized
INFO - 2017-01-26 23:33:25 --> Security Class Initialized
DEBUG - 2017-01-26 23:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-26 23:33:25 --> Input Class Initialized
INFO - 2017-01-26 23:33:25 --> Language Class Initialized
INFO - 2017-01-26 23:33:25 --> Loader Class Initialized
INFO - 2017-01-26 23:33:25 --> Database Driver Class Initialized
INFO - 2017-01-26 23:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-26 23:33:25 --> Controller Class Initialized
INFO - 2017-01-26 23:33:25 --> Helper loaded: url_helper
DEBUG - 2017-01-26 23:33:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-26 23:33:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-26 23:33:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-26 23:33:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-26 23:33:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-26 23:33:25 --> Final output sent to browser
DEBUG - 2017-01-26 23:33:25 --> Total execution time: 0.0156

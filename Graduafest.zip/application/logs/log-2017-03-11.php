<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-11 00:12:14 --> Config Class Initialized
INFO - 2017-03-11 00:12:15 --> Hooks Class Initialized
DEBUG - 2017-03-11 00:12:15 --> UTF-8 Support Enabled
INFO - 2017-03-11 00:12:15 --> Utf8 Class Initialized
INFO - 2017-03-11 00:12:15 --> URI Class Initialized
INFO - 2017-03-11 00:12:15 --> Router Class Initialized
INFO - 2017-03-11 00:12:15 --> Output Class Initialized
INFO - 2017-03-11 00:12:15 --> Security Class Initialized
DEBUG - 2017-03-11 00:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 00:12:15 --> Input Class Initialized
INFO - 2017-03-11 00:12:15 --> Language Class Initialized
INFO - 2017-03-11 00:12:15 --> Loader Class Initialized
INFO - 2017-03-11 00:12:15 --> Database Driver Class Initialized
INFO - 2017-03-11 00:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 00:12:16 --> Controller Class Initialized
INFO - 2017-03-11 00:12:16 --> Helper loaded: url_helper
DEBUG - 2017-03-11 00:12:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 00:12:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 00:12:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 00:12:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 00:12:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 00:12:16 --> Final output sent to browser
DEBUG - 2017-03-11 00:12:16 --> Total execution time: 2.2623
INFO - 2017-03-11 00:13:14 --> Config Class Initialized
INFO - 2017-03-11 00:13:14 --> Hooks Class Initialized
DEBUG - 2017-03-11 00:13:15 --> UTF-8 Support Enabled
INFO - 2017-03-11 00:13:15 --> Utf8 Class Initialized
INFO - 2017-03-11 00:13:15 --> URI Class Initialized
DEBUG - 2017-03-11 00:13:15 --> No URI present. Default controller set.
INFO - 2017-03-11 00:13:15 --> Router Class Initialized
INFO - 2017-03-11 00:13:15 --> Output Class Initialized
INFO - 2017-03-11 00:13:15 --> Security Class Initialized
DEBUG - 2017-03-11 00:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 00:13:15 --> Input Class Initialized
INFO - 2017-03-11 00:13:15 --> Language Class Initialized
INFO - 2017-03-11 00:13:15 --> Loader Class Initialized
INFO - 2017-03-11 00:13:15 --> Database Driver Class Initialized
INFO - 2017-03-11 00:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 00:13:15 --> Controller Class Initialized
INFO - 2017-03-11 00:13:15 --> Helper loaded: url_helper
DEBUG - 2017-03-11 00:13:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 00:13:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 00:13:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 00:13:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 00:13:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 00:13:16 --> Final output sent to browser
DEBUG - 2017-03-11 00:13:16 --> Total execution time: 1.4667
INFO - 2017-03-11 00:51:41 --> Config Class Initialized
INFO - 2017-03-11 00:51:41 --> Hooks Class Initialized
DEBUG - 2017-03-11 00:51:41 --> UTF-8 Support Enabled
INFO - 2017-03-11 00:51:41 --> Utf8 Class Initialized
INFO - 2017-03-11 00:51:41 --> URI Class Initialized
DEBUG - 2017-03-11 00:51:41 --> No URI present. Default controller set.
INFO - 2017-03-11 00:51:41 --> Router Class Initialized
INFO - 2017-03-11 00:51:41 --> Output Class Initialized
INFO - 2017-03-11 00:51:41 --> Security Class Initialized
DEBUG - 2017-03-11 00:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 00:51:41 --> Input Class Initialized
INFO - 2017-03-11 00:51:41 --> Language Class Initialized
INFO - 2017-03-11 00:51:41 --> Loader Class Initialized
INFO - 2017-03-11 00:51:42 --> Database Driver Class Initialized
INFO - 2017-03-11 00:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 00:51:42 --> Controller Class Initialized
INFO - 2017-03-11 00:51:42 --> Helper loaded: url_helper
DEBUG - 2017-03-11 00:51:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 00:51:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 00:51:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 00:51:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 00:51:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 00:51:43 --> Final output sent to browser
DEBUG - 2017-03-11 00:51:43 --> Total execution time: 1.7426
INFO - 2017-03-11 00:51:49 --> Config Class Initialized
INFO - 2017-03-11 00:51:49 --> Hooks Class Initialized
DEBUG - 2017-03-11 00:51:49 --> UTF-8 Support Enabled
INFO - 2017-03-11 00:51:49 --> Utf8 Class Initialized
INFO - 2017-03-11 00:51:49 --> URI Class Initialized
DEBUG - 2017-03-11 00:51:49 --> No URI present. Default controller set.
INFO - 2017-03-11 00:51:49 --> Router Class Initialized
INFO - 2017-03-11 00:51:49 --> Output Class Initialized
INFO - 2017-03-11 00:51:49 --> Security Class Initialized
DEBUG - 2017-03-11 00:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 00:51:50 --> Input Class Initialized
INFO - 2017-03-11 00:51:50 --> Language Class Initialized
INFO - 2017-03-11 00:51:50 --> Loader Class Initialized
INFO - 2017-03-11 00:51:50 --> Database Driver Class Initialized
INFO - 2017-03-11 00:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 00:51:50 --> Controller Class Initialized
INFO - 2017-03-11 00:51:50 --> Helper loaded: url_helper
DEBUG - 2017-03-11 00:51:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 00:51:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 00:51:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 00:51:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 00:51:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 00:51:50 --> Final output sent to browser
DEBUG - 2017-03-11 00:51:50 --> Total execution time: 1.2708
INFO - 2017-03-11 00:52:57 --> Config Class Initialized
INFO - 2017-03-11 00:52:57 --> Hooks Class Initialized
DEBUG - 2017-03-11 00:52:57 --> UTF-8 Support Enabled
INFO - 2017-03-11 00:52:57 --> Utf8 Class Initialized
INFO - 2017-03-11 00:52:57 --> URI Class Initialized
DEBUG - 2017-03-11 00:52:57 --> No URI present. Default controller set.
INFO - 2017-03-11 00:52:57 --> Router Class Initialized
INFO - 2017-03-11 00:52:57 --> Output Class Initialized
INFO - 2017-03-11 00:52:57 --> Security Class Initialized
DEBUG - 2017-03-11 00:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 00:52:58 --> Input Class Initialized
INFO - 2017-03-11 00:52:58 --> Language Class Initialized
INFO - 2017-03-11 00:52:58 --> Loader Class Initialized
INFO - 2017-03-11 00:52:58 --> Database Driver Class Initialized
INFO - 2017-03-11 00:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 00:52:58 --> Controller Class Initialized
INFO - 2017-03-11 00:52:58 --> Helper loaded: url_helper
DEBUG - 2017-03-11 00:52:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 00:52:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 00:52:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 00:52:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 00:52:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 00:52:58 --> Final output sent to browser
DEBUG - 2017-03-11 00:52:58 --> Total execution time: 1.4596
INFO - 2017-03-11 00:53:04 --> Config Class Initialized
INFO - 2017-03-11 00:53:04 --> Hooks Class Initialized
DEBUG - 2017-03-11 00:53:04 --> UTF-8 Support Enabled
INFO - 2017-03-11 00:53:04 --> Utf8 Class Initialized
INFO - 2017-03-11 00:53:04 --> URI Class Initialized
DEBUG - 2017-03-11 00:53:04 --> No URI present. Default controller set.
INFO - 2017-03-11 00:53:04 --> Router Class Initialized
INFO - 2017-03-11 00:53:04 --> Output Class Initialized
INFO - 2017-03-11 00:53:04 --> Security Class Initialized
DEBUG - 2017-03-11 00:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 00:53:04 --> Input Class Initialized
INFO - 2017-03-11 00:53:04 --> Language Class Initialized
INFO - 2017-03-11 00:53:04 --> Loader Class Initialized
INFO - 2017-03-11 00:53:04 --> Database Driver Class Initialized
INFO - 2017-03-11 00:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 00:53:05 --> Controller Class Initialized
INFO - 2017-03-11 00:53:05 --> Helper loaded: url_helper
DEBUG - 2017-03-11 00:53:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 00:53:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 00:53:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 00:53:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 00:53:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 00:53:05 --> Final output sent to browser
DEBUG - 2017-03-11 00:53:05 --> Total execution time: 0.2915
INFO - 2017-03-11 00:53:32 --> Config Class Initialized
INFO - 2017-03-11 00:53:32 --> Hooks Class Initialized
DEBUG - 2017-03-11 00:53:32 --> UTF-8 Support Enabled
INFO - 2017-03-11 00:53:32 --> Utf8 Class Initialized
INFO - 2017-03-11 00:53:32 --> URI Class Initialized
INFO - 2017-03-11 00:53:32 --> Router Class Initialized
INFO - 2017-03-11 00:53:32 --> Output Class Initialized
INFO - 2017-03-11 00:53:32 --> Security Class Initialized
DEBUG - 2017-03-11 00:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 00:53:32 --> Input Class Initialized
INFO - 2017-03-11 00:53:32 --> Language Class Initialized
INFO - 2017-03-11 00:53:32 --> Loader Class Initialized
INFO - 2017-03-11 00:53:32 --> Database Driver Class Initialized
INFO - 2017-03-11 00:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 00:53:32 --> Controller Class Initialized
INFO - 2017-03-11 00:53:32 --> Helper loaded: url_helper
DEBUG - 2017-03-11 00:53:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 00:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 00:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 00:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 00:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 00:53:32 --> Final output sent to browser
DEBUG - 2017-03-11 00:53:32 --> Total execution time: 0.0148
INFO - 2017-03-11 00:57:31 --> Config Class Initialized
INFO - 2017-03-11 00:57:31 --> Hooks Class Initialized
DEBUG - 2017-03-11 00:57:32 --> UTF-8 Support Enabled
INFO - 2017-03-11 00:57:32 --> Utf8 Class Initialized
INFO - 2017-03-11 00:57:32 --> URI Class Initialized
DEBUG - 2017-03-11 00:57:32 --> No URI present. Default controller set.
INFO - 2017-03-11 00:57:32 --> Router Class Initialized
INFO - 2017-03-11 00:57:32 --> Output Class Initialized
INFO - 2017-03-11 00:57:32 --> Security Class Initialized
DEBUG - 2017-03-11 00:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 00:57:32 --> Input Class Initialized
INFO - 2017-03-11 00:57:32 --> Language Class Initialized
INFO - 2017-03-11 00:57:32 --> Loader Class Initialized
INFO - 2017-03-11 00:57:32 --> Database Driver Class Initialized
INFO - 2017-03-11 00:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 00:57:33 --> Controller Class Initialized
INFO - 2017-03-11 00:57:33 --> Helper loaded: url_helper
DEBUG - 2017-03-11 00:57:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 00:57:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 00:57:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 00:57:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 00:57:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 00:57:33 --> Final output sent to browser
DEBUG - 2017-03-11 00:57:33 --> Total execution time: 1.7509
INFO - 2017-03-11 00:58:21 --> Config Class Initialized
INFO - 2017-03-11 00:58:21 --> Hooks Class Initialized
DEBUG - 2017-03-11 00:58:21 --> UTF-8 Support Enabled
INFO - 2017-03-11 00:58:21 --> Utf8 Class Initialized
INFO - 2017-03-11 00:58:21 --> URI Class Initialized
INFO - 2017-03-11 00:58:21 --> Router Class Initialized
INFO - 2017-03-11 00:58:21 --> Output Class Initialized
INFO - 2017-03-11 00:58:21 --> Security Class Initialized
DEBUG - 2017-03-11 00:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 00:58:21 --> Input Class Initialized
INFO - 2017-03-11 00:58:21 --> Language Class Initialized
INFO - 2017-03-11 00:58:21 --> Loader Class Initialized
INFO - 2017-03-11 00:58:21 --> Database Driver Class Initialized
INFO - 2017-03-11 00:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 00:58:21 --> Controller Class Initialized
INFO - 2017-03-11 00:58:21 --> Helper loaded: url_helper
DEBUG - 2017-03-11 00:58:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 00:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 00:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 00:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 00:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 00:58:21 --> Final output sent to browser
DEBUG - 2017-03-11 00:58:21 --> Total execution time: 0.0142
INFO - 2017-03-11 00:59:43 --> Config Class Initialized
INFO - 2017-03-11 00:59:43 --> Hooks Class Initialized
DEBUG - 2017-03-11 00:59:43 --> UTF-8 Support Enabled
INFO - 2017-03-11 00:59:43 --> Utf8 Class Initialized
INFO - 2017-03-11 00:59:43 --> URI Class Initialized
INFO - 2017-03-11 00:59:43 --> Router Class Initialized
INFO - 2017-03-11 00:59:43 --> Output Class Initialized
INFO - 2017-03-11 00:59:43 --> Security Class Initialized
DEBUG - 2017-03-11 00:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 00:59:43 --> Input Class Initialized
INFO - 2017-03-11 00:59:43 --> Language Class Initialized
INFO - 2017-03-11 00:59:43 --> Loader Class Initialized
INFO - 2017-03-11 00:59:43 --> Database Driver Class Initialized
INFO - 2017-03-11 00:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 00:59:43 --> Controller Class Initialized
INFO - 2017-03-11 00:59:43 --> Helper loaded: url_helper
DEBUG - 2017-03-11 00:59:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 00:59:43 --> Config Class Initialized
INFO - 2017-03-11 00:59:43 --> Hooks Class Initialized
DEBUG - 2017-03-11 00:59:43 --> UTF-8 Support Enabled
INFO - 2017-03-11 00:59:43 --> Utf8 Class Initialized
INFO - 2017-03-11 00:59:43 --> URI Class Initialized
INFO - 2017-03-11 00:59:43 --> Router Class Initialized
INFO - 2017-03-11 00:59:43 --> Output Class Initialized
INFO - 2017-03-11 00:59:43 --> Security Class Initialized
DEBUG - 2017-03-11 00:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 00:59:43 --> Input Class Initialized
INFO - 2017-03-11 00:59:43 --> Language Class Initialized
INFO - 2017-03-11 00:59:43 --> Loader Class Initialized
INFO - 2017-03-11 00:59:43 --> Database Driver Class Initialized
INFO - 2017-03-11 00:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 00:59:43 --> Controller Class Initialized
INFO - 2017-03-11 00:59:43 --> Helper loaded: date_helper
DEBUG - 2017-03-11 00:59:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 00:59:43 --> Helper loaded: url_helper
INFO - 2017-03-11 00:59:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 00:59:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 00:59:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 00:59:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 00:59:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 00:59:43 --> Final output sent to browser
DEBUG - 2017-03-11 00:59:43 --> Total execution time: 0.1074
INFO - 2017-03-11 00:59:44 --> Config Class Initialized
INFO - 2017-03-11 00:59:44 --> Hooks Class Initialized
DEBUG - 2017-03-11 00:59:44 --> UTF-8 Support Enabled
INFO - 2017-03-11 00:59:44 --> Utf8 Class Initialized
INFO - 2017-03-11 00:59:44 --> URI Class Initialized
INFO - 2017-03-11 00:59:44 --> Router Class Initialized
INFO - 2017-03-11 00:59:44 --> Output Class Initialized
INFO - 2017-03-11 00:59:44 --> Security Class Initialized
DEBUG - 2017-03-11 00:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 00:59:44 --> Input Class Initialized
INFO - 2017-03-11 00:59:44 --> Language Class Initialized
INFO - 2017-03-11 00:59:44 --> Loader Class Initialized
INFO - 2017-03-11 00:59:44 --> Database Driver Class Initialized
INFO - 2017-03-11 00:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 00:59:44 --> Controller Class Initialized
INFO - 2017-03-11 00:59:44 --> Helper loaded: url_helper
DEBUG - 2017-03-11 00:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 00:59:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 00:59:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 00:59:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 00:59:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 00:59:44 --> Final output sent to browser
DEBUG - 2017-03-11 00:59:44 --> Total execution time: 0.0143
INFO - 2017-03-11 00:59:52 --> Config Class Initialized
INFO - 2017-03-11 00:59:52 --> Hooks Class Initialized
DEBUG - 2017-03-11 00:59:52 --> UTF-8 Support Enabled
INFO - 2017-03-11 00:59:52 --> Utf8 Class Initialized
INFO - 2017-03-11 00:59:52 --> URI Class Initialized
DEBUG - 2017-03-11 00:59:52 --> No URI present. Default controller set.
INFO - 2017-03-11 00:59:52 --> Router Class Initialized
INFO - 2017-03-11 00:59:52 --> Output Class Initialized
INFO - 2017-03-11 00:59:52 --> Security Class Initialized
DEBUG - 2017-03-11 00:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 00:59:52 --> Input Class Initialized
INFO - 2017-03-11 00:59:52 --> Language Class Initialized
INFO - 2017-03-11 00:59:52 --> Loader Class Initialized
INFO - 2017-03-11 00:59:52 --> Database Driver Class Initialized
INFO - 2017-03-11 00:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 00:59:52 --> Controller Class Initialized
INFO - 2017-03-11 00:59:52 --> Helper loaded: url_helper
DEBUG - 2017-03-11 00:59:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 00:59:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 00:59:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 00:59:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 00:59:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 00:59:52 --> Final output sent to browser
DEBUG - 2017-03-11 00:59:52 --> Total execution time: 0.0143
INFO - 2017-03-11 00:59:54 --> Config Class Initialized
INFO - 2017-03-11 00:59:54 --> Hooks Class Initialized
DEBUG - 2017-03-11 00:59:54 --> UTF-8 Support Enabled
INFO - 2017-03-11 00:59:54 --> Utf8 Class Initialized
INFO - 2017-03-11 00:59:54 --> URI Class Initialized
INFO - 2017-03-11 00:59:54 --> Router Class Initialized
INFO - 2017-03-11 00:59:54 --> Output Class Initialized
INFO - 2017-03-11 00:59:54 --> Security Class Initialized
DEBUG - 2017-03-11 00:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 00:59:54 --> Input Class Initialized
INFO - 2017-03-11 00:59:54 --> Language Class Initialized
INFO - 2017-03-11 00:59:54 --> Loader Class Initialized
INFO - 2017-03-11 00:59:54 --> Database Driver Class Initialized
INFO - 2017-03-11 00:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 00:59:54 --> Controller Class Initialized
INFO - 2017-03-11 00:59:54 --> Helper loaded: url_helper
DEBUG - 2017-03-11 00:59:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 00:59:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 00:59:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 00:59:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 00:59:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 00:59:54 --> Final output sent to browser
DEBUG - 2017-03-11 00:59:54 --> Total execution time: 0.0149
INFO - 2017-03-11 01:13:03 --> Config Class Initialized
INFO - 2017-03-11 01:13:03 --> Hooks Class Initialized
DEBUG - 2017-03-11 01:13:04 --> UTF-8 Support Enabled
INFO - 2017-03-11 01:13:04 --> Utf8 Class Initialized
INFO - 2017-03-11 01:13:04 --> URI Class Initialized
DEBUG - 2017-03-11 01:13:04 --> No URI present. Default controller set.
INFO - 2017-03-11 01:13:04 --> Router Class Initialized
INFO - 2017-03-11 01:13:04 --> Output Class Initialized
INFO - 2017-03-11 01:13:04 --> Security Class Initialized
DEBUG - 2017-03-11 01:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 01:13:04 --> Input Class Initialized
INFO - 2017-03-11 01:13:04 --> Language Class Initialized
INFO - 2017-03-11 01:13:04 --> Loader Class Initialized
INFO - 2017-03-11 01:13:04 --> Database Driver Class Initialized
INFO - 2017-03-11 01:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 01:13:05 --> Controller Class Initialized
INFO - 2017-03-11 01:13:05 --> Helper loaded: url_helper
DEBUG - 2017-03-11 01:13:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 01:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 01:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 01:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 01:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 01:13:05 --> Final output sent to browser
DEBUG - 2017-03-11 01:13:05 --> Total execution time: 1.7428
INFO - 2017-03-11 01:13:13 --> Config Class Initialized
INFO - 2017-03-11 01:13:13 --> Hooks Class Initialized
DEBUG - 2017-03-11 01:13:13 --> UTF-8 Support Enabled
INFO - 2017-03-11 01:13:13 --> Utf8 Class Initialized
INFO - 2017-03-11 01:13:13 --> URI Class Initialized
INFO - 2017-03-11 01:13:13 --> Router Class Initialized
INFO - 2017-03-11 01:13:13 --> Output Class Initialized
INFO - 2017-03-11 01:13:13 --> Security Class Initialized
DEBUG - 2017-03-11 01:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 01:13:13 --> Input Class Initialized
INFO - 2017-03-11 01:13:13 --> Language Class Initialized
INFO - 2017-03-11 01:13:13 --> Loader Class Initialized
INFO - 2017-03-11 01:13:14 --> Database Driver Class Initialized
INFO - 2017-03-11 01:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 01:13:14 --> Controller Class Initialized
INFO - 2017-03-11 01:13:14 --> Helper loaded: url_helper
DEBUG - 2017-03-11 01:13:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 01:13:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 01:13:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 01:13:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 01:13:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 01:13:14 --> Final output sent to browser
DEBUG - 2017-03-11 01:13:14 --> Total execution time: 1.2210
INFO - 2017-03-11 01:14:18 --> Config Class Initialized
INFO - 2017-03-11 01:14:18 --> Hooks Class Initialized
DEBUG - 2017-03-11 01:14:18 --> UTF-8 Support Enabled
INFO - 2017-03-11 01:14:18 --> Utf8 Class Initialized
INFO - 2017-03-11 01:14:18 --> URI Class Initialized
INFO - 2017-03-11 01:14:18 --> Router Class Initialized
INFO - 2017-03-11 01:14:18 --> Output Class Initialized
INFO - 2017-03-11 01:14:18 --> Security Class Initialized
DEBUG - 2017-03-11 01:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 01:14:19 --> Input Class Initialized
INFO - 2017-03-11 01:14:19 --> Language Class Initialized
INFO - 2017-03-11 01:14:19 --> Loader Class Initialized
INFO - 2017-03-11 01:14:19 --> Database Driver Class Initialized
INFO - 2017-03-11 01:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 01:14:19 --> Controller Class Initialized
INFO - 2017-03-11 01:14:19 --> Helper loaded: url_helper
DEBUG - 2017-03-11 01:14:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 01:14:21 --> Config Class Initialized
INFO - 2017-03-11 01:14:21 --> Hooks Class Initialized
DEBUG - 2017-03-11 01:14:21 --> UTF-8 Support Enabled
INFO - 2017-03-11 01:14:21 --> Utf8 Class Initialized
INFO - 2017-03-11 01:14:21 --> URI Class Initialized
INFO - 2017-03-11 01:14:21 --> Router Class Initialized
INFO - 2017-03-11 01:14:21 --> Output Class Initialized
INFO - 2017-03-11 01:14:21 --> Security Class Initialized
DEBUG - 2017-03-11 01:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 01:14:21 --> Input Class Initialized
INFO - 2017-03-11 01:14:21 --> Language Class Initialized
INFO - 2017-03-11 01:14:21 --> Loader Class Initialized
INFO - 2017-03-11 01:14:21 --> Database Driver Class Initialized
INFO - 2017-03-11 01:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 01:14:21 --> Controller Class Initialized
INFO - 2017-03-11 01:14:21 --> Helper loaded: date_helper
DEBUG - 2017-03-11 01:14:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 01:14:21 --> Helper loaded: url_helper
INFO - 2017-03-11 01:14:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 01:14:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 01:14:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 01:14:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 01:14:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 01:14:21 --> Final output sent to browser
DEBUG - 2017-03-11 01:14:21 --> Total execution time: 0.1083
INFO - 2017-03-11 01:14:22 --> Config Class Initialized
INFO - 2017-03-11 01:14:22 --> Hooks Class Initialized
DEBUG - 2017-03-11 01:14:22 --> UTF-8 Support Enabled
INFO - 2017-03-11 01:14:22 --> Utf8 Class Initialized
INFO - 2017-03-11 01:14:22 --> URI Class Initialized
INFO - 2017-03-11 01:14:22 --> Router Class Initialized
INFO - 2017-03-11 01:14:22 --> Output Class Initialized
INFO - 2017-03-11 01:14:22 --> Security Class Initialized
DEBUG - 2017-03-11 01:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 01:14:22 --> Input Class Initialized
INFO - 2017-03-11 01:14:22 --> Language Class Initialized
INFO - 2017-03-11 01:14:22 --> Loader Class Initialized
INFO - 2017-03-11 01:14:22 --> Database Driver Class Initialized
INFO - 2017-03-11 01:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 01:14:22 --> Controller Class Initialized
INFO - 2017-03-11 01:14:22 --> Helper loaded: url_helper
DEBUG - 2017-03-11 01:14:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 01:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 01:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 01:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 01:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 01:14:22 --> Final output sent to browser
DEBUG - 2017-03-11 01:14:22 --> Total execution time: 0.0466
INFO - 2017-03-11 02:20:48 --> Config Class Initialized
INFO - 2017-03-11 02:20:48 --> Hooks Class Initialized
DEBUG - 2017-03-11 02:20:48 --> UTF-8 Support Enabled
INFO - 2017-03-11 02:20:48 --> Utf8 Class Initialized
INFO - 2017-03-11 02:20:48 --> URI Class Initialized
DEBUG - 2017-03-11 02:20:49 --> No URI present. Default controller set.
INFO - 2017-03-11 02:20:49 --> Router Class Initialized
INFO - 2017-03-11 02:20:49 --> Output Class Initialized
INFO - 2017-03-11 02:20:49 --> Security Class Initialized
DEBUG - 2017-03-11 02:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 02:20:49 --> Input Class Initialized
INFO - 2017-03-11 02:20:49 --> Language Class Initialized
INFO - 2017-03-11 02:20:49 --> Loader Class Initialized
INFO - 2017-03-11 02:20:49 --> Database Driver Class Initialized
INFO - 2017-03-11 02:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 02:20:50 --> Controller Class Initialized
INFO - 2017-03-11 02:20:50 --> Helper loaded: url_helper
DEBUG - 2017-03-11 02:20:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 02:20:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 02:20:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 02:20:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 02:20:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 02:20:50 --> Final output sent to browser
DEBUG - 2017-03-11 02:20:50 --> Total execution time: 1.5089
INFO - 2017-03-11 02:20:56 --> Config Class Initialized
INFO - 2017-03-11 02:20:56 --> Hooks Class Initialized
DEBUG - 2017-03-11 02:20:56 --> UTF-8 Support Enabled
INFO - 2017-03-11 02:20:56 --> Utf8 Class Initialized
INFO - 2017-03-11 02:20:56 --> URI Class Initialized
INFO - 2017-03-11 02:20:56 --> Router Class Initialized
INFO - 2017-03-11 02:20:56 --> Output Class Initialized
INFO - 2017-03-11 02:20:56 --> Security Class Initialized
DEBUG - 2017-03-11 02:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 02:20:56 --> Input Class Initialized
INFO - 2017-03-11 02:20:56 --> Language Class Initialized
INFO - 2017-03-11 02:20:56 --> Loader Class Initialized
INFO - 2017-03-11 02:20:56 --> Database Driver Class Initialized
INFO - 2017-03-11 02:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 02:20:56 --> Controller Class Initialized
INFO - 2017-03-11 02:20:56 --> Helper loaded: url_helper
DEBUG - 2017-03-11 02:20:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 02:20:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 02:20:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 02:20:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 02:20:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 02:20:56 --> Final output sent to browser
DEBUG - 2017-03-11 02:20:56 --> Total execution time: 0.0140
INFO - 2017-03-11 02:34:28 --> Config Class Initialized
INFO - 2017-03-11 02:34:28 --> Hooks Class Initialized
DEBUG - 2017-03-11 02:34:28 --> UTF-8 Support Enabled
INFO - 2017-03-11 02:34:28 --> Utf8 Class Initialized
INFO - 2017-03-11 02:34:28 --> URI Class Initialized
INFO - 2017-03-11 02:34:28 --> Router Class Initialized
INFO - 2017-03-11 02:34:28 --> Output Class Initialized
INFO - 2017-03-11 02:34:28 --> Security Class Initialized
DEBUG - 2017-03-11 02:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 02:34:28 --> Input Class Initialized
INFO - 2017-03-11 02:34:28 --> Language Class Initialized
INFO - 2017-03-11 02:34:28 --> Loader Class Initialized
INFO - 2017-03-11 02:34:29 --> Database Driver Class Initialized
INFO - 2017-03-11 02:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 02:34:29 --> Controller Class Initialized
INFO - 2017-03-11 02:34:29 --> Helper loaded: date_helper
DEBUG - 2017-03-11 02:34:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 02:34:29 --> Helper loaded: url_helper
INFO - 2017-03-11 02:34:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 02:34:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 02:34:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 02:34:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 02:34:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 02:34:29 --> Final output sent to browser
DEBUG - 2017-03-11 02:34:29 --> Total execution time: 1.3665
INFO - 2017-03-11 02:46:47 --> Config Class Initialized
INFO - 2017-03-11 02:46:47 --> Hooks Class Initialized
DEBUG - 2017-03-11 02:46:47 --> UTF-8 Support Enabled
INFO - 2017-03-11 02:46:47 --> Utf8 Class Initialized
INFO - 2017-03-11 02:46:47 --> URI Class Initialized
DEBUG - 2017-03-11 02:46:47 --> No URI present. Default controller set.
INFO - 2017-03-11 02:46:47 --> Router Class Initialized
INFO - 2017-03-11 02:46:47 --> Output Class Initialized
INFO - 2017-03-11 02:46:47 --> Security Class Initialized
DEBUG - 2017-03-11 02:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 02:46:47 --> Input Class Initialized
INFO - 2017-03-11 02:46:47 --> Language Class Initialized
INFO - 2017-03-11 02:46:47 --> Loader Class Initialized
INFO - 2017-03-11 02:46:47 --> Database Driver Class Initialized
INFO - 2017-03-11 02:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 02:46:48 --> Controller Class Initialized
INFO - 2017-03-11 02:46:48 --> Helper loaded: url_helper
DEBUG - 2017-03-11 02:46:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 02:46:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 02:46:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 02:46:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 02:46:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 02:46:48 --> Final output sent to browser
DEBUG - 2017-03-11 02:46:48 --> Total execution time: 1.2544
INFO - 2017-03-11 02:48:53 --> Config Class Initialized
INFO - 2017-03-11 02:48:53 --> Hooks Class Initialized
DEBUG - 2017-03-11 02:48:53 --> UTF-8 Support Enabled
INFO - 2017-03-11 02:48:53 --> Utf8 Class Initialized
INFO - 2017-03-11 02:48:53 --> URI Class Initialized
INFO - 2017-03-11 02:48:53 --> Router Class Initialized
INFO - 2017-03-11 02:48:53 --> Output Class Initialized
INFO - 2017-03-11 02:48:53 --> Security Class Initialized
DEBUG - 2017-03-11 02:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 02:48:53 --> Input Class Initialized
INFO - 2017-03-11 02:48:53 --> Language Class Initialized
INFO - 2017-03-11 02:48:53 --> Loader Class Initialized
INFO - 2017-03-11 02:48:54 --> Database Driver Class Initialized
INFO - 2017-03-11 02:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 02:48:54 --> Controller Class Initialized
INFO - 2017-03-11 02:48:54 --> Helper loaded: url_helper
DEBUG - 2017-03-11 02:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 02:48:57 --> Config Class Initialized
INFO - 2017-03-11 02:48:57 --> Hooks Class Initialized
DEBUG - 2017-03-11 02:48:57 --> UTF-8 Support Enabled
INFO - 2017-03-11 02:48:57 --> Utf8 Class Initialized
INFO - 2017-03-11 02:48:57 --> URI Class Initialized
INFO - 2017-03-11 02:48:57 --> Router Class Initialized
INFO - 2017-03-11 02:48:57 --> Output Class Initialized
INFO - 2017-03-11 02:48:57 --> Security Class Initialized
DEBUG - 2017-03-11 02:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 02:48:57 --> Input Class Initialized
INFO - 2017-03-11 02:48:57 --> Language Class Initialized
INFO - 2017-03-11 02:48:57 --> Loader Class Initialized
INFO - 2017-03-11 02:48:57 --> Database Driver Class Initialized
INFO - 2017-03-11 02:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 02:48:57 --> Controller Class Initialized
INFO - 2017-03-11 02:48:57 --> Helper loaded: date_helper
DEBUG - 2017-03-11 02:48:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 02:48:57 --> Helper loaded: url_helper
INFO - 2017-03-11 02:48:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 02:48:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 02:48:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 02:48:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 02:48:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 02:48:57 --> Final output sent to browser
DEBUG - 2017-03-11 02:48:57 --> Total execution time: 0.1178
INFO - 2017-03-11 02:50:42 --> Config Class Initialized
INFO - 2017-03-11 02:50:42 --> Hooks Class Initialized
DEBUG - 2017-03-11 02:50:42 --> UTF-8 Support Enabled
INFO - 2017-03-11 02:50:42 --> Utf8 Class Initialized
INFO - 2017-03-11 02:50:42 --> URI Class Initialized
INFO - 2017-03-11 02:50:42 --> Router Class Initialized
INFO - 2017-03-11 02:50:42 --> Output Class Initialized
INFO - 2017-03-11 02:50:42 --> Security Class Initialized
DEBUG - 2017-03-11 02:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 02:50:42 --> Input Class Initialized
INFO - 2017-03-11 02:50:42 --> Language Class Initialized
INFO - 2017-03-11 02:50:42 --> Loader Class Initialized
INFO - 2017-03-11 02:50:42 --> Database Driver Class Initialized
INFO - 2017-03-11 02:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 02:50:43 --> Controller Class Initialized
INFO - 2017-03-11 02:50:43 --> Helper loaded: url_helper
DEBUG - 2017-03-11 02:50:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 02:50:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 02:50:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 02:50:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 02:50:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 02:50:43 --> Final output sent to browser
DEBUG - 2017-03-11 02:50:43 --> Total execution time: 1.2094
INFO - 2017-03-11 02:50:43 --> Config Class Initialized
INFO - 2017-03-11 02:50:43 --> Hooks Class Initialized
DEBUG - 2017-03-11 02:50:43 --> UTF-8 Support Enabled
INFO - 2017-03-11 02:50:43 --> Utf8 Class Initialized
INFO - 2017-03-11 02:50:43 --> URI Class Initialized
DEBUG - 2017-03-11 02:50:43 --> No URI present. Default controller set.
INFO - 2017-03-11 02:50:43 --> Router Class Initialized
INFO - 2017-03-11 02:50:43 --> Output Class Initialized
INFO - 2017-03-11 02:50:43 --> Security Class Initialized
DEBUG - 2017-03-11 02:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 02:50:43 --> Input Class Initialized
INFO - 2017-03-11 02:50:43 --> Language Class Initialized
INFO - 2017-03-11 02:50:43 --> Loader Class Initialized
INFO - 2017-03-11 02:50:43 --> Database Driver Class Initialized
INFO - 2017-03-11 02:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 02:50:43 --> Controller Class Initialized
INFO - 2017-03-11 02:50:43 --> Helper loaded: url_helper
DEBUG - 2017-03-11 02:50:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 02:50:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 02:50:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 02:50:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 02:50:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 02:50:43 --> Final output sent to browser
DEBUG - 2017-03-11 02:50:43 --> Total execution time: 0.0144
INFO - 2017-03-11 02:52:32 --> Config Class Initialized
INFO - 2017-03-11 02:52:32 --> Hooks Class Initialized
DEBUG - 2017-03-11 02:52:32 --> UTF-8 Support Enabled
INFO - 2017-03-11 02:52:32 --> Utf8 Class Initialized
INFO - 2017-03-11 02:52:32 --> URI Class Initialized
INFO - 2017-03-11 02:52:32 --> Router Class Initialized
INFO - 2017-03-11 02:52:32 --> Output Class Initialized
INFO - 2017-03-11 02:52:32 --> Security Class Initialized
DEBUG - 2017-03-11 02:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 02:52:32 --> Input Class Initialized
INFO - 2017-03-11 02:52:32 --> Language Class Initialized
INFO - 2017-03-11 02:52:32 --> Loader Class Initialized
INFO - 2017-03-11 02:52:33 --> Database Driver Class Initialized
INFO - 2017-03-11 02:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 02:52:33 --> Controller Class Initialized
INFO - 2017-03-11 02:52:33 --> Helper loaded: url_helper
DEBUG - 2017-03-11 02:52:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 02:52:38 --> Config Class Initialized
INFO - 2017-03-11 02:52:38 --> Hooks Class Initialized
DEBUG - 2017-03-11 02:52:38 --> UTF-8 Support Enabled
INFO - 2017-03-11 02:52:38 --> Utf8 Class Initialized
INFO - 2017-03-11 02:52:38 --> URI Class Initialized
INFO - 2017-03-11 02:52:38 --> Router Class Initialized
INFO - 2017-03-11 02:52:38 --> Output Class Initialized
INFO - 2017-03-11 02:52:38 --> Security Class Initialized
DEBUG - 2017-03-11 02:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 02:52:38 --> Input Class Initialized
INFO - 2017-03-11 02:52:38 --> Language Class Initialized
INFO - 2017-03-11 02:52:38 --> Loader Class Initialized
INFO - 2017-03-11 02:52:38 --> Database Driver Class Initialized
INFO - 2017-03-11 02:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 02:52:38 --> Controller Class Initialized
INFO - 2017-03-11 02:52:38 --> Helper loaded: date_helper
DEBUG - 2017-03-11 02:52:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 02:52:38 --> Helper loaded: url_helper
INFO - 2017-03-11 02:52:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 02:52:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 02:52:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 02:52:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 02:52:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 02:52:38 --> Final output sent to browser
DEBUG - 2017-03-11 02:52:38 --> Total execution time: 0.1117
INFO - 2017-03-11 02:56:20 --> Config Class Initialized
INFO - 2017-03-11 02:56:20 --> Hooks Class Initialized
DEBUG - 2017-03-11 02:56:20 --> UTF-8 Support Enabled
INFO - 2017-03-11 02:56:20 --> Utf8 Class Initialized
INFO - 2017-03-11 02:56:20 --> URI Class Initialized
DEBUG - 2017-03-11 02:56:20 --> No URI present. Default controller set.
INFO - 2017-03-11 02:56:20 --> Router Class Initialized
INFO - 2017-03-11 02:56:20 --> Output Class Initialized
INFO - 2017-03-11 02:56:20 --> Security Class Initialized
DEBUG - 2017-03-11 02:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 02:56:20 --> Input Class Initialized
INFO - 2017-03-11 02:56:20 --> Language Class Initialized
INFO - 2017-03-11 02:56:20 --> Loader Class Initialized
INFO - 2017-03-11 02:56:20 --> Database Driver Class Initialized
INFO - 2017-03-11 02:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 02:56:20 --> Controller Class Initialized
INFO - 2017-03-11 02:56:20 --> Helper loaded: url_helper
DEBUG - 2017-03-11 02:56:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 02:56:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 02:56:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 02:56:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 02:56:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 02:56:20 --> Final output sent to browser
DEBUG - 2017-03-11 02:56:20 --> Total execution time: 0.0424
INFO - 2017-03-11 02:56:32 --> Config Class Initialized
INFO - 2017-03-11 02:56:32 --> Hooks Class Initialized
DEBUG - 2017-03-11 02:56:32 --> UTF-8 Support Enabled
INFO - 2017-03-11 02:56:32 --> Utf8 Class Initialized
INFO - 2017-03-11 02:56:32 --> URI Class Initialized
INFO - 2017-03-11 02:56:32 --> Router Class Initialized
INFO - 2017-03-11 02:56:32 --> Output Class Initialized
INFO - 2017-03-11 02:56:32 --> Security Class Initialized
DEBUG - 2017-03-11 02:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 02:56:32 --> Input Class Initialized
INFO - 2017-03-11 02:56:32 --> Language Class Initialized
INFO - 2017-03-11 02:56:32 --> Loader Class Initialized
INFO - 2017-03-11 02:56:32 --> Database Driver Class Initialized
INFO - 2017-03-11 02:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 02:56:32 --> Controller Class Initialized
INFO - 2017-03-11 02:56:32 --> Helper loaded: url_helper
DEBUG - 2017-03-11 02:56:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 02:56:32 --> Config Class Initialized
INFO - 2017-03-11 02:56:32 --> Hooks Class Initialized
DEBUG - 2017-03-11 02:56:32 --> UTF-8 Support Enabled
INFO - 2017-03-11 02:56:32 --> Utf8 Class Initialized
INFO - 2017-03-11 02:56:32 --> URI Class Initialized
INFO - 2017-03-11 02:56:32 --> Router Class Initialized
INFO - 2017-03-11 02:56:32 --> Output Class Initialized
INFO - 2017-03-11 02:56:32 --> Security Class Initialized
DEBUG - 2017-03-11 02:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 02:56:32 --> Input Class Initialized
INFO - 2017-03-11 02:56:32 --> Language Class Initialized
INFO - 2017-03-11 02:56:32 --> Loader Class Initialized
INFO - 2017-03-11 02:56:32 --> Database Driver Class Initialized
INFO - 2017-03-11 02:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 02:56:32 --> Controller Class Initialized
INFO - 2017-03-11 02:56:32 --> Helper loaded: date_helper
DEBUG - 2017-03-11 02:56:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 02:56:32 --> Helper loaded: url_helper
INFO - 2017-03-11 02:56:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 02:56:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 02:56:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 02:56:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 02:56:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 02:56:32 --> Final output sent to browser
DEBUG - 2017-03-11 02:56:32 --> Total execution time: 0.0139
INFO - 2017-03-11 02:56:35 --> Config Class Initialized
INFO - 2017-03-11 02:56:35 --> Hooks Class Initialized
DEBUG - 2017-03-11 02:56:35 --> UTF-8 Support Enabled
INFO - 2017-03-11 02:56:35 --> Utf8 Class Initialized
INFO - 2017-03-11 02:56:35 --> URI Class Initialized
DEBUG - 2017-03-11 02:56:35 --> No URI present. Default controller set.
INFO - 2017-03-11 02:56:35 --> Router Class Initialized
INFO - 2017-03-11 02:56:35 --> Output Class Initialized
INFO - 2017-03-11 02:56:35 --> Security Class Initialized
DEBUG - 2017-03-11 02:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 02:56:35 --> Input Class Initialized
INFO - 2017-03-11 02:56:35 --> Language Class Initialized
INFO - 2017-03-11 02:56:35 --> Loader Class Initialized
INFO - 2017-03-11 02:56:35 --> Database Driver Class Initialized
INFO - 2017-03-11 02:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 02:56:35 --> Controller Class Initialized
INFO - 2017-03-11 02:56:35 --> Helper loaded: url_helper
DEBUG - 2017-03-11 02:56:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 02:56:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 02:56:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 02:56:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 02:56:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 02:56:35 --> Final output sent to browser
DEBUG - 2017-03-11 02:56:35 --> Total execution time: 0.0142
INFO - 2017-03-11 04:59:38 --> Config Class Initialized
INFO - 2017-03-11 04:59:38 --> Hooks Class Initialized
DEBUG - 2017-03-11 04:59:38 --> UTF-8 Support Enabled
INFO - 2017-03-11 04:59:38 --> Utf8 Class Initialized
INFO - 2017-03-11 04:59:38 --> URI Class Initialized
DEBUG - 2017-03-11 04:59:38 --> No URI present. Default controller set.
INFO - 2017-03-11 04:59:38 --> Router Class Initialized
INFO - 2017-03-11 04:59:38 --> Output Class Initialized
INFO - 2017-03-11 04:59:38 --> Security Class Initialized
DEBUG - 2017-03-11 04:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 04:59:38 --> Input Class Initialized
INFO - 2017-03-11 04:59:38 --> Language Class Initialized
INFO - 2017-03-11 04:59:38 --> Loader Class Initialized
INFO - 2017-03-11 04:59:39 --> Database Driver Class Initialized
INFO - 2017-03-11 04:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 04:59:39 --> Controller Class Initialized
INFO - 2017-03-11 04:59:39 --> Helper loaded: url_helper
DEBUG - 2017-03-11 04:59:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 04:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 04:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 04:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 04:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 04:59:39 --> Final output sent to browser
DEBUG - 2017-03-11 04:59:39 --> Total execution time: 1.2299
INFO - 2017-03-11 04:59:53 --> Config Class Initialized
INFO - 2017-03-11 04:59:53 --> Hooks Class Initialized
DEBUG - 2017-03-11 04:59:53 --> UTF-8 Support Enabled
INFO - 2017-03-11 04:59:53 --> Utf8 Class Initialized
INFO - 2017-03-11 04:59:53 --> URI Class Initialized
DEBUG - 2017-03-11 04:59:53 --> No URI present. Default controller set.
INFO - 2017-03-11 04:59:53 --> Router Class Initialized
INFO - 2017-03-11 04:59:53 --> Output Class Initialized
INFO - 2017-03-11 04:59:53 --> Security Class Initialized
DEBUG - 2017-03-11 04:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 04:59:53 --> Input Class Initialized
INFO - 2017-03-11 04:59:53 --> Language Class Initialized
INFO - 2017-03-11 04:59:53 --> Loader Class Initialized
INFO - 2017-03-11 04:59:53 --> Database Driver Class Initialized
INFO - 2017-03-11 04:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 04:59:53 --> Controller Class Initialized
INFO - 2017-03-11 04:59:53 --> Helper loaded: url_helper
DEBUG - 2017-03-11 04:59:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 04:59:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 04:59:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 04:59:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 04:59:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 04:59:53 --> Final output sent to browser
DEBUG - 2017-03-11 04:59:53 --> Total execution time: 0.0139
INFO - 2017-03-11 04:59:59 --> Config Class Initialized
INFO - 2017-03-11 04:59:59 --> Hooks Class Initialized
DEBUG - 2017-03-11 04:59:59 --> UTF-8 Support Enabled
INFO - 2017-03-11 04:59:59 --> Utf8 Class Initialized
INFO - 2017-03-11 04:59:59 --> URI Class Initialized
INFO - 2017-03-11 04:59:59 --> Router Class Initialized
INFO - 2017-03-11 04:59:59 --> Output Class Initialized
INFO - 2017-03-11 04:59:59 --> Security Class Initialized
DEBUG - 2017-03-11 04:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 04:59:59 --> Input Class Initialized
INFO - 2017-03-11 04:59:59 --> Language Class Initialized
INFO - 2017-03-11 04:59:59 --> Loader Class Initialized
INFO - 2017-03-11 04:59:59 --> Database Driver Class Initialized
INFO - 2017-03-11 04:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 04:59:59 --> Controller Class Initialized
INFO - 2017-03-11 04:59:59 --> Helper loaded: url_helper
DEBUG - 2017-03-11 04:59:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 04:59:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 04:59:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 04:59:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 04:59:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 04:59:59 --> Final output sent to browser
DEBUG - 2017-03-11 04:59:59 --> Total execution time: 0.0553
INFO - 2017-03-11 05:00:33 --> Config Class Initialized
INFO - 2017-03-11 05:00:33 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:00:33 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:00:33 --> Utf8 Class Initialized
INFO - 2017-03-11 05:00:33 --> URI Class Initialized
INFO - 2017-03-11 05:00:33 --> Router Class Initialized
INFO - 2017-03-11 05:00:33 --> Output Class Initialized
INFO - 2017-03-11 05:00:33 --> Security Class Initialized
DEBUG - 2017-03-11 05:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:00:33 --> Input Class Initialized
INFO - 2017-03-11 05:00:33 --> Language Class Initialized
INFO - 2017-03-11 05:00:34 --> Loader Class Initialized
INFO - 2017-03-11 05:00:34 --> Database Driver Class Initialized
INFO - 2017-03-11 05:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:00:34 --> Controller Class Initialized
INFO - 2017-03-11 05:00:34 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:00:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:00:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:00:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:00:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:00:34 --> Final output sent to browser
DEBUG - 2017-03-11 05:00:34 --> Total execution time: 1.2971
INFO - 2017-03-11 05:00:38 --> Config Class Initialized
INFO - 2017-03-11 05:00:38 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:00:38 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:00:38 --> Utf8 Class Initialized
INFO - 2017-03-11 05:00:39 --> URI Class Initialized
INFO - 2017-03-11 05:00:39 --> Router Class Initialized
INFO - 2017-03-11 05:00:39 --> Output Class Initialized
INFO - 2017-03-11 05:00:39 --> Security Class Initialized
DEBUG - 2017-03-11 05:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:00:39 --> Input Class Initialized
INFO - 2017-03-11 05:00:39 --> Language Class Initialized
INFO - 2017-03-11 05:00:39 --> Loader Class Initialized
INFO - 2017-03-11 05:00:39 --> Database Driver Class Initialized
INFO - 2017-03-11 05:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:00:39 --> Controller Class Initialized
INFO - 2017-03-11 05:00:39 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:00:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:00:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:00:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:00:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:00:40 --> Final output sent to browser
DEBUG - 2017-03-11 05:00:40 --> Total execution time: 1.6118
INFO - 2017-03-11 05:00:54 --> Config Class Initialized
INFO - 2017-03-11 05:00:54 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:00:54 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:00:54 --> Utf8 Class Initialized
INFO - 2017-03-11 05:00:54 --> URI Class Initialized
INFO - 2017-03-11 05:00:54 --> Router Class Initialized
INFO - 2017-03-11 05:00:54 --> Output Class Initialized
INFO - 2017-03-11 05:00:54 --> Security Class Initialized
DEBUG - 2017-03-11 05:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:00:54 --> Input Class Initialized
INFO - 2017-03-11 05:00:54 --> Language Class Initialized
INFO - 2017-03-11 05:00:54 --> Loader Class Initialized
INFO - 2017-03-11 05:00:54 --> Database Driver Class Initialized
INFO - 2017-03-11 05:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:00:54 --> Controller Class Initialized
INFO - 2017-03-11 05:00:54 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:00:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:00:58 --> Config Class Initialized
INFO - 2017-03-11 05:00:58 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:00:58 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:00:58 --> Utf8 Class Initialized
INFO - 2017-03-11 05:00:58 --> URI Class Initialized
INFO - 2017-03-11 05:00:58 --> Router Class Initialized
INFO - 2017-03-11 05:00:58 --> Output Class Initialized
INFO - 2017-03-11 05:00:58 --> Security Class Initialized
DEBUG - 2017-03-11 05:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:00:58 --> Input Class Initialized
INFO - 2017-03-11 05:00:58 --> Language Class Initialized
INFO - 2017-03-11 05:00:58 --> Loader Class Initialized
INFO - 2017-03-11 05:00:58 --> Database Driver Class Initialized
INFO - 2017-03-11 05:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:00:58 --> Controller Class Initialized
INFO - 2017-03-11 05:00:58 --> Helper loaded: date_helper
DEBUG - 2017-03-11 05:00:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:00:58 --> Helper loaded: url_helper
INFO - 2017-03-11 05:00:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:00:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 05:00:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 05:00:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 05:00:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:00:58 --> Final output sent to browser
DEBUG - 2017-03-11 05:00:58 --> Total execution time: 0.1817
INFO - 2017-03-11 05:01:00 --> Config Class Initialized
INFO - 2017-03-11 05:01:00 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:01:00 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:01:00 --> Utf8 Class Initialized
INFO - 2017-03-11 05:01:00 --> URI Class Initialized
INFO - 2017-03-11 05:01:00 --> Router Class Initialized
INFO - 2017-03-11 05:01:00 --> Output Class Initialized
INFO - 2017-03-11 05:01:00 --> Security Class Initialized
DEBUG - 2017-03-11 05:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:01:00 --> Input Class Initialized
INFO - 2017-03-11 05:01:00 --> Language Class Initialized
INFO - 2017-03-11 05:01:00 --> Loader Class Initialized
INFO - 2017-03-11 05:01:00 --> Database Driver Class Initialized
INFO - 2017-03-11 05:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:01:00 --> Controller Class Initialized
INFO - 2017-03-11 05:01:00 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:01:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:01:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:01:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:01:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:01:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:01:00 --> Final output sent to browser
DEBUG - 2017-03-11 05:01:00 --> Total execution time: 0.0404
INFO - 2017-03-11 05:01:13 --> Config Class Initialized
INFO - 2017-03-11 05:01:13 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:01:13 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:01:13 --> Utf8 Class Initialized
INFO - 2017-03-11 05:01:13 --> URI Class Initialized
INFO - 2017-03-11 05:01:13 --> Router Class Initialized
INFO - 2017-03-11 05:01:13 --> Output Class Initialized
INFO - 2017-03-11 05:01:13 --> Security Class Initialized
DEBUG - 2017-03-11 05:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:01:13 --> Input Class Initialized
INFO - 2017-03-11 05:01:13 --> Language Class Initialized
INFO - 2017-03-11 05:01:13 --> Loader Class Initialized
INFO - 2017-03-11 05:01:13 --> Database Driver Class Initialized
INFO - 2017-03-11 05:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:01:13 --> Controller Class Initialized
INFO - 2017-03-11 05:01:13 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:01:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:01:13 --> Config Class Initialized
INFO - 2017-03-11 05:01:13 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:01:13 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:01:13 --> Utf8 Class Initialized
INFO - 2017-03-11 05:01:13 --> URI Class Initialized
INFO - 2017-03-11 05:01:13 --> Router Class Initialized
INFO - 2017-03-11 05:01:13 --> Output Class Initialized
INFO - 2017-03-11 05:01:13 --> Security Class Initialized
DEBUG - 2017-03-11 05:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:01:13 --> Input Class Initialized
INFO - 2017-03-11 05:01:13 --> Language Class Initialized
INFO - 2017-03-11 05:01:13 --> Loader Class Initialized
INFO - 2017-03-11 05:01:13 --> Database Driver Class Initialized
INFO - 2017-03-11 05:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:01:13 --> Controller Class Initialized
INFO - 2017-03-11 05:01:13 --> Helper loaded: date_helper
DEBUG - 2017-03-11 05:01:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:01:13 --> Helper loaded: url_helper
INFO - 2017-03-11 05:01:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:01:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 05:01:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 05:01:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 05:01:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:01:13 --> Final output sent to browser
DEBUG - 2017-03-11 05:01:13 --> Total execution time: 0.0189
INFO - 2017-03-11 05:01:15 --> Config Class Initialized
INFO - 2017-03-11 05:01:15 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:01:15 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:01:15 --> Utf8 Class Initialized
INFO - 2017-03-11 05:01:15 --> URI Class Initialized
INFO - 2017-03-11 05:01:15 --> Router Class Initialized
INFO - 2017-03-11 05:01:15 --> Output Class Initialized
INFO - 2017-03-11 05:01:15 --> Security Class Initialized
DEBUG - 2017-03-11 05:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:01:15 --> Input Class Initialized
INFO - 2017-03-11 05:01:15 --> Language Class Initialized
INFO - 2017-03-11 05:01:15 --> Loader Class Initialized
INFO - 2017-03-11 05:01:15 --> Database Driver Class Initialized
INFO - 2017-03-11 05:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:01:15 --> Controller Class Initialized
INFO - 2017-03-11 05:01:15 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:01:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:01:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:01:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:01:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:01:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:01:15 --> Final output sent to browser
DEBUG - 2017-03-11 05:01:15 --> Total execution time: 0.0135
INFO - 2017-03-11 05:01:30 --> Config Class Initialized
INFO - 2017-03-11 05:01:30 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:01:30 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:01:30 --> Utf8 Class Initialized
INFO - 2017-03-11 05:01:30 --> URI Class Initialized
DEBUG - 2017-03-11 05:01:30 --> No URI present. Default controller set.
INFO - 2017-03-11 05:01:30 --> Router Class Initialized
INFO - 2017-03-11 05:01:30 --> Output Class Initialized
INFO - 2017-03-11 05:01:30 --> Security Class Initialized
DEBUG - 2017-03-11 05:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:01:30 --> Input Class Initialized
INFO - 2017-03-11 05:01:30 --> Language Class Initialized
INFO - 2017-03-11 05:01:30 --> Loader Class Initialized
INFO - 2017-03-11 05:01:31 --> Database Driver Class Initialized
INFO - 2017-03-11 05:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:01:32 --> Controller Class Initialized
INFO - 2017-03-11 05:01:32 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:01:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:01:32 --> Final output sent to browser
DEBUG - 2017-03-11 05:01:32 --> Total execution time: 2.3522
INFO - 2017-03-11 05:01:37 --> Config Class Initialized
INFO - 2017-03-11 05:01:37 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:01:37 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:01:37 --> Utf8 Class Initialized
INFO - 2017-03-11 05:01:37 --> URI Class Initialized
INFO - 2017-03-11 05:01:37 --> Router Class Initialized
INFO - 2017-03-11 05:01:37 --> Output Class Initialized
INFO - 2017-03-11 05:01:37 --> Security Class Initialized
DEBUG - 2017-03-11 05:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:01:37 --> Input Class Initialized
INFO - 2017-03-11 05:01:37 --> Language Class Initialized
INFO - 2017-03-11 05:01:37 --> Loader Class Initialized
INFO - 2017-03-11 05:01:38 --> Database Driver Class Initialized
INFO - 2017-03-11 05:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:01:38 --> Controller Class Initialized
INFO - 2017-03-11 05:01:38 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:01:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:01:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:01:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:01:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:01:39 --> Final output sent to browser
DEBUG - 2017-03-11 05:01:39 --> Total execution time: 1.6209
INFO - 2017-03-11 05:02:29 --> Config Class Initialized
INFO - 2017-03-11 05:02:29 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:02:29 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:02:29 --> Utf8 Class Initialized
INFO - 2017-03-11 05:02:29 --> URI Class Initialized
INFO - 2017-03-11 05:02:29 --> Router Class Initialized
INFO - 2017-03-11 05:02:29 --> Output Class Initialized
INFO - 2017-03-11 05:02:29 --> Security Class Initialized
DEBUG - 2017-03-11 05:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:02:29 --> Input Class Initialized
INFO - 2017-03-11 05:02:29 --> Language Class Initialized
INFO - 2017-03-11 05:02:29 --> Loader Class Initialized
INFO - 2017-03-11 05:02:30 --> Database Driver Class Initialized
INFO - 2017-03-11 05:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:02:30 --> Controller Class Initialized
INFO - 2017-03-11 05:02:30 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:02:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:02:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:02:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:02:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:02:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:02:30 --> Final output sent to browser
DEBUG - 2017-03-11 05:02:30 --> Total execution time: 1.4460
INFO - 2017-03-11 05:02:39 --> Config Class Initialized
INFO - 2017-03-11 05:02:39 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:02:39 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:02:39 --> Utf8 Class Initialized
INFO - 2017-03-11 05:02:39 --> URI Class Initialized
INFO - 2017-03-11 05:02:39 --> Router Class Initialized
INFO - 2017-03-11 05:02:39 --> Output Class Initialized
INFO - 2017-03-11 05:02:39 --> Security Class Initialized
DEBUG - 2017-03-11 05:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:02:40 --> Input Class Initialized
INFO - 2017-03-11 05:02:40 --> Language Class Initialized
INFO - 2017-03-11 05:02:40 --> Loader Class Initialized
INFO - 2017-03-11 05:02:40 --> Database Driver Class Initialized
INFO - 2017-03-11 05:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:02:40 --> Controller Class Initialized
INFO - 2017-03-11 05:02:40 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:02:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:02:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:02:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:02:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:02:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:02:41 --> Final output sent to browser
DEBUG - 2017-03-11 05:02:41 --> Total execution time: 1.4877
INFO - 2017-03-11 05:02:53 --> Config Class Initialized
INFO - 2017-03-11 05:02:53 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:02:53 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:02:53 --> Utf8 Class Initialized
INFO - 2017-03-11 05:02:53 --> URI Class Initialized
INFO - 2017-03-11 05:02:53 --> Router Class Initialized
INFO - 2017-03-11 05:02:53 --> Output Class Initialized
INFO - 2017-03-11 05:02:53 --> Security Class Initialized
DEBUG - 2017-03-11 05:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:02:53 --> Input Class Initialized
INFO - 2017-03-11 05:02:53 --> Language Class Initialized
INFO - 2017-03-11 05:02:53 --> Loader Class Initialized
INFO - 2017-03-11 05:02:54 --> Database Driver Class Initialized
INFO - 2017-03-11 05:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:02:54 --> Controller Class Initialized
INFO - 2017-03-11 05:02:54 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:02:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:02:57 --> Config Class Initialized
INFO - 2017-03-11 05:02:57 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:02:57 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:02:57 --> Utf8 Class Initialized
INFO - 2017-03-11 05:02:57 --> URI Class Initialized
INFO - 2017-03-11 05:02:57 --> Router Class Initialized
INFO - 2017-03-11 05:02:57 --> Output Class Initialized
INFO - 2017-03-11 05:02:57 --> Security Class Initialized
DEBUG - 2017-03-11 05:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:02:57 --> Input Class Initialized
INFO - 2017-03-11 05:02:57 --> Language Class Initialized
INFO - 2017-03-11 05:02:57 --> Loader Class Initialized
INFO - 2017-03-11 05:02:57 --> Database Driver Class Initialized
INFO - 2017-03-11 05:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:02:57 --> Controller Class Initialized
INFO - 2017-03-11 05:02:58 --> Helper loaded: date_helper
DEBUG - 2017-03-11 05:02:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:02:58 --> Helper loaded: url_helper
INFO - 2017-03-11 05:02:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:02:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 05:02:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 05:02:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 05:02:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:02:58 --> Final output sent to browser
DEBUG - 2017-03-11 05:02:58 --> Total execution time: 1.1208
INFO - 2017-03-11 05:03:02 --> Config Class Initialized
INFO - 2017-03-11 05:03:02 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:03:02 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:03:02 --> Utf8 Class Initialized
INFO - 2017-03-11 05:03:02 --> URI Class Initialized
INFO - 2017-03-11 05:03:02 --> Router Class Initialized
INFO - 2017-03-11 05:03:02 --> Output Class Initialized
INFO - 2017-03-11 05:03:02 --> Security Class Initialized
DEBUG - 2017-03-11 05:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:03:02 --> Input Class Initialized
INFO - 2017-03-11 05:03:02 --> Language Class Initialized
INFO - 2017-03-11 05:03:02 --> Loader Class Initialized
INFO - 2017-03-11 05:03:02 --> Database Driver Class Initialized
INFO - 2017-03-11 05:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:03:03 --> Controller Class Initialized
INFO - 2017-03-11 05:03:03 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:03:03 --> Final output sent to browser
DEBUG - 2017-03-11 05:03:03 --> Total execution time: 1.3006
INFO - 2017-03-11 05:06:56 --> Config Class Initialized
INFO - 2017-03-11 05:06:56 --> Config Class Initialized
INFO - 2017-03-11 05:06:56 --> Hooks Class Initialized
INFO - 2017-03-11 05:06:56 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:06:56 --> UTF-8 Support Enabled
DEBUG - 2017-03-11 05:06:56 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:06:56 --> Utf8 Class Initialized
INFO - 2017-03-11 05:06:56 --> Utf8 Class Initialized
INFO - 2017-03-11 05:06:56 --> URI Class Initialized
INFO - 2017-03-11 05:06:56 --> URI Class Initialized
DEBUG - 2017-03-11 05:06:56 --> No URI present. Default controller set.
INFO - 2017-03-11 05:06:56 --> Router Class Initialized
DEBUG - 2017-03-11 05:06:56 --> No URI present. Default controller set.
INFO - 2017-03-11 05:06:56 --> Router Class Initialized
INFO - 2017-03-11 05:06:56 --> Output Class Initialized
INFO - 2017-03-11 05:06:56 --> Security Class Initialized
INFO - 2017-03-11 05:06:56 --> Output Class Initialized
DEBUG - 2017-03-11 05:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:06:56 --> Input Class Initialized
INFO - 2017-03-11 05:06:56 --> Security Class Initialized
INFO - 2017-03-11 05:06:56 --> Language Class Initialized
DEBUG - 2017-03-11 05:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:06:56 --> Input Class Initialized
INFO - 2017-03-11 05:06:56 --> Loader Class Initialized
INFO - 2017-03-11 05:06:56 --> Language Class Initialized
INFO - 2017-03-11 05:06:57 --> Loader Class Initialized
INFO - 2017-03-11 05:06:58 --> Database Driver Class Initialized
INFO - 2017-03-11 05:06:58 --> Database Driver Class Initialized
INFO - 2017-03-11 05:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:06:58 --> Controller Class Initialized
INFO - 2017-03-11 05:06:58 --> Controller Class Initialized
INFO - 2017-03-11 05:06:58 --> Helper loaded: url_helper
INFO - 2017-03-11 05:06:58 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:06:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-11 05:06:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:06:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:06:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:06:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:06:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:06:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:06:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:06:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:06:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:06:58 --> Final output sent to browser
DEBUG - 2017-03-11 05:06:58 --> Total execution time: 2.4413
INFO - 2017-03-11 05:06:58 --> Final output sent to browser
DEBUG - 2017-03-11 05:06:58 --> Total execution time: 2.4413
INFO - 2017-03-11 05:07:23 --> Config Class Initialized
INFO - 2017-03-11 05:07:23 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:07:23 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:07:23 --> Utf8 Class Initialized
INFO - 2017-03-11 05:07:23 --> URI Class Initialized
INFO - 2017-03-11 05:07:23 --> Router Class Initialized
INFO - 2017-03-11 05:07:23 --> Output Class Initialized
INFO - 2017-03-11 05:07:23 --> Security Class Initialized
DEBUG - 2017-03-11 05:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:07:24 --> Input Class Initialized
INFO - 2017-03-11 05:07:24 --> Language Class Initialized
INFO - 2017-03-11 05:07:24 --> Loader Class Initialized
INFO - 2017-03-11 05:07:24 --> Database Driver Class Initialized
INFO - 2017-03-11 05:07:24 --> Config Class Initialized
INFO - 2017-03-11 05:07:24 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:07:24 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:07:24 --> Utf8 Class Initialized
INFO - 2017-03-11 05:07:24 --> URI Class Initialized
INFO - 2017-03-11 05:07:24 --> Router Class Initialized
INFO - 2017-03-11 05:07:24 --> Output Class Initialized
INFO - 2017-03-11 05:07:24 --> Security Class Initialized
DEBUG - 2017-03-11 05:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:07:24 --> Input Class Initialized
INFO - 2017-03-11 05:07:24 --> Language Class Initialized
INFO - 2017-03-11 05:07:24 --> Loader Class Initialized
INFO - 2017-03-11 05:07:24 --> Database Driver Class Initialized
INFO - 2017-03-11 05:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:07:24 --> Controller Class Initialized
INFO - 2017-03-11 05:07:24 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:07:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:07:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:07:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:07:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:07:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:07:24 --> Final output sent to browser
DEBUG - 2017-03-11 05:07:24 --> Total execution time: 1.8869
INFO - 2017-03-11 05:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:07:24 --> Controller Class Initialized
INFO - 2017-03-11 05:07:24 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:07:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:07:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:07:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:07:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:07:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:07:24 --> Final output sent to browser
DEBUG - 2017-03-11 05:07:24 --> Total execution time: 0.4795
INFO - 2017-03-11 05:08:08 --> Config Class Initialized
INFO - 2017-03-11 05:08:08 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:08:08 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:08:08 --> Utf8 Class Initialized
INFO - 2017-03-11 05:08:08 --> URI Class Initialized
INFO - 2017-03-11 05:08:08 --> Router Class Initialized
INFO - 2017-03-11 05:08:08 --> Output Class Initialized
INFO - 2017-03-11 05:08:08 --> Security Class Initialized
DEBUG - 2017-03-11 05:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:08:08 --> Input Class Initialized
INFO - 2017-03-11 05:08:08 --> Language Class Initialized
INFO - 2017-03-11 05:08:08 --> Loader Class Initialized
INFO - 2017-03-11 05:08:08 --> Database Driver Class Initialized
INFO - 2017-03-11 05:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:08:09 --> Controller Class Initialized
INFO - 2017-03-11 05:08:09 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:08:13 --> Config Class Initialized
INFO - 2017-03-11 05:08:13 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:08:13 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:08:13 --> Utf8 Class Initialized
INFO - 2017-03-11 05:08:13 --> URI Class Initialized
INFO - 2017-03-11 05:08:13 --> Router Class Initialized
INFO - 2017-03-11 05:08:13 --> Output Class Initialized
INFO - 2017-03-11 05:08:13 --> Security Class Initialized
DEBUG - 2017-03-11 05:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:08:13 --> Input Class Initialized
INFO - 2017-03-11 05:08:13 --> Language Class Initialized
INFO - 2017-03-11 05:08:13 --> Loader Class Initialized
INFO - 2017-03-11 05:08:13 --> Database Driver Class Initialized
INFO - 2017-03-11 05:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:08:13 --> Controller Class Initialized
INFO - 2017-03-11 05:08:13 --> Helper loaded: date_helper
DEBUG - 2017-03-11 05:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:08:13 --> Helper loaded: url_helper
INFO - 2017-03-11 05:08:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:08:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 05:08:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 05:08:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 05:08:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:08:13 --> Final output sent to browser
DEBUG - 2017-03-11 05:08:13 --> Total execution time: 0.3910
INFO - 2017-03-11 05:08:46 --> Config Class Initialized
INFO - 2017-03-11 05:08:46 --> Config Class Initialized
INFO - 2017-03-11 05:08:46 --> Hooks Class Initialized
INFO - 2017-03-11 05:08:46 --> Hooks Class Initialized
INFO - 2017-03-11 05:08:46 --> Config Class Initialized
INFO - 2017-03-11 05:08:46 --> Hooks Class Initialized
INFO - 2017-03-11 05:08:46 --> Config Class Initialized
INFO - 2017-03-11 05:08:46 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:08:46 --> UTF-8 Support Enabled
DEBUG - 2017-03-11 05:08:46 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:08:46 --> Utf8 Class Initialized
INFO - 2017-03-11 05:08:46 --> Utf8 Class Initialized
DEBUG - 2017-03-11 05:08:46 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:08:46 --> URI Class Initialized
INFO - 2017-03-11 05:08:46 --> URI Class Initialized
INFO - 2017-03-11 05:08:46 --> Utf8 Class Initialized
INFO - 2017-03-11 05:08:46 --> URI Class Initialized
DEBUG - 2017-03-11 05:08:46 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:08:46 --> Utf8 Class Initialized
INFO - 2017-03-11 05:08:46 --> URI Class Initialized
DEBUG - 2017-03-11 05:08:46 --> No URI present. Default controller set.
INFO - 2017-03-11 05:08:46 --> Router Class Initialized
INFO - 2017-03-11 05:08:46 --> Router Class Initialized
DEBUG - 2017-03-11 05:08:46 --> No URI present. Default controller set.
INFO - 2017-03-11 05:08:46 --> Router Class Initialized
INFO - 2017-03-11 05:08:46 --> Router Class Initialized
INFO - 2017-03-11 05:08:46 --> Output Class Initialized
INFO - 2017-03-11 05:08:46 --> Output Class Initialized
INFO - 2017-03-11 05:08:46 --> Security Class Initialized
INFO - 2017-03-11 05:08:46 --> Output Class Initialized
DEBUG - 2017-03-11 05:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:08:46 --> Input Class Initialized
INFO - 2017-03-11 05:08:46 --> Language Class Initialized
INFO - 2017-03-11 05:08:46 --> Output Class Initialized
INFO - 2017-03-11 05:08:46 --> Security Class Initialized
DEBUG - 2017-03-11 05:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:08:46 --> Loader Class Initialized
INFO - 2017-03-11 05:08:46 --> Input Class Initialized
INFO - 2017-03-11 05:08:46 --> Language Class Initialized
INFO - 2017-03-11 05:08:46 --> Security Class Initialized
DEBUG - 2017-03-11 05:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:08:46 --> Input Class Initialized
INFO - 2017-03-11 05:08:46 --> Language Class Initialized
INFO - 2017-03-11 05:08:46 --> Loader Class Initialized
INFO - 2017-03-11 05:08:46 --> Security Class Initialized
DEBUG - 2017-03-11 05:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:08:46 --> Input Class Initialized
INFO - 2017-03-11 05:08:46 --> Language Class Initialized
INFO - 2017-03-11 05:08:46 --> Loader Class Initialized
INFO - 2017-03-11 05:08:46 --> Loader Class Initialized
INFO - 2017-03-11 05:08:47 --> Database Driver Class Initialized
INFO - 2017-03-11 05:08:47 --> Database Driver Class Initialized
INFO - 2017-03-11 05:08:47 --> Database Driver Class Initialized
INFO - 2017-03-11 05:08:47 --> Database Driver Class Initialized
INFO - 2017-03-11 05:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:08:47 --> Controller Class Initialized
INFO - 2017-03-11 05:08:47 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:08:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:08:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:08:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:08:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:08:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:08:47 --> Final output sent to browser
DEBUG - 2017-03-11 05:08:47 --> Total execution time: 1.2509
INFO - 2017-03-11 05:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:08:47 --> Controller Class Initialized
INFO - 2017-03-11 05:08:47 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:08:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:08:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:08:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:08:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:08:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:08:47 --> Final output sent to browser
DEBUG - 2017-03-11 05:08:47 --> Total execution time: 1.2559
INFO - 2017-03-11 05:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:08:47 --> Controller Class Initialized
INFO - 2017-03-11 05:08:47 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:08:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:08:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:08:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:08:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:08:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:08:47 --> Final output sent to browser
DEBUG - 2017-03-11 05:08:47 --> Total execution time: 1.2627
INFO - 2017-03-11 05:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:08:47 --> Controller Class Initialized
INFO - 2017-03-11 05:08:47 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:08:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:08:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:08:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:08:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:08:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:08:48 --> Final output sent to browser
DEBUG - 2017-03-11 05:08:48 --> Total execution time: 2.1670
INFO - 2017-03-11 05:08:51 --> Config Class Initialized
INFO - 2017-03-11 05:08:51 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:08:51 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:08:52 --> Utf8 Class Initialized
INFO - 2017-03-11 05:08:52 --> URI Class Initialized
INFO - 2017-03-11 05:08:52 --> Router Class Initialized
INFO - 2017-03-11 05:08:52 --> Output Class Initialized
INFO - 2017-03-11 05:08:52 --> Security Class Initialized
DEBUG - 2017-03-11 05:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:08:52 --> Input Class Initialized
INFO - 2017-03-11 05:08:52 --> Language Class Initialized
INFO - 2017-03-11 05:08:52 --> Loader Class Initialized
INFO - 2017-03-11 05:08:52 --> Database Driver Class Initialized
INFO - 2017-03-11 05:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:08:52 --> Controller Class Initialized
INFO - 2017-03-11 05:08:52 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:08:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:08:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:08:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:08:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:08:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:08:53 --> Final output sent to browser
DEBUG - 2017-03-11 05:08:53 --> Total execution time: 1.2726
INFO - 2017-03-11 05:17:02 --> Config Class Initialized
INFO - 2017-03-11 05:17:02 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:17:02 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:17:02 --> Utf8 Class Initialized
INFO - 2017-03-11 05:17:06 --> URI Class Initialized
INFO - 2017-03-11 05:17:06 --> Router Class Initialized
INFO - 2017-03-11 05:17:06 --> Output Class Initialized
INFO - 2017-03-11 05:17:06 --> Security Class Initialized
DEBUG - 2017-03-11 05:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:17:06 --> Input Class Initialized
INFO - 2017-03-11 05:17:06 --> Language Class Initialized
INFO - 2017-03-11 05:17:06 --> Loader Class Initialized
INFO - 2017-03-11 05:17:06 --> Database Driver Class Initialized
INFO - 2017-03-11 05:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:17:06 --> Controller Class Initialized
INFO - 2017-03-11 05:17:06 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:17:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:17:07 --> Config Class Initialized
INFO - 2017-03-11 05:17:07 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:17:07 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:17:07 --> Utf8 Class Initialized
INFO - 2017-03-11 05:17:07 --> URI Class Initialized
INFO - 2017-03-11 05:17:07 --> Router Class Initialized
INFO - 2017-03-11 05:17:07 --> Output Class Initialized
INFO - 2017-03-11 05:17:07 --> Security Class Initialized
DEBUG - 2017-03-11 05:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:17:07 --> Input Class Initialized
INFO - 2017-03-11 05:17:07 --> Language Class Initialized
INFO - 2017-03-11 05:17:07 --> Loader Class Initialized
INFO - 2017-03-11 05:17:07 --> Database Driver Class Initialized
INFO - 2017-03-11 05:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:17:07 --> Controller Class Initialized
INFO - 2017-03-11 05:17:07 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:17:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:17:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-11 05:17:07 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-11 05:17:07 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-11 05:17:07 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-11 05:17:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:17:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:17:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:17:07 --> Final output sent to browser
DEBUG - 2017-03-11 05:17:07 --> Total execution time: 0.2769
INFO - 2017-03-11 05:17:10 --> Config Class Initialized
INFO - 2017-03-11 05:17:10 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:17:10 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:17:10 --> Utf8 Class Initialized
INFO - 2017-03-11 05:17:10 --> URI Class Initialized
INFO - 2017-03-11 05:17:10 --> Router Class Initialized
INFO - 2017-03-11 05:17:10 --> Output Class Initialized
INFO - 2017-03-11 05:17:10 --> Security Class Initialized
DEBUG - 2017-03-11 05:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:17:10 --> Input Class Initialized
INFO - 2017-03-11 05:17:10 --> Language Class Initialized
INFO - 2017-03-11 05:17:10 --> Loader Class Initialized
INFO - 2017-03-11 05:17:10 --> Database Driver Class Initialized
INFO - 2017-03-11 05:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:17:10 --> Controller Class Initialized
INFO - 2017-03-11 05:17:10 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:17:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:17:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:17:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:17:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:17:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:17:10 --> Final output sent to browser
DEBUG - 2017-03-11 05:17:10 --> Total execution time: 0.0147
INFO - 2017-03-11 05:17:16 --> Config Class Initialized
INFO - 2017-03-11 05:17:16 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:17:16 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:17:16 --> Utf8 Class Initialized
INFO - 2017-03-11 05:17:16 --> URI Class Initialized
DEBUG - 2017-03-11 05:17:16 --> No URI present. Default controller set.
INFO - 2017-03-11 05:17:16 --> Router Class Initialized
INFO - 2017-03-11 05:17:16 --> Output Class Initialized
INFO - 2017-03-11 05:17:16 --> Security Class Initialized
DEBUG - 2017-03-11 05:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:17:16 --> Input Class Initialized
INFO - 2017-03-11 05:17:16 --> Language Class Initialized
INFO - 2017-03-11 05:17:16 --> Loader Class Initialized
INFO - 2017-03-11 05:17:16 --> Database Driver Class Initialized
INFO - 2017-03-11 05:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:17:16 --> Controller Class Initialized
INFO - 2017-03-11 05:17:16 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:17:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:17:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:17:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:17:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:17:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:17:16 --> Final output sent to browser
DEBUG - 2017-03-11 05:17:16 --> Total execution time: 0.0138
INFO - 2017-03-11 05:17:20 --> Config Class Initialized
INFO - 2017-03-11 05:17:20 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:17:20 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:17:20 --> Utf8 Class Initialized
INFO - 2017-03-11 05:17:20 --> URI Class Initialized
INFO - 2017-03-11 05:17:20 --> Router Class Initialized
INFO - 2017-03-11 05:17:20 --> Output Class Initialized
INFO - 2017-03-11 05:17:20 --> Security Class Initialized
DEBUG - 2017-03-11 05:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:17:20 --> Input Class Initialized
INFO - 2017-03-11 05:17:20 --> Language Class Initialized
INFO - 2017-03-11 05:17:20 --> Loader Class Initialized
INFO - 2017-03-11 05:17:20 --> Database Driver Class Initialized
INFO - 2017-03-11 05:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:17:20 --> Controller Class Initialized
INFO - 2017-03-11 05:17:20 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:17:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:17:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:17:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:17:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:17:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:17:21 --> Final output sent to browser
DEBUG - 2017-03-11 05:17:21 --> Total execution time: 0.0648
INFO - 2017-03-11 05:17:50 --> Config Class Initialized
INFO - 2017-03-11 05:17:50 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:17:50 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:17:50 --> Utf8 Class Initialized
INFO - 2017-03-11 05:17:50 --> URI Class Initialized
INFO - 2017-03-11 05:17:50 --> Router Class Initialized
INFO - 2017-03-11 05:17:50 --> Output Class Initialized
INFO - 2017-03-11 05:17:50 --> Security Class Initialized
DEBUG - 2017-03-11 05:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:17:50 --> Input Class Initialized
INFO - 2017-03-11 05:17:50 --> Language Class Initialized
INFO - 2017-03-11 05:17:50 --> Loader Class Initialized
INFO - 2017-03-11 05:17:50 --> Database Driver Class Initialized
INFO - 2017-03-11 05:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:17:50 --> Controller Class Initialized
INFO - 2017-03-11 05:17:50 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:17:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:17:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:17:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:17:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:17:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:17:50 --> Final output sent to browser
DEBUG - 2017-03-11 05:17:50 --> Total execution time: 0.0149
INFO - 2017-03-11 05:17:53 --> Config Class Initialized
INFO - 2017-03-11 05:17:53 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:17:53 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:17:53 --> Utf8 Class Initialized
INFO - 2017-03-11 05:17:53 --> URI Class Initialized
INFO - 2017-03-11 05:17:53 --> Router Class Initialized
INFO - 2017-03-11 05:17:53 --> Output Class Initialized
INFO - 2017-03-11 05:17:53 --> Security Class Initialized
DEBUG - 2017-03-11 05:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:17:53 --> Input Class Initialized
INFO - 2017-03-11 05:17:53 --> Language Class Initialized
INFO - 2017-03-11 05:17:53 --> Loader Class Initialized
INFO - 2017-03-11 05:17:53 --> Database Driver Class Initialized
INFO - 2017-03-11 05:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:17:53 --> Controller Class Initialized
INFO - 2017-03-11 05:17:53 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:17:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:17:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:17:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:17:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:17:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:17:53 --> Final output sent to browser
DEBUG - 2017-03-11 05:17:53 --> Total execution time: 0.0138
INFO - 2017-03-11 05:18:10 --> Config Class Initialized
INFO - 2017-03-11 05:18:10 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:18:10 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:18:10 --> Utf8 Class Initialized
INFO - 2017-03-11 05:18:10 --> URI Class Initialized
INFO - 2017-03-11 05:18:10 --> Router Class Initialized
INFO - 2017-03-11 05:18:10 --> Output Class Initialized
INFO - 2017-03-11 05:18:10 --> Security Class Initialized
DEBUG - 2017-03-11 05:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:18:10 --> Input Class Initialized
INFO - 2017-03-11 05:18:10 --> Language Class Initialized
INFO - 2017-03-11 05:18:10 --> Loader Class Initialized
INFO - 2017-03-11 05:18:10 --> Database Driver Class Initialized
INFO - 2017-03-11 05:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:18:10 --> Controller Class Initialized
INFO - 2017-03-11 05:18:10 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:18:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:18:10 --> Config Class Initialized
INFO - 2017-03-11 05:18:10 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:18:10 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:18:10 --> Utf8 Class Initialized
INFO - 2017-03-11 05:18:10 --> URI Class Initialized
INFO - 2017-03-11 05:18:10 --> Router Class Initialized
INFO - 2017-03-11 05:18:10 --> Output Class Initialized
INFO - 2017-03-11 05:18:10 --> Security Class Initialized
DEBUG - 2017-03-11 05:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:18:10 --> Input Class Initialized
INFO - 2017-03-11 05:18:10 --> Language Class Initialized
INFO - 2017-03-11 05:18:10 --> Loader Class Initialized
INFO - 2017-03-11 05:18:10 --> Database Driver Class Initialized
INFO - 2017-03-11 05:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:18:10 --> Controller Class Initialized
INFO - 2017-03-11 05:18:10 --> Helper loaded: date_helper
DEBUG - 2017-03-11 05:18:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:18:10 --> Helper loaded: url_helper
INFO - 2017-03-11 05:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 05:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 05:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 05:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:18:10 --> Final output sent to browser
DEBUG - 2017-03-11 05:18:10 --> Total execution time: 0.0819
INFO - 2017-03-11 05:18:11 --> Config Class Initialized
INFO - 2017-03-11 05:18:11 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:18:11 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:18:11 --> Utf8 Class Initialized
INFO - 2017-03-11 05:18:11 --> URI Class Initialized
INFO - 2017-03-11 05:18:11 --> Router Class Initialized
INFO - 2017-03-11 05:18:11 --> Output Class Initialized
INFO - 2017-03-11 05:18:11 --> Security Class Initialized
DEBUG - 2017-03-11 05:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:18:11 --> Input Class Initialized
INFO - 2017-03-11 05:18:11 --> Language Class Initialized
INFO - 2017-03-11 05:18:11 --> Loader Class Initialized
INFO - 2017-03-11 05:18:11 --> Database Driver Class Initialized
INFO - 2017-03-11 05:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:18:11 --> Controller Class Initialized
INFO - 2017-03-11 05:18:11 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:18:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:18:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:18:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:18:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:18:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:18:11 --> Final output sent to browser
DEBUG - 2017-03-11 05:18:11 --> Total execution time: 0.0135
INFO - 2017-03-11 05:18:18 --> Config Class Initialized
INFO - 2017-03-11 05:18:18 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:18:18 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:18:18 --> Utf8 Class Initialized
INFO - 2017-03-11 05:18:18 --> URI Class Initialized
INFO - 2017-03-11 05:18:18 --> Router Class Initialized
INFO - 2017-03-11 05:18:18 --> Output Class Initialized
INFO - 2017-03-11 05:18:18 --> Security Class Initialized
DEBUG - 2017-03-11 05:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:18:18 --> Input Class Initialized
INFO - 2017-03-11 05:18:18 --> Language Class Initialized
INFO - 2017-03-11 05:18:18 --> Loader Class Initialized
INFO - 2017-03-11 05:18:18 --> Database Driver Class Initialized
INFO - 2017-03-11 05:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:18:18 --> Controller Class Initialized
INFO - 2017-03-11 05:18:18 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:18:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:18:19 --> Config Class Initialized
INFO - 2017-03-11 05:18:19 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:18:19 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:18:19 --> Utf8 Class Initialized
INFO - 2017-03-11 05:18:19 --> URI Class Initialized
INFO - 2017-03-11 05:18:19 --> Router Class Initialized
INFO - 2017-03-11 05:18:19 --> Output Class Initialized
INFO - 2017-03-11 05:18:19 --> Security Class Initialized
DEBUG - 2017-03-11 05:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:18:19 --> Input Class Initialized
INFO - 2017-03-11 05:18:19 --> Language Class Initialized
INFO - 2017-03-11 05:18:19 --> Loader Class Initialized
INFO - 2017-03-11 05:18:19 --> Database Driver Class Initialized
INFO - 2017-03-11 05:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:18:19 --> Controller Class Initialized
INFO - 2017-03-11 05:18:19 --> Helper loaded: date_helper
DEBUG - 2017-03-11 05:18:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:18:19 --> Helper loaded: url_helper
INFO - 2017-03-11 05:18:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:18:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 05:18:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 05:18:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 05:18:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:18:19 --> Final output sent to browser
DEBUG - 2017-03-11 05:18:19 --> Total execution time: 0.0142
INFO - 2017-03-11 05:18:20 --> Config Class Initialized
INFO - 2017-03-11 05:18:20 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:18:20 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:18:20 --> Utf8 Class Initialized
INFO - 2017-03-11 05:18:20 --> URI Class Initialized
INFO - 2017-03-11 05:18:20 --> Router Class Initialized
INFO - 2017-03-11 05:18:20 --> Output Class Initialized
INFO - 2017-03-11 05:18:20 --> Security Class Initialized
DEBUG - 2017-03-11 05:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:18:20 --> Input Class Initialized
INFO - 2017-03-11 05:18:20 --> Language Class Initialized
INFO - 2017-03-11 05:18:20 --> Loader Class Initialized
INFO - 2017-03-11 05:18:20 --> Database Driver Class Initialized
INFO - 2017-03-11 05:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:18:20 --> Controller Class Initialized
INFO - 2017-03-11 05:18:20 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:18:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:18:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:18:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:18:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:18:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:18:20 --> Final output sent to browser
DEBUG - 2017-03-11 05:18:20 --> Total execution time: 0.0138
INFO - 2017-03-11 05:18:24 --> Config Class Initialized
INFO - 2017-03-11 05:18:24 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:18:24 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:18:24 --> Utf8 Class Initialized
INFO - 2017-03-11 05:18:24 --> URI Class Initialized
INFO - 2017-03-11 05:18:24 --> Router Class Initialized
INFO - 2017-03-11 05:18:24 --> Output Class Initialized
INFO - 2017-03-11 05:18:24 --> Security Class Initialized
DEBUG - 2017-03-11 05:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:18:24 --> Input Class Initialized
INFO - 2017-03-11 05:18:24 --> Language Class Initialized
INFO - 2017-03-11 05:18:24 --> Loader Class Initialized
INFO - 2017-03-11 05:18:24 --> Database Driver Class Initialized
INFO - 2017-03-11 05:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:18:24 --> Controller Class Initialized
INFO - 2017-03-11 05:18:24 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:18:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:18:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-11 05:18:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-11 05:18:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-11 05:18:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-11 05:18:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:18:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:18:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:18:24 --> Final output sent to browser
DEBUG - 2017-03-11 05:18:24 --> Total execution time: 0.0145
INFO - 2017-03-11 05:18:26 --> Config Class Initialized
INFO - 2017-03-11 05:18:26 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:18:26 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:18:26 --> Utf8 Class Initialized
INFO - 2017-03-11 05:18:26 --> URI Class Initialized
INFO - 2017-03-11 05:18:26 --> Router Class Initialized
INFO - 2017-03-11 05:18:26 --> Output Class Initialized
INFO - 2017-03-11 05:18:26 --> Security Class Initialized
DEBUG - 2017-03-11 05:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:18:26 --> Input Class Initialized
INFO - 2017-03-11 05:18:26 --> Language Class Initialized
INFO - 2017-03-11 05:18:26 --> Loader Class Initialized
INFO - 2017-03-11 05:18:27 --> Database Driver Class Initialized
INFO - 2017-03-11 05:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:18:27 --> Controller Class Initialized
INFO - 2017-03-11 05:18:27 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:18:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:18:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:18:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:18:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:18:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:18:27 --> Final output sent to browser
DEBUG - 2017-03-11 05:18:27 --> Total execution time: 0.0142
INFO - 2017-03-11 05:18:30 --> Config Class Initialized
INFO - 2017-03-11 05:18:30 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:18:30 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:18:30 --> Utf8 Class Initialized
INFO - 2017-03-11 05:18:30 --> URI Class Initialized
DEBUG - 2017-03-11 05:18:30 --> No URI present. Default controller set.
INFO - 2017-03-11 05:18:30 --> Router Class Initialized
INFO - 2017-03-11 05:18:30 --> Output Class Initialized
INFO - 2017-03-11 05:18:30 --> Security Class Initialized
DEBUG - 2017-03-11 05:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:18:30 --> Input Class Initialized
INFO - 2017-03-11 05:18:30 --> Language Class Initialized
INFO - 2017-03-11 05:18:30 --> Loader Class Initialized
INFO - 2017-03-11 05:18:30 --> Database Driver Class Initialized
INFO - 2017-03-11 05:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:18:30 --> Controller Class Initialized
INFO - 2017-03-11 05:18:30 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:18:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:18:30 --> Final output sent to browser
DEBUG - 2017-03-11 05:18:30 --> Total execution time: 0.0134
INFO - 2017-03-11 05:18:33 --> Config Class Initialized
INFO - 2017-03-11 05:18:33 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:18:33 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:18:33 --> Utf8 Class Initialized
INFO - 2017-03-11 05:18:33 --> URI Class Initialized
INFO - 2017-03-11 05:18:33 --> Router Class Initialized
INFO - 2017-03-11 05:18:33 --> Output Class Initialized
INFO - 2017-03-11 05:18:33 --> Security Class Initialized
DEBUG - 2017-03-11 05:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:18:33 --> Input Class Initialized
INFO - 2017-03-11 05:18:33 --> Language Class Initialized
INFO - 2017-03-11 05:18:33 --> Loader Class Initialized
INFO - 2017-03-11 05:18:33 --> Database Driver Class Initialized
INFO - 2017-03-11 05:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:18:33 --> Controller Class Initialized
INFO - 2017-03-11 05:18:33 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:18:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:18:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:18:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:18:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:18:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:18:33 --> Final output sent to browser
DEBUG - 2017-03-11 05:18:33 --> Total execution time: 0.0138
INFO - 2017-03-11 05:18:40 --> Config Class Initialized
INFO - 2017-03-11 05:18:40 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:18:40 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:18:40 --> Utf8 Class Initialized
INFO - 2017-03-11 05:18:40 --> URI Class Initialized
INFO - 2017-03-11 05:18:40 --> Router Class Initialized
INFO - 2017-03-11 05:18:40 --> Output Class Initialized
INFO - 2017-03-11 05:18:40 --> Security Class Initialized
DEBUG - 2017-03-11 05:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:18:40 --> Input Class Initialized
INFO - 2017-03-11 05:18:40 --> Language Class Initialized
INFO - 2017-03-11 05:18:40 --> Loader Class Initialized
INFO - 2017-03-11 05:18:40 --> Database Driver Class Initialized
INFO - 2017-03-11 05:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:18:40 --> Controller Class Initialized
INFO - 2017-03-11 05:18:40 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:18:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:18:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:18:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:18:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:18:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:18:40 --> Final output sent to browser
DEBUG - 2017-03-11 05:18:40 --> Total execution time: 0.0165
INFO - 2017-03-11 05:18:43 --> Config Class Initialized
INFO - 2017-03-11 05:18:43 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:18:43 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:18:43 --> Utf8 Class Initialized
INFO - 2017-03-11 05:18:43 --> URI Class Initialized
INFO - 2017-03-11 05:18:43 --> Router Class Initialized
INFO - 2017-03-11 05:18:43 --> Output Class Initialized
INFO - 2017-03-11 05:18:43 --> Security Class Initialized
DEBUG - 2017-03-11 05:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:18:43 --> Input Class Initialized
INFO - 2017-03-11 05:18:43 --> Language Class Initialized
INFO - 2017-03-11 05:18:43 --> Loader Class Initialized
INFO - 2017-03-11 05:18:43 --> Database Driver Class Initialized
INFO - 2017-03-11 05:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:18:43 --> Controller Class Initialized
INFO - 2017-03-11 05:18:43 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:18:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:18:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:18:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:18:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:18:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:18:43 --> Final output sent to browser
DEBUG - 2017-03-11 05:18:43 --> Total execution time: 0.0136
INFO - 2017-03-11 05:18:53 --> Config Class Initialized
INFO - 2017-03-11 05:18:53 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:18:53 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:18:53 --> Utf8 Class Initialized
INFO - 2017-03-11 05:18:53 --> URI Class Initialized
INFO - 2017-03-11 05:18:53 --> Router Class Initialized
INFO - 2017-03-11 05:18:53 --> Output Class Initialized
INFO - 2017-03-11 05:18:53 --> Security Class Initialized
DEBUG - 2017-03-11 05:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:18:54 --> Input Class Initialized
INFO - 2017-03-11 05:18:54 --> Language Class Initialized
INFO - 2017-03-11 05:18:54 --> Loader Class Initialized
INFO - 2017-03-11 05:18:54 --> Database Driver Class Initialized
INFO - 2017-03-11 05:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:18:54 --> Controller Class Initialized
INFO - 2017-03-11 05:18:54 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:18:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:18:55 --> Config Class Initialized
INFO - 2017-03-11 05:18:55 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:18:55 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:18:55 --> Utf8 Class Initialized
INFO - 2017-03-11 05:18:55 --> URI Class Initialized
INFO - 2017-03-11 05:18:55 --> Router Class Initialized
INFO - 2017-03-11 05:18:55 --> Output Class Initialized
INFO - 2017-03-11 05:18:55 --> Security Class Initialized
DEBUG - 2017-03-11 05:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:18:55 --> Input Class Initialized
INFO - 2017-03-11 05:18:55 --> Language Class Initialized
INFO - 2017-03-11 05:18:55 --> Loader Class Initialized
INFO - 2017-03-11 05:18:55 --> Database Driver Class Initialized
INFO - 2017-03-11 05:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:18:55 --> Controller Class Initialized
INFO - 2017-03-11 05:18:55 --> Helper loaded: date_helper
DEBUG - 2017-03-11 05:18:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:18:55 --> Helper loaded: url_helper
INFO - 2017-03-11 05:18:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:18:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 05:18:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 05:18:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 05:18:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:18:55 --> Final output sent to browser
DEBUG - 2017-03-11 05:18:55 --> Total execution time: 0.0143
INFO - 2017-03-11 05:18:56 --> Config Class Initialized
INFO - 2017-03-11 05:18:56 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:18:56 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:18:56 --> Utf8 Class Initialized
INFO - 2017-03-11 05:18:56 --> URI Class Initialized
INFO - 2017-03-11 05:18:56 --> Router Class Initialized
INFO - 2017-03-11 05:18:56 --> Output Class Initialized
INFO - 2017-03-11 05:18:56 --> Security Class Initialized
DEBUG - 2017-03-11 05:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:18:56 --> Input Class Initialized
INFO - 2017-03-11 05:18:56 --> Language Class Initialized
INFO - 2017-03-11 05:18:56 --> Loader Class Initialized
INFO - 2017-03-11 05:18:56 --> Database Driver Class Initialized
INFO - 2017-03-11 05:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:18:56 --> Controller Class Initialized
INFO - 2017-03-11 05:18:56 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:18:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:18:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:18:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:18:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:18:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:18:56 --> Final output sent to browser
DEBUG - 2017-03-11 05:18:56 --> Total execution time: 0.0142
INFO - 2017-03-11 05:19:04 --> Config Class Initialized
INFO - 2017-03-11 05:19:04 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:19:04 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:19:04 --> Utf8 Class Initialized
INFO - 2017-03-11 05:19:04 --> URI Class Initialized
INFO - 2017-03-11 05:19:04 --> Router Class Initialized
INFO - 2017-03-11 05:19:04 --> Output Class Initialized
INFO - 2017-03-11 05:19:04 --> Security Class Initialized
DEBUG - 2017-03-11 05:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:19:04 --> Input Class Initialized
INFO - 2017-03-11 05:19:04 --> Language Class Initialized
INFO - 2017-03-11 05:19:04 --> Loader Class Initialized
INFO - 2017-03-11 05:19:04 --> Database Driver Class Initialized
INFO - 2017-03-11 05:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:19:04 --> Controller Class Initialized
INFO - 2017-03-11 05:19:04 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:19:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:19:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-11 05:19:04 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-11 05:19:04 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-11 05:19:04 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-11 05:19:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:19:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:19:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:19:04 --> Final output sent to browser
DEBUG - 2017-03-11 05:19:04 --> Total execution time: 0.0142
INFO - 2017-03-11 05:19:05 --> Config Class Initialized
INFO - 2017-03-11 05:19:05 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:19:05 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:19:05 --> Utf8 Class Initialized
INFO - 2017-03-11 05:19:05 --> URI Class Initialized
INFO - 2017-03-11 05:19:05 --> Router Class Initialized
INFO - 2017-03-11 05:19:05 --> Output Class Initialized
INFO - 2017-03-11 05:19:05 --> Security Class Initialized
DEBUG - 2017-03-11 05:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:19:05 --> Input Class Initialized
INFO - 2017-03-11 05:19:05 --> Language Class Initialized
INFO - 2017-03-11 05:19:05 --> Loader Class Initialized
INFO - 2017-03-11 05:19:05 --> Database Driver Class Initialized
INFO - 2017-03-11 05:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:19:05 --> Controller Class Initialized
INFO - 2017-03-11 05:19:05 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:19:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:19:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:19:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:19:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:19:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:19:05 --> Final output sent to browser
DEBUG - 2017-03-11 05:19:05 --> Total execution time: 0.0183
INFO - 2017-03-11 05:19:59 --> Config Class Initialized
INFO - 2017-03-11 05:19:59 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:19:59 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:19:59 --> Utf8 Class Initialized
INFO - 2017-03-11 05:19:59 --> URI Class Initialized
INFO - 2017-03-11 05:19:59 --> Router Class Initialized
INFO - 2017-03-11 05:19:59 --> Output Class Initialized
INFO - 2017-03-11 05:19:59 --> Security Class Initialized
DEBUG - 2017-03-11 05:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:19:59 --> Input Class Initialized
INFO - 2017-03-11 05:19:59 --> Language Class Initialized
INFO - 2017-03-11 05:19:59 --> Loader Class Initialized
INFO - 2017-03-11 05:19:59 --> Database Driver Class Initialized
INFO - 2017-03-11 05:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:19:59 --> Controller Class Initialized
INFO - 2017-03-11 05:19:59 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:19:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:20:00 --> Config Class Initialized
INFO - 2017-03-11 05:20:00 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:20:00 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:20:00 --> Utf8 Class Initialized
INFO - 2017-03-11 05:20:00 --> URI Class Initialized
INFO - 2017-03-11 05:20:00 --> Router Class Initialized
INFO - 2017-03-11 05:20:00 --> Output Class Initialized
INFO - 2017-03-11 05:20:00 --> Security Class Initialized
DEBUG - 2017-03-11 05:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:20:00 --> Input Class Initialized
INFO - 2017-03-11 05:20:00 --> Language Class Initialized
INFO - 2017-03-11 05:20:00 --> Loader Class Initialized
INFO - 2017-03-11 05:20:00 --> Database Driver Class Initialized
INFO - 2017-03-11 05:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:20:00 --> Controller Class Initialized
INFO - 2017-03-11 05:20:00 --> Helper loaded: date_helper
DEBUG - 2017-03-11 05:20:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:20:00 --> Helper loaded: url_helper
INFO - 2017-03-11 05:20:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:20:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 05:20:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 05:20:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 05:20:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:20:00 --> Final output sent to browser
DEBUG - 2017-03-11 05:20:00 --> Total execution time: 0.0142
INFO - 2017-03-11 05:20:01 --> Config Class Initialized
INFO - 2017-03-11 05:20:01 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:20:01 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:20:01 --> Utf8 Class Initialized
INFO - 2017-03-11 05:20:01 --> URI Class Initialized
INFO - 2017-03-11 05:20:01 --> Router Class Initialized
INFO - 2017-03-11 05:20:01 --> Output Class Initialized
INFO - 2017-03-11 05:20:01 --> Security Class Initialized
DEBUG - 2017-03-11 05:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:20:01 --> Input Class Initialized
INFO - 2017-03-11 05:20:01 --> Language Class Initialized
INFO - 2017-03-11 05:20:01 --> Loader Class Initialized
INFO - 2017-03-11 05:20:01 --> Database Driver Class Initialized
INFO - 2017-03-11 05:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:20:01 --> Controller Class Initialized
INFO - 2017-03-11 05:20:01 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:20:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:20:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:20:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:20:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:20:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:20:01 --> Final output sent to browser
DEBUG - 2017-03-11 05:20:01 --> Total execution time: 0.0144
INFO - 2017-03-11 05:20:10 --> Config Class Initialized
INFO - 2017-03-11 05:20:10 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:20:10 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:20:10 --> Utf8 Class Initialized
INFO - 2017-03-11 05:20:10 --> URI Class Initialized
DEBUG - 2017-03-11 05:20:10 --> No URI present. Default controller set.
INFO - 2017-03-11 05:20:10 --> Router Class Initialized
INFO - 2017-03-11 05:20:10 --> Output Class Initialized
INFO - 2017-03-11 05:20:10 --> Security Class Initialized
DEBUG - 2017-03-11 05:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:20:10 --> Input Class Initialized
INFO - 2017-03-11 05:20:10 --> Language Class Initialized
INFO - 2017-03-11 05:20:10 --> Loader Class Initialized
INFO - 2017-03-11 05:20:10 --> Database Driver Class Initialized
INFO - 2017-03-11 05:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:20:10 --> Controller Class Initialized
INFO - 2017-03-11 05:20:10 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:20:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:20:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:20:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:20:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:20:10 --> Final output sent to browser
DEBUG - 2017-03-11 05:20:10 --> Total execution time: 0.0136
INFO - 2017-03-11 05:20:11 --> Config Class Initialized
INFO - 2017-03-11 05:20:11 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:20:11 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:20:11 --> Utf8 Class Initialized
INFO - 2017-03-11 05:20:11 --> URI Class Initialized
INFO - 2017-03-11 05:20:11 --> Router Class Initialized
INFO - 2017-03-11 05:20:11 --> Output Class Initialized
INFO - 2017-03-11 05:20:11 --> Security Class Initialized
DEBUG - 2017-03-11 05:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:20:11 --> Input Class Initialized
INFO - 2017-03-11 05:20:11 --> Language Class Initialized
INFO - 2017-03-11 05:20:11 --> Loader Class Initialized
INFO - 2017-03-11 05:20:11 --> Database Driver Class Initialized
INFO - 2017-03-11 05:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:20:11 --> Controller Class Initialized
INFO - 2017-03-11 05:20:11 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:20:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:20:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:20:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:20:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:20:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:20:11 --> Final output sent to browser
DEBUG - 2017-03-11 05:20:11 --> Total execution time: 0.0138
INFO - 2017-03-11 05:21:06 --> Config Class Initialized
INFO - 2017-03-11 05:21:06 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:21:06 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:21:06 --> Utf8 Class Initialized
INFO - 2017-03-11 05:21:06 --> URI Class Initialized
INFO - 2017-03-11 05:21:06 --> Router Class Initialized
INFO - 2017-03-11 05:21:06 --> Output Class Initialized
INFO - 2017-03-11 05:21:06 --> Security Class Initialized
DEBUG - 2017-03-11 05:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:21:06 --> Input Class Initialized
INFO - 2017-03-11 05:21:06 --> Language Class Initialized
INFO - 2017-03-11 05:21:06 --> Loader Class Initialized
INFO - 2017-03-11 05:21:06 --> Database Driver Class Initialized
INFO - 2017-03-11 05:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:21:07 --> Controller Class Initialized
INFO - 2017-03-11 05:21:07 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:21:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:21:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:21:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:21:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:21:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:21:07 --> Final output sent to browser
DEBUG - 2017-03-11 05:21:07 --> Total execution time: 1.5460
INFO - 2017-03-11 05:21:08 --> Config Class Initialized
INFO - 2017-03-11 05:21:08 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:21:08 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:21:08 --> Utf8 Class Initialized
INFO - 2017-03-11 05:21:08 --> URI Class Initialized
INFO - 2017-03-11 05:21:08 --> Router Class Initialized
INFO - 2017-03-11 05:21:08 --> Output Class Initialized
INFO - 2017-03-11 05:21:08 --> Security Class Initialized
DEBUG - 2017-03-11 05:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:21:08 --> Input Class Initialized
INFO - 2017-03-11 05:21:08 --> Language Class Initialized
INFO - 2017-03-11 05:21:08 --> Loader Class Initialized
INFO - 2017-03-11 05:21:08 --> Database Driver Class Initialized
INFO - 2017-03-11 05:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:21:08 --> Controller Class Initialized
INFO - 2017-03-11 05:21:08 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:21:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:21:08 --> Final output sent to browser
DEBUG - 2017-03-11 05:21:08 --> Total execution time: 0.0137
INFO - 2017-03-11 05:21:21 --> Config Class Initialized
INFO - 2017-03-11 05:21:21 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:21:21 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:21:21 --> Utf8 Class Initialized
INFO - 2017-03-11 05:21:21 --> URI Class Initialized
INFO - 2017-03-11 05:21:21 --> Router Class Initialized
INFO - 2017-03-11 05:21:21 --> Output Class Initialized
INFO - 2017-03-11 05:21:21 --> Security Class Initialized
DEBUG - 2017-03-11 05:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:21:21 --> Input Class Initialized
INFO - 2017-03-11 05:21:21 --> Language Class Initialized
INFO - 2017-03-11 05:21:21 --> Loader Class Initialized
INFO - 2017-03-11 05:21:22 --> Database Driver Class Initialized
INFO - 2017-03-11 05:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:21:22 --> Controller Class Initialized
INFO - 2017-03-11 05:21:22 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:21:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:21:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:21:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:21:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:21:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:21:22 --> Final output sent to browser
DEBUG - 2017-03-11 05:21:22 --> Total execution time: 2.5936
INFO - 2017-03-11 05:21:24 --> Config Class Initialized
INFO - 2017-03-11 05:21:24 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:21:24 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:21:24 --> Utf8 Class Initialized
INFO - 2017-03-11 05:21:24 --> URI Class Initialized
INFO - 2017-03-11 05:21:24 --> Router Class Initialized
INFO - 2017-03-11 05:21:24 --> Output Class Initialized
INFO - 2017-03-11 05:21:24 --> Security Class Initialized
DEBUG - 2017-03-11 05:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:21:24 --> Input Class Initialized
INFO - 2017-03-11 05:21:24 --> Language Class Initialized
INFO - 2017-03-11 05:21:24 --> Loader Class Initialized
INFO - 2017-03-11 05:21:24 --> Database Driver Class Initialized
INFO - 2017-03-11 05:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:21:24 --> Controller Class Initialized
INFO - 2017-03-11 05:21:24 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:21:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:21:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:21:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:21:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:21:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:21:24 --> Final output sent to browser
DEBUG - 2017-03-11 05:21:24 --> Total execution time: 0.0185
INFO - 2017-03-11 05:21:32 --> Config Class Initialized
INFO - 2017-03-11 05:21:32 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:21:32 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:21:33 --> Utf8 Class Initialized
INFO - 2017-03-11 05:21:33 --> URI Class Initialized
INFO - 2017-03-11 05:21:33 --> Router Class Initialized
INFO - 2017-03-11 05:21:33 --> Output Class Initialized
INFO - 2017-03-11 05:21:33 --> Security Class Initialized
DEBUG - 2017-03-11 05:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:21:33 --> Input Class Initialized
INFO - 2017-03-11 05:21:33 --> Language Class Initialized
INFO - 2017-03-11 05:21:33 --> Loader Class Initialized
INFO - 2017-03-11 05:21:33 --> Database Driver Class Initialized
INFO - 2017-03-11 05:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:21:34 --> Controller Class Initialized
INFO - 2017-03-11 05:21:34 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:21:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:21:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:21:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:21:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:21:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:21:34 --> Config Class Initialized
INFO - 2017-03-11 05:21:34 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:21:34 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:21:34 --> Utf8 Class Initialized
INFO - 2017-03-11 05:21:34 --> URI Class Initialized
INFO - 2017-03-11 05:21:34 --> Router Class Initialized
INFO - 2017-03-11 05:21:34 --> Output Class Initialized
INFO - 2017-03-11 05:21:34 --> Security Class Initialized
DEBUG - 2017-03-11 05:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:21:34 --> Input Class Initialized
INFO - 2017-03-11 05:21:34 --> Language Class Initialized
INFO - 2017-03-11 05:21:34 --> Loader Class Initialized
INFO - 2017-03-11 05:21:34 --> Database Driver Class Initialized
INFO - 2017-03-11 05:21:34 --> Final output sent to browser
DEBUG - 2017-03-11 05:21:34 --> Total execution time: 2.1226
INFO - 2017-03-11 05:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:21:34 --> Controller Class Initialized
INFO - 2017-03-11 05:21:34 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:21:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:21:35 --> Config Class Initialized
INFO - 2017-03-11 05:21:35 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:21:35 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:21:35 --> Utf8 Class Initialized
INFO - 2017-03-11 05:21:35 --> URI Class Initialized
INFO - 2017-03-11 05:21:35 --> Router Class Initialized
INFO - 2017-03-11 05:21:35 --> Output Class Initialized
INFO - 2017-03-11 05:21:35 --> Security Class Initialized
DEBUG - 2017-03-11 05:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:21:35 --> Input Class Initialized
INFO - 2017-03-11 05:21:35 --> Language Class Initialized
INFO - 2017-03-11 05:21:35 --> Loader Class Initialized
INFO - 2017-03-11 05:21:35 --> Database Driver Class Initialized
INFO - 2017-03-11 05:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:21:35 --> Controller Class Initialized
INFO - 2017-03-11 05:21:35 --> Helper loaded: date_helper
DEBUG - 2017-03-11 05:21:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:21:35 --> Helper loaded: url_helper
INFO - 2017-03-11 05:21:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:21:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 05:21:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 05:21:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 05:21:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:21:35 --> Final output sent to browser
DEBUG - 2017-03-11 05:21:35 --> Total execution time: 0.0930
INFO - 2017-03-11 05:21:36 --> Config Class Initialized
INFO - 2017-03-11 05:21:36 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:21:36 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:21:36 --> Utf8 Class Initialized
INFO - 2017-03-11 05:21:36 --> URI Class Initialized
INFO - 2017-03-11 05:21:36 --> Router Class Initialized
INFO - 2017-03-11 05:21:36 --> Output Class Initialized
INFO - 2017-03-11 05:21:36 --> Security Class Initialized
DEBUG - 2017-03-11 05:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:21:36 --> Input Class Initialized
INFO - 2017-03-11 05:21:36 --> Language Class Initialized
INFO - 2017-03-11 05:21:36 --> Loader Class Initialized
INFO - 2017-03-11 05:21:36 --> Database Driver Class Initialized
INFO - 2017-03-11 05:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:21:36 --> Controller Class Initialized
INFO - 2017-03-11 05:21:36 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:21:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:21:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:21:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:21:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:21:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:21:36 --> Final output sent to browser
DEBUG - 2017-03-11 05:21:36 --> Total execution time: 0.0139
INFO - 2017-03-11 05:36:36 --> Config Class Initialized
INFO - 2017-03-11 05:36:36 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:36:36 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:36:36 --> Utf8 Class Initialized
INFO - 2017-03-11 05:36:36 --> URI Class Initialized
DEBUG - 2017-03-11 05:36:36 --> No URI present. Default controller set.
INFO - 2017-03-11 05:36:36 --> Router Class Initialized
INFO - 2017-03-11 05:36:36 --> Output Class Initialized
INFO - 2017-03-11 05:36:36 --> Security Class Initialized
DEBUG - 2017-03-11 05:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:36:37 --> Input Class Initialized
INFO - 2017-03-11 05:36:37 --> Language Class Initialized
INFO - 2017-03-11 05:36:37 --> Loader Class Initialized
INFO - 2017-03-11 05:36:37 --> Database Driver Class Initialized
INFO - 2017-03-11 05:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:36:37 --> Controller Class Initialized
INFO - 2017-03-11 05:36:37 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:36:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:36:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:36:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:36:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:36:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:36:38 --> Final output sent to browser
DEBUG - 2017-03-11 05:36:38 --> Total execution time: 1.5126
INFO - 2017-03-11 05:37:23 --> Config Class Initialized
INFO - 2017-03-11 05:37:23 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:37:23 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:37:23 --> Utf8 Class Initialized
INFO - 2017-03-11 05:37:23 --> URI Class Initialized
INFO - 2017-03-11 05:37:23 --> Router Class Initialized
INFO - 2017-03-11 05:37:23 --> Output Class Initialized
INFO - 2017-03-11 05:37:23 --> Security Class Initialized
DEBUG - 2017-03-11 05:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:37:23 --> Input Class Initialized
INFO - 2017-03-11 05:37:23 --> Language Class Initialized
INFO - 2017-03-11 05:37:23 --> Loader Class Initialized
INFO - 2017-03-11 05:37:24 --> Database Driver Class Initialized
INFO - 2017-03-11 05:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:37:24 --> Controller Class Initialized
INFO - 2017-03-11 05:37:24 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:37:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-11 05:37:25 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-11 05:37:25 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-11 05:37:25 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-11 05:37:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:37:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:37:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:37:25 --> Final output sent to browser
DEBUG - 2017-03-11 05:37:25 --> Total execution time: 1.7902
INFO - 2017-03-11 05:38:13 --> Config Class Initialized
INFO - 2017-03-11 05:38:13 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:38:13 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:38:13 --> Utf8 Class Initialized
INFO - 2017-03-11 05:38:13 --> URI Class Initialized
DEBUG - 2017-03-11 05:38:13 --> No URI present. Default controller set.
INFO - 2017-03-11 05:38:13 --> Router Class Initialized
INFO - 2017-03-11 05:38:13 --> Output Class Initialized
INFO - 2017-03-11 05:38:13 --> Security Class Initialized
DEBUG - 2017-03-11 05:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:38:13 --> Input Class Initialized
INFO - 2017-03-11 05:38:13 --> Language Class Initialized
INFO - 2017-03-11 05:38:13 --> Loader Class Initialized
INFO - 2017-03-11 05:38:13 --> Database Driver Class Initialized
INFO - 2017-03-11 05:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:38:13 --> Controller Class Initialized
INFO - 2017-03-11 05:38:13 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:38:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:38:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:38:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:38:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:38:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:38:13 --> Final output sent to browser
DEBUG - 2017-03-11 05:38:13 --> Total execution time: 0.0243
INFO - 2017-03-11 05:38:21 --> Config Class Initialized
INFO - 2017-03-11 05:38:21 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:38:21 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:38:21 --> Utf8 Class Initialized
INFO - 2017-03-11 05:38:21 --> URI Class Initialized
INFO - 2017-03-11 05:38:21 --> Router Class Initialized
INFO - 2017-03-11 05:38:21 --> Output Class Initialized
INFO - 2017-03-11 05:38:21 --> Security Class Initialized
DEBUG - 2017-03-11 05:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:38:21 --> Input Class Initialized
INFO - 2017-03-11 05:38:21 --> Language Class Initialized
INFO - 2017-03-11 05:38:21 --> Loader Class Initialized
INFO - 2017-03-11 05:38:21 --> Database Driver Class Initialized
INFO - 2017-03-11 05:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:38:21 --> Controller Class Initialized
INFO - 2017-03-11 05:38:21 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:38:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:38:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:38:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:38:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:38:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:38:21 --> Final output sent to browser
DEBUG - 2017-03-11 05:38:21 --> Total execution time: 0.0138
INFO - 2017-03-11 05:38:31 --> Config Class Initialized
INFO - 2017-03-11 05:38:31 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:38:31 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:38:31 --> Utf8 Class Initialized
INFO - 2017-03-11 05:38:31 --> URI Class Initialized
INFO - 2017-03-11 05:38:31 --> Router Class Initialized
INFO - 2017-03-11 05:38:31 --> Output Class Initialized
INFO - 2017-03-11 05:38:31 --> Security Class Initialized
DEBUG - 2017-03-11 05:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:38:31 --> Input Class Initialized
INFO - 2017-03-11 05:38:31 --> Language Class Initialized
INFO - 2017-03-11 05:38:31 --> Loader Class Initialized
INFO - 2017-03-11 05:38:31 --> Database Driver Class Initialized
INFO - 2017-03-11 05:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:38:31 --> Controller Class Initialized
INFO - 2017-03-11 05:38:31 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:38:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-11 05:38:32 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-11 05:38:32 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Janeth Femat García')
INFO - 2017-03-11 05:38:32 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-11 05:38:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-11 05:38:33 --> Config Class Initialized
INFO - 2017-03-11 05:38:33 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:38:33 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:38:33 --> Utf8 Class Initialized
INFO - 2017-03-11 05:38:33 --> URI Class Initialized
INFO - 2017-03-11 05:38:33 --> Router Class Initialized
INFO - 2017-03-11 05:38:33 --> Output Class Initialized
INFO - 2017-03-11 05:38:33 --> Security Class Initialized
DEBUG - 2017-03-11 05:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:38:33 --> Input Class Initialized
INFO - 2017-03-11 05:38:33 --> Language Class Initialized
INFO - 2017-03-11 05:38:33 --> Loader Class Initialized
INFO - 2017-03-11 05:38:33 --> Database Driver Class Initialized
INFO - 2017-03-11 05:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:38:33 --> Controller Class Initialized
INFO - 2017-03-11 05:38:33 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:38:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:38:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:38:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:38:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:38:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:38:33 --> Final output sent to browser
DEBUG - 2017-03-11 05:38:33 --> Total execution time: 0.0138
INFO - 2017-03-11 05:39:12 --> Config Class Initialized
INFO - 2017-03-11 05:39:12 --> Config Class Initialized
INFO - 2017-03-11 05:39:12 --> Hooks Class Initialized
INFO - 2017-03-11 05:39:12 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:39:12 --> UTF-8 Support Enabled
DEBUG - 2017-03-11 05:39:12 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:39:12 --> Utf8 Class Initialized
INFO - 2017-03-11 05:39:12 --> Utf8 Class Initialized
INFO - 2017-03-11 05:39:12 --> URI Class Initialized
INFO - 2017-03-11 05:39:12 --> URI Class Initialized
INFO - 2017-03-11 05:39:12 --> Router Class Initialized
INFO - 2017-03-11 05:39:12 --> Router Class Initialized
INFO - 2017-03-11 05:39:12 --> Output Class Initialized
INFO - 2017-03-11 05:39:12 --> Output Class Initialized
INFO - 2017-03-11 05:39:12 --> Security Class Initialized
INFO - 2017-03-11 05:39:12 --> Security Class Initialized
DEBUG - 2017-03-11 05:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:39:12 --> Input Class Initialized
INFO - 2017-03-11 05:39:12 --> Language Class Initialized
DEBUG - 2017-03-11 05:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:39:12 --> Input Class Initialized
INFO - 2017-03-11 05:39:12 --> Language Class Initialized
INFO - 2017-03-11 05:39:12 --> Loader Class Initialized
INFO - 2017-03-11 05:39:13 --> Loader Class Initialized
INFO - 2017-03-11 05:39:13 --> Database Driver Class Initialized
INFO - 2017-03-11 05:39:13 --> Database Driver Class Initialized
INFO - 2017-03-11 05:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:39:13 --> Controller Class Initialized
INFO - 2017-03-11 05:39:13 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:39:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-11 05:39:15 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-11 05:39:15 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Janeth Femat García')
INFO - 2017-03-11 05:39:15 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-11 05:39:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-11 05:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:39:15 --> Controller Class Initialized
INFO - 2017-03-11 05:39:15 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:39:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-11 05:39:15 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-11 05:39:15 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Janeth Femat García')
INFO - 2017-03-11 05:39:15 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-11 05:39:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-11 05:39:17 --> Config Class Initialized
INFO - 2017-03-11 05:39:17 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:39:17 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:39:17 --> Utf8 Class Initialized
INFO - 2017-03-11 05:39:17 --> URI Class Initialized
INFO - 2017-03-11 05:39:17 --> Router Class Initialized
INFO - 2017-03-11 05:39:17 --> Output Class Initialized
INFO - 2017-03-11 05:39:17 --> Security Class Initialized
DEBUG - 2017-03-11 05:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:39:17 --> Input Class Initialized
INFO - 2017-03-11 05:39:17 --> Language Class Initialized
INFO - 2017-03-11 05:39:17 --> Loader Class Initialized
INFO - 2017-03-11 05:39:17 --> Database Driver Class Initialized
INFO - 2017-03-11 05:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:39:17 --> Controller Class Initialized
INFO - 2017-03-11 05:39:17 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:39:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:39:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:39:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:39:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:39:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:39:17 --> Final output sent to browser
DEBUG - 2017-03-11 05:39:17 --> Total execution time: 0.1690
INFO - 2017-03-11 05:39:20 --> Config Class Initialized
INFO - 2017-03-11 05:39:20 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:39:20 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:39:20 --> Utf8 Class Initialized
INFO - 2017-03-11 05:39:20 --> URI Class Initialized
DEBUG - 2017-03-11 05:39:20 --> No URI present. Default controller set.
INFO - 2017-03-11 05:39:20 --> Router Class Initialized
INFO - 2017-03-11 05:39:20 --> Output Class Initialized
INFO - 2017-03-11 05:39:20 --> Security Class Initialized
DEBUG - 2017-03-11 05:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:39:20 --> Input Class Initialized
INFO - 2017-03-11 05:39:20 --> Language Class Initialized
INFO - 2017-03-11 05:39:20 --> Loader Class Initialized
INFO - 2017-03-11 05:39:20 --> Database Driver Class Initialized
INFO - 2017-03-11 05:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:39:20 --> Controller Class Initialized
INFO - 2017-03-11 05:39:20 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:39:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:39:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:39:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:39:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:39:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:39:20 --> Final output sent to browser
DEBUG - 2017-03-11 05:39:20 --> Total execution time: 0.0138
INFO - 2017-03-11 05:39:22 --> Config Class Initialized
INFO - 2017-03-11 05:39:22 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:39:22 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:39:22 --> Utf8 Class Initialized
INFO - 2017-03-11 05:39:22 --> URI Class Initialized
INFO - 2017-03-11 05:39:22 --> Router Class Initialized
INFO - 2017-03-11 05:39:22 --> Output Class Initialized
INFO - 2017-03-11 05:39:22 --> Security Class Initialized
DEBUG - 2017-03-11 05:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:39:22 --> Input Class Initialized
INFO - 2017-03-11 05:39:22 --> Language Class Initialized
INFO - 2017-03-11 05:39:22 --> Loader Class Initialized
INFO - 2017-03-11 05:39:22 --> Database Driver Class Initialized
INFO - 2017-03-11 05:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:39:22 --> Controller Class Initialized
INFO - 2017-03-11 05:39:22 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:39:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:39:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:39:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:39:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:39:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:39:22 --> Final output sent to browser
DEBUG - 2017-03-11 05:39:22 --> Total execution time: 0.0147
INFO - 2017-03-11 05:39:44 --> Config Class Initialized
INFO - 2017-03-11 05:39:44 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:39:44 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:39:44 --> Utf8 Class Initialized
INFO - 2017-03-11 05:39:44 --> URI Class Initialized
INFO - 2017-03-11 05:39:44 --> Router Class Initialized
INFO - 2017-03-11 05:39:44 --> Output Class Initialized
INFO - 2017-03-11 05:39:44 --> Security Class Initialized
DEBUG - 2017-03-11 05:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:39:44 --> Input Class Initialized
INFO - 2017-03-11 05:39:44 --> Language Class Initialized
INFO - 2017-03-11 05:39:44 --> Loader Class Initialized
INFO - 2017-03-11 05:39:44 --> Database Driver Class Initialized
INFO - 2017-03-11 05:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:39:44 --> Controller Class Initialized
INFO - 2017-03-11 05:39:44 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:39:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-11 05:39:45 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-11 05:39:45 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Janeth Femat García')
INFO - 2017-03-11 05:39:45 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-11 05:39:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-11 05:39:46 --> Config Class Initialized
INFO - 2017-03-11 05:39:46 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:39:46 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:39:46 --> Utf8 Class Initialized
INFO - 2017-03-11 05:39:46 --> URI Class Initialized
INFO - 2017-03-11 05:39:46 --> Router Class Initialized
INFO - 2017-03-11 05:39:46 --> Output Class Initialized
INFO - 2017-03-11 05:39:46 --> Security Class Initialized
DEBUG - 2017-03-11 05:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:39:46 --> Input Class Initialized
INFO - 2017-03-11 05:39:46 --> Language Class Initialized
INFO - 2017-03-11 05:39:46 --> Loader Class Initialized
INFO - 2017-03-11 05:39:46 --> Database Driver Class Initialized
INFO - 2017-03-11 05:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:39:46 --> Controller Class Initialized
INFO - 2017-03-11 05:39:46 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:39:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:39:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:39:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:39:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:39:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:39:46 --> Final output sent to browser
DEBUG - 2017-03-11 05:39:46 --> Total execution time: 0.0149
INFO - 2017-03-11 05:39:51 --> Config Class Initialized
INFO - 2017-03-11 05:39:51 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:39:51 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:39:51 --> Utf8 Class Initialized
INFO - 2017-03-11 05:39:51 --> URI Class Initialized
DEBUG - 2017-03-11 05:39:51 --> No URI present. Default controller set.
INFO - 2017-03-11 05:39:51 --> Router Class Initialized
INFO - 2017-03-11 05:39:51 --> Output Class Initialized
INFO - 2017-03-11 05:39:51 --> Security Class Initialized
DEBUG - 2017-03-11 05:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:39:51 --> Input Class Initialized
INFO - 2017-03-11 05:39:51 --> Language Class Initialized
INFO - 2017-03-11 05:39:51 --> Loader Class Initialized
INFO - 2017-03-11 05:39:51 --> Database Driver Class Initialized
INFO - 2017-03-11 05:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:39:51 --> Controller Class Initialized
INFO - 2017-03-11 05:39:51 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:39:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:39:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:39:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:39:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:39:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:39:51 --> Final output sent to browser
DEBUG - 2017-03-11 05:39:51 --> Total execution time: 0.0131
INFO - 2017-03-11 05:39:53 --> Config Class Initialized
INFO - 2017-03-11 05:39:53 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:39:53 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:39:53 --> Utf8 Class Initialized
INFO - 2017-03-11 05:39:53 --> URI Class Initialized
INFO - 2017-03-11 05:39:53 --> Router Class Initialized
INFO - 2017-03-11 05:39:53 --> Output Class Initialized
INFO - 2017-03-11 05:39:53 --> Security Class Initialized
DEBUG - 2017-03-11 05:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:39:53 --> Input Class Initialized
INFO - 2017-03-11 05:39:53 --> Language Class Initialized
INFO - 2017-03-11 05:39:53 --> Loader Class Initialized
INFO - 2017-03-11 05:39:53 --> Database Driver Class Initialized
INFO - 2017-03-11 05:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:39:53 --> Controller Class Initialized
INFO - 2017-03-11 05:39:53 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:39:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:39:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:39:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:39:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:39:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:39:53 --> Final output sent to browser
DEBUG - 2017-03-11 05:39:53 --> Total execution time: 0.0133
INFO - 2017-03-11 05:41:12 --> Config Class Initialized
INFO - 2017-03-11 05:41:12 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:41:12 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:41:12 --> Utf8 Class Initialized
INFO - 2017-03-11 05:41:12 --> URI Class Initialized
INFO - 2017-03-11 05:41:12 --> Router Class Initialized
INFO - 2017-03-11 05:41:12 --> Output Class Initialized
INFO - 2017-03-11 05:41:12 --> Security Class Initialized
DEBUG - 2017-03-11 05:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:41:12 --> Input Class Initialized
INFO - 2017-03-11 05:41:12 --> Language Class Initialized
INFO - 2017-03-11 05:41:12 --> Loader Class Initialized
INFO - 2017-03-11 05:41:13 --> Database Driver Class Initialized
INFO - 2017-03-11 05:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:41:13 --> Controller Class Initialized
INFO - 2017-03-11 05:41:13 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:41:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:41:14 --> Config Class Initialized
INFO - 2017-03-11 05:41:14 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:41:14 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:41:14 --> Utf8 Class Initialized
INFO - 2017-03-11 05:41:14 --> URI Class Initialized
INFO - 2017-03-11 05:41:14 --> Router Class Initialized
INFO - 2017-03-11 05:41:14 --> Output Class Initialized
INFO - 2017-03-11 05:41:14 --> Security Class Initialized
DEBUG - 2017-03-11 05:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:41:14 --> Input Class Initialized
INFO - 2017-03-11 05:41:14 --> Language Class Initialized
INFO - 2017-03-11 05:41:14 --> Loader Class Initialized
INFO - 2017-03-11 05:41:14 --> Database Driver Class Initialized
INFO - 2017-03-11 05:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:41:14 --> Controller Class Initialized
INFO - 2017-03-11 05:41:14 --> Helper loaded: date_helper
DEBUG - 2017-03-11 05:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:41:14 --> Helper loaded: url_helper
INFO - 2017-03-11 05:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 05:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 05:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 05:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:41:14 --> Final output sent to browser
DEBUG - 2017-03-11 05:41:14 --> Total execution time: 0.1080
INFO - 2017-03-11 05:41:15 --> Config Class Initialized
INFO - 2017-03-11 05:41:15 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:41:15 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:41:15 --> Utf8 Class Initialized
INFO - 2017-03-11 05:41:15 --> URI Class Initialized
INFO - 2017-03-11 05:41:15 --> Router Class Initialized
INFO - 2017-03-11 05:41:15 --> Output Class Initialized
INFO - 2017-03-11 05:41:15 --> Security Class Initialized
DEBUG - 2017-03-11 05:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:41:15 --> Input Class Initialized
INFO - 2017-03-11 05:41:15 --> Language Class Initialized
INFO - 2017-03-11 05:41:15 --> Loader Class Initialized
INFO - 2017-03-11 05:41:15 --> Database Driver Class Initialized
INFO - 2017-03-11 05:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:41:15 --> Controller Class Initialized
INFO - 2017-03-11 05:41:15 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:41:15 --> Final output sent to browser
DEBUG - 2017-03-11 05:41:15 --> Total execution time: 0.0309
INFO - 2017-03-11 05:41:42 --> Config Class Initialized
INFO - 2017-03-11 05:41:42 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:41:42 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:41:42 --> Utf8 Class Initialized
INFO - 2017-03-11 05:41:42 --> URI Class Initialized
DEBUG - 2017-03-11 05:41:42 --> No URI present. Default controller set.
INFO - 2017-03-11 05:41:42 --> Router Class Initialized
INFO - 2017-03-11 05:41:42 --> Output Class Initialized
INFO - 2017-03-11 05:41:42 --> Security Class Initialized
DEBUG - 2017-03-11 05:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:41:42 --> Input Class Initialized
INFO - 2017-03-11 05:41:42 --> Language Class Initialized
INFO - 2017-03-11 05:41:42 --> Loader Class Initialized
INFO - 2017-03-11 05:41:42 --> Database Driver Class Initialized
INFO - 2017-03-11 05:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:41:42 --> Controller Class Initialized
INFO - 2017-03-11 05:41:42 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:41:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:41:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:41:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:41:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:41:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:41:42 --> Final output sent to browser
DEBUG - 2017-03-11 05:41:42 --> Total execution time: 0.0135
INFO - 2017-03-11 05:41:43 --> Config Class Initialized
INFO - 2017-03-11 05:41:43 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:41:43 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:41:43 --> Utf8 Class Initialized
INFO - 2017-03-11 05:41:43 --> URI Class Initialized
INFO - 2017-03-11 05:41:43 --> Router Class Initialized
INFO - 2017-03-11 05:41:43 --> Output Class Initialized
INFO - 2017-03-11 05:41:43 --> Security Class Initialized
DEBUG - 2017-03-11 05:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:41:43 --> Input Class Initialized
INFO - 2017-03-11 05:41:43 --> Language Class Initialized
INFO - 2017-03-11 05:41:43 --> Loader Class Initialized
INFO - 2017-03-11 05:41:43 --> Database Driver Class Initialized
INFO - 2017-03-11 05:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:41:43 --> Controller Class Initialized
INFO - 2017-03-11 05:41:43 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:41:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:41:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:41:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:41:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:41:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:41:43 --> Final output sent to browser
DEBUG - 2017-03-11 05:41:43 --> Total execution time: 0.0139
INFO - 2017-03-11 05:41:46 --> Config Class Initialized
INFO - 2017-03-11 05:41:46 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:41:46 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:41:46 --> Utf8 Class Initialized
INFO - 2017-03-11 05:41:46 --> URI Class Initialized
INFO - 2017-03-11 05:41:46 --> Router Class Initialized
INFO - 2017-03-11 05:41:46 --> Output Class Initialized
INFO - 2017-03-11 05:41:46 --> Security Class Initialized
DEBUG - 2017-03-11 05:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:41:46 --> Input Class Initialized
INFO - 2017-03-11 05:41:46 --> Language Class Initialized
INFO - 2017-03-11 05:41:46 --> Loader Class Initialized
INFO - 2017-03-11 05:41:46 --> Database Driver Class Initialized
INFO - 2017-03-11 05:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:41:46 --> Controller Class Initialized
INFO - 2017-03-11 05:41:46 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:41:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:41:46 --> Config Class Initialized
INFO - 2017-03-11 05:41:46 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:41:46 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:41:46 --> Utf8 Class Initialized
INFO - 2017-03-11 05:41:46 --> URI Class Initialized
INFO - 2017-03-11 05:41:46 --> Router Class Initialized
INFO - 2017-03-11 05:41:46 --> Output Class Initialized
INFO - 2017-03-11 05:41:46 --> Security Class Initialized
DEBUG - 2017-03-11 05:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:41:46 --> Input Class Initialized
INFO - 2017-03-11 05:41:46 --> Language Class Initialized
INFO - 2017-03-11 05:41:46 --> Loader Class Initialized
INFO - 2017-03-11 05:41:46 --> Database Driver Class Initialized
INFO - 2017-03-11 05:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:41:46 --> Controller Class Initialized
INFO - 2017-03-11 05:41:46 --> Helper loaded: date_helper
DEBUG - 2017-03-11 05:41:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:41:46 --> Helper loaded: url_helper
INFO - 2017-03-11 05:41:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:41:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 05:41:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 05:41:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 05:41:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:41:46 --> Final output sent to browser
DEBUG - 2017-03-11 05:41:46 --> Total execution time: 0.0156
INFO - 2017-03-11 05:41:47 --> Config Class Initialized
INFO - 2017-03-11 05:41:47 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:41:47 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:41:47 --> Utf8 Class Initialized
INFO - 2017-03-11 05:41:47 --> URI Class Initialized
INFO - 2017-03-11 05:41:47 --> Router Class Initialized
INFO - 2017-03-11 05:41:47 --> Output Class Initialized
INFO - 2017-03-11 05:41:47 --> Security Class Initialized
DEBUG - 2017-03-11 05:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:41:47 --> Input Class Initialized
INFO - 2017-03-11 05:41:47 --> Language Class Initialized
INFO - 2017-03-11 05:41:47 --> Loader Class Initialized
INFO - 2017-03-11 05:41:47 --> Database Driver Class Initialized
INFO - 2017-03-11 05:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:41:47 --> Controller Class Initialized
INFO - 2017-03-11 05:41:47 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:41:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:41:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:41:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:41:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:41:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:41:47 --> Final output sent to browser
DEBUG - 2017-03-11 05:41:47 --> Total execution time: 0.0138
INFO - 2017-03-11 05:41:52 --> Config Class Initialized
INFO - 2017-03-11 05:41:52 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:41:52 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:41:52 --> Utf8 Class Initialized
INFO - 2017-03-11 05:41:52 --> URI Class Initialized
DEBUG - 2017-03-11 05:41:52 --> No URI present. Default controller set.
INFO - 2017-03-11 05:41:52 --> Router Class Initialized
INFO - 2017-03-11 05:41:52 --> Output Class Initialized
INFO - 2017-03-11 05:41:52 --> Security Class Initialized
DEBUG - 2017-03-11 05:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:41:52 --> Input Class Initialized
INFO - 2017-03-11 05:41:52 --> Language Class Initialized
INFO - 2017-03-11 05:41:52 --> Loader Class Initialized
INFO - 2017-03-11 05:41:52 --> Database Driver Class Initialized
INFO - 2017-03-11 05:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:41:52 --> Controller Class Initialized
INFO - 2017-03-11 05:41:52 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:41:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:41:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:41:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:41:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:41:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:41:52 --> Final output sent to browser
DEBUG - 2017-03-11 05:41:52 --> Total execution time: 0.0652
INFO - 2017-03-11 05:41:54 --> Config Class Initialized
INFO - 2017-03-11 05:41:54 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:41:54 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:41:54 --> Utf8 Class Initialized
INFO - 2017-03-11 05:41:54 --> URI Class Initialized
INFO - 2017-03-11 05:41:54 --> Router Class Initialized
INFO - 2017-03-11 05:41:54 --> Output Class Initialized
INFO - 2017-03-11 05:41:54 --> Security Class Initialized
DEBUG - 2017-03-11 05:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:41:54 --> Input Class Initialized
INFO - 2017-03-11 05:41:54 --> Language Class Initialized
INFO - 2017-03-11 05:41:54 --> Loader Class Initialized
INFO - 2017-03-11 05:41:54 --> Database Driver Class Initialized
INFO - 2017-03-11 05:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:41:54 --> Controller Class Initialized
INFO - 2017-03-11 05:41:54 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:41:54 --> Final output sent to browser
DEBUG - 2017-03-11 05:41:54 --> Total execution time: 0.0137
INFO - 2017-03-11 05:41:57 --> Config Class Initialized
INFO - 2017-03-11 05:41:57 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:41:57 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:41:57 --> Utf8 Class Initialized
INFO - 2017-03-11 05:41:57 --> URI Class Initialized
INFO - 2017-03-11 05:41:57 --> Router Class Initialized
INFO - 2017-03-11 05:41:57 --> Output Class Initialized
INFO - 2017-03-11 05:41:57 --> Security Class Initialized
DEBUG - 2017-03-11 05:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:41:57 --> Input Class Initialized
INFO - 2017-03-11 05:41:57 --> Language Class Initialized
INFO - 2017-03-11 05:41:57 --> Loader Class Initialized
INFO - 2017-03-11 05:41:57 --> Database Driver Class Initialized
INFO - 2017-03-11 05:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:41:57 --> Controller Class Initialized
INFO - 2017-03-11 05:41:57 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:41:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-11 05:41:58 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-11 05:41:58 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Janeth Femat García')
INFO - 2017-03-11 05:41:58 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-11 05:41:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-11 05:41:58 --> Config Class Initialized
INFO - 2017-03-11 05:41:58 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:41:58 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:41:58 --> Utf8 Class Initialized
INFO - 2017-03-11 05:41:58 --> URI Class Initialized
INFO - 2017-03-11 05:41:58 --> Router Class Initialized
INFO - 2017-03-11 05:41:58 --> Output Class Initialized
INFO - 2017-03-11 05:41:58 --> Security Class Initialized
DEBUG - 2017-03-11 05:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:41:58 --> Input Class Initialized
INFO - 2017-03-11 05:41:58 --> Language Class Initialized
INFO - 2017-03-11 05:41:58 --> Loader Class Initialized
INFO - 2017-03-11 05:41:58 --> Database Driver Class Initialized
INFO - 2017-03-11 05:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:41:58 --> Controller Class Initialized
INFO - 2017-03-11 05:41:58 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:41:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:41:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:41:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:41:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:41:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:41:58 --> Final output sent to browser
DEBUG - 2017-03-11 05:41:58 --> Total execution time: 0.0136
INFO - 2017-03-11 05:42:02 --> Config Class Initialized
INFO - 2017-03-11 05:42:02 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:42:02 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:42:02 --> Utf8 Class Initialized
INFO - 2017-03-11 05:42:02 --> URI Class Initialized
DEBUG - 2017-03-11 05:42:02 --> No URI present. Default controller set.
INFO - 2017-03-11 05:42:02 --> Router Class Initialized
INFO - 2017-03-11 05:42:02 --> Output Class Initialized
INFO - 2017-03-11 05:42:02 --> Security Class Initialized
DEBUG - 2017-03-11 05:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:42:02 --> Input Class Initialized
INFO - 2017-03-11 05:42:02 --> Language Class Initialized
INFO - 2017-03-11 05:42:02 --> Loader Class Initialized
INFO - 2017-03-11 05:42:02 --> Database Driver Class Initialized
INFO - 2017-03-11 05:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:42:02 --> Controller Class Initialized
INFO - 2017-03-11 05:42:02 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:42:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:42:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:42:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:42:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:42:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:42:02 --> Final output sent to browser
DEBUG - 2017-03-11 05:42:02 --> Total execution time: 0.0134
INFO - 2017-03-11 05:42:04 --> Config Class Initialized
INFO - 2017-03-11 05:42:04 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:42:04 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:42:04 --> Utf8 Class Initialized
INFO - 2017-03-11 05:42:04 --> URI Class Initialized
INFO - 2017-03-11 05:42:04 --> Router Class Initialized
INFO - 2017-03-11 05:42:04 --> Output Class Initialized
INFO - 2017-03-11 05:42:04 --> Security Class Initialized
DEBUG - 2017-03-11 05:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:42:04 --> Input Class Initialized
INFO - 2017-03-11 05:42:04 --> Language Class Initialized
INFO - 2017-03-11 05:42:04 --> Loader Class Initialized
INFO - 2017-03-11 05:42:04 --> Database Driver Class Initialized
INFO - 2017-03-11 05:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:42:04 --> Controller Class Initialized
INFO - 2017-03-11 05:42:04 --> Helper loaded: date_helper
DEBUG - 2017-03-11 05:42:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:42:04 --> Helper loaded: url_helper
INFO - 2017-03-11 05:42:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:42:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 05:42:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 05:42:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 05:42:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:42:04 --> Final output sent to browser
DEBUG - 2017-03-11 05:42:04 --> Total execution time: 0.0147
INFO - 2017-03-11 05:42:04 --> Config Class Initialized
INFO - 2017-03-11 05:42:04 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:42:04 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:42:04 --> Utf8 Class Initialized
INFO - 2017-03-11 05:42:04 --> URI Class Initialized
INFO - 2017-03-11 05:42:04 --> Router Class Initialized
INFO - 2017-03-11 05:42:04 --> Output Class Initialized
INFO - 2017-03-11 05:42:04 --> Security Class Initialized
DEBUG - 2017-03-11 05:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:42:04 --> Input Class Initialized
INFO - 2017-03-11 05:42:04 --> Language Class Initialized
INFO - 2017-03-11 05:42:04 --> Loader Class Initialized
INFO - 2017-03-11 05:42:04 --> Database Driver Class Initialized
INFO - 2017-03-11 05:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:42:04 --> Controller Class Initialized
INFO - 2017-03-11 05:42:04 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:42:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:42:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:42:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:42:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:42:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:42:04 --> Final output sent to browser
DEBUG - 2017-03-11 05:42:04 --> Total execution time: 0.0138
INFO - 2017-03-11 05:42:06 --> Config Class Initialized
INFO - 2017-03-11 05:42:06 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:42:06 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:42:06 --> Utf8 Class Initialized
INFO - 2017-03-11 05:42:06 --> URI Class Initialized
DEBUG - 2017-03-11 05:42:06 --> No URI present. Default controller set.
INFO - 2017-03-11 05:42:06 --> Router Class Initialized
INFO - 2017-03-11 05:42:06 --> Output Class Initialized
INFO - 2017-03-11 05:42:06 --> Security Class Initialized
DEBUG - 2017-03-11 05:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:42:06 --> Input Class Initialized
INFO - 2017-03-11 05:42:06 --> Language Class Initialized
INFO - 2017-03-11 05:42:06 --> Loader Class Initialized
INFO - 2017-03-11 05:42:06 --> Database Driver Class Initialized
INFO - 2017-03-11 05:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:42:06 --> Controller Class Initialized
INFO - 2017-03-11 05:42:06 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:42:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:42:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:42:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:42:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:42:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:42:06 --> Final output sent to browser
DEBUG - 2017-03-11 05:42:06 --> Total execution time: 0.0140
INFO - 2017-03-11 05:42:07 --> Config Class Initialized
INFO - 2017-03-11 05:42:07 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:42:07 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:42:07 --> Utf8 Class Initialized
INFO - 2017-03-11 05:42:07 --> URI Class Initialized
INFO - 2017-03-11 05:42:07 --> Router Class Initialized
INFO - 2017-03-11 05:42:07 --> Output Class Initialized
INFO - 2017-03-11 05:42:07 --> Security Class Initialized
DEBUG - 2017-03-11 05:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:42:07 --> Input Class Initialized
INFO - 2017-03-11 05:42:07 --> Language Class Initialized
INFO - 2017-03-11 05:42:07 --> Loader Class Initialized
INFO - 2017-03-11 05:42:07 --> Database Driver Class Initialized
INFO - 2017-03-11 05:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:42:07 --> Controller Class Initialized
INFO - 2017-03-11 05:42:07 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:42:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:42:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:42:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:42:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:42:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:42:07 --> Final output sent to browser
DEBUG - 2017-03-11 05:42:07 --> Total execution time: 0.0136
INFO - 2017-03-11 05:42:11 --> Config Class Initialized
INFO - 2017-03-11 05:42:11 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:42:11 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:42:11 --> Utf8 Class Initialized
INFO - 2017-03-11 05:42:11 --> URI Class Initialized
INFO - 2017-03-11 05:42:11 --> Router Class Initialized
INFO - 2017-03-11 05:42:11 --> Output Class Initialized
INFO - 2017-03-11 05:42:11 --> Security Class Initialized
DEBUG - 2017-03-11 05:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:42:11 --> Input Class Initialized
INFO - 2017-03-11 05:42:11 --> Language Class Initialized
INFO - 2017-03-11 05:42:11 --> Loader Class Initialized
INFO - 2017-03-11 05:42:11 --> Database Driver Class Initialized
INFO - 2017-03-11 05:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:42:11 --> Controller Class Initialized
INFO - 2017-03-11 05:42:11 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:42:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:42:12 --> Config Class Initialized
INFO - 2017-03-11 05:42:12 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:42:12 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:42:12 --> Utf8 Class Initialized
INFO - 2017-03-11 05:42:12 --> URI Class Initialized
INFO - 2017-03-11 05:42:12 --> Router Class Initialized
INFO - 2017-03-11 05:42:12 --> Output Class Initialized
INFO - 2017-03-11 05:42:12 --> Security Class Initialized
DEBUG - 2017-03-11 05:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:42:12 --> Input Class Initialized
INFO - 2017-03-11 05:42:12 --> Language Class Initialized
INFO - 2017-03-11 05:42:12 --> Loader Class Initialized
INFO - 2017-03-11 05:42:12 --> Database Driver Class Initialized
INFO - 2017-03-11 05:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:42:12 --> Controller Class Initialized
INFO - 2017-03-11 05:42:12 --> Helper loaded: date_helper
DEBUG - 2017-03-11 05:42:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:42:12 --> Helper loaded: url_helper
INFO - 2017-03-11 05:42:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:42:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 05:42:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 05:42:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 05:42:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:42:12 --> Final output sent to browser
DEBUG - 2017-03-11 05:42:12 --> Total execution time: 0.0146
INFO - 2017-03-11 05:42:12 --> Config Class Initialized
INFO - 2017-03-11 05:42:12 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:42:12 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:42:12 --> Utf8 Class Initialized
INFO - 2017-03-11 05:42:12 --> URI Class Initialized
INFO - 2017-03-11 05:42:12 --> Router Class Initialized
INFO - 2017-03-11 05:42:12 --> Output Class Initialized
INFO - 2017-03-11 05:42:12 --> Security Class Initialized
DEBUG - 2017-03-11 05:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:42:12 --> Input Class Initialized
INFO - 2017-03-11 05:42:12 --> Language Class Initialized
INFO - 2017-03-11 05:42:12 --> Loader Class Initialized
INFO - 2017-03-11 05:42:12 --> Database Driver Class Initialized
INFO - 2017-03-11 05:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:42:12 --> Controller Class Initialized
INFO - 2017-03-11 05:42:12 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:42:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:42:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:42:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:42:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:42:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:42:12 --> Final output sent to browser
DEBUG - 2017-03-11 05:42:12 --> Total execution time: 0.0143
INFO - 2017-03-11 05:42:21 --> Config Class Initialized
INFO - 2017-03-11 05:42:21 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:42:21 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:42:21 --> Utf8 Class Initialized
INFO - 2017-03-11 05:42:21 --> URI Class Initialized
DEBUG - 2017-03-11 05:42:21 --> No URI present. Default controller set.
INFO - 2017-03-11 05:42:21 --> Router Class Initialized
INFO - 2017-03-11 05:42:21 --> Output Class Initialized
INFO - 2017-03-11 05:42:21 --> Security Class Initialized
DEBUG - 2017-03-11 05:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:42:21 --> Input Class Initialized
INFO - 2017-03-11 05:42:21 --> Language Class Initialized
INFO - 2017-03-11 05:42:21 --> Loader Class Initialized
INFO - 2017-03-11 05:42:21 --> Database Driver Class Initialized
INFO - 2017-03-11 05:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:42:21 --> Controller Class Initialized
INFO - 2017-03-11 05:42:21 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:42:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:42:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:42:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:42:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:42:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:42:21 --> Final output sent to browser
DEBUG - 2017-03-11 05:42:21 --> Total execution time: 0.0141
INFO - 2017-03-11 05:42:24 --> Config Class Initialized
INFO - 2017-03-11 05:42:24 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:42:24 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:42:24 --> Utf8 Class Initialized
INFO - 2017-03-11 05:42:24 --> URI Class Initialized
INFO - 2017-03-11 05:42:24 --> Router Class Initialized
INFO - 2017-03-11 05:42:24 --> Output Class Initialized
INFO - 2017-03-11 05:42:24 --> Security Class Initialized
DEBUG - 2017-03-11 05:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:42:24 --> Input Class Initialized
INFO - 2017-03-11 05:42:24 --> Language Class Initialized
INFO - 2017-03-11 05:42:24 --> Loader Class Initialized
INFO - 2017-03-11 05:42:24 --> Database Driver Class Initialized
INFO - 2017-03-11 05:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:42:24 --> Controller Class Initialized
INFO - 2017-03-11 05:42:24 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:42:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:42:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:42:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:42:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:42:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:42:24 --> Final output sent to browser
DEBUG - 2017-03-11 05:42:24 --> Total execution time: 0.0138
INFO - 2017-03-11 05:42:34 --> Config Class Initialized
INFO - 2017-03-11 05:42:34 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:42:34 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:42:34 --> Utf8 Class Initialized
INFO - 2017-03-11 05:42:34 --> URI Class Initialized
INFO - 2017-03-11 05:42:34 --> Router Class Initialized
INFO - 2017-03-11 05:42:34 --> Output Class Initialized
INFO - 2017-03-11 05:42:34 --> Security Class Initialized
DEBUG - 2017-03-11 05:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:42:34 --> Input Class Initialized
INFO - 2017-03-11 05:42:34 --> Language Class Initialized
INFO - 2017-03-11 05:42:34 --> Loader Class Initialized
INFO - 2017-03-11 05:42:34 --> Database Driver Class Initialized
INFO - 2017-03-11 05:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:42:34 --> Controller Class Initialized
INFO - 2017-03-11 05:42:34 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:42:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-11 05:42:34 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-11 05:42:34 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Janeth Femat García')
INFO - 2017-03-11 05:42:34 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-11 05:42:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-11 05:42:34 --> Config Class Initialized
INFO - 2017-03-11 05:42:34 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:42:34 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:42:34 --> Utf8 Class Initialized
INFO - 2017-03-11 05:42:34 --> URI Class Initialized
INFO - 2017-03-11 05:42:34 --> Router Class Initialized
INFO - 2017-03-11 05:42:34 --> Output Class Initialized
INFO - 2017-03-11 05:42:34 --> Security Class Initialized
DEBUG - 2017-03-11 05:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:42:34 --> Input Class Initialized
INFO - 2017-03-11 05:42:34 --> Language Class Initialized
INFO - 2017-03-11 05:42:34 --> Loader Class Initialized
INFO - 2017-03-11 05:42:34 --> Database Driver Class Initialized
INFO - 2017-03-11 05:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:42:34 --> Controller Class Initialized
INFO - 2017-03-11 05:42:34 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:42:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:42:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:42:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:42:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:42:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:42:34 --> Final output sent to browser
DEBUG - 2017-03-11 05:42:34 --> Total execution time: 0.0146
INFO - 2017-03-11 05:42:37 --> Config Class Initialized
INFO - 2017-03-11 05:42:37 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:42:37 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:42:37 --> Utf8 Class Initialized
INFO - 2017-03-11 05:42:37 --> URI Class Initialized
INFO - 2017-03-11 05:42:37 --> Router Class Initialized
INFO - 2017-03-11 05:42:37 --> Output Class Initialized
INFO - 2017-03-11 05:42:37 --> Security Class Initialized
DEBUG - 2017-03-11 05:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:42:37 --> Input Class Initialized
INFO - 2017-03-11 05:42:37 --> Language Class Initialized
INFO - 2017-03-11 05:42:37 --> Loader Class Initialized
INFO - 2017-03-11 05:42:37 --> Database Driver Class Initialized
INFO - 2017-03-11 05:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:42:37 --> Controller Class Initialized
INFO - 2017-03-11 05:42:37 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:42:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-11 05:42:37 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-11 05:42:37 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Janeth Femat García')
INFO - 2017-03-11 05:42:37 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-11 05:42:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-11 05:42:38 --> Config Class Initialized
INFO - 2017-03-11 05:42:38 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:42:38 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:42:38 --> Utf8 Class Initialized
INFO - 2017-03-11 05:42:38 --> URI Class Initialized
INFO - 2017-03-11 05:42:38 --> Router Class Initialized
INFO - 2017-03-11 05:42:38 --> Output Class Initialized
INFO - 2017-03-11 05:42:38 --> Security Class Initialized
DEBUG - 2017-03-11 05:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:42:38 --> Input Class Initialized
INFO - 2017-03-11 05:42:38 --> Language Class Initialized
INFO - 2017-03-11 05:42:38 --> Loader Class Initialized
INFO - 2017-03-11 05:42:38 --> Database Driver Class Initialized
INFO - 2017-03-11 05:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:42:38 --> Controller Class Initialized
INFO - 2017-03-11 05:42:38 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:42:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:42:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:42:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:42:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:42:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:42:38 --> Final output sent to browser
DEBUG - 2017-03-11 05:42:38 --> Total execution time: 0.0140
INFO - 2017-03-11 05:42:38 --> Config Class Initialized
INFO - 2017-03-11 05:42:38 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:42:38 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:42:38 --> Utf8 Class Initialized
INFO - 2017-03-11 05:42:38 --> URI Class Initialized
INFO - 2017-03-11 05:42:38 --> Router Class Initialized
INFO - 2017-03-11 05:42:38 --> Output Class Initialized
INFO - 2017-03-11 05:42:38 --> Security Class Initialized
DEBUG - 2017-03-11 05:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:42:38 --> Input Class Initialized
INFO - 2017-03-11 05:42:38 --> Language Class Initialized
INFO - 2017-03-11 05:42:38 --> Loader Class Initialized
INFO - 2017-03-11 05:42:38 --> Database Driver Class Initialized
INFO - 2017-03-11 05:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:42:38 --> Controller Class Initialized
INFO - 2017-03-11 05:42:38 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:42:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:42:39 --> Config Class Initialized
INFO - 2017-03-11 05:42:39 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:42:39 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:42:39 --> Utf8 Class Initialized
INFO - 2017-03-11 05:42:39 --> URI Class Initialized
INFO - 2017-03-11 05:42:39 --> Router Class Initialized
INFO - 2017-03-11 05:42:39 --> Output Class Initialized
INFO - 2017-03-11 05:42:39 --> Security Class Initialized
DEBUG - 2017-03-11 05:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:42:39 --> Input Class Initialized
INFO - 2017-03-11 05:42:39 --> Language Class Initialized
INFO - 2017-03-11 05:42:39 --> Loader Class Initialized
INFO - 2017-03-11 05:42:39 --> Database Driver Class Initialized
INFO - 2017-03-11 05:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:42:39 --> Controller Class Initialized
INFO - 2017-03-11 05:42:39 --> Helper loaded: date_helper
DEBUG - 2017-03-11 05:42:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:42:39 --> Helper loaded: url_helper
INFO - 2017-03-11 05:42:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:42:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 05:42:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 05:42:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 05:42:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:42:39 --> Final output sent to browser
DEBUG - 2017-03-11 05:42:39 --> Total execution time: 0.0141
INFO - 2017-03-11 05:42:58 --> Config Class Initialized
INFO - 2017-03-11 05:42:58 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:42:58 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:42:58 --> Utf8 Class Initialized
INFO - 2017-03-11 05:42:58 --> URI Class Initialized
DEBUG - 2017-03-11 05:42:58 --> No URI present. Default controller set.
INFO - 2017-03-11 05:42:58 --> Router Class Initialized
INFO - 2017-03-11 05:42:58 --> Output Class Initialized
INFO - 2017-03-11 05:42:58 --> Security Class Initialized
DEBUG - 2017-03-11 05:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:42:58 --> Input Class Initialized
INFO - 2017-03-11 05:42:58 --> Language Class Initialized
INFO - 2017-03-11 05:42:58 --> Loader Class Initialized
INFO - 2017-03-11 05:42:58 --> Database Driver Class Initialized
INFO - 2017-03-11 05:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:42:58 --> Controller Class Initialized
INFO - 2017-03-11 05:42:58 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:42:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:42:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:42:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:42:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:42:58 --> Final output sent to browser
DEBUG - 2017-03-11 05:42:58 --> Total execution time: 0.0137
INFO - 2017-03-11 05:43:00 --> Config Class Initialized
INFO - 2017-03-11 05:43:00 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:43:00 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:43:00 --> Utf8 Class Initialized
INFO - 2017-03-11 05:43:00 --> URI Class Initialized
INFO - 2017-03-11 05:43:00 --> Router Class Initialized
INFO - 2017-03-11 05:43:00 --> Output Class Initialized
INFO - 2017-03-11 05:43:00 --> Security Class Initialized
DEBUG - 2017-03-11 05:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:43:00 --> Input Class Initialized
INFO - 2017-03-11 05:43:00 --> Language Class Initialized
INFO - 2017-03-11 05:43:00 --> Loader Class Initialized
INFO - 2017-03-11 05:43:00 --> Database Driver Class Initialized
INFO - 2017-03-11 05:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:43:00 --> Controller Class Initialized
INFO - 2017-03-11 05:43:00 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:43:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:43:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:43:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:43:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:43:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:43:00 --> Final output sent to browser
DEBUG - 2017-03-11 05:43:00 --> Total execution time: 0.0426
INFO - 2017-03-11 05:43:16 --> Config Class Initialized
INFO - 2017-03-11 05:43:16 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:43:16 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:43:16 --> Utf8 Class Initialized
INFO - 2017-03-11 05:43:16 --> URI Class Initialized
INFO - 2017-03-11 05:43:16 --> Router Class Initialized
INFO - 2017-03-11 05:43:16 --> Output Class Initialized
INFO - 2017-03-11 05:43:16 --> Security Class Initialized
DEBUG - 2017-03-11 05:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:43:16 --> Input Class Initialized
INFO - 2017-03-11 05:43:16 --> Language Class Initialized
INFO - 2017-03-11 05:43:16 --> Loader Class Initialized
INFO - 2017-03-11 05:43:16 --> Database Driver Class Initialized
INFO - 2017-03-11 05:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:43:16 --> Controller Class Initialized
INFO - 2017-03-11 05:43:16 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:43:16 --> Config Class Initialized
INFO - 2017-03-11 05:43:16 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:43:16 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:43:16 --> Utf8 Class Initialized
INFO - 2017-03-11 05:43:16 --> URI Class Initialized
INFO - 2017-03-11 05:43:16 --> Router Class Initialized
INFO - 2017-03-11 05:43:16 --> Output Class Initialized
INFO - 2017-03-11 05:43:16 --> Security Class Initialized
DEBUG - 2017-03-11 05:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:43:16 --> Input Class Initialized
INFO - 2017-03-11 05:43:16 --> Language Class Initialized
INFO - 2017-03-11 05:43:16 --> Loader Class Initialized
INFO - 2017-03-11 05:43:16 --> Database Driver Class Initialized
INFO - 2017-03-11 05:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:43:16 --> Controller Class Initialized
INFO - 2017-03-11 05:43:16 --> Helper loaded: date_helper
DEBUG - 2017-03-11 05:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:43:16 --> Helper loaded: url_helper
INFO - 2017-03-11 05:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 05:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 05:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 05:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:43:16 --> Final output sent to browser
DEBUG - 2017-03-11 05:43:16 --> Total execution time: 0.0143
INFO - 2017-03-11 05:43:17 --> Config Class Initialized
INFO - 2017-03-11 05:43:17 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:43:17 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:43:17 --> Utf8 Class Initialized
INFO - 2017-03-11 05:43:17 --> URI Class Initialized
INFO - 2017-03-11 05:43:17 --> Router Class Initialized
INFO - 2017-03-11 05:43:17 --> Output Class Initialized
INFO - 2017-03-11 05:43:17 --> Security Class Initialized
DEBUG - 2017-03-11 05:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:43:17 --> Input Class Initialized
INFO - 2017-03-11 05:43:17 --> Language Class Initialized
INFO - 2017-03-11 05:43:17 --> Loader Class Initialized
INFO - 2017-03-11 05:43:17 --> Database Driver Class Initialized
INFO - 2017-03-11 05:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:43:17 --> Controller Class Initialized
INFO - 2017-03-11 05:43:17 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:43:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:43:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:43:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:43:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:43:17 --> Final output sent to browser
DEBUG - 2017-03-11 05:43:17 --> Total execution time: 0.0134
INFO - 2017-03-11 05:43:37 --> Config Class Initialized
INFO - 2017-03-11 05:43:37 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:43:37 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:43:37 --> Utf8 Class Initialized
INFO - 2017-03-11 05:43:37 --> URI Class Initialized
DEBUG - 2017-03-11 05:43:37 --> No URI present. Default controller set.
INFO - 2017-03-11 05:43:37 --> Router Class Initialized
INFO - 2017-03-11 05:43:37 --> Output Class Initialized
INFO - 2017-03-11 05:43:37 --> Security Class Initialized
DEBUG - 2017-03-11 05:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:43:37 --> Input Class Initialized
INFO - 2017-03-11 05:43:37 --> Language Class Initialized
INFO - 2017-03-11 05:43:37 --> Loader Class Initialized
INFO - 2017-03-11 05:43:38 --> Database Driver Class Initialized
INFO - 2017-03-11 05:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:43:38 --> Controller Class Initialized
INFO - 2017-03-11 05:43:38 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:43:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:43:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:43:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:43:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:43:39 --> Final output sent to browser
DEBUG - 2017-03-11 05:43:39 --> Total execution time: 1.5044
INFO - 2017-03-11 05:43:39 --> Config Class Initialized
INFO - 2017-03-11 05:43:39 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:43:39 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:43:39 --> Utf8 Class Initialized
INFO - 2017-03-11 05:43:39 --> URI Class Initialized
DEBUG - 2017-03-11 05:43:39 --> No URI present. Default controller set.
INFO - 2017-03-11 05:43:39 --> Router Class Initialized
INFO - 2017-03-11 05:43:39 --> Output Class Initialized
INFO - 2017-03-11 05:43:39 --> Security Class Initialized
DEBUG - 2017-03-11 05:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:43:39 --> Input Class Initialized
INFO - 2017-03-11 05:43:39 --> Language Class Initialized
INFO - 2017-03-11 05:43:39 --> Loader Class Initialized
INFO - 2017-03-11 05:43:39 --> Database Driver Class Initialized
INFO - 2017-03-11 05:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:43:39 --> Controller Class Initialized
INFO - 2017-03-11 05:43:39 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:43:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:43:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:43:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:43:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:43:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:43:39 --> Final output sent to browser
DEBUG - 2017-03-11 05:43:39 --> Total execution time: 0.0137
INFO - 2017-03-11 05:43:41 --> Config Class Initialized
INFO - 2017-03-11 05:43:41 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:43:41 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:43:41 --> Utf8 Class Initialized
INFO - 2017-03-11 05:43:41 --> URI Class Initialized
INFO - 2017-03-11 05:43:41 --> Router Class Initialized
INFO - 2017-03-11 05:43:41 --> Output Class Initialized
INFO - 2017-03-11 05:43:41 --> Security Class Initialized
DEBUG - 2017-03-11 05:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:43:41 --> Input Class Initialized
INFO - 2017-03-11 05:43:41 --> Language Class Initialized
INFO - 2017-03-11 05:43:41 --> Loader Class Initialized
INFO - 2017-03-11 05:43:41 --> Database Driver Class Initialized
INFO - 2017-03-11 05:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:43:41 --> Controller Class Initialized
INFO - 2017-03-11 05:43:41 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:43:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:43:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:43:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:43:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:43:41 --> Final output sent to browser
DEBUG - 2017-03-11 05:43:41 --> Total execution time: 0.0137
INFO - 2017-03-11 05:43:45 --> Config Class Initialized
INFO - 2017-03-11 05:43:45 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:43:45 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:43:45 --> Utf8 Class Initialized
INFO - 2017-03-11 05:43:45 --> URI Class Initialized
INFO - 2017-03-11 05:43:45 --> Router Class Initialized
INFO - 2017-03-11 05:43:45 --> Output Class Initialized
INFO - 2017-03-11 05:43:45 --> Security Class Initialized
DEBUG - 2017-03-11 05:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:43:45 --> Input Class Initialized
INFO - 2017-03-11 05:43:45 --> Language Class Initialized
INFO - 2017-03-11 05:43:45 --> Loader Class Initialized
INFO - 2017-03-11 05:43:45 --> Database Driver Class Initialized
INFO - 2017-03-11 05:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:43:45 --> Controller Class Initialized
INFO - 2017-03-11 05:43:45 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:43:46 --> Config Class Initialized
INFO - 2017-03-11 05:43:46 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:43:46 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:43:46 --> Utf8 Class Initialized
INFO - 2017-03-11 05:43:46 --> URI Class Initialized
INFO - 2017-03-11 05:43:46 --> Router Class Initialized
INFO - 2017-03-11 05:43:46 --> Output Class Initialized
INFO - 2017-03-11 05:43:46 --> Security Class Initialized
DEBUG - 2017-03-11 05:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:43:46 --> Input Class Initialized
INFO - 2017-03-11 05:43:46 --> Language Class Initialized
INFO - 2017-03-11 05:43:46 --> Loader Class Initialized
INFO - 2017-03-11 05:43:46 --> Database Driver Class Initialized
INFO - 2017-03-11 05:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:43:46 --> Controller Class Initialized
INFO - 2017-03-11 05:43:46 --> Helper loaded: date_helper
DEBUG - 2017-03-11 05:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:43:46 --> Helper loaded: url_helper
INFO - 2017-03-11 05:43:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:43:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 05:43:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 05:43:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 05:43:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:43:46 --> Final output sent to browser
DEBUG - 2017-03-11 05:43:46 --> Total execution time: 0.1014
INFO - 2017-03-11 05:43:47 --> Config Class Initialized
INFO - 2017-03-11 05:43:47 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:43:47 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:43:47 --> Utf8 Class Initialized
INFO - 2017-03-11 05:43:47 --> URI Class Initialized
INFO - 2017-03-11 05:43:47 --> Router Class Initialized
INFO - 2017-03-11 05:43:47 --> Output Class Initialized
INFO - 2017-03-11 05:43:47 --> Security Class Initialized
DEBUG - 2017-03-11 05:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:43:47 --> Input Class Initialized
INFO - 2017-03-11 05:43:47 --> Language Class Initialized
INFO - 2017-03-11 05:43:47 --> Loader Class Initialized
INFO - 2017-03-11 05:43:47 --> Database Driver Class Initialized
INFO - 2017-03-11 05:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:43:47 --> Controller Class Initialized
INFO - 2017-03-11 05:43:47 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:43:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:43:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:43:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:43:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:43:47 --> Final output sent to browser
DEBUG - 2017-03-11 05:43:47 --> Total execution time: 0.0139
INFO - 2017-03-11 05:43:58 --> Config Class Initialized
INFO - 2017-03-11 05:43:58 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:43:58 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:43:58 --> Utf8 Class Initialized
INFO - 2017-03-11 05:43:58 --> URI Class Initialized
DEBUG - 2017-03-11 05:43:58 --> No URI present. Default controller set.
INFO - 2017-03-11 05:43:58 --> Router Class Initialized
INFO - 2017-03-11 05:43:58 --> Output Class Initialized
INFO - 2017-03-11 05:43:58 --> Security Class Initialized
DEBUG - 2017-03-11 05:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:43:58 --> Input Class Initialized
INFO - 2017-03-11 05:43:58 --> Language Class Initialized
INFO - 2017-03-11 05:43:58 --> Loader Class Initialized
INFO - 2017-03-11 05:43:58 --> Database Driver Class Initialized
INFO - 2017-03-11 05:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:43:58 --> Controller Class Initialized
INFO - 2017-03-11 05:43:58 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:43:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:43:58 --> Final output sent to browser
DEBUG - 2017-03-11 05:43:58 --> Total execution time: 0.0141
INFO - 2017-03-11 05:44:00 --> Config Class Initialized
INFO - 2017-03-11 05:44:00 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:44:00 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:44:00 --> Utf8 Class Initialized
INFO - 2017-03-11 05:44:00 --> URI Class Initialized
INFO - 2017-03-11 05:44:00 --> Router Class Initialized
INFO - 2017-03-11 05:44:00 --> Output Class Initialized
INFO - 2017-03-11 05:44:00 --> Security Class Initialized
DEBUG - 2017-03-11 05:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:44:00 --> Input Class Initialized
INFO - 2017-03-11 05:44:00 --> Language Class Initialized
INFO - 2017-03-11 05:44:00 --> Loader Class Initialized
INFO - 2017-03-11 05:44:00 --> Database Driver Class Initialized
INFO - 2017-03-11 05:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:44:00 --> Controller Class Initialized
INFO - 2017-03-11 05:44:00 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:44:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:44:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:44:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:44:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:44:00 --> Final output sent to browser
DEBUG - 2017-03-11 05:44:00 --> Total execution time: 0.0138
INFO - 2017-03-11 05:57:07 --> Config Class Initialized
INFO - 2017-03-11 05:57:07 --> Hooks Class Initialized
DEBUG - 2017-03-11 05:57:07 --> UTF-8 Support Enabled
INFO - 2017-03-11 05:57:07 --> Utf8 Class Initialized
INFO - 2017-03-11 05:57:07 --> URI Class Initialized
INFO - 2017-03-11 05:57:07 --> Router Class Initialized
INFO - 2017-03-11 05:57:07 --> Output Class Initialized
INFO - 2017-03-11 05:57:07 --> Security Class Initialized
DEBUG - 2017-03-11 05:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 05:57:07 --> Input Class Initialized
INFO - 2017-03-11 05:57:07 --> Language Class Initialized
INFO - 2017-03-11 05:57:07 --> Loader Class Initialized
INFO - 2017-03-11 05:57:07 --> Database Driver Class Initialized
INFO - 2017-03-11 05:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 05:57:08 --> Controller Class Initialized
INFO - 2017-03-11 05:57:08 --> Helper loaded: url_helper
DEBUG - 2017-03-11 05:57:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 05:57:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 05:57:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 05:57:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 05:57:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 05:57:08 --> Final output sent to browser
DEBUG - 2017-03-11 05:57:08 --> Total execution time: 1.6426
INFO - 2017-03-11 06:22:42 --> Config Class Initialized
INFO - 2017-03-11 06:22:42 --> Hooks Class Initialized
DEBUG - 2017-03-11 06:22:42 --> UTF-8 Support Enabled
INFO - 2017-03-11 06:22:42 --> Utf8 Class Initialized
INFO - 2017-03-11 06:22:42 --> URI Class Initialized
INFO - 2017-03-11 06:22:42 --> Router Class Initialized
INFO - 2017-03-11 06:22:42 --> Output Class Initialized
INFO - 2017-03-11 06:22:42 --> Security Class Initialized
DEBUG - 2017-03-11 06:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 06:22:42 --> Input Class Initialized
INFO - 2017-03-11 06:22:42 --> Language Class Initialized
INFO - 2017-03-11 06:22:42 --> Loader Class Initialized
INFO - 2017-03-11 06:22:43 --> Database Driver Class Initialized
INFO - 2017-03-11 06:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 06:22:43 --> Controller Class Initialized
INFO - 2017-03-11 06:22:43 --> Helper loaded: url_helper
DEBUG - 2017-03-11 06:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 06:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-11 06:22:44 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-11 06:22:44 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-11 06:22:44 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-11 06:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 06:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 06:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 06:22:44 --> Final output sent to browser
DEBUG - 2017-03-11 06:22:44 --> Total execution time: 1.7876
INFO - 2017-03-11 06:22:46 --> Config Class Initialized
INFO - 2017-03-11 06:22:46 --> Hooks Class Initialized
DEBUG - 2017-03-11 06:22:46 --> UTF-8 Support Enabled
INFO - 2017-03-11 06:22:46 --> Utf8 Class Initialized
INFO - 2017-03-11 06:22:46 --> URI Class Initialized
INFO - 2017-03-11 06:22:46 --> Router Class Initialized
INFO - 2017-03-11 06:22:46 --> Output Class Initialized
INFO - 2017-03-11 06:22:46 --> Security Class Initialized
DEBUG - 2017-03-11 06:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 06:22:46 --> Input Class Initialized
INFO - 2017-03-11 06:22:46 --> Language Class Initialized
INFO - 2017-03-11 06:22:46 --> Loader Class Initialized
INFO - 2017-03-11 06:22:46 --> Database Driver Class Initialized
INFO - 2017-03-11 06:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 06:22:46 --> Controller Class Initialized
INFO - 2017-03-11 06:22:46 --> Helper loaded: url_helper
DEBUG - 2017-03-11 06:22:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 06:22:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 06:22:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 06:22:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 06:22:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 06:22:46 --> Final output sent to browser
DEBUG - 2017-03-11 06:22:46 --> Total execution time: 0.0136
INFO - 2017-03-11 13:04:57 --> Config Class Initialized
INFO - 2017-03-11 13:04:57 --> Hooks Class Initialized
DEBUG - 2017-03-11 13:04:58 --> UTF-8 Support Enabled
INFO - 2017-03-11 13:04:58 --> Utf8 Class Initialized
INFO - 2017-03-11 13:04:58 --> URI Class Initialized
INFO - 2017-03-11 13:04:58 --> Router Class Initialized
INFO - 2017-03-11 13:04:58 --> Output Class Initialized
INFO - 2017-03-11 13:04:58 --> Security Class Initialized
DEBUG - 2017-03-11 13:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 13:04:58 --> Input Class Initialized
INFO - 2017-03-11 13:04:58 --> Language Class Initialized
INFO - 2017-03-11 13:04:58 --> Loader Class Initialized
INFO - 2017-03-11 13:04:58 --> Database Driver Class Initialized
INFO - 2017-03-11 13:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 13:04:59 --> Controller Class Initialized
INFO - 2017-03-11 13:04:59 --> Helper loaded: url_helper
DEBUG - 2017-03-11 13:04:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 13:04:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-11 13:04:59 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-11 13:04:59 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-11 13:04:59 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-11 13:04:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 13:04:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 13:04:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 13:04:59 --> Final output sent to browser
DEBUG - 2017-03-11 13:05:00 --> Total execution time: 2.3694
INFO - 2017-03-11 13:18:03 --> Config Class Initialized
INFO - 2017-03-11 13:18:03 --> Config Class Initialized
INFO - 2017-03-11 13:18:03 --> Hooks Class Initialized
INFO - 2017-03-11 13:18:03 --> Hooks Class Initialized
DEBUG - 2017-03-11 13:18:04 --> UTF-8 Support Enabled
DEBUG - 2017-03-11 13:18:04 --> UTF-8 Support Enabled
INFO - 2017-03-11 13:18:04 --> Utf8 Class Initialized
INFO - 2017-03-11 13:18:04 --> Utf8 Class Initialized
INFO - 2017-03-11 13:18:04 --> URI Class Initialized
INFO - 2017-03-11 13:18:04 --> URI Class Initialized
INFO - 2017-03-11 13:18:04 --> Router Class Initialized
INFO - 2017-03-11 13:18:04 --> Router Class Initialized
INFO - 2017-03-11 13:18:04 --> Output Class Initialized
INFO - 2017-03-11 13:18:04 --> Output Class Initialized
INFO - 2017-03-11 13:18:04 --> Security Class Initialized
INFO - 2017-03-11 13:18:04 --> Security Class Initialized
DEBUG - 2017-03-11 13:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 13:18:04 --> Input Class Initialized
INFO - 2017-03-11 13:18:04 --> Language Class Initialized
DEBUG - 2017-03-11 13:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 13:18:04 --> Input Class Initialized
INFO - 2017-03-11 13:18:04 --> Language Class Initialized
INFO - 2017-03-11 13:18:04 --> Loader Class Initialized
INFO - 2017-03-11 13:18:04 --> Loader Class Initialized
INFO - 2017-03-11 13:18:04 --> Database Driver Class Initialized
INFO - 2017-03-11 13:18:04 --> Database Driver Class Initialized
INFO - 2017-03-11 13:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 13:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 13:18:05 --> Controller Class Initialized
INFO - 2017-03-11 13:18:05 --> Controller Class Initialized
INFO - 2017-03-11 13:18:05 --> Helper loaded: url_helper
INFO - 2017-03-11 13:18:05 --> Helper loaded: url_helper
DEBUG - 2017-03-11 13:18:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-11 13:18:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 13:18:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 13:18:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-11 13:18:05 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-11 13:18:06 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-11 13:18:06 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-11 13:18:06 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-11 13:18:06 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
ERROR - 2017-03-11 13:18:06 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-11 13:18:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 13:18:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 13:18:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 13:18:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 13:18:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 13:18:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 13:18:06 --> Final output sent to browser
INFO - 2017-03-11 13:18:06 --> Final output sent to browser
DEBUG - 2017-03-11 13:18:06 --> Total execution time: 2.5333
DEBUG - 2017-03-11 13:18:06 --> Total execution time: 2.5332
INFO - 2017-03-11 13:18:12 --> Config Class Initialized
INFO - 2017-03-11 13:18:12 --> Hooks Class Initialized
DEBUG - 2017-03-11 13:18:12 --> UTF-8 Support Enabled
INFO - 2017-03-11 13:18:12 --> Utf8 Class Initialized
INFO - 2017-03-11 13:18:12 --> URI Class Initialized
INFO - 2017-03-11 13:18:12 --> Router Class Initialized
INFO - 2017-03-11 13:18:12 --> Output Class Initialized
INFO - 2017-03-11 13:18:12 --> Security Class Initialized
DEBUG - 2017-03-11 13:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 13:18:12 --> Input Class Initialized
INFO - 2017-03-11 13:18:12 --> Language Class Initialized
INFO - 2017-03-11 13:18:12 --> Loader Class Initialized
INFO - 2017-03-11 13:18:13 --> Database Driver Class Initialized
INFO - 2017-03-11 13:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 13:18:13 --> Controller Class Initialized
INFO - 2017-03-11 13:18:13 --> Helper loaded: url_helper
DEBUG - 2017-03-11 13:18:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 13:18:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 13:18:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 13:18:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 13:18:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 13:18:14 --> Final output sent to browser
DEBUG - 2017-03-11 13:18:14 --> Total execution time: 1.9176
INFO - 2017-03-11 13:18:17 --> Config Class Initialized
INFO - 2017-03-11 13:18:17 --> Hooks Class Initialized
DEBUG - 2017-03-11 13:18:17 --> UTF-8 Support Enabled
INFO - 2017-03-11 13:18:17 --> Utf8 Class Initialized
INFO - 2017-03-11 13:18:17 --> URI Class Initialized
INFO - 2017-03-11 13:18:17 --> Router Class Initialized
INFO - 2017-03-11 13:18:17 --> Output Class Initialized
INFO - 2017-03-11 13:18:18 --> Security Class Initialized
DEBUG - 2017-03-11 13:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 13:18:18 --> Input Class Initialized
INFO - 2017-03-11 13:18:18 --> Language Class Initialized
INFO - 2017-03-11 13:18:18 --> Loader Class Initialized
INFO - 2017-03-11 13:18:18 --> Database Driver Class Initialized
INFO - 2017-03-11 13:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 13:18:18 --> Controller Class Initialized
INFO - 2017-03-11 13:18:18 --> Helper loaded: url_helper
DEBUG - 2017-03-11 13:18:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 13:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 13:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 13:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 13:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 13:18:18 --> Final output sent to browser
DEBUG - 2017-03-11 13:18:18 --> Total execution time: 0.1980
INFO - 2017-03-11 14:48:57 --> Config Class Initialized
INFO - 2017-03-11 14:48:57 --> Hooks Class Initialized
DEBUG - 2017-03-11 14:48:57 --> UTF-8 Support Enabled
INFO - 2017-03-11 14:48:57 --> Utf8 Class Initialized
INFO - 2017-03-11 14:48:57 --> URI Class Initialized
INFO - 2017-03-11 14:48:57 --> Router Class Initialized
INFO - 2017-03-11 14:48:57 --> Output Class Initialized
INFO - 2017-03-11 14:48:57 --> Security Class Initialized
DEBUG - 2017-03-11 14:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 14:48:57 --> Input Class Initialized
INFO - 2017-03-11 14:48:57 --> Language Class Initialized
INFO - 2017-03-11 14:48:57 --> Loader Class Initialized
INFO - 2017-03-11 14:48:58 --> Database Driver Class Initialized
INFO - 2017-03-11 14:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 14:48:58 --> Controller Class Initialized
INFO - 2017-03-11 14:48:58 --> Helper loaded: date_helper
DEBUG - 2017-03-11 14:48:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 14:48:58 --> Helper loaded: url_helper
INFO - 2017-03-11 14:48:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 14:48:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 14:48:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 14:48:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 14:48:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 14:48:59 --> Final output sent to browser
DEBUG - 2017-03-11 14:48:59 --> Total execution time: 2.1760
INFO - 2017-03-11 15:33:52 --> Config Class Initialized
INFO - 2017-03-11 15:33:52 --> Hooks Class Initialized
DEBUG - 2017-03-11 15:33:52 --> UTF-8 Support Enabled
INFO - 2017-03-11 15:33:52 --> Utf8 Class Initialized
INFO - 2017-03-11 15:33:52 --> URI Class Initialized
DEBUG - 2017-03-11 15:33:52 --> No URI present. Default controller set.
INFO - 2017-03-11 15:33:52 --> Router Class Initialized
INFO - 2017-03-11 15:33:52 --> Output Class Initialized
INFO - 2017-03-11 15:33:52 --> Security Class Initialized
DEBUG - 2017-03-11 15:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 15:33:52 --> Input Class Initialized
INFO - 2017-03-11 15:33:52 --> Language Class Initialized
INFO - 2017-03-11 15:33:52 --> Loader Class Initialized
INFO - 2017-03-11 15:33:53 --> Database Driver Class Initialized
INFO - 2017-03-11 15:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 15:33:53 --> Controller Class Initialized
INFO - 2017-03-11 15:33:53 --> Helper loaded: url_helper
DEBUG - 2017-03-11 15:33:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 15:33:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 15:33:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 15:33:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 15:33:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 15:33:54 --> Final output sent to browser
DEBUG - 2017-03-11 15:33:54 --> Total execution time: 2.0259
INFO - 2017-03-11 15:34:02 --> Config Class Initialized
INFO - 2017-03-11 15:34:02 --> Hooks Class Initialized
DEBUG - 2017-03-11 15:34:02 --> UTF-8 Support Enabled
INFO - 2017-03-11 15:34:02 --> Utf8 Class Initialized
INFO - 2017-03-11 15:34:02 --> URI Class Initialized
INFO - 2017-03-11 15:34:02 --> Router Class Initialized
INFO - 2017-03-11 15:34:02 --> Output Class Initialized
INFO - 2017-03-11 15:34:02 --> Security Class Initialized
DEBUG - 2017-03-11 15:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 15:34:02 --> Input Class Initialized
INFO - 2017-03-11 15:34:02 --> Language Class Initialized
INFO - 2017-03-11 15:34:02 --> Loader Class Initialized
INFO - 2017-03-11 15:34:03 --> Database Driver Class Initialized
INFO - 2017-03-11 15:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 15:34:03 --> Controller Class Initialized
INFO - 2017-03-11 15:34:07 --> Helper loaded: url_helper
DEBUG - 2017-03-11 15:34:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 15:34:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 15:34:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 15:34:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 15:34:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 15:34:07 --> Final output sent to browser
DEBUG - 2017-03-11 15:34:07 --> Total execution time: 5.0656
INFO - 2017-03-11 15:34:41 --> Config Class Initialized
INFO - 2017-03-11 15:34:41 --> Hooks Class Initialized
DEBUG - 2017-03-11 15:34:41 --> UTF-8 Support Enabled
INFO - 2017-03-11 15:34:41 --> Utf8 Class Initialized
INFO - 2017-03-11 15:34:41 --> URI Class Initialized
INFO - 2017-03-11 15:34:41 --> Router Class Initialized
INFO - 2017-03-11 15:34:41 --> Output Class Initialized
INFO - 2017-03-11 15:34:41 --> Security Class Initialized
DEBUG - 2017-03-11 15:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 15:34:41 --> Input Class Initialized
INFO - 2017-03-11 15:34:41 --> Language Class Initialized
INFO - 2017-03-11 15:34:41 --> Loader Class Initialized
INFO - 2017-03-11 15:34:41 --> Database Driver Class Initialized
INFO - 2017-03-11 15:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 15:34:41 --> Controller Class Initialized
INFO - 2017-03-11 15:34:41 --> Helper loaded: url_helper
DEBUG - 2017-03-11 15:34:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 15:34:43 --> Config Class Initialized
INFO - 2017-03-11 15:34:43 --> Hooks Class Initialized
DEBUG - 2017-03-11 15:34:43 --> UTF-8 Support Enabled
INFO - 2017-03-11 15:34:43 --> Utf8 Class Initialized
INFO - 2017-03-11 15:34:43 --> URI Class Initialized
INFO - 2017-03-11 15:34:43 --> Router Class Initialized
INFO - 2017-03-11 15:34:43 --> Output Class Initialized
INFO - 2017-03-11 15:34:43 --> Security Class Initialized
DEBUG - 2017-03-11 15:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 15:34:43 --> Input Class Initialized
INFO - 2017-03-11 15:34:43 --> Language Class Initialized
INFO - 2017-03-11 15:34:43 --> Loader Class Initialized
INFO - 2017-03-11 15:34:43 --> Database Driver Class Initialized
INFO - 2017-03-11 15:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 15:34:43 --> Controller Class Initialized
INFO - 2017-03-11 15:34:43 --> Helper loaded: date_helper
DEBUG - 2017-03-11 15:34:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 15:34:43 --> Helper loaded: url_helper
INFO - 2017-03-11 15:34:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 15:34:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 15:34:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 15:34:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 15:34:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 15:34:43 --> Final output sent to browser
DEBUG - 2017-03-11 15:34:43 --> Total execution time: 0.1232
INFO - 2017-03-11 15:34:44 --> Config Class Initialized
INFO - 2017-03-11 15:34:44 --> Hooks Class Initialized
DEBUG - 2017-03-11 15:34:44 --> UTF-8 Support Enabled
INFO - 2017-03-11 15:34:44 --> Utf8 Class Initialized
INFO - 2017-03-11 15:34:44 --> URI Class Initialized
INFO - 2017-03-11 15:34:44 --> Router Class Initialized
INFO - 2017-03-11 15:34:44 --> Output Class Initialized
INFO - 2017-03-11 15:34:44 --> Security Class Initialized
DEBUG - 2017-03-11 15:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 15:34:44 --> Input Class Initialized
INFO - 2017-03-11 15:34:44 --> Language Class Initialized
INFO - 2017-03-11 15:34:44 --> Loader Class Initialized
INFO - 2017-03-11 15:34:44 --> Database Driver Class Initialized
INFO - 2017-03-11 15:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 15:34:44 --> Controller Class Initialized
INFO - 2017-03-11 15:34:44 --> Helper loaded: url_helper
DEBUG - 2017-03-11 15:34:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 15:34:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 15:34:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 15:34:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 15:34:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 15:34:44 --> Final output sent to browser
DEBUG - 2017-03-11 15:34:44 --> Total execution time: 0.0732
INFO - 2017-03-11 17:53:16 --> Config Class Initialized
INFO - 2017-03-11 17:53:16 --> Hooks Class Initialized
DEBUG - 2017-03-11 17:53:16 --> UTF-8 Support Enabled
INFO - 2017-03-11 17:53:16 --> Utf8 Class Initialized
INFO - 2017-03-11 17:53:16 --> URI Class Initialized
DEBUG - 2017-03-11 17:53:16 --> No URI present. Default controller set.
INFO - 2017-03-11 17:53:16 --> Router Class Initialized
INFO - 2017-03-11 17:53:16 --> Output Class Initialized
INFO - 2017-03-11 17:53:16 --> Security Class Initialized
DEBUG - 2017-03-11 17:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 17:53:16 --> Input Class Initialized
INFO - 2017-03-11 17:53:16 --> Language Class Initialized
INFO - 2017-03-11 17:53:17 --> Loader Class Initialized
INFO - 2017-03-11 17:53:17 --> Database Driver Class Initialized
INFO - 2017-03-11 17:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 17:53:17 --> Controller Class Initialized
INFO - 2017-03-11 17:53:17 --> Helper loaded: url_helper
DEBUG - 2017-03-11 17:53:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 17:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 17:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 17:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 17:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 17:53:18 --> Final output sent to browser
DEBUG - 2017-03-11 17:53:18 --> Total execution time: 1.9693
INFO - 2017-03-11 17:53:35 --> Config Class Initialized
INFO - 2017-03-11 17:53:35 --> Hooks Class Initialized
DEBUG - 2017-03-11 17:53:35 --> UTF-8 Support Enabled
INFO - 2017-03-11 17:53:35 --> Utf8 Class Initialized
INFO - 2017-03-11 17:53:35 --> URI Class Initialized
INFO - 2017-03-11 17:53:35 --> Router Class Initialized
INFO - 2017-03-11 17:53:36 --> Output Class Initialized
INFO - 2017-03-11 17:53:36 --> Security Class Initialized
DEBUG - 2017-03-11 17:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 17:53:36 --> Input Class Initialized
INFO - 2017-03-11 17:53:36 --> Language Class Initialized
INFO - 2017-03-11 17:53:36 --> Loader Class Initialized
INFO - 2017-03-11 17:53:36 --> Database Driver Class Initialized
INFO - 2017-03-11 17:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 17:53:36 --> Controller Class Initialized
INFO - 2017-03-11 17:53:36 --> Helper loaded: url_helper
DEBUG - 2017-03-11 17:53:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 17:53:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 17:53:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 17:53:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 17:53:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 17:53:37 --> Final output sent to browser
DEBUG - 2017-03-11 17:53:37 --> Total execution time: 1.5094
INFO - 2017-03-11 17:55:15 --> Config Class Initialized
INFO - 2017-03-11 17:55:15 --> Hooks Class Initialized
DEBUG - 2017-03-11 17:55:15 --> UTF-8 Support Enabled
INFO - 2017-03-11 17:55:15 --> Utf8 Class Initialized
INFO - 2017-03-11 17:55:15 --> URI Class Initialized
INFO - 2017-03-11 17:55:15 --> Router Class Initialized
INFO - 2017-03-11 17:55:15 --> Output Class Initialized
INFO - 2017-03-11 17:55:15 --> Security Class Initialized
DEBUG - 2017-03-11 17:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 17:55:15 --> Input Class Initialized
INFO - 2017-03-11 17:55:15 --> Language Class Initialized
INFO - 2017-03-11 17:55:16 --> Loader Class Initialized
INFO - 2017-03-11 17:55:16 --> Database Driver Class Initialized
INFO - 2017-03-11 17:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 17:55:17 --> Controller Class Initialized
INFO - 2017-03-11 17:55:17 --> Helper loaded: url_helper
DEBUG - 2017-03-11 17:55:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 17:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-11 17:55:17 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-11 17:55:17 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-11 17:55:17 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-11 17:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 17:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 17:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 17:55:17 --> Final output sent to browser
DEBUG - 2017-03-11 17:55:17 --> Total execution time: 2.6458
INFO - 2017-03-11 17:56:41 --> Config Class Initialized
INFO - 2017-03-11 17:56:41 --> Hooks Class Initialized
DEBUG - 2017-03-11 17:56:41 --> UTF-8 Support Enabled
INFO - 2017-03-11 17:56:41 --> Utf8 Class Initialized
INFO - 2017-03-11 17:56:41 --> URI Class Initialized
INFO - 2017-03-11 17:56:42 --> Router Class Initialized
INFO - 2017-03-11 17:56:42 --> Output Class Initialized
INFO - 2017-03-11 17:56:42 --> Security Class Initialized
DEBUG - 2017-03-11 17:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 17:56:42 --> Input Class Initialized
INFO - 2017-03-11 17:56:42 --> Language Class Initialized
INFO - 2017-03-11 17:56:42 --> Loader Class Initialized
INFO - 2017-03-11 17:56:42 --> Database Driver Class Initialized
INFO - 2017-03-11 17:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 17:56:42 --> Controller Class Initialized
INFO - 2017-03-11 17:56:42 --> Helper loaded: url_helper
DEBUG - 2017-03-11 17:56:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 17:56:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-11 17:56:43 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-11 17:56:43 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-11 17:56:43 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-11 17:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 17:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 17:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 17:56:43 --> Final output sent to browser
DEBUG - 2017-03-11 17:56:43 --> Total execution time: 1.2594
INFO - 2017-03-11 17:56:46 --> Config Class Initialized
INFO - 2017-03-11 17:56:46 --> Hooks Class Initialized
DEBUG - 2017-03-11 17:56:46 --> UTF-8 Support Enabled
INFO - 2017-03-11 17:56:46 --> Utf8 Class Initialized
INFO - 2017-03-11 17:56:46 --> URI Class Initialized
INFO - 2017-03-11 17:56:46 --> Router Class Initialized
INFO - 2017-03-11 17:56:47 --> Output Class Initialized
INFO - 2017-03-11 17:56:47 --> Security Class Initialized
DEBUG - 2017-03-11 17:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 17:56:47 --> Input Class Initialized
INFO - 2017-03-11 17:56:47 --> Language Class Initialized
INFO - 2017-03-11 17:56:47 --> Loader Class Initialized
INFO - 2017-03-11 17:56:47 --> Database Driver Class Initialized
INFO - 2017-03-11 17:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 17:56:47 --> Controller Class Initialized
INFO - 2017-03-11 17:56:47 --> Helper loaded: url_helper
DEBUG - 2017-03-11 17:56:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 17:56:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 17:56:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 17:56:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 17:56:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 17:56:47 --> Final output sent to browser
DEBUG - 2017-03-11 17:56:47 --> Total execution time: 0.0152
INFO - 2017-03-11 17:57:05 --> Config Class Initialized
INFO - 2017-03-11 17:57:05 --> Hooks Class Initialized
DEBUG - 2017-03-11 17:57:05 --> UTF-8 Support Enabled
INFO - 2017-03-11 17:57:05 --> Utf8 Class Initialized
INFO - 2017-03-11 17:57:05 --> URI Class Initialized
INFO - 2017-03-11 17:57:05 --> Router Class Initialized
INFO - 2017-03-11 17:57:05 --> Output Class Initialized
INFO - 2017-03-11 17:57:05 --> Security Class Initialized
DEBUG - 2017-03-11 17:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 17:57:05 --> Input Class Initialized
INFO - 2017-03-11 17:57:05 --> Language Class Initialized
INFO - 2017-03-11 17:57:05 --> Loader Class Initialized
INFO - 2017-03-11 17:57:05 --> Database Driver Class Initialized
INFO - 2017-03-11 17:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 17:57:06 --> Controller Class Initialized
INFO - 2017-03-11 17:57:06 --> Helper loaded: url_helper
DEBUG - 2017-03-11 17:57:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 17:57:08 --> Config Class Initialized
INFO - 2017-03-11 17:57:08 --> Hooks Class Initialized
DEBUG - 2017-03-11 17:57:08 --> UTF-8 Support Enabled
INFO - 2017-03-11 17:57:08 --> Utf8 Class Initialized
INFO - 2017-03-11 17:57:08 --> URI Class Initialized
INFO - 2017-03-11 17:57:08 --> Router Class Initialized
INFO - 2017-03-11 17:57:08 --> Output Class Initialized
INFO - 2017-03-11 17:57:08 --> Security Class Initialized
DEBUG - 2017-03-11 17:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 17:57:08 --> Input Class Initialized
INFO - 2017-03-11 17:57:08 --> Language Class Initialized
INFO - 2017-03-11 17:57:08 --> Loader Class Initialized
INFO - 2017-03-11 17:57:08 --> Database Driver Class Initialized
INFO - 2017-03-11 17:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 17:57:08 --> Controller Class Initialized
INFO - 2017-03-11 17:57:08 --> Helper loaded: date_helper
DEBUG - 2017-03-11 17:57:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 17:57:08 --> Helper loaded: url_helper
INFO - 2017-03-11 17:57:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 17:57:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 17:57:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 17:57:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 17:57:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 17:57:08 --> Final output sent to browser
DEBUG - 2017-03-11 17:57:08 --> Total execution time: 0.1113
INFO - 2017-03-11 17:57:10 --> Config Class Initialized
INFO - 2017-03-11 17:57:10 --> Hooks Class Initialized
DEBUG - 2017-03-11 17:57:10 --> UTF-8 Support Enabled
INFO - 2017-03-11 17:57:10 --> Utf8 Class Initialized
INFO - 2017-03-11 17:57:10 --> URI Class Initialized
INFO - 2017-03-11 17:57:10 --> Router Class Initialized
INFO - 2017-03-11 17:57:10 --> Output Class Initialized
INFO - 2017-03-11 17:57:10 --> Security Class Initialized
DEBUG - 2017-03-11 17:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 17:57:10 --> Input Class Initialized
INFO - 2017-03-11 17:57:10 --> Language Class Initialized
INFO - 2017-03-11 17:57:10 --> Loader Class Initialized
INFO - 2017-03-11 17:57:10 --> Database Driver Class Initialized
INFO - 2017-03-11 17:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 17:57:10 --> Controller Class Initialized
INFO - 2017-03-11 17:57:10 --> Helper loaded: url_helper
DEBUG - 2017-03-11 17:57:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 17:57:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 17:57:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 17:57:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 17:57:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 17:57:10 --> Final output sent to browser
DEBUG - 2017-03-11 17:57:10 --> Total execution time: 0.0141
INFO - 2017-03-11 17:57:17 --> Config Class Initialized
INFO - 2017-03-11 17:57:17 --> Hooks Class Initialized
DEBUG - 2017-03-11 17:57:17 --> UTF-8 Support Enabled
INFO - 2017-03-11 17:57:17 --> Utf8 Class Initialized
INFO - 2017-03-11 17:57:17 --> URI Class Initialized
INFO - 2017-03-11 17:57:17 --> Router Class Initialized
INFO - 2017-03-11 17:57:17 --> Output Class Initialized
INFO - 2017-03-11 17:57:17 --> Security Class Initialized
DEBUG - 2017-03-11 17:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 17:57:17 --> Input Class Initialized
INFO - 2017-03-11 17:57:17 --> Language Class Initialized
INFO - 2017-03-11 17:57:17 --> Loader Class Initialized
INFO - 2017-03-11 17:57:17 --> Database Driver Class Initialized
INFO - 2017-03-11 17:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 17:57:17 --> Controller Class Initialized
INFO - 2017-03-11 17:57:17 --> Helper loaded: date_helper
DEBUG - 2017-03-11 17:57:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 17:57:17 --> Helper loaded: url_helper
INFO - 2017-03-11 17:57:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 17:57:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 17:57:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 17:57:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 17:57:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 17:57:17 --> Final output sent to browser
DEBUG - 2017-03-11 17:57:17 --> Total execution time: 0.0150
INFO - 2017-03-11 17:57:18 --> Config Class Initialized
INFO - 2017-03-11 17:57:18 --> Hooks Class Initialized
DEBUG - 2017-03-11 17:57:18 --> UTF-8 Support Enabled
INFO - 2017-03-11 17:57:18 --> Utf8 Class Initialized
INFO - 2017-03-11 17:57:18 --> URI Class Initialized
INFO - 2017-03-11 17:57:18 --> Router Class Initialized
INFO - 2017-03-11 17:57:18 --> Output Class Initialized
INFO - 2017-03-11 17:57:18 --> Security Class Initialized
DEBUG - 2017-03-11 17:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 17:57:18 --> Input Class Initialized
INFO - 2017-03-11 17:57:18 --> Language Class Initialized
INFO - 2017-03-11 17:57:18 --> Loader Class Initialized
INFO - 2017-03-11 17:57:18 --> Database Driver Class Initialized
INFO - 2017-03-11 17:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 17:57:18 --> Controller Class Initialized
INFO - 2017-03-11 17:57:18 --> Helper loaded: url_helper
DEBUG - 2017-03-11 17:57:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 17:57:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 17:57:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 17:57:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 17:57:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 17:57:18 --> Final output sent to browser
DEBUG - 2017-03-11 17:57:18 --> Total execution time: 0.0139
INFO - 2017-03-11 17:57:29 --> Config Class Initialized
INFO - 2017-03-11 17:57:29 --> Hooks Class Initialized
DEBUG - 2017-03-11 17:57:29 --> UTF-8 Support Enabled
INFO - 2017-03-11 17:57:29 --> Utf8 Class Initialized
INFO - 2017-03-11 17:57:29 --> URI Class Initialized
INFO - 2017-03-11 17:57:29 --> Router Class Initialized
INFO - 2017-03-11 17:57:29 --> Output Class Initialized
INFO - 2017-03-11 17:57:29 --> Security Class Initialized
DEBUG - 2017-03-11 17:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 17:57:29 --> Input Class Initialized
INFO - 2017-03-11 17:57:29 --> Language Class Initialized
INFO - 2017-03-11 17:57:29 --> Loader Class Initialized
INFO - 2017-03-11 17:57:29 --> Database Driver Class Initialized
INFO - 2017-03-11 17:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 17:57:29 --> Controller Class Initialized
INFO - 2017-03-11 17:57:29 --> Helper loaded: url_helper
DEBUG - 2017-03-11 17:57:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 17:57:35 --> Config Class Initialized
INFO - 2017-03-11 17:57:35 --> Hooks Class Initialized
DEBUG - 2017-03-11 17:57:35 --> UTF-8 Support Enabled
INFO - 2017-03-11 17:57:35 --> Utf8 Class Initialized
INFO - 2017-03-11 17:57:35 --> URI Class Initialized
DEBUG - 2017-03-11 17:57:35 --> No URI present. Default controller set.
INFO - 2017-03-11 17:57:35 --> Router Class Initialized
INFO - 2017-03-11 17:57:35 --> Output Class Initialized
INFO - 2017-03-11 17:57:35 --> Security Class Initialized
DEBUG - 2017-03-11 17:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 17:57:35 --> Input Class Initialized
INFO - 2017-03-11 17:57:35 --> Language Class Initialized
INFO - 2017-03-11 17:57:35 --> Loader Class Initialized
INFO - 2017-03-11 17:57:35 --> Database Driver Class Initialized
INFO - 2017-03-11 17:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 17:57:35 --> Controller Class Initialized
INFO - 2017-03-11 17:57:35 --> Helper loaded: url_helper
DEBUG - 2017-03-11 17:57:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 17:57:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 17:57:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 17:57:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 17:57:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 17:57:35 --> Final output sent to browser
DEBUG - 2017-03-11 17:57:35 --> Total execution time: 0.0865
INFO - 2017-03-11 18:01:11 --> Config Class Initialized
INFO - 2017-03-11 18:01:11 --> Hooks Class Initialized
DEBUG - 2017-03-11 18:01:11 --> UTF-8 Support Enabled
INFO - 2017-03-11 18:01:11 --> Utf8 Class Initialized
INFO - 2017-03-11 18:01:11 --> URI Class Initialized
DEBUG - 2017-03-11 18:01:11 --> No URI present. Default controller set.
INFO - 2017-03-11 18:01:11 --> Router Class Initialized
INFO - 2017-03-11 18:01:11 --> Output Class Initialized
INFO - 2017-03-11 18:01:11 --> Security Class Initialized
DEBUG - 2017-03-11 18:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 18:01:11 --> Input Class Initialized
INFO - 2017-03-11 18:01:11 --> Language Class Initialized
INFO - 2017-03-11 18:01:11 --> Loader Class Initialized
INFO - 2017-03-11 18:01:12 --> Database Driver Class Initialized
INFO - 2017-03-11 18:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 18:01:12 --> Controller Class Initialized
INFO - 2017-03-11 18:01:12 --> Helper loaded: url_helper
DEBUG - 2017-03-11 18:01:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 18:01:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 18:01:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 18:01:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 18:01:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 18:01:13 --> Final output sent to browser
DEBUG - 2017-03-11 18:01:13 --> Total execution time: 2.0606
INFO - 2017-03-11 18:01:37 --> Config Class Initialized
INFO - 2017-03-11 18:01:37 --> Hooks Class Initialized
DEBUG - 2017-03-11 18:01:37 --> UTF-8 Support Enabled
INFO - 2017-03-11 18:01:37 --> Utf8 Class Initialized
INFO - 2017-03-11 18:01:37 --> URI Class Initialized
INFO - 2017-03-11 18:01:37 --> Router Class Initialized
INFO - 2017-03-11 18:01:38 --> Output Class Initialized
INFO - 2017-03-11 18:01:38 --> Security Class Initialized
DEBUG - 2017-03-11 18:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 18:01:38 --> Input Class Initialized
INFO - 2017-03-11 18:01:38 --> Language Class Initialized
INFO - 2017-03-11 18:01:38 --> Loader Class Initialized
INFO - 2017-03-11 18:01:38 --> Database Driver Class Initialized
INFO - 2017-03-11 18:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 18:01:38 --> Controller Class Initialized
INFO - 2017-03-11 18:01:38 --> Helper loaded: url_helper
DEBUG - 2017-03-11 18:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 18:01:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 18:01:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 18:01:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 18:01:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 18:01:38 --> Final output sent to browser
DEBUG - 2017-03-11 18:01:38 --> Total execution time: 1.2297
INFO - 2017-03-11 18:03:23 --> Config Class Initialized
INFO - 2017-03-11 18:03:23 --> Hooks Class Initialized
DEBUG - 2017-03-11 18:03:23 --> UTF-8 Support Enabled
INFO - 2017-03-11 18:03:23 --> Utf8 Class Initialized
INFO - 2017-03-11 18:03:23 --> URI Class Initialized
INFO - 2017-03-11 18:03:23 --> Router Class Initialized
INFO - 2017-03-11 18:03:24 --> Output Class Initialized
INFO - 2017-03-11 18:03:24 --> Security Class Initialized
DEBUG - 2017-03-11 18:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 18:03:24 --> Input Class Initialized
INFO - 2017-03-11 18:03:24 --> Language Class Initialized
INFO - 2017-03-11 18:03:24 --> Loader Class Initialized
INFO - 2017-03-11 18:03:24 --> Database Driver Class Initialized
INFO - 2017-03-11 18:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 18:03:24 --> Controller Class Initialized
INFO - 2017-03-11 18:03:24 --> Helper loaded: url_helper
DEBUG - 2017-03-11 18:03:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 18:03:33 --> Config Class Initialized
INFO - 2017-03-11 18:03:33 --> Hooks Class Initialized
DEBUG - 2017-03-11 18:03:33 --> UTF-8 Support Enabled
INFO - 2017-03-11 18:03:33 --> Utf8 Class Initialized
INFO - 2017-03-11 18:03:33 --> URI Class Initialized
INFO - 2017-03-11 18:03:33 --> Router Class Initialized
INFO - 2017-03-11 18:03:33 --> Output Class Initialized
INFO - 2017-03-11 18:03:33 --> Security Class Initialized
DEBUG - 2017-03-11 18:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 18:03:33 --> Input Class Initialized
INFO - 2017-03-11 18:03:33 --> Language Class Initialized
INFO - 2017-03-11 18:03:33 --> Loader Class Initialized
INFO - 2017-03-11 18:03:34 --> Database Driver Class Initialized
INFO - 2017-03-11 18:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 18:03:34 --> Controller Class Initialized
INFO - 2017-03-11 18:03:34 --> Helper loaded: date_helper
DEBUG - 2017-03-11 18:03:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 18:03:34 --> Helper loaded: url_helper
INFO - 2017-03-11 18:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 18:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 18:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 18:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 18:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 18:03:34 --> Final output sent to browser
DEBUG - 2017-03-11 18:03:34 --> Total execution time: 1.3128
INFO - 2017-03-11 18:03:36 --> Config Class Initialized
INFO - 2017-03-11 18:03:36 --> Hooks Class Initialized
DEBUG - 2017-03-11 18:03:36 --> UTF-8 Support Enabled
INFO - 2017-03-11 18:03:36 --> Utf8 Class Initialized
INFO - 2017-03-11 18:03:36 --> URI Class Initialized
INFO - 2017-03-11 18:03:36 --> Router Class Initialized
INFO - 2017-03-11 18:03:36 --> Output Class Initialized
INFO - 2017-03-11 18:03:36 --> Security Class Initialized
DEBUG - 2017-03-11 18:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 18:03:36 --> Input Class Initialized
INFO - 2017-03-11 18:03:36 --> Language Class Initialized
INFO - 2017-03-11 18:03:36 --> Loader Class Initialized
INFO - 2017-03-11 18:03:36 --> Database Driver Class Initialized
INFO - 2017-03-11 18:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 18:03:36 --> Controller Class Initialized
INFO - 2017-03-11 18:03:36 --> Helper loaded: url_helper
DEBUG - 2017-03-11 18:03:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 18:03:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 18:03:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 18:03:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 18:03:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 18:03:36 --> Final output sent to browser
DEBUG - 2017-03-11 18:03:36 --> Total execution time: 0.2584
INFO - 2017-03-11 18:03:40 --> Config Class Initialized
INFO - 2017-03-11 18:03:40 --> Hooks Class Initialized
DEBUG - 2017-03-11 18:03:40 --> UTF-8 Support Enabled
INFO - 2017-03-11 18:03:40 --> Utf8 Class Initialized
INFO - 2017-03-11 18:03:40 --> URI Class Initialized
DEBUG - 2017-03-11 18:03:40 --> No URI present. Default controller set.
INFO - 2017-03-11 18:03:40 --> Router Class Initialized
INFO - 2017-03-11 18:03:40 --> Output Class Initialized
INFO - 2017-03-11 18:03:40 --> Security Class Initialized
DEBUG - 2017-03-11 18:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 18:03:40 --> Input Class Initialized
INFO - 2017-03-11 18:03:40 --> Language Class Initialized
INFO - 2017-03-11 18:03:40 --> Loader Class Initialized
INFO - 2017-03-11 18:03:40 --> Database Driver Class Initialized
INFO - 2017-03-11 18:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 18:03:40 --> Controller Class Initialized
INFO - 2017-03-11 18:03:40 --> Helper loaded: url_helper
DEBUG - 2017-03-11 18:03:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 18:03:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 18:03:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 18:03:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 18:03:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 18:03:41 --> Final output sent to browser
DEBUG - 2017-03-11 18:03:41 --> Total execution time: 0.0186
INFO - 2017-03-11 18:03:42 --> Config Class Initialized
INFO - 2017-03-11 18:03:42 --> Hooks Class Initialized
DEBUG - 2017-03-11 18:03:42 --> UTF-8 Support Enabled
INFO - 2017-03-11 18:03:42 --> Utf8 Class Initialized
INFO - 2017-03-11 18:03:42 --> URI Class Initialized
INFO - 2017-03-11 18:03:42 --> Router Class Initialized
INFO - 2017-03-11 18:03:42 --> Output Class Initialized
INFO - 2017-03-11 18:03:42 --> Security Class Initialized
DEBUG - 2017-03-11 18:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 18:03:42 --> Input Class Initialized
INFO - 2017-03-11 18:03:42 --> Language Class Initialized
INFO - 2017-03-11 18:03:42 --> Loader Class Initialized
INFO - 2017-03-11 18:03:42 --> Database Driver Class Initialized
INFO - 2017-03-11 18:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 18:03:42 --> Controller Class Initialized
INFO - 2017-03-11 18:03:42 --> Helper loaded: url_helper
DEBUG - 2017-03-11 18:03:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 18:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 18:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 18:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 18:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 18:03:42 --> Final output sent to browser
DEBUG - 2017-03-11 18:03:42 --> Total execution time: 0.0146
INFO - 2017-03-11 18:13:14 --> Config Class Initialized
INFO - 2017-03-11 18:13:14 --> Hooks Class Initialized
DEBUG - 2017-03-11 18:13:15 --> UTF-8 Support Enabled
INFO - 2017-03-11 18:13:15 --> Utf8 Class Initialized
INFO - 2017-03-11 18:13:15 --> URI Class Initialized
INFO - 2017-03-11 18:13:15 --> Router Class Initialized
INFO - 2017-03-11 18:13:15 --> Output Class Initialized
INFO - 2017-03-11 18:13:15 --> Security Class Initialized
DEBUG - 2017-03-11 18:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 18:13:15 --> Input Class Initialized
INFO - 2017-03-11 18:13:15 --> Language Class Initialized
INFO - 2017-03-11 18:13:15 --> Loader Class Initialized
INFO - 2017-03-11 18:13:15 --> Database Driver Class Initialized
INFO - 2017-03-11 18:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 18:13:16 --> Controller Class Initialized
INFO - 2017-03-11 18:13:16 --> Helper loaded: date_helper
DEBUG - 2017-03-11 18:13:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 18:13:16 --> Helper loaded: url_helper
INFO - 2017-03-11 18:13:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 18:13:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 18:13:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 18:13:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 18:13:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 18:13:16 --> Final output sent to browser
DEBUG - 2017-03-11 18:13:16 --> Total execution time: 2.5313
INFO - 2017-03-11 18:13:37 --> Config Class Initialized
INFO - 2017-03-11 18:13:37 --> Hooks Class Initialized
DEBUG - 2017-03-11 18:13:37 --> UTF-8 Support Enabled
INFO - 2017-03-11 18:13:37 --> Utf8 Class Initialized
INFO - 2017-03-11 18:13:37 --> URI Class Initialized
INFO - 2017-03-11 18:13:38 --> Router Class Initialized
INFO - 2017-03-11 18:13:38 --> Output Class Initialized
INFO - 2017-03-11 18:13:38 --> Security Class Initialized
DEBUG - 2017-03-11 18:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 18:13:38 --> Input Class Initialized
INFO - 2017-03-11 18:13:38 --> Language Class Initialized
INFO - 2017-03-11 18:13:38 --> Loader Class Initialized
INFO - 2017-03-11 18:13:38 --> Database Driver Class Initialized
INFO - 2017-03-11 18:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 18:13:38 --> Controller Class Initialized
INFO - 2017-03-11 18:13:38 --> Helper loaded: url_helper
DEBUG - 2017-03-11 18:13:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 18:13:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 18:13:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 18:13:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 18:13:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 18:13:39 --> Final output sent to browser
DEBUG - 2017-03-11 18:13:39 --> Total execution time: 1.5844
INFO - 2017-03-11 20:01:31 --> Config Class Initialized
INFO - 2017-03-11 20:01:31 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:01:32 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:01:32 --> Utf8 Class Initialized
INFO - 2017-03-11 20:01:32 --> URI Class Initialized
DEBUG - 2017-03-11 20:01:32 --> No URI present. Default controller set.
INFO - 2017-03-11 20:01:32 --> Router Class Initialized
INFO - 2017-03-11 20:01:32 --> Output Class Initialized
INFO - 2017-03-11 20:01:32 --> Security Class Initialized
DEBUG - 2017-03-11 20:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:01:32 --> Input Class Initialized
INFO - 2017-03-11 20:01:32 --> Language Class Initialized
INFO - 2017-03-11 20:01:32 --> Loader Class Initialized
INFO - 2017-03-11 20:01:32 --> Database Driver Class Initialized
INFO - 2017-03-11 20:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:01:33 --> Controller Class Initialized
INFO - 2017-03-11 20:01:33 --> Helper loaded: url_helper
DEBUG - 2017-03-11 20:01:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 20:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 20:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 20:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 20:01:33 --> Final output sent to browser
DEBUG - 2017-03-11 20:01:33 --> Total execution time: 1.8092
INFO - 2017-03-11 20:02:05 --> Config Class Initialized
INFO - 2017-03-11 20:02:05 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:02:05 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:02:05 --> Utf8 Class Initialized
INFO - 2017-03-11 20:02:05 --> URI Class Initialized
DEBUG - 2017-03-11 20:02:05 --> No URI present. Default controller set.
INFO - 2017-03-11 20:02:05 --> Router Class Initialized
INFO - 2017-03-11 20:02:05 --> Output Class Initialized
INFO - 2017-03-11 20:02:05 --> Security Class Initialized
DEBUG - 2017-03-11 20:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:02:05 --> Input Class Initialized
INFO - 2017-03-11 20:02:05 --> Language Class Initialized
INFO - 2017-03-11 20:02:05 --> Loader Class Initialized
INFO - 2017-03-11 20:02:06 --> Database Driver Class Initialized
INFO - 2017-03-11 20:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:02:06 --> Controller Class Initialized
INFO - 2017-03-11 20:02:06 --> Helper loaded: url_helper
DEBUG - 2017-03-11 20:02:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:02:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 20:02:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 20:02:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 20:02:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 20:02:07 --> Final output sent to browser
DEBUG - 2017-03-11 20:02:07 --> Total execution time: 1.8677
INFO - 2017-03-11 20:02:17 --> Config Class Initialized
INFO - 2017-03-11 20:02:17 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:02:17 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:02:17 --> Utf8 Class Initialized
INFO - 2017-03-11 20:02:17 --> URI Class Initialized
INFO - 2017-03-11 20:02:17 --> Router Class Initialized
INFO - 2017-03-11 20:02:17 --> Output Class Initialized
INFO - 2017-03-11 20:02:17 --> Security Class Initialized
DEBUG - 2017-03-11 20:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:02:17 --> Input Class Initialized
INFO - 2017-03-11 20:02:17 --> Language Class Initialized
INFO - 2017-03-11 20:02:17 --> Loader Class Initialized
INFO - 2017-03-11 20:02:18 --> Database Driver Class Initialized
INFO - 2017-03-11 20:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:02:18 --> Controller Class Initialized
INFO - 2017-03-11 20:02:18 --> Helper loaded: url_helper
DEBUG - 2017-03-11 20:02:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:02:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 20:02:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 20:02:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 20:02:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 20:02:18 --> Final output sent to browser
DEBUG - 2017-03-11 20:02:18 --> Total execution time: 1.3876
INFO - 2017-03-11 20:29:56 --> Config Class Initialized
INFO - 2017-03-11 20:29:56 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:29:57 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:29:57 --> Utf8 Class Initialized
INFO - 2017-03-11 20:29:57 --> URI Class Initialized
DEBUG - 2017-03-11 20:29:57 --> No URI present. Default controller set.
INFO - 2017-03-11 20:29:57 --> Router Class Initialized
INFO - 2017-03-11 20:29:57 --> Output Class Initialized
INFO - 2017-03-11 20:29:57 --> Security Class Initialized
DEBUG - 2017-03-11 20:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:29:57 --> Input Class Initialized
INFO - 2017-03-11 20:29:57 --> Language Class Initialized
INFO - 2017-03-11 20:29:57 --> Loader Class Initialized
INFO - 2017-03-11 20:29:57 --> Database Driver Class Initialized
INFO - 2017-03-11 20:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:29:58 --> Controller Class Initialized
INFO - 2017-03-11 20:29:58 --> Helper loaded: url_helper
DEBUG - 2017-03-11 20:29:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:29:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 20:29:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 20:29:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 20:29:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 20:29:59 --> Final output sent to browser
DEBUG - 2017-03-11 20:29:59 --> Total execution time: 2.3721
INFO - 2017-03-11 20:30:11 --> Config Class Initialized
INFO - 2017-03-11 20:30:11 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:30:11 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:30:11 --> Utf8 Class Initialized
INFO - 2017-03-11 20:30:11 --> URI Class Initialized
INFO - 2017-03-11 20:30:11 --> Router Class Initialized
INFO - 2017-03-11 20:30:11 --> Output Class Initialized
INFO - 2017-03-11 20:30:11 --> Security Class Initialized
DEBUG - 2017-03-11 20:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:30:12 --> Input Class Initialized
INFO - 2017-03-11 20:30:12 --> Language Class Initialized
INFO - 2017-03-11 20:30:12 --> Loader Class Initialized
INFO - 2017-03-11 20:30:12 --> Database Driver Class Initialized
INFO - 2017-03-11 20:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:30:12 --> Controller Class Initialized
INFO - 2017-03-11 20:30:12 --> Helper loaded: url_helper
DEBUG - 2017-03-11 20:30:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:30:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 20:30:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 20:30:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 20:30:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 20:30:12 --> Final output sent to browser
DEBUG - 2017-03-11 20:30:12 --> Total execution time: 1.2483
INFO - 2017-03-11 20:30:31 --> Config Class Initialized
INFO - 2017-03-11 20:30:31 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:30:31 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:30:31 --> Utf8 Class Initialized
INFO - 2017-03-11 20:30:31 --> URI Class Initialized
INFO - 2017-03-11 20:30:31 --> Router Class Initialized
INFO - 2017-03-11 20:30:31 --> Output Class Initialized
INFO - 2017-03-11 20:30:31 --> Security Class Initialized
DEBUG - 2017-03-11 20:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:30:31 --> Input Class Initialized
INFO - 2017-03-11 20:30:31 --> Language Class Initialized
INFO - 2017-03-11 20:30:31 --> Loader Class Initialized
INFO - 2017-03-11 20:30:32 --> Database Driver Class Initialized
INFO - 2017-03-11 20:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:30:32 --> Controller Class Initialized
INFO - 2017-03-11 20:30:32 --> Helper loaded: url_helper
DEBUG - 2017-03-11 20:30:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:30:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-11 20:30:33 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-11 20:30:33 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-11 20:30:33 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-11 20:30:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 20:30:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 20:30:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 20:30:33 --> Final output sent to browser
DEBUG - 2017-03-11 20:30:33 --> Total execution time: 2.3425
INFO - 2017-03-11 20:30:38 --> Config Class Initialized
INFO - 2017-03-11 20:30:38 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:30:38 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:30:38 --> Utf8 Class Initialized
INFO - 2017-03-11 20:30:38 --> URI Class Initialized
INFO - 2017-03-11 20:30:38 --> Router Class Initialized
INFO - 2017-03-11 20:30:38 --> Output Class Initialized
INFO - 2017-03-11 20:30:38 --> Security Class Initialized
DEBUG - 2017-03-11 20:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:30:38 --> Input Class Initialized
INFO - 2017-03-11 20:30:38 --> Language Class Initialized
INFO - 2017-03-11 20:30:38 --> Loader Class Initialized
INFO - 2017-03-11 20:30:38 --> Database Driver Class Initialized
INFO - 2017-03-11 20:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:30:38 --> Controller Class Initialized
INFO - 2017-03-11 20:30:38 --> Helper loaded: url_helper
DEBUG - 2017-03-11 20:30:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:30:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 20:30:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 20:30:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 20:30:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 20:30:38 --> Final output sent to browser
DEBUG - 2017-03-11 20:30:38 --> Total execution time: 0.0134
INFO - 2017-03-11 20:30:49 --> Config Class Initialized
INFO - 2017-03-11 20:30:49 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:30:49 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:30:49 --> Utf8 Class Initialized
INFO - 2017-03-11 20:30:49 --> URI Class Initialized
INFO - 2017-03-11 20:30:49 --> Router Class Initialized
INFO - 2017-03-11 20:30:49 --> Output Class Initialized
INFO - 2017-03-11 20:30:49 --> Security Class Initialized
DEBUG - 2017-03-11 20:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:30:49 --> Input Class Initialized
INFO - 2017-03-11 20:30:49 --> Language Class Initialized
INFO - 2017-03-11 20:30:49 --> Loader Class Initialized
INFO - 2017-03-11 20:30:50 --> Database Driver Class Initialized
INFO - 2017-03-11 20:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:30:50 --> Controller Class Initialized
INFO - 2017-03-11 20:30:50 --> Helper loaded: url_helper
DEBUG - 2017-03-11 20:30:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:31:02 --> Config Class Initialized
INFO - 2017-03-11 20:31:02 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:31:02 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:31:02 --> Utf8 Class Initialized
INFO - 2017-03-11 20:31:02 --> URI Class Initialized
INFO - 2017-03-11 20:31:02 --> Router Class Initialized
INFO - 2017-03-11 20:31:02 --> Output Class Initialized
INFO - 2017-03-11 20:31:02 --> Security Class Initialized
DEBUG - 2017-03-11 20:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:31:02 --> Input Class Initialized
INFO - 2017-03-11 20:31:02 --> Language Class Initialized
INFO - 2017-03-11 20:31:02 --> Loader Class Initialized
INFO - 2017-03-11 20:31:03 --> Database Driver Class Initialized
INFO - 2017-03-11 20:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:31:03 --> Controller Class Initialized
INFO - 2017-03-11 20:31:03 --> Helper loaded: date_helper
DEBUG - 2017-03-11 20:31:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:31:03 --> Helper loaded: url_helper
INFO - 2017-03-11 20:31:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 20:31:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 20:31:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 20:31:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 20:31:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 20:31:03 --> Final output sent to browser
DEBUG - 2017-03-11 20:31:03 --> Total execution time: 1.3690
INFO - 2017-03-11 20:31:12 --> Config Class Initialized
INFO - 2017-03-11 20:31:12 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:31:13 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:31:13 --> Utf8 Class Initialized
INFO - 2017-03-11 20:31:13 --> URI Class Initialized
INFO - 2017-03-11 20:31:13 --> Router Class Initialized
INFO - 2017-03-11 20:31:13 --> Output Class Initialized
INFO - 2017-03-11 20:31:13 --> Security Class Initialized
DEBUG - 2017-03-11 20:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:31:13 --> Input Class Initialized
INFO - 2017-03-11 20:31:13 --> Language Class Initialized
INFO - 2017-03-11 20:31:13 --> Loader Class Initialized
INFO - 2017-03-11 20:31:13 --> Database Driver Class Initialized
INFO - 2017-03-11 20:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:31:14 --> Controller Class Initialized
INFO - 2017-03-11 20:31:14 --> Helper loaded: url_helper
DEBUG - 2017-03-11 20:31:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:31:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 20:31:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 20:31:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 20:31:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 20:31:14 --> Final output sent to browser
DEBUG - 2017-03-11 20:31:14 --> Total execution time: 1.5211
INFO - 2017-03-11 20:31:19 --> Config Class Initialized
INFO - 2017-03-11 20:31:19 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:31:19 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:31:19 --> Utf8 Class Initialized
INFO - 2017-03-11 20:31:19 --> URI Class Initialized
INFO - 2017-03-11 20:31:19 --> Router Class Initialized
INFO - 2017-03-11 20:31:19 --> Output Class Initialized
INFO - 2017-03-11 20:31:19 --> Security Class Initialized
DEBUG - 2017-03-11 20:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:31:19 --> Input Class Initialized
INFO - 2017-03-11 20:31:19 --> Language Class Initialized
INFO - 2017-03-11 20:31:19 --> Loader Class Initialized
INFO - 2017-03-11 20:31:19 --> Database Driver Class Initialized
INFO - 2017-03-11 20:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:31:19 --> Controller Class Initialized
INFO - 2017-03-11 20:31:19 --> Helper loaded: url_helper
DEBUG - 2017-03-11 20:31:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:31:22 --> Config Class Initialized
INFO - 2017-03-11 20:31:22 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:31:22 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:31:22 --> Utf8 Class Initialized
INFO - 2017-03-11 20:31:22 --> URI Class Initialized
INFO - 2017-03-11 20:31:22 --> Router Class Initialized
INFO - 2017-03-11 20:31:22 --> Output Class Initialized
INFO - 2017-03-11 20:31:22 --> Security Class Initialized
DEBUG - 2017-03-11 20:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:31:22 --> Input Class Initialized
INFO - 2017-03-11 20:31:22 --> Language Class Initialized
INFO - 2017-03-11 20:31:22 --> Loader Class Initialized
INFO - 2017-03-11 20:31:22 --> Database Driver Class Initialized
INFO - 2017-03-11 20:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:31:22 --> Controller Class Initialized
INFO - 2017-03-11 20:31:22 --> Helper loaded: date_helper
DEBUG - 2017-03-11 20:31:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:31:22 --> Helper loaded: url_helper
INFO - 2017-03-11 20:31:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 20:31:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 20:31:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 20:31:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 20:31:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 20:31:22 --> Final output sent to browser
DEBUG - 2017-03-11 20:31:22 --> Total execution time: 0.2213
INFO - 2017-03-11 20:31:33 --> Config Class Initialized
INFO - 2017-03-11 20:31:33 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:31:33 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:31:33 --> Utf8 Class Initialized
INFO - 2017-03-11 20:31:33 --> URI Class Initialized
INFO - 2017-03-11 20:31:33 --> Router Class Initialized
INFO - 2017-03-11 20:31:33 --> Output Class Initialized
INFO - 2017-03-11 20:31:33 --> Security Class Initialized
DEBUG - 2017-03-11 20:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:31:33 --> Input Class Initialized
INFO - 2017-03-11 20:31:33 --> Language Class Initialized
INFO - 2017-03-11 20:31:33 --> Loader Class Initialized
INFO - 2017-03-11 20:31:34 --> Database Driver Class Initialized
INFO - 2017-03-11 20:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:31:34 --> Controller Class Initialized
INFO - 2017-03-11 20:31:34 --> Helper loaded: url_helper
DEBUG - 2017-03-11 20:31:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:31:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 20:31:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 20:31:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 20:31:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 20:31:34 --> Final output sent to browser
DEBUG - 2017-03-11 20:31:34 --> Total execution time: 1.4912
INFO - 2017-03-11 20:36:58 --> Config Class Initialized
INFO - 2017-03-11 20:36:58 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:36:58 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:36:58 --> Utf8 Class Initialized
INFO - 2017-03-11 20:36:58 --> URI Class Initialized
INFO - 2017-03-11 20:36:58 --> Router Class Initialized
INFO - 2017-03-11 20:36:58 --> Output Class Initialized
INFO - 2017-03-11 20:36:58 --> Security Class Initialized
DEBUG - 2017-03-11 20:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:36:58 --> Input Class Initialized
INFO - 2017-03-11 20:36:58 --> Language Class Initialized
INFO - 2017-03-11 20:36:58 --> Loader Class Initialized
INFO - 2017-03-11 20:36:59 --> Database Driver Class Initialized
INFO - 2017-03-11 20:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:36:59 --> Controller Class Initialized
INFO - 2017-03-11 20:36:59 --> Helper loaded: date_helper
DEBUG - 2017-03-11 20:36:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:36:59 --> Helper loaded: url_helper
INFO - 2017-03-11 20:36:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 20:36:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 20:36:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 20:36:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 20:36:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 20:36:59 --> Final output sent to browser
DEBUG - 2017-03-11 20:36:59 --> Total execution time: 1.7007
INFO - 2017-03-11 20:40:12 --> Config Class Initialized
INFO - 2017-03-11 20:40:12 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:40:13 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:40:13 --> Utf8 Class Initialized
INFO - 2017-03-11 20:40:13 --> URI Class Initialized
INFO - 2017-03-11 20:40:13 --> Router Class Initialized
INFO - 2017-03-11 20:40:13 --> Output Class Initialized
INFO - 2017-03-11 20:40:13 --> Security Class Initialized
DEBUG - 2017-03-11 20:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:40:13 --> Input Class Initialized
INFO - 2017-03-11 20:40:13 --> Language Class Initialized
INFO - 2017-03-11 20:40:13 --> Loader Class Initialized
INFO - 2017-03-11 20:40:13 --> Database Driver Class Initialized
INFO - 2017-03-11 20:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:40:14 --> Controller Class Initialized
INFO - 2017-03-11 20:40:14 --> Helper loaded: date_helper
DEBUG - 2017-03-11 20:40:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:40:14 --> Helper loaded: url_helper
INFO - 2017-03-11 20:40:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 20:40:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 20:40:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 20:40:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 20:40:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 20:40:14 --> Final output sent to browser
DEBUG - 2017-03-11 20:40:14 --> Total execution time: 1.9375
INFO - 2017-03-11 20:40:32 --> Config Class Initialized
INFO - 2017-03-11 20:40:32 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:40:32 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:40:32 --> Utf8 Class Initialized
INFO - 2017-03-11 20:40:32 --> URI Class Initialized
INFO - 2017-03-11 20:40:33 --> Router Class Initialized
INFO - 2017-03-11 20:40:33 --> Output Class Initialized
INFO - 2017-03-11 20:40:33 --> Security Class Initialized
DEBUG - 2017-03-11 20:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:40:33 --> Input Class Initialized
INFO - 2017-03-11 20:40:33 --> Language Class Initialized
INFO - 2017-03-11 20:40:33 --> Loader Class Initialized
INFO - 2017-03-11 20:40:33 --> Database Driver Class Initialized
INFO - 2017-03-11 20:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:40:34 --> Controller Class Initialized
INFO - 2017-03-11 20:40:34 --> Helper loaded: url_helper
DEBUG - 2017-03-11 20:40:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:40:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 20:40:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 20:40:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 20:40:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 20:40:34 --> Final output sent to browser
DEBUG - 2017-03-11 20:40:34 --> Total execution time: 2.0260
INFO - 2017-03-11 20:46:26 --> Config Class Initialized
INFO - 2017-03-11 20:46:27 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:46:27 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:46:27 --> Utf8 Class Initialized
INFO - 2017-03-11 20:46:27 --> URI Class Initialized
DEBUG - 2017-03-11 20:46:27 --> No URI present. Default controller set.
INFO - 2017-03-11 20:46:27 --> Router Class Initialized
INFO - 2017-03-11 20:46:27 --> Output Class Initialized
INFO - 2017-03-11 20:46:27 --> Security Class Initialized
DEBUG - 2017-03-11 20:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:46:27 --> Input Class Initialized
INFO - 2017-03-11 20:46:27 --> Language Class Initialized
INFO - 2017-03-11 20:46:27 --> Loader Class Initialized
INFO - 2017-03-11 20:46:27 --> Database Driver Class Initialized
INFO - 2017-03-11 20:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:46:28 --> Controller Class Initialized
INFO - 2017-03-11 20:46:28 --> Helper loaded: url_helper
DEBUG - 2017-03-11 20:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:46:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 20:46:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 20:46:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 20:46:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 20:46:28 --> Final output sent to browser
DEBUG - 2017-03-11 20:46:28 --> Total execution time: 1.8794
INFO - 2017-03-11 20:51:07 --> Config Class Initialized
INFO - 2017-03-11 20:51:07 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:51:08 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:51:08 --> Utf8 Class Initialized
INFO - 2017-03-11 20:51:08 --> URI Class Initialized
INFO - 2017-03-11 20:51:08 --> Router Class Initialized
INFO - 2017-03-11 20:51:08 --> Output Class Initialized
INFO - 2017-03-11 20:51:08 --> Security Class Initialized
DEBUG - 2017-03-11 20:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:51:08 --> Input Class Initialized
INFO - 2017-03-11 20:51:08 --> Language Class Initialized
INFO - 2017-03-11 20:51:08 --> Loader Class Initialized
INFO - 2017-03-11 20:51:08 --> Database Driver Class Initialized
INFO - 2017-03-11 20:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:51:10 --> Controller Class Initialized
INFO - 2017-03-11 20:51:10 --> Helper loaded: url_helper
DEBUG - 2017-03-11 20:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-11 20:51:10 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-11 20:51:10 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-11 20:51:10 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-11 20:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 20:51:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 20:51:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 20:51:11 --> Final output sent to browser
DEBUG - 2017-03-11 20:51:11 --> Total execution time: 3.2079
INFO - 2017-03-11 20:51:49 --> Config Class Initialized
INFO - 2017-03-11 20:51:49 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:51:49 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:51:49 --> Utf8 Class Initialized
INFO - 2017-03-11 20:51:49 --> URI Class Initialized
INFO - 2017-03-11 20:51:49 --> Router Class Initialized
INFO - 2017-03-11 20:51:50 --> Output Class Initialized
INFO - 2017-03-11 20:51:50 --> Security Class Initialized
DEBUG - 2017-03-11 20:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:51:50 --> Input Class Initialized
INFO - 2017-03-11 20:51:50 --> Language Class Initialized
INFO - 2017-03-11 20:51:50 --> Loader Class Initialized
INFO - 2017-03-11 20:51:50 --> Database Driver Class Initialized
INFO - 2017-03-11 20:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:51:50 --> Controller Class Initialized
INFO - 2017-03-11 20:51:50 --> Helper loaded: url_helper
DEBUG - 2017-03-11 20:51:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:52:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-11 20:52:03 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-11 20:52:03 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-11 20:52:03 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-11 20:52:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 20:52:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 20:52:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 20:52:03 --> Final output sent to browser
DEBUG - 2017-03-11 20:52:03 --> Total execution time: 14.0117
INFO - 2017-03-11 20:52:06 --> Config Class Initialized
INFO - 2017-03-11 20:52:06 --> Hooks Class Initialized
INFO - 2017-03-11 20:52:06 --> Config Class Initialized
INFO - 2017-03-11 20:52:06 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:52:06 --> UTF-8 Support Enabled
DEBUG - 2017-03-11 20:52:06 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:52:06 --> Utf8 Class Initialized
INFO - 2017-03-11 20:52:06 --> Utf8 Class Initialized
INFO - 2017-03-11 20:52:06 --> URI Class Initialized
INFO - 2017-03-11 20:52:06 --> URI Class Initialized
INFO - 2017-03-11 20:52:06 --> Router Class Initialized
INFO - 2017-03-11 20:52:06 --> Router Class Initialized
INFO - 2017-03-11 20:52:06 --> Output Class Initialized
INFO - 2017-03-11 20:52:06 --> Output Class Initialized
INFO - 2017-03-11 20:52:06 --> Security Class Initialized
INFO - 2017-03-11 20:52:06 --> Security Class Initialized
DEBUG - 2017-03-11 20:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:52:06 --> Input Class Initialized
DEBUG - 2017-03-11 20:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:52:07 --> Language Class Initialized
INFO - 2017-03-11 20:52:07 --> Input Class Initialized
INFO - 2017-03-11 20:52:07 --> Language Class Initialized
INFO - 2017-03-11 20:52:07 --> Loader Class Initialized
INFO - 2017-03-11 20:52:07 --> Loader Class Initialized
INFO - 2017-03-11 20:52:07 --> Database Driver Class Initialized
INFO - 2017-03-11 20:52:07 --> Database Driver Class Initialized
INFO - 2017-03-11 20:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:52:07 --> Controller Class Initialized
INFO - 2017-03-11 20:52:07 --> Helper loaded: url_helper
INFO - 2017-03-11 20:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:52:07 --> Controller Class Initialized
DEBUG - 2017-03-11 20:52:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:52:08 --> Helper loaded: date_helper
DEBUG - 2017-03-11 20:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:52:08 --> Helper loaded: url_helper
INFO - 2017-03-11 20:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-11 20:52:08 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
INFO - 2017-03-11 20:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-11 20:52:08 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-11 20:52:08 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-11 20:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 20:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 20:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 20:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 20:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 20:52:08 --> Final output sent to browser
DEBUG - 2017-03-11 20:52:08 --> Total execution time: 2.5228
INFO - 2017-03-11 20:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 20:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 20:52:08 --> Final output sent to browser
DEBUG - 2017-03-11 20:52:08 --> Total execution time: 2.5331
INFO - 2017-03-11 20:53:07 --> Config Class Initialized
INFO - 2017-03-11 20:53:07 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:53:07 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:53:07 --> Utf8 Class Initialized
INFO - 2017-03-11 20:53:07 --> URI Class Initialized
INFO - 2017-03-11 20:53:07 --> Router Class Initialized
INFO - 2017-03-11 20:53:07 --> Output Class Initialized
INFO - 2017-03-11 20:53:07 --> Security Class Initialized
DEBUG - 2017-03-11 20:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:53:07 --> Input Class Initialized
INFO - 2017-03-11 20:53:07 --> Language Class Initialized
INFO - 2017-03-11 20:53:07 --> Loader Class Initialized
INFO - 2017-03-11 20:53:08 --> Database Driver Class Initialized
INFO - 2017-03-11 20:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:53:08 --> Controller Class Initialized
INFO - 2017-03-11 20:53:08 --> Helper loaded: url_helper
DEBUG - 2017-03-11 20:53:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:53:09 --> Config Class Initialized
INFO - 2017-03-11 20:53:09 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:53:09 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:53:09 --> Utf8 Class Initialized
INFO - 2017-03-11 20:53:09 --> URI Class Initialized
INFO - 2017-03-11 20:53:09 --> Router Class Initialized
INFO - 2017-03-11 20:53:09 --> Output Class Initialized
INFO - 2017-03-11 20:53:09 --> Security Class Initialized
DEBUG - 2017-03-11 20:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:53:09 --> Input Class Initialized
INFO - 2017-03-11 20:53:09 --> Language Class Initialized
INFO - 2017-03-11 20:53:09 --> Loader Class Initialized
INFO - 2017-03-11 20:53:09 --> Database Driver Class Initialized
INFO - 2017-03-11 20:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:53:12 --> Controller Class Initialized
INFO - 2017-03-11 20:53:12 --> Helper loaded: url_helper
DEBUG - 2017-03-11 20:53:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:53:15 --> Config Class Initialized
INFO - 2017-03-11 20:53:15 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:53:15 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:53:15 --> Utf8 Class Initialized
INFO - 2017-03-11 20:53:15 --> URI Class Initialized
INFO - 2017-03-11 20:53:15 --> Router Class Initialized
INFO - 2017-03-11 20:53:15 --> Output Class Initialized
INFO - 2017-03-11 20:53:15 --> Security Class Initialized
DEBUG - 2017-03-11 20:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:53:16 --> Input Class Initialized
INFO - 2017-03-11 20:53:16 --> Language Class Initialized
INFO - 2017-03-11 20:53:16 --> Loader Class Initialized
INFO - 2017-03-11 20:53:16 --> Database Driver Class Initialized
INFO - 2017-03-11 20:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:53:16 --> Controller Class Initialized
INFO - 2017-03-11 20:53:16 --> Helper loaded: date_helper
DEBUG - 2017-03-11 20:53:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:53:16 --> Helper loaded: url_helper
INFO - 2017-03-11 20:53:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 20:53:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 20:53:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 20:53:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 20:53:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 20:53:16 --> Final output sent to browser
DEBUG - 2017-03-11 20:53:16 --> Total execution time: 1.0694
INFO - 2017-03-11 20:53:18 --> Config Class Initialized
INFO - 2017-03-11 20:53:18 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:53:18 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:53:18 --> Utf8 Class Initialized
INFO - 2017-03-11 20:53:18 --> URI Class Initialized
INFO - 2017-03-11 20:53:18 --> Router Class Initialized
INFO - 2017-03-11 20:53:18 --> Output Class Initialized
INFO - 2017-03-11 20:53:18 --> Security Class Initialized
DEBUG - 2017-03-11 20:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:53:18 --> Input Class Initialized
INFO - 2017-03-11 20:53:18 --> Language Class Initialized
INFO - 2017-03-11 20:53:18 --> Loader Class Initialized
INFO - 2017-03-11 20:53:18 --> Database Driver Class Initialized
INFO - 2017-03-11 20:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:53:18 --> Controller Class Initialized
INFO - 2017-03-11 20:53:18 --> Helper loaded: url_helper
DEBUG - 2017-03-11 20:53:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 20:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 20:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 20:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 20:53:18 --> Final output sent to browser
DEBUG - 2017-03-11 20:53:18 --> Total execution time: 0.2789
INFO - 2017-03-11 20:54:50 --> Config Class Initialized
INFO - 2017-03-11 20:54:50 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:54:51 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:54:51 --> Utf8 Class Initialized
INFO - 2017-03-11 20:54:51 --> URI Class Initialized
DEBUG - 2017-03-11 20:54:51 --> No URI present. Default controller set.
INFO - 2017-03-11 20:54:51 --> Router Class Initialized
INFO - 2017-03-11 20:54:51 --> Output Class Initialized
INFO - 2017-03-11 20:54:51 --> Security Class Initialized
DEBUG - 2017-03-11 20:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:54:51 --> Input Class Initialized
INFO - 2017-03-11 20:54:51 --> Language Class Initialized
INFO - 2017-03-11 20:54:51 --> Loader Class Initialized
INFO - 2017-03-11 20:54:51 --> Database Driver Class Initialized
INFO - 2017-03-11 20:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:54:52 --> Controller Class Initialized
INFO - 2017-03-11 20:54:52 --> Helper loaded: url_helper
DEBUG - 2017-03-11 20:54:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 20:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 20:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 20:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 20:54:52 --> Final output sent to browser
DEBUG - 2017-03-11 20:54:52 --> Total execution time: 2.0625
INFO - 2017-03-11 20:55:15 --> Config Class Initialized
INFO - 2017-03-11 20:55:15 --> Hooks Class Initialized
DEBUG - 2017-03-11 20:55:15 --> UTF-8 Support Enabled
INFO - 2017-03-11 20:55:15 --> Utf8 Class Initialized
INFO - 2017-03-11 20:55:15 --> URI Class Initialized
INFO - 2017-03-11 20:55:15 --> Router Class Initialized
INFO - 2017-03-11 20:55:15 --> Output Class Initialized
INFO - 2017-03-11 20:55:15 --> Security Class Initialized
DEBUG - 2017-03-11 20:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 20:55:15 --> Input Class Initialized
INFO - 2017-03-11 20:55:15 --> Language Class Initialized
INFO - 2017-03-11 20:55:15 --> Loader Class Initialized
INFO - 2017-03-11 20:55:16 --> Database Driver Class Initialized
INFO - 2017-03-11 20:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 20:55:16 --> Controller Class Initialized
INFO - 2017-03-11 20:55:16 --> Helper loaded: url_helper
DEBUG - 2017-03-11 20:55:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 20:55:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 20:55:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 20:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 20:55:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 20:55:17 --> Final output sent to browser
DEBUG - 2017-03-11 20:55:17 --> Total execution time: 2.1945
INFO - 2017-03-11 21:30:02 --> Config Class Initialized
INFO - 2017-03-11 21:30:02 --> Hooks Class Initialized
DEBUG - 2017-03-11 21:30:02 --> UTF-8 Support Enabled
INFO - 2017-03-11 21:30:02 --> Utf8 Class Initialized
INFO - 2017-03-11 21:30:02 --> URI Class Initialized
DEBUG - 2017-03-11 21:30:02 --> No URI present. Default controller set.
INFO - 2017-03-11 21:30:02 --> Router Class Initialized
INFO - 2017-03-11 21:30:02 --> Output Class Initialized
INFO - 2017-03-11 21:30:02 --> Security Class Initialized
DEBUG - 2017-03-11 21:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 21:30:02 --> Input Class Initialized
INFO - 2017-03-11 21:30:02 --> Language Class Initialized
INFO - 2017-03-11 21:30:02 --> Loader Class Initialized
INFO - 2017-03-11 21:30:03 --> Database Driver Class Initialized
INFO - 2017-03-11 21:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 21:30:04 --> Controller Class Initialized
INFO - 2017-03-11 21:30:04 --> Helper loaded: url_helper
DEBUG - 2017-03-11 21:30:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 21:30:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 21:30:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 21:30:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 21:30:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 21:30:04 --> Final output sent to browser
DEBUG - 2017-03-11 21:30:04 --> Total execution time: 2.5458
INFO - 2017-03-11 21:56:10 --> Config Class Initialized
INFO - 2017-03-11 21:56:10 --> Hooks Class Initialized
DEBUG - 2017-03-11 21:56:10 --> UTF-8 Support Enabled
INFO - 2017-03-11 21:56:10 --> Utf8 Class Initialized
INFO - 2017-03-11 21:56:10 --> URI Class Initialized
DEBUG - 2017-03-11 21:56:10 --> No URI present. Default controller set.
INFO - 2017-03-11 21:56:10 --> Router Class Initialized
INFO - 2017-03-11 21:56:10 --> Output Class Initialized
INFO - 2017-03-11 21:56:10 --> Security Class Initialized
DEBUG - 2017-03-11 21:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 21:56:11 --> Input Class Initialized
INFO - 2017-03-11 21:56:11 --> Language Class Initialized
INFO - 2017-03-11 21:56:11 --> Loader Class Initialized
INFO - 2017-03-11 21:56:11 --> Config Class Initialized
INFO - 2017-03-11 21:56:11 --> Hooks Class Initialized
DEBUG - 2017-03-11 21:56:11 --> UTF-8 Support Enabled
INFO - 2017-03-11 21:56:11 --> Utf8 Class Initialized
INFO - 2017-03-11 21:56:11 --> URI Class Initialized
DEBUG - 2017-03-11 21:56:11 --> No URI present. Default controller set.
INFO - 2017-03-11 21:56:11 --> Router Class Initialized
INFO - 2017-03-11 21:56:11 --> Output Class Initialized
INFO - 2017-03-11 21:56:11 --> Security Class Initialized
DEBUG - 2017-03-11 21:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 21:56:11 --> Input Class Initialized
INFO - 2017-03-11 21:56:11 --> Language Class Initialized
INFO - 2017-03-11 21:56:11 --> Loader Class Initialized
INFO - 2017-03-11 21:56:11 --> Database Driver Class Initialized
INFO - 2017-03-11 21:56:11 --> Database Driver Class Initialized
INFO - 2017-03-11 21:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 21:56:11 --> Controller Class Initialized
INFO - 2017-03-11 21:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 21:56:11 --> Controller Class Initialized
INFO - 2017-03-11 21:56:11 --> Helper loaded: url_helper
INFO - 2017-03-11 21:56:11 --> Helper loaded: url_helper
DEBUG - 2017-03-11 21:56:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-11 21:56:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 21:56:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 21:56:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 21:56:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 21:56:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 21:56:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 21:56:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 21:56:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 21:56:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 21:56:11 --> Final output sent to browser
DEBUG - 2017-03-11 21:56:11 --> Total execution time: 1.5927
INFO - 2017-03-11 21:56:11 --> Final output sent to browser
DEBUG - 2017-03-11 21:56:11 --> Total execution time: 0.7598
INFO - 2017-03-11 21:56:15 --> Config Class Initialized
INFO - 2017-03-11 21:56:15 --> Hooks Class Initialized
DEBUG - 2017-03-11 21:56:15 --> UTF-8 Support Enabled
INFO - 2017-03-11 21:56:15 --> Utf8 Class Initialized
INFO - 2017-03-11 21:56:15 --> URI Class Initialized
INFO - 2017-03-11 21:56:15 --> Router Class Initialized
INFO - 2017-03-11 21:56:15 --> Output Class Initialized
INFO - 2017-03-11 21:56:15 --> Security Class Initialized
DEBUG - 2017-03-11 21:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 21:56:15 --> Input Class Initialized
INFO - 2017-03-11 21:56:15 --> Language Class Initialized
INFO - 2017-03-11 21:56:15 --> Loader Class Initialized
INFO - 2017-03-11 21:56:15 --> Database Driver Class Initialized
INFO - 2017-03-11 21:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 21:56:15 --> Controller Class Initialized
INFO - 2017-03-11 21:56:15 --> Helper loaded: url_helper
DEBUG - 2017-03-11 21:56:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 21:56:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 21:56:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 21:56:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 21:56:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 21:56:15 --> Final output sent to browser
DEBUG - 2017-03-11 21:56:15 --> Total execution time: 0.0138
INFO - 2017-03-11 21:56:22 --> Config Class Initialized
INFO - 2017-03-11 21:56:22 --> Hooks Class Initialized
DEBUG - 2017-03-11 21:56:22 --> UTF-8 Support Enabled
INFO - 2017-03-11 21:56:22 --> Utf8 Class Initialized
INFO - 2017-03-11 21:56:22 --> URI Class Initialized
INFO - 2017-03-11 21:56:22 --> Router Class Initialized
INFO - 2017-03-11 21:56:22 --> Output Class Initialized
INFO - 2017-03-11 21:56:22 --> Security Class Initialized
DEBUG - 2017-03-11 21:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 21:56:22 --> Input Class Initialized
INFO - 2017-03-11 21:56:22 --> Language Class Initialized
INFO - 2017-03-11 21:56:22 --> Loader Class Initialized
INFO - 2017-03-11 21:56:22 --> Database Driver Class Initialized
INFO - 2017-03-11 21:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 21:56:22 --> Controller Class Initialized
INFO - 2017-03-11 21:56:22 --> Helper loaded: url_helper
DEBUG - 2017-03-11 21:56:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-11 21:56:24 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-11 21:56:24 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Janeth Femat García')
INFO - 2017-03-11 21:56:24 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-11 21:56:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-11 21:56:24 --> Config Class Initialized
INFO - 2017-03-11 21:56:24 --> Hooks Class Initialized
DEBUG - 2017-03-11 21:56:24 --> UTF-8 Support Enabled
INFO - 2017-03-11 21:56:24 --> Utf8 Class Initialized
INFO - 2017-03-11 21:56:24 --> URI Class Initialized
INFO - 2017-03-11 21:56:24 --> Router Class Initialized
INFO - 2017-03-11 21:56:24 --> Output Class Initialized
INFO - 2017-03-11 21:56:24 --> Security Class Initialized
DEBUG - 2017-03-11 21:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 21:56:24 --> Input Class Initialized
INFO - 2017-03-11 21:56:24 --> Language Class Initialized
INFO - 2017-03-11 21:56:24 --> Loader Class Initialized
INFO - 2017-03-11 21:56:24 --> Database Driver Class Initialized
INFO - 2017-03-11 21:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 21:56:24 --> Controller Class Initialized
INFO - 2017-03-11 21:56:24 --> Helper loaded: url_helper
DEBUG - 2017-03-11 21:56:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 21:56:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 21:56:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 21:56:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 21:56:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 21:56:24 --> Final output sent to browser
DEBUG - 2017-03-11 21:56:24 --> Total execution time: 0.0143
INFO - 2017-03-11 21:56:32 --> Config Class Initialized
INFO - 2017-03-11 21:56:32 --> Hooks Class Initialized
DEBUG - 2017-03-11 21:56:32 --> UTF-8 Support Enabled
INFO - 2017-03-11 21:56:32 --> Utf8 Class Initialized
INFO - 2017-03-11 21:56:32 --> URI Class Initialized
INFO - 2017-03-11 21:56:32 --> Router Class Initialized
INFO - 2017-03-11 21:56:32 --> Output Class Initialized
INFO - 2017-03-11 21:56:32 --> Security Class Initialized
DEBUG - 2017-03-11 21:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 21:56:32 --> Input Class Initialized
INFO - 2017-03-11 21:56:32 --> Language Class Initialized
INFO - 2017-03-11 21:56:32 --> Loader Class Initialized
INFO - 2017-03-11 21:56:32 --> Database Driver Class Initialized
INFO - 2017-03-11 21:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 21:56:32 --> Controller Class Initialized
INFO - 2017-03-11 21:56:32 --> Helper loaded: url_helper
DEBUG - 2017-03-11 21:56:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-11 21:56:32 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-11 21:56:32 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Janeth Femat García')
INFO - 2017-03-11 21:56:32 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-11 21:56:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-11 21:56:33 --> Config Class Initialized
INFO - 2017-03-11 21:56:33 --> Hooks Class Initialized
DEBUG - 2017-03-11 21:56:33 --> UTF-8 Support Enabled
INFO - 2017-03-11 21:56:33 --> Utf8 Class Initialized
INFO - 2017-03-11 21:56:33 --> URI Class Initialized
INFO - 2017-03-11 21:56:33 --> Router Class Initialized
INFO - 2017-03-11 21:56:33 --> Output Class Initialized
INFO - 2017-03-11 21:56:33 --> Security Class Initialized
DEBUG - 2017-03-11 21:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 21:56:33 --> Input Class Initialized
INFO - 2017-03-11 21:56:33 --> Language Class Initialized
INFO - 2017-03-11 21:56:33 --> Loader Class Initialized
INFO - 2017-03-11 21:56:33 --> Database Driver Class Initialized
INFO - 2017-03-11 21:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 21:56:33 --> Controller Class Initialized
INFO - 2017-03-11 21:56:33 --> Helper loaded: url_helper
DEBUG - 2017-03-11 21:56:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 21:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 21:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 21:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 21:56:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 21:56:33 --> Final output sent to browser
DEBUG - 2017-03-11 21:56:33 --> Total execution time: 0.0139
INFO - 2017-03-11 21:56:37 --> Config Class Initialized
INFO - 2017-03-11 21:56:37 --> Hooks Class Initialized
DEBUG - 2017-03-11 21:56:37 --> UTF-8 Support Enabled
INFO - 2017-03-11 21:56:37 --> Utf8 Class Initialized
INFO - 2017-03-11 21:56:37 --> URI Class Initialized
DEBUG - 2017-03-11 21:56:37 --> No URI present. Default controller set.
INFO - 2017-03-11 21:56:37 --> Router Class Initialized
INFO - 2017-03-11 21:56:37 --> Output Class Initialized
INFO - 2017-03-11 21:56:37 --> Security Class Initialized
DEBUG - 2017-03-11 21:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 21:56:37 --> Input Class Initialized
INFO - 2017-03-11 21:56:37 --> Language Class Initialized
INFO - 2017-03-11 21:56:37 --> Loader Class Initialized
INFO - 2017-03-11 21:56:37 --> Database Driver Class Initialized
INFO - 2017-03-11 21:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 21:56:37 --> Controller Class Initialized
INFO - 2017-03-11 21:56:37 --> Helper loaded: url_helper
DEBUG - 2017-03-11 21:56:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 21:56:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 21:56:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 21:56:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 21:56:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 21:56:37 --> Final output sent to browser
DEBUG - 2017-03-11 21:56:37 --> Total execution time: 0.0138
INFO - 2017-03-11 21:56:39 --> Config Class Initialized
INFO - 2017-03-11 21:56:39 --> Hooks Class Initialized
DEBUG - 2017-03-11 21:56:39 --> UTF-8 Support Enabled
INFO - 2017-03-11 21:56:39 --> Utf8 Class Initialized
INFO - 2017-03-11 21:56:39 --> URI Class Initialized
INFO - 2017-03-11 21:56:39 --> Router Class Initialized
INFO - 2017-03-11 21:56:39 --> Output Class Initialized
INFO - 2017-03-11 21:56:39 --> Security Class Initialized
DEBUG - 2017-03-11 21:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 21:56:39 --> Input Class Initialized
INFO - 2017-03-11 21:56:39 --> Language Class Initialized
INFO - 2017-03-11 21:56:39 --> Loader Class Initialized
INFO - 2017-03-11 21:56:39 --> Database Driver Class Initialized
INFO - 2017-03-11 21:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 21:56:39 --> Controller Class Initialized
INFO - 2017-03-11 21:56:39 --> Helper loaded: url_helper
DEBUG - 2017-03-11 21:56:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 21:56:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 21:56:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 21:56:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 21:56:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 21:56:39 --> Final output sent to browser
DEBUG - 2017-03-11 21:56:39 --> Total execution time: 0.0143
INFO - 2017-03-11 21:56:41 --> Config Class Initialized
INFO - 2017-03-11 21:56:41 --> Hooks Class Initialized
DEBUG - 2017-03-11 21:56:41 --> UTF-8 Support Enabled
INFO - 2017-03-11 21:56:41 --> Utf8 Class Initialized
INFO - 2017-03-11 21:56:41 --> URI Class Initialized
INFO - 2017-03-11 21:56:41 --> Router Class Initialized
INFO - 2017-03-11 21:56:41 --> Output Class Initialized
INFO - 2017-03-11 21:56:41 --> Security Class Initialized
DEBUG - 2017-03-11 21:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 21:56:41 --> Input Class Initialized
INFO - 2017-03-11 21:56:41 --> Language Class Initialized
INFO - 2017-03-11 21:56:41 --> Loader Class Initialized
INFO - 2017-03-11 21:56:41 --> Database Driver Class Initialized
INFO - 2017-03-11 21:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 21:56:41 --> Controller Class Initialized
INFO - 2017-03-11 21:56:41 --> Helper loaded: url_helper
DEBUG - 2017-03-11 21:56:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 21:56:41 --> Config Class Initialized
INFO - 2017-03-11 21:56:41 --> Hooks Class Initialized
DEBUG - 2017-03-11 21:56:41 --> UTF-8 Support Enabled
INFO - 2017-03-11 21:56:41 --> Utf8 Class Initialized
INFO - 2017-03-11 21:56:41 --> URI Class Initialized
INFO - 2017-03-11 21:56:41 --> Router Class Initialized
INFO - 2017-03-11 21:56:41 --> Output Class Initialized
INFO - 2017-03-11 21:56:41 --> Security Class Initialized
DEBUG - 2017-03-11 21:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 21:56:41 --> Input Class Initialized
INFO - 2017-03-11 21:56:41 --> Language Class Initialized
INFO - 2017-03-11 21:56:41 --> Loader Class Initialized
INFO - 2017-03-11 21:56:41 --> Database Driver Class Initialized
INFO - 2017-03-11 21:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 21:56:41 --> Controller Class Initialized
INFO - 2017-03-11 21:56:41 --> Helper loaded: date_helper
DEBUG - 2017-03-11 21:56:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 21:56:42 --> Helper loaded: url_helper
INFO - 2017-03-11 21:56:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 21:56:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 21:56:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 21:56:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 21:56:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 21:56:42 --> Final output sent to browser
DEBUG - 2017-03-11 21:56:42 --> Total execution time: 0.3874
INFO - 2017-03-11 21:56:43 --> Config Class Initialized
INFO - 2017-03-11 21:56:43 --> Hooks Class Initialized
DEBUG - 2017-03-11 21:56:43 --> UTF-8 Support Enabled
INFO - 2017-03-11 21:56:43 --> Utf8 Class Initialized
INFO - 2017-03-11 21:56:43 --> URI Class Initialized
INFO - 2017-03-11 21:56:43 --> Router Class Initialized
INFO - 2017-03-11 21:56:43 --> Output Class Initialized
INFO - 2017-03-11 21:56:43 --> Security Class Initialized
DEBUG - 2017-03-11 21:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 21:56:43 --> Input Class Initialized
INFO - 2017-03-11 21:56:43 --> Language Class Initialized
INFO - 2017-03-11 21:56:43 --> Loader Class Initialized
INFO - 2017-03-11 21:56:43 --> Database Driver Class Initialized
INFO - 2017-03-11 21:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 21:56:43 --> Controller Class Initialized
INFO - 2017-03-11 21:56:43 --> Helper loaded: url_helper
DEBUG - 2017-03-11 21:56:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 21:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 21:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 21:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 21:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 21:56:43 --> Final output sent to browser
DEBUG - 2017-03-11 21:56:43 --> Total execution time: 0.0141
INFO - 2017-03-11 22:39:44 --> Config Class Initialized
INFO - 2017-03-11 22:39:44 --> Hooks Class Initialized
DEBUG - 2017-03-11 22:39:44 --> UTF-8 Support Enabled
INFO - 2017-03-11 22:39:44 --> Utf8 Class Initialized
INFO - 2017-03-11 22:39:44 --> URI Class Initialized
DEBUG - 2017-03-11 22:39:44 --> No URI present. Default controller set.
INFO - 2017-03-11 22:39:44 --> Router Class Initialized
INFO - 2017-03-11 22:39:44 --> Output Class Initialized
INFO - 2017-03-11 22:39:44 --> Security Class Initialized
DEBUG - 2017-03-11 22:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 22:39:44 --> Input Class Initialized
INFO - 2017-03-11 22:39:44 --> Language Class Initialized
INFO - 2017-03-11 22:39:44 --> Loader Class Initialized
INFO - 2017-03-11 22:39:45 --> Database Driver Class Initialized
INFO - 2017-03-11 22:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 22:39:45 --> Controller Class Initialized
INFO - 2017-03-11 22:39:45 --> Helper loaded: url_helper
DEBUG - 2017-03-11 22:39:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 22:39:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 22:39:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 22:39:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 22:39:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 22:39:45 --> Final output sent to browser
DEBUG - 2017-03-11 22:39:45 --> Total execution time: 1.7538
INFO - 2017-03-11 22:40:53 --> Config Class Initialized
INFO - 2017-03-11 22:40:53 --> Hooks Class Initialized
DEBUG - 2017-03-11 22:40:53 --> UTF-8 Support Enabled
INFO - 2017-03-11 22:40:53 --> Utf8 Class Initialized
INFO - 2017-03-11 22:40:53 --> URI Class Initialized
INFO - 2017-03-11 22:40:54 --> Router Class Initialized
INFO - 2017-03-11 22:40:54 --> Output Class Initialized
INFO - 2017-03-11 22:40:54 --> Security Class Initialized
DEBUG - 2017-03-11 22:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 22:40:54 --> Input Class Initialized
INFO - 2017-03-11 22:40:54 --> Language Class Initialized
INFO - 2017-03-11 22:40:54 --> Loader Class Initialized
INFO - 2017-03-11 22:40:54 --> Database Driver Class Initialized
INFO - 2017-03-11 22:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 22:40:54 --> Controller Class Initialized
INFO - 2017-03-11 22:40:54 --> Helper loaded: url_helper
DEBUG - 2017-03-11 22:40:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 22:40:59 --> Config Class Initialized
INFO - 2017-03-11 22:40:59 --> Hooks Class Initialized
DEBUG - 2017-03-11 22:40:59 --> UTF-8 Support Enabled
INFO - 2017-03-11 22:40:59 --> Utf8 Class Initialized
INFO - 2017-03-11 22:40:59 --> URI Class Initialized
INFO - 2017-03-11 22:40:59 --> Router Class Initialized
INFO - 2017-03-11 22:40:59 --> Output Class Initialized
INFO - 2017-03-11 22:40:59 --> Security Class Initialized
DEBUG - 2017-03-11 22:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 22:40:59 --> Input Class Initialized
INFO - 2017-03-11 22:40:59 --> Language Class Initialized
INFO - 2017-03-11 22:40:59 --> Loader Class Initialized
INFO - 2017-03-11 22:41:00 --> Database Driver Class Initialized
INFO - 2017-03-11 22:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 22:41:00 --> Controller Class Initialized
INFO - 2017-03-11 22:41:00 --> Helper loaded: date_helper
DEBUG - 2017-03-11 22:41:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 22:41:00 --> Helper loaded: url_helper
INFO - 2017-03-11 22:41:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 22:41:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-11 22:41:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-11 22:41:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-11 22:41:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 22:41:00 --> Final output sent to browser
DEBUG - 2017-03-11 22:41:00 --> Total execution time: 1.1127
INFO - 2017-03-11 23:16:59 --> Config Class Initialized
INFO - 2017-03-11 23:16:59 --> Hooks Class Initialized
DEBUG - 2017-03-11 23:16:59 --> UTF-8 Support Enabled
INFO - 2017-03-11 23:16:59 --> Utf8 Class Initialized
INFO - 2017-03-11 23:17:00 --> URI Class Initialized
INFO - 2017-03-11 23:17:00 --> Router Class Initialized
INFO - 2017-03-11 23:17:00 --> Output Class Initialized
INFO - 2017-03-11 23:17:00 --> Security Class Initialized
DEBUG - 2017-03-11 23:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 23:17:00 --> Input Class Initialized
INFO - 2017-03-11 23:17:00 --> Language Class Initialized
INFO - 2017-03-11 23:17:00 --> Loader Class Initialized
INFO - 2017-03-11 23:17:00 --> Database Driver Class Initialized
INFO - 2017-03-11 23:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 23:17:01 --> Controller Class Initialized
INFO - 2017-03-11 23:17:01 --> Helper loaded: url_helper
DEBUG - 2017-03-11 23:17:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 23:17:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 23:17:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 23:17:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 23:17:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 23:17:02 --> Final output sent to browser
DEBUG - 2017-03-11 23:17:02 --> Total execution time: 3.2256
INFO - 2017-03-11 23:17:14 --> Config Class Initialized
INFO - 2017-03-11 23:17:14 --> Hooks Class Initialized
DEBUG - 2017-03-11 23:17:15 --> UTF-8 Support Enabled
INFO - 2017-03-11 23:17:15 --> Utf8 Class Initialized
INFO - 2017-03-11 23:17:15 --> URI Class Initialized
INFO - 2017-03-11 23:17:15 --> Router Class Initialized
INFO - 2017-03-11 23:17:15 --> Output Class Initialized
INFO - 2017-03-11 23:17:15 --> Security Class Initialized
DEBUG - 2017-03-11 23:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 23:17:16 --> Input Class Initialized
INFO - 2017-03-11 23:17:16 --> Language Class Initialized
INFO - 2017-03-11 23:17:16 --> Loader Class Initialized
INFO - 2017-03-11 23:17:16 --> Database Driver Class Initialized
INFO - 2017-03-11 23:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 23:17:17 --> Controller Class Initialized
INFO - 2017-03-11 23:17:17 --> Helper loaded: url_helper
DEBUG - 2017-03-11 23:17:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 23:17:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 23:17:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 23:17:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 23:17:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 23:17:17 --> Final output sent to browser
DEBUG - 2017-03-11 23:17:17 --> Total execution time: 5.0337
INFO - 2017-03-11 23:37:56 --> Config Class Initialized
INFO - 2017-03-11 23:37:56 --> Hooks Class Initialized
DEBUG - 2017-03-11 23:37:56 --> UTF-8 Support Enabled
INFO - 2017-03-11 23:37:56 --> Config Class Initialized
INFO - 2017-03-11 23:37:56 --> Utf8 Class Initialized
INFO - 2017-03-11 23:37:56 --> Hooks Class Initialized
INFO - 2017-03-11 23:37:56 --> URI Class Initialized
DEBUG - 2017-03-11 23:37:56 --> UTF-8 Support Enabled
INFO - 2017-03-11 23:37:56 --> Utf8 Class Initialized
INFO - 2017-03-11 23:37:56 --> Router Class Initialized
INFO - 2017-03-11 23:37:56 --> URI Class Initialized
INFO - 2017-03-11 23:37:56 --> Router Class Initialized
INFO - 2017-03-11 23:37:56 --> Output Class Initialized
INFO - 2017-03-11 23:37:56 --> Output Class Initialized
INFO - 2017-03-11 23:37:56 --> Security Class Initialized
INFO - 2017-03-11 23:37:57 --> Security Class Initialized
DEBUG - 2017-03-11 23:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-03-11 23:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-11 23:37:57 --> Input Class Initialized
INFO - 2017-03-11 23:37:57 --> Input Class Initialized
INFO - 2017-03-11 23:37:57 --> Language Class Initialized
INFO - 2017-03-11 23:37:57 --> Language Class Initialized
INFO - 2017-03-11 23:37:57 --> Loader Class Initialized
INFO - 2017-03-11 23:37:57 --> Loader Class Initialized
INFO - 2017-03-11 23:37:57 --> Database Driver Class Initialized
INFO - 2017-03-11 23:37:57 --> Database Driver Class Initialized
INFO - 2017-03-11 23:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 23:37:57 --> Controller Class Initialized
INFO - 2017-03-11 23:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-11 23:37:57 --> Helper loaded: url_helper
INFO - 2017-03-11 23:37:57 --> Controller Class Initialized
INFO - 2017-03-11 23:37:57 --> Helper loaded: url_helper
DEBUG - 2017-03-11 23:37:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-11 23:37:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-11 23:37:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-11 23:37:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-11 23:37:58 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-11 23:37:58 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-11 23:37:58 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-11 23:37:58 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-11 23:37:58 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
ERROR - 2017-03-11 23:37:58 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-11 23:37:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 23:37:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-11 23:37:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 23:37:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-11 23:37:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 23:37:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-11 23:37:58 --> Final output sent to browser
DEBUG - 2017-03-11 23:37:58 --> Total execution time: 6.2129
INFO - 2017-03-11 23:37:58 --> Final output sent to browser
DEBUG - 2017-03-11 23:37:58 --> Total execution time: 6.2125

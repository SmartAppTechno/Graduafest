<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-17 01:04:05 --> Config Class Initialized
INFO - 2017-02-17 01:04:05 --> Hooks Class Initialized
DEBUG - 2017-02-17 01:04:05 --> UTF-8 Support Enabled
INFO - 2017-02-17 01:04:05 --> Utf8 Class Initialized
INFO - 2017-02-17 01:04:05 --> URI Class Initialized
INFO - 2017-02-17 01:04:05 --> Router Class Initialized
INFO - 2017-02-17 01:04:05 --> Output Class Initialized
INFO - 2017-02-17 01:04:05 --> Security Class Initialized
DEBUG - 2017-02-17 01:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 01:04:05 --> Input Class Initialized
INFO - 2017-02-17 01:04:05 --> Language Class Initialized
INFO - 2017-02-17 01:04:05 --> Loader Class Initialized
INFO - 2017-02-17 01:04:05 --> Database Driver Class Initialized
INFO - 2017-02-17 01:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 01:04:05 --> Controller Class Initialized
INFO - 2017-02-17 01:04:05 --> Helper loaded: url_helper
DEBUG - 2017-02-17 01:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 01:04:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 01:04:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 01:04:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 01:04:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 01:04:05 --> Final output sent to browser
DEBUG - 2017-02-17 01:04:05 --> Total execution time: 0.0145
INFO - 2017-02-17 02:25:08 --> Config Class Initialized
INFO - 2017-02-17 02:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 02:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 02:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 02:25:08 --> URI Class Initialized
DEBUG - 2017-02-17 02:25:08 --> No URI present. Default controller set.
INFO - 2017-02-17 02:25:08 --> Router Class Initialized
INFO - 2017-02-17 02:25:08 --> Output Class Initialized
INFO - 2017-02-17 02:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 02:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 02:25:08 --> Input Class Initialized
INFO - 2017-02-17 02:25:08 --> Language Class Initialized
INFO - 2017-02-17 02:25:08 --> Loader Class Initialized
INFO - 2017-02-17 02:25:08 --> Database Driver Class Initialized
INFO - 2017-02-17 02:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 02:25:08 --> Controller Class Initialized
INFO - 2017-02-17 02:25:08 --> Helper loaded: url_helper
DEBUG - 2017-02-17 02:25:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 02:25:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 02:25:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 02:25:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 02:25:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 02:25:08 --> Final output sent to browser
DEBUG - 2017-02-17 02:25:08 --> Total execution time: 0.0138
INFO - 2017-02-17 02:25:12 --> Config Class Initialized
INFO - 2017-02-17 02:25:12 --> Hooks Class Initialized
DEBUG - 2017-02-17 02:25:12 --> UTF-8 Support Enabled
INFO - 2017-02-17 02:25:12 --> Utf8 Class Initialized
INFO - 2017-02-17 02:25:12 --> URI Class Initialized
INFO - 2017-02-17 02:25:12 --> Router Class Initialized
INFO - 2017-02-17 02:25:12 --> Output Class Initialized
INFO - 2017-02-17 02:25:12 --> Security Class Initialized
DEBUG - 2017-02-17 02:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 02:25:12 --> Input Class Initialized
INFO - 2017-02-17 02:25:12 --> Language Class Initialized
INFO - 2017-02-17 02:25:12 --> Loader Class Initialized
INFO - 2017-02-17 02:25:12 --> Database Driver Class Initialized
INFO - 2017-02-17 02:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 02:25:12 --> Controller Class Initialized
INFO - 2017-02-17 02:25:12 --> Helper loaded: url_helper
DEBUG - 2017-02-17 02:25:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 02:25:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 02:25:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 02:25:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 02:25:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 02:25:12 --> Final output sent to browser
DEBUG - 2017-02-17 02:25:12 --> Total execution time: 0.0142
INFO - 2017-02-17 02:25:41 --> Config Class Initialized
INFO - 2017-02-17 02:25:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 02:25:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 02:25:41 --> Utf8 Class Initialized
INFO - 2017-02-17 02:25:41 --> URI Class Initialized
DEBUG - 2017-02-17 02:25:41 --> No URI present. Default controller set.
INFO - 2017-02-17 02:25:41 --> Router Class Initialized
INFO - 2017-02-17 02:25:41 --> Output Class Initialized
INFO - 2017-02-17 02:25:41 --> Security Class Initialized
DEBUG - 2017-02-17 02:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 02:25:41 --> Input Class Initialized
INFO - 2017-02-17 02:25:41 --> Language Class Initialized
INFO - 2017-02-17 02:25:41 --> Loader Class Initialized
INFO - 2017-02-17 02:25:41 --> Database Driver Class Initialized
INFO - 2017-02-17 02:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 02:25:41 --> Controller Class Initialized
INFO - 2017-02-17 02:25:41 --> Helper loaded: url_helper
DEBUG - 2017-02-17 02:25:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 02:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 02:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 02:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 02:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 02:25:41 --> Final output sent to browser
DEBUG - 2017-02-17 02:25:41 --> Total execution time: 0.0135
INFO - 2017-02-17 02:25:43 --> Config Class Initialized
INFO - 2017-02-17 02:25:43 --> Hooks Class Initialized
DEBUG - 2017-02-17 02:25:43 --> UTF-8 Support Enabled
INFO - 2017-02-17 02:25:43 --> Utf8 Class Initialized
INFO - 2017-02-17 02:25:43 --> URI Class Initialized
INFO - 2017-02-17 02:25:43 --> Router Class Initialized
INFO - 2017-02-17 02:25:43 --> Output Class Initialized
INFO - 2017-02-17 02:25:43 --> Security Class Initialized
DEBUG - 2017-02-17 02:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 02:25:43 --> Input Class Initialized
INFO - 2017-02-17 02:25:43 --> Language Class Initialized
INFO - 2017-02-17 02:25:43 --> Loader Class Initialized
INFO - 2017-02-17 02:25:43 --> Database Driver Class Initialized
INFO - 2017-02-17 02:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 02:25:43 --> Controller Class Initialized
INFO - 2017-02-17 02:25:43 --> Helper loaded: url_helper
DEBUG - 2017-02-17 02:25:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 02:25:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 02:25:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 02:25:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 02:25:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 02:25:43 --> Final output sent to browser
DEBUG - 2017-02-17 02:25:43 --> Total execution time: 0.0141
INFO - 2017-02-17 02:26:44 --> Config Class Initialized
INFO - 2017-02-17 02:26:44 --> Hooks Class Initialized
DEBUG - 2017-02-17 02:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-17 02:26:44 --> Utf8 Class Initialized
INFO - 2017-02-17 02:26:44 --> URI Class Initialized
INFO - 2017-02-17 02:26:44 --> Router Class Initialized
INFO - 2017-02-17 02:26:44 --> Output Class Initialized
INFO - 2017-02-17 02:26:44 --> Security Class Initialized
DEBUG - 2017-02-17 02:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 02:26:44 --> Input Class Initialized
INFO - 2017-02-17 02:26:44 --> Language Class Initialized
INFO - 2017-02-17 02:26:44 --> Loader Class Initialized
INFO - 2017-02-17 02:26:44 --> Database Driver Class Initialized
INFO - 2017-02-17 02:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 02:26:44 --> Controller Class Initialized
INFO - 2017-02-17 02:26:44 --> Helper loaded: url_helper
DEBUG - 2017-02-17 02:26:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-17 02:26:46 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-17 02:26:46 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jesús Iván')
INFO - 2017-02-17 02:26:46 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-17 02:26:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-17 02:26:46 --> Config Class Initialized
INFO - 2017-02-17 02:26:46 --> Hooks Class Initialized
DEBUG - 2017-02-17 02:26:46 --> UTF-8 Support Enabled
INFO - 2017-02-17 02:26:46 --> Utf8 Class Initialized
INFO - 2017-02-17 02:26:46 --> URI Class Initialized
INFO - 2017-02-17 02:26:46 --> Router Class Initialized
INFO - 2017-02-17 02:26:46 --> Output Class Initialized
INFO - 2017-02-17 02:26:46 --> Security Class Initialized
DEBUG - 2017-02-17 02:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 02:26:46 --> Input Class Initialized
INFO - 2017-02-17 02:26:46 --> Language Class Initialized
INFO - 2017-02-17 02:26:46 --> Loader Class Initialized
INFO - 2017-02-17 02:26:46 --> Database Driver Class Initialized
INFO - 2017-02-17 02:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 02:26:46 --> Controller Class Initialized
INFO - 2017-02-17 02:26:46 --> Helper loaded: url_helper
DEBUG - 2017-02-17 02:26:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 02:26:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 02:26:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 02:26:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 02:26:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 02:26:46 --> Final output sent to browser
DEBUG - 2017-02-17 02:26:46 --> Total execution time: 0.0134
INFO - 2017-02-17 02:26:49 --> Config Class Initialized
INFO - 2017-02-17 02:26:49 --> Hooks Class Initialized
DEBUG - 2017-02-17 02:26:49 --> UTF-8 Support Enabled
INFO - 2017-02-17 02:26:49 --> Utf8 Class Initialized
INFO - 2017-02-17 02:26:49 --> URI Class Initialized
INFO - 2017-02-17 02:26:49 --> Router Class Initialized
INFO - 2017-02-17 02:26:49 --> Output Class Initialized
INFO - 2017-02-17 02:26:49 --> Security Class Initialized
DEBUG - 2017-02-17 02:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 02:26:49 --> Input Class Initialized
INFO - 2017-02-17 02:26:49 --> Language Class Initialized
INFO - 2017-02-17 02:26:49 --> Loader Class Initialized
INFO - 2017-02-17 02:26:49 --> Database Driver Class Initialized
INFO - 2017-02-17 02:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 02:26:49 --> Controller Class Initialized
INFO - 2017-02-17 02:26:49 --> Helper loaded: url_helper
DEBUG - 2017-02-17 02:26:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-17 02:26:49 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-17 02:26:49 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jesús Iván')
INFO - 2017-02-17 02:26:49 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-17 02:26:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-17 02:26:50 --> Config Class Initialized
INFO - 2017-02-17 02:26:50 --> Hooks Class Initialized
DEBUG - 2017-02-17 02:26:50 --> UTF-8 Support Enabled
INFO - 2017-02-17 02:26:50 --> Utf8 Class Initialized
INFO - 2017-02-17 02:26:50 --> URI Class Initialized
INFO - 2017-02-17 02:26:50 --> Router Class Initialized
INFO - 2017-02-17 02:26:50 --> Output Class Initialized
INFO - 2017-02-17 02:26:50 --> Security Class Initialized
DEBUG - 2017-02-17 02:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 02:26:50 --> Input Class Initialized
INFO - 2017-02-17 02:26:50 --> Language Class Initialized
INFO - 2017-02-17 02:26:50 --> Loader Class Initialized
INFO - 2017-02-17 02:26:50 --> Database Driver Class Initialized
INFO - 2017-02-17 02:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 02:26:50 --> Controller Class Initialized
INFO - 2017-02-17 02:26:50 --> Helper loaded: url_helper
DEBUG - 2017-02-17 02:26:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 02:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 02:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 02:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 02:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 02:26:50 --> Final output sent to browser
DEBUG - 2017-02-17 02:26:50 --> Total execution time: 0.0139
INFO - 2017-02-17 02:26:55 --> Config Class Initialized
INFO - 2017-02-17 02:26:55 --> Hooks Class Initialized
DEBUG - 2017-02-17 02:26:55 --> UTF-8 Support Enabled
INFO - 2017-02-17 02:26:55 --> Utf8 Class Initialized
INFO - 2017-02-17 02:26:55 --> URI Class Initialized
INFO - 2017-02-17 02:26:55 --> Router Class Initialized
INFO - 2017-02-17 02:26:55 --> Output Class Initialized
INFO - 2017-02-17 02:26:55 --> Security Class Initialized
DEBUG - 2017-02-17 02:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 02:26:55 --> Input Class Initialized
INFO - 2017-02-17 02:26:55 --> Language Class Initialized
INFO - 2017-02-17 02:26:55 --> Loader Class Initialized
INFO - 2017-02-17 02:26:55 --> Database Driver Class Initialized
INFO - 2017-02-17 02:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 02:26:55 --> Controller Class Initialized
INFO - 2017-02-17 02:26:55 --> Helper loaded: url_helper
DEBUG - 2017-02-17 02:26:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-17 02:26:55 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-17 02:26:55 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jesús Iván')
INFO - 2017-02-17 02:26:55 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-17 02:26:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-17 02:26:56 --> Config Class Initialized
INFO - 2017-02-17 02:26:56 --> Hooks Class Initialized
DEBUG - 2017-02-17 02:26:56 --> UTF-8 Support Enabled
INFO - 2017-02-17 02:26:56 --> Utf8 Class Initialized
INFO - 2017-02-17 02:26:56 --> URI Class Initialized
INFO - 2017-02-17 02:26:56 --> Router Class Initialized
INFO - 2017-02-17 02:26:56 --> Output Class Initialized
INFO - 2017-02-17 02:26:56 --> Security Class Initialized
DEBUG - 2017-02-17 02:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 02:26:56 --> Input Class Initialized
INFO - 2017-02-17 02:26:56 --> Language Class Initialized
INFO - 2017-02-17 02:26:56 --> Loader Class Initialized
INFO - 2017-02-17 02:26:56 --> Database Driver Class Initialized
INFO - 2017-02-17 02:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 02:26:56 --> Controller Class Initialized
INFO - 2017-02-17 02:26:56 --> Helper loaded: url_helper
DEBUG - 2017-02-17 02:26:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 02:26:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 02:26:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 02:26:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 02:26:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 02:26:56 --> Final output sent to browser
DEBUG - 2017-02-17 02:26:56 --> Total execution time: 0.0132
INFO - 2017-02-17 02:26:57 --> Config Class Initialized
INFO - 2017-02-17 02:26:57 --> Hooks Class Initialized
DEBUG - 2017-02-17 02:26:57 --> UTF-8 Support Enabled
INFO - 2017-02-17 02:26:57 --> Utf8 Class Initialized
INFO - 2017-02-17 02:26:57 --> URI Class Initialized
DEBUG - 2017-02-17 02:26:57 --> No URI present. Default controller set.
INFO - 2017-02-17 02:26:57 --> Router Class Initialized
INFO - 2017-02-17 02:26:57 --> Output Class Initialized
INFO - 2017-02-17 02:26:57 --> Security Class Initialized
DEBUG - 2017-02-17 02:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 02:26:57 --> Input Class Initialized
INFO - 2017-02-17 02:26:57 --> Language Class Initialized
INFO - 2017-02-17 02:26:57 --> Loader Class Initialized
INFO - 2017-02-17 02:26:57 --> Database Driver Class Initialized
INFO - 2017-02-17 02:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 02:26:57 --> Controller Class Initialized
INFO - 2017-02-17 02:26:57 --> Helper loaded: url_helper
DEBUG - 2017-02-17 02:26:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 02:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 02:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 02:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 02:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 02:26:57 --> Final output sent to browser
DEBUG - 2017-02-17 02:26:57 --> Total execution time: 0.0133
INFO - 2017-02-17 02:26:59 --> Config Class Initialized
INFO - 2017-02-17 02:26:59 --> Hooks Class Initialized
DEBUG - 2017-02-17 02:26:59 --> UTF-8 Support Enabled
INFO - 2017-02-17 02:26:59 --> Utf8 Class Initialized
INFO - 2017-02-17 02:26:59 --> URI Class Initialized
INFO - 2017-02-17 02:26:59 --> Router Class Initialized
INFO - 2017-02-17 02:26:59 --> Output Class Initialized
INFO - 2017-02-17 02:26:59 --> Security Class Initialized
DEBUG - 2017-02-17 02:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 02:26:59 --> Input Class Initialized
INFO - 2017-02-17 02:26:59 --> Language Class Initialized
INFO - 2017-02-17 02:26:59 --> Loader Class Initialized
INFO - 2017-02-17 02:26:59 --> Database Driver Class Initialized
INFO - 2017-02-17 02:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 02:26:59 --> Controller Class Initialized
INFO - 2017-02-17 02:26:59 --> Helper loaded: url_helper
DEBUG - 2017-02-17 02:26:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 02:26:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 02:26:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 02:26:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 02:26:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 02:26:59 --> Final output sent to browser
DEBUG - 2017-02-17 02:26:59 --> Total execution time: 0.0157
INFO - 2017-02-17 02:27:04 --> Config Class Initialized
INFO - 2017-02-17 02:27:04 --> Hooks Class Initialized
DEBUG - 2017-02-17 02:27:04 --> UTF-8 Support Enabled
INFO - 2017-02-17 02:27:04 --> Utf8 Class Initialized
INFO - 2017-02-17 02:27:04 --> URI Class Initialized
INFO - 2017-02-17 02:27:04 --> Router Class Initialized
INFO - 2017-02-17 02:27:04 --> Output Class Initialized
INFO - 2017-02-17 02:27:04 --> Security Class Initialized
DEBUG - 2017-02-17 02:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 02:27:04 --> Input Class Initialized
INFO - 2017-02-17 02:27:04 --> Language Class Initialized
INFO - 2017-02-17 02:27:04 --> Loader Class Initialized
INFO - 2017-02-17 02:27:04 --> Database Driver Class Initialized
INFO - 2017-02-17 02:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 02:27:04 --> Controller Class Initialized
INFO - 2017-02-17 02:27:04 --> Helper loaded: url_helper
DEBUG - 2017-02-17 02:27:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-17 02:27:05 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-17 02:27:05 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jesús Iván')
INFO - 2017-02-17 02:27:05 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-17 02:27:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-17 02:27:06 --> Config Class Initialized
INFO - 2017-02-17 02:27:06 --> Hooks Class Initialized
DEBUG - 2017-02-17 02:27:06 --> UTF-8 Support Enabled
INFO - 2017-02-17 02:27:06 --> Utf8 Class Initialized
INFO - 2017-02-17 02:27:06 --> URI Class Initialized
INFO - 2017-02-17 02:27:06 --> Router Class Initialized
INFO - 2017-02-17 02:27:06 --> Output Class Initialized
INFO - 2017-02-17 02:27:06 --> Security Class Initialized
DEBUG - 2017-02-17 02:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 02:27:06 --> Input Class Initialized
INFO - 2017-02-17 02:27:06 --> Language Class Initialized
INFO - 2017-02-17 02:27:06 --> Loader Class Initialized
INFO - 2017-02-17 02:27:06 --> Database Driver Class Initialized
INFO - 2017-02-17 02:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 02:27:06 --> Controller Class Initialized
INFO - 2017-02-17 02:27:06 --> Helper loaded: url_helper
DEBUG - 2017-02-17 02:27:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 02:27:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 02:27:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 02:27:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 02:27:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 02:27:06 --> Final output sent to browser
DEBUG - 2017-02-17 02:27:06 --> Total execution time: 0.0143
INFO - 2017-02-17 04:23:25 --> Config Class Initialized
INFO - 2017-02-17 04:23:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 04:23:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 04:23:25 --> Utf8 Class Initialized
INFO - 2017-02-17 04:23:25 --> URI Class Initialized
DEBUG - 2017-02-17 04:23:25 --> No URI present. Default controller set.
INFO - 2017-02-17 04:23:25 --> Router Class Initialized
INFO - 2017-02-17 04:23:25 --> Output Class Initialized
INFO - 2017-02-17 04:23:25 --> Security Class Initialized
DEBUG - 2017-02-17 04:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 04:23:25 --> Input Class Initialized
INFO - 2017-02-17 04:23:25 --> Language Class Initialized
INFO - 2017-02-17 04:23:25 --> Loader Class Initialized
INFO - 2017-02-17 04:23:25 --> Database Driver Class Initialized
INFO - 2017-02-17 04:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 04:23:25 --> Controller Class Initialized
INFO - 2017-02-17 04:23:25 --> Helper loaded: url_helper
DEBUG - 2017-02-17 04:23:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 04:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 04:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 04:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 04:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 04:23:25 --> Final output sent to browser
DEBUG - 2017-02-17 04:23:25 --> Total execution time: 0.0136
INFO - 2017-02-17 04:45:30 --> Config Class Initialized
INFO - 2017-02-17 04:45:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 04:45:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 04:45:30 --> Utf8 Class Initialized
INFO - 2017-02-17 04:45:30 --> URI Class Initialized
INFO - 2017-02-17 04:45:30 --> Router Class Initialized
INFO - 2017-02-17 04:45:30 --> Output Class Initialized
INFO - 2017-02-17 04:45:30 --> Security Class Initialized
DEBUG - 2017-02-17 04:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 04:45:30 --> Input Class Initialized
INFO - 2017-02-17 04:45:30 --> Language Class Initialized
INFO - 2017-02-17 04:45:30 --> Loader Class Initialized
INFO - 2017-02-17 04:45:30 --> Database Driver Class Initialized
INFO - 2017-02-17 04:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 04:45:30 --> Controller Class Initialized
INFO - 2017-02-17 04:45:30 --> Helper loaded: url_helper
DEBUG - 2017-02-17 04:45:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 04:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-17 04:45:30 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-17 04:45:30 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-17 04:45:30 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-17 04:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 04:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 04:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 04:45:30 --> Final output sent to browser
DEBUG - 2017-02-17 04:45:30 --> Total execution time: 0.0141
INFO - 2017-02-17 04:45:34 --> Config Class Initialized
INFO - 2017-02-17 04:45:34 --> Hooks Class Initialized
DEBUG - 2017-02-17 04:45:34 --> UTF-8 Support Enabled
INFO - 2017-02-17 04:45:34 --> Utf8 Class Initialized
INFO - 2017-02-17 04:45:34 --> URI Class Initialized
INFO - 2017-02-17 04:45:34 --> Router Class Initialized
INFO - 2017-02-17 04:45:34 --> Output Class Initialized
INFO - 2017-02-17 04:45:34 --> Security Class Initialized
DEBUG - 2017-02-17 04:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 04:45:34 --> Input Class Initialized
INFO - 2017-02-17 04:45:34 --> Language Class Initialized
INFO - 2017-02-17 04:45:34 --> Loader Class Initialized
INFO - 2017-02-17 04:45:34 --> Database Driver Class Initialized
INFO - 2017-02-17 04:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 04:45:34 --> Controller Class Initialized
INFO - 2017-02-17 04:45:34 --> Helper loaded: url_helper
DEBUG - 2017-02-17 04:45:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 04:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 04:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 04:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 04:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 04:45:34 --> Final output sent to browser
DEBUG - 2017-02-17 04:45:34 --> Total execution time: 0.0135
INFO - 2017-02-17 06:27:58 --> Config Class Initialized
INFO - 2017-02-17 06:27:58 --> Hooks Class Initialized
DEBUG - 2017-02-17 06:27:58 --> UTF-8 Support Enabled
INFO - 2017-02-17 06:27:58 --> Utf8 Class Initialized
INFO - 2017-02-17 06:27:58 --> URI Class Initialized
DEBUG - 2017-02-17 06:27:58 --> No URI present. Default controller set.
INFO - 2017-02-17 06:27:58 --> Router Class Initialized
INFO - 2017-02-17 06:27:58 --> Output Class Initialized
INFO - 2017-02-17 06:27:58 --> Security Class Initialized
DEBUG - 2017-02-17 06:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 06:27:58 --> Input Class Initialized
INFO - 2017-02-17 06:27:58 --> Language Class Initialized
INFO - 2017-02-17 06:27:58 --> Loader Class Initialized
INFO - 2017-02-17 06:27:58 --> Database Driver Class Initialized
INFO - 2017-02-17 06:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 06:27:58 --> Controller Class Initialized
INFO - 2017-02-17 06:27:58 --> Helper loaded: url_helper
DEBUG - 2017-02-17 06:27:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 06:27:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 06:27:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 06:27:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 06:27:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 06:27:58 --> Final output sent to browser
DEBUG - 2017-02-17 06:27:58 --> Total execution time: 0.0304
INFO - 2017-02-17 06:28:31 --> Config Class Initialized
INFO - 2017-02-17 06:28:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 06:28:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 06:28:31 --> Utf8 Class Initialized
INFO - 2017-02-17 06:28:31 --> URI Class Initialized
INFO - 2017-02-17 06:28:31 --> Router Class Initialized
INFO - 2017-02-17 06:28:31 --> Output Class Initialized
INFO - 2017-02-17 06:28:31 --> Security Class Initialized
DEBUG - 2017-02-17 06:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 06:28:31 --> Input Class Initialized
INFO - 2017-02-17 06:28:31 --> Language Class Initialized
INFO - 2017-02-17 06:28:31 --> Loader Class Initialized
INFO - 2017-02-17 06:28:31 --> Database Driver Class Initialized
INFO - 2017-02-17 06:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 06:28:31 --> Controller Class Initialized
INFO - 2017-02-17 06:28:31 --> Helper loaded: url_helper
DEBUG - 2017-02-17 06:28:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 06:28:32 --> Config Class Initialized
INFO - 2017-02-17 06:28:32 --> Hooks Class Initialized
DEBUG - 2017-02-17 06:28:32 --> UTF-8 Support Enabled
INFO - 2017-02-17 06:28:32 --> Utf8 Class Initialized
INFO - 2017-02-17 06:28:32 --> URI Class Initialized
INFO - 2017-02-17 06:28:32 --> Router Class Initialized
INFO - 2017-02-17 06:28:32 --> Output Class Initialized
INFO - 2017-02-17 06:28:32 --> Security Class Initialized
DEBUG - 2017-02-17 06:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 06:28:32 --> Input Class Initialized
INFO - 2017-02-17 06:28:32 --> Language Class Initialized
INFO - 2017-02-17 06:28:32 --> Loader Class Initialized
INFO - 2017-02-17 06:28:32 --> Database Driver Class Initialized
INFO - 2017-02-17 06:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 06:28:32 --> Controller Class Initialized
INFO - 2017-02-17 06:28:32 --> Helper loaded: date_helper
DEBUG - 2017-02-17 06:28:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 06:28:32 --> Helper loaded: url_helper
INFO - 2017-02-17 06:28:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 06:28:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-17 06:28:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-17 06:28:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-17 06:28:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 06:28:32 --> Final output sent to browser
DEBUG - 2017-02-17 06:28:32 --> Total execution time: 0.0422
INFO - 2017-02-17 15:29:08 --> Config Class Initialized
INFO - 2017-02-17 15:29:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 15:29:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 15:29:08 --> Utf8 Class Initialized
INFO - 2017-02-17 15:29:08 --> URI Class Initialized
DEBUG - 2017-02-17 15:29:08 --> No URI present. Default controller set.
INFO - 2017-02-17 15:29:08 --> Router Class Initialized
INFO - 2017-02-17 15:29:08 --> Output Class Initialized
INFO - 2017-02-17 15:29:08 --> Security Class Initialized
DEBUG - 2017-02-17 15:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 15:29:08 --> Input Class Initialized
INFO - 2017-02-17 15:29:08 --> Language Class Initialized
INFO - 2017-02-17 15:29:08 --> Loader Class Initialized
INFO - 2017-02-17 15:29:08 --> Database Driver Class Initialized
INFO - 2017-02-17 15:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 15:29:08 --> Controller Class Initialized
INFO - 2017-02-17 15:29:08 --> Helper loaded: url_helper
DEBUG - 2017-02-17 15:29:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 15:29:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 15:29:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 15:29:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 15:29:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 15:29:08 --> Final output sent to browser
DEBUG - 2017-02-17 15:29:08 --> Total execution time: 0.5223
INFO - 2017-02-17 16:29:55 --> Config Class Initialized
INFO - 2017-02-17 16:29:55 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:29:56 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:29:56 --> Utf8 Class Initialized
INFO - 2017-02-17 16:29:56 --> URI Class Initialized
DEBUG - 2017-02-17 16:29:56 --> No URI present. Default controller set.
INFO - 2017-02-17 16:29:56 --> Router Class Initialized
INFO - 2017-02-17 16:29:56 --> Output Class Initialized
INFO - 2017-02-17 16:29:56 --> Security Class Initialized
DEBUG - 2017-02-17 16:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:29:56 --> Input Class Initialized
INFO - 2017-02-17 16:29:56 --> Language Class Initialized
INFO - 2017-02-17 16:29:56 --> Loader Class Initialized
INFO - 2017-02-17 16:29:56 --> Database Driver Class Initialized
INFO - 2017-02-17 16:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:29:56 --> Controller Class Initialized
INFO - 2017-02-17 16:29:56 --> Helper loaded: url_helper
DEBUG - 2017-02-17 16:29:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 16:29:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 16:29:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 16:29:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 16:29:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 16:29:56 --> Final output sent to browser
DEBUG - 2017-02-17 16:29:56 --> Total execution time: 0.3125
INFO - 2017-02-17 16:37:24 --> Config Class Initialized
INFO - 2017-02-17 16:37:24 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:37:24 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:37:24 --> Utf8 Class Initialized
INFO - 2017-02-17 16:37:24 --> URI Class Initialized
DEBUG - 2017-02-17 16:37:24 --> No URI present. Default controller set.
INFO - 2017-02-17 16:37:24 --> Router Class Initialized
INFO - 2017-02-17 16:37:24 --> Output Class Initialized
INFO - 2017-02-17 16:37:24 --> Security Class Initialized
DEBUG - 2017-02-17 16:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:37:24 --> Input Class Initialized
INFO - 2017-02-17 16:37:24 --> Language Class Initialized
INFO - 2017-02-17 16:37:24 --> Loader Class Initialized
INFO - 2017-02-17 16:37:24 --> Database Driver Class Initialized
INFO - 2017-02-17 16:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:37:24 --> Controller Class Initialized
INFO - 2017-02-17 16:37:24 --> Helper loaded: url_helper
DEBUG - 2017-02-17 16:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 16:37:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 16:37:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 16:37:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 16:37:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 16:37:24 --> Final output sent to browser
DEBUG - 2017-02-17 16:37:24 --> Total execution time: 0.0138
INFO - 2017-02-17 16:38:32 --> Config Class Initialized
INFO - 2017-02-17 16:38:32 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:38:32 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:38:32 --> Utf8 Class Initialized
INFO - 2017-02-17 16:38:32 --> URI Class Initialized
INFO - 2017-02-17 16:38:32 --> Router Class Initialized
INFO - 2017-02-17 16:38:32 --> Output Class Initialized
INFO - 2017-02-17 16:38:32 --> Security Class Initialized
DEBUG - 2017-02-17 16:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:38:32 --> Input Class Initialized
INFO - 2017-02-17 16:38:32 --> Language Class Initialized
INFO - 2017-02-17 16:38:32 --> Loader Class Initialized
INFO - 2017-02-17 16:38:32 --> Database Driver Class Initialized
INFO - 2017-02-17 16:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:38:32 --> Controller Class Initialized
INFO - 2017-02-17 16:38:32 --> Helper loaded: url_helper
DEBUG - 2017-02-17 16:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 16:38:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-17 16:38:32 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-17 16:38:32 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-17 16:38:32 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-17 16:38:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 16:38:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 16:38:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 16:38:32 --> Final output sent to browser
DEBUG - 2017-02-17 16:38:32 --> Total execution time: 0.0140
INFO - 2017-02-17 16:38:49 --> Config Class Initialized
INFO - 2017-02-17 16:38:49 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:38:49 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:38:49 --> Utf8 Class Initialized
INFO - 2017-02-17 16:38:49 --> URI Class Initialized
INFO - 2017-02-17 16:38:49 --> Router Class Initialized
INFO - 2017-02-17 16:38:49 --> Output Class Initialized
INFO - 2017-02-17 16:38:49 --> Security Class Initialized
DEBUG - 2017-02-17 16:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:38:49 --> Input Class Initialized
INFO - 2017-02-17 16:38:49 --> Language Class Initialized
INFO - 2017-02-17 16:38:49 --> Loader Class Initialized
INFO - 2017-02-17 16:38:49 --> Database Driver Class Initialized
INFO - 2017-02-17 16:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:38:49 --> Controller Class Initialized
INFO - 2017-02-17 16:38:49 --> Helper loaded: url_helper
DEBUG - 2017-02-17 16:38:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 16:38:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-17 16:38:49 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-17 16:38:49 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-17 16:38:49 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-17 16:38:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 16:38:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 16:38:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 16:38:49 --> Final output sent to browser
DEBUG - 2017-02-17 16:38:49 --> Total execution time: 0.0140
INFO - 2017-02-17 16:39:03 --> Config Class Initialized
INFO - 2017-02-17 16:39:03 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:39:03 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:39:03 --> Utf8 Class Initialized
INFO - 2017-02-17 16:39:03 --> URI Class Initialized
INFO - 2017-02-17 16:39:03 --> Router Class Initialized
INFO - 2017-02-17 16:39:03 --> Output Class Initialized
INFO - 2017-02-17 16:39:03 --> Security Class Initialized
DEBUG - 2017-02-17 16:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:39:03 --> Input Class Initialized
INFO - 2017-02-17 16:39:03 --> Language Class Initialized
INFO - 2017-02-17 16:39:03 --> Loader Class Initialized
INFO - 2017-02-17 16:39:03 --> Database Driver Class Initialized
INFO - 2017-02-17 16:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:39:03 --> Controller Class Initialized
INFO - 2017-02-17 16:39:03 --> Helper loaded: url_helper
DEBUG - 2017-02-17 16:39:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-17 16:39:04 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-17 16:39:04 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Navi Ibarra')
INFO - 2017-02-17 16:39:04 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-17 16:39:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-17 16:39:04 --> Config Class Initialized
INFO - 2017-02-17 16:39:04 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:39:04 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:39:04 --> Utf8 Class Initialized
INFO - 2017-02-17 16:39:04 --> URI Class Initialized
INFO - 2017-02-17 16:39:04 --> Router Class Initialized
INFO - 2017-02-17 16:39:04 --> Output Class Initialized
INFO - 2017-02-17 16:39:04 --> Security Class Initialized
DEBUG - 2017-02-17 16:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:39:04 --> Input Class Initialized
INFO - 2017-02-17 16:39:04 --> Language Class Initialized
INFO - 2017-02-17 16:39:04 --> Loader Class Initialized
INFO - 2017-02-17 16:39:04 --> Database Driver Class Initialized
INFO - 2017-02-17 16:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:39:04 --> Controller Class Initialized
INFO - 2017-02-17 16:39:04 --> Helper loaded: url_helper
DEBUG - 2017-02-17 16:39:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 16:39:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 16:39:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 16:39:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 16:39:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 16:39:04 --> Final output sent to browser
DEBUG - 2017-02-17 16:39:04 --> Total execution time: 0.0140
INFO - 2017-02-17 16:39:19 --> Config Class Initialized
INFO - 2017-02-17 16:39:19 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:39:19 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:39:19 --> Utf8 Class Initialized
INFO - 2017-02-17 16:39:19 --> URI Class Initialized
INFO - 2017-02-17 16:39:19 --> Router Class Initialized
INFO - 2017-02-17 16:39:19 --> Output Class Initialized
INFO - 2017-02-17 16:39:19 --> Security Class Initialized
DEBUG - 2017-02-17 16:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:39:19 --> Input Class Initialized
INFO - 2017-02-17 16:39:19 --> Language Class Initialized
INFO - 2017-02-17 16:39:19 --> Loader Class Initialized
INFO - 2017-02-17 16:39:19 --> Database Driver Class Initialized
INFO - 2017-02-17 16:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:39:19 --> Controller Class Initialized
INFO - 2017-02-17 16:39:19 --> Helper loaded: url_helper
DEBUG - 2017-02-17 16:39:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-17 16:39:20 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-17 16:39:20 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Navi Ibarra')
INFO - 2017-02-17 16:39:20 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-17 16:39:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-17 16:39:28 --> Config Class Initialized
INFO - 2017-02-17 16:39:28 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:39:28 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:39:28 --> Utf8 Class Initialized
INFO - 2017-02-17 16:39:28 --> URI Class Initialized
INFO - 2017-02-17 16:39:28 --> Router Class Initialized
INFO - 2017-02-17 16:39:28 --> Output Class Initialized
INFO - 2017-02-17 16:39:28 --> Security Class Initialized
DEBUG - 2017-02-17 16:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:39:28 --> Input Class Initialized
INFO - 2017-02-17 16:39:28 --> Language Class Initialized
INFO - 2017-02-17 16:39:28 --> Loader Class Initialized
INFO - 2017-02-17 16:39:28 --> Database Driver Class Initialized
INFO - 2017-02-17 16:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:39:28 --> Controller Class Initialized
INFO - 2017-02-17 16:39:28 --> Helper loaded: url_helper
DEBUG - 2017-02-17 16:39:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-17 16:39:29 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-17 16:39:29 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Navi Ibarra')
INFO - 2017-02-17 16:39:29 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-17 16:39:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-17 16:39:32 --> Config Class Initialized
INFO - 2017-02-17 16:39:32 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:39:32 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:39:32 --> Utf8 Class Initialized
INFO - 2017-02-17 16:39:32 --> URI Class Initialized
INFO - 2017-02-17 16:39:32 --> Router Class Initialized
INFO - 2017-02-17 16:39:32 --> Output Class Initialized
INFO - 2017-02-17 16:39:32 --> Security Class Initialized
DEBUG - 2017-02-17 16:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:39:32 --> Input Class Initialized
INFO - 2017-02-17 16:39:32 --> Language Class Initialized
INFO - 2017-02-17 16:39:32 --> Loader Class Initialized
INFO - 2017-02-17 16:39:32 --> Database Driver Class Initialized
INFO - 2017-02-17 16:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:39:32 --> Controller Class Initialized
INFO - 2017-02-17 16:39:32 --> Helper loaded: url_helper
DEBUG - 2017-02-17 16:39:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-17 16:39:33 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-17 16:39:33 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Navi Ibarra')
INFO - 2017-02-17 16:39:33 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-17 16:39:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-17 16:39:37 --> Config Class Initialized
INFO - 2017-02-17 16:39:37 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:39:37 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:39:37 --> Utf8 Class Initialized
INFO - 2017-02-17 16:39:37 --> URI Class Initialized
DEBUG - 2017-02-17 16:39:37 --> No URI present. Default controller set.
INFO - 2017-02-17 16:39:37 --> Router Class Initialized
INFO - 2017-02-17 16:39:37 --> Output Class Initialized
INFO - 2017-02-17 16:39:37 --> Security Class Initialized
DEBUG - 2017-02-17 16:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:39:37 --> Input Class Initialized
INFO - 2017-02-17 16:39:37 --> Language Class Initialized
INFO - 2017-02-17 16:39:37 --> Loader Class Initialized
INFO - 2017-02-17 16:39:37 --> Database Driver Class Initialized
INFO - 2017-02-17 16:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:39:37 --> Controller Class Initialized
INFO - 2017-02-17 16:39:37 --> Helper loaded: url_helper
DEBUG - 2017-02-17 16:39:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 16:39:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 16:39:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 16:39:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 16:39:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 16:39:37 --> Final output sent to browser
DEBUG - 2017-02-17 16:39:37 --> Total execution time: 0.0138
INFO - 2017-02-17 17:03:23 --> Config Class Initialized
INFO - 2017-02-17 17:03:23 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:03:23 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:03:23 --> Utf8 Class Initialized
INFO - 2017-02-17 17:03:23 --> URI Class Initialized
DEBUG - 2017-02-17 17:03:23 --> No URI present. Default controller set.
INFO - 2017-02-17 17:03:23 --> Router Class Initialized
INFO - 2017-02-17 17:03:23 --> Output Class Initialized
INFO - 2017-02-17 17:03:23 --> Security Class Initialized
DEBUG - 2017-02-17 17:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:03:23 --> Input Class Initialized
INFO - 2017-02-17 17:03:23 --> Language Class Initialized
INFO - 2017-02-17 17:03:23 --> Loader Class Initialized
INFO - 2017-02-17 17:03:23 --> Database Driver Class Initialized
INFO - 2017-02-17 17:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:03:23 --> Controller Class Initialized
INFO - 2017-02-17 17:03:23 --> Helper loaded: url_helper
DEBUG - 2017-02-17 17:03:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 17:03:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 17:03:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 17:03:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 17:03:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 17:03:23 --> Final output sent to browser
DEBUG - 2017-02-17 17:03:23 --> Total execution time: 0.0136
INFO - 2017-02-17 17:03:31 --> Config Class Initialized
INFO - 2017-02-17 17:03:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:03:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:03:31 --> Utf8 Class Initialized
INFO - 2017-02-17 17:03:31 --> URI Class Initialized
INFO - 2017-02-17 17:03:31 --> Router Class Initialized
INFO - 2017-02-17 17:03:31 --> Output Class Initialized
INFO - 2017-02-17 17:03:31 --> Security Class Initialized
DEBUG - 2017-02-17 17:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:03:31 --> Input Class Initialized
INFO - 2017-02-17 17:03:31 --> Language Class Initialized
INFO - 2017-02-17 17:03:31 --> Loader Class Initialized
INFO - 2017-02-17 17:03:31 --> Database Driver Class Initialized
INFO - 2017-02-17 17:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:03:31 --> Controller Class Initialized
INFO - 2017-02-17 17:03:31 --> Helper loaded: url_helper
DEBUG - 2017-02-17 17:03:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 17:03:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 17:03:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 17:03:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 17:03:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 17:03:31 --> Final output sent to browser
DEBUG - 2017-02-17 17:03:31 --> Total execution time: 0.0205
INFO - 2017-02-17 17:04:09 --> Config Class Initialized
INFO - 2017-02-17 17:04:09 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:04:09 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:04:09 --> Utf8 Class Initialized
INFO - 2017-02-17 17:04:09 --> URI Class Initialized
INFO - 2017-02-17 17:04:09 --> Router Class Initialized
INFO - 2017-02-17 17:04:09 --> Output Class Initialized
INFO - 2017-02-17 17:04:09 --> Security Class Initialized
DEBUG - 2017-02-17 17:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:04:09 --> Input Class Initialized
INFO - 2017-02-17 17:04:09 --> Language Class Initialized
INFO - 2017-02-17 17:04:09 --> Loader Class Initialized
INFO - 2017-02-17 17:04:09 --> Database Driver Class Initialized
INFO - 2017-02-17 17:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:04:09 --> Controller Class Initialized
INFO - 2017-02-17 17:04:09 --> Helper loaded: url_helper
DEBUG - 2017-02-17 17:04:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 17:04:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-17 17:04:09 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-17 17:04:09 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-17 17:04:09 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-17 17:04:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 17:04:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 17:04:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 17:04:09 --> Final output sent to browser
DEBUG - 2017-02-17 17:04:09 --> Total execution time: 0.0138
INFO - 2017-02-17 17:04:13 --> Config Class Initialized
INFO - 2017-02-17 17:04:13 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:04:13 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:04:13 --> Utf8 Class Initialized
INFO - 2017-02-17 17:04:13 --> URI Class Initialized
INFO - 2017-02-17 17:04:13 --> Router Class Initialized
INFO - 2017-02-17 17:04:13 --> Output Class Initialized
INFO - 2017-02-17 17:04:13 --> Security Class Initialized
DEBUG - 2017-02-17 17:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:04:13 --> Input Class Initialized
INFO - 2017-02-17 17:04:13 --> Language Class Initialized
INFO - 2017-02-17 17:04:13 --> Loader Class Initialized
INFO - 2017-02-17 17:04:13 --> Database Driver Class Initialized
INFO - 2017-02-17 17:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:04:13 --> Controller Class Initialized
INFO - 2017-02-17 17:04:13 --> Helper loaded: url_helper
DEBUG - 2017-02-17 17:04:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 17:04:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 17:04:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 17:04:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 17:04:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 17:04:13 --> Final output sent to browser
DEBUG - 2017-02-17 17:04:13 --> Total execution time: 0.0135
INFO - 2017-02-17 17:04:35 --> Config Class Initialized
INFO - 2017-02-17 17:04:35 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:04:35 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:04:35 --> Utf8 Class Initialized
INFO - 2017-02-17 17:04:35 --> URI Class Initialized
INFO - 2017-02-17 17:04:35 --> Router Class Initialized
INFO - 2017-02-17 17:04:35 --> Output Class Initialized
INFO - 2017-02-17 17:04:35 --> Security Class Initialized
DEBUG - 2017-02-17 17:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:04:35 --> Input Class Initialized
INFO - 2017-02-17 17:04:35 --> Language Class Initialized
INFO - 2017-02-17 17:04:35 --> Loader Class Initialized
INFO - 2017-02-17 17:04:35 --> Database Driver Class Initialized
INFO - 2017-02-17 17:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:04:35 --> Controller Class Initialized
INFO - 2017-02-17 17:04:35 --> Helper loaded: url_helper
DEBUG - 2017-02-17 17:04:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 17:04:37 --> Config Class Initialized
INFO - 2017-02-17 17:04:37 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:04:37 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:04:37 --> Utf8 Class Initialized
INFO - 2017-02-17 17:04:37 --> URI Class Initialized
INFO - 2017-02-17 17:04:37 --> Router Class Initialized
INFO - 2017-02-17 17:04:37 --> Output Class Initialized
INFO - 2017-02-17 17:04:37 --> Security Class Initialized
DEBUG - 2017-02-17 17:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:04:37 --> Input Class Initialized
INFO - 2017-02-17 17:04:37 --> Language Class Initialized
INFO - 2017-02-17 17:04:37 --> Loader Class Initialized
INFO - 2017-02-17 17:04:37 --> Database Driver Class Initialized
INFO - 2017-02-17 17:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:04:37 --> Controller Class Initialized
INFO - 2017-02-17 17:04:37 --> Helper loaded: date_helper
DEBUG - 2017-02-17 17:04:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 17:04:37 --> Helper loaded: url_helper
INFO - 2017-02-17 17:04:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 17:04:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-17 17:04:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-17 17:04:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-17 17:04:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 17:04:37 --> Final output sent to browser
DEBUG - 2017-02-17 17:04:37 --> Total execution time: 0.0295
INFO - 2017-02-17 17:04:38 --> Config Class Initialized
INFO - 2017-02-17 17:04:38 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:04:38 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:04:38 --> Utf8 Class Initialized
INFO - 2017-02-17 17:04:38 --> URI Class Initialized
INFO - 2017-02-17 17:04:38 --> Router Class Initialized
INFO - 2017-02-17 17:04:38 --> Output Class Initialized
INFO - 2017-02-17 17:04:38 --> Security Class Initialized
DEBUG - 2017-02-17 17:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:04:38 --> Input Class Initialized
INFO - 2017-02-17 17:04:38 --> Language Class Initialized
INFO - 2017-02-17 17:04:38 --> Loader Class Initialized
INFO - 2017-02-17 17:04:38 --> Database Driver Class Initialized
INFO - 2017-02-17 17:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:04:38 --> Controller Class Initialized
INFO - 2017-02-17 17:04:38 --> Helper loaded: url_helper
DEBUG - 2017-02-17 17:04:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 17:04:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 17:04:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 17:04:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 17:04:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 17:04:38 --> Final output sent to browser
DEBUG - 2017-02-17 17:04:38 --> Total execution time: 0.0140
INFO - 2017-02-17 17:04:57 --> Config Class Initialized
INFO - 2017-02-17 17:04:57 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:04:57 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:04:57 --> Utf8 Class Initialized
INFO - 2017-02-17 17:04:57 --> URI Class Initialized
INFO - 2017-02-17 17:04:57 --> Router Class Initialized
INFO - 2017-02-17 17:04:57 --> Output Class Initialized
INFO - 2017-02-17 17:04:57 --> Security Class Initialized
DEBUG - 2017-02-17 17:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:04:57 --> Input Class Initialized
INFO - 2017-02-17 17:04:57 --> Language Class Initialized
INFO - 2017-02-17 17:04:57 --> Loader Class Initialized
INFO - 2017-02-17 17:04:57 --> Database Driver Class Initialized
INFO - 2017-02-17 17:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:04:57 --> Controller Class Initialized
INFO - 2017-02-17 17:04:57 --> Helper loaded: url_helper
DEBUG - 2017-02-17 17:04:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 17:04:58 --> Config Class Initialized
INFO - 2017-02-17 17:04:58 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:04:58 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:04:58 --> Utf8 Class Initialized
INFO - 2017-02-17 17:04:58 --> URI Class Initialized
INFO - 2017-02-17 17:04:58 --> Router Class Initialized
INFO - 2017-02-17 17:04:58 --> Output Class Initialized
INFO - 2017-02-17 17:04:58 --> Security Class Initialized
DEBUG - 2017-02-17 17:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:04:58 --> Input Class Initialized
INFO - 2017-02-17 17:04:58 --> Language Class Initialized
INFO - 2017-02-17 17:04:58 --> Loader Class Initialized
INFO - 2017-02-17 17:04:58 --> Database Driver Class Initialized
INFO - 2017-02-17 17:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:04:58 --> Controller Class Initialized
INFO - 2017-02-17 17:04:58 --> Helper loaded: date_helper
DEBUG - 2017-02-17 17:04:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 17:04:58 --> Helper loaded: url_helper
INFO - 2017-02-17 17:04:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 17:04:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-17 17:04:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-17 17:04:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-17 17:04:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 17:04:58 --> Final output sent to browser
DEBUG - 2017-02-17 17:04:58 --> Total execution time: 0.0231
INFO - 2017-02-17 17:04:59 --> Config Class Initialized
INFO - 2017-02-17 17:04:59 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:04:59 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:04:59 --> Utf8 Class Initialized
INFO - 2017-02-17 17:04:59 --> URI Class Initialized
INFO - 2017-02-17 17:04:59 --> Router Class Initialized
INFO - 2017-02-17 17:04:59 --> Output Class Initialized
INFO - 2017-02-17 17:04:59 --> Security Class Initialized
DEBUG - 2017-02-17 17:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:04:59 --> Input Class Initialized
INFO - 2017-02-17 17:04:59 --> Language Class Initialized
INFO - 2017-02-17 17:04:59 --> Loader Class Initialized
INFO - 2017-02-17 17:04:59 --> Database Driver Class Initialized
INFO - 2017-02-17 17:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:04:59 --> Controller Class Initialized
INFO - 2017-02-17 17:04:59 --> Helper loaded: url_helper
DEBUG - 2017-02-17 17:04:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 17:04:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 17:04:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 17:04:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 17:04:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 17:04:59 --> Final output sent to browser
DEBUG - 2017-02-17 17:04:59 --> Total execution time: 0.0137
INFO - 2017-02-17 17:20:57 --> Config Class Initialized
INFO - 2017-02-17 17:20:57 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:20:57 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:20:57 --> Utf8 Class Initialized
INFO - 2017-02-17 17:20:57 --> URI Class Initialized
DEBUG - 2017-02-17 17:20:57 --> No URI present. Default controller set.
INFO - 2017-02-17 17:20:57 --> Router Class Initialized
INFO - 2017-02-17 17:20:57 --> Output Class Initialized
INFO - 2017-02-17 17:20:57 --> Security Class Initialized
DEBUG - 2017-02-17 17:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:20:57 --> Input Class Initialized
INFO - 2017-02-17 17:20:57 --> Language Class Initialized
INFO - 2017-02-17 17:20:57 --> Loader Class Initialized
INFO - 2017-02-17 17:20:57 --> Database Driver Class Initialized
INFO - 2017-02-17 17:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:20:57 --> Controller Class Initialized
INFO - 2017-02-17 17:20:57 --> Helper loaded: url_helper
DEBUG - 2017-02-17 17:20:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 17:20:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 17:20:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 17:20:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 17:20:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 17:20:57 --> Final output sent to browser
DEBUG - 2017-02-17 17:20:57 --> Total execution time: 0.0133
INFO - 2017-02-17 17:21:09 --> Config Class Initialized
INFO - 2017-02-17 17:21:09 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:21:09 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:21:09 --> Utf8 Class Initialized
INFO - 2017-02-17 17:21:09 --> URI Class Initialized
INFO - 2017-02-17 17:21:09 --> Router Class Initialized
INFO - 2017-02-17 17:21:09 --> Output Class Initialized
INFO - 2017-02-17 17:21:09 --> Security Class Initialized
DEBUG - 2017-02-17 17:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:21:09 --> Input Class Initialized
INFO - 2017-02-17 17:21:09 --> Language Class Initialized
INFO - 2017-02-17 17:21:09 --> Loader Class Initialized
INFO - 2017-02-17 17:21:09 --> Database Driver Class Initialized
INFO - 2017-02-17 17:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:21:09 --> Controller Class Initialized
INFO - 2017-02-17 17:21:09 --> Helper loaded: url_helper
DEBUG - 2017-02-17 17:21:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 17:21:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 17:21:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 17:21:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 17:21:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 17:21:09 --> Final output sent to browser
DEBUG - 2017-02-17 17:21:09 --> Total execution time: 0.0138
INFO - 2017-02-17 19:30:43 --> Config Class Initialized
INFO - 2017-02-17 19:30:43 --> Hooks Class Initialized
DEBUG - 2017-02-17 19:30:43 --> UTF-8 Support Enabled
INFO - 2017-02-17 19:30:43 --> Utf8 Class Initialized
INFO - 2017-02-17 19:30:43 --> URI Class Initialized
INFO - 2017-02-17 19:30:43 --> Router Class Initialized
INFO - 2017-02-17 19:30:43 --> Output Class Initialized
INFO - 2017-02-17 19:30:43 --> Security Class Initialized
DEBUG - 2017-02-17 19:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 19:30:43 --> Input Class Initialized
INFO - 2017-02-17 19:30:43 --> Language Class Initialized
INFO - 2017-02-17 19:30:43 --> Loader Class Initialized
INFO - 2017-02-17 19:30:43 --> Database Driver Class Initialized
INFO - 2017-02-17 19:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 19:30:43 --> Controller Class Initialized
INFO - 2017-02-17 19:30:43 --> Helper loaded: date_helper
DEBUG - 2017-02-17 19:30:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 19:30:43 --> Helper loaded: url_helper
INFO - 2017-02-17 19:30:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 19:30:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-17 19:30:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-17 19:30:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-17 19:30:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 19:30:43 --> Final output sent to browser
DEBUG - 2017-02-17 19:30:43 --> Total execution time: 0.0496
INFO - 2017-02-17 19:30:54 --> Config Class Initialized
INFO - 2017-02-17 19:30:54 --> Hooks Class Initialized
DEBUG - 2017-02-17 19:30:54 --> UTF-8 Support Enabled
INFO - 2017-02-17 19:30:54 --> Utf8 Class Initialized
INFO - 2017-02-17 19:30:54 --> URI Class Initialized
INFO - 2017-02-17 19:30:54 --> Router Class Initialized
INFO - 2017-02-17 19:30:54 --> Output Class Initialized
INFO - 2017-02-17 19:30:54 --> Security Class Initialized
DEBUG - 2017-02-17 19:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 19:30:54 --> Input Class Initialized
INFO - 2017-02-17 19:30:54 --> Language Class Initialized
INFO - 2017-02-17 19:30:54 --> Loader Class Initialized
INFO - 2017-02-17 19:30:54 --> Database Driver Class Initialized
INFO - 2017-02-17 19:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 19:30:54 --> Controller Class Initialized
INFO - 2017-02-17 19:30:54 --> Helper loaded: url_helper
DEBUG - 2017-02-17 19:30:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 19:30:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 19:30:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 19:30:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 19:30:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 19:30:54 --> Final output sent to browser
DEBUG - 2017-02-17 19:30:54 --> Total execution time: 0.0139
INFO - 2017-02-17 19:31:01 --> Config Class Initialized
INFO - 2017-02-17 19:31:01 --> Hooks Class Initialized
DEBUG - 2017-02-17 19:31:01 --> UTF-8 Support Enabled
INFO - 2017-02-17 19:31:01 --> Utf8 Class Initialized
INFO - 2017-02-17 19:31:01 --> URI Class Initialized
DEBUG - 2017-02-17 19:31:01 --> No URI present. Default controller set.
INFO - 2017-02-17 19:31:01 --> Router Class Initialized
INFO - 2017-02-17 19:31:01 --> Output Class Initialized
INFO - 2017-02-17 19:31:01 --> Security Class Initialized
DEBUG - 2017-02-17 19:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 19:31:01 --> Input Class Initialized
INFO - 2017-02-17 19:31:01 --> Language Class Initialized
INFO - 2017-02-17 19:31:01 --> Loader Class Initialized
INFO - 2017-02-17 19:31:01 --> Database Driver Class Initialized
INFO - 2017-02-17 19:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 19:31:01 --> Controller Class Initialized
INFO - 2017-02-17 19:31:01 --> Helper loaded: url_helper
DEBUG - 2017-02-17 19:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 19:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 19:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 19:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 19:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 19:31:01 --> Final output sent to browser
DEBUG - 2017-02-17 19:31:01 --> Total execution time: 0.0134
INFO - 2017-02-17 19:31:19 --> Config Class Initialized
INFO - 2017-02-17 19:31:19 --> Hooks Class Initialized
DEBUG - 2017-02-17 19:31:19 --> UTF-8 Support Enabled
INFO - 2017-02-17 19:31:19 --> Utf8 Class Initialized
INFO - 2017-02-17 19:31:19 --> URI Class Initialized
INFO - 2017-02-17 19:31:19 --> Router Class Initialized
INFO - 2017-02-17 19:31:19 --> Output Class Initialized
INFO - 2017-02-17 19:31:19 --> Security Class Initialized
DEBUG - 2017-02-17 19:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 19:31:19 --> Input Class Initialized
INFO - 2017-02-17 19:31:19 --> Language Class Initialized
INFO - 2017-02-17 19:31:19 --> Loader Class Initialized
INFO - 2017-02-17 19:31:19 --> Database Driver Class Initialized
INFO - 2017-02-17 19:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 19:31:19 --> Controller Class Initialized
INFO - 2017-02-17 19:31:19 --> Helper loaded: url_helper
DEBUG - 2017-02-17 19:31:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 19:31:21 --> Config Class Initialized
INFO - 2017-02-17 19:31:21 --> Hooks Class Initialized
DEBUG - 2017-02-17 19:31:21 --> UTF-8 Support Enabled
INFO - 2017-02-17 19:31:21 --> Utf8 Class Initialized
INFO - 2017-02-17 19:31:21 --> URI Class Initialized
INFO - 2017-02-17 19:31:21 --> Router Class Initialized
INFO - 2017-02-17 19:31:21 --> Output Class Initialized
INFO - 2017-02-17 19:31:21 --> Security Class Initialized
DEBUG - 2017-02-17 19:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 19:31:21 --> Input Class Initialized
INFO - 2017-02-17 19:31:21 --> Language Class Initialized
INFO - 2017-02-17 19:31:21 --> Loader Class Initialized
INFO - 2017-02-17 19:31:21 --> Database Driver Class Initialized
INFO - 2017-02-17 19:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 19:31:21 --> Controller Class Initialized
INFO - 2017-02-17 19:31:21 --> Helper loaded: date_helper
DEBUG - 2017-02-17 19:31:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 19:31:21 --> Helper loaded: url_helper
INFO - 2017-02-17 19:31:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 19:31:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-17 19:31:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-17 19:31:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-17 19:31:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 19:31:21 --> Final output sent to browser
DEBUG - 2017-02-17 19:31:21 --> Total execution time: 0.0135
INFO - 2017-02-17 19:31:24 --> Config Class Initialized
INFO - 2017-02-17 19:31:24 --> Hooks Class Initialized
DEBUG - 2017-02-17 19:31:24 --> UTF-8 Support Enabled
INFO - 2017-02-17 19:31:24 --> Utf8 Class Initialized
INFO - 2017-02-17 19:31:24 --> URI Class Initialized
INFO - 2017-02-17 19:31:24 --> Router Class Initialized
INFO - 2017-02-17 19:31:24 --> Output Class Initialized
INFO - 2017-02-17 19:31:24 --> Security Class Initialized
DEBUG - 2017-02-17 19:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 19:31:24 --> Input Class Initialized
INFO - 2017-02-17 19:31:24 --> Language Class Initialized
INFO - 2017-02-17 19:31:24 --> Loader Class Initialized
INFO - 2017-02-17 19:31:24 --> Database Driver Class Initialized
INFO - 2017-02-17 19:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 19:31:24 --> Controller Class Initialized
INFO - 2017-02-17 19:31:24 --> Helper loaded: url_helper
DEBUG - 2017-02-17 19:31:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 19:31:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 19:31:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 19:31:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 19:31:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 19:31:24 --> Final output sent to browser
DEBUG - 2017-02-17 19:31:24 --> Total execution time: 0.0132
INFO - 2017-02-17 23:50:56 --> Config Class Initialized
INFO - 2017-02-17 23:50:56 --> Hooks Class Initialized
DEBUG - 2017-02-17 23:50:56 --> UTF-8 Support Enabled
INFO - 2017-02-17 23:50:56 --> Utf8 Class Initialized
INFO - 2017-02-17 23:50:56 --> URI Class Initialized
DEBUG - 2017-02-17 23:50:56 --> No URI present. Default controller set.
INFO - 2017-02-17 23:50:56 --> Router Class Initialized
INFO - 2017-02-17 23:50:56 --> Output Class Initialized
INFO - 2017-02-17 23:50:56 --> Security Class Initialized
DEBUG - 2017-02-17 23:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 23:50:56 --> Input Class Initialized
INFO - 2017-02-17 23:50:56 --> Language Class Initialized
INFO - 2017-02-17 23:50:57 --> Loader Class Initialized
INFO - 2017-02-17 23:50:57 --> Database Driver Class Initialized
INFO - 2017-02-17 23:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 23:50:57 --> Controller Class Initialized
INFO - 2017-02-17 23:50:57 --> Helper loaded: url_helper
DEBUG - 2017-02-17 23:50:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 23:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 23:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 23:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 23:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 23:50:58 --> Final output sent to browser
DEBUG - 2017-02-17 23:50:58 --> Total execution time: 1.9053
INFO - 2017-02-17 23:51:08 --> Config Class Initialized
INFO - 2017-02-17 23:51:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 23:51:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 23:51:08 --> Utf8 Class Initialized
INFO - 2017-02-17 23:51:08 --> URI Class Initialized
INFO - 2017-02-17 23:51:08 --> Router Class Initialized
INFO - 2017-02-17 23:51:08 --> Output Class Initialized
INFO - 2017-02-17 23:51:08 --> Security Class Initialized
DEBUG - 2017-02-17 23:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 23:51:08 --> Input Class Initialized
INFO - 2017-02-17 23:51:08 --> Language Class Initialized
INFO - 2017-02-17 23:51:08 --> Loader Class Initialized
INFO - 2017-02-17 23:51:08 --> Database Driver Class Initialized
INFO - 2017-02-17 23:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 23:51:08 --> Controller Class Initialized
INFO - 2017-02-17 23:51:08 --> Helper loaded: url_helper
DEBUG - 2017-02-17 23:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 23:51:10 --> Config Class Initialized
INFO - 2017-02-17 23:51:10 --> Hooks Class Initialized
DEBUG - 2017-02-17 23:51:10 --> UTF-8 Support Enabled
INFO - 2017-02-17 23:51:10 --> Utf8 Class Initialized
INFO - 2017-02-17 23:51:10 --> URI Class Initialized
INFO - 2017-02-17 23:51:10 --> Router Class Initialized
INFO - 2017-02-17 23:51:10 --> Output Class Initialized
INFO - 2017-02-17 23:51:10 --> Security Class Initialized
DEBUG - 2017-02-17 23:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 23:51:10 --> Input Class Initialized
INFO - 2017-02-17 23:51:10 --> Language Class Initialized
INFO - 2017-02-17 23:51:10 --> Loader Class Initialized
INFO - 2017-02-17 23:51:10 --> Database Driver Class Initialized
INFO - 2017-02-17 23:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 23:51:10 --> Controller Class Initialized
INFO - 2017-02-17 23:51:10 --> Helper loaded: date_helper
DEBUG - 2017-02-17 23:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 23:51:10 --> Helper loaded: url_helper
INFO - 2017-02-17 23:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 23:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-17 23:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-17 23:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-17 23:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 23:51:10 --> Final output sent to browser
DEBUG - 2017-02-17 23:51:10 --> Total execution time: 0.1907
INFO - 2017-02-17 23:51:14 --> Config Class Initialized
INFO - 2017-02-17 23:51:14 --> Hooks Class Initialized
DEBUG - 2017-02-17 23:51:14 --> UTF-8 Support Enabled
INFO - 2017-02-17 23:51:14 --> Utf8 Class Initialized
INFO - 2017-02-17 23:51:14 --> URI Class Initialized
DEBUG - 2017-02-17 23:51:14 --> No URI present. Default controller set.
INFO - 2017-02-17 23:51:14 --> Router Class Initialized
INFO - 2017-02-17 23:51:14 --> Output Class Initialized
INFO - 2017-02-17 23:51:14 --> Security Class Initialized
DEBUG - 2017-02-17 23:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 23:51:14 --> Input Class Initialized
INFO - 2017-02-17 23:51:14 --> Language Class Initialized
INFO - 2017-02-17 23:51:14 --> Loader Class Initialized
INFO - 2017-02-17 23:51:14 --> Database Driver Class Initialized
INFO - 2017-02-17 23:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 23:51:14 --> Controller Class Initialized
INFO - 2017-02-17 23:51:14 --> Helper loaded: url_helper
DEBUG - 2017-02-17 23:51:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 23:51:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 23:51:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 23:51:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 23:51:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 23:51:14 --> Final output sent to browser
DEBUG - 2017-02-17 23:51:14 --> Total execution time: 0.0129
INFO - 2017-02-17 23:51:52 --> Config Class Initialized
INFO - 2017-02-17 23:51:52 --> Hooks Class Initialized
DEBUG - 2017-02-17 23:51:52 --> UTF-8 Support Enabled
INFO - 2017-02-17 23:51:52 --> Utf8 Class Initialized
INFO - 2017-02-17 23:51:52 --> URI Class Initialized
INFO - 2017-02-17 23:51:52 --> Router Class Initialized
INFO - 2017-02-17 23:51:52 --> Output Class Initialized
INFO - 2017-02-17 23:51:52 --> Security Class Initialized
DEBUG - 2017-02-17 23:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 23:51:52 --> Input Class Initialized
INFO - 2017-02-17 23:51:52 --> Language Class Initialized
INFO - 2017-02-17 23:51:52 --> Loader Class Initialized
INFO - 2017-02-17 23:51:52 --> Database Driver Class Initialized
INFO - 2017-02-17 23:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 23:51:52 --> Controller Class Initialized
INFO - 2017-02-17 23:51:52 --> Helper loaded: url_helper
DEBUG - 2017-02-17 23:51:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 23:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 23:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 23:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 23:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 23:51:52 --> Final output sent to browser
DEBUG - 2017-02-17 23:51:52 --> Total execution time: 0.0237
INFO - 2017-02-17 23:51:55 --> Config Class Initialized
INFO - 2017-02-17 23:51:55 --> Hooks Class Initialized
DEBUG - 2017-02-17 23:51:55 --> UTF-8 Support Enabled
INFO - 2017-02-17 23:51:55 --> Utf8 Class Initialized
INFO - 2017-02-17 23:51:55 --> URI Class Initialized
INFO - 2017-02-17 23:51:55 --> Router Class Initialized
INFO - 2017-02-17 23:51:55 --> Output Class Initialized
INFO - 2017-02-17 23:51:55 --> Security Class Initialized
DEBUG - 2017-02-17 23:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 23:51:55 --> Input Class Initialized
INFO - 2017-02-17 23:51:55 --> Language Class Initialized
INFO - 2017-02-17 23:51:55 --> Loader Class Initialized
INFO - 2017-02-17 23:51:55 --> Database Driver Class Initialized
INFO - 2017-02-17 23:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 23:51:55 --> Controller Class Initialized
INFO - 2017-02-17 23:51:55 --> Helper loaded: url_helper
DEBUG - 2017-02-17 23:51:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 23:51:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 23:51:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 23:51:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 23:51:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 23:51:55 --> Final output sent to browser
DEBUG - 2017-02-17 23:51:55 --> Total execution time: 0.0129
INFO - 2017-02-17 23:52:30 --> Config Class Initialized
INFO - 2017-02-17 23:52:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 23:52:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 23:52:30 --> Utf8 Class Initialized
INFO - 2017-02-17 23:52:30 --> URI Class Initialized
INFO - 2017-02-17 23:52:30 --> Router Class Initialized
INFO - 2017-02-17 23:52:30 --> Output Class Initialized
INFO - 2017-02-17 23:52:30 --> Security Class Initialized
DEBUG - 2017-02-17 23:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 23:52:30 --> Input Class Initialized
INFO - 2017-02-17 23:52:30 --> Language Class Initialized
INFO - 2017-02-17 23:52:30 --> Loader Class Initialized
INFO - 2017-02-17 23:52:30 --> Database Driver Class Initialized
INFO - 2017-02-17 23:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 23:52:30 --> Controller Class Initialized
INFO - 2017-02-17 23:52:30 --> Helper loaded: url_helper
DEBUG - 2017-02-17 23:52:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 23:52:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 23:52:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 23:52:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 23:52:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 23:52:30 --> Final output sent to browser
DEBUG - 2017-02-17 23:52:30 --> Total execution time: 0.0131
INFO - 2017-02-17 23:52:31 --> Config Class Initialized
INFO - 2017-02-17 23:52:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 23:52:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 23:52:31 --> Utf8 Class Initialized
INFO - 2017-02-17 23:52:31 --> URI Class Initialized
DEBUG - 2017-02-17 23:52:31 --> No URI present. Default controller set.
INFO - 2017-02-17 23:52:31 --> Router Class Initialized
INFO - 2017-02-17 23:52:31 --> Output Class Initialized
INFO - 2017-02-17 23:52:31 --> Security Class Initialized
DEBUG - 2017-02-17 23:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 23:52:31 --> Input Class Initialized
INFO - 2017-02-17 23:52:31 --> Language Class Initialized
INFO - 2017-02-17 23:52:31 --> Loader Class Initialized
INFO - 2017-02-17 23:52:31 --> Database Driver Class Initialized
INFO - 2017-02-17 23:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 23:52:31 --> Controller Class Initialized
INFO - 2017-02-17 23:52:31 --> Helper loaded: url_helper
DEBUG - 2017-02-17 23:52:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 23:52:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 23:52:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-17 23:52:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-17 23:52:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 23:52:31 --> Final output sent to browser
DEBUG - 2017-02-17 23:52:31 --> Total execution time: 0.0138
INFO - 2017-02-17 23:52:31 --> Config Class Initialized
INFO - 2017-02-17 23:52:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 23:52:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 23:52:31 --> Utf8 Class Initialized
INFO - 2017-02-17 23:52:31 --> URI Class Initialized
INFO - 2017-02-17 23:52:31 --> Router Class Initialized
INFO - 2017-02-17 23:52:31 --> Output Class Initialized
INFO - 2017-02-17 23:52:31 --> Security Class Initialized
DEBUG - 2017-02-17 23:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 23:52:31 --> Input Class Initialized
INFO - 2017-02-17 23:52:31 --> Language Class Initialized
INFO - 2017-02-17 23:52:31 --> Loader Class Initialized
INFO - 2017-02-17 23:52:31 --> Database Driver Class Initialized
INFO - 2017-02-17 23:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 23:52:31 --> Controller Class Initialized
INFO - 2017-02-17 23:52:31 --> Helper loaded: date_helper
DEBUG - 2017-02-17 23:52:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-17 23:52:31 --> Helper loaded: url_helper
INFO - 2017-02-17 23:52:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-17 23:52:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-17 23:52:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-17 23:52:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-17 23:52:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-17 23:52:31 --> Final output sent to browser
DEBUG - 2017-02-17 23:52:31 --> Total execution time: 0.0128

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-09 01:58:44 --> Config Class Initialized
INFO - 2017-01-09 01:58:44 --> Hooks Class Initialized
DEBUG - 2017-01-09 01:58:44 --> UTF-8 Support Enabled
INFO - 2017-01-09 01:58:44 --> Utf8 Class Initialized
INFO - 2017-01-09 01:58:44 --> URI Class Initialized
DEBUG - 2017-01-09 01:58:44 --> No URI present. Default controller set.
INFO - 2017-01-09 01:58:44 --> Router Class Initialized
INFO - 2017-01-09 01:58:44 --> Output Class Initialized
INFO - 2017-01-09 01:58:44 --> Security Class Initialized
DEBUG - 2017-01-09 01:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 01:58:44 --> Input Class Initialized
INFO - 2017-01-09 01:58:44 --> Language Class Initialized
INFO - 2017-01-09 01:58:44 --> Loader Class Initialized
INFO - 2017-01-09 01:58:44 --> Database Driver Class Initialized
INFO - 2017-01-09 01:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 01:58:44 --> Controller Class Initialized
INFO - 2017-01-09 01:58:44 --> Helper loaded: url_helper
DEBUG - 2017-01-09 01:58:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 01:58:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 01:58:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 01:58:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 01:58:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 01:58:45 --> Final output sent to browser
DEBUG - 2017-01-09 01:58:45 --> Total execution time: 1.7210
INFO - 2017-01-09 02:34:36 --> Config Class Initialized
INFO - 2017-01-09 02:34:36 --> Hooks Class Initialized
DEBUG - 2017-01-09 02:34:36 --> UTF-8 Support Enabled
INFO - 2017-01-09 02:34:36 --> Utf8 Class Initialized
INFO - 2017-01-09 02:34:36 --> URI Class Initialized
DEBUG - 2017-01-09 02:34:36 --> No URI present. Default controller set.
INFO - 2017-01-09 02:34:36 --> Router Class Initialized
INFO - 2017-01-09 02:34:36 --> Output Class Initialized
INFO - 2017-01-09 02:34:36 --> Security Class Initialized
DEBUG - 2017-01-09 02:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 02:34:37 --> Input Class Initialized
INFO - 2017-01-09 02:34:37 --> Language Class Initialized
INFO - 2017-01-09 02:34:37 --> Loader Class Initialized
INFO - 2017-01-09 02:34:37 --> Database Driver Class Initialized
INFO - 2017-01-09 02:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 02:34:37 --> Controller Class Initialized
INFO - 2017-01-09 02:34:37 --> Helper loaded: url_helper
DEBUG - 2017-01-09 02:34:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 02:34:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 02:34:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 02:34:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 02:34:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 02:34:37 --> Final output sent to browser
DEBUG - 2017-01-09 02:34:37 --> Total execution time: 1.5207
INFO - 2017-01-09 02:34:47 --> Config Class Initialized
INFO - 2017-01-09 02:34:47 --> Hooks Class Initialized
DEBUG - 2017-01-09 02:34:47 --> UTF-8 Support Enabled
INFO - 2017-01-09 02:34:47 --> Utf8 Class Initialized
INFO - 2017-01-09 02:34:47 --> URI Class Initialized
DEBUG - 2017-01-09 02:34:47 --> No URI present. Default controller set.
INFO - 2017-01-09 02:34:47 --> Router Class Initialized
INFO - 2017-01-09 02:34:47 --> Output Class Initialized
INFO - 2017-01-09 02:34:47 --> Security Class Initialized
DEBUG - 2017-01-09 02:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 02:34:47 --> Input Class Initialized
INFO - 2017-01-09 02:34:47 --> Language Class Initialized
INFO - 2017-01-09 02:34:47 --> Loader Class Initialized
INFO - 2017-01-09 02:34:47 --> Database Driver Class Initialized
INFO - 2017-01-09 02:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 02:34:47 --> Controller Class Initialized
INFO - 2017-01-09 02:34:47 --> Helper loaded: url_helper
DEBUG - 2017-01-09 02:34:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 02:34:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 02:34:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 02:34:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 02:34:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 02:34:47 --> Final output sent to browser
DEBUG - 2017-01-09 02:34:47 --> Total execution time: 0.0139
INFO - 2017-01-09 02:34:56 --> Config Class Initialized
INFO - 2017-01-09 02:34:56 --> Hooks Class Initialized
DEBUG - 2017-01-09 02:34:56 --> UTF-8 Support Enabled
INFO - 2017-01-09 02:34:56 --> Utf8 Class Initialized
INFO - 2017-01-09 02:34:56 --> URI Class Initialized
INFO - 2017-01-09 02:34:56 --> Router Class Initialized
INFO - 2017-01-09 02:34:56 --> Output Class Initialized
INFO - 2017-01-09 02:34:56 --> Security Class Initialized
DEBUG - 2017-01-09 02:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 02:34:56 --> Input Class Initialized
INFO - 2017-01-09 02:34:56 --> Language Class Initialized
INFO - 2017-01-09 02:34:56 --> Loader Class Initialized
INFO - 2017-01-09 02:34:56 --> Database Driver Class Initialized
INFO - 2017-01-09 02:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 02:34:56 --> Controller Class Initialized
INFO - 2017-01-09 02:34:56 --> Helper loaded: url_helper
DEBUG - 2017-01-09 02:34:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 02:34:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 02:34:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 02:34:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 02:34:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 02:34:56 --> Final output sent to browser
DEBUG - 2017-01-09 02:34:56 --> Total execution time: 0.0145
INFO - 2017-01-09 02:35:12 --> Config Class Initialized
INFO - 2017-01-09 02:35:12 --> Hooks Class Initialized
DEBUG - 2017-01-09 02:35:12 --> UTF-8 Support Enabled
INFO - 2017-01-09 02:35:12 --> Utf8 Class Initialized
INFO - 2017-01-09 02:35:12 --> URI Class Initialized
DEBUG - 2017-01-09 02:35:12 --> No URI present. Default controller set.
INFO - 2017-01-09 02:35:12 --> Router Class Initialized
INFO - 2017-01-09 02:35:13 --> Output Class Initialized
INFO - 2017-01-09 02:35:13 --> Security Class Initialized
DEBUG - 2017-01-09 02:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 02:35:13 --> Input Class Initialized
INFO - 2017-01-09 02:35:13 --> Language Class Initialized
INFO - 2017-01-09 02:35:13 --> Loader Class Initialized
INFO - 2017-01-09 02:35:13 --> Database Driver Class Initialized
INFO - 2017-01-09 02:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 02:35:13 --> Controller Class Initialized
INFO - 2017-01-09 02:35:13 --> Helper loaded: url_helper
DEBUG - 2017-01-09 02:35:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 02:35:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 02:35:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 02:35:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 02:35:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 02:35:13 --> Final output sent to browser
DEBUG - 2017-01-09 02:35:13 --> Total execution time: 0.2876
INFO - 2017-01-09 11:27:34 --> Config Class Initialized
INFO - 2017-01-09 11:27:34 --> Hooks Class Initialized
DEBUG - 2017-01-09 11:27:34 --> UTF-8 Support Enabled
INFO - 2017-01-09 11:27:35 --> Utf8 Class Initialized
INFO - 2017-01-09 11:27:35 --> URI Class Initialized
INFO - 2017-01-09 11:27:35 --> Router Class Initialized
INFO - 2017-01-09 11:27:35 --> Output Class Initialized
INFO - 2017-01-09 11:27:35 --> Security Class Initialized
DEBUG - 2017-01-09 11:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 11:27:35 --> Input Class Initialized
INFO - 2017-01-09 11:27:35 --> Language Class Initialized
INFO - 2017-01-09 11:27:35 --> Loader Class Initialized
INFO - 2017-01-09 11:27:35 --> Database Driver Class Initialized
INFO - 2017-01-09 11:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 11:27:36 --> Controller Class Initialized
INFO - 2017-01-09 11:27:36 --> Helper loaded: url_helper
DEBUG - 2017-01-09 11:27:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 11:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 11:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 11:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 11:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 11:27:36 --> Final output sent to browser
DEBUG - 2017-01-09 11:27:36 --> Total execution time: 1.8505
INFO - 2017-01-09 11:27:37 --> Config Class Initialized
INFO - 2017-01-09 11:27:37 --> Hooks Class Initialized
DEBUG - 2017-01-09 11:27:37 --> UTF-8 Support Enabled
INFO - 2017-01-09 11:27:37 --> Utf8 Class Initialized
INFO - 2017-01-09 11:27:37 --> URI Class Initialized
DEBUG - 2017-01-09 11:27:37 --> No URI present. Default controller set.
INFO - 2017-01-09 11:27:37 --> Router Class Initialized
INFO - 2017-01-09 11:27:37 --> Output Class Initialized
INFO - 2017-01-09 11:27:37 --> Security Class Initialized
DEBUG - 2017-01-09 11:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 11:27:37 --> Input Class Initialized
INFO - 2017-01-09 11:27:37 --> Language Class Initialized
INFO - 2017-01-09 11:27:37 --> Loader Class Initialized
INFO - 2017-01-09 11:27:37 --> Database Driver Class Initialized
INFO - 2017-01-09 11:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 11:27:37 --> Controller Class Initialized
INFO - 2017-01-09 11:27:37 --> Helper loaded: url_helper
DEBUG - 2017-01-09 11:27:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 11:27:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 11:27:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 11:27:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 11:27:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 11:27:37 --> Final output sent to browser
DEBUG - 2017-01-09 11:27:37 --> Total execution time: 0.0156
INFO - 2017-01-09 17:16:16 --> Config Class Initialized
INFO - 2017-01-09 17:16:16 --> Hooks Class Initialized
DEBUG - 2017-01-09 17:16:17 --> UTF-8 Support Enabled
INFO - 2017-01-09 17:16:17 --> Utf8 Class Initialized
INFO - 2017-01-09 17:16:17 --> URI Class Initialized
DEBUG - 2017-01-09 17:16:17 --> No URI present. Default controller set.
INFO - 2017-01-09 17:16:17 --> Router Class Initialized
INFO - 2017-01-09 17:16:17 --> Output Class Initialized
INFO - 2017-01-09 17:16:17 --> Security Class Initialized
DEBUG - 2017-01-09 17:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 17:16:17 --> Input Class Initialized
INFO - 2017-01-09 17:16:17 --> Language Class Initialized
INFO - 2017-01-09 17:16:17 --> Loader Class Initialized
INFO - 2017-01-09 17:16:17 --> Database Driver Class Initialized
INFO - 2017-01-09 17:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 17:16:19 --> Controller Class Initialized
INFO - 2017-01-09 17:16:19 --> Helper loaded: url_helper
DEBUG - 2017-01-09 17:16:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 17:16:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 17:16:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 17:16:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 17:16:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 17:16:20 --> Final output sent to browser
DEBUG - 2017-01-09 17:16:20 --> Total execution time: 3.8256
INFO - 2017-01-09 18:21:22 --> Config Class Initialized
INFO - 2017-01-09 18:21:22 --> Hooks Class Initialized
DEBUG - 2017-01-09 18:21:22 --> UTF-8 Support Enabled
INFO - 2017-01-09 18:21:22 --> Utf8 Class Initialized
INFO - 2017-01-09 18:21:22 --> URI Class Initialized
DEBUG - 2017-01-09 18:21:22 --> No URI present. Default controller set.
INFO - 2017-01-09 18:21:23 --> Router Class Initialized
INFO - 2017-01-09 18:21:23 --> Output Class Initialized
INFO - 2017-01-09 18:21:23 --> Security Class Initialized
DEBUG - 2017-01-09 18:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 18:21:23 --> Input Class Initialized
INFO - 2017-01-09 18:21:23 --> Language Class Initialized
INFO - 2017-01-09 18:21:23 --> Loader Class Initialized
INFO - 2017-01-09 18:21:23 --> Database Driver Class Initialized
INFO - 2017-01-09 18:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 18:21:24 --> Controller Class Initialized
INFO - 2017-01-09 18:21:24 --> Helper loaded: url_helper
DEBUG - 2017-01-09 18:21:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 18:21:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 18:21:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 18:21:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 18:21:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 18:21:24 --> Final output sent to browser
DEBUG - 2017-01-09 18:21:24 --> Total execution time: 1.7426
INFO - 2017-01-09 19:10:18 --> Config Class Initialized
INFO - 2017-01-09 19:10:18 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:10:19 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:10:19 --> Utf8 Class Initialized
INFO - 2017-01-09 19:10:19 --> URI Class Initialized
DEBUG - 2017-01-09 19:10:19 --> No URI present. Default controller set.
INFO - 2017-01-09 19:10:19 --> Router Class Initialized
INFO - 2017-01-09 19:10:19 --> Output Class Initialized
INFO - 2017-01-09 19:10:19 --> Security Class Initialized
DEBUG - 2017-01-09 19:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:10:19 --> Input Class Initialized
INFO - 2017-01-09 19:10:19 --> Language Class Initialized
INFO - 2017-01-09 19:10:19 --> Loader Class Initialized
INFO - 2017-01-09 19:10:19 --> Database Driver Class Initialized
INFO - 2017-01-09 19:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:10:20 --> Controller Class Initialized
INFO - 2017-01-09 19:10:20 --> Helper loaded: url_helper
DEBUG - 2017-01-09 19:10:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 19:10:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 19:10:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 19:10:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 19:10:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 19:10:20 --> Final output sent to browser
DEBUG - 2017-01-09 19:10:20 --> Total execution time: 1.8338
INFO - 2017-01-09 19:11:40 --> Config Class Initialized
INFO - 2017-01-09 19:11:40 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:11:40 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:11:40 --> Utf8 Class Initialized
INFO - 2017-01-09 19:11:40 --> URI Class Initialized
INFO - 2017-01-09 19:11:40 --> Router Class Initialized
INFO - 2017-01-09 19:11:40 --> Output Class Initialized
INFO - 2017-01-09 19:11:40 --> Security Class Initialized
DEBUG - 2017-01-09 19:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:11:40 --> Input Class Initialized
INFO - 2017-01-09 19:11:40 --> Language Class Initialized
INFO - 2017-01-09 19:11:40 --> Loader Class Initialized
INFO - 2017-01-09 19:11:40 --> Database Driver Class Initialized
INFO - 2017-01-09 19:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:11:40 --> Controller Class Initialized
INFO - 2017-01-09 19:11:40 --> Helper loaded: url_helper
DEBUG - 2017-01-09 19:11:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 19:11:49 --> Config Class Initialized
INFO - 2017-01-09 19:11:49 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:11:49 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:11:49 --> Utf8 Class Initialized
INFO - 2017-01-09 19:11:49 --> URI Class Initialized
INFO - 2017-01-09 19:11:49 --> Router Class Initialized
INFO - 2017-01-09 19:11:49 --> Output Class Initialized
INFO - 2017-01-09 19:11:49 --> Security Class Initialized
DEBUG - 2017-01-09 19:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:11:49 --> Input Class Initialized
INFO - 2017-01-09 19:11:49 --> Language Class Initialized
INFO - 2017-01-09 19:11:49 --> Loader Class Initialized
INFO - 2017-01-09 19:11:49 --> Database Driver Class Initialized
INFO - 2017-01-09 19:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:11:49 --> Controller Class Initialized
INFO - 2017-01-09 19:11:49 --> Helper loaded: date_helper
DEBUG - 2017-01-09 19:11:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 19:11:49 --> Helper loaded: url_helper
INFO - 2017-01-09 19:11:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 19:11:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-09 19:11:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-09 19:11:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-09 19:11:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 19:11:49 --> Final output sent to browser
DEBUG - 2017-01-09 19:11:49 --> Total execution time: 0.1092
INFO - 2017-01-09 19:14:47 --> Config Class Initialized
INFO - 2017-01-09 19:14:47 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:14:47 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:14:47 --> Utf8 Class Initialized
INFO - 2017-01-09 19:14:47 --> URI Class Initialized
DEBUG - 2017-01-09 19:14:47 --> No URI present. Default controller set.
INFO - 2017-01-09 19:14:47 --> Router Class Initialized
INFO - 2017-01-09 19:14:47 --> Output Class Initialized
INFO - 2017-01-09 19:14:47 --> Security Class Initialized
DEBUG - 2017-01-09 19:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:14:47 --> Input Class Initialized
INFO - 2017-01-09 19:14:47 --> Language Class Initialized
INFO - 2017-01-09 19:14:47 --> Loader Class Initialized
INFO - 2017-01-09 19:14:47 --> Database Driver Class Initialized
INFO - 2017-01-09 19:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:14:47 --> Controller Class Initialized
INFO - 2017-01-09 19:14:47 --> Helper loaded: url_helper
DEBUG - 2017-01-09 19:14:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 19:14:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 19:14:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 19:14:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 19:14:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 19:14:47 --> Final output sent to browser
DEBUG - 2017-01-09 19:14:47 --> Total execution time: 0.0134
INFO - 2017-01-09 19:16:56 --> Config Class Initialized
INFO - 2017-01-09 19:16:56 --> Hooks Class Initialized
DEBUG - 2017-01-09 19:16:56 --> UTF-8 Support Enabled
INFO - 2017-01-09 19:16:56 --> Utf8 Class Initialized
INFO - 2017-01-09 19:16:56 --> URI Class Initialized
DEBUG - 2017-01-09 19:16:56 --> No URI present. Default controller set.
INFO - 2017-01-09 19:16:56 --> Router Class Initialized
INFO - 2017-01-09 19:16:56 --> Output Class Initialized
INFO - 2017-01-09 19:16:56 --> Security Class Initialized
DEBUG - 2017-01-09 19:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 19:16:56 --> Input Class Initialized
INFO - 2017-01-09 19:16:56 --> Language Class Initialized
INFO - 2017-01-09 19:16:56 --> Loader Class Initialized
INFO - 2017-01-09 19:16:56 --> Database Driver Class Initialized
INFO - 2017-01-09 19:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 19:16:56 --> Controller Class Initialized
INFO - 2017-01-09 19:16:56 --> Helper loaded: url_helper
DEBUG - 2017-01-09 19:16:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 19:16:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 19:16:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 19:16:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 19:16:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 19:16:56 --> Final output sent to browser
DEBUG - 2017-01-09 19:16:56 --> Total execution time: 0.0135
INFO - 2017-01-09 22:33:27 --> Config Class Initialized
INFO - 2017-01-09 22:33:27 --> Hooks Class Initialized
DEBUG - 2017-01-09 22:33:28 --> UTF-8 Support Enabled
INFO - 2017-01-09 22:33:28 --> Utf8 Class Initialized
INFO - 2017-01-09 22:33:28 --> URI Class Initialized
INFO - 2017-01-09 22:33:28 --> Router Class Initialized
INFO - 2017-01-09 22:33:28 --> Output Class Initialized
INFO - 2017-01-09 22:33:28 --> Security Class Initialized
DEBUG - 2017-01-09 22:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 22:33:28 --> Input Class Initialized
INFO - 2017-01-09 22:33:28 --> Language Class Initialized
INFO - 2017-01-09 22:33:28 --> Loader Class Initialized
INFO - 2017-01-09 22:33:28 --> Database Driver Class Initialized
INFO - 2017-01-09 22:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 22:33:29 --> Controller Class Initialized
INFO - 2017-01-09 22:33:29 --> Helper loaded: url_helper
DEBUG - 2017-01-09 22:33:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 22:33:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 22:33:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 22:33:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 22:33:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 22:33:31 --> Final output sent to browser
DEBUG - 2017-01-09 22:33:31 --> Total execution time: 2.5175
INFO - 2017-01-09 22:52:24 --> Config Class Initialized
INFO - 2017-01-09 22:52:24 --> Hooks Class Initialized
DEBUG - 2017-01-09 22:52:24 --> UTF-8 Support Enabled
INFO - 2017-01-09 22:52:24 --> Utf8 Class Initialized
INFO - 2017-01-09 22:52:24 --> URI Class Initialized
INFO - 2017-01-09 22:52:24 --> Router Class Initialized
INFO - 2017-01-09 22:52:25 --> Output Class Initialized
INFO - 2017-01-09 22:52:25 --> Security Class Initialized
DEBUG - 2017-01-09 22:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 22:52:25 --> Input Class Initialized
INFO - 2017-01-09 22:52:25 --> Language Class Initialized
INFO - 2017-01-09 22:52:25 --> Loader Class Initialized
INFO - 2017-01-09 22:52:25 --> Database Driver Class Initialized
INFO - 2017-01-09 22:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 22:52:25 --> Controller Class Initialized
INFO - 2017-01-09 22:52:25 --> Helper loaded: url_helper
DEBUG - 2017-01-09 22:52:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 22:52:25 --> Helper loaded: form_helper
INFO - 2017-01-09 22:52:26 --> Form Validation Class Initialized
INFO - 2017-01-09 22:52:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-09 22:52:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-09 22:52:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-09 22:52:26 --> Final output sent to browser
DEBUG - 2017-01-09 22:52:26 --> Total execution time: 1.4465
INFO - 2017-01-09 22:52:28 --> Config Class Initialized
INFO - 2017-01-09 22:52:28 --> Hooks Class Initialized
DEBUG - 2017-01-09 22:52:28 --> UTF-8 Support Enabled
INFO - 2017-01-09 22:52:28 --> Utf8 Class Initialized
INFO - 2017-01-09 22:52:28 --> URI Class Initialized
INFO - 2017-01-09 22:52:28 --> Router Class Initialized
INFO - 2017-01-09 22:52:28 --> Output Class Initialized
INFO - 2017-01-09 22:52:28 --> Security Class Initialized
DEBUG - 2017-01-09 22:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 22:52:28 --> Input Class Initialized
INFO - 2017-01-09 22:52:28 --> Language Class Initialized
INFO - 2017-01-09 22:52:28 --> Loader Class Initialized
INFO - 2017-01-09 22:52:28 --> Database Driver Class Initialized
INFO - 2017-01-09 22:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 22:52:28 --> Controller Class Initialized
INFO - 2017-01-09 22:52:28 --> Helper loaded: url_helper
DEBUG - 2017-01-09 22:52:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 22:52:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 22:52:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 22:52:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 22:52:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 22:52:28 --> Final output sent to browser
DEBUG - 2017-01-09 22:52:28 --> Total execution time: 1.2737
INFO - 2017-01-09 22:53:45 --> Config Class Initialized
INFO - 2017-01-09 22:53:45 --> Hooks Class Initialized
DEBUG - 2017-01-09 22:53:45 --> UTF-8 Support Enabled
INFO - 2017-01-09 22:53:45 --> Utf8 Class Initialized
INFO - 2017-01-09 22:53:45 --> URI Class Initialized
INFO - 2017-01-09 22:53:45 --> Router Class Initialized
INFO - 2017-01-09 22:53:45 --> Output Class Initialized
INFO - 2017-01-09 22:53:45 --> Security Class Initialized
DEBUG - 2017-01-09 22:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 22:53:45 --> Input Class Initialized
INFO - 2017-01-09 22:53:45 --> Language Class Initialized
INFO - 2017-01-09 22:53:45 --> Loader Class Initialized
INFO - 2017-01-09 22:53:46 --> Database Driver Class Initialized
INFO - 2017-01-09 22:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 22:53:46 --> Controller Class Initialized
INFO - 2017-01-09 22:53:46 --> Helper loaded: url_helper
DEBUG - 2017-01-09 22:53:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 22:53:46 --> Helper loaded: form_helper
INFO - 2017-01-09 22:53:46 --> Form Validation Class Initialized
INFO - 2017-01-09 22:53:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-09 22:53:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-09 22:53:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-09 22:53:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-09 22:53:46 --> Final output sent to browser
DEBUG - 2017-01-09 22:53:46 --> Total execution time: 1.2188
INFO - 2017-01-09 22:53:46 --> Config Class Initialized
INFO - 2017-01-09 22:53:46 --> Hooks Class Initialized
DEBUG - 2017-01-09 22:53:46 --> UTF-8 Support Enabled
INFO - 2017-01-09 22:53:46 --> Utf8 Class Initialized
INFO - 2017-01-09 22:53:46 --> URI Class Initialized
INFO - 2017-01-09 22:53:46 --> Router Class Initialized
INFO - 2017-01-09 22:53:46 --> Output Class Initialized
INFO - 2017-01-09 22:53:46 --> Security Class Initialized
DEBUG - 2017-01-09 22:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 22:53:46 --> Input Class Initialized
INFO - 2017-01-09 22:53:46 --> Language Class Initialized
INFO - 2017-01-09 22:53:46 --> Loader Class Initialized
INFO - 2017-01-09 22:53:46 --> Database Driver Class Initialized
INFO - 2017-01-09 22:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 22:53:46 --> Controller Class Initialized
INFO - 2017-01-09 22:53:46 --> Helper loaded: url_helper
DEBUG - 2017-01-09 22:53:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 22:53:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 22:53:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 22:53:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 22:53:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 22:53:46 --> Final output sent to browser
DEBUG - 2017-01-09 22:53:46 --> Total execution time: 0.2778
INFO - 2017-01-09 22:54:24 --> Config Class Initialized
INFO - 2017-01-09 22:54:24 --> Hooks Class Initialized
DEBUG - 2017-01-09 22:54:24 --> UTF-8 Support Enabled
INFO - 2017-01-09 22:54:24 --> Utf8 Class Initialized
INFO - 2017-01-09 22:54:24 --> URI Class Initialized
INFO - 2017-01-09 22:54:24 --> Router Class Initialized
INFO - 2017-01-09 22:54:24 --> Output Class Initialized
INFO - 2017-01-09 22:54:24 --> Security Class Initialized
DEBUG - 2017-01-09 22:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 22:54:24 --> Input Class Initialized
INFO - 2017-01-09 22:54:24 --> Language Class Initialized
INFO - 2017-01-09 22:54:24 --> Loader Class Initialized
INFO - 2017-01-09 22:54:25 --> Database Driver Class Initialized
INFO - 2017-01-09 22:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 22:54:25 --> Controller Class Initialized
INFO - 2017-01-09 22:54:25 --> Helper loaded: url_helper
DEBUG - 2017-01-09 22:54:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 22:54:25 --> Helper loaded: form_helper
INFO - 2017-01-09 22:54:25 --> Form Validation Class Initialized
INFO - 2017-01-09 22:54:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-09 22:54:25 --> Config Class Initialized
INFO - 2017-01-09 22:54:25 --> Hooks Class Initialized
DEBUG - 2017-01-09 22:54:25 --> UTF-8 Support Enabled
INFO - 2017-01-09 22:54:25 --> Utf8 Class Initialized
INFO - 2017-01-09 22:54:25 --> URI Class Initialized
INFO - 2017-01-09 22:54:25 --> Router Class Initialized
INFO - 2017-01-09 22:54:25 --> Output Class Initialized
INFO - 2017-01-09 22:54:25 --> Security Class Initialized
DEBUG - 2017-01-09 22:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 22:54:25 --> Input Class Initialized
INFO - 2017-01-09 22:54:25 --> Language Class Initialized
INFO - 2017-01-09 22:54:25 --> Loader Class Initialized
INFO - 2017-01-09 22:54:25 --> Database Driver Class Initialized
INFO - 2017-01-09 22:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 22:54:25 --> Controller Class Initialized
INFO - 2017-01-09 22:54:25 --> Helper loaded: date_helper
INFO - 2017-01-09 22:54:25 --> Helper loaded: url_helper
DEBUG - 2017-01-09 22:54:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 22:54:25 --> Helper loaded: form_helper
INFO - 2017-01-09 22:54:25 --> Form Validation Class Initialized
INFO - 2017-01-09 22:54:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-09 22:54:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-09 22:54:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-09 22:54:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-09 22:54:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-09 22:54:26 --> Final output sent to browser
DEBUG - 2017-01-09 22:54:26 --> Total execution time: 0.5110
INFO - 2017-01-09 22:54:26 --> Config Class Initialized
INFO - 2017-01-09 22:54:26 --> Hooks Class Initialized
DEBUG - 2017-01-09 22:54:26 --> UTF-8 Support Enabled
INFO - 2017-01-09 22:54:26 --> Utf8 Class Initialized
INFO - 2017-01-09 22:54:26 --> URI Class Initialized
INFO - 2017-01-09 22:54:26 --> Router Class Initialized
INFO - 2017-01-09 22:54:26 --> Output Class Initialized
INFO - 2017-01-09 22:54:26 --> Security Class Initialized
DEBUG - 2017-01-09 22:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 22:54:26 --> Input Class Initialized
INFO - 2017-01-09 22:54:26 --> Language Class Initialized
INFO - 2017-01-09 22:54:26 --> Loader Class Initialized
INFO - 2017-01-09 22:54:26 --> Database Driver Class Initialized
INFO - 2017-01-09 22:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 22:54:26 --> Controller Class Initialized
INFO - 2017-01-09 22:54:26 --> Helper loaded: date_helper
INFO - 2017-01-09 22:54:26 --> Helper loaded: url_helper
DEBUG - 2017-01-09 22:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 22:54:26 --> Helper loaded: form_helper
INFO - 2017-01-09 22:54:26 --> Form Validation Class Initialized
INFO - 2017-01-09 22:54:26 --> Final output sent to browser
DEBUG - 2017-01-09 22:54:26 --> Total execution time: 0.0153
INFO - 2017-01-09 22:54:27 --> Config Class Initialized
INFO - 2017-01-09 22:54:27 --> Hooks Class Initialized
DEBUG - 2017-01-09 22:54:27 --> UTF-8 Support Enabled
INFO - 2017-01-09 22:54:27 --> Utf8 Class Initialized
INFO - 2017-01-09 22:54:27 --> URI Class Initialized
INFO - 2017-01-09 22:54:27 --> Router Class Initialized
INFO - 2017-01-09 22:54:27 --> Output Class Initialized
INFO - 2017-01-09 22:54:27 --> Security Class Initialized
DEBUG - 2017-01-09 22:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 22:54:27 --> Input Class Initialized
INFO - 2017-01-09 22:54:27 --> Language Class Initialized
INFO - 2017-01-09 22:54:27 --> Loader Class Initialized
INFO - 2017-01-09 22:54:27 --> Database Driver Class Initialized
INFO - 2017-01-09 22:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 22:54:27 --> Controller Class Initialized
INFO - 2017-01-09 22:54:27 --> Helper loaded: url_helper
DEBUG - 2017-01-09 22:54:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 22:54:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 22:54:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 22:54:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 22:54:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 22:54:28 --> Final output sent to browser
DEBUG - 2017-01-09 22:54:28 --> Total execution time: 0.2939
INFO - 2017-01-09 23:07:11 --> Config Class Initialized
INFO - 2017-01-09 23:07:11 --> Hooks Class Initialized
DEBUG - 2017-01-09 23:07:11 --> UTF-8 Support Enabled
INFO - 2017-01-09 23:07:11 --> Utf8 Class Initialized
INFO - 2017-01-09 23:07:11 --> URI Class Initialized
INFO - 2017-01-09 23:07:11 --> Router Class Initialized
INFO - 2017-01-09 23:07:11 --> Output Class Initialized
INFO - 2017-01-09 23:07:11 --> Security Class Initialized
DEBUG - 2017-01-09 23:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 23:07:11 --> Input Class Initialized
INFO - 2017-01-09 23:07:11 --> Language Class Initialized
INFO - 2017-01-09 23:07:11 --> Loader Class Initialized
INFO - 2017-01-09 23:07:11 --> Database Driver Class Initialized
INFO - 2017-01-09 23:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 23:07:11 --> Controller Class Initialized
INFO - 2017-01-09 23:07:11 --> Helper loaded: url_helper
DEBUG - 2017-01-09 23:07:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 23:07:12 --> Config Class Initialized
INFO - 2017-01-09 23:07:12 --> Hooks Class Initialized
DEBUG - 2017-01-09 23:07:12 --> UTF-8 Support Enabled
INFO - 2017-01-09 23:07:12 --> Utf8 Class Initialized
INFO - 2017-01-09 23:07:12 --> URI Class Initialized
INFO - 2017-01-09 23:07:12 --> Router Class Initialized
INFO - 2017-01-09 23:07:12 --> Output Class Initialized
INFO - 2017-01-09 23:07:12 --> Security Class Initialized
DEBUG - 2017-01-09 23:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 23:07:12 --> Input Class Initialized
INFO - 2017-01-09 23:07:12 --> Language Class Initialized
INFO - 2017-01-09 23:07:12 --> Loader Class Initialized
INFO - 2017-01-09 23:07:12 --> Database Driver Class Initialized
INFO - 2017-01-09 23:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 23:07:12 --> Controller Class Initialized
INFO - 2017-01-09 23:07:12 --> Helper loaded: url_helper
DEBUG - 2017-01-09 23:07:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 23:07:12 --> Helper loaded: form_helper
INFO - 2017-01-09 23:07:12 --> Form Validation Class Initialized
INFO - 2017-01-09 23:07:12 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-09 23:07:12 --> Config Class Initialized
INFO - 2017-01-09 23:07:12 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-09 23:07:12 --> Hooks Class Initialized
DEBUG - 2017-01-09 23:07:12 --> UTF-8 Support Enabled
INFO - 2017-01-09 23:07:12 --> Utf8 Class Initialized
INFO - 2017-01-09 23:07:12 --> URI Class Initialized
INFO - 2017-01-09 23:07:12 --> Router Class Initialized
INFO - 2017-01-09 23:07:12 --> Output Class Initialized
INFO - 2017-01-09 23:07:12 --> Security Class Initialized
DEBUG - 2017-01-09 23:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 23:07:12 --> Input Class Initialized
INFO - 2017-01-09 23:07:12 --> Language Class Initialized
INFO - 2017-01-09 23:07:12 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-09 23:07:12 --> Loader Class Initialized
INFO - 2017-01-09 23:07:12 --> Final output sent to browser
DEBUG - 2017-01-09 23:07:12 --> Total execution time: 0.1406
INFO - 2017-01-09 23:07:12 --> Database Driver Class Initialized
INFO - 2017-01-09 23:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 23:07:12 --> Controller Class Initialized
INFO - 2017-01-09 23:07:12 --> Helper loaded: url_helper
DEBUG - 2017-01-09 23:07:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 23:07:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 23:07:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 23:07:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 23:07:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 23:07:12 --> Final output sent to browser
DEBUG - 2017-01-09 23:07:12 --> Total execution time: 0.2873
INFO - 2017-01-09 23:07:13 --> Config Class Initialized
INFO - 2017-01-09 23:07:13 --> Hooks Class Initialized
DEBUG - 2017-01-09 23:07:13 --> UTF-8 Support Enabled
INFO - 2017-01-09 23:07:13 --> Utf8 Class Initialized
INFO - 2017-01-09 23:07:13 --> URI Class Initialized
INFO - 2017-01-09 23:07:13 --> Router Class Initialized
INFO - 2017-01-09 23:07:13 --> Output Class Initialized
INFO - 2017-01-09 23:07:13 --> Security Class Initialized
DEBUG - 2017-01-09 23:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 23:07:13 --> Input Class Initialized
INFO - 2017-01-09 23:07:13 --> Language Class Initialized
INFO - 2017-01-09 23:07:13 --> Loader Class Initialized
INFO - 2017-01-09 23:07:13 --> Database Driver Class Initialized
INFO - 2017-01-09 23:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 23:07:13 --> Controller Class Initialized
INFO - 2017-01-09 23:07:13 --> Helper loaded: url_helper
DEBUG - 2017-01-09 23:07:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 23:07:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 23:07:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 23:07:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 23:07:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 23:07:13 --> Final output sent to browser
DEBUG - 2017-01-09 23:07:13 --> Total execution time: 0.0148
INFO - 2017-01-09 23:07:28 --> Config Class Initialized
INFO - 2017-01-09 23:07:28 --> Hooks Class Initialized
DEBUG - 2017-01-09 23:07:28 --> UTF-8 Support Enabled
INFO - 2017-01-09 23:07:28 --> Utf8 Class Initialized
INFO - 2017-01-09 23:07:28 --> URI Class Initialized
INFO - 2017-01-09 23:07:28 --> Router Class Initialized
INFO - 2017-01-09 23:07:28 --> Output Class Initialized
INFO - 2017-01-09 23:07:28 --> Security Class Initialized
DEBUG - 2017-01-09 23:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 23:07:28 --> Input Class Initialized
INFO - 2017-01-09 23:07:28 --> Language Class Initialized
INFO - 2017-01-09 23:07:28 --> Loader Class Initialized
INFO - 2017-01-09 23:07:28 --> Database Driver Class Initialized
INFO - 2017-01-09 23:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 23:07:28 --> Controller Class Initialized
INFO - 2017-01-09 23:07:28 --> Helper loaded: url_helper
DEBUG - 2017-01-09 23:07:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 23:07:28 --> Helper loaded: form_helper
INFO - 2017-01-09 23:07:28 --> Form Validation Class Initialized
INFO - 2017-01-09 23:07:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-09 23:07:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-09 23:07:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-09 23:07:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-09 23:07:28 --> Final output sent to browser
DEBUG - 2017-01-09 23:07:28 --> Total execution time: 0.0600
INFO - 2017-01-09 23:07:29 --> Config Class Initialized
INFO - 2017-01-09 23:07:29 --> Hooks Class Initialized
DEBUG - 2017-01-09 23:07:29 --> UTF-8 Support Enabled
INFO - 2017-01-09 23:07:29 --> Utf8 Class Initialized
INFO - 2017-01-09 23:07:29 --> URI Class Initialized
INFO - 2017-01-09 23:07:29 --> Router Class Initialized
INFO - 2017-01-09 23:07:29 --> Output Class Initialized
INFO - 2017-01-09 23:07:29 --> Security Class Initialized
DEBUG - 2017-01-09 23:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 23:07:29 --> Input Class Initialized
INFO - 2017-01-09 23:07:29 --> Language Class Initialized
INFO - 2017-01-09 23:07:29 --> Loader Class Initialized
INFO - 2017-01-09 23:07:29 --> Database Driver Class Initialized
INFO - 2017-01-09 23:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 23:07:29 --> Controller Class Initialized
INFO - 2017-01-09 23:07:29 --> Helper loaded: url_helper
DEBUG - 2017-01-09 23:07:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 23:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 23:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 23:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 23:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 23:07:29 --> Final output sent to browser
DEBUG - 2017-01-09 23:07:29 --> Total execution time: 0.0140
INFO - 2017-01-09 23:09:56 --> Config Class Initialized
INFO - 2017-01-09 23:09:56 --> Hooks Class Initialized
DEBUG - 2017-01-09 23:09:56 --> UTF-8 Support Enabled
INFO - 2017-01-09 23:09:56 --> Utf8 Class Initialized
INFO - 2017-01-09 23:09:56 --> URI Class Initialized
INFO - 2017-01-09 23:09:57 --> Router Class Initialized
INFO - 2017-01-09 23:09:57 --> Output Class Initialized
INFO - 2017-01-09 23:09:57 --> Security Class Initialized
DEBUG - 2017-01-09 23:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 23:09:57 --> Input Class Initialized
INFO - 2017-01-09 23:09:57 --> Language Class Initialized
INFO - 2017-01-09 23:09:57 --> Loader Class Initialized
INFO - 2017-01-09 23:09:57 --> Database Driver Class Initialized
INFO - 2017-01-09 23:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 23:09:57 --> Controller Class Initialized
INFO - 2017-01-09 23:09:57 --> Helper loaded: url_helper
DEBUG - 2017-01-09 23:09:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 23:09:57 --> Helper loaded: form_helper
INFO - 2017-01-09 23:09:57 --> Form Validation Class Initialized
INFO - 2017-01-09 23:09:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-09 23:09:57 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-09 23:09:57 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-09 23:09:57 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-09 23:09:57 --> Final output sent to browser
DEBUG - 2017-01-09 23:09:57 --> Total execution time: 0.1781
INFO - 2017-01-09 23:09:57 --> Config Class Initialized
INFO - 2017-01-09 23:09:57 --> Hooks Class Initialized
DEBUG - 2017-01-09 23:09:57 --> UTF-8 Support Enabled
INFO - 2017-01-09 23:09:57 --> Utf8 Class Initialized
INFO - 2017-01-09 23:09:57 --> URI Class Initialized
INFO - 2017-01-09 23:09:57 --> Router Class Initialized
INFO - 2017-01-09 23:09:57 --> Output Class Initialized
INFO - 2017-01-09 23:09:57 --> Security Class Initialized
DEBUG - 2017-01-09 23:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 23:09:57 --> Input Class Initialized
INFO - 2017-01-09 23:09:57 --> Language Class Initialized
INFO - 2017-01-09 23:09:57 --> Loader Class Initialized
INFO - 2017-01-09 23:09:57 --> Database Driver Class Initialized
INFO - 2017-01-09 23:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 23:09:57 --> Controller Class Initialized
INFO - 2017-01-09 23:09:57 --> Helper loaded: url_helper
DEBUG - 2017-01-09 23:09:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 23:09:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 23:09:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 23:09:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 23:09:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 23:09:57 --> Final output sent to browser
DEBUG - 2017-01-09 23:09:57 --> Total execution time: 0.0153
INFO - 2017-01-09 23:10:19 --> Config Class Initialized
INFO - 2017-01-09 23:10:19 --> Hooks Class Initialized
DEBUG - 2017-01-09 23:10:19 --> UTF-8 Support Enabled
INFO - 2017-01-09 23:10:19 --> Utf8 Class Initialized
INFO - 2017-01-09 23:10:19 --> URI Class Initialized
INFO - 2017-01-09 23:10:19 --> Router Class Initialized
INFO - 2017-01-09 23:10:19 --> Output Class Initialized
INFO - 2017-01-09 23:10:19 --> Security Class Initialized
DEBUG - 2017-01-09 23:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 23:10:19 --> Input Class Initialized
INFO - 2017-01-09 23:10:19 --> Language Class Initialized
INFO - 2017-01-09 23:10:19 --> Loader Class Initialized
INFO - 2017-01-09 23:10:19 --> Database Driver Class Initialized
INFO - 2017-01-09 23:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 23:10:19 --> Controller Class Initialized
INFO - 2017-01-09 23:10:19 --> Helper loaded: url_helper
DEBUG - 2017-01-09 23:10:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 23:10:19 --> Helper loaded: form_helper
INFO - 2017-01-09 23:10:19 --> Form Validation Class Initialized
INFO - 2017-01-09 23:10:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-09 23:10:19 --> Config Class Initialized
INFO - 2017-01-09 23:10:19 --> Hooks Class Initialized
DEBUG - 2017-01-09 23:10:19 --> UTF-8 Support Enabled
INFO - 2017-01-09 23:10:19 --> Utf8 Class Initialized
INFO - 2017-01-09 23:10:19 --> URI Class Initialized
INFO - 2017-01-09 23:10:19 --> Router Class Initialized
INFO - 2017-01-09 23:10:19 --> Output Class Initialized
INFO - 2017-01-09 23:10:19 --> Security Class Initialized
DEBUG - 2017-01-09 23:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 23:10:19 --> Input Class Initialized
INFO - 2017-01-09 23:10:19 --> Language Class Initialized
INFO - 2017-01-09 23:10:19 --> Loader Class Initialized
INFO - 2017-01-09 23:10:19 --> Database Driver Class Initialized
INFO - 2017-01-09 23:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 23:10:19 --> Controller Class Initialized
INFO - 2017-01-09 23:10:19 --> Helper loaded: date_helper
INFO - 2017-01-09 23:10:19 --> Helper loaded: url_helper
DEBUG - 2017-01-09 23:10:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 23:10:19 --> Helper loaded: form_helper
INFO - 2017-01-09 23:10:19 --> Form Validation Class Initialized
INFO - 2017-01-09 23:10:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-09 23:10:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-09 23:10:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-09 23:10:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-09 23:10:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-09 23:10:19 --> Final output sent to browser
DEBUG - 2017-01-09 23:10:19 --> Total execution time: 0.1313
INFO - 2017-01-09 23:10:19 --> Config Class Initialized
INFO - 2017-01-09 23:10:19 --> Hooks Class Initialized
DEBUG - 2017-01-09 23:10:19 --> UTF-8 Support Enabled
INFO - 2017-01-09 23:10:19 --> Utf8 Class Initialized
INFO - 2017-01-09 23:10:19 --> URI Class Initialized
INFO - 2017-01-09 23:10:19 --> Router Class Initialized
INFO - 2017-01-09 23:10:19 --> Output Class Initialized
INFO - 2017-01-09 23:10:19 --> Security Class Initialized
DEBUG - 2017-01-09 23:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 23:10:19 --> Input Class Initialized
INFO - 2017-01-09 23:10:19 --> Language Class Initialized
INFO - 2017-01-09 23:10:19 --> Loader Class Initialized
INFO - 2017-01-09 23:10:19 --> Database Driver Class Initialized
INFO - 2017-01-09 23:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 23:10:19 --> Controller Class Initialized
INFO - 2017-01-09 23:10:19 --> Helper loaded: date_helper
INFO - 2017-01-09 23:10:19 --> Helper loaded: url_helper
DEBUG - 2017-01-09 23:10:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 23:10:19 --> Helper loaded: form_helper
INFO - 2017-01-09 23:10:19 --> Form Validation Class Initialized
INFO - 2017-01-09 23:10:19 --> Final output sent to browser
DEBUG - 2017-01-09 23:10:19 --> Total execution time: 0.0146
INFO - 2017-01-09 23:10:19 --> Config Class Initialized
INFO - 2017-01-09 23:10:19 --> Hooks Class Initialized
DEBUG - 2017-01-09 23:10:19 --> UTF-8 Support Enabled
INFO - 2017-01-09 23:10:19 --> Utf8 Class Initialized
INFO - 2017-01-09 23:10:19 --> URI Class Initialized
INFO - 2017-01-09 23:10:19 --> Router Class Initialized
INFO - 2017-01-09 23:10:19 --> Output Class Initialized
INFO - 2017-01-09 23:10:19 --> Security Class Initialized
DEBUG - 2017-01-09 23:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 23:10:19 --> Input Class Initialized
INFO - 2017-01-09 23:10:19 --> Language Class Initialized
INFO - 2017-01-09 23:10:19 --> Loader Class Initialized
INFO - 2017-01-09 23:10:19 --> Database Driver Class Initialized
INFO - 2017-01-09 23:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 23:10:19 --> Controller Class Initialized
INFO - 2017-01-09 23:10:19 --> Helper loaded: url_helper
DEBUG - 2017-01-09 23:10:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 23:10:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 23:10:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 23:10:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 23:10:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 23:10:19 --> Final output sent to browser
DEBUG - 2017-01-09 23:10:19 --> Total execution time: 0.0131
INFO - 2017-01-09 23:10:47 --> Config Class Initialized
INFO - 2017-01-09 23:10:47 --> Hooks Class Initialized
DEBUG - 2017-01-09 23:10:47 --> UTF-8 Support Enabled
INFO - 2017-01-09 23:10:47 --> Utf8 Class Initialized
INFO - 2017-01-09 23:10:47 --> URI Class Initialized
INFO - 2017-01-09 23:10:47 --> Router Class Initialized
INFO - 2017-01-09 23:10:47 --> Output Class Initialized
INFO - 2017-01-09 23:10:47 --> Security Class Initialized
DEBUG - 2017-01-09 23:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 23:10:47 --> Input Class Initialized
INFO - 2017-01-09 23:10:47 --> Language Class Initialized
INFO - 2017-01-09 23:10:47 --> Loader Class Initialized
INFO - 2017-01-09 23:10:47 --> Database Driver Class Initialized
INFO - 2017-01-09 23:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 23:10:47 --> Controller Class Initialized
INFO - 2017-01-09 23:10:47 --> Helper loaded: url_helper
DEBUG - 2017-01-09 23:10:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 23:10:48 --> Config Class Initialized
INFO - 2017-01-09 23:10:48 --> Hooks Class Initialized
DEBUG - 2017-01-09 23:10:48 --> UTF-8 Support Enabled
INFO - 2017-01-09 23:10:48 --> Utf8 Class Initialized
INFO - 2017-01-09 23:10:48 --> URI Class Initialized
INFO - 2017-01-09 23:10:48 --> Router Class Initialized
INFO - 2017-01-09 23:10:48 --> Output Class Initialized
INFO - 2017-01-09 23:10:48 --> Security Class Initialized
DEBUG - 2017-01-09 23:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 23:10:48 --> Input Class Initialized
INFO - 2017-01-09 23:10:48 --> Language Class Initialized
INFO - 2017-01-09 23:10:48 --> Loader Class Initialized
INFO - 2017-01-09 23:10:48 --> Database Driver Class Initialized
INFO - 2017-01-09 23:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 23:10:48 --> Controller Class Initialized
INFO - 2017-01-09 23:10:48 --> Helper loaded: url_helper
DEBUG - 2017-01-09 23:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 23:10:48 --> Helper loaded: form_helper
INFO - 2017-01-09 23:10:48 --> Form Validation Class Initialized
INFO - 2017-01-09 23:10:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-09 23:10:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-09 23:10:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-09 23:10:48 --> Final output sent to browser
DEBUG - 2017-01-09 23:10:48 --> Total execution time: 0.0137
INFO - 2017-01-09 23:10:48 --> Config Class Initialized
INFO - 2017-01-09 23:10:48 --> Hooks Class Initialized
DEBUG - 2017-01-09 23:10:48 --> UTF-8 Support Enabled
INFO - 2017-01-09 23:10:48 --> Utf8 Class Initialized
INFO - 2017-01-09 23:10:48 --> URI Class Initialized
INFO - 2017-01-09 23:10:48 --> Router Class Initialized
INFO - 2017-01-09 23:10:48 --> Output Class Initialized
INFO - 2017-01-09 23:10:48 --> Security Class Initialized
DEBUG - 2017-01-09 23:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 23:10:48 --> Input Class Initialized
INFO - 2017-01-09 23:10:48 --> Language Class Initialized
INFO - 2017-01-09 23:10:48 --> Loader Class Initialized
INFO - 2017-01-09 23:10:48 --> Database Driver Class Initialized
INFO - 2017-01-09 23:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 23:10:48 --> Controller Class Initialized
INFO - 2017-01-09 23:10:48 --> Helper loaded: url_helper
DEBUG - 2017-01-09 23:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 23:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 23:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 23:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 23:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 23:10:48 --> Final output sent to browser
DEBUG - 2017-01-09 23:10:48 --> Total execution time: 0.0144
INFO - 2017-01-09 23:10:48 --> Config Class Initialized
INFO - 2017-01-09 23:10:48 --> Hooks Class Initialized
DEBUG - 2017-01-09 23:10:48 --> UTF-8 Support Enabled
INFO - 2017-01-09 23:10:48 --> Utf8 Class Initialized
INFO - 2017-01-09 23:10:48 --> URI Class Initialized
INFO - 2017-01-09 23:10:48 --> Router Class Initialized
INFO - 2017-01-09 23:10:48 --> Output Class Initialized
INFO - 2017-01-09 23:10:48 --> Security Class Initialized
DEBUG - 2017-01-09 23:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 23:10:48 --> Input Class Initialized
INFO - 2017-01-09 23:10:48 --> Language Class Initialized
INFO - 2017-01-09 23:10:48 --> Loader Class Initialized
INFO - 2017-01-09 23:10:48 --> Database Driver Class Initialized
INFO - 2017-01-09 23:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 23:10:48 --> Controller Class Initialized
INFO - 2017-01-09 23:10:48 --> Helper loaded: url_helper
DEBUG - 2017-01-09 23:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 23:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 23:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 23:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 23:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 23:10:48 --> Final output sent to browser
DEBUG - 2017-01-09 23:10:48 --> Total execution time: 0.0378
INFO - 2017-01-09 23:10:58 --> Config Class Initialized
INFO - 2017-01-09 23:10:58 --> Hooks Class Initialized
DEBUG - 2017-01-09 23:10:58 --> UTF-8 Support Enabled
INFO - 2017-01-09 23:10:58 --> Utf8 Class Initialized
INFO - 2017-01-09 23:10:58 --> URI Class Initialized
INFO - 2017-01-09 23:10:58 --> Router Class Initialized
INFO - 2017-01-09 23:10:58 --> Output Class Initialized
INFO - 2017-01-09 23:10:58 --> Security Class Initialized
DEBUG - 2017-01-09 23:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 23:10:58 --> Input Class Initialized
INFO - 2017-01-09 23:10:58 --> Language Class Initialized
INFO - 2017-01-09 23:10:58 --> Loader Class Initialized
INFO - 2017-01-09 23:10:58 --> Database Driver Class Initialized
INFO - 2017-01-09 23:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 23:10:58 --> Controller Class Initialized
INFO - 2017-01-09 23:10:58 --> Helper loaded: url_helper
DEBUG - 2017-01-09 23:10:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 23:10:58 --> Helper loaded: form_helper
INFO - 2017-01-09 23:10:58 --> Form Validation Class Initialized
INFO - 2017-01-09 23:10:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-09 23:10:59 --> Config Class Initialized
INFO - 2017-01-09 23:10:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 23:10:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 23:10:59 --> Utf8 Class Initialized
INFO - 2017-01-09 23:10:59 --> URI Class Initialized
INFO - 2017-01-09 23:10:59 --> Router Class Initialized
INFO - 2017-01-09 23:10:59 --> Output Class Initialized
INFO - 2017-01-09 23:10:59 --> Security Class Initialized
DEBUG - 2017-01-09 23:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 23:10:59 --> Input Class Initialized
INFO - 2017-01-09 23:10:59 --> Language Class Initialized
INFO - 2017-01-09 23:10:59 --> Loader Class Initialized
INFO - 2017-01-09 23:10:59 --> Database Driver Class Initialized
INFO - 2017-01-09 23:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 23:10:59 --> Controller Class Initialized
INFO - 2017-01-09 23:10:59 --> Helper loaded: date_helper
INFO - 2017-01-09 23:10:59 --> Helper loaded: url_helper
DEBUG - 2017-01-09 23:10:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 23:10:59 --> Helper loaded: form_helper
INFO - 2017-01-09 23:10:59 --> Form Validation Class Initialized
INFO - 2017-01-09 23:10:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-09 23:10:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-09 23:10:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-09 23:10:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-09 23:10:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-09 23:10:59 --> Final output sent to browser
DEBUG - 2017-01-09 23:10:59 --> Total execution time: 0.0431
INFO - 2017-01-09 23:10:59 --> Config Class Initialized
INFO - 2017-01-09 23:10:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 23:10:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 23:10:59 --> Utf8 Class Initialized
INFO - 2017-01-09 23:10:59 --> URI Class Initialized
INFO - 2017-01-09 23:10:59 --> Router Class Initialized
INFO - 2017-01-09 23:10:59 --> Output Class Initialized
INFO - 2017-01-09 23:10:59 --> Security Class Initialized
DEBUG - 2017-01-09 23:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 23:10:59 --> Input Class Initialized
INFO - 2017-01-09 23:10:59 --> Language Class Initialized
INFO - 2017-01-09 23:10:59 --> Loader Class Initialized
INFO - 2017-01-09 23:10:59 --> Database Driver Class Initialized
INFO - 2017-01-09 23:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 23:10:59 --> Controller Class Initialized
INFO - 2017-01-09 23:10:59 --> Helper loaded: date_helper
INFO - 2017-01-09 23:10:59 --> Helper loaded: url_helper
DEBUG - 2017-01-09 23:10:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 23:10:59 --> Helper loaded: form_helper
INFO - 2017-01-09 23:10:59 --> Form Validation Class Initialized
INFO - 2017-01-09 23:10:59 --> Final output sent to browser
DEBUG - 2017-01-09 23:10:59 --> Total execution time: 0.0143
INFO - 2017-01-09 23:10:59 --> Config Class Initialized
INFO - 2017-01-09 23:10:59 --> Hooks Class Initialized
DEBUG - 2017-01-09 23:10:59 --> UTF-8 Support Enabled
INFO - 2017-01-09 23:10:59 --> Utf8 Class Initialized
INFO - 2017-01-09 23:10:59 --> URI Class Initialized
INFO - 2017-01-09 23:10:59 --> Router Class Initialized
INFO - 2017-01-09 23:10:59 --> Output Class Initialized
INFO - 2017-01-09 23:10:59 --> Security Class Initialized
DEBUG - 2017-01-09 23:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 23:10:59 --> Input Class Initialized
INFO - 2017-01-09 23:10:59 --> Language Class Initialized
INFO - 2017-01-09 23:10:59 --> Loader Class Initialized
INFO - 2017-01-09 23:10:59 --> Database Driver Class Initialized
INFO - 2017-01-09 23:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 23:10:59 --> Controller Class Initialized
INFO - 2017-01-09 23:10:59 --> Helper loaded: url_helper
DEBUG - 2017-01-09 23:10:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 23:10:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 23:10:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 23:10:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 23:10:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 23:10:59 --> Final output sent to browser
DEBUG - 2017-01-09 23:10:59 --> Total execution time: 0.0589
INFO - 2017-01-09 23:12:19 --> Config Class Initialized
INFO - 2017-01-09 23:12:19 --> Hooks Class Initialized
DEBUG - 2017-01-09 23:12:19 --> UTF-8 Support Enabled
INFO - 2017-01-09 23:12:19 --> Utf8 Class Initialized
INFO - 2017-01-09 23:12:19 --> URI Class Initialized
INFO - 2017-01-09 23:12:19 --> Router Class Initialized
INFO - 2017-01-09 23:12:20 --> Output Class Initialized
INFO - 2017-01-09 23:12:20 --> Security Class Initialized
DEBUG - 2017-01-09 23:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 23:12:20 --> Input Class Initialized
INFO - 2017-01-09 23:12:20 --> Language Class Initialized
INFO - 2017-01-09 23:12:20 --> Loader Class Initialized
INFO - 2017-01-09 23:12:20 --> Database Driver Class Initialized
INFO - 2017-01-09 23:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 23:12:20 --> Controller Class Initialized
INFO - 2017-01-09 23:12:20 --> Helper loaded: url_helper
DEBUG - 2017-01-09 23:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 23:12:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 23:12:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 23:12:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 23:12:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 23:12:20 --> Final output sent to browser
DEBUG - 2017-01-09 23:12:20 --> Total execution time: 0.7545
INFO - 2017-01-09 23:12:20 --> Config Class Initialized
INFO - 2017-01-09 23:12:20 --> Hooks Class Initialized
DEBUG - 2017-01-09 23:12:20 --> UTF-8 Support Enabled
INFO - 2017-01-09 23:12:20 --> Utf8 Class Initialized
INFO - 2017-01-09 23:12:20 --> URI Class Initialized
DEBUG - 2017-01-09 23:12:20 --> No URI present. Default controller set.
INFO - 2017-01-09 23:12:20 --> Router Class Initialized
INFO - 2017-01-09 23:12:20 --> Output Class Initialized
INFO - 2017-01-09 23:12:20 --> Security Class Initialized
DEBUG - 2017-01-09 23:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-09 23:12:20 --> Input Class Initialized
INFO - 2017-01-09 23:12:20 --> Language Class Initialized
INFO - 2017-01-09 23:12:20 --> Loader Class Initialized
INFO - 2017-01-09 23:12:20 --> Database Driver Class Initialized
INFO - 2017-01-09 23:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-09 23:12:20 --> Controller Class Initialized
INFO - 2017-01-09 23:12:20 --> Helper loaded: url_helper
DEBUG - 2017-01-09 23:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-09 23:12:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-09 23:12:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-09 23:12:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-09 23:12:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-09 23:12:20 --> Final output sent to browser
DEBUG - 2017-01-09 23:12:20 --> Total execution time: 0.1347

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-16 00:16:02 --> Config Class Initialized
INFO - 2017-01-16 00:16:02 --> Hooks Class Initialized
DEBUG - 2017-01-16 00:16:02 --> UTF-8 Support Enabled
INFO - 2017-01-16 00:16:02 --> Utf8 Class Initialized
INFO - 2017-01-16 00:16:02 --> URI Class Initialized
INFO - 2017-01-16 00:16:02 --> Router Class Initialized
INFO - 2017-01-16 00:16:02 --> Output Class Initialized
INFO - 2017-01-16 00:16:02 --> Security Class Initialized
DEBUG - 2017-01-16 00:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 00:16:02 --> Input Class Initialized
INFO - 2017-01-16 00:16:02 --> Language Class Initialized
INFO - 2017-01-16 00:16:02 --> Loader Class Initialized
INFO - 2017-01-16 00:16:02 --> Database Driver Class Initialized
INFO - 2017-01-16 00:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 00:16:02 --> Controller Class Initialized
INFO - 2017-01-16 00:16:02 --> Helper loaded: date_helper
DEBUG - 2017-01-16 00:16:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 00:16:02 --> Helper loaded: url_helper
INFO - 2017-01-16 00:16:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 00:16:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-16 00:16:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-16 00:16:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-16 00:16:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 00:16:02 --> Final output sent to browser
DEBUG - 2017-01-16 00:16:02 --> Total execution time: 0.1705
INFO - 2017-01-16 00:16:10 --> Config Class Initialized
INFO - 2017-01-16 00:16:10 --> Hooks Class Initialized
DEBUG - 2017-01-16 00:16:10 --> UTF-8 Support Enabled
INFO - 2017-01-16 00:16:10 --> Utf8 Class Initialized
INFO - 2017-01-16 00:16:10 --> URI Class Initialized
INFO - 2017-01-16 00:16:10 --> Router Class Initialized
INFO - 2017-01-16 00:16:10 --> Output Class Initialized
INFO - 2017-01-16 00:16:10 --> Security Class Initialized
DEBUG - 2017-01-16 00:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 00:16:10 --> Input Class Initialized
INFO - 2017-01-16 00:16:10 --> Language Class Initialized
INFO - 2017-01-16 00:16:10 --> Loader Class Initialized
INFO - 2017-01-16 00:16:10 --> Database Driver Class Initialized
INFO - 2017-01-16 00:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 00:16:10 --> Controller Class Initialized
INFO - 2017-01-16 00:16:10 --> Helper loaded: url_helper
DEBUG - 2017-01-16 00:16:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 00:16:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 00:16:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 00:16:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 00:16:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 00:16:10 --> Final output sent to browser
DEBUG - 2017-01-16 00:16:10 --> Total execution time: 0.0135
INFO - 2017-01-16 00:40:21 --> Config Class Initialized
INFO - 2017-01-16 00:40:21 --> Hooks Class Initialized
DEBUG - 2017-01-16 00:40:21 --> UTF-8 Support Enabled
INFO - 2017-01-16 00:40:21 --> Utf8 Class Initialized
INFO - 2017-01-16 00:40:21 --> URI Class Initialized
INFO - 2017-01-16 00:40:21 --> Router Class Initialized
INFO - 2017-01-16 00:40:21 --> Output Class Initialized
INFO - 2017-01-16 00:40:21 --> Security Class Initialized
DEBUG - 2017-01-16 00:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 00:40:21 --> Input Class Initialized
INFO - 2017-01-16 00:40:21 --> Language Class Initialized
INFO - 2017-01-16 00:40:21 --> Loader Class Initialized
INFO - 2017-01-16 00:40:21 --> Database Driver Class Initialized
INFO - 2017-01-16 00:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 00:40:21 --> Controller Class Initialized
INFO - 2017-01-16 00:40:21 --> Helper loaded: url_helper
DEBUG - 2017-01-16 00:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 00:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 00:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 00:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 00:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 00:40:21 --> Final output sent to browser
DEBUG - 2017-01-16 00:40:21 --> Total execution time: 0.0135
INFO - 2017-01-16 11:38:19 --> Config Class Initialized
INFO - 2017-01-16 11:38:19 --> Hooks Class Initialized
DEBUG - 2017-01-16 11:38:19 --> UTF-8 Support Enabled
INFO - 2017-01-16 11:38:19 --> Utf8 Class Initialized
INFO - 2017-01-16 11:38:19 --> URI Class Initialized
INFO - 2017-01-16 11:38:19 --> Router Class Initialized
INFO - 2017-01-16 11:38:19 --> Output Class Initialized
INFO - 2017-01-16 11:38:19 --> Security Class Initialized
DEBUG - 2017-01-16 11:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 11:38:19 --> Input Class Initialized
INFO - 2017-01-16 11:38:19 --> Language Class Initialized
INFO - 2017-01-16 11:38:19 --> Loader Class Initialized
INFO - 2017-01-16 11:38:19 --> Database Driver Class Initialized
INFO - 2017-01-16 11:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 11:38:19 --> Controller Class Initialized
INFO - 2017-01-16 11:38:19 --> Helper loaded: url_helper
DEBUG - 2017-01-16 11:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 11:38:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 11:38:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 11:38:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 11:38:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 11:38:19 --> Final output sent to browser
DEBUG - 2017-01-16 11:38:19 --> Total execution time: 0.0136
INFO - 2017-01-16 11:38:19 --> Config Class Initialized
INFO - 2017-01-16 11:38:19 --> Hooks Class Initialized
DEBUG - 2017-01-16 11:38:19 --> UTF-8 Support Enabled
INFO - 2017-01-16 11:38:19 --> Utf8 Class Initialized
INFO - 2017-01-16 11:38:19 --> URI Class Initialized
DEBUG - 2017-01-16 11:38:19 --> No URI present. Default controller set.
INFO - 2017-01-16 11:38:19 --> Router Class Initialized
INFO - 2017-01-16 11:38:19 --> Output Class Initialized
INFO - 2017-01-16 11:38:19 --> Security Class Initialized
DEBUG - 2017-01-16 11:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 11:38:19 --> Input Class Initialized
INFO - 2017-01-16 11:38:19 --> Language Class Initialized
INFO - 2017-01-16 11:38:19 --> Loader Class Initialized
INFO - 2017-01-16 11:38:19 --> Database Driver Class Initialized
INFO - 2017-01-16 11:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 11:38:19 --> Controller Class Initialized
INFO - 2017-01-16 11:38:19 --> Helper loaded: url_helper
DEBUG - 2017-01-16 11:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 11:38:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 11:38:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 11:38:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 11:38:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 11:38:19 --> Final output sent to browser
DEBUG - 2017-01-16 11:38:19 --> Total execution time: 0.0134
INFO - 2017-01-16 11:38:22 --> Config Class Initialized
INFO - 2017-01-16 11:38:22 --> Hooks Class Initialized
DEBUG - 2017-01-16 11:38:22 --> UTF-8 Support Enabled
INFO - 2017-01-16 11:38:22 --> Utf8 Class Initialized
INFO - 2017-01-16 11:38:22 --> URI Class Initialized
INFO - 2017-01-16 11:38:22 --> Router Class Initialized
INFO - 2017-01-16 11:38:22 --> Output Class Initialized
INFO - 2017-01-16 11:38:22 --> Security Class Initialized
DEBUG - 2017-01-16 11:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 11:38:22 --> Input Class Initialized
INFO - 2017-01-16 11:38:22 --> Language Class Initialized
INFO - 2017-01-16 11:38:22 --> Loader Class Initialized
INFO - 2017-01-16 11:38:22 --> Database Driver Class Initialized
INFO - 2017-01-16 11:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 11:38:22 --> Controller Class Initialized
INFO - 2017-01-16 11:38:22 --> Helper loaded: url_helper
DEBUG - 2017-01-16 11:38:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 11:38:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 11:38:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 11:38:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 11:38:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 11:38:22 --> Final output sent to browser
DEBUG - 2017-01-16 11:38:22 --> Total execution time: 0.0137
INFO - 2017-01-16 12:59:15 --> Config Class Initialized
INFO - 2017-01-16 12:59:15 --> Hooks Class Initialized
DEBUG - 2017-01-16 12:59:15 --> UTF-8 Support Enabled
INFO - 2017-01-16 12:59:15 --> Utf8 Class Initialized
INFO - 2017-01-16 12:59:15 --> URI Class Initialized
DEBUG - 2017-01-16 12:59:15 --> No URI present. Default controller set.
INFO - 2017-01-16 12:59:15 --> Router Class Initialized
INFO - 2017-01-16 12:59:15 --> Output Class Initialized
INFO - 2017-01-16 12:59:15 --> Security Class Initialized
DEBUG - 2017-01-16 12:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 12:59:15 --> Input Class Initialized
INFO - 2017-01-16 12:59:15 --> Language Class Initialized
INFO - 2017-01-16 12:59:15 --> Loader Class Initialized
INFO - 2017-01-16 12:59:15 --> Database Driver Class Initialized
INFO - 2017-01-16 12:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 12:59:15 --> Controller Class Initialized
INFO - 2017-01-16 12:59:15 --> Helper loaded: url_helper
DEBUG - 2017-01-16 12:59:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 12:59:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 12:59:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 12:59:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 12:59:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 12:59:15 --> Final output sent to browser
DEBUG - 2017-01-16 12:59:15 --> Total execution time: 0.0133
INFO - 2017-01-16 14:18:50 --> Config Class Initialized
INFO - 2017-01-16 14:18:50 --> Hooks Class Initialized
DEBUG - 2017-01-16 14:18:50 --> UTF-8 Support Enabled
INFO - 2017-01-16 14:18:50 --> Utf8 Class Initialized
INFO - 2017-01-16 14:18:50 --> URI Class Initialized
DEBUG - 2017-01-16 14:18:50 --> No URI present. Default controller set.
INFO - 2017-01-16 14:18:50 --> Router Class Initialized
INFO - 2017-01-16 14:18:50 --> Output Class Initialized
INFO - 2017-01-16 14:18:50 --> Security Class Initialized
DEBUG - 2017-01-16 14:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 14:18:50 --> Input Class Initialized
INFO - 2017-01-16 14:18:50 --> Language Class Initialized
INFO - 2017-01-16 14:18:50 --> Loader Class Initialized
INFO - 2017-01-16 14:18:50 --> Database Driver Class Initialized
INFO - 2017-01-16 14:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 14:18:50 --> Controller Class Initialized
INFO - 2017-01-16 14:18:50 --> Helper loaded: url_helper
DEBUG - 2017-01-16 14:18:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 14:18:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 14:18:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 14:18:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 14:18:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 14:18:50 --> Final output sent to browser
DEBUG - 2017-01-16 14:18:50 --> Total execution time: 0.0647
INFO - 2017-01-16 14:19:03 --> Config Class Initialized
INFO - 2017-01-16 14:19:03 --> Hooks Class Initialized
DEBUG - 2017-01-16 14:19:03 --> UTF-8 Support Enabled
INFO - 2017-01-16 14:19:03 --> Utf8 Class Initialized
INFO - 2017-01-16 14:19:03 --> URI Class Initialized
INFO - 2017-01-16 14:19:03 --> Router Class Initialized
INFO - 2017-01-16 14:19:03 --> Output Class Initialized
INFO - 2017-01-16 14:19:03 --> Security Class Initialized
DEBUG - 2017-01-16 14:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 14:19:03 --> Input Class Initialized
INFO - 2017-01-16 14:19:03 --> Language Class Initialized
INFO - 2017-01-16 14:19:03 --> Loader Class Initialized
INFO - 2017-01-16 14:19:03 --> Database Driver Class Initialized
INFO - 2017-01-16 14:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 14:19:03 --> Controller Class Initialized
INFO - 2017-01-16 14:19:03 --> Helper loaded: url_helper
DEBUG - 2017-01-16 14:19:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 14:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 14:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 14:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 14:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 14:19:03 --> Final output sent to browser
DEBUG - 2017-01-16 14:19:03 --> Total execution time: 0.0145
INFO - 2017-01-16 15:33:10 --> Config Class Initialized
INFO - 2017-01-16 15:33:10 --> Hooks Class Initialized
DEBUG - 2017-01-16 15:33:10 --> UTF-8 Support Enabled
INFO - 2017-01-16 15:33:10 --> Utf8 Class Initialized
INFO - 2017-01-16 15:33:10 --> URI Class Initialized
DEBUG - 2017-01-16 15:33:10 --> No URI present. Default controller set.
INFO - 2017-01-16 15:33:10 --> Router Class Initialized
INFO - 2017-01-16 15:33:10 --> Output Class Initialized
INFO - 2017-01-16 15:33:10 --> Security Class Initialized
DEBUG - 2017-01-16 15:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 15:33:10 --> Input Class Initialized
INFO - 2017-01-16 15:33:10 --> Language Class Initialized
INFO - 2017-01-16 15:33:10 --> Loader Class Initialized
INFO - 2017-01-16 15:33:10 --> Database Driver Class Initialized
INFO - 2017-01-16 15:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 15:33:10 --> Controller Class Initialized
INFO - 2017-01-16 15:33:10 --> Helper loaded: url_helper
DEBUG - 2017-01-16 15:33:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 15:33:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 15:33:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 15:33:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 15:33:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 15:33:10 --> Final output sent to browser
DEBUG - 2017-01-16 15:33:10 --> Total execution time: 0.0141
INFO - 2017-01-16 15:33:19 --> Config Class Initialized
INFO - 2017-01-16 15:33:19 --> Hooks Class Initialized
DEBUG - 2017-01-16 15:33:19 --> UTF-8 Support Enabled
INFO - 2017-01-16 15:33:19 --> Utf8 Class Initialized
INFO - 2017-01-16 15:33:19 --> URI Class Initialized
INFO - 2017-01-16 15:33:19 --> Router Class Initialized
INFO - 2017-01-16 15:33:19 --> Output Class Initialized
INFO - 2017-01-16 15:33:19 --> Security Class Initialized
DEBUG - 2017-01-16 15:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 15:33:19 --> Input Class Initialized
INFO - 2017-01-16 15:33:19 --> Language Class Initialized
INFO - 2017-01-16 15:33:19 --> Loader Class Initialized
INFO - 2017-01-16 15:33:19 --> Database Driver Class Initialized
INFO - 2017-01-16 15:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 15:33:19 --> Controller Class Initialized
INFO - 2017-01-16 15:33:19 --> Helper loaded: url_helper
DEBUG - 2017-01-16 15:33:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 15:33:20 --> Config Class Initialized
INFO - 2017-01-16 15:33:20 --> Hooks Class Initialized
DEBUG - 2017-01-16 15:33:20 --> UTF-8 Support Enabled
INFO - 2017-01-16 15:33:20 --> Utf8 Class Initialized
INFO - 2017-01-16 15:33:20 --> URI Class Initialized
INFO - 2017-01-16 15:33:20 --> Router Class Initialized
INFO - 2017-01-16 15:33:20 --> Output Class Initialized
INFO - 2017-01-16 15:33:20 --> Security Class Initialized
DEBUG - 2017-01-16 15:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 15:33:20 --> Input Class Initialized
INFO - 2017-01-16 15:33:20 --> Language Class Initialized
INFO - 2017-01-16 15:33:20 --> Loader Class Initialized
INFO - 2017-01-16 15:33:20 --> Database Driver Class Initialized
INFO - 2017-01-16 15:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 15:33:20 --> Controller Class Initialized
INFO - 2017-01-16 15:33:20 --> Helper loaded: date_helper
DEBUG - 2017-01-16 15:33:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 15:33:20 --> Helper loaded: url_helper
INFO - 2017-01-16 15:33:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 15:33:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-16 15:33:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-16 15:33:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-16 15:33:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 15:33:20 --> Final output sent to browser
DEBUG - 2017-01-16 15:33:20 --> Total execution time: 0.0281
INFO - 2017-01-16 15:33:34 --> Config Class Initialized
INFO - 2017-01-16 15:33:34 --> Hooks Class Initialized
DEBUG - 2017-01-16 15:33:34 --> UTF-8 Support Enabled
INFO - 2017-01-16 15:33:34 --> Utf8 Class Initialized
INFO - 2017-01-16 15:33:34 --> URI Class Initialized
DEBUG - 2017-01-16 15:33:34 --> No URI present. Default controller set.
INFO - 2017-01-16 15:33:34 --> Router Class Initialized
INFO - 2017-01-16 15:33:34 --> Output Class Initialized
INFO - 2017-01-16 15:33:34 --> Security Class Initialized
DEBUG - 2017-01-16 15:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 15:33:34 --> Input Class Initialized
INFO - 2017-01-16 15:33:34 --> Language Class Initialized
INFO - 2017-01-16 15:33:34 --> Loader Class Initialized
INFO - 2017-01-16 15:33:34 --> Database Driver Class Initialized
INFO - 2017-01-16 15:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 15:33:34 --> Controller Class Initialized
INFO - 2017-01-16 15:33:34 --> Helper loaded: url_helper
DEBUG - 2017-01-16 15:33:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 15:33:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 15:33:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 15:33:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 15:33:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 15:33:34 --> Final output sent to browser
DEBUG - 2017-01-16 15:33:34 --> Total execution time: 0.0142
INFO - 2017-01-16 15:33:58 --> Config Class Initialized
INFO - 2017-01-16 15:33:58 --> Hooks Class Initialized
DEBUG - 2017-01-16 15:33:58 --> UTF-8 Support Enabled
INFO - 2017-01-16 15:33:58 --> Utf8 Class Initialized
INFO - 2017-01-16 15:33:58 --> URI Class Initialized
INFO - 2017-01-16 15:33:58 --> Router Class Initialized
INFO - 2017-01-16 15:33:58 --> Output Class Initialized
INFO - 2017-01-16 15:33:58 --> Security Class Initialized
DEBUG - 2017-01-16 15:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 15:33:58 --> Input Class Initialized
INFO - 2017-01-16 15:33:58 --> Language Class Initialized
INFO - 2017-01-16 15:33:58 --> Loader Class Initialized
INFO - 2017-01-16 15:33:58 --> Database Driver Class Initialized
INFO - 2017-01-16 15:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 15:33:58 --> Controller Class Initialized
INFO - 2017-01-16 15:33:58 --> Helper loaded: url_helper
DEBUG - 2017-01-16 15:33:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 15:33:58 --> Config Class Initialized
INFO - 2017-01-16 15:33:58 --> Hooks Class Initialized
DEBUG - 2017-01-16 15:33:58 --> UTF-8 Support Enabled
INFO - 2017-01-16 15:33:58 --> Utf8 Class Initialized
INFO - 2017-01-16 15:33:58 --> URI Class Initialized
INFO - 2017-01-16 15:33:58 --> Router Class Initialized
INFO - 2017-01-16 15:33:58 --> Output Class Initialized
INFO - 2017-01-16 15:33:58 --> Security Class Initialized
DEBUG - 2017-01-16 15:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 15:33:58 --> Input Class Initialized
INFO - 2017-01-16 15:33:58 --> Language Class Initialized
INFO - 2017-01-16 15:33:58 --> Loader Class Initialized
INFO - 2017-01-16 15:33:58 --> Database Driver Class Initialized
INFO - 2017-01-16 15:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 15:33:58 --> Controller Class Initialized
INFO - 2017-01-16 15:33:58 --> Helper loaded: date_helper
DEBUG - 2017-01-16 15:33:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 15:33:58 --> Helper loaded: url_helper
INFO - 2017-01-16 15:33:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 15:33:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-16 15:33:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-16 15:33:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-16 15:33:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 15:33:58 --> Final output sent to browser
DEBUG - 2017-01-16 15:33:58 --> Total execution time: 0.0530
INFO - 2017-01-16 15:34:03 --> Config Class Initialized
INFO - 2017-01-16 15:34:03 --> Hooks Class Initialized
DEBUG - 2017-01-16 15:34:03 --> UTF-8 Support Enabled
INFO - 2017-01-16 15:34:03 --> Utf8 Class Initialized
INFO - 2017-01-16 15:34:03 --> URI Class Initialized
INFO - 2017-01-16 15:34:03 --> Router Class Initialized
INFO - 2017-01-16 15:34:03 --> Output Class Initialized
INFO - 2017-01-16 15:34:03 --> Security Class Initialized
DEBUG - 2017-01-16 15:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 15:34:03 --> Input Class Initialized
INFO - 2017-01-16 15:34:03 --> Language Class Initialized
INFO - 2017-01-16 15:34:03 --> Loader Class Initialized
INFO - 2017-01-16 15:34:03 --> Database Driver Class Initialized
INFO - 2017-01-16 15:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 15:34:03 --> Controller Class Initialized
INFO - 2017-01-16 15:34:03 --> Helper loaded: date_helper
DEBUG - 2017-01-16 15:34:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 15:34:03 --> Helper loaded: url_helper
INFO - 2017-01-16 15:34:03 --> Helper loaded: download_helper
INFO - 2017-01-16 15:34:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 15:34:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-16 15:34:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-16 15:34:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-16 15:34:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 15:34:03 --> Final output sent to browser
DEBUG - 2017-01-16 15:34:03 --> Total execution time: 0.1197
INFO - 2017-01-16 15:34:09 --> Config Class Initialized
INFO - 2017-01-16 15:34:09 --> Hooks Class Initialized
DEBUG - 2017-01-16 15:34:09 --> UTF-8 Support Enabled
INFO - 2017-01-16 15:34:09 --> Utf8 Class Initialized
INFO - 2017-01-16 15:34:09 --> URI Class Initialized
INFO - 2017-01-16 15:34:09 --> Router Class Initialized
INFO - 2017-01-16 15:34:09 --> Output Class Initialized
INFO - 2017-01-16 15:34:09 --> Security Class Initialized
DEBUG - 2017-01-16 15:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 15:34:09 --> Input Class Initialized
INFO - 2017-01-16 15:34:09 --> Language Class Initialized
INFO - 2017-01-16 15:34:09 --> Loader Class Initialized
INFO - 2017-01-16 15:34:09 --> Database Driver Class Initialized
INFO - 2017-01-16 15:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 15:34:09 --> Controller Class Initialized
INFO - 2017-01-16 15:34:09 --> Helper loaded: date_helper
DEBUG - 2017-01-16 15:34:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 15:34:09 --> Helper loaded: url_helper
INFO - 2017-01-16 15:34:09 --> Helper loaded: download_helper
INFO - 2017-01-16 15:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 15:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-16 15:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-16 15:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-16 15:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 15:34:09 --> Final output sent to browser
DEBUG - 2017-01-16 15:34:09 --> Total execution time: 0.0238
INFO - 2017-01-16 15:34:15 --> Config Class Initialized
INFO - 2017-01-16 15:34:15 --> Hooks Class Initialized
DEBUG - 2017-01-16 15:34:15 --> UTF-8 Support Enabled
INFO - 2017-01-16 15:34:15 --> Utf8 Class Initialized
INFO - 2017-01-16 15:34:15 --> URI Class Initialized
INFO - 2017-01-16 15:34:15 --> Router Class Initialized
INFO - 2017-01-16 15:34:15 --> Output Class Initialized
INFO - 2017-01-16 15:34:15 --> Security Class Initialized
DEBUG - 2017-01-16 15:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 15:34:15 --> Input Class Initialized
INFO - 2017-01-16 15:34:15 --> Language Class Initialized
INFO - 2017-01-16 15:34:15 --> Loader Class Initialized
INFO - 2017-01-16 15:34:15 --> Database Driver Class Initialized
INFO - 2017-01-16 15:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 15:34:15 --> Controller Class Initialized
INFO - 2017-01-16 15:34:15 --> Helper loaded: date_helper
DEBUG - 2017-01-16 15:34:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 15:34:15 --> Helper loaded: url_helper
INFO - 2017-01-16 15:34:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 15:34:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-16 15:34:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-16 15:34:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-16 15:34:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 15:34:15 --> Final output sent to browser
DEBUG - 2017-01-16 15:34:15 --> Total execution time: 0.0145
INFO - 2017-01-16 15:34:21 --> Config Class Initialized
INFO - 2017-01-16 15:34:21 --> Hooks Class Initialized
DEBUG - 2017-01-16 15:34:21 --> UTF-8 Support Enabled
INFO - 2017-01-16 15:34:21 --> Utf8 Class Initialized
INFO - 2017-01-16 15:34:21 --> URI Class Initialized
INFO - 2017-01-16 15:34:21 --> Router Class Initialized
INFO - 2017-01-16 15:34:21 --> Output Class Initialized
INFO - 2017-01-16 15:34:21 --> Security Class Initialized
DEBUG - 2017-01-16 15:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 15:34:21 --> Input Class Initialized
INFO - 2017-01-16 15:34:21 --> Language Class Initialized
INFO - 2017-01-16 15:34:21 --> Loader Class Initialized
INFO - 2017-01-16 15:34:21 --> Database Driver Class Initialized
INFO - 2017-01-16 15:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 15:34:21 --> Controller Class Initialized
INFO - 2017-01-16 15:34:21 --> Helper loaded: url_helper
DEBUG - 2017-01-16 15:34:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 15:34:21 --> Config Class Initialized
INFO - 2017-01-16 15:34:21 --> Hooks Class Initialized
DEBUG - 2017-01-16 15:34:21 --> UTF-8 Support Enabled
INFO - 2017-01-16 15:34:21 --> Utf8 Class Initialized
INFO - 2017-01-16 15:34:21 --> URI Class Initialized
DEBUG - 2017-01-16 15:34:21 --> No URI present. Default controller set.
INFO - 2017-01-16 15:34:21 --> Router Class Initialized
INFO - 2017-01-16 15:34:21 --> Output Class Initialized
INFO - 2017-01-16 15:34:21 --> Security Class Initialized
DEBUG - 2017-01-16 15:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 15:34:21 --> Input Class Initialized
INFO - 2017-01-16 15:34:21 --> Language Class Initialized
INFO - 2017-01-16 15:34:21 --> Loader Class Initialized
INFO - 2017-01-16 15:34:21 --> Database Driver Class Initialized
INFO - 2017-01-16 15:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 15:34:21 --> Controller Class Initialized
INFO - 2017-01-16 15:34:21 --> Helper loaded: url_helper
DEBUG - 2017-01-16 15:34:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 15:34:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 15:34:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 15:34:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 15:34:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 15:34:21 --> Final output sent to browser
DEBUG - 2017-01-16 15:34:21 --> Total execution time: 0.0140
INFO - 2017-01-16 16:17:47 --> Config Class Initialized
INFO - 2017-01-16 16:17:47 --> Hooks Class Initialized
DEBUG - 2017-01-16 16:17:47 --> UTF-8 Support Enabled
INFO - 2017-01-16 16:17:47 --> Utf8 Class Initialized
INFO - 2017-01-16 16:17:47 --> URI Class Initialized
INFO - 2017-01-16 16:17:47 --> Router Class Initialized
INFO - 2017-01-16 16:17:47 --> Output Class Initialized
INFO - 2017-01-16 16:17:47 --> Security Class Initialized
DEBUG - 2017-01-16 16:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 16:17:47 --> Input Class Initialized
INFO - 2017-01-16 16:17:47 --> Language Class Initialized
ERROR - 2017-01-16 16:17:47 --> 404 Page Not Found: Phone/paquetes.html
INFO - 2017-01-16 16:18:25 --> Config Class Initialized
INFO - 2017-01-16 16:18:25 --> Hooks Class Initialized
DEBUG - 2017-01-16 16:18:25 --> UTF-8 Support Enabled
INFO - 2017-01-16 16:18:25 --> Utf8 Class Initialized
INFO - 2017-01-16 16:18:25 --> URI Class Initialized
DEBUG - 2017-01-16 16:18:25 --> No URI present. Default controller set.
INFO - 2017-01-16 16:18:25 --> Router Class Initialized
INFO - 2017-01-16 16:18:25 --> Output Class Initialized
INFO - 2017-01-16 16:18:25 --> Security Class Initialized
DEBUG - 2017-01-16 16:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 16:18:25 --> Input Class Initialized
INFO - 2017-01-16 16:18:25 --> Language Class Initialized
INFO - 2017-01-16 16:18:25 --> Loader Class Initialized
INFO - 2017-01-16 16:18:25 --> Database Driver Class Initialized
INFO - 2017-01-16 16:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 16:18:25 --> Controller Class Initialized
INFO - 2017-01-16 16:18:25 --> Helper loaded: url_helper
DEBUG - 2017-01-16 16:18:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 16:18:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 16:18:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 16:18:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 16:18:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 16:18:25 --> Final output sent to browser
DEBUG - 2017-01-16 16:18:25 --> Total execution time: 0.0144
INFO - 2017-01-16 16:32:17 --> Config Class Initialized
INFO - 2017-01-16 16:32:17 --> Hooks Class Initialized
DEBUG - 2017-01-16 16:32:17 --> UTF-8 Support Enabled
INFO - 2017-01-16 16:32:17 --> Utf8 Class Initialized
INFO - 2017-01-16 16:32:17 --> URI Class Initialized
DEBUG - 2017-01-16 16:32:17 --> No URI present. Default controller set.
INFO - 2017-01-16 16:32:17 --> Router Class Initialized
INFO - 2017-01-16 16:32:17 --> Output Class Initialized
INFO - 2017-01-16 16:32:17 --> Security Class Initialized
DEBUG - 2017-01-16 16:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 16:32:17 --> Input Class Initialized
INFO - 2017-01-16 16:32:17 --> Language Class Initialized
INFO - 2017-01-16 16:32:17 --> Loader Class Initialized
INFO - 2017-01-16 16:32:17 --> Database Driver Class Initialized
INFO - 2017-01-16 16:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 16:32:17 --> Controller Class Initialized
INFO - 2017-01-16 16:32:17 --> Helper loaded: url_helper
DEBUG - 2017-01-16 16:32:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 16:32:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 16:32:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 16:32:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 16:32:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 16:32:17 --> Final output sent to browser
DEBUG - 2017-01-16 16:32:17 --> Total execution time: 0.0142
INFO - 2017-01-16 16:33:01 --> Config Class Initialized
INFO - 2017-01-16 16:33:01 --> Hooks Class Initialized
DEBUG - 2017-01-16 16:33:01 --> UTF-8 Support Enabled
INFO - 2017-01-16 16:33:01 --> Utf8 Class Initialized
INFO - 2017-01-16 16:33:01 --> URI Class Initialized
INFO - 2017-01-16 16:33:01 --> Router Class Initialized
INFO - 2017-01-16 16:33:01 --> Output Class Initialized
INFO - 2017-01-16 16:33:01 --> Security Class Initialized
DEBUG - 2017-01-16 16:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 16:33:01 --> Input Class Initialized
INFO - 2017-01-16 16:33:01 --> Language Class Initialized
INFO - 2017-01-16 16:33:01 --> Loader Class Initialized
INFO - 2017-01-16 16:33:01 --> Database Driver Class Initialized
INFO - 2017-01-16 16:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 16:33:01 --> Controller Class Initialized
INFO - 2017-01-16 16:33:01 --> Helper loaded: url_helper
DEBUG - 2017-01-16 16:33:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 16:33:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-16 16:33:01 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-16 16:33:01 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-16 16:33:01 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-16 16:33:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 16:33:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 16:33:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 16:33:01 --> Final output sent to browser
DEBUG - 2017-01-16 16:33:01 --> Total execution time: 0.2668
INFO - 2017-01-16 16:33:22 --> Config Class Initialized
INFO - 2017-01-16 16:33:22 --> Hooks Class Initialized
DEBUG - 2017-01-16 16:33:22 --> UTF-8 Support Enabled
INFO - 2017-01-16 16:33:22 --> Utf8 Class Initialized
INFO - 2017-01-16 16:33:22 --> URI Class Initialized
INFO - 2017-01-16 16:33:22 --> Router Class Initialized
INFO - 2017-01-16 16:33:22 --> Output Class Initialized
INFO - 2017-01-16 16:33:22 --> Security Class Initialized
DEBUG - 2017-01-16 16:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 16:33:22 --> Input Class Initialized
INFO - 2017-01-16 16:33:22 --> Language Class Initialized
INFO - 2017-01-16 16:33:22 --> Loader Class Initialized
INFO - 2017-01-16 16:33:22 --> Database Driver Class Initialized
INFO - 2017-01-16 16:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 16:33:22 --> Controller Class Initialized
INFO - 2017-01-16 16:33:22 --> Helper loaded: url_helper
DEBUG - 2017-01-16 16:33:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 16:33:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 16:33:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 16:33:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 16:33:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 16:33:22 --> Final output sent to browser
DEBUG - 2017-01-16 16:33:22 --> Total execution time: 0.0140
INFO - 2017-01-16 16:43:14 --> Config Class Initialized
INFO - 2017-01-16 16:43:14 --> Hooks Class Initialized
DEBUG - 2017-01-16 16:43:14 --> UTF-8 Support Enabled
INFO - 2017-01-16 16:43:14 --> Utf8 Class Initialized
INFO - 2017-01-16 16:43:14 --> URI Class Initialized
DEBUG - 2017-01-16 16:43:14 --> No URI present. Default controller set.
INFO - 2017-01-16 16:43:14 --> Router Class Initialized
INFO - 2017-01-16 16:43:14 --> Output Class Initialized
INFO - 2017-01-16 16:43:14 --> Security Class Initialized
DEBUG - 2017-01-16 16:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 16:43:14 --> Input Class Initialized
INFO - 2017-01-16 16:43:14 --> Language Class Initialized
INFO - 2017-01-16 16:43:14 --> Loader Class Initialized
INFO - 2017-01-16 16:43:14 --> Database Driver Class Initialized
INFO - 2017-01-16 16:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 16:43:14 --> Controller Class Initialized
INFO - 2017-01-16 16:43:14 --> Helper loaded: url_helper
DEBUG - 2017-01-16 16:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 16:43:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 16:43:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 16:43:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 16:43:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 16:43:14 --> Final output sent to browser
DEBUG - 2017-01-16 16:43:14 --> Total execution time: 0.0137
INFO - 2017-01-16 16:44:58 --> Config Class Initialized
INFO - 2017-01-16 16:44:58 --> Hooks Class Initialized
DEBUG - 2017-01-16 16:44:58 --> UTF-8 Support Enabled
INFO - 2017-01-16 16:44:58 --> Utf8 Class Initialized
INFO - 2017-01-16 16:44:58 --> URI Class Initialized
DEBUG - 2017-01-16 16:44:58 --> No URI present. Default controller set.
INFO - 2017-01-16 16:44:58 --> Router Class Initialized
INFO - 2017-01-16 16:44:58 --> Output Class Initialized
INFO - 2017-01-16 16:44:58 --> Security Class Initialized
DEBUG - 2017-01-16 16:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 16:44:58 --> Input Class Initialized
INFO - 2017-01-16 16:44:58 --> Language Class Initialized
INFO - 2017-01-16 16:44:58 --> Loader Class Initialized
INFO - 2017-01-16 16:44:58 --> Database Driver Class Initialized
INFO - 2017-01-16 16:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 16:44:58 --> Controller Class Initialized
INFO - 2017-01-16 16:44:58 --> Helper loaded: url_helper
DEBUG - 2017-01-16 16:44:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 16:44:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 16:44:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 16:44:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 16:44:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 16:44:58 --> Final output sent to browser
DEBUG - 2017-01-16 16:44:58 --> Total execution time: 0.0135
INFO - 2017-01-16 16:45:12 --> Config Class Initialized
INFO - 2017-01-16 16:45:12 --> Hooks Class Initialized
DEBUG - 2017-01-16 16:45:12 --> UTF-8 Support Enabled
INFO - 2017-01-16 16:45:12 --> Utf8 Class Initialized
INFO - 2017-01-16 16:45:12 --> URI Class Initialized
DEBUG - 2017-01-16 16:45:12 --> No URI present. Default controller set.
INFO - 2017-01-16 16:45:12 --> Router Class Initialized
INFO - 2017-01-16 16:45:12 --> Output Class Initialized
INFO - 2017-01-16 16:45:12 --> Security Class Initialized
DEBUG - 2017-01-16 16:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 16:45:12 --> Input Class Initialized
INFO - 2017-01-16 16:45:12 --> Language Class Initialized
INFO - 2017-01-16 16:45:12 --> Loader Class Initialized
INFO - 2017-01-16 16:45:12 --> Database Driver Class Initialized
INFO - 2017-01-16 16:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 16:45:12 --> Controller Class Initialized
INFO - 2017-01-16 16:45:12 --> Helper loaded: url_helper
DEBUG - 2017-01-16 16:45:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 16:45:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 16:45:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 16:45:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 16:45:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 16:45:12 --> Final output sent to browser
DEBUG - 2017-01-16 16:45:12 --> Total execution time: 0.0141
INFO - 2017-01-16 18:12:32 --> Config Class Initialized
INFO - 2017-01-16 18:12:32 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:12:32 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:12:32 --> Utf8 Class Initialized
INFO - 2017-01-16 18:12:32 --> URI Class Initialized
DEBUG - 2017-01-16 18:12:32 --> No URI present. Default controller set.
INFO - 2017-01-16 18:12:32 --> Router Class Initialized
INFO - 2017-01-16 18:12:32 --> Output Class Initialized
INFO - 2017-01-16 18:12:32 --> Security Class Initialized
DEBUG - 2017-01-16 18:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:12:32 --> Input Class Initialized
INFO - 2017-01-16 18:12:32 --> Language Class Initialized
INFO - 2017-01-16 18:12:32 --> Loader Class Initialized
INFO - 2017-01-16 18:12:32 --> Database Driver Class Initialized
INFO - 2017-01-16 18:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:12:32 --> Controller Class Initialized
INFO - 2017-01-16 18:12:32 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:12:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 18:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 18:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:12:32 --> Final output sent to browser
DEBUG - 2017-01-16 18:12:32 --> Total execution time: 0.0147
INFO - 2017-01-16 18:12:39 --> Config Class Initialized
INFO - 2017-01-16 18:12:39 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:12:39 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:12:39 --> Utf8 Class Initialized
INFO - 2017-01-16 18:12:39 --> URI Class Initialized
INFO - 2017-01-16 18:12:39 --> Router Class Initialized
INFO - 2017-01-16 18:12:39 --> Output Class Initialized
INFO - 2017-01-16 18:12:39 --> Security Class Initialized
DEBUG - 2017-01-16 18:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:12:39 --> Input Class Initialized
INFO - 2017-01-16 18:12:39 --> Language Class Initialized
INFO - 2017-01-16 18:12:39 --> Loader Class Initialized
INFO - 2017-01-16 18:12:39 --> Database Driver Class Initialized
INFO - 2017-01-16 18:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:12:39 --> Controller Class Initialized
INFO - 2017-01-16 18:12:39 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:12:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:12:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:12:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 18:12:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 18:12:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:12:39 --> Final output sent to browser
DEBUG - 2017-01-16 18:12:39 --> Total execution time: 0.0144
INFO - 2017-01-16 18:13:28 --> Config Class Initialized
INFO - 2017-01-16 18:13:28 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:13:28 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:13:28 --> Utf8 Class Initialized
INFO - 2017-01-16 18:13:28 --> URI Class Initialized
INFO - 2017-01-16 18:13:28 --> Router Class Initialized
INFO - 2017-01-16 18:13:28 --> Output Class Initialized
INFO - 2017-01-16 18:13:28 --> Security Class Initialized
DEBUG - 2017-01-16 18:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:13:28 --> Input Class Initialized
INFO - 2017-01-16 18:13:28 --> Language Class Initialized
INFO - 2017-01-16 18:13:28 --> Loader Class Initialized
INFO - 2017-01-16 18:13:28 --> Database Driver Class Initialized
INFO - 2017-01-16 18:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:13:28 --> Controller Class Initialized
INFO - 2017-01-16 18:13:28 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:13:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:13:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-16 18:13:28 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-16 18:13:28 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-16 18:13:28 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-16 18:13:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 18:13:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 18:13:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:13:28 --> Final output sent to browser
DEBUG - 2017-01-16 18:13:28 --> Total execution time: 0.0283
INFO - 2017-01-16 18:13:29 --> Config Class Initialized
INFO - 2017-01-16 18:13:29 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:13:29 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:13:29 --> Utf8 Class Initialized
INFO - 2017-01-16 18:13:29 --> URI Class Initialized
INFO - 2017-01-16 18:13:29 --> Router Class Initialized
INFO - 2017-01-16 18:13:29 --> Output Class Initialized
INFO - 2017-01-16 18:13:29 --> Security Class Initialized
DEBUG - 2017-01-16 18:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:13:29 --> Input Class Initialized
INFO - 2017-01-16 18:13:29 --> Language Class Initialized
INFO - 2017-01-16 18:13:29 --> Loader Class Initialized
INFO - 2017-01-16 18:13:29 --> Database Driver Class Initialized
INFO - 2017-01-16 18:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:13:29 --> Controller Class Initialized
INFO - 2017-01-16 18:13:29 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:13:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:13:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:13:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 18:13:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 18:13:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:13:29 --> Final output sent to browser
DEBUG - 2017-01-16 18:13:29 --> Total execution time: 0.0135
INFO - 2017-01-16 18:17:07 --> Config Class Initialized
INFO - 2017-01-16 18:17:07 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:17:07 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:17:07 --> Utf8 Class Initialized
INFO - 2017-01-16 18:17:07 --> URI Class Initialized
DEBUG - 2017-01-16 18:17:07 --> No URI present. Default controller set.
INFO - 2017-01-16 18:17:07 --> Router Class Initialized
INFO - 2017-01-16 18:17:07 --> Output Class Initialized
INFO - 2017-01-16 18:17:07 --> Security Class Initialized
DEBUG - 2017-01-16 18:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:17:07 --> Input Class Initialized
INFO - 2017-01-16 18:17:07 --> Language Class Initialized
INFO - 2017-01-16 18:17:07 --> Loader Class Initialized
INFO - 2017-01-16 18:17:07 --> Database Driver Class Initialized
INFO - 2017-01-16 18:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:17:07 --> Controller Class Initialized
INFO - 2017-01-16 18:17:07 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:17:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:17:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:17:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 18:17:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 18:17:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:17:07 --> Final output sent to browser
DEBUG - 2017-01-16 18:17:07 --> Total execution time: 0.0140
INFO - 2017-01-16 18:17:11 --> Config Class Initialized
INFO - 2017-01-16 18:17:11 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:17:11 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:17:11 --> Utf8 Class Initialized
INFO - 2017-01-16 18:17:11 --> URI Class Initialized
INFO - 2017-01-16 18:17:11 --> Router Class Initialized
INFO - 2017-01-16 18:17:11 --> Output Class Initialized
INFO - 2017-01-16 18:17:11 --> Security Class Initialized
DEBUG - 2017-01-16 18:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:17:11 --> Input Class Initialized
INFO - 2017-01-16 18:17:11 --> Language Class Initialized
INFO - 2017-01-16 18:17:11 --> Loader Class Initialized
INFO - 2017-01-16 18:17:11 --> Database Driver Class Initialized
INFO - 2017-01-16 18:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:17:11 --> Controller Class Initialized
INFO - 2017-01-16 18:17:11 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:17:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:17:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:17:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 18:17:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 18:17:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:17:11 --> Final output sent to browser
DEBUG - 2017-01-16 18:17:11 --> Total execution time: 0.0191
INFO - 2017-01-16 18:18:22 --> Config Class Initialized
INFO - 2017-01-16 18:18:22 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:18:22 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:18:22 --> Utf8 Class Initialized
INFO - 2017-01-16 18:18:22 --> URI Class Initialized
INFO - 2017-01-16 18:18:22 --> Router Class Initialized
INFO - 2017-01-16 18:18:22 --> Output Class Initialized
INFO - 2017-01-16 18:18:22 --> Security Class Initialized
DEBUG - 2017-01-16 18:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:18:22 --> Input Class Initialized
INFO - 2017-01-16 18:18:22 --> Language Class Initialized
INFO - 2017-01-16 18:18:22 --> Loader Class Initialized
INFO - 2017-01-16 18:18:22 --> Database Driver Class Initialized
INFO - 2017-01-16 18:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:18:22 --> Controller Class Initialized
INFO - 2017-01-16 18:18:22 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:18:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:18:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-16 18:18:22 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-16 18:18:22 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-16 18:18:22 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-16 18:18:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 18:18:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 18:18:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:18:22 --> Final output sent to browser
DEBUG - 2017-01-16 18:18:22 --> Total execution time: 0.0150
INFO - 2017-01-16 18:18:25 --> Config Class Initialized
INFO - 2017-01-16 18:18:25 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:18:25 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:18:25 --> Utf8 Class Initialized
INFO - 2017-01-16 18:18:25 --> URI Class Initialized
INFO - 2017-01-16 18:18:25 --> Router Class Initialized
INFO - 2017-01-16 18:18:25 --> Output Class Initialized
INFO - 2017-01-16 18:18:25 --> Security Class Initialized
DEBUG - 2017-01-16 18:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:18:25 --> Input Class Initialized
INFO - 2017-01-16 18:18:25 --> Language Class Initialized
INFO - 2017-01-16 18:18:25 --> Loader Class Initialized
INFO - 2017-01-16 18:18:25 --> Database Driver Class Initialized
INFO - 2017-01-16 18:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:18:25 --> Controller Class Initialized
INFO - 2017-01-16 18:18:25 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:18:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:18:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:18:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 18:18:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 18:18:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:18:25 --> Final output sent to browser
DEBUG - 2017-01-16 18:18:25 --> Total execution time: 0.0145
INFO - 2017-01-16 18:18:34 --> Config Class Initialized
INFO - 2017-01-16 18:18:34 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:18:34 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:18:34 --> Utf8 Class Initialized
INFO - 2017-01-16 18:18:34 --> URI Class Initialized
INFO - 2017-01-16 18:18:34 --> Router Class Initialized
INFO - 2017-01-16 18:18:34 --> Output Class Initialized
INFO - 2017-01-16 18:18:34 --> Security Class Initialized
DEBUG - 2017-01-16 18:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:18:34 --> Input Class Initialized
INFO - 2017-01-16 18:18:34 --> Language Class Initialized
INFO - 2017-01-16 18:18:34 --> Loader Class Initialized
INFO - 2017-01-16 18:18:34 --> Database Driver Class Initialized
INFO - 2017-01-16 18:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:18:34 --> Controller Class Initialized
INFO - 2017-01-16 18:18:34 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:18:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:18:35 --> Config Class Initialized
INFO - 2017-01-16 18:18:35 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:18:35 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:18:35 --> Utf8 Class Initialized
INFO - 2017-01-16 18:18:35 --> URI Class Initialized
INFO - 2017-01-16 18:18:35 --> Router Class Initialized
INFO - 2017-01-16 18:18:35 --> Output Class Initialized
INFO - 2017-01-16 18:18:35 --> Security Class Initialized
DEBUG - 2017-01-16 18:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:18:35 --> Input Class Initialized
INFO - 2017-01-16 18:18:35 --> Language Class Initialized
INFO - 2017-01-16 18:18:35 --> Loader Class Initialized
INFO - 2017-01-16 18:18:35 --> Database Driver Class Initialized
INFO - 2017-01-16 18:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:18:35 --> Controller Class Initialized
INFO - 2017-01-16 18:18:35 --> Helper loaded: date_helper
DEBUG - 2017-01-16 18:18:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:18:35 --> Helper loaded: url_helper
INFO - 2017-01-16 18:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-16 18:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-16 18:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-16 18:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:18:35 --> Final output sent to browser
DEBUG - 2017-01-16 18:18:35 --> Total execution time: 0.0274
INFO - 2017-01-16 18:18:38 --> Config Class Initialized
INFO - 2017-01-16 18:18:38 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:18:38 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:18:38 --> Utf8 Class Initialized
INFO - 2017-01-16 18:18:38 --> URI Class Initialized
INFO - 2017-01-16 18:18:38 --> Router Class Initialized
INFO - 2017-01-16 18:18:38 --> Output Class Initialized
INFO - 2017-01-16 18:18:38 --> Security Class Initialized
DEBUG - 2017-01-16 18:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:18:38 --> Input Class Initialized
INFO - 2017-01-16 18:18:38 --> Language Class Initialized
INFO - 2017-01-16 18:18:38 --> Loader Class Initialized
INFO - 2017-01-16 18:18:38 --> Database Driver Class Initialized
INFO - 2017-01-16 18:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:18:38 --> Controller Class Initialized
INFO - 2017-01-16 18:18:38 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 18:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 18:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:18:38 --> Final output sent to browser
DEBUG - 2017-01-16 18:18:38 --> Total execution time: 0.0140
INFO - 2017-01-16 18:18:42 --> Config Class Initialized
INFO - 2017-01-16 18:18:42 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:18:42 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:18:42 --> Utf8 Class Initialized
INFO - 2017-01-16 18:18:42 --> URI Class Initialized
INFO - 2017-01-16 18:18:42 --> Router Class Initialized
INFO - 2017-01-16 18:18:42 --> Output Class Initialized
INFO - 2017-01-16 18:18:42 --> Security Class Initialized
DEBUG - 2017-01-16 18:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:18:42 --> Input Class Initialized
INFO - 2017-01-16 18:18:42 --> Language Class Initialized
INFO - 2017-01-16 18:18:42 --> Loader Class Initialized
INFO - 2017-01-16 18:18:42 --> Database Driver Class Initialized
INFO - 2017-01-16 18:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:18:42 --> Controller Class Initialized
INFO - 2017-01-16 18:18:42 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:18:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:18:43 --> Config Class Initialized
INFO - 2017-01-16 18:18:43 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:18:43 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:18:43 --> Utf8 Class Initialized
INFO - 2017-01-16 18:18:43 --> URI Class Initialized
INFO - 2017-01-16 18:18:43 --> Router Class Initialized
INFO - 2017-01-16 18:18:43 --> Output Class Initialized
INFO - 2017-01-16 18:18:43 --> Security Class Initialized
DEBUG - 2017-01-16 18:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:18:43 --> Input Class Initialized
INFO - 2017-01-16 18:18:43 --> Language Class Initialized
INFO - 2017-01-16 18:18:43 --> Loader Class Initialized
INFO - 2017-01-16 18:18:43 --> Database Driver Class Initialized
INFO - 2017-01-16 18:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:18:43 --> Controller Class Initialized
INFO - 2017-01-16 18:18:43 --> Helper loaded: date_helper
DEBUG - 2017-01-16 18:18:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:18:43 --> Helper loaded: url_helper
INFO - 2017-01-16 18:18:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:18:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-16 18:18:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-16 18:18:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-16 18:18:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:18:43 --> Final output sent to browser
DEBUG - 2017-01-16 18:18:43 --> Total execution time: 0.0135
INFO - 2017-01-16 18:18:44 --> Config Class Initialized
INFO - 2017-01-16 18:18:44 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:18:44 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:18:44 --> Utf8 Class Initialized
INFO - 2017-01-16 18:18:44 --> URI Class Initialized
INFO - 2017-01-16 18:18:44 --> Router Class Initialized
INFO - 2017-01-16 18:18:44 --> Output Class Initialized
INFO - 2017-01-16 18:18:44 --> Security Class Initialized
DEBUG - 2017-01-16 18:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:18:44 --> Input Class Initialized
INFO - 2017-01-16 18:18:44 --> Language Class Initialized
INFO - 2017-01-16 18:18:44 --> Loader Class Initialized
INFO - 2017-01-16 18:18:44 --> Database Driver Class Initialized
INFO - 2017-01-16 18:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:18:44 --> Controller Class Initialized
INFO - 2017-01-16 18:18:44 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:18:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 18:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 18:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:18:44 --> Final output sent to browser
DEBUG - 2017-01-16 18:18:44 --> Total execution time: 0.0147
INFO - 2017-01-16 18:18:48 --> Config Class Initialized
INFO - 2017-01-16 18:18:48 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:18:48 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:18:48 --> Utf8 Class Initialized
INFO - 2017-01-16 18:18:48 --> URI Class Initialized
INFO - 2017-01-16 18:18:48 --> Router Class Initialized
INFO - 2017-01-16 18:18:48 --> Output Class Initialized
INFO - 2017-01-16 18:18:48 --> Security Class Initialized
DEBUG - 2017-01-16 18:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:18:48 --> Input Class Initialized
INFO - 2017-01-16 18:18:48 --> Language Class Initialized
INFO - 2017-01-16 18:18:48 --> Loader Class Initialized
INFO - 2017-01-16 18:18:48 --> Database Driver Class Initialized
INFO - 2017-01-16 18:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:18:48 --> Controller Class Initialized
INFO - 2017-01-16 18:18:48 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:18:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:18:49 --> Config Class Initialized
INFO - 2017-01-16 18:18:49 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:18:49 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:18:49 --> Utf8 Class Initialized
INFO - 2017-01-16 18:18:49 --> URI Class Initialized
INFO - 2017-01-16 18:18:49 --> Router Class Initialized
INFO - 2017-01-16 18:18:49 --> Output Class Initialized
INFO - 2017-01-16 18:18:49 --> Security Class Initialized
DEBUG - 2017-01-16 18:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:18:49 --> Input Class Initialized
INFO - 2017-01-16 18:18:49 --> Language Class Initialized
INFO - 2017-01-16 18:18:49 --> Loader Class Initialized
INFO - 2017-01-16 18:18:49 --> Database Driver Class Initialized
INFO - 2017-01-16 18:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:18:49 --> Controller Class Initialized
INFO - 2017-01-16 18:18:49 --> Helper loaded: date_helper
DEBUG - 2017-01-16 18:18:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:18:49 --> Helper loaded: url_helper
INFO - 2017-01-16 18:18:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:18:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-16 18:18:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-16 18:18:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-16 18:18:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:18:49 --> Final output sent to browser
DEBUG - 2017-01-16 18:18:49 --> Total execution time: 0.0224
INFO - 2017-01-16 18:18:50 --> Config Class Initialized
INFO - 2017-01-16 18:18:50 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:18:50 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:18:50 --> Utf8 Class Initialized
INFO - 2017-01-16 18:18:50 --> URI Class Initialized
INFO - 2017-01-16 18:18:50 --> Router Class Initialized
INFO - 2017-01-16 18:18:50 --> Output Class Initialized
INFO - 2017-01-16 18:18:50 --> Security Class Initialized
DEBUG - 2017-01-16 18:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:18:50 --> Input Class Initialized
INFO - 2017-01-16 18:18:50 --> Language Class Initialized
INFO - 2017-01-16 18:18:50 --> Loader Class Initialized
INFO - 2017-01-16 18:18:50 --> Database Driver Class Initialized
INFO - 2017-01-16 18:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:18:50 --> Controller Class Initialized
INFO - 2017-01-16 18:18:50 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:18:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:18:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:18:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 18:18:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 18:18:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:18:50 --> Final output sent to browser
DEBUG - 2017-01-16 18:18:50 --> Total execution time: 0.0152
INFO - 2017-01-16 18:18:53 --> Config Class Initialized
INFO - 2017-01-16 18:18:53 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:18:53 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:18:53 --> Utf8 Class Initialized
INFO - 2017-01-16 18:18:53 --> URI Class Initialized
DEBUG - 2017-01-16 18:18:53 --> No URI present. Default controller set.
INFO - 2017-01-16 18:18:53 --> Router Class Initialized
INFO - 2017-01-16 18:18:53 --> Output Class Initialized
INFO - 2017-01-16 18:18:53 --> Security Class Initialized
DEBUG - 2017-01-16 18:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:18:53 --> Input Class Initialized
INFO - 2017-01-16 18:18:53 --> Language Class Initialized
INFO - 2017-01-16 18:18:53 --> Loader Class Initialized
INFO - 2017-01-16 18:18:53 --> Database Driver Class Initialized
INFO - 2017-01-16 18:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:18:53 --> Controller Class Initialized
INFO - 2017-01-16 18:18:53 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:18:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 18:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 18:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:18:53 --> Final output sent to browser
DEBUG - 2017-01-16 18:18:53 --> Total execution time: 0.0148
INFO - 2017-01-16 18:19:07 --> Config Class Initialized
INFO - 2017-01-16 18:19:07 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:19:07 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:19:07 --> Utf8 Class Initialized
INFO - 2017-01-16 18:19:07 --> URI Class Initialized
DEBUG - 2017-01-16 18:19:07 --> No URI present. Default controller set.
INFO - 2017-01-16 18:19:07 --> Router Class Initialized
INFO - 2017-01-16 18:19:07 --> Output Class Initialized
INFO - 2017-01-16 18:19:07 --> Security Class Initialized
DEBUG - 2017-01-16 18:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:19:07 --> Input Class Initialized
INFO - 2017-01-16 18:19:07 --> Language Class Initialized
INFO - 2017-01-16 18:19:07 --> Loader Class Initialized
INFO - 2017-01-16 18:19:07 --> Database Driver Class Initialized
INFO - 2017-01-16 18:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:19:07 --> Controller Class Initialized
INFO - 2017-01-16 18:19:07 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:19:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:19:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:19:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 18:19:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 18:19:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:19:07 --> Final output sent to browser
DEBUG - 2017-01-16 18:19:07 --> Total execution time: 0.0139
INFO - 2017-01-16 18:19:10 --> Config Class Initialized
INFO - 2017-01-16 18:19:10 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:19:10 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:19:10 --> Utf8 Class Initialized
INFO - 2017-01-16 18:19:10 --> URI Class Initialized
INFO - 2017-01-16 18:19:10 --> Router Class Initialized
INFO - 2017-01-16 18:19:10 --> Output Class Initialized
INFO - 2017-01-16 18:19:10 --> Security Class Initialized
DEBUG - 2017-01-16 18:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:19:10 --> Input Class Initialized
INFO - 2017-01-16 18:19:10 --> Language Class Initialized
INFO - 2017-01-16 18:19:10 --> Loader Class Initialized
INFO - 2017-01-16 18:19:10 --> Database Driver Class Initialized
INFO - 2017-01-16 18:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:19:10 --> Controller Class Initialized
INFO - 2017-01-16 18:19:10 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:19:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:19:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:19:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 18:19:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 18:19:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:19:10 --> Final output sent to browser
DEBUG - 2017-01-16 18:19:10 --> Total execution time: 0.0140
INFO - 2017-01-16 18:19:56 --> Config Class Initialized
INFO - 2017-01-16 18:19:56 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:19:56 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:19:56 --> Utf8 Class Initialized
INFO - 2017-01-16 18:19:56 --> URI Class Initialized
DEBUG - 2017-01-16 18:19:56 --> No URI present. Default controller set.
INFO - 2017-01-16 18:19:56 --> Router Class Initialized
INFO - 2017-01-16 18:19:56 --> Output Class Initialized
INFO - 2017-01-16 18:19:56 --> Security Class Initialized
DEBUG - 2017-01-16 18:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:19:56 --> Input Class Initialized
INFO - 2017-01-16 18:19:56 --> Language Class Initialized
INFO - 2017-01-16 18:19:56 --> Loader Class Initialized
INFO - 2017-01-16 18:19:56 --> Database Driver Class Initialized
INFO - 2017-01-16 18:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:19:56 --> Controller Class Initialized
INFO - 2017-01-16 18:19:56 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 18:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 18:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:19:56 --> Final output sent to browser
DEBUG - 2017-01-16 18:19:56 --> Total execution time: 0.0135
INFO - 2017-01-16 18:20:09 --> Config Class Initialized
INFO - 2017-01-16 18:20:09 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:20:09 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:20:09 --> Utf8 Class Initialized
INFO - 2017-01-16 18:20:09 --> URI Class Initialized
DEBUG - 2017-01-16 18:20:09 --> No URI present. Default controller set.
INFO - 2017-01-16 18:20:09 --> Router Class Initialized
INFO - 2017-01-16 18:20:09 --> Output Class Initialized
INFO - 2017-01-16 18:20:09 --> Security Class Initialized
DEBUG - 2017-01-16 18:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:20:09 --> Input Class Initialized
INFO - 2017-01-16 18:20:09 --> Language Class Initialized
INFO - 2017-01-16 18:20:09 --> Loader Class Initialized
INFO - 2017-01-16 18:20:09 --> Database Driver Class Initialized
INFO - 2017-01-16 18:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:20:09 --> Controller Class Initialized
INFO - 2017-01-16 18:20:09 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:20:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:20:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:20:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 18:20:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 18:20:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:20:09 --> Final output sent to browser
DEBUG - 2017-01-16 18:20:09 --> Total execution time: 0.0150
INFO - 2017-01-16 18:44:12 --> Config Class Initialized
INFO - 2017-01-16 18:44:12 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:44:12 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:44:12 --> Utf8 Class Initialized
INFO - 2017-01-16 18:44:12 --> URI Class Initialized
DEBUG - 2017-01-16 18:44:12 --> No URI present. Default controller set.
INFO - 2017-01-16 18:44:12 --> Router Class Initialized
INFO - 2017-01-16 18:44:12 --> Output Class Initialized
INFO - 2017-01-16 18:44:12 --> Security Class Initialized
DEBUG - 2017-01-16 18:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:44:12 --> Input Class Initialized
INFO - 2017-01-16 18:44:12 --> Language Class Initialized
INFO - 2017-01-16 18:44:12 --> Loader Class Initialized
INFO - 2017-01-16 18:44:12 --> Database Driver Class Initialized
INFO - 2017-01-16 18:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:44:12 --> Controller Class Initialized
INFO - 2017-01-16 18:44:12 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:44:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:44:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:44:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 18:44:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 18:44:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:44:12 --> Final output sent to browser
DEBUG - 2017-01-16 18:44:12 --> Total execution time: 0.0139
INFO - 2017-01-16 18:44:30 --> Config Class Initialized
INFO - 2017-01-16 18:44:30 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:44:30 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:44:30 --> Utf8 Class Initialized
INFO - 2017-01-16 18:44:30 --> URI Class Initialized
DEBUG - 2017-01-16 18:44:30 --> No URI present. Default controller set.
INFO - 2017-01-16 18:44:30 --> Router Class Initialized
INFO - 2017-01-16 18:44:30 --> Output Class Initialized
INFO - 2017-01-16 18:44:30 --> Security Class Initialized
DEBUG - 2017-01-16 18:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:44:30 --> Input Class Initialized
INFO - 2017-01-16 18:44:30 --> Language Class Initialized
INFO - 2017-01-16 18:44:30 --> Loader Class Initialized
INFO - 2017-01-16 18:44:30 --> Database Driver Class Initialized
INFO - 2017-01-16 18:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:44:30 --> Controller Class Initialized
INFO - 2017-01-16 18:44:30 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:44:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:44:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:44:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 18:44:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 18:44:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:44:30 --> Final output sent to browser
DEBUG - 2017-01-16 18:44:30 --> Total execution time: 0.0164
INFO - 2017-01-16 18:44:38 --> Config Class Initialized
INFO - 2017-01-16 18:44:38 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:44:38 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:44:38 --> Utf8 Class Initialized
INFO - 2017-01-16 18:44:38 --> URI Class Initialized
INFO - 2017-01-16 18:44:38 --> Router Class Initialized
INFO - 2017-01-16 18:44:38 --> Output Class Initialized
INFO - 2017-01-16 18:44:38 --> Security Class Initialized
DEBUG - 2017-01-16 18:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:44:38 --> Input Class Initialized
INFO - 2017-01-16 18:44:38 --> Language Class Initialized
INFO - 2017-01-16 18:44:38 --> Loader Class Initialized
INFO - 2017-01-16 18:44:38 --> Database Driver Class Initialized
INFO - 2017-01-16 18:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:44:38 --> Controller Class Initialized
INFO - 2017-01-16 18:44:38 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:44:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:44:39 --> Config Class Initialized
INFO - 2017-01-16 18:44:39 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:44:39 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:44:39 --> Utf8 Class Initialized
INFO - 2017-01-16 18:44:39 --> URI Class Initialized
INFO - 2017-01-16 18:44:39 --> Router Class Initialized
INFO - 2017-01-16 18:44:39 --> Output Class Initialized
INFO - 2017-01-16 18:44:39 --> Security Class Initialized
DEBUG - 2017-01-16 18:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:44:39 --> Input Class Initialized
INFO - 2017-01-16 18:44:39 --> Language Class Initialized
INFO - 2017-01-16 18:44:39 --> Loader Class Initialized
INFO - 2017-01-16 18:44:39 --> Database Driver Class Initialized
INFO - 2017-01-16 18:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:44:39 --> Controller Class Initialized
INFO - 2017-01-16 18:44:39 --> Helper loaded: date_helper
DEBUG - 2017-01-16 18:44:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:44:39 --> Helper loaded: url_helper
INFO - 2017-01-16 18:44:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:44:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-16 18:44:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-16 18:44:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-16 18:44:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:44:39 --> Final output sent to browser
DEBUG - 2017-01-16 18:44:39 --> Total execution time: 0.0145
INFO - 2017-01-16 18:44:49 --> Config Class Initialized
INFO - 2017-01-16 18:44:49 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:44:49 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:44:49 --> Utf8 Class Initialized
INFO - 2017-01-16 18:44:49 --> URI Class Initialized
DEBUG - 2017-01-16 18:44:49 --> No URI present. Default controller set.
INFO - 2017-01-16 18:44:49 --> Router Class Initialized
INFO - 2017-01-16 18:44:49 --> Output Class Initialized
INFO - 2017-01-16 18:44:49 --> Security Class Initialized
DEBUG - 2017-01-16 18:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:44:49 --> Input Class Initialized
INFO - 2017-01-16 18:44:49 --> Language Class Initialized
INFO - 2017-01-16 18:44:49 --> Loader Class Initialized
INFO - 2017-01-16 18:44:49 --> Database Driver Class Initialized
INFO - 2017-01-16 18:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:44:49 --> Controller Class Initialized
INFO - 2017-01-16 18:44:49 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:44:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:44:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:44:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 18:44:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 18:44:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:44:49 --> Final output sent to browser
DEBUG - 2017-01-16 18:44:49 --> Total execution time: 0.0467
INFO - 2017-01-16 18:45:25 --> Config Class Initialized
INFO - 2017-01-16 18:45:25 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:45:25 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:45:25 --> Utf8 Class Initialized
INFO - 2017-01-16 18:45:25 --> URI Class Initialized
INFO - 2017-01-16 18:45:25 --> Router Class Initialized
INFO - 2017-01-16 18:45:25 --> Output Class Initialized
INFO - 2017-01-16 18:45:25 --> Security Class Initialized
DEBUG - 2017-01-16 18:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:45:25 --> Input Class Initialized
INFO - 2017-01-16 18:45:25 --> Language Class Initialized
INFO - 2017-01-16 18:45:25 --> Loader Class Initialized
INFO - 2017-01-16 18:45:25 --> Database Driver Class Initialized
INFO - 2017-01-16 18:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:45:25 --> Controller Class Initialized
INFO - 2017-01-16 18:45:25 --> Helper loaded: url_helper
DEBUG - 2017-01-16 18:45:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:45:26 --> Config Class Initialized
INFO - 2017-01-16 18:45:26 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:45:26 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:45:26 --> Utf8 Class Initialized
INFO - 2017-01-16 18:45:26 --> URI Class Initialized
INFO - 2017-01-16 18:45:26 --> Router Class Initialized
INFO - 2017-01-16 18:45:26 --> Output Class Initialized
INFO - 2017-01-16 18:45:26 --> Security Class Initialized
DEBUG - 2017-01-16 18:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:45:26 --> Input Class Initialized
INFO - 2017-01-16 18:45:26 --> Language Class Initialized
INFO - 2017-01-16 18:45:26 --> Loader Class Initialized
INFO - 2017-01-16 18:45:26 --> Database Driver Class Initialized
INFO - 2017-01-16 18:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:45:26 --> Controller Class Initialized
INFO - 2017-01-16 18:45:26 --> Helper loaded: date_helper
DEBUG - 2017-01-16 18:45:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:45:26 --> Helper loaded: url_helper
INFO - 2017-01-16 18:45:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:45:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-16 18:45:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-16 18:45:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-16 18:45:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:45:26 --> Final output sent to browser
DEBUG - 2017-01-16 18:45:26 --> Total execution time: 0.0153
INFO - 2017-01-16 18:45:40 --> Config Class Initialized
INFO - 2017-01-16 18:45:40 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:45:40 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:45:40 --> Utf8 Class Initialized
INFO - 2017-01-16 18:45:40 --> URI Class Initialized
INFO - 2017-01-16 18:45:40 --> Router Class Initialized
INFO - 2017-01-16 18:45:40 --> Output Class Initialized
INFO - 2017-01-16 18:45:40 --> Security Class Initialized
DEBUG - 2017-01-16 18:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:45:40 --> Input Class Initialized
INFO - 2017-01-16 18:45:40 --> Language Class Initialized
INFO - 2017-01-16 18:45:40 --> Loader Class Initialized
INFO - 2017-01-16 18:45:40 --> Database Driver Class Initialized
INFO - 2017-01-16 18:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:45:40 --> Controller Class Initialized
INFO - 2017-01-16 18:45:40 --> Helper loaded: date_helper
DEBUG - 2017-01-16 18:45:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:45:40 --> Helper loaded: url_helper
INFO - 2017-01-16 18:45:40 --> Helper loaded: download_helper
INFO - 2017-01-16 18:45:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:45:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-16 18:45:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-16 18:45:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-16 18:45:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:45:40 --> Final output sent to browser
DEBUG - 2017-01-16 18:45:40 --> Total execution time: 0.0186
INFO - 2017-01-16 18:46:04 --> Config Class Initialized
INFO - 2017-01-16 18:46:04 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:46:04 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:46:04 --> Utf8 Class Initialized
INFO - 2017-01-16 18:46:04 --> URI Class Initialized
INFO - 2017-01-16 18:46:04 --> Router Class Initialized
INFO - 2017-01-16 18:46:04 --> Output Class Initialized
INFO - 2017-01-16 18:46:04 --> Security Class Initialized
DEBUG - 2017-01-16 18:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:46:04 --> Input Class Initialized
INFO - 2017-01-16 18:46:04 --> Language Class Initialized
INFO - 2017-01-16 18:46:04 --> Loader Class Initialized
INFO - 2017-01-16 18:46:04 --> Database Driver Class Initialized
INFO - 2017-01-16 18:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:46:04 --> Controller Class Initialized
INFO - 2017-01-16 18:46:04 --> Helper loaded: date_helper
DEBUG - 2017-01-16 18:46:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:46:04 --> Helper loaded: url_helper
INFO - 2017-01-16 18:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-16 18:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-16 18:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-16 18:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:46:04 --> Final output sent to browser
DEBUG - 2017-01-16 18:46:04 --> Total execution time: 0.0218
INFO - 2017-01-16 18:46:09 --> Config Class Initialized
INFO - 2017-01-16 18:46:09 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:46:09 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:46:09 --> Utf8 Class Initialized
INFO - 2017-01-16 18:46:09 --> URI Class Initialized
INFO - 2017-01-16 18:46:09 --> Router Class Initialized
INFO - 2017-01-16 18:46:09 --> Output Class Initialized
INFO - 2017-01-16 18:46:09 --> Security Class Initialized
DEBUG - 2017-01-16 18:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:46:09 --> Input Class Initialized
INFO - 2017-01-16 18:46:09 --> Language Class Initialized
INFO - 2017-01-16 18:46:09 --> Loader Class Initialized
INFO - 2017-01-16 18:46:09 --> Database Driver Class Initialized
INFO - 2017-01-16 18:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:46:09 --> Controller Class Initialized
INFO - 2017-01-16 18:46:09 --> Helper loaded: date_helper
DEBUG - 2017-01-16 18:46:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:46:09 --> Helper loaded: url_helper
INFO - 2017-01-16 18:46:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:46:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-16 18:46:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-16 18:46:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-16 18:46:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:46:09 --> Final output sent to browser
DEBUG - 2017-01-16 18:46:09 --> Total execution time: 0.0160
INFO - 2017-01-16 18:46:17 --> Config Class Initialized
INFO - 2017-01-16 18:46:17 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:46:17 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:46:17 --> Utf8 Class Initialized
INFO - 2017-01-16 18:46:17 --> URI Class Initialized
INFO - 2017-01-16 18:46:17 --> Router Class Initialized
INFO - 2017-01-16 18:46:17 --> Output Class Initialized
INFO - 2017-01-16 18:46:17 --> Security Class Initialized
DEBUG - 2017-01-16 18:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:46:17 --> Input Class Initialized
INFO - 2017-01-16 18:46:17 --> Language Class Initialized
INFO - 2017-01-16 18:46:17 --> Loader Class Initialized
INFO - 2017-01-16 18:46:17 --> Database Driver Class Initialized
INFO - 2017-01-16 18:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:46:17 --> Controller Class Initialized
INFO - 2017-01-16 18:46:17 --> Helper loaded: date_helper
DEBUG - 2017-01-16 18:46:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:46:17 --> Helper loaded: url_helper
INFO - 2017-01-16 18:46:17 --> Helper loaded: download_helper
INFO - 2017-01-16 18:46:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:46:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-16 18:46:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-16 18:46:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-16 18:46:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:46:17 --> Final output sent to browser
DEBUG - 2017-01-16 18:46:17 --> Total execution time: 0.0254
INFO - 2017-01-16 18:46:48 --> Config Class Initialized
INFO - 2017-01-16 18:46:48 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:46:48 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:46:48 --> Utf8 Class Initialized
INFO - 2017-01-16 18:46:48 --> URI Class Initialized
INFO - 2017-01-16 18:46:48 --> Router Class Initialized
INFO - 2017-01-16 18:46:48 --> Output Class Initialized
INFO - 2017-01-16 18:46:48 --> Security Class Initialized
DEBUG - 2017-01-16 18:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:46:48 --> Input Class Initialized
INFO - 2017-01-16 18:46:48 --> Language Class Initialized
INFO - 2017-01-16 18:46:48 --> Loader Class Initialized
INFO - 2017-01-16 18:46:48 --> Database Driver Class Initialized
INFO - 2017-01-16 18:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:46:48 --> Controller Class Initialized
INFO - 2017-01-16 18:46:48 --> Helper loaded: date_helper
DEBUG - 2017-01-16 18:46:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:46:48 --> Helper loaded: url_helper
INFO - 2017-01-16 18:46:48 --> Helper loaded: download_helper
INFO - 2017-01-16 18:46:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:46:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-16 18:46:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-16 18:46:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-16 18:46:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:46:48 --> Final output sent to browser
DEBUG - 2017-01-16 18:46:48 --> Total execution time: 0.0184
INFO - 2017-01-16 18:46:49 --> Config Class Initialized
INFO - 2017-01-16 18:46:49 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:46:49 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:46:49 --> Utf8 Class Initialized
INFO - 2017-01-16 18:46:49 --> URI Class Initialized
INFO - 2017-01-16 18:46:49 --> Router Class Initialized
INFO - 2017-01-16 18:46:49 --> Output Class Initialized
INFO - 2017-01-16 18:46:49 --> Security Class Initialized
DEBUG - 2017-01-16 18:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:46:49 --> Input Class Initialized
INFO - 2017-01-16 18:46:49 --> Language Class Initialized
INFO - 2017-01-16 18:46:49 --> Loader Class Initialized
INFO - 2017-01-16 18:46:49 --> Database Driver Class Initialized
INFO - 2017-01-16 18:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:46:49 --> Controller Class Initialized
INFO - 2017-01-16 18:46:49 --> Helper loaded: date_helper
DEBUG - 2017-01-16 18:46:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:46:49 --> Helper loaded: url_helper
INFO - 2017-01-16 18:46:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:46:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-16 18:46:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-16 18:46:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-16 18:46:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:46:49 --> Final output sent to browser
DEBUG - 2017-01-16 18:46:49 --> Total execution time: 0.0225
INFO - 2017-01-16 18:47:07 --> Config Class Initialized
INFO - 2017-01-16 18:47:07 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:47:07 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:47:07 --> Utf8 Class Initialized
INFO - 2017-01-16 18:47:07 --> URI Class Initialized
INFO - 2017-01-16 18:47:07 --> Router Class Initialized
INFO - 2017-01-16 18:47:07 --> Output Class Initialized
INFO - 2017-01-16 18:47:07 --> Security Class Initialized
DEBUG - 2017-01-16 18:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:47:07 --> Input Class Initialized
INFO - 2017-01-16 18:47:07 --> Language Class Initialized
INFO - 2017-01-16 18:47:07 --> Loader Class Initialized
INFO - 2017-01-16 18:47:07 --> Database Driver Class Initialized
INFO - 2017-01-16 18:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:47:07 --> Controller Class Initialized
INFO - 2017-01-16 18:47:07 --> Helper loaded: date_helper
DEBUG - 2017-01-16 18:47:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:47:07 --> Helper loaded: url_helper
INFO - 2017-01-16 18:47:07 --> Final output sent to browser
DEBUG - 2017-01-16 18:47:07 --> Total execution time: 0.0150
INFO - 2017-01-16 18:47:12 --> Config Class Initialized
INFO - 2017-01-16 18:47:12 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:47:12 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:47:12 --> Utf8 Class Initialized
INFO - 2017-01-16 18:47:12 --> URI Class Initialized
INFO - 2017-01-16 18:47:12 --> Router Class Initialized
INFO - 2017-01-16 18:47:12 --> Output Class Initialized
INFO - 2017-01-16 18:47:12 --> Security Class Initialized
DEBUG - 2017-01-16 18:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:47:12 --> Input Class Initialized
INFO - 2017-01-16 18:47:12 --> Language Class Initialized
INFO - 2017-01-16 18:47:12 --> Loader Class Initialized
INFO - 2017-01-16 18:47:12 --> Database Driver Class Initialized
INFO - 2017-01-16 18:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:47:12 --> Controller Class Initialized
INFO - 2017-01-16 18:47:12 --> Helper loaded: date_helper
DEBUG - 2017-01-16 18:47:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:47:12 --> Helper loaded: url_helper
INFO - 2017-01-16 18:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-16 18:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-16 18:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-16 18:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-16 18:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:47:12 --> Final output sent to browser
DEBUG - 2017-01-16 18:47:12 --> Total execution time: 0.3571
INFO - 2017-01-16 18:47:21 --> Config Class Initialized
INFO - 2017-01-16 18:47:21 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:47:21 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:47:21 --> Utf8 Class Initialized
INFO - 2017-01-16 18:47:21 --> URI Class Initialized
INFO - 2017-01-16 18:47:21 --> Router Class Initialized
INFO - 2017-01-16 18:47:21 --> Output Class Initialized
INFO - 2017-01-16 18:47:21 --> Security Class Initialized
DEBUG - 2017-01-16 18:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:47:21 --> Input Class Initialized
INFO - 2017-01-16 18:47:21 --> Language Class Initialized
INFO - 2017-01-16 18:47:21 --> Loader Class Initialized
INFO - 2017-01-16 18:47:21 --> Database Driver Class Initialized
INFO - 2017-01-16 18:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:47:21 --> Controller Class Initialized
INFO - 2017-01-16 18:47:21 --> Helper loaded: date_helper
DEBUG - 2017-01-16 18:47:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:47:21 --> Helper loaded: url_helper
INFO - 2017-01-16 18:47:21 --> Final output sent to browser
DEBUG - 2017-01-16 18:47:21 --> Total execution time: 0.0308
INFO - 2017-01-16 18:47:21 --> Config Class Initialized
INFO - 2017-01-16 18:47:21 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:47:21 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:47:21 --> Utf8 Class Initialized
INFO - 2017-01-16 18:47:21 --> URI Class Initialized
INFO - 2017-01-16 18:47:21 --> Router Class Initialized
INFO - 2017-01-16 18:47:21 --> Output Class Initialized
INFO - 2017-01-16 18:47:21 --> Security Class Initialized
DEBUG - 2017-01-16 18:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:47:21 --> Input Class Initialized
INFO - 2017-01-16 18:47:21 --> Language Class Initialized
INFO - 2017-01-16 18:47:21 --> Loader Class Initialized
INFO - 2017-01-16 18:47:21 --> Database Driver Class Initialized
INFO - 2017-01-16 18:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:47:21 --> Controller Class Initialized
INFO - 2017-01-16 18:47:21 --> Helper loaded: date_helper
DEBUG - 2017-01-16 18:47:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:47:21 --> Helper loaded: url_helper
INFO - 2017-01-16 18:47:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:47:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-16 18:47:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-16 18:47:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-16 18:47:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-16 18:47:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:47:21 --> Final output sent to browser
DEBUG - 2017-01-16 18:47:21 --> Total execution time: 0.0154
INFO - 2017-01-16 18:47:25 --> Config Class Initialized
INFO - 2017-01-16 18:47:25 --> Hooks Class Initialized
DEBUG - 2017-01-16 18:47:25 --> UTF-8 Support Enabled
INFO - 2017-01-16 18:47:25 --> Utf8 Class Initialized
INFO - 2017-01-16 18:47:25 --> URI Class Initialized
INFO - 2017-01-16 18:47:25 --> Router Class Initialized
INFO - 2017-01-16 18:47:25 --> Output Class Initialized
INFO - 2017-01-16 18:47:25 --> Security Class Initialized
DEBUG - 2017-01-16 18:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 18:47:25 --> Input Class Initialized
INFO - 2017-01-16 18:47:25 --> Language Class Initialized
INFO - 2017-01-16 18:47:25 --> Loader Class Initialized
INFO - 2017-01-16 18:47:25 --> Database Driver Class Initialized
INFO - 2017-01-16 18:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 18:47:25 --> Controller Class Initialized
INFO - 2017-01-16 18:47:25 --> Upload Class Initialized
INFO - 2017-01-16 18:47:25 --> Helper loaded: date_helper
DEBUG - 2017-01-16 18:47:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 18:47:25 --> Helper loaded: url_helper
INFO - 2017-01-16 18:47:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 18:47:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-16 18:47:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-01-16 18:47:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-01-16 18:47:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-16 18:47:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 18:47:25 --> Final output sent to browser
DEBUG - 2017-01-16 18:47:25 --> Total execution time: 0.3869
INFO - 2017-01-16 22:08:27 --> Config Class Initialized
INFO - 2017-01-16 22:08:27 --> Hooks Class Initialized
DEBUG - 2017-01-16 22:08:27 --> UTF-8 Support Enabled
INFO - 2017-01-16 22:08:27 --> Utf8 Class Initialized
INFO - 2017-01-16 22:08:27 --> URI Class Initialized
DEBUG - 2017-01-16 22:08:27 --> No URI present. Default controller set.
INFO - 2017-01-16 22:08:27 --> Router Class Initialized
INFO - 2017-01-16 22:08:27 --> Output Class Initialized
INFO - 2017-01-16 22:08:27 --> Security Class Initialized
DEBUG - 2017-01-16 22:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 22:08:27 --> Input Class Initialized
INFO - 2017-01-16 22:08:27 --> Language Class Initialized
INFO - 2017-01-16 22:08:27 --> Loader Class Initialized
INFO - 2017-01-16 22:08:27 --> Database Driver Class Initialized
INFO - 2017-01-16 22:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 22:08:27 --> Controller Class Initialized
INFO - 2017-01-16 22:08:27 --> Helper loaded: url_helper
DEBUG - 2017-01-16 22:08:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 22:08:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 22:08:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 22:08:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 22:08:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 22:08:27 --> Final output sent to browser
DEBUG - 2017-01-16 22:08:27 --> Total execution time: 0.2090
INFO - 2017-01-16 22:45:54 --> Config Class Initialized
INFO - 2017-01-16 22:45:54 --> Hooks Class Initialized
DEBUG - 2017-01-16 22:45:54 --> UTF-8 Support Enabled
INFO - 2017-01-16 22:45:54 --> Utf8 Class Initialized
INFO - 2017-01-16 22:45:54 --> URI Class Initialized
DEBUG - 2017-01-16 22:45:54 --> No URI present. Default controller set.
INFO - 2017-01-16 22:45:54 --> Router Class Initialized
INFO - 2017-01-16 22:45:54 --> Output Class Initialized
INFO - 2017-01-16 22:45:54 --> Security Class Initialized
DEBUG - 2017-01-16 22:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 22:45:54 --> Input Class Initialized
INFO - 2017-01-16 22:45:54 --> Language Class Initialized
INFO - 2017-01-16 22:45:54 --> Loader Class Initialized
INFO - 2017-01-16 22:45:54 --> Database Driver Class Initialized
INFO - 2017-01-16 22:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 22:45:54 --> Controller Class Initialized
INFO - 2017-01-16 22:45:54 --> Helper loaded: url_helper
DEBUG - 2017-01-16 22:45:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 22:45:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 22:45:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 22:45:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 22:45:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 22:45:54 --> Final output sent to browser
DEBUG - 2017-01-16 22:45:54 --> Total execution time: 0.0142
INFO - 2017-01-16 22:57:34 --> Config Class Initialized
INFO - 2017-01-16 22:57:34 --> Hooks Class Initialized
DEBUG - 2017-01-16 22:57:34 --> UTF-8 Support Enabled
INFO - 2017-01-16 22:57:34 --> Utf8 Class Initialized
INFO - 2017-01-16 22:57:34 --> URI Class Initialized
DEBUG - 2017-01-16 22:57:34 --> No URI present. Default controller set.
INFO - 2017-01-16 22:57:34 --> Router Class Initialized
INFO - 2017-01-16 22:57:34 --> Output Class Initialized
INFO - 2017-01-16 22:57:34 --> Security Class Initialized
DEBUG - 2017-01-16 22:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 22:57:34 --> Input Class Initialized
INFO - 2017-01-16 22:57:34 --> Language Class Initialized
INFO - 2017-01-16 22:57:34 --> Loader Class Initialized
INFO - 2017-01-16 22:57:34 --> Database Driver Class Initialized
INFO - 2017-01-16 22:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 22:57:34 --> Controller Class Initialized
INFO - 2017-01-16 22:57:34 --> Helper loaded: url_helper
DEBUG - 2017-01-16 22:57:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 22:57:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 22:57:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 22:57:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 22:57:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 22:57:34 --> Final output sent to browser
DEBUG - 2017-01-16 22:57:34 --> Total execution time: 0.0132
INFO - 2017-01-16 22:57:39 --> Config Class Initialized
INFO - 2017-01-16 22:57:39 --> Hooks Class Initialized
DEBUG - 2017-01-16 22:57:39 --> UTF-8 Support Enabled
INFO - 2017-01-16 22:57:39 --> Utf8 Class Initialized
INFO - 2017-01-16 22:57:39 --> URI Class Initialized
INFO - 2017-01-16 22:57:39 --> Router Class Initialized
INFO - 2017-01-16 22:57:39 --> Output Class Initialized
INFO - 2017-01-16 22:57:39 --> Security Class Initialized
DEBUG - 2017-01-16 22:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 22:57:39 --> Input Class Initialized
INFO - 2017-01-16 22:57:39 --> Language Class Initialized
INFO - 2017-01-16 22:57:39 --> Loader Class Initialized
INFO - 2017-01-16 22:57:39 --> Database Driver Class Initialized
INFO - 2017-01-16 22:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 22:57:39 --> Controller Class Initialized
INFO - 2017-01-16 22:57:39 --> Helper loaded: url_helper
DEBUG - 2017-01-16 22:57:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 22:57:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 22:57:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 22:57:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 22:57:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 22:57:39 --> Final output sent to browser
DEBUG - 2017-01-16 22:57:39 --> Total execution time: 0.0147
INFO - 2017-01-16 22:58:49 --> Config Class Initialized
INFO - 2017-01-16 22:58:49 --> Hooks Class Initialized
DEBUG - 2017-01-16 22:58:49 --> UTF-8 Support Enabled
INFO - 2017-01-16 22:58:49 --> Utf8 Class Initialized
INFO - 2017-01-16 22:58:49 --> URI Class Initialized
INFO - 2017-01-16 22:58:49 --> Router Class Initialized
INFO - 2017-01-16 22:58:49 --> Output Class Initialized
INFO - 2017-01-16 22:58:49 --> Security Class Initialized
DEBUG - 2017-01-16 22:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 22:58:49 --> Input Class Initialized
INFO - 2017-01-16 22:58:49 --> Language Class Initialized
INFO - 2017-01-16 22:58:49 --> Loader Class Initialized
INFO - 2017-01-16 22:58:49 --> Database Driver Class Initialized
INFO - 2017-01-16 22:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 22:58:49 --> Controller Class Initialized
INFO - 2017-01-16 22:58:49 --> Helper loaded: url_helper
DEBUG - 2017-01-16 22:58:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 22:58:51 --> Config Class Initialized
INFO - 2017-01-16 22:58:51 --> Hooks Class Initialized
DEBUG - 2017-01-16 22:58:51 --> UTF-8 Support Enabled
INFO - 2017-01-16 22:58:51 --> Utf8 Class Initialized
INFO - 2017-01-16 22:58:51 --> URI Class Initialized
INFO - 2017-01-16 22:58:51 --> Router Class Initialized
INFO - 2017-01-16 22:58:51 --> Output Class Initialized
INFO - 2017-01-16 22:58:51 --> Security Class Initialized
DEBUG - 2017-01-16 22:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 22:58:51 --> Input Class Initialized
INFO - 2017-01-16 22:58:51 --> Language Class Initialized
INFO - 2017-01-16 22:58:51 --> Loader Class Initialized
INFO - 2017-01-16 22:58:51 --> Database Driver Class Initialized
INFO - 2017-01-16 22:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 22:58:51 --> Controller Class Initialized
INFO - 2017-01-16 22:58:51 --> Helper loaded: date_helper
DEBUG - 2017-01-16 22:58:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 22:58:51 --> Helper loaded: url_helper
INFO - 2017-01-16 22:58:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 22:58:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-16 22:58:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-16 22:58:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-16 22:58:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 22:58:51 --> Final output sent to browser
DEBUG - 2017-01-16 22:58:51 --> Total execution time: 0.0144
INFO - 2017-01-16 22:58:52 --> Config Class Initialized
INFO - 2017-01-16 22:58:52 --> Hooks Class Initialized
DEBUG - 2017-01-16 22:58:52 --> UTF-8 Support Enabled
INFO - 2017-01-16 22:58:52 --> Utf8 Class Initialized
INFO - 2017-01-16 22:58:52 --> URI Class Initialized
INFO - 2017-01-16 22:58:52 --> Router Class Initialized
INFO - 2017-01-16 22:58:52 --> Output Class Initialized
INFO - 2017-01-16 22:58:52 --> Security Class Initialized
DEBUG - 2017-01-16 22:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 22:58:52 --> Input Class Initialized
INFO - 2017-01-16 22:58:52 --> Language Class Initialized
INFO - 2017-01-16 22:58:52 --> Loader Class Initialized
INFO - 2017-01-16 22:58:52 --> Database Driver Class Initialized
INFO - 2017-01-16 22:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 22:58:52 --> Controller Class Initialized
INFO - 2017-01-16 22:58:52 --> Helper loaded: url_helper
DEBUG - 2017-01-16 22:58:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 22:58:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 22:58:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 22:58:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 22:58:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 22:58:52 --> Final output sent to browser
DEBUG - 2017-01-16 22:58:52 --> Total execution time: 0.0144
INFO - 2017-01-16 23:18:27 --> Config Class Initialized
INFO - 2017-01-16 23:18:27 --> Hooks Class Initialized
DEBUG - 2017-01-16 23:18:27 --> UTF-8 Support Enabled
INFO - 2017-01-16 23:18:27 --> Utf8 Class Initialized
INFO - 2017-01-16 23:18:27 --> URI Class Initialized
INFO - 2017-01-16 23:18:27 --> Router Class Initialized
INFO - 2017-01-16 23:18:27 --> Output Class Initialized
INFO - 2017-01-16 23:18:27 --> Security Class Initialized
DEBUG - 2017-01-16 23:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 23:18:27 --> Input Class Initialized
INFO - 2017-01-16 23:18:27 --> Language Class Initialized
INFO - 2017-01-16 23:18:27 --> Loader Class Initialized
INFO - 2017-01-16 23:18:27 --> Database Driver Class Initialized
INFO - 2017-01-16 23:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 23:18:27 --> Controller Class Initialized
INFO - 2017-01-16 23:18:27 --> Helper loaded: date_helper
DEBUG - 2017-01-16 23:18:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 23:18:27 --> Helper loaded: url_helper
INFO - 2017-01-16 23:18:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 23:18:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-16 23:18:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-16 23:18:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-16 23:18:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 23:18:27 --> Final output sent to browser
DEBUG - 2017-01-16 23:18:27 --> Total execution time: 0.0584
INFO - 2017-01-16 23:18:30 --> Config Class Initialized
INFO - 2017-01-16 23:18:30 --> Hooks Class Initialized
DEBUG - 2017-01-16 23:18:30 --> UTF-8 Support Enabled
INFO - 2017-01-16 23:18:30 --> Utf8 Class Initialized
INFO - 2017-01-16 23:18:30 --> URI Class Initialized
INFO - 2017-01-16 23:18:30 --> Router Class Initialized
INFO - 2017-01-16 23:18:30 --> Output Class Initialized
INFO - 2017-01-16 23:18:30 --> Security Class Initialized
DEBUG - 2017-01-16 23:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-16 23:18:30 --> Input Class Initialized
INFO - 2017-01-16 23:18:30 --> Language Class Initialized
INFO - 2017-01-16 23:18:30 --> Loader Class Initialized
INFO - 2017-01-16 23:18:30 --> Database Driver Class Initialized
INFO - 2017-01-16 23:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-16 23:18:30 --> Controller Class Initialized
INFO - 2017-01-16 23:18:30 --> Helper loaded: url_helper
DEBUG - 2017-01-16 23:18:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-16 23:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-16 23:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-16 23:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-16 23:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-16 23:18:30 --> Final output sent to browser
DEBUG - 2017-01-16 23:18:30 --> Total execution time: 0.0134

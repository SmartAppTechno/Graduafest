<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-19 00:07:50 --> Config Class Initialized
INFO - 2017-01-19 00:07:50 --> Hooks Class Initialized
DEBUG - 2017-01-19 00:07:50 --> UTF-8 Support Enabled
INFO - 2017-01-19 00:07:50 --> Utf8 Class Initialized
INFO - 2017-01-19 00:07:50 --> URI Class Initialized
DEBUG - 2017-01-19 00:07:50 --> No URI present. Default controller set.
INFO - 2017-01-19 00:07:50 --> Router Class Initialized
INFO - 2017-01-19 00:07:50 --> Output Class Initialized
INFO - 2017-01-19 00:07:50 --> Security Class Initialized
DEBUG - 2017-01-19 00:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 00:07:50 --> Input Class Initialized
INFO - 2017-01-19 00:07:50 --> Language Class Initialized
INFO - 2017-01-19 00:07:50 --> Loader Class Initialized
INFO - 2017-01-19 00:07:50 --> Database Driver Class Initialized
INFO - 2017-01-19 00:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 00:07:50 --> Controller Class Initialized
INFO - 2017-01-19 00:07:50 --> Helper loaded: url_helper
DEBUG - 2017-01-19 00:07:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 00:07:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 00:07:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 00:07:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 00:07:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 00:07:50 --> Final output sent to browser
DEBUG - 2017-01-19 00:07:50 --> Total execution time: 0.2828
INFO - 2017-01-19 00:41:13 --> Config Class Initialized
INFO - 2017-01-19 00:41:13 --> Hooks Class Initialized
DEBUG - 2017-01-19 00:41:13 --> UTF-8 Support Enabled
INFO - 2017-01-19 00:41:13 --> Utf8 Class Initialized
INFO - 2017-01-19 00:41:13 --> URI Class Initialized
INFO - 2017-01-19 00:41:13 --> Router Class Initialized
INFO - 2017-01-19 00:41:13 --> Output Class Initialized
INFO - 2017-01-19 00:41:13 --> Security Class Initialized
DEBUG - 2017-01-19 00:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 00:41:13 --> Input Class Initialized
INFO - 2017-01-19 00:41:13 --> Language Class Initialized
INFO - 2017-01-19 00:41:13 --> Loader Class Initialized
INFO - 2017-01-19 00:41:13 --> Database Driver Class Initialized
INFO - 2017-01-19 00:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 00:41:13 --> Controller Class Initialized
INFO - 2017-01-19 00:41:13 --> Helper loaded: url_helper
DEBUG - 2017-01-19 00:41:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 00:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 00:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 00:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 00:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 00:41:13 --> Final output sent to browser
DEBUG - 2017-01-19 00:41:13 --> Total execution time: 0.0132
INFO - 2017-01-19 00:59:29 --> Config Class Initialized
INFO - 2017-01-19 00:59:29 --> Hooks Class Initialized
DEBUG - 2017-01-19 00:59:29 --> UTF-8 Support Enabled
INFO - 2017-01-19 00:59:29 --> Utf8 Class Initialized
INFO - 2017-01-19 00:59:29 --> URI Class Initialized
DEBUG - 2017-01-19 00:59:29 --> No URI present. Default controller set.
INFO - 2017-01-19 00:59:29 --> Router Class Initialized
INFO - 2017-01-19 00:59:29 --> Output Class Initialized
INFO - 2017-01-19 00:59:29 --> Security Class Initialized
DEBUG - 2017-01-19 00:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 00:59:29 --> Input Class Initialized
INFO - 2017-01-19 00:59:29 --> Language Class Initialized
INFO - 2017-01-19 00:59:29 --> Loader Class Initialized
INFO - 2017-01-19 00:59:29 --> Database Driver Class Initialized
INFO - 2017-01-19 00:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 00:59:29 --> Controller Class Initialized
INFO - 2017-01-19 00:59:29 --> Helper loaded: url_helper
DEBUG - 2017-01-19 00:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 00:59:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 00:59:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 00:59:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 00:59:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 00:59:29 --> Final output sent to browser
DEBUG - 2017-01-19 00:59:29 --> Total execution time: 0.0137
INFO - 2017-01-19 01:22:06 --> Config Class Initialized
INFO - 2017-01-19 01:22:06 --> Hooks Class Initialized
DEBUG - 2017-01-19 01:22:06 --> UTF-8 Support Enabled
INFO - 2017-01-19 01:22:06 --> Utf8 Class Initialized
INFO - 2017-01-19 01:22:06 --> URI Class Initialized
DEBUG - 2017-01-19 01:22:06 --> No URI present. Default controller set.
INFO - 2017-01-19 01:22:06 --> Router Class Initialized
INFO - 2017-01-19 01:22:06 --> Output Class Initialized
INFO - 2017-01-19 01:22:06 --> Security Class Initialized
DEBUG - 2017-01-19 01:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 01:22:06 --> Input Class Initialized
INFO - 2017-01-19 01:22:06 --> Language Class Initialized
INFO - 2017-01-19 01:22:06 --> Loader Class Initialized
INFO - 2017-01-19 01:22:06 --> Database Driver Class Initialized
INFO - 2017-01-19 01:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 01:22:06 --> Controller Class Initialized
INFO - 2017-01-19 01:22:06 --> Helper loaded: url_helper
DEBUG - 2017-01-19 01:22:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 01:22:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 01:22:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 01:22:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 01:22:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 01:22:06 --> Final output sent to browser
DEBUG - 2017-01-19 01:22:06 --> Total execution time: 0.0134
INFO - 2017-01-19 01:22:37 --> Config Class Initialized
INFO - 2017-01-19 01:22:37 --> Hooks Class Initialized
DEBUG - 2017-01-19 01:22:37 --> UTF-8 Support Enabled
INFO - 2017-01-19 01:22:37 --> Utf8 Class Initialized
INFO - 2017-01-19 01:22:37 --> URI Class Initialized
INFO - 2017-01-19 01:22:37 --> Router Class Initialized
INFO - 2017-01-19 01:22:37 --> Output Class Initialized
INFO - 2017-01-19 01:22:37 --> Security Class Initialized
DEBUG - 2017-01-19 01:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 01:22:37 --> Input Class Initialized
INFO - 2017-01-19 01:22:37 --> Language Class Initialized
INFO - 2017-01-19 01:22:37 --> Loader Class Initialized
INFO - 2017-01-19 01:22:37 --> Database Driver Class Initialized
INFO - 2017-01-19 01:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 01:22:37 --> Controller Class Initialized
INFO - 2017-01-19 01:22:37 --> Helper loaded: url_helper
DEBUG - 2017-01-19 01:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 01:22:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 01:22:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 01:22:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 01:22:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 01:22:37 --> Final output sent to browser
DEBUG - 2017-01-19 01:22:37 --> Total execution time: 0.0162
INFO - 2017-01-19 01:23:23 --> Config Class Initialized
INFO - 2017-01-19 01:23:23 --> Hooks Class Initialized
DEBUG - 2017-01-19 01:23:23 --> UTF-8 Support Enabled
INFO - 2017-01-19 01:23:23 --> Utf8 Class Initialized
INFO - 2017-01-19 01:23:23 --> URI Class Initialized
INFO - 2017-01-19 01:23:23 --> Router Class Initialized
INFO - 2017-01-19 01:23:23 --> Output Class Initialized
INFO - 2017-01-19 01:23:23 --> Security Class Initialized
DEBUG - 2017-01-19 01:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 01:23:23 --> Input Class Initialized
INFO - 2017-01-19 01:23:23 --> Language Class Initialized
INFO - 2017-01-19 01:23:23 --> Loader Class Initialized
INFO - 2017-01-19 01:23:23 --> Database Driver Class Initialized
INFO - 2017-01-19 01:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 01:23:23 --> Controller Class Initialized
INFO - 2017-01-19 01:23:23 --> Helper loaded: url_helper
DEBUG - 2017-01-19 01:23:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 01:23:25 --> Config Class Initialized
INFO - 2017-01-19 01:23:25 --> Hooks Class Initialized
DEBUG - 2017-01-19 01:23:25 --> UTF-8 Support Enabled
INFO - 2017-01-19 01:23:25 --> Utf8 Class Initialized
INFO - 2017-01-19 01:23:25 --> URI Class Initialized
INFO - 2017-01-19 01:23:25 --> Router Class Initialized
INFO - 2017-01-19 01:23:25 --> Output Class Initialized
INFO - 2017-01-19 01:23:25 --> Security Class Initialized
DEBUG - 2017-01-19 01:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 01:23:25 --> Input Class Initialized
INFO - 2017-01-19 01:23:25 --> Language Class Initialized
INFO - 2017-01-19 01:23:25 --> Loader Class Initialized
INFO - 2017-01-19 01:23:25 --> Database Driver Class Initialized
INFO - 2017-01-19 01:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 01:23:25 --> Controller Class Initialized
INFO - 2017-01-19 01:23:25 --> Helper loaded: date_helper
DEBUG - 2017-01-19 01:23:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 01:23:25 --> Helper loaded: url_helper
INFO - 2017-01-19 01:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 01:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-19 01:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-19 01:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-19 01:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 01:23:25 --> Final output sent to browser
DEBUG - 2017-01-19 01:23:25 --> Total execution time: 0.0412
INFO - 2017-01-19 01:23:25 --> Config Class Initialized
INFO - 2017-01-19 01:23:25 --> Hooks Class Initialized
DEBUG - 2017-01-19 01:23:25 --> UTF-8 Support Enabled
INFO - 2017-01-19 01:23:25 --> Utf8 Class Initialized
INFO - 2017-01-19 01:23:25 --> URI Class Initialized
INFO - 2017-01-19 01:23:25 --> Router Class Initialized
INFO - 2017-01-19 01:23:25 --> Output Class Initialized
INFO - 2017-01-19 01:23:25 --> Security Class Initialized
DEBUG - 2017-01-19 01:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 01:23:25 --> Input Class Initialized
INFO - 2017-01-19 01:23:25 --> Language Class Initialized
INFO - 2017-01-19 01:23:25 --> Loader Class Initialized
INFO - 2017-01-19 01:23:25 --> Database Driver Class Initialized
INFO - 2017-01-19 01:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 01:23:25 --> Controller Class Initialized
INFO - 2017-01-19 01:23:25 --> Helper loaded: url_helper
DEBUG - 2017-01-19 01:23:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 01:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 01:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 01:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 01:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 01:23:25 --> Final output sent to browser
DEBUG - 2017-01-19 01:23:25 --> Total execution time: 0.0135
INFO - 2017-01-19 01:23:48 --> Config Class Initialized
INFO - 2017-01-19 01:23:48 --> Hooks Class Initialized
DEBUG - 2017-01-19 01:23:48 --> UTF-8 Support Enabled
INFO - 2017-01-19 01:23:48 --> Utf8 Class Initialized
INFO - 2017-01-19 01:23:48 --> URI Class Initialized
DEBUG - 2017-01-19 01:23:48 --> No URI present. Default controller set.
INFO - 2017-01-19 01:23:48 --> Router Class Initialized
INFO - 2017-01-19 01:23:48 --> Output Class Initialized
INFO - 2017-01-19 01:23:48 --> Security Class Initialized
DEBUG - 2017-01-19 01:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 01:23:48 --> Input Class Initialized
INFO - 2017-01-19 01:23:48 --> Language Class Initialized
INFO - 2017-01-19 01:23:48 --> Loader Class Initialized
INFO - 2017-01-19 01:23:48 --> Database Driver Class Initialized
INFO - 2017-01-19 01:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 01:23:48 --> Controller Class Initialized
INFO - 2017-01-19 01:23:48 --> Helper loaded: url_helper
DEBUG - 2017-01-19 01:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 01:23:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 01:23:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 01:23:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 01:23:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 01:23:48 --> Final output sent to browser
DEBUG - 2017-01-19 01:23:48 --> Total execution time: 0.0197
INFO - 2017-01-19 01:23:49 --> Config Class Initialized
INFO - 2017-01-19 01:23:49 --> Hooks Class Initialized
DEBUG - 2017-01-19 01:23:49 --> UTF-8 Support Enabled
INFO - 2017-01-19 01:23:49 --> Utf8 Class Initialized
INFO - 2017-01-19 01:23:49 --> URI Class Initialized
INFO - 2017-01-19 01:23:49 --> Router Class Initialized
INFO - 2017-01-19 01:23:49 --> Output Class Initialized
INFO - 2017-01-19 01:23:49 --> Security Class Initialized
DEBUG - 2017-01-19 01:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 01:23:49 --> Input Class Initialized
INFO - 2017-01-19 01:23:49 --> Language Class Initialized
INFO - 2017-01-19 01:23:49 --> Loader Class Initialized
INFO - 2017-01-19 01:23:49 --> Database Driver Class Initialized
INFO - 2017-01-19 01:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 01:23:49 --> Controller Class Initialized
INFO - 2017-01-19 01:23:49 --> Helper loaded: url_helper
DEBUG - 2017-01-19 01:23:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 01:23:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 01:23:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 01:23:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 01:23:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 01:23:49 --> Final output sent to browser
DEBUG - 2017-01-19 01:23:49 --> Total execution time: 0.0131
INFO - 2017-01-19 01:23:59 --> Config Class Initialized
INFO - 2017-01-19 01:23:59 --> Hooks Class Initialized
DEBUG - 2017-01-19 01:23:59 --> UTF-8 Support Enabled
INFO - 2017-01-19 01:23:59 --> Utf8 Class Initialized
INFO - 2017-01-19 01:23:59 --> URI Class Initialized
INFO - 2017-01-19 01:23:59 --> Router Class Initialized
INFO - 2017-01-19 01:23:59 --> Output Class Initialized
INFO - 2017-01-19 01:23:59 --> Security Class Initialized
DEBUG - 2017-01-19 01:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 01:23:59 --> Input Class Initialized
INFO - 2017-01-19 01:23:59 --> Language Class Initialized
INFO - 2017-01-19 01:23:59 --> Loader Class Initialized
INFO - 2017-01-19 01:23:59 --> Database Driver Class Initialized
INFO - 2017-01-19 01:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 01:23:59 --> Controller Class Initialized
INFO - 2017-01-19 01:23:59 --> Helper loaded: url_helper
DEBUG - 2017-01-19 01:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 01:24:00 --> Config Class Initialized
INFO - 2017-01-19 01:24:00 --> Hooks Class Initialized
DEBUG - 2017-01-19 01:24:00 --> UTF-8 Support Enabled
INFO - 2017-01-19 01:24:00 --> Utf8 Class Initialized
INFO - 2017-01-19 01:24:00 --> URI Class Initialized
INFO - 2017-01-19 01:24:00 --> Router Class Initialized
INFO - 2017-01-19 01:24:00 --> Output Class Initialized
INFO - 2017-01-19 01:24:00 --> Security Class Initialized
DEBUG - 2017-01-19 01:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 01:24:00 --> Input Class Initialized
INFO - 2017-01-19 01:24:00 --> Language Class Initialized
INFO - 2017-01-19 01:24:00 --> Loader Class Initialized
INFO - 2017-01-19 01:24:00 --> Database Driver Class Initialized
INFO - 2017-01-19 01:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 01:24:00 --> Controller Class Initialized
INFO - 2017-01-19 01:24:00 --> Helper loaded: date_helper
DEBUG - 2017-01-19 01:24:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 01:24:00 --> Helper loaded: url_helper
INFO - 2017-01-19 01:24:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 01:24:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-19 01:24:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-19 01:24:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-19 01:24:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 01:24:00 --> Final output sent to browser
DEBUG - 2017-01-19 01:24:00 --> Total execution time: 0.0133
INFO - 2017-01-19 01:24:01 --> Config Class Initialized
INFO - 2017-01-19 01:24:01 --> Hooks Class Initialized
DEBUG - 2017-01-19 01:24:01 --> UTF-8 Support Enabled
INFO - 2017-01-19 01:24:01 --> Utf8 Class Initialized
INFO - 2017-01-19 01:24:01 --> URI Class Initialized
INFO - 2017-01-19 01:24:01 --> Router Class Initialized
INFO - 2017-01-19 01:24:01 --> Output Class Initialized
INFO - 2017-01-19 01:24:01 --> Security Class Initialized
DEBUG - 2017-01-19 01:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 01:24:01 --> Input Class Initialized
INFO - 2017-01-19 01:24:01 --> Language Class Initialized
INFO - 2017-01-19 01:24:01 --> Loader Class Initialized
INFO - 2017-01-19 01:24:01 --> Database Driver Class Initialized
INFO - 2017-01-19 01:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 01:24:01 --> Controller Class Initialized
INFO - 2017-01-19 01:24:01 --> Helper loaded: url_helper
DEBUG - 2017-01-19 01:24:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 01:24:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 01:24:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 01:24:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 01:24:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 01:24:01 --> Final output sent to browser
DEBUG - 2017-01-19 01:24:01 --> Total execution time: 0.0136
INFO - 2017-01-19 01:49:08 --> Config Class Initialized
INFO - 2017-01-19 01:49:08 --> Hooks Class Initialized
DEBUG - 2017-01-19 01:49:08 --> UTF-8 Support Enabled
INFO - 2017-01-19 01:49:08 --> Utf8 Class Initialized
INFO - 2017-01-19 01:49:08 --> URI Class Initialized
DEBUG - 2017-01-19 01:49:08 --> No URI present. Default controller set.
INFO - 2017-01-19 01:49:08 --> Router Class Initialized
INFO - 2017-01-19 01:49:08 --> Output Class Initialized
INFO - 2017-01-19 01:49:08 --> Security Class Initialized
DEBUG - 2017-01-19 01:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 01:49:08 --> Input Class Initialized
INFO - 2017-01-19 01:49:08 --> Language Class Initialized
INFO - 2017-01-19 01:49:08 --> Loader Class Initialized
INFO - 2017-01-19 01:49:08 --> Database Driver Class Initialized
INFO - 2017-01-19 01:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 01:49:08 --> Controller Class Initialized
INFO - 2017-01-19 01:49:08 --> Helper loaded: url_helper
DEBUG - 2017-01-19 01:49:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 01:49:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 01:49:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 01:49:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 01:49:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 01:49:08 --> Final output sent to browser
DEBUG - 2017-01-19 01:49:08 --> Total execution time: 0.0141
INFO - 2017-01-19 02:21:53 --> Config Class Initialized
INFO - 2017-01-19 02:21:53 --> Hooks Class Initialized
DEBUG - 2017-01-19 02:21:53 --> UTF-8 Support Enabled
INFO - 2017-01-19 02:21:53 --> Utf8 Class Initialized
INFO - 2017-01-19 02:21:53 --> URI Class Initialized
DEBUG - 2017-01-19 02:21:53 --> No URI present. Default controller set.
INFO - 2017-01-19 02:21:53 --> Router Class Initialized
INFO - 2017-01-19 02:21:53 --> Output Class Initialized
INFO - 2017-01-19 02:21:53 --> Security Class Initialized
DEBUG - 2017-01-19 02:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 02:21:53 --> Input Class Initialized
INFO - 2017-01-19 02:21:53 --> Language Class Initialized
INFO - 2017-01-19 02:21:53 --> Loader Class Initialized
INFO - 2017-01-19 02:21:53 --> Database Driver Class Initialized
INFO - 2017-01-19 02:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 02:21:53 --> Controller Class Initialized
INFO - 2017-01-19 02:21:53 --> Helper loaded: url_helper
DEBUG - 2017-01-19 02:21:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 02:21:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 02:21:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 02:21:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 02:21:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 02:21:53 --> Final output sent to browser
DEBUG - 2017-01-19 02:21:53 --> Total execution time: 0.0134
INFO - 2017-01-19 02:24:33 --> Config Class Initialized
INFO - 2017-01-19 02:24:33 --> Hooks Class Initialized
DEBUG - 2017-01-19 02:24:33 --> UTF-8 Support Enabled
INFO - 2017-01-19 02:24:33 --> Utf8 Class Initialized
INFO - 2017-01-19 02:24:33 --> URI Class Initialized
INFO - 2017-01-19 02:24:33 --> Router Class Initialized
INFO - 2017-01-19 02:24:33 --> Output Class Initialized
INFO - 2017-01-19 02:24:33 --> Security Class Initialized
DEBUG - 2017-01-19 02:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 02:24:33 --> Input Class Initialized
INFO - 2017-01-19 02:24:33 --> Language Class Initialized
INFO - 2017-01-19 02:24:33 --> Loader Class Initialized
INFO - 2017-01-19 02:24:33 --> Database Driver Class Initialized
INFO - 2017-01-19 02:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 02:24:33 --> Controller Class Initialized
INFO - 2017-01-19 02:24:33 --> Helper loaded: url_helper
DEBUG - 2017-01-19 02:24:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 02:24:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 02:24:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 02:24:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 02:24:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 02:24:33 --> Final output sent to browser
DEBUG - 2017-01-19 02:24:33 --> Total execution time: 0.0137
INFO - 2017-01-19 02:24:34 --> Config Class Initialized
INFO - 2017-01-19 02:24:34 --> Hooks Class Initialized
DEBUG - 2017-01-19 02:24:34 --> UTF-8 Support Enabled
INFO - 2017-01-19 02:24:34 --> Utf8 Class Initialized
INFO - 2017-01-19 02:24:34 --> URI Class Initialized
INFO - 2017-01-19 02:24:34 --> Router Class Initialized
INFO - 2017-01-19 02:24:34 --> Output Class Initialized
INFO - 2017-01-19 02:24:34 --> Security Class Initialized
DEBUG - 2017-01-19 02:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 02:24:34 --> Input Class Initialized
INFO - 2017-01-19 02:24:34 --> Language Class Initialized
INFO - 2017-01-19 02:24:34 --> Loader Class Initialized
INFO - 2017-01-19 02:24:34 --> Database Driver Class Initialized
INFO - 2017-01-19 02:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 02:24:34 --> Controller Class Initialized
INFO - 2017-01-19 02:24:34 --> Helper loaded: url_helper
DEBUG - 2017-01-19 02:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 02:24:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 02:24:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 02:24:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 02:24:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 02:24:34 --> Final output sent to browser
DEBUG - 2017-01-19 02:24:34 --> Total execution time: 0.0132
INFO - 2017-01-19 02:24:47 --> Config Class Initialized
INFO - 2017-01-19 02:24:47 --> Hooks Class Initialized
DEBUG - 2017-01-19 02:24:47 --> UTF-8 Support Enabled
INFO - 2017-01-19 02:24:47 --> Utf8 Class Initialized
INFO - 2017-01-19 02:24:47 --> URI Class Initialized
DEBUG - 2017-01-19 02:24:47 --> No URI present. Default controller set.
INFO - 2017-01-19 02:24:47 --> Router Class Initialized
INFO - 2017-01-19 02:24:48 --> Output Class Initialized
INFO - 2017-01-19 02:24:48 --> Security Class Initialized
DEBUG - 2017-01-19 02:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 02:24:48 --> Input Class Initialized
INFO - 2017-01-19 02:24:48 --> Language Class Initialized
INFO - 2017-01-19 02:24:48 --> Loader Class Initialized
INFO - 2017-01-19 02:24:48 --> Database Driver Class Initialized
INFO - 2017-01-19 02:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 02:24:48 --> Controller Class Initialized
INFO - 2017-01-19 02:24:48 --> Helper loaded: url_helper
DEBUG - 2017-01-19 02:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 02:24:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 02:24:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 02:24:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 02:24:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 02:24:48 --> Final output sent to browser
DEBUG - 2017-01-19 02:24:48 --> Total execution time: 0.0152
INFO - 2017-01-19 02:24:49 --> Config Class Initialized
INFO - 2017-01-19 02:24:49 --> Hooks Class Initialized
DEBUG - 2017-01-19 02:24:49 --> UTF-8 Support Enabled
INFO - 2017-01-19 02:24:49 --> Utf8 Class Initialized
INFO - 2017-01-19 02:24:49 --> URI Class Initialized
INFO - 2017-01-19 02:24:49 --> Router Class Initialized
INFO - 2017-01-19 02:24:49 --> Output Class Initialized
INFO - 2017-01-19 02:24:49 --> Security Class Initialized
DEBUG - 2017-01-19 02:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 02:24:49 --> Input Class Initialized
INFO - 2017-01-19 02:24:49 --> Language Class Initialized
INFO - 2017-01-19 02:24:49 --> Loader Class Initialized
INFO - 2017-01-19 02:24:49 --> Database Driver Class Initialized
INFO - 2017-01-19 02:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 02:24:49 --> Controller Class Initialized
INFO - 2017-01-19 02:24:49 --> Helper loaded: url_helper
DEBUG - 2017-01-19 02:24:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 02:24:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 02:24:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 02:24:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 02:24:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 02:24:49 --> Final output sent to browser
DEBUG - 2017-01-19 02:24:49 --> Total execution time: 0.0138
INFO - 2017-01-19 02:25:32 --> Config Class Initialized
INFO - 2017-01-19 02:25:32 --> Hooks Class Initialized
DEBUG - 2017-01-19 02:25:32 --> UTF-8 Support Enabled
INFO - 2017-01-19 02:25:32 --> Utf8 Class Initialized
INFO - 2017-01-19 02:25:32 --> URI Class Initialized
INFO - 2017-01-19 02:25:32 --> Router Class Initialized
INFO - 2017-01-19 02:25:32 --> Output Class Initialized
INFO - 2017-01-19 02:25:32 --> Security Class Initialized
DEBUG - 2017-01-19 02:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 02:25:32 --> Input Class Initialized
INFO - 2017-01-19 02:25:32 --> Language Class Initialized
INFO - 2017-01-19 02:25:32 --> Loader Class Initialized
INFO - 2017-01-19 02:25:32 --> Database Driver Class Initialized
INFO - 2017-01-19 02:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 02:25:32 --> Controller Class Initialized
INFO - 2017-01-19 02:25:32 --> Helper loaded: url_helper
DEBUG - 2017-01-19 02:25:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-19 02:25:33 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-19 02:25:33 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Alina Madera')
INFO - 2017-01-19 02:25:33 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-19 02:25:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-19 02:25:33 --> Config Class Initialized
INFO - 2017-01-19 02:25:33 --> Hooks Class Initialized
DEBUG - 2017-01-19 02:25:33 --> UTF-8 Support Enabled
INFO - 2017-01-19 02:25:33 --> Utf8 Class Initialized
INFO - 2017-01-19 02:25:33 --> URI Class Initialized
INFO - 2017-01-19 02:25:33 --> Router Class Initialized
INFO - 2017-01-19 02:25:33 --> Output Class Initialized
INFO - 2017-01-19 02:25:33 --> Security Class Initialized
DEBUG - 2017-01-19 02:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 02:25:33 --> Input Class Initialized
INFO - 2017-01-19 02:25:33 --> Language Class Initialized
INFO - 2017-01-19 02:25:33 --> Loader Class Initialized
INFO - 2017-01-19 02:25:33 --> Database Driver Class Initialized
INFO - 2017-01-19 02:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 02:25:33 --> Controller Class Initialized
INFO - 2017-01-19 02:25:33 --> Helper loaded: url_helper
DEBUG - 2017-01-19 02:25:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 02:25:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 02:25:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 02:25:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 02:25:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 02:25:33 --> Final output sent to browser
DEBUG - 2017-01-19 02:25:33 --> Total execution time: 0.0145
INFO - 2017-01-19 02:25:38 --> Config Class Initialized
INFO - 2017-01-19 02:25:38 --> Hooks Class Initialized
DEBUG - 2017-01-19 02:25:38 --> UTF-8 Support Enabled
INFO - 2017-01-19 02:25:38 --> Utf8 Class Initialized
INFO - 2017-01-19 02:25:38 --> URI Class Initialized
INFO - 2017-01-19 02:25:38 --> Router Class Initialized
INFO - 2017-01-19 02:25:38 --> Output Class Initialized
INFO - 2017-01-19 02:25:38 --> Security Class Initialized
DEBUG - 2017-01-19 02:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 02:25:38 --> Input Class Initialized
INFO - 2017-01-19 02:25:38 --> Language Class Initialized
INFO - 2017-01-19 02:25:38 --> Loader Class Initialized
INFO - 2017-01-19 02:25:38 --> Database Driver Class Initialized
INFO - 2017-01-19 02:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 02:25:38 --> Controller Class Initialized
INFO - 2017-01-19 02:25:38 --> Helper loaded: url_helper
DEBUG - 2017-01-19 02:25:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-19 02:25:38 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-19 02:25:38 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Alina Madera')
INFO - 2017-01-19 02:25:38 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-19 02:25:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-19 02:25:38 --> Config Class Initialized
INFO - 2017-01-19 02:25:38 --> Hooks Class Initialized
DEBUG - 2017-01-19 02:25:38 --> UTF-8 Support Enabled
INFO - 2017-01-19 02:25:38 --> Utf8 Class Initialized
INFO - 2017-01-19 02:25:38 --> URI Class Initialized
INFO - 2017-01-19 02:25:38 --> Router Class Initialized
INFO - 2017-01-19 02:25:38 --> Output Class Initialized
INFO - 2017-01-19 02:25:38 --> Security Class Initialized
DEBUG - 2017-01-19 02:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 02:25:38 --> Input Class Initialized
INFO - 2017-01-19 02:25:38 --> Language Class Initialized
INFO - 2017-01-19 02:25:38 --> Loader Class Initialized
INFO - 2017-01-19 02:25:38 --> Database Driver Class Initialized
INFO - 2017-01-19 02:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 02:25:38 --> Controller Class Initialized
INFO - 2017-01-19 02:25:38 --> Helper loaded: url_helper
DEBUG - 2017-01-19 02:25:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 02:25:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 02:25:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 02:25:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 02:25:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 02:25:38 --> Final output sent to browser
DEBUG - 2017-01-19 02:25:38 --> Total execution time: 0.0135
INFO - 2017-01-19 02:25:41 --> Config Class Initialized
INFO - 2017-01-19 02:25:41 --> Hooks Class Initialized
DEBUG - 2017-01-19 02:25:41 --> UTF-8 Support Enabled
INFO - 2017-01-19 02:25:41 --> Utf8 Class Initialized
INFO - 2017-01-19 02:25:41 --> URI Class Initialized
INFO - 2017-01-19 02:25:41 --> Router Class Initialized
INFO - 2017-01-19 02:25:41 --> Output Class Initialized
INFO - 2017-01-19 02:25:41 --> Security Class Initialized
DEBUG - 2017-01-19 02:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 02:25:41 --> Input Class Initialized
INFO - 2017-01-19 02:25:41 --> Language Class Initialized
INFO - 2017-01-19 02:25:41 --> Loader Class Initialized
INFO - 2017-01-19 02:25:41 --> Database Driver Class Initialized
INFO - 2017-01-19 02:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 02:25:41 --> Controller Class Initialized
INFO - 2017-01-19 02:25:41 --> Helper loaded: url_helper
DEBUG - 2017-01-19 02:25:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 02:25:41 --> Config Class Initialized
INFO - 2017-01-19 02:25:41 --> Hooks Class Initialized
DEBUG - 2017-01-19 02:25:41 --> UTF-8 Support Enabled
INFO - 2017-01-19 02:25:41 --> Utf8 Class Initialized
INFO - 2017-01-19 02:25:41 --> URI Class Initialized
INFO - 2017-01-19 02:25:41 --> Router Class Initialized
INFO - 2017-01-19 02:25:41 --> Output Class Initialized
INFO - 2017-01-19 02:25:41 --> Security Class Initialized
DEBUG - 2017-01-19 02:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 02:25:41 --> Input Class Initialized
INFO - 2017-01-19 02:25:41 --> Language Class Initialized
INFO - 2017-01-19 02:25:41 --> Loader Class Initialized
ERROR - 2017-01-19 02:25:41 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
INFO - 2017-01-19 02:25:41 --> Database Driver Class Initialized
ERROR - 2017-01-19 02:25:41 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Alina Madera')
INFO - 2017-01-19 02:25:41 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-19 02:25:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-19 02:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 02:25:41 --> Controller Class Initialized
INFO - 2017-01-19 02:25:41 --> Helper loaded: url_helper
DEBUG - 2017-01-19 02:25:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 02:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 02:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 02:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 02:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 02:25:41 --> Final output sent to browser
DEBUG - 2017-01-19 02:25:41 --> Total execution time: 0.0807
INFO - 2017-01-19 02:25:42 --> Config Class Initialized
INFO - 2017-01-19 02:25:42 --> Hooks Class Initialized
DEBUG - 2017-01-19 02:25:42 --> UTF-8 Support Enabled
INFO - 2017-01-19 02:25:42 --> Utf8 Class Initialized
INFO - 2017-01-19 02:25:42 --> URI Class Initialized
INFO - 2017-01-19 02:25:42 --> Router Class Initialized
INFO - 2017-01-19 02:25:42 --> Output Class Initialized
INFO - 2017-01-19 02:25:42 --> Security Class Initialized
DEBUG - 2017-01-19 02:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 02:25:42 --> Input Class Initialized
INFO - 2017-01-19 02:25:42 --> Language Class Initialized
INFO - 2017-01-19 02:25:42 --> Loader Class Initialized
INFO - 2017-01-19 02:25:42 --> Database Driver Class Initialized
INFO - 2017-01-19 02:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 02:25:42 --> Controller Class Initialized
INFO - 2017-01-19 02:25:42 --> Helper loaded: url_helper
DEBUG - 2017-01-19 02:25:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 02:25:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 02:25:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 02:25:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 02:25:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 02:25:42 --> Final output sent to browser
DEBUG - 2017-01-19 02:25:42 --> Total execution time: 0.0136
INFO - 2017-01-19 04:15:31 --> Config Class Initialized
INFO - 2017-01-19 04:15:31 --> Hooks Class Initialized
DEBUG - 2017-01-19 04:15:31 --> UTF-8 Support Enabled
INFO - 2017-01-19 04:15:31 --> Utf8 Class Initialized
INFO - 2017-01-19 04:15:31 --> URI Class Initialized
DEBUG - 2017-01-19 04:15:31 --> No URI present. Default controller set.
INFO - 2017-01-19 04:15:31 --> Router Class Initialized
INFO - 2017-01-19 04:15:31 --> Output Class Initialized
INFO - 2017-01-19 04:15:31 --> Security Class Initialized
DEBUG - 2017-01-19 04:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 04:15:31 --> Input Class Initialized
INFO - 2017-01-19 04:15:31 --> Language Class Initialized
INFO - 2017-01-19 04:15:31 --> Loader Class Initialized
INFO - 2017-01-19 04:15:31 --> Database Driver Class Initialized
INFO - 2017-01-19 04:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 04:15:31 --> Controller Class Initialized
INFO - 2017-01-19 04:15:31 --> Helper loaded: url_helper
DEBUG - 2017-01-19 04:15:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 04:15:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 04:15:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 04:15:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 04:15:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 04:15:31 --> Final output sent to browser
DEBUG - 2017-01-19 04:15:31 --> Total execution time: 0.0137
INFO - 2017-01-19 04:15:38 --> Config Class Initialized
INFO - 2017-01-19 04:15:38 --> Hooks Class Initialized
DEBUG - 2017-01-19 04:15:38 --> UTF-8 Support Enabled
INFO - 2017-01-19 04:15:38 --> Utf8 Class Initialized
INFO - 2017-01-19 04:15:38 --> URI Class Initialized
INFO - 2017-01-19 04:15:38 --> Router Class Initialized
INFO - 2017-01-19 04:15:38 --> Output Class Initialized
INFO - 2017-01-19 04:15:38 --> Security Class Initialized
DEBUG - 2017-01-19 04:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 04:15:38 --> Input Class Initialized
INFO - 2017-01-19 04:15:38 --> Language Class Initialized
INFO - 2017-01-19 04:15:38 --> Loader Class Initialized
INFO - 2017-01-19 04:15:38 --> Database Driver Class Initialized
INFO - 2017-01-19 04:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 04:15:38 --> Controller Class Initialized
INFO - 2017-01-19 04:15:38 --> Helper loaded: url_helper
DEBUG - 2017-01-19 04:15:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 04:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 04:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 04:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 04:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 04:15:38 --> Final output sent to browser
DEBUG - 2017-01-19 04:15:38 --> Total execution time: 0.0138
INFO - 2017-01-19 04:16:19 --> Config Class Initialized
INFO - 2017-01-19 04:16:19 --> Hooks Class Initialized
DEBUG - 2017-01-19 04:16:19 --> UTF-8 Support Enabled
INFO - 2017-01-19 04:16:19 --> Utf8 Class Initialized
INFO - 2017-01-19 04:16:19 --> URI Class Initialized
INFO - 2017-01-19 04:16:19 --> Router Class Initialized
INFO - 2017-01-19 04:16:19 --> Output Class Initialized
INFO - 2017-01-19 04:16:19 --> Security Class Initialized
DEBUG - 2017-01-19 04:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 04:16:19 --> Input Class Initialized
INFO - 2017-01-19 04:16:19 --> Language Class Initialized
INFO - 2017-01-19 04:16:19 --> Loader Class Initialized
INFO - 2017-01-19 04:16:19 --> Database Driver Class Initialized
INFO - 2017-01-19 04:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 04:16:19 --> Controller Class Initialized
INFO - 2017-01-19 04:16:19 --> Helper loaded: url_helper
DEBUG - 2017-01-19 04:16:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 04:16:21 --> Config Class Initialized
INFO - 2017-01-19 04:16:21 --> Hooks Class Initialized
DEBUG - 2017-01-19 04:16:21 --> UTF-8 Support Enabled
INFO - 2017-01-19 04:16:21 --> Utf8 Class Initialized
INFO - 2017-01-19 04:16:21 --> URI Class Initialized
INFO - 2017-01-19 04:16:21 --> Router Class Initialized
INFO - 2017-01-19 04:16:21 --> Output Class Initialized
INFO - 2017-01-19 04:16:21 --> Security Class Initialized
DEBUG - 2017-01-19 04:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 04:16:21 --> Input Class Initialized
INFO - 2017-01-19 04:16:21 --> Language Class Initialized
INFO - 2017-01-19 04:16:21 --> Loader Class Initialized
INFO - 2017-01-19 04:16:21 --> Database Driver Class Initialized
INFO - 2017-01-19 04:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 04:16:21 --> Controller Class Initialized
INFO - 2017-01-19 04:16:21 --> Helper loaded: date_helper
DEBUG - 2017-01-19 04:16:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 04:16:21 --> Helper loaded: url_helper
INFO - 2017-01-19 04:16:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 04:16:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-19 04:16:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-19 04:16:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-19 04:16:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 04:16:21 --> Final output sent to browser
DEBUG - 2017-01-19 04:16:21 --> Total execution time: 0.0143
INFO - 2017-01-19 04:16:22 --> Config Class Initialized
INFO - 2017-01-19 04:16:22 --> Hooks Class Initialized
DEBUG - 2017-01-19 04:16:22 --> UTF-8 Support Enabled
INFO - 2017-01-19 04:16:22 --> Utf8 Class Initialized
INFO - 2017-01-19 04:16:22 --> URI Class Initialized
INFO - 2017-01-19 04:16:22 --> Router Class Initialized
INFO - 2017-01-19 04:16:22 --> Output Class Initialized
INFO - 2017-01-19 04:16:22 --> Security Class Initialized
DEBUG - 2017-01-19 04:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 04:16:22 --> Input Class Initialized
INFO - 2017-01-19 04:16:22 --> Language Class Initialized
INFO - 2017-01-19 04:16:22 --> Loader Class Initialized
INFO - 2017-01-19 04:16:22 --> Database Driver Class Initialized
INFO - 2017-01-19 04:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 04:16:22 --> Controller Class Initialized
INFO - 2017-01-19 04:16:22 --> Helper loaded: url_helper
DEBUG - 2017-01-19 04:16:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 04:16:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 04:16:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 04:16:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 04:16:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 04:16:22 --> Final output sent to browser
DEBUG - 2017-01-19 04:16:22 --> Total execution time: 0.0135
INFO - 2017-01-19 04:16:36 --> Config Class Initialized
INFO - 2017-01-19 04:16:36 --> Hooks Class Initialized
DEBUG - 2017-01-19 04:16:36 --> UTF-8 Support Enabled
INFO - 2017-01-19 04:16:36 --> Utf8 Class Initialized
INFO - 2017-01-19 04:16:36 --> URI Class Initialized
DEBUG - 2017-01-19 04:16:36 --> No URI present. Default controller set.
INFO - 2017-01-19 04:16:36 --> Router Class Initialized
INFO - 2017-01-19 04:16:36 --> Output Class Initialized
INFO - 2017-01-19 04:16:36 --> Security Class Initialized
DEBUG - 2017-01-19 04:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 04:16:36 --> Input Class Initialized
INFO - 2017-01-19 04:16:36 --> Language Class Initialized
INFO - 2017-01-19 04:16:36 --> Loader Class Initialized
INFO - 2017-01-19 04:16:36 --> Database Driver Class Initialized
INFO - 2017-01-19 04:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 04:16:36 --> Controller Class Initialized
INFO - 2017-01-19 04:16:36 --> Helper loaded: url_helper
DEBUG - 2017-01-19 04:16:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 04:16:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 04:16:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 04:16:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 04:16:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 04:16:36 --> Final output sent to browser
DEBUG - 2017-01-19 04:16:36 --> Total execution time: 0.0151
INFO - 2017-01-19 04:16:38 --> Config Class Initialized
INFO - 2017-01-19 04:16:38 --> Hooks Class Initialized
DEBUG - 2017-01-19 04:16:38 --> UTF-8 Support Enabled
INFO - 2017-01-19 04:16:38 --> Utf8 Class Initialized
INFO - 2017-01-19 04:16:38 --> URI Class Initialized
INFO - 2017-01-19 04:16:38 --> Router Class Initialized
INFO - 2017-01-19 04:16:38 --> Output Class Initialized
INFO - 2017-01-19 04:16:38 --> Security Class Initialized
DEBUG - 2017-01-19 04:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 04:16:38 --> Input Class Initialized
INFO - 2017-01-19 04:16:38 --> Language Class Initialized
INFO - 2017-01-19 04:16:38 --> Loader Class Initialized
INFO - 2017-01-19 04:16:38 --> Database Driver Class Initialized
INFO - 2017-01-19 04:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 04:16:38 --> Controller Class Initialized
INFO - 2017-01-19 04:16:38 --> Helper loaded: url_helper
DEBUG - 2017-01-19 04:16:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 04:16:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 04:16:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 04:16:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 04:16:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 04:16:38 --> Final output sent to browser
DEBUG - 2017-01-19 04:16:38 --> Total execution time: 0.0134
INFO - 2017-01-19 04:17:33 --> Config Class Initialized
INFO - 2017-01-19 04:17:33 --> Hooks Class Initialized
DEBUG - 2017-01-19 04:17:33 --> UTF-8 Support Enabled
INFO - 2017-01-19 04:17:33 --> Utf8 Class Initialized
INFO - 2017-01-19 04:17:33 --> URI Class Initialized
INFO - 2017-01-19 04:17:33 --> Router Class Initialized
INFO - 2017-01-19 04:17:33 --> Output Class Initialized
INFO - 2017-01-19 04:17:33 --> Security Class Initialized
DEBUG - 2017-01-19 04:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 04:17:33 --> Input Class Initialized
INFO - 2017-01-19 04:17:33 --> Language Class Initialized
INFO - 2017-01-19 04:17:33 --> Loader Class Initialized
INFO - 2017-01-19 04:17:33 --> Database Driver Class Initialized
INFO - 2017-01-19 04:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 04:17:33 --> Controller Class Initialized
INFO - 2017-01-19 04:17:33 --> Helper loaded: date_helper
DEBUG - 2017-01-19 04:17:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 04:17:33 --> Helper loaded: url_helper
INFO - 2017-01-19 04:17:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 04:17:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-19 04:17:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-19 04:17:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-19 04:17:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 04:17:33 --> Final output sent to browser
DEBUG - 2017-01-19 04:17:33 --> Total execution time: 0.0134
INFO - 2017-01-19 04:17:35 --> Config Class Initialized
INFO - 2017-01-19 04:17:35 --> Hooks Class Initialized
DEBUG - 2017-01-19 04:17:35 --> UTF-8 Support Enabled
INFO - 2017-01-19 04:17:35 --> Utf8 Class Initialized
INFO - 2017-01-19 04:17:35 --> URI Class Initialized
INFO - 2017-01-19 04:17:35 --> Router Class Initialized
INFO - 2017-01-19 04:17:35 --> Output Class Initialized
INFO - 2017-01-19 04:17:35 --> Security Class Initialized
DEBUG - 2017-01-19 04:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 04:17:35 --> Input Class Initialized
INFO - 2017-01-19 04:17:35 --> Language Class Initialized
INFO - 2017-01-19 04:17:35 --> Loader Class Initialized
INFO - 2017-01-19 04:17:35 --> Database Driver Class Initialized
INFO - 2017-01-19 04:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 04:17:35 --> Controller Class Initialized
INFO - 2017-01-19 04:17:35 --> Helper loaded: url_helper
DEBUG - 2017-01-19 04:17:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 04:17:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 04:17:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 04:17:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 04:17:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 04:17:35 --> Final output sent to browser
DEBUG - 2017-01-19 04:17:35 --> Total execution time: 0.0135
INFO - 2017-01-19 05:56:06 --> Config Class Initialized
INFO - 2017-01-19 05:56:06 --> Hooks Class Initialized
DEBUG - 2017-01-19 05:56:06 --> UTF-8 Support Enabled
INFO - 2017-01-19 05:56:06 --> Utf8 Class Initialized
INFO - 2017-01-19 05:56:06 --> URI Class Initialized
DEBUG - 2017-01-19 05:56:06 --> No URI present. Default controller set.
INFO - 2017-01-19 05:56:06 --> Router Class Initialized
INFO - 2017-01-19 05:56:06 --> Output Class Initialized
INFO - 2017-01-19 05:56:06 --> Security Class Initialized
DEBUG - 2017-01-19 05:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 05:56:06 --> Input Class Initialized
INFO - 2017-01-19 05:56:06 --> Language Class Initialized
INFO - 2017-01-19 05:56:06 --> Loader Class Initialized
INFO - 2017-01-19 05:56:06 --> Database Driver Class Initialized
INFO - 2017-01-19 05:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 05:56:06 --> Controller Class Initialized
INFO - 2017-01-19 05:56:06 --> Helper loaded: url_helper
DEBUG - 2017-01-19 05:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 05:56:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 05:56:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 05:56:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 05:56:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 05:56:06 --> Final output sent to browser
DEBUG - 2017-01-19 05:56:06 --> Total execution time: 0.0133
INFO - 2017-01-19 05:56:18 --> Config Class Initialized
INFO - 2017-01-19 05:56:18 --> Hooks Class Initialized
DEBUG - 2017-01-19 05:56:18 --> UTF-8 Support Enabled
INFO - 2017-01-19 05:56:18 --> Utf8 Class Initialized
INFO - 2017-01-19 05:56:18 --> URI Class Initialized
INFO - 2017-01-19 05:56:18 --> Router Class Initialized
INFO - 2017-01-19 05:56:18 --> Output Class Initialized
INFO - 2017-01-19 05:56:18 --> Security Class Initialized
DEBUG - 2017-01-19 05:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 05:56:18 --> Input Class Initialized
INFO - 2017-01-19 05:56:18 --> Language Class Initialized
INFO - 2017-01-19 05:56:18 --> Loader Class Initialized
INFO - 2017-01-19 05:56:18 --> Database Driver Class Initialized
INFO - 2017-01-19 05:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 05:56:18 --> Controller Class Initialized
INFO - 2017-01-19 05:56:18 --> Helper loaded: url_helper
DEBUG - 2017-01-19 05:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 05:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 05:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 05:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 05:56:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 05:56:18 --> Final output sent to browser
DEBUG - 2017-01-19 05:56:18 --> Total execution time: 0.0132
INFO - 2017-01-19 05:57:44 --> Config Class Initialized
INFO - 2017-01-19 05:57:44 --> Hooks Class Initialized
DEBUG - 2017-01-19 05:57:44 --> UTF-8 Support Enabled
INFO - 2017-01-19 05:57:44 --> Utf8 Class Initialized
INFO - 2017-01-19 05:57:44 --> URI Class Initialized
INFO - 2017-01-19 05:57:44 --> Router Class Initialized
INFO - 2017-01-19 05:57:44 --> Output Class Initialized
INFO - 2017-01-19 05:57:44 --> Security Class Initialized
DEBUG - 2017-01-19 05:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 05:57:44 --> Input Class Initialized
INFO - 2017-01-19 05:57:44 --> Language Class Initialized
INFO - 2017-01-19 05:57:44 --> Loader Class Initialized
INFO - 2017-01-19 05:57:44 --> Database Driver Class Initialized
INFO - 2017-01-19 05:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 05:57:44 --> Controller Class Initialized
INFO - 2017-01-19 05:57:44 --> Helper loaded: url_helper
DEBUG - 2017-01-19 05:57:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 05:57:45 --> Config Class Initialized
INFO - 2017-01-19 05:57:45 --> Hooks Class Initialized
DEBUG - 2017-01-19 05:57:45 --> UTF-8 Support Enabled
INFO - 2017-01-19 05:57:45 --> Utf8 Class Initialized
INFO - 2017-01-19 05:57:45 --> URI Class Initialized
INFO - 2017-01-19 05:57:45 --> Router Class Initialized
INFO - 2017-01-19 05:57:45 --> Output Class Initialized
INFO - 2017-01-19 05:57:45 --> Security Class Initialized
DEBUG - 2017-01-19 05:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 05:57:45 --> Input Class Initialized
INFO - 2017-01-19 05:57:45 --> Language Class Initialized
INFO - 2017-01-19 05:57:45 --> Loader Class Initialized
INFO - 2017-01-19 05:57:45 --> Database Driver Class Initialized
INFO - 2017-01-19 05:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 05:57:45 --> Controller Class Initialized
INFO - 2017-01-19 05:57:45 --> Helper loaded: date_helper
DEBUG - 2017-01-19 05:57:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 05:57:45 --> Helper loaded: url_helper
INFO - 2017-01-19 05:57:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 05:57:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-19 05:57:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-19 05:57:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-19 05:57:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 05:57:45 --> Final output sent to browser
DEBUG - 2017-01-19 05:57:45 --> Total execution time: 0.0361
INFO - 2017-01-19 05:57:46 --> Config Class Initialized
INFO - 2017-01-19 05:57:46 --> Hooks Class Initialized
DEBUG - 2017-01-19 05:57:46 --> UTF-8 Support Enabled
INFO - 2017-01-19 05:57:46 --> Utf8 Class Initialized
INFO - 2017-01-19 05:57:46 --> URI Class Initialized
INFO - 2017-01-19 05:57:46 --> Router Class Initialized
INFO - 2017-01-19 05:57:46 --> Output Class Initialized
INFO - 2017-01-19 05:57:46 --> Security Class Initialized
DEBUG - 2017-01-19 05:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 05:57:46 --> Input Class Initialized
INFO - 2017-01-19 05:57:46 --> Language Class Initialized
INFO - 2017-01-19 05:57:46 --> Loader Class Initialized
INFO - 2017-01-19 05:57:46 --> Database Driver Class Initialized
INFO - 2017-01-19 05:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 05:57:46 --> Controller Class Initialized
INFO - 2017-01-19 05:57:46 --> Helper loaded: url_helper
DEBUG - 2017-01-19 05:57:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 05:57:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 05:57:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 05:57:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 05:57:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 05:57:46 --> Final output sent to browser
DEBUG - 2017-01-19 05:57:46 --> Total execution time: 0.0132
INFO - 2017-01-19 05:57:59 --> Config Class Initialized
INFO - 2017-01-19 05:57:59 --> Hooks Class Initialized
DEBUG - 2017-01-19 05:57:59 --> UTF-8 Support Enabled
INFO - 2017-01-19 05:57:59 --> Utf8 Class Initialized
INFO - 2017-01-19 05:57:59 --> URI Class Initialized
DEBUG - 2017-01-19 05:57:59 --> No URI present. Default controller set.
INFO - 2017-01-19 05:57:59 --> Router Class Initialized
INFO - 2017-01-19 05:57:59 --> Output Class Initialized
INFO - 2017-01-19 05:57:59 --> Security Class Initialized
DEBUG - 2017-01-19 05:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 05:57:59 --> Input Class Initialized
INFO - 2017-01-19 05:57:59 --> Language Class Initialized
INFO - 2017-01-19 05:57:59 --> Loader Class Initialized
INFO - 2017-01-19 05:57:59 --> Database Driver Class Initialized
INFO - 2017-01-19 05:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 05:57:59 --> Controller Class Initialized
INFO - 2017-01-19 05:57:59 --> Helper loaded: url_helper
DEBUG - 2017-01-19 05:57:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 05:57:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 05:57:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 05:57:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 05:57:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 05:57:59 --> Final output sent to browser
DEBUG - 2017-01-19 05:57:59 --> Total execution time: 0.0136
INFO - 2017-01-19 05:58:02 --> Config Class Initialized
INFO - 2017-01-19 05:58:02 --> Hooks Class Initialized
DEBUG - 2017-01-19 05:58:02 --> UTF-8 Support Enabled
INFO - 2017-01-19 05:58:02 --> Utf8 Class Initialized
INFO - 2017-01-19 05:58:02 --> URI Class Initialized
INFO - 2017-01-19 05:58:02 --> Router Class Initialized
INFO - 2017-01-19 05:58:02 --> Output Class Initialized
INFO - 2017-01-19 05:58:02 --> Security Class Initialized
DEBUG - 2017-01-19 05:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 05:58:02 --> Input Class Initialized
INFO - 2017-01-19 05:58:02 --> Language Class Initialized
INFO - 2017-01-19 05:58:02 --> Loader Class Initialized
INFO - 2017-01-19 05:58:02 --> Database Driver Class Initialized
INFO - 2017-01-19 05:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 05:58:02 --> Controller Class Initialized
INFO - 2017-01-19 05:58:02 --> Helper loaded: url_helper
DEBUG - 2017-01-19 05:58:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 05:58:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 05:58:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 05:58:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 05:58:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 05:58:02 --> Final output sent to browser
DEBUG - 2017-01-19 05:58:02 --> Total execution time: 0.0140
INFO - 2017-01-19 05:59:07 --> Config Class Initialized
INFO - 2017-01-19 05:59:07 --> Hooks Class Initialized
DEBUG - 2017-01-19 05:59:07 --> UTF-8 Support Enabled
INFO - 2017-01-19 05:59:07 --> Utf8 Class Initialized
INFO - 2017-01-19 05:59:07 --> URI Class Initialized
INFO - 2017-01-19 05:59:07 --> Router Class Initialized
INFO - 2017-01-19 05:59:07 --> Output Class Initialized
INFO - 2017-01-19 05:59:07 --> Security Class Initialized
DEBUG - 2017-01-19 05:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 05:59:07 --> Input Class Initialized
INFO - 2017-01-19 05:59:07 --> Language Class Initialized
INFO - 2017-01-19 05:59:07 --> Loader Class Initialized
INFO - 2017-01-19 05:59:07 --> Database Driver Class Initialized
INFO - 2017-01-19 05:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 05:59:07 --> Controller Class Initialized
INFO - 2017-01-19 05:59:07 --> Helper loaded: url_helper
DEBUG - 2017-01-19 05:59:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 05:59:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 05:59:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 05:59:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 05:59:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 05:59:07 --> Final output sent to browser
DEBUG - 2017-01-19 05:59:07 --> Total execution time: 0.0140
INFO - 2017-01-19 05:59:11 --> Config Class Initialized
INFO - 2017-01-19 05:59:11 --> Hooks Class Initialized
DEBUG - 2017-01-19 05:59:11 --> UTF-8 Support Enabled
INFO - 2017-01-19 05:59:11 --> Utf8 Class Initialized
INFO - 2017-01-19 05:59:11 --> URI Class Initialized
INFO - 2017-01-19 05:59:11 --> Router Class Initialized
INFO - 2017-01-19 05:59:11 --> Output Class Initialized
INFO - 2017-01-19 05:59:11 --> Security Class Initialized
DEBUG - 2017-01-19 05:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 05:59:11 --> Input Class Initialized
INFO - 2017-01-19 05:59:11 --> Language Class Initialized
INFO - 2017-01-19 05:59:11 --> Loader Class Initialized
INFO - 2017-01-19 05:59:11 --> Database Driver Class Initialized
INFO - 2017-01-19 05:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 05:59:11 --> Controller Class Initialized
INFO - 2017-01-19 05:59:11 --> Helper loaded: url_helper
DEBUG - 2017-01-19 05:59:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 05:59:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 05:59:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 05:59:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 05:59:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 05:59:11 --> Final output sent to browser
DEBUG - 2017-01-19 05:59:11 --> Total execution time: 0.0131
INFO - 2017-01-19 05:59:39 --> Config Class Initialized
INFO - 2017-01-19 05:59:39 --> Hooks Class Initialized
DEBUG - 2017-01-19 05:59:39 --> UTF-8 Support Enabled
INFO - 2017-01-19 05:59:39 --> Utf8 Class Initialized
INFO - 2017-01-19 05:59:39 --> URI Class Initialized
INFO - 2017-01-19 05:59:39 --> Router Class Initialized
INFO - 2017-01-19 05:59:39 --> Output Class Initialized
INFO - 2017-01-19 05:59:39 --> Security Class Initialized
DEBUG - 2017-01-19 05:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 05:59:39 --> Input Class Initialized
INFO - 2017-01-19 05:59:39 --> Language Class Initialized
INFO - 2017-01-19 05:59:39 --> Loader Class Initialized
INFO - 2017-01-19 05:59:39 --> Database Driver Class Initialized
INFO - 2017-01-19 05:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 05:59:39 --> Controller Class Initialized
INFO - 2017-01-19 05:59:39 --> Helper loaded: url_helper
DEBUG - 2017-01-19 05:59:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 05:59:39 --> Config Class Initialized
INFO - 2017-01-19 05:59:39 --> Hooks Class Initialized
DEBUG - 2017-01-19 05:59:39 --> UTF-8 Support Enabled
INFO - 2017-01-19 05:59:39 --> Utf8 Class Initialized
INFO - 2017-01-19 05:59:39 --> URI Class Initialized
INFO - 2017-01-19 05:59:39 --> Router Class Initialized
INFO - 2017-01-19 05:59:39 --> Output Class Initialized
INFO - 2017-01-19 05:59:39 --> Security Class Initialized
DEBUG - 2017-01-19 05:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 05:59:39 --> Input Class Initialized
INFO - 2017-01-19 05:59:39 --> Language Class Initialized
INFO - 2017-01-19 05:59:39 --> Loader Class Initialized
INFO - 2017-01-19 05:59:39 --> Database Driver Class Initialized
INFO - 2017-01-19 05:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 05:59:39 --> Controller Class Initialized
INFO - 2017-01-19 05:59:39 --> Helper loaded: date_helper
DEBUG - 2017-01-19 05:59:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 05:59:39 --> Helper loaded: url_helper
INFO - 2017-01-19 05:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 05:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-19 05:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-19 05:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-19 05:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 05:59:39 --> Final output sent to browser
DEBUG - 2017-01-19 05:59:39 --> Total execution time: 0.0132
INFO - 2017-01-19 05:59:41 --> Config Class Initialized
INFO - 2017-01-19 05:59:41 --> Hooks Class Initialized
DEBUG - 2017-01-19 05:59:41 --> UTF-8 Support Enabled
INFO - 2017-01-19 05:59:41 --> Utf8 Class Initialized
INFO - 2017-01-19 05:59:41 --> URI Class Initialized
INFO - 2017-01-19 05:59:41 --> Router Class Initialized
INFO - 2017-01-19 05:59:41 --> Output Class Initialized
INFO - 2017-01-19 05:59:41 --> Security Class Initialized
DEBUG - 2017-01-19 05:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 05:59:41 --> Input Class Initialized
INFO - 2017-01-19 05:59:41 --> Language Class Initialized
INFO - 2017-01-19 05:59:41 --> Loader Class Initialized
INFO - 2017-01-19 05:59:41 --> Database Driver Class Initialized
INFO - 2017-01-19 05:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 05:59:41 --> Controller Class Initialized
INFO - 2017-01-19 05:59:41 --> Helper loaded: url_helper
DEBUG - 2017-01-19 05:59:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 05:59:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 05:59:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 05:59:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 05:59:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 05:59:41 --> Final output sent to browser
DEBUG - 2017-01-19 05:59:41 --> Total execution time: 0.0137
INFO - 2017-01-19 05:59:58 --> Config Class Initialized
INFO - 2017-01-19 05:59:58 --> Hooks Class Initialized
DEBUG - 2017-01-19 05:59:58 --> UTF-8 Support Enabled
INFO - 2017-01-19 05:59:58 --> Utf8 Class Initialized
INFO - 2017-01-19 05:59:58 --> URI Class Initialized
DEBUG - 2017-01-19 05:59:58 --> No URI present. Default controller set.
INFO - 2017-01-19 05:59:58 --> Router Class Initialized
INFO - 2017-01-19 05:59:58 --> Output Class Initialized
INFO - 2017-01-19 05:59:58 --> Security Class Initialized
DEBUG - 2017-01-19 05:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 05:59:58 --> Input Class Initialized
INFO - 2017-01-19 05:59:58 --> Language Class Initialized
INFO - 2017-01-19 05:59:58 --> Loader Class Initialized
INFO - 2017-01-19 05:59:58 --> Database Driver Class Initialized
INFO - 2017-01-19 05:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 05:59:58 --> Controller Class Initialized
INFO - 2017-01-19 05:59:58 --> Helper loaded: url_helper
DEBUG - 2017-01-19 05:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 05:59:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 05:59:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 05:59:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 05:59:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 05:59:58 --> Final output sent to browser
DEBUG - 2017-01-19 05:59:58 --> Total execution time: 0.0136
INFO - 2017-01-19 05:59:59 --> Config Class Initialized
INFO - 2017-01-19 05:59:59 --> Hooks Class Initialized
DEBUG - 2017-01-19 05:59:59 --> UTF-8 Support Enabled
INFO - 2017-01-19 05:59:59 --> Utf8 Class Initialized
INFO - 2017-01-19 05:59:59 --> URI Class Initialized
INFO - 2017-01-19 05:59:59 --> Router Class Initialized
INFO - 2017-01-19 05:59:59 --> Output Class Initialized
INFO - 2017-01-19 05:59:59 --> Security Class Initialized
DEBUG - 2017-01-19 05:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 05:59:59 --> Input Class Initialized
INFO - 2017-01-19 05:59:59 --> Language Class Initialized
INFO - 2017-01-19 05:59:59 --> Loader Class Initialized
INFO - 2017-01-19 05:59:59 --> Database Driver Class Initialized
INFO - 2017-01-19 05:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 05:59:59 --> Controller Class Initialized
INFO - 2017-01-19 05:59:59 --> Helper loaded: url_helper
DEBUG - 2017-01-19 05:59:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 05:59:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 05:59:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 05:59:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 05:59:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 05:59:59 --> Final output sent to browser
DEBUG - 2017-01-19 05:59:59 --> Total execution time: 0.0131
INFO - 2017-01-19 06:00:37 --> Config Class Initialized
INFO - 2017-01-19 06:00:37 --> Hooks Class Initialized
DEBUG - 2017-01-19 06:00:37 --> UTF-8 Support Enabled
INFO - 2017-01-19 06:00:37 --> Utf8 Class Initialized
INFO - 2017-01-19 06:00:37 --> URI Class Initialized
INFO - 2017-01-19 06:00:37 --> Router Class Initialized
INFO - 2017-01-19 06:00:37 --> Output Class Initialized
INFO - 2017-01-19 06:00:37 --> Security Class Initialized
DEBUG - 2017-01-19 06:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 06:00:37 --> Input Class Initialized
INFO - 2017-01-19 06:00:37 --> Language Class Initialized
INFO - 2017-01-19 06:00:37 --> Loader Class Initialized
INFO - 2017-01-19 06:00:37 --> Database Driver Class Initialized
INFO - 2017-01-19 06:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 06:00:37 --> Controller Class Initialized
INFO - 2017-01-19 06:00:37 --> Helper loaded: date_helper
DEBUG - 2017-01-19 06:00:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 06:00:37 --> Helper loaded: url_helper
INFO - 2017-01-19 06:00:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 06:00:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-19 06:00:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-19 06:00:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-19 06:00:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 06:00:37 --> Final output sent to browser
DEBUG - 2017-01-19 06:00:37 --> Total execution time: 0.0137
INFO - 2017-01-19 06:00:38 --> Config Class Initialized
INFO - 2017-01-19 06:00:38 --> Hooks Class Initialized
DEBUG - 2017-01-19 06:00:38 --> UTF-8 Support Enabled
INFO - 2017-01-19 06:00:38 --> Utf8 Class Initialized
INFO - 2017-01-19 06:00:38 --> URI Class Initialized
INFO - 2017-01-19 06:00:38 --> Router Class Initialized
INFO - 2017-01-19 06:00:38 --> Output Class Initialized
INFO - 2017-01-19 06:00:38 --> Security Class Initialized
DEBUG - 2017-01-19 06:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 06:00:38 --> Input Class Initialized
INFO - 2017-01-19 06:00:38 --> Language Class Initialized
INFO - 2017-01-19 06:00:38 --> Loader Class Initialized
INFO - 2017-01-19 06:00:38 --> Database Driver Class Initialized
INFO - 2017-01-19 06:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 06:00:38 --> Controller Class Initialized
INFO - 2017-01-19 06:00:38 --> Helper loaded: url_helper
DEBUG - 2017-01-19 06:00:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 06:00:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 06:00:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 06:00:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 06:00:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 06:00:38 --> Final output sent to browser
DEBUG - 2017-01-19 06:00:38 --> Total execution time: 0.0136
INFO - 2017-01-19 11:38:19 --> Config Class Initialized
INFO - 2017-01-19 11:38:19 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:38:19 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:38:19 --> Utf8 Class Initialized
INFO - 2017-01-19 11:38:19 --> URI Class Initialized
INFO - 2017-01-19 11:38:19 --> Router Class Initialized
INFO - 2017-01-19 11:38:19 --> Output Class Initialized
INFO - 2017-01-19 11:38:19 --> Security Class Initialized
DEBUG - 2017-01-19 11:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:38:19 --> Input Class Initialized
INFO - 2017-01-19 11:38:19 --> Language Class Initialized
INFO - 2017-01-19 11:38:19 --> Loader Class Initialized
INFO - 2017-01-19 11:38:19 --> Database Driver Class Initialized
INFO - 2017-01-19 11:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:38:19 --> Controller Class Initialized
INFO - 2017-01-19 11:38:19 --> Helper loaded: url_helper
DEBUG - 2017-01-19 11:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 11:38:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 11:38:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 11:38:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 11:38:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 11:38:19 --> Final output sent to browser
DEBUG - 2017-01-19 11:38:19 --> Total execution time: 0.0621
INFO - 2017-01-19 11:38:20 --> Config Class Initialized
INFO - 2017-01-19 11:38:20 --> Hooks Class Initialized
DEBUG - 2017-01-19 11:38:20 --> UTF-8 Support Enabled
INFO - 2017-01-19 11:38:20 --> Utf8 Class Initialized
INFO - 2017-01-19 11:38:20 --> URI Class Initialized
DEBUG - 2017-01-19 11:38:20 --> No URI present. Default controller set.
INFO - 2017-01-19 11:38:20 --> Router Class Initialized
INFO - 2017-01-19 11:38:20 --> Output Class Initialized
INFO - 2017-01-19 11:38:20 --> Security Class Initialized
DEBUG - 2017-01-19 11:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 11:38:20 --> Input Class Initialized
INFO - 2017-01-19 11:38:20 --> Language Class Initialized
INFO - 2017-01-19 11:38:20 --> Loader Class Initialized
INFO - 2017-01-19 11:38:20 --> Database Driver Class Initialized
INFO - 2017-01-19 11:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 11:38:20 --> Controller Class Initialized
INFO - 2017-01-19 11:38:20 --> Helper loaded: url_helper
DEBUG - 2017-01-19 11:38:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 11:38:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 11:38:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 11:38:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 11:38:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 11:38:20 --> Final output sent to browser
DEBUG - 2017-01-19 11:38:20 --> Total execution time: 0.0131
INFO - 2017-01-19 14:05:17 --> Config Class Initialized
INFO - 2017-01-19 14:05:17 --> Hooks Class Initialized
DEBUG - 2017-01-19 14:05:17 --> UTF-8 Support Enabled
INFO - 2017-01-19 14:05:17 --> Utf8 Class Initialized
INFO - 2017-01-19 14:05:18 --> URI Class Initialized
DEBUG - 2017-01-19 14:05:18 --> No URI present. Default controller set.
INFO - 2017-01-19 14:05:18 --> Router Class Initialized
INFO - 2017-01-19 14:05:18 --> Output Class Initialized
INFO - 2017-01-19 14:05:18 --> Security Class Initialized
DEBUG - 2017-01-19 14:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 14:05:18 --> Input Class Initialized
INFO - 2017-01-19 14:05:18 --> Language Class Initialized
INFO - 2017-01-19 14:05:18 --> Loader Class Initialized
INFO - 2017-01-19 14:05:18 --> Database Driver Class Initialized
INFO - 2017-01-19 14:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 14:05:18 --> Controller Class Initialized
INFO - 2017-01-19 14:05:18 --> Helper loaded: url_helper
DEBUG - 2017-01-19 14:05:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 14:05:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 14:05:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 14:05:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 14:05:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 14:05:18 --> Final output sent to browser
DEBUG - 2017-01-19 14:05:18 --> Total execution time: 0.2199
INFO - 2017-01-19 14:05:22 --> Config Class Initialized
INFO - 2017-01-19 14:05:22 --> Hooks Class Initialized
DEBUG - 2017-01-19 14:05:22 --> UTF-8 Support Enabled
INFO - 2017-01-19 14:05:22 --> Utf8 Class Initialized
INFO - 2017-01-19 14:05:22 --> URI Class Initialized
INFO - 2017-01-19 14:05:22 --> Router Class Initialized
INFO - 2017-01-19 14:05:22 --> Output Class Initialized
INFO - 2017-01-19 14:05:22 --> Security Class Initialized
DEBUG - 2017-01-19 14:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 14:05:22 --> Input Class Initialized
INFO - 2017-01-19 14:05:22 --> Language Class Initialized
INFO - 2017-01-19 14:05:22 --> Loader Class Initialized
INFO - 2017-01-19 14:05:22 --> Database Driver Class Initialized
INFO - 2017-01-19 14:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 14:05:22 --> Controller Class Initialized
INFO - 2017-01-19 14:05:22 --> Helper loaded: url_helper
DEBUG - 2017-01-19 14:05:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 14:05:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 14:05:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 14:05:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 14:05:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 14:05:22 --> Final output sent to browser
DEBUG - 2017-01-19 14:05:22 --> Total execution time: 0.0133
INFO - 2017-01-19 14:37:49 --> Config Class Initialized
INFO - 2017-01-19 14:37:49 --> Hooks Class Initialized
DEBUG - 2017-01-19 14:37:49 --> UTF-8 Support Enabled
INFO - 2017-01-19 14:37:49 --> Utf8 Class Initialized
INFO - 2017-01-19 14:37:49 --> URI Class Initialized
INFO - 2017-01-19 14:37:49 --> Router Class Initialized
INFO - 2017-01-19 14:37:49 --> Output Class Initialized
INFO - 2017-01-19 14:37:49 --> Security Class Initialized
DEBUG - 2017-01-19 14:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 14:37:49 --> Input Class Initialized
INFO - 2017-01-19 14:37:49 --> Language Class Initialized
INFO - 2017-01-19 14:37:49 --> Loader Class Initialized
INFO - 2017-01-19 14:37:49 --> Database Driver Class Initialized
INFO - 2017-01-19 14:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 14:37:49 --> Controller Class Initialized
INFO - 2017-01-19 14:37:49 --> Helper loaded: date_helper
DEBUG - 2017-01-19 14:37:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 14:37:49 --> Helper loaded: url_helper
INFO - 2017-01-19 14:37:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 14:37:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-19 14:37:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-19 14:37:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-19 14:37:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 14:37:49 --> Final output sent to browser
DEBUG - 2017-01-19 14:37:49 --> Total execution time: 0.0212
INFO - 2017-01-19 14:37:54 --> Config Class Initialized
INFO - 2017-01-19 14:37:54 --> Hooks Class Initialized
DEBUG - 2017-01-19 14:37:54 --> UTF-8 Support Enabled
INFO - 2017-01-19 14:37:54 --> Utf8 Class Initialized
INFO - 2017-01-19 14:37:54 --> URI Class Initialized
INFO - 2017-01-19 14:37:54 --> Router Class Initialized
INFO - 2017-01-19 14:37:54 --> Output Class Initialized
INFO - 2017-01-19 14:37:54 --> Security Class Initialized
DEBUG - 2017-01-19 14:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 14:37:54 --> Input Class Initialized
INFO - 2017-01-19 14:37:54 --> Language Class Initialized
INFO - 2017-01-19 14:37:54 --> Loader Class Initialized
INFO - 2017-01-19 14:37:54 --> Database Driver Class Initialized
INFO - 2017-01-19 14:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 14:37:54 --> Controller Class Initialized
INFO - 2017-01-19 14:37:54 --> Helper loaded: url_helper
DEBUG - 2017-01-19 14:37:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 14:37:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 14:37:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 14:37:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 14:37:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 14:37:54 --> Final output sent to browser
DEBUG - 2017-01-19 14:37:54 --> Total execution time: 0.0177
INFO - 2017-01-19 15:17:56 --> Config Class Initialized
INFO - 2017-01-19 15:17:56 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:17:56 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:17:56 --> Utf8 Class Initialized
INFO - 2017-01-19 15:17:56 --> URI Class Initialized
DEBUG - 2017-01-19 15:17:56 --> No URI present. Default controller set.
INFO - 2017-01-19 15:17:56 --> Router Class Initialized
INFO - 2017-01-19 15:17:56 --> Output Class Initialized
INFO - 2017-01-19 15:17:56 --> Security Class Initialized
DEBUG - 2017-01-19 15:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:17:56 --> Input Class Initialized
INFO - 2017-01-19 15:17:56 --> Language Class Initialized
INFO - 2017-01-19 15:17:56 --> Loader Class Initialized
INFO - 2017-01-19 15:17:56 --> Database Driver Class Initialized
INFO - 2017-01-19 15:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:17:56 --> Controller Class Initialized
INFO - 2017-01-19 15:17:56 --> Helper loaded: url_helper
DEBUG - 2017-01-19 15:17:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 15:17:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 15:17:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 15:17:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 15:17:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 15:17:56 --> Final output sent to browser
DEBUG - 2017-01-19 15:17:56 --> Total execution time: 0.0135
INFO - 2017-01-19 15:18:49 --> Config Class Initialized
INFO - 2017-01-19 15:18:49 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:18:49 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:18:49 --> Utf8 Class Initialized
INFO - 2017-01-19 15:18:49 --> URI Class Initialized
INFO - 2017-01-19 15:18:49 --> Router Class Initialized
INFO - 2017-01-19 15:18:49 --> Output Class Initialized
INFO - 2017-01-19 15:18:49 --> Security Class Initialized
DEBUG - 2017-01-19 15:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:18:49 --> Input Class Initialized
INFO - 2017-01-19 15:18:49 --> Language Class Initialized
INFO - 2017-01-19 15:18:49 --> Loader Class Initialized
INFO - 2017-01-19 15:18:49 --> Database Driver Class Initialized
INFO - 2017-01-19 15:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:18:49 --> Controller Class Initialized
INFO - 2017-01-19 15:18:49 --> Helper loaded: url_helper
DEBUG - 2017-01-19 15:18:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 15:18:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 15:18:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 15:18:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 15:18:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 15:18:49 --> Final output sent to browser
DEBUG - 2017-01-19 15:18:49 --> Total execution time: 0.0145
INFO - 2017-01-19 15:19:20 --> Config Class Initialized
INFO - 2017-01-19 15:19:20 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:19:20 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:19:20 --> Utf8 Class Initialized
INFO - 2017-01-19 15:19:20 --> URI Class Initialized
INFO - 2017-01-19 15:19:20 --> Router Class Initialized
INFO - 2017-01-19 15:19:20 --> Output Class Initialized
INFO - 2017-01-19 15:19:20 --> Security Class Initialized
DEBUG - 2017-01-19 15:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:19:20 --> Input Class Initialized
INFO - 2017-01-19 15:19:20 --> Language Class Initialized
INFO - 2017-01-19 15:19:20 --> Loader Class Initialized
INFO - 2017-01-19 15:19:20 --> Database Driver Class Initialized
INFO - 2017-01-19 15:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:19:20 --> Controller Class Initialized
INFO - 2017-01-19 15:19:20 --> Helper loaded: url_helper
DEBUG - 2017-01-19 15:19:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 15:19:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 15:19:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 15:19:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 15:19:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 15:19:20 --> Final output sent to browser
DEBUG - 2017-01-19 15:19:20 --> Total execution time: 0.0219
INFO - 2017-01-19 15:24:11 --> Config Class Initialized
INFO - 2017-01-19 15:24:11 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:24:11 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:24:11 --> Utf8 Class Initialized
INFO - 2017-01-19 15:24:11 --> URI Class Initialized
INFO - 2017-01-19 15:24:11 --> Router Class Initialized
INFO - 2017-01-19 15:24:11 --> Output Class Initialized
INFO - 2017-01-19 15:24:11 --> Security Class Initialized
DEBUG - 2017-01-19 15:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:24:11 --> Input Class Initialized
INFO - 2017-01-19 15:24:11 --> Language Class Initialized
INFO - 2017-01-19 15:24:11 --> Loader Class Initialized
INFO - 2017-01-19 15:24:11 --> Database Driver Class Initialized
INFO - 2017-01-19 15:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:24:11 --> Controller Class Initialized
INFO - 2017-01-19 15:24:11 --> Helper loaded: url_helper
DEBUG - 2017-01-19 15:24:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 15:24:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 15:24:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 15:24:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 15:24:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 15:24:11 --> Final output sent to browser
DEBUG - 2017-01-19 15:24:11 --> Total execution time: 0.0141
INFO - 2017-01-19 15:24:27 --> Config Class Initialized
INFO - 2017-01-19 15:24:27 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:24:27 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:24:27 --> Utf8 Class Initialized
INFO - 2017-01-19 15:24:27 --> URI Class Initialized
INFO - 2017-01-19 15:24:27 --> Router Class Initialized
INFO - 2017-01-19 15:24:27 --> Output Class Initialized
INFO - 2017-01-19 15:24:27 --> Security Class Initialized
DEBUG - 2017-01-19 15:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:24:27 --> Input Class Initialized
INFO - 2017-01-19 15:24:27 --> Language Class Initialized
INFO - 2017-01-19 15:24:27 --> Loader Class Initialized
INFO - 2017-01-19 15:24:27 --> Database Driver Class Initialized
INFO - 2017-01-19 15:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:24:27 --> Controller Class Initialized
INFO - 2017-01-19 15:24:27 --> Helper loaded: url_helper
DEBUG - 2017-01-19 15:24:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 15:24:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 15:24:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 15:24:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 15:24:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 15:24:27 --> Final output sent to browser
DEBUG - 2017-01-19 15:24:27 --> Total execution time: 0.0135
INFO - 2017-01-19 15:24:31 --> Config Class Initialized
INFO - 2017-01-19 15:24:31 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:24:31 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:24:31 --> Utf8 Class Initialized
INFO - 2017-01-19 15:24:31 --> URI Class Initialized
INFO - 2017-01-19 15:24:31 --> Router Class Initialized
INFO - 2017-01-19 15:24:31 --> Output Class Initialized
INFO - 2017-01-19 15:24:31 --> Security Class Initialized
DEBUG - 2017-01-19 15:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:24:31 --> Input Class Initialized
INFO - 2017-01-19 15:24:31 --> Language Class Initialized
INFO - 2017-01-19 15:24:31 --> Loader Class Initialized
INFO - 2017-01-19 15:24:31 --> Database Driver Class Initialized
INFO - 2017-01-19 15:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:24:31 --> Controller Class Initialized
INFO - 2017-01-19 15:24:31 --> Helper loaded: url_helper
DEBUG - 2017-01-19 15:24:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 15:24:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 15:24:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 15:24:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 15:24:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 15:24:31 --> Final output sent to browser
DEBUG - 2017-01-19 15:24:31 --> Total execution time: 0.0131
INFO - 2017-01-19 15:24:37 --> Config Class Initialized
INFO - 2017-01-19 15:24:37 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:24:37 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:24:37 --> Utf8 Class Initialized
INFO - 2017-01-19 15:24:37 --> URI Class Initialized
INFO - 2017-01-19 15:24:37 --> Router Class Initialized
INFO - 2017-01-19 15:24:37 --> Output Class Initialized
INFO - 2017-01-19 15:24:37 --> Security Class Initialized
DEBUG - 2017-01-19 15:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:24:37 --> Input Class Initialized
INFO - 2017-01-19 15:24:37 --> Language Class Initialized
INFO - 2017-01-19 15:24:37 --> Loader Class Initialized
INFO - 2017-01-19 15:24:37 --> Database Driver Class Initialized
INFO - 2017-01-19 15:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:24:37 --> Controller Class Initialized
INFO - 2017-01-19 15:24:37 --> Helper loaded: url_helper
DEBUG - 2017-01-19 15:24:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 15:24:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 15:24:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 15:24:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 15:24:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 15:24:37 --> Final output sent to browser
DEBUG - 2017-01-19 15:24:37 --> Total execution time: 0.0133
INFO - 2017-01-19 15:25:12 --> Config Class Initialized
INFO - 2017-01-19 15:25:12 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:25:12 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:25:12 --> Utf8 Class Initialized
INFO - 2017-01-19 15:25:12 --> URI Class Initialized
INFO - 2017-01-19 15:25:12 --> Router Class Initialized
INFO - 2017-01-19 15:25:12 --> Output Class Initialized
INFO - 2017-01-19 15:25:12 --> Security Class Initialized
DEBUG - 2017-01-19 15:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:25:12 --> Input Class Initialized
INFO - 2017-01-19 15:25:12 --> Language Class Initialized
INFO - 2017-01-19 15:25:12 --> Loader Class Initialized
INFO - 2017-01-19 15:25:12 --> Database Driver Class Initialized
INFO - 2017-01-19 15:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:25:12 --> Controller Class Initialized
INFO - 2017-01-19 15:25:12 --> Helper loaded: url_helper
DEBUG - 2017-01-19 15:25:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 15:25:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 15:25:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 15:25:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 15:25:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 15:25:12 --> Final output sent to browser
DEBUG - 2017-01-19 15:25:12 --> Total execution time: 0.0149
INFO - 2017-01-19 15:25:18 --> Config Class Initialized
INFO - 2017-01-19 15:25:18 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:25:18 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:25:18 --> Utf8 Class Initialized
INFO - 2017-01-19 15:25:18 --> URI Class Initialized
INFO - 2017-01-19 15:25:18 --> Router Class Initialized
INFO - 2017-01-19 15:25:18 --> Output Class Initialized
INFO - 2017-01-19 15:25:18 --> Security Class Initialized
DEBUG - 2017-01-19 15:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:25:18 --> Input Class Initialized
INFO - 2017-01-19 15:25:18 --> Language Class Initialized
INFO - 2017-01-19 15:25:18 --> Loader Class Initialized
INFO - 2017-01-19 15:25:18 --> Database Driver Class Initialized
INFO - 2017-01-19 15:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:25:18 --> Controller Class Initialized
INFO - 2017-01-19 15:25:18 --> Helper loaded: url_helper
DEBUG - 2017-01-19 15:25:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 15:25:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 15:25:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 15:25:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 15:25:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 15:25:18 --> Final output sent to browser
DEBUG - 2017-01-19 15:25:18 --> Total execution time: 0.0132
INFO - 2017-01-19 15:25:26 --> Config Class Initialized
INFO - 2017-01-19 15:25:26 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:25:26 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:25:26 --> Utf8 Class Initialized
INFO - 2017-01-19 15:25:26 --> URI Class Initialized
DEBUG - 2017-01-19 15:25:26 --> No URI present. Default controller set.
INFO - 2017-01-19 15:25:26 --> Router Class Initialized
INFO - 2017-01-19 15:25:26 --> Output Class Initialized
INFO - 2017-01-19 15:25:26 --> Security Class Initialized
DEBUG - 2017-01-19 15:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:25:26 --> Input Class Initialized
INFO - 2017-01-19 15:25:26 --> Language Class Initialized
INFO - 2017-01-19 15:25:26 --> Loader Class Initialized
INFO - 2017-01-19 15:25:26 --> Database Driver Class Initialized
INFO - 2017-01-19 15:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:25:26 --> Controller Class Initialized
INFO - 2017-01-19 15:25:26 --> Helper loaded: url_helper
DEBUG - 2017-01-19 15:25:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 15:25:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 15:25:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 15:25:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 15:25:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 15:25:26 --> Final output sent to browser
DEBUG - 2017-01-19 15:25:26 --> Total execution time: 0.0157
INFO - 2017-01-19 15:25:58 --> Config Class Initialized
INFO - 2017-01-19 15:25:58 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:25:58 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:25:58 --> Utf8 Class Initialized
INFO - 2017-01-19 15:25:58 --> URI Class Initialized
INFO - 2017-01-19 15:25:58 --> Router Class Initialized
INFO - 2017-01-19 15:25:58 --> Output Class Initialized
INFO - 2017-01-19 15:25:58 --> Security Class Initialized
DEBUG - 2017-01-19 15:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:25:58 --> Input Class Initialized
INFO - 2017-01-19 15:25:58 --> Language Class Initialized
INFO - 2017-01-19 15:25:58 --> Loader Class Initialized
INFO - 2017-01-19 15:25:58 --> Database Driver Class Initialized
INFO - 2017-01-19 15:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:25:58 --> Controller Class Initialized
INFO - 2017-01-19 15:25:58 --> Helper loaded: url_helper
DEBUG - 2017-01-19 15:25:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 15:25:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 15:25:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 15:25:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 15:25:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 15:25:58 --> Final output sent to browser
DEBUG - 2017-01-19 15:25:58 --> Total execution time: 0.0131
INFO - 2017-01-19 15:42:58 --> Config Class Initialized
INFO - 2017-01-19 15:42:58 --> Hooks Class Initialized
DEBUG - 2017-01-19 15:42:58 --> UTF-8 Support Enabled
INFO - 2017-01-19 15:42:58 --> Utf8 Class Initialized
INFO - 2017-01-19 15:42:58 --> URI Class Initialized
DEBUG - 2017-01-19 15:42:58 --> No URI present. Default controller set.
INFO - 2017-01-19 15:42:58 --> Router Class Initialized
INFO - 2017-01-19 15:42:58 --> Output Class Initialized
INFO - 2017-01-19 15:42:58 --> Security Class Initialized
DEBUG - 2017-01-19 15:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 15:42:58 --> Input Class Initialized
INFO - 2017-01-19 15:42:58 --> Language Class Initialized
INFO - 2017-01-19 15:42:58 --> Loader Class Initialized
INFO - 2017-01-19 15:42:58 --> Database Driver Class Initialized
INFO - 2017-01-19 15:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 15:42:58 --> Controller Class Initialized
INFO - 2017-01-19 15:42:58 --> Helper loaded: url_helper
DEBUG - 2017-01-19 15:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 15:42:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 15:42:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 15:42:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 15:42:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 15:42:58 --> Final output sent to browser
DEBUG - 2017-01-19 15:42:58 --> Total execution time: 0.0153
INFO - 2017-01-19 16:35:51 --> Config Class Initialized
INFO - 2017-01-19 16:35:51 --> Hooks Class Initialized
DEBUG - 2017-01-19 16:35:51 --> UTF-8 Support Enabled
INFO - 2017-01-19 16:35:51 --> Utf8 Class Initialized
INFO - 2017-01-19 16:35:51 --> URI Class Initialized
DEBUG - 2017-01-19 16:35:51 --> No URI present. Default controller set.
INFO - 2017-01-19 16:35:51 --> Router Class Initialized
INFO - 2017-01-19 16:35:51 --> Output Class Initialized
INFO - 2017-01-19 16:35:51 --> Security Class Initialized
DEBUG - 2017-01-19 16:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 16:35:51 --> Input Class Initialized
INFO - 2017-01-19 16:35:51 --> Language Class Initialized
INFO - 2017-01-19 16:35:51 --> Loader Class Initialized
INFO - 2017-01-19 16:35:51 --> Database Driver Class Initialized
INFO - 2017-01-19 16:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 16:35:51 --> Controller Class Initialized
INFO - 2017-01-19 16:35:51 --> Helper loaded: url_helper
DEBUG - 2017-01-19 16:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 16:35:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 16:35:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 16:35:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 16:35:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 16:35:51 --> Final output sent to browser
DEBUG - 2017-01-19 16:35:51 --> Total execution time: 0.0137
INFO - 2017-01-19 18:11:57 --> Config Class Initialized
INFO - 2017-01-19 18:11:57 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:11:57 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:11:57 --> Utf8 Class Initialized
INFO - 2017-01-19 18:11:57 --> URI Class Initialized
DEBUG - 2017-01-19 18:11:57 --> No URI present. Default controller set.
INFO - 2017-01-19 18:11:57 --> Router Class Initialized
INFO - 2017-01-19 18:11:57 --> Output Class Initialized
INFO - 2017-01-19 18:11:57 --> Security Class Initialized
DEBUG - 2017-01-19 18:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:11:57 --> Input Class Initialized
INFO - 2017-01-19 18:11:57 --> Language Class Initialized
INFO - 2017-01-19 18:11:57 --> Loader Class Initialized
INFO - 2017-01-19 18:11:57 --> Database Driver Class Initialized
INFO - 2017-01-19 18:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:11:57 --> Controller Class Initialized
INFO - 2017-01-19 18:11:57 --> Helper loaded: url_helper
DEBUG - 2017-01-19 18:11:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:11:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 18:11:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 18:11:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 18:11:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 18:11:57 --> Final output sent to browser
DEBUG - 2017-01-19 18:11:57 --> Total execution time: 0.0593
INFO - 2017-01-19 18:12:27 --> Config Class Initialized
INFO - 2017-01-19 18:12:27 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:12:27 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:12:27 --> Utf8 Class Initialized
INFO - 2017-01-19 18:12:27 --> URI Class Initialized
INFO - 2017-01-19 18:12:27 --> Router Class Initialized
INFO - 2017-01-19 18:12:27 --> Output Class Initialized
INFO - 2017-01-19 18:12:27 --> Security Class Initialized
DEBUG - 2017-01-19 18:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:12:27 --> Input Class Initialized
INFO - 2017-01-19 18:12:27 --> Language Class Initialized
INFO - 2017-01-19 18:12:27 --> Loader Class Initialized
INFO - 2017-01-19 18:12:27 --> Database Driver Class Initialized
INFO - 2017-01-19 18:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:12:27 --> Controller Class Initialized
INFO - 2017-01-19 18:12:27 --> Helper loaded: url_helper
DEBUG - 2017-01-19 18:12:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:12:27 --> Config Class Initialized
INFO - 2017-01-19 18:12:27 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:12:27 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:12:27 --> Utf8 Class Initialized
INFO - 2017-01-19 18:12:27 --> URI Class Initialized
INFO - 2017-01-19 18:12:27 --> Router Class Initialized
INFO - 2017-01-19 18:12:27 --> Output Class Initialized
INFO - 2017-01-19 18:12:27 --> Security Class Initialized
DEBUG - 2017-01-19 18:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:12:27 --> Input Class Initialized
INFO - 2017-01-19 18:12:27 --> Language Class Initialized
INFO - 2017-01-19 18:12:27 --> Loader Class Initialized
INFO - 2017-01-19 18:12:27 --> Database Driver Class Initialized
INFO - 2017-01-19 18:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:12:27 --> Controller Class Initialized
INFO - 2017-01-19 18:12:27 --> Helper loaded: date_helper
DEBUG - 2017-01-19 18:12:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:12:27 --> Helper loaded: url_helper
INFO - 2017-01-19 18:12:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 18:12:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-19 18:12:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-19 18:12:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-19 18:12:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 18:12:27 --> Final output sent to browser
DEBUG - 2017-01-19 18:12:27 --> Total execution time: 0.3432
INFO - 2017-01-19 18:12:31 --> Config Class Initialized
INFO - 2017-01-19 18:12:31 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:12:31 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:12:31 --> Utf8 Class Initialized
INFO - 2017-01-19 18:12:31 --> URI Class Initialized
INFO - 2017-01-19 18:12:31 --> Router Class Initialized
INFO - 2017-01-19 18:12:31 --> Output Class Initialized
INFO - 2017-01-19 18:12:31 --> Security Class Initialized
DEBUG - 2017-01-19 18:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:12:31 --> Input Class Initialized
INFO - 2017-01-19 18:12:31 --> Language Class Initialized
INFO - 2017-01-19 18:12:31 --> Loader Class Initialized
INFO - 2017-01-19 18:12:31 --> Database Driver Class Initialized
INFO - 2017-01-19 18:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:12:31 --> Controller Class Initialized
INFO - 2017-01-19 18:12:31 --> Helper loaded: date_helper
DEBUG - 2017-01-19 18:12:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:12:31 --> Helper loaded: url_helper
INFO - 2017-01-19 18:12:31 --> Final output sent to browser
DEBUG - 2017-01-19 18:12:31 --> Total execution time: 0.0126
INFO - 2017-01-19 18:12:35 --> Config Class Initialized
INFO - 2017-01-19 18:12:35 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:12:35 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:12:35 --> Utf8 Class Initialized
INFO - 2017-01-19 18:12:35 --> URI Class Initialized
INFO - 2017-01-19 18:12:35 --> Router Class Initialized
INFO - 2017-01-19 18:12:35 --> Output Class Initialized
INFO - 2017-01-19 18:12:35 --> Security Class Initialized
DEBUG - 2017-01-19 18:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:12:35 --> Input Class Initialized
INFO - 2017-01-19 18:12:35 --> Language Class Initialized
INFO - 2017-01-19 18:12:35 --> Loader Class Initialized
INFO - 2017-01-19 18:12:35 --> Database Driver Class Initialized
INFO - 2017-01-19 18:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:12:35 --> Controller Class Initialized
INFO - 2017-01-19 18:12:35 --> Helper loaded: date_helper
DEBUG - 2017-01-19 18:12:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:12:35 --> Helper loaded: url_helper
INFO - 2017-01-19 18:12:35 --> Final output sent to browser
DEBUG - 2017-01-19 18:12:35 --> Total execution time: 0.0130
INFO - 2017-01-19 18:12:41 --> Config Class Initialized
INFO - 2017-01-19 18:12:41 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:12:41 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:12:41 --> Utf8 Class Initialized
INFO - 2017-01-19 18:12:41 --> URI Class Initialized
INFO - 2017-01-19 18:12:41 --> Router Class Initialized
INFO - 2017-01-19 18:12:41 --> Output Class Initialized
INFO - 2017-01-19 18:12:41 --> Security Class Initialized
DEBUG - 2017-01-19 18:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:12:41 --> Input Class Initialized
INFO - 2017-01-19 18:12:41 --> Language Class Initialized
INFO - 2017-01-19 18:12:41 --> Loader Class Initialized
INFO - 2017-01-19 18:12:41 --> Database Driver Class Initialized
INFO - 2017-01-19 18:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:12:41 --> Controller Class Initialized
INFO - 2017-01-19 18:12:41 --> Helper loaded: date_helper
DEBUG - 2017-01-19 18:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:12:41 --> Helper loaded: url_helper
INFO - 2017-01-19 18:12:41 --> Helper loaded: download_helper
INFO - 2017-01-19 18:12:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 18:12:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-19 18:12:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-19 18:12:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-19 18:12:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 18:12:41 --> Final output sent to browser
DEBUG - 2017-01-19 18:12:41 --> Total execution time: 0.4871
INFO - 2017-01-19 18:12:47 --> Config Class Initialized
INFO - 2017-01-19 18:12:47 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:12:47 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:12:47 --> Utf8 Class Initialized
INFO - 2017-01-19 18:12:47 --> URI Class Initialized
INFO - 2017-01-19 18:12:47 --> Router Class Initialized
INFO - 2017-01-19 18:12:47 --> Output Class Initialized
INFO - 2017-01-19 18:12:47 --> Security Class Initialized
DEBUG - 2017-01-19 18:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:12:47 --> Input Class Initialized
INFO - 2017-01-19 18:12:47 --> Language Class Initialized
INFO - 2017-01-19 18:12:47 --> Loader Class Initialized
INFO - 2017-01-19 18:12:47 --> Database Driver Class Initialized
INFO - 2017-01-19 18:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:12:47 --> Controller Class Initialized
INFO - 2017-01-19 18:12:47 --> Helper loaded: date_helper
DEBUG - 2017-01-19 18:12:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:12:47 --> Helper loaded: url_helper
INFO - 2017-01-19 18:12:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 18:12:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-19 18:12:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-19 18:12:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-19 18:12:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-19 18:12:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 18:12:47 --> Final output sent to browser
DEBUG - 2017-01-19 18:12:47 --> Total execution time: 0.0803
INFO - 2017-01-19 18:13:03 --> Config Class Initialized
INFO - 2017-01-19 18:13:03 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:13:03 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:13:03 --> Utf8 Class Initialized
INFO - 2017-01-19 18:13:03 --> URI Class Initialized
INFO - 2017-01-19 18:13:03 --> Router Class Initialized
INFO - 2017-01-19 18:13:03 --> Output Class Initialized
INFO - 2017-01-19 18:13:03 --> Security Class Initialized
DEBUG - 2017-01-19 18:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:13:03 --> Input Class Initialized
INFO - 2017-01-19 18:13:03 --> Language Class Initialized
INFO - 2017-01-19 18:13:03 --> Loader Class Initialized
INFO - 2017-01-19 18:13:03 --> Database Driver Class Initialized
INFO - 2017-01-19 18:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:13:03 --> Controller Class Initialized
INFO - 2017-01-19 18:13:03 --> Helper loaded: date_helper
DEBUG - 2017-01-19 18:13:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:13:03 --> Helper loaded: url_helper
INFO - 2017-01-19 18:13:03 --> Final output sent to browser
DEBUG - 2017-01-19 18:13:03 --> Total execution time: 0.0123
INFO - 2017-01-19 18:13:03 --> Config Class Initialized
INFO - 2017-01-19 18:13:03 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:13:03 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:13:03 --> Utf8 Class Initialized
INFO - 2017-01-19 18:13:03 --> URI Class Initialized
INFO - 2017-01-19 18:13:03 --> Router Class Initialized
INFO - 2017-01-19 18:13:03 --> Output Class Initialized
INFO - 2017-01-19 18:13:03 --> Security Class Initialized
DEBUG - 2017-01-19 18:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:13:03 --> Input Class Initialized
INFO - 2017-01-19 18:13:03 --> Language Class Initialized
INFO - 2017-01-19 18:13:03 --> Loader Class Initialized
INFO - 2017-01-19 18:13:03 --> Database Driver Class Initialized
INFO - 2017-01-19 18:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:13:03 --> Controller Class Initialized
INFO - 2017-01-19 18:13:03 --> Helper loaded: date_helper
DEBUG - 2017-01-19 18:13:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:13:03 --> Helper loaded: url_helper
INFO - 2017-01-19 18:13:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 18:13:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-19 18:13:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-19 18:13:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-19 18:13:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-19 18:13:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 18:13:03 --> Final output sent to browser
DEBUG - 2017-01-19 18:13:03 --> Total execution time: 0.0135
INFO - 2017-01-19 18:13:04 --> Config Class Initialized
INFO - 2017-01-19 18:13:04 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:13:04 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:13:04 --> Utf8 Class Initialized
INFO - 2017-01-19 18:13:04 --> URI Class Initialized
INFO - 2017-01-19 18:13:04 --> Router Class Initialized
INFO - 2017-01-19 18:13:04 --> Output Class Initialized
INFO - 2017-01-19 18:13:04 --> Security Class Initialized
DEBUG - 2017-01-19 18:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:13:04 --> Input Class Initialized
INFO - 2017-01-19 18:13:04 --> Language Class Initialized
INFO - 2017-01-19 18:13:04 --> Loader Class Initialized
INFO - 2017-01-19 18:13:04 --> Database Driver Class Initialized
INFO - 2017-01-19 18:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:13:04 --> Controller Class Initialized
INFO - 2017-01-19 18:13:04 --> Helper loaded: date_helper
DEBUG - 2017-01-19 18:13:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:13:04 --> Helper loaded: url_helper
INFO - 2017-01-19 18:13:04 --> Final output sent to browser
DEBUG - 2017-01-19 18:13:04 --> Total execution time: 0.0133
INFO - 2017-01-19 18:13:05 --> Config Class Initialized
INFO - 2017-01-19 18:13:05 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:13:05 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:13:05 --> Utf8 Class Initialized
INFO - 2017-01-19 18:13:05 --> URI Class Initialized
INFO - 2017-01-19 18:13:05 --> Router Class Initialized
INFO - 2017-01-19 18:13:05 --> Output Class Initialized
INFO - 2017-01-19 18:13:05 --> Security Class Initialized
DEBUG - 2017-01-19 18:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:13:05 --> Input Class Initialized
INFO - 2017-01-19 18:13:05 --> Language Class Initialized
INFO - 2017-01-19 18:13:05 --> Loader Class Initialized
INFO - 2017-01-19 18:13:05 --> Database Driver Class Initialized
INFO - 2017-01-19 18:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:13:05 --> Controller Class Initialized
INFO - 2017-01-19 18:13:05 --> Helper loaded: date_helper
DEBUG - 2017-01-19 18:13:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:13:05 --> Helper loaded: url_helper
INFO - 2017-01-19 18:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 18:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-19 18:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-19 18:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-19 18:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-19 18:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 18:13:05 --> Final output sent to browser
DEBUG - 2017-01-19 18:13:05 --> Total execution time: 0.0134
INFO - 2017-01-19 18:13:09 --> Config Class Initialized
INFO - 2017-01-19 18:13:09 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:13:09 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:13:09 --> Utf8 Class Initialized
INFO - 2017-01-19 18:13:09 --> URI Class Initialized
INFO - 2017-01-19 18:13:09 --> Router Class Initialized
INFO - 2017-01-19 18:13:09 --> Output Class Initialized
INFO - 2017-01-19 18:13:09 --> Security Class Initialized
DEBUG - 2017-01-19 18:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:13:09 --> Input Class Initialized
INFO - 2017-01-19 18:13:09 --> Language Class Initialized
INFO - 2017-01-19 18:13:09 --> Loader Class Initialized
INFO - 2017-01-19 18:13:09 --> Database Driver Class Initialized
INFO - 2017-01-19 18:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:13:09 --> Controller Class Initialized
INFO - 2017-01-19 18:13:09 --> Helper loaded: date_helper
DEBUG - 2017-01-19 18:13:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:13:09 --> Helper loaded: url_helper
INFO - 2017-01-19 18:13:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 18:13:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-19 18:13:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-19 18:13:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-19 18:13:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 18:13:09 --> Final output sent to browser
DEBUG - 2017-01-19 18:13:09 --> Total execution time: 0.0146
INFO - 2017-01-19 18:13:14 --> Config Class Initialized
INFO - 2017-01-19 18:13:14 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:13:14 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:13:14 --> Utf8 Class Initialized
INFO - 2017-01-19 18:13:14 --> URI Class Initialized
INFO - 2017-01-19 18:13:14 --> Router Class Initialized
INFO - 2017-01-19 18:13:14 --> Output Class Initialized
INFO - 2017-01-19 18:13:14 --> Security Class Initialized
DEBUG - 2017-01-19 18:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:13:14 --> Input Class Initialized
INFO - 2017-01-19 18:13:14 --> Language Class Initialized
INFO - 2017-01-19 18:13:14 --> Loader Class Initialized
INFO - 2017-01-19 18:13:14 --> Database Driver Class Initialized
INFO - 2017-01-19 18:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:13:14 --> Controller Class Initialized
INFO - 2017-01-19 18:13:14 --> Helper loaded: date_helper
DEBUG - 2017-01-19 18:13:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:13:14 --> Helper loaded: url_helper
INFO - 2017-01-19 18:13:14 --> Final output sent to browser
DEBUG - 2017-01-19 18:13:14 --> Total execution time: 0.0123
INFO - 2017-01-19 18:13:22 --> Config Class Initialized
INFO - 2017-01-19 18:13:22 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:13:22 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:13:22 --> Utf8 Class Initialized
INFO - 2017-01-19 18:13:22 --> URI Class Initialized
INFO - 2017-01-19 18:13:22 --> Router Class Initialized
INFO - 2017-01-19 18:13:22 --> Output Class Initialized
INFO - 2017-01-19 18:13:22 --> Security Class Initialized
DEBUG - 2017-01-19 18:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:13:22 --> Input Class Initialized
INFO - 2017-01-19 18:13:22 --> Language Class Initialized
INFO - 2017-01-19 18:13:22 --> Loader Class Initialized
INFO - 2017-01-19 18:13:22 --> Database Driver Class Initialized
INFO - 2017-01-19 18:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:13:22 --> Controller Class Initialized
INFO - 2017-01-19 18:13:22 --> Helper loaded: date_helper
DEBUG - 2017-01-19 18:13:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:13:22 --> Helper loaded: url_helper
INFO - 2017-01-19 18:13:22 --> Final output sent to browser
DEBUG - 2017-01-19 18:13:22 --> Total execution time: 0.0122
INFO - 2017-01-19 18:13:46 --> Config Class Initialized
INFO - 2017-01-19 18:13:46 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:13:46 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:13:46 --> Utf8 Class Initialized
INFO - 2017-01-19 18:13:46 --> URI Class Initialized
INFO - 2017-01-19 18:13:46 --> Router Class Initialized
INFO - 2017-01-19 18:13:46 --> Output Class Initialized
INFO - 2017-01-19 18:13:46 --> Security Class Initialized
DEBUG - 2017-01-19 18:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:13:46 --> Input Class Initialized
INFO - 2017-01-19 18:13:46 --> Language Class Initialized
INFO - 2017-01-19 18:13:46 --> Loader Class Initialized
INFO - 2017-01-19 18:13:46 --> Database Driver Class Initialized
INFO - 2017-01-19 18:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:13:46 --> Controller Class Initialized
INFO - 2017-01-19 18:13:46 --> Upload Class Initialized
INFO - 2017-01-19 18:13:46 --> Helper loaded: date_helper
DEBUG - 2017-01-19 18:13:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:13:46 --> Helper loaded: url_helper
INFO - 2017-01-19 18:13:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 18:13:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-19 18:13:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-01-19 18:13:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-01-19 18:13:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-19 18:13:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 18:13:46 --> Final output sent to browser
DEBUG - 2017-01-19 18:13:46 --> Total execution time: 0.3986
INFO - 2017-01-19 18:13:59 --> Config Class Initialized
INFO - 2017-01-19 18:13:59 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:13:59 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:13:59 --> Utf8 Class Initialized
INFO - 2017-01-19 18:13:59 --> URI Class Initialized
INFO - 2017-01-19 18:13:59 --> Router Class Initialized
INFO - 2017-01-19 18:13:59 --> Output Class Initialized
INFO - 2017-01-19 18:13:59 --> Security Class Initialized
DEBUG - 2017-01-19 18:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:13:59 --> Input Class Initialized
INFO - 2017-01-19 18:13:59 --> Language Class Initialized
INFO - 2017-01-19 18:13:59 --> Loader Class Initialized
INFO - 2017-01-19 18:13:59 --> Database Driver Class Initialized
INFO - 2017-01-19 18:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:13:59 --> Controller Class Initialized
INFO - 2017-01-19 18:13:59 --> Helper loaded: date_helper
DEBUG - 2017-01-19 18:13:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:13:59 --> Helper loaded: url_helper
INFO - 2017-01-19 18:13:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 18:13:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-19 18:13:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-19 18:13:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-19 18:13:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-19 18:13:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 18:13:59 --> Final output sent to browser
DEBUG - 2017-01-19 18:13:59 --> Total execution time: 0.0138
INFO - 2017-01-19 18:14:09 --> Config Class Initialized
INFO - 2017-01-19 18:14:09 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:14:09 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:14:09 --> Utf8 Class Initialized
INFO - 2017-01-19 18:14:09 --> URI Class Initialized
INFO - 2017-01-19 18:14:09 --> Router Class Initialized
INFO - 2017-01-19 18:14:09 --> Output Class Initialized
INFO - 2017-01-19 18:14:09 --> Security Class Initialized
DEBUG - 2017-01-19 18:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:14:09 --> Input Class Initialized
INFO - 2017-01-19 18:14:09 --> Language Class Initialized
INFO - 2017-01-19 18:14:09 --> Loader Class Initialized
INFO - 2017-01-19 18:14:09 --> Database Driver Class Initialized
INFO - 2017-01-19 18:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:14:09 --> Controller Class Initialized
INFO - 2017-01-19 18:14:09 --> Helper loaded: date_helper
DEBUG - 2017-01-19 18:14:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:14:09 --> Helper loaded: url_helper
INFO - 2017-01-19 18:14:09 --> Final output sent to browser
DEBUG - 2017-01-19 18:14:09 --> Total execution time: 0.0222
INFO - 2017-01-19 18:14:09 --> Config Class Initialized
INFO - 2017-01-19 18:14:09 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:14:09 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:14:09 --> Utf8 Class Initialized
INFO - 2017-01-19 18:14:09 --> URI Class Initialized
INFO - 2017-01-19 18:14:09 --> Router Class Initialized
INFO - 2017-01-19 18:14:09 --> Output Class Initialized
INFO - 2017-01-19 18:14:09 --> Security Class Initialized
DEBUG - 2017-01-19 18:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:14:09 --> Input Class Initialized
INFO - 2017-01-19 18:14:09 --> Language Class Initialized
INFO - 2017-01-19 18:14:09 --> Loader Class Initialized
INFO - 2017-01-19 18:14:09 --> Database Driver Class Initialized
INFO - 2017-01-19 18:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:14:09 --> Controller Class Initialized
INFO - 2017-01-19 18:14:09 --> Helper loaded: date_helper
DEBUG - 2017-01-19 18:14:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:14:09 --> Helper loaded: url_helper
INFO - 2017-01-19 18:14:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 18:14:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-19 18:14:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-19 18:14:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-19 18:14:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-19 18:14:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 18:14:09 --> Final output sent to browser
DEBUG - 2017-01-19 18:14:09 --> Total execution time: 0.0139
INFO - 2017-01-19 18:14:13 --> Config Class Initialized
INFO - 2017-01-19 18:14:13 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:14:13 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:14:13 --> Utf8 Class Initialized
INFO - 2017-01-19 18:14:13 --> URI Class Initialized
INFO - 2017-01-19 18:14:13 --> Router Class Initialized
INFO - 2017-01-19 18:14:13 --> Output Class Initialized
INFO - 2017-01-19 18:14:13 --> Security Class Initialized
DEBUG - 2017-01-19 18:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:14:13 --> Input Class Initialized
INFO - 2017-01-19 18:14:13 --> Language Class Initialized
INFO - 2017-01-19 18:14:13 --> Loader Class Initialized
INFO - 2017-01-19 18:14:13 --> Database Driver Class Initialized
INFO - 2017-01-19 18:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:14:13 --> Controller Class Initialized
INFO - 2017-01-19 18:14:13 --> Upload Class Initialized
INFO - 2017-01-19 18:14:13 --> Helper loaded: date_helper
DEBUG - 2017-01-19 18:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:14:13 --> Helper loaded: url_helper
INFO - 2017-01-19 18:14:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 18:14:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-19 18:14:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-01-19 18:14:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-01-19 18:14:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-19 18:14:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 18:14:13 --> Final output sent to browser
DEBUG - 2017-01-19 18:14:13 --> Total execution time: 0.0156
INFO - 2017-01-19 18:49:18 --> Config Class Initialized
INFO - 2017-01-19 18:49:18 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:49:18 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:49:18 --> Utf8 Class Initialized
INFO - 2017-01-19 18:49:18 --> URI Class Initialized
INFO - 2017-01-19 18:49:18 --> Router Class Initialized
INFO - 2017-01-19 18:49:18 --> Output Class Initialized
INFO - 2017-01-19 18:49:18 --> Security Class Initialized
DEBUG - 2017-01-19 18:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:49:18 --> Input Class Initialized
INFO - 2017-01-19 18:49:18 --> Language Class Initialized
INFO - 2017-01-19 18:49:18 --> Loader Class Initialized
INFO - 2017-01-19 18:49:18 --> Database Driver Class Initialized
INFO - 2017-01-19 18:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:49:18 --> Controller Class Initialized
INFO - 2017-01-19 18:49:18 --> Helper loaded: date_helper
DEBUG - 2017-01-19 18:49:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:49:18 --> Helper loaded: url_helper
INFO - 2017-01-19 18:49:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 18:49:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-19 18:49:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-19 18:49:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-19 18:49:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 18:49:18 --> Final output sent to browser
DEBUG - 2017-01-19 18:49:18 --> Total execution time: 0.0147
INFO - 2017-01-19 18:49:21 --> Config Class Initialized
INFO - 2017-01-19 18:49:21 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:49:21 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:49:21 --> Utf8 Class Initialized
INFO - 2017-01-19 18:49:21 --> URI Class Initialized
INFO - 2017-01-19 18:49:21 --> Router Class Initialized
INFO - 2017-01-19 18:49:21 --> Output Class Initialized
INFO - 2017-01-19 18:49:21 --> Security Class Initialized
DEBUG - 2017-01-19 18:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:49:21 --> Input Class Initialized
INFO - 2017-01-19 18:49:21 --> Language Class Initialized
INFO - 2017-01-19 18:49:21 --> Loader Class Initialized
INFO - 2017-01-19 18:49:21 --> Database Driver Class Initialized
INFO - 2017-01-19 18:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:49:21 --> Controller Class Initialized
INFO - 2017-01-19 18:49:21 --> Helper loaded: url_helper
DEBUG - 2017-01-19 18:49:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:49:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 18:49:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 18:49:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 18:49:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 18:49:21 --> Final output sent to browser
DEBUG - 2017-01-19 18:49:21 --> Total execution time: 0.0364
INFO - 2017-01-19 18:58:55 --> Config Class Initialized
INFO - 2017-01-19 18:58:55 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:58:55 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:58:55 --> Utf8 Class Initialized
INFO - 2017-01-19 18:58:55 --> URI Class Initialized
DEBUG - 2017-01-19 18:58:55 --> No URI present. Default controller set.
INFO - 2017-01-19 18:58:55 --> Router Class Initialized
INFO - 2017-01-19 18:58:55 --> Output Class Initialized
INFO - 2017-01-19 18:58:55 --> Security Class Initialized
DEBUG - 2017-01-19 18:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:58:55 --> Input Class Initialized
INFO - 2017-01-19 18:58:55 --> Language Class Initialized
INFO - 2017-01-19 18:58:55 --> Loader Class Initialized
INFO - 2017-01-19 18:58:55 --> Database Driver Class Initialized
INFO - 2017-01-19 18:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:58:55 --> Controller Class Initialized
INFO - 2017-01-19 18:58:55 --> Helper loaded: url_helper
DEBUG - 2017-01-19 18:58:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:58:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 18:58:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 18:58:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 18:58:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 18:58:55 --> Final output sent to browser
DEBUG - 2017-01-19 18:58:55 --> Total execution time: 0.0132
INFO - 2017-01-19 18:59:00 --> Config Class Initialized
INFO - 2017-01-19 18:59:00 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:59:00 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:59:00 --> Utf8 Class Initialized
INFO - 2017-01-19 18:59:00 --> URI Class Initialized
INFO - 2017-01-19 18:59:00 --> Router Class Initialized
INFO - 2017-01-19 18:59:00 --> Output Class Initialized
INFO - 2017-01-19 18:59:00 --> Security Class Initialized
DEBUG - 2017-01-19 18:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:59:00 --> Input Class Initialized
INFO - 2017-01-19 18:59:00 --> Language Class Initialized
INFO - 2017-01-19 18:59:00 --> Loader Class Initialized
INFO - 2017-01-19 18:59:00 --> Database Driver Class Initialized
INFO - 2017-01-19 18:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:59:00 --> Controller Class Initialized
INFO - 2017-01-19 18:59:00 --> Helper loaded: url_helper
DEBUG - 2017-01-19 18:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:59:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 18:59:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 18:59:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 18:59:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 18:59:00 --> Final output sent to browser
DEBUG - 2017-01-19 18:59:00 --> Total execution time: 0.0130
INFO - 2017-01-19 18:59:49 --> Config Class Initialized
INFO - 2017-01-19 18:59:49 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:59:49 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:59:49 --> Utf8 Class Initialized
INFO - 2017-01-19 18:59:49 --> URI Class Initialized
DEBUG - 2017-01-19 18:59:49 --> No URI present. Default controller set.
INFO - 2017-01-19 18:59:49 --> Router Class Initialized
INFO - 2017-01-19 18:59:49 --> Output Class Initialized
INFO - 2017-01-19 18:59:49 --> Security Class Initialized
DEBUG - 2017-01-19 18:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:59:49 --> Input Class Initialized
INFO - 2017-01-19 18:59:49 --> Language Class Initialized
INFO - 2017-01-19 18:59:49 --> Loader Class Initialized
INFO - 2017-01-19 18:59:49 --> Database Driver Class Initialized
INFO - 2017-01-19 18:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:59:49 --> Controller Class Initialized
INFO - 2017-01-19 18:59:49 --> Helper loaded: url_helper
DEBUG - 2017-01-19 18:59:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:59:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 18:59:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 18:59:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 18:59:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 18:59:49 --> Final output sent to browser
DEBUG - 2017-01-19 18:59:49 --> Total execution time: 0.0133
INFO - 2017-01-19 18:59:52 --> Config Class Initialized
INFO - 2017-01-19 18:59:52 --> Hooks Class Initialized
DEBUG - 2017-01-19 18:59:52 --> UTF-8 Support Enabled
INFO - 2017-01-19 18:59:52 --> Utf8 Class Initialized
INFO - 2017-01-19 18:59:52 --> URI Class Initialized
INFO - 2017-01-19 18:59:52 --> Router Class Initialized
INFO - 2017-01-19 18:59:52 --> Output Class Initialized
INFO - 2017-01-19 18:59:52 --> Security Class Initialized
DEBUG - 2017-01-19 18:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 18:59:52 --> Input Class Initialized
INFO - 2017-01-19 18:59:52 --> Language Class Initialized
INFO - 2017-01-19 18:59:52 --> Loader Class Initialized
INFO - 2017-01-19 18:59:52 --> Database Driver Class Initialized
INFO - 2017-01-19 18:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 18:59:52 --> Controller Class Initialized
INFO - 2017-01-19 18:59:52 --> Helper loaded: url_helper
DEBUG - 2017-01-19 18:59:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 18:59:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 18:59:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 18:59:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 18:59:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 18:59:52 --> Final output sent to browser
DEBUG - 2017-01-19 18:59:52 --> Total execution time: 0.0132
INFO - 2017-01-19 19:00:31 --> Config Class Initialized
INFO - 2017-01-19 19:00:31 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:00:31 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:00:31 --> Utf8 Class Initialized
INFO - 2017-01-19 19:00:31 --> URI Class Initialized
INFO - 2017-01-19 19:00:31 --> Router Class Initialized
INFO - 2017-01-19 19:00:31 --> Output Class Initialized
INFO - 2017-01-19 19:00:31 --> Security Class Initialized
DEBUG - 2017-01-19 19:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:00:31 --> Input Class Initialized
INFO - 2017-01-19 19:00:31 --> Language Class Initialized
INFO - 2017-01-19 19:00:31 --> Loader Class Initialized
INFO - 2017-01-19 19:00:31 --> Database Driver Class Initialized
INFO - 2017-01-19 19:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:00:31 --> Controller Class Initialized
INFO - 2017-01-19 19:00:31 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:00:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:00:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:00:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:00:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:00:31 --> Final output sent to browser
DEBUG - 2017-01-19 19:00:31 --> Total execution time: 0.0140
INFO - 2017-01-19 19:00:31 --> Config Class Initialized
INFO - 2017-01-19 19:00:31 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:00:31 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:00:31 --> Utf8 Class Initialized
INFO - 2017-01-19 19:00:31 --> URI Class Initialized
INFO - 2017-01-19 19:00:31 --> Router Class Initialized
INFO - 2017-01-19 19:00:31 --> Output Class Initialized
INFO - 2017-01-19 19:00:31 --> Security Class Initialized
DEBUG - 2017-01-19 19:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:00:31 --> Input Class Initialized
INFO - 2017-01-19 19:00:31 --> Language Class Initialized
INFO - 2017-01-19 19:00:31 --> Loader Class Initialized
INFO - 2017-01-19 19:00:31 --> Database Driver Class Initialized
INFO - 2017-01-19 19:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:00:31 --> Controller Class Initialized
INFO - 2017-01-19 19:00:31 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:00:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:00:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:00:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:00:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:00:31 --> Final output sent to browser
DEBUG - 2017-01-19 19:00:31 --> Total execution time: 0.0130
INFO - 2017-01-19 19:00:39 --> Config Class Initialized
INFO - 2017-01-19 19:00:39 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:00:39 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:00:39 --> Utf8 Class Initialized
INFO - 2017-01-19 19:00:39 --> URI Class Initialized
INFO - 2017-01-19 19:00:39 --> Router Class Initialized
INFO - 2017-01-19 19:00:39 --> Output Class Initialized
INFO - 2017-01-19 19:00:39 --> Security Class Initialized
DEBUG - 2017-01-19 19:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:00:39 --> Input Class Initialized
INFO - 2017-01-19 19:00:39 --> Language Class Initialized
INFO - 2017-01-19 19:00:39 --> Loader Class Initialized
INFO - 2017-01-19 19:00:39 --> Database Driver Class Initialized
INFO - 2017-01-19 19:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:00:39 --> Controller Class Initialized
INFO - 2017-01-19 19:00:39 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:00:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:00:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:00:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:00:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:00:39 --> Final output sent to browser
DEBUG - 2017-01-19 19:00:39 --> Total execution time: 0.0186
INFO - 2017-01-19 19:00:39 --> Config Class Initialized
INFO - 2017-01-19 19:00:39 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:00:39 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:00:39 --> Utf8 Class Initialized
INFO - 2017-01-19 19:00:39 --> URI Class Initialized
INFO - 2017-01-19 19:00:39 --> Router Class Initialized
INFO - 2017-01-19 19:00:39 --> Output Class Initialized
INFO - 2017-01-19 19:00:39 --> Security Class Initialized
DEBUG - 2017-01-19 19:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:00:39 --> Input Class Initialized
INFO - 2017-01-19 19:00:39 --> Language Class Initialized
INFO - 2017-01-19 19:00:39 --> Loader Class Initialized
INFO - 2017-01-19 19:00:39 --> Database Driver Class Initialized
INFO - 2017-01-19 19:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:00:39 --> Controller Class Initialized
INFO - 2017-01-19 19:00:39 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:00:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:00:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:00:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:00:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:00:39 --> Final output sent to browser
DEBUG - 2017-01-19 19:00:39 --> Total execution time: 0.0171
INFO - 2017-01-19 19:00:56 --> Config Class Initialized
INFO - 2017-01-19 19:00:56 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:00:56 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:00:56 --> Utf8 Class Initialized
INFO - 2017-01-19 19:00:56 --> URI Class Initialized
INFO - 2017-01-19 19:00:56 --> Router Class Initialized
INFO - 2017-01-19 19:00:56 --> Output Class Initialized
INFO - 2017-01-19 19:00:56 --> Security Class Initialized
DEBUG - 2017-01-19 19:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:00:56 --> Input Class Initialized
INFO - 2017-01-19 19:00:56 --> Language Class Initialized
INFO - 2017-01-19 19:00:56 --> Loader Class Initialized
INFO - 2017-01-19 19:00:56 --> Database Driver Class Initialized
INFO - 2017-01-19 19:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:00:56 --> Controller Class Initialized
INFO - 2017-01-19 19:00:56 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:00:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:00:58 --> Config Class Initialized
INFO - 2017-01-19 19:00:58 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:00:58 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:00:58 --> Utf8 Class Initialized
INFO - 2017-01-19 19:00:58 --> URI Class Initialized
INFO - 2017-01-19 19:00:58 --> Router Class Initialized
INFO - 2017-01-19 19:00:58 --> Output Class Initialized
INFO - 2017-01-19 19:00:58 --> Security Class Initialized
DEBUG - 2017-01-19 19:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:00:58 --> Input Class Initialized
INFO - 2017-01-19 19:00:58 --> Language Class Initialized
INFO - 2017-01-19 19:00:58 --> Loader Class Initialized
INFO - 2017-01-19 19:00:58 --> Database Driver Class Initialized
INFO - 2017-01-19 19:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:00:58 --> Controller Class Initialized
INFO - 2017-01-19 19:00:58 --> Helper loaded: date_helper
DEBUG - 2017-01-19 19:00:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:00:58 --> Helper loaded: url_helper
INFO - 2017-01-19 19:00:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:00:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-19 19:00:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-19 19:00:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-19 19:00:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:00:58 --> Final output sent to browser
DEBUG - 2017-01-19 19:00:58 --> Total execution time: 0.0135
INFO - 2017-01-19 19:00:58 --> Config Class Initialized
INFO - 2017-01-19 19:00:58 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:00:58 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:00:58 --> Utf8 Class Initialized
INFO - 2017-01-19 19:00:58 --> URI Class Initialized
INFO - 2017-01-19 19:00:58 --> Router Class Initialized
INFO - 2017-01-19 19:00:58 --> Output Class Initialized
INFO - 2017-01-19 19:00:58 --> Security Class Initialized
DEBUG - 2017-01-19 19:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:00:58 --> Input Class Initialized
INFO - 2017-01-19 19:00:58 --> Language Class Initialized
INFO - 2017-01-19 19:00:58 --> Loader Class Initialized
INFO - 2017-01-19 19:00:58 --> Database Driver Class Initialized
INFO - 2017-01-19 19:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:00:58 --> Controller Class Initialized
INFO - 2017-01-19 19:00:58 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:00:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:00:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:00:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:00:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:00:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:00:58 --> Final output sent to browser
DEBUG - 2017-01-19 19:00:58 --> Total execution time: 0.0137
INFO - 2017-01-19 19:01:10 --> Config Class Initialized
INFO - 2017-01-19 19:01:10 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:01:10 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:01:10 --> Utf8 Class Initialized
INFO - 2017-01-19 19:01:10 --> URI Class Initialized
DEBUG - 2017-01-19 19:01:10 --> No URI present. Default controller set.
INFO - 2017-01-19 19:01:10 --> Router Class Initialized
INFO - 2017-01-19 19:01:10 --> Output Class Initialized
INFO - 2017-01-19 19:01:10 --> Security Class Initialized
DEBUG - 2017-01-19 19:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:01:10 --> Input Class Initialized
INFO - 2017-01-19 19:01:10 --> Language Class Initialized
INFO - 2017-01-19 19:01:10 --> Loader Class Initialized
INFO - 2017-01-19 19:01:10 --> Database Driver Class Initialized
INFO - 2017-01-19 19:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:01:10 --> Controller Class Initialized
INFO - 2017-01-19 19:01:10 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:01:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:01:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:01:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:01:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:01:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:01:10 --> Final output sent to browser
DEBUG - 2017-01-19 19:01:10 --> Total execution time: 0.0138
INFO - 2017-01-19 19:01:10 --> Config Class Initialized
INFO - 2017-01-19 19:01:10 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:01:10 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:01:10 --> Utf8 Class Initialized
INFO - 2017-01-19 19:01:10 --> URI Class Initialized
INFO - 2017-01-19 19:01:10 --> Router Class Initialized
INFO - 2017-01-19 19:01:10 --> Output Class Initialized
INFO - 2017-01-19 19:01:10 --> Security Class Initialized
DEBUG - 2017-01-19 19:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:01:10 --> Input Class Initialized
INFO - 2017-01-19 19:01:10 --> Language Class Initialized
INFO - 2017-01-19 19:01:10 --> Loader Class Initialized
INFO - 2017-01-19 19:01:10 --> Database Driver Class Initialized
INFO - 2017-01-19 19:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:01:10 --> Controller Class Initialized
INFO - 2017-01-19 19:01:10 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:01:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:01:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:01:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:01:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:01:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:01:10 --> Final output sent to browser
DEBUG - 2017-01-19 19:01:10 --> Total execution time: 0.0139
INFO - 2017-01-19 19:01:33 --> Config Class Initialized
INFO - 2017-01-19 19:01:33 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:01:33 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:01:33 --> Utf8 Class Initialized
INFO - 2017-01-19 19:01:33 --> URI Class Initialized
DEBUG - 2017-01-19 19:01:33 --> No URI present. Default controller set.
INFO - 2017-01-19 19:01:33 --> Router Class Initialized
INFO - 2017-01-19 19:01:33 --> Output Class Initialized
INFO - 2017-01-19 19:01:33 --> Security Class Initialized
DEBUG - 2017-01-19 19:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:01:33 --> Input Class Initialized
INFO - 2017-01-19 19:01:33 --> Language Class Initialized
INFO - 2017-01-19 19:01:33 --> Loader Class Initialized
INFO - 2017-01-19 19:01:33 --> Database Driver Class Initialized
INFO - 2017-01-19 19:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:01:33 --> Controller Class Initialized
INFO - 2017-01-19 19:01:33 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:01:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:01:33 --> Final output sent to browser
DEBUG - 2017-01-19 19:01:33 --> Total execution time: 0.3767
INFO - 2017-01-19 19:01:37 --> Config Class Initialized
INFO - 2017-01-19 19:01:37 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:01:37 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:01:37 --> Utf8 Class Initialized
INFO - 2017-01-19 19:01:37 --> URI Class Initialized
INFO - 2017-01-19 19:01:37 --> Router Class Initialized
INFO - 2017-01-19 19:01:37 --> Output Class Initialized
INFO - 2017-01-19 19:01:37 --> Security Class Initialized
DEBUG - 2017-01-19 19:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:01:37 --> Input Class Initialized
INFO - 2017-01-19 19:01:37 --> Language Class Initialized
INFO - 2017-01-19 19:01:37 --> Loader Class Initialized
INFO - 2017-01-19 19:01:37 --> Database Driver Class Initialized
INFO - 2017-01-19 19:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:01:37 --> Controller Class Initialized
INFO - 2017-01-19 19:01:37 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:01:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:01:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:01:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:01:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:01:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:01:37 --> Final output sent to browser
DEBUG - 2017-01-19 19:01:37 --> Total execution time: 0.0308
INFO - 2017-01-19 19:02:58 --> Config Class Initialized
INFO - 2017-01-19 19:02:58 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:02:58 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:02:58 --> Utf8 Class Initialized
INFO - 2017-01-19 19:02:58 --> URI Class Initialized
INFO - 2017-01-19 19:02:58 --> Router Class Initialized
INFO - 2017-01-19 19:02:58 --> Output Class Initialized
INFO - 2017-01-19 19:02:58 --> Security Class Initialized
DEBUG - 2017-01-19 19:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:02:58 --> Input Class Initialized
INFO - 2017-01-19 19:02:58 --> Language Class Initialized
INFO - 2017-01-19 19:02:58 --> Loader Class Initialized
INFO - 2017-01-19 19:02:58 --> Database Driver Class Initialized
INFO - 2017-01-19 19:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:02:58 --> Controller Class Initialized
INFO - 2017-01-19 19:02:58 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:02:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:02:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:02:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:02:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:02:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:02:58 --> Final output sent to browser
DEBUG - 2017-01-19 19:02:58 --> Total execution time: 0.0141
INFO - 2017-01-19 19:03:00 --> Config Class Initialized
INFO - 2017-01-19 19:03:00 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:03:00 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:03:00 --> Utf8 Class Initialized
INFO - 2017-01-19 19:03:00 --> URI Class Initialized
INFO - 2017-01-19 19:03:00 --> Router Class Initialized
INFO - 2017-01-19 19:03:00 --> Output Class Initialized
INFO - 2017-01-19 19:03:00 --> Security Class Initialized
DEBUG - 2017-01-19 19:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:03:00 --> Input Class Initialized
INFO - 2017-01-19 19:03:00 --> Language Class Initialized
INFO - 2017-01-19 19:03:00 --> Loader Class Initialized
INFO - 2017-01-19 19:03:00 --> Database Driver Class Initialized
INFO - 2017-01-19 19:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:03:00 --> Controller Class Initialized
INFO - 2017-01-19 19:03:00 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:03:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:03:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:03:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:03:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:03:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:03:00 --> Final output sent to browser
DEBUG - 2017-01-19 19:03:00 --> Total execution time: 0.0485
INFO - 2017-01-19 19:03:13 --> Config Class Initialized
INFO - 2017-01-19 19:03:13 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:03:13 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:03:13 --> Utf8 Class Initialized
INFO - 2017-01-19 19:03:13 --> URI Class Initialized
INFO - 2017-01-19 19:03:13 --> Router Class Initialized
INFO - 2017-01-19 19:03:13 --> Output Class Initialized
INFO - 2017-01-19 19:03:13 --> Security Class Initialized
DEBUG - 2017-01-19 19:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:03:13 --> Input Class Initialized
INFO - 2017-01-19 19:03:13 --> Language Class Initialized
INFO - 2017-01-19 19:03:13 --> Loader Class Initialized
INFO - 2017-01-19 19:03:13 --> Database Driver Class Initialized
INFO - 2017-01-19 19:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:03:13 --> Controller Class Initialized
INFO - 2017-01-19 19:03:13 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:03:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:03:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:03:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:03:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:03:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:03:13 --> Final output sent to browser
DEBUG - 2017-01-19 19:03:13 --> Total execution time: 0.0137
INFO - 2017-01-19 19:03:13 --> Config Class Initialized
INFO - 2017-01-19 19:03:13 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:03:13 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:03:13 --> Utf8 Class Initialized
INFO - 2017-01-19 19:03:13 --> URI Class Initialized
INFO - 2017-01-19 19:03:13 --> Router Class Initialized
INFO - 2017-01-19 19:03:13 --> Output Class Initialized
INFO - 2017-01-19 19:03:13 --> Security Class Initialized
DEBUG - 2017-01-19 19:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:03:13 --> Input Class Initialized
INFO - 2017-01-19 19:03:13 --> Language Class Initialized
INFO - 2017-01-19 19:03:13 --> Loader Class Initialized
INFO - 2017-01-19 19:03:13 --> Database Driver Class Initialized
INFO - 2017-01-19 19:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:03:13 --> Controller Class Initialized
INFO - 2017-01-19 19:03:13 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:03:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:03:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:03:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:03:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:03:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:03:13 --> Final output sent to browser
DEBUG - 2017-01-19 19:03:13 --> Total execution time: 0.0154
INFO - 2017-01-19 19:03:20 --> Config Class Initialized
INFO - 2017-01-19 19:03:20 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:03:20 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:03:20 --> Utf8 Class Initialized
INFO - 2017-01-19 19:03:20 --> URI Class Initialized
INFO - 2017-01-19 19:03:20 --> Router Class Initialized
INFO - 2017-01-19 19:03:20 --> Output Class Initialized
INFO - 2017-01-19 19:03:20 --> Security Class Initialized
DEBUG - 2017-01-19 19:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:03:20 --> Input Class Initialized
INFO - 2017-01-19 19:03:20 --> Language Class Initialized
INFO - 2017-01-19 19:03:20 --> Loader Class Initialized
INFO - 2017-01-19 19:03:20 --> Database Driver Class Initialized
INFO - 2017-01-19 19:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:03:20 --> Controller Class Initialized
INFO - 2017-01-19 19:03:20 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:03:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:03:21 --> Config Class Initialized
INFO - 2017-01-19 19:03:21 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:03:21 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:03:21 --> Utf8 Class Initialized
INFO - 2017-01-19 19:03:21 --> URI Class Initialized
INFO - 2017-01-19 19:03:21 --> Router Class Initialized
INFO - 2017-01-19 19:03:21 --> Output Class Initialized
INFO - 2017-01-19 19:03:21 --> Security Class Initialized
DEBUG - 2017-01-19 19:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:03:21 --> Input Class Initialized
INFO - 2017-01-19 19:03:21 --> Language Class Initialized
INFO - 2017-01-19 19:03:21 --> Loader Class Initialized
INFO - 2017-01-19 19:03:21 --> Database Driver Class Initialized
INFO - 2017-01-19 19:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:03:21 --> Controller Class Initialized
INFO - 2017-01-19 19:03:21 --> Helper loaded: date_helper
DEBUG - 2017-01-19 19:03:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:03:21 --> Helper loaded: url_helper
INFO - 2017-01-19 19:03:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:03:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-19 19:03:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-19 19:03:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-19 19:03:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:03:21 --> Final output sent to browser
DEBUG - 2017-01-19 19:03:21 --> Total execution time: 0.0142
INFO - 2017-01-19 19:03:21 --> Config Class Initialized
INFO - 2017-01-19 19:03:21 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:03:21 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:03:21 --> Utf8 Class Initialized
INFO - 2017-01-19 19:03:21 --> URI Class Initialized
INFO - 2017-01-19 19:03:21 --> Router Class Initialized
INFO - 2017-01-19 19:03:21 --> Output Class Initialized
INFO - 2017-01-19 19:03:21 --> Security Class Initialized
DEBUG - 2017-01-19 19:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:03:21 --> Input Class Initialized
INFO - 2017-01-19 19:03:21 --> Language Class Initialized
INFO - 2017-01-19 19:03:21 --> Loader Class Initialized
INFO - 2017-01-19 19:03:21 --> Database Driver Class Initialized
INFO - 2017-01-19 19:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:03:21 --> Controller Class Initialized
INFO - 2017-01-19 19:03:21 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:03:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:03:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:03:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:03:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:03:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:03:21 --> Final output sent to browser
DEBUG - 2017-01-19 19:03:21 --> Total execution time: 0.0136
INFO - 2017-01-19 19:03:24 --> Config Class Initialized
INFO - 2017-01-19 19:03:24 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:03:24 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:03:24 --> Utf8 Class Initialized
INFO - 2017-01-19 19:03:24 --> URI Class Initialized
DEBUG - 2017-01-19 19:03:24 --> No URI present. Default controller set.
INFO - 2017-01-19 19:03:24 --> Router Class Initialized
INFO - 2017-01-19 19:03:24 --> Output Class Initialized
INFO - 2017-01-19 19:03:24 --> Security Class Initialized
DEBUG - 2017-01-19 19:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:03:24 --> Input Class Initialized
INFO - 2017-01-19 19:03:24 --> Language Class Initialized
INFO - 2017-01-19 19:03:24 --> Loader Class Initialized
INFO - 2017-01-19 19:03:24 --> Database Driver Class Initialized
INFO - 2017-01-19 19:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:03:24 --> Controller Class Initialized
INFO - 2017-01-19 19:03:24 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:03:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:03:24 --> Final output sent to browser
DEBUG - 2017-01-19 19:03:24 --> Total execution time: 0.0139
INFO - 2017-01-19 19:03:24 --> Config Class Initialized
INFO - 2017-01-19 19:03:24 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:03:24 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:03:24 --> Utf8 Class Initialized
INFO - 2017-01-19 19:03:24 --> URI Class Initialized
INFO - 2017-01-19 19:03:24 --> Router Class Initialized
INFO - 2017-01-19 19:03:24 --> Output Class Initialized
INFO - 2017-01-19 19:03:24 --> Security Class Initialized
DEBUG - 2017-01-19 19:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:03:24 --> Input Class Initialized
INFO - 2017-01-19 19:03:24 --> Language Class Initialized
INFO - 2017-01-19 19:03:24 --> Loader Class Initialized
INFO - 2017-01-19 19:03:24 --> Database Driver Class Initialized
INFO - 2017-01-19 19:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:03:24 --> Controller Class Initialized
INFO - 2017-01-19 19:03:24 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:03:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:03:24 --> Final output sent to browser
DEBUG - 2017-01-19 19:03:24 --> Total execution time: 0.0148
INFO - 2017-01-19 19:08:15 --> Config Class Initialized
INFO - 2017-01-19 19:08:15 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:08:15 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:08:15 --> Utf8 Class Initialized
INFO - 2017-01-19 19:08:15 --> URI Class Initialized
INFO - 2017-01-19 19:08:15 --> Router Class Initialized
INFO - 2017-01-19 19:08:15 --> Output Class Initialized
INFO - 2017-01-19 19:08:15 --> Security Class Initialized
DEBUG - 2017-01-19 19:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:08:15 --> Input Class Initialized
INFO - 2017-01-19 19:08:15 --> Language Class Initialized
INFO - 2017-01-19 19:08:15 --> Loader Class Initialized
INFO - 2017-01-19 19:08:15 --> Database Driver Class Initialized
INFO - 2017-01-19 19:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:08:15 --> Controller Class Initialized
INFO - 2017-01-19 19:08:15 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:08:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-19 19:08:15 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-19 19:08:15 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Karely Yissel Rodriguez')
INFO - 2017-01-19 19:08:15 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-19 19:08:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-19 19:08:16 --> Config Class Initialized
INFO - 2017-01-19 19:08:16 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:08:16 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:08:16 --> Utf8 Class Initialized
INFO - 2017-01-19 19:08:16 --> URI Class Initialized
INFO - 2017-01-19 19:08:16 --> Router Class Initialized
INFO - 2017-01-19 19:08:16 --> Output Class Initialized
INFO - 2017-01-19 19:08:16 --> Security Class Initialized
DEBUG - 2017-01-19 19:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:08:16 --> Input Class Initialized
INFO - 2017-01-19 19:08:16 --> Language Class Initialized
INFO - 2017-01-19 19:08:16 --> Loader Class Initialized
INFO - 2017-01-19 19:08:16 --> Database Driver Class Initialized
INFO - 2017-01-19 19:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:08:16 --> Controller Class Initialized
INFO - 2017-01-19 19:08:16 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:08:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:08:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:08:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:08:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:08:16 --> Final output sent to browser
DEBUG - 2017-01-19 19:08:16 --> Total execution time: 0.0130
INFO - 2017-01-19 19:08:32 --> Config Class Initialized
INFO - 2017-01-19 19:08:32 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:08:32 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:08:32 --> Utf8 Class Initialized
INFO - 2017-01-19 19:08:32 --> URI Class Initialized
INFO - 2017-01-19 19:08:32 --> Router Class Initialized
INFO - 2017-01-19 19:08:32 --> Output Class Initialized
INFO - 2017-01-19 19:08:32 --> Security Class Initialized
DEBUG - 2017-01-19 19:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:08:32 --> Input Class Initialized
INFO - 2017-01-19 19:08:32 --> Language Class Initialized
INFO - 2017-01-19 19:08:32 --> Loader Class Initialized
INFO - 2017-01-19 19:08:32 --> Database Driver Class Initialized
INFO - 2017-01-19 19:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:08:32 --> Controller Class Initialized
INFO - 2017-01-19 19:08:32 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:08:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-19 19:08:32 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-19 19:08:32 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Karely Yissel Rodriguez')
INFO - 2017-01-19 19:08:32 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-19 19:08:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-19 19:08:32 --> Config Class Initialized
INFO - 2017-01-19 19:08:32 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:08:32 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:08:32 --> Utf8 Class Initialized
INFO - 2017-01-19 19:08:32 --> URI Class Initialized
INFO - 2017-01-19 19:08:32 --> Router Class Initialized
INFO - 2017-01-19 19:08:32 --> Output Class Initialized
INFO - 2017-01-19 19:08:32 --> Security Class Initialized
DEBUG - 2017-01-19 19:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:08:32 --> Input Class Initialized
INFO - 2017-01-19 19:08:32 --> Language Class Initialized
INFO - 2017-01-19 19:08:32 --> Loader Class Initialized
INFO - 2017-01-19 19:08:32 --> Database Driver Class Initialized
INFO - 2017-01-19 19:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:08:32 --> Controller Class Initialized
INFO - 2017-01-19 19:08:32 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:08:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:08:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:08:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:08:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:08:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:08:32 --> Final output sent to browser
DEBUG - 2017-01-19 19:08:32 --> Total execution time: 0.0139
INFO - 2017-01-19 19:08:39 --> Config Class Initialized
INFO - 2017-01-19 19:08:39 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:08:39 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:08:39 --> Utf8 Class Initialized
INFO - 2017-01-19 19:08:39 --> URI Class Initialized
DEBUG - 2017-01-19 19:08:39 --> No URI present. Default controller set.
INFO - 2017-01-19 19:08:39 --> Router Class Initialized
INFO - 2017-01-19 19:08:39 --> Output Class Initialized
INFO - 2017-01-19 19:08:39 --> Security Class Initialized
DEBUG - 2017-01-19 19:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:08:39 --> Input Class Initialized
INFO - 2017-01-19 19:08:39 --> Language Class Initialized
INFO - 2017-01-19 19:08:39 --> Loader Class Initialized
INFO - 2017-01-19 19:08:39 --> Database Driver Class Initialized
INFO - 2017-01-19 19:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:08:39 --> Controller Class Initialized
INFO - 2017-01-19 19:08:39 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:08:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:08:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:08:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:08:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:08:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:08:39 --> Final output sent to browser
DEBUG - 2017-01-19 19:08:39 --> Total execution time: 0.0140
INFO - 2017-01-19 19:08:41 --> Config Class Initialized
INFO - 2017-01-19 19:08:41 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:08:41 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:08:41 --> Utf8 Class Initialized
INFO - 2017-01-19 19:08:41 --> URI Class Initialized
INFO - 2017-01-19 19:08:41 --> Router Class Initialized
INFO - 2017-01-19 19:08:41 --> Output Class Initialized
INFO - 2017-01-19 19:08:41 --> Security Class Initialized
DEBUG - 2017-01-19 19:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:08:41 --> Input Class Initialized
INFO - 2017-01-19 19:08:41 --> Language Class Initialized
INFO - 2017-01-19 19:08:41 --> Loader Class Initialized
INFO - 2017-01-19 19:08:41 --> Database Driver Class Initialized
INFO - 2017-01-19 19:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:08:41 --> Controller Class Initialized
INFO - 2017-01-19 19:08:41 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:08:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:08:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:08:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:08:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:08:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:08:41 --> Final output sent to browser
DEBUG - 2017-01-19 19:08:41 --> Total execution time: 0.0141
INFO - 2017-01-19 19:09:17 --> Config Class Initialized
INFO - 2017-01-19 19:09:17 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:09:17 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:09:17 --> Utf8 Class Initialized
INFO - 2017-01-19 19:09:17 --> URI Class Initialized
INFO - 2017-01-19 19:09:17 --> Router Class Initialized
INFO - 2017-01-19 19:09:17 --> Output Class Initialized
INFO - 2017-01-19 19:09:17 --> Security Class Initialized
DEBUG - 2017-01-19 19:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:09:17 --> Input Class Initialized
INFO - 2017-01-19 19:09:17 --> Language Class Initialized
INFO - 2017-01-19 19:09:17 --> Loader Class Initialized
INFO - 2017-01-19 19:09:17 --> Database Driver Class Initialized
INFO - 2017-01-19 19:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:09:17 --> Controller Class Initialized
INFO - 2017-01-19 19:09:17 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:09:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:09:17 --> Config Class Initialized
INFO - 2017-01-19 19:09:17 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:09:17 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:09:17 --> Utf8 Class Initialized
INFO - 2017-01-19 19:09:17 --> URI Class Initialized
INFO - 2017-01-19 19:09:17 --> Router Class Initialized
INFO - 2017-01-19 19:09:17 --> Output Class Initialized
INFO - 2017-01-19 19:09:17 --> Security Class Initialized
DEBUG - 2017-01-19 19:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:09:17 --> Input Class Initialized
INFO - 2017-01-19 19:09:17 --> Language Class Initialized
INFO - 2017-01-19 19:09:17 --> Loader Class Initialized
INFO - 2017-01-19 19:09:17 --> Database Driver Class Initialized
INFO - 2017-01-19 19:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:09:17 --> Controller Class Initialized
INFO - 2017-01-19 19:09:17 --> Helper loaded: date_helper
DEBUG - 2017-01-19 19:09:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:09:17 --> Helper loaded: url_helper
INFO - 2017-01-19 19:09:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:09:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-19 19:09:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-19 19:09:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-19 19:09:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:09:17 --> Final output sent to browser
DEBUG - 2017-01-19 19:09:17 --> Total execution time: 0.0145
INFO - 2017-01-19 19:09:21 --> Config Class Initialized
INFO - 2017-01-19 19:09:21 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:09:21 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:09:21 --> Utf8 Class Initialized
INFO - 2017-01-19 19:09:21 --> URI Class Initialized
INFO - 2017-01-19 19:09:21 --> Router Class Initialized
INFO - 2017-01-19 19:09:21 --> Output Class Initialized
INFO - 2017-01-19 19:09:21 --> Security Class Initialized
DEBUG - 2017-01-19 19:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:09:21 --> Input Class Initialized
INFO - 2017-01-19 19:09:21 --> Language Class Initialized
INFO - 2017-01-19 19:09:21 --> Loader Class Initialized
INFO - 2017-01-19 19:09:21 --> Database Driver Class Initialized
INFO - 2017-01-19 19:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:09:21 --> Controller Class Initialized
INFO - 2017-01-19 19:09:21 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:09:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:09:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:09:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:09:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:09:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:09:21 --> Final output sent to browser
DEBUG - 2017-01-19 19:09:21 --> Total execution time: 0.0128
INFO - 2017-01-19 19:09:46 --> Config Class Initialized
INFO - 2017-01-19 19:09:46 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:09:46 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:09:46 --> Utf8 Class Initialized
INFO - 2017-01-19 19:09:46 --> URI Class Initialized
INFO - 2017-01-19 19:09:46 --> Router Class Initialized
INFO - 2017-01-19 19:09:46 --> Output Class Initialized
INFO - 2017-01-19 19:09:46 --> Security Class Initialized
DEBUG - 2017-01-19 19:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:09:46 --> Input Class Initialized
INFO - 2017-01-19 19:09:46 --> Language Class Initialized
INFO - 2017-01-19 19:09:46 --> Loader Class Initialized
INFO - 2017-01-19 19:09:46 --> Database Driver Class Initialized
INFO - 2017-01-19 19:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:09:46 --> Controller Class Initialized
INFO - 2017-01-19 19:09:46 --> Helper loaded: date_helper
DEBUG - 2017-01-19 19:09:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:09:46 --> Helper loaded: url_helper
INFO - 2017-01-19 19:09:46 --> Final output sent to browser
DEBUG - 2017-01-19 19:09:46 --> Total execution time: 0.0122
INFO - 2017-01-19 19:09:50 --> Config Class Initialized
INFO - 2017-01-19 19:09:50 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:09:50 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:09:50 --> Utf8 Class Initialized
INFO - 2017-01-19 19:09:50 --> URI Class Initialized
INFO - 2017-01-19 19:09:50 --> Router Class Initialized
INFO - 2017-01-19 19:09:50 --> Output Class Initialized
INFO - 2017-01-19 19:09:50 --> Security Class Initialized
DEBUG - 2017-01-19 19:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:09:50 --> Input Class Initialized
INFO - 2017-01-19 19:09:50 --> Language Class Initialized
INFO - 2017-01-19 19:09:50 --> Loader Class Initialized
INFO - 2017-01-19 19:09:50 --> Database Driver Class Initialized
INFO - 2017-01-19 19:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:09:50 --> Controller Class Initialized
INFO - 2017-01-19 19:09:50 --> Helper loaded: date_helper
DEBUG - 2017-01-19 19:09:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:09:50 --> Helper loaded: url_helper
INFO - 2017-01-19 19:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-19 19:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-19 19:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-19 19:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-19 19:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:09:50 --> Final output sent to browser
DEBUG - 2017-01-19 19:09:50 --> Total execution time: 0.0142
INFO - 2017-01-19 19:09:51 --> Config Class Initialized
INFO - 2017-01-19 19:09:51 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:09:51 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:09:51 --> Utf8 Class Initialized
INFO - 2017-01-19 19:09:51 --> URI Class Initialized
INFO - 2017-01-19 19:09:51 --> Router Class Initialized
INFO - 2017-01-19 19:09:51 --> Output Class Initialized
INFO - 2017-01-19 19:09:51 --> Security Class Initialized
DEBUG - 2017-01-19 19:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:09:51 --> Input Class Initialized
INFO - 2017-01-19 19:09:51 --> Language Class Initialized
INFO - 2017-01-19 19:09:51 --> Loader Class Initialized
INFO - 2017-01-19 19:09:51 --> Database Driver Class Initialized
INFO - 2017-01-19 19:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:09:51 --> Controller Class Initialized
INFO - 2017-01-19 19:09:51 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:09:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:09:51 --> Final output sent to browser
DEBUG - 2017-01-19 19:09:51 --> Total execution time: 0.0136
INFO - 2017-01-19 19:10:08 --> Config Class Initialized
INFO - 2017-01-19 19:10:08 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:10:08 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:10:08 --> Utf8 Class Initialized
INFO - 2017-01-19 19:10:08 --> URI Class Initialized
INFO - 2017-01-19 19:10:08 --> Router Class Initialized
INFO - 2017-01-19 19:10:08 --> Output Class Initialized
INFO - 2017-01-19 19:10:08 --> Security Class Initialized
DEBUG - 2017-01-19 19:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:10:08 --> Input Class Initialized
INFO - 2017-01-19 19:10:08 --> Language Class Initialized
INFO - 2017-01-19 19:10:08 --> Loader Class Initialized
INFO - 2017-01-19 19:10:08 --> Database Driver Class Initialized
INFO - 2017-01-19 19:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:10:08 --> Controller Class Initialized
INFO - 2017-01-19 19:10:08 --> Helper loaded: date_helper
DEBUG - 2017-01-19 19:10:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:10:08 --> Helper loaded: url_helper
INFO - 2017-01-19 19:10:08 --> Final output sent to browser
DEBUG - 2017-01-19 19:10:08 --> Total execution time: 0.0172
INFO - 2017-01-19 19:10:09 --> Config Class Initialized
INFO - 2017-01-19 19:10:09 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:10:09 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:10:09 --> Utf8 Class Initialized
INFO - 2017-01-19 19:10:09 --> URI Class Initialized
INFO - 2017-01-19 19:10:09 --> Router Class Initialized
INFO - 2017-01-19 19:10:09 --> Output Class Initialized
INFO - 2017-01-19 19:10:09 --> Security Class Initialized
DEBUG - 2017-01-19 19:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:10:09 --> Input Class Initialized
INFO - 2017-01-19 19:10:09 --> Language Class Initialized
INFO - 2017-01-19 19:10:09 --> Loader Class Initialized
INFO - 2017-01-19 19:10:09 --> Database Driver Class Initialized
INFO - 2017-01-19 19:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:10:09 --> Controller Class Initialized
INFO - 2017-01-19 19:10:09 --> Helper loaded: date_helper
DEBUG - 2017-01-19 19:10:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:10:09 --> Helper loaded: url_helper
INFO - 2017-01-19 19:10:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:10:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-19 19:10:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-19 19:10:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-19 19:10:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-19 19:10:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:10:09 --> Final output sent to browser
DEBUG - 2017-01-19 19:10:09 --> Total execution time: 0.0137
INFO - 2017-01-19 19:10:11 --> Config Class Initialized
INFO - 2017-01-19 19:10:11 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:10:11 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:10:11 --> Utf8 Class Initialized
INFO - 2017-01-19 19:10:11 --> URI Class Initialized
INFO - 2017-01-19 19:10:11 --> Router Class Initialized
INFO - 2017-01-19 19:10:11 --> Output Class Initialized
INFO - 2017-01-19 19:10:11 --> Security Class Initialized
DEBUG - 2017-01-19 19:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:10:11 --> Input Class Initialized
INFO - 2017-01-19 19:10:11 --> Language Class Initialized
INFO - 2017-01-19 19:10:11 --> Loader Class Initialized
INFO - 2017-01-19 19:10:11 --> Database Driver Class Initialized
INFO - 2017-01-19 19:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:10:11 --> Controller Class Initialized
INFO - 2017-01-19 19:10:11 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:10:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:10:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:10:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:10:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:10:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:10:11 --> Final output sent to browser
DEBUG - 2017-01-19 19:10:11 --> Total execution time: 0.0139
INFO - 2017-01-19 19:10:12 --> Config Class Initialized
INFO - 2017-01-19 19:10:12 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:10:12 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:10:12 --> Utf8 Class Initialized
INFO - 2017-01-19 19:10:12 --> URI Class Initialized
INFO - 2017-01-19 19:10:12 --> Router Class Initialized
INFO - 2017-01-19 19:10:12 --> Output Class Initialized
INFO - 2017-01-19 19:10:12 --> Security Class Initialized
DEBUG - 2017-01-19 19:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:10:12 --> Input Class Initialized
INFO - 2017-01-19 19:10:12 --> Language Class Initialized
INFO - 2017-01-19 19:10:12 --> Loader Class Initialized
INFO - 2017-01-19 19:10:12 --> Database Driver Class Initialized
INFO - 2017-01-19 19:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:10:12 --> Controller Class Initialized
INFO - 2017-01-19 19:10:12 --> Upload Class Initialized
INFO - 2017-01-19 19:10:12 --> Helper loaded: date_helper
DEBUG - 2017-01-19 19:10:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:10:12 --> Helper loaded: url_helper
INFO - 2017-01-19 19:10:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:10:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-19 19:10:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-01-19 19:10:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-01-19 19:10:12 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-19 19:10:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:10:12 --> Final output sent to browser
DEBUG - 2017-01-19 19:10:12 --> Total execution time: 0.0159
INFO - 2017-01-19 19:10:14 --> Config Class Initialized
INFO - 2017-01-19 19:10:14 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:10:14 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:10:14 --> Utf8 Class Initialized
INFO - 2017-01-19 19:10:14 --> URI Class Initialized
INFO - 2017-01-19 19:10:14 --> Router Class Initialized
INFO - 2017-01-19 19:10:14 --> Output Class Initialized
INFO - 2017-01-19 19:10:14 --> Security Class Initialized
DEBUG - 2017-01-19 19:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:10:14 --> Input Class Initialized
INFO - 2017-01-19 19:10:14 --> Language Class Initialized
INFO - 2017-01-19 19:10:14 --> Loader Class Initialized
INFO - 2017-01-19 19:10:14 --> Database Driver Class Initialized
INFO - 2017-01-19 19:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:10:14 --> Controller Class Initialized
INFO - 2017-01-19 19:10:14 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:10:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:10:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:10:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:10:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:10:14 --> Final output sent to browser
DEBUG - 2017-01-19 19:10:14 --> Total execution time: 0.0132
INFO - 2017-01-19 19:11:15 --> Config Class Initialized
INFO - 2017-01-19 19:11:15 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:11:15 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:11:15 --> Utf8 Class Initialized
INFO - 2017-01-19 19:11:15 --> URI Class Initialized
INFO - 2017-01-19 19:11:15 --> Router Class Initialized
INFO - 2017-01-19 19:11:15 --> Output Class Initialized
INFO - 2017-01-19 19:11:15 --> Security Class Initialized
DEBUG - 2017-01-19 19:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:11:15 --> Input Class Initialized
INFO - 2017-01-19 19:11:15 --> Language Class Initialized
INFO - 2017-01-19 19:11:15 --> Loader Class Initialized
INFO - 2017-01-19 19:11:15 --> Database Driver Class Initialized
INFO - 2017-01-19 19:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:11:15 --> Controller Class Initialized
INFO - 2017-01-19 19:11:15 --> Helper loaded: date_helper
DEBUG - 2017-01-19 19:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:11:15 --> Helper loaded: url_helper
INFO - 2017-01-19 19:11:15 --> Helper loaded: download_helper
INFO - 2017-01-19 19:11:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:11:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-19 19:11:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-19 19:11:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-19 19:11:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:11:15 --> Final output sent to browser
DEBUG - 2017-01-19 19:11:15 --> Total execution time: 0.0530
INFO - 2017-01-19 19:11:17 --> Config Class Initialized
INFO - 2017-01-19 19:11:17 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:11:17 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:11:17 --> Utf8 Class Initialized
INFO - 2017-01-19 19:11:17 --> URI Class Initialized
INFO - 2017-01-19 19:11:17 --> Router Class Initialized
INFO - 2017-01-19 19:11:17 --> Output Class Initialized
INFO - 2017-01-19 19:11:17 --> Security Class Initialized
DEBUG - 2017-01-19 19:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:11:17 --> Input Class Initialized
INFO - 2017-01-19 19:11:17 --> Language Class Initialized
INFO - 2017-01-19 19:11:17 --> Loader Class Initialized
INFO - 2017-01-19 19:11:17 --> Database Driver Class Initialized
INFO - 2017-01-19 19:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:11:17 --> Controller Class Initialized
INFO - 2017-01-19 19:11:17 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:11:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:11:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:11:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:11:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:11:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:11:17 --> Final output sent to browser
DEBUG - 2017-01-19 19:11:17 --> Total execution time: 0.0147
INFO - 2017-01-19 19:11:33 --> Config Class Initialized
INFO - 2017-01-19 19:11:33 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:11:33 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:11:33 --> Utf8 Class Initialized
INFO - 2017-01-19 19:11:33 --> URI Class Initialized
DEBUG - 2017-01-19 19:11:33 --> No URI present. Default controller set.
INFO - 2017-01-19 19:11:33 --> Router Class Initialized
INFO - 2017-01-19 19:11:33 --> Output Class Initialized
INFO - 2017-01-19 19:11:33 --> Security Class Initialized
DEBUG - 2017-01-19 19:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:11:33 --> Input Class Initialized
INFO - 2017-01-19 19:11:33 --> Language Class Initialized
INFO - 2017-01-19 19:11:33 --> Loader Class Initialized
INFO - 2017-01-19 19:11:33 --> Database Driver Class Initialized
INFO - 2017-01-19 19:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:11:33 --> Controller Class Initialized
INFO - 2017-01-19 19:11:33 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:11:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:11:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:11:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:11:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:11:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:11:33 --> Final output sent to browser
DEBUG - 2017-01-19 19:11:33 --> Total execution time: 0.0160
INFO - 2017-01-19 19:11:42 --> Config Class Initialized
INFO - 2017-01-19 19:11:42 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:11:42 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:11:42 --> Utf8 Class Initialized
INFO - 2017-01-19 19:11:42 --> URI Class Initialized
INFO - 2017-01-19 19:11:42 --> Router Class Initialized
INFO - 2017-01-19 19:11:42 --> Output Class Initialized
INFO - 2017-01-19 19:11:42 --> Security Class Initialized
DEBUG - 2017-01-19 19:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:11:42 --> Input Class Initialized
INFO - 2017-01-19 19:11:42 --> Language Class Initialized
INFO - 2017-01-19 19:11:42 --> Loader Class Initialized
INFO - 2017-01-19 19:11:42 --> Database Driver Class Initialized
INFO - 2017-01-19 19:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:11:42 --> Controller Class Initialized
INFO - 2017-01-19 19:11:42 --> Helper loaded: date_helper
DEBUG - 2017-01-19 19:11:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:11:42 --> Helper loaded: url_helper
INFO - 2017-01-19 19:11:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:11:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-19 19:11:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-19 19:11:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-19 19:11:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:11:42 --> Final output sent to browser
DEBUG - 2017-01-19 19:11:42 --> Total execution time: 0.0149
INFO - 2017-01-19 19:11:43 --> Config Class Initialized
INFO - 2017-01-19 19:11:43 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:11:43 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:11:43 --> Utf8 Class Initialized
INFO - 2017-01-19 19:11:43 --> URI Class Initialized
INFO - 2017-01-19 19:11:43 --> Router Class Initialized
INFO - 2017-01-19 19:11:43 --> Output Class Initialized
INFO - 2017-01-19 19:11:43 --> Security Class Initialized
DEBUG - 2017-01-19 19:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:11:43 --> Input Class Initialized
INFO - 2017-01-19 19:11:43 --> Language Class Initialized
INFO - 2017-01-19 19:11:43 --> Loader Class Initialized
INFO - 2017-01-19 19:11:43 --> Database Driver Class Initialized
INFO - 2017-01-19 19:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:11:43 --> Controller Class Initialized
INFO - 2017-01-19 19:11:43 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:11:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:11:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:11:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:11:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:11:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:11:43 --> Final output sent to browser
DEBUG - 2017-01-19 19:11:43 --> Total execution time: 0.0140
INFO - 2017-01-19 19:11:44 --> Config Class Initialized
INFO - 2017-01-19 19:11:44 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:11:44 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:11:44 --> Utf8 Class Initialized
INFO - 2017-01-19 19:11:44 --> URI Class Initialized
INFO - 2017-01-19 19:11:44 --> Router Class Initialized
INFO - 2017-01-19 19:11:44 --> Output Class Initialized
INFO - 2017-01-19 19:11:44 --> Security Class Initialized
DEBUG - 2017-01-19 19:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:11:44 --> Input Class Initialized
INFO - 2017-01-19 19:11:44 --> Language Class Initialized
INFO - 2017-01-19 19:11:44 --> Loader Class Initialized
INFO - 2017-01-19 19:11:44 --> Database Driver Class Initialized
INFO - 2017-01-19 19:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:11:44 --> Controller Class Initialized
INFO - 2017-01-19 19:11:44 --> Helper loaded: date_helper
DEBUG - 2017-01-19 19:11:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:11:44 --> Helper loaded: url_helper
INFO - 2017-01-19 19:11:44 --> Helper loaded: download_helper
INFO - 2017-01-19 19:11:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:11:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-19 19:11:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-19 19:11:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-19 19:11:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:11:44 --> Final output sent to browser
DEBUG - 2017-01-19 19:11:44 --> Total execution time: 0.0236
INFO - 2017-01-19 19:11:45 --> Config Class Initialized
INFO - 2017-01-19 19:11:45 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:11:45 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:11:45 --> Utf8 Class Initialized
INFO - 2017-01-19 19:11:45 --> URI Class Initialized
INFO - 2017-01-19 19:11:45 --> Router Class Initialized
INFO - 2017-01-19 19:11:45 --> Output Class Initialized
INFO - 2017-01-19 19:11:45 --> Security Class Initialized
DEBUG - 2017-01-19 19:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:11:45 --> Input Class Initialized
INFO - 2017-01-19 19:11:45 --> Language Class Initialized
INFO - 2017-01-19 19:11:45 --> Loader Class Initialized
INFO - 2017-01-19 19:11:45 --> Database Driver Class Initialized
INFO - 2017-01-19 19:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:11:45 --> Controller Class Initialized
INFO - 2017-01-19 19:11:45 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:11:45 --> Final output sent to browser
DEBUG - 2017-01-19 19:11:45 --> Total execution time: 0.0163
INFO - 2017-01-19 19:11:49 --> Config Class Initialized
INFO - 2017-01-19 19:11:49 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:11:49 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:11:49 --> Utf8 Class Initialized
INFO - 2017-01-19 19:11:49 --> URI Class Initialized
INFO - 2017-01-19 19:11:49 --> Router Class Initialized
INFO - 2017-01-19 19:11:49 --> Output Class Initialized
INFO - 2017-01-19 19:11:49 --> Security Class Initialized
DEBUG - 2017-01-19 19:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:11:49 --> Input Class Initialized
INFO - 2017-01-19 19:11:49 --> Language Class Initialized
INFO - 2017-01-19 19:11:49 --> Loader Class Initialized
INFO - 2017-01-19 19:11:49 --> Database Driver Class Initialized
INFO - 2017-01-19 19:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:11:49 --> Controller Class Initialized
INFO - 2017-01-19 19:11:49 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:11:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:11:49 --> Config Class Initialized
INFO - 2017-01-19 19:11:49 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:11:49 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:11:49 --> Utf8 Class Initialized
INFO - 2017-01-19 19:11:49 --> URI Class Initialized
DEBUG - 2017-01-19 19:11:49 --> No URI present. Default controller set.
INFO - 2017-01-19 19:11:49 --> Router Class Initialized
INFO - 2017-01-19 19:11:49 --> Output Class Initialized
INFO - 2017-01-19 19:11:49 --> Security Class Initialized
DEBUG - 2017-01-19 19:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:11:49 --> Input Class Initialized
INFO - 2017-01-19 19:11:49 --> Language Class Initialized
INFO - 2017-01-19 19:11:49 --> Loader Class Initialized
INFO - 2017-01-19 19:11:49 --> Database Driver Class Initialized
INFO - 2017-01-19 19:11:49 --> Config Class Initialized
INFO - 2017-01-19 19:11:49 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:11:49 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:11:49 --> Utf8 Class Initialized
INFO - 2017-01-19 19:11:49 --> URI Class Initialized
INFO - 2017-01-19 19:11:49 --> Router Class Initialized
INFO - 2017-01-19 19:11:49 --> Output Class Initialized
INFO - 2017-01-19 19:11:49 --> Security Class Initialized
DEBUG - 2017-01-19 19:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:11:49 --> Input Class Initialized
INFO - 2017-01-19 19:11:49 --> Language Class Initialized
INFO - 2017-01-19 19:11:49 --> Loader Class Initialized
INFO - 2017-01-19 19:11:49 --> Database Driver Class Initialized
INFO - 2017-01-19 19:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:11:50 --> Controller Class Initialized
INFO - 2017-01-19 19:11:50 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:11:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:11:50 --> Controller Class Initialized
INFO - 2017-01-19 19:11:50 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:11:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:11:50 --> Final output sent to browser
DEBUG - 2017-01-19 19:11:50 --> Total execution time: 0.0803
INFO - 2017-01-19 19:11:50 --> Final output sent to browser
DEBUG - 2017-01-19 19:11:50 --> Total execution time: 0.0789
INFO - 2017-01-19 19:11:51 --> Config Class Initialized
INFO - 2017-01-19 19:11:51 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:11:51 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:11:51 --> Utf8 Class Initialized
INFO - 2017-01-19 19:11:51 --> URI Class Initialized
INFO - 2017-01-19 19:11:51 --> Router Class Initialized
INFO - 2017-01-19 19:11:51 --> Output Class Initialized
INFO - 2017-01-19 19:11:51 --> Security Class Initialized
DEBUG - 2017-01-19 19:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:11:51 --> Input Class Initialized
INFO - 2017-01-19 19:11:51 --> Language Class Initialized
INFO - 2017-01-19 19:11:51 --> Loader Class Initialized
INFO - 2017-01-19 19:11:51 --> Database Driver Class Initialized
INFO - 2017-01-19 19:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:11:51 --> Controller Class Initialized
INFO - 2017-01-19 19:11:51 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:11:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:11:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:11:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:11:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:11:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:11:51 --> Final output sent to browser
DEBUG - 2017-01-19 19:11:51 --> Total execution time: 0.0137
INFO - 2017-01-19 19:24:03 --> Config Class Initialized
INFO - 2017-01-19 19:24:03 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:24:03 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:24:03 --> Utf8 Class Initialized
INFO - 2017-01-19 19:24:03 --> URI Class Initialized
INFO - 2017-01-19 19:24:03 --> Router Class Initialized
INFO - 2017-01-19 19:24:03 --> Output Class Initialized
INFO - 2017-01-19 19:24:03 --> Security Class Initialized
DEBUG - 2017-01-19 19:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:24:03 --> Input Class Initialized
INFO - 2017-01-19 19:24:03 --> Language Class Initialized
INFO - 2017-01-19 19:24:03 --> Loader Class Initialized
INFO - 2017-01-19 19:24:03 --> Database Driver Class Initialized
INFO - 2017-01-19 19:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:24:03 --> Controller Class Initialized
INFO - 2017-01-19 19:24:03 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:24:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:24:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:24:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:24:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:24:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:24:03 --> Final output sent to browser
DEBUG - 2017-01-19 19:24:03 --> Total execution time: 0.0160
INFO - 2017-01-19 19:24:05 --> Config Class Initialized
INFO - 2017-01-19 19:24:05 --> Hooks Class Initialized
DEBUG - 2017-01-19 19:24:05 --> UTF-8 Support Enabled
INFO - 2017-01-19 19:24:05 --> Utf8 Class Initialized
INFO - 2017-01-19 19:24:05 --> URI Class Initialized
INFO - 2017-01-19 19:24:05 --> Router Class Initialized
INFO - 2017-01-19 19:24:05 --> Output Class Initialized
INFO - 2017-01-19 19:24:05 --> Security Class Initialized
DEBUG - 2017-01-19 19:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 19:24:05 --> Input Class Initialized
INFO - 2017-01-19 19:24:05 --> Language Class Initialized
INFO - 2017-01-19 19:24:05 --> Loader Class Initialized
INFO - 2017-01-19 19:24:05 --> Database Driver Class Initialized
INFO - 2017-01-19 19:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 19:24:05 --> Controller Class Initialized
INFO - 2017-01-19 19:24:05 --> Helper loaded: url_helper
DEBUG - 2017-01-19 19:24:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 19:24:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 19:24:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 19:24:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 19:24:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 19:24:05 --> Final output sent to browser
DEBUG - 2017-01-19 19:24:05 --> Total execution time: 0.0164
INFO - 2017-01-19 21:00:45 --> Config Class Initialized
INFO - 2017-01-19 21:00:45 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:00:45 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:00:45 --> Utf8 Class Initialized
INFO - 2017-01-19 21:00:45 --> URI Class Initialized
DEBUG - 2017-01-19 21:00:45 --> No URI present. Default controller set.
INFO - 2017-01-19 21:00:45 --> Router Class Initialized
INFO - 2017-01-19 21:00:45 --> Output Class Initialized
INFO - 2017-01-19 21:00:45 --> Security Class Initialized
DEBUG - 2017-01-19 21:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:00:45 --> Input Class Initialized
INFO - 2017-01-19 21:00:45 --> Language Class Initialized
INFO - 2017-01-19 21:00:45 --> Loader Class Initialized
INFO - 2017-01-19 21:00:45 --> Database Driver Class Initialized
INFO - 2017-01-19 21:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:00:45 --> Controller Class Initialized
INFO - 2017-01-19 21:00:45 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:00:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:00:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 21:00:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 21:00:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 21:00:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 21:00:45 --> Final output sent to browser
DEBUG - 2017-01-19 21:00:45 --> Total execution time: 0.0183
INFO - 2017-01-19 21:28:28 --> Config Class Initialized
INFO - 2017-01-19 21:28:28 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:28:28 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:28:28 --> Utf8 Class Initialized
INFO - 2017-01-19 21:28:28 --> URI Class Initialized
DEBUG - 2017-01-19 21:28:28 --> No URI present. Default controller set.
INFO - 2017-01-19 21:28:28 --> Router Class Initialized
INFO - 2017-01-19 21:28:28 --> Output Class Initialized
INFO - 2017-01-19 21:28:28 --> Security Class Initialized
DEBUG - 2017-01-19 21:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:28:28 --> Input Class Initialized
INFO - 2017-01-19 21:28:28 --> Language Class Initialized
INFO - 2017-01-19 21:28:28 --> Loader Class Initialized
INFO - 2017-01-19 21:28:28 --> Database Driver Class Initialized
INFO - 2017-01-19 21:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:28:28 --> Controller Class Initialized
INFO - 2017-01-19 21:28:28 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:28:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:28:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 21:28:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 21:28:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 21:28:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 21:28:28 --> Final output sent to browser
DEBUG - 2017-01-19 21:28:28 --> Total execution time: 0.0425
INFO - 2017-01-19 21:28:30 --> Config Class Initialized
INFO - 2017-01-19 21:28:30 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:28:30 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:28:30 --> Utf8 Class Initialized
INFO - 2017-01-19 21:28:30 --> URI Class Initialized
INFO - 2017-01-19 21:28:30 --> Router Class Initialized
INFO - 2017-01-19 21:28:30 --> Output Class Initialized
INFO - 2017-01-19 21:28:30 --> Security Class Initialized
DEBUG - 2017-01-19 21:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:28:30 --> Input Class Initialized
INFO - 2017-01-19 21:28:30 --> Language Class Initialized
INFO - 2017-01-19 21:28:30 --> Loader Class Initialized
INFO - 2017-01-19 21:28:30 --> Database Driver Class Initialized
INFO - 2017-01-19 21:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:28:30 --> Controller Class Initialized
INFO - 2017-01-19 21:28:30 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:28:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:28:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 21:28:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 21:28:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 21:28:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 21:28:30 --> Final output sent to browser
DEBUG - 2017-01-19 21:28:30 --> Total execution time: 0.0173
INFO - 2017-01-19 21:28:39 --> Config Class Initialized
INFO - 2017-01-19 21:28:39 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:28:39 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:28:39 --> Utf8 Class Initialized
INFO - 2017-01-19 21:28:39 --> URI Class Initialized
INFO - 2017-01-19 21:28:39 --> Router Class Initialized
INFO - 2017-01-19 21:28:39 --> Output Class Initialized
INFO - 2017-01-19 21:28:39 --> Security Class Initialized
DEBUG - 2017-01-19 21:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:28:39 --> Input Class Initialized
INFO - 2017-01-19 21:28:39 --> Language Class Initialized
INFO - 2017-01-19 21:28:39 --> Loader Class Initialized
INFO - 2017-01-19 21:28:39 --> Database Driver Class Initialized
INFO - 2017-01-19 21:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:28:39 --> Controller Class Initialized
INFO - 2017-01-19 21:28:39 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:28:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:28:39 --> Helper loaded: form_helper
INFO - 2017-01-19 21:28:39 --> Form Validation Class Initialized
INFO - 2017-01-19 21:28:39 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-19 21:28:39 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-19 21:28:39 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-19 21:28:39 --> Final output sent to browser
DEBUG - 2017-01-19 21:28:39 --> Total execution time: 0.1733
INFO - 2017-01-19 21:28:40 --> Config Class Initialized
INFO - 2017-01-19 21:28:40 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:28:40 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:28:40 --> Utf8 Class Initialized
INFO - 2017-01-19 21:28:40 --> URI Class Initialized
INFO - 2017-01-19 21:28:40 --> Router Class Initialized
INFO - 2017-01-19 21:28:40 --> Output Class Initialized
INFO - 2017-01-19 21:28:40 --> Security Class Initialized
DEBUG - 2017-01-19 21:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:28:40 --> Input Class Initialized
INFO - 2017-01-19 21:28:40 --> Language Class Initialized
INFO - 2017-01-19 21:28:40 --> Loader Class Initialized
INFO - 2017-01-19 21:28:40 --> Database Driver Class Initialized
INFO - 2017-01-19 21:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:28:40 --> Controller Class Initialized
INFO - 2017-01-19 21:28:40 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:28:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:28:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 21:28:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 21:28:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 21:28:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 21:28:40 --> Final output sent to browser
DEBUG - 2017-01-19 21:28:40 --> Total execution time: 0.0143
INFO - 2017-01-19 21:28:48 --> Config Class Initialized
INFO - 2017-01-19 21:28:48 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:28:48 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:28:48 --> Utf8 Class Initialized
INFO - 2017-01-19 21:28:48 --> URI Class Initialized
INFO - 2017-01-19 21:28:48 --> Router Class Initialized
INFO - 2017-01-19 21:28:48 --> Output Class Initialized
INFO - 2017-01-19 21:28:48 --> Security Class Initialized
DEBUG - 2017-01-19 21:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:28:48 --> Input Class Initialized
INFO - 2017-01-19 21:28:48 --> Language Class Initialized
INFO - 2017-01-19 21:28:48 --> Loader Class Initialized
INFO - 2017-01-19 21:28:48 --> Database Driver Class Initialized
INFO - 2017-01-19 21:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:28:48 --> Controller Class Initialized
INFO - 2017-01-19 21:28:48 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:28:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:28:48 --> Helper loaded: form_helper
INFO - 2017-01-19 21:28:48 --> Form Validation Class Initialized
INFO - 2017-01-19 21:28:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-19 21:28:48 --> Config Class Initialized
INFO - 2017-01-19 21:28:48 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:28:48 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:28:48 --> Utf8 Class Initialized
INFO - 2017-01-19 21:28:48 --> URI Class Initialized
INFO - 2017-01-19 21:28:48 --> Router Class Initialized
INFO - 2017-01-19 21:28:48 --> Output Class Initialized
INFO - 2017-01-19 21:28:48 --> Security Class Initialized
DEBUG - 2017-01-19 21:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:28:48 --> Input Class Initialized
INFO - 2017-01-19 21:28:48 --> Language Class Initialized
INFO - 2017-01-19 21:28:48 --> Loader Class Initialized
INFO - 2017-01-19 21:28:48 --> Database Driver Class Initialized
INFO - 2017-01-19 21:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:28:48 --> Controller Class Initialized
INFO - 2017-01-19 21:28:48 --> Helper loaded: date_helper
INFO - 2017-01-19 21:28:48 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:28:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:28:48 --> Helper loaded: form_helper
INFO - 2017-01-19 21:28:48 --> Form Validation Class Initialized
INFO - 2017-01-19 21:28:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-19 21:28:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-19 21:28:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-19 21:28:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-19 21:28:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-19 21:28:48 --> Final output sent to browser
DEBUG - 2017-01-19 21:28:48 --> Total execution time: 0.3010
INFO - 2017-01-19 21:28:49 --> Config Class Initialized
INFO - 2017-01-19 21:28:49 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:28:49 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:28:49 --> Utf8 Class Initialized
INFO - 2017-01-19 21:28:49 --> URI Class Initialized
INFO - 2017-01-19 21:28:49 --> Router Class Initialized
INFO - 2017-01-19 21:28:49 --> Output Class Initialized
INFO - 2017-01-19 21:28:49 --> Security Class Initialized
DEBUG - 2017-01-19 21:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:28:49 --> Input Class Initialized
INFO - 2017-01-19 21:28:49 --> Language Class Initialized
INFO - 2017-01-19 21:28:49 --> Loader Class Initialized
INFO - 2017-01-19 21:28:49 --> Database Driver Class Initialized
INFO - 2017-01-19 21:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:28:49 --> Controller Class Initialized
INFO - 2017-01-19 21:28:49 --> Helper loaded: date_helper
INFO - 2017-01-19 21:28:49 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:28:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:28:49 --> Helper loaded: form_helper
INFO - 2017-01-19 21:28:49 --> Form Validation Class Initialized
INFO - 2017-01-19 21:28:49 --> Final output sent to browser
DEBUG - 2017-01-19 21:28:49 --> Total execution time: 0.0620
INFO - 2017-01-19 21:28:49 --> Config Class Initialized
INFO - 2017-01-19 21:28:49 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:28:49 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:28:49 --> Utf8 Class Initialized
INFO - 2017-01-19 21:28:49 --> URI Class Initialized
INFO - 2017-01-19 21:28:49 --> Router Class Initialized
INFO - 2017-01-19 21:28:49 --> Output Class Initialized
INFO - 2017-01-19 21:28:49 --> Security Class Initialized
DEBUG - 2017-01-19 21:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:28:49 --> Input Class Initialized
INFO - 2017-01-19 21:28:49 --> Language Class Initialized
INFO - 2017-01-19 21:28:49 --> Loader Class Initialized
INFO - 2017-01-19 21:28:49 --> Database Driver Class Initialized
INFO - 2017-01-19 21:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:28:49 --> Controller Class Initialized
INFO - 2017-01-19 21:28:49 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:28:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:28:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 21:28:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 21:28:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 21:28:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 21:28:49 --> Final output sent to browser
DEBUG - 2017-01-19 21:28:49 --> Total execution time: 0.0138
INFO - 2017-01-19 21:28:53 --> Config Class Initialized
INFO - 2017-01-19 21:28:53 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:28:53 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:28:53 --> Utf8 Class Initialized
INFO - 2017-01-19 21:28:53 --> URI Class Initialized
INFO - 2017-01-19 21:28:53 --> Router Class Initialized
INFO - 2017-01-19 21:28:53 --> Output Class Initialized
INFO - 2017-01-19 21:28:53 --> Security Class Initialized
DEBUG - 2017-01-19 21:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:28:53 --> Input Class Initialized
INFO - 2017-01-19 21:28:53 --> Language Class Initialized
INFO - 2017-01-19 21:28:53 --> Loader Class Initialized
INFO - 2017-01-19 21:28:53 --> Database Driver Class Initialized
INFO - 2017-01-19 21:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:28:53 --> Controller Class Initialized
INFO - 2017-01-19 21:28:53 --> Helper loaded: date_helper
INFO - 2017-01-19 21:28:53 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:28:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:28:53 --> Helper loaded: form_helper
INFO - 2017-01-19 21:28:53 --> Form Validation Class Initialized
INFO - 2017-01-19 21:28:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-19 21:28:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-19 21:28:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-19 21:28:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-19 21:28:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-19 21:28:53 --> Final output sent to browser
DEBUG - 2017-01-19 21:28:53 --> Total execution time: 0.0538
INFO - 2017-01-19 21:28:54 --> Config Class Initialized
INFO - 2017-01-19 21:28:54 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:28:54 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:28:54 --> Utf8 Class Initialized
INFO - 2017-01-19 21:28:54 --> URI Class Initialized
INFO - 2017-01-19 21:28:54 --> Router Class Initialized
INFO - 2017-01-19 21:28:54 --> Output Class Initialized
INFO - 2017-01-19 21:28:54 --> Security Class Initialized
DEBUG - 2017-01-19 21:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:28:54 --> Input Class Initialized
INFO - 2017-01-19 21:28:54 --> Language Class Initialized
INFO - 2017-01-19 21:28:54 --> Loader Class Initialized
INFO - 2017-01-19 21:28:54 --> Database Driver Class Initialized
INFO - 2017-01-19 21:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:28:54 --> Controller Class Initialized
INFO - 2017-01-19 21:28:54 --> Helper loaded: date_helper
INFO - 2017-01-19 21:28:54 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:28:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:28:54 --> Helper loaded: form_helper
INFO - 2017-01-19 21:28:54 --> Form Validation Class Initialized
INFO - 2017-01-19 21:28:54 --> Final output sent to browser
DEBUG - 2017-01-19 21:28:54 --> Total execution time: 0.0447
INFO - 2017-01-19 21:28:54 --> Config Class Initialized
INFO - 2017-01-19 21:28:54 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:28:54 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:28:54 --> Utf8 Class Initialized
INFO - 2017-01-19 21:28:54 --> URI Class Initialized
INFO - 2017-01-19 21:28:54 --> Router Class Initialized
INFO - 2017-01-19 21:28:54 --> Output Class Initialized
INFO - 2017-01-19 21:28:54 --> Security Class Initialized
DEBUG - 2017-01-19 21:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:28:54 --> Input Class Initialized
INFO - 2017-01-19 21:28:54 --> Language Class Initialized
INFO - 2017-01-19 21:28:54 --> Loader Class Initialized
INFO - 2017-01-19 21:28:54 --> Database Driver Class Initialized
INFO - 2017-01-19 21:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:28:54 --> Controller Class Initialized
INFO - 2017-01-19 21:28:54 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:28:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:28:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 21:28:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 21:28:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 21:28:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 21:28:54 --> Final output sent to browser
DEBUG - 2017-01-19 21:28:54 --> Total execution time: 0.0134
INFO - 2017-01-19 21:28:56 --> Config Class Initialized
INFO - 2017-01-19 21:28:56 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:28:56 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:28:56 --> Utf8 Class Initialized
INFO - 2017-01-19 21:28:56 --> URI Class Initialized
INFO - 2017-01-19 21:28:56 --> Router Class Initialized
INFO - 2017-01-19 21:28:56 --> Output Class Initialized
INFO - 2017-01-19 21:28:56 --> Security Class Initialized
DEBUG - 2017-01-19 21:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:28:56 --> Input Class Initialized
INFO - 2017-01-19 21:28:56 --> Language Class Initialized
INFO - 2017-01-19 21:28:56 --> Loader Class Initialized
INFO - 2017-01-19 21:28:56 --> Database Driver Class Initialized
INFO - 2017-01-19 21:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:28:56 --> Controller Class Initialized
INFO - 2017-01-19 21:28:56 --> Helper loaded: date_helper
INFO - 2017-01-19 21:28:56 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:28:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:28:56 --> Helper loaded: form_helper
INFO - 2017-01-19 21:28:56 --> Form Validation Class Initialized
INFO - 2017-01-19 21:28:56 --> Final output sent to browser
DEBUG - 2017-01-19 21:28:56 --> Total execution time: 0.0150
INFO - 2017-01-19 21:29:00 --> Config Class Initialized
INFO - 2017-01-19 21:29:00 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:29:00 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:29:00 --> Utf8 Class Initialized
INFO - 2017-01-19 21:29:00 --> URI Class Initialized
INFO - 2017-01-19 21:29:00 --> Router Class Initialized
INFO - 2017-01-19 21:29:00 --> Output Class Initialized
INFO - 2017-01-19 21:29:00 --> Security Class Initialized
DEBUG - 2017-01-19 21:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:29:00 --> Input Class Initialized
INFO - 2017-01-19 21:29:00 --> Language Class Initialized
INFO - 2017-01-19 21:29:00 --> Loader Class Initialized
INFO - 2017-01-19 21:29:00 --> Database Driver Class Initialized
INFO - 2017-01-19 21:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:29:00 --> Controller Class Initialized
INFO - 2017-01-19 21:29:00 --> Helper loaded: date_helper
INFO - 2017-01-19 21:29:00 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:29:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:29:00 --> Helper loaded: form_helper
INFO - 2017-01-19 21:29:00 --> Form Validation Class Initialized
INFO - 2017-01-19 21:29:00 --> Final output sent to browser
DEBUG - 2017-01-19 21:29:00 --> Total execution time: 0.0147
INFO - 2017-01-19 21:29:04 --> Config Class Initialized
INFO - 2017-01-19 21:29:04 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:29:04 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:29:04 --> Utf8 Class Initialized
INFO - 2017-01-19 21:29:04 --> URI Class Initialized
INFO - 2017-01-19 21:29:04 --> Router Class Initialized
INFO - 2017-01-19 21:29:04 --> Output Class Initialized
INFO - 2017-01-19 21:29:04 --> Security Class Initialized
DEBUG - 2017-01-19 21:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:29:04 --> Input Class Initialized
INFO - 2017-01-19 21:29:04 --> Language Class Initialized
INFO - 2017-01-19 21:29:04 --> Loader Class Initialized
INFO - 2017-01-19 21:29:04 --> Database Driver Class Initialized
INFO - 2017-01-19 21:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:29:04 --> Controller Class Initialized
INFO - 2017-01-19 21:29:04 --> Helper loaded: date_helper
INFO - 2017-01-19 21:29:04 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:29:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:29:04 --> Helper loaded: form_helper
INFO - 2017-01-19 21:29:04 --> Form Validation Class Initialized
INFO - 2017-01-19 21:29:04 --> Final output sent to browser
DEBUG - 2017-01-19 21:29:04 --> Total execution time: 0.0957
INFO - 2017-01-19 21:29:41 --> Config Class Initialized
INFO - 2017-01-19 21:29:41 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:29:41 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:29:41 --> Utf8 Class Initialized
INFO - 2017-01-19 21:29:41 --> URI Class Initialized
INFO - 2017-01-19 21:29:41 --> Router Class Initialized
INFO - 2017-01-19 21:29:41 --> Output Class Initialized
INFO - 2017-01-19 21:29:41 --> Security Class Initialized
DEBUG - 2017-01-19 21:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:29:41 --> Input Class Initialized
INFO - 2017-01-19 21:29:41 --> Language Class Initialized
INFO - 2017-01-19 21:29:41 --> Loader Class Initialized
INFO - 2017-01-19 21:29:41 --> Database Driver Class Initialized
INFO - 2017-01-19 21:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:29:41 --> Controller Class Initialized
INFO - 2017-01-19 21:29:41 --> Upload Class Initialized
INFO - 2017-01-19 21:29:41 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:29:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:29:41 --> Helper loaded: form_helper
INFO - 2017-01-19 21:29:41 --> Form Validation Class Initialized
INFO - 2017-01-19 21:29:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-19 21:29:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-19 21:29:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-19 21:29:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-19 21:29:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-19 21:29:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-19 21:29:42 --> Final output sent to browser
DEBUG - 2017-01-19 21:29:42 --> Total execution time: 0.2799
INFO - 2017-01-19 21:29:42 --> Config Class Initialized
INFO - 2017-01-19 21:29:42 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:29:42 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:29:42 --> Utf8 Class Initialized
INFO - 2017-01-19 21:29:42 --> URI Class Initialized
INFO - 2017-01-19 21:29:42 --> Router Class Initialized
INFO - 2017-01-19 21:29:42 --> Output Class Initialized
INFO - 2017-01-19 21:29:42 --> Security Class Initialized
DEBUG - 2017-01-19 21:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:29:42 --> Input Class Initialized
INFO - 2017-01-19 21:29:42 --> Language Class Initialized
INFO - 2017-01-19 21:29:42 --> Loader Class Initialized
INFO - 2017-01-19 21:29:42 --> Database Driver Class Initialized
INFO - 2017-01-19 21:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:29:42 --> Controller Class Initialized
INFO - 2017-01-19 21:29:42 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:29:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:29:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 21:29:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 21:29:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 21:29:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 21:29:42 --> Final output sent to browser
DEBUG - 2017-01-19 21:29:42 --> Total execution time: 0.0141
INFO - 2017-01-19 21:30:02 --> Config Class Initialized
INFO - 2017-01-19 21:30:02 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:30:02 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:30:02 --> Utf8 Class Initialized
INFO - 2017-01-19 21:30:02 --> URI Class Initialized
INFO - 2017-01-19 21:30:02 --> Router Class Initialized
INFO - 2017-01-19 21:30:02 --> Output Class Initialized
INFO - 2017-01-19 21:30:02 --> Security Class Initialized
DEBUG - 2017-01-19 21:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:30:02 --> Input Class Initialized
INFO - 2017-01-19 21:30:02 --> Language Class Initialized
INFO - 2017-01-19 21:30:02 --> Loader Class Initialized
INFO - 2017-01-19 21:30:02 --> Database Driver Class Initialized
INFO - 2017-01-19 21:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:30:02 --> Controller Class Initialized
INFO - 2017-01-19 21:30:02 --> Upload Class Initialized
INFO - 2017-01-19 21:30:02 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:30:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:30:02 --> Helper loaded: form_helper
INFO - 2017-01-19 21:30:02 --> Form Validation Class Initialized
INFO - 2017-01-19 21:30:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-19 21:30:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-19 21:30:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-19 21:30:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-19 21:30:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-19 21:30:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-19 21:30:02 --> Final output sent to browser
DEBUG - 2017-01-19 21:30:02 --> Total execution time: 0.0350
INFO - 2017-01-19 21:30:05 --> Config Class Initialized
INFO - 2017-01-19 21:30:05 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:30:05 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:30:05 --> Utf8 Class Initialized
INFO - 2017-01-19 21:30:05 --> URI Class Initialized
INFO - 2017-01-19 21:30:05 --> Router Class Initialized
INFO - 2017-01-19 21:30:05 --> Output Class Initialized
INFO - 2017-01-19 21:30:05 --> Security Class Initialized
DEBUG - 2017-01-19 21:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:30:05 --> Input Class Initialized
INFO - 2017-01-19 21:30:05 --> Language Class Initialized
INFO - 2017-01-19 21:30:05 --> Loader Class Initialized
INFO - 2017-01-19 21:30:05 --> Database Driver Class Initialized
INFO - 2017-01-19 21:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:30:05 --> Controller Class Initialized
INFO - 2017-01-19 21:30:05 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:30:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:30:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 21:30:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 21:30:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 21:30:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 21:30:05 --> Final output sent to browser
DEBUG - 2017-01-19 21:30:05 --> Total execution time: 0.0158
INFO - 2017-01-19 21:31:52 --> Config Class Initialized
INFO - 2017-01-19 21:31:52 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:31:52 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:31:52 --> Utf8 Class Initialized
INFO - 2017-01-19 21:31:52 --> URI Class Initialized
INFO - 2017-01-19 21:31:52 --> Router Class Initialized
INFO - 2017-01-19 21:31:52 --> Output Class Initialized
INFO - 2017-01-19 21:31:52 --> Security Class Initialized
DEBUG - 2017-01-19 21:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:31:52 --> Input Class Initialized
INFO - 2017-01-19 21:31:52 --> Language Class Initialized
INFO - 2017-01-19 21:31:52 --> Loader Class Initialized
INFO - 2017-01-19 21:31:52 --> Database Driver Class Initialized
INFO - 2017-01-19 21:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:31:52 --> Controller Class Initialized
INFO - 2017-01-19 21:31:52 --> Upload Class Initialized
INFO - 2017-01-19 21:31:52 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:31:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:31:52 --> Helper loaded: form_helper
INFO - 2017-01-19 21:31:52 --> Form Validation Class Initialized
INFO - 2017-01-19 21:31:52 --> Final output sent to browser
DEBUG - 2017-01-19 21:31:52 --> Total execution time: 0.0553
INFO - 2017-01-19 21:31:52 --> Config Class Initialized
INFO - 2017-01-19 21:31:52 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:31:52 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:31:52 --> Utf8 Class Initialized
INFO - 2017-01-19 21:31:52 --> URI Class Initialized
INFO - 2017-01-19 21:31:52 --> Router Class Initialized
INFO - 2017-01-19 21:31:52 --> Output Class Initialized
INFO - 2017-01-19 21:31:52 --> Security Class Initialized
DEBUG - 2017-01-19 21:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:31:52 --> Input Class Initialized
INFO - 2017-01-19 21:31:52 --> Language Class Initialized
INFO - 2017-01-19 21:31:52 --> Loader Class Initialized
INFO - 2017-01-19 21:31:52 --> Database Driver Class Initialized
INFO - 2017-01-19 21:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:31:52 --> Controller Class Initialized
INFO - 2017-01-19 21:31:52 --> Upload Class Initialized
INFO - 2017-01-19 21:31:52 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:31:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:31:52 --> Helper loaded: form_helper
INFO - 2017-01-19 21:31:52 --> Form Validation Class Initialized
INFO - 2017-01-19 21:31:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-19 21:31:52 --> Final output sent to browser
DEBUG - 2017-01-19 21:31:52 --> Total execution time: 0.0160
INFO - 2017-01-19 21:32:54 --> Config Class Initialized
INFO - 2017-01-19 21:32:54 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:32:54 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:32:54 --> Utf8 Class Initialized
INFO - 2017-01-19 21:32:54 --> URI Class Initialized
INFO - 2017-01-19 21:32:54 --> Router Class Initialized
INFO - 2017-01-19 21:32:54 --> Output Class Initialized
INFO - 2017-01-19 21:32:54 --> Security Class Initialized
DEBUG - 2017-01-19 21:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:32:54 --> Input Class Initialized
INFO - 2017-01-19 21:32:54 --> Language Class Initialized
INFO - 2017-01-19 21:32:54 --> Loader Class Initialized
INFO - 2017-01-19 21:32:54 --> Database Driver Class Initialized
INFO - 2017-01-19 21:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:32:54 --> Controller Class Initialized
INFO - 2017-01-19 21:32:54 --> Upload Class Initialized
INFO - 2017-01-19 21:32:54 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:32:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:32:54 --> Helper loaded: form_helper
INFO - 2017-01-19 21:32:54 --> Form Validation Class Initialized
INFO - 2017-01-19 21:32:54 --> Final output sent to browser
DEBUG - 2017-01-19 21:32:54 --> Total execution time: 0.0176
INFO - 2017-01-19 21:32:54 --> Config Class Initialized
INFO - 2017-01-19 21:32:54 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:32:54 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:32:54 --> Utf8 Class Initialized
INFO - 2017-01-19 21:32:54 --> URI Class Initialized
INFO - 2017-01-19 21:32:54 --> Router Class Initialized
INFO - 2017-01-19 21:32:54 --> Output Class Initialized
INFO - 2017-01-19 21:32:54 --> Security Class Initialized
DEBUG - 2017-01-19 21:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:32:54 --> Input Class Initialized
INFO - 2017-01-19 21:32:54 --> Language Class Initialized
INFO - 2017-01-19 21:32:54 --> Loader Class Initialized
INFO - 2017-01-19 21:32:54 --> Database Driver Class Initialized
INFO - 2017-01-19 21:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:32:54 --> Controller Class Initialized
INFO - 2017-01-19 21:32:54 --> Upload Class Initialized
INFO - 2017-01-19 21:32:54 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:32:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:32:54 --> Helper loaded: form_helper
INFO - 2017-01-19 21:32:54 --> Form Validation Class Initialized
INFO - 2017-01-19 21:32:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-19 21:32:54 --> Final output sent to browser
DEBUG - 2017-01-19 21:32:54 --> Total execution time: 0.0225
INFO - 2017-01-19 21:33:54 --> Config Class Initialized
INFO - 2017-01-19 21:33:54 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:33:54 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:33:54 --> Utf8 Class Initialized
INFO - 2017-01-19 21:33:54 --> URI Class Initialized
INFO - 2017-01-19 21:33:54 --> Router Class Initialized
INFO - 2017-01-19 21:33:54 --> Output Class Initialized
INFO - 2017-01-19 21:33:54 --> Security Class Initialized
DEBUG - 2017-01-19 21:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:33:54 --> Input Class Initialized
INFO - 2017-01-19 21:33:54 --> Language Class Initialized
INFO - 2017-01-19 21:33:54 --> Loader Class Initialized
INFO - 2017-01-19 21:33:54 --> Database Driver Class Initialized
INFO - 2017-01-19 21:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:33:54 --> Controller Class Initialized
INFO - 2017-01-19 21:33:54 --> Upload Class Initialized
INFO - 2017-01-19 21:33:54 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:33:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:33:54 --> Helper loaded: form_helper
INFO - 2017-01-19 21:33:54 --> Form Validation Class Initialized
INFO - 2017-01-19 21:33:54 --> Final output sent to browser
DEBUG - 2017-01-19 21:33:54 --> Total execution time: 0.0153
INFO - 2017-01-19 21:33:54 --> Config Class Initialized
INFO - 2017-01-19 21:33:54 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:33:54 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:33:54 --> Utf8 Class Initialized
INFO - 2017-01-19 21:33:54 --> URI Class Initialized
INFO - 2017-01-19 21:33:54 --> Router Class Initialized
INFO - 2017-01-19 21:33:54 --> Output Class Initialized
INFO - 2017-01-19 21:33:54 --> Security Class Initialized
DEBUG - 2017-01-19 21:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:33:54 --> Input Class Initialized
INFO - 2017-01-19 21:33:54 --> Language Class Initialized
INFO - 2017-01-19 21:33:54 --> Loader Class Initialized
INFO - 2017-01-19 21:33:54 --> Database Driver Class Initialized
INFO - 2017-01-19 21:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:33:54 --> Controller Class Initialized
INFO - 2017-01-19 21:33:54 --> Upload Class Initialized
INFO - 2017-01-19 21:33:54 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:33:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:33:54 --> Helper loaded: form_helper
INFO - 2017-01-19 21:33:54 --> Form Validation Class Initialized
INFO - 2017-01-19 21:33:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-19 21:33:54 --> Final output sent to browser
DEBUG - 2017-01-19 21:33:54 --> Total execution time: 0.0191
INFO - 2017-01-19 21:38:17 --> Config Class Initialized
INFO - 2017-01-19 21:38:17 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:38:17 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:38:17 --> Utf8 Class Initialized
INFO - 2017-01-19 21:38:17 --> URI Class Initialized
INFO - 2017-01-19 21:38:17 --> Router Class Initialized
INFO - 2017-01-19 21:38:17 --> Output Class Initialized
INFO - 2017-01-19 21:38:17 --> Security Class Initialized
DEBUG - 2017-01-19 21:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:38:17 --> Input Class Initialized
INFO - 2017-01-19 21:38:17 --> Language Class Initialized
INFO - 2017-01-19 21:38:17 --> Loader Class Initialized
INFO - 2017-01-19 21:38:17 --> Database Driver Class Initialized
INFO - 2017-01-19 21:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:38:17 --> Controller Class Initialized
INFO - 2017-01-19 21:38:17 --> Upload Class Initialized
INFO - 2017-01-19 21:38:17 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:38:17 --> Helper loaded: form_helper
INFO - 2017-01-19 21:38:17 --> Form Validation Class Initialized
INFO - 2017-01-19 21:38:17 --> Final output sent to browser
DEBUG - 2017-01-19 21:38:17 --> Total execution time: 0.0169
INFO - 2017-01-19 21:38:17 --> Config Class Initialized
INFO - 2017-01-19 21:38:17 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:38:17 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:38:17 --> Utf8 Class Initialized
INFO - 2017-01-19 21:38:17 --> URI Class Initialized
INFO - 2017-01-19 21:38:17 --> Router Class Initialized
INFO - 2017-01-19 21:38:17 --> Output Class Initialized
INFO - 2017-01-19 21:38:17 --> Security Class Initialized
DEBUG - 2017-01-19 21:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:38:17 --> Input Class Initialized
INFO - 2017-01-19 21:38:17 --> Language Class Initialized
INFO - 2017-01-19 21:38:17 --> Loader Class Initialized
INFO - 2017-01-19 21:38:17 --> Database Driver Class Initialized
INFO - 2017-01-19 21:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:38:17 --> Controller Class Initialized
INFO - 2017-01-19 21:38:17 --> Upload Class Initialized
INFO - 2017-01-19 21:38:17 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:38:17 --> Helper loaded: form_helper
INFO - 2017-01-19 21:38:17 --> Form Validation Class Initialized
INFO - 2017-01-19 21:38:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-19 21:38:17 --> Final output sent to browser
DEBUG - 2017-01-19 21:38:17 --> Total execution time: 0.0221
INFO - 2017-01-19 21:39:24 --> Config Class Initialized
INFO - 2017-01-19 21:39:24 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:39:24 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:39:24 --> Utf8 Class Initialized
INFO - 2017-01-19 21:39:24 --> URI Class Initialized
INFO - 2017-01-19 21:39:24 --> Router Class Initialized
INFO - 2017-01-19 21:39:24 --> Output Class Initialized
INFO - 2017-01-19 21:39:24 --> Security Class Initialized
DEBUG - 2017-01-19 21:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:39:24 --> Input Class Initialized
INFO - 2017-01-19 21:39:24 --> Language Class Initialized
INFO - 2017-01-19 21:39:24 --> Loader Class Initialized
INFO - 2017-01-19 21:39:24 --> Database Driver Class Initialized
INFO - 2017-01-19 21:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:39:24 --> Controller Class Initialized
INFO - 2017-01-19 21:39:24 --> Upload Class Initialized
INFO - 2017-01-19 21:39:24 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:39:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:39:24 --> Helper loaded: form_helper
INFO - 2017-01-19 21:39:24 --> Form Validation Class Initialized
INFO - 2017-01-19 21:39:24 --> Final output sent to browser
DEBUG - 2017-01-19 21:39:24 --> Total execution time: 0.0170
INFO - 2017-01-19 21:39:24 --> Config Class Initialized
INFO - 2017-01-19 21:39:24 --> Hooks Class Initialized
DEBUG - 2017-01-19 21:39:24 --> UTF-8 Support Enabled
INFO - 2017-01-19 21:39:24 --> Utf8 Class Initialized
INFO - 2017-01-19 21:39:24 --> URI Class Initialized
INFO - 2017-01-19 21:39:24 --> Router Class Initialized
INFO - 2017-01-19 21:39:24 --> Output Class Initialized
INFO - 2017-01-19 21:39:24 --> Security Class Initialized
DEBUG - 2017-01-19 21:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 21:39:24 --> Input Class Initialized
INFO - 2017-01-19 21:39:24 --> Language Class Initialized
INFO - 2017-01-19 21:39:24 --> Loader Class Initialized
INFO - 2017-01-19 21:39:24 --> Database Driver Class Initialized
INFO - 2017-01-19 21:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 21:39:24 --> Controller Class Initialized
INFO - 2017-01-19 21:39:24 --> Upload Class Initialized
INFO - 2017-01-19 21:39:24 --> Helper loaded: url_helper
DEBUG - 2017-01-19 21:39:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 21:39:24 --> Helper loaded: form_helper
INFO - 2017-01-19 21:39:24 --> Form Validation Class Initialized
INFO - 2017-01-19 21:39:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-19 21:39:24 --> Final output sent to browser
DEBUG - 2017-01-19 21:39:24 --> Total execution time: 0.0152
INFO - 2017-01-19 22:22:50 --> Config Class Initialized
INFO - 2017-01-19 22:22:50 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:22:50 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:22:50 --> Utf8 Class Initialized
INFO - 2017-01-19 22:22:50 --> URI Class Initialized
INFO - 2017-01-19 22:22:50 --> Router Class Initialized
INFO - 2017-01-19 22:22:50 --> Output Class Initialized
INFO - 2017-01-19 22:22:50 --> Security Class Initialized
DEBUG - 2017-01-19 22:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:22:50 --> Input Class Initialized
INFO - 2017-01-19 22:22:50 --> Language Class Initialized
INFO - 2017-01-19 22:22:50 --> Loader Class Initialized
INFO - 2017-01-19 22:22:50 --> Database Driver Class Initialized
INFO - 2017-01-19 22:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:22:50 --> Controller Class Initialized
INFO - 2017-01-19 22:22:50 --> Upload Class Initialized
INFO - 2017-01-19 22:22:50 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:22:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:22:50 --> Helper loaded: form_helper
INFO - 2017-01-19 22:22:50 --> Form Validation Class Initialized
INFO - 2017-01-19 22:22:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-19 22:22:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-19 22:22:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-19 22:22:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-19 22:22:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-19 22:22:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-19 22:22:50 --> Final output sent to browser
DEBUG - 2017-01-19 22:22:50 --> Total execution time: 0.0171
INFO - 2017-01-19 22:22:51 --> Config Class Initialized
INFO - 2017-01-19 22:22:51 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:22:51 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:22:51 --> Utf8 Class Initialized
INFO - 2017-01-19 22:22:51 --> URI Class Initialized
INFO - 2017-01-19 22:22:51 --> Router Class Initialized
INFO - 2017-01-19 22:22:51 --> Output Class Initialized
INFO - 2017-01-19 22:22:51 --> Security Class Initialized
DEBUG - 2017-01-19 22:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:22:51 --> Input Class Initialized
INFO - 2017-01-19 22:22:51 --> Language Class Initialized
INFO - 2017-01-19 22:22:51 --> Loader Class Initialized
INFO - 2017-01-19 22:22:51 --> Database Driver Class Initialized
INFO - 2017-01-19 22:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:22:51 --> Controller Class Initialized
INFO - 2017-01-19 22:22:51 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:22:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:22:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 22:22:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 22:22:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 22:22:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 22:22:51 --> Final output sent to browser
DEBUG - 2017-01-19 22:22:51 --> Total execution time: 0.0332
INFO - 2017-01-19 22:23:00 --> Config Class Initialized
INFO - 2017-01-19 22:23:00 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:23:00 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:23:00 --> Utf8 Class Initialized
INFO - 2017-01-19 22:23:00 --> URI Class Initialized
INFO - 2017-01-19 22:23:00 --> Router Class Initialized
INFO - 2017-01-19 22:23:00 --> Output Class Initialized
INFO - 2017-01-19 22:23:00 --> Security Class Initialized
DEBUG - 2017-01-19 22:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:23:00 --> Input Class Initialized
INFO - 2017-01-19 22:23:00 --> Language Class Initialized
INFO - 2017-01-19 22:23:00 --> Loader Class Initialized
INFO - 2017-01-19 22:23:00 --> Database Driver Class Initialized
INFO - 2017-01-19 22:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:23:00 --> Controller Class Initialized
INFO - 2017-01-19 22:23:00 --> Helper loaded: date_helper
INFO - 2017-01-19 22:23:00 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:23:00 --> Helper loaded: form_helper
INFO - 2017-01-19 22:23:00 --> Form Validation Class Initialized
INFO - 2017-01-19 22:23:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-19 22:23:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-19 22:23:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-19 22:23:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-19 22:23:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-19 22:23:00 --> Final output sent to browser
DEBUG - 2017-01-19 22:23:00 --> Total execution time: 0.0690
INFO - 2017-01-19 22:23:01 --> Config Class Initialized
INFO - 2017-01-19 22:23:01 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:23:01 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:23:01 --> Utf8 Class Initialized
INFO - 2017-01-19 22:23:01 --> URI Class Initialized
INFO - 2017-01-19 22:23:01 --> Router Class Initialized
INFO - 2017-01-19 22:23:01 --> Output Class Initialized
INFO - 2017-01-19 22:23:01 --> Security Class Initialized
DEBUG - 2017-01-19 22:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:23:01 --> Input Class Initialized
INFO - 2017-01-19 22:23:01 --> Language Class Initialized
INFO - 2017-01-19 22:23:01 --> Loader Class Initialized
INFO - 2017-01-19 22:23:01 --> Database Driver Class Initialized
INFO - 2017-01-19 22:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:23:01 --> Controller Class Initialized
INFO - 2017-01-19 22:23:01 --> Helper loaded: date_helper
INFO - 2017-01-19 22:23:01 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:23:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:23:01 --> Helper loaded: form_helper
INFO - 2017-01-19 22:23:01 --> Form Validation Class Initialized
INFO - 2017-01-19 22:23:01 --> Final output sent to browser
DEBUG - 2017-01-19 22:23:01 --> Total execution time: 0.0198
INFO - 2017-01-19 22:23:01 --> Config Class Initialized
INFO - 2017-01-19 22:23:01 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:23:01 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:23:01 --> Utf8 Class Initialized
INFO - 2017-01-19 22:23:01 --> URI Class Initialized
INFO - 2017-01-19 22:23:01 --> Router Class Initialized
INFO - 2017-01-19 22:23:01 --> Output Class Initialized
INFO - 2017-01-19 22:23:01 --> Security Class Initialized
DEBUG - 2017-01-19 22:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:23:01 --> Input Class Initialized
INFO - 2017-01-19 22:23:01 --> Language Class Initialized
INFO - 2017-01-19 22:23:01 --> Loader Class Initialized
INFO - 2017-01-19 22:23:01 --> Database Driver Class Initialized
INFO - 2017-01-19 22:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:23:01 --> Controller Class Initialized
INFO - 2017-01-19 22:23:01 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:23:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:23:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 22:23:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 22:23:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 22:23:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 22:23:01 --> Final output sent to browser
DEBUG - 2017-01-19 22:23:01 --> Total execution time: 0.0232
INFO - 2017-01-19 22:23:03 --> Config Class Initialized
INFO - 2017-01-19 22:23:03 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:23:03 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:23:03 --> Utf8 Class Initialized
INFO - 2017-01-19 22:23:03 --> URI Class Initialized
INFO - 2017-01-19 22:23:03 --> Router Class Initialized
INFO - 2017-01-19 22:23:03 --> Output Class Initialized
INFO - 2017-01-19 22:23:03 --> Security Class Initialized
DEBUG - 2017-01-19 22:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:23:03 --> Input Class Initialized
INFO - 2017-01-19 22:23:03 --> Language Class Initialized
INFO - 2017-01-19 22:23:03 --> Loader Class Initialized
INFO - 2017-01-19 22:23:03 --> Database Driver Class Initialized
INFO - 2017-01-19 22:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:23:03 --> Controller Class Initialized
INFO - 2017-01-19 22:23:03 --> Helper loaded: date_helper
INFO - 2017-01-19 22:23:03 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:23:03 --> Helper loaded: form_helper
INFO - 2017-01-19 22:23:03 --> Form Validation Class Initialized
INFO - 2017-01-19 22:23:03 --> Final output sent to browser
DEBUG - 2017-01-19 22:23:03 --> Total execution time: 0.0253
INFO - 2017-01-19 22:23:16 --> Config Class Initialized
INFO - 2017-01-19 22:23:16 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:23:16 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:23:16 --> Utf8 Class Initialized
INFO - 2017-01-19 22:23:16 --> URI Class Initialized
INFO - 2017-01-19 22:23:16 --> Router Class Initialized
INFO - 2017-01-19 22:23:16 --> Output Class Initialized
INFO - 2017-01-19 22:23:16 --> Security Class Initialized
DEBUG - 2017-01-19 22:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:23:16 --> Input Class Initialized
INFO - 2017-01-19 22:23:16 --> Language Class Initialized
INFO - 2017-01-19 22:23:16 --> Loader Class Initialized
INFO - 2017-01-19 22:23:16 --> Database Driver Class Initialized
INFO - 2017-01-19 22:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:23:16 --> Controller Class Initialized
INFO - 2017-01-19 22:23:16 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:23:16 --> Config Class Initialized
INFO - 2017-01-19 22:23:16 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:23:16 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:23:16 --> Utf8 Class Initialized
INFO - 2017-01-19 22:23:16 --> URI Class Initialized
INFO - 2017-01-19 22:23:16 --> Router Class Initialized
INFO - 2017-01-19 22:23:16 --> Output Class Initialized
INFO - 2017-01-19 22:23:16 --> Security Class Initialized
DEBUG - 2017-01-19 22:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:23:16 --> Input Class Initialized
INFO - 2017-01-19 22:23:16 --> Language Class Initialized
INFO - 2017-01-19 22:23:16 --> Loader Class Initialized
INFO - 2017-01-19 22:23:16 --> Database Driver Class Initialized
INFO - 2017-01-19 22:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:23:16 --> Controller Class Initialized
INFO - 2017-01-19 22:23:16 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:23:16 --> Helper loaded: form_helper
INFO - 2017-01-19 22:23:16 --> Form Validation Class Initialized
INFO - 2017-01-19 22:23:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-19 22:23:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-19 22:23:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-19 22:23:16 --> Final output sent to browser
DEBUG - 2017-01-19 22:23:16 --> Total execution time: 0.0132
INFO - 2017-01-19 22:23:16 --> Config Class Initialized
INFO - 2017-01-19 22:23:16 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:23:16 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:23:16 --> Utf8 Class Initialized
INFO - 2017-01-19 22:23:16 --> URI Class Initialized
INFO - 2017-01-19 22:23:16 --> Router Class Initialized
INFO - 2017-01-19 22:23:16 --> Output Class Initialized
INFO - 2017-01-19 22:23:16 --> Security Class Initialized
DEBUG - 2017-01-19 22:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:23:16 --> Input Class Initialized
INFO - 2017-01-19 22:23:16 --> Language Class Initialized
INFO - 2017-01-19 22:23:16 --> Loader Class Initialized
INFO - 2017-01-19 22:23:16 --> Database Driver Class Initialized
INFO - 2017-01-19 22:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:23:16 --> Controller Class Initialized
INFO - 2017-01-19 22:23:16 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:23:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 22:23:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 22:23:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 22:23:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 22:23:16 --> Final output sent to browser
DEBUG - 2017-01-19 22:23:16 --> Total execution time: 0.0461
INFO - 2017-01-19 22:23:16 --> Config Class Initialized
INFO - 2017-01-19 22:23:16 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:23:16 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:23:16 --> Utf8 Class Initialized
INFO - 2017-01-19 22:23:16 --> URI Class Initialized
INFO - 2017-01-19 22:23:16 --> Router Class Initialized
INFO - 2017-01-19 22:23:16 --> Output Class Initialized
INFO - 2017-01-19 22:23:16 --> Security Class Initialized
DEBUG - 2017-01-19 22:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:23:16 --> Input Class Initialized
INFO - 2017-01-19 22:23:16 --> Language Class Initialized
INFO - 2017-01-19 22:23:16 --> Loader Class Initialized
INFO - 2017-01-19 22:23:16 --> Database Driver Class Initialized
INFO - 2017-01-19 22:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:23:16 --> Controller Class Initialized
INFO - 2017-01-19 22:23:16 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:23:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 22:23:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 22:23:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 22:23:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 22:23:16 --> Final output sent to browser
DEBUG - 2017-01-19 22:23:16 --> Total execution time: 0.0542
INFO - 2017-01-19 22:23:40 --> Config Class Initialized
INFO - 2017-01-19 22:23:40 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:23:40 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:23:40 --> Utf8 Class Initialized
INFO - 2017-01-19 22:23:40 --> URI Class Initialized
INFO - 2017-01-19 22:23:40 --> Router Class Initialized
INFO - 2017-01-19 22:23:40 --> Output Class Initialized
INFO - 2017-01-19 22:23:40 --> Security Class Initialized
DEBUG - 2017-01-19 22:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:23:40 --> Input Class Initialized
INFO - 2017-01-19 22:23:40 --> Language Class Initialized
INFO - 2017-01-19 22:23:40 --> Loader Class Initialized
INFO - 2017-01-19 22:23:40 --> Database Driver Class Initialized
INFO - 2017-01-19 22:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:23:40 --> Controller Class Initialized
INFO - 2017-01-19 22:23:40 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:23:40 --> Helper loaded: form_helper
INFO - 2017-01-19 22:23:40 --> Form Validation Class Initialized
INFO - 2017-01-19 22:23:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-19 22:23:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-19 22:23:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-19 22:23:40 --> Final output sent to browser
DEBUG - 2017-01-19 22:23:40 --> Total execution time: 0.0136
INFO - 2017-01-19 22:23:41 --> Config Class Initialized
INFO - 2017-01-19 22:23:41 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:23:41 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:23:41 --> Utf8 Class Initialized
INFO - 2017-01-19 22:23:41 --> URI Class Initialized
INFO - 2017-01-19 22:23:41 --> Router Class Initialized
INFO - 2017-01-19 22:23:41 --> Output Class Initialized
INFO - 2017-01-19 22:23:41 --> Security Class Initialized
DEBUG - 2017-01-19 22:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:23:41 --> Input Class Initialized
INFO - 2017-01-19 22:23:41 --> Language Class Initialized
INFO - 2017-01-19 22:23:41 --> Loader Class Initialized
INFO - 2017-01-19 22:23:41 --> Database Driver Class Initialized
INFO - 2017-01-19 22:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:23:41 --> Controller Class Initialized
INFO - 2017-01-19 22:23:41 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:23:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 22:23:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 22:23:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 22:23:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 22:23:41 --> Final output sent to browser
DEBUG - 2017-01-19 22:23:41 --> Total execution time: 0.0152
INFO - 2017-01-19 22:23:59 --> Config Class Initialized
INFO - 2017-01-19 22:23:59 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:23:59 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:23:59 --> Utf8 Class Initialized
INFO - 2017-01-19 22:23:59 --> URI Class Initialized
INFO - 2017-01-19 22:23:59 --> Router Class Initialized
INFO - 2017-01-19 22:23:59 --> Output Class Initialized
INFO - 2017-01-19 22:23:59 --> Security Class Initialized
DEBUG - 2017-01-19 22:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:23:59 --> Input Class Initialized
INFO - 2017-01-19 22:23:59 --> Language Class Initialized
INFO - 2017-01-19 22:23:59 --> Loader Class Initialized
INFO - 2017-01-19 22:23:59 --> Database Driver Class Initialized
INFO - 2017-01-19 22:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:23:59 --> Controller Class Initialized
INFO - 2017-01-19 22:23:59 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:23:59 --> Helper loaded: form_helper
INFO - 2017-01-19 22:23:59 --> Form Validation Class Initialized
INFO - 2017-01-19 22:23:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-19 22:23:59 --> Config Class Initialized
INFO - 2017-01-19 22:23:59 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:23:59 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:23:59 --> Utf8 Class Initialized
INFO - 2017-01-19 22:23:59 --> URI Class Initialized
INFO - 2017-01-19 22:23:59 --> Router Class Initialized
INFO - 2017-01-19 22:23:59 --> Output Class Initialized
INFO - 2017-01-19 22:23:59 --> Security Class Initialized
DEBUG - 2017-01-19 22:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:23:59 --> Input Class Initialized
INFO - 2017-01-19 22:23:59 --> Language Class Initialized
INFO - 2017-01-19 22:23:59 --> Loader Class Initialized
INFO - 2017-01-19 22:23:59 --> Database Driver Class Initialized
INFO - 2017-01-19 22:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:23:59 --> Controller Class Initialized
INFO - 2017-01-19 22:23:59 --> Helper loaded: date_helper
INFO - 2017-01-19 22:23:59 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:23:59 --> Helper loaded: form_helper
INFO - 2017-01-19 22:23:59 --> Form Validation Class Initialized
INFO - 2017-01-19 22:23:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-19 22:23:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-19 22:23:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-19 22:23:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-19 22:23:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-19 22:23:59 --> Final output sent to browser
DEBUG - 2017-01-19 22:23:59 --> Total execution time: 0.0151
INFO - 2017-01-19 22:24:00 --> Config Class Initialized
INFO - 2017-01-19 22:24:00 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:24:00 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:24:00 --> Utf8 Class Initialized
INFO - 2017-01-19 22:24:00 --> URI Class Initialized
INFO - 2017-01-19 22:24:00 --> Router Class Initialized
INFO - 2017-01-19 22:24:00 --> Output Class Initialized
INFO - 2017-01-19 22:24:00 --> Security Class Initialized
DEBUG - 2017-01-19 22:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:24:00 --> Input Class Initialized
INFO - 2017-01-19 22:24:00 --> Language Class Initialized
INFO - 2017-01-19 22:24:00 --> Loader Class Initialized
INFO - 2017-01-19 22:24:00 --> Database Driver Class Initialized
INFO - 2017-01-19 22:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:24:00 --> Controller Class Initialized
INFO - 2017-01-19 22:24:00 --> Helper loaded: date_helper
INFO - 2017-01-19 22:24:00 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:24:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:24:00 --> Helper loaded: form_helper
INFO - 2017-01-19 22:24:00 --> Form Validation Class Initialized
INFO - 2017-01-19 22:24:00 --> Final output sent to browser
DEBUG - 2017-01-19 22:24:00 --> Total execution time: 0.0141
INFO - 2017-01-19 22:24:07 --> Config Class Initialized
INFO - 2017-01-19 22:24:07 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:24:07 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:24:07 --> Utf8 Class Initialized
INFO - 2017-01-19 22:24:07 --> URI Class Initialized
INFO - 2017-01-19 22:24:07 --> Router Class Initialized
INFO - 2017-01-19 22:24:07 --> Output Class Initialized
INFO - 2017-01-19 22:24:07 --> Security Class Initialized
DEBUG - 2017-01-19 22:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:24:07 --> Input Class Initialized
INFO - 2017-01-19 22:24:07 --> Language Class Initialized
INFO - 2017-01-19 22:24:07 --> Loader Class Initialized
INFO - 2017-01-19 22:24:07 --> Database Driver Class Initialized
INFO - 2017-01-19 22:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:24:07 --> Controller Class Initialized
INFO - 2017-01-19 22:24:07 --> Helper loaded: date_helper
INFO - 2017-01-19 22:24:07 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:24:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:24:07 --> Helper loaded: form_helper
INFO - 2017-01-19 22:24:07 --> Form Validation Class Initialized
INFO - 2017-01-19 22:24:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-19 22:24:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-19 22:24:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-19 22:24:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-19 22:24:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-19 22:24:07 --> Final output sent to browser
DEBUG - 2017-01-19 22:24:07 --> Total execution time: 0.0152
INFO - 2017-01-19 22:24:07 --> Config Class Initialized
INFO - 2017-01-19 22:24:07 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:24:07 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:24:07 --> Utf8 Class Initialized
INFO - 2017-01-19 22:24:07 --> URI Class Initialized
INFO - 2017-01-19 22:24:07 --> Router Class Initialized
INFO - 2017-01-19 22:24:07 --> Output Class Initialized
INFO - 2017-01-19 22:24:07 --> Security Class Initialized
DEBUG - 2017-01-19 22:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:24:07 --> Input Class Initialized
INFO - 2017-01-19 22:24:07 --> Language Class Initialized
INFO - 2017-01-19 22:24:07 --> Loader Class Initialized
INFO - 2017-01-19 22:24:07 --> Database Driver Class Initialized
INFO - 2017-01-19 22:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:24:07 --> Controller Class Initialized
INFO - 2017-01-19 22:24:07 --> Helper loaded: date_helper
INFO - 2017-01-19 22:24:07 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:24:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:24:07 --> Helper loaded: form_helper
INFO - 2017-01-19 22:24:07 --> Form Validation Class Initialized
INFO - 2017-01-19 22:24:07 --> Final output sent to browser
DEBUG - 2017-01-19 22:24:07 --> Total execution time: 0.0153
INFO - 2017-01-19 22:24:11 --> Config Class Initialized
INFO - 2017-01-19 22:24:11 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:24:11 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:24:11 --> Utf8 Class Initialized
INFO - 2017-01-19 22:24:11 --> URI Class Initialized
INFO - 2017-01-19 22:24:11 --> Router Class Initialized
INFO - 2017-01-19 22:24:11 --> Output Class Initialized
INFO - 2017-01-19 22:24:11 --> Security Class Initialized
DEBUG - 2017-01-19 22:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:24:11 --> Input Class Initialized
INFO - 2017-01-19 22:24:11 --> Language Class Initialized
INFO - 2017-01-19 22:24:11 --> Loader Class Initialized
INFO - 2017-01-19 22:24:11 --> Database Driver Class Initialized
INFO - 2017-01-19 22:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:24:11 --> Controller Class Initialized
INFO - 2017-01-19 22:24:11 --> Helper loaded: date_helper
INFO - 2017-01-19 22:24:11 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:24:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:24:11 --> Helper loaded: form_helper
INFO - 2017-01-19 22:24:11 --> Form Validation Class Initialized
INFO - 2017-01-19 22:24:11 --> Final output sent to browser
DEBUG - 2017-01-19 22:24:11 --> Total execution time: 0.0144
INFO - 2017-01-19 22:24:11 --> Config Class Initialized
INFO - 2017-01-19 22:24:11 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:24:11 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:24:11 --> Utf8 Class Initialized
INFO - 2017-01-19 22:24:11 --> URI Class Initialized
INFO - 2017-01-19 22:24:11 --> Router Class Initialized
INFO - 2017-01-19 22:24:11 --> Output Class Initialized
INFO - 2017-01-19 22:24:11 --> Security Class Initialized
DEBUG - 2017-01-19 22:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:24:11 --> Input Class Initialized
INFO - 2017-01-19 22:24:11 --> Language Class Initialized
INFO - 2017-01-19 22:24:11 --> Loader Class Initialized
INFO - 2017-01-19 22:24:11 --> Database Driver Class Initialized
INFO - 2017-01-19 22:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:24:11 --> Controller Class Initialized
INFO - 2017-01-19 22:24:11 --> Helper loaded: date_helper
INFO - 2017-01-19 22:24:11 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:24:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:24:11 --> Helper loaded: form_helper
INFO - 2017-01-19 22:24:11 --> Form Validation Class Initialized
INFO - 2017-01-19 22:24:11 --> Final output sent to browser
DEBUG - 2017-01-19 22:24:11 --> Total execution time: 0.0143
INFO - 2017-01-19 22:24:16 --> Config Class Initialized
INFO - 2017-01-19 22:24:16 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:24:16 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:24:16 --> Utf8 Class Initialized
INFO - 2017-01-19 22:24:16 --> URI Class Initialized
INFO - 2017-01-19 22:24:16 --> Router Class Initialized
INFO - 2017-01-19 22:24:16 --> Output Class Initialized
INFO - 2017-01-19 22:24:16 --> Security Class Initialized
DEBUG - 2017-01-19 22:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:24:16 --> Input Class Initialized
INFO - 2017-01-19 22:24:16 --> Language Class Initialized
INFO - 2017-01-19 22:24:16 --> Loader Class Initialized
INFO - 2017-01-19 22:24:16 --> Database Driver Class Initialized
INFO - 2017-01-19 22:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:24:16 --> Controller Class Initialized
INFO - 2017-01-19 22:24:16 --> Helper loaded: date_helper
INFO - 2017-01-19 22:24:16 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:24:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:24:16 --> Helper loaded: form_helper
INFO - 2017-01-19 22:24:16 --> Form Validation Class Initialized
INFO - 2017-01-19 22:24:16 --> Final output sent to browser
DEBUG - 2017-01-19 22:24:16 --> Total execution time: 0.0146
INFO - 2017-01-19 22:24:20 --> Config Class Initialized
INFO - 2017-01-19 22:24:20 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:24:20 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:24:20 --> Utf8 Class Initialized
INFO - 2017-01-19 22:24:20 --> URI Class Initialized
INFO - 2017-01-19 22:24:20 --> Router Class Initialized
INFO - 2017-01-19 22:24:20 --> Output Class Initialized
INFO - 2017-01-19 22:24:20 --> Security Class Initialized
DEBUG - 2017-01-19 22:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:24:20 --> Input Class Initialized
INFO - 2017-01-19 22:24:20 --> Language Class Initialized
INFO - 2017-01-19 22:24:20 --> Loader Class Initialized
INFO - 2017-01-19 22:24:20 --> Database Driver Class Initialized
INFO - 2017-01-19 22:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:24:20 --> Controller Class Initialized
INFO - 2017-01-19 22:24:20 --> Helper loaded: date_helper
INFO - 2017-01-19 22:24:20 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:24:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:24:20 --> Helper loaded: form_helper
INFO - 2017-01-19 22:24:20 --> Form Validation Class Initialized
INFO - 2017-01-19 22:24:20 --> Final output sent to browser
DEBUG - 2017-01-19 22:24:20 --> Total execution time: 0.0340
INFO - 2017-01-19 22:24:38 --> Config Class Initialized
INFO - 2017-01-19 22:24:38 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:24:38 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:24:38 --> Utf8 Class Initialized
INFO - 2017-01-19 22:24:38 --> URI Class Initialized
INFO - 2017-01-19 22:24:38 --> Router Class Initialized
INFO - 2017-01-19 22:24:38 --> Output Class Initialized
INFO - 2017-01-19 22:24:38 --> Security Class Initialized
DEBUG - 2017-01-19 22:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:24:38 --> Input Class Initialized
INFO - 2017-01-19 22:24:38 --> Language Class Initialized
INFO - 2017-01-19 22:24:38 --> Loader Class Initialized
INFO - 2017-01-19 22:24:38 --> Database Driver Class Initialized
INFO - 2017-01-19 22:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:24:38 --> Controller Class Initialized
INFO - 2017-01-19 22:24:38 --> Helper loaded: date_helper
INFO - 2017-01-19 22:24:38 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:24:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:24:38 --> Helper loaded: form_helper
INFO - 2017-01-19 22:24:38 --> Form Validation Class Initialized
INFO - 2017-01-19 22:24:38 --> Final output sent to browser
DEBUG - 2017-01-19 22:24:38 --> Total execution time: 0.0146
INFO - 2017-01-19 22:24:38 --> Config Class Initialized
INFO - 2017-01-19 22:24:38 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:24:38 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:24:38 --> Utf8 Class Initialized
INFO - 2017-01-19 22:24:38 --> URI Class Initialized
INFO - 2017-01-19 22:24:38 --> Router Class Initialized
INFO - 2017-01-19 22:24:38 --> Output Class Initialized
INFO - 2017-01-19 22:24:38 --> Security Class Initialized
DEBUG - 2017-01-19 22:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:24:38 --> Input Class Initialized
INFO - 2017-01-19 22:24:38 --> Language Class Initialized
INFO - 2017-01-19 22:24:38 --> Loader Class Initialized
INFO - 2017-01-19 22:24:38 --> Database Driver Class Initialized
INFO - 2017-01-19 22:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:24:38 --> Controller Class Initialized
INFO - 2017-01-19 22:24:38 --> Helper loaded: date_helper
INFO - 2017-01-19 22:24:38 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:24:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:24:38 --> Helper loaded: form_helper
INFO - 2017-01-19 22:24:38 --> Form Validation Class Initialized
INFO - 2017-01-19 22:24:38 --> Final output sent to browser
DEBUG - 2017-01-19 22:24:38 --> Total execution time: 0.0148
INFO - 2017-01-19 22:24:45 --> Config Class Initialized
INFO - 2017-01-19 22:24:45 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:24:45 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:24:45 --> Utf8 Class Initialized
INFO - 2017-01-19 22:24:45 --> URI Class Initialized
INFO - 2017-01-19 22:24:45 --> Router Class Initialized
INFO - 2017-01-19 22:24:45 --> Output Class Initialized
INFO - 2017-01-19 22:24:45 --> Security Class Initialized
DEBUG - 2017-01-19 22:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:24:45 --> Input Class Initialized
INFO - 2017-01-19 22:24:45 --> Language Class Initialized
INFO - 2017-01-19 22:24:45 --> Loader Class Initialized
INFO - 2017-01-19 22:24:45 --> Database Driver Class Initialized
INFO - 2017-01-19 22:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:24:45 --> Controller Class Initialized
INFO - 2017-01-19 22:24:45 --> Helper loaded: date_helper
INFO - 2017-01-19 22:24:45 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:24:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:24:45 --> Helper loaded: form_helper
INFO - 2017-01-19 22:24:45 --> Form Validation Class Initialized
INFO - 2017-01-19 22:24:45 --> Final output sent to browser
DEBUG - 2017-01-19 22:24:45 --> Total execution time: 0.0143
INFO - 2017-01-19 22:24:45 --> Config Class Initialized
INFO - 2017-01-19 22:24:45 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:24:45 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:24:45 --> Utf8 Class Initialized
INFO - 2017-01-19 22:24:45 --> URI Class Initialized
INFO - 2017-01-19 22:24:45 --> Router Class Initialized
INFO - 2017-01-19 22:24:45 --> Output Class Initialized
INFO - 2017-01-19 22:24:45 --> Security Class Initialized
DEBUG - 2017-01-19 22:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:24:45 --> Input Class Initialized
INFO - 2017-01-19 22:24:45 --> Language Class Initialized
INFO - 2017-01-19 22:24:45 --> Loader Class Initialized
INFO - 2017-01-19 22:24:45 --> Database Driver Class Initialized
INFO - 2017-01-19 22:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:24:45 --> Controller Class Initialized
INFO - 2017-01-19 22:24:45 --> Helper loaded: date_helper
INFO - 2017-01-19 22:24:45 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:24:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:24:45 --> Helper loaded: form_helper
INFO - 2017-01-19 22:24:45 --> Form Validation Class Initialized
INFO - 2017-01-19 22:24:45 --> Final output sent to browser
DEBUG - 2017-01-19 22:24:45 --> Total execution time: 0.0144
INFO - 2017-01-19 22:24:53 --> Config Class Initialized
INFO - 2017-01-19 22:24:53 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:24:53 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:24:53 --> Utf8 Class Initialized
INFO - 2017-01-19 22:24:53 --> URI Class Initialized
INFO - 2017-01-19 22:24:53 --> Router Class Initialized
INFO - 2017-01-19 22:24:53 --> Output Class Initialized
INFO - 2017-01-19 22:24:53 --> Security Class Initialized
DEBUG - 2017-01-19 22:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:24:53 --> Input Class Initialized
INFO - 2017-01-19 22:24:53 --> Language Class Initialized
INFO - 2017-01-19 22:24:53 --> Loader Class Initialized
INFO - 2017-01-19 22:24:53 --> Database Driver Class Initialized
INFO - 2017-01-19 22:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:24:53 --> Controller Class Initialized
INFO - 2017-01-19 22:24:53 --> Helper loaded: date_helper
INFO - 2017-01-19 22:24:53 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:24:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:24:53 --> Helper loaded: form_helper
INFO - 2017-01-19 22:24:53 --> Form Validation Class Initialized
INFO - 2017-01-19 22:24:53 --> Final output sent to browser
DEBUG - 2017-01-19 22:24:53 --> Total execution time: 0.0149
INFO - 2017-01-19 22:24:58 --> Config Class Initialized
INFO - 2017-01-19 22:24:58 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:24:58 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:24:58 --> Utf8 Class Initialized
INFO - 2017-01-19 22:24:58 --> URI Class Initialized
INFO - 2017-01-19 22:24:58 --> Router Class Initialized
INFO - 2017-01-19 22:24:58 --> Output Class Initialized
INFO - 2017-01-19 22:24:58 --> Security Class Initialized
DEBUG - 2017-01-19 22:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:24:58 --> Input Class Initialized
INFO - 2017-01-19 22:24:58 --> Language Class Initialized
INFO - 2017-01-19 22:24:58 --> Loader Class Initialized
INFO - 2017-01-19 22:24:58 --> Database Driver Class Initialized
INFO - 2017-01-19 22:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:24:58 --> Controller Class Initialized
INFO - 2017-01-19 22:24:58 --> Helper loaded: date_helper
INFO - 2017-01-19 22:24:58 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:24:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:24:58 --> Helper loaded: form_helper
INFO - 2017-01-19 22:24:58 --> Form Validation Class Initialized
INFO - 2017-01-19 22:24:58 --> Final output sent to browser
DEBUG - 2017-01-19 22:24:58 --> Total execution time: 0.0139
INFO - 2017-01-19 22:25:02 --> Config Class Initialized
INFO - 2017-01-19 22:25:02 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:25:02 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:25:02 --> Utf8 Class Initialized
INFO - 2017-01-19 22:25:02 --> URI Class Initialized
INFO - 2017-01-19 22:25:02 --> Router Class Initialized
INFO - 2017-01-19 22:25:02 --> Output Class Initialized
INFO - 2017-01-19 22:25:02 --> Security Class Initialized
DEBUG - 2017-01-19 22:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:25:02 --> Input Class Initialized
INFO - 2017-01-19 22:25:02 --> Language Class Initialized
INFO - 2017-01-19 22:25:02 --> Loader Class Initialized
INFO - 2017-01-19 22:25:02 --> Database Driver Class Initialized
INFO - 2017-01-19 22:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:25:02 --> Controller Class Initialized
INFO - 2017-01-19 22:25:02 --> Helper loaded: date_helper
INFO - 2017-01-19 22:25:02 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:25:02 --> Helper loaded: form_helper
INFO - 2017-01-19 22:25:02 --> Form Validation Class Initialized
INFO - 2017-01-19 22:25:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-19 22:25:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-19 22:25:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-19 22:25:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-19 22:25:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-19 22:25:02 --> Final output sent to browser
DEBUG - 2017-01-19 22:25:02 --> Total execution time: 0.0530
INFO - 2017-01-19 22:25:02 --> Config Class Initialized
INFO - 2017-01-19 22:25:02 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:25:02 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:25:02 --> Utf8 Class Initialized
INFO - 2017-01-19 22:25:02 --> URI Class Initialized
INFO - 2017-01-19 22:25:02 --> Router Class Initialized
INFO - 2017-01-19 22:25:02 --> Output Class Initialized
INFO - 2017-01-19 22:25:02 --> Security Class Initialized
DEBUG - 2017-01-19 22:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:25:02 --> Input Class Initialized
INFO - 2017-01-19 22:25:02 --> Language Class Initialized
INFO - 2017-01-19 22:25:02 --> Loader Class Initialized
INFO - 2017-01-19 22:25:02 --> Database Driver Class Initialized
INFO - 2017-01-19 22:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:25:02 --> Controller Class Initialized
INFO - 2017-01-19 22:25:02 --> Helper loaded: date_helper
INFO - 2017-01-19 22:25:02 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:25:02 --> Helper loaded: form_helper
INFO - 2017-01-19 22:25:02 --> Form Validation Class Initialized
INFO - 2017-01-19 22:25:02 --> Final output sent to browser
DEBUG - 2017-01-19 22:25:02 --> Total execution time: 0.0152
INFO - 2017-01-19 22:25:02 --> Config Class Initialized
INFO - 2017-01-19 22:25:02 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:25:02 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:25:02 --> Utf8 Class Initialized
INFO - 2017-01-19 22:25:02 --> URI Class Initialized
INFO - 2017-01-19 22:25:02 --> Router Class Initialized
INFO - 2017-01-19 22:25:02 --> Output Class Initialized
INFO - 2017-01-19 22:25:02 --> Security Class Initialized
DEBUG - 2017-01-19 22:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:25:02 --> Input Class Initialized
INFO - 2017-01-19 22:25:02 --> Language Class Initialized
INFO - 2017-01-19 22:25:02 --> Loader Class Initialized
INFO - 2017-01-19 22:25:02 --> Database Driver Class Initialized
INFO - 2017-01-19 22:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:25:02 --> Controller Class Initialized
INFO - 2017-01-19 22:25:02 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:25:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-19 22:25:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-19 22:25:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-19 22:25:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-19 22:25:02 --> Final output sent to browser
DEBUG - 2017-01-19 22:25:02 --> Total execution time: 0.0670
INFO - 2017-01-19 22:25:05 --> Config Class Initialized
INFO - 2017-01-19 22:25:05 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:25:05 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:25:05 --> Utf8 Class Initialized
INFO - 2017-01-19 22:25:05 --> URI Class Initialized
INFO - 2017-01-19 22:25:05 --> Router Class Initialized
INFO - 2017-01-19 22:25:05 --> Output Class Initialized
INFO - 2017-01-19 22:25:05 --> Security Class Initialized
DEBUG - 2017-01-19 22:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:25:05 --> Input Class Initialized
INFO - 2017-01-19 22:25:05 --> Language Class Initialized
INFO - 2017-01-19 22:25:05 --> Loader Class Initialized
INFO - 2017-01-19 22:25:05 --> Config Class Initialized
INFO - 2017-01-19 22:25:05 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:25:05 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:25:05 --> Utf8 Class Initialized
INFO - 2017-01-19 22:25:05 --> URI Class Initialized
INFO - 2017-01-19 22:25:05 --> Router Class Initialized
INFO - 2017-01-19 22:25:05 --> Database Driver Class Initialized
INFO - 2017-01-19 22:25:05 --> Output Class Initialized
INFO - 2017-01-19 22:25:05 --> Security Class Initialized
DEBUG - 2017-01-19 22:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:25:05 --> Input Class Initialized
INFO - 2017-01-19 22:25:05 --> Language Class Initialized
INFO - 2017-01-19 22:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:25:05 --> Controller Class Initialized
INFO - 2017-01-19 22:25:05 --> Loader Class Initialized
INFO - 2017-01-19 22:25:05 --> Helper loaded: date_helper
INFO - 2017-01-19 22:25:05 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:25:05 --> Helper loaded: form_helper
INFO - 2017-01-19 22:25:05 --> Form Validation Class Initialized
INFO - 2017-01-19 22:25:05 --> Database Driver Class Initialized
INFO - 2017-01-19 22:25:05 --> Final output sent to browser
DEBUG - 2017-01-19 22:25:05 --> Total execution time: 0.0256
INFO - 2017-01-19 22:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:25:05 --> Controller Class Initialized
INFO - 2017-01-19 22:25:05 --> Helper loaded: date_helper
INFO - 2017-01-19 22:25:05 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:25:05 --> Helper loaded: form_helper
INFO - 2017-01-19 22:25:05 --> Form Validation Class Initialized
INFO - 2017-01-19 22:25:05 --> Final output sent to browser
DEBUG - 2017-01-19 22:25:05 --> Total execution time: 0.0887
INFO - 2017-01-19 22:25:25 --> Config Class Initialized
INFO - 2017-01-19 22:25:25 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:25:25 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:25:25 --> Utf8 Class Initialized
INFO - 2017-01-19 22:25:25 --> URI Class Initialized
INFO - 2017-01-19 22:25:25 --> Router Class Initialized
INFO - 2017-01-19 22:25:25 --> Output Class Initialized
INFO - 2017-01-19 22:25:25 --> Security Class Initialized
DEBUG - 2017-01-19 22:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:25:25 --> Input Class Initialized
INFO - 2017-01-19 22:25:25 --> Language Class Initialized
INFO - 2017-01-19 22:25:25 --> Loader Class Initialized
INFO - 2017-01-19 22:25:25 --> Database Driver Class Initialized
INFO - 2017-01-19 22:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:25:25 --> Controller Class Initialized
INFO - 2017-01-19 22:25:25 --> Upload Class Initialized
INFO - 2017-01-19 22:25:25 --> Helper loaded: date_helper
INFO - 2017-01-19 22:25:25 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:25:25 --> Helper loaded: form_helper
INFO - 2017-01-19 22:25:25 --> Form Validation Class Initialized
INFO - 2017-01-19 22:25:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-19 22:25:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-19 22:25:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-19 22:25:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-19 22:25:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-19 22:25:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-19 22:25:25 --> Final output sent to browser
DEBUG - 2017-01-19 22:25:25 --> Total execution time: 0.0853
INFO - 2017-01-19 22:25:27 --> Config Class Initialized
INFO - 2017-01-19 22:25:27 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:25:27 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:25:27 --> Utf8 Class Initialized
INFO - 2017-01-19 22:25:27 --> URI Class Initialized
INFO - 2017-01-19 22:25:27 --> Router Class Initialized
INFO - 2017-01-19 22:25:27 --> Output Class Initialized
INFO - 2017-01-19 22:25:27 --> Security Class Initialized
DEBUG - 2017-01-19 22:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:25:27 --> Input Class Initialized
INFO - 2017-01-19 22:25:27 --> Language Class Initialized
INFO - 2017-01-19 22:25:27 --> Loader Class Initialized
INFO - 2017-01-19 22:25:27 --> Database Driver Class Initialized
INFO - 2017-01-19 22:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:25:27 --> Controller Class Initialized
INFO - 2017-01-19 22:25:27 --> Upload Class Initialized
INFO - 2017-01-19 22:25:27 --> Helper loaded: date_helper
INFO - 2017-01-19 22:25:27 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:25:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:25:27 --> Helper loaded: form_helper
INFO - 2017-01-19 22:25:27 --> Form Validation Class Initialized
INFO - 2017-01-19 22:25:27 --> Final output sent to browser
DEBUG - 2017-01-19 22:25:27 --> Total execution time: 0.0534
INFO - 2017-01-19 22:25:34 --> Config Class Initialized
INFO - 2017-01-19 22:25:34 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:25:34 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:25:34 --> Utf8 Class Initialized
INFO - 2017-01-19 22:25:34 --> URI Class Initialized
INFO - 2017-01-19 22:25:34 --> Router Class Initialized
INFO - 2017-01-19 22:25:34 --> Output Class Initialized
INFO - 2017-01-19 22:25:34 --> Security Class Initialized
DEBUG - 2017-01-19 22:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:25:34 --> Input Class Initialized
INFO - 2017-01-19 22:25:34 --> Language Class Initialized
INFO - 2017-01-19 22:25:34 --> Loader Class Initialized
INFO - 2017-01-19 22:25:34 --> Database Driver Class Initialized
INFO - 2017-01-19 22:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:25:34 --> Controller Class Initialized
INFO - 2017-01-19 22:25:34 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:25:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:25:34 --> Config Class Initialized
INFO - 2017-01-19 22:25:34 --> Hooks Class Initialized
DEBUG - 2017-01-19 22:25:34 --> UTF-8 Support Enabled
INFO - 2017-01-19 22:25:34 --> Utf8 Class Initialized
INFO - 2017-01-19 22:25:34 --> URI Class Initialized
INFO - 2017-01-19 22:25:34 --> Router Class Initialized
INFO - 2017-01-19 22:25:34 --> Output Class Initialized
INFO - 2017-01-19 22:25:34 --> Security Class Initialized
DEBUG - 2017-01-19 22:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-19 22:25:34 --> Input Class Initialized
INFO - 2017-01-19 22:25:34 --> Language Class Initialized
INFO - 2017-01-19 22:25:34 --> Loader Class Initialized
INFO - 2017-01-19 22:25:34 --> Database Driver Class Initialized
INFO - 2017-01-19 22:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-19 22:25:34 --> Controller Class Initialized
INFO - 2017-01-19 22:25:34 --> Helper loaded: url_helper
DEBUG - 2017-01-19 22:25:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-19 22:25:34 --> Helper loaded: form_helper
INFO - 2017-01-19 22:25:34 --> Form Validation Class Initialized
INFO - 2017-01-19 22:25:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-19 22:25:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-19 22:25:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-19 22:25:34 --> Final output sent to browser
DEBUG - 2017-01-19 22:25:34 --> Total execution time: 0.0147

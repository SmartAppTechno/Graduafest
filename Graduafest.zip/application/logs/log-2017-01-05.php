<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-05 00:00:22 --> Config Class Initialized
INFO - 2017-01-05 00:00:22 --> Hooks Class Initialized
DEBUG - 2017-01-05 00:00:22 --> UTF-8 Support Enabled
INFO - 2017-01-05 00:00:22 --> Utf8 Class Initialized
INFO - 2017-01-05 00:00:22 --> URI Class Initialized
DEBUG - 2017-01-05 00:00:22 --> No URI present. Default controller set.
INFO - 2017-01-05 00:00:23 --> Router Class Initialized
INFO - 2017-01-05 00:00:23 --> Output Class Initialized
INFO - 2017-01-05 00:00:23 --> Security Class Initialized
DEBUG - 2017-01-05 00:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 00:00:23 --> Input Class Initialized
INFO - 2017-01-05 00:00:23 --> Language Class Initialized
INFO - 2017-01-05 00:00:23 --> Loader Class Initialized
INFO - 2017-01-05 00:00:23 --> Database Driver Class Initialized
INFO - 2017-01-05 00:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 00:00:23 --> Controller Class Initialized
INFO - 2017-01-05 00:00:23 --> Helper loaded: url_helper
DEBUG - 2017-01-05 00:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-05 00:00:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-05 00:00:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-05 00:00:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-05 00:00:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-05 00:00:24 --> Final output sent to browser
DEBUG - 2017-01-05 00:00:24 --> Total execution time: 2.0626
INFO - 2017-01-05 00:03:57 --> Config Class Initialized
INFO - 2017-01-05 00:03:57 --> Hooks Class Initialized
DEBUG - 2017-01-05 00:03:57 --> UTF-8 Support Enabled
INFO - 2017-01-05 00:03:57 --> Utf8 Class Initialized
INFO - 2017-01-05 00:03:57 --> URI Class Initialized
DEBUG - 2017-01-05 00:03:57 --> No URI present. Default controller set.
INFO - 2017-01-05 00:03:57 --> Router Class Initialized
INFO - 2017-01-05 00:03:57 --> Output Class Initialized
INFO - 2017-01-05 00:03:57 --> Security Class Initialized
DEBUG - 2017-01-05 00:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 00:03:57 --> Input Class Initialized
INFO - 2017-01-05 00:03:57 --> Language Class Initialized
INFO - 2017-01-05 00:03:57 --> Loader Class Initialized
INFO - 2017-01-05 00:03:58 --> Database Driver Class Initialized
INFO - 2017-01-05 00:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 00:03:58 --> Controller Class Initialized
INFO - 2017-01-05 00:03:58 --> Helper loaded: url_helper
DEBUG - 2017-01-05 00:03:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-05 00:03:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-05 00:03:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-05 00:03:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-05 00:03:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-05 00:03:58 --> Final output sent to browser
DEBUG - 2017-01-05 00:03:58 --> Total execution time: 1.7304
INFO - 2017-01-05 00:55:03 --> Config Class Initialized
INFO - 2017-01-05 00:55:03 --> Hooks Class Initialized
DEBUG - 2017-01-05 00:55:03 --> UTF-8 Support Enabled
INFO - 2017-01-05 00:55:03 --> Utf8 Class Initialized
INFO - 2017-01-05 00:55:03 --> URI Class Initialized
DEBUG - 2017-01-05 00:55:03 --> No URI present. Default controller set.
INFO - 2017-01-05 00:55:03 --> Router Class Initialized
INFO - 2017-01-05 00:55:03 --> Output Class Initialized
INFO - 2017-01-05 00:55:03 --> Security Class Initialized
DEBUG - 2017-01-05 00:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 00:55:04 --> Input Class Initialized
INFO - 2017-01-05 00:55:04 --> Language Class Initialized
INFO - 2017-01-05 00:55:04 --> Loader Class Initialized
INFO - 2017-01-05 00:55:04 --> Database Driver Class Initialized
INFO - 2017-01-05 00:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 00:55:04 --> Controller Class Initialized
INFO - 2017-01-05 00:55:04 --> Helper loaded: url_helper
DEBUG - 2017-01-05 00:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-05 00:55:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-05 00:55:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-05 00:55:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-05 00:55:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-05 00:55:05 --> Final output sent to browser
DEBUG - 2017-01-05 00:55:05 --> Total execution time: 1.7533
INFO - 2017-01-05 01:02:47 --> Config Class Initialized
INFO - 2017-01-05 01:02:47 --> Hooks Class Initialized
DEBUG - 2017-01-05 01:02:48 --> UTF-8 Support Enabled
INFO - 2017-01-05 01:02:48 --> Utf8 Class Initialized
INFO - 2017-01-05 01:02:48 --> URI Class Initialized
DEBUG - 2017-01-05 01:02:48 --> No URI present. Default controller set.
INFO - 2017-01-05 01:02:48 --> Router Class Initialized
INFO - 2017-01-05 01:02:48 --> Output Class Initialized
INFO - 2017-01-05 01:02:48 --> Security Class Initialized
DEBUG - 2017-01-05 01:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 01:02:48 --> Input Class Initialized
INFO - 2017-01-05 01:02:48 --> Language Class Initialized
INFO - 2017-01-05 01:02:48 --> Loader Class Initialized
INFO - 2017-01-05 01:02:48 --> Database Driver Class Initialized
INFO - 2017-01-05 01:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 01:02:49 --> Controller Class Initialized
INFO - 2017-01-05 01:02:49 --> Helper loaded: url_helper
DEBUG - 2017-01-05 01:02:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-05 01:02:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-05 01:02:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-05 01:02:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-05 01:02:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-05 01:02:49 --> Final output sent to browser
DEBUG - 2017-01-05 01:02:49 --> Total execution time: 1.7288
INFO - 2017-01-05 02:01:29 --> Config Class Initialized
INFO - 2017-01-05 02:01:29 --> Hooks Class Initialized
DEBUG - 2017-01-05 02:01:29 --> UTF-8 Support Enabled
INFO - 2017-01-05 02:01:29 --> Utf8 Class Initialized
INFO - 2017-01-05 02:01:29 --> URI Class Initialized
DEBUG - 2017-01-05 02:01:30 --> No URI present. Default controller set.
INFO - 2017-01-05 02:01:30 --> Router Class Initialized
INFO - 2017-01-05 02:01:30 --> Output Class Initialized
INFO - 2017-01-05 02:01:30 --> Security Class Initialized
DEBUG - 2017-01-05 02:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 02:01:30 --> Input Class Initialized
INFO - 2017-01-05 02:01:30 --> Language Class Initialized
INFO - 2017-01-05 02:01:30 --> Loader Class Initialized
INFO - 2017-01-05 02:01:30 --> Database Driver Class Initialized
INFO - 2017-01-05 02:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 02:01:31 --> Controller Class Initialized
INFO - 2017-01-05 02:01:31 --> Helper loaded: url_helper
DEBUG - 2017-01-05 02:01:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-05 02:01:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-05 02:01:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-05 02:01:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-05 02:01:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-05 02:01:31 --> Final output sent to browser
DEBUG - 2017-01-05 02:01:31 --> Total execution time: 1.7578
INFO - 2017-01-05 02:01:32 --> Config Class Initialized
INFO - 2017-01-05 02:01:32 --> Hooks Class Initialized
DEBUG - 2017-01-05 02:01:32 --> UTF-8 Support Enabled
INFO - 2017-01-05 02:01:32 --> Utf8 Class Initialized
INFO - 2017-01-05 02:01:32 --> URI Class Initialized
INFO - 2017-01-05 02:01:32 --> Router Class Initialized
INFO - 2017-01-05 02:01:32 --> Output Class Initialized
INFO - 2017-01-05 02:01:32 --> Security Class Initialized
DEBUG - 2017-01-05 02:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 02:01:32 --> Input Class Initialized
INFO - 2017-01-05 02:01:32 --> Language Class Initialized
INFO - 2017-01-05 02:01:32 --> Loader Class Initialized
INFO - 2017-01-05 02:01:32 --> Database Driver Class Initialized
INFO - 2017-01-05 02:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 02:01:32 --> Controller Class Initialized
INFO - 2017-01-05 02:01:32 --> Helper loaded: url_helper
DEBUG - 2017-01-05 02:01:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-05 02:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-05 02:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-05 02:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-05 02:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-05 02:01:32 --> Final output sent to browser
DEBUG - 2017-01-05 02:01:32 --> Total execution time: 0.0218
INFO - 2017-01-05 02:43:52 --> Config Class Initialized
INFO - 2017-01-05 02:43:52 --> Hooks Class Initialized
DEBUG - 2017-01-05 02:43:53 --> UTF-8 Support Enabled
INFO - 2017-01-05 02:43:53 --> Utf8 Class Initialized
INFO - 2017-01-05 02:43:53 --> URI Class Initialized
INFO - 2017-01-05 02:43:53 --> Router Class Initialized
INFO - 2017-01-05 02:43:53 --> Output Class Initialized
INFO - 2017-01-05 02:43:53 --> Security Class Initialized
DEBUG - 2017-01-05 02:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 02:43:53 --> Input Class Initialized
INFO - 2017-01-05 02:43:53 --> Language Class Initialized
INFO - 2017-01-05 02:43:53 --> Loader Class Initialized
INFO - 2017-01-05 02:43:53 --> Database Driver Class Initialized
INFO - 2017-01-05 02:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 02:43:54 --> Controller Class Initialized
INFO - 2017-01-05 02:43:54 --> Helper loaded: url_helper
DEBUG - 2017-01-05 02:43:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-05 02:43:57 --> Config Class Initialized
INFO - 2017-01-05 02:43:57 --> Hooks Class Initialized
DEBUG - 2017-01-05 02:43:57 --> UTF-8 Support Enabled
INFO - 2017-01-05 02:43:57 --> Utf8 Class Initialized
INFO - 2017-01-05 02:43:57 --> URI Class Initialized
INFO - 2017-01-05 02:43:57 --> Router Class Initialized
INFO - 2017-01-05 02:43:57 --> Output Class Initialized
INFO - 2017-01-05 02:43:57 --> Security Class Initialized
DEBUG - 2017-01-05 02:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 02:43:57 --> Input Class Initialized
INFO - 2017-01-05 02:43:57 --> Language Class Initialized
INFO - 2017-01-05 02:43:57 --> Loader Class Initialized
INFO - 2017-01-05 02:43:57 --> Database Driver Class Initialized
INFO - 2017-01-05 02:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 02:43:57 --> Controller Class Initialized
INFO - 2017-01-05 02:43:57 --> Helper loaded: date_helper
DEBUG - 2017-01-05 02:43:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-05 02:43:57 --> Helper loaded: url_helper
INFO - 2017-01-05 02:43:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-05 02:43:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-05 02:43:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-05 02:43:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-05 02:43:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-05 02:43:57 --> Final output sent to browser
DEBUG - 2017-01-05 02:43:57 --> Total execution time: 0.4307
INFO - 2017-01-05 02:43:58 --> Config Class Initialized
INFO - 2017-01-05 02:43:58 --> Hooks Class Initialized
DEBUG - 2017-01-05 02:43:58 --> UTF-8 Support Enabled
INFO - 2017-01-05 02:43:58 --> Utf8 Class Initialized
INFO - 2017-01-05 02:43:58 --> URI Class Initialized
INFO - 2017-01-05 02:43:58 --> Router Class Initialized
INFO - 2017-01-05 02:43:58 --> Output Class Initialized
INFO - 2017-01-05 02:43:58 --> Security Class Initialized
DEBUG - 2017-01-05 02:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 02:43:58 --> Input Class Initialized
INFO - 2017-01-05 02:43:58 --> Language Class Initialized
INFO - 2017-01-05 02:43:58 --> Loader Class Initialized
INFO - 2017-01-05 02:43:58 --> Database Driver Class Initialized
INFO - 2017-01-05 02:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 02:43:58 --> Controller Class Initialized
INFO - 2017-01-05 02:43:58 --> Helper loaded: url_helper
DEBUG - 2017-01-05 02:43:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-05 02:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-05 02:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-05 02:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-05 02:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-05 02:43:58 --> Final output sent to browser
DEBUG - 2017-01-05 02:43:58 --> Total execution time: 0.0229
INFO - 2017-01-05 02:44:50 --> Config Class Initialized
INFO - 2017-01-05 02:44:50 --> Hooks Class Initialized
DEBUG - 2017-01-05 02:44:50 --> UTF-8 Support Enabled
INFO - 2017-01-05 02:44:50 --> Utf8 Class Initialized
INFO - 2017-01-05 02:44:50 --> URI Class Initialized
INFO - 2017-01-05 02:44:50 --> Router Class Initialized
INFO - 2017-01-05 02:44:50 --> Output Class Initialized
INFO - 2017-01-05 02:44:50 --> Security Class Initialized
DEBUG - 2017-01-05 02:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 02:44:50 --> Input Class Initialized
INFO - 2017-01-05 02:44:50 --> Language Class Initialized
INFO - 2017-01-05 02:44:50 --> Loader Class Initialized
INFO - 2017-01-05 02:44:50 --> Database Driver Class Initialized
INFO - 2017-01-05 02:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 02:44:50 --> Controller Class Initialized
INFO - 2017-01-05 02:44:50 --> Helper loaded: date_helper
DEBUG - 2017-01-05 02:44:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-05 02:44:50 --> Helper loaded: url_helper
INFO - 2017-01-05 02:44:50 --> Helper loaded: download_helper
INFO - 2017-01-05 02:44:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-05 02:44:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-05 02:44:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-05 02:44:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-05 02:44:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-05 02:44:50 --> Final output sent to browser
DEBUG - 2017-01-05 02:44:50 --> Total execution time: 0.3401
INFO - 2017-01-05 02:44:51 --> Config Class Initialized
INFO - 2017-01-05 02:44:51 --> Hooks Class Initialized
DEBUG - 2017-01-05 02:44:51 --> UTF-8 Support Enabled
INFO - 2017-01-05 02:44:51 --> Utf8 Class Initialized
INFO - 2017-01-05 02:44:51 --> URI Class Initialized
INFO - 2017-01-05 02:44:51 --> Router Class Initialized
INFO - 2017-01-05 02:44:51 --> Output Class Initialized
INFO - 2017-01-05 02:44:51 --> Security Class Initialized
DEBUG - 2017-01-05 02:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 02:44:51 --> Input Class Initialized
INFO - 2017-01-05 02:44:51 --> Language Class Initialized
INFO - 2017-01-05 02:44:51 --> Loader Class Initialized
INFO - 2017-01-05 02:44:51 --> Database Driver Class Initialized
INFO - 2017-01-05 02:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 02:44:51 --> Controller Class Initialized
INFO - 2017-01-05 02:44:51 --> Helper loaded: url_helper
DEBUG - 2017-01-05 02:44:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-05 02:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-05 02:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-05 02:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-05 02:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-05 02:44:51 --> Final output sent to browser
DEBUG - 2017-01-05 02:44:51 --> Total execution time: 0.0132
INFO - 2017-01-05 02:45:42 --> Config Class Initialized
INFO - 2017-01-05 02:45:42 --> Hooks Class Initialized
DEBUG - 2017-01-05 02:45:42 --> UTF-8 Support Enabled
INFO - 2017-01-05 02:45:42 --> Utf8 Class Initialized
INFO - 2017-01-05 02:45:42 --> URI Class Initialized
INFO - 2017-01-05 02:45:42 --> Router Class Initialized
INFO - 2017-01-05 02:45:42 --> Output Class Initialized
INFO - 2017-01-05 02:45:42 --> Security Class Initialized
DEBUG - 2017-01-05 02:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 02:45:42 --> Input Class Initialized
INFO - 2017-01-05 02:45:42 --> Language Class Initialized
INFO - 2017-01-05 02:45:42 --> Loader Class Initialized
INFO - 2017-01-05 02:45:42 --> Database Driver Class Initialized
INFO - 2017-01-05 02:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 02:45:42 --> Controller Class Initialized
INFO - 2017-01-05 02:45:42 --> Helper loaded: url_helper
DEBUG - 2017-01-05 02:45:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-05 02:45:42 --> Config Class Initialized
INFO - 2017-01-05 02:45:42 --> Hooks Class Initialized
DEBUG - 2017-01-05 02:45:42 --> UTF-8 Support Enabled
INFO - 2017-01-05 02:45:42 --> Utf8 Class Initialized
INFO - 2017-01-05 02:45:42 --> URI Class Initialized
DEBUG - 2017-01-05 02:45:42 --> No URI present. Default controller set.
INFO - 2017-01-05 02:45:42 --> Router Class Initialized
INFO - 2017-01-05 02:45:42 --> Output Class Initialized
INFO - 2017-01-05 02:45:42 --> Security Class Initialized
DEBUG - 2017-01-05 02:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 02:45:42 --> Input Class Initialized
INFO - 2017-01-05 02:45:42 --> Language Class Initialized
INFO - 2017-01-05 02:45:42 --> Loader Class Initialized
INFO - 2017-01-05 02:45:42 --> Database Driver Class Initialized
INFO - 2017-01-05 02:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 02:45:42 --> Controller Class Initialized
INFO - 2017-01-05 02:45:42 --> Helper loaded: url_helper
DEBUG - 2017-01-05 02:45:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-05 02:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-05 02:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-05 02:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-05 02:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-05 02:45:42 --> Final output sent to browser
DEBUG - 2017-01-05 02:45:42 --> Total execution time: 0.0132
INFO - 2017-01-05 02:45:42 --> Config Class Initialized
INFO - 2017-01-05 02:45:42 --> Hooks Class Initialized
DEBUG - 2017-01-05 02:45:42 --> UTF-8 Support Enabled
INFO - 2017-01-05 02:45:42 --> Utf8 Class Initialized
INFO - 2017-01-05 02:45:42 --> URI Class Initialized
INFO - 2017-01-05 02:45:42 --> Router Class Initialized
INFO - 2017-01-05 02:45:42 --> Output Class Initialized
INFO - 2017-01-05 02:45:42 --> Security Class Initialized
DEBUG - 2017-01-05 02:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 02:45:42 --> Input Class Initialized
INFO - 2017-01-05 02:45:42 --> Language Class Initialized
INFO - 2017-01-05 02:45:42 --> Loader Class Initialized
INFO - 2017-01-05 02:45:42 --> Database Driver Class Initialized
INFO - 2017-01-05 02:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 02:45:42 --> Controller Class Initialized
INFO - 2017-01-05 02:45:42 --> Helper loaded: url_helper
DEBUG - 2017-01-05 02:45:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-05 02:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-05 02:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-05 02:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-05 02:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-05 02:45:42 --> Final output sent to browser
DEBUG - 2017-01-05 02:45:42 --> Total execution time: 0.0146
INFO - 2017-01-05 02:45:42 --> Config Class Initialized
INFO - 2017-01-05 02:45:42 --> Hooks Class Initialized
DEBUG - 2017-01-05 02:45:42 --> UTF-8 Support Enabled
INFO - 2017-01-05 02:45:42 --> Utf8 Class Initialized
INFO - 2017-01-05 02:45:42 --> URI Class Initialized
INFO - 2017-01-05 02:45:42 --> Router Class Initialized
INFO - 2017-01-05 02:45:42 --> Output Class Initialized
INFO - 2017-01-05 02:45:42 --> Security Class Initialized
DEBUG - 2017-01-05 02:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 02:45:42 --> Input Class Initialized
INFO - 2017-01-05 02:45:42 --> Language Class Initialized
INFO - 2017-01-05 02:45:42 --> Loader Class Initialized
INFO - 2017-01-05 02:45:42 --> Database Driver Class Initialized
INFO - 2017-01-05 02:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 02:45:42 --> Controller Class Initialized
INFO - 2017-01-05 02:45:42 --> Helper loaded: url_helper
DEBUG - 2017-01-05 02:45:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-05 02:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-05 02:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-05 02:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-05 02:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-05 02:45:42 --> Final output sent to browser
DEBUG - 2017-01-05 02:45:42 --> Total execution time: 0.0132
INFO - 2017-01-05 14:40:36 --> Config Class Initialized
INFO - 2017-01-05 14:40:36 --> Config Class Initialized
INFO - 2017-01-05 14:40:36 --> Hooks Class Initialized
INFO - 2017-01-05 14:40:36 --> Hooks Class Initialized
DEBUG - 2017-01-05 14:40:36 --> UTF-8 Support Enabled
DEBUG - 2017-01-05 14:40:36 --> UTF-8 Support Enabled
INFO - 2017-01-05 14:40:36 --> Utf8 Class Initialized
INFO - 2017-01-05 14:40:36 --> Utf8 Class Initialized
INFO - 2017-01-05 14:40:36 --> URI Class Initialized
INFO - 2017-01-05 14:40:37 --> URI Class Initialized
DEBUG - 2017-01-05 14:40:37 --> No URI present. Default controller set.
DEBUG - 2017-01-05 14:40:37 --> No URI present. Default controller set.
INFO - 2017-01-05 14:40:37 --> Router Class Initialized
INFO - 2017-01-05 14:40:37 --> Router Class Initialized
INFO - 2017-01-05 14:40:37 --> Output Class Initialized
INFO - 2017-01-05 14:40:37 --> Output Class Initialized
INFO - 2017-01-05 14:40:37 --> Security Class Initialized
INFO - 2017-01-05 14:40:37 --> Security Class Initialized
DEBUG - 2017-01-05 14:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 14:40:37 --> Input Class Initialized
DEBUG - 2017-01-05 14:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 14:40:37 --> Language Class Initialized
INFO - 2017-01-05 14:40:37 --> Input Class Initialized
INFO - 2017-01-05 14:40:37 --> Language Class Initialized
INFO - 2017-01-05 14:40:37 --> Loader Class Initialized
INFO - 2017-01-05 14:40:37 --> Loader Class Initialized
INFO - 2017-01-05 14:40:37 --> Database Driver Class Initialized
INFO - 2017-01-05 14:40:37 --> Database Driver Class Initialized
INFO - 2017-01-05 14:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 14:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 14:40:37 --> Controller Class Initialized
INFO - 2017-01-05 14:40:38 --> Controller Class Initialized
INFO - 2017-01-05 14:40:38 --> Helper loaded: url_helper
INFO - 2017-01-05 14:40:38 --> Helper loaded: url_helper
DEBUG - 2017-01-05 14:40:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-01-05 14:40:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-05 14:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-05 14:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-05 14:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-05 14:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-05 14:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-05 14:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-05 14:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-05 14:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-05 14:40:38 --> Final output sent to browser
DEBUG - 2017-01-05 14:40:38 --> Total execution time: 1.6649
INFO - 2017-01-05 14:40:38 --> Final output sent to browser
DEBUG - 2017-01-05 14:40:38 --> Total execution time: 1.6649
INFO - 2017-01-05 15:37:35 --> Config Class Initialized
INFO - 2017-01-05 15:37:35 --> Hooks Class Initialized
INFO - 2017-01-05 15:37:35 --> Config Class Initialized
INFO - 2017-01-05 15:37:35 --> Config Class Initialized
INFO - 2017-01-05 15:37:35 --> Config Class Initialized
INFO - 2017-01-05 15:37:35 --> Hooks Class Initialized
INFO - 2017-01-05 15:37:35 --> Hooks Class Initialized
DEBUG - 2017-01-05 15:37:35 --> UTF-8 Support Enabled
INFO - 2017-01-05 15:37:35 --> Utf8 Class Initialized
INFO - 2017-01-05 15:37:35 --> Hooks Class Initialized
INFO - 2017-01-05 15:37:35 --> URI Class Initialized
DEBUG - 2017-01-05 15:37:35 --> UTF-8 Support Enabled
DEBUG - 2017-01-05 15:37:35 --> UTF-8 Support Enabled
INFO - 2017-01-05 15:37:36 --> Utf8 Class Initialized
DEBUG - 2017-01-05 15:37:36 --> No URI present. Default controller set.
INFO - 2017-01-05 15:37:36 --> Utf8 Class Initialized
INFO - 2017-01-05 15:37:36 --> Router Class Initialized
INFO - 2017-01-05 15:37:36 --> URI Class Initialized
DEBUG - 2017-01-05 15:37:36 --> UTF-8 Support Enabled
INFO - 2017-01-05 15:37:36 --> Utf8 Class Initialized
INFO - 2017-01-05 15:37:36 --> URI Class Initialized
INFO - 2017-01-05 15:37:36 --> Router Class Initialized
INFO - 2017-01-05 15:37:36 --> Router Class Initialized
INFO - 2017-01-05 15:37:36 --> Output Class Initialized
INFO - 2017-01-05 15:37:36 --> URI Class Initialized
INFO - 2017-01-05 15:37:36 --> Output Class Initialized
INFO - 2017-01-05 15:37:36 --> Router Class Initialized
INFO - 2017-01-05 15:37:36 --> Output Class Initialized
INFO - 2017-01-05 15:37:36 --> Output Class Initialized
INFO - 2017-01-05 15:37:36 --> Security Class Initialized
INFO - 2017-01-05 15:37:36 --> Security Class Initialized
INFO - 2017-01-05 15:37:36 --> Security Class Initialized
DEBUG - 2017-01-05 15:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-05 15:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 15:37:36 --> Input Class Initialized
INFO - 2017-01-05 15:37:36 --> Input Class Initialized
INFO - 2017-01-05 15:37:36 --> Language Class Initialized
DEBUG - 2017-01-05 15:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 15:37:36 --> Input Class Initialized
INFO - 2017-01-05 15:37:36 --> Security Class Initialized
INFO - 2017-01-05 15:37:36 --> Language Class Initialized
DEBUG - 2017-01-05 15:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 15:37:36 --> Language Class Initialized
INFO - 2017-01-05 15:37:36 --> Input Class Initialized
ERROR - 2017-01-05 15:37:36 --> 404 Page Not Found: Imagenes_portada/Galeria4.jpg
ERROR - 2017-01-05 15:37:36 --> 404 Page Not Found: Imagenes_portada/Galeria5.jpg
INFO - 2017-01-05 15:37:36 --> Language Class Initialized
INFO - 2017-01-05 15:37:36 --> Loader Class Initialized
ERROR - 2017-01-05 15:37:36 --> 404 Page Not Found: Imagenes_portada/Galeria2.jpg
INFO - 2017-01-05 15:37:36 --> Database Driver Class Initialized
INFO - 2017-01-05 15:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 15:37:37 --> Controller Class Initialized
INFO - 2017-01-05 15:37:37 --> Helper loaded: url_helper
DEBUG - 2017-01-05 15:37:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-05 15:37:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-05 15:37:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-05 15:37:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-05 15:37:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-05 15:37:38 --> Final output sent to browser
DEBUG - 2017-01-05 15:37:38 --> Total execution time: 6.8082
INFO - 2017-01-05 15:37:40 --> Config Class Initialized
INFO - 2017-01-05 15:37:40 --> Config Class Initialized
INFO - 2017-01-05 15:37:40 --> Hooks Class Initialized
INFO - 2017-01-05 15:37:40 --> Hooks Class Initialized
DEBUG - 2017-01-05 15:37:40 --> UTF-8 Support Enabled
DEBUG - 2017-01-05 15:37:40 --> UTF-8 Support Enabled
INFO - 2017-01-05 15:37:40 --> Utf8 Class Initialized
INFO - 2017-01-05 15:37:40 --> Utf8 Class Initialized
INFO - 2017-01-05 15:37:40 --> URI Class Initialized
INFO - 2017-01-05 15:37:40 --> URI Class Initialized
INFO - 2017-01-05 15:37:40 --> Router Class Initialized
INFO - 2017-01-05 15:37:40 --> Router Class Initialized
INFO - 2017-01-05 15:37:40 --> Output Class Initialized
INFO - 2017-01-05 15:37:40 --> Output Class Initialized
INFO - 2017-01-05 15:37:40 --> Security Class Initialized
INFO - 2017-01-05 15:37:40 --> Security Class Initialized
DEBUG - 2017-01-05 15:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 15:37:40 --> Input Class Initialized
INFO - 2017-01-05 15:37:40 --> Language Class Initialized
DEBUG - 2017-01-05 15:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 15:37:40 --> Input Class Initialized
INFO - 2017-01-05 15:37:40 --> Language Class Initialized
ERROR - 2017-01-05 15:37:40 --> 404 Page Not Found: Imagenes_portada/Galeria3.jpg
ERROR - 2017-01-05 15:37:40 --> 404 Page Not Found: Imagenes_portada/Galeria6.jpg
INFO - 2017-01-05 18:25:09 --> Config Class Initialized
INFO - 2017-01-05 18:25:09 --> Hooks Class Initialized
DEBUG - 2017-01-05 18:25:09 --> UTF-8 Support Enabled
INFO - 2017-01-05 18:25:09 --> Utf8 Class Initialized
INFO - 2017-01-05 18:25:09 --> URI Class Initialized
DEBUG - 2017-01-05 18:25:09 --> No URI present. Default controller set.
INFO - 2017-01-05 18:25:09 --> Router Class Initialized
INFO - 2017-01-05 18:25:09 --> Output Class Initialized
INFO - 2017-01-05 18:25:09 --> Security Class Initialized
DEBUG - 2017-01-05 18:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 18:25:09 --> Input Class Initialized
INFO - 2017-01-05 18:25:09 --> Language Class Initialized
INFO - 2017-01-05 18:25:09 --> Loader Class Initialized
INFO - 2017-01-05 18:25:10 --> Database Driver Class Initialized
INFO - 2017-01-05 18:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 18:25:10 --> Controller Class Initialized
INFO - 2017-01-05 18:25:10 --> Helper loaded: url_helper
DEBUG - 2017-01-05 18:25:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-05 18:25:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-05 18:25:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-05 18:25:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-05 18:25:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-05 18:25:10 --> Final output sent to browser
DEBUG - 2017-01-05 18:25:10 --> Total execution time: 1.5046
INFO - 2017-01-05 21:29:32 --> Config Class Initialized
INFO - 2017-01-05 21:29:32 --> Hooks Class Initialized
DEBUG - 2017-01-05 21:29:32 --> UTF-8 Support Enabled
INFO - 2017-01-05 21:29:32 --> Utf8 Class Initialized
INFO - 2017-01-05 21:29:32 --> URI Class Initialized
DEBUG - 2017-01-05 21:29:32 --> No URI present. Default controller set.
INFO - 2017-01-05 21:29:32 --> Router Class Initialized
INFO - 2017-01-05 21:29:32 --> Output Class Initialized
INFO - 2017-01-05 21:29:32 --> Security Class Initialized
DEBUG - 2017-01-05 21:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 21:29:32 --> Input Class Initialized
INFO - 2017-01-05 21:29:32 --> Language Class Initialized
INFO - 2017-01-05 21:29:32 --> Loader Class Initialized
INFO - 2017-01-05 21:29:33 --> Database Driver Class Initialized
INFO - 2017-01-05 21:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 21:29:33 --> Controller Class Initialized
INFO - 2017-01-05 21:29:33 --> Helper loaded: url_helper
DEBUG - 2017-01-05 21:29:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-05 21:29:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-05 21:29:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-05 21:29:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-05 21:29:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-05 21:29:33 --> Final output sent to browser
DEBUG - 2017-01-05 21:29:33 --> Total execution time: 1.8990
INFO - 2017-01-05 22:16:51 --> Config Class Initialized
INFO - 2017-01-05 22:16:51 --> Hooks Class Initialized
DEBUG - 2017-01-05 22:16:52 --> UTF-8 Support Enabled
INFO - 2017-01-05 22:16:52 --> Utf8 Class Initialized
INFO - 2017-01-05 22:16:52 --> URI Class Initialized
DEBUG - 2017-01-05 22:16:52 --> No URI present. Default controller set.
INFO - 2017-01-05 22:16:52 --> Router Class Initialized
INFO - 2017-01-05 22:16:52 --> Output Class Initialized
INFO - 2017-01-05 22:16:52 --> Security Class Initialized
DEBUG - 2017-01-05 22:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 22:16:52 --> Input Class Initialized
INFO - 2017-01-05 22:16:52 --> Language Class Initialized
INFO - 2017-01-05 22:16:52 --> Loader Class Initialized
INFO - 2017-01-05 22:16:52 --> Database Driver Class Initialized
INFO - 2017-01-05 22:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 22:16:53 --> Controller Class Initialized
INFO - 2017-01-05 22:16:53 --> Helper loaded: url_helper
DEBUG - 2017-01-05 22:16:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-05 22:16:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-05 22:16:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-05 22:16:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-05 22:16:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-05 22:16:53 --> Final output sent to browser
DEBUG - 2017-01-05 22:16:53 --> Total execution time: 1.8158
INFO - 2017-01-05 22:53:12 --> Config Class Initialized
INFO - 2017-01-05 22:53:12 --> Hooks Class Initialized
DEBUG - 2017-01-05 22:53:12 --> UTF-8 Support Enabled
INFO - 2017-01-05 22:53:12 --> Utf8 Class Initialized
INFO - 2017-01-05 22:53:12 --> URI Class Initialized
DEBUG - 2017-01-05 22:53:12 --> No URI present. Default controller set.
INFO - 2017-01-05 22:53:12 --> Router Class Initialized
INFO - 2017-01-05 22:53:12 --> Output Class Initialized
INFO - 2017-01-05 22:53:12 --> Security Class Initialized
DEBUG - 2017-01-05 22:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 22:53:12 --> Input Class Initialized
INFO - 2017-01-05 22:53:12 --> Language Class Initialized
INFO - 2017-01-05 22:53:12 --> Loader Class Initialized
INFO - 2017-01-05 22:53:13 --> Database Driver Class Initialized
INFO - 2017-01-05 22:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 22:53:13 --> Controller Class Initialized
INFO - 2017-01-05 22:53:13 --> Helper loaded: url_helper
DEBUG - 2017-01-05 22:53:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-05 22:53:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-05 22:53:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-05 22:53:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-05 22:53:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-05 22:53:13 --> Final output sent to browser
DEBUG - 2017-01-05 22:53:13 --> Total execution time: 1.7505
INFO - 2017-01-05 22:53:22 --> Config Class Initialized
INFO - 2017-01-05 22:53:22 --> Hooks Class Initialized
DEBUG - 2017-01-05 22:53:22 --> UTF-8 Support Enabled
INFO - 2017-01-05 22:53:22 --> Utf8 Class Initialized
INFO - 2017-01-05 22:53:22 --> URI Class Initialized
INFO - 2017-01-05 22:53:22 --> Router Class Initialized
INFO - 2017-01-05 22:53:22 --> Output Class Initialized
INFO - 2017-01-05 22:53:22 --> Security Class Initialized
DEBUG - 2017-01-05 22:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 22:53:22 --> Input Class Initialized
INFO - 2017-01-05 22:53:22 --> Language Class Initialized
INFO - 2017-01-05 22:53:22 --> Loader Class Initialized
INFO - 2017-01-05 22:53:22 --> Database Driver Class Initialized
INFO - 2017-01-05 22:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 22:53:22 --> Controller Class Initialized
INFO - 2017-01-05 22:53:22 --> Helper loaded: url_helper
DEBUG - 2017-01-05 22:53:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-05 22:53:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-05 22:53:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-05 22:53:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-05 22:53:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-05 22:53:22 --> Final output sent to browser
DEBUG - 2017-01-05 22:53:22 --> Total execution time: 0.0288
INFO - 2017-01-05 23:06:58 --> Config Class Initialized
INFO - 2017-01-05 23:06:58 --> Hooks Class Initialized
DEBUG - 2017-01-05 23:06:58 --> UTF-8 Support Enabled
INFO - 2017-01-05 23:06:58 --> Utf8 Class Initialized
INFO - 2017-01-05 23:06:58 --> URI Class Initialized
DEBUG - 2017-01-05 23:06:59 --> No URI present. Default controller set.
INFO - 2017-01-05 23:06:59 --> Router Class Initialized
INFO - 2017-01-05 23:06:59 --> Output Class Initialized
INFO - 2017-01-05 23:06:59 --> Security Class Initialized
DEBUG - 2017-01-05 23:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-05 23:06:59 --> Input Class Initialized
INFO - 2017-01-05 23:06:59 --> Language Class Initialized
INFO - 2017-01-05 23:06:59 --> Loader Class Initialized
INFO - 2017-01-05 23:06:59 --> Database Driver Class Initialized
INFO - 2017-01-05 23:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-05 23:07:00 --> Controller Class Initialized
INFO - 2017-01-05 23:07:00 --> Helper loaded: url_helper
DEBUG - 2017-01-05 23:07:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-05 23:07:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-05 23:07:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-05 23:07:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-05 23:07:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-05 23:07:01 --> Final output sent to browser
DEBUG - 2017-01-05 23:07:01 --> Total execution time: 2.7184

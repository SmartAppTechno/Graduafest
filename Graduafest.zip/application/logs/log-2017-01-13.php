<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-13 00:23:25 --> Config Class Initialized
INFO - 2017-01-13 00:23:25 --> Hooks Class Initialized
DEBUG - 2017-01-13 00:23:25 --> UTF-8 Support Enabled
INFO - 2017-01-13 00:23:25 --> Utf8 Class Initialized
INFO - 2017-01-13 00:23:25 --> URI Class Initialized
DEBUG - 2017-01-13 00:23:25 --> No URI present. Default controller set.
INFO - 2017-01-13 00:23:25 --> Router Class Initialized
INFO - 2017-01-13 00:23:25 --> Output Class Initialized
INFO - 2017-01-13 00:23:25 --> Security Class Initialized
DEBUG - 2017-01-13 00:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 00:23:25 --> Input Class Initialized
INFO - 2017-01-13 00:23:25 --> Language Class Initialized
INFO - 2017-01-13 00:23:25 --> Loader Class Initialized
INFO - 2017-01-13 00:23:25 --> Database Driver Class Initialized
INFO - 2017-01-13 00:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 00:23:25 --> Controller Class Initialized
INFO - 2017-01-13 00:23:25 --> Helper loaded: url_helper
DEBUG - 2017-01-13 00:23:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 00:23:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 00:23:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 00:23:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 00:23:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 00:23:26 --> Final output sent to browser
DEBUG - 2017-01-13 00:23:26 --> Total execution time: 1.2344
INFO - 2017-01-13 00:23:27 --> Config Class Initialized
INFO - 2017-01-13 00:23:27 --> Hooks Class Initialized
DEBUG - 2017-01-13 00:23:27 --> UTF-8 Support Enabled
INFO - 2017-01-13 00:23:27 --> Utf8 Class Initialized
INFO - 2017-01-13 00:23:27 --> URI Class Initialized
INFO - 2017-01-13 00:23:27 --> Router Class Initialized
INFO - 2017-01-13 00:23:27 --> Output Class Initialized
INFO - 2017-01-13 00:23:27 --> Security Class Initialized
DEBUG - 2017-01-13 00:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 00:23:27 --> Input Class Initialized
INFO - 2017-01-13 00:23:27 --> Language Class Initialized
INFO - 2017-01-13 00:23:27 --> Loader Class Initialized
INFO - 2017-01-13 00:23:27 --> Database Driver Class Initialized
INFO - 2017-01-13 00:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 00:23:27 --> Controller Class Initialized
INFO - 2017-01-13 00:23:27 --> Helper loaded: url_helper
DEBUG - 2017-01-13 00:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 00:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 00:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 00:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 00:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 00:23:27 --> Final output sent to browser
DEBUG - 2017-01-13 00:23:27 --> Total execution time: 0.0143
INFO - 2017-01-13 00:40:20 --> Config Class Initialized
INFO - 2017-01-13 00:40:20 --> Hooks Class Initialized
DEBUG - 2017-01-13 00:40:20 --> UTF-8 Support Enabled
INFO - 2017-01-13 00:40:20 --> Utf8 Class Initialized
INFO - 2017-01-13 00:40:20 --> URI Class Initialized
INFO - 2017-01-13 00:40:20 --> Router Class Initialized
INFO - 2017-01-13 00:40:20 --> Output Class Initialized
INFO - 2017-01-13 00:40:20 --> Security Class Initialized
DEBUG - 2017-01-13 00:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 00:40:20 --> Input Class Initialized
INFO - 2017-01-13 00:40:20 --> Language Class Initialized
INFO - 2017-01-13 00:40:20 --> Loader Class Initialized
INFO - 2017-01-13 00:40:20 --> Database Driver Class Initialized
INFO - 2017-01-13 00:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 00:40:21 --> Controller Class Initialized
INFO - 2017-01-13 00:40:21 --> Helper loaded: url_helper
DEBUG - 2017-01-13 00:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 00:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 00:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 00:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 00:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 00:40:21 --> Final output sent to browser
DEBUG - 2017-01-13 00:40:21 --> Total execution time: 1.2209
INFO - 2017-01-13 08:52:09 --> Config Class Initialized
INFO - 2017-01-13 08:52:09 --> Hooks Class Initialized
DEBUG - 2017-01-13 08:52:10 --> UTF-8 Support Enabled
INFO - 2017-01-13 08:52:10 --> Utf8 Class Initialized
INFO - 2017-01-13 08:52:10 --> URI Class Initialized
DEBUG - 2017-01-13 08:52:10 --> No URI present. Default controller set.
INFO - 2017-01-13 08:52:10 --> Router Class Initialized
INFO - 2017-01-13 08:52:10 --> Output Class Initialized
INFO - 2017-01-13 08:52:10 --> Security Class Initialized
DEBUG - 2017-01-13 08:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 08:52:10 --> Input Class Initialized
INFO - 2017-01-13 08:52:10 --> Language Class Initialized
INFO - 2017-01-13 08:52:10 --> Loader Class Initialized
INFO - 2017-01-13 08:52:10 --> Database Driver Class Initialized
INFO - 2017-01-13 08:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 08:52:11 --> Controller Class Initialized
INFO - 2017-01-13 08:52:11 --> Helper loaded: url_helper
DEBUG - 2017-01-13 08:52:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 08:52:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 08:52:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 08:52:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 08:52:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 08:52:11 --> Final output sent to browser
DEBUG - 2017-01-13 08:52:11 --> Total execution time: 1.8757
INFO - 2017-01-13 11:38:09 --> Config Class Initialized
INFO - 2017-01-13 11:38:09 --> Hooks Class Initialized
DEBUG - 2017-01-13 11:38:09 --> UTF-8 Support Enabled
INFO - 2017-01-13 11:38:09 --> Utf8 Class Initialized
INFO - 2017-01-13 11:38:09 --> URI Class Initialized
INFO - 2017-01-13 11:38:09 --> Router Class Initialized
INFO - 2017-01-13 11:38:09 --> Output Class Initialized
INFO - 2017-01-13 11:38:09 --> Security Class Initialized
DEBUG - 2017-01-13 11:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 11:38:09 --> Input Class Initialized
INFO - 2017-01-13 11:38:09 --> Language Class Initialized
INFO - 2017-01-13 11:38:09 --> Loader Class Initialized
INFO - 2017-01-13 11:38:10 --> Database Driver Class Initialized
INFO - 2017-01-13 11:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 11:38:10 --> Controller Class Initialized
INFO - 2017-01-13 11:38:10 --> Helper loaded: url_helper
DEBUG - 2017-01-13 11:38:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 11:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 11:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 11:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 11:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 11:38:10 --> Final output sent to browser
DEBUG - 2017-01-13 11:38:10 --> Total execution time: 1.6584
INFO - 2017-01-13 11:38:19 --> Config Class Initialized
INFO - 2017-01-13 11:38:19 --> Hooks Class Initialized
DEBUG - 2017-01-13 11:38:19 --> UTF-8 Support Enabled
INFO - 2017-01-13 11:38:19 --> Utf8 Class Initialized
INFO - 2017-01-13 11:38:19 --> URI Class Initialized
DEBUG - 2017-01-13 11:38:19 --> No URI present. Default controller set.
INFO - 2017-01-13 11:38:19 --> Router Class Initialized
INFO - 2017-01-13 11:38:19 --> Output Class Initialized
INFO - 2017-01-13 11:38:19 --> Security Class Initialized
DEBUG - 2017-01-13 11:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 11:38:19 --> Input Class Initialized
INFO - 2017-01-13 11:38:19 --> Language Class Initialized
INFO - 2017-01-13 11:38:19 --> Loader Class Initialized
INFO - 2017-01-13 11:38:19 --> Database Driver Class Initialized
INFO - 2017-01-13 11:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 11:38:19 --> Controller Class Initialized
INFO - 2017-01-13 11:38:19 --> Helper loaded: url_helper
DEBUG - 2017-01-13 11:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 11:38:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 11:38:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 11:38:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 11:38:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 11:38:19 --> Final output sent to browser
DEBUG - 2017-01-13 11:38:19 --> Total execution time: 0.0132
INFO - 2017-01-13 11:38:28 --> Config Class Initialized
INFO - 2017-01-13 11:38:28 --> Hooks Class Initialized
DEBUG - 2017-01-13 11:38:28 --> UTF-8 Support Enabled
INFO - 2017-01-13 11:38:28 --> Utf8 Class Initialized
INFO - 2017-01-13 11:38:28 --> URI Class Initialized
INFO - 2017-01-13 11:38:28 --> Router Class Initialized
INFO - 2017-01-13 11:38:28 --> Output Class Initialized
INFO - 2017-01-13 11:38:28 --> Security Class Initialized
DEBUG - 2017-01-13 11:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 11:38:28 --> Input Class Initialized
INFO - 2017-01-13 11:38:28 --> Language Class Initialized
INFO - 2017-01-13 11:38:28 --> Loader Class Initialized
INFO - 2017-01-13 11:38:28 --> Database Driver Class Initialized
INFO - 2017-01-13 11:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 11:38:28 --> Controller Class Initialized
INFO - 2017-01-13 11:38:28 --> Helper loaded: url_helper
DEBUG - 2017-01-13 11:38:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 11:38:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 11:38:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 11:38:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 11:38:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 11:38:28 --> Final output sent to browser
DEBUG - 2017-01-13 11:38:28 --> Total execution time: 0.0133
INFO - 2017-01-13 19:15:36 --> Config Class Initialized
INFO - 2017-01-13 19:15:36 --> Hooks Class Initialized
DEBUG - 2017-01-13 19:15:36 --> UTF-8 Support Enabled
INFO - 2017-01-13 19:15:36 --> Utf8 Class Initialized
INFO - 2017-01-13 19:15:36 --> URI Class Initialized
DEBUG - 2017-01-13 19:15:36 --> No URI present. Default controller set.
INFO - 2017-01-13 19:15:36 --> Router Class Initialized
INFO - 2017-01-13 19:15:36 --> Output Class Initialized
INFO - 2017-01-13 19:15:36 --> Security Class Initialized
DEBUG - 2017-01-13 19:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 19:15:36 --> Input Class Initialized
INFO - 2017-01-13 19:15:36 --> Language Class Initialized
INFO - 2017-01-13 19:15:36 --> Loader Class Initialized
INFO - 2017-01-13 19:15:36 --> Database Driver Class Initialized
INFO - 2017-01-13 19:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 19:15:37 --> Controller Class Initialized
INFO - 2017-01-13 19:15:37 --> Helper loaded: url_helper
DEBUG - 2017-01-13 19:15:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 19:15:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 19:15:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 19:15:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 19:15:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 19:15:37 --> Final output sent to browser
DEBUG - 2017-01-13 19:15:37 --> Total execution time: 1.5627
INFO - 2017-01-13 19:22:02 --> Config Class Initialized
INFO - 2017-01-13 19:22:02 --> Hooks Class Initialized
DEBUG - 2017-01-13 19:22:02 --> UTF-8 Support Enabled
INFO - 2017-01-13 19:22:02 --> Utf8 Class Initialized
INFO - 2017-01-13 19:22:02 --> URI Class Initialized
DEBUG - 2017-01-13 19:22:02 --> No URI present. Default controller set.
INFO - 2017-01-13 19:22:02 --> Router Class Initialized
INFO - 2017-01-13 19:22:02 --> Output Class Initialized
INFO - 2017-01-13 19:22:02 --> Security Class Initialized
DEBUG - 2017-01-13 19:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 19:22:02 --> Input Class Initialized
INFO - 2017-01-13 19:22:02 --> Language Class Initialized
INFO - 2017-01-13 19:22:02 --> Loader Class Initialized
INFO - 2017-01-13 19:22:02 --> Database Driver Class Initialized
INFO - 2017-01-13 19:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 19:22:02 --> Controller Class Initialized
INFO - 2017-01-13 19:22:02 --> Helper loaded: url_helper
DEBUG - 2017-01-13 19:22:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 19:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 19:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 19:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 19:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 19:22:02 --> Final output sent to browser
DEBUG - 2017-01-13 19:22:02 --> Total execution time: 0.0146
INFO - 2017-01-13 20:56:34 --> Config Class Initialized
INFO - 2017-01-13 20:56:34 --> Hooks Class Initialized
DEBUG - 2017-01-13 20:56:34 --> UTF-8 Support Enabled
INFO - 2017-01-13 20:56:34 --> Utf8 Class Initialized
INFO - 2017-01-13 20:56:34 --> URI Class Initialized
DEBUG - 2017-01-13 20:56:34 --> No URI present. Default controller set.
INFO - 2017-01-13 20:56:34 --> Router Class Initialized
INFO - 2017-01-13 20:56:34 --> Output Class Initialized
INFO - 2017-01-13 20:56:34 --> Security Class Initialized
DEBUG - 2017-01-13 20:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 20:56:34 --> Input Class Initialized
INFO - 2017-01-13 20:56:34 --> Language Class Initialized
INFO - 2017-01-13 20:56:34 --> Loader Class Initialized
INFO - 2017-01-13 20:56:34 --> Database Driver Class Initialized
INFO - 2017-01-13 20:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 20:56:34 --> Controller Class Initialized
INFO - 2017-01-13 20:56:34 --> Helper loaded: url_helper
DEBUG - 2017-01-13 20:56:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 20:56:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 20:56:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 20:56:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 20:56:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 20:56:34 --> Final output sent to browser
DEBUG - 2017-01-13 20:56:34 --> Total execution time: 0.0150
INFO - 2017-01-13 22:12:27 --> Config Class Initialized
INFO - 2017-01-13 22:12:27 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:12:27 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:12:27 --> Utf8 Class Initialized
INFO - 2017-01-13 22:12:27 --> URI Class Initialized
DEBUG - 2017-01-13 22:12:27 --> No URI present. Default controller set.
INFO - 2017-01-13 22:12:27 --> Router Class Initialized
INFO - 2017-01-13 22:12:27 --> Output Class Initialized
INFO - 2017-01-13 22:12:27 --> Security Class Initialized
DEBUG - 2017-01-13 22:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:12:27 --> Input Class Initialized
INFO - 2017-01-13 22:12:27 --> Language Class Initialized
INFO - 2017-01-13 22:12:27 --> Loader Class Initialized
INFO - 2017-01-13 22:12:27 --> Database Driver Class Initialized
INFO - 2017-01-13 22:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:12:27 --> Controller Class Initialized
INFO - 2017-01-13 22:12:27 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:12:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:12:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:12:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:12:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:12:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:12:27 --> Final output sent to browser
DEBUG - 2017-01-13 22:12:27 --> Total execution time: 0.0131
INFO - 2017-01-13 22:12:29 --> Config Class Initialized
INFO - 2017-01-13 22:12:29 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:12:29 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:12:29 --> Utf8 Class Initialized
INFO - 2017-01-13 22:12:29 --> URI Class Initialized
INFO - 2017-01-13 22:12:29 --> Router Class Initialized
INFO - 2017-01-13 22:12:29 --> Output Class Initialized
INFO - 2017-01-13 22:12:29 --> Security Class Initialized
DEBUG - 2017-01-13 22:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:12:29 --> Input Class Initialized
INFO - 2017-01-13 22:12:29 --> Language Class Initialized
INFO - 2017-01-13 22:12:29 --> Loader Class Initialized
INFO - 2017-01-13 22:12:29 --> Database Driver Class Initialized
INFO - 2017-01-13 22:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:12:29 --> Controller Class Initialized
INFO - 2017-01-13 22:12:29 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:12:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:12:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:12:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:12:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:12:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:12:29 --> Final output sent to browser
DEBUG - 2017-01-13 22:12:29 --> Total execution time: 0.0133
INFO - 2017-01-13 22:12:53 --> Config Class Initialized
INFO - 2017-01-13 22:12:53 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:12:53 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:12:53 --> Utf8 Class Initialized
INFO - 2017-01-13 22:12:53 --> URI Class Initialized
INFO - 2017-01-13 22:12:53 --> Router Class Initialized
INFO - 2017-01-13 22:12:53 --> Output Class Initialized
INFO - 2017-01-13 22:12:53 --> Security Class Initialized
DEBUG - 2017-01-13 22:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:12:53 --> Input Class Initialized
INFO - 2017-01-13 22:12:53 --> Language Class Initialized
INFO - 2017-01-13 22:12:53 --> Loader Class Initialized
INFO - 2017-01-13 22:12:53 --> Database Driver Class Initialized
INFO - 2017-01-13 22:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:12:53 --> Controller Class Initialized
INFO - 2017-01-13 22:12:53 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:12:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:12:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:12:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:12:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:12:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:12:53 --> Final output sent to browser
DEBUG - 2017-01-13 22:12:53 --> Total execution time: 0.0857
INFO - 2017-01-13 22:12:53 --> Config Class Initialized
INFO - 2017-01-13 22:12:53 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:12:53 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:12:53 --> Utf8 Class Initialized
INFO - 2017-01-13 22:12:53 --> URI Class Initialized
INFO - 2017-01-13 22:12:53 --> Router Class Initialized
INFO - 2017-01-13 22:12:53 --> Output Class Initialized
INFO - 2017-01-13 22:12:53 --> Security Class Initialized
DEBUG - 2017-01-13 22:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:12:53 --> Input Class Initialized
INFO - 2017-01-13 22:12:53 --> Language Class Initialized
INFO - 2017-01-13 22:12:53 --> Loader Class Initialized
INFO - 2017-01-13 22:12:53 --> Database Driver Class Initialized
INFO - 2017-01-13 22:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:12:53 --> Controller Class Initialized
INFO - 2017-01-13 22:12:53 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:12:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:12:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:12:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:12:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:12:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:12:53 --> Final output sent to browser
DEBUG - 2017-01-13 22:12:53 --> Total execution time: 0.0138
INFO - 2017-01-13 22:13:08 --> Config Class Initialized
INFO - 2017-01-13 22:13:08 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:13:08 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:13:08 --> Utf8 Class Initialized
INFO - 2017-01-13 22:13:08 --> URI Class Initialized
INFO - 2017-01-13 22:13:08 --> Router Class Initialized
INFO - 2017-01-13 22:13:08 --> Output Class Initialized
INFO - 2017-01-13 22:13:08 --> Security Class Initialized
DEBUG - 2017-01-13 22:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:13:08 --> Input Class Initialized
INFO - 2017-01-13 22:13:08 --> Language Class Initialized
INFO - 2017-01-13 22:13:08 --> Loader Class Initialized
INFO - 2017-01-13 22:13:08 --> Database Driver Class Initialized
INFO - 2017-01-13 22:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:13:08 --> Controller Class Initialized
INFO - 2017-01-13 22:13:08 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:13:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:13:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:13:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:13:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:13:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:13:08 --> Final output sent to browser
DEBUG - 2017-01-13 22:13:08 --> Total execution time: 0.0140
INFO - 2017-01-13 22:13:09 --> Config Class Initialized
INFO - 2017-01-13 22:13:09 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:13:09 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:13:09 --> Utf8 Class Initialized
INFO - 2017-01-13 22:13:09 --> URI Class Initialized
INFO - 2017-01-13 22:13:09 --> Router Class Initialized
INFO - 2017-01-13 22:13:09 --> Output Class Initialized
INFO - 2017-01-13 22:13:09 --> Security Class Initialized
DEBUG - 2017-01-13 22:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:13:09 --> Input Class Initialized
INFO - 2017-01-13 22:13:09 --> Language Class Initialized
INFO - 2017-01-13 22:13:09 --> Loader Class Initialized
INFO - 2017-01-13 22:13:09 --> Database Driver Class Initialized
INFO - 2017-01-13 22:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:13:09 --> Controller Class Initialized
INFO - 2017-01-13 22:13:09 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:13:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:13:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:13:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:13:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:13:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:13:09 --> Final output sent to browser
DEBUG - 2017-01-13 22:13:09 --> Total execution time: 0.0128
INFO - 2017-01-13 22:13:48 --> Config Class Initialized
INFO - 2017-01-13 22:13:48 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:13:48 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:13:48 --> Utf8 Class Initialized
INFO - 2017-01-13 22:13:48 --> URI Class Initialized
INFO - 2017-01-13 22:13:48 --> Router Class Initialized
INFO - 2017-01-13 22:13:48 --> Output Class Initialized
INFO - 2017-01-13 22:13:48 --> Security Class Initialized
DEBUG - 2017-01-13 22:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:13:48 --> Input Class Initialized
INFO - 2017-01-13 22:13:48 --> Language Class Initialized
INFO - 2017-01-13 22:13:48 --> Loader Class Initialized
INFO - 2017-01-13 22:13:48 --> Database Driver Class Initialized
INFO - 2017-01-13 22:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:13:48 --> Controller Class Initialized
INFO - 2017-01-13 22:13:48 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:13:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:13:49 --> Config Class Initialized
INFO - 2017-01-13 22:13:49 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:13:49 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:13:49 --> Utf8 Class Initialized
INFO - 2017-01-13 22:13:49 --> URI Class Initialized
INFO - 2017-01-13 22:13:49 --> Router Class Initialized
INFO - 2017-01-13 22:13:49 --> Output Class Initialized
INFO - 2017-01-13 22:13:49 --> Security Class Initialized
DEBUG - 2017-01-13 22:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:13:49 --> Input Class Initialized
INFO - 2017-01-13 22:13:49 --> Language Class Initialized
INFO - 2017-01-13 22:13:49 --> Loader Class Initialized
INFO - 2017-01-13 22:13:49 --> Database Driver Class Initialized
INFO - 2017-01-13 22:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:13:49 --> Controller Class Initialized
INFO - 2017-01-13 22:13:49 --> Helper loaded: date_helper
DEBUG - 2017-01-13 22:13:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:13:49 --> Helper loaded: url_helper
INFO - 2017-01-13 22:13:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:13:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-13 22:13:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-13 22:13:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-13 22:13:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:13:49 --> Final output sent to browser
DEBUG - 2017-01-13 22:13:49 --> Total execution time: 0.2317
INFO - 2017-01-13 22:13:49 --> Config Class Initialized
INFO - 2017-01-13 22:13:49 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:13:49 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:13:49 --> Utf8 Class Initialized
INFO - 2017-01-13 22:13:49 --> URI Class Initialized
INFO - 2017-01-13 22:13:49 --> Router Class Initialized
INFO - 2017-01-13 22:13:49 --> Output Class Initialized
INFO - 2017-01-13 22:13:49 --> Security Class Initialized
DEBUG - 2017-01-13 22:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:13:49 --> Input Class Initialized
INFO - 2017-01-13 22:13:49 --> Language Class Initialized
INFO - 2017-01-13 22:13:49 --> Loader Class Initialized
INFO - 2017-01-13 22:13:49 --> Database Driver Class Initialized
INFO - 2017-01-13 22:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:13:49 --> Controller Class Initialized
INFO - 2017-01-13 22:13:49 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:13:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:13:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:13:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:13:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:13:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:13:49 --> Final output sent to browser
DEBUG - 2017-01-13 22:13:49 --> Total execution time: 0.0135
INFO - 2017-01-13 22:14:04 --> Config Class Initialized
INFO - 2017-01-13 22:14:04 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:04 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:04 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:04 --> URI Class Initialized
INFO - 2017-01-13 22:14:04 --> Router Class Initialized
INFO - 2017-01-13 22:14:04 --> Output Class Initialized
INFO - 2017-01-13 22:14:04 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:04 --> Input Class Initialized
INFO - 2017-01-13 22:14:04 --> Language Class Initialized
INFO - 2017-01-13 22:14:04 --> Loader Class Initialized
INFO - 2017-01-13 22:14:04 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:04 --> Controller Class Initialized
INFO - 2017-01-13 22:14:04 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:04 --> Helper loaded: form_helper
INFO - 2017-01-13 22:14:04 --> Form Validation Class Initialized
INFO - 2017-01-13 22:14:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 22:14:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-13 22:14:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 22:14:04 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:04 --> Total execution time: 0.1940
INFO - 2017-01-13 22:14:04 --> Config Class Initialized
INFO - 2017-01-13 22:14:04 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:04 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:04 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:04 --> URI Class Initialized
INFO - 2017-01-13 22:14:04 --> Router Class Initialized
INFO - 2017-01-13 22:14:04 --> Output Class Initialized
INFO - 2017-01-13 22:14:04 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:04 --> Input Class Initialized
INFO - 2017-01-13 22:14:04 --> Language Class Initialized
INFO - 2017-01-13 22:14:04 --> Loader Class Initialized
INFO - 2017-01-13 22:14:04 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:04 --> Controller Class Initialized
INFO - 2017-01-13 22:14:04 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:14:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:14:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:14:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:14:04 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:04 --> Total execution time: 0.0136
INFO - 2017-01-13 22:14:15 --> Config Class Initialized
INFO - 2017-01-13 22:14:15 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:15 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:15 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:15 --> URI Class Initialized
INFO - 2017-01-13 22:14:15 --> Router Class Initialized
INFO - 2017-01-13 22:14:15 --> Output Class Initialized
INFO - 2017-01-13 22:14:15 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:15 --> Input Class Initialized
INFO - 2017-01-13 22:14:15 --> Language Class Initialized
INFO - 2017-01-13 22:14:15 --> Loader Class Initialized
INFO - 2017-01-13 22:14:15 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:15 --> Controller Class Initialized
INFO - 2017-01-13 22:14:15 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:15 --> Helper loaded: form_helper
INFO - 2017-01-13 22:14:15 --> Form Validation Class Initialized
INFO - 2017-01-13 22:14:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-13 22:14:15 --> Config Class Initialized
INFO - 2017-01-13 22:14:15 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:15 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:15 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:15 --> URI Class Initialized
INFO - 2017-01-13 22:14:15 --> Router Class Initialized
INFO - 2017-01-13 22:14:15 --> Output Class Initialized
INFO - 2017-01-13 22:14:15 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:15 --> Input Class Initialized
INFO - 2017-01-13 22:14:15 --> Language Class Initialized
INFO - 2017-01-13 22:14:15 --> Loader Class Initialized
INFO - 2017-01-13 22:14:15 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:15 --> Controller Class Initialized
INFO - 2017-01-13 22:14:15 --> Helper loaded: date_helper
INFO - 2017-01-13 22:14:15 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:15 --> Helper loaded: form_helper
INFO - 2017-01-13 22:14:15 --> Form Validation Class Initialized
INFO - 2017-01-13 22:14:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 22:14:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 22:14:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-13 22:14:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-13 22:14:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 22:14:15 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:15 --> Total execution time: 0.1949
INFO - 2017-01-13 22:14:15 --> Config Class Initialized
INFO - 2017-01-13 22:14:15 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:15 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:15 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:15 --> URI Class Initialized
INFO - 2017-01-13 22:14:15 --> Router Class Initialized
INFO - 2017-01-13 22:14:15 --> Output Class Initialized
INFO - 2017-01-13 22:14:15 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:15 --> Input Class Initialized
INFO - 2017-01-13 22:14:15 --> Language Class Initialized
INFO - 2017-01-13 22:14:15 --> Loader Class Initialized
INFO - 2017-01-13 22:14:15 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:15 --> Controller Class Initialized
INFO - 2017-01-13 22:14:15 --> Helper loaded: date_helper
INFO - 2017-01-13 22:14:15 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:15 --> Helper loaded: form_helper
INFO - 2017-01-13 22:14:15 --> Form Validation Class Initialized
INFO - 2017-01-13 22:14:16 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:16 --> Total execution time: 0.0928
INFO - 2017-01-13 22:14:16 --> Config Class Initialized
INFO - 2017-01-13 22:14:16 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:16 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:16 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:16 --> URI Class Initialized
INFO - 2017-01-13 22:14:16 --> Router Class Initialized
INFO - 2017-01-13 22:14:16 --> Output Class Initialized
INFO - 2017-01-13 22:14:16 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:16 --> Input Class Initialized
INFO - 2017-01-13 22:14:16 --> Language Class Initialized
INFO - 2017-01-13 22:14:16 --> Loader Class Initialized
INFO - 2017-01-13 22:14:16 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:16 --> Controller Class Initialized
INFO - 2017-01-13 22:14:16 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:14:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:14:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:14:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:14:16 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:16 --> Total execution time: 0.0159
INFO - 2017-01-13 22:14:21 --> Config Class Initialized
INFO - 2017-01-13 22:14:21 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:21 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:21 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:21 --> URI Class Initialized
INFO - 2017-01-13 22:14:21 --> Router Class Initialized
INFO - 2017-01-13 22:14:21 --> Output Class Initialized
INFO - 2017-01-13 22:14:21 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:21 --> Input Class Initialized
INFO - 2017-01-13 22:14:21 --> Language Class Initialized
INFO - 2017-01-13 22:14:21 --> Loader Class Initialized
INFO - 2017-01-13 22:14:21 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:21 --> Controller Class Initialized
INFO - 2017-01-13 22:14:21 --> Helper loaded: date_helper
INFO - 2017-01-13 22:14:21 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:21 --> Helper loaded: form_helper
INFO - 2017-01-13 22:14:21 --> Form Validation Class Initialized
INFO - 2017-01-13 22:14:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 22:14:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 22:14:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-13 22:14:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-13 22:14:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 22:14:21 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:21 --> Total execution time: 0.0472
INFO - 2017-01-13 22:14:21 --> Config Class Initialized
INFO - 2017-01-13 22:14:21 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:21 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:21 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:21 --> URI Class Initialized
INFO - 2017-01-13 22:14:21 --> Router Class Initialized
INFO - 2017-01-13 22:14:21 --> Output Class Initialized
INFO - 2017-01-13 22:14:21 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:21 --> Input Class Initialized
INFO - 2017-01-13 22:14:21 --> Language Class Initialized
INFO - 2017-01-13 22:14:21 --> Loader Class Initialized
INFO - 2017-01-13 22:14:21 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:21 --> Controller Class Initialized
INFO - 2017-01-13 22:14:21 --> Helper loaded: date_helper
INFO - 2017-01-13 22:14:21 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:21 --> Helper loaded: form_helper
INFO - 2017-01-13 22:14:21 --> Form Validation Class Initialized
INFO - 2017-01-13 22:14:21 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:21 --> Total execution time: 0.0144
INFO - 2017-01-13 22:14:21 --> Config Class Initialized
INFO - 2017-01-13 22:14:21 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:21 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:21 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:21 --> URI Class Initialized
INFO - 2017-01-13 22:14:21 --> Router Class Initialized
INFO - 2017-01-13 22:14:21 --> Output Class Initialized
INFO - 2017-01-13 22:14:21 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:21 --> Input Class Initialized
INFO - 2017-01-13 22:14:21 --> Language Class Initialized
INFO - 2017-01-13 22:14:21 --> Loader Class Initialized
INFO - 2017-01-13 22:14:21 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:21 --> Controller Class Initialized
INFO - 2017-01-13 22:14:21 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:14:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:14:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:14:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:14:21 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:21 --> Total execution time: 0.0137
INFO - 2017-01-13 22:14:24 --> Config Class Initialized
INFO - 2017-01-13 22:14:24 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:24 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:24 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:24 --> URI Class Initialized
INFO - 2017-01-13 22:14:24 --> Router Class Initialized
INFO - 2017-01-13 22:14:24 --> Output Class Initialized
INFO - 2017-01-13 22:14:24 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:24 --> Input Class Initialized
INFO - 2017-01-13 22:14:24 --> Language Class Initialized
INFO - 2017-01-13 22:14:24 --> Loader Class Initialized
INFO - 2017-01-13 22:14:24 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:24 --> Controller Class Initialized
INFO - 2017-01-13 22:14:24 --> Helper loaded: date_helper
INFO - 2017-01-13 22:14:24 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:24 --> Helper loaded: form_helper
INFO - 2017-01-13 22:14:24 --> Form Validation Class Initialized
INFO - 2017-01-13 22:14:24 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:24 --> Total execution time: 0.0145
INFO - 2017-01-13 22:14:25 --> Config Class Initialized
INFO - 2017-01-13 22:14:25 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:25 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:25 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:25 --> URI Class Initialized
INFO - 2017-01-13 22:14:25 --> Router Class Initialized
INFO - 2017-01-13 22:14:25 --> Output Class Initialized
INFO - 2017-01-13 22:14:25 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:25 --> Input Class Initialized
INFO - 2017-01-13 22:14:25 --> Language Class Initialized
INFO - 2017-01-13 22:14:25 --> Loader Class Initialized
INFO - 2017-01-13 22:14:25 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:25 --> Controller Class Initialized
INFO - 2017-01-13 22:14:25 --> Helper loaded: date_helper
INFO - 2017-01-13 22:14:25 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:25 --> Helper loaded: form_helper
INFO - 2017-01-13 22:14:25 --> Form Validation Class Initialized
INFO - 2017-01-13 22:14:25 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:25 --> Total execution time: 0.0138
INFO - 2017-01-13 22:14:29 --> Config Class Initialized
INFO - 2017-01-13 22:14:29 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:29 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:29 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:29 --> URI Class Initialized
INFO - 2017-01-13 22:14:29 --> Router Class Initialized
INFO - 2017-01-13 22:14:29 --> Output Class Initialized
INFO - 2017-01-13 22:14:29 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:29 --> Input Class Initialized
INFO - 2017-01-13 22:14:29 --> Language Class Initialized
INFO - 2017-01-13 22:14:29 --> Loader Class Initialized
INFO - 2017-01-13 22:14:29 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:29 --> Controller Class Initialized
INFO - 2017-01-13 22:14:29 --> Helper loaded: date_helper
INFO - 2017-01-13 22:14:29 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:29 --> Helper loaded: form_helper
INFO - 2017-01-13 22:14:29 --> Form Validation Class Initialized
INFO - 2017-01-13 22:14:29 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:29 --> Total execution time: 0.0149
INFO - 2017-01-13 22:14:36 --> Config Class Initialized
INFO - 2017-01-13 22:14:36 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:36 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:36 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:36 --> URI Class Initialized
INFO - 2017-01-13 22:14:36 --> Router Class Initialized
INFO - 2017-01-13 22:14:36 --> Output Class Initialized
INFO - 2017-01-13 22:14:36 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:36 --> Input Class Initialized
INFO - 2017-01-13 22:14:36 --> Language Class Initialized
INFO - 2017-01-13 22:14:36 --> Loader Class Initialized
INFO - 2017-01-13 22:14:36 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:36 --> Controller Class Initialized
INFO - 2017-01-13 22:14:36 --> Helper loaded: date_helper
INFO - 2017-01-13 22:14:36 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:36 --> Helper loaded: form_helper
INFO - 2017-01-13 22:14:36 --> Form Validation Class Initialized
INFO - 2017-01-13 22:14:36 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:36 --> Total execution time: 0.0141
INFO - 2017-01-13 22:14:41 --> Config Class Initialized
INFO - 2017-01-13 22:14:41 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:41 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:41 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:41 --> URI Class Initialized
INFO - 2017-01-13 22:14:41 --> Router Class Initialized
INFO - 2017-01-13 22:14:41 --> Output Class Initialized
INFO - 2017-01-13 22:14:41 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:41 --> Input Class Initialized
INFO - 2017-01-13 22:14:41 --> Language Class Initialized
INFO - 2017-01-13 22:14:41 --> Loader Class Initialized
INFO - 2017-01-13 22:14:41 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:41 --> Controller Class Initialized
INFO - 2017-01-13 22:14:41 --> Helper loaded: date_helper
INFO - 2017-01-13 22:14:41 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:41 --> Helper loaded: form_helper
INFO - 2017-01-13 22:14:41 --> Form Validation Class Initialized
INFO - 2017-01-13 22:14:41 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:41 --> Total execution time: 0.0146
INFO - 2017-01-13 22:14:41 --> Config Class Initialized
INFO - 2017-01-13 22:14:41 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:41 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:41 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:41 --> URI Class Initialized
INFO - 2017-01-13 22:14:41 --> Router Class Initialized
INFO - 2017-01-13 22:14:41 --> Output Class Initialized
INFO - 2017-01-13 22:14:41 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:41 --> Input Class Initialized
INFO - 2017-01-13 22:14:41 --> Language Class Initialized
INFO - 2017-01-13 22:14:41 --> Loader Class Initialized
INFO - 2017-01-13 22:14:41 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:41 --> Controller Class Initialized
INFO - 2017-01-13 22:14:41 --> Helper loaded: date_helper
INFO - 2017-01-13 22:14:41 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:41 --> Helper loaded: form_helper
INFO - 2017-01-13 22:14:41 --> Form Validation Class Initialized
INFO - 2017-01-13 22:14:41 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:41 --> Total execution time: 0.0151
INFO - 2017-01-13 22:14:50 --> Config Class Initialized
INFO - 2017-01-13 22:14:50 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:50 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:50 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:50 --> URI Class Initialized
INFO - 2017-01-13 22:14:50 --> Router Class Initialized
INFO - 2017-01-13 22:14:50 --> Output Class Initialized
INFO - 2017-01-13 22:14:50 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:50 --> Input Class Initialized
INFO - 2017-01-13 22:14:50 --> Language Class Initialized
INFO - 2017-01-13 22:14:50 --> Loader Class Initialized
INFO - 2017-01-13 22:14:50 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:50 --> Controller Class Initialized
INFO - 2017-01-13 22:14:50 --> Helper loaded: date_helper
INFO - 2017-01-13 22:14:50 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:50 --> Helper loaded: form_helper
INFO - 2017-01-13 22:14:50 --> Form Validation Class Initialized
INFO - 2017-01-13 22:14:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 22:14:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 22:14:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-13 22:14:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-13 22:14:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 22:14:50 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:50 --> Total execution time: 0.0260
INFO - 2017-01-13 22:14:50 --> Config Class Initialized
INFO - 2017-01-13 22:14:50 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:50 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:50 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:50 --> URI Class Initialized
INFO - 2017-01-13 22:14:50 --> Router Class Initialized
INFO - 2017-01-13 22:14:50 --> Output Class Initialized
INFO - 2017-01-13 22:14:50 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:50 --> Input Class Initialized
INFO - 2017-01-13 22:14:50 --> Language Class Initialized
INFO - 2017-01-13 22:14:50 --> Loader Class Initialized
INFO - 2017-01-13 22:14:50 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:50 --> Controller Class Initialized
INFO - 2017-01-13 22:14:50 --> Helper loaded: date_helper
INFO - 2017-01-13 22:14:50 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:50 --> Helper loaded: form_helper
INFO - 2017-01-13 22:14:50 --> Form Validation Class Initialized
INFO - 2017-01-13 22:14:50 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:50 --> Total execution time: 0.0216
INFO - 2017-01-13 22:14:50 --> Config Class Initialized
INFO - 2017-01-13 22:14:50 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:50 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:50 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:50 --> URI Class Initialized
INFO - 2017-01-13 22:14:50 --> Router Class Initialized
INFO - 2017-01-13 22:14:50 --> Output Class Initialized
INFO - 2017-01-13 22:14:50 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:50 --> Input Class Initialized
INFO - 2017-01-13 22:14:50 --> Language Class Initialized
INFO - 2017-01-13 22:14:50 --> Loader Class Initialized
INFO - 2017-01-13 22:14:50 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:50 --> Controller Class Initialized
INFO - 2017-01-13 22:14:50 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:14:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:14:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:14:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:14:50 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:50 --> Total execution time: 0.0212
INFO - 2017-01-13 22:14:52 --> Config Class Initialized
INFO - 2017-01-13 22:14:52 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:52 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:52 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:52 --> URI Class Initialized
INFO - 2017-01-13 22:14:52 --> Router Class Initialized
INFO - 2017-01-13 22:14:52 --> Output Class Initialized
INFO - 2017-01-13 22:14:52 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:52 --> Input Class Initialized
INFO - 2017-01-13 22:14:52 --> Language Class Initialized
INFO - 2017-01-13 22:14:52 --> Loader Class Initialized
INFO - 2017-01-13 22:14:52 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:52 --> Controller Class Initialized
INFO - 2017-01-13 22:14:52 --> Helper loaded: date_helper
INFO - 2017-01-13 22:14:52 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:52 --> Helper loaded: form_helper
INFO - 2017-01-13 22:14:52 --> Form Validation Class Initialized
INFO - 2017-01-13 22:14:52 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:52 --> Total execution time: 0.0159
INFO - 2017-01-13 22:14:52 --> Config Class Initialized
INFO - 2017-01-13 22:14:52 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:52 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:52 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:52 --> URI Class Initialized
INFO - 2017-01-13 22:14:52 --> Router Class Initialized
INFO - 2017-01-13 22:14:52 --> Output Class Initialized
INFO - 2017-01-13 22:14:52 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:52 --> Input Class Initialized
INFO - 2017-01-13 22:14:52 --> Language Class Initialized
INFO - 2017-01-13 22:14:52 --> Loader Class Initialized
INFO - 2017-01-13 22:14:52 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:52 --> Controller Class Initialized
INFO - 2017-01-13 22:14:52 --> Helper loaded: date_helper
INFO - 2017-01-13 22:14:52 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:52 --> Helper loaded: form_helper
INFO - 2017-01-13 22:14:52 --> Form Validation Class Initialized
INFO - 2017-01-13 22:14:52 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:52 --> Total execution time: 0.0482
INFO - 2017-01-13 22:14:54 --> Config Class Initialized
INFO - 2017-01-13 22:14:54 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:54 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:54 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:54 --> URI Class Initialized
INFO - 2017-01-13 22:14:54 --> Router Class Initialized
INFO - 2017-01-13 22:14:54 --> Output Class Initialized
INFO - 2017-01-13 22:14:54 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:54 --> Input Class Initialized
INFO - 2017-01-13 22:14:54 --> Language Class Initialized
INFO - 2017-01-13 22:14:54 --> Loader Class Initialized
INFO - 2017-01-13 22:14:54 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:54 --> Controller Class Initialized
INFO - 2017-01-13 22:14:54 --> Helper loaded: date_helper
INFO - 2017-01-13 22:14:54 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:54 --> Helper loaded: form_helper
INFO - 2017-01-13 22:14:54 --> Form Validation Class Initialized
INFO - 2017-01-13 22:14:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 22:14:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 22:14:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pagos.php
INFO - 2017-01-13 22:14:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pagos.php
INFO - 2017-01-13 22:14:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 22:14:54 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:54 --> Total execution time: 0.0615
INFO - 2017-01-13 22:14:54 --> Config Class Initialized
INFO - 2017-01-13 22:14:54 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:54 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:54 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:54 --> URI Class Initialized
INFO - 2017-01-13 22:14:54 --> Router Class Initialized
INFO - 2017-01-13 22:14:54 --> Output Class Initialized
INFO - 2017-01-13 22:14:54 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:54 --> Input Class Initialized
INFO - 2017-01-13 22:14:54 --> Language Class Initialized
INFO - 2017-01-13 22:14:54 --> Loader Class Initialized
INFO - 2017-01-13 22:14:54 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:54 --> Controller Class Initialized
INFO - 2017-01-13 22:14:54 --> Helper loaded: date_helper
INFO - 2017-01-13 22:14:54 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:54 --> Helper loaded: form_helper
INFO - 2017-01-13 22:14:54 --> Form Validation Class Initialized
INFO - 2017-01-13 22:14:54 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:54 --> Total execution time: 0.0295
INFO - 2017-01-13 22:14:54 --> Config Class Initialized
INFO - 2017-01-13 22:14:54 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:54 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:54 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:54 --> URI Class Initialized
INFO - 2017-01-13 22:14:54 --> Router Class Initialized
INFO - 2017-01-13 22:14:54 --> Output Class Initialized
INFO - 2017-01-13 22:14:54 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:54 --> Input Class Initialized
INFO - 2017-01-13 22:14:54 --> Language Class Initialized
INFO - 2017-01-13 22:14:54 --> Loader Class Initialized
INFO - 2017-01-13 22:14:54 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:54 --> Controller Class Initialized
INFO - 2017-01-13 22:14:54 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:14:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:14:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:14:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:14:54 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:54 --> Total execution time: 0.0742
INFO - 2017-01-13 22:14:55 --> Config Class Initialized
INFO - 2017-01-13 22:14:55 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:55 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:55 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:55 --> URI Class Initialized
INFO - 2017-01-13 22:14:55 --> Router Class Initialized
INFO - 2017-01-13 22:14:55 --> Output Class Initialized
INFO - 2017-01-13 22:14:55 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:55 --> Input Class Initialized
INFO - 2017-01-13 22:14:55 --> Language Class Initialized
INFO - 2017-01-13 22:14:55 --> Loader Class Initialized
INFO - 2017-01-13 22:14:55 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:55 --> Controller Class Initialized
INFO - 2017-01-13 22:14:55 --> Helper loaded: date_helper
INFO - 2017-01-13 22:14:55 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:55 --> Helper loaded: form_helper
INFO - 2017-01-13 22:14:55 --> Form Validation Class Initialized
INFO - 2017-01-13 22:14:55 --> Config Class Initialized
INFO - 2017-01-13 22:14:55 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:55 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:55 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:55 --> URI Class Initialized
INFO - 2017-01-13 22:14:55 --> Router Class Initialized
INFO - 2017-01-13 22:14:55 --> Output Class Initialized
INFO - 2017-01-13 22:14:55 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:55 --> Input Class Initialized
INFO - 2017-01-13 22:14:55 --> Language Class Initialized
INFO - 2017-01-13 22:14:55 --> Loader Class Initialized
INFO - 2017-01-13 22:14:55 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:56 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:56 --> Total execution time: 0.0772
INFO - 2017-01-13 22:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:56 --> Controller Class Initialized
INFO - 2017-01-13 22:14:56 --> Helper loaded: date_helper
INFO - 2017-01-13 22:14:56 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:56 --> Helper loaded: form_helper
INFO - 2017-01-13 22:14:56 --> Form Validation Class Initialized
INFO - 2017-01-13 22:14:56 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:56 --> Total execution time: 0.1222
INFO - 2017-01-13 22:14:59 --> Config Class Initialized
INFO - 2017-01-13 22:14:59 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:59 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:59 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:59 --> URI Class Initialized
INFO - 2017-01-13 22:14:59 --> Router Class Initialized
INFO - 2017-01-13 22:14:59 --> Output Class Initialized
INFO - 2017-01-13 22:14:59 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:59 --> Input Class Initialized
INFO - 2017-01-13 22:14:59 --> Language Class Initialized
INFO - 2017-01-13 22:14:59 --> Loader Class Initialized
INFO - 2017-01-13 22:14:59 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:59 --> Controller Class Initialized
INFO - 2017-01-13 22:14:59 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:59 --> Config Class Initialized
INFO - 2017-01-13 22:14:59 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:59 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:59 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:59 --> URI Class Initialized
INFO - 2017-01-13 22:14:59 --> Router Class Initialized
INFO - 2017-01-13 22:14:59 --> Output Class Initialized
INFO - 2017-01-13 22:14:59 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:59 --> Input Class Initialized
INFO - 2017-01-13 22:14:59 --> Language Class Initialized
INFO - 2017-01-13 22:14:59 --> Loader Class Initialized
INFO - 2017-01-13 22:14:59 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:59 --> Controller Class Initialized
INFO - 2017-01-13 22:14:59 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:59 --> Helper loaded: form_helper
INFO - 2017-01-13 22:14:59 --> Form Validation Class Initialized
INFO - 2017-01-13 22:14:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 22:14:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-13 22:14:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 22:14:59 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:59 --> Total execution time: 0.0256
INFO - 2017-01-13 22:14:59 --> Config Class Initialized
INFO - 2017-01-13 22:14:59 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:14:59 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:14:59 --> Utf8 Class Initialized
INFO - 2017-01-13 22:14:59 --> URI Class Initialized
INFO - 2017-01-13 22:14:59 --> Router Class Initialized
INFO - 2017-01-13 22:14:59 --> Output Class Initialized
INFO - 2017-01-13 22:14:59 --> Security Class Initialized
DEBUG - 2017-01-13 22:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:14:59 --> Input Class Initialized
INFO - 2017-01-13 22:14:59 --> Language Class Initialized
INFO - 2017-01-13 22:14:59 --> Loader Class Initialized
INFO - 2017-01-13 22:14:59 --> Database Driver Class Initialized
INFO - 2017-01-13 22:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:14:59 --> Controller Class Initialized
INFO - 2017-01-13 22:14:59 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:14:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:14:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:14:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:14:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:14:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:14:59 --> Final output sent to browser
DEBUG - 2017-01-13 22:14:59 --> Total execution time: 0.0221
INFO - 2017-01-13 22:15:00 --> Config Class Initialized
INFO - 2017-01-13 22:15:00 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:15:00 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:15:00 --> Utf8 Class Initialized
INFO - 2017-01-13 22:15:00 --> URI Class Initialized
INFO - 2017-01-13 22:15:00 --> Router Class Initialized
INFO - 2017-01-13 22:15:00 --> Output Class Initialized
INFO - 2017-01-13 22:15:00 --> Security Class Initialized
DEBUG - 2017-01-13 22:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:15:00 --> Input Class Initialized
INFO - 2017-01-13 22:15:00 --> Language Class Initialized
INFO - 2017-01-13 22:15:00 --> Loader Class Initialized
INFO - 2017-01-13 22:15:00 --> Database Driver Class Initialized
INFO - 2017-01-13 22:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:15:00 --> Controller Class Initialized
INFO - 2017-01-13 22:15:00 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:15:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:15:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:15:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:15:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:15:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:15:00 --> Final output sent to browser
DEBUG - 2017-01-13 22:15:00 --> Total execution time: 0.0138
INFO - 2017-01-13 22:15:03 --> Config Class Initialized
INFO - 2017-01-13 22:15:03 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:15:03 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:15:03 --> Utf8 Class Initialized
INFO - 2017-01-13 22:15:03 --> URI Class Initialized
DEBUG - 2017-01-13 22:15:03 --> No URI present. Default controller set.
INFO - 2017-01-13 22:15:03 --> Router Class Initialized
INFO - 2017-01-13 22:15:03 --> Output Class Initialized
INFO - 2017-01-13 22:15:03 --> Security Class Initialized
DEBUG - 2017-01-13 22:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:15:03 --> Input Class Initialized
INFO - 2017-01-13 22:15:03 --> Language Class Initialized
INFO - 2017-01-13 22:15:03 --> Loader Class Initialized
INFO - 2017-01-13 22:15:03 --> Database Driver Class Initialized
INFO - 2017-01-13 22:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:15:03 --> Controller Class Initialized
INFO - 2017-01-13 22:15:03 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:15:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:15:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:15:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:15:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:15:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:15:03 --> Final output sent to browser
DEBUG - 2017-01-13 22:15:03 --> Total execution time: 0.0137
INFO - 2017-01-13 22:15:04 --> Config Class Initialized
INFO - 2017-01-13 22:15:04 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:15:04 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:15:04 --> Utf8 Class Initialized
INFO - 2017-01-13 22:15:04 --> URI Class Initialized
INFO - 2017-01-13 22:15:04 --> Router Class Initialized
INFO - 2017-01-13 22:15:04 --> Output Class Initialized
INFO - 2017-01-13 22:15:04 --> Security Class Initialized
DEBUG - 2017-01-13 22:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:15:04 --> Input Class Initialized
INFO - 2017-01-13 22:15:04 --> Language Class Initialized
INFO - 2017-01-13 22:15:04 --> Loader Class Initialized
INFO - 2017-01-13 22:15:04 --> Database Driver Class Initialized
INFO - 2017-01-13 22:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:15:04 --> Controller Class Initialized
INFO - 2017-01-13 22:15:04 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:15:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:15:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:15:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:15:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:15:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:15:04 --> Final output sent to browser
DEBUG - 2017-01-13 22:15:04 --> Total execution time: 0.0142
INFO - 2017-01-13 22:15:13 --> Config Class Initialized
INFO - 2017-01-13 22:15:13 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:15:13 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:15:13 --> Utf8 Class Initialized
INFO - 2017-01-13 22:15:13 --> URI Class Initialized
INFO - 2017-01-13 22:15:13 --> Router Class Initialized
INFO - 2017-01-13 22:15:13 --> Output Class Initialized
INFO - 2017-01-13 22:15:13 --> Security Class Initialized
DEBUG - 2017-01-13 22:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:15:13 --> Input Class Initialized
INFO - 2017-01-13 22:15:13 --> Language Class Initialized
INFO - 2017-01-13 22:15:13 --> Loader Class Initialized
INFO - 2017-01-13 22:15:13 --> Database Driver Class Initialized
INFO - 2017-01-13 22:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:15:13 --> Controller Class Initialized
INFO - 2017-01-13 22:15:13 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:15:13 --> Config Class Initialized
INFO - 2017-01-13 22:15:13 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:15:13 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:15:13 --> Utf8 Class Initialized
INFO - 2017-01-13 22:15:13 --> URI Class Initialized
INFO - 2017-01-13 22:15:13 --> Router Class Initialized
INFO - 2017-01-13 22:15:13 --> Output Class Initialized
INFO - 2017-01-13 22:15:13 --> Security Class Initialized
DEBUG - 2017-01-13 22:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:15:13 --> Input Class Initialized
INFO - 2017-01-13 22:15:13 --> Language Class Initialized
INFO - 2017-01-13 22:15:13 --> Loader Class Initialized
INFO - 2017-01-13 22:15:13 --> Database Driver Class Initialized
INFO - 2017-01-13 22:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:15:13 --> Controller Class Initialized
INFO - 2017-01-13 22:15:13 --> Helper loaded: date_helper
DEBUG - 2017-01-13 22:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:15:13 --> Helper loaded: url_helper
INFO - 2017-01-13 22:15:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:15:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 22:15:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-13 22:15:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-13 22:15:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:15:13 --> Final output sent to browser
DEBUG - 2017-01-13 22:15:13 --> Total execution time: 0.0242
INFO - 2017-01-13 22:15:38 --> Config Class Initialized
INFO - 2017-01-13 22:15:38 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:15:38 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:15:38 --> Utf8 Class Initialized
INFO - 2017-01-13 22:15:38 --> URI Class Initialized
INFO - 2017-01-13 22:15:38 --> Router Class Initialized
INFO - 2017-01-13 22:15:38 --> Output Class Initialized
INFO - 2017-01-13 22:15:38 --> Security Class Initialized
DEBUG - 2017-01-13 22:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:15:38 --> Input Class Initialized
INFO - 2017-01-13 22:15:38 --> Language Class Initialized
INFO - 2017-01-13 22:15:38 --> Loader Class Initialized
INFO - 2017-01-13 22:15:38 --> Database Driver Class Initialized
INFO - 2017-01-13 22:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:15:38 --> Controller Class Initialized
INFO - 2017-01-13 22:15:38 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:15:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:15:38 --> Final output sent to browser
DEBUG - 2017-01-13 22:15:38 --> Total execution time: 0.0142
INFO - 2017-01-13 22:15:52 --> Config Class Initialized
INFO - 2017-01-13 22:15:52 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:15:52 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:15:52 --> Utf8 Class Initialized
INFO - 2017-01-13 22:15:52 --> URI Class Initialized
INFO - 2017-01-13 22:15:52 --> Router Class Initialized
INFO - 2017-01-13 22:15:52 --> Output Class Initialized
INFO - 2017-01-13 22:15:52 --> Security Class Initialized
DEBUG - 2017-01-13 22:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:15:52 --> Input Class Initialized
INFO - 2017-01-13 22:15:52 --> Language Class Initialized
INFO - 2017-01-13 22:15:52 --> Loader Class Initialized
INFO - 2017-01-13 22:15:52 --> Database Driver Class Initialized
INFO - 2017-01-13 22:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:15:52 --> Controller Class Initialized
INFO - 2017-01-13 22:15:52 --> Helper loaded: date_helper
DEBUG - 2017-01-13 22:15:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:15:52 --> Helper loaded: url_helper
INFO - 2017-01-13 22:15:52 --> Helper loaded: download_helper
INFO - 2017-01-13 22:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 22:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-13 22:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-13 22:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:15:52 --> Final output sent to browser
DEBUG - 2017-01-13 22:15:52 --> Total execution time: 0.1405
INFO - 2017-01-13 22:15:52 --> Config Class Initialized
INFO - 2017-01-13 22:15:52 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:15:52 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:15:52 --> Utf8 Class Initialized
INFO - 2017-01-13 22:15:52 --> URI Class Initialized
INFO - 2017-01-13 22:15:52 --> Router Class Initialized
INFO - 2017-01-13 22:15:52 --> Output Class Initialized
INFO - 2017-01-13 22:15:52 --> Security Class Initialized
DEBUG - 2017-01-13 22:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:15:52 --> Input Class Initialized
INFO - 2017-01-13 22:15:52 --> Language Class Initialized
INFO - 2017-01-13 22:15:52 --> Loader Class Initialized
INFO - 2017-01-13 22:15:52 --> Database Driver Class Initialized
INFO - 2017-01-13 22:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:15:52 --> Controller Class Initialized
INFO - 2017-01-13 22:15:52 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:15:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:15:52 --> Final output sent to browser
DEBUG - 2017-01-13 22:15:52 --> Total execution time: 0.0527
INFO - 2017-01-13 22:16:08 --> Config Class Initialized
INFO - 2017-01-13 22:16:08 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:16:08 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:16:08 --> Utf8 Class Initialized
INFO - 2017-01-13 22:16:08 --> URI Class Initialized
INFO - 2017-01-13 22:16:08 --> Router Class Initialized
INFO - 2017-01-13 22:16:08 --> Output Class Initialized
INFO - 2017-01-13 22:16:08 --> Security Class Initialized
DEBUG - 2017-01-13 22:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:16:08 --> Input Class Initialized
INFO - 2017-01-13 22:16:08 --> Language Class Initialized
INFO - 2017-01-13 22:16:08 --> Loader Class Initialized
INFO - 2017-01-13 22:16:08 --> Database Driver Class Initialized
INFO - 2017-01-13 22:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:16:08 --> Controller Class Initialized
INFO - 2017-01-13 22:16:08 --> Helper loaded: date_helper
DEBUG - 2017-01-13 22:16:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:16:08 --> Helper loaded: url_helper
INFO - 2017-01-13 22:16:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:16:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 22:16:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-13 22:16:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-13 22:16:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:16:08 --> Final output sent to browser
DEBUG - 2017-01-13 22:16:08 --> Total execution time: 0.0151
INFO - 2017-01-13 22:16:08 --> Config Class Initialized
INFO - 2017-01-13 22:16:08 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:16:08 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:16:08 --> Utf8 Class Initialized
INFO - 2017-01-13 22:16:08 --> URI Class Initialized
INFO - 2017-01-13 22:16:08 --> Router Class Initialized
INFO - 2017-01-13 22:16:08 --> Output Class Initialized
INFO - 2017-01-13 22:16:08 --> Security Class Initialized
DEBUG - 2017-01-13 22:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:16:08 --> Input Class Initialized
INFO - 2017-01-13 22:16:08 --> Language Class Initialized
INFO - 2017-01-13 22:16:08 --> Loader Class Initialized
INFO - 2017-01-13 22:16:08 --> Database Driver Class Initialized
INFO - 2017-01-13 22:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:16:08 --> Controller Class Initialized
INFO - 2017-01-13 22:16:08 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:16:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:16:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:16:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:16:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:16:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:16:08 --> Final output sent to browser
DEBUG - 2017-01-13 22:16:08 --> Total execution time: 0.0147
INFO - 2017-01-13 22:16:17 --> Config Class Initialized
INFO - 2017-01-13 22:16:17 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:16:17 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:16:17 --> Utf8 Class Initialized
INFO - 2017-01-13 22:16:17 --> URI Class Initialized
INFO - 2017-01-13 22:16:17 --> Router Class Initialized
INFO - 2017-01-13 22:16:17 --> Output Class Initialized
INFO - 2017-01-13 22:16:17 --> Security Class Initialized
DEBUG - 2017-01-13 22:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:16:17 --> Input Class Initialized
INFO - 2017-01-13 22:16:17 --> Language Class Initialized
INFO - 2017-01-13 22:16:17 --> Loader Class Initialized
INFO - 2017-01-13 22:16:17 --> Database Driver Class Initialized
INFO - 2017-01-13 22:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:16:17 --> Controller Class Initialized
INFO - 2017-01-13 22:16:17 --> Helper loaded: date_helper
DEBUG - 2017-01-13 22:16:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:16:17 --> Helper loaded: url_helper
INFO - 2017-01-13 22:16:17 --> Helper loaded: download_helper
INFO - 2017-01-13 22:16:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:16:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 22:16:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-13 22:16:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-13 22:16:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:16:17 --> Final output sent to browser
DEBUG - 2017-01-13 22:16:17 --> Total execution time: 0.0183
INFO - 2017-01-13 22:16:17 --> Config Class Initialized
INFO - 2017-01-13 22:16:17 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:16:17 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:16:17 --> Utf8 Class Initialized
INFO - 2017-01-13 22:16:17 --> URI Class Initialized
INFO - 2017-01-13 22:16:17 --> Router Class Initialized
INFO - 2017-01-13 22:16:17 --> Output Class Initialized
INFO - 2017-01-13 22:16:17 --> Security Class Initialized
DEBUG - 2017-01-13 22:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:16:17 --> Input Class Initialized
INFO - 2017-01-13 22:16:17 --> Language Class Initialized
INFO - 2017-01-13 22:16:17 --> Loader Class Initialized
INFO - 2017-01-13 22:16:17 --> Database Driver Class Initialized
INFO - 2017-01-13 22:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:16:17 --> Controller Class Initialized
INFO - 2017-01-13 22:16:17 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:16:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:16:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:16:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:16:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:16:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:16:17 --> Final output sent to browser
DEBUG - 2017-01-13 22:16:17 --> Total execution time: 0.0138
INFO - 2017-01-13 22:16:22 --> Config Class Initialized
INFO - 2017-01-13 22:16:22 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:16:22 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:16:22 --> Utf8 Class Initialized
INFO - 2017-01-13 22:16:22 --> URI Class Initialized
DEBUG - 2017-01-13 22:16:22 --> No URI present. Default controller set.
INFO - 2017-01-13 22:16:22 --> Router Class Initialized
INFO - 2017-01-13 22:16:22 --> Output Class Initialized
INFO - 2017-01-13 22:16:22 --> Security Class Initialized
DEBUG - 2017-01-13 22:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:16:22 --> Input Class Initialized
INFO - 2017-01-13 22:16:22 --> Language Class Initialized
INFO - 2017-01-13 22:16:22 --> Loader Class Initialized
INFO - 2017-01-13 22:16:22 --> Database Driver Class Initialized
INFO - 2017-01-13 22:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:16:22 --> Controller Class Initialized
INFO - 2017-01-13 22:16:22 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:16:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:16:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:16:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:16:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:16:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:16:22 --> Final output sent to browser
DEBUG - 2017-01-13 22:16:22 --> Total execution time: 0.0137
INFO - 2017-01-13 22:16:25 --> Config Class Initialized
INFO - 2017-01-13 22:16:25 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:16:25 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:16:25 --> Utf8 Class Initialized
INFO - 2017-01-13 22:16:25 --> URI Class Initialized
INFO - 2017-01-13 22:16:25 --> Router Class Initialized
INFO - 2017-01-13 22:16:25 --> Output Class Initialized
INFO - 2017-01-13 22:16:25 --> Security Class Initialized
DEBUG - 2017-01-13 22:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:16:25 --> Input Class Initialized
INFO - 2017-01-13 22:16:25 --> Language Class Initialized
INFO - 2017-01-13 22:16:25 --> Loader Class Initialized
INFO - 2017-01-13 22:16:25 --> Database Driver Class Initialized
INFO - 2017-01-13 22:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:16:25 --> Controller Class Initialized
INFO - 2017-01-13 22:16:25 --> Helper loaded: date_helper
DEBUG - 2017-01-13 22:16:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:16:25 --> Helper loaded: url_helper
INFO - 2017-01-13 22:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 22:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-13 22:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-13 22:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:16:25 --> Final output sent to browser
DEBUG - 2017-01-13 22:16:25 --> Total execution time: 0.0381
INFO - 2017-01-13 22:16:25 --> Config Class Initialized
INFO - 2017-01-13 22:16:25 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:16:25 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:16:25 --> Utf8 Class Initialized
INFO - 2017-01-13 22:16:25 --> URI Class Initialized
INFO - 2017-01-13 22:16:25 --> Router Class Initialized
INFO - 2017-01-13 22:16:25 --> Output Class Initialized
INFO - 2017-01-13 22:16:25 --> Security Class Initialized
DEBUG - 2017-01-13 22:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:16:25 --> Input Class Initialized
INFO - 2017-01-13 22:16:25 --> Language Class Initialized
INFO - 2017-01-13 22:16:25 --> Loader Class Initialized
INFO - 2017-01-13 22:16:25 --> Database Driver Class Initialized
INFO - 2017-01-13 22:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:16:25 --> Controller Class Initialized
INFO - 2017-01-13 22:16:25 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:16:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:16:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:16:25 --> Final output sent to browser
DEBUG - 2017-01-13 22:16:25 --> Total execution time: 0.0133
INFO - 2017-01-13 22:16:28 --> Config Class Initialized
INFO - 2017-01-13 22:16:28 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:16:28 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:16:28 --> Utf8 Class Initialized
INFO - 2017-01-13 22:16:28 --> URI Class Initialized
INFO - 2017-01-13 22:16:28 --> Router Class Initialized
INFO - 2017-01-13 22:16:28 --> Output Class Initialized
INFO - 2017-01-13 22:16:28 --> Security Class Initialized
DEBUG - 2017-01-13 22:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:16:28 --> Input Class Initialized
INFO - 2017-01-13 22:16:28 --> Language Class Initialized
INFO - 2017-01-13 22:16:28 --> Loader Class Initialized
INFO - 2017-01-13 22:16:28 --> Database Driver Class Initialized
INFO - 2017-01-13 22:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:16:28 --> Controller Class Initialized
INFO - 2017-01-13 22:16:28 --> Upload Class Initialized
INFO - 2017-01-13 22:16:29 --> Helper loaded: date_helper
DEBUG - 2017-01-13 22:16:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:16:29 --> Helper loaded: url_helper
INFO - 2017-01-13 22:16:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:16:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 22:16:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-01-13 22:16:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-01-13 22:16:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-13 22:16:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:16:29 --> Final output sent to browser
DEBUG - 2017-01-13 22:16:29 --> Total execution time: 0.0839
INFO - 2017-01-13 22:16:29 --> Config Class Initialized
INFO - 2017-01-13 22:16:29 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:16:29 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:16:29 --> Utf8 Class Initialized
INFO - 2017-01-13 22:16:29 --> URI Class Initialized
INFO - 2017-01-13 22:16:29 --> Router Class Initialized
INFO - 2017-01-13 22:16:29 --> Output Class Initialized
INFO - 2017-01-13 22:16:29 --> Security Class Initialized
DEBUG - 2017-01-13 22:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:16:29 --> Input Class Initialized
INFO - 2017-01-13 22:16:29 --> Language Class Initialized
INFO - 2017-01-13 22:16:29 --> Loader Class Initialized
INFO - 2017-01-13 22:16:29 --> Database Driver Class Initialized
INFO - 2017-01-13 22:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:16:29 --> Controller Class Initialized
INFO - 2017-01-13 22:16:29 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:16:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:16:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:16:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:16:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:16:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:16:29 --> Final output sent to browser
DEBUG - 2017-01-13 22:16:29 --> Total execution time: 0.0146
INFO - 2017-01-13 22:16:32 --> Config Class Initialized
INFO - 2017-01-13 22:16:32 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:16:32 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:16:32 --> Utf8 Class Initialized
INFO - 2017-01-13 22:16:32 --> URI Class Initialized
INFO - 2017-01-13 22:16:32 --> Router Class Initialized
INFO - 2017-01-13 22:16:32 --> Output Class Initialized
INFO - 2017-01-13 22:16:32 --> Security Class Initialized
DEBUG - 2017-01-13 22:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:16:32 --> Input Class Initialized
INFO - 2017-01-13 22:16:32 --> Language Class Initialized
INFO - 2017-01-13 22:16:32 --> Loader Class Initialized
INFO - 2017-01-13 22:16:32 --> Database Driver Class Initialized
INFO - 2017-01-13 22:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:16:32 --> Controller Class Initialized
INFO - 2017-01-13 22:16:32 --> Helper loaded: date_helper
DEBUG - 2017-01-13 22:16:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:16:32 --> Helper loaded: url_helper
INFO - 2017-01-13 22:16:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:16:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-13 22:16:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 22:16:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-13 22:16:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-13 22:16:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:16:32 --> Final output sent to browser
DEBUG - 2017-01-13 22:16:32 --> Total execution time: 0.0788
INFO - 2017-01-13 22:16:32 --> Config Class Initialized
INFO - 2017-01-13 22:16:32 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:16:32 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:16:32 --> Utf8 Class Initialized
INFO - 2017-01-13 22:16:32 --> URI Class Initialized
INFO - 2017-01-13 22:16:32 --> Router Class Initialized
INFO - 2017-01-13 22:16:32 --> Output Class Initialized
INFO - 2017-01-13 22:16:32 --> Security Class Initialized
DEBUG - 2017-01-13 22:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:16:32 --> Input Class Initialized
INFO - 2017-01-13 22:16:32 --> Language Class Initialized
INFO - 2017-01-13 22:16:32 --> Loader Class Initialized
INFO - 2017-01-13 22:16:32 --> Database Driver Class Initialized
INFO - 2017-01-13 22:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:16:32 --> Controller Class Initialized
INFO - 2017-01-13 22:16:32 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:16:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:16:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:16:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:16:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:16:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:16:32 --> Final output sent to browser
DEBUG - 2017-01-13 22:16:32 --> Total execution time: 0.0149
INFO - 2017-01-13 22:16:36 --> Config Class Initialized
INFO - 2017-01-13 22:16:36 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:16:36 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:16:36 --> Utf8 Class Initialized
INFO - 2017-01-13 22:16:36 --> URI Class Initialized
INFO - 2017-01-13 22:16:36 --> Router Class Initialized
INFO - 2017-01-13 22:16:36 --> Output Class Initialized
INFO - 2017-01-13 22:16:36 --> Security Class Initialized
DEBUG - 2017-01-13 22:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:16:36 --> Input Class Initialized
INFO - 2017-01-13 22:16:36 --> Language Class Initialized
INFO - 2017-01-13 22:16:36 --> Loader Class Initialized
INFO - 2017-01-13 22:16:36 --> Database Driver Class Initialized
INFO - 2017-01-13 22:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:16:36 --> Controller Class Initialized
INFO - 2017-01-13 22:16:36 --> Helper loaded: date_helper
DEBUG - 2017-01-13 22:16:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:16:36 --> Helper loaded: url_helper
INFO - 2017-01-13 22:16:36 --> Helper loaded: download_helper
INFO - 2017-01-13 22:16:41 --> Config Class Initialized
INFO - 2017-01-13 22:16:41 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:16:41 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:16:41 --> Utf8 Class Initialized
INFO - 2017-01-13 22:16:41 --> URI Class Initialized
INFO - 2017-01-13 22:16:41 --> Router Class Initialized
INFO - 2017-01-13 22:16:41 --> Output Class Initialized
INFO - 2017-01-13 22:16:41 --> Security Class Initialized
DEBUG - 2017-01-13 22:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:16:41 --> Input Class Initialized
INFO - 2017-01-13 22:16:41 --> Language Class Initialized
INFO - 2017-01-13 22:16:41 --> Loader Class Initialized
INFO - 2017-01-13 22:16:41 --> Database Driver Class Initialized
INFO - 2017-01-13 22:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:16:41 --> Controller Class Initialized
INFO - 2017-01-13 22:16:41 --> Helper loaded: date_helper
DEBUG - 2017-01-13 22:16:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:16:41 --> Helper loaded: url_helper
INFO - 2017-01-13 22:16:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:16:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 22:16:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-13 22:16:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-13 22:16:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:16:41 --> Final output sent to browser
DEBUG - 2017-01-13 22:16:41 --> Total execution time: 0.0144
INFO - 2017-01-13 22:16:41 --> Config Class Initialized
INFO - 2017-01-13 22:16:41 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:16:41 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:16:41 --> Utf8 Class Initialized
INFO - 2017-01-13 22:16:41 --> URI Class Initialized
INFO - 2017-01-13 22:16:41 --> Router Class Initialized
INFO - 2017-01-13 22:16:41 --> Output Class Initialized
INFO - 2017-01-13 22:16:41 --> Security Class Initialized
DEBUG - 2017-01-13 22:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:16:41 --> Input Class Initialized
INFO - 2017-01-13 22:16:41 --> Language Class Initialized
INFO - 2017-01-13 22:16:41 --> Loader Class Initialized
INFO - 2017-01-13 22:16:41 --> Database Driver Class Initialized
INFO - 2017-01-13 22:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:16:41 --> Controller Class Initialized
INFO - 2017-01-13 22:16:41 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:16:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:16:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:16:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:16:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:16:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:16:41 --> Final output sent to browser
DEBUG - 2017-01-13 22:16:41 --> Total execution time: 0.0135
INFO - 2017-01-13 22:16:42 --> Config Class Initialized
INFO - 2017-01-13 22:16:42 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:16:42 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:16:42 --> Utf8 Class Initialized
INFO - 2017-01-13 22:16:42 --> URI Class Initialized
INFO - 2017-01-13 22:16:42 --> Router Class Initialized
INFO - 2017-01-13 22:16:42 --> Output Class Initialized
INFO - 2017-01-13 22:16:42 --> Security Class Initialized
DEBUG - 2017-01-13 22:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:16:42 --> Input Class Initialized
INFO - 2017-01-13 22:16:42 --> Language Class Initialized
INFO - 2017-01-13 22:16:42 --> Loader Class Initialized
INFO - 2017-01-13 22:16:42 --> Database Driver Class Initialized
INFO - 2017-01-13 22:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:16:42 --> Controller Class Initialized
INFO - 2017-01-13 22:16:42 --> Helper loaded: date_helper
DEBUG - 2017-01-13 22:16:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:16:42 --> Helper loaded: url_helper
INFO - 2017-01-13 22:16:42 --> Helper loaded: download_helper
INFO - 2017-01-13 22:16:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:16:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 22:16:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-13 22:16:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-13 22:16:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:16:42 --> Final output sent to browser
DEBUG - 2017-01-13 22:16:42 --> Total execution time: 0.0204
INFO - 2017-01-13 22:16:43 --> Config Class Initialized
INFO - 2017-01-13 22:16:43 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:16:43 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:16:43 --> Utf8 Class Initialized
INFO - 2017-01-13 22:16:43 --> URI Class Initialized
INFO - 2017-01-13 22:16:43 --> Router Class Initialized
INFO - 2017-01-13 22:16:43 --> Output Class Initialized
INFO - 2017-01-13 22:16:43 --> Security Class Initialized
DEBUG - 2017-01-13 22:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:16:43 --> Input Class Initialized
INFO - 2017-01-13 22:16:43 --> Language Class Initialized
INFO - 2017-01-13 22:16:43 --> Loader Class Initialized
INFO - 2017-01-13 22:16:43 --> Database Driver Class Initialized
INFO - 2017-01-13 22:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:16:43 --> Controller Class Initialized
INFO - 2017-01-13 22:16:43 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:16:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:16:43 --> Final output sent to browser
DEBUG - 2017-01-13 22:16:43 --> Total execution time: 0.0135
INFO - 2017-01-13 22:16:45 --> Config Class Initialized
INFO - 2017-01-13 22:16:45 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:16:45 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:16:45 --> Utf8 Class Initialized
INFO - 2017-01-13 22:16:45 --> URI Class Initialized
INFO - 2017-01-13 22:16:45 --> Router Class Initialized
INFO - 2017-01-13 22:16:45 --> Output Class Initialized
INFO - 2017-01-13 22:16:45 --> Security Class Initialized
DEBUG - 2017-01-13 22:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:16:45 --> Input Class Initialized
INFO - 2017-01-13 22:16:45 --> Language Class Initialized
INFO - 2017-01-13 22:16:45 --> Loader Class Initialized
INFO - 2017-01-13 22:16:45 --> Database Driver Class Initialized
INFO - 2017-01-13 22:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:16:45 --> Controller Class Initialized
INFO - 2017-01-13 22:16:45 --> Helper loaded: date_helper
DEBUG - 2017-01-13 22:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:16:45 --> Helper loaded: url_helper
INFO - 2017-01-13 22:16:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:16:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 22:16:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-13 22:16:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-13 22:16:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:16:45 --> Final output sent to browser
DEBUG - 2017-01-13 22:16:45 --> Total execution time: 0.0142
INFO - 2017-01-13 22:16:45 --> Config Class Initialized
INFO - 2017-01-13 22:16:45 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:16:45 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:16:45 --> Utf8 Class Initialized
INFO - 2017-01-13 22:16:45 --> URI Class Initialized
INFO - 2017-01-13 22:16:45 --> Router Class Initialized
INFO - 2017-01-13 22:16:45 --> Output Class Initialized
INFO - 2017-01-13 22:16:45 --> Security Class Initialized
DEBUG - 2017-01-13 22:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:16:45 --> Input Class Initialized
INFO - 2017-01-13 22:16:45 --> Language Class Initialized
INFO - 2017-01-13 22:16:45 --> Loader Class Initialized
INFO - 2017-01-13 22:16:45 --> Database Driver Class Initialized
INFO - 2017-01-13 22:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:16:45 --> Controller Class Initialized
INFO - 2017-01-13 22:16:45 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:16:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:16:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:16:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:16:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:16:45 --> Final output sent to browser
DEBUG - 2017-01-13 22:16:45 --> Total execution time: 0.0151
INFO - 2017-01-13 22:17:00 --> Config Class Initialized
INFO - 2017-01-13 22:17:00 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:17:00 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:17:00 --> Utf8 Class Initialized
INFO - 2017-01-13 22:17:00 --> URI Class Initialized
INFO - 2017-01-13 22:17:00 --> Router Class Initialized
INFO - 2017-01-13 22:17:00 --> Output Class Initialized
INFO - 2017-01-13 22:17:00 --> Security Class Initialized
DEBUG - 2017-01-13 22:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:17:00 --> Input Class Initialized
INFO - 2017-01-13 22:17:00 --> Language Class Initialized
INFO - 2017-01-13 22:17:00 --> Loader Class Initialized
INFO - 2017-01-13 22:17:00 --> Database Driver Class Initialized
INFO - 2017-01-13 22:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:17:00 --> Controller Class Initialized
INFO - 2017-01-13 22:17:00 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:17:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:17:00 --> Config Class Initialized
INFO - 2017-01-13 22:17:00 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:17:00 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:17:00 --> Utf8 Class Initialized
INFO - 2017-01-13 22:17:00 --> URI Class Initialized
DEBUG - 2017-01-13 22:17:00 --> No URI present. Default controller set.
INFO - 2017-01-13 22:17:00 --> Router Class Initialized
INFO - 2017-01-13 22:17:00 --> Output Class Initialized
INFO - 2017-01-13 22:17:00 --> Security Class Initialized
DEBUG - 2017-01-13 22:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:17:00 --> Input Class Initialized
INFO - 2017-01-13 22:17:00 --> Language Class Initialized
INFO - 2017-01-13 22:17:00 --> Loader Class Initialized
INFO - 2017-01-13 22:17:00 --> Database Driver Class Initialized
INFO - 2017-01-13 22:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:17:00 --> Controller Class Initialized
INFO - 2017-01-13 22:17:00 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:17:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:17:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:17:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:17:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:17:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:17:00 --> Final output sent to browser
DEBUG - 2017-01-13 22:17:00 --> Total execution time: 0.0134
INFO - 2017-01-13 22:17:00 --> Config Class Initialized
INFO - 2017-01-13 22:17:00 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:17:00 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:17:00 --> Utf8 Class Initialized
INFO - 2017-01-13 22:17:00 --> URI Class Initialized
INFO - 2017-01-13 22:17:00 --> Router Class Initialized
INFO - 2017-01-13 22:17:00 --> Output Class Initialized
INFO - 2017-01-13 22:17:00 --> Security Class Initialized
DEBUG - 2017-01-13 22:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:17:00 --> Input Class Initialized
INFO - 2017-01-13 22:17:00 --> Language Class Initialized
INFO - 2017-01-13 22:17:00 --> Loader Class Initialized
INFO - 2017-01-13 22:17:00 --> Database Driver Class Initialized
INFO - 2017-01-13 22:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:17:00 --> Controller Class Initialized
INFO - 2017-01-13 22:17:00 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:17:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:17:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:17:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:17:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:17:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:17:00 --> Final output sent to browser
DEBUG - 2017-01-13 22:17:00 --> Total execution time: 0.0136
INFO - 2017-01-13 22:17:01 --> Config Class Initialized
INFO - 2017-01-13 22:17:01 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:17:01 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:17:01 --> Utf8 Class Initialized
INFO - 2017-01-13 22:17:01 --> URI Class Initialized
INFO - 2017-01-13 22:17:01 --> Router Class Initialized
INFO - 2017-01-13 22:17:01 --> Output Class Initialized
INFO - 2017-01-13 22:17:01 --> Security Class Initialized
DEBUG - 2017-01-13 22:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:17:01 --> Input Class Initialized
INFO - 2017-01-13 22:17:01 --> Language Class Initialized
INFO - 2017-01-13 22:17:01 --> Loader Class Initialized
INFO - 2017-01-13 22:17:01 --> Database Driver Class Initialized
INFO - 2017-01-13 22:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:17:01 --> Controller Class Initialized
INFO - 2017-01-13 22:17:01 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:17:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:17:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:17:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:17:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:17:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:17:01 --> Final output sent to browser
DEBUG - 2017-01-13 22:17:01 --> Total execution time: 0.0670
INFO - 2017-01-13 22:17:05 --> Config Class Initialized
INFO - 2017-01-13 22:17:05 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:17:05 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:17:05 --> Utf8 Class Initialized
INFO - 2017-01-13 22:17:05 --> URI Class Initialized
INFO - 2017-01-13 22:17:05 --> Router Class Initialized
INFO - 2017-01-13 22:17:05 --> Output Class Initialized
INFO - 2017-01-13 22:17:05 --> Security Class Initialized
DEBUG - 2017-01-13 22:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:17:05 --> Input Class Initialized
INFO - 2017-01-13 22:17:05 --> Language Class Initialized
INFO - 2017-01-13 22:17:05 --> Loader Class Initialized
INFO - 2017-01-13 22:17:05 --> Database Driver Class Initialized
INFO - 2017-01-13 22:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:17:05 --> Controller Class Initialized
INFO - 2017-01-13 22:17:05 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:17:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:17:05 --> Helper loaded: form_helper
INFO - 2017-01-13 22:17:05 --> Form Validation Class Initialized
INFO - 2017-01-13 22:17:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 22:17:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-13 22:17:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 22:17:05 --> Final output sent to browser
DEBUG - 2017-01-13 22:17:05 --> Total execution time: 0.0130
INFO - 2017-01-13 22:17:05 --> Config Class Initialized
INFO - 2017-01-13 22:17:05 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:17:05 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:17:05 --> Utf8 Class Initialized
INFO - 2017-01-13 22:17:05 --> URI Class Initialized
INFO - 2017-01-13 22:17:05 --> Router Class Initialized
INFO - 2017-01-13 22:17:05 --> Output Class Initialized
INFO - 2017-01-13 22:17:05 --> Security Class Initialized
DEBUG - 2017-01-13 22:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:17:05 --> Input Class Initialized
INFO - 2017-01-13 22:17:05 --> Language Class Initialized
INFO - 2017-01-13 22:17:05 --> Loader Class Initialized
INFO - 2017-01-13 22:17:05 --> Database Driver Class Initialized
INFO - 2017-01-13 22:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:17:05 --> Controller Class Initialized
INFO - 2017-01-13 22:17:05 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:17:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:17:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:17:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:17:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:17:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:17:05 --> Final output sent to browser
DEBUG - 2017-01-13 22:17:05 --> Total execution time: 0.0133
INFO - 2017-01-13 22:17:14 --> Config Class Initialized
INFO - 2017-01-13 22:17:14 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:17:14 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:17:14 --> Utf8 Class Initialized
INFO - 2017-01-13 22:17:14 --> URI Class Initialized
INFO - 2017-01-13 22:17:14 --> Router Class Initialized
INFO - 2017-01-13 22:17:14 --> Output Class Initialized
INFO - 2017-01-13 22:17:14 --> Security Class Initialized
DEBUG - 2017-01-13 22:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:17:14 --> Input Class Initialized
INFO - 2017-01-13 22:17:14 --> Language Class Initialized
INFO - 2017-01-13 22:17:14 --> Loader Class Initialized
INFO - 2017-01-13 22:17:14 --> Database Driver Class Initialized
INFO - 2017-01-13 22:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:17:14 --> Controller Class Initialized
INFO - 2017-01-13 22:17:14 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:17:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:17:14 --> Helper loaded: form_helper
INFO - 2017-01-13 22:17:14 --> Form Validation Class Initialized
INFO - 2017-01-13 22:17:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-13 22:17:14 --> Config Class Initialized
INFO - 2017-01-13 22:17:14 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:17:14 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:17:14 --> Utf8 Class Initialized
INFO - 2017-01-13 22:17:14 --> URI Class Initialized
INFO - 2017-01-13 22:17:14 --> Router Class Initialized
INFO - 2017-01-13 22:17:14 --> Output Class Initialized
INFO - 2017-01-13 22:17:14 --> Security Class Initialized
DEBUG - 2017-01-13 22:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:17:14 --> Input Class Initialized
INFO - 2017-01-13 22:17:14 --> Language Class Initialized
INFO - 2017-01-13 22:17:14 --> Loader Class Initialized
INFO - 2017-01-13 22:17:14 --> Database Driver Class Initialized
INFO - 2017-01-13 22:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:17:14 --> Controller Class Initialized
INFO - 2017-01-13 22:17:14 --> Helper loaded: date_helper
INFO - 2017-01-13 22:17:14 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:17:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:17:14 --> Helper loaded: form_helper
INFO - 2017-01-13 22:17:14 --> Form Validation Class Initialized
INFO - 2017-01-13 22:17:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 22:17:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 22:17:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-13 22:17:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-13 22:17:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 22:17:14 --> Final output sent to browser
DEBUG - 2017-01-13 22:17:14 --> Total execution time: 0.0156
INFO - 2017-01-13 22:17:14 --> Config Class Initialized
INFO - 2017-01-13 22:17:14 --> Hooks Class Initialized
INFO - 2017-01-13 22:17:14 --> Config Class Initialized
INFO - 2017-01-13 22:17:14 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:17:14 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:17:14 --> Utf8 Class Initialized
INFO - 2017-01-13 22:17:14 --> URI Class Initialized
INFO - 2017-01-13 22:17:14 --> Router Class Initialized
INFO - 2017-01-13 22:17:14 --> Output Class Initialized
INFO - 2017-01-13 22:17:14 --> Security Class Initialized
DEBUG - 2017-01-13 22:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:17:14 --> Input Class Initialized
INFO - 2017-01-13 22:17:14 --> Language Class Initialized
INFO - 2017-01-13 22:17:14 --> Loader Class Initialized
INFO - 2017-01-13 22:17:14 --> Database Driver Class Initialized
DEBUG - 2017-01-13 22:17:14 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:17:14 --> Utf8 Class Initialized
INFO - 2017-01-13 22:17:14 --> URI Class Initialized
INFO - 2017-01-13 22:17:14 --> Router Class Initialized
INFO - 2017-01-13 22:17:14 --> Output Class Initialized
INFO - 2017-01-13 22:17:14 --> Security Class Initialized
DEBUG - 2017-01-13 22:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:17:14 --> Input Class Initialized
INFO - 2017-01-13 22:17:14 --> Language Class Initialized
INFO - 2017-01-13 22:17:14 --> Loader Class Initialized
INFO - 2017-01-13 22:17:14 --> Database Driver Class Initialized
INFO - 2017-01-13 22:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:17:14 --> Controller Class Initialized
INFO - 2017-01-13 22:17:14 --> Helper loaded: date_helper
INFO - 2017-01-13 22:17:14 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:17:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:17:14 --> Helper loaded: form_helper
INFO - 2017-01-13 22:17:14 --> Form Validation Class Initialized
INFO - 2017-01-13 22:17:14 --> Final output sent to browser
DEBUG - 2017-01-13 22:17:14 --> Total execution time: 0.0999
INFO - 2017-01-13 22:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:17:14 --> Controller Class Initialized
INFO - 2017-01-13 22:17:14 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:17:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:17:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:17:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:17:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:17:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:17:14 --> Final output sent to browser
DEBUG - 2017-01-13 22:17:14 --> Total execution time: 0.0327
INFO - 2017-01-13 22:17:18 --> Config Class Initialized
INFO - 2017-01-13 22:17:18 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:17:18 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:17:18 --> Utf8 Class Initialized
INFO - 2017-01-13 22:17:18 --> URI Class Initialized
INFO - 2017-01-13 22:17:18 --> Router Class Initialized
INFO - 2017-01-13 22:17:18 --> Output Class Initialized
INFO - 2017-01-13 22:17:18 --> Security Class Initialized
DEBUG - 2017-01-13 22:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:17:18 --> Input Class Initialized
INFO - 2017-01-13 22:17:18 --> Language Class Initialized
INFO - 2017-01-13 22:17:18 --> Loader Class Initialized
INFO - 2017-01-13 22:17:18 --> Database Driver Class Initialized
INFO - 2017-01-13 22:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:17:18 --> Controller Class Initialized
INFO - 2017-01-13 22:17:18 --> Upload Class Initialized
INFO - 2017-01-13 22:17:18 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:17:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:17:18 --> Helper loaded: form_helper
INFO - 2017-01-13 22:17:18 --> Form Validation Class Initialized
INFO - 2017-01-13 22:17:18 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 22:17:18 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 22:17:18 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-13 22:17:18 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-13 22:17:18 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-13 22:17:18 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 22:17:18 --> Final output sent to browser
DEBUG - 2017-01-13 22:17:18 --> Total execution time: 0.0953
INFO - 2017-01-13 22:17:19 --> Config Class Initialized
INFO - 2017-01-13 22:17:19 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:17:19 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:17:19 --> Utf8 Class Initialized
INFO - 2017-01-13 22:17:19 --> URI Class Initialized
INFO - 2017-01-13 22:17:19 --> Router Class Initialized
INFO - 2017-01-13 22:17:19 --> Output Class Initialized
INFO - 2017-01-13 22:17:19 --> Security Class Initialized
DEBUG - 2017-01-13 22:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:17:19 --> Input Class Initialized
INFO - 2017-01-13 22:17:19 --> Language Class Initialized
INFO - 2017-01-13 22:17:19 --> Loader Class Initialized
INFO - 2017-01-13 22:17:19 --> Database Driver Class Initialized
INFO - 2017-01-13 22:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:17:19 --> Controller Class Initialized
INFO - 2017-01-13 22:17:19 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:17:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:17:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:17:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:17:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:17:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:17:19 --> Final output sent to browser
DEBUG - 2017-01-13 22:17:19 --> Total execution time: 0.0133
INFO - 2017-01-13 22:17:40 --> Config Class Initialized
INFO - 2017-01-13 22:17:40 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:17:40 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:17:40 --> Utf8 Class Initialized
INFO - 2017-01-13 22:17:40 --> URI Class Initialized
INFO - 2017-01-13 22:17:40 --> Router Class Initialized
INFO - 2017-01-13 22:17:40 --> Output Class Initialized
INFO - 2017-01-13 22:17:40 --> Security Class Initialized
DEBUG - 2017-01-13 22:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:17:40 --> Input Class Initialized
INFO - 2017-01-13 22:17:40 --> Language Class Initialized
INFO - 2017-01-13 22:17:40 --> Loader Class Initialized
INFO - 2017-01-13 22:17:40 --> Database Driver Class Initialized
INFO - 2017-01-13 22:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:17:40 --> Controller Class Initialized
INFO - 2017-01-13 22:17:40 --> Helper loaded: date_helper
INFO - 2017-01-13 22:17:40 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:17:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:17:40 --> Helper loaded: form_helper
INFO - 2017-01-13 22:17:40 --> Form Validation Class Initialized
INFO - 2017-01-13 22:17:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 22:17:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 22:17:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-13 22:17:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-13 22:17:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 22:17:40 --> Final output sent to browser
DEBUG - 2017-01-13 22:17:40 --> Total execution time: 0.0801
INFO - 2017-01-13 22:17:40 --> Config Class Initialized
INFO - 2017-01-13 22:17:40 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:17:40 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:17:40 --> Utf8 Class Initialized
INFO - 2017-01-13 22:17:40 --> URI Class Initialized
INFO - 2017-01-13 22:17:40 --> Router Class Initialized
INFO - 2017-01-13 22:17:40 --> Output Class Initialized
INFO - 2017-01-13 22:17:40 --> Security Class Initialized
DEBUG - 2017-01-13 22:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:17:40 --> Input Class Initialized
INFO - 2017-01-13 22:17:40 --> Language Class Initialized
INFO - 2017-01-13 22:17:40 --> Loader Class Initialized
INFO - 2017-01-13 22:17:40 --> Database Driver Class Initialized
INFO - 2017-01-13 22:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:17:40 --> Controller Class Initialized
INFO - 2017-01-13 22:17:40 --> Helper loaded: date_helper
INFO - 2017-01-13 22:17:40 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:17:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:17:40 --> Helper loaded: form_helper
INFO - 2017-01-13 22:17:40 --> Form Validation Class Initialized
INFO - 2017-01-13 22:17:40 --> Final output sent to browser
DEBUG - 2017-01-13 22:17:40 --> Total execution time: 0.0146
INFO - 2017-01-13 22:17:40 --> Config Class Initialized
INFO - 2017-01-13 22:17:40 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:17:40 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:17:40 --> Utf8 Class Initialized
INFO - 2017-01-13 22:17:40 --> URI Class Initialized
INFO - 2017-01-13 22:17:40 --> Router Class Initialized
INFO - 2017-01-13 22:17:40 --> Output Class Initialized
INFO - 2017-01-13 22:17:40 --> Security Class Initialized
DEBUG - 2017-01-13 22:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:17:40 --> Input Class Initialized
INFO - 2017-01-13 22:17:40 --> Language Class Initialized
INFO - 2017-01-13 22:17:40 --> Loader Class Initialized
INFO - 2017-01-13 22:17:40 --> Database Driver Class Initialized
INFO - 2017-01-13 22:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:17:40 --> Controller Class Initialized
INFO - 2017-01-13 22:17:40 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:17:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:17:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:17:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:17:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:17:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:17:40 --> Final output sent to browser
DEBUG - 2017-01-13 22:17:40 --> Total execution time: 0.0145
INFO - 2017-01-13 22:18:01 --> Config Class Initialized
INFO - 2017-01-13 22:18:01 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:18:01 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:18:01 --> Utf8 Class Initialized
INFO - 2017-01-13 22:18:01 --> URI Class Initialized
INFO - 2017-01-13 22:18:01 --> Router Class Initialized
INFO - 2017-01-13 22:18:01 --> Output Class Initialized
INFO - 2017-01-13 22:18:01 --> Security Class Initialized
DEBUG - 2017-01-13 22:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:18:01 --> Input Class Initialized
INFO - 2017-01-13 22:18:01 --> Language Class Initialized
INFO - 2017-01-13 22:18:01 --> Loader Class Initialized
INFO - 2017-01-13 22:18:01 --> Config Class Initialized
INFO - 2017-01-13 22:18:01 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:18:01 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:18:01 --> Utf8 Class Initialized
INFO - 2017-01-13 22:18:01 --> URI Class Initialized
INFO - 2017-01-13 22:18:01 --> Router Class Initialized
INFO - 2017-01-13 22:18:01 --> Output Class Initialized
INFO - 2017-01-13 22:18:01 --> Security Class Initialized
DEBUG - 2017-01-13 22:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:18:01 --> Input Class Initialized
INFO - 2017-01-13 22:18:01 --> Language Class Initialized
INFO - 2017-01-13 22:18:01 --> Loader Class Initialized
INFO - 2017-01-13 22:18:01 --> Database Driver Class Initialized
INFO - 2017-01-13 22:18:01 --> Database Driver Class Initialized
INFO - 2017-01-13 22:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:18:01 --> Controller Class Initialized
INFO - 2017-01-13 22:18:01 --> Helper loaded: date_helper
INFO - 2017-01-13 22:18:01 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:18:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:18:01 --> Helper loaded: form_helper
INFO - 2017-01-13 22:18:01 --> Form Validation Class Initialized
INFO - 2017-01-13 22:18:01 --> Final output sent to browser
DEBUG - 2017-01-13 22:18:01 --> Total execution time: 0.0169
INFO - 2017-01-13 22:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:18:01 --> Controller Class Initialized
INFO - 2017-01-13 22:18:01 --> Helper loaded: date_helper
INFO - 2017-01-13 22:18:01 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:18:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:18:01 --> Helper loaded: form_helper
INFO - 2017-01-13 22:18:01 --> Form Validation Class Initialized
INFO - 2017-01-13 22:18:01 --> Final output sent to browser
DEBUG - 2017-01-13 22:18:01 --> Total execution time: 0.0891
INFO - 2017-01-13 22:18:13 --> Config Class Initialized
INFO - 2017-01-13 22:18:13 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:18:13 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:18:13 --> Utf8 Class Initialized
INFO - 2017-01-13 22:18:13 --> URI Class Initialized
INFO - 2017-01-13 22:18:13 --> Router Class Initialized
INFO - 2017-01-13 22:18:13 --> Output Class Initialized
INFO - 2017-01-13 22:18:13 --> Security Class Initialized
DEBUG - 2017-01-13 22:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:18:13 --> Input Class Initialized
INFO - 2017-01-13 22:18:13 --> Language Class Initialized
INFO - 2017-01-13 22:18:13 --> Loader Class Initialized
INFO - 2017-01-13 22:18:13 --> Database Driver Class Initialized
INFO - 2017-01-13 22:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:18:13 --> Controller Class Initialized
INFO - 2017-01-13 22:18:13 --> Helper loaded: date_helper
INFO - 2017-01-13 22:18:13 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:18:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:18:13 --> Helper loaded: form_helper
INFO - 2017-01-13 22:18:13 --> Form Validation Class Initialized
INFO - 2017-01-13 22:18:13 --> Final output sent to browser
DEBUG - 2017-01-13 22:18:13 --> Total execution time: 0.0153
INFO - 2017-01-13 22:18:13 --> Config Class Initialized
INFO - 2017-01-13 22:18:13 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:18:13 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:18:13 --> Utf8 Class Initialized
INFO - 2017-01-13 22:18:14 --> URI Class Initialized
INFO - 2017-01-13 22:18:14 --> Router Class Initialized
INFO - 2017-01-13 22:18:14 --> Output Class Initialized
INFO - 2017-01-13 22:18:14 --> Security Class Initialized
DEBUG - 2017-01-13 22:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:18:14 --> Input Class Initialized
INFO - 2017-01-13 22:18:14 --> Language Class Initialized
INFO - 2017-01-13 22:18:14 --> Loader Class Initialized
INFO - 2017-01-13 22:18:14 --> Database Driver Class Initialized
INFO - 2017-01-13 22:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:18:14 --> Controller Class Initialized
INFO - 2017-01-13 22:18:14 --> Helper loaded: date_helper
INFO - 2017-01-13 22:18:14 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:18:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:18:14 --> Helper loaded: form_helper
INFO - 2017-01-13 22:18:14 --> Form Validation Class Initialized
INFO - 2017-01-13 22:18:14 --> Final output sent to browser
DEBUG - 2017-01-13 22:18:14 --> Total execution time: 0.0157
INFO - 2017-01-13 22:18:14 --> Config Class Initialized
INFO - 2017-01-13 22:18:14 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:18:14 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:18:14 --> Utf8 Class Initialized
INFO - 2017-01-13 22:18:14 --> URI Class Initialized
INFO - 2017-01-13 22:18:14 --> Router Class Initialized
INFO - 2017-01-13 22:18:14 --> Output Class Initialized
INFO - 2017-01-13 22:18:14 --> Security Class Initialized
DEBUG - 2017-01-13 22:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:18:14 --> Input Class Initialized
INFO - 2017-01-13 22:18:14 --> Language Class Initialized
INFO - 2017-01-13 22:18:14 --> Loader Class Initialized
INFO - 2017-01-13 22:18:14 --> Database Driver Class Initialized
INFO - 2017-01-13 22:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:18:14 --> Controller Class Initialized
INFO - 2017-01-13 22:18:14 --> Helper loaded: date_helper
INFO - 2017-01-13 22:18:14 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:18:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:18:14 --> Helper loaded: form_helper
INFO - 2017-01-13 22:18:14 --> Form Validation Class Initialized
INFO - 2017-01-13 22:18:14 --> Final output sent to browser
DEBUG - 2017-01-13 22:18:14 --> Total execution time: 0.0156
INFO - 2017-01-13 22:18:19 --> Config Class Initialized
INFO - 2017-01-13 22:18:19 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:18:19 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:18:19 --> Utf8 Class Initialized
INFO - 2017-01-13 22:18:19 --> URI Class Initialized
INFO - 2017-01-13 22:18:19 --> Router Class Initialized
INFO - 2017-01-13 22:18:19 --> Output Class Initialized
INFO - 2017-01-13 22:18:19 --> Security Class Initialized
DEBUG - 2017-01-13 22:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:18:19 --> Input Class Initialized
INFO - 2017-01-13 22:18:19 --> Language Class Initialized
INFO - 2017-01-13 22:18:19 --> Loader Class Initialized
INFO - 2017-01-13 22:18:19 --> Database Driver Class Initialized
INFO - 2017-01-13 22:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:18:19 --> Controller Class Initialized
INFO - 2017-01-13 22:18:19 --> Helper loaded: date_helper
INFO - 2017-01-13 22:18:19 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:18:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:18:19 --> Helper loaded: form_helper
INFO - 2017-01-13 22:18:19 --> Form Validation Class Initialized
INFO - 2017-01-13 22:18:19 --> Final output sent to browser
DEBUG - 2017-01-13 22:18:19 --> Total execution time: 0.0155
INFO - 2017-01-13 22:18:27 --> Config Class Initialized
INFO - 2017-01-13 22:18:27 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:18:27 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:18:27 --> Utf8 Class Initialized
INFO - 2017-01-13 22:18:27 --> URI Class Initialized
INFO - 2017-01-13 22:18:27 --> Router Class Initialized
INFO - 2017-01-13 22:18:27 --> Output Class Initialized
INFO - 2017-01-13 22:18:27 --> Security Class Initialized
DEBUG - 2017-01-13 22:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:18:27 --> Input Class Initialized
INFO - 2017-01-13 22:18:27 --> Language Class Initialized
INFO - 2017-01-13 22:18:27 --> Loader Class Initialized
INFO - 2017-01-13 22:18:27 --> Database Driver Class Initialized
INFO - 2017-01-13 22:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:18:27 --> Controller Class Initialized
INFO - 2017-01-13 22:18:27 --> Helper loaded: date_helper
INFO - 2017-01-13 22:18:27 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:18:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:18:27 --> Helper loaded: form_helper
INFO - 2017-01-13 22:18:27 --> Form Validation Class Initialized
INFO - 2017-01-13 22:18:27 --> Final output sent to browser
DEBUG - 2017-01-13 22:18:27 --> Total execution time: 0.0146
INFO - 2017-01-13 22:18:29 --> Config Class Initialized
INFO - 2017-01-13 22:18:29 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:18:29 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:18:29 --> Utf8 Class Initialized
INFO - 2017-01-13 22:18:29 --> URI Class Initialized
INFO - 2017-01-13 22:18:29 --> Router Class Initialized
INFO - 2017-01-13 22:18:29 --> Output Class Initialized
INFO - 2017-01-13 22:18:29 --> Security Class Initialized
DEBUG - 2017-01-13 22:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:18:29 --> Input Class Initialized
INFO - 2017-01-13 22:18:29 --> Language Class Initialized
INFO - 2017-01-13 22:18:29 --> Loader Class Initialized
INFO - 2017-01-13 22:18:29 --> Database Driver Class Initialized
INFO - 2017-01-13 22:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:18:29 --> Controller Class Initialized
INFO - 2017-01-13 22:18:29 --> Helper loaded: date_helper
INFO - 2017-01-13 22:18:29 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:18:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:18:29 --> Helper loaded: form_helper
INFO - 2017-01-13 22:18:29 --> Form Validation Class Initialized
INFO - 2017-01-13 22:18:29 --> Final output sent to browser
DEBUG - 2017-01-13 22:18:29 --> Total execution time: 0.0147
INFO - 2017-01-13 22:18:35 --> Config Class Initialized
INFO - 2017-01-13 22:18:35 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:18:35 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:18:35 --> Utf8 Class Initialized
INFO - 2017-01-13 22:18:35 --> URI Class Initialized
INFO - 2017-01-13 22:18:36 --> Router Class Initialized
INFO - 2017-01-13 22:18:36 --> Output Class Initialized
INFO - 2017-01-13 22:18:36 --> Security Class Initialized
DEBUG - 2017-01-13 22:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:18:36 --> Input Class Initialized
INFO - 2017-01-13 22:18:36 --> Language Class Initialized
INFO - 2017-01-13 22:18:36 --> Loader Class Initialized
INFO - 2017-01-13 22:18:36 --> Database Driver Class Initialized
INFO - 2017-01-13 22:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:18:36 --> Controller Class Initialized
INFO - 2017-01-13 22:18:36 --> Helper loaded: date_helper
INFO - 2017-01-13 22:18:36 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:18:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:18:36 --> Helper loaded: form_helper
INFO - 2017-01-13 22:18:36 --> Form Validation Class Initialized
INFO - 2017-01-13 22:18:36 --> Final output sent to browser
DEBUG - 2017-01-13 22:18:36 --> Total execution time: 0.0168
INFO - 2017-01-13 22:18:36 --> Config Class Initialized
INFO - 2017-01-13 22:18:36 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:18:36 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:18:36 --> Utf8 Class Initialized
INFO - 2017-01-13 22:18:36 --> URI Class Initialized
INFO - 2017-01-13 22:18:36 --> Router Class Initialized
INFO - 2017-01-13 22:18:36 --> Output Class Initialized
INFO - 2017-01-13 22:18:36 --> Security Class Initialized
DEBUG - 2017-01-13 22:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:18:36 --> Input Class Initialized
INFO - 2017-01-13 22:18:36 --> Language Class Initialized
INFO - 2017-01-13 22:18:36 --> Loader Class Initialized
INFO - 2017-01-13 22:18:36 --> Database Driver Class Initialized
INFO - 2017-01-13 22:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:18:36 --> Controller Class Initialized
INFO - 2017-01-13 22:18:36 --> Helper loaded: date_helper
INFO - 2017-01-13 22:18:36 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:18:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:18:36 --> Helper loaded: form_helper
INFO - 2017-01-13 22:18:36 --> Form Validation Class Initialized
INFO - 2017-01-13 22:18:36 --> Final output sent to browser
DEBUG - 2017-01-13 22:18:36 --> Total execution time: 0.0155
INFO - 2017-01-13 22:24:40 --> Config Class Initialized
INFO - 2017-01-13 22:24:40 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:24:40 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:24:40 --> Utf8 Class Initialized
INFO - 2017-01-13 22:24:40 --> URI Class Initialized
INFO - 2017-01-13 22:24:40 --> Router Class Initialized
INFO - 2017-01-13 22:24:40 --> Output Class Initialized
INFO - 2017-01-13 22:24:40 --> Security Class Initialized
DEBUG - 2017-01-13 22:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:24:40 --> Input Class Initialized
INFO - 2017-01-13 22:24:40 --> Language Class Initialized
INFO - 2017-01-13 22:24:40 --> Loader Class Initialized
INFO - 2017-01-13 22:24:40 --> Database Driver Class Initialized
INFO - 2017-01-13 22:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:24:40 --> Controller Class Initialized
INFO - 2017-01-13 22:24:40 --> Helper loaded: date_helper
INFO - 2017-01-13 22:24:40 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:24:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:24:40 --> Helper loaded: form_helper
INFO - 2017-01-13 22:24:40 --> Form Validation Class Initialized
INFO - 2017-01-13 22:24:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 22:24:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 22:24:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-13 22:24:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-13 22:24:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 22:24:40 --> Final output sent to browser
DEBUG - 2017-01-13 22:24:40 --> Total execution time: 0.0144
INFO - 2017-01-13 22:24:40 --> Config Class Initialized
INFO - 2017-01-13 22:24:40 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:24:40 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:24:40 --> Utf8 Class Initialized
INFO - 2017-01-13 22:24:40 --> URI Class Initialized
INFO - 2017-01-13 22:24:40 --> Router Class Initialized
INFO - 2017-01-13 22:24:40 --> Output Class Initialized
INFO - 2017-01-13 22:24:40 --> Security Class Initialized
DEBUG - 2017-01-13 22:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:24:40 --> Input Class Initialized
INFO - 2017-01-13 22:24:40 --> Language Class Initialized
INFO - 2017-01-13 22:24:40 --> Loader Class Initialized
INFO - 2017-01-13 22:24:40 --> Database Driver Class Initialized
INFO - 2017-01-13 22:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:24:40 --> Controller Class Initialized
INFO - 2017-01-13 22:24:40 --> Helper loaded: date_helper
INFO - 2017-01-13 22:24:40 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:24:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:24:40 --> Helper loaded: form_helper
INFO - 2017-01-13 22:24:40 --> Form Validation Class Initialized
INFO - 2017-01-13 22:24:40 --> Final output sent to browser
DEBUG - 2017-01-13 22:24:40 --> Total execution time: 0.0150
INFO - 2017-01-13 22:24:40 --> Config Class Initialized
INFO - 2017-01-13 22:24:40 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:24:40 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:24:40 --> Utf8 Class Initialized
INFO - 2017-01-13 22:24:40 --> URI Class Initialized
INFO - 2017-01-13 22:24:40 --> Router Class Initialized
INFO - 2017-01-13 22:24:40 --> Output Class Initialized
INFO - 2017-01-13 22:24:40 --> Security Class Initialized
DEBUG - 2017-01-13 22:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:24:40 --> Input Class Initialized
INFO - 2017-01-13 22:24:40 --> Language Class Initialized
INFO - 2017-01-13 22:24:40 --> Loader Class Initialized
INFO - 2017-01-13 22:24:40 --> Database Driver Class Initialized
INFO - 2017-01-13 22:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:24:40 --> Controller Class Initialized
INFO - 2017-01-13 22:24:40 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:24:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:24:40 --> Final output sent to browser
DEBUG - 2017-01-13 22:24:40 --> Total execution time: 0.0148
INFO - 2017-01-13 22:24:44 --> Config Class Initialized
INFO - 2017-01-13 22:24:44 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:24:44 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:24:44 --> Utf8 Class Initialized
INFO - 2017-01-13 22:24:44 --> URI Class Initialized
INFO - 2017-01-13 22:24:44 --> Router Class Initialized
INFO - 2017-01-13 22:24:44 --> Output Class Initialized
INFO - 2017-01-13 22:24:44 --> Security Class Initialized
DEBUG - 2017-01-13 22:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:24:44 --> Input Class Initialized
INFO - 2017-01-13 22:24:44 --> Language Class Initialized
INFO - 2017-01-13 22:24:44 --> Loader Class Initialized
INFO - 2017-01-13 22:24:44 --> Database Driver Class Initialized
INFO - 2017-01-13 22:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:24:44 --> Controller Class Initialized
INFO - 2017-01-13 22:24:44 --> Upload Class Initialized
INFO - 2017-01-13 22:24:44 --> Helper loaded: date_helper
INFO - 2017-01-13 22:24:44 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:24:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:24:44 --> Helper loaded: form_helper
INFO - 2017-01-13 22:24:44 --> Form Validation Class Initialized
INFO - 2017-01-13 22:24:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 22:24:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 22:24:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/cupones.php
INFO - 2017-01-13 22:24:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/cupones.php
INFO - 2017-01-13 22:24:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-13 22:24:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 22:24:44 --> Final output sent to browser
DEBUG - 2017-01-13 22:24:44 --> Total execution time: 0.0626
INFO - 2017-01-13 22:24:44 --> Config Class Initialized
INFO - 2017-01-13 22:24:44 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:24:44 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:24:44 --> Utf8 Class Initialized
INFO - 2017-01-13 22:24:44 --> URI Class Initialized
INFO - 2017-01-13 22:24:44 --> Router Class Initialized
INFO - 2017-01-13 22:24:44 --> Output Class Initialized
INFO - 2017-01-13 22:24:44 --> Security Class Initialized
DEBUG - 2017-01-13 22:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:24:44 --> Input Class Initialized
INFO - 2017-01-13 22:24:44 --> Language Class Initialized
INFO - 2017-01-13 22:24:44 --> Loader Class Initialized
INFO - 2017-01-13 22:24:44 --> Database Driver Class Initialized
INFO - 2017-01-13 22:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:24:44 --> Controller Class Initialized
INFO - 2017-01-13 22:24:44 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:24:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:24:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:24:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:24:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:24:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:24:44 --> Final output sent to browser
DEBUG - 2017-01-13 22:24:44 --> Total execution time: 0.0134
INFO - 2017-01-13 22:24:46 --> Config Class Initialized
INFO - 2017-01-13 22:24:46 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:24:46 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:24:46 --> Utf8 Class Initialized
INFO - 2017-01-13 22:24:46 --> URI Class Initialized
INFO - 2017-01-13 22:24:46 --> Router Class Initialized
INFO - 2017-01-13 22:24:46 --> Output Class Initialized
INFO - 2017-01-13 22:24:46 --> Security Class Initialized
DEBUG - 2017-01-13 22:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:24:46 --> Input Class Initialized
INFO - 2017-01-13 22:24:46 --> Language Class Initialized
INFO - 2017-01-13 22:24:46 --> Loader Class Initialized
INFO - 2017-01-13 22:24:46 --> Database Driver Class Initialized
INFO - 2017-01-13 22:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:24:46 --> Controller Class Initialized
INFO - 2017-01-13 22:24:46 --> Helper loaded: date_helper
INFO - 2017-01-13 22:24:46 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:24:46 --> Helper loaded: form_helper
INFO - 2017-01-13 22:24:46 --> Form Validation Class Initialized
INFO - 2017-01-13 22:24:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 22:24:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 22:24:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-13 22:24:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-13 22:24:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 22:24:46 --> Final output sent to browser
DEBUG - 2017-01-13 22:24:46 --> Total execution time: 0.0249
INFO - 2017-01-13 22:24:46 --> Config Class Initialized
INFO - 2017-01-13 22:24:46 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:24:46 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:24:46 --> Utf8 Class Initialized
INFO - 2017-01-13 22:24:46 --> URI Class Initialized
INFO - 2017-01-13 22:24:46 --> Config Class Initialized
INFO - 2017-01-13 22:24:46 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:24:46 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:24:46 --> Utf8 Class Initialized
INFO - 2017-01-13 22:24:46 --> URI Class Initialized
INFO - 2017-01-13 22:24:46 --> Router Class Initialized
INFO - 2017-01-13 22:24:46 --> Output Class Initialized
INFO - 2017-01-13 22:24:46 --> Security Class Initialized
DEBUG - 2017-01-13 22:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:24:46 --> Input Class Initialized
INFO - 2017-01-13 22:24:46 --> Language Class Initialized
INFO - 2017-01-13 22:24:46 --> Loader Class Initialized
INFO - 2017-01-13 22:24:46 --> Database Driver Class Initialized
INFO - 2017-01-13 22:24:46 --> Router Class Initialized
INFO - 2017-01-13 22:24:46 --> Output Class Initialized
INFO - 2017-01-13 22:24:46 --> Security Class Initialized
DEBUG - 2017-01-13 22:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:24:46 --> Input Class Initialized
INFO - 2017-01-13 22:24:46 --> Language Class Initialized
INFO - 2017-01-13 22:24:46 --> Loader Class Initialized
INFO - 2017-01-13 22:24:46 --> Database Driver Class Initialized
INFO - 2017-01-13 22:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:24:46 --> Controller Class Initialized
INFO - 2017-01-13 22:24:46 --> Helper loaded: date_helper
INFO - 2017-01-13 22:24:46 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:24:46 --> Helper loaded: form_helper
INFO - 2017-01-13 22:24:46 --> Form Validation Class Initialized
INFO - 2017-01-13 22:24:46 --> Final output sent to browser
DEBUG - 2017-01-13 22:24:46 --> Total execution time: 0.0217
INFO - 2017-01-13 22:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:24:46 --> Controller Class Initialized
INFO - 2017-01-13 22:24:46 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:24:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:24:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:24:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:24:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:24:46 --> Final output sent to browser
DEBUG - 2017-01-13 22:24:46 --> Total execution time: 0.0913
INFO - 2017-01-13 22:24:48 --> Config Class Initialized
INFO - 2017-01-13 22:24:48 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:24:48 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:24:48 --> Utf8 Class Initialized
INFO - 2017-01-13 22:24:48 --> URI Class Initialized
INFO - 2017-01-13 22:24:48 --> Router Class Initialized
INFO - 2017-01-13 22:24:48 --> Output Class Initialized
INFO - 2017-01-13 22:24:48 --> Security Class Initialized
DEBUG - 2017-01-13 22:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:24:48 --> Input Class Initialized
INFO - 2017-01-13 22:24:48 --> Language Class Initialized
INFO - 2017-01-13 22:24:48 --> Loader Class Initialized
INFO - 2017-01-13 22:24:48 --> Database Driver Class Initialized
INFO - 2017-01-13 22:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:24:48 --> Controller Class Initialized
INFO - 2017-01-13 22:24:48 --> Helper loaded: date_helper
INFO - 2017-01-13 22:24:48 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:24:48 --> Helper loaded: form_helper
INFO - 2017-01-13 22:24:48 --> Form Validation Class Initialized
INFO - 2017-01-13 22:24:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 22:24:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 22:24:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pagos.php
INFO - 2017-01-13 22:24:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pagos.php
INFO - 2017-01-13 22:24:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 22:24:48 --> Final output sent to browser
DEBUG - 2017-01-13 22:24:48 --> Total execution time: 0.0158
INFO - 2017-01-13 22:24:48 --> Config Class Initialized
INFO - 2017-01-13 22:24:48 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:24:48 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:24:48 --> Utf8 Class Initialized
INFO - 2017-01-13 22:24:48 --> URI Class Initialized
INFO - 2017-01-13 22:24:48 --> Router Class Initialized
INFO - 2017-01-13 22:24:48 --> Output Class Initialized
INFO - 2017-01-13 22:24:48 --> Security Class Initialized
DEBUG - 2017-01-13 22:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:24:48 --> Input Class Initialized
INFO - 2017-01-13 22:24:48 --> Language Class Initialized
INFO - 2017-01-13 22:24:48 --> Loader Class Initialized
INFO - 2017-01-13 22:24:48 --> Database Driver Class Initialized
INFO - 2017-01-13 22:24:48 --> Config Class Initialized
INFO - 2017-01-13 22:24:48 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:24:48 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:24:48 --> Utf8 Class Initialized
INFO - 2017-01-13 22:24:48 --> URI Class Initialized
INFO - 2017-01-13 22:24:48 --> Router Class Initialized
INFO - 2017-01-13 22:24:48 --> Output Class Initialized
INFO - 2017-01-13 22:24:48 --> Security Class Initialized
DEBUG - 2017-01-13 22:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:24:48 --> Input Class Initialized
INFO - 2017-01-13 22:24:48 --> Language Class Initialized
INFO - 2017-01-13 22:24:48 --> Loader Class Initialized
INFO - 2017-01-13 22:24:48 --> Database Driver Class Initialized
INFO - 2017-01-13 22:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:24:48 --> Controller Class Initialized
INFO - 2017-01-13 22:24:48 --> Helper loaded: date_helper
INFO - 2017-01-13 22:24:48 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:24:48 --> Helper loaded: form_helper
INFO - 2017-01-13 22:24:48 --> Form Validation Class Initialized
INFO - 2017-01-13 22:24:48 --> Final output sent to browser
DEBUG - 2017-01-13 22:24:48 --> Total execution time: 0.0770
INFO - 2017-01-13 22:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:24:48 --> Controller Class Initialized
INFO - 2017-01-13 22:24:48 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:24:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:24:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:24:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:24:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:24:48 --> Final output sent to browser
DEBUG - 2017-01-13 22:24:48 --> Total execution time: 0.0231
INFO - 2017-01-13 22:24:51 --> Config Class Initialized
INFO - 2017-01-13 22:24:51 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:24:51 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:24:51 --> Utf8 Class Initialized
INFO - 2017-01-13 22:24:51 --> URI Class Initialized
INFO - 2017-01-13 22:24:51 --> Router Class Initialized
INFO - 2017-01-13 22:24:51 --> Output Class Initialized
INFO - 2017-01-13 22:24:51 --> Security Class Initialized
DEBUG - 2017-01-13 22:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:24:51 --> Input Class Initialized
INFO - 2017-01-13 22:24:51 --> Language Class Initialized
INFO - 2017-01-13 22:24:51 --> Loader Class Initialized
INFO - 2017-01-13 22:24:51 --> Database Driver Class Initialized
INFO - 2017-01-13 22:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:24:51 --> Controller Class Initialized
INFO - 2017-01-13 22:24:51 --> Helper loaded: date_helper
INFO - 2017-01-13 22:24:51 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:24:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:24:51 --> Helper loaded: form_helper
INFO - 2017-01-13 22:24:51 --> Form Validation Class Initialized
INFO - 2017-01-13 22:24:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 22:24:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 22:24:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-13 22:24:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-13 22:24:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 22:24:51 --> Final output sent to browser
DEBUG - 2017-01-13 22:24:51 --> Total execution time: 0.0168
INFO - 2017-01-13 22:24:51 --> Config Class Initialized
INFO - 2017-01-13 22:24:51 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:24:51 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:24:51 --> Utf8 Class Initialized
INFO - 2017-01-13 22:24:51 --> URI Class Initialized
INFO - 2017-01-13 22:24:51 --> Router Class Initialized
INFO - 2017-01-13 22:24:51 --> Output Class Initialized
INFO - 2017-01-13 22:24:51 --> Security Class Initialized
DEBUG - 2017-01-13 22:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:24:51 --> Input Class Initialized
INFO - 2017-01-13 22:24:51 --> Language Class Initialized
INFO - 2017-01-13 22:24:51 --> Loader Class Initialized
INFO - 2017-01-13 22:24:51 --> Database Driver Class Initialized
INFO - 2017-01-13 22:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:24:51 --> Controller Class Initialized
INFO - 2017-01-13 22:24:51 --> Helper loaded: date_helper
INFO - 2017-01-13 22:24:51 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:24:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:24:51 --> Helper loaded: form_helper
INFO - 2017-01-13 22:24:51 --> Form Validation Class Initialized
INFO - 2017-01-13 22:24:51 --> Final output sent to browser
DEBUG - 2017-01-13 22:24:51 --> Total execution time: 0.0147
INFO - 2017-01-13 22:24:51 --> Config Class Initialized
INFO - 2017-01-13 22:24:51 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:24:51 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:24:51 --> Utf8 Class Initialized
INFO - 2017-01-13 22:24:51 --> URI Class Initialized
INFO - 2017-01-13 22:24:51 --> Router Class Initialized
INFO - 2017-01-13 22:24:51 --> Output Class Initialized
INFO - 2017-01-13 22:24:51 --> Security Class Initialized
DEBUG - 2017-01-13 22:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:24:51 --> Input Class Initialized
INFO - 2017-01-13 22:24:51 --> Language Class Initialized
INFO - 2017-01-13 22:24:51 --> Loader Class Initialized
INFO - 2017-01-13 22:24:51 --> Database Driver Class Initialized
INFO - 2017-01-13 22:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:24:51 --> Controller Class Initialized
INFO - 2017-01-13 22:24:51 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:24:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:24:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:24:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:24:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:24:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:24:51 --> Final output sent to browser
DEBUG - 2017-01-13 22:24:51 --> Total execution time: 0.0402
INFO - 2017-01-13 22:24:53 --> Config Class Initialized
INFO - 2017-01-13 22:24:53 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:24:53 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:24:53 --> Utf8 Class Initialized
INFO - 2017-01-13 22:24:53 --> URI Class Initialized
INFO - 2017-01-13 22:24:53 --> Router Class Initialized
INFO - 2017-01-13 22:24:53 --> Output Class Initialized
INFO - 2017-01-13 22:24:53 --> Config Class Initialized
INFO - 2017-01-13 22:24:53 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:24:53 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:24:53 --> Utf8 Class Initialized
INFO - 2017-01-13 22:24:53 --> URI Class Initialized
INFO - 2017-01-13 22:24:53 --> Router Class Initialized
INFO - 2017-01-13 22:24:53 --> Output Class Initialized
INFO - 2017-01-13 22:24:53 --> Security Class Initialized
DEBUG - 2017-01-13 22:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:24:53 --> Input Class Initialized
INFO - 2017-01-13 22:24:53 --> Language Class Initialized
INFO - 2017-01-13 22:24:53 --> Loader Class Initialized
INFO - 2017-01-13 22:24:53 --> Database Driver Class Initialized
INFO - 2017-01-13 22:24:53 --> Security Class Initialized
DEBUG - 2017-01-13 22:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:24:53 --> Input Class Initialized
INFO - 2017-01-13 22:24:53 --> Language Class Initialized
INFO - 2017-01-13 22:24:53 --> Loader Class Initialized
INFO - 2017-01-13 22:24:53 --> Database Driver Class Initialized
INFO - 2017-01-13 22:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:24:53 --> Controller Class Initialized
INFO - 2017-01-13 22:24:53 --> Helper loaded: date_helper
INFO - 2017-01-13 22:24:53 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:24:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:24:53 --> Helper loaded: form_helper
INFO - 2017-01-13 22:24:53 --> Form Validation Class Initialized
INFO - 2017-01-13 22:24:53 --> Final output sent to browser
DEBUG - 2017-01-13 22:24:53 --> Total execution time: 0.0285
INFO - 2017-01-13 22:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:24:53 --> Controller Class Initialized
INFO - 2017-01-13 22:24:53 --> Helper loaded: date_helper
INFO - 2017-01-13 22:24:53 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:24:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:24:53 --> Helper loaded: form_helper
INFO - 2017-01-13 22:24:53 --> Form Validation Class Initialized
INFO - 2017-01-13 22:24:53 --> Final output sent to browser
DEBUG - 2017-01-13 22:24:53 --> Total execution time: 0.0825
INFO - 2017-01-13 22:25:19 --> Config Class Initialized
INFO - 2017-01-13 22:25:19 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:25:19 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:25:19 --> Utf8 Class Initialized
INFO - 2017-01-13 22:25:19 --> URI Class Initialized
INFO - 2017-01-13 22:25:19 --> Router Class Initialized
INFO - 2017-01-13 22:25:19 --> Output Class Initialized
INFO - 2017-01-13 22:25:19 --> Security Class Initialized
DEBUG - 2017-01-13 22:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:25:19 --> Input Class Initialized
INFO - 2017-01-13 22:25:19 --> Language Class Initialized
INFO - 2017-01-13 22:25:19 --> Loader Class Initialized
INFO - 2017-01-13 22:25:19 --> Database Driver Class Initialized
INFO - 2017-01-13 22:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:25:19 --> Controller Class Initialized
INFO - 2017-01-13 22:25:19 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:25:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:25:19 --> Config Class Initialized
INFO - 2017-01-13 22:25:19 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:25:19 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:25:19 --> Utf8 Class Initialized
INFO - 2017-01-13 22:25:19 --> URI Class Initialized
INFO - 2017-01-13 22:25:19 --> Router Class Initialized
INFO - 2017-01-13 22:25:19 --> Output Class Initialized
INFO - 2017-01-13 22:25:19 --> Security Class Initialized
DEBUG - 2017-01-13 22:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:25:19 --> Input Class Initialized
INFO - 2017-01-13 22:25:19 --> Language Class Initialized
INFO - 2017-01-13 22:25:19 --> Loader Class Initialized
INFO - 2017-01-13 22:25:19 --> Database Driver Class Initialized
INFO - 2017-01-13 22:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:25:19 --> Controller Class Initialized
INFO - 2017-01-13 22:25:19 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:25:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:25:19 --> Helper loaded: form_helper
INFO - 2017-01-13 22:25:19 --> Form Validation Class Initialized
INFO - 2017-01-13 22:25:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 22:25:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-13 22:25:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 22:25:19 --> Final output sent to browser
DEBUG - 2017-01-13 22:25:19 --> Total execution time: 0.0131
INFO - 2017-01-13 22:25:20 --> Config Class Initialized
INFO - 2017-01-13 22:25:20 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:25:20 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:25:20 --> Utf8 Class Initialized
INFO - 2017-01-13 22:25:20 --> URI Class Initialized
INFO - 2017-01-13 22:25:20 --> Router Class Initialized
INFO - 2017-01-13 22:25:20 --> Output Class Initialized
INFO - 2017-01-13 22:25:20 --> Security Class Initialized
DEBUG - 2017-01-13 22:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:25:20 --> Input Class Initialized
INFO - 2017-01-13 22:25:20 --> Language Class Initialized
INFO - 2017-01-13 22:25:20 --> Loader Class Initialized
INFO - 2017-01-13 22:25:20 --> Database Driver Class Initialized
INFO - 2017-01-13 22:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:25:20 --> Controller Class Initialized
INFO - 2017-01-13 22:25:20 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:25:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:25:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:25:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:25:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:25:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:25:20 --> Final output sent to browser
DEBUG - 2017-01-13 22:25:20 --> Total execution time: 0.0136
INFO - 2017-01-13 22:25:20 --> Config Class Initialized
INFO - 2017-01-13 22:25:20 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:25:20 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:25:20 --> Utf8 Class Initialized
INFO - 2017-01-13 22:25:20 --> URI Class Initialized
INFO - 2017-01-13 22:25:20 --> Router Class Initialized
INFO - 2017-01-13 22:25:20 --> Output Class Initialized
INFO - 2017-01-13 22:25:20 --> Security Class Initialized
DEBUG - 2017-01-13 22:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:25:20 --> Input Class Initialized
INFO - 2017-01-13 22:25:20 --> Language Class Initialized
INFO - 2017-01-13 22:25:20 --> Loader Class Initialized
INFO - 2017-01-13 22:25:20 --> Database Driver Class Initialized
INFO - 2017-01-13 22:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:25:20 --> Controller Class Initialized
INFO - 2017-01-13 22:25:20 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:25:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:25:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:25:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:25:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:25:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:25:20 --> Final output sent to browser
DEBUG - 2017-01-13 22:25:20 --> Total execution time: 0.0139
INFO - 2017-01-13 22:26:34 --> Config Class Initialized
INFO - 2017-01-13 22:26:34 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:26:34 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:26:34 --> Utf8 Class Initialized
INFO - 2017-01-13 22:26:34 --> URI Class Initialized
DEBUG - 2017-01-13 22:26:34 --> No URI present. Default controller set.
INFO - 2017-01-13 22:26:34 --> Router Class Initialized
INFO - 2017-01-13 22:26:34 --> Output Class Initialized
INFO - 2017-01-13 22:26:34 --> Security Class Initialized
DEBUG - 2017-01-13 22:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:26:34 --> Input Class Initialized
INFO - 2017-01-13 22:26:34 --> Language Class Initialized
INFO - 2017-01-13 22:26:34 --> Loader Class Initialized
INFO - 2017-01-13 22:26:34 --> Database Driver Class Initialized
INFO - 2017-01-13 22:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:26:34 --> Controller Class Initialized
INFO - 2017-01-13 22:26:34 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:26:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:26:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:26:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 22:26:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 22:26:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:26:34 --> Final output sent to browser
DEBUG - 2017-01-13 22:26:34 --> Total execution time: 0.0173
INFO - 2017-01-13 22:27:03 --> Config Class Initialized
INFO - 2017-01-13 22:27:03 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:27:03 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:27:03 --> Utf8 Class Initialized
INFO - 2017-01-13 22:27:03 --> URI Class Initialized
INFO - 2017-01-13 22:27:03 --> Router Class Initialized
INFO - 2017-01-13 22:27:03 --> Output Class Initialized
INFO - 2017-01-13 22:27:03 --> Security Class Initialized
DEBUG - 2017-01-13 22:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:27:03 --> Input Class Initialized
INFO - 2017-01-13 22:27:03 --> Language Class Initialized
INFO - 2017-01-13 22:27:03 --> Loader Class Initialized
INFO - 2017-01-13 22:27:03 --> Database Driver Class Initialized
INFO - 2017-01-13 22:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:27:03 --> Controller Class Initialized
INFO - 2017-01-13 22:27:03 --> Helper loaded: url_helper
DEBUG - 2017-01-13 22:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:27:03 --> Config Class Initialized
INFO - 2017-01-13 22:27:03 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:27:03 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:27:03 --> Utf8 Class Initialized
INFO - 2017-01-13 22:27:03 --> URI Class Initialized
INFO - 2017-01-13 22:27:03 --> Router Class Initialized
INFO - 2017-01-13 22:27:03 --> Output Class Initialized
INFO - 2017-01-13 22:27:03 --> Security Class Initialized
DEBUG - 2017-01-13 22:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:27:03 --> Input Class Initialized
INFO - 2017-01-13 22:27:03 --> Language Class Initialized
INFO - 2017-01-13 22:27:03 --> Loader Class Initialized
INFO - 2017-01-13 22:27:03 --> Database Driver Class Initialized
INFO - 2017-01-13 22:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:27:03 --> Controller Class Initialized
INFO - 2017-01-13 22:27:03 --> Helper loaded: date_helper
DEBUG - 2017-01-13 22:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:27:03 --> Helper loaded: url_helper
INFO - 2017-01-13 22:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 22:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-13 22:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-13 22:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:27:03 --> Final output sent to browser
DEBUG - 2017-01-13 22:27:03 --> Total execution time: 0.0141
INFO - 2017-01-13 22:27:13 --> Config Class Initialized
INFO - 2017-01-13 22:27:13 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:27:13 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:27:13 --> Utf8 Class Initialized
INFO - 2017-01-13 22:27:13 --> URI Class Initialized
INFO - 2017-01-13 22:27:13 --> Router Class Initialized
INFO - 2017-01-13 22:27:13 --> Output Class Initialized
INFO - 2017-01-13 22:27:13 --> Security Class Initialized
DEBUG - 2017-01-13 22:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:27:13 --> Input Class Initialized
INFO - 2017-01-13 22:27:13 --> Language Class Initialized
INFO - 2017-01-13 22:27:13 --> Loader Class Initialized
INFO - 2017-01-13 22:27:13 --> Database Driver Class Initialized
INFO - 2017-01-13 22:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:27:13 --> Controller Class Initialized
INFO - 2017-01-13 22:27:13 --> Helper loaded: date_helper
DEBUG - 2017-01-13 22:27:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:27:13 --> Helper loaded: url_helper
INFO - 2017-01-13 22:27:13 --> Helper loaded: download_helper
INFO - 2017-01-13 22:27:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:27:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 22:27:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-13 22:27:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-13 22:27:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:27:13 --> Final output sent to browser
DEBUG - 2017-01-13 22:27:13 --> Total execution time: 0.0168
INFO - 2017-01-13 22:27:29 --> Config Class Initialized
INFO - 2017-01-13 22:27:29 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:27:29 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:27:29 --> Utf8 Class Initialized
INFO - 2017-01-13 22:27:29 --> URI Class Initialized
INFO - 2017-01-13 22:27:29 --> Router Class Initialized
INFO - 2017-01-13 22:27:29 --> Output Class Initialized
INFO - 2017-01-13 22:27:29 --> Security Class Initialized
DEBUG - 2017-01-13 22:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:27:29 --> Input Class Initialized
INFO - 2017-01-13 22:27:29 --> Language Class Initialized
INFO - 2017-01-13 22:27:29 --> Loader Class Initialized
INFO - 2017-01-13 22:27:29 --> Database Driver Class Initialized
INFO - 2017-01-13 22:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:27:29 --> Controller Class Initialized
INFO - 2017-01-13 22:27:29 --> Upload Class Initialized
INFO - 2017-01-13 22:27:29 --> Helper loaded: date_helper
DEBUG - 2017-01-13 22:27:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:27:29 --> Helper loaded: url_helper
INFO - 2017-01-13 22:27:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:27:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 22:27:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-01-13 22:27:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-01-13 22:27:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-13 22:27:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:27:29 --> Final output sent to browser
DEBUG - 2017-01-13 22:27:29 --> Total execution time: 0.0151
INFO - 2017-01-13 22:40:06 --> Config Class Initialized
INFO - 2017-01-13 22:40:06 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:40:06 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:40:06 --> Utf8 Class Initialized
INFO - 2017-01-13 22:40:06 --> URI Class Initialized
INFO - 2017-01-13 22:40:06 --> Router Class Initialized
INFO - 2017-01-13 22:40:06 --> Output Class Initialized
INFO - 2017-01-13 22:40:06 --> Security Class Initialized
DEBUG - 2017-01-13 22:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:40:06 --> Input Class Initialized
INFO - 2017-01-13 22:40:06 --> Language Class Initialized
INFO - 2017-01-13 22:40:06 --> Loader Class Initialized
INFO - 2017-01-13 22:40:06 --> Database Driver Class Initialized
INFO - 2017-01-13 22:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:40:06 --> Controller Class Initialized
INFO - 2017-01-13 22:40:06 --> Helper loaded: date_helper
DEBUG - 2017-01-13 22:40:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:40:06 --> Helper loaded: url_helper
INFO - 2017-01-13 22:40:06 --> Helper loaded: download_helper
INFO - 2017-01-13 22:40:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:40:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 22:40:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-13 22:40:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-13 22:40:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:40:06 --> Final output sent to browser
DEBUG - 2017-01-13 22:40:06 --> Total execution time: 0.0413
INFO - 2017-01-13 22:40:11 --> Config Class Initialized
INFO - 2017-01-13 22:40:11 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:40:11 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:40:11 --> Utf8 Class Initialized
INFO - 2017-01-13 22:40:11 --> URI Class Initialized
INFO - 2017-01-13 22:40:11 --> Router Class Initialized
INFO - 2017-01-13 22:40:11 --> Output Class Initialized
INFO - 2017-01-13 22:40:11 --> Security Class Initialized
DEBUG - 2017-01-13 22:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:40:11 --> Input Class Initialized
INFO - 2017-01-13 22:40:11 --> Language Class Initialized
INFO - 2017-01-13 22:40:11 --> Loader Class Initialized
INFO - 2017-01-13 22:40:11 --> Database Driver Class Initialized
INFO - 2017-01-13 22:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:40:11 --> Controller Class Initialized
INFO - 2017-01-13 22:40:11 --> Helper loaded: date_helper
DEBUG - 2017-01-13 22:40:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:40:11 --> Helper loaded: url_helper
INFO - 2017-01-13 22:40:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:40:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 22:40:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-13 22:40:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-13 22:40:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:40:11 --> Final output sent to browser
DEBUG - 2017-01-13 22:40:11 --> Total execution time: 0.0159
INFO - 2017-01-13 22:43:36 --> Config Class Initialized
INFO - 2017-01-13 22:43:36 --> Hooks Class Initialized
DEBUG - 2017-01-13 22:43:36 --> UTF-8 Support Enabled
INFO - 2017-01-13 22:43:36 --> Utf8 Class Initialized
INFO - 2017-01-13 22:43:36 --> URI Class Initialized
INFO - 2017-01-13 22:43:36 --> Router Class Initialized
INFO - 2017-01-13 22:43:36 --> Output Class Initialized
INFO - 2017-01-13 22:43:36 --> Security Class Initialized
DEBUG - 2017-01-13 22:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 22:43:36 --> Input Class Initialized
INFO - 2017-01-13 22:43:36 --> Language Class Initialized
INFO - 2017-01-13 22:43:36 --> Loader Class Initialized
INFO - 2017-01-13 22:43:36 --> Database Driver Class Initialized
INFO - 2017-01-13 22:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 22:43:36 --> Controller Class Initialized
INFO - 2017-01-13 22:43:36 --> Helper loaded: date_helper
DEBUG - 2017-01-13 22:43:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 22:43:36 --> Helper loaded: url_helper
INFO - 2017-01-13 22:43:36 --> Helper loaded: download_helper
INFO - 2017-01-13 22:43:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 22:43:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 22:43:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-13 22:43:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-13 22:43:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 22:43:36 --> Final output sent to browser
DEBUG - 2017-01-13 22:43:36 --> Total execution time: 0.0176
INFO - 2017-01-13 23:01:55 --> Config Class Initialized
INFO - 2017-01-13 23:01:55 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:01:55 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:01:55 --> Utf8 Class Initialized
INFO - 2017-01-13 23:01:55 --> URI Class Initialized
INFO - 2017-01-13 23:01:55 --> Router Class Initialized
INFO - 2017-01-13 23:01:55 --> Output Class Initialized
INFO - 2017-01-13 23:01:55 --> Security Class Initialized
DEBUG - 2017-01-13 23:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:01:55 --> Input Class Initialized
INFO - 2017-01-13 23:01:55 --> Language Class Initialized
INFO - 2017-01-13 23:01:55 --> Loader Class Initialized
INFO - 2017-01-13 23:01:55 --> Database Driver Class Initialized
INFO - 2017-01-13 23:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:01:55 --> Controller Class Initialized
INFO - 2017-01-13 23:01:55 --> Helper loaded: date_helper
DEBUG - 2017-01-13 23:01:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:01:55 --> Helper loaded: url_helper
INFO - 2017-01-13 23:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-13 23:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-13 23:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-13 23:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:01:55 --> Final output sent to browser
DEBUG - 2017-01-13 23:01:55 --> Total execution time: 0.0135
INFO - 2017-01-13 23:02:05 --> Config Class Initialized
INFO - 2017-01-13 23:02:05 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:02:05 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:02:05 --> Utf8 Class Initialized
INFO - 2017-01-13 23:02:05 --> URI Class Initialized
INFO - 2017-01-13 23:02:05 --> Router Class Initialized
INFO - 2017-01-13 23:02:05 --> Output Class Initialized
INFO - 2017-01-13 23:02:05 --> Security Class Initialized
DEBUG - 2017-01-13 23:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:02:05 --> Input Class Initialized
INFO - 2017-01-13 23:02:05 --> Language Class Initialized
INFO - 2017-01-13 23:02:05 --> Loader Class Initialized
INFO - 2017-01-13 23:02:05 --> Database Driver Class Initialized
INFO - 2017-01-13 23:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:02:05 --> Controller Class Initialized
INFO - 2017-01-13 23:02:05 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:02:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:02:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:02:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 23:02:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 23:02:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:02:05 --> Final output sent to browser
DEBUG - 2017-01-13 23:02:05 --> Total execution time: 0.0142
INFO - 2017-01-13 23:02:11 --> Config Class Initialized
INFO - 2017-01-13 23:02:11 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:02:11 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:02:11 --> Utf8 Class Initialized
INFO - 2017-01-13 23:02:11 --> URI Class Initialized
DEBUG - 2017-01-13 23:02:11 --> No URI present. Default controller set.
INFO - 2017-01-13 23:02:11 --> Router Class Initialized
INFO - 2017-01-13 23:02:11 --> Output Class Initialized
INFO - 2017-01-13 23:02:11 --> Security Class Initialized
DEBUG - 2017-01-13 23:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:02:11 --> Input Class Initialized
INFO - 2017-01-13 23:02:11 --> Language Class Initialized
INFO - 2017-01-13 23:02:11 --> Loader Class Initialized
INFO - 2017-01-13 23:02:11 --> Database Driver Class Initialized
INFO - 2017-01-13 23:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:02:11 --> Controller Class Initialized
INFO - 2017-01-13 23:02:11 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:02:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:02:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:02:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 23:02:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 23:02:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:02:11 --> Final output sent to browser
DEBUG - 2017-01-13 23:02:11 --> Total execution time: 0.0129
INFO - 2017-01-13 23:02:32 --> Config Class Initialized
INFO - 2017-01-13 23:02:32 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:02:32 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:02:32 --> Utf8 Class Initialized
INFO - 2017-01-13 23:02:32 --> URI Class Initialized
INFO - 2017-01-13 23:02:32 --> Router Class Initialized
INFO - 2017-01-13 23:02:32 --> Output Class Initialized
INFO - 2017-01-13 23:02:32 --> Security Class Initialized
DEBUG - 2017-01-13 23:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:02:32 --> Input Class Initialized
INFO - 2017-01-13 23:02:32 --> Language Class Initialized
INFO - 2017-01-13 23:02:32 --> Loader Class Initialized
INFO - 2017-01-13 23:02:32 --> Database Driver Class Initialized
INFO - 2017-01-13 23:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:02:32 --> Controller Class Initialized
INFO - 2017-01-13 23:02:32 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:02:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:02:34 --> Config Class Initialized
INFO - 2017-01-13 23:02:34 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:02:34 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:02:34 --> Utf8 Class Initialized
INFO - 2017-01-13 23:02:34 --> URI Class Initialized
INFO - 2017-01-13 23:02:34 --> Router Class Initialized
INFO - 2017-01-13 23:02:34 --> Output Class Initialized
INFO - 2017-01-13 23:02:34 --> Security Class Initialized
DEBUG - 2017-01-13 23:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:02:34 --> Input Class Initialized
INFO - 2017-01-13 23:02:34 --> Language Class Initialized
INFO - 2017-01-13 23:02:34 --> Loader Class Initialized
INFO - 2017-01-13 23:02:34 --> Database Driver Class Initialized
INFO - 2017-01-13 23:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:02:34 --> Controller Class Initialized
INFO - 2017-01-13 23:02:34 --> Helper loaded: date_helper
DEBUG - 2017-01-13 23:02:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:02:34 --> Helper loaded: url_helper
INFO - 2017-01-13 23:02:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:02:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 23:02:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-13 23:02:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-13 23:02:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:02:34 --> Final output sent to browser
DEBUG - 2017-01-13 23:02:34 --> Total execution time: 0.0145
INFO - 2017-01-13 23:02:53 --> Config Class Initialized
INFO - 2017-01-13 23:02:53 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:02:53 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:02:53 --> Utf8 Class Initialized
INFO - 2017-01-13 23:02:53 --> URI Class Initialized
INFO - 2017-01-13 23:02:53 --> Router Class Initialized
INFO - 2017-01-13 23:02:53 --> Output Class Initialized
INFO - 2017-01-13 23:02:53 --> Security Class Initialized
DEBUG - 2017-01-13 23:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:02:53 --> Input Class Initialized
INFO - 2017-01-13 23:02:53 --> Language Class Initialized
INFO - 2017-01-13 23:02:53 --> Loader Class Initialized
INFO - 2017-01-13 23:02:53 --> Database Driver Class Initialized
INFO - 2017-01-13 23:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:02:53 --> Controller Class Initialized
INFO - 2017-01-13 23:02:53 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:02:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:02:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:02:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 23:02:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 23:02:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:02:53 --> Final output sent to browser
DEBUG - 2017-01-13 23:02:53 --> Total execution time: 0.0137
INFO - 2017-01-13 23:15:13 --> Config Class Initialized
INFO - 2017-01-13 23:15:13 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:15:13 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:15:13 --> Utf8 Class Initialized
INFO - 2017-01-13 23:15:13 --> URI Class Initialized
DEBUG - 2017-01-13 23:15:13 --> No URI present. Default controller set.
INFO - 2017-01-13 23:15:13 --> Router Class Initialized
INFO - 2017-01-13 23:15:13 --> Output Class Initialized
INFO - 2017-01-13 23:15:13 --> Security Class Initialized
DEBUG - 2017-01-13 23:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:15:13 --> Input Class Initialized
INFO - 2017-01-13 23:15:13 --> Language Class Initialized
INFO - 2017-01-13 23:15:13 --> Loader Class Initialized
INFO - 2017-01-13 23:15:13 --> Database Driver Class Initialized
INFO - 2017-01-13 23:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:15:13 --> Controller Class Initialized
INFO - 2017-01-13 23:15:13 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:15:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:15:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 23:15:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 23:15:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:15:13 --> Final output sent to browser
DEBUG - 2017-01-13 23:15:13 --> Total execution time: 0.0137
INFO - 2017-01-13 23:15:14 --> Config Class Initialized
INFO - 2017-01-13 23:15:14 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:15:14 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:15:14 --> Utf8 Class Initialized
INFO - 2017-01-13 23:15:14 --> URI Class Initialized
INFO - 2017-01-13 23:15:14 --> Router Class Initialized
INFO - 2017-01-13 23:15:14 --> Output Class Initialized
INFO - 2017-01-13 23:15:14 --> Security Class Initialized
DEBUG - 2017-01-13 23:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:15:14 --> Input Class Initialized
INFO - 2017-01-13 23:15:14 --> Language Class Initialized
INFO - 2017-01-13 23:15:14 --> Loader Class Initialized
INFO - 2017-01-13 23:15:14 --> Database Driver Class Initialized
INFO - 2017-01-13 23:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:15:14 --> Controller Class Initialized
INFO - 2017-01-13 23:15:14 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:15:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:15:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:15:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 23:15:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 23:15:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:15:14 --> Final output sent to browser
DEBUG - 2017-01-13 23:15:14 --> Total execution time: 0.0183
INFO - 2017-01-13 23:15:21 --> Config Class Initialized
INFO - 2017-01-13 23:15:21 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:15:21 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:15:21 --> Utf8 Class Initialized
INFO - 2017-01-13 23:15:21 --> URI Class Initialized
INFO - 2017-01-13 23:15:21 --> Router Class Initialized
INFO - 2017-01-13 23:15:21 --> Output Class Initialized
INFO - 2017-01-13 23:15:21 --> Security Class Initialized
DEBUG - 2017-01-13 23:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:15:21 --> Input Class Initialized
INFO - 2017-01-13 23:15:21 --> Language Class Initialized
INFO - 2017-01-13 23:15:21 --> Loader Class Initialized
INFO - 2017-01-13 23:15:21 --> Database Driver Class Initialized
INFO - 2017-01-13 23:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:15:21 --> Controller Class Initialized
INFO - 2017-01-13 23:15:21 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:15:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:15:21 --> Helper loaded: form_helper
INFO - 2017-01-13 23:15:21 --> Form Validation Class Initialized
INFO - 2017-01-13 23:15:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 23:15:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-13 23:15:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 23:15:21 --> Final output sent to browser
DEBUG - 2017-01-13 23:15:21 --> Total execution time: 0.0141
INFO - 2017-01-13 23:15:22 --> Config Class Initialized
INFO - 2017-01-13 23:15:22 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:15:22 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:15:22 --> Utf8 Class Initialized
INFO - 2017-01-13 23:15:22 --> URI Class Initialized
INFO - 2017-01-13 23:15:22 --> Router Class Initialized
INFO - 2017-01-13 23:15:22 --> Output Class Initialized
INFO - 2017-01-13 23:15:22 --> Security Class Initialized
DEBUG - 2017-01-13 23:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:15:22 --> Input Class Initialized
INFO - 2017-01-13 23:15:22 --> Language Class Initialized
INFO - 2017-01-13 23:15:22 --> Loader Class Initialized
INFO - 2017-01-13 23:15:22 --> Database Driver Class Initialized
INFO - 2017-01-13 23:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:15:22 --> Controller Class Initialized
INFO - 2017-01-13 23:15:22 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:15:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:15:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:15:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 23:15:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 23:15:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:15:22 --> Final output sent to browser
DEBUG - 2017-01-13 23:15:22 --> Total execution time: 0.0204
INFO - 2017-01-13 23:15:30 --> Config Class Initialized
INFO - 2017-01-13 23:15:30 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:15:30 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:15:30 --> Utf8 Class Initialized
INFO - 2017-01-13 23:15:30 --> URI Class Initialized
INFO - 2017-01-13 23:15:30 --> Router Class Initialized
INFO - 2017-01-13 23:15:30 --> Output Class Initialized
INFO - 2017-01-13 23:15:30 --> Security Class Initialized
DEBUG - 2017-01-13 23:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:15:30 --> Input Class Initialized
INFO - 2017-01-13 23:15:30 --> Language Class Initialized
INFO - 2017-01-13 23:15:30 --> Loader Class Initialized
INFO - 2017-01-13 23:15:30 --> Database Driver Class Initialized
INFO - 2017-01-13 23:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:15:30 --> Controller Class Initialized
INFO - 2017-01-13 23:15:30 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:15:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:15:30 --> Helper loaded: form_helper
INFO - 2017-01-13 23:15:30 --> Form Validation Class Initialized
INFO - 2017-01-13 23:15:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-13 23:15:30 --> Config Class Initialized
INFO - 2017-01-13 23:15:30 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:15:30 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:15:30 --> Utf8 Class Initialized
INFO - 2017-01-13 23:15:30 --> URI Class Initialized
INFO - 2017-01-13 23:15:30 --> Router Class Initialized
INFO - 2017-01-13 23:15:30 --> Output Class Initialized
INFO - 2017-01-13 23:15:30 --> Security Class Initialized
DEBUG - 2017-01-13 23:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:15:30 --> Input Class Initialized
INFO - 2017-01-13 23:15:30 --> Language Class Initialized
INFO - 2017-01-13 23:15:30 --> Loader Class Initialized
INFO - 2017-01-13 23:15:30 --> Database Driver Class Initialized
INFO - 2017-01-13 23:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:15:30 --> Controller Class Initialized
INFO - 2017-01-13 23:15:30 --> Helper loaded: date_helper
INFO - 2017-01-13 23:15:30 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:15:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:15:30 --> Helper loaded: form_helper
INFO - 2017-01-13 23:15:30 --> Form Validation Class Initialized
INFO - 2017-01-13 23:15:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 23:15:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 23:15:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-13 23:15:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-13 23:15:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 23:15:30 --> Final output sent to browser
DEBUG - 2017-01-13 23:15:30 --> Total execution time: 0.0544
INFO - 2017-01-13 23:15:30 --> Config Class Initialized
INFO - 2017-01-13 23:15:30 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:15:30 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:15:30 --> Utf8 Class Initialized
INFO - 2017-01-13 23:15:30 --> URI Class Initialized
INFO - 2017-01-13 23:15:30 --> Router Class Initialized
INFO - 2017-01-13 23:15:30 --> Output Class Initialized
INFO - 2017-01-13 23:15:30 --> Security Class Initialized
DEBUG - 2017-01-13 23:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:15:30 --> Input Class Initialized
INFO - 2017-01-13 23:15:30 --> Language Class Initialized
INFO - 2017-01-13 23:15:30 --> Loader Class Initialized
INFO - 2017-01-13 23:15:30 --> Database Driver Class Initialized
INFO - 2017-01-13 23:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:15:30 --> Controller Class Initialized
INFO - 2017-01-13 23:15:30 --> Helper loaded: date_helper
INFO - 2017-01-13 23:15:30 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:15:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:15:30 --> Helper loaded: form_helper
INFO - 2017-01-13 23:15:30 --> Form Validation Class Initialized
INFO - 2017-01-13 23:15:30 --> Final output sent to browser
DEBUG - 2017-01-13 23:15:30 --> Total execution time: 0.0890
INFO - 2017-01-13 23:15:30 --> Config Class Initialized
INFO - 2017-01-13 23:15:30 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:15:30 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:15:30 --> Utf8 Class Initialized
INFO - 2017-01-13 23:15:30 --> URI Class Initialized
INFO - 2017-01-13 23:15:30 --> Router Class Initialized
INFO - 2017-01-13 23:15:30 --> Output Class Initialized
INFO - 2017-01-13 23:15:30 --> Security Class Initialized
DEBUG - 2017-01-13 23:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:15:30 --> Input Class Initialized
INFO - 2017-01-13 23:15:30 --> Language Class Initialized
INFO - 2017-01-13 23:15:30 --> Loader Class Initialized
INFO - 2017-01-13 23:15:30 --> Database Driver Class Initialized
INFO - 2017-01-13 23:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:15:30 --> Controller Class Initialized
INFO - 2017-01-13 23:15:30 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:15:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:15:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:15:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 23:15:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 23:15:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:15:30 --> Final output sent to browser
DEBUG - 2017-01-13 23:15:30 --> Total execution time: 0.0770
INFO - 2017-01-13 23:15:35 --> Config Class Initialized
INFO - 2017-01-13 23:15:35 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:15:35 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:15:35 --> Utf8 Class Initialized
INFO - 2017-01-13 23:15:35 --> URI Class Initialized
INFO - 2017-01-13 23:15:35 --> Router Class Initialized
INFO - 2017-01-13 23:15:35 --> Output Class Initialized
INFO - 2017-01-13 23:15:35 --> Security Class Initialized
DEBUG - 2017-01-13 23:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:15:35 --> Input Class Initialized
INFO - 2017-01-13 23:15:35 --> Language Class Initialized
INFO - 2017-01-13 23:15:35 --> Loader Class Initialized
INFO - 2017-01-13 23:15:36 --> Database Driver Class Initialized
INFO - 2017-01-13 23:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:15:36 --> Controller Class Initialized
INFO - 2017-01-13 23:15:36 --> Upload Class Initialized
INFO - 2017-01-13 23:15:36 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:15:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:15:36 --> Helper loaded: form_helper
INFO - 2017-01-13 23:15:36 --> Form Validation Class Initialized
INFO - 2017-01-13 23:15:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 23:15:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 23:15:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-13 23:15:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-13 23:15:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-13 23:15:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 23:15:36 --> Final output sent to browser
DEBUG - 2017-01-13 23:15:36 --> Total execution time: 0.0171
INFO - 2017-01-13 23:15:36 --> Config Class Initialized
INFO - 2017-01-13 23:15:36 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:15:36 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:15:36 --> Utf8 Class Initialized
INFO - 2017-01-13 23:15:36 --> URI Class Initialized
INFO - 2017-01-13 23:15:36 --> Router Class Initialized
INFO - 2017-01-13 23:15:36 --> Output Class Initialized
INFO - 2017-01-13 23:15:36 --> Security Class Initialized
DEBUG - 2017-01-13 23:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:15:36 --> Input Class Initialized
INFO - 2017-01-13 23:15:36 --> Language Class Initialized
INFO - 2017-01-13 23:15:36 --> Loader Class Initialized
INFO - 2017-01-13 23:15:36 --> Database Driver Class Initialized
INFO - 2017-01-13 23:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:15:36 --> Controller Class Initialized
INFO - 2017-01-13 23:15:36 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:15:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:15:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:15:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 23:15:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 23:15:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:15:36 --> Final output sent to browser
DEBUG - 2017-01-13 23:15:36 --> Total execution time: 0.0141
INFO - 2017-01-13 23:17:12 --> Config Class Initialized
INFO - 2017-01-13 23:17:12 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:17:12 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:17:12 --> Utf8 Class Initialized
INFO - 2017-01-13 23:17:12 --> URI Class Initialized
INFO - 2017-01-13 23:17:12 --> Router Class Initialized
INFO - 2017-01-13 23:17:12 --> Output Class Initialized
INFO - 2017-01-13 23:17:12 --> Security Class Initialized
DEBUG - 2017-01-13 23:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:17:12 --> Input Class Initialized
INFO - 2017-01-13 23:17:12 --> Language Class Initialized
INFO - 2017-01-13 23:17:12 --> Loader Class Initialized
INFO - 2017-01-13 23:17:12 --> Database Driver Class Initialized
INFO - 2017-01-13 23:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:17:12 --> Controller Class Initialized
INFO - 2017-01-13 23:17:12 --> Upload Class Initialized
INFO - 2017-01-13 23:17:12 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:17:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:17:12 --> Helper loaded: form_helper
INFO - 2017-01-13 23:17:12 --> Form Validation Class Initialized
INFO - 2017-01-13 23:17:12 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 23:17:12 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 23:17:12 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-13 23:17:12 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-13 23:17:12 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-13 23:17:12 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 23:17:12 --> Final output sent to browser
DEBUG - 2017-01-13 23:17:12 --> Total execution time: 0.0163
INFO - 2017-01-13 23:17:12 --> Config Class Initialized
INFO - 2017-01-13 23:17:12 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:17:12 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:17:12 --> Utf8 Class Initialized
INFO - 2017-01-13 23:17:12 --> URI Class Initialized
INFO - 2017-01-13 23:17:12 --> Router Class Initialized
INFO - 2017-01-13 23:17:12 --> Output Class Initialized
INFO - 2017-01-13 23:17:12 --> Security Class Initialized
DEBUG - 2017-01-13 23:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:17:12 --> Input Class Initialized
INFO - 2017-01-13 23:17:12 --> Language Class Initialized
INFO - 2017-01-13 23:17:12 --> Loader Class Initialized
INFO - 2017-01-13 23:17:12 --> Database Driver Class Initialized
INFO - 2017-01-13 23:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:17:12 --> Controller Class Initialized
INFO - 2017-01-13 23:17:12 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:17:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:17:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:17:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 23:17:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 23:17:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:17:12 --> Final output sent to browser
DEBUG - 2017-01-13 23:17:12 --> Total execution time: 0.0132
INFO - 2017-01-13 23:17:18 --> Config Class Initialized
INFO - 2017-01-13 23:17:18 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:17:18 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:17:18 --> Utf8 Class Initialized
INFO - 2017-01-13 23:17:18 --> URI Class Initialized
INFO - 2017-01-13 23:17:18 --> Router Class Initialized
INFO - 2017-01-13 23:17:18 --> Output Class Initialized
INFO - 2017-01-13 23:17:18 --> Security Class Initialized
DEBUG - 2017-01-13 23:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:17:18 --> Input Class Initialized
INFO - 2017-01-13 23:17:18 --> Language Class Initialized
INFO - 2017-01-13 23:17:18 --> Loader Class Initialized
INFO - 2017-01-13 23:17:18 --> Database Driver Class Initialized
INFO - 2017-01-13 23:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:17:18 --> Controller Class Initialized
INFO - 2017-01-13 23:17:18 --> Upload Class Initialized
INFO - 2017-01-13 23:17:18 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:17:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:17:18 --> Helper loaded: form_helper
INFO - 2017-01-13 23:17:18 --> Form Validation Class Initialized
INFO - 2017-01-13 23:17:18 --> Final output sent to browser
DEBUG - 2017-01-13 23:17:18 --> Total execution time: 0.0151
INFO - 2017-01-13 23:17:40 --> Config Class Initialized
INFO - 2017-01-13 23:17:40 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:17:40 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:17:40 --> Utf8 Class Initialized
INFO - 2017-01-13 23:17:40 --> URI Class Initialized
INFO - 2017-01-13 23:17:40 --> Router Class Initialized
INFO - 2017-01-13 23:17:40 --> Output Class Initialized
INFO - 2017-01-13 23:17:40 --> Security Class Initialized
DEBUG - 2017-01-13 23:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:17:40 --> Input Class Initialized
INFO - 2017-01-13 23:17:40 --> Language Class Initialized
INFO - 2017-01-13 23:17:40 --> Loader Class Initialized
INFO - 2017-01-13 23:17:40 --> Database Driver Class Initialized
INFO - 2017-01-13 23:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:17:40 --> Controller Class Initialized
INFO - 2017-01-13 23:17:40 --> Upload Class Initialized
INFO - 2017-01-13 23:17:40 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:17:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:17:40 --> Helper loaded: form_helper
INFO - 2017-01-13 23:17:40 --> Form Validation Class Initialized
INFO - 2017-01-13 23:17:40 --> Final output sent to browser
DEBUG - 2017-01-13 23:17:40 --> Total execution time: 0.0149
INFO - 2017-01-13 23:17:43 --> Config Class Initialized
INFO - 2017-01-13 23:17:43 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:17:43 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:17:43 --> Utf8 Class Initialized
INFO - 2017-01-13 23:17:43 --> URI Class Initialized
INFO - 2017-01-13 23:17:43 --> Router Class Initialized
INFO - 2017-01-13 23:17:43 --> Output Class Initialized
INFO - 2017-01-13 23:17:43 --> Security Class Initialized
DEBUG - 2017-01-13 23:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:17:43 --> Input Class Initialized
INFO - 2017-01-13 23:17:43 --> Language Class Initialized
INFO - 2017-01-13 23:17:43 --> Loader Class Initialized
INFO - 2017-01-13 23:17:43 --> Database Driver Class Initialized
INFO - 2017-01-13 23:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:17:43 --> Controller Class Initialized
INFO - 2017-01-13 23:17:43 --> Upload Class Initialized
INFO - 2017-01-13 23:17:43 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:17:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:17:43 --> Helper loaded: form_helper
INFO - 2017-01-13 23:17:43 --> Form Validation Class Initialized
INFO - 2017-01-13 23:17:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 23:17:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 23:17:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-13 23:17:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-13 23:17:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-13 23:17:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 23:17:43 --> Final output sent to browser
DEBUG - 2017-01-13 23:17:43 --> Total execution time: 0.0159
INFO - 2017-01-13 23:17:43 --> Config Class Initialized
INFO - 2017-01-13 23:17:43 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:17:43 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:17:43 --> Utf8 Class Initialized
INFO - 2017-01-13 23:17:43 --> URI Class Initialized
INFO - 2017-01-13 23:17:43 --> Router Class Initialized
INFO - 2017-01-13 23:17:43 --> Output Class Initialized
INFO - 2017-01-13 23:17:43 --> Security Class Initialized
DEBUG - 2017-01-13 23:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:17:43 --> Input Class Initialized
INFO - 2017-01-13 23:17:43 --> Language Class Initialized
INFO - 2017-01-13 23:17:43 --> Loader Class Initialized
INFO - 2017-01-13 23:17:43 --> Database Driver Class Initialized
INFO - 2017-01-13 23:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:17:43 --> Controller Class Initialized
INFO - 2017-01-13 23:17:43 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:17:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 23:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 23:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:17:43 --> Final output sent to browser
DEBUG - 2017-01-13 23:17:43 --> Total execution time: 0.0142
INFO - 2017-01-13 23:17:57 --> Config Class Initialized
INFO - 2017-01-13 23:17:57 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:17:57 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:17:57 --> Utf8 Class Initialized
INFO - 2017-01-13 23:17:57 --> URI Class Initialized
INFO - 2017-01-13 23:17:57 --> Router Class Initialized
INFO - 2017-01-13 23:17:57 --> Output Class Initialized
INFO - 2017-01-13 23:17:57 --> Security Class Initialized
DEBUG - 2017-01-13 23:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:17:57 --> Input Class Initialized
INFO - 2017-01-13 23:17:57 --> Language Class Initialized
INFO - 2017-01-13 23:17:57 --> Loader Class Initialized
INFO - 2017-01-13 23:17:57 --> Database Driver Class Initialized
INFO - 2017-01-13 23:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:17:57 --> Controller Class Initialized
INFO - 2017-01-13 23:17:57 --> Upload Class Initialized
INFO - 2017-01-13 23:17:57 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:17:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:17:57 --> Helper loaded: form_helper
INFO - 2017-01-13 23:17:57 --> Form Validation Class Initialized
INFO - 2017-01-13 23:17:57 --> Final output sent to browser
DEBUG - 2017-01-13 23:17:57 --> Total execution time: 0.0163
INFO - 2017-01-13 23:31:08 --> Config Class Initialized
INFO - 2017-01-13 23:31:08 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:31:08 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:31:08 --> Utf8 Class Initialized
INFO - 2017-01-13 23:31:08 --> URI Class Initialized
INFO - 2017-01-13 23:31:08 --> Router Class Initialized
INFO - 2017-01-13 23:31:08 --> Output Class Initialized
INFO - 2017-01-13 23:31:08 --> Security Class Initialized
DEBUG - 2017-01-13 23:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:31:08 --> Input Class Initialized
INFO - 2017-01-13 23:31:08 --> Language Class Initialized
INFO - 2017-01-13 23:31:08 --> Loader Class Initialized
INFO - 2017-01-13 23:31:08 --> Database Driver Class Initialized
INFO - 2017-01-13 23:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:31:08 --> Controller Class Initialized
INFO - 2017-01-13 23:31:08 --> Upload Class Initialized
INFO - 2017-01-13 23:31:08 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:31:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:31:08 --> Helper loaded: form_helper
INFO - 2017-01-13 23:31:08 --> Form Validation Class Initialized
INFO - 2017-01-13 23:31:08 --> Language file loaded: language/english/upload_lang.php
INFO - 2017-01-13 23:31:08 --> The file you are attempting to upload is larger than the permitted size.
INFO - 2017-01-13 23:31:08 --> Final output sent to browser
DEBUG - 2017-01-13 23:31:08 --> Total execution time: 0.0905
INFO - 2017-01-13 23:31:09 --> Config Class Initialized
INFO - 2017-01-13 23:31:09 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:31:09 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:31:09 --> Utf8 Class Initialized
INFO - 2017-01-13 23:31:09 --> URI Class Initialized
INFO - 2017-01-13 23:31:09 --> Router Class Initialized
INFO - 2017-01-13 23:31:09 --> Output Class Initialized
INFO - 2017-01-13 23:31:09 --> Security Class Initialized
DEBUG - 2017-01-13 23:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:31:09 --> Input Class Initialized
INFO - 2017-01-13 23:31:09 --> Language Class Initialized
INFO - 2017-01-13 23:31:09 --> Loader Class Initialized
INFO - 2017-01-13 23:31:09 --> Database Driver Class Initialized
INFO - 2017-01-13 23:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:31:09 --> Controller Class Initialized
INFO - 2017-01-13 23:31:09 --> Upload Class Initialized
INFO - 2017-01-13 23:31:09 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:31:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:31:09 --> Helper loaded: form_helper
INFO - 2017-01-13 23:31:09 --> Form Validation Class Initialized
INFO - 2017-01-13 23:31:09 --> Language file loaded: language/english/upload_lang.php
INFO - 2017-01-13 23:31:09 --> The file you are attempting to upload is larger than the permitted size.
INFO - 2017-01-13 23:31:09 --> Final output sent to browser
DEBUG - 2017-01-13 23:31:09 --> Total execution time: 0.0273
INFO - 2017-01-13 23:31:09 --> Config Class Initialized
INFO - 2017-01-13 23:31:09 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:31:09 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:31:09 --> Utf8 Class Initialized
INFO - 2017-01-13 23:31:09 --> URI Class Initialized
INFO - 2017-01-13 23:31:09 --> Router Class Initialized
INFO - 2017-01-13 23:31:09 --> Output Class Initialized
INFO - 2017-01-13 23:31:09 --> Security Class Initialized
DEBUG - 2017-01-13 23:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:31:09 --> Input Class Initialized
INFO - 2017-01-13 23:31:09 --> Language Class Initialized
INFO - 2017-01-13 23:31:09 --> Loader Class Initialized
INFO - 2017-01-13 23:31:09 --> Database Driver Class Initialized
INFO - 2017-01-13 23:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:31:09 --> Controller Class Initialized
INFO - 2017-01-13 23:31:09 --> Upload Class Initialized
INFO - 2017-01-13 23:31:09 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:31:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:31:09 --> Helper loaded: form_helper
INFO - 2017-01-13 23:31:09 --> Form Validation Class Initialized
INFO - 2017-01-13 23:31:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-13 23:31:09 --> Final output sent to browser
DEBUG - 2017-01-13 23:31:09 --> Total execution time: 0.0163
INFO - 2017-01-13 23:31:09 --> Config Class Initialized
INFO - 2017-01-13 23:31:09 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:31:09 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:31:09 --> Utf8 Class Initialized
INFO - 2017-01-13 23:31:09 --> URI Class Initialized
INFO - 2017-01-13 23:31:09 --> Router Class Initialized
INFO - 2017-01-13 23:31:09 --> Output Class Initialized
INFO - 2017-01-13 23:31:09 --> Security Class Initialized
DEBUG - 2017-01-13 23:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:31:09 --> Input Class Initialized
INFO - 2017-01-13 23:31:09 --> Language Class Initialized
INFO - 2017-01-13 23:31:09 --> Loader Class Initialized
INFO - 2017-01-13 23:31:09 --> Database Driver Class Initialized
INFO - 2017-01-13 23:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:31:09 --> Controller Class Initialized
INFO - 2017-01-13 23:31:09 --> Upload Class Initialized
INFO - 2017-01-13 23:31:09 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:31:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:31:09 --> Helper loaded: form_helper
INFO - 2017-01-13 23:31:09 --> Form Validation Class Initialized
INFO - 2017-01-13 23:31:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-13 23:31:09 --> Final output sent to browser
DEBUG - 2017-01-13 23:31:09 --> Total execution time: 0.0164
INFO - 2017-01-13 23:31:49 --> Config Class Initialized
INFO - 2017-01-13 23:31:49 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:31:49 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:31:49 --> Utf8 Class Initialized
INFO - 2017-01-13 23:31:49 --> URI Class Initialized
INFO - 2017-01-13 23:31:49 --> Router Class Initialized
INFO - 2017-01-13 23:31:49 --> Output Class Initialized
INFO - 2017-01-13 23:31:49 --> Security Class Initialized
DEBUG - 2017-01-13 23:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:31:49 --> Input Class Initialized
INFO - 2017-01-13 23:31:49 --> Language Class Initialized
INFO - 2017-01-13 23:31:49 --> Loader Class Initialized
INFO - 2017-01-13 23:31:49 --> Database Driver Class Initialized
INFO - 2017-01-13 23:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:31:49 --> Controller Class Initialized
INFO - 2017-01-13 23:31:49 --> Upload Class Initialized
INFO - 2017-01-13 23:31:49 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:31:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:31:49 --> Helper loaded: form_helper
INFO - 2017-01-13 23:31:49 --> Form Validation Class Initialized
INFO - 2017-01-13 23:31:49 --> Final output sent to browser
DEBUG - 2017-01-13 23:31:49 --> Total execution time: 0.0156
INFO - 2017-01-13 23:31:56 --> Config Class Initialized
INFO - 2017-01-13 23:31:56 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:31:56 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:31:56 --> Utf8 Class Initialized
INFO - 2017-01-13 23:31:56 --> URI Class Initialized
INFO - 2017-01-13 23:31:56 --> Router Class Initialized
INFO - 2017-01-13 23:31:56 --> Output Class Initialized
INFO - 2017-01-13 23:31:56 --> Security Class Initialized
DEBUG - 2017-01-13 23:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:31:56 --> Input Class Initialized
INFO - 2017-01-13 23:31:56 --> Language Class Initialized
INFO - 2017-01-13 23:31:56 --> Loader Class Initialized
INFO - 2017-01-13 23:31:56 --> Database Driver Class Initialized
INFO - 2017-01-13 23:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:31:56 --> Controller Class Initialized
INFO - 2017-01-13 23:31:56 --> Upload Class Initialized
INFO - 2017-01-13 23:31:56 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:31:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:31:56 --> Helper loaded: form_helper
INFO - 2017-01-13 23:31:56 --> Form Validation Class Initialized
INFO - 2017-01-13 23:31:56 --> Final output sent to browser
DEBUG - 2017-01-13 23:31:56 --> Total execution time: 0.0151
INFO - 2017-01-13 23:32:42 --> Config Class Initialized
INFO - 2017-01-13 23:32:42 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:32:42 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:32:42 --> Utf8 Class Initialized
INFO - 2017-01-13 23:32:42 --> URI Class Initialized
INFO - 2017-01-13 23:32:42 --> Router Class Initialized
INFO - 2017-01-13 23:32:42 --> Output Class Initialized
INFO - 2017-01-13 23:32:42 --> Security Class Initialized
DEBUG - 2017-01-13 23:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:32:42 --> Input Class Initialized
INFO - 2017-01-13 23:32:42 --> Language Class Initialized
INFO - 2017-01-13 23:32:42 --> Loader Class Initialized
INFO - 2017-01-13 23:32:42 --> Database Driver Class Initialized
INFO - 2017-01-13 23:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:32:42 --> Controller Class Initialized
INFO - 2017-01-13 23:32:42 --> Upload Class Initialized
INFO - 2017-01-13 23:32:42 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:32:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:32:42 --> Helper loaded: form_helper
INFO - 2017-01-13 23:32:42 --> Form Validation Class Initialized
INFO - 2017-01-13 23:32:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 23:32:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 23:32:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-13 23:32:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-13 23:32:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-13 23:32:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 23:32:42 --> Final output sent to browser
DEBUG - 2017-01-13 23:32:42 --> Total execution time: 0.0204
INFO - 2017-01-13 23:32:42 --> Config Class Initialized
INFO - 2017-01-13 23:32:42 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:32:42 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:32:42 --> Utf8 Class Initialized
INFO - 2017-01-13 23:32:42 --> URI Class Initialized
INFO - 2017-01-13 23:32:42 --> Router Class Initialized
INFO - 2017-01-13 23:32:42 --> Output Class Initialized
INFO - 2017-01-13 23:32:42 --> Security Class Initialized
DEBUG - 2017-01-13 23:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:32:42 --> Input Class Initialized
INFO - 2017-01-13 23:32:42 --> Language Class Initialized
INFO - 2017-01-13 23:32:42 --> Loader Class Initialized
INFO - 2017-01-13 23:32:42 --> Database Driver Class Initialized
INFO - 2017-01-13 23:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:32:42 --> Controller Class Initialized
INFO - 2017-01-13 23:32:42 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:32:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:32:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:32:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 23:32:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 23:32:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:32:42 --> Final output sent to browser
DEBUG - 2017-01-13 23:32:42 --> Total execution time: 0.0511
INFO - 2017-01-13 23:32:43 --> Config Class Initialized
INFO - 2017-01-13 23:32:43 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:32:43 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:32:43 --> Utf8 Class Initialized
INFO - 2017-01-13 23:32:43 --> URI Class Initialized
INFO - 2017-01-13 23:32:43 --> Router Class Initialized
INFO - 2017-01-13 23:32:43 --> Output Class Initialized
INFO - 2017-01-13 23:32:43 --> Security Class Initialized
DEBUG - 2017-01-13 23:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:32:43 --> Input Class Initialized
INFO - 2017-01-13 23:32:43 --> Language Class Initialized
INFO - 2017-01-13 23:32:43 --> Loader Class Initialized
INFO - 2017-01-13 23:32:43 --> Database Driver Class Initialized
INFO - 2017-01-13 23:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:32:43 --> Controller Class Initialized
INFO - 2017-01-13 23:32:43 --> Upload Class Initialized
INFO - 2017-01-13 23:32:43 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:32:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:32:43 --> Helper loaded: form_helper
INFO - 2017-01-13 23:32:43 --> Form Validation Class Initialized
INFO - 2017-01-13 23:32:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 23:32:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 23:32:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-13 23:32:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-13 23:32:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-13 23:32:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 23:32:43 --> Final output sent to browser
DEBUG - 2017-01-13 23:32:43 --> Total execution time: 0.0226
INFO - 2017-01-13 23:32:43 --> Config Class Initialized
INFO - 2017-01-13 23:32:43 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:32:43 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:32:43 --> Utf8 Class Initialized
INFO - 2017-01-13 23:32:43 --> URI Class Initialized
INFO - 2017-01-13 23:32:43 --> Router Class Initialized
INFO - 2017-01-13 23:32:43 --> Output Class Initialized
INFO - 2017-01-13 23:32:43 --> Security Class Initialized
DEBUG - 2017-01-13 23:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:32:43 --> Input Class Initialized
INFO - 2017-01-13 23:32:43 --> Language Class Initialized
INFO - 2017-01-13 23:32:43 --> Loader Class Initialized
INFO - 2017-01-13 23:32:43 --> Database Driver Class Initialized
INFO - 2017-01-13 23:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:32:43 --> Controller Class Initialized
INFO - 2017-01-13 23:32:43 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:32:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:32:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:32:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 23:32:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 23:32:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:32:43 --> Final output sent to browser
DEBUG - 2017-01-13 23:32:43 --> Total execution time: 0.0138
INFO - 2017-01-13 23:36:11 --> Config Class Initialized
INFO - 2017-01-13 23:36:11 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:36:11 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:36:11 --> Utf8 Class Initialized
INFO - 2017-01-13 23:36:11 --> URI Class Initialized
INFO - 2017-01-13 23:36:11 --> Router Class Initialized
INFO - 2017-01-13 23:36:11 --> Output Class Initialized
INFO - 2017-01-13 23:36:11 --> Security Class Initialized
DEBUG - 2017-01-13 23:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:36:11 --> Input Class Initialized
INFO - 2017-01-13 23:36:11 --> Language Class Initialized
INFO - 2017-01-13 23:36:11 --> Loader Class Initialized
INFO - 2017-01-13 23:36:11 --> Database Driver Class Initialized
INFO - 2017-01-13 23:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:36:11 --> Controller Class Initialized
INFO - 2017-01-13 23:36:11 --> Upload Class Initialized
INFO - 2017-01-13 23:36:11 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:36:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:36:11 --> Helper loaded: form_helper
INFO - 2017-01-13 23:36:11 --> Form Validation Class Initialized
INFO - 2017-01-13 23:36:11 --> Language file loaded: language/english/upload_lang.php
INFO - 2017-01-13 23:36:11 --> The file you are attempting to upload is larger than the permitted size.
INFO - 2017-01-13 23:36:11 --> Final output sent to browser
DEBUG - 2017-01-13 23:36:11 --> Total execution time: 0.0162
INFO - 2017-01-13 23:36:11 --> Config Class Initialized
INFO - 2017-01-13 23:36:11 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:36:11 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:36:11 --> Utf8 Class Initialized
INFO - 2017-01-13 23:36:11 --> URI Class Initialized
INFO - 2017-01-13 23:36:11 --> Router Class Initialized
INFO - 2017-01-13 23:36:11 --> Output Class Initialized
INFO - 2017-01-13 23:36:11 --> Security Class Initialized
DEBUG - 2017-01-13 23:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:36:11 --> Input Class Initialized
INFO - 2017-01-13 23:36:11 --> Language Class Initialized
INFO - 2017-01-13 23:36:11 --> Loader Class Initialized
INFO - 2017-01-13 23:36:11 --> Database Driver Class Initialized
INFO - 2017-01-13 23:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:36:11 --> Controller Class Initialized
INFO - 2017-01-13 23:36:11 --> Upload Class Initialized
INFO - 2017-01-13 23:36:11 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:36:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:36:11 --> Helper loaded: form_helper
INFO - 2017-01-13 23:36:11 --> Form Validation Class Initialized
INFO - 2017-01-13 23:36:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-13 23:36:11 --> Final output sent to browser
DEBUG - 2017-01-13 23:36:11 --> Total execution time: 0.0167
INFO - 2017-01-13 23:37:15 --> Config Class Initialized
INFO - 2017-01-13 23:37:15 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:37:15 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:37:15 --> Utf8 Class Initialized
INFO - 2017-01-13 23:37:15 --> URI Class Initialized
INFO - 2017-01-13 23:37:15 --> Router Class Initialized
INFO - 2017-01-13 23:37:15 --> Output Class Initialized
INFO - 2017-01-13 23:37:15 --> Security Class Initialized
DEBUG - 2017-01-13 23:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:37:15 --> Input Class Initialized
INFO - 2017-01-13 23:37:15 --> Language Class Initialized
INFO - 2017-01-13 23:37:15 --> Loader Class Initialized
INFO - 2017-01-13 23:37:15 --> Database Driver Class Initialized
INFO - 2017-01-13 23:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:37:15 --> Controller Class Initialized
INFO - 2017-01-13 23:37:15 --> Upload Class Initialized
INFO - 2017-01-13 23:37:15 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:37:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:37:15 --> Helper loaded: form_helper
INFO - 2017-01-13 23:37:15 --> Form Validation Class Initialized
INFO - 2017-01-13 23:37:15 --> Final output sent to browser
DEBUG - 2017-01-13 23:37:15 --> Total execution time: 0.0144
INFO - 2017-01-13 23:37:15 --> Config Class Initialized
INFO - 2017-01-13 23:37:15 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:37:15 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:37:15 --> Utf8 Class Initialized
INFO - 2017-01-13 23:37:15 --> URI Class Initialized
INFO - 2017-01-13 23:37:15 --> Router Class Initialized
INFO - 2017-01-13 23:37:15 --> Output Class Initialized
INFO - 2017-01-13 23:37:15 --> Security Class Initialized
DEBUG - 2017-01-13 23:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:37:15 --> Input Class Initialized
INFO - 2017-01-13 23:37:15 --> Language Class Initialized
INFO - 2017-01-13 23:37:15 --> Loader Class Initialized
INFO - 2017-01-13 23:37:15 --> Database Driver Class Initialized
INFO - 2017-01-13 23:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:37:15 --> Controller Class Initialized
INFO - 2017-01-13 23:37:15 --> Upload Class Initialized
INFO - 2017-01-13 23:37:15 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:37:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:37:15 --> Helper loaded: form_helper
INFO - 2017-01-13 23:37:15 --> Form Validation Class Initialized
INFO - 2017-01-13 23:37:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-13 23:37:15 --> Final output sent to browser
DEBUG - 2017-01-13 23:37:15 --> Total execution time: 0.0144
INFO - 2017-01-13 23:38:09 --> Config Class Initialized
INFO - 2017-01-13 23:38:09 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:38:09 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:38:09 --> Utf8 Class Initialized
INFO - 2017-01-13 23:38:09 --> URI Class Initialized
INFO - 2017-01-13 23:38:09 --> Router Class Initialized
INFO - 2017-01-13 23:38:09 --> Output Class Initialized
INFO - 2017-01-13 23:38:09 --> Security Class Initialized
DEBUG - 2017-01-13 23:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:38:09 --> Input Class Initialized
INFO - 2017-01-13 23:38:09 --> Language Class Initialized
INFO - 2017-01-13 23:38:09 --> Loader Class Initialized
INFO - 2017-01-13 23:38:09 --> Database Driver Class Initialized
INFO - 2017-01-13 23:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:38:09 --> Controller Class Initialized
INFO - 2017-01-13 23:38:09 --> Helper loaded: date_helper
DEBUG - 2017-01-13 23:38:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:38:09 --> Helper loaded: url_helper
INFO - 2017-01-13 23:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-13 23:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 23:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-13 23:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-13 23:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:38:09 --> Final output sent to browser
DEBUG - 2017-01-13 23:38:09 --> Total execution time: 0.0163
INFO - 2017-01-13 23:38:22 --> Config Class Initialized
INFO - 2017-01-13 23:38:22 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:38:22 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:38:22 --> Utf8 Class Initialized
INFO - 2017-01-13 23:38:22 --> URI Class Initialized
INFO - 2017-01-13 23:38:22 --> Router Class Initialized
INFO - 2017-01-13 23:38:22 --> Output Class Initialized
INFO - 2017-01-13 23:38:22 --> Security Class Initialized
DEBUG - 2017-01-13 23:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:38:22 --> Input Class Initialized
INFO - 2017-01-13 23:38:22 --> Language Class Initialized
INFO - 2017-01-13 23:38:22 --> Loader Class Initialized
INFO - 2017-01-13 23:38:22 --> Database Driver Class Initialized
INFO - 2017-01-13 23:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:38:22 --> Controller Class Initialized
INFO - 2017-01-13 23:38:22 --> Helper loaded: date_helper
DEBUG - 2017-01-13 23:38:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:38:22 --> Helper loaded: url_helper
INFO - 2017-01-13 23:38:22 --> Helper loaded: download_helper
INFO - 2017-01-13 23:38:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:38:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 23:38:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-13 23:38:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-13 23:38:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:38:22 --> Final output sent to browser
DEBUG - 2017-01-13 23:38:22 --> Total execution time: 0.0171
INFO - 2017-01-13 23:38:31 --> Config Class Initialized
INFO - 2017-01-13 23:38:31 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:38:31 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:38:31 --> Utf8 Class Initialized
INFO - 2017-01-13 23:38:31 --> URI Class Initialized
INFO - 2017-01-13 23:38:31 --> Router Class Initialized
INFO - 2017-01-13 23:38:31 --> Output Class Initialized
INFO - 2017-01-13 23:38:31 --> Security Class Initialized
DEBUG - 2017-01-13 23:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:38:31 --> Input Class Initialized
INFO - 2017-01-13 23:38:31 --> Language Class Initialized
INFO - 2017-01-13 23:38:31 --> Loader Class Initialized
INFO - 2017-01-13 23:38:31 --> Database Driver Class Initialized
INFO - 2017-01-13 23:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:38:31 --> Controller Class Initialized
INFO - 2017-01-13 23:38:31 --> Helper loaded: date_helper
DEBUG - 2017-01-13 23:38:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:38:31 --> Helper loaded: url_helper
INFO - 2017-01-13 23:38:31 --> Helper loaded: download_helper
INFO - 2017-01-13 23:38:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:38:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 23:38:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-13 23:38:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-13 23:38:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:38:31 --> Final output sent to browser
DEBUG - 2017-01-13 23:38:31 --> Total execution time: 0.0179
INFO - 2017-01-13 23:38:39 --> Config Class Initialized
INFO - 2017-01-13 23:38:39 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:38:39 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:38:39 --> Utf8 Class Initialized
INFO - 2017-01-13 23:38:39 --> URI Class Initialized
INFO - 2017-01-13 23:38:39 --> Router Class Initialized
INFO - 2017-01-13 23:38:39 --> Output Class Initialized
INFO - 2017-01-13 23:38:39 --> Security Class Initialized
DEBUG - 2017-01-13 23:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:38:39 --> Input Class Initialized
INFO - 2017-01-13 23:38:39 --> Language Class Initialized
INFO - 2017-01-13 23:38:39 --> Loader Class Initialized
INFO - 2017-01-13 23:38:39 --> Database Driver Class Initialized
INFO - 2017-01-13 23:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:38:39 --> Controller Class Initialized
INFO - 2017-01-13 23:38:39 --> Helper loaded: date_helper
DEBUG - 2017-01-13 23:38:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:38:39 --> Helper loaded: url_helper
INFO - 2017-01-13 23:38:39 --> Helper loaded: download_helper
INFO - 2017-01-13 23:38:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:38:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 23:38:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-13 23:38:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-13 23:38:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:38:39 --> Final output sent to browser
DEBUG - 2017-01-13 23:38:39 --> Total execution time: 0.0181
INFO - 2017-01-13 23:48:07 --> Config Class Initialized
INFO - 2017-01-13 23:48:07 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:48:07 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:48:07 --> Utf8 Class Initialized
INFO - 2017-01-13 23:48:07 --> URI Class Initialized
INFO - 2017-01-13 23:48:07 --> Router Class Initialized
INFO - 2017-01-13 23:48:07 --> Output Class Initialized
INFO - 2017-01-13 23:48:07 --> Security Class Initialized
DEBUG - 2017-01-13 23:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:48:07 --> Input Class Initialized
INFO - 2017-01-13 23:48:07 --> Language Class Initialized
INFO - 2017-01-13 23:48:07 --> Loader Class Initialized
INFO - 2017-01-13 23:48:07 --> Database Driver Class Initialized
INFO - 2017-01-13 23:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:48:07 --> Controller Class Initialized
INFO - 2017-01-13 23:48:07 --> Helper loaded: date_helper
DEBUG - 2017-01-13 23:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:48:07 --> Helper loaded: url_helper
INFO - 2017-01-13 23:48:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:48:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 23:48:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-13 23:48:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-13 23:48:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:48:07 --> Final output sent to browser
DEBUG - 2017-01-13 23:48:07 --> Total execution time: 0.0144
INFO - 2017-01-13 23:48:12 --> Config Class Initialized
INFO - 2017-01-13 23:48:12 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:48:12 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:48:12 --> Utf8 Class Initialized
INFO - 2017-01-13 23:48:12 --> URI Class Initialized
INFO - 2017-01-13 23:48:12 --> Router Class Initialized
INFO - 2017-01-13 23:48:12 --> Output Class Initialized
INFO - 2017-01-13 23:48:12 --> Security Class Initialized
DEBUG - 2017-01-13 23:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:48:12 --> Input Class Initialized
INFO - 2017-01-13 23:48:12 --> Language Class Initialized
INFO - 2017-01-13 23:48:12 --> Loader Class Initialized
INFO - 2017-01-13 23:48:12 --> Database Driver Class Initialized
INFO - 2017-01-13 23:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:48:12 --> Controller Class Initialized
INFO - 2017-01-13 23:48:12 --> Helper loaded: date_helper
DEBUG - 2017-01-13 23:48:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:48:12 --> Helper loaded: url_helper
INFO - 2017-01-13 23:48:12 --> Helper loaded: download_helper
INFO - 2017-01-13 23:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 23:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-13 23:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-13 23:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:48:12 --> Final output sent to browser
DEBUG - 2017-01-13 23:48:12 --> Total execution time: 0.0198
INFO - 2017-01-13 23:48:16 --> Config Class Initialized
INFO - 2017-01-13 23:48:16 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:48:16 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:48:16 --> Utf8 Class Initialized
INFO - 2017-01-13 23:48:16 --> URI Class Initialized
INFO - 2017-01-13 23:48:16 --> Router Class Initialized
INFO - 2017-01-13 23:48:16 --> Output Class Initialized
INFO - 2017-01-13 23:48:16 --> Security Class Initialized
DEBUG - 2017-01-13 23:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:48:16 --> Input Class Initialized
INFO - 2017-01-13 23:48:16 --> Language Class Initialized
INFO - 2017-01-13 23:48:16 --> Loader Class Initialized
INFO - 2017-01-13 23:48:16 --> Database Driver Class Initialized
INFO - 2017-01-13 23:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:48:16 --> Controller Class Initialized
INFO - 2017-01-13 23:48:16 --> Helper loaded: date_helper
DEBUG - 2017-01-13 23:48:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:48:16 --> Helper loaded: url_helper
INFO - 2017-01-13 23:48:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:48:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 23:48:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-13 23:48:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-13 23:48:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:48:16 --> Final output sent to browser
DEBUG - 2017-01-13 23:48:16 --> Total execution time: 0.0142
INFO - 2017-01-13 23:52:52 --> Config Class Initialized
INFO - 2017-01-13 23:52:52 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:52:52 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:52:52 --> Utf8 Class Initialized
INFO - 2017-01-13 23:52:52 --> URI Class Initialized
INFO - 2017-01-13 23:52:52 --> Router Class Initialized
INFO - 2017-01-13 23:52:52 --> Output Class Initialized
INFO - 2017-01-13 23:52:52 --> Security Class Initialized
DEBUG - 2017-01-13 23:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:52:52 --> Input Class Initialized
INFO - 2017-01-13 23:52:52 --> Language Class Initialized
INFO - 2017-01-13 23:52:52 --> Loader Class Initialized
INFO - 2017-01-13 23:52:52 --> Database Driver Class Initialized
INFO - 2017-01-13 23:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:52:52 --> Controller Class Initialized
INFO - 2017-01-13 23:52:52 --> Helper loaded: date_helper
DEBUG - 2017-01-13 23:52:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:52:52 --> Helper loaded: url_helper
INFO - 2017-01-13 23:52:52 --> Helper loaded: download_helper
INFO - 2017-01-13 23:52:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:52:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-13 23:52:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-13 23:52:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-13 23:52:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:52:52 --> Final output sent to browser
DEBUG - 2017-01-13 23:52:52 --> Total execution time: 0.0175
INFO - 2017-01-13 23:56:34 --> Config Class Initialized
INFO - 2017-01-13 23:56:34 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:56:34 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:56:34 --> Utf8 Class Initialized
INFO - 2017-01-13 23:56:34 --> URI Class Initialized
INFO - 2017-01-13 23:56:34 --> Router Class Initialized
INFO - 2017-01-13 23:56:34 --> Output Class Initialized
INFO - 2017-01-13 23:56:34 --> Security Class Initialized
DEBUG - 2017-01-13 23:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:56:34 --> Input Class Initialized
INFO - 2017-01-13 23:56:34 --> Language Class Initialized
INFO - 2017-01-13 23:56:34 --> Loader Class Initialized
INFO - 2017-01-13 23:56:34 --> Database Driver Class Initialized
INFO - 2017-01-13 23:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:56:34 --> Controller Class Initialized
INFO - 2017-01-13 23:56:34 --> Upload Class Initialized
INFO - 2017-01-13 23:56:34 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:56:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:56:34 --> Helper loaded: form_helper
INFO - 2017-01-13 23:56:34 --> Form Validation Class Initialized
INFO - 2017-01-13 23:56:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 23:56:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 23:56:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-13 23:56:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-13 23:56:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-13 23:56:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 23:56:34 --> Final output sent to browser
DEBUG - 2017-01-13 23:56:34 --> Total execution time: 0.0170
INFO - 2017-01-13 23:56:35 --> Config Class Initialized
INFO - 2017-01-13 23:56:35 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:56:35 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:56:35 --> Utf8 Class Initialized
INFO - 2017-01-13 23:56:35 --> URI Class Initialized
INFO - 2017-01-13 23:56:35 --> Router Class Initialized
INFO - 2017-01-13 23:56:35 --> Output Class Initialized
INFO - 2017-01-13 23:56:35 --> Security Class Initialized
DEBUG - 2017-01-13 23:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:56:35 --> Input Class Initialized
INFO - 2017-01-13 23:56:35 --> Language Class Initialized
INFO - 2017-01-13 23:56:35 --> Loader Class Initialized
INFO - 2017-01-13 23:56:35 --> Database Driver Class Initialized
INFO - 2017-01-13 23:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:56:35 --> Controller Class Initialized
INFO - 2017-01-13 23:56:35 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:56:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:56:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:56:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 23:56:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 23:56:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:56:35 --> Final output sent to browser
DEBUG - 2017-01-13 23:56:35 --> Total execution time: 0.0138
INFO - 2017-01-13 23:56:38 --> Config Class Initialized
INFO - 2017-01-13 23:56:38 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:56:38 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:56:38 --> Utf8 Class Initialized
INFO - 2017-01-13 23:56:38 --> URI Class Initialized
INFO - 2017-01-13 23:56:38 --> Router Class Initialized
INFO - 2017-01-13 23:56:38 --> Output Class Initialized
INFO - 2017-01-13 23:56:38 --> Security Class Initialized
DEBUG - 2017-01-13 23:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:56:38 --> Input Class Initialized
INFO - 2017-01-13 23:56:38 --> Language Class Initialized
INFO - 2017-01-13 23:56:38 --> Loader Class Initialized
INFO - 2017-01-13 23:56:38 --> Database Driver Class Initialized
INFO - 2017-01-13 23:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:56:38 --> Controller Class Initialized
INFO - 2017-01-13 23:56:38 --> Upload Class Initialized
INFO - 2017-01-13 23:56:38 --> Helper loaded: date_helper
INFO - 2017-01-13 23:56:38 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:56:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:56:38 --> Helper loaded: form_helper
INFO - 2017-01-13 23:56:38 --> Form Validation Class Initialized
INFO - 2017-01-13 23:56:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 23:56:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 23:56:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-13 23:56:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-13 23:56:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-13 23:56:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 23:56:38 --> Final output sent to browser
DEBUG - 2017-01-13 23:56:38 --> Total execution time: 0.0736
INFO - 2017-01-13 23:56:38 --> Config Class Initialized
INFO - 2017-01-13 23:56:38 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:56:38 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:56:38 --> Utf8 Class Initialized
INFO - 2017-01-13 23:56:38 --> URI Class Initialized
INFO - 2017-01-13 23:56:38 --> Router Class Initialized
INFO - 2017-01-13 23:56:38 --> Output Class Initialized
INFO - 2017-01-13 23:56:38 --> Security Class Initialized
DEBUG - 2017-01-13 23:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:56:38 --> Input Class Initialized
INFO - 2017-01-13 23:56:38 --> Language Class Initialized
INFO - 2017-01-13 23:56:38 --> Loader Class Initialized
INFO - 2017-01-13 23:56:38 --> Database Driver Class Initialized
INFO - 2017-01-13 23:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:56:38 --> Controller Class Initialized
INFO - 2017-01-13 23:56:38 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:56:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:56:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:56:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 23:56:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 23:56:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:56:38 --> Final output sent to browser
DEBUG - 2017-01-13 23:56:38 --> Total execution time: 0.0140
INFO - 2017-01-13 23:56:40 --> Config Class Initialized
INFO - 2017-01-13 23:56:40 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:56:40 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:56:40 --> Utf8 Class Initialized
INFO - 2017-01-13 23:56:40 --> URI Class Initialized
INFO - 2017-01-13 23:56:40 --> Router Class Initialized
INFO - 2017-01-13 23:56:40 --> Output Class Initialized
INFO - 2017-01-13 23:56:40 --> Security Class Initialized
DEBUG - 2017-01-13 23:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:56:40 --> Input Class Initialized
INFO - 2017-01-13 23:56:40 --> Language Class Initialized
INFO - 2017-01-13 23:56:40 --> Loader Class Initialized
INFO - 2017-01-13 23:56:40 --> Database Driver Class Initialized
INFO - 2017-01-13 23:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:56:40 --> Controller Class Initialized
INFO - 2017-01-13 23:56:40 --> Helper loaded: date_helper
INFO - 2017-01-13 23:56:40 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:56:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:56:40 --> Helper loaded: form_helper
INFO - 2017-01-13 23:56:40 --> Form Validation Class Initialized
INFO - 2017-01-13 23:56:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 23:56:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 23:56:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-13 23:56:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-13 23:56:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 23:56:40 --> Final output sent to browser
DEBUG - 2017-01-13 23:56:40 --> Total execution time: 0.0160
INFO - 2017-01-13 23:56:40 --> Config Class Initialized
INFO - 2017-01-13 23:56:40 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:56:40 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:56:40 --> Utf8 Class Initialized
INFO - 2017-01-13 23:56:40 --> URI Class Initialized
INFO - 2017-01-13 23:56:40 --> Router Class Initialized
INFO - 2017-01-13 23:56:40 --> Output Class Initialized
INFO - 2017-01-13 23:56:40 --> Security Class Initialized
DEBUG - 2017-01-13 23:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:56:40 --> Input Class Initialized
INFO - 2017-01-13 23:56:40 --> Language Class Initialized
INFO - 2017-01-13 23:56:40 --> Loader Class Initialized
INFO - 2017-01-13 23:56:40 --> Database Driver Class Initialized
INFO - 2017-01-13 23:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:56:40 --> Controller Class Initialized
INFO - 2017-01-13 23:56:40 --> Helper loaded: date_helper
INFO - 2017-01-13 23:56:40 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:56:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:56:40 --> Helper loaded: form_helper
INFO - 2017-01-13 23:56:40 --> Form Validation Class Initialized
INFO - 2017-01-13 23:56:40 --> Final output sent to browser
DEBUG - 2017-01-13 23:56:40 --> Total execution time: 0.0145
INFO - 2017-01-13 23:56:40 --> Config Class Initialized
INFO - 2017-01-13 23:56:40 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:56:40 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:56:40 --> Utf8 Class Initialized
INFO - 2017-01-13 23:56:40 --> URI Class Initialized
INFO - 2017-01-13 23:56:40 --> Router Class Initialized
INFO - 2017-01-13 23:56:40 --> Output Class Initialized
INFO - 2017-01-13 23:56:40 --> Security Class Initialized
DEBUG - 2017-01-13 23:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:56:40 --> Input Class Initialized
INFO - 2017-01-13 23:56:40 --> Language Class Initialized
INFO - 2017-01-13 23:56:40 --> Loader Class Initialized
INFO - 2017-01-13 23:56:40 --> Database Driver Class Initialized
INFO - 2017-01-13 23:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:56:40 --> Controller Class Initialized
INFO - 2017-01-13 23:56:40 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:56:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:56:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:56:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 23:56:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 23:56:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:56:40 --> Final output sent to browser
DEBUG - 2017-01-13 23:56:40 --> Total execution time: 0.0135
INFO - 2017-01-13 23:56:44 --> Config Class Initialized
INFO - 2017-01-13 23:56:44 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:56:44 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:56:44 --> Utf8 Class Initialized
INFO - 2017-01-13 23:56:44 --> URI Class Initialized
INFO - 2017-01-13 23:56:44 --> Router Class Initialized
INFO - 2017-01-13 23:56:44 --> Output Class Initialized
INFO - 2017-01-13 23:56:44 --> Security Class Initialized
DEBUG - 2017-01-13 23:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:56:44 --> Input Class Initialized
INFO - 2017-01-13 23:56:44 --> Language Class Initialized
INFO - 2017-01-13 23:56:44 --> Loader Class Initialized
INFO - 2017-01-13 23:56:44 --> Database Driver Class Initialized
INFO - 2017-01-13 23:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:56:44 --> Controller Class Initialized
INFO - 2017-01-13 23:56:44 --> Helper loaded: date_helper
INFO - 2017-01-13 23:56:44 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:56:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:56:44 --> Helper loaded: form_helper
INFO - 2017-01-13 23:56:44 --> Form Validation Class Initialized
INFO - 2017-01-13 23:56:44 --> Final output sent to browser
DEBUG - 2017-01-13 23:56:44 --> Total execution time: 0.0156
INFO - 2017-01-13 23:56:52 --> Config Class Initialized
INFO - 2017-01-13 23:56:52 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:56:52 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:56:52 --> Utf8 Class Initialized
INFO - 2017-01-13 23:56:52 --> URI Class Initialized
INFO - 2017-01-13 23:56:52 --> Router Class Initialized
INFO - 2017-01-13 23:56:52 --> Output Class Initialized
INFO - 2017-01-13 23:56:52 --> Security Class Initialized
DEBUG - 2017-01-13 23:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:56:52 --> Input Class Initialized
INFO - 2017-01-13 23:56:52 --> Language Class Initialized
INFO - 2017-01-13 23:56:52 --> Loader Class Initialized
INFO - 2017-01-13 23:56:52 --> Database Driver Class Initialized
INFO - 2017-01-13 23:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:56:52 --> Controller Class Initialized
INFO - 2017-01-13 23:56:52 --> Upload Class Initialized
INFO - 2017-01-13 23:56:52 --> Helper loaded: date_helper
INFO - 2017-01-13 23:56:52 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:56:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:56:52 --> Helper loaded: form_helper
INFO - 2017-01-13 23:56:52 --> Form Validation Class Initialized
INFO - 2017-01-13 23:56:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 23:56:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 23:56:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-13 23:56:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-13 23:56:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-13 23:56:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 23:56:52 --> Final output sent to browser
DEBUG - 2017-01-13 23:56:52 --> Total execution time: 0.0174
INFO - 2017-01-13 23:56:52 --> Config Class Initialized
INFO - 2017-01-13 23:56:52 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:56:52 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:56:52 --> Utf8 Class Initialized
INFO - 2017-01-13 23:56:52 --> URI Class Initialized
INFO - 2017-01-13 23:56:52 --> Router Class Initialized
INFO - 2017-01-13 23:56:52 --> Output Class Initialized
INFO - 2017-01-13 23:56:52 --> Security Class Initialized
DEBUG - 2017-01-13 23:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:56:52 --> Input Class Initialized
INFO - 2017-01-13 23:56:52 --> Language Class Initialized
INFO - 2017-01-13 23:56:52 --> Loader Class Initialized
INFO - 2017-01-13 23:56:52 --> Database Driver Class Initialized
INFO - 2017-01-13 23:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:56:52 --> Controller Class Initialized
INFO - 2017-01-13 23:56:52 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:56:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:56:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:56:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 23:56:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 23:56:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:56:52 --> Final output sent to browser
DEBUG - 2017-01-13 23:56:52 --> Total execution time: 0.0369
INFO - 2017-01-13 23:56:53 --> Config Class Initialized
INFO - 2017-01-13 23:56:53 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:56:53 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:56:53 --> Utf8 Class Initialized
INFO - 2017-01-13 23:56:53 --> URI Class Initialized
INFO - 2017-01-13 23:56:53 --> Router Class Initialized
INFO - 2017-01-13 23:56:53 --> Output Class Initialized
INFO - 2017-01-13 23:56:53 --> Security Class Initialized
DEBUG - 2017-01-13 23:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:56:53 --> Input Class Initialized
INFO - 2017-01-13 23:56:53 --> Language Class Initialized
INFO - 2017-01-13 23:56:53 --> Loader Class Initialized
INFO - 2017-01-13 23:56:53 --> Database Driver Class Initialized
INFO - 2017-01-13 23:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:56:53 --> Controller Class Initialized
INFO - 2017-01-13 23:56:53 --> Helper loaded: date_helper
INFO - 2017-01-13 23:56:53 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:56:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:56:53 --> Helper loaded: form_helper
INFO - 2017-01-13 23:56:53 --> Form Validation Class Initialized
INFO - 2017-01-13 23:56:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 23:56:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 23:56:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-13 23:56:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-13 23:56:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 23:56:53 --> Final output sent to browser
DEBUG - 2017-01-13 23:56:53 --> Total execution time: 0.0499
INFO - 2017-01-13 23:56:53 --> Config Class Initialized
INFO - 2017-01-13 23:56:53 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:56:53 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:56:53 --> Utf8 Class Initialized
INFO - 2017-01-13 23:56:53 --> URI Class Initialized
INFO - 2017-01-13 23:56:53 --> Router Class Initialized
INFO - 2017-01-13 23:56:53 --> Output Class Initialized
INFO - 2017-01-13 23:56:53 --> Security Class Initialized
DEBUG - 2017-01-13 23:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:56:53 --> Input Class Initialized
INFO - 2017-01-13 23:56:53 --> Language Class Initialized
INFO - 2017-01-13 23:56:53 --> Loader Class Initialized
INFO - 2017-01-13 23:56:53 --> Database Driver Class Initialized
INFO - 2017-01-13 23:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:56:53 --> Controller Class Initialized
INFO - 2017-01-13 23:56:53 --> Helper loaded: date_helper
INFO - 2017-01-13 23:56:53 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:56:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:56:53 --> Helper loaded: form_helper
INFO - 2017-01-13 23:56:53 --> Form Validation Class Initialized
INFO - 2017-01-13 23:56:53 --> Final output sent to browser
DEBUG - 2017-01-13 23:56:53 --> Total execution time: 0.0148
INFO - 2017-01-13 23:56:54 --> Config Class Initialized
INFO - 2017-01-13 23:56:54 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:56:54 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:56:54 --> Utf8 Class Initialized
INFO - 2017-01-13 23:56:54 --> URI Class Initialized
INFO - 2017-01-13 23:56:54 --> Router Class Initialized
INFO - 2017-01-13 23:56:54 --> Output Class Initialized
INFO - 2017-01-13 23:56:54 --> Security Class Initialized
DEBUG - 2017-01-13 23:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:56:54 --> Input Class Initialized
INFO - 2017-01-13 23:56:54 --> Language Class Initialized
INFO - 2017-01-13 23:56:54 --> Loader Class Initialized
INFO - 2017-01-13 23:56:54 --> Database Driver Class Initialized
INFO - 2017-01-13 23:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:56:54 --> Controller Class Initialized
INFO - 2017-01-13 23:56:54 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:56:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:56:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:56:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 23:56:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 23:56:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:56:54 --> Final output sent to browser
DEBUG - 2017-01-13 23:56:54 --> Total execution time: 0.0138
INFO - 2017-01-13 23:56:55 --> Config Class Initialized
INFO - 2017-01-13 23:56:55 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:56:55 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:56:55 --> Utf8 Class Initialized
INFO - 2017-01-13 23:56:55 --> URI Class Initialized
INFO - 2017-01-13 23:56:55 --> Router Class Initialized
INFO - 2017-01-13 23:56:55 --> Output Class Initialized
INFO - 2017-01-13 23:56:55 --> Security Class Initialized
DEBUG - 2017-01-13 23:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:56:55 --> Input Class Initialized
INFO - 2017-01-13 23:56:55 --> Language Class Initialized
INFO - 2017-01-13 23:56:55 --> Loader Class Initialized
INFO - 2017-01-13 23:56:55 --> Database Driver Class Initialized
INFO - 2017-01-13 23:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:56:55 --> Controller Class Initialized
INFO - 2017-01-13 23:56:55 --> Helper loaded: date_helper
INFO - 2017-01-13 23:56:55 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:56:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:56:55 --> Helper loaded: form_helper
INFO - 2017-01-13 23:56:55 --> Form Validation Class Initialized
INFO - 2017-01-13 23:56:55 --> Final output sent to browser
DEBUG - 2017-01-13 23:56:55 --> Total execution time: 0.0144
INFO - 2017-01-13 23:57:09 --> Config Class Initialized
INFO - 2017-01-13 23:57:09 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:57:09 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:57:09 --> Utf8 Class Initialized
INFO - 2017-01-13 23:57:09 --> URI Class Initialized
INFO - 2017-01-13 23:57:09 --> Router Class Initialized
INFO - 2017-01-13 23:57:09 --> Output Class Initialized
INFO - 2017-01-13 23:57:09 --> Security Class Initialized
DEBUG - 2017-01-13 23:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:57:09 --> Input Class Initialized
INFO - 2017-01-13 23:57:09 --> Language Class Initialized
INFO - 2017-01-13 23:57:09 --> Loader Class Initialized
INFO - 2017-01-13 23:57:09 --> Database Driver Class Initialized
INFO - 2017-01-13 23:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:57:09 --> Controller Class Initialized
INFO - 2017-01-13 23:57:09 --> Upload Class Initialized
INFO - 2017-01-13 23:57:09 --> Helper loaded: date_helper
INFO - 2017-01-13 23:57:09 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:57:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:57:09 --> Helper loaded: form_helper
INFO - 2017-01-13 23:57:09 --> Form Validation Class Initialized
INFO - 2017-01-13 23:57:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 23:57:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 23:57:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-13 23:57:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-13 23:57:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-13 23:57:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 23:57:09 --> Final output sent to browser
DEBUG - 2017-01-13 23:57:09 --> Total execution time: 0.0156
INFO - 2017-01-13 23:57:10 --> Config Class Initialized
INFO - 2017-01-13 23:57:10 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:57:10 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:57:10 --> Utf8 Class Initialized
INFO - 2017-01-13 23:57:10 --> URI Class Initialized
INFO - 2017-01-13 23:57:10 --> Router Class Initialized
INFO - 2017-01-13 23:57:10 --> Output Class Initialized
INFO - 2017-01-13 23:57:10 --> Security Class Initialized
DEBUG - 2017-01-13 23:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:57:10 --> Input Class Initialized
INFO - 2017-01-13 23:57:10 --> Language Class Initialized
INFO - 2017-01-13 23:57:10 --> Loader Class Initialized
INFO - 2017-01-13 23:57:10 --> Database Driver Class Initialized
INFO - 2017-01-13 23:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:57:10 --> Controller Class Initialized
INFO - 2017-01-13 23:57:10 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:57:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:57:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:57:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 23:57:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 23:57:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:57:10 --> Final output sent to browser
DEBUG - 2017-01-13 23:57:10 --> Total execution time: 0.0131
INFO - 2017-01-13 23:57:10 --> Config Class Initialized
INFO - 2017-01-13 23:57:10 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:57:10 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:57:10 --> Utf8 Class Initialized
INFO - 2017-01-13 23:57:10 --> URI Class Initialized
INFO - 2017-01-13 23:57:10 --> Router Class Initialized
INFO - 2017-01-13 23:57:10 --> Output Class Initialized
INFO - 2017-01-13 23:57:10 --> Security Class Initialized
DEBUG - 2017-01-13 23:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:57:10 --> Input Class Initialized
INFO - 2017-01-13 23:57:10 --> Language Class Initialized
INFO - 2017-01-13 23:57:10 --> Loader Class Initialized
INFO - 2017-01-13 23:57:10 --> Database Driver Class Initialized
INFO - 2017-01-13 23:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:57:10 --> Controller Class Initialized
INFO - 2017-01-13 23:57:10 --> Helper loaded: date_helper
INFO - 2017-01-13 23:57:10 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:57:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:57:10 --> Helper loaded: form_helper
INFO - 2017-01-13 23:57:10 --> Form Validation Class Initialized
INFO - 2017-01-13 23:57:10 --> Final output sent to browser
DEBUG - 2017-01-13 23:57:10 --> Total execution time: 0.0266
INFO - 2017-01-13 23:57:11 --> Config Class Initialized
INFO - 2017-01-13 23:57:11 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:57:11 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:57:11 --> Utf8 Class Initialized
INFO - 2017-01-13 23:57:11 --> URI Class Initialized
INFO - 2017-01-13 23:57:11 --> Router Class Initialized
INFO - 2017-01-13 23:57:11 --> Output Class Initialized
INFO - 2017-01-13 23:57:11 --> Security Class Initialized
DEBUG - 2017-01-13 23:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:57:11 --> Input Class Initialized
INFO - 2017-01-13 23:57:11 --> Language Class Initialized
INFO - 2017-01-13 23:57:11 --> Loader Class Initialized
INFO - 2017-01-13 23:57:11 --> Database Driver Class Initialized
INFO - 2017-01-13 23:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:57:11 --> Controller Class Initialized
INFO - 2017-01-13 23:57:11 --> Helper loaded: date_helper
INFO - 2017-01-13 23:57:11 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:57:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:57:11 --> Helper loaded: form_helper
INFO - 2017-01-13 23:57:11 --> Form Validation Class Initialized
INFO - 2017-01-13 23:57:11 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-13 23:57:11 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-13 23:57:11 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-13 23:57:11 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-13 23:57:11 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-13 23:57:11 --> Final output sent to browser
DEBUG - 2017-01-13 23:57:11 --> Total execution time: 0.0150
INFO - 2017-01-13 23:57:11 --> Config Class Initialized
INFO - 2017-01-13 23:57:11 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:57:11 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:57:11 --> Utf8 Class Initialized
INFO - 2017-01-13 23:57:11 --> URI Class Initialized
INFO - 2017-01-13 23:57:11 --> Router Class Initialized
INFO - 2017-01-13 23:57:11 --> Output Class Initialized
INFO - 2017-01-13 23:57:11 --> Security Class Initialized
DEBUG - 2017-01-13 23:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:57:11 --> Input Class Initialized
INFO - 2017-01-13 23:57:11 --> Language Class Initialized
INFO - 2017-01-13 23:57:11 --> Loader Class Initialized
INFO - 2017-01-13 23:57:11 --> Database Driver Class Initialized
INFO - 2017-01-13 23:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:57:11 --> Controller Class Initialized
INFO - 2017-01-13 23:57:11 --> Helper loaded: date_helper
INFO - 2017-01-13 23:57:11 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:57:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:57:11 --> Helper loaded: form_helper
INFO - 2017-01-13 23:57:11 --> Form Validation Class Initialized
INFO - 2017-01-13 23:57:11 --> Final output sent to browser
DEBUG - 2017-01-13 23:57:11 --> Total execution time: 0.0161
INFO - 2017-01-13 23:57:11 --> Config Class Initialized
INFO - 2017-01-13 23:57:11 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:57:11 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:57:11 --> Utf8 Class Initialized
INFO - 2017-01-13 23:57:11 --> URI Class Initialized
INFO - 2017-01-13 23:57:11 --> Router Class Initialized
INFO - 2017-01-13 23:57:11 --> Output Class Initialized
INFO - 2017-01-13 23:57:11 --> Security Class Initialized
DEBUG - 2017-01-13 23:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:57:11 --> Input Class Initialized
INFO - 2017-01-13 23:57:11 --> Language Class Initialized
INFO - 2017-01-13 23:57:11 --> Loader Class Initialized
INFO - 2017-01-13 23:57:11 --> Database Driver Class Initialized
INFO - 2017-01-13 23:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:57:11 --> Controller Class Initialized
INFO - 2017-01-13 23:57:11 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:57:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:57:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-13 23:57:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-13 23:57:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-13 23:57:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-13 23:57:11 --> Final output sent to browser
DEBUG - 2017-01-13 23:57:11 --> Total execution time: 0.0256
INFO - 2017-01-13 23:57:14 --> Config Class Initialized
INFO - 2017-01-13 23:57:14 --> Hooks Class Initialized
DEBUG - 2017-01-13 23:57:14 --> UTF-8 Support Enabled
INFO - 2017-01-13 23:57:14 --> Utf8 Class Initialized
INFO - 2017-01-13 23:57:14 --> URI Class Initialized
INFO - 2017-01-13 23:57:14 --> Router Class Initialized
INFO - 2017-01-13 23:57:14 --> Output Class Initialized
INFO - 2017-01-13 23:57:14 --> Security Class Initialized
DEBUG - 2017-01-13 23:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-13 23:57:14 --> Input Class Initialized
INFO - 2017-01-13 23:57:14 --> Language Class Initialized
INFO - 2017-01-13 23:57:14 --> Loader Class Initialized
INFO - 2017-01-13 23:57:14 --> Database Driver Class Initialized
INFO - 2017-01-13 23:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-13 23:57:14 --> Controller Class Initialized
INFO - 2017-01-13 23:57:14 --> Helper loaded: date_helper
INFO - 2017-01-13 23:57:14 --> Helper loaded: url_helper
DEBUG - 2017-01-13 23:57:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-13 23:57:14 --> Helper loaded: form_helper
INFO - 2017-01-13 23:57:14 --> Form Validation Class Initialized
INFO - 2017-01-13 23:57:14 --> Final output sent to browser
DEBUG - 2017-01-13 23:57:14 --> Total execution time: 0.0160

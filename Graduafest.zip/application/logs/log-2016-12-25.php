<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-25 23:11:59 --> Config Class Initialized
INFO - 2016-12-25 23:11:59 --> Hooks Class Initialized
DEBUG - 2016-12-25 23:11:59 --> UTF-8 Support Enabled
INFO - 2016-12-25 23:11:59 --> Utf8 Class Initialized
INFO - 2016-12-25 23:11:59 --> URI Class Initialized
INFO - 2016-12-25 23:11:59 --> Router Class Initialized
INFO - 2016-12-25 23:12:00 --> Output Class Initialized
INFO - 2016-12-25 23:12:00 --> Security Class Initialized
DEBUG - 2016-12-25 23:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-25 23:12:00 --> Input Class Initialized
INFO - 2016-12-25 23:12:00 --> Language Class Initialized
INFO - 2016-12-25 23:12:00 --> Loader Class Initialized
INFO - 2016-12-25 23:12:00 --> Database Driver Class Initialized
INFO - 2016-12-25 23:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-25 23:12:00 --> Controller Class Initialized
INFO - 2016-12-25 23:12:00 --> Upload Class Initialized
INFO - 2016-12-25 23:12:01 --> Helper loaded: date_helper
DEBUG - 2016-12-25 23:12:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-25 23:12:01 --> Helper loaded: url_helper
INFO - 2016-12-25 23:12:01 --> Config Class Initialized
INFO - 2016-12-25 23:12:01 --> Hooks Class Initialized
DEBUG - 2016-12-25 23:12:01 --> UTF-8 Support Enabled
INFO - 2016-12-25 23:12:01 --> Utf8 Class Initialized
INFO - 2016-12-25 23:12:01 --> URI Class Initialized
DEBUG - 2016-12-25 23:12:01 --> No URI present. Default controller set.
INFO - 2016-12-25 23:12:01 --> Router Class Initialized
INFO - 2016-12-25 23:12:01 --> Output Class Initialized
INFO - 2016-12-25 23:12:01 --> Security Class Initialized
DEBUG - 2016-12-25 23:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-25 23:12:01 --> Input Class Initialized
INFO - 2016-12-25 23:12:01 --> Language Class Initialized
INFO - 2016-12-25 23:12:01 --> Loader Class Initialized
INFO - 2016-12-25 23:12:01 --> Database Driver Class Initialized
INFO - 2016-12-25 23:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-25 23:12:01 --> Controller Class Initialized
INFO - 2016-12-25 23:12:01 --> Helper loaded: url_helper
DEBUG - 2016-12-25 23:12:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-25 23:12:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-25 23:12:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-25 23:12:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-25 23:12:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-25 23:12:01 --> Final output sent to browser
DEBUG - 2016-12-25 23:12:01 --> Total execution time: 0.2828
INFO - 2016-12-25 23:12:15 --> Config Class Initialized
INFO - 2016-12-25 23:12:15 --> Hooks Class Initialized
DEBUG - 2016-12-25 23:12:15 --> UTF-8 Support Enabled
INFO - 2016-12-25 23:12:15 --> Utf8 Class Initialized
INFO - 2016-12-25 23:12:15 --> URI Class Initialized
INFO - 2016-12-25 23:12:15 --> Router Class Initialized
INFO - 2016-12-25 23:12:15 --> Output Class Initialized
INFO - 2016-12-25 23:12:15 --> Security Class Initialized
DEBUG - 2016-12-25 23:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-25 23:12:15 --> Input Class Initialized
INFO - 2016-12-25 23:12:15 --> Language Class Initialized
INFO - 2016-12-25 23:12:15 --> Loader Class Initialized
INFO - 2016-12-25 23:12:15 --> Database Driver Class Initialized
INFO - 2016-12-25 23:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-25 23:12:15 --> Controller Class Initialized
INFO - 2016-12-25 23:12:15 --> Helper loaded: url_helper
DEBUG - 2016-12-25 23:12:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-25 23:12:18 --> Config Class Initialized
INFO - 2016-12-25 23:12:18 --> Hooks Class Initialized
DEBUG - 2016-12-25 23:12:18 --> UTF-8 Support Enabled
INFO - 2016-12-25 23:12:18 --> Utf8 Class Initialized
INFO - 2016-12-25 23:12:18 --> URI Class Initialized
INFO - 2016-12-25 23:12:18 --> Router Class Initialized
INFO - 2016-12-25 23:12:18 --> Output Class Initialized
INFO - 2016-12-25 23:12:18 --> Security Class Initialized
DEBUG - 2016-12-25 23:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-25 23:12:18 --> Input Class Initialized
INFO - 2016-12-25 23:12:18 --> Language Class Initialized
INFO - 2016-12-25 23:12:18 --> Loader Class Initialized
INFO - 2016-12-25 23:12:18 --> Database Driver Class Initialized
INFO - 2016-12-25 23:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-25 23:12:18 --> Controller Class Initialized
INFO - 2016-12-25 23:12:18 --> Helper loaded: date_helper
DEBUG - 2016-12-25 23:12:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-25 23:12:18 --> Helper loaded: url_helper
INFO - 2016-12-25 23:12:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-25 23:12:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-25 23:12:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-25 23:12:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-25 23:12:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-25 23:12:18 --> Final output sent to browser
DEBUG - 2016-12-25 23:12:18 --> Total execution time: 0.0391
INFO - 2016-12-25 23:12:23 --> Config Class Initialized
INFO - 2016-12-25 23:12:23 --> Hooks Class Initialized
DEBUG - 2016-12-25 23:12:23 --> UTF-8 Support Enabled
INFO - 2016-12-25 23:12:23 --> Utf8 Class Initialized
INFO - 2016-12-25 23:12:23 --> URI Class Initialized
INFO - 2016-12-25 23:12:23 --> Router Class Initialized
INFO - 2016-12-25 23:12:23 --> Output Class Initialized
INFO - 2016-12-25 23:12:23 --> Security Class Initialized
DEBUG - 2016-12-25 23:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-25 23:12:23 --> Input Class Initialized
INFO - 2016-12-25 23:12:23 --> Language Class Initialized
INFO - 2016-12-25 23:12:23 --> Loader Class Initialized
INFO - 2016-12-25 23:12:23 --> Database Driver Class Initialized
INFO - 2016-12-25 23:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-25 23:12:23 --> Controller Class Initialized
INFO - 2016-12-25 23:12:23 --> Helper loaded: date_helper
DEBUG - 2016-12-25 23:12:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-25 23:12:23 --> Helper loaded: url_helper
INFO - 2016-12-25 23:12:23 --> Helper loaded: download_helper
INFO - 2016-12-25 23:12:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-25 23:12:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-25 23:12:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-25 23:12:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-25 23:12:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-25 23:12:23 --> Final output sent to browser
DEBUG - 2016-12-25 23:12:23 --> Total execution time: 0.0924
INFO - 2016-12-25 23:12:32 --> Config Class Initialized
INFO - 2016-12-25 23:12:32 --> Hooks Class Initialized
DEBUG - 2016-12-25 23:12:32 --> UTF-8 Support Enabled
INFO - 2016-12-25 23:12:32 --> Utf8 Class Initialized
INFO - 2016-12-25 23:12:32 --> URI Class Initialized
INFO - 2016-12-25 23:12:32 --> Router Class Initialized
INFO - 2016-12-25 23:12:32 --> Output Class Initialized
INFO - 2016-12-25 23:12:32 --> Security Class Initialized
DEBUG - 2016-12-25 23:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-25 23:12:32 --> Input Class Initialized
INFO - 2016-12-25 23:12:32 --> Language Class Initialized
INFO - 2016-12-25 23:12:32 --> Loader Class Initialized
INFO - 2016-12-25 23:12:32 --> Database Driver Class Initialized
INFO - 2016-12-25 23:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-25 23:12:32 --> Controller Class Initialized
INFO - 2016-12-25 23:12:32 --> Helper loaded: date_helper
INFO - 2016-12-25 23:12:32 --> Helper loaded: url_helper
DEBUG - 2016-12-25 23:12:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-25 23:12:32 --> Helper loaded: form_helper
INFO - 2016-12-25 23:12:32 --> Form Validation Class Initialized
INFO - 2016-12-25 23:12:32 --> Final output sent to browser
DEBUG - 2016-12-25 23:12:32 --> Total execution time: 0.1338
INFO - 2016-12-25 23:12:41 --> Config Class Initialized
INFO - 2016-12-25 23:12:41 --> Hooks Class Initialized
DEBUG - 2016-12-25 23:12:41 --> UTF-8 Support Enabled
INFO - 2016-12-25 23:12:41 --> Utf8 Class Initialized
INFO - 2016-12-25 23:12:41 --> URI Class Initialized
INFO - 2016-12-25 23:12:41 --> Router Class Initialized
INFO - 2016-12-25 23:12:41 --> Output Class Initialized
INFO - 2016-12-25 23:12:41 --> Security Class Initialized
DEBUG - 2016-12-25 23:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-25 23:12:41 --> Input Class Initialized
INFO - 2016-12-25 23:12:41 --> Language Class Initialized
INFO - 2016-12-25 23:12:41 --> Loader Class Initialized
INFO - 2016-12-25 23:12:41 --> Database Driver Class Initialized
INFO - 2016-12-25 23:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-25 23:12:41 --> Controller Class Initialized
INFO - 2016-12-25 23:12:41 --> Helper loaded: date_helper
INFO - 2016-12-25 23:12:41 --> Helper loaded: url_helper
DEBUG - 2016-12-25 23:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-25 23:12:41 --> Helper loaded: form_helper
INFO - 2016-12-25 23:12:41 --> Form Validation Class Initialized
INFO - 2016-12-25 23:12:41 --> Final output sent to browser
DEBUG - 2016-12-25 23:12:41 --> Total execution time: 0.0146
INFO - 2016-12-25 23:12:41 --> Config Class Initialized
INFO - 2016-12-25 23:12:41 --> Hooks Class Initialized
DEBUG - 2016-12-25 23:12:41 --> UTF-8 Support Enabled
INFO - 2016-12-25 23:12:41 --> Utf8 Class Initialized
INFO - 2016-12-25 23:12:41 --> URI Class Initialized
INFO - 2016-12-25 23:12:41 --> Router Class Initialized
INFO - 2016-12-25 23:12:41 --> Output Class Initialized
INFO - 2016-12-25 23:12:41 --> Security Class Initialized
DEBUG - 2016-12-25 23:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-25 23:12:41 --> Input Class Initialized
INFO - 2016-12-25 23:12:41 --> Language Class Initialized
INFO - 2016-12-25 23:12:41 --> Loader Class Initialized
INFO - 2016-12-25 23:12:41 --> Database Driver Class Initialized
INFO - 2016-12-25 23:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-25 23:12:41 --> Controller Class Initialized
INFO - 2016-12-25 23:12:41 --> Helper loaded: date_helper
INFO - 2016-12-25 23:12:41 --> Helper loaded: url_helper
DEBUG - 2016-12-25 23:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-25 23:12:41 --> Helper loaded: form_helper
INFO - 2016-12-25 23:12:41 --> Form Validation Class Initialized
INFO - 2016-12-25 23:12:41 --> Final output sent to browser
DEBUG - 2016-12-25 23:12:41 --> Total execution time: 0.0153
INFO - 2016-12-25 23:12:46 --> Config Class Initialized
INFO - 2016-12-25 23:12:46 --> Hooks Class Initialized
DEBUG - 2016-12-25 23:12:46 --> UTF-8 Support Enabled
INFO - 2016-12-25 23:12:46 --> Utf8 Class Initialized
INFO - 2016-12-25 23:12:46 --> URI Class Initialized
INFO - 2016-12-25 23:12:46 --> Router Class Initialized
INFO - 2016-12-25 23:12:46 --> Output Class Initialized
INFO - 2016-12-25 23:12:46 --> Security Class Initialized
DEBUG - 2016-12-25 23:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-25 23:12:46 --> Input Class Initialized
INFO - 2016-12-25 23:12:46 --> Language Class Initialized
INFO - 2016-12-25 23:12:46 --> Loader Class Initialized
INFO - 2016-12-25 23:12:46 --> Database Driver Class Initialized
INFO - 2016-12-25 23:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-25 23:12:46 --> Controller Class Initialized
INFO - 2016-12-25 23:12:46 --> Helper loaded: date_helper
INFO - 2016-12-25 23:12:46 --> Helper loaded: url_helper
DEBUG - 2016-12-25 23:12:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-25 23:12:46 --> Helper loaded: form_helper
INFO - 2016-12-25 23:12:46 --> Form Validation Class Initialized
INFO - 2016-12-25 23:12:46 --> Final output sent to browser
DEBUG - 2016-12-25 23:12:46 --> Total execution time: 0.0150
INFO - 2016-12-25 23:12:46 --> Config Class Initialized
INFO - 2016-12-25 23:12:46 --> Hooks Class Initialized
DEBUG - 2016-12-25 23:12:46 --> UTF-8 Support Enabled
INFO - 2016-12-25 23:12:46 --> Utf8 Class Initialized
INFO - 2016-12-25 23:12:46 --> URI Class Initialized
INFO - 2016-12-25 23:12:46 --> Router Class Initialized
INFO - 2016-12-25 23:12:46 --> Output Class Initialized
INFO - 2016-12-25 23:12:46 --> Security Class Initialized
DEBUG - 2016-12-25 23:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-25 23:12:46 --> Input Class Initialized
INFO - 2016-12-25 23:12:46 --> Language Class Initialized
INFO - 2016-12-25 23:12:46 --> Loader Class Initialized
INFO - 2016-12-25 23:12:46 --> Database Driver Class Initialized
INFO - 2016-12-25 23:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-25 23:12:46 --> Controller Class Initialized
INFO - 2016-12-25 23:12:46 --> Helper loaded: date_helper
INFO - 2016-12-25 23:12:46 --> Helper loaded: url_helper
DEBUG - 2016-12-25 23:12:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-25 23:12:46 --> Helper loaded: form_helper
INFO - 2016-12-25 23:12:46 --> Form Validation Class Initialized
INFO - 2016-12-25 23:12:46 --> Final output sent to browser
DEBUG - 2016-12-25 23:12:46 --> Total execution time: 0.0157
INFO - 2016-12-25 23:12:52 --> Config Class Initialized
INFO - 2016-12-25 23:12:52 --> Hooks Class Initialized
DEBUG - 2016-12-25 23:12:52 --> UTF-8 Support Enabled
INFO - 2016-12-25 23:12:52 --> Utf8 Class Initialized
INFO - 2016-12-25 23:12:52 --> URI Class Initialized
INFO - 2016-12-25 23:12:52 --> Router Class Initialized
INFO - 2016-12-25 23:12:52 --> Output Class Initialized
INFO - 2016-12-25 23:12:52 --> Security Class Initialized
DEBUG - 2016-12-25 23:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-25 23:12:52 --> Input Class Initialized
INFO - 2016-12-25 23:12:52 --> Language Class Initialized
INFO - 2016-12-25 23:12:52 --> Loader Class Initialized
INFO - 2016-12-25 23:12:52 --> Database Driver Class Initialized
INFO - 2016-12-25 23:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-25 23:12:52 --> Controller Class Initialized
INFO - 2016-12-25 23:12:52 --> Upload Class Initialized
INFO - 2016-12-25 23:12:52 --> Helper loaded: date_helper
DEBUG - 2016-12-25 23:12:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-25 23:12:52 --> Helper loaded: url_helper
INFO - 2016-12-25 23:12:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-25 23:12:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-25 23:12:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-25 23:12:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-25 23:12:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-25 23:12:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-25 23:12:52 --> Final output sent to browser
DEBUG - 2016-12-25 23:12:52 --> Total execution time: 0.0629
INFO - 2016-12-25 23:13:11 --> Config Class Initialized
INFO - 2016-12-25 23:13:11 --> Hooks Class Initialized
DEBUG - 2016-12-25 23:13:11 --> UTF-8 Support Enabled
INFO - 2016-12-25 23:13:11 --> Utf8 Class Initialized
INFO - 2016-12-25 23:13:11 --> URI Class Initialized
INFO - 2016-12-25 23:13:11 --> Router Class Initialized
INFO - 2016-12-25 23:13:11 --> Output Class Initialized
INFO - 2016-12-25 23:13:11 --> Security Class Initialized
DEBUG - 2016-12-25 23:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-25 23:13:11 --> Input Class Initialized
INFO - 2016-12-25 23:13:11 --> Language Class Initialized
INFO - 2016-12-25 23:13:11 --> Loader Class Initialized
INFO - 2016-12-25 23:13:11 --> Database Driver Class Initialized
INFO - 2016-12-25 23:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-25 23:13:11 --> Controller Class Initialized
INFO - 2016-12-25 23:13:11 --> Helper loaded: date_helper
DEBUG - 2016-12-25 23:13:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-25 23:13:11 --> Helper loaded: url_helper
INFO - 2016-12-25 23:13:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-25 23:13:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-25 23:13:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-25 23:13:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-25 23:13:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-25 23:13:11 --> Final output sent to browser
DEBUG - 2016-12-25 23:13:11 --> Total execution time: 0.0312
INFO - 2016-12-25 23:13:20 --> Config Class Initialized
INFO - 2016-12-25 23:13:20 --> Hooks Class Initialized
DEBUG - 2016-12-25 23:13:20 --> UTF-8 Support Enabled
INFO - 2016-12-25 23:13:20 --> Utf8 Class Initialized
INFO - 2016-12-25 23:13:20 --> URI Class Initialized
INFO - 2016-12-25 23:13:20 --> Router Class Initialized
INFO - 2016-12-25 23:13:20 --> Output Class Initialized
INFO - 2016-12-25 23:13:20 --> Security Class Initialized
DEBUG - 2016-12-25 23:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-25 23:13:20 --> Input Class Initialized
INFO - 2016-12-25 23:13:20 --> Language Class Initialized
INFO - 2016-12-25 23:13:20 --> Loader Class Initialized
INFO - 2016-12-25 23:13:20 --> Database Driver Class Initialized
INFO - 2016-12-25 23:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-25 23:13:20 --> Controller Class Initialized
INFO - 2016-12-25 23:13:20 --> Helper loaded: date_helper
DEBUG - 2016-12-25 23:13:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-25 23:13:21 --> Helper loaded: url_helper
INFO - 2016-12-25 23:13:21 --> Final output sent to browser
DEBUG - 2016-12-25 23:13:21 --> Total execution time: 0.3719
INFO - 2016-12-25 23:13:32 --> Config Class Initialized
INFO - 2016-12-25 23:13:32 --> Hooks Class Initialized
DEBUG - 2016-12-25 23:13:32 --> UTF-8 Support Enabled
INFO - 2016-12-25 23:13:32 --> Utf8 Class Initialized
INFO - 2016-12-25 23:13:32 --> URI Class Initialized
INFO - 2016-12-25 23:13:32 --> Router Class Initialized
INFO - 2016-12-25 23:13:32 --> Output Class Initialized
INFO - 2016-12-25 23:13:32 --> Security Class Initialized
DEBUG - 2016-12-25 23:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-25 23:13:32 --> Input Class Initialized
INFO - 2016-12-25 23:13:32 --> Language Class Initialized
INFO - 2016-12-25 23:13:32 --> Loader Class Initialized
INFO - 2016-12-25 23:13:33 --> Database Driver Class Initialized
INFO - 2016-12-25 23:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-25 23:13:33 --> Controller Class Initialized
INFO - 2016-12-25 23:13:33 --> Helper loaded: url_helper
DEBUG - 2016-12-25 23:13:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-25 23:13:33 --> Config Class Initialized
INFO - 2016-12-25 23:13:33 --> Hooks Class Initialized
DEBUG - 2016-12-25 23:13:33 --> UTF-8 Support Enabled
INFO - 2016-12-25 23:13:33 --> Utf8 Class Initialized
INFO - 2016-12-25 23:13:33 --> URI Class Initialized
DEBUG - 2016-12-25 23:13:33 --> No URI present. Default controller set.
INFO - 2016-12-25 23:13:33 --> Router Class Initialized
INFO - 2016-12-25 23:13:33 --> Output Class Initialized
INFO - 2016-12-25 23:13:33 --> Security Class Initialized
DEBUG - 2016-12-25 23:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-25 23:13:33 --> Input Class Initialized
INFO - 2016-12-25 23:13:33 --> Language Class Initialized
INFO - 2016-12-25 23:13:33 --> Loader Class Initialized
INFO - 2016-12-25 23:13:33 --> Database Driver Class Initialized
INFO - 2016-12-25 23:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-25 23:13:33 --> Controller Class Initialized
INFO - 2016-12-25 23:13:33 --> Helper loaded: url_helper
DEBUG - 2016-12-25 23:13:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-25 23:13:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-25 23:13:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-25 23:13:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-25 23:13:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-25 23:13:33 --> Final output sent to browser
DEBUG - 2016-12-25 23:13:33 --> Total execution time: 0.0975

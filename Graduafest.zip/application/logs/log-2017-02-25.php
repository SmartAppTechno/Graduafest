<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-25 01:07:59 --> Config Class Initialized
INFO - 2017-02-25 01:07:59 --> Hooks Class Initialized
DEBUG - 2017-02-25 01:07:59 --> UTF-8 Support Enabled
INFO - 2017-02-25 01:07:59 --> Utf8 Class Initialized
INFO - 2017-02-25 01:07:59 --> URI Class Initialized
INFO - 2017-02-25 01:07:59 --> Router Class Initialized
INFO - 2017-02-25 01:07:59 --> Output Class Initialized
INFO - 2017-02-25 01:07:59 --> Security Class Initialized
DEBUG - 2017-02-25 01:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 01:07:59 --> Input Class Initialized
INFO - 2017-02-25 01:07:59 --> Language Class Initialized
INFO - 2017-02-25 01:07:59 --> Loader Class Initialized
INFO - 2017-02-25 01:08:00 --> Database Driver Class Initialized
INFO - 2017-02-25 01:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 01:08:00 --> Controller Class Initialized
INFO - 2017-02-25 01:08:00 --> Helper loaded: url_helper
DEBUG - 2017-02-25 01:08:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 01:08:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 01:08:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 01:08:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 01:08:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 01:08:00 --> Final output sent to browser
DEBUG - 2017-02-25 01:08:00 --> Total execution time: 2.0210
INFO - 2017-02-25 01:09:27 --> Config Class Initialized
INFO - 2017-02-25 01:09:27 --> Hooks Class Initialized
DEBUG - 2017-02-25 01:09:27 --> UTF-8 Support Enabled
INFO - 2017-02-25 01:09:27 --> Utf8 Class Initialized
INFO - 2017-02-25 01:09:27 --> URI Class Initialized
INFO - 2017-02-25 01:09:27 --> Router Class Initialized
INFO - 2017-02-25 01:09:28 --> Output Class Initialized
INFO - 2017-02-25 01:09:28 --> Security Class Initialized
DEBUG - 2017-02-25 01:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 01:09:28 --> Input Class Initialized
INFO - 2017-02-25 01:09:28 --> Language Class Initialized
INFO - 2017-02-25 01:09:28 --> Loader Class Initialized
INFO - 2017-02-25 01:09:28 --> Database Driver Class Initialized
INFO - 2017-02-25 01:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 01:09:28 --> Controller Class Initialized
INFO - 2017-02-25 01:09:28 --> Helper loaded: url_helper
DEBUG - 2017-02-25 01:09:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 01:09:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 01:09:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 01:09:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 01:09:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 01:09:29 --> Final output sent to browser
DEBUG - 2017-02-25 01:09:29 --> Total execution time: 1.5043
INFO - 2017-02-25 01:10:31 --> Config Class Initialized
INFO - 2017-02-25 01:10:31 --> Hooks Class Initialized
DEBUG - 2017-02-25 01:10:31 --> UTF-8 Support Enabled
INFO - 2017-02-25 01:10:31 --> Utf8 Class Initialized
INFO - 2017-02-25 01:10:31 --> URI Class Initialized
DEBUG - 2017-02-25 01:10:31 --> No URI present. Default controller set.
INFO - 2017-02-25 01:10:31 --> Router Class Initialized
INFO - 2017-02-25 01:10:31 --> Output Class Initialized
INFO - 2017-02-25 01:10:31 --> Security Class Initialized
DEBUG - 2017-02-25 01:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 01:10:31 --> Input Class Initialized
INFO - 2017-02-25 01:10:31 --> Language Class Initialized
INFO - 2017-02-25 01:10:31 --> Loader Class Initialized
INFO - 2017-02-25 01:10:32 --> Database Driver Class Initialized
INFO - 2017-02-25 01:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 01:10:32 --> Controller Class Initialized
INFO - 2017-02-25 01:10:32 --> Helper loaded: url_helper
DEBUG - 2017-02-25 01:10:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 01:10:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 01:10:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 01:10:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 01:10:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 01:10:32 --> Final output sent to browser
DEBUG - 2017-02-25 01:10:32 --> Total execution time: 1.5087
INFO - 2017-02-25 01:10:33 --> Config Class Initialized
INFO - 2017-02-25 01:10:33 --> Hooks Class Initialized
DEBUG - 2017-02-25 01:10:33 --> UTF-8 Support Enabled
INFO - 2017-02-25 01:10:33 --> Utf8 Class Initialized
INFO - 2017-02-25 01:10:33 --> URI Class Initialized
DEBUG - 2017-02-25 01:10:33 --> No URI present. Default controller set.
INFO - 2017-02-25 01:10:33 --> Router Class Initialized
INFO - 2017-02-25 01:10:33 --> Output Class Initialized
INFO - 2017-02-25 01:10:33 --> Security Class Initialized
DEBUG - 2017-02-25 01:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 01:10:33 --> Input Class Initialized
INFO - 2017-02-25 01:10:33 --> Language Class Initialized
INFO - 2017-02-25 01:10:33 --> Loader Class Initialized
INFO - 2017-02-25 01:10:33 --> Database Driver Class Initialized
INFO - 2017-02-25 01:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 01:10:33 --> Controller Class Initialized
INFO - 2017-02-25 01:10:33 --> Helper loaded: url_helper
DEBUG - 2017-02-25 01:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 01:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 01:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 01:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 01:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 01:10:33 --> Final output sent to browser
DEBUG - 2017-02-25 01:10:33 --> Total execution time: 0.0138
INFO - 2017-02-25 02:41:03 --> Config Class Initialized
INFO - 2017-02-25 02:41:03 --> Hooks Class Initialized
DEBUG - 2017-02-25 02:41:03 --> UTF-8 Support Enabled
INFO - 2017-02-25 02:41:03 --> Utf8 Class Initialized
INFO - 2017-02-25 02:41:03 --> URI Class Initialized
INFO - 2017-02-25 02:41:03 --> Router Class Initialized
INFO - 2017-02-25 02:41:03 --> Output Class Initialized
INFO - 2017-02-25 02:41:03 --> Security Class Initialized
DEBUG - 2017-02-25 02:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 02:41:03 --> Input Class Initialized
INFO - 2017-02-25 02:41:03 --> Language Class Initialized
INFO - 2017-02-25 02:41:03 --> Loader Class Initialized
INFO - 2017-02-25 02:41:04 --> Database Driver Class Initialized
INFO - 2017-02-25 02:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 02:41:04 --> Controller Class Initialized
INFO - 2017-02-25 02:41:04 --> Helper loaded: url_helper
DEBUG - 2017-02-25 02:41:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 02:41:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 02:41:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 02:41:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 02:41:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 02:41:04 --> Final output sent to browser
DEBUG - 2017-02-25 02:41:04 --> Total execution time: 1.2511
INFO - 2017-02-25 02:41:36 --> Config Class Initialized
INFO - 2017-02-25 02:41:36 --> Hooks Class Initialized
DEBUG - 2017-02-25 02:41:36 --> UTF-8 Support Enabled
INFO - 2017-02-25 02:41:36 --> Utf8 Class Initialized
INFO - 2017-02-25 02:41:36 --> URI Class Initialized
DEBUG - 2017-02-25 02:41:36 --> No URI present. Default controller set.
INFO - 2017-02-25 02:41:36 --> Router Class Initialized
INFO - 2017-02-25 02:41:36 --> Output Class Initialized
INFO - 2017-02-25 02:41:36 --> Security Class Initialized
DEBUG - 2017-02-25 02:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 02:41:36 --> Input Class Initialized
INFO - 2017-02-25 02:41:36 --> Language Class Initialized
INFO - 2017-02-25 02:41:36 --> Loader Class Initialized
INFO - 2017-02-25 02:41:37 --> Database Driver Class Initialized
INFO - 2017-02-25 02:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 02:41:37 --> Controller Class Initialized
INFO - 2017-02-25 02:41:37 --> Helper loaded: url_helper
DEBUG - 2017-02-25 02:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 02:41:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 02:41:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 02:41:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 02:41:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 02:41:38 --> Final output sent to browser
DEBUG - 2017-02-25 02:41:38 --> Total execution time: 1.4260
INFO - 2017-02-25 03:41:36 --> Config Class Initialized
INFO - 2017-02-25 03:41:36 --> Hooks Class Initialized
DEBUG - 2017-02-25 03:41:36 --> UTF-8 Support Enabled
INFO - 2017-02-25 03:41:36 --> Utf8 Class Initialized
INFO - 2017-02-25 03:41:36 --> URI Class Initialized
INFO - 2017-02-25 03:41:36 --> Router Class Initialized
INFO - 2017-02-25 03:41:36 --> Output Class Initialized
INFO - 2017-02-25 03:41:36 --> Security Class Initialized
DEBUG - 2017-02-25 03:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 03:41:36 --> Input Class Initialized
INFO - 2017-02-25 03:41:36 --> Language Class Initialized
INFO - 2017-02-25 03:41:37 --> Loader Class Initialized
INFO - 2017-02-25 03:41:37 --> Database Driver Class Initialized
INFO - 2017-02-25 03:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 03:41:38 --> Controller Class Initialized
INFO - 2017-02-25 03:41:38 --> Helper loaded: url_helper
DEBUG - 2017-02-25 03:41:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 03:41:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 03:41:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 03:41:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 03:41:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 03:41:38 --> Final output sent to browser
DEBUG - 2017-02-25 03:41:38 --> Total execution time: 1.7225
INFO - 2017-02-25 03:41:46 --> Config Class Initialized
INFO - 2017-02-25 03:41:46 --> Hooks Class Initialized
DEBUG - 2017-02-25 03:41:46 --> UTF-8 Support Enabled
INFO - 2017-02-25 03:41:46 --> Utf8 Class Initialized
INFO - 2017-02-25 03:41:46 --> URI Class Initialized
DEBUG - 2017-02-25 03:41:46 --> No URI present. Default controller set.
INFO - 2017-02-25 03:41:46 --> Router Class Initialized
INFO - 2017-02-25 03:41:46 --> Output Class Initialized
INFO - 2017-02-25 03:41:46 --> Security Class Initialized
DEBUG - 2017-02-25 03:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 03:41:46 --> Input Class Initialized
INFO - 2017-02-25 03:41:46 --> Language Class Initialized
INFO - 2017-02-25 03:41:46 --> Loader Class Initialized
INFO - 2017-02-25 03:41:46 --> Database Driver Class Initialized
INFO - 2017-02-25 03:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 03:41:46 --> Controller Class Initialized
INFO - 2017-02-25 03:41:46 --> Helper loaded: url_helper
DEBUG - 2017-02-25 03:41:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 03:41:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 03:41:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 03:41:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 03:41:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 03:41:46 --> Final output sent to browser
DEBUG - 2017-02-25 03:41:46 --> Total execution time: 0.0138
INFO - 2017-02-25 05:49:02 --> Config Class Initialized
INFO - 2017-02-25 05:49:02 --> Hooks Class Initialized
DEBUG - 2017-02-25 05:49:02 --> UTF-8 Support Enabled
INFO - 2017-02-25 05:49:02 --> Utf8 Class Initialized
INFO - 2017-02-25 05:49:02 --> URI Class Initialized
INFO - 2017-02-25 05:49:02 --> Router Class Initialized
INFO - 2017-02-25 05:49:02 --> Output Class Initialized
INFO - 2017-02-25 05:49:02 --> Security Class Initialized
DEBUG - 2017-02-25 05:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 05:49:03 --> Input Class Initialized
INFO - 2017-02-25 05:49:03 --> Language Class Initialized
INFO - 2017-02-25 05:49:03 --> Loader Class Initialized
INFO - 2017-02-25 05:49:03 --> Database Driver Class Initialized
INFO - 2017-02-25 05:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 05:49:03 --> Controller Class Initialized
INFO - 2017-02-25 05:49:03 --> Helper loaded: url_helper
DEBUG - 2017-02-25 05:49:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 05:49:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 05:49:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 05:49:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 05:49:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 05:49:04 --> Final output sent to browser
DEBUG - 2017-02-25 05:49:04 --> Total execution time: 1.7503
INFO - 2017-02-25 05:49:50 --> Config Class Initialized
INFO - 2017-02-25 05:49:50 --> Hooks Class Initialized
DEBUG - 2017-02-25 05:49:50 --> UTF-8 Support Enabled
INFO - 2017-02-25 05:49:50 --> Utf8 Class Initialized
INFO - 2017-02-25 05:49:50 --> URI Class Initialized
DEBUG - 2017-02-25 05:49:50 --> No URI present. Default controller set.
INFO - 2017-02-25 05:49:50 --> Router Class Initialized
INFO - 2017-02-25 05:49:50 --> Output Class Initialized
INFO - 2017-02-25 05:49:50 --> Security Class Initialized
DEBUG - 2017-02-25 05:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 05:49:50 --> Input Class Initialized
INFO - 2017-02-25 05:49:50 --> Language Class Initialized
INFO - 2017-02-25 05:49:50 --> Loader Class Initialized
INFO - 2017-02-25 05:49:50 --> Database Driver Class Initialized
INFO - 2017-02-25 05:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 05:49:51 --> Controller Class Initialized
INFO - 2017-02-25 05:49:51 --> Helper loaded: url_helper
DEBUG - 2017-02-25 05:49:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 05:49:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 05:49:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 05:49:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 05:49:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 05:49:51 --> Final output sent to browser
DEBUG - 2017-02-25 05:49:51 --> Total execution time: 0.8503
INFO - 2017-02-25 05:52:43 --> Config Class Initialized
INFO - 2017-02-25 05:52:43 --> Hooks Class Initialized
DEBUG - 2017-02-25 05:52:44 --> UTF-8 Support Enabled
INFO - 2017-02-25 05:52:44 --> Utf8 Class Initialized
INFO - 2017-02-25 05:52:44 --> URI Class Initialized
INFO - 2017-02-25 05:52:44 --> Router Class Initialized
INFO - 2017-02-25 05:52:44 --> Output Class Initialized
INFO - 2017-02-25 05:52:44 --> Security Class Initialized
DEBUG - 2017-02-25 05:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 05:52:44 --> Input Class Initialized
INFO - 2017-02-25 05:52:44 --> Language Class Initialized
INFO - 2017-02-25 05:52:44 --> Loader Class Initialized
INFO - 2017-02-25 05:52:44 --> Database Driver Class Initialized
INFO - 2017-02-25 05:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 05:52:45 --> Controller Class Initialized
INFO - 2017-02-25 05:52:45 --> Helper loaded: url_helper
DEBUG - 2017-02-25 05:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 05:52:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 05:52:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 05:52:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 05:52:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 05:52:45 --> Final output sent to browser
DEBUG - 2017-02-25 05:52:45 --> Total execution time: 1.7260
INFO - 2017-02-25 05:53:06 --> Config Class Initialized
INFO - 2017-02-25 05:53:06 --> Hooks Class Initialized
DEBUG - 2017-02-25 05:53:06 --> UTF-8 Support Enabled
INFO - 2017-02-25 05:53:06 --> Utf8 Class Initialized
INFO - 2017-02-25 05:53:06 --> URI Class Initialized
DEBUG - 2017-02-25 05:53:06 --> No URI present. Default controller set.
INFO - 2017-02-25 05:53:06 --> Router Class Initialized
INFO - 2017-02-25 05:53:06 --> Output Class Initialized
INFO - 2017-02-25 05:53:06 --> Security Class Initialized
DEBUG - 2017-02-25 05:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 05:53:06 --> Input Class Initialized
INFO - 2017-02-25 05:53:06 --> Language Class Initialized
INFO - 2017-02-25 05:53:06 --> Loader Class Initialized
INFO - 2017-02-25 05:53:06 --> Database Driver Class Initialized
INFO - 2017-02-25 05:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 05:53:06 --> Controller Class Initialized
INFO - 2017-02-25 05:53:06 --> Helper loaded: url_helper
DEBUG - 2017-02-25 05:53:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 05:53:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 05:53:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 05:53:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 05:53:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 05:53:06 --> Final output sent to browser
DEBUG - 2017-02-25 05:53:06 --> Total execution time: 0.0141
INFO - 2017-02-25 07:07:31 --> Config Class Initialized
INFO - 2017-02-25 07:07:31 --> Hooks Class Initialized
DEBUG - 2017-02-25 07:07:31 --> UTF-8 Support Enabled
INFO - 2017-02-25 07:07:31 --> Utf8 Class Initialized
INFO - 2017-02-25 07:07:31 --> URI Class Initialized
INFO - 2017-02-25 07:07:32 --> Router Class Initialized
INFO - 2017-02-25 07:07:32 --> Output Class Initialized
INFO - 2017-02-25 07:07:32 --> Security Class Initialized
DEBUG - 2017-02-25 07:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 07:07:32 --> Input Class Initialized
INFO - 2017-02-25 07:07:32 --> Language Class Initialized
INFO - 2017-02-25 07:07:32 --> Loader Class Initialized
INFO - 2017-02-25 07:07:32 --> Database Driver Class Initialized
INFO - 2017-02-25 07:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 07:07:32 --> Controller Class Initialized
INFO - 2017-02-25 07:07:32 --> Helper loaded: url_helper
DEBUG - 2017-02-25 07:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 07:07:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 07:07:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 07:07:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 07:07:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 07:07:33 --> Final output sent to browser
DEBUG - 2017-02-25 07:07:33 --> Total execution time: 1.7526
INFO - 2017-02-25 14:11:49 --> Config Class Initialized
INFO - 2017-02-25 14:11:49 --> Hooks Class Initialized
DEBUG - 2017-02-25 14:11:49 --> UTF-8 Support Enabled
INFO - 2017-02-25 14:11:49 --> Utf8 Class Initialized
INFO - 2017-02-25 14:11:49 --> URI Class Initialized
INFO - 2017-02-25 14:11:49 --> Router Class Initialized
INFO - 2017-02-25 14:11:49 --> Output Class Initialized
INFO - 2017-02-25 14:11:49 --> Security Class Initialized
DEBUG - 2017-02-25 14:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 14:11:49 --> Input Class Initialized
INFO - 2017-02-25 14:11:49 --> Language Class Initialized
INFO - 2017-02-25 14:11:49 --> Loader Class Initialized
INFO - 2017-02-25 14:11:49 --> Database Driver Class Initialized
INFO - 2017-02-25 14:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 14:11:50 --> Controller Class Initialized
INFO - 2017-02-25 14:11:50 --> Helper loaded: url_helper
DEBUG - 2017-02-25 14:11:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 14:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 14:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 14:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 14:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 14:11:50 --> Final output sent to browser
DEBUG - 2017-02-25 14:11:50 --> Total execution time: 1.5058
INFO - 2017-02-25 14:12:00 --> Config Class Initialized
INFO - 2017-02-25 14:12:00 --> Hooks Class Initialized
DEBUG - 2017-02-25 14:12:00 --> UTF-8 Support Enabled
INFO - 2017-02-25 14:12:00 --> Utf8 Class Initialized
INFO - 2017-02-25 14:12:00 --> URI Class Initialized
DEBUG - 2017-02-25 14:12:00 --> No URI present. Default controller set.
INFO - 2017-02-25 14:12:00 --> Router Class Initialized
INFO - 2017-02-25 14:12:00 --> Output Class Initialized
INFO - 2017-02-25 14:12:00 --> Security Class Initialized
DEBUG - 2017-02-25 14:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 14:12:00 --> Input Class Initialized
INFO - 2017-02-25 14:12:00 --> Language Class Initialized
INFO - 2017-02-25 14:12:00 --> Loader Class Initialized
INFO - 2017-02-25 14:12:00 --> Database Driver Class Initialized
INFO - 2017-02-25 14:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 14:12:00 --> Controller Class Initialized
INFO - 2017-02-25 14:12:00 --> Helper loaded: url_helper
DEBUG - 2017-02-25 14:12:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 14:12:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 14:12:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 14:12:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 14:12:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 14:12:01 --> Final output sent to browser
DEBUG - 2017-02-25 14:12:01 --> Total execution time: 1.2602
INFO - 2017-02-25 14:12:01 --> Config Class Initialized
INFO - 2017-02-25 14:12:01 --> Hooks Class Initialized
DEBUG - 2017-02-25 14:12:01 --> UTF-8 Support Enabled
INFO - 2017-02-25 14:12:01 --> Utf8 Class Initialized
INFO - 2017-02-25 14:12:01 --> URI Class Initialized
INFO - 2017-02-25 14:12:01 --> Router Class Initialized
INFO - 2017-02-25 14:12:01 --> Output Class Initialized
INFO - 2017-02-25 14:12:01 --> Security Class Initialized
DEBUG - 2017-02-25 14:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 14:12:01 --> Input Class Initialized
INFO - 2017-02-25 14:12:01 --> Language Class Initialized
INFO - 2017-02-25 14:12:01 --> Loader Class Initialized
INFO - 2017-02-25 14:12:01 --> Database Driver Class Initialized
INFO - 2017-02-25 14:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 14:12:01 --> Controller Class Initialized
INFO - 2017-02-25 14:12:01 --> Helper loaded: url_helper
DEBUG - 2017-02-25 14:12:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 14:12:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 14:12:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 14:12:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 14:12:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 14:12:01 --> Final output sent to browser
DEBUG - 2017-02-25 14:12:01 --> Total execution time: 0.0143
INFO - 2017-02-25 14:12:06 --> Config Class Initialized
INFO - 2017-02-25 14:12:06 --> Hooks Class Initialized
DEBUG - 2017-02-25 14:12:06 --> UTF-8 Support Enabled
INFO - 2017-02-25 14:12:06 --> Utf8 Class Initialized
INFO - 2017-02-25 14:12:06 --> URI Class Initialized
DEBUG - 2017-02-25 14:12:06 --> No URI present. Default controller set.
INFO - 2017-02-25 14:12:06 --> Router Class Initialized
INFO - 2017-02-25 14:12:06 --> Output Class Initialized
INFO - 2017-02-25 14:12:06 --> Security Class Initialized
DEBUG - 2017-02-25 14:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 14:12:06 --> Input Class Initialized
INFO - 2017-02-25 14:12:06 --> Language Class Initialized
INFO - 2017-02-25 14:12:06 --> Loader Class Initialized
INFO - 2017-02-25 14:12:06 --> Database Driver Class Initialized
INFO - 2017-02-25 14:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 14:12:06 --> Controller Class Initialized
INFO - 2017-02-25 14:12:06 --> Helper loaded: url_helper
DEBUG - 2017-02-25 14:12:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 14:12:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 14:12:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 14:12:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 14:12:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 14:12:06 --> Final output sent to browser
DEBUG - 2017-02-25 14:12:06 --> Total execution time: 0.0137
INFO - 2017-02-25 16:36:01 --> Config Class Initialized
INFO - 2017-02-25 16:36:01 --> Hooks Class Initialized
DEBUG - 2017-02-25 16:36:01 --> UTF-8 Support Enabled
INFO - 2017-02-25 16:36:01 --> Utf8 Class Initialized
INFO - 2017-02-25 16:36:01 --> URI Class Initialized
INFO - 2017-02-25 16:36:01 --> Router Class Initialized
INFO - 2017-02-25 16:36:01 --> Output Class Initialized
INFO - 2017-02-25 16:36:01 --> Security Class Initialized
DEBUG - 2017-02-25 16:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 16:36:01 --> Input Class Initialized
INFO - 2017-02-25 16:36:01 --> Language Class Initialized
INFO - 2017-02-25 16:36:01 --> Loader Class Initialized
INFO - 2017-02-25 16:36:02 --> Database Driver Class Initialized
INFO - 2017-02-25 16:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 16:36:02 --> Controller Class Initialized
INFO - 2017-02-25 16:36:02 --> Helper loaded: url_helper
DEBUG - 2017-02-25 16:36:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 16:36:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 16:36:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 16:36:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 16:36:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 16:36:03 --> Final output sent to browser
DEBUG - 2017-02-25 16:36:03 --> Total execution time: 2.2062
INFO - 2017-02-25 16:36:14 --> Config Class Initialized
INFO - 2017-02-25 16:36:14 --> Hooks Class Initialized
DEBUG - 2017-02-25 16:36:14 --> UTF-8 Support Enabled
INFO - 2017-02-25 16:36:14 --> Utf8 Class Initialized
INFO - 2017-02-25 16:36:14 --> URI Class Initialized
INFO - 2017-02-25 16:36:14 --> Router Class Initialized
INFO - 2017-02-25 16:36:14 --> Output Class Initialized
INFO - 2017-02-25 16:36:14 --> Security Class Initialized
DEBUG - 2017-02-25 16:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 16:36:14 --> Input Class Initialized
INFO - 2017-02-25 16:36:14 --> Language Class Initialized
INFO - 2017-02-25 16:36:14 --> Loader Class Initialized
INFO - 2017-02-25 16:36:15 --> Database Driver Class Initialized
INFO - 2017-02-25 16:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 16:36:15 --> Controller Class Initialized
INFO - 2017-02-25 16:36:15 --> Helper loaded: url_helper
DEBUG - 2017-02-25 16:36:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 16:36:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 16:36:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 16:36:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 16:36:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 16:36:15 --> Final output sent to browser
DEBUG - 2017-02-25 16:36:15 --> Total execution time: 0.8812
INFO - 2017-02-25 16:36:28 --> Config Class Initialized
INFO - 2017-02-25 16:36:28 --> Hooks Class Initialized
DEBUG - 2017-02-25 16:36:28 --> UTF-8 Support Enabled
INFO - 2017-02-25 16:36:28 --> Utf8 Class Initialized
INFO - 2017-02-25 16:36:28 --> URI Class Initialized
DEBUG - 2017-02-25 16:36:28 --> No URI present. Default controller set.
INFO - 2017-02-25 16:36:28 --> Router Class Initialized
INFO - 2017-02-25 16:36:28 --> Output Class Initialized
INFO - 2017-02-25 16:36:28 --> Security Class Initialized
DEBUG - 2017-02-25 16:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 16:36:28 --> Input Class Initialized
INFO - 2017-02-25 16:36:28 --> Language Class Initialized
INFO - 2017-02-25 16:36:28 --> Loader Class Initialized
INFO - 2017-02-25 16:36:28 --> Database Driver Class Initialized
INFO - 2017-02-25 16:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 16:36:28 --> Controller Class Initialized
INFO - 2017-02-25 16:36:28 --> Helper loaded: url_helper
DEBUG - 2017-02-25 16:36:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 16:36:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 16:36:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 16:36:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 16:36:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 16:36:28 --> Final output sent to browser
DEBUG - 2017-02-25 16:36:28 --> Total execution time: 0.0136
INFO - 2017-02-25 16:36:30 --> Config Class Initialized
INFO - 2017-02-25 16:36:30 --> Hooks Class Initialized
DEBUG - 2017-02-25 16:36:30 --> UTF-8 Support Enabled
INFO - 2017-02-25 16:36:30 --> Utf8 Class Initialized
INFO - 2017-02-25 16:36:30 --> URI Class Initialized
DEBUG - 2017-02-25 16:36:30 --> No URI present. Default controller set.
INFO - 2017-02-25 16:36:30 --> Router Class Initialized
INFO - 2017-02-25 16:36:30 --> Output Class Initialized
INFO - 2017-02-25 16:36:30 --> Security Class Initialized
DEBUG - 2017-02-25 16:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 16:36:30 --> Input Class Initialized
INFO - 2017-02-25 16:36:30 --> Language Class Initialized
INFO - 2017-02-25 16:36:30 --> Loader Class Initialized
INFO - 2017-02-25 16:36:30 --> Database Driver Class Initialized
INFO - 2017-02-25 16:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 16:36:30 --> Controller Class Initialized
INFO - 2017-02-25 16:36:30 --> Helper loaded: url_helper
DEBUG - 2017-02-25 16:36:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 16:36:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 16:36:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 16:36:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 16:36:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 16:36:30 --> Final output sent to browser
DEBUG - 2017-02-25 16:36:30 --> Total execution time: 0.0138
INFO - 2017-02-25 19:00:05 --> Config Class Initialized
INFO - 2017-02-25 19:00:05 --> Hooks Class Initialized
DEBUG - 2017-02-25 19:00:05 --> UTF-8 Support Enabled
INFO - 2017-02-25 19:00:05 --> Utf8 Class Initialized
INFO - 2017-02-25 19:00:05 --> URI Class Initialized
INFO - 2017-02-25 19:00:05 --> Router Class Initialized
INFO - 2017-02-25 19:00:05 --> Output Class Initialized
INFO - 2017-02-25 19:00:05 --> Security Class Initialized
DEBUG - 2017-02-25 19:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 19:00:05 --> Input Class Initialized
INFO - 2017-02-25 19:00:05 --> Language Class Initialized
INFO - 2017-02-25 19:00:05 --> Loader Class Initialized
INFO - 2017-02-25 19:00:06 --> Database Driver Class Initialized
INFO - 2017-02-25 19:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 19:00:06 --> Controller Class Initialized
INFO - 2017-02-25 19:00:06 --> Helper loaded: url_helper
DEBUG - 2017-02-25 19:00:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 19:00:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 19:00:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 19:00:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 19:00:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 19:00:06 --> Final output sent to browser
DEBUG - 2017-02-25 19:00:06 --> Total execution time: 1.5154
INFO - 2017-02-25 19:00:06 --> Config Class Initialized
INFO - 2017-02-25 19:00:06 --> Hooks Class Initialized
DEBUG - 2017-02-25 19:00:06 --> UTF-8 Support Enabled
INFO - 2017-02-25 19:00:06 --> Utf8 Class Initialized
INFO - 2017-02-25 19:00:06 --> URI Class Initialized
DEBUG - 2017-02-25 19:00:06 --> No URI present. Default controller set.
INFO - 2017-02-25 19:00:06 --> Router Class Initialized
INFO - 2017-02-25 19:00:06 --> Output Class Initialized
INFO - 2017-02-25 19:00:06 --> Security Class Initialized
DEBUG - 2017-02-25 19:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 19:00:06 --> Input Class Initialized
INFO - 2017-02-25 19:00:06 --> Language Class Initialized
INFO - 2017-02-25 19:00:06 --> Loader Class Initialized
INFO - 2017-02-25 19:00:06 --> Database Driver Class Initialized
INFO - 2017-02-25 19:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 19:00:06 --> Controller Class Initialized
INFO - 2017-02-25 19:00:06 --> Helper loaded: url_helper
DEBUG - 2017-02-25 19:00:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 19:00:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 19:00:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 19:00:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 19:00:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 19:00:06 --> Final output sent to browser
DEBUG - 2017-02-25 19:00:06 --> Total execution time: 0.0344
INFO - 2017-02-25 19:58:55 --> Config Class Initialized
INFO - 2017-02-25 19:58:55 --> Hooks Class Initialized
DEBUG - 2017-02-25 19:58:56 --> UTF-8 Support Enabled
INFO - 2017-02-25 19:58:56 --> Utf8 Class Initialized
INFO - 2017-02-25 19:58:56 --> URI Class Initialized
DEBUG - 2017-02-25 19:58:56 --> No URI present. Default controller set.
INFO - 2017-02-25 19:58:56 --> Router Class Initialized
INFO - 2017-02-25 19:58:56 --> Output Class Initialized
INFO - 2017-02-25 19:58:56 --> Security Class Initialized
DEBUG - 2017-02-25 19:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 19:58:56 --> Input Class Initialized
INFO - 2017-02-25 19:58:56 --> Language Class Initialized
INFO - 2017-02-25 19:58:56 --> Loader Class Initialized
INFO - 2017-02-25 19:58:56 --> Database Driver Class Initialized
INFO - 2017-02-25 19:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 19:58:57 --> Controller Class Initialized
INFO - 2017-02-25 19:58:57 --> Helper loaded: url_helper
DEBUG - 2017-02-25 19:58:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-25 19:58:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-25 19:58:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-25 19:58:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-25 19:58:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-25 19:58:58 --> Final output sent to browser
DEBUG - 2017-02-25 19:58:58 --> Total execution time: 2.1400

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-29 19:08:29 --> Config Class Initialized
INFO - 2016-11-29 19:08:30 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:08:30 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:08:30 --> Utf8 Class Initialized
INFO - 2016-11-29 19:08:30 --> URI Class Initialized
DEBUG - 2016-11-29 19:08:30 --> No URI present. Default controller set.
INFO - 2016-11-29 19:08:30 --> Router Class Initialized
INFO - 2016-11-29 19:08:30 --> Output Class Initialized
INFO - 2016-11-29 19:08:30 --> Security Class Initialized
DEBUG - 2016-11-29 19:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:08:30 --> Input Class Initialized
INFO - 2016-11-29 19:08:30 --> Language Class Initialized
INFO - 2016-11-29 19:08:30 --> Loader Class Initialized
INFO - 2016-11-29 19:08:30 --> Database Driver Class Initialized
INFO - 2016-11-29 19:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:08:31 --> Controller Class Initialized
INFO - 2016-11-29 19:08:31 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:08:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 19:08:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 19:08:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 19:08:31 --> Final output sent to browser
DEBUG - 2016-11-29 19:08:31 --> Total execution time: 1.7731
INFO - 2016-11-29 19:08:33 --> Config Class Initialized
INFO - 2016-11-29 19:08:33 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:08:33 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:08:33 --> Utf8 Class Initialized
INFO - 2016-11-29 19:08:33 --> URI Class Initialized
INFO - 2016-11-29 19:08:33 --> Config Class Initialized
INFO - 2016-11-29 19:08:33 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:08:33 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:08:33 --> Utf8 Class Initialized
INFO - 2016-11-29 19:08:33 --> URI Class Initialized
INFO - 2016-11-29 19:08:33 --> Router Class Initialized
INFO - 2016-11-29 19:08:33 --> Output Class Initialized
INFO - 2016-11-29 19:08:33 --> Security Class Initialized
DEBUG - 2016-11-29 19:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:08:33 --> Input Class Initialized
INFO - 2016-11-29 19:08:33 --> Language Class Initialized
ERROR - 2016-11-29 19:08:33 --> 404 Page Not Found: Img/about
INFO - 2016-11-29 19:08:33 --> Config Class Initialized
INFO - 2016-11-29 19:08:33 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:08:33 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:08:33 --> Utf8 Class Initialized
INFO - 2016-11-29 19:08:33 --> URI Class Initialized
INFO - 2016-11-29 19:08:33 --> Router Class Initialized
INFO - 2016-11-29 19:08:33 --> Output Class Initialized
INFO - 2016-11-29 19:08:33 --> Security Class Initialized
DEBUG - 2016-11-29 19:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:08:33 --> Input Class Initialized
INFO - 2016-11-29 19:08:33 --> Language Class Initialized
ERROR - 2016-11-29 19:08:33 --> 404 Page Not Found: Img/team
INFO - 2016-11-29 19:08:33 --> Router Class Initialized
INFO - 2016-11-29 19:08:33 --> Output Class Initialized
INFO - 2016-11-29 19:08:33 --> Security Class Initialized
DEBUG - 2016-11-29 19:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:08:33 --> Input Class Initialized
INFO - 2016-11-29 19:08:33 --> Language Class Initialized
ERROR - 2016-11-29 19:08:33 --> 404 Page Not Found: Img/team
INFO - 2016-11-29 19:08:33 --> Config Class Initialized
INFO - 2016-11-29 19:08:33 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:08:33 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:08:33 --> Utf8 Class Initialized
INFO - 2016-11-29 19:08:33 --> URI Class Initialized
INFO - 2016-11-29 19:08:33 --> Router Class Initialized
INFO - 2016-11-29 19:08:33 --> Output Class Initialized
INFO - 2016-11-29 19:08:33 --> Security Class Initialized
DEBUG - 2016-11-29 19:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:08:33 --> Input Class Initialized
INFO - 2016-11-29 19:08:33 --> Language Class Initialized
ERROR - 2016-11-29 19:08:33 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 19:08:33 --> Config Class Initialized
INFO - 2016-11-29 19:08:33 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:08:33 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:08:33 --> Utf8 Class Initialized
INFO - 2016-11-29 19:08:33 --> URI Class Initialized
INFO - 2016-11-29 19:08:33 --> Router Class Initialized
INFO - 2016-11-29 19:08:33 --> Output Class Initialized
INFO - 2016-11-29 19:08:33 --> Security Class Initialized
DEBUG - 2016-11-29 19:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:08:33 --> Input Class Initialized
INFO - 2016-11-29 19:08:33 --> Language Class Initialized
ERROR - 2016-11-29 19:08:33 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 19:08:35 --> Config Class Initialized
INFO - 2016-11-29 19:08:35 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:08:35 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:08:35 --> Utf8 Class Initialized
INFO - 2016-11-29 19:08:35 --> URI Class Initialized
INFO - 2016-11-29 19:08:35 --> Router Class Initialized
INFO - 2016-11-29 19:08:35 --> Output Class Initialized
INFO - 2016-11-29 19:08:35 --> Security Class Initialized
DEBUG - 2016-11-29 19:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:08:35 --> Input Class Initialized
INFO - 2016-11-29 19:08:35 --> Language Class Initialized
INFO - 2016-11-29 19:08:35 --> Loader Class Initialized
INFO - 2016-11-29 19:08:35 --> Database Driver Class Initialized
INFO - 2016-11-29 19:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:08:35 --> Controller Class Initialized
INFO - 2016-11-29 19:08:35 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:08:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 19:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 19:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 19:08:35 --> Final output sent to browser
DEBUG - 2016-11-29 19:08:35 --> Total execution time: 0.0221
INFO - 2016-11-29 19:11:05 --> Config Class Initialized
INFO - 2016-11-29 19:11:05 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:06 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:06 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:06 --> URI Class Initialized
DEBUG - 2016-11-29 19:11:06 --> No URI present. Default controller set.
INFO - 2016-11-29 19:11:06 --> Router Class Initialized
INFO - 2016-11-29 19:11:06 --> Output Class Initialized
INFO - 2016-11-29 19:11:06 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:06 --> Input Class Initialized
INFO - 2016-11-29 19:11:06 --> Language Class Initialized
INFO - 2016-11-29 19:11:06 --> Loader Class Initialized
INFO - 2016-11-29 19:11:06 --> Database Driver Class Initialized
INFO - 2016-11-29 19:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:11:06 --> Controller Class Initialized
INFO - 2016-11-29 19:11:06 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:11:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:11:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 19:11:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 19:11:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 19:11:06 --> Final output sent to browser
DEBUG - 2016-11-29 19:11:06 --> Total execution time: 0.5954
INFO - 2016-11-29 19:11:07 --> Config Class Initialized
INFO - 2016-11-29 19:11:07 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:07 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:07 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:07 --> URI Class Initialized
INFO - 2016-11-29 19:11:07 --> Router Class Initialized
INFO - 2016-11-29 19:11:07 --> Output Class Initialized
INFO - 2016-11-29 19:11:07 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:07 --> Input Class Initialized
INFO - 2016-11-29 19:11:07 --> Language Class Initialized
ERROR - 2016-11-29 19:11:07 --> 404 Page Not Found: Img/about
INFO - 2016-11-29 19:11:07 --> Config Class Initialized
INFO - 2016-11-29 19:11:07 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:07 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:07 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:07 --> URI Class Initialized
INFO - 2016-11-29 19:11:07 --> Router Class Initialized
INFO - 2016-11-29 19:11:07 --> Output Class Initialized
INFO - 2016-11-29 19:11:07 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:07 --> Input Class Initialized
INFO - 2016-11-29 19:11:07 --> Language Class Initialized
ERROR - 2016-11-29 19:11:07 --> 404 Page Not Found: Img/team
INFO - 2016-11-29 19:11:07 --> Config Class Initialized
INFO - 2016-11-29 19:11:07 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:07 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:07 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:07 --> URI Class Initialized
INFO - 2016-11-29 19:11:07 --> Router Class Initialized
INFO - 2016-11-29 19:11:07 --> Output Class Initialized
INFO - 2016-11-29 19:11:07 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:07 --> Input Class Initialized
INFO - 2016-11-29 19:11:07 --> Language Class Initialized
ERROR - 2016-11-29 19:11:07 --> 404 Page Not Found: Img/team
INFO - 2016-11-29 19:11:07 --> Config Class Initialized
INFO - 2016-11-29 19:11:07 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:07 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:07 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:07 --> URI Class Initialized
INFO - 2016-11-29 19:11:07 --> Router Class Initialized
INFO - 2016-11-29 19:11:07 --> Output Class Initialized
INFO - 2016-11-29 19:11:07 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:07 --> Input Class Initialized
INFO - 2016-11-29 19:11:07 --> Language Class Initialized
ERROR - 2016-11-29 19:11:07 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 19:11:07 --> Config Class Initialized
INFO - 2016-11-29 19:11:07 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:07 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:07 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:07 --> URI Class Initialized
INFO - 2016-11-29 19:11:07 --> Router Class Initialized
INFO - 2016-11-29 19:11:07 --> Output Class Initialized
INFO - 2016-11-29 19:11:07 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:07 --> Input Class Initialized
INFO - 2016-11-29 19:11:07 --> Language Class Initialized
ERROR - 2016-11-29 19:11:07 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 19:11:08 --> Config Class Initialized
INFO - 2016-11-29 19:11:08 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:08 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:08 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:08 --> URI Class Initialized
INFO - 2016-11-29 19:11:08 --> Router Class Initialized
INFO - 2016-11-29 19:11:08 --> Output Class Initialized
INFO - 2016-11-29 19:11:08 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:08 --> Input Class Initialized
INFO - 2016-11-29 19:11:08 --> Language Class Initialized
INFO - 2016-11-29 19:11:08 --> Loader Class Initialized
INFO - 2016-11-29 19:11:08 --> Database Driver Class Initialized
INFO - 2016-11-29 19:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:11:08 --> Controller Class Initialized
INFO - 2016-11-29 19:11:08 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:11:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:11:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 19:11:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 19:11:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 19:11:08 --> Final output sent to browser
DEBUG - 2016-11-29 19:11:08 --> Total execution time: 0.0153
INFO - 2016-11-29 19:11:11 --> Config Class Initialized
INFO - 2016-11-29 19:11:11 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:11 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:11 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:11 --> URI Class Initialized
INFO - 2016-11-29 19:11:11 --> Router Class Initialized
INFO - 2016-11-29 19:11:11 --> Output Class Initialized
INFO - 2016-11-29 19:11:11 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:11 --> Input Class Initialized
INFO - 2016-11-29 19:11:11 --> Language Class Initialized
INFO - 2016-11-29 19:11:11 --> Loader Class Initialized
INFO - 2016-11-29 19:11:11 --> Database Driver Class Initialized
INFO - 2016-11-29 19:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:11:11 --> Controller Class Initialized
INFO - 2016-11-29 19:11:11 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:11:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:11:11 --> Final output sent to browser
DEBUG - 2016-11-29 19:11:11 --> Total execution time: 0.0659
INFO - 2016-11-29 19:11:11 --> Config Class Initialized
INFO - 2016-11-29 19:11:11 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:11 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:11 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:11 --> URI Class Initialized
INFO - 2016-11-29 19:11:11 --> Router Class Initialized
INFO - 2016-11-29 19:11:11 --> Output Class Initialized
INFO - 2016-11-29 19:11:11 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:11 --> Input Class Initialized
INFO - 2016-11-29 19:11:11 --> Language Class Initialized
INFO - 2016-11-29 19:11:11 --> Loader Class Initialized
INFO - 2016-11-29 19:11:11 --> Database Driver Class Initialized
INFO - 2016-11-29 19:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:11:11 --> Controller Class Initialized
INFO - 2016-11-29 19:11:11 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:11:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:11:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 19:11:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 19:11:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 19:11:11 --> Final output sent to browser
DEBUG - 2016-11-29 19:11:11 --> Total execution time: 0.0141
INFO - 2016-11-29 19:11:18 --> Config Class Initialized
INFO - 2016-11-29 19:11:18 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:18 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:18 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:18 --> URI Class Initialized
INFO - 2016-11-29 19:11:18 --> Router Class Initialized
INFO - 2016-11-29 19:11:18 --> Output Class Initialized
INFO - 2016-11-29 19:11:18 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:18 --> Input Class Initialized
INFO - 2016-11-29 19:11:18 --> Language Class Initialized
INFO - 2016-11-29 19:11:18 --> Loader Class Initialized
INFO - 2016-11-29 19:11:18 --> Database Driver Class Initialized
INFO - 2016-11-29 19:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:11:18 --> Controller Class Initialized
INFO - 2016-11-29 19:11:18 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:11:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:11:18 --> Final output sent to browser
DEBUG - 2016-11-29 19:11:18 --> Total execution time: 0.0141
INFO - 2016-11-29 19:11:18 --> Config Class Initialized
INFO - 2016-11-29 19:11:18 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:18 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:18 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:18 --> URI Class Initialized
INFO - 2016-11-29 19:11:18 --> Router Class Initialized
INFO - 2016-11-29 19:11:18 --> Output Class Initialized
INFO - 2016-11-29 19:11:18 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:18 --> Input Class Initialized
INFO - 2016-11-29 19:11:18 --> Language Class Initialized
INFO - 2016-11-29 19:11:18 --> Loader Class Initialized
INFO - 2016-11-29 19:11:18 --> Database Driver Class Initialized
INFO - 2016-11-29 19:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:11:18 --> Controller Class Initialized
INFO - 2016-11-29 19:11:18 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:11:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 19:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 19:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 19:11:18 --> Final output sent to browser
DEBUG - 2016-11-29 19:11:18 --> Total execution time: 0.0160
INFO - 2016-11-29 19:11:20 --> Config Class Initialized
INFO - 2016-11-29 19:11:20 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:20 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:20 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:20 --> URI Class Initialized
INFO - 2016-11-29 19:11:20 --> Router Class Initialized
INFO - 2016-11-29 19:11:20 --> Output Class Initialized
INFO - 2016-11-29 19:11:20 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:20 --> Input Class Initialized
INFO - 2016-11-29 19:11:20 --> Language Class Initialized
INFO - 2016-11-29 19:11:20 --> Loader Class Initialized
INFO - 2016-11-29 19:11:20 --> Database Driver Class Initialized
INFO - 2016-11-29 19:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:11:20 --> Controller Class Initialized
INFO - 2016-11-29 19:11:20 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:11:20 --> Final output sent to browser
DEBUG - 2016-11-29 19:11:20 --> Total execution time: 0.0138
INFO - 2016-11-29 19:11:20 --> Config Class Initialized
INFO - 2016-11-29 19:11:20 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:20 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:20 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:20 --> URI Class Initialized
INFO - 2016-11-29 19:11:20 --> Router Class Initialized
INFO - 2016-11-29 19:11:20 --> Output Class Initialized
INFO - 2016-11-29 19:11:20 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:20 --> Input Class Initialized
INFO - 2016-11-29 19:11:20 --> Language Class Initialized
INFO - 2016-11-29 19:11:20 --> Loader Class Initialized
INFO - 2016-11-29 19:11:20 --> Database Driver Class Initialized
INFO - 2016-11-29 19:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:11:20 --> Controller Class Initialized
INFO - 2016-11-29 19:11:20 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 19:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 19:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 19:11:20 --> Final output sent to browser
DEBUG - 2016-11-29 19:11:20 --> Total execution time: 0.0141
INFO - 2016-11-29 19:11:21 --> Config Class Initialized
INFO - 2016-11-29 19:11:21 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:21 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:21 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:21 --> URI Class Initialized
INFO - 2016-11-29 19:11:21 --> Router Class Initialized
INFO - 2016-11-29 19:11:21 --> Output Class Initialized
INFO - 2016-11-29 19:11:21 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:21 --> Input Class Initialized
INFO - 2016-11-29 19:11:21 --> Language Class Initialized
INFO - 2016-11-29 19:11:21 --> Loader Class Initialized
INFO - 2016-11-29 19:11:21 --> Database Driver Class Initialized
INFO - 2016-11-29 19:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:11:21 --> Controller Class Initialized
INFO - 2016-11-29 19:11:21 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:11:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:11:21 --> Final output sent to browser
DEBUG - 2016-11-29 19:11:21 --> Total execution time: 0.0143
INFO - 2016-11-29 19:11:21 --> Config Class Initialized
INFO - 2016-11-29 19:11:21 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:21 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:21 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:21 --> URI Class Initialized
INFO - 2016-11-29 19:11:21 --> Router Class Initialized
INFO - 2016-11-29 19:11:21 --> Output Class Initialized
INFO - 2016-11-29 19:11:21 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:21 --> Input Class Initialized
INFO - 2016-11-29 19:11:21 --> Language Class Initialized
INFO - 2016-11-29 19:11:21 --> Loader Class Initialized
INFO - 2016-11-29 19:11:21 --> Database Driver Class Initialized
INFO - 2016-11-29 19:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:11:21 --> Controller Class Initialized
INFO - 2016-11-29 19:11:21 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:11:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:11:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 19:11:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 19:11:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 19:11:21 --> Final output sent to browser
DEBUG - 2016-11-29 19:11:21 --> Total execution time: 0.0141
INFO - 2016-11-29 19:11:21 --> Config Class Initialized
INFO - 2016-11-29 19:11:21 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:21 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:21 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:21 --> URI Class Initialized
INFO - 2016-11-29 19:11:21 --> Router Class Initialized
INFO - 2016-11-29 19:11:21 --> Output Class Initialized
INFO - 2016-11-29 19:11:21 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:21 --> Input Class Initialized
INFO - 2016-11-29 19:11:21 --> Language Class Initialized
INFO - 2016-11-29 19:11:21 --> Loader Class Initialized
INFO - 2016-11-29 19:11:21 --> Database Driver Class Initialized
INFO - 2016-11-29 19:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:11:21 --> Controller Class Initialized
INFO - 2016-11-29 19:11:21 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:11:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:11:21 --> Final output sent to browser
DEBUG - 2016-11-29 19:11:21 --> Total execution time: 0.0162
INFO - 2016-11-29 19:11:21 --> Config Class Initialized
INFO - 2016-11-29 19:11:21 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:21 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:21 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:21 --> URI Class Initialized
INFO - 2016-11-29 19:11:21 --> Router Class Initialized
INFO - 2016-11-29 19:11:21 --> Output Class Initialized
INFO - 2016-11-29 19:11:21 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:21 --> Input Class Initialized
INFO - 2016-11-29 19:11:21 --> Language Class Initialized
INFO - 2016-11-29 19:11:21 --> Loader Class Initialized
INFO - 2016-11-29 19:11:21 --> Database Driver Class Initialized
INFO - 2016-11-29 19:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:11:21 --> Controller Class Initialized
INFO - 2016-11-29 19:11:21 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:11:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:11:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 19:11:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 19:11:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 19:11:21 --> Final output sent to browser
DEBUG - 2016-11-29 19:11:21 --> Total execution time: 0.0643
INFO - 2016-11-29 19:11:24 --> Config Class Initialized
INFO - 2016-11-29 19:11:24 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:24 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:24 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:24 --> URI Class Initialized
INFO - 2016-11-29 19:11:24 --> Router Class Initialized
INFO - 2016-11-29 19:11:24 --> Output Class Initialized
INFO - 2016-11-29 19:11:24 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:24 --> Input Class Initialized
INFO - 2016-11-29 19:11:24 --> Language Class Initialized
INFO - 2016-11-29 19:11:24 --> Loader Class Initialized
INFO - 2016-11-29 19:11:24 --> Database Driver Class Initialized
INFO - 2016-11-29 19:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:11:24 --> Controller Class Initialized
INFO - 2016-11-29 19:11:24 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:11:24 --> Final output sent to browser
DEBUG - 2016-11-29 19:11:24 --> Total execution time: 0.0135
INFO - 2016-11-29 19:11:24 --> Config Class Initialized
INFO - 2016-11-29 19:11:24 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:24 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:24 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:24 --> URI Class Initialized
INFO - 2016-11-29 19:11:24 --> Router Class Initialized
INFO - 2016-11-29 19:11:24 --> Output Class Initialized
INFO - 2016-11-29 19:11:24 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:24 --> Input Class Initialized
INFO - 2016-11-29 19:11:24 --> Language Class Initialized
INFO - 2016-11-29 19:11:24 --> Loader Class Initialized
INFO - 2016-11-29 19:11:24 --> Database Driver Class Initialized
INFO - 2016-11-29 19:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:11:24 --> Controller Class Initialized
INFO - 2016-11-29 19:11:24 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:11:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 19:11:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 19:11:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 19:11:24 --> Final output sent to browser
DEBUG - 2016-11-29 19:11:24 --> Total execution time: 0.0135
INFO - 2016-11-29 19:11:25 --> Config Class Initialized
INFO - 2016-11-29 19:11:25 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:25 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:25 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:25 --> URI Class Initialized
DEBUG - 2016-11-29 19:11:25 --> No URI present. Default controller set.
INFO - 2016-11-29 19:11:25 --> Router Class Initialized
INFO - 2016-11-29 19:11:25 --> Output Class Initialized
INFO - 2016-11-29 19:11:25 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:25 --> Input Class Initialized
INFO - 2016-11-29 19:11:25 --> Language Class Initialized
INFO - 2016-11-29 19:11:25 --> Loader Class Initialized
INFO - 2016-11-29 19:11:25 --> Database Driver Class Initialized
INFO - 2016-11-29 19:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:11:25 --> Controller Class Initialized
INFO - 2016-11-29 19:11:25 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:11:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:11:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 19:11:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 19:11:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 19:11:25 --> Final output sent to browser
DEBUG - 2016-11-29 19:11:25 --> Total execution time: 0.0143
INFO - 2016-11-29 19:11:25 --> Config Class Initialized
INFO - 2016-11-29 19:11:25 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:25 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:25 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:25 --> URI Class Initialized
INFO - 2016-11-29 19:11:25 --> Router Class Initialized
INFO - 2016-11-29 19:11:25 --> Output Class Initialized
INFO - 2016-11-29 19:11:25 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:25 --> Input Class Initialized
INFO - 2016-11-29 19:11:25 --> Language Class Initialized
ERROR - 2016-11-29 19:11:25 --> 404 Page Not Found: Img/team
INFO - 2016-11-29 19:11:25 --> Config Class Initialized
INFO - 2016-11-29 19:11:25 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:25 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:25 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:25 --> URI Class Initialized
INFO - 2016-11-29 19:11:25 --> Router Class Initialized
INFO - 2016-11-29 19:11:25 --> Output Class Initialized
INFO - 2016-11-29 19:11:25 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:25 --> Input Class Initialized
INFO - 2016-11-29 19:11:25 --> Language Class Initialized
ERROR - 2016-11-29 19:11:25 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 19:11:25 --> Config Class Initialized
INFO - 2016-11-29 19:11:25 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:25 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:25 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:25 --> URI Class Initialized
INFO - 2016-11-29 19:11:25 --> Router Class Initialized
INFO - 2016-11-29 19:11:25 --> Output Class Initialized
INFO - 2016-11-29 19:11:25 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:25 --> Input Class Initialized
INFO - 2016-11-29 19:11:25 --> Language Class Initialized
ERROR - 2016-11-29 19:11:25 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 19:11:26 --> Config Class Initialized
INFO - 2016-11-29 19:11:26 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:26 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:26 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:26 --> URI Class Initialized
INFO - 2016-11-29 19:11:26 --> Router Class Initialized
INFO - 2016-11-29 19:11:26 --> Output Class Initialized
INFO - 2016-11-29 19:11:26 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:26 --> Input Class Initialized
INFO - 2016-11-29 19:11:26 --> Language Class Initialized
INFO - 2016-11-29 19:11:26 --> Loader Class Initialized
INFO - 2016-11-29 19:11:26 --> Database Driver Class Initialized
INFO - 2016-11-29 19:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:11:26 --> Controller Class Initialized
INFO - 2016-11-29 19:11:26 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:11:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:11:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 19:11:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 19:11:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 19:11:26 --> Final output sent to browser
DEBUG - 2016-11-29 19:11:26 --> Total execution time: 0.0136
INFO - 2016-11-29 19:11:28 --> Config Class Initialized
INFO - 2016-11-29 19:11:28 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:28 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:28 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:28 --> URI Class Initialized
INFO - 2016-11-29 19:11:28 --> Router Class Initialized
INFO - 2016-11-29 19:11:28 --> Output Class Initialized
INFO - 2016-11-29 19:11:28 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:28 --> Input Class Initialized
INFO - 2016-11-29 19:11:28 --> Language Class Initialized
INFO - 2016-11-29 19:11:28 --> Loader Class Initialized
INFO - 2016-11-29 19:11:28 --> Database Driver Class Initialized
INFO - 2016-11-29 19:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:11:28 --> Controller Class Initialized
INFO - 2016-11-29 19:11:28 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:11:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:11:28 --> Final output sent to browser
DEBUG - 2016-11-29 19:11:28 --> Total execution time: 0.0692
INFO - 2016-11-29 19:11:28 --> Config Class Initialized
INFO - 2016-11-29 19:11:28 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:28 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:28 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:28 --> URI Class Initialized
INFO - 2016-11-29 19:11:28 --> Router Class Initialized
INFO - 2016-11-29 19:11:28 --> Output Class Initialized
INFO - 2016-11-29 19:11:28 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:28 --> Input Class Initialized
INFO - 2016-11-29 19:11:28 --> Language Class Initialized
INFO - 2016-11-29 19:11:28 --> Loader Class Initialized
INFO - 2016-11-29 19:11:28 --> Database Driver Class Initialized
INFO - 2016-11-29 19:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:11:28 --> Controller Class Initialized
INFO - 2016-11-29 19:11:28 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:11:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:11:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 19:11:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 19:11:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 19:11:28 --> Final output sent to browser
DEBUG - 2016-11-29 19:11:28 --> Total execution time: 0.0141
INFO - 2016-11-29 19:11:32 --> Config Class Initialized
INFO - 2016-11-29 19:11:32 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:32 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:32 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:32 --> URI Class Initialized
INFO - 2016-11-29 19:11:32 --> Router Class Initialized
INFO - 2016-11-29 19:11:32 --> Output Class Initialized
INFO - 2016-11-29 19:11:32 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:32 --> Input Class Initialized
INFO - 2016-11-29 19:11:32 --> Language Class Initialized
INFO - 2016-11-29 19:11:32 --> Loader Class Initialized
INFO - 2016-11-29 19:11:32 --> Database Driver Class Initialized
INFO - 2016-11-29 19:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:11:32 --> Controller Class Initialized
INFO - 2016-11-29 19:11:32 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:11:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:11:32 --> Final output sent to browser
DEBUG - 2016-11-29 19:11:32 --> Total execution time: 0.0137
INFO - 2016-11-29 19:11:32 --> Config Class Initialized
INFO - 2016-11-29 19:11:32 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:11:32 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:11:32 --> Utf8 Class Initialized
INFO - 2016-11-29 19:11:32 --> URI Class Initialized
INFO - 2016-11-29 19:11:32 --> Router Class Initialized
INFO - 2016-11-29 19:11:32 --> Output Class Initialized
INFO - 2016-11-29 19:11:32 --> Security Class Initialized
DEBUG - 2016-11-29 19:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:11:32 --> Input Class Initialized
INFO - 2016-11-29 19:11:32 --> Language Class Initialized
INFO - 2016-11-29 19:11:32 --> Loader Class Initialized
INFO - 2016-11-29 19:11:32 --> Database Driver Class Initialized
INFO - 2016-11-29 19:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:11:32 --> Controller Class Initialized
INFO - 2016-11-29 19:11:32 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:11:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:11:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 19:11:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 19:11:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 19:11:32 --> Final output sent to browser
DEBUG - 2016-11-29 19:11:32 --> Total execution time: 0.0676
INFO - 2016-11-29 19:18:52 --> Config Class Initialized
INFO - 2016-11-29 19:18:52 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:18:52 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:18:52 --> Utf8 Class Initialized
INFO - 2016-11-29 19:18:52 --> URI Class Initialized
DEBUG - 2016-11-29 19:18:52 --> No URI present. Default controller set.
INFO - 2016-11-29 19:18:52 --> Router Class Initialized
INFO - 2016-11-29 19:18:53 --> Output Class Initialized
INFO - 2016-11-29 19:18:53 --> Security Class Initialized
DEBUG - 2016-11-29 19:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:18:53 --> Input Class Initialized
INFO - 2016-11-29 19:18:53 --> Language Class Initialized
INFO - 2016-11-29 19:18:53 --> Loader Class Initialized
INFO - 2016-11-29 19:18:53 --> Database Driver Class Initialized
INFO - 2016-11-29 19:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:18:53 --> Controller Class Initialized
INFO - 2016-11-29 19:18:53 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:18:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 19:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 19:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 19:18:53 --> Final output sent to browser
DEBUG - 2016-11-29 19:18:53 --> Total execution time: 0.0332
INFO - 2016-11-29 19:18:53 --> Config Class Initialized
INFO - 2016-11-29 19:18:53 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:18:53 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:18:53 --> Utf8 Class Initialized
INFO - 2016-11-29 19:18:53 --> URI Class Initialized
INFO - 2016-11-29 19:18:53 --> Router Class Initialized
INFO - 2016-11-29 19:18:53 --> Output Class Initialized
INFO - 2016-11-29 19:18:53 --> Security Class Initialized
DEBUG - 2016-11-29 19:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:18:53 --> Input Class Initialized
INFO - 2016-11-29 19:18:53 --> Language Class Initialized
INFO - 2016-11-29 19:18:53 --> Loader Class Initialized
INFO - 2016-11-29 19:18:53 --> Database Driver Class Initialized
INFO - 2016-11-29 19:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:18:53 --> Controller Class Initialized
INFO - 2016-11-29 19:18:53 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:18:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 19:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 19:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 19:18:53 --> Final output sent to browser
DEBUG - 2016-11-29 19:18:53 --> Total execution time: 0.0142
INFO - 2016-11-29 19:18:53 --> Config Class Initialized
INFO - 2016-11-29 19:18:53 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:18:53 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:18:53 --> Utf8 Class Initialized
INFO - 2016-11-29 19:18:53 --> URI Class Initialized
DEBUG - 2016-11-29 19:18:53 --> No URI present. Default controller set.
INFO - 2016-11-29 19:18:53 --> Router Class Initialized
INFO - 2016-11-29 19:18:53 --> Output Class Initialized
INFO - 2016-11-29 19:18:53 --> Security Class Initialized
DEBUG - 2016-11-29 19:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:18:53 --> Input Class Initialized
INFO - 2016-11-29 19:18:53 --> Language Class Initialized
INFO - 2016-11-29 19:18:53 --> Loader Class Initialized
INFO - 2016-11-29 19:18:53 --> Database Driver Class Initialized
INFO - 2016-11-29 19:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:18:53 --> Controller Class Initialized
INFO - 2016-11-29 19:18:53 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:18:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 19:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 19:18:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 19:18:53 --> Final output sent to browser
DEBUG - 2016-11-29 19:18:53 --> Total execution time: 0.0599
INFO - 2016-11-29 19:18:53 --> Config Class Initialized
INFO - 2016-11-29 19:18:53 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:18:53 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:18:53 --> Utf8 Class Initialized
INFO - 2016-11-29 19:18:53 --> URI Class Initialized
INFO - 2016-11-29 19:18:53 --> Router Class Initialized
INFO - 2016-11-29 19:18:53 --> Output Class Initialized
INFO - 2016-11-29 19:18:53 --> Security Class Initialized
DEBUG - 2016-11-29 19:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:18:53 --> Input Class Initialized
INFO - 2016-11-29 19:18:53 --> Language Class Initialized
ERROR - 2016-11-29 19:18:53 --> 404 Page Not Found: Img/about
INFO - 2016-11-29 19:18:53 --> Config Class Initialized
INFO - 2016-11-29 19:18:53 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:18:53 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:18:53 --> Utf8 Class Initialized
INFO - 2016-11-29 19:18:53 --> URI Class Initialized
INFO - 2016-11-29 19:18:53 --> Config Class Initialized
INFO - 2016-11-29 19:18:53 --> Hooks Class Initialized
INFO - 2016-11-29 19:18:54 --> Router Class Initialized
INFO - 2016-11-29 19:18:54 --> Output Class Initialized
INFO - 2016-11-29 19:18:54 --> Security Class Initialized
DEBUG - 2016-11-29 19:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:18:54 --> Input Class Initialized
INFO - 2016-11-29 19:18:54 --> Language Class Initialized
ERROR - 2016-11-29 19:18:54 --> 404 Page Not Found: Img/team
DEBUG - 2016-11-29 19:18:54 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:18:54 --> Utf8 Class Initialized
INFO - 2016-11-29 19:18:54 --> URI Class Initialized
INFO - 2016-11-29 19:18:54 --> Router Class Initialized
INFO - 2016-11-29 19:18:54 --> Output Class Initialized
INFO - 2016-11-29 19:18:54 --> Security Class Initialized
DEBUG - 2016-11-29 19:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:18:54 --> Input Class Initialized
INFO - 2016-11-29 19:18:54 --> Language Class Initialized
ERROR - 2016-11-29 19:18:54 --> 404 Page Not Found: Img/team
INFO - 2016-11-29 19:18:54 --> Config Class Initialized
INFO - 2016-11-29 19:18:54 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:18:54 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:18:54 --> Utf8 Class Initialized
INFO - 2016-11-29 19:18:54 --> URI Class Initialized
INFO - 2016-11-29 19:18:54 --> Router Class Initialized
INFO - 2016-11-29 19:18:54 --> Output Class Initialized
INFO - 2016-11-29 19:18:54 --> Security Class Initialized
DEBUG - 2016-11-29 19:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:18:54 --> Input Class Initialized
INFO - 2016-11-29 19:18:54 --> Language Class Initialized
ERROR - 2016-11-29 19:18:54 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 19:18:54 --> Config Class Initialized
INFO - 2016-11-29 19:18:54 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:18:54 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:18:54 --> Utf8 Class Initialized
INFO - 2016-11-29 19:18:54 --> URI Class Initialized
INFO - 2016-11-29 19:18:54 --> Router Class Initialized
INFO - 2016-11-29 19:18:54 --> Output Class Initialized
INFO - 2016-11-29 19:18:54 --> Security Class Initialized
DEBUG - 2016-11-29 19:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:18:54 --> Input Class Initialized
INFO - 2016-11-29 19:18:54 --> Language Class Initialized
ERROR - 2016-11-29 19:18:54 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 19:39:11 --> Config Class Initialized
INFO - 2016-11-29 19:39:11 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:39:11 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:39:11 --> Utf8 Class Initialized
INFO - 2016-11-29 19:39:11 --> URI Class Initialized
DEBUG - 2016-11-29 19:39:11 --> No URI present. Default controller set.
INFO - 2016-11-29 19:39:11 --> Router Class Initialized
INFO - 2016-11-29 19:39:11 --> Output Class Initialized
INFO - 2016-11-29 19:39:11 --> Security Class Initialized
DEBUG - 2016-11-29 19:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:39:11 --> Input Class Initialized
INFO - 2016-11-29 19:39:11 --> Language Class Initialized
INFO - 2016-11-29 19:39:11 --> Loader Class Initialized
INFO - 2016-11-29 19:39:11 --> Database Driver Class Initialized
INFO - 2016-11-29 19:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:39:11 --> Controller Class Initialized
INFO - 2016-11-29 19:39:11 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:39:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:39:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 19:39:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 19:39:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 19:39:11 --> Final output sent to browser
DEBUG - 2016-11-29 19:39:11 --> Total execution time: 0.0179
INFO - 2016-11-29 19:39:12 --> Config Class Initialized
INFO - 2016-11-29 19:39:12 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:39:12 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:39:12 --> Utf8 Class Initialized
INFO - 2016-11-29 19:39:12 --> URI Class Initialized
INFO - 2016-11-29 19:39:12 --> Router Class Initialized
INFO - 2016-11-29 19:39:12 --> Output Class Initialized
INFO - 2016-11-29 19:39:12 --> Security Class Initialized
DEBUG - 2016-11-29 19:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:39:12 --> Input Class Initialized
INFO - 2016-11-29 19:39:12 --> Language Class Initialized
ERROR - 2016-11-29 19:39:12 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 19:39:12 --> Config Class Initialized
INFO - 2016-11-29 19:39:12 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:39:12 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:39:12 --> Utf8 Class Initialized
INFO - 2016-11-29 19:39:12 --> URI Class Initialized
INFO - 2016-11-29 19:39:12 --> Router Class Initialized
INFO - 2016-11-29 19:39:12 --> Output Class Initialized
INFO - 2016-11-29 19:39:12 --> Security Class Initialized
DEBUG - 2016-11-29 19:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:39:12 --> Input Class Initialized
INFO - 2016-11-29 19:39:12 --> Language Class Initialized
ERROR - 2016-11-29 19:39:12 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 19:39:12 --> Config Class Initialized
INFO - 2016-11-29 19:39:12 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:39:12 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:39:12 --> Utf8 Class Initialized
INFO - 2016-11-29 19:39:12 --> URI Class Initialized
INFO - 2016-11-29 19:39:12 --> Router Class Initialized
INFO - 2016-11-29 19:39:12 --> Output Class Initialized
INFO - 2016-11-29 19:39:12 --> Security Class Initialized
DEBUG - 2016-11-29 19:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:39:12 --> Input Class Initialized
INFO - 2016-11-29 19:39:12 --> Language Class Initialized
INFO - 2016-11-29 19:39:12 --> Loader Class Initialized
INFO - 2016-11-29 19:39:12 --> Database Driver Class Initialized
INFO - 2016-11-29 19:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:39:12 --> Controller Class Initialized
INFO - 2016-11-29 19:39:12 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:39:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:39:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 19:39:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 19:39:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 19:39:12 --> Final output sent to browser
DEBUG - 2016-11-29 19:39:12 --> Total execution time: 0.0464
INFO - 2016-11-29 19:43:36 --> Config Class Initialized
INFO - 2016-11-29 19:43:36 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:43:36 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:43:36 --> Utf8 Class Initialized
INFO - 2016-11-29 19:43:36 --> URI Class Initialized
DEBUG - 2016-11-29 19:43:36 --> No URI present. Default controller set.
INFO - 2016-11-29 19:43:36 --> Router Class Initialized
INFO - 2016-11-29 19:43:36 --> Output Class Initialized
INFO - 2016-11-29 19:43:36 --> Security Class Initialized
DEBUG - 2016-11-29 19:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:43:36 --> Input Class Initialized
INFO - 2016-11-29 19:43:36 --> Language Class Initialized
INFO - 2016-11-29 19:43:36 --> Loader Class Initialized
INFO - 2016-11-29 19:43:36 --> Database Driver Class Initialized
INFO - 2016-11-29 19:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:43:36 --> Controller Class Initialized
INFO - 2016-11-29 19:43:36 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:43:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:43:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 19:43:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 19:43:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 19:43:36 --> Final output sent to browser
DEBUG - 2016-11-29 19:43:36 --> Total execution time: 0.0131
INFO - 2016-11-29 19:43:36 --> Config Class Initialized
INFO - 2016-11-29 19:43:36 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:43:36 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:43:36 --> Utf8 Class Initialized
INFO - 2016-11-29 19:43:36 --> URI Class Initialized
INFO - 2016-11-29 19:43:36 --> Router Class Initialized
INFO - 2016-11-29 19:43:36 --> Output Class Initialized
INFO - 2016-11-29 19:43:36 --> Security Class Initialized
DEBUG - 2016-11-29 19:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:43:36 --> Input Class Initialized
INFO - 2016-11-29 19:43:36 --> Language Class Initialized
ERROR - 2016-11-29 19:43:36 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 19:43:36 --> Config Class Initialized
INFO - 2016-11-29 19:43:36 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:43:36 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:43:36 --> Utf8 Class Initialized
INFO - 2016-11-29 19:43:36 --> URI Class Initialized
INFO - 2016-11-29 19:43:36 --> Router Class Initialized
INFO - 2016-11-29 19:43:36 --> Output Class Initialized
INFO - 2016-11-29 19:43:36 --> Security Class Initialized
DEBUG - 2016-11-29 19:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:43:36 --> Input Class Initialized
INFO - 2016-11-29 19:43:36 --> Language Class Initialized
ERROR - 2016-11-29 19:43:36 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 19:43:37 --> Config Class Initialized
INFO - 2016-11-29 19:43:37 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:43:37 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:43:37 --> Utf8 Class Initialized
INFO - 2016-11-29 19:43:37 --> URI Class Initialized
INFO - 2016-11-29 19:43:37 --> Router Class Initialized
INFO - 2016-11-29 19:43:37 --> Output Class Initialized
INFO - 2016-11-29 19:43:37 --> Security Class Initialized
DEBUG - 2016-11-29 19:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:43:37 --> Input Class Initialized
INFO - 2016-11-29 19:43:37 --> Language Class Initialized
INFO - 2016-11-29 19:43:37 --> Loader Class Initialized
INFO - 2016-11-29 19:43:37 --> Database Driver Class Initialized
INFO - 2016-11-29 19:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:43:37 --> Controller Class Initialized
INFO - 2016-11-29 19:43:37 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:43:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 19:43:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 19:43:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 19:43:37 --> Final output sent to browser
DEBUG - 2016-11-29 19:43:37 --> Total execution time: 0.0141
INFO - 2016-11-29 19:43:38 --> Config Class Initialized
INFO - 2016-11-29 19:43:38 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:43:38 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:43:38 --> Utf8 Class Initialized
INFO - 2016-11-29 19:43:38 --> URI Class Initialized
DEBUG - 2016-11-29 19:43:38 --> No URI present. Default controller set.
INFO - 2016-11-29 19:43:38 --> Router Class Initialized
INFO - 2016-11-29 19:43:38 --> Output Class Initialized
INFO - 2016-11-29 19:43:38 --> Security Class Initialized
DEBUG - 2016-11-29 19:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:43:38 --> Input Class Initialized
INFO - 2016-11-29 19:43:38 --> Language Class Initialized
INFO - 2016-11-29 19:43:38 --> Loader Class Initialized
INFO - 2016-11-29 19:43:38 --> Database Driver Class Initialized
INFO - 2016-11-29 19:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:43:38 --> Controller Class Initialized
INFO - 2016-11-29 19:43:38 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:43:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 19:43:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 19:43:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 19:43:38 --> Final output sent to browser
DEBUG - 2016-11-29 19:43:38 --> Total execution time: 0.0149
INFO - 2016-11-29 19:43:38 --> Config Class Initialized
INFO - 2016-11-29 19:43:38 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:43:38 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:43:38 --> Utf8 Class Initialized
INFO - 2016-11-29 19:43:38 --> URI Class Initialized
INFO - 2016-11-29 19:43:38 --> Router Class Initialized
INFO - 2016-11-29 19:43:38 --> Output Class Initialized
INFO - 2016-11-29 19:43:38 --> Security Class Initialized
DEBUG - 2016-11-29 19:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:43:38 --> Input Class Initialized
INFO - 2016-11-29 19:43:38 --> Language Class Initialized
ERROR - 2016-11-29 19:43:38 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 19:43:38 --> Config Class Initialized
INFO - 2016-11-29 19:43:38 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:43:38 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:43:38 --> Utf8 Class Initialized
INFO - 2016-11-29 19:43:38 --> URI Class Initialized
INFO - 2016-11-29 19:43:38 --> Router Class Initialized
INFO - 2016-11-29 19:43:38 --> Output Class Initialized
INFO - 2016-11-29 19:43:38 --> Security Class Initialized
DEBUG - 2016-11-29 19:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:43:38 --> Input Class Initialized
INFO - 2016-11-29 19:43:38 --> Language Class Initialized
ERROR - 2016-11-29 19:43:38 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 19:43:38 --> Config Class Initialized
INFO - 2016-11-29 19:43:38 --> Hooks Class Initialized
DEBUG - 2016-11-29 19:43:38 --> UTF-8 Support Enabled
INFO - 2016-11-29 19:43:38 --> Utf8 Class Initialized
INFO - 2016-11-29 19:43:38 --> URI Class Initialized
INFO - 2016-11-29 19:43:38 --> Router Class Initialized
INFO - 2016-11-29 19:43:38 --> Output Class Initialized
INFO - 2016-11-29 19:43:38 --> Security Class Initialized
DEBUG - 2016-11-29 19:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 19:43:38 --> Input Class Initialized
INFO - 2016-11-29 19:43:38 --> Language Class Initialized
INFO - 2016-11-29 19:43:38 --> Loader Class Initialized
INFO - 2016-11-29 19:43:38 --> Database Driver Class Initialized
INFO - 2016-11-29 19:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 19:43:38 --> Controller Class Initialized
INFO - 2016-11-29 19:43:38 --> Helper loaded: url_helper
DEBUG - 2016-11-29 19:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 19:43:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 19:43:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 19:43:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 19:43:38 --> Final output sent to browser
DEBUG - 2016-11-29 19:43:38 --> Total execution time: 0.0143
INFO - 2016-11-29 21:33:10 --> Config Class Initialized
INFO - 2016-11-29 21:33:10 --> Hooks Class Initialized
DEBUG - 2016-11-29 21:33:10 --> UTF-8 Support Enabled
INFO - 2016-11-29 21:33:10 --> Utf8 Class Initialized
INFO - 2016-11-29 21:33:10 --> URI Class Initialized
INFO - 2016-11-29 21:33:10 --> Router Class Initialized
INFO - 2016-11-29 21:33:10 --> Output Class Initialized
INFO - 2016-11-29 21:33:10 --> Security Class Initialized
DEBUG - 2016-11-29 21:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 21:33:10 --> Input Class Initialized
INFO - 2016-11-29 21:33:10 --> Language Class Initialized
ERROR - 2016-11-29 21:33:10 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 21:33:10 --> Config Class Initialized
INFO - 2016-11-29 21:33:10 --> Hooks Class Initialized
DEBUG - 2016-11-29 21:33:10 --> UTF-8 Support Enabled
INFO - 2016-11-29 21:33:10 --> Utf8 Class Initialized
INFO - 2016-11-29 21:33:10 --> URI Class Initialized
INFO - 2016-11-29 21:33:10 --> Router Class Initialized
INFO - 2016-11-29 21:33:10 --> Output Class Initialized
INFO - 2016-11-29 21:33:10 --> Security Class Initialized
DEBUG - 2016-11-29 21:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 21:33:10 --> Input Class Initialized
INFO - 2016-11-29 21:33:10 --> Language Class Initialized
ERROR - 2016-11-29 21:33:10 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 23:31:54 --> Config Class Initialized
INFO - 2016-11-29 23:31:54 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:31:54 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:31:54 --> Utf8 Class Initialized
INFO - 2016-11-29 23:31:54 --> URI Class Initialized
DEBUG - 2016-11-29 23:31:54 --> No URI present. Default controller set.
INFO - 2016-11-29 23:31:54 --> Router Class Initialized
INFO - 2016-11-29 23:31:54 --> Output Class Initialized
INFO - 2016-11-29 23:31:54 --> Security Class Initialized
DEBUG - 2016-11-29 23:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:31:54 --> Input Class Initialized
INFO - 2016-11-29 23:31:54 --> Language Class Initialized
INFO - 2016-11-29 23:31:54 --> Loader Class Initialized
INFO - 2016-11-29 23:31:54 --> Database Driver Class Initialized
INFO - 2016-11-29 23:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:31:54 --> Controller Class Initialized
INFO - 2016-11-29 23:31:54 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:31:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:31:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:31:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:31:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:31:54 --> Final output sent to browser
DEBUG - 2016-11-29 23:31:54 --> Total execution time: 0.0607
INFO - 2016-11-29 23:31:54 --> Config Class Initialized
INFO - 2016-11-29 23:31:54 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:31:54 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:31:54 --> Utf8 Class Initialized
INFO - 2016-11-29 23:31:54 --> URI Class Initialized
INFO - 2016-11-29 23:31:54 --> Router Class Initialized
INFO - 2016-11-29 23:31:54 --> Output Class Initialized
INFO - 2016-11-29 23:31:54 --> Security Class Initialized
DEBUG - 2016-11-29 23:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:31:54 --> Input Class Initialized
INFO - 2016-11-29 23:31:54 --> Language Class Initialized
ERROR - 2016-11-29 23:31:54 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:31:54 --> Config Class Initialized
INFO - 2016-11-29 23:31:54 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:31:54 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:31:54 --> Utf8 Class Initialized
INFO - 2016-11-29 23:31:54 --> URI Class Initialized
INFO - 2016-11-29 23:31:54 --> Router Class Initialized
INFO - 2016-11-29 23:31:54 --> Output Class Initialized
INFO - 2016-11-29 23:31:54 --> Security Class Initialized
DEBUG - 2016-11-29 23:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:31:54 --> Input Class Initialized
INFO - 2016-11-29 23:31:54 --> Language Class Initialized
ERROR - 2016-11-29 23:31:54 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:31:54 --> Config Class Initialized
INFO - 2016-11-29 23:31:54 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:31:54 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:31:54 --> Utf8 Class Initialized
INFO - 2016-11-29 23:31:54 --> URI Class Initialized
INFO - 2016-11-29 23:31:54 --> Router Class Initialized
INFO - 2016-11-29 23:31:54 --> Output Class Initialized
INFO - 2016-11-29 23:31:54 --> Security Class Initialized
DEBUG - 2016-11-29 23:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:31:54 --> Input Class Initialized
INFO - 2016-11-29 23:31:54 --> Language Class Initialized
INFO - 2016-11-29 23:31:54 --> Loader Class Initialized
INFO - 2016-11-29 23:31:54 --> Database Driver Class Initialized
INFO - 2016-11-29 23:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:31:54 --> Controller Class Initialized
INFO - 2016-11-29 23:31:54 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:31:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:31:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:31:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:31:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:31:54 --> Final output sent to browser
DEBUG - 2016-11-29 23:31:54 --> Total execution time: 0.0140
INFO - 2016-11-29 23:32:06 --> Config Class Initialized
INFO - 2016-11-29 23:32:06 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:32:06 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:32:06 --> Utf8 Class Initialized
INFO - 2016-11-29 23:32:06 --> URI Class Initialized
INFO - 2016-11-29 23:32:06 --> Router Class Initialized
INFO - 2016-11-29 23:32:06 --> Output Class Initialized
INFO - 2016-11-29 23:32:06 --> Security Class Initialized
DEBUG - 2016-11-29 23:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:32:06 --> Input Class Initialized
INFO - 2016-11-29 23:32:06 --> Language Class Initialized
INFO - 2016-11-29 23:32:06 --> Loader Class Initialized
INFO - 2016-11-29 23:32:06 --> Database Driver Class Initialized
INFO - 2016-11-29 23:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:32:06 --> Controller Class Initialized
INFO - 2016-11-29 23:32:06 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:32:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:32:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:32:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:32:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:32:06 --> Final output sent to browser
DEBUG - 2016-11-29 23:32:06 --> Total execution time: 0.0318
INFO - 2016-11-29 23:32:10 --> Config Class Initialized
INFO - 2016-11-29 23:32:10 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:32:10 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:32:10 --> Utf8 Class Initialized
INFO - 2016-11-29 23:32:10 --> URI Class Initialized
INFO - 2016-11-29 23:32:10 --> Router Class Initialized
INFO - 2016-11-29 23:32:10 --> Output Class Initialized
INFO - 2016-11-29 23:32:10 --> Security Class Initialized
DEBUG - 2016-11-29 23:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:32:10 --> Input Class Initialized
INFO - 2016-11-29 23:32:10 --> Language Class Initialized
INFO - 2016-11-29 23:32:10 --> Loader Class Initialized
INFO - 2016-11-29 23:32:10 --> Database Driver Class Initialized
INFO - 2016-11-29 23:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:32:10 --> Controller Class Initialized
INFO - 2016-11-29 23:32:10 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:32:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:32:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:32:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:32:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:32:10 --> Final output sent to browser
DEBUG - 2016-11-29 23:32:10 --> Total execution time: 0.0137
INFO - 2016-11-29 23:32:39 --> Config Class Initialized
INFO - 2016-11-29 23:32:39 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:32:39 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:32:39 --> Utf8 Class Initialized
INFO - 2016-11-29 23:32:39 --> URI Class Initialized
DEBUG - 2016-11-29 23:32:39 --> No URI present. Default controller set.
INFO - 2016-11-29 23:32:39 --> Router Class Initialized
INFO - 2016-11-29 23:32:39 --> Output Class Initialized
INFO - 2016-11-29 23:32:39 --> Security Class Initialized
DEBUG - 2016-11-29 23:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:32:39 --> Input Class Initialized
INFO - 2016-11-29 23:32:39 --> Language Class Initialized
INFO - 2016-11-29 23:32:39 --> Loader Class Initialized
INFO - 2016-11-29 23:32:39 --> Database Driver Class Initialized
INFO - 2016-11-29 23:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:32:39 --> Controller Class Initialized
INFO - 2016-11-29 23:32:39 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:32:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:32:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:32:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:32:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:32:39 --> Final output sent to browser
DEBUG - 2016-11-29 23:32:39 --> Total execution time: 0.0197
INFO - 2016-11-29 23:32:39 --> Config Class Initialized
INFO - 2016-11-29 23:32:39 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:32:39 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:32:39 --> Utf8 Class Initialized
INFO - 2016-11-29 23:32:39 --> URI Class Initialized
INFO - 2016-11-29 23:32:39 --> Config Class Initialized
INFO - 2016-11-29 23:32:39 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:32:39 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:32:39 --> Utf8 Class Initialized
INFO - 2016-11-29 23:32:39 --> URI Class Initialized
INFO - 2016-11-29 23:32:39 --> Router Class Initialized
INFO - 2016-11-29 23:32:39 --> Output Class Initialized
INFO - 2016-11-29 23:32:39 --> Security Class Initialized
DEBUG - 2016-11-29 23:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:32:39 --> Input Class Initialized
INFO - 2016-11-29 23:32:39 --> Language Class Initialized
ERROR - 2016-11-29 23:32:39 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:32:39 --> Router Class Initialized
INFO - 2016-11-29 23:32:39 --> Output Class Initialized
INFO - 2016-11-29 23:32:39 --> Security Class Initialized
DEBUG - 2016-11-29 23:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:32:39 --> Input Class Initialized
INFO - 2016-11-29 23:32:39 --> Language Class Initialized
ERROR - 2016-11-29 23:32:39 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:32:39 --> Config Class Initialized
INFO - 2016-11-29 23:32:39 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:32:39 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:32:39 --> Utf8 Class Initialized
INFO - 2016-11-29 23:32:39 --> URI Class Initialized
INFO - 2016-11-29 23:32:39 --> Config Class Initialized
INFO - 2016-11-29 23:32:39 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:32:39 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:32:39 --> Utf8 Class Initialized
INFO - 2016-11-29 23:32:39 --> URI Class Initialized
INFO - 2016-11-29 23:32:39 --> Router Class Initialized
INFO - 2016-11-29 23:32:39 --> Output Class Initialized
INFO - 2016-11-29 23:32:39 --> Security Class Initialized
DEBUG - 2016-11-29 23:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:32:39 --> Input Class Initialized
INFO - 2016-11-29 23:32:39 --> Language Class Initialized
ERROR - 2016-11-29 23:32:39 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 23:32:39 --> Router Class Initialized
INFO - 2016-11-29 23:32:39 --> Output Class Initialized
INFO - 2016-11-29 23:32:39 --> Security Class Initialized
DEBUG - 2016-11-29 23:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:32:39 --> Input Class Initialized
INFO - 2016-11-29 23:32:39 --> Language Class Initialized
ERROR - 2016-11-29 23:32:39 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 23:32:39 --> Config Class Initialized
INFO - 2016-11-29 23:32:39 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:32:39 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:32:39 --> Utf8 Class Initialized
INFO - 2016-11-29 23:32:39 --> URI Class Initialized
INFO - 2016-11-29 23:32:39 --> Router Class Initialized
INFO - 2016-11-29 23:32:39 --> Output Class Initialized
INFO - 2016-11-29 23:32:39 --> Security Class Initialized
DEBUG - 2016-11-29 23:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:32:39 --> Input Class Initialized
INFO - 2016-11-29 23:32:39 --> Language Class Initialized
INFO - 2016-11-29 23:32:39 --> Loader Class Initialized
INFO - 2016-11-29 23:32:39 --> Database Driver Class Initialized
INFO - 2016-11-29 23:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:32:39 --> Controller Class Initialized
INFO - 2016-11-29 23:32:39 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:32:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:32:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:32:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:32:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:32:39 --> Final output sent to browser
DEBUG - 2016-11-29 23:32:39 --> Total execution time: 0.0139
INFO - 2016-11-29 23:33:06 --> Config Class Initialized
INFO - 2016-11-29 23:33:06 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:33:06 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:33:06 --> Utf8 Class Initialized
INFO - 2016-11-29 23:33:06 --> URI Class Initialized
DEBUG - 2016-11-29 23:33:06 --> No URI present. Default controller set.
INFO - 2016-11-29 23:33:06 --> Router Class Initialized
INFO - 2016-11-29 23:33:06 --> Output Class Initialized
INFO - 2016-11-29 23:33:06 --> Security Class Initialized
DEBUG - 2016-11-29 23:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:33:06 --> Input Class Initialized
INFO - 2016-11-29 23:33:06 --> Language Class Initialized
INFO - 2016-11-29 23:33:06 --> Loader Class Initialized
INFO - 2016-11-29 23:33:06 --> Database Driver Class Initialized
INFO - 2016-11-29 23:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:33:06 --> Controller Class Initialized
INFO - 2016-11-29 23:33:06 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:33:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:33:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:33:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:33:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:33:06 --> Final output sent to browser
DEBUG - 2016-11-29 23:33:06 --> Total execution time: 0.0188
INFO - 2016-11-29 23:33:08 --> Config Class Initialized
INFO - 2016-11-29 23:33:08 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:33:08 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:33:08 --> Utf8 Class Initialized
INFO - 2016-11-29 23:33:08 --> URI Class Initialized
INFO - 2016-11-29 23:33:08 --> Router Class Initialized
INFO - 2016-11-29 23:33:08 --> Output Class Initialized
INFO - 2016-11-29 23:33:08 --> Security Class Initialized
DEBUG - 2016-11-29 23:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:33:08 --> Input Class Initialized
INFO - 2016-11-29 23:33:08 --> Language Class Initialized
ERROR - 2016-11-29 23:33:08 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:33:08 --> Config Class Initialized
INFO - 2016-11-29 23:33:08 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:33:08 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:33:08 --> Utf8 Class Initialized
INFO - 2016-11-29 23:33:08 --> URI Class Initialized
INFO - 2016-11-29 23:33:08 --> Router Class Initialized
INFO - 2016-11-29 23:33:08 --> Output Class Initialized
INFO - 2016-11-29 23:33:08 --> Security Class Initialized
DEBUG - 2016-11-29 23:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:33:08 --> Input Class Initialized
INFO - 2016-11-29 23:33:08 --> Language Class Initialized
ERROR - 2016-11-29 23:33:08 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:33:09 --> Config Class Initialized
INFO - 2016-11-29 23:33:09 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:33:09 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:33:09 --> Utf8 Class Initialized
INFO - 2016-11-29 23:33:09 --> URI Class Initialized
INFO - 2016-11-29 23:33:09 --> Router Class Initialized
INFO - 2016-11-29 23:33:09 --> Output Class Initialized
INFO - 2016-11-29 23:33:09 --> Security Class Initialized
DEBUG - 2016-11-29 23:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:33:09 --> Input Class Initialized
INFO - 2016-11-29 23:33:09 --> Language Class Initialized
INFO - 2016-11-29 23:33:09 --> Loader Class Initialized
INFO - 2016-11-29 23:33:09 --> Database Driver Class Initialized
INFO - 2016-11-29 23:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:33:09 --> Controller Class Initialized
INFO - 2016-11-29 23:33:09 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:33:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:33:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:33:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:33:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:33:09 --> Final output sent to browser
DEBUG - 2016-11-29 23:33:09 --> Total execution time: 0.0203
INFO - 2016-11-29 23:33:13 --> Config Class Initialized
INFO - 2016-11-29 23:33:13 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:33:13 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:33:13 --> Utf8 Class Initialized
INFO - 2016-11-29 23:33:13 --> URI Class Initialized
INFO - 2016-11-29 23:33:13 --> Router Class Initialized
INFO - 2016-11-29 23:33:13 --> Output Class Initialized
INFO - 2016-11-29 23:33:13 --> Security Class Initialized
DEBUG - 2016-11-29 23:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:33:13 --> Input Class Initialized
INFO - 2016-11-29 23:33:13 --> Language Class Initialized
ERROR - 2016-11-29 23:33:13 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 23:33:13 --> Config Class Initialized
INFO - 2016-11-29 23:33:13 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:33:13 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:33:13 --> Utf8 Class Initialized
INFO - 2016-11-29 23:33:13 --> URI Class Initialized
INFO - 2016-11-29 23:33:13 --> Router Class Initialized
INFO - 2016-11-29 23:33:13 --> Output Class Initialized
INFO - 2016-11-29 23:33:13 --> Security Class Initialized
DEBUG - 2016-11-29 23:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:33:13 --> Input Class Initialized
INFO - 2016-11-29 23:33:13 --> Language Class Initialized
ERROR - 2016-11-29 23:33:13 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 23:33:39 --> Config Class Initialized
INFO - 2016-11-29 23:33:39 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:33:39 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:33:39 --> Utf8 Class Initialized
INFO - 2016-11-29 23:33:39 --> URI Class Initialized
DEBUG - 2016-11-29 23:33:39 --> No URI present. Default controller set.
INFO - 2016-11-29 23:33:39 --> Router Class Initialized
INFO - 2016-11-29 23:33:39 --> Output Class Initialized
INFO - 2016-11-29 23:33:39 --> Security Class Initialized
DEBUG - 2016-11-29 23:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:33:39 --> Input Class Initialized
INFO - 2016-11-29 23:33:39 --> Language Class Initialized
INFO - 2016-11-29 23:33:39 --> Loader Class Initialized
INFO - 2016-11-29 23:33:39 --> Database Driver Class Initialized
INFO - 2016-11-29 23:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:33:39 --> Controller Class Initialized
INFO - 2016-11-29 23:33:39 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:33:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:33:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:33:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:33:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:33:39 --> Final output sent to browser
DEBUG - 2016-11-29 23:33:39 --> Total execution time: 0.0224
INFO - 2016-11-29 23:33:40 --> Config Class Initialized
INFO - 2016-11-29 23:33:40 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:33:40 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:33:40 --> Utf8 Class Initialized
INFO - 2016-11-29 23:33:40 --> URI Class Initialized
INFO - 2016-11-29 23:33:40 --> Router Class Initialized
INFO - 2016-11-29 23:33:40 --> Output Class Initialized
INFO - 2016-11-29 23:33:40 --> Security Class Initialized
DEBUG - 2016-11-29 23:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:33:40 --> Input Class Initialized
INFO - 2016-11-29 23:33:40 --> Language Class Initialized
ERROR - 2016-11-29 23:33:40 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:33:40 --> Config Class Initialized
INFO - 2016-11-29 23:33:40 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:33:40 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:33:40 --> Utf8 Class Initialized
INFO - 2016-11-29 23:33:40 --> URI Class Initialized
INFO - 2016-11-29 23:33:40 --> Router Class Initialized
INFO - 2016-11-29 23:33:40 --> Output Class Initialized
INFO - 2016-11-29 23:33:40 --> Security Class Initialized
DEBUG - 2016-11-29 23:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:33:40 --> Input Class Initialized
INFO - 2016-11-29 23:33:40 --> Language Class Initialized
ERROR - 2016-11-29 23:33:40 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 23:33:40 --> Config Class Initialized
INFO - 2016-11-29 23:33:40 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:33:40 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:33:40 --> Utf8 Class Initialized
INFO - 2016-11-29 23:33:40 --> URI Class Initialized
INFO - 2016-11-29 23:33:40 --> Router Class Initialized
INFO - 2016-11-29 23:33:40 --> Output Class Initialized
INFO - 2016-11-29 23:33:40 --> Config Class Initialized
INFO - 2016-11-29 23:33:40 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:33:40 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:33:40 --> Utf8 Class Initialized
INFO - 2016-11-29 23:33:40 --> URI Class Initialized
INFO - 2016-11-29 23:33:40 --> Router Class Initialized
INFO - 2016-11-29 23:33:40 --> Output Class Initialized
INFO - 2016-11-29 23:33:40 --> Security Class Initialized
DEBUG - 2016-11-29 23:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:33:40 --> Input Class Initialized
INFO - 2016-11-29 23:33:40 --> Language Class Initialized
ERROR - 2016-11-29 23:33:40 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:33:40 --> Security Class Initialized
DEBUG - 2016-11-29 23:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:33:40 --> Input Class Initialized
INFO - 2016-11-29 23:33:40 --> Language Class Initialized
ERROR - 2016-11-29 23:33:40 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 23:33:40 --> Config Class Initialized
INFO - 2016-11-29 23:33:40 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:33:40 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:33:40 --> Utf8 Class Initialized
INFO - 2016-11-29 23:33:40 --> URI Class Initialized
INFO - 2016-11-29 23:33:40 --> Router Class Initialized
INFO - 2016-11-29 23:33:40 --> Output Class Initialized
INFO - 2016-11-29 23:33:40 --> Security Class Initialized
DEBUG - 2016-11-29 23:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:33:40 --> Input Class Initialized
INFO - 2016-11-29 23:33:40 --> Language Class Initialized
INFO - 2016-11-29 23:33:40 --> Loader Class Initialized
INFO - 2016-11-29 23:33:40 --> Database Driver Class Initialized
INFO - 2016-11-29 23:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:33:40 --> Controller Class Initialized
INFO - 2016-11-29 23:33:40 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:33:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:33:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:33:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:33:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:33:40 --> Final output sent to browser
DEBUG - 2016-11-29 23:33:40 --> Total execution time: 0.0143
INFO - 2016-11-29 23:34:17 --> Config Class Initialized
INFO - 2016-11-29 23:34:17 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:34:17 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:34:17 --> Utf8 Class Initialized
INFO - 2016-11-29 23:34:17 --> URI Class Initialized
DEBUG - 2016-11-29 23:34:17 --> No URI present. Default controller set.
INFO - 2016-11-29 23:34:17 --> Router Class Initialized
INFO - 2016-11-29 23:34:17 --> Output Class Initialized
INFO - 2016-11-29 23:34:17 --> Security Class Initialized
DEBUG - 2016-11-29 23:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:34:17 --> Input Class Initialized
INFO - 2016-11-29 23:34:17 --> Language Class Initialized
INFO - 2016-11-29 23:34:17 --> Loader Class Initialized
INFO - 2016-11-29 23:34:17 --> Database Driver Class Initialized
INFO - 2016-11-29 23:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:34:17 --> Controller Class Initialized
INFO - 2016-11-29 23:34:17 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:34:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:34:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:34:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:34:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:34:17 --> Final output sent to browser
DEBUG - 2016-11-29 23:34:17 --> Total execution time: 0.0138
INFO - 2016-11-29 23:34:18 --> Config Class Initialized
INFO - 2016-11-29 23:34:18 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:34:18 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:34:18 --> Utf8 Class Initialized
INFO - 2016-11-29 23:34:18 --> URI Class Initialized
INFO - 2016-11-29 23:34:18 --> Router Class Initialized
INFO - 2016-11-29 23:34:18 --> Output Class Initialized
INFO - 2016-11-29 23:34:18 --> Security Class Initialized
DEBUG - 2016-11-29 23:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:34:18 --> Input Class Initialized
INFO - 2016-11-29 23:34:18 --> Language Class Initialized
ERROR - 2016-11-29 23:34:18 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:34:18 --> Config Class Initialized
INFO - 2016-11-29 23:34:18 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:34:18 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:34:18 --> Utf8 Class Initialized
INFO - 2016-11-29 23:34:18 --> URI Class Initialized
INFO - 2016-11-29 23:34:18 --> Router Class Initialized
INFO - 2016-11-29 23:34:18 --> Output Class Initialized
INFO - 2016-11-29 23:34:18 --> Security Class Initialized
DEBUG - 2016-11-29 23:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:34:18 --> Input Class Initialized
INFO - 2016-11-29 23:34:18 --> Language Class Initialized
ERROR - 2016-11-29 23:34:18 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 23:34:18 --> Config Class Initialized
INFO - 2016-11-29 23:34:18 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:34:18 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:34:18 --> Utf8 Class Initialized
INFO - 2016-11-29 23:34:18 --> URI Class Initialized
INFO - 2016-11-29 23:34:18 --> Router Class Initialized
INFO - 2016-11-29 23:34:18 --> Output Class Initialized
INFO - 2016-11-29 23:34:18 --> Security Class Initialized
DEBUG - 2016-11-29 23:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:34:18 --> Input Class Initialized
INFO - 2016-11-29 23:34:18 --> Language Class Initialized
ERROR - 2016-11-29 23:34:18 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:34:18 --> Config Class Initialized
INFO - 2016-11-29 23:34:18 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:34:18 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:34:18 --> Utf8 Class Initialized
INFO - 2016-11-29 23:34:18 --> URI Class Initialized
INFO - 2016-11-29 23:34:18 --> Router Class Initialized
INFO - 2016-11-29 23:34:18 --> Output Class Initialized
INFO - 2016-11-29 23:34:18 --> Security Class Initialized
DEBUG - 2016-11-29 23:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:34:18 --> Input Class Initialized
INFO - 2016-11-29 23:34:18 --> Language Class Initialized
ERROR - 2016-11-29 23:34:18 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 23:34:23 --> Config Class Initialized
INFO - 2016-11-29 23:34:23 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:34:23 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:34:23 --> Utf8 Class Initialized
INFO - 2016-11-29 23:34:23 --> URI Class Initialized
INFO - 2016-11-29 23:34:23 --> Router Class Initialized
INFO - 2016-11-29 23:34:23 --> Output Class Initialized
INFO - 2016-11-29 23:34:23 --> Security Class Initialized
DEBUG - 2016-11-29 23:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:34:23 --> Input Class Initialized
INFO - 2016-11-29 23:34:23 --> Language Class Initialized
INFO - 2016-11-29 23:34:23 --> Loader Class Initialized
INFO - 2016-11-29 23:34:23 --> Database Driver Class Initialized
INFO - 2016-11-29 23:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:34:23 --> Controller Class Initialized
INFO - 2016-11-29 23:34:23 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:34:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:34:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:34:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:34:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:34:23 --> Final output sent to browser
DEBUG - 2016-11-29 23:34:23 --> Total execution time: 0.0132
INFO - 2016-11-29 23:34:43 --> Config Class Initialized
INFO - 2016-11-29 23:34:43 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:34:43 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:34:43 --> Utf8 Class Initialized
INFO - 2016-11-29 23:34:43 --> URI Class Initialized
DEBUG - 2016-11-29 23:34:43 --> No URI present. Default controller set.
INFO - 2016-11-29 23:34:43 --> Router Class Initialized
INFO - 2016-11-29 23:34:43 --> Output Class Initialized
INFO - 2016-11-29 23:34:43 --> Security Class Initialized
DEBUG - 2016-11-29 23:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:34:43 --> Input Class Initialized
INFO - 2016-11-29 23:34:43 --> Language Class Initialized
INFO - 2016-11-29 23:34:43 --> Loader Class Initialized
INFO - 2016-11-29 23:34:43 --> Database Driver Class Initialized
INFO - 2016-11-29 23:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:34:43 --> Controller Class Initialized
INFO - 2016-11-29 23:34:43 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:34:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:34:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:34:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:34:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:34:43 --> Final output sent to browser
DEBUG - 2016-11-29 23:34:43 --> Total execution time: 0.0148
INFO - 2016-11-29 23:34:44 --> Config Class Initialized
INFO - 2016-11-29 23:34:44 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:34:44 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:34:44 --> Utf8 Class Initialized
INFO - 2016-11-29 23:34:44 --> URI Class Initialized
INFO - 2016-11-29 23:34:44 --> Router Class Initialized
INFO - 2016-11-29 23:34:44 --> Output Class Initialized
INFO - 2016-11-29 23:34:44 --> Security Class Initialized
DEBUG - 2016-11-29 23:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:34:44 --> Input Class Initialized
INFO - 2016-11-29 23:34:44 --> Language Class Initialized
ERROR - 2016-11-29 23:34:44 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:34:44 --> Config Class Initialized
INFO - 2016-11-29 23:34:44 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:34:44 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:34:44 --> Utf8 Class Initialized
INFO - 2016-11-29 23:34:44 --> URI Class Initialized
INFO - 2016-11-29 23:34:44 --> Router Class Initialized
INFO - 2016-11-29 23:34:44 --> Output Class Initialized
INFO - 2016-11-29 23:34:44 --> Security Class Initialized
DEBUG - 2016-11-29 23:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:34:44 --> Input Class Initialized
INFO - 2016-11-29 23:34:44 --> Language Class Initialized
ERROR - 2016-11-29 23:34:44 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:34:44 --> Config Class Initialized
INFO - 2016-11-29 23:34:44 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:34:44 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:34:44 --> Utf8 Class Initialized
INFO - 2016-11-29 23:34:44 --> URI Class Initialized
INFO - 2016-11-29 23:34:44 --> Router Class Initialized
INFO - 2016-11-29 23:34:44 --> Output Class Initialized
INFO - 2016-11-29 23:34:44 --> Security Class Initialized
DEBUG - 2016-11-29 23:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:34:44 --> Input Class Initialized
INFO - 2016-11-29 23:34:44 --> Language Class Initialized
INFO - 2016-11-29 23:34:44 --> Loader Class Initialized
INFO - 2016-11-29 23:34:44 --> Database Driver Class Initialized
INFO - 2016-11-29 23:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:34:44 --> Controller Class Initialized
INFO - 2016-11-29 23:34:44 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:34:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:34:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:34:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:34:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:34:44 --> Final output sent to browser
DEBUG - 2016-11-29 23:34:44 --> Total execution time: 0.0139
INFO - 2016-11-29 23:35:07 --> Config Class Initialized
INFO - 2016-11-29 23:35:07 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:35:07 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:35:07 --> Utf8 Class Initialized
INFO - 2016-11-29 23:35:07 --> URI Class Initialized
DEBUG - 2016-11-29 23:35:07 --> No URI present. Default controller set.
INFO - 2016-11-29 23:35:07 --> Router Class Initialized
INFO - 2016-11-29 23:35:07 --> Output Class Initialized
INFO - 2016-11-29 23:35:07 --> Security Class Initialized
DEBUG - 2016-11-29 23:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:35:07 --> Input Class Initialized
INFO - 2016-11-29 23:35:07 --> Language Class Initialized
INFO - 2016-11-29 23:35:07 --> Loader Class Initialized
INFO - 2016-11-29 23:35:07 --> Database Driver Class Initialized
INFO - 2016-11-29 23:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:35:07 --> Controller Class Initialized
INFO - 2016-11-29 23:35:07 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:35:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:35:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:35:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:35:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:35:07 --> Final output sent to browser
DEBUG - 2016-11-29 23:35:07 --> Total execution time: 0.0438
INFO - 2016-11-29 23:35:08 --> Config Class Initialized
INFO - 2016-11-29 23:35:08 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:35:08 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:35:08 --> Utf8 Class Initialized
INFO - 2016-11-29 23:35:08 --> URI Class Initialized
INFO - 2016-11-29 23:35:08 --> Router Class Initialized
INFO - 2016-11-29 23:35:08 --> Output Class Initialized
INFO - 2016-11-29 23:35:08 --> Security Class Initialized
DEBUG - 2016-11-29 23:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:35:08 --> Input Class Initialized
INFO - 2016-11-29 23:35:08 --> Language Class Initialized
ERROR - 2016-11-29 23:35:08 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:35:08 --> Config Class Initialized
INFO - 2016-11-29 23:35:08 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:35:08 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:35:08 --> Utf8 Class Initialized
INFO - 2016-11-29 23:35:08 --> URI Class Initialized
INFO - 2016-11-29 23:35:08 --> Router Class Initialized
INFO - 2016-11-29 23:35:08 --> Output Class Initialized
INFO - 2016-11-29 23:35:08 --> Security Class Initialized
DEBUG - 2016-11-29 23:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:35:08 --> Input Class Initialized
INFO - 2016-11-29 23:35:08 --> Language Class Initialized
ERROR - 2016-11-29 23:35:08 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:35:09 --> Config Class Initialized
INFO - 2016-11-29 23:35:09 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:35:09 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:35:09 --> Utf8 Class Initialized
INFO - 2016-11-29 23:35:09 --> URI Class Initialized
INFO - 2016-11-29 23:35:09 --> Router Class Initialized
INFO - 2016-11-29 23:35:09 --> Output Class Initialized
INFO - 2016-11-29 23:35:09 --> Security Class Initialized
DEBUG - 2016-11-29 23:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:35:09 --> Input Class Initialized
INFO - 2016-11-29 23:35:09 --> Language Class Initialized
INFO - 2016-11-29 23:35:09 --> Loader Class Initialized
INFO - 2016-11-29 23:35:09 --> Database Driver Class Initialized
INFO - 2016-11-29 23:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:35:09 --> Controller Class Initialized
INFO - 2016-11-29 23:35:09 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:35:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:35:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:35:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:35:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:35:09 --> Final output sent to browser
DEBUG - 2016-11-29 23:35:09 --> Total execution time: 0.0145
INFO - 2016-11-29 23:35:10 --> Config Class Initialized
INFO - 2016-11-29 23:35:10 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:35:10 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:35:10 --> Utf8 Class Initialized
INFO - 2016-11-29 23:35:10 --> URI Class Initialized
DEBUG - 2016-11-29 23:35:10 --> No URI present. Default controller set.
INFO - 2016-11-29 23:35:10 --> Router Class Initialized
INFO - 2016-11-29 23:35:10 --> Output Class Initialized
INFO - 2016-11-29 23:35:10 --> Security Class Initialized
DEBUG - 2016-11-29 23:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:35:10 --> Input Class Initialized
INFO - 2016-11-29 23:35:10 --> Language Class Initialized
INFO - 2016-11-29 23:35:10 --> Loader Class Initialized
INFO - 2016-11-29 23:35:10 --> Database Driver Class Initialized
INFO - 2016-11-29 23:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:35:10 --> Controller Class Initialized
INFO - 2016-11-29 23:35:10 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:35:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:35:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:35:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:35:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:35:10 --> Final output sent to browser
DEBUG - 2016-11-29 23:35:10 --> Total execution time: 0.0138
INFO - 2016-11-29 23:35:10 --> Config Class Initialized
INFO - 2016-11-29 23:35:10 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:35:10 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:35:10 --> Utf8 Class Initialized
INFO - 2016-11-29 23:35:10 --> URI Class Initialized
INFO - 2016-11-29 23:35:10 --> Router Class Initialized
INFO - 2016-11-29 23:35:10 --> Output Class Initialized
INFO - 2016-11-29 23:35:10 --> Security Class Initialized
DEBUG - 2016-11-29 23:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:35:10 --> Input Class Initialized
INFO - 2016-11-29 23:35:10 --> Language Class Initialized
ERROR - 2016-11-29 23:35:10 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:35:11 --> Config Class Initialized
INFO - 2016-11-29 23:35:11 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:35:11 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:35:11 --> Utf8 Class Initialized
INFO - 2016-11-29 23:35:11 --> URI Class Initialized
INFO - 2016-11-29 23:35:11 --> Router Class Initialized
INFO - 2016-11-29 23:35:11 --> Output Class Initialized
INFO - 2016-11-29 23:35:11 --> Security Class Initialized
DEBUG - 2016-11-29 23:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:35:11 --> Input Class Initialized
INFO - 2016-11-29 23:35:11 --> Language Class Initialized
ERROR - 2016-11-29 23:35:11 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:35:11 --> Config Class Initialized
INFO - 2016-11-29 23:35:11 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:35:11 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:35:11 --> Utf8 Class Initialized
INFO - 2016-11-29 23:35:11 --> URI Class Initialized
INFO - 2016-11-29 23:35:11 --> Router Class Initialized
INFO - 2016-11-29 23:35:11 --> Output Class Initialized
INFO - 2016-11-29 23:35:11 --> Security Class Initialized
DEBUG - 2016-11-29 23:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:35:11 --> Input Class Initialized
INFO - 2016-11-29 23:35:11 --> Language Class Initialized
INFO - 2016-11-29 23:35:11 --> Loader Class Initialized
INFO - 2016-11-29 23:35:11 --> Database Driver Class Initialized
INFO - 2016-11-29 23:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:35:11 --> Controller Class Initialized
INFO - 2016-11-29 23:35:11 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:35:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:35:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:35:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:35:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:35:11 --> Final output sent to browser
DEBUG - 2016-11-29 23:35:11 --> Total execution time: 0.0145
INFO - 2016-11-29 23:35:12 --> Config Class Initialized
INFO - 2016-11-29 23:35:12 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:35:12 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:35:12 --> Utf8 Class Initialized
INFO - 2016-11-29 23:35:12 --> URI Class Initialized
DEBUG - 2016-11-29 23:35:12 --> No URI present. Default controller set.
INFO - 2016-11-29 23:35:12 --> Router Class Initialized
INFO - 2016-11-29 23:35:12 --> Output Class Initialized
INFO - 2016-11-29 23:35:12 --> Security Class Initialized
DEBUG - 2016-11-29 23:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:35:12 --> Input Class Initialized
INFO - 2016-11-29 23:35:12 --> Language Class Initialized
INFO - 2016-11-29 23:35:12 --> Loader Class Initialized
INFO - 2016-11-29 23:35:12 --> Database Driver Class Initialized
INFO - 2016-11-29 23:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:35:12 --> Controller Class Initialized
INFO - 2016-11-29 23:35:12 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:35:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:35:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:35:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:35:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:35:12 --> Final output sent to browser
DEBUG - 2016-11-29 23:35:12 --> Total execution time: 0.0128
INFO - 2016-11-29 23:35:13 --> Config Class Initialized
INFO - 2016-11-29 23:35:13 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:35:13 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:35:13 --> Utf8 Class Initialized
INFO - 2016-11-29 23:35:13 --> URI Class Initialized
INFO - 2016-11-29 23:35:13 --> Router Class Initialized
INFO - 2016-11-29 23:35:13 --> Output Class Initialized
INFO - 2016-11-29 23:35:13 --> Security Class Initialized
DEBUG - 2016-11-29 23:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:35:13 --> Input Class Initialized
INFO - 2016-11-29 23:35:13 --> Language Class Initialized
INFO - 2016-11-29 23:35:13 --> Loader Class Initialized
INFO - 2016-11-29 23:35:13 --> Database Driver Class Initialized
INFO - 2016-11-29 23:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:35:13 --> Controller Class Initialized
INFO - 2016-11-29 23:35:13 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:35:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:35:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:35:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:35:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:35:13 --> Final output sent to browser
DEBUG - 2016-11-29 23:35:13 --> Total execution time: 0.0137
INFO - 2016-11-29 23:35:15 --> Config Class Initialized
INFO - 2016-11-29 23:35:15 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:35:15 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:35:15 --> Utf8 Class Initialized
INFO - 2016-11-29 23:35:15 --> URI Class Initialized
INFO - 2016-11-29 23:35:15 --> Router Class Initialized
INFO - 2016-11-29 23:35:15 --> Output Class Initialized
INFO - 2016-11-29 23:35:15 --> Security Class Initialized
INFO - 2016-11-29 23:35:15 --> Config Class Initialized
INFO - 2016-11-29 23:35:15 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:35:15 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:35:15 --> Utf8 Class Initialized
INFO - 2016-11-29 23:35:15 --> URI Class Initialized
DEBUG - 2016-11-29 23:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:35:15 --> Input Class Initialized
INFO - 2016-11-29 23:35:15 --> Language Class Initialized
ERROR - 2016-11-29 23:35:15 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 23:35:15 --> Router Class Initialized
INFO - 2016-11-29 23:35:15 --> Output Class Initialized
INFO - 2016-11-29 23:35:15 --> Security Class Initialized
DEBUG - 2016-11-29 23:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:35:15 --> Input Class Initialized
INFO - 2016-11-29 23:35:15 --> Language Class Initialized
ERROR - 2016-11-29 23:35:15 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 23:35:28 --> Config Class Initialized
INFO - 2016-11-29 23:35:28 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:35:28 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:35:28 --> Utf8 Class Initialized
INFO - 2016-11-29 23:35:28 --> URI Class Initialized
DEBUG - 2016-11-29 23:35:28 --> No URI present. Default controller set.
INFO - 2016-11-29 23:35:28 --> Router Class Initialized
INFO - 2016-11-29 23:35:28 --> Output Class Initialized
INFO - 2016-11-29 23:35:28 --> Security Class Initialized
DEBUG - 2016-11-29 23:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:35:28 --> Input Class Initialized
INFO - 2016-11-29 23:35:28 --> Language Class Initialized
INFO - 2016-11-29 23:35:28 --> Loader Class Initialized
INFO - 2016-11-29 23:35:28 --> Database Driver Class Initialized
INFO - 2016-11-29 23:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:35:28 --> Controller Class Initialized
INFO - 2016-11-29 23:35:28 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:35:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:35:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:35:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:35:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:35:28 --> Final output sent to browser
DEBUG - 2016-11-29 23:35:28 --> Total execution time: 0.0140
INFO - 2016-11-29 23:35:28 --> Config Class Initialized
INFO - 2016-11-29 23:35:28 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:35:28 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:35:28 --> Utf8 Class Initialized
INFO - 2016-11-29 23:35:28 --> URI Class Initialized
INFO - 2016-11-29 23:35:28 --> Router Class Initialized
INFO - 2016-11-29 23:35:29 --> Output Class Initialized
INFO - 2016-11-29 23:35:29 --> Security Class Initialized
DEBUG - 2016-11-29 23:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:35:29 --> Input Class Initialized
INFO - 2016-11-29 23:35:29 --> Language Class Initialized
ERROR - 2016-11-29 23:35:29 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:35:29 --> Config Class Initialized
INFO - 2016-11-29 23:35:29 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:35:29 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:35:29 --> Utf8 Class Initialized
INFO - 2016-11-29 23:35:29 --> URI Class Initialized
INFO - 2016-11-29 23:35:29 --> Router Class Initialized
INFO - 2016-11-29 23:35:29 --> Output Class Initialized
INFO - 2016-11-29 23:35:29 --> Security Class Initialized
DEBUG - 2016-11-29 23:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:35:29 --> Input Class Initialized
INFO - 2016-11-29 23:35:29 --> Language Class Initialized
ERROR - 2016-11-29 23:35:29 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:35:29 --> Config Class Initialized
INFO - 2016-11-29 23:35:29 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:35:29 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:35:29 --> Utf8 Class Initialized
INFO - 2016-11-29 23:35:29 --> URI Class Initialized
INFO - 2016-11-29 23:35:29 --> Router Class Initialized
INFO - 2016-11-29 23:35:29 --> Output Class Initialized
INFO - 2016-11-29 23:35:29 --> Security Class Initialized
DEBUG - 2016-11-29 23:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:35:29 --> Input Class Initialized
INFO - 2016-11-29 23:35:29 --> Language Class Initialized
ERROR - 2016-11-29 23:35:29 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 23:35:29 --> Config Class Initialized
INFO - 2016-11-29 23:35:29 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:35:29 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:35:29 --> Utf8 Class Initialized
INFO - 2016-11-29 23:35:29 --> URI Class Initialized
INFO - 2016-11-29 23:35:29 --> Router Class Initialized
INFO - 2016-11-29 23:35:29 --> Output Class Initialized
INFO - 2016-11-29 23:35:29 --> Security Class Initialized
DEBUG - 2016-11-29 23:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:35:29 --> Input Class Initialized
INFO - 2016-11-29 23:35:29 --> Language Class Initialized
ERROR - 2016-11-29 23:35:29 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 23:35:29 --> Config Class Initialized
INFO - 2016-11-29 23:35:29 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:35:29 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:35:29 --> Utf8 Class Initialized
INFO - 2016-11-29 23:35:29 --> URI Class Initialized
INFO - 2016-11-29 23:35:29 --> Router Class Initialized
INFO - 2016-11-29 23:35:29 --> Output Class Initialized
INFO - 2016-11-29 23:35:29 --> Security Class Initialized
DEBUG - 2016-11-29 23:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:35:29 --> Input Class Initialized
INFO - 2016-11-29 23:35:29 --> Language Class Initialized
INFO - 2016-11-29 23:35:29 --> Loader Class Initialized
INFO - 2016-11-29 23:35:29 --> Database Driver Class Initialized
INFO - 2016-11-29 23:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:35:29 --> Controller Class Initialized
INFO - 2016-11-29 23:35:29 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:35:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:35:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:35:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:35:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:35:29 --> Final output sent to browser
DEBUG - 2016-11-29 23:35:29 --> Total execution time: 0.0208
INFO - 2016-11-29 23:36:37 --> Config Class Initialized
INFO - 2016-11-29 23:36:37 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:36:37 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:36:37 --> Utf8 Class Initialized
INFO - 2016-11-29 23:36:37 --> URI Class Initialized
DEBUG - 2016-11-29 23:36:37 --> No URI present. Default controller set.
INFO - 2016-11-29 23:36:37 --> Router Class Initialized
INFO - 2016-11-29 23:36:37 --> Output Class Initialized
INFO - 2016-11-29 23:36:37 --> Security Class Initialized
DEBUG - 2016-11-29 23:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:36:37 --> Input Class Initialized
INFO - 2016-11-29 23:36:37 --> Language Class Initialized
INFO - 2016-11-29 23:36:37 --> Loader Class Initialized
INFO - 2016-11-29 23:36:37 --> Database Driver Class Initialized
INFO - 2016-11-29 23:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:36:37 --> Controller Class Initialized
INFO - 2016-11-29 23:36:37 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:36:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:36:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:36:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:36:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:36:37 --> Final output sent to browser
DEBUG - 2016-11-29 23:36:37 --> Total execution time: 0.0139
INFO - 2016-11-29 23:36:37 --> Config Class Initialized
INFO - 2016-11-29 23:36:37 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:36:37 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:36:37 --> Utf8 Class Initialized
INFO - 2016-11-29 23:36:37 --> URI Class Initialized
INFO - 2016-11-29 23:36:37 --> Config Class Initialized
INFO - 2016-11-29 23:36:37 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:36:37 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:36:37 --> Utf8 Class Initialized
INFO - 2016-11-29 23:36:37 --> URI Class Initialized
INFO - 2016-11-29 23:36:37 --> Router Class Initialized
INFO - 2016-11-29 23:36:37 --> Output Class Initialized
INFO - 2016-11-29 23:36:37 --> Security Class Initialized
DEBUG - 2016-11-29 23:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:36:37 --> Input Class Initialized
INFO - 2016-11-29 23:36:37 --> Language Class Initialized
ERROR - 2016-11-29 23:36:37 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:36:37 --> Router Class Initialized
INFO - 2016-11-29 23:36:37 --> Output Class Initialized
INFO - 2016-11-29 23:36:37 --> Security Class Initialized
DEBUG - 2016-11-29 23:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:36:37 --> Input Class Initialized
INFO - 2016-11-29 23:36:37 --> Language Class Initialized
ERROR - 2016-11-29 23:36:37 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:36:37 --> Config Class Initialized
INFO - 2016-11-29 23:36:37 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:36:37 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:36:37 --> Utf8 Class Initialized
INFO - 2016-11-29 23:36:37 --> URI Class Initialized
INFO - 2016-11-29 23:36:37 --> Router Class Initialized
INFO - 2016-11-29 23:36:37 --> Output Class Initialized
INFO - 2016-11-29 23:36:37 --> Security Class Initialized
DEBUG - 2016-11-29 23:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:36:37 --> Input Class Initialized
INFO - 2016-11-29 23:36:37 --> Language Class Initialized
ERROR - 2016-11-29 23:36:37 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 23:36:37 --> Config Class Initialized
INFO - 2016-11-29 23:36:37 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:36:37 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:36:37 --> Utf8 Class Initialized
INFO - 2016-11-29 23:36:37 --> URI Class Initialized
INFO - 2016-11-29 23:36:37 --> Router Class Initialized
INFO - 2016-11-29 23:36:37 --> Output Class Initialized
INFO - 2016-11-29 23:36:37 --> Security Class Initialized
DEBUG - 2016-11-29 23:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:36:37 --> Input Class Initialized
INFO - 2016-11-29 23:36:37 --> Language Class Initialized
INFO - 2016-11-29 23:36:37 --> Loader Class Initialized
INFO - 2016-11-29 23:36:37 --> Database Driver Class Initialized
INFO - 2016-11-29 23:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:36:37 --> Controller Class Initialized
INFO - 2016-11-29 23:36:37 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:36:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:36:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:36:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:36:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:36:37 --> Final output sent to browser
DEBUG - 2016-11-29 23:36:37 --> Total execution time: 0.0216
INFO - 2016-11-29 23:36:38 --> Config Class Initialized
INFO - 2016-11-29 23:36:38 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:36:38 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:36:38 --> Utf8 Class Initialized
INFO - 2016-11-29 23:36:38 --> URI Class Initialized
INFO - 2016-11-29 23:36:38 --> Router Class Initialized
INFO - 2016-11-29 23:36:38 --> Output Class Initialized
INFO - 2016-11-29 23:36:38 --> Security Class Initialized
DEBUG - 2016-11-29 23:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:36:38 --> Input Class Initialized
INFO - 2016-11-29 23:36:38 --> Language Class Initialized
ERROR - 2016-11-29 23:36:38 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 23:36:59 --> Config Class Initialized
INFO - 2016-11-29 23:36:59 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:36:59 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:36:59 --> Utf8 Class Initialized
INFO - 2016-11-29 23:36:59 --> URI Class Initialized
DEBUG - 2016-11-29 23:36:59 --> No URI present. Default controller set.
INFO - 2016-11-29 23:36:59 --> Router Class Initialized
INFO - 2016-11-29 23:36:59 --> Output Class Initialized
INFO - 2016-11-29 23:36:59 --> Security Class Initialized
DEBUG - 2016-11-29 23:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:36:59 --> Input Class Initialized
INFO - 2016-11-29 23:36:59 --> Language Class Initialized
INFO - 2016-11-29 23:36:59 --> Loader Class Initialized
INFO - 2016-11-29 23:36:59 --> Database Driver Class Initialized
INFO - 2016-11-29 23:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:36:59 --> Controller Class Initialized
INFO - 2016-11-29 23:36:59 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:36:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:36:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:36:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:36:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:36:59 --> Final output sent to browser
DEBUG - 2016-11-29 23:36:59 --> Total execution time: 0.0140
INFO - 2016-11-29 23:37:00 --> Config Class Initialized
INFO - 2016-11-29 23:37:00 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:37:00 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:37:00 --> Utf8 Class Initialized
INFO - 2016-11-29 23:37:00 --> URI Class Initialized
INFO - 2016-11-29 23:37:00 --> Router Class Initialized
INFO - 2016-11-29 23:37:00 --> Output Class Initialized
INFO - 2016-11-29 23:37:00 --> Security Class Initialized
DEBUG - 2016-11-29 23:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:37:00 --> Input Class Initialized
INFO - 2016-11-29 23:37:00 --> Language Class Initialized
ERROR - 2016-11-29 23:37:00 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:37:01 --> Config Class Initialized
INFO - 2016-11-29 23:37:01 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:37:01 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:37:01 --> Utf8 Class Initialized
INFO - 2016-11-29 23:37:01 --> URI Class Initialized
INFO - 2016-11-29 23:37:01 --> Router Class Initialized
INFO - 2016-11-29 23:37:01 --> Output Class Initialized
INFO - 2016-11-29 23:37:01 --> Security Class Initialized
DEBUG - 2016-11-29 23:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:37:01 --> Input Class Initialized
INFO - 2016-11-29 23:37:01 --> Language Class Initialized
ERROR - 2016-11-29 23:37:01 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:37:04 --> Config Class Initialized
INFO - 2016-11-29 23:37:04 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:37:04 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:37:04 --> Utf8 Class Initialized
INFO - 2016-11-29 23:37:04 --> URI Class Initialized
INFO - 2016-11-29 23:37:04 --> Router Class Initialized
INFO - 2016-11-29 23:37:04 --> Output Class Initialized
INFO - 2016-11-29 23:37:04 --> Security Class Initialized
DEBUG - 2016-11-29 23:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:37:04 --> Input Class Initialized
INFO - 2016-11-29 23:37:04 --> Language Class Initialized
ERROR - 2016-11-29 23:37:04 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 23:37:04 --> Config Class Initialized
INFO - 2016-11-29 23:37:04 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:37:04 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:37:04 --> Utf8 Class Initialized
INFO - 2016-11-29 23:37:04 --> URI Class Initialized
INFO - 2016-11-29 23:37:04 --> Router Class Initialized
INFO - 2016-11-29 23:37:04 --> Output Class Initialized
INFO - 2016-11-29 23:37:04 --> Security Class Initialized
DEBUG - 2016-11-29 23:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:37:04 --> Input Class Initialized
INFO - 2016-11-29 23:37:04 --> Language Class Initialized
ERROR - 2016-11-29 23:37:04 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 23:37:08 --> Config Class Initialized
INFO - 2016-11-29 23:37:08 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:37:08 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:37:08 --> Utf8 Class Initialized
INFO - 2016-11-29 23:37:08 --> URI Class Initialized
INFO - 2016-11-29 23:37:08 --> Router Class Initialized
INFO - 2016-11-29 23:37:08 --> Output Class Initialized
INFO - 2016-11-29 23:37:08 --> Security Class Initialized
DEBUG - 2016-11-29 23:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:37:08 --> Input Class Initialized
INFO - 2016-11-29 23:37:08 --> Language Class Initialized
INFO - 2016-11-29 23:37:08 --> Loader Class Initialized
INFO - 2016-11-29 23:37:08 --> Database Driver Class Initialized
INFO - 2016-11-29 23:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:37:08 --> Controller Class Initialized
INFO - 2016-11-29 23:37:08 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:37:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:37:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:37:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:37:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:37:08 --> Final output sent to browser
DEBUG - 2016-11-29 23:37:08 --> Total execution time: 0.0205
INFO - 2016-11-29 23:38:07 --> Config Class Initialized
INFO - 2016-11-29 23:38:07 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:38:07 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:38:07 --> Utf8 Class Initialized
INFO - 2016-11-29 23:38:07 --> URI Class Initialized
DEBUG - 2016-11-29 23:38:07 --> No URI present. Default controller set.
INFO - 2016-11-29 23:38:07 --> Router Class Initialized
INFO - 2016-11-29 23:38:07 --> Output Class Initialized
INFO - 2016-11-29 23:38:07 --> Security Class Initialized
DEBUG - 2016-11-29 23:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:38:07 --> Input Class Initialized
INFO - 2016-11-29 23:38:07 --> Language Class Initialized
INFO - 2016-11-29 23:38:07 --> Loader Class Initialized
INFO - 2016-11-29 23:38:07 --> Database Driver Class Initialized
INFO - 2016-11-29 23:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:38:07 --> Controller Class Initialized
INFO - 2016-11-29 23:38:07 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:38:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:38:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:38:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:38:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:38:07 --> Final output sent to browser
DEBUG - 2016-11-29 23:38:07 --> Total execution time: 0.0708
INFO - 2016-11-29 23:38:07 --> Config Class Initialized
INFO - 2016-11-29 23:38:07 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:38:07 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:38:07 --> Utf8 Class Initialized
INFO - 2016-11-29 23:38:07 --> URI Class Initialized
INFO - 2016-11-29 23:38:07 --> Router Class Initialized
INFO - 2016-11-29 23:38:07 --> Output Class Initialized
INFO - 2016-11-29 23:38:07 --> Security Class Initialized
DEBUG - 2016-11-29 23:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:38:07 --> Input Class Initialized
INFO - 2016-11-29 23:38:07 --> Language Class Initialized
ERROR - 2016-11-29 23:38:07 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:38:07 --> Config Class Initialized
INFO - 2016-11-29 23:38:07 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:38:07 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:38:07 --> Utf8 Class Initialized
INFO - 2016-11-29 23:38:07 --> URI Class Initialized
INFO - 2016-11-29 23:38:07 --> Router Class Initialized
INFO - 2016-11-29 23:38:07 --> Output Class Initialized
INFO - 2016-11-29 23:38:07 --> Security Class Initialized
DEBUG - 2016-11-29 23:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:38:07 --> Input Class Initialized
INFO - 2016-11-29 23:38:07 --> Language Class Initialized
ERROR - 2016-11-29 23:38:07 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 23:38:07 --> Config Class Initialized
INFO - 2016-11-29 23:38:07 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:38:07 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:38:07 --> Utf8 Class Initialized
INFO - 2016-11-29 23:38:07 --> URI Class Initialized
INFO - 2016-11-29 23:38:07 --> Router Class Initialized
INFO - 2016-11-29 23:38:07 --> Output Class Initialized
INFO - 2016-11-29 23:38:07 --> Security Class Initialized
DEBUG - 2016-11-29 23:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:38:07 --> Input Class Initialized
INFO - 2016-11-29 23:38:07 --> Language Class Initialized
ERROR - 2016-11-29 23:38:07 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:38:07 --> Config Class Initialized
INFO - 2016-11-29 23:38:07 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:38:07 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:38:07 --> Utf8 Class Initialized
INFO - 2016-11-29 23:38:07 --> URI Class Initialized
INFO - 2016-11-29 23:38:07 --> Router Class Initialized
INFO - 2016-11-29 23:38:07 --> Output Class Initialized
INFO - 2016-11-29 23:38:07 --> Security Class Initialized
DEBUG - 2016-11-29 23:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:38:07 --> Input Class Initialized
INFO - 2016-11-29 23:38:07 --> Language Class Initialized
ERROR - 2016-11-29 23:38:07 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 23:38:07 --> Config Class Initialized
INFO - 2016-11-29 23:38:07 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:38:07 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:38:07 --> Utf8 Class Initialized
INFO - 2016-11-29 23:38:07 --> URI Class Initialized
INFO - 2016-11-29 23:38:07 --> Router Class Initialized
INFO - 2016-11-29 23:38:07 --> Output Class Initialized
INFO - 2016-11-29 23:38:07 --> Security Class Initialized
DEBUG - 2016-11-29 23:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:38:07 --> Input Class Initialized
INFO - 2016-11-29 23:38:07 --> Language Class Initialized
INFO - 2016-11-29 23:38:07 --> Loader Class Initialized
INFO - 2016-11-29 23:38:08 --> Database Driver Class Initialized
INFO - 2016-11-29 23:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:38:08 --> Controller Class Initialized
INFO - 2016-11-29 23:38:08 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:38:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:38:08 --> Final output sent to browser
DEBUG - 2016-11-29 23:38:08 --> Total execution time: 0.0574
INFO - 2016-11-29 23:38:09 --> Config Class Initialized
INFO - 2016-11-29 23:38:09 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:38:09 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:38:09 --> Utf8 Class Initialized
INFO - 2016-11-29 23:38:09 --> URI Class Initialized
DEBUG - 2016-11-29 23:38:09 --> No URI present. Default controller set.
INFO - 2016-11-29 23:38:09 --> Router Class Initialized
INFO - 2016-11-29 23:38:09 --> Output Class Initialized
INFO - 2016-11-29 23:38:09 --> Security Class Initialized
DEBUG - 2016-11-29 23:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:38:09 --> Input Class Initialized
INFO - 2016-11-29 23:38:09 --> Language Class Initialized
INFO - 2016-11-29 23:38:09 --> Loader Class Initialized
INFO - 2016-11-29 23:38:09 --> Database Driver Class Initialized
INFO - 2016-11-29 23:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:38:09 --> Controller Class Initialized
INFO - 2016-11-29 23:38:09 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:38:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:38:09 --> Final output sent to browser
DEBUG - 2016-11-29 23:38:09 --> Total execution time: 0.0195
INFO - 2016-11-29 23:38:09 --> Config Class Initialized
INFO - 2016-11-29 23:38:09 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:38:09 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:38:09 --> Utf8 Class Initialized
INFO - 2016-11-29 23:38:09 --> URI Class Initialized
INFO - 2016-11-29 23:38:09 --> Router Class Initialized
INFO - 2016-11-29 23:38:09 --> Output Class Initialized
INFO - 2016-11-29 23:38:09 --> Security Class Initialized
DEBUG - 2016-11-29 23:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:38:09 --> Input Class Initialized
INFO - 2016-11-29 23:38:09 --> Language Class Initialized
ERROR - 2016-11-29 23:38:09 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:38:09 --> Config Class Initialized
INFO - 2016-11-29 23:38:09 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:38:09 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:38:09 --> Utf8 Class Initialized
INFO - 2016-11-29 23:38:09 --> URI Class Initialized
INFO - 2016-11-29 23:38:09 --> Router Class Initialized
INFO - 2016-11-29 23:38:09 --> Output Class Initialized
INFO - 2016-11-29 23:38:09 --> Security Class Initialized
DEBUG - 2016-11-29 23:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:38:09 --> Input Class Initialized
INFO - 2016-11-29 23:38:09 --> Language Class Initialized
ERROR - 2016-11-29 23:38:09 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:38:09 --> Config Class Initialized
INFO - 2016-11-29 23:38:09 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:38:09 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:38:09 --> Utf8 Class Initialized
INFO - 2016-11-29 23:38:09 --> URI Class Initialized
INFO - 2016-11-29 23:38:09 --> Router Class Initialized
INFO - 2016-11-29 23:38:09 --> Output Class Initialized
INFO - 2016-11-29 23:38:09 --> Security Class Initialized
DEBUG - 2016-11-29 23:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:38:09 --> Input Class Initialized
INFO - 2016-11-29 23:38:09 --> Language Class Initialized
ERROR - 2016-11-29 23:38:09 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 23:38:09 --> Config Class Initialized
INFO - 2016-11-29 23:38:09 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:38:09 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:38:09 --> Utf8 Class Initialized
INFO - 2016-11-29 23:38:09 --> URI Class Initialized
INFO - 2016-11-29 23:38:09 --> Router Class Initialized
INFO - 2016-11-29 23:38:09 --> Output Class Initialized
INFO - 2016-11-29 23:38:09 --> Security Class Initialized
DEBUG - 2016-11-29 23:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:38:09 --> Input Class Initialized
INFO - 2016-11-29 23:38:09 --> Language Class Initialized
ERROR - 2016-11-29 23:38:09 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 23:38:09 --> Config Class Initialized
INFO - 2016-11-29 23:38:09 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:38:09 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:38:09 --> Utf8 Class Initialized
INFO - 2016-11-29 23:38:09 --> URI Class Initialized
INFO - 2016-11-29 23:38:09 --> Router Class Initialized
INFO - 2016-11-29 23:38:09 --> Output Class Initialized
INFO - 2016-11-29 23:38:09 --> Security Class Initialized
DEBUG - 2016-11-29 23:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:38:09 --> Input Class Initialized
INFO - 2016-11-29 23:38:09 --> Language Class Initialized
INFO - 2016-11-29 23:38:09 --> Loader Class Initialized
INFO - 2016-11-29 23:38:09 --> Database Driver Class Initialized
INFO - 2016-11-29 23:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:38:09 --> Controller Class Initialized
INFO - 2016-11-29 23:38:09 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:38:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:38:09 --> Final output sent to browser
DEBUG - 2016-11-29 23:38:09 --> Total execution time: 0.0140
INFO - 2016-11-29 23:39:00 --> Config Class Initialized
INFO - 2016-11-29 23:39:00 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:39:00 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:39:00 --> Utf8 Class Initialized
INFO - 2016-11-29 23:39:00 --> URI Class Initialized
DEBUG - 2016-11-29 23:39:00 --> No URI present. Default controller set.
INFO - 2016-11-29 23:39:00 --> Router Class Initialized
INFO - 2016-11-29 23:39:00 --> Output Class Initialized
INFO - 2016-11-29 23:39:00 --> Security Class Initialized
DEBUG - 2016-11-29 23:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:39:00 --> Input Class Initialized
INFO - 2016-11-29 23:39:00 --> Language Class Initialized
INFO - 2016-11-29 23:39:00 --> Loader Class Initialized
INFO - 2016-11-29 23:39:00 --> Database Driver Class Initialized
INFO - 2016-11-29 23:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:39:00 --> Controller Class Initialized
INFO - 2016-11-29 23:39:00 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:39:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:39:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:39:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:39:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:39:00 --> Final output sent to browser
DEBUG - 2016-11-29 23:39:00 --> Total execution time: 0.0224
INFO - 2016-11-29 23:39:00 --> Config Class Initialized
INFO - 2016-11-29 23:39:00 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:39:00 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:39:00 --> Utf8 Class Initialized
INFO - 2016-11-29 23:39:00 --> URI Class Initialized
INFO - 2016-11-29 23:39:00 --> Router Class Initialized
INFO - 2016-11-29 23:39:00 --> Output Class Initialized
INFO - 2016-11-29 23:39:00 --> Security Class Initialized
DEBUG - 2016-11-29 23:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:39:00 --> Input Class Initialized
INFO - 2016-11-29 23:39:00 --> Language Class Initialized
ERROR - 2016-11-29 23:39:00 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 23:39:01 --> Config Class Initialized
INFO - 2016-11-29 23:39:01 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:39:01 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:39:01 --> Utf8 Class Initialized
INFO - 2016-11-29 23:39:01 --> URI Class Initialized
INFO - 2016-11-29 23:39:01 --> Router Class Initialized
INFO - 2016-11-29 23:39:01 --> Output Class Initialized
INFO - 2016-11-29 23:39:01 --> Security Class Initialized
DEBUG - 2016-11-29 23:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:39:01 --> Input Class Initialized
INFO - 2016-11-29 23:39:01 --> Language Class Initialized
ERROR - 2016-11-29 23:39:01 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:39:01 --> Config Class Initialized
INFO - 2016-11-29 23:39:01 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:39:01 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:39:01 --> Utf8 Class Initialized
INFO - 2016-11-29 23:39:01 --> URI Class Initialized
INFO - 2016-11-29 23:39:01 --> Router Class Initialized
INFO - 2016-11-29 23:39:01 --> Output Class Initialized
INFO - 2016-11-29 23:39:01 --> Security Class Initialized
DEBUG - 2016-11-29 23:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:39:01 --> Input Class Initialized
INFO - 2016-11-29 23:39:01 --> Language Class Initialized
ERROR - 2016-11-29 23:39:01 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-29 23:39:01 --> Config Class Initialized
INFO - 2016-11-29 23:39:01 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:39:01 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:39:01 --> Utf8 Class Initialized
INFO - 2016-11-29 23:39:01 --> URI Class Initialized
INFO - 2016-11-29 23:39:01 --> Router Class Initialized
INFO - 2016-11-29 23:39:01 --> Output Class Initialized
INFO - 2016-11-29 23:39:01 --> Security Class Initialized
DEBUG - 2016-11-29 23:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:39:01 --> Input Class Initialized
INFO - 2016-11-29 23:39:01 --> Language Class Initialized
ERROR - 2016-11-29 23:39:01 --> 404 Page Not Found: Templates/usuario
INFO - 2016-11-29 23:39:01 --> Config Class Initialized
INFO - 2016-11-29 23:39:01 --> Hooks Class Initialized
DEBUG - 2016-11-29 23:39:01 --> UTF-8 Support Enabled
INFO - 2016-11-29 23:39:01 --> Utf8 Class Initialized
INFO - 2016-11-29 23:39:01 --> URI Class Initialized
INFO - 2016-11-29 23:39:01 --> Router Class Initialized
INFO - 2016-11-29 23:39:01 --> Output Class Initialized
INFO - 2016-11-29 23:39:01 --> Security Class Initialized
DEBUG - 2016-11-29 23:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 23:39:01 --> Input Class Initialized
INFO - 2016-11-29 23:39:01 --> Language Class Initialized
INFO - 2016-11-29 23:39:01 --> Loader Class Initialized
INFO - 2016-11-29 23:39:01 --> Database Driver Class Initialized
INFO - 2016-11-29 23:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 23:39:01 --> Controller Class Initialized
INFO - 2016-11-29 23:39:01 --> Helper loaded: url_helper
DEBUG - 2016-11-29 23:39:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 23:39:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-29 23:39:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-29 23:39:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-29 23:39:01 --> Final output sent to browser
DEBUG - 2016-11-29 23:39:01 --> Total execution time: 0.0682

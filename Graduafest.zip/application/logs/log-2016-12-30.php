<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-30 02:32:29 --> Config Class Initialized
INFO - 2016-12-30 02:32:29 --> Hooks Class Initialized
DEBUG - 2016-12-30 02:32:30 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:32:30 --> Utf8 Class Initialized
INFO - 2016-12-30 02:32:30 --> URI Class Initialized
DEBUG - 2016-12-30 02:32:30 --> No URI present. Default controller set.
INFO - 2016-12-30 02:32:30 --> Router Class Initialized
INFO - 2016-12-30 02:32:30 --> Output Class Initialized
INFO - 2016-12-30 02:32:30 --> Security Class Initialized
DEBUG - 2016-12-30 02:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:32:30 --> Input Class Initialized
INFO - 2016-12-30 02:32:30 --> Language Class Initialized
INFO - 2016-12-30 02:32:30 --> Loader Class Initialized
INFO - 2016-12-30 02:32:30 --> Database Driver Class Initialized
INFO - 2016-12-30 02:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 02:32:30 --> Controller Class Initialized
INFO - 2016-12-30 02:32:30 --> Helper loaded: url_helper
DEBUG - 2016-12-30 02:32:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-30 02:32:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-30 02:32:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-30 02:32:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-30 02:32:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-30 02:32:31 --> Final output sent to browser
DEBUG - 2016-12-30 02:32:31 --> Total execution time: 1.3677
INFO - 2016-12-30 02:32:34 --> Config Class Initialized
INFO - 2016-12-30 02:32:34 --> Hooks Class Initialized
INFO - 2016-12-30 02:32:34 --> Config Class Initialized
INFO - 2016-12-30 02:32:34 --> Hooks Class Initialized
DEBUG - 2016-12-30 02:32:34 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:32:34 --> Utf8 Class Initialized
INFO - 2016-12-30 02:32:34 --> URI Class Initialized
DEBUG - 2016-12-30 02:32:34 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:32:34 --> Utf8 Class Initialized
INFO - 2016-12-30 02:32:34 --> Router Class Initialized
INFO - 2016-12-30 02:32:34 --> URI Class Initialized
INFO - 2016-12-30 02:32:34 --> Output Class Initialized
INFO - 2016-12-30 02:32:34 --> Security Class Initialized
DEBUG - 2016-12-30 02:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:32:34 --> Input Class Initialized
INFO - 2016-12-30 02:32:34 --> Config Class Initialized
INFO - 2016-12-30 02:32:34 --> Hooks Class Initialized
DEBUG - 2016-12-30 02:32:34 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:32:34 --> Utf8 Class Initialized
INFO - 2016-12-30 02:32:34 --> URI Class Initialized
INFO - 2016-12-30 02:32:34 --> Router Class Initialized
INFO - 2016-12-30 02:32:34 --> Output Class Initialized
INFO - 2016-12-30 02:32:34 --> Security Class Initialized
DEBUG - 2016-12-30 02:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:32:34 --> Input Class Initialized
INFO - 2016-12-30 02:32:34 --> Language Class Initialized
INFO - 2016-12-30 02:32:34 --> Config Class Initialized
INFO - 2016-12-30 02:32:34 --> Hooks Class Initialized
DEBUG - 2016-12-30 02:32:34 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:32:34 --> Utf8 Class Initialized
INFO - 2016-12-30 02:32:34 --> URI Class Initialized
INFO - 2016-12-30 02:32:34 --> Router Class Initialized
INFO - 2016-12-30 02:32:34 --> Output Class Initialized
INFO - 2016-12-30 02:32:34 --> Security Class Initialized
DEBUG - 2016-12-30 02:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:32:34 --> Input Class Initialized
ERROR - 2016-12-30 02:32:34 --> 404 Page Not Found: Imagenes_portada/Galeria6.jpg
INFO - 2016-12-30 02:32:34 --> Config Class Initialized
INFO - 2016-12-30 02:32:34 --> Hooks Class Initialized
DEBUG - 2016-12-30 02:32:34 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:32:34 --> Utf8 Class Initialized
INFO - 2016-12-30 02:32:34 --> URI Class Initialized
INFO - 2016-12-30 02:32:34 --> Router Class Initialized
INFO - 2016-12-30 02:32:34 --> Output Class Initialized
INFO - 2016-12-30 02:32:34 --> Security Class Initialized
DEBUG - 2016-12-30 02:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:32:34 --> Input Class Initialized
INFO - 2016-12-30 02:32:34 --> Language Class Initialized
ERROR - 2016-12-30 02:32:34 --> 404 Page Not Found: Imagenes_portada/Galeria5.jpg
INFO - 2016-12-30 02:32:34 --> Router Class Initialized
INFO - 2016-12-30 02:32:34 --> Output Class Initialized
INFO - 2016-12-30 02:32:34 --> Security Class Initialized
DEBUG - 2016-12-30 02:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:32:34 --> Input Class Initialized
INFO - 2016-12-30 02:32:34 --> Language Class Initialized
ERROR - 2016-12-30 02:32:34 --> 404 Page Not Found: Imagenes_portada/Galeria3.jpg
INFO - 2016-12-30 02:32:34 --> Language Class Initialized
ERROR - 2016-12-30 02:32:34 --> 404 Page Not Found: Imagenes_portada/Galeria2.jpg
INFO - 2016-12-30 02:32:34 --> Language Class Initialized
ERROR - 2016-12-30 02:32:34 --> 404 Page Not Found: Imagenes_portada/Galeria4.jpg
INFO - 2016-12-30 02:32:40 --> Config Class Initialized
INFO - 2016-12-30 02:32:40 --> Hooks Class Initialized
INFO - 2016-12-30 02:32:40 --> Config Class Initialized
INFO - 2016-12-30 02:32:40 --> Hooks Class Initialized
DEBUG - 2016-12-30 02:32:40 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:32:40 --> Utf8 Class Initialized
DEBUG - 2016-12-30 02:32:40 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:32:40 --> Utf8 Class Initialized
INFO - 2016-12-30 02:32:40 --> URI Class Initialized
INFO - 2016-12-30 02:32:40 --> URI Class Initialized
INFO - 2016-12-30 02:32:40 --> Config Class Initialized
INFO - 2016-12-30 02:32:40 --> Router Class Initialized
INFO - 2016-12-30 02:32:40 --> Hooks Class Initialized
DEBUG - 2016-12-30 02:32:40 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:32:40 --> Utf8 Class Initialized
INFO - 2016-12-30 02:32:40 --> Output Class Initialized
INFO - 2016-12-30 02:32:40 --> URI Class Initialized
INFO - 2016-12-30 02:32:40 --> Security Class Initialized
INFO - 2016-12-30 02:32:40 --> Router Class Initialized
INFO - 2016-12-30 02:32:40 --> Router Class Initialized
INFO - 2016-12-30 02:32:40 --> Output Class Initialized
INFO - 2016-12-30 02:32:40 --> Security Class Initialized
DEBUG - 2016-12-30 02:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:32:40 --> Input Class Initialized
INFO - 2016-12-30 02:32:40 --> Language Class Initialized
ERROR - 2016-12-30 02:32:40 --> 404 Page Not Found: Imagenes_portada/Galeria5.jpg
INFO - 2016-12-30 02:32:40 --> Output Class Initialized
INFO - 2016-12-30 02:32:40 --> Security Class Initialized
DEBUG - 2016-12-30 02:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:32:40 --> Input Class Initialized
INFO - 2016-12-30 02:32:40 --> Language Class Initialized
ERROR - 2016-12-30 02:32:40 --> 404 Page Not Found: Imagenes_portada/Galeria2.jpg
INFO - 2016-12-30 02:32:40 --> Config Class Initialized
INFO - 2016-12-30 02:32:40 --> Hooks Class Initialized
DEBUG - 2016-12-30 02:32:40 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:32:40 --> Utf8 Class Initialized
INFO - 2016-12-30 02:32:40 --> URI Class Initialized
INFO - 2016-12-30 02:32:40 --> Router Class Initialized
INFO - 2016-12-30 02:32:40 --> Output Class Initialized
INFO - 2016-12-30 02:32:40 --> Security Class Initialized
DEBUG - 2016-12-30 02:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:32:40 --> Input Class Initialized
INFO - 2016-12-30 02:32:40 --> Language Class Initialized
ERROR - 2016-12-30 02:32:40 --> 404 Page Not Found: Imagenes_portada/Galeria6.jpg
DEBUG - 2016-12-30 02:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:32:40 --> Input Class Initialized
INFO - 2016-12-30 02:32:40 --> Language Class Initialized
ERROR - 2016-12-30 02:32:40 --> 404 Page Not Found: Imagenes_portada/Galeria4.jpg
INFO - 2016-12-30 02:32:40 --> Config Class Initialized
INFO - 2016-12-30 02:32:40 --> Hooks Class Initialized
DEBUG - 2016-12-30 02:32:40 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:32:40 --> Utf8 Class Initialized
INFO - 2016-12-30 02:32:40 --> URI Class Initialized
INFO - 2016-12-30 02:32:40 --> Router Class Initialized
INFO - 2016-12-30 02:32:40 --> Output Class Initialized
INFO - 2016-12-30 02:32:40 --> Security Class Initialized
DEBUG - 2016-12-30 02:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:32:40 --> Input Class Initialized
INFO - 2016-12-30 02:32:40 --> Language Class Initialized
ERROR - 2016-12-30 02:32:40 --> 404 Page Not Found: Imagenes_portada/Galeria3.jpg
INFO - 2016-12-30 02:32:40 --> Config Class Initialized
INFO - 2016-12-30 02:32:40 --> Hooks Class Initialized
DEBUG - 2016-12-30 02:32:40 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:32:40 --> Utf8 Class Initialized
INFO - 2016-12-30 02:32:40 --> URI Class Initialized
INFO - 2016-12-30 02:32:40 --> Router Class Initialized
INFO - 2016-12-30 02:32:40 --> Output Class Initialized
INFO - 2016-12-30 02:32:40 --> Security Class Initialized
DEBUG - 2016-12-30 02:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:32:40 --> Input Class Initialized
INFO - 2016-12-30 02:32:40 --> Language Class Initialized
INFO - 2016-12-30 02:32:40 --> Loader Class Initialized
INFO - 2016-12-30 02:32:41 --> Database Driver Class Initialized
INFO - 2016-12-30 02:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 02:32:41 --> Controller Class Initialized
INFO - 2016-12-30 02:32:41 --> Helper loaded: url_helper
DEBUG - 2016-12-30 02:32:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-30 02:32:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-30 02:32:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-30 02:32:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-30 02:32:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-30 02:32:41 --> Final output sent to browser
DEBUG - 2016-12-30 02:32:41 --> Total execution time: 0.7028
INFO - 2016-12-30 02:33:43 --> Config Class Initialized
INFO - 2016-12-30 02:33:43 --> Hooks Class Initialized
DEBUG - 2016-12-30 02:33:43 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:33:43 --> Utf8 Class Initialized
INFO - 2016-12-30 02:33:43 --> URI Class Initialized
DEBUG - 2016-12-30 02:33:43 --> No URI present. Default controller set.
INFO - 2016-12-30 02:33:43 --> Router Class Initialized
INFO - 2016-12-30 02:33:43 --> Output Class Initialized
INFO - 2016-12-30 02:33:43 --> Security Class Initialized
DEBUG - 2016-12-30 02:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:33:43 --> Input Class Initialized
INFO - 2016-12-30 02:33:43 --> Language Class Initialized
INFO - 2016-12-30 02:33:43 --> Loader Class Initialized
INFO - 2016-12-30 02:33:44 --> Database Driver Class Initialized
INFO - 2016-12-30 02:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 02:33:44 --> Controller Class Initialized
INFO - 2016-12-30 02:33:44 --> Helper loaded: url_helper
DEBUG - 2016-12-30 02:33:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-30 02:33:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-30 02:33:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-30 02:33:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-30 02:33:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-30 02:33:44 --> Final output sent to browser
DEBUG - 2016-12-30 02:33:44 --> Total execution time: 1.1107
INFO - 2016-12-30 02:33:46 --> Config Class Initialized
INFO - 2016-12-30 02:33:46 --> Hooks Class Initialized
DEBUG - 2016-12-30 02:33:46 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:33:46 --> Utf8 Class Initialized
INFO - 2016-12-30 02:33:46 --> URI Class Initialized
INFO - 2016-12-30 02:33:46 --> Router Class Initialized
INFO - 2016-12-30 02:33:46 --> Output Class Initialized
INFO - 2016-12-30 02:33:46 --> Security Class Initialized
DEBUG - 2016-12-30 02:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:33:46 --> Input Class Initialized
INFO - 2016-12-30 02:33:46 --> Language Class Initialized
INFO - 2016-12-30 02:33:46 --> Config Class Initialized
INFO - 2016-12-30 02:33:46 --> Hooks Class Initialized
DEBUG - 2016-12-30 02:33:46 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:33:46 --> Utf8 Class Initialized
INFO - 2016-12-30 02:33:46 --> URI Class Initialized
INFO - 2016-12-30 02:33:46 --> Router Class Initialized
INFO - 2016-12-30 02:33:46 --> Output Class Initialized
INFO - 2016-12-30 02:33:46 --> Security Class Initialized
DEBUG - 2016-12-30 02:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:33:46 --> Input Class Initialized
INFO - 2016-12-30 02:33:46 --> Language Class Initialized
ERROR - 2016-12-30 02:33:46 --> 404 Page Not Found: Imagenes_portada/Galeria5.jpg
INFO - 2016-12-30 02:33:46 --> Config Class Initialized
INFO - 2016-12-30 02:33:46 --> Hooks Class Initialized
DEBUG - 2016-12-30 02:33:46 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:33:46 --> Utf8 Class Initialized
INFO - 2016-12-30 02:33:46 --> URI Class Initialized
INFO - 2016-12-30 02:33:46 --> Router Class Initialized
INFO - 2016-12-30 02:33:46 --> Output Class Initialized
INFO - 2016-12-30 02:33:46 --> Security Class Initialized
DEBUG - 2016-12-30 02:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:33:46 --> Input Class Initialized
INFO - 2016-12-30 02:33:46 --> Language Class Initialized
ERROR - 2016-12-30 02:33:46 --> 404 Page Not Found: Imagenes_portada/Galeria2.jpg
INFO - 2016-12-30 02:33:46 --> Config Class Initialized
INFO - 2016-12-30 02:33:46 --> Hooks Class Initialized
DEBUG - 2016-12-30 02:33:46 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:33:46 --> Utf8 Class Initialized
INFO - 2016-12-30 02:33:46 --> URI Class Initialized
INFO - 2016-12-30 02:33:46 --> Router Class Initialized
INFO - 2016-12-30 02:33:46 --> Output Class Initialized
INFO - 2016-12-30 02:33:46 --> Security Class Initialized
INFO - 2016-12-30 02:33:46 --> Config Class Initialized
INFO - 2016-12-30 02:33:46 --> Hooks Class Initialized
DEBUG - 2016-12-30 02:33:46 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:33:46 --> Utf8 Class Initialized
INFO - 2016-12-30 02:33:46 --> URI Class Initialized
INFO - 2016-12-30 02:33:46 --> Router Class Initialized
INFO - 2016-12-30 02:33:46 --> Output Class Initialized
INFO - 2016-12-30 02:33:46 --> Security Class Initialized
DEBUG - 2016-12-30 02:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:33:46 --> Input Class Initialized
INFO - 2016-12-30 02:33:46 --> Language Class Initialized
ERROR - 2016-12-30 02:33:46 --> 404 Page Not Found: Imagenes_portada/Galeria4.jpg
DEBUG - 2016-12-30 02:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:33:46 --> Input Class Initialized
INFO - 2016-12-30 02:33:46 --> Language Class Initialized
ERROR - 2016-12-30 02:33:46 --> 404 Page Not Found: Imagenes_portada/Galeria3.jpg
ERROR - 2016-12-30 02:33:46 --> 404 Page Not Found: Imagenes_portada/Galeria6.jpg
INFO - 2016-12-30 02:36:20 --> Config Class Initialized
INFO - 2016-12-30 02:36:20 --> Hooks Class Initialized
DEBUG - 2016-12-30 02:36:20 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:36:20 --> Utf8 Class Initialized
INFO - 2016-12-30 02:36:20 --> URI Class Initialized
DEBUG - 2016-12-30 02:36:20 --> No URI present. Default controller set.
INFO - 2016-12-30 02:36:20 --> Router Class Initialized
INFO - 2016-12-30 02:36:20 --> Output Class Initialized
INFO - 2016-12-30 02:36:20 --> Security Class Initialized
DEBUG - 2016-12-30 02:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:36:20 --> Input Class Initialized
INFO - 2016-12-30 02:36:20 --> Language Class Initialized
INFO - 2016-12-30 02:36:20 --> Loader Class Initialized
INFO - 2016-12-30 02:36:20 --> Database Driver Class Initialized
INFO - 2016-12-30 02:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 02:36:20 --> Controller Class Initialized
INFO - 2016-12-30 02:36:20 --> Helper loaded: url_helper
DEBUG - 2016-12-30 02:36:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-30 02:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-30 02:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-30 02:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-30 02:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-30 02:36:20 --> Final output sent to browser
DEBUG - 2016-12-30 02:36:20 --> Total execution time: 0.0150
INFO - 2016-12-30 02:36:20 --> Config Class Initialized
INFO - 2016-12-30 02:36:20 --> Hooks Class Initialized
DEBUG - 2016-12-30 02:36:20 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:36:20 --> Utf8 Class Initialized
INFO - 2016-12-30 02:36:20 --> URI Class Initialized
INFO - 2016-12-30 02:36:20 --> Router Class Initialized
INFO - 2016-12-30 02:36:20 --> Output Class Initialized
INFO - 2016-12-30 02:36:20 --> Security Class Initialized
DEBUG - 2016-12-30 02:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:36:20 --> Input Class Initialized
INFO - 2016-12-30 02:36:20 --> Language Class Initialized
ERROR - 2016-12-30 02:36:20 --> 404 Page Not Found: Imagenes_portada/Galeria3.jpg
INFO - 2016-12-30 02:36:20 --> Config Class Initialized
INFO - 2016-12-30 02:36:20 --> Hooks Class Initialized
DEBUG - 2016-12-30 02:36:20 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:36:20 --> Utf8 Class Initialized
INFO - 2016-12-30 02:36:20 --> URI Class Initialized
INFO - 2016-12-30 02:36:20 --> Router Class Initialized
INFO - 2016-12-30 02:36:20 --> Output Class Initialized
INFO - 2016-12-30 02:36:20 --> Security Class Initialized
DEBUG - 2016-12-30 02:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:36:20 --> Input Class Initialized
INFO - 2016-12-30 02:36:20 --> Language Class Initialized
ERROR - 2016-12-30 02:36:20 --> 404 Page Not Found: Imagenes_portada/Galeria2.jpg
INFO - 2016-12-30 02:36:21 --> Config Class Initialized
INFO - 2016-12-30 02:36:21 --> Hooks Class Initialized
DEBUG - 2016-12-30 02:36:21 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:36:21 --> Utf8 Class Initialized
INFO - 2016-12-30 02:36:21 --> URI Class Initialized
INFO - 2016-12-30 02:36:21 --> Router Class Initialized
INFO - 2016-12-30 02:36:21 --> Output Class Initialized
INFO - 2016-12-30 02:36:21 --> Security Class Initialized
DEBUG - 2016-12-30 02:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:36:21 --> Input Class Initialized
INFO - 2016-12-30 02:36:21 --> Language Class Initialized
ERROR - 2016-12-30 02:36:21 --> 404 Page Not Found: Imagenes_portada/Galeria4.jpg
INFO - 2016-12-30 02:36:21 --> Config Class Initialized
INFO - 2016-12-30 02:36:21 --> Hooks Class Initialized
DEBUG - 2016-12-30 02:36:21 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:36:21 --> Utf8 Class Initialized
INFO - 2016-12-30 02:36:21 --> URI Class Initialized
INFO - 2016-12-30 02:36:21 --> Router Class Initialized
INFO - 2016-12-30 02:36:21 --> Output Class Initialized
INFO - 2016-12-30 02:36:21 --> Config Class Initialized
INFO - 2016-12-30 02:36:21 --> Hooks Class Initialized
DEBUG - 2016-12-30 02:36:21 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:36:21 --> Utf8 Class Initialized
INFO - 2016-12-30 02:36:21 --> URI Class Initialized
INFO - 2016-12-30 02:36:21 --> Router Class Initialized
INFO - 2016-12-30 02:36:21 --> Security Class Initialized
DEBUG - 2016-12-30 02:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:36:21 --> Input Class Initialized
INFO - 2016-12-30 02:36:21 --> Language Class Initialized
ERROR - 2016-12-30 02:36:21 --> 404 Page Not Found: Imagenes_portada/Galeria5.jpg
INFO - 2016-12-30 02:36:21 --> Output Class Initialized
INFO - 2016-12-30 02:36:21 --> Security Class Initialized
DEBUG - 2016-12-30 02:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:36:21 --> Input Class Initialized
INFO - 2016-12-30 02:36:21 --> Language Class Initialized
ERROR - 2016-12-30 02:36:21 --> 404 Page Not Found: Imagenes_portada/Galeria6.jpg
INFO - 2016-12-30 02:36:26 --> Config Class Initialized
INFO - 2016-12-30 02:36:26 --> Hooks Class Initialized
DEBUG - 2016-12-30 02:36:26 --> UTF-8 Support Enabled
INFO - 2016-12-30 02:36:26 --> Utf8 Class Initialized
INFO - 2016-12-30 02:36:26 --> URI Class Initialized
INFO - 2016-12-30 02:36:26 --> Router Class Initialized
INFO - 2016-12-30 02:36:26 --> Output Class Initialized
INFO - 2016-12-30 02:36:26 --> Security Class Initialized
DEBUG - 2016-12-30 02:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 02:36:26 --> Input Class Initialized
INFO - 2016-12-30 02:36:26 --> Language Class Initialized
INFO - 2016-12-30 02:36:26 --> Loader Class Initialized
INFO - 2016-12-30 02:36:26 --> Database Driver Class Initialized
INFO - 2016-12-30 02:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 02:36:26 --> Controller Class Initialized
INFO - 2016-12-30 02:36:26 --> Helper loaded: url_helper
DEBUG - 2016-12-30 02:36:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-30 02:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-30 02:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-30 02:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-30 02:36:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-30 02:36:26 --> Final output sent to browser
DEBUG - 2016-12-30 02:36:26 --> Total execution time: 0.0141
INFO - 2016-12-30 03:41:31 --> Config Class Initialized
INFO - 2016-12-30 03:41:31 --> Hooks Class Initialized
DEBUG - 2016-12-30 03:41:31 --> UTF-8 Support Enabled
INFO - 2016-12-30 03:41:31 --> Utf8 Class Initialized
INFO - 2016-12-30 03:41:31 --> URI Class Initialized
DEBUG - 2016-12-30 03:41:31 --> No URI present. Default controller set.
INFO - 2016-12-30 03:41:31 --> Router Class Initialized
INFO - 2016-12-30 03:41:31 --> Output Class Initialized
INFO - 2016-12-30 03:41:31 --> Security Class Initialized
DEBUG - 2016-12-30 03:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 03:41:31 --> Input Class Initialized
INFO - 2016-12-30 03:41:31 --> Language Class Initialized
INFO - 2016-12-30 03:41:31 --> Loader Class Initialized
INFO - 2016-12-30 03:41:32 --> Database Driver Class Initialized
INFO - 2016-12-30 03:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 03:41:32 --> Controller Class Initialized
INFO - 2016-12-30 03:41:32 --> Helper loaded: url_helper
DEBUG - 2016-12-30 03:41:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-30 03:41:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-30 03:41:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-30 03:41:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-30 03:41:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-30 03:41:32 --> Final output sent to browser
DEBUG - 2016-12-30 03:41:32 --> Total execution time: 1.1628
INFO - 2016-12-30 14:07:24 --> Config Class Initialized
INFO - 2016-12-30 14:07:24 --> Hooks Class Initialized
DEBUG - 2016-12-30 14:07:24 --> UTF-8 Support Enabled
INFO - 2016-12-30 14:07:24 --> Utf8 Class Initialized
INFO - 2016-12-30 14:07:24 --> URI Class Initialized
DEBUG - 2016-12-30 14:07:24 --> No URI present. Default controller set.
INFO - 2016-12-30 14:07:24 --> Router Class Initialized
INFO - 2016-12-30 14:07:25 --> Output Class Initialized
INFO - 2016-12-30 14:07:25 --> Security Class Initialized
DEBUG - 2016-12-30 14:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 14:07:25 --> Input Class Initialized
INFO - 2016-12-30 14:07:25 --> Language Class Initialized
INFO - 2016-12-30 14:07:25 --> Loader Class Initialized
INFO - 2016-12-30 14:07:25 --> Database Driver Class Initialized
INFO - 2016-12-30 14:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 14:07:25 --> Controller Class Initialized
INFO - 2016-12-30 14:07:25 --> Helper loaded: url_helper
DEBUG - 2016-12-30 14:07:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-30 14:07:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-30 14:07:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-30 14:07:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-30 14:07:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-30 14:07:26 --> Final output sent to browser
DEBUG - 2016-12-30 14:07:26 --> Total execution time: 1.6334
INFO - 2016-12-30 17:56:24 --> Config Class Initialized
INFO - 2016-12-30 17:56:25 --> Hooks Class Initialized
DEBUG - 2016-12-30 17:56:25 --> UTF-8 Support Enabled
INFO - 2016-12-30 17:56:25 --> Utf8 Class Initialized
INFO - 2016-12-30 17:56:25 --> URI Class Initialized
DEBUG - 2016-12-30 17:56:25 --> No URI present. Default controller set.
INFO - 2016-12-30 17:56:25 --> Router Class Initialized
INFO - 2016-12-30 17:56:25 --> Output Class Initialized
INFO - 2016-12-30 17:56:25 --> Security Class Initialized
DEBUG - 2016-12-30 17:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 17:56:25 --> Input Class Initialized
INFO - 2016-12-30 17:56:25 --> Language Class Initialized
INFO - 2016-12-30 17:56:25 --> Loader Class Initialized
INFO - 2016-12-30 17:56:25 --> Database Driver Class Initialized
INFO - 2016-12-30 17:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 17:56:26 --> Controller Class Initialized
INFO - 2016-12-30 17:56:26 --> Helper loaded: url_helper
DEBUG - 2016-12-30 17:56:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-30 17:56:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-30 17:56:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-30 17:56:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-30 17:56:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-30 17:56:26 --> Final output sent to browser
DEBUG - 2016-12-30 17:56:26 --> Total execution time: 1.5792
INFO - 2016-12-30 21:04:00 --> Config Class Initialized
INFO - 2016-12-30 21:04:00 --> Hooks Class Initialized
DEBUG - 2016-12-30 21:04:00 --> UTF-8 Support Enabled
INFO - 2016-12-30 21:04:00 --> Utf8 Class Initialized
INFO - 2016-12-30 21:04:00 --> URI Class Initialized
DEBUG - 2016-12-30 21:04:00 --> No URI present. Default controller set.
INFO - 2016-12-30 21:04:00 --> Router Class Initialized
INFO - 2016-12-30 21:04:01 --> Output Class Initialized
INFO - 2016-12-30 21:04:01 --> Security Class Initialized
DEBUG - 2016-12-30 21:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 21:04:01 --> Input Class Initialized
INFO - 2016-12-30 21:04:01 --> Language Class Initialized
INFO - 2016-12-30 21:04:01 --> Loader Class Initialized
INFO - 2016-12-30 21:04:01 --> Database Driver Class Initialized
INFO - 2016-12-30 21:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 21:04:01 --> Controller Class Initialized
INFO - 2016-12-30 21:04:01 --> Helper loaded: url_helper
DEBUG - 2016-12-30 21:04:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-30 21:04:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-30 21:04:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-30 21:04:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-30 21:04:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-30 21:04:02 --> Final output sent to browser
DEBUG - 2016-12-30 21:04:02 --> Total execution time: 1.6348
INFO - 2016-12-30 21:04:02 --> Config Class Initialized
INFO - 2016-12-30 21:04:02 --> Hooks Class Initialized
DEBUG - 2016-12-30 21:04:02 --> UTF-8 Support Enabled
INFO - 2016-12-30 21:04:02 --> Utf8 Class Initialized
INFO - 2016-12-30 21:04:02 --> URI Class Initialized
INFO - 2016-12-30 21:04:02 --> Router Class Initialized
INFO - 2016-12-30 21:04:02 --> Output Class Initialized
INFO - 2016-12-30 21:04:02 --> Security Class Initialized
DEBUG - 2016-12-30 21:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 21:04:02 --> Input Class Initialized
INFO - 2016-12-30 21:04:02 --> Language Class Initialized
INFO - 2016-12-30 21:04:02 --> Loader Class Initialized
INFO - 2016-12-30 21:04:02 --> Database Driver Class Initialized
INFO - 2016-12-30 21:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 21:04:02 --> Controller Class Initialized
INFO - 2016-12-30 21:04:02 --> Helper loaded: url_helper
DEBUG - 2016-12-30 21:04:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-30 21:04:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-30 21:04:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-30 21:04:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-30 21:04:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-30 21:04:02 --> Final output sent to browser
DEBUG - 2016-12-30 21:04:02 --> Total execution time: 0.0135
INFO - 2016-12-30 21:04:02 --> Config Class Initialized
INFO - 2016-12-30 21:04:02 --> Hooks Class Initialized
DEBUG - 2016-12-30 21:04:02 --> UTF-8 Support Enabled
INFO - 2016-12-30 21:04:02 --> Utf8 Class Initialized
INFO - 2016-12-30 21:04:02 --> URI Class Initialized
INFO - 2016-12-30 21:04:02 --> Router Class Initialized
INFO - 2016-12-30 21:04:02 --> Output Class Initialized
INFO - 2016-12-30 21:04:02 --> Security Class Initialized
DEBUG - 2016-12-30 21:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 21:04:02 --> Input Class Initialized
INFO - 2016-12-30 21:04:02 --> Language Class Initialized
INFO - 2016-12-30 21:04:02 --> Loader Class Initialized
INFO - 2016-12-30 21:04:02 --> Database Driver Class Initialized
INFO - 2016-12-30 21:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 21:04:02 --> Controller Class Initialized
INFO - 2016-12-30 21:04:02 --> Helper loaded: url_helper
DEBUG - 2016-12-30 21:04:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-30 21:04:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-30 21:04:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-30 21:04:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-30 21:04:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-30 21:04:02 --> Final output sent to browser
DEBUG - 2016-12-30 21:04:02 --> Total execution time: 0.0135
INFO - 2016-12-30 21:04:03 --> Config Class Initialized
INFO - 2016-12-30 21:04:03 --> Hooks Class Initialized
DEBUG - 2016-12-30 21:04:03 --> UTF-8 Support Enabled
INFO - 2016-12-30 21:04:03 --> Utf8 Class Initialized
INFO - 2016-12-30 21:04:03 --> URI Class Initialized
INFO - 2016-12-30 21:04:03 --> Router Class Initialized
INFO - 2016-12-30 21:04:03 --> Output Class Initialized
INFO - 2016-12-30 21:04:03 --> Security Class Initialized
DEBUG - 2016-12-30 21:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 21:04:03 --> Input Class Initialized
INFO - 2016-12-30 21:04:03 --> Language Class Initialized
INFO - 2016-12-30 21:04:03 --> Loader Class Initialized
INFO - 2016-12-30 21:04:03 --> Database Driver Class Initialized
INFO - 2016-12-30 21:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 21:04:03 --> Controller Class Initialized
INFO - 2016-12-30 21:04:03 --> Helper loaded: url_helper
DEBUG - 2016-12-30 21:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-30 21:04:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-30 21:04:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-30 21:04:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-30 21:04:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-30 21:04:03 --> Final output sent to browser
DEBUG - 2016-12-30 21:04:03 --> Total execution time: 0.0135
INFO - 2016-12-30 21:04:03 --> Config Class Initialized
INFO - 2016-12-30 21:04:03 --> Hooks Class Initialized
DEBUG - 2016-12-30 21:04:03 --> UTF-8 Support Enabled
INFO - 2016-12-30 21:04:03 --> Utf8 Class Initialized
INFO - 2016-12-30 21:04:03 --> URI Class Initialized
INFO - 2016-12-30 21:04:03 --> Router Class Initialized
INFO - 2016-12-30 21:04:03 --> Output Class Initialized
INFO - 2016-12-30 21:04:03 --> Security Class Initialized
DEBUG - 2016-12-30 21:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 21:04:03 --> Input Class Initialized
INFO - 2016-12-30 21:04:03 --> Language Class Initialized
INFO - 2016-12-30 21:04:03 --> Loader Class Initialized
INFO - 2016-12-30 21:04:03 --> Database Driver Class Initialized
INFO - 2016-12-30 21:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 21:04:03 --> Controller Class Initialized
INFO - 2016-12-30 21:04:03 --> Helper loaded: url_helper
DEBUG - 2016-12-30 21:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-30 21:04:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-30 21:04:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-30 21:04:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-30 21:04:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-30 21:04:03 --> Final output sent to browser
DEBUG - 2016-12-30 21:04:03 --> Total execution time: 0.0133
INFO - 2016-12-30 21:04:03 --> Config Class Initialized
INFO - 2016-12-30 21:04:03 --> Hooks Class Initialized
DEBUG - 2016-12-30 21:04:03 --> UTF-8 Support Enabled
INFO - 2016-12-30 21:04:03 --> Utf8 Class Initialized
INFO - 2016-12-30 21:04:03 --> URI Class Initialized
INFO - 2016-12-30 21:04:03 --> Router Class Initialized
INFO - 2016-12-30 21:04:03 --> Output Class Initialized
INFO - 2016-12-30 21:04:03 --> Security Class Initialized
DEBUG - 2016-12-30 21:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 21:04:03 --> Input Class Initialized
INFO - 2016-12-30 21:04:03 --> Language Class Initialized
INFO - 2016-12-30 21:04:03 --> Loader Class Initialized
INFO - 2016-12-30 21:04:03 --> Database Driver Class Initialized
INFO - 2016-12-30 21:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 21:04:03 --> Controller Class Initialized
INFO - 2016-12-30 21:04:03 --> Helper loaded: url_helper
DEBUG - 2016-12-30 21:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-30 21:04:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-30 21:04:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-30 21:04:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-30 21:04:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-30 21:04:03 --> Final output sent to browser
DEBUG - 2016-12-30 21:04:03 --> Total execution time: 0.0134
INFO - 2016-12-30 21:04:04 --> Config Class Initialized
INFO - 2016-12-30 21:04:04 --> Hooks Class Initialized
DEBUG - 2016-12-30 21:04:04 --> UTF-8 Support Enabled
INFO - 2016-12-30 21:04:04 --> Utf8 Class Initialized
INFO - 2016-12-30 21:04:04 --> URI Class Initialized
INFO - 2016-12-30 21:04:04 --> Router Class Initialized
INFO - 2016-12-30 21:04:04 --> Output Class Initialized
INFO - 2016-12-30 21:04:04 --> Security Class Initialized
DEBUG - 2016-12-30 21:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 21:04:04 --> Input Class Initialized
INFO - 2016-12-30 21:04:04 --> Language Class Initialized
INFO - 2016-12-30 21:04:04 --> Loader Class Initialized
INFO - 2016-12-30 21:04:04 --> Database Driver Class Initialized
INFO - 2016-12-30 21:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 21:04:04 --> Controller Class Initialized
INFO - 2016-12-30 21:04:04 --> Helper loaded: url_helper
DEBUG - 2016-12-30 21:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-30 21:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-30 21:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-30 21:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-30 21:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-30 21:04:04 --> Final output sent to browser
DEBUG - 2016-12-30 21:04:04 --> Total execution time: 0.0134
INFO - 2016-12-30 21:04:04 --> Config Class Initialized
INFO - 2016-12-30 21:04:04 --> Hooks Class Initialized
DEBUG - 2016-12-30 21:04:04 --> UTF-8 Support Enabled
INFO - 2016-12-30 21:04:04 --> Utf8 Class Initialized
INFO - 2016-12-30 21:04:04 --> URI Class Initialized
DEBUG - 2016-12-30 21:04:04 --> No URI present. Default controller set.
INFO - 2016-12-30 21:04:04 --> Router Class Initialized
INFO - 2016-12-30 21:04:04 --> Output Class Initialized
INFO - 2016-12-30 21:04:04 --> Security Class Initialized
DEBUG - 2016-12-30 21:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 21:04:04 --> Input Class Initialized
INFO - 2016-12-30 21:04:04 --> Language Class Initialized
INFO - 2016-12-30 21:04:04 --> Loader Class Initialized
INFO - 2016-12-30 21:04:04 --> Database Driver Class Initialized
INFO - 2016-12-30 21:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 21:04:04 --> Controller Class Initialized
INFO - 2016-12-30 21:04:04 --> Helper loaded: url_helper
DEBUG - 2016-12-30 21:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-30 21:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-30 21:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-30 21:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-30 21:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-30 21:04:04 --> Final output sent to browser
DEBUG - 2016-12-30 21:04:04 --> Total execution time: 0.0130
INFO - 2016-12-30 21:04:04 --> Config Class Initialized
INFO - 2016-12-30 21:04:04 --> Hooks Class Initialized
DEBUG - 2016-12-30 21:04:04 --> UTF-8 Support Enabled
INFO - 2016-12-30 21:04:04 --> Utf8 Class Initialized
INFO - 2016-12-30 21:04:04 --> URI Class Initialized
INFO - 2016-12-30 21:04:04 --> Router Class Initialized
INFO - 2016-12-30 21:04:04 --> Output Class Initialized
INFO - 2016-12-30 21:04:04 --> Security Class Initialized
DEBUG - 2016-12-30 21:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 21:04:04 --> Input Class Initialized
INFO - 2016-12-30 21:04:04 --> Language Class Initialized
INFO - 2016-12-30 21:04:04 --> Loader Class Initialized
INFO - 2016-12-30 21:04:04 --> Database Driver Class Initialized
INFO - 2016-12-30 21:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 21:04:04 --> Controller Class Initialized
INFO - 2016-12-30 21:04:04 --> Helper loaded: url_helper
DEBUG - 2016-12-30 21:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-30 21:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-30 21:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-30 21:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-30 21:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-30 21:04:04 --> Final output sent to browser
DEBUG - 2016-12-30 21:04:04 --> Total execution time: 0.0137
INFO - 2016-12-30 21:04:05 --> Config Class Initialized
INFO - 2016-12-30 21:04:05 --> Hooks Class Initialized
DEBUG - 2016-12-30 21:04:05 --> UTF-8 Support Enabled
INFO - 2016-12-30 21:04:05 --> Utf8 Class Initialized
INFO - 2016-12-30 21:04:05 --> URI Class Initialized
INFO - 2016-12-30 21:04:05 --> Router Class Initialized
INFO - 2016-12-30 21:04:05 --> Output Class Initialized
INFO - 2016-12-30 21:04:05 --> Security Class Initialized
DEBUG - 2016-12-30 21:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 21:04:05 --> Input Class Initialized
INFO - 2016-12-30 21:04:05 --> Language Class Initialized
INFO - 2016-12-30 21:04:05 --> Loader Class Initialized
INFO - 2016-12-30 21:04:05 --> Database Driver Class Initialized
INFO - 2016-12-30 21:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 21:04:05 --> Controller Class Initialized
INFO - 2016-12-30 21:04:05 --> Helper loaded: url_helper
DEBUG - 2016-12-30 21:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-30 21:04:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-30 21:04:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-30 21:04:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-30 21:04:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-30 21:04:05 --> Final output sent to browser
DEBUG - 2016-12-30 21:04:05 --> Total execution time: 0.0139
INFO - 2016-12-30 21:04:05 --> Config Class Initialized
INFO - 2016-12-30 21:04:05 --> Hooks Class Initialized
DEBUG - 2016-12-30 21:04:05 --> UTF-8 Support Enabled
INFO - 2016-12-30 21:04:05 --> Utf8 Class Initialized
INFO - 2016-12-30 21:04:05 --> URI Class Initialized
INFO - 2016-12-30 21:04:05 --> Router Class Initialized
INFO - 2016-12-30 21:04:05 --> Output Class Initialized
INFO - 2016-12-30 21:04:05 --> Security Class Initialized
DEBUG - 2016-12-30 21:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 21:04:05 --> Input Class Initialized
INFO - 2016-12-30 21:04:05 --> Language Class Initialized
INFO - 2016-12-30 21:04:05 --> Loader Class Initialized
INFO - 2016-12-30 21:04:05 --> Database Driver Class Initialized
INFO - 2016-12-30 21:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 21:04:05 --> Controller Class Initialized
INFO - 2016-12-30 21:04:05 --> Helper loaded: url_helper
DEBUG - 2016-12-30 21:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-30 21:04:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-30 21:04:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-30 21:04:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-30 21:04:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-30 21:04:05 --> Final output sent to browser
DEBUG - 2016-12-30 21:04:05 --> Total execution time: 0.0132
INFO - 2016-12-30 21:04:05 --> Config Class Initialized
INFO - 2016-12-30 21:04:05 --> Hooks Class Initialized
DEBUG - 2016-12-30 21:04:05 --> UTF-8 Support Enabled
INFO - 2016-12-30 21:04:05 --> Utf8 Class Initialized
INFO - 2016-12-30 21:04:05 --> URI Class Initialized
INFO - 2016-12-30 21:04:05 --> Router Class Initialized
INFO - 2016-12-30 21:04:05 --> Output Class Initialized
INFO - 2016-12-30 21:04:05 --> Security Class Initialized
DEBUG - 2016-12-30 21:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 21:04:05 --> Input Class Initialized
INFO - 2016-12-30 21:04:05 --> Language Class Initialized
INFO - 2016-12-30 21:04:05 --> Loader Class Initialized
INFO - 2016-12-30 21:04:05 --> Database Driver Class Initialized
INFO - 2016-12-30 21:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 21:04:05 --> Controller Class Initialized
INFO - 2016-12-30 21:04:05 --> Helper loaded: url_helper
DEBUG - 2016-12-30 21:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-30 21:04:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-30 21:04:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-30 21:04:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-30 21:04:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-30 21:04:05 --> Final output sent to browser
DEBUG - 2016-12-30 21:04:05 --> Total execution time: 0.0129
INFO - 2016-12-30 21:04:05 --> Config Class Initialized
INFO - 2016-12-30 21:04:05 --> Hooks Class Initialized
DEBUG - 2016-12-30 21:04:05 --> UTF-8 Support Enabled
INFO - 2016-12-30 21:04:05 --> Utf8 Class Initialized
INFO - 2016-12-30 21:04:05 --> URI Class Initialized
INFO - 2016-12-30 21:04:05 --> Router Class Initialized
INFO - 2016-12-30 21:04:05 --> Output Class Initialized
INFO - 2016-12-30 21:04:05 --> Security Class Initialized
DEBUG - 2016-12-30 21:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 21:04:05 --> Input Class Initialized
INFO - 2016-12-30 21:04:05 --> Language Class Initialized
INFO - 2016-12-30 21:04:05 --> Loader Class Initialized
INFO - 2016-12-30 21:04:05 --> Database Driver Class Initialized
INFO - 2016-12-30 21:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 21:04:05 --> Controller Class Initialized
INFO - 2016-12-30 21:04:05 --> Helper loaded: url_helper
DEBUG - 2016-12-30 21:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-30 21:04:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-30 21:04:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-30 21:04:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-30 21:04:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-30 21:04:05 --> Final output sent to browser
DEBUG - 2016-12-30 21:04:05 --> Total execution time: 0.0132
INFO - 2016-12-30 21:04:06 --> Config Class Initialized
INFO - 2016-12-30 21:04:06 --> Hooks Class Initialized
DEBUG - 2016-12-30 21:04:06 --> UTF-8 Support Enabled
INFO - 2016-12-30 21:04:06 --> Utf8 Class Initialized
INFO - 2016-12-30 21:04:06 --> URI Class Initialized
INFO - 2016-12-30 21:04:06 --> Router Class Initialized
INFO - 2016-12-30 21:04:06 --> Output Class Initialized
INFO - 2016-12-30 21:04:06 --> Security Class Initialized
DEBUG - 2016-12-30 21:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 21:04:06 --> Input Class Initialized
INFO - 2016-12-30 21:04:06 --> Language Class Initialized
INFO - 2016-12-30 21:04:06 --> Loader Class Initialized
INFO - 2016-12-30 21:04:06 --> Database Driver Class Initialized
INFO - 2016-12-30 21:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 21:04:06 --> Controller Class Initialized
INFO - 2016-12-30 21:04:06 --> Helper loaded: url_helper
DEBUG - 2016-12-30 21:04:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-30 21:04:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-30 21:04:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-30 21:04:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-30 21:04:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-30 21:04:06 --> Final output sent to browser
DEBUG - 2016-12-30 21:04:06 --> Total execution time: 0.0136

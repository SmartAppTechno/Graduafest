<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-10 03:00:44 --> Config Class Initialized
INFO - 2016-12-10 03:00:44 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:00:44 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:00:44 --> Utf8 Class Initialized
INFO - 2016-12-10 03:00:44 --> URI Class Initialized
INFO - 2016-12-10 03:00:44 --> Router Class Initialized
INFO - 2016-12-10 03:00:44 --> Output Class Initialized
INFO - 2016-12-10 03:00:44 --> Security Class Initialized
DEBUG - 2016-12-10 03:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:00:44 --> Input Class Initialized
INFO - 2016-12-10 03:00:44 --> Language Class Initialized
INFO - 2016-12-10 03:00:44 --> Loader Class Initialized
INFO - 2016-12-10 03:00:44 --> Database Driver Class Initialized
INFO - 2016-12-10 03:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:00:44 --> Controller Class Initialized
DEBUG - 2016-12-10 03:00:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:00:44 --> Helper loaded: url_helper
INFO - 2016-12-10 03:00:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:00:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2016-12-10 03:00:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-10 03:00:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:00:44 --> Final output sent to browser
DEBUG - 2016-12-10 03:00:44 --> Total execution time: 0.7986
INFO - 2016-12-10 03:00:45 --> Config Class Initialized
INFO - 2016-12-10 03:00:45 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:00:45 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:00:45 --> Utf8 Class Initialized
INFO - 2016-12-10 03:00:45 --> URI Class Initialized
INFO - 2016-12-10 03:00:45 --> Router Class Initialized
INFO - 2016-12-10 03:00:45 --> Output Class Initialized
INFO - 2016-12-10 03:00:45 --> Security Class Initialized
DEBUG - 2016-12-10 03:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:00:45 --> Input Class Initialized
INFO - 2016-12-10 03:00:45 --> Language Class Initialized
INFO - 2016-12-10 03:00:45 --> Loader Class Initialized
INFO - 2016-12-10 03:00:45 --> Database Driver Class Initialized
INFO - 2016-12-10 03:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:00:45 --> Controller Class Initialized
INFO - 2016-12-10 03:00:45 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:00:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:00:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:00:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:00:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:00:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:00:45 --> Final output sent to browser
DEBUG - 2016-12-10 03:00:45 --> Total execution time: 0.0205
INFO - 2016-12-10 03:00:50 --> Config Class Initialized
INFO - 2016-12-10 03:00:50 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:00:50 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:00:50 --> Utf8 Class Initialized
INFO - 2016-12-10 03:00:50 --> URI Class Initialized
DEBUG - 2016-12-10 03:00:50 --> No URI present. Default controller set.
INFO - 2016-12-10 03:00:50 --> Router Class Initialized
INFO - 2016-12-10 03:00:50 --> Output Class Initialized
INFO - 2016-12-10 03:00:50 --> Security Class Initialized
DEBUG - 2016-12-10 03:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:00:50 --> Input Class Initialized
INFO - 2016-12-10 03:00:50 --> Language Class Initialized
INFO - 2016-12-10 03:00:50 --> Loader Class Initialized
INFO - 2016-12-10 03:00:50 --> Database Driver Class Initialized
INFO - 2016-12-10 03:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:00:50 --> Controller Class Initialized
INFO - 2016-12-10 03:00:50 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:00:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:00:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:00:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:00:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:00:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:00:50 --> Final output sent to browser
DEBUG - 2016-12-10 03:00:50 --> Total execution time: 0.0151
INFO - 2016-12-10 03:00:56 --> Config Class Initialized
INFO - 2016-12-10 03:00:56 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:00:56 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:00:56 --> Utf8 Class Initialized
INFO - 2016-12-10 03:00:56 --> URI Class Initialized
INFO - 2016-12-10 03:00:56 --> Router Class Initialized
INFO - 2016-12-10 03:00:56 --> Output Class Initialized
INFO - 2016-12-10 03:00:56 --> Security Class Initialized
DEBUG - 2016-12-10 03:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:00:56 --> Input Class Initialized
INFO - 2016-12-10 03:00:56 --> Language Class Initialized
INFO - 2016-12-10 03:00:56 --> Loader Class Initialized
INFO - 2016-12-10 03:00:56 --> Database Driver Class Initialized
INFO - 2016-12-10 03:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:00:56 --> Controller Class Initialized
INFO - 2016-12-10 03:00:56 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:00:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:00:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:00:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:00:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:00:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:00:56 --> Final output sent to browser
DEBUG - 2016-12-10 03:00:56 --> Total execution time: 0.0154
INFO - 2016-12-10 03:02:05 --> Config Class Initialized
INFO - 2016-12-10 03:02:05 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:02:05 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:02:05 --> Utf8 Class Initialized
INFO - 2016-12-10 03:02:05 --> URI Class Initialized
INFO - 2016-12-10 03:02:05 --> Router Class Initialized
INFO - 2016-12-10 03:02:05 --> Output Class Initialized
INFO - 2016-12-10 03:02:05 --> Security Class Initialized
DEBUG - 2016-12-10 03:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:02:05 --> Input Class Initialized
INFO - 2016-12-10 03:02:05 --> Language Class Initialized
INFO - 2016-12-10 03:02:05 --> Loader Class Initialized
INFO - 2016-12-10 03:02:05 --> Database Driver Class Initialized
INFO - 2016-12-10 03:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:02:05 --> Controller Class Initialized
INFO - 2016-12-10 03:02:05 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:02:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:02:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:02:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:02:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:02:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:02:05 --> Final output sent to browser
DEBUG - 2016-12-10 03:02:05 --> Total execution time: 0.0607
INFO - 2016-12-10 03:02:05 --> Config Class Initialized
INFO - 2016-12-10 03:02:05 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:02:05 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:02:05 --> Utf8 Class Initialized
INFO - 2016-12-10 03:02:05 --> URI Class Initialized
INFO - 2016-12-10 03:02:05 --> Router Class Initialized
INFO - 2016-12-10 03:02:05 --> Output Class Initialized
INFO - 2016-12-10 03:02:05 --> Security Class Initialized
DEBUG - 2016-12-10 03:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:02:05 --> Input Class Initialized
INFO - 2016-12-10 03:02:05 --> Language Class Initialized
INFO - 2016-12-10 03:02:05 --> Loader Class Initialized
INFO - 2016-12-10 03:02:05 --> Database Driver Class Initialized
INFO - 2016-12-10 03:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:02:05 --> Controller Class Initialized
INFO - 2016-12-10 03:02:05 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:02:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:02:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:02:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:02:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:02:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:02:05 --> Final output sent to browser
DEBUG - 2016-12-10 03:02:05 --> Total execution time: 0.0139
INFO - 2016-12-10 03:02:19 --> Config Class Initialized
INFO - 2016-12-10 03:02:19 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:02:19 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:02:19 --> Utf8 Class Initialized
INFO - 2016-12-10 03:02:19 --> URI Class Initialized
INFO - 2016-12-10 03:02:19 --> Router Class Initialized
INFO - 2016-12-10 03:02:19 --> Output Class Initialized
INFO - 2016-12-10 03:02:19 --> Security Class Initialized
DEBUG - 2016-12-10 03:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:02:19 --> Input Class Initialized
INFO - 2016-12-10 03:02:19 --> Language Class Initialized
INFO - 2016-12-10 03:02:19 --> Loader Class Initialized
INFO - 2016-12-10 03:02:19 --> Database Driver Class Initialized
INFO - 2016-12-10 03:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:02:19 --> Controller Class Initialized
INFO - 2016-12-10 03:02:19 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:02:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:02:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:02:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:02:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:02:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:02:19 --> Final output sent to browser
DEBUG - 2016-12-10 03:02:19 --> Total execution time: 0.0144
INFO - 2016-12-10 03:02:20 --> Config Class Initialized
INFO - 2016-12-10 03:02:20 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:02:20 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:02:20 --> Utf8 Class Initialized
INFO - 2016-12-10 03:02:20 --> URI Class Initialized
INFO - 2016-12-10 03:02:20 --> Router Class Initialized
INFO - 2016-12-10 03:02:20 --> Output Class Initialized
INFO - 2016-12-10 03:02:20 --> Security Class Initialized
DEBUG - 2016-12-10 03:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:02:20 --> Input Class Initialized
INFO - 2016-12-10 03:02:20 --> Language Class Initialized
INFO - 2016-12-10 03:02:20 --> Loader Class Initialized
INFO - 2016-12-10 03:02:20 --> Database Driver Class Initialized
INFO - 2016-12-10 03:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:02:20 --> Controller Class Initialized
INFO - 2016-12-10 03:02:20 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:02:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:02:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:02:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:02:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:02:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:02:20 --> Final output sent to browser
DEBUG - 2016-12-10 03:02:20 --> Total execution time: 0.0371
INFO - 2016-12-10 03:02:38 --> Config Class Initialized
INFO - 2016-12-10 03:02:38 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:02:38 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:02:38 --> Utf8 Class Initialized
INFO - 2016-12-10 03:02:38 --> URI Class Initialized
INFO - 2016-12-10 03:02:38 --> Router Class Initialized
INFO - 2016-12-10 03:02:38 --> Output Class Initialized
INFO - 2016-12-10 03:02:38 --> Security Class Initialized
DEBUG - 2016-12-10 03:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:02:38 --> Input Class Initialized
INFO - 2016-12-10 03:02:38 --> Language Class Initialized
INFO - 2016-12-10 03:02:38 --> Loader Class Initialized
INFO - 2016-12-10 03:02:38 --> Database Driver Class Initialized
INFO - 2016-12-10 03:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:02:38 --> Controller Class Initialized
INFO - 2016-12-10 03:02:38 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:02:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:02:38 --> Config Class Initialized
INFO - 2016-12-10 03:02:38 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:02:38 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:02:38 --> Utf8 Class Initialized
INFO - 2016-12-10 03:02:38 --> URI Class Initialized
DEBUG - 2016-12-10 03:02:38 --> No URI present. Default controller set.
INFO - 2016-12-10 03:02:38 --> Router Class Initialized
INFO - 2016-12-10 03:02:38 --> Output Class Initialized
INFO - 2016-12-10 03:02:38 --> Security Class Initialized
DEBUG - 2016-12-10 03:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:02:38 --> Input Class Initialized
INFO - 2016-12-10 03:02:38 --> Language Class Initialized
INFO - 2016-12-10 03:02:38 --> Loader Class Initialized
INFO - 2016-12-10 03:02:38 --> Database Driver Class Initialized
INFO - 2016-12-10 03:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:02:38 --> Controller Class Initialized
INFO - 2016-12-10 03:02:38 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:02:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:02:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:02:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:02:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:02:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:02:38 --> Final output sent to browser
DEBUG - 2016-12-10 03:02:38 --> Total execution time: 0.0131
INFO - 2016-12-10 03:02:39 --> Config Class Initialized
INFO - 2016-12-10 03:02:39 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:02:39 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:02:39 --> Utf8 Class Initialized
INFO - 2016-12-10 03:02:39 --> URI Class Initialized
INFO - 2016-12-10 03:02:39 --> Router Class Initialized
INFO - 2016-12-10 03:02:39 --> Output Class Initialized
INFO - 2016-12-10 03:02:39 --> Security Class Initialized
DEBUG - 2016-12-10 03:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:02:39 --> Input Class Initialized
INFO - 2016-12-10 03:02:39 --> Language Class Initialized
INFO - 2016-12-10 03:02:39 --> Loader Class Initialized
INFO - 2016-12-10 03:02:39 --> Database Driver Class Initialized
INFO - 2016-12-10 03:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:02:39 --> Controller Class Initialized
INFO - 2016-12-10 03:02:39 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:02:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:02:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:02:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:02:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:02:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:02:39 --> Final output sent to browser
DEBUG - 2016-12-10 03:02:39 --> Total execution time: 0.0133
INFO - 2016-12-10 03:22:54 --> Config Class Initialized
INFO - 2016-12-10 03:22:54 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:22:54 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:22:54 --> Utf8 Class Initialized
INFO - 2016-12-10 03:22:54 --> URI Class Initialized
DEBUG - 2016-12-10 03:22:54 --> No URI present. Default controller set.
INFO - 2016-12-10 03:22:54 --> Router Class Initialized
INFO - 2016-12-10 03:22:54 --> Output Class Initialized
INFO - 2016-12-10 03:22:54 --> Security Class Initialized
DEBUG - 2016-12-10 03:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:22:54 --> Input Class Initialized
INFO - 2016-12-10 03:22:54 --> Language Class Initialized
INFO - 2016-12-10 03:22:54 --> Loader Class Initialized
INFO - 2016-12-10 03:22:54 --> Database Driver Class Initialized
INFO - 2016-12-10 03:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:22:54 --> Controller Class Initialized
INFO - 2016-12-10 03:22:54 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:22:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:22:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:22:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:22:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:22:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:22:54 --> Final output sent to browser
DEBUG - 2016-12-10 03:22:54 --> Total execution time: 0.0138
INFO - 2016-12-10 03:22:54 --> Config Class Initialized
INFO - 2016-12-10 03:22:54 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:22:54 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:22:54 --> Utf8 Class Initialized
INFO - 2016-12-10 03:22:54 --> URI Class Initialized
INFO - 2016-12-10 03:22:54 --> Router Class Initialized
INFO - 2016-12-10 03:22:54 --> Output Class Initialized
INFO - 2016-12-10 03:22:54 --> Security Class Initialized
DEBUG - 2016-12-10 03:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:22:54 --> Input Class Initialized
INFO - 2016-12-10 03:22:54 --> Language Class Initialized
INFO - 2016-12-10 03:22:54 --> Loader Class Initialized
INFO - 2016-12-10 03:22:54 --> Database Driver Class Initialized
INFO - 2016-12-10 03:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:22:54 --> Controller Class Initialized
INFO - 2016-12-10 03:22:54 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:22:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:22:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:22:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:22:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:22:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:22:54 --> Final output sent to browser
DEBUG - 2016-12-10 03:22:54 --> Total execution time: 0.0138
INFO - 2016-12-10 03:23:01 --> Config Class Initialized
INFO - 2016-12-10 03:23:01 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:23:01 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:23:01 --> Utf8 Class Initialized
INFO - 2016-12-10 03:23:01 --> URI Class Initialized
INFO - 2016-12-10 03:23:01 --> Router Class Initialized
INFO - 2016-12-10 03:23:01 --> Output Class Initialized
INFO - 2016-12-10 03:23:01 --> Security Class Initialized
DEBUG - 2016-12-10 03:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:23:01 --> Input Class Initialized
INFO - 2016-12-10 03:23:01 --> Language Class Initialized
INFO - 2016-12-10 03:23:01 --> Loader Class Initialized
INFO - 2016-12-10 03:23:01 --> Database Driver Class Initialized
INFO - 2016-12-10 03:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:23:01 --> Controller Class Initialized
INFO - 2016-12-10 03:23:01 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:23:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:23:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:23:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:23:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:23:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:23:01 --> Final output sent to browser
DEBUG - 2016-12-10 03:23:01 --> Total execution time: 0.0144
INFO - 2016-12-10 03:23:01 --> Config Class Initialized
INFO - 2016-12-10 03:23:01 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:23:01 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:23:01 --> Utf8 Class Initialized
INFO - 2016-12-10 03:23:01 --> URI Class Initialized
INFO - 2016-12-10 03:23:01 --> Router Class Initialized
INFO - 2016-12-10 03:23:01 --> Output Class Initialized
INFO - 2016-12-10 03:23:01 --> Security Class Initialized
DEBUG - 2016-12-10 03:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:23:01 --> Input Class Initialized
INFO - 2016-12-10 03:23:01 --> Language Class Initialized
INFO - 2016-12-10 03:23:01 --> Loader Class Initialized
INFO - 2016-12-10 03:23:01 --> Database Driver Class Initialized
INFO - 2016-12-10 03:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:23:01 --> Controller Class Initialized
INFO - 2016-12-10 03:23:01 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:23:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:23:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:23:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:23:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:23:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:23:01 --> Final output sent to browser
DEBUG - 2016-12-10 03:23:01 --> Total execution time: 0.0137
INFO - 2016-12-10 03:23:39 --> Config Class Initialized
INFO - 2016-12-10 03:23:39 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:23:39 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:23:39 --> Utf8 Class Initialized
INFO - 2016-12-10 03:23:39 --> URI Class Initialized
INFO - 2016-12-10 03:23:39 --> Router Class Initialized
INFO - 2016-12-10 03:23:39 --> Output Class Initialized
INFO - 2016-12-10 03:23:39 --> Security Class Initialized
DEBUG - 2016-12-10 03:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:23:39 --> Input Class Initialized
INFO - 2016-12-10 03:23:39 --> Language Class Initialized
INFO - 2016-12-10 03:23:39 --> Loader Class Initialized
INFO - 2016-12-10 03:23:39 --> Database Driver Class Initialized
INFO - 2016-12-10 03:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:23:39 --> Controller Class Initialized
INFO - 2016-12-10 03:23:39 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:23:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:23:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:23:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:23:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:23:39 --> Final output sent to browser
DEBUG - 2016-12-10 03:23:39 --> Total execution time: 0.0212
INFO - 2016-12-10 03:23:39 --> Config Class Initialized
INFO - 2016-12-10 03:23:39 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:23:39 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:23:39 --> Utf8 Class Initialized
INFO - 2016-12-10 03:23:39 --> URI Class Initialized
INFO - 2016-12-10 03:23:39 --> Router Class Initialized
INFO - 2016-12-10 03:23:39 --> Output Class Initialized
INFO - 2016-12-10 03:23:39 --> Security Class Initialized
DEBUG - 2016-12-10 03:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:23:39 --> Input Class Initialized
INFO - 2016-12-10 03:23:39 --> Language Class Initialized
INFO - 2016-12-10 03:23:39 --> Loader Class Initialized
INFO - 2016-12-10 03:23:39 --> Database Driver Class Initialized
INFO - 2016-12-10 03:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:23:39 --> Controller Class Initialized
INFO - 2016-12-10 03:23:39 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:23:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:23:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:23:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:23:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:23:39 --> Final output sent to browser
DEBUG - 2016-12-10 03:23:39 --> Total execution time: 0.0135
INFO - 2016-12-10 03:24:15 --> Config Class Initialized
INFO - 2016-12-10 03:24:15 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:24:15 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:24:15 --> Utf8 Class Initialized
INFO - 2016-12-10 03:24:15 --> URI Class Initialized
INFO - 2016-12-10 03:24:15 --> Router Class Initialized
INFO - 2016-12-10 03:24:15 --> Output Class Initialized
INFO - 2016-12-10 03:24:15 --> Security Class Initialized
DEBUG - 2016-12-10 03:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:24:15 --> Input Class Initialized
INFO - 2016-12-10 03:24:15 --> Language Class Initialized
INFO - 2016-12-10 03:24:15 --> Loader Class Initialized
INFO - 2016-12-10 03:24:15 --> Database Driver Class Initialized
INFO - 2016-12-10 03:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:24:15 --> Controller Class Initialized
INFO - 2016-12-10 03:24:15 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:24:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:24:15 --> Config Class Initialized
INFO - 2016-12-10 03:24:15 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:24:15 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:24:15 --> Utf8 Class Initialized
INFO - 2016-12-10 03:24:15 --> URI Class Initialized
INFO - 2016-12-10 03:24:15 --> Router Class Initialized
INFO - 2016-12-10 03:24:15 --> Output Class Initialized
INFO - 2016-12-10 03:24:15 --> Security Class Initialized
DEBUG - 2016-12-10 03:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:24:15 --> Input Class Initialized
INFO - 2016-12-10 03:24:15 --> Language Class Initialized
INFO - 2016-12-10 03:24:15 --> Loader Class Initialized
INFO - 2016-12-10 03:24:15 --> Database Driver Class Initialized
INFO - 2016-12-10 03:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:24:15 --> Controller Class Initialized
DEBUG - 2016-12-10 03:24:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:24:15 --> Helper loaded: url_helper
INFO - 2016-12-10 03:24:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:24:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2016-12-10 03:24:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-10 03:24:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:24:15 --> Final output sent to browser
DEBUG - 2016-12-10 03:24:15 --> Total execution time: 0.0121
INFO - 2016-12-10 03:24:15 --> Config Class Initialized
INFO - 2016-12-10 03:24:15 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:24:15 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:24:15 --> Utf8 Class Initialized
INFO - 2016-12-10 03:24:15 --> URI Class Initialized
INFO - 2016-12-10 03:24:15 --> Router Class Initialized
INFO - 2016-12-10 03:24:15 --> Output Class Initialized
INFO - 2016-12-10 03:24:15 --> Security Class Initialized
DEBUG - 2016-12-10 03:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:24:15 --> Input Class Initialized
INFO - 2016-12-10 03:24:15 --> Language Class Initialized
INFO - 2016-12-10 03:24:15 --> Loader Class Initialized
INFO - 2016-12-10 03:24:15 --> Database Driver Class Initialized
INFO - 2016-12-10 03:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:24:15 --> Controller Class Initialized
INFO - 2016-12-10 03:24:15 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:24:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:24:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:24:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:24:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:24:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:24:15 --> Final output sent to browser
DEBUG - 2016-12-10 03:24:15 --> Total execution time: 0.0529
INFO - 2016-12-10 03:24:40 --> Config Class Initialized
INFO - 2016-12-10 03:24:40 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:24:40 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:24:40 --> Utf8 Class Initialized
INFO - 2016-12-10 03:24:40 --> URI Class Initialized
DEBUG - 2016-12-10 03:24:40 --> No URI present. Default controller set.
INFO - 2016-12-10 03:24:40 --> Router Class Initialized
INFO - 2016-12-10 03:24:40 --> Output Class Initialized
INFO - 2016-12-10 03:24:40 --> Security Class Initialized
DEBUG - 2016-12-10 03:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:24:40 --> Input Class Initialized
INFO - 2016-12-10 03:24:40 --> Language Class Initialized
INFO - 2016-12-10 03:24:40 --> Loader Class Initialized
INFO - 2016-12-10 03:24:40 --> Database Driver Class Initialized
INFO - 2016-12-10 03:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:24:40 --> Controller Class Initialized
INFO - 2016-12-10 03:24:40 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:24:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:24:40 --> Final output sent to browser
DEBUG - 2016-12-10 03:24:40 --> Total execution time: 0.0135
INFO - 2016-12-10 03:24:41 --> Config Class Initialized
INFO - 2016-12-10 03:24:41 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:24:41 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:24:41 --> Utf8 Class Initialized
INFO - 2016-12-10 03:24:41 --> URI Class Initialized
INFO - 2016-12-10 03:24:41 --> Router Class Initialized
INFO - 2016-12-10 03:24:41 --> Output Class Initialized
INFO - 2016-12-10 03:24:41 --> Security Class Initialized
DEBUG - 2016-12-10 03:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:24:41 --> Input Class Initialized
INFO - 2016-12-10 03:24:41 --> Language Class Initialized
INFO - 2016-12-10 03:24:41 --> Loader Class Initialized
INFO - 2016-12-10 03:24:41 --> Database Driver Class Initialized
INFO - 2016-12-10 03:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:24:41 --> Controller Class Initialized
INFO - 2016-12-10 03:24:41 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:24:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:24:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:24:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:24:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:24:41 --> Final output sent to browser
DEBUG - 2016-12-10 03:24:41 --> Total execution time: 0.0136
INFO - 2016-12-10 03:26:01 --> Config Class Initialized
INFO - 2016-12-10 03:26:01 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:26:01 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:26:01 --> Utf8 Class Initialized
INFO - 2016-12-10 03:26:01 --> URI Class Initialized
INFO - 2016-12-10 03:26:01 --> Router Class Initialized
INFO - 2016-12-10 03:26:01 --> Output Class Initialized
INFO - 2016-12-10 03:26:01 --> Security Class Initialized
DEBUG - 2016-12-10 03:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:26:01 --> Input Class Initialized
INFO - 2016-12-10 03:26:01 --> Language Class Initialized
INFO - 2016-12-10 03:26:01 --> Loader Class Initialized
INFO - 2016-12-10 03:26:01 --> Database Driver Class Initialized
INFO - 2016-12-10 03:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:26:01 --> Controller Class Initialized
INFO - 2016-12-10 03:26:01 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:26:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:26:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:26:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:26:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:26:01 --> Final output sent to browser
DEBUG - 2016-12-10 03:26:01 --> Total execution time: 0.0148
INFO - 2016-12-10 03:26:02 --> Config Class Initialized
INFO - 2016-12-10 03:26:02 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:26:02 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:26:02 --> Utf8 Class Initialized
INFO - 2016-12-10 03:26:02 --> URI Class Initialized
INFO - 2016-12-10 03:26:02 --> Router Class Initialized
INFO - 2016-12-10 03:26:02 --> Output Class Initialized
INFO - 2016-12-10 03:26:02 --> Security Class Initialized
DEBUG - 2016-12-10 03:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:26:02 --> Input Class Initialized
INFO - 2016-12-10 03:26:02 --> Language Class Initialized
INFO - 2016-12-10 03:26:02 --> Loader Class Initialized
INFO - 2016-12-10 03:26:02 --> Database Driver Class Initialized
INFO - 2016-12-10 03:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:26:02 --> Controller Class Initialized
INFO - 2016-12-10 03:26:02 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:26:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:26:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:26:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:26:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:26:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:26:02 --> Final output sent to browser
DEBUG - 2016-12-10 03:26:02 --> Total execution time: 0.0193
INFO - 2016-12-10 03:26:20 --> Config Class Initialized
INFO - 2016-12-10 03:26:20 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:26:20 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:26:20 --> Utf8 Class Initialized
INFO - 2016-12-10 03:26:20 --> URI Class Initialized
INFO - 2016-12-10 03:26:20 --> Router Class Initialized
INFO - 2016-12-10 03:26:20 --> Output Class Initialized
INFO - 2016-12-10 03:26:20 --> Security Class Initialized
DEBUG - 2016-12-10 03:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:26:20 --> Input Class Initialized
INFO - 2016-12-10 03:26:20 --> Language Class Initialized
INFO - 2016-12-10 03:26:20 --> Loader Class Initialized
INFO - 2016-12-10 03:26:20 --> Database Driver Class Initialized
INFO - 2016-12-10 03:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:26:20 --> Controller Class Initialized
INFO - 2016-12-10 03:26:20 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:26:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:26:20 --> Config Class Initialized
INFO - 2016-12-10 03:26:20 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:26:20 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:26:20 --> Utf8 Class Initialized
INFO - 2016-12-10 03:26:20 --> URI Class Initialized
INFO - 2016-12-10 03:26:20 --> Router Class Initialized
INFO - 2016-12-10 03:26:20 --> Output Class Initialized
INFO - 2016-12-10 03:26:20 --> Security Class Initialized
DEBUG - 2016-12-10 03:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:26:20 --> Input Class Initialized
INFO - 2016-12-10 03:26:20 --> Language Class Initialized
INFO - 2016-12-10 03:26:20 --> Loader Class Initialized
INFO - 2016-12-10 03:26:20 --> Database Driver Class Initialized
INFO - 2016-12-10 03:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:26:20 --> Controller Class Initialized
DEBUG - 2016-12-10 03:26:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:26:20 --> Helper loaded: url_helper
INFO - 2016-12-10 03:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 03:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-10 03:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-10 03:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:26:20 --> Final output sent to browser
DEBUG - 2016-12-10 03:26:20 --> Total execution time: 0.0878
INFO - 2016-12-10 03:26:23 --> Config Class Initialized
INFO - 2016-12-10 03:26:23 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:26:23 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:26:23 --> Utf8 Class Initialized
INFO - 2016-12-10 03:26:23 --> URI Class Initialized
INFO - 2016-12-10 03:26:23 --> Router Class Initialized
INFO - 2016-12-10 03:26:23 --> Output Class Initialized
INFO - 2016-12-10 03:26:23 --> Security Class Initialized
DEBUG - 2016-12-10 03:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:26:23 --> Input Class Initialized
INFO - 2016-12-10 03:26:23 --> Language Class Initialized
INFO - 2016-12-10 03:26:23 --> Loader Class Initialized
INFO - 2016-12-10 03:26:23 --> Database Driver Class Initialized
INFO - 2016-12-10 03:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:26:23 --> Controller Class Initialized
INFO - 2016-12-10 03:26:23 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:26:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:26:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:26:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:26:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:26:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:26:23 --> Final output sent to browser
DEBUG - 2016-12-10 03:26:23 --> Total execution time: 0.0140
INFO - 2016-12-10 03:26:37 --> Config Class Initialized
INFO - 2016-12-10 03:26:37 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:26:37 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:26:37 --> Utf8 Class Initialized
INFO - 2016-12-10 03:26:37 --> URI Class Initialized
INFO - 2016-12-10 03:26:37 --> Router Class Initialized
INFO - 2016-12-10 03:26:37 --> Output Class Initialized
INFO - 2016-12-10 03:26:37 --> Security Class Initialized
DEBUG - 2016-12-10 03:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:26:37 --> Input Class Initialized
INFO - 2016-12-10 03:26:37 --> Language Class Initialized
INFO - 2016-12-10 03:26:37 --> Loader Class Initialized
INFO - 2016-12-10 03:26:37 --> Database Driver Class Initialized
INFO - 2016-12-10 03:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:26:37 --> Controller Class Initialized
INFO - 2016-12-10 03:26:37 --> Helper loaded: date_helper
DEBUG - 2016-12-10 03:26:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:26:37 --> Helper loaded: url_helper
INFO - 2016-12-10 03:26:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:26:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 03:26:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-10 03:26:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-10 03:26:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:26:37 --> Final output sent to browser
DEBUG - 2016-12-10 03:26:37 --> Total execution time: 0.1943
INFO - 2016-12-10 03:26:38 --> Config Class Initialized
INFO - 2016-12-10 03:26:38 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:26:38 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:26:38 --> Utf8 Class Initialized
INFO - 2016-12-10 03:26:38 --> URI Class Initialized
INFO - 2016-12-10 03:26:38 --> Router Class Initialized
INFO - 2016-12-10 03:26:38 --> Output Class Initialized
INFO - 2016-12-10 03:26:38 --> Security Class Initialized
DEBUG - 2016-12-10 03:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:26:38 --> Input Class Initialized
INFO - 2016-12-10 03:26:38 --> Language Class Initialized
INFO - 2016-12-10 03:26:38 --> Loader Class Initialized
INFO - 2016-12-10 03:26:38 --> Database Driver Class Initialized
INFO - 2016-12-10 03:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:26:38 --> Controller Class Initialized
INFO - 2016-12-10 03:26:38 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:26:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:26:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:26:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:26:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:26:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:26:38 --> Final output sent to browser
DEBUG - 2016-12-10 03:26:38 --> Total execution time: 0.0132
INFO - 2016-12-10 03:26:41 --> Config Class Initialized
INFO - 2016-12-10 03:26:41 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:26:41 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:26:41 --> Utf8 Class Initialized
INFO - 2016-12-10 03:26:41 --> URI Class Initialized
INFO - 2016-12-10 03:26:41 --> Router Class Initialized
INFO - 2016-12-10 03:26:41 --> Output Class Initialized
INFO - 2016-12-10 03:26:41 --> Security Class Initialized
DEBUG - 2016-12-10 03:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:26:41 --> Input Class Initialized
INFO - 2016-12-10 03:26:41 --> Language Class Initialized
INFO - 2016-12-10 03:26:41 --> Loader Class Initialized
INFO - 2016-12-10 03:26:41 --> Database Driver Class Initialized
INFO - 2016-12-10 03:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:26:41 --> Controller Class Initialized
DEBUG - 2016-12-10 03:26:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:26:41 --> Helper loaded: url_helper
INFO - 2016-12-10 03:26:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:26:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-10 03:26:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 03:26:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-10 03:26:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-10 03:26:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:26:41 --> Final output sent to browser
DEBUG - 2016-12-10 03:26:41 --> Total execution time: 0.0678
INFO - 2016-12-10 03:26:41 --> Config Class Initialized
INFO - 2016-12-10 03:26:41 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:26:41 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:26:41 --> Utf8 Class Initialized
INFO - 2016-12-10 03:26:41 --> URI Class Initialized
INFO - 2016-12-10 03:26:41 --> Router Class Initialized
INFO - 2016-12-10 03:26:41 --> Output Class Initialized
INFO - 2016-12-10 03:26:41 --> Security Class Initialized
DEBUG - 2016-12-10 03:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:26:41 --> Input Class Initialized
INFO - 2016-12-10 03:26:41 --> Language Class Initialized
INFO - 2016-12-10 03:26:41 --> Loader Class Initialized
INFO - 2016-12-10 03:26:41 --> Database Driver Class Initialized
INFO - 2016-12-10 03:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:26:41 --> Controller Class Initialized
INFO - 2016-12-10 03:26:41 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:26:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:26:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:26:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:26:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:26:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:26:41 --> Final output sent to browser
DEBUG - 2016-12-10 03:26:41 --> Total execution time: 0.0136
INFO - 2016-12-10 03:26:55 --> Config Class Initialized
INFO - 2016-12-10 03:26:55 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:26:55 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:26:55 --> Utf8 Class Initialized
INFO - 2016-12-10 03:26:55 --> URI Class Initialized
INFO - 2016-12-10 03:26:55 --> Router Class Initialized
INFO - 2016-12-10 03:26:55 --> Output Class Initialized
INFO - 2016-12-10 03:26:55 --> Security Class Initialized
DEBUG - 2016-12-10 03:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:26:55 --> Input Class Initialized
INFO - 2016-12-10 03:26:55 --> Language Class Initialized
INFO - 2016-12-10 03:26:55 --> Loader Class Initialized
INFO - 2016-12-10 03:26:55 --> Database Driver Class Initialized
INFO - 2016-12-10 03:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:26:55 --> Controller Class Initialized
DEBUG - 2016-12-10 03:26:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:26:55 --> Helper loaded: url_helper
INFO - 2016-12-10 03:26:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:26:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 03:26:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 03:26:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:26:55 --> Final output sent to browser
DEBUG - 2016-12-10 03:26:55 --> Total execution time: 0.0193
INFO - 2016-12-10 03:26:55 --> Config Class Initialized
INFO - 2016-12-10 03:26:55 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:26:55 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:26:55 --> Utf8 Class Initialized
INFO - 2016-12-10 03:26:55 --> URI Class Initialized
INFO - 2016-12-10 03:26:55 --> Router Class Initialized
INFO - 2016-12-10 03:26:55 --> Output Class Initialized
INFO - 2016-12-10 03:26:55 --> Security Class Initialized
DEBUG - 2016-12-10 03:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:26:55 --> Input Class Initialized
INFO - 2016-12-10 03:26:55 --> Language Class Initialized
INFO - 2016-12-10 03:26:55 --> Loader Class Initialized
INFO - 2016-12-10 03:26:55 --> Database Driver Class Initialized
INFO - 2016-12-10 03:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:26:55 --> Controller Class Initialized
INFO - 2016-12-10 03:26:55 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:26:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:26:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:26:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:26:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:26:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:26:55 --> Final output sent to browser
DEBUG - 2016-12-10 03:26:55 --> Total execution time: 0.0144
INFO - 2016-12-10 03:26:57 --> Config Class Initialized
INFO - 2016-12-10 03:26:57 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:26:57 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:26:57 --> Utf8 Class Initialized
INFO - 2016-12-10 03:26:57 --> URI Class Initialized
INFO - 2016-12-10 03:26:57 --> Router Class Initialized
INFO - 2016-12-10 03:26:57 --> Output Class Initialized
INFO - 2016-12-10 03:26:57 --> Security Class Initialized
DEBUG - 2016-12-10 03:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:26:57 --> Input Class Initialized
INFO - 2016-12-10 03:26:57 --> Language Class Initialized
INFO - 2016-12-10 03:26:57 --> Loader Class Initialized
INFO - 2016-12-10 03:26:57 --> Database Driver Class Initialized
INFO - 2016-12-10 03:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:26:57 --> Controller Class Initialized
DEBUG - 2016-12-10 03:26:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:26:57 --> Helper loaded: url_helper
INFO - 2016-12-10 03:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-10 03:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 03:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-10 03:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-10 03:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:26:57 --> Final output sent to browser
DEBUG - 2016-12-10 03:26:57 --> Total execution time: 0.0123
INFO - 2016-12-10 03:26:57 --> Config Class Initialized
INFO - 2016-12-10 03:26:57 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:26:57 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:26:57 --> Utf8 Class Initialized
INFO - 2016-12-10 03:26:57 --> URI Class Initialized
INFO - 2016-12-10 03:26:57 --> Router Class Initialized
INFO - 2016-12-10 03:26:57 --> Output Class Initialized
INFO - 2016-12-10 03:26:57 --> Security Class Initialized
DEBUG - 2016-12-10 03:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:26:57 --> Input Class Initialized
INFO - 2016-12-10 03:26:57 --> Language Class Initialized
INFO - 2016-12-10 03:26:57 --> Loader Class Initialized
INFO - 2016-12-10 03:26:57 --> Database Driver Class Initialized
INFO - 2016-12-10 03:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:26:57 --> Controller Class Initialized
INFO - 2016-12-10 03:26:57 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:26:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:26:57 --> Final output sent to browser
DEBUG - 2016-12-10 03:26:57 --> Total execution time: 0.0135
INFO - 2016-12-10 03:26:58 --> Config Class Initialized
INFO - 2016-12-10 03:26:58 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:26:58 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:26:58 --> Utf8 Class Initialized
INFO - 2016-12-10 03:26:58 --> URI Class Initialized
INFO - 2016-12-10 03:26:58 --> Router Class Initialized
INFO - 2016-12-10 03:26:58 --> Output Class Initialized
INFO - 2016-12-10 03:26:58 --> Security Class Initialized
DEBUG - 2016-12-10 03:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:26:58 --> Input Class Initialized
INFO - 2016-12-10 03:26:58 --> Language Class Initialized
INFO - 2016-12-10 03:26:58 --> Loader Class Initialized
INFO - 2016-12-10 03:26:58 --> Database Driver Class Initialized
INFO - 2016-12-10 03:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:26:58 --> Controller Class Initialized
INFO - 2016-12-10 03:26:58 --> Helper loaded: date_helper
DEBUG - 2016-12-10 03:26:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:26:58 --> Helper loaded: url_helper
INFO - 2016-12-10 03:26:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:26:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 03:26:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-10 03:26:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-10 03:26:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:26:58 --> Final output sent to browser
DEBUG - 2016-12-10 03:26:58 --> Total execution time: 0.0171
INFO - 2016-12-10 03:26:58 --> Config Class Initialized
INFO - 2016-12-10 03:26:58 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:26:58 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:26:58 --> Utf8 Class Initialized
INFO - 2016-12-10 03:26:58 --> URI Class Initialized
INFO - 2016-12-10 03:26:58 --> Router Class Initialized
INFO - 2016-12-10 03:26:58 --> Output Class Initialized
INFO - 2016-12-10 03:26:58 --> Security Class Initialized
DEBUG - 2016-12-10 03:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:26:58 --> Input Class Initialized
INFO - 2016-12-10 03:26:58 --> Language Class Initialized
INFO - 2016-12-10 03:26:58 --> Loader Class Initialized
INFO - 2016-12-10 03:26:58 --> Database Driver Class Initialized
INFO - 2016-12-10 03:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:26:58 --> Controller Class Initialized
INFO - 2016-12-10 03:26:58 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:26:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:26:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:26:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:26:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:26:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:26:58 --> Final output sent to browser
DEBUG - 2016-12-10 03:26:58 --> Total execution time: 0.0137
INFO - 2016-12-10 03:27:06 --> Config Class Initialized
INFO - 2016-12-10 03:27:06 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:27:06 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:27:06 --> Utf8 Class Initialized
INFO - 2016-12-10 03:27:06 --> URI Class Initialized
INFO - 2016-12-10 03:27:06 --> Router Class Initialized
INFO - 2016-12-10 03:27:06 --> Output Class Initialized
INFO - 2016-12-10 03:27:06 --> Security Class Initialized
DEBUG - 2016-12-10 03:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:27:06 --> Input Class Initialized
INFO - 2016-12-10 03:27:06 --> Language Class Initialized
INFO - 2016-12-10 03:27:06 --> Loader Class Initialized
INFO - 2016-12-10 03:27:06 --> Database Driver Class Initialized
INFO - 2016-12-10 03:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:27:06 --> Controller Class Initialized
DEBUG - 2016-12-10 03:27:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:27:06 --> Helper loaded: url_helper
INFO - 2016-12-10 03:27:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:27:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 03:27:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 03:27:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:27:06 --> Final output sent to browser
DEBUG - 2016-12-10 03:27:06 --> Total execution time: 0.0124
INFO - 2016-12-10 03:27:06 --> Config Class Initialized
INFO - 2016-12-10 03:27:06 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:27:06 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:27:06 --> Utf8 Class Initialized
INFO - 2016-12-10 03:27:06 --> URI Class Initialized
INFO - 2016-12-10 03:27:06 --> Router Class Initialized
INFO - 2016-12-10 03:27:06 --> Output Class Initialized
INFO - 2016-12-10 03:27:06 --> Security Class Initialized
DEBUG - 2016-12-10 03:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:27:06 --> Input Class Initialized
INFO - 2016-12-10 03:27:06 --> Language Class Initialized
INFO - 2016-12-10 03:27:06 --> Loader Class Initialized
INFO - 2016-12-10 03:27:06 --> Database Driver Class Initialized
INFO - 2016-12-10 03:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:27:06 --> Controller Class Initialized
INFO - 2016-12-10 03:27:06 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:27:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:27:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:27:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:27:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:27:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:27:06 --> Final output sent to browser
DEBUG - 2016-12-10 03:27:06 --> Total execution time: 0.0134
INFO - 2016-12-10 03:46:25 --> Config Class Initialized
INFO - 2016-12-10 03:46:25 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:46:25 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:46:25 --> Utf8 Class Initialized
INFO - 2016-12-10 03:46:25 --> URI Class Initialized
INFO - 2016-12-10 03:46:25 --> Router Class Initialized
INFO - 2016-12-10 03:46:25 --> Output Class Initialized
INFO - 2016-12-10 03:46:25 --> Security Class Initialized
DEBUG - 2016-12-10 03:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:46:25 --> Input Class Initialized
INFO - 2016-12-10 03:46:25 --> Language Class Initialized
INFO - 2016-12-10 03:46:25 --> Loader Class Initialized
INFO - 2016-12-10 03:46:25 --> Database Driver Class Initialized
INFO - 2016-12-10 03:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:46:25 --> Controller Class Initialized
INFO - 2016-12-10 03:46:25 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:46:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:46:25 --> Helper loaded: form_helper
INFO - 2016-12-10 03:46:25 --> Form Validation Class Initialized
INFO - 2016-12-10 03:46:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 03:46:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2016-12-10 03:46:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 03:46:25 --> Final output sent to browser
DEBUG - 2016-12-10 03:46:25 --> Total execution time: 0.1876
INFO - 2016-12-10 03:46:27 --> Config Class Initialized
INFO - 2016-12-10 03:46:27 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:46:27 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:46:27 --> Utf8 Class Initialized
INFO - 2016-12-10 03:46:27 --> URI Class Initialized
INFO - 2016-12-10 03:46:27 --> Router Class Initialized
INFO - 2016-12-10 03:46:27 --> Output Class Initialized
INFO - 2016-12-10 03:46:27 --> Security Class Initialized
DEBUG - 2016-12-10 03:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:46:27 --> Input Class Initialized
INFO - 2016-12-10 03:46:27 --> Language Class Initialized
INFO - 2016-12-10 03:46:27 --> Loader Class Initialized
INFO - 2016-12-10 03:46:27 --> Database Driver Class Initialized
INFO - 2016-12-10 03:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:46:27 --> Controller Class Initialized
INFO - 2016-12-10 03:46:27 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:46:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:46:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:46:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:46:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:46:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:46:27 --> Final output sent to browser
DEBUG - 2016-12-10 03:46:27 --> Total execution time: 0.0143
INFO - 2016-12-10 03:46:38 --> Config Class Initialized
INFO - 2016-12-10 03:46:38 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:46:38 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:46:38 --> Utf8 Class Initialized
INFO - 2016-12-10 03:46:38 --> URI Class Initialized
INFO - 2016-12-10 03:46:38 --> Router Class Initialized
INFO - 2016-12-10 03:46:38 --> Output Class Initialized
INFO - 2016-12-10 03:46:38 --> Security Class Initialized
DEBUG - 2016-12-10 03:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:46:38 --> Input Class Initialized
INFO - 2016-12-10 03:46:38 --> Language Class Initialized
INFO - 2016-12-10 03:46:38 --> Loader Class Initialized
INFO - 2016-12-10 03:46:38 --> Database Driver Class Initialized
INFO - 2016-12-10 03:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:46:38 --> Controller Class Initialized
INFO - 2016-12-10 03:46:38 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:46:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:46:38 --> Helper loaded: form_helper
INFO - 2016-12-10 03:46:38 --> Form Validation Class Initialized
INFO - 2016-12-10 03:46:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-10 03:46:38 --> Config Class Initialized
INFO - 2016-12-10 03:46:38 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:46:38 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:46:38 --> Utf8 Class Initialized
INFO - 2016-12-10 03:46:38 --> URI Class Initialized
INFO - 2016-12-10 03:46:38 --> Router Class Initialized
INFO - 2016-12-10 03:46:38 --> Output Class Initialized
INFO - 2016-12-10 03:46:38 --> Security Class Initialized
DEBUG - 2016-12-10 03:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:46:38 --> Input Class Initialized
INFO - 2016-12-10 03:46:38 --> Language Class Initialized
INFO - 2016-12-10 03:46:38 --> Loader Class Initialized
INFO - 2016-12-10 03:46:38 --> Database Driver Class Initialized
INFO - 2016-12-10 03:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:46:38 --> Controller Class Initialized
INFO - 2016-12-10 03:46:38 --> Helper loaded: date_helper
INFO - 2016-12-10 03:46:38 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:46:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:46:38 --> Helper loaded: form_helper
INFO - 2016-12-10 03:46:38 --> Form Validation Class Initialized
INFO - 2016-12-10 03:46:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 03:46:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-10 03:46:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2016-12-10 03:46:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2016-12-10 03:46:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 03:46:38 --> Final output sent to browser
DEBUG - 2016-12-10 03:46:38 --> Total execution time: 0.0769
INFO - 2016-12-10 03:46:39 --> Config Class Initialized
INFO - 2016-12-10 03:46:39 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:46:39 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:46:39 --> Utf8 Class Initialized
INFO - 2016-12-10 03:46:39 --> URI Class Initialized
INFO - 2016-12-10 03:46:39 --> Router Class Initialized
INFO - 2016-12-10 03:46:39 --> Output Class Initialized
INFO - 2016-12-10 03:46:39 --> Security Class Initialized
DEBUG - 2016-12-10 03:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:46:39 --> Input Class Initialized
INFO - 2016-12-10 03:46:39 --> Language Class Initialized
INFO - 2016-12-10 03:46:39 --> Loader Class Initialized
INFO - 2016-12-10 03:46:39 --> Database Driver Class Initialized
INFO - 2016-12-10 03:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:46:39 --> Controller Class Initialized
INFO - 2016-12-10 03:46:39 --> Helper loaded: date_helper
INFO - 2016-12-10 03:46:39 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:46:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:46:39 --> Helper loaded: form_helper
INFO - 2016-12-10 03:46:39 --> Form Validation Class Initialized
INFO - 2016-12-10 03:46:39 --> Final output sent to browser
DEBUG - 2016-12-10 03:46:39 --> Total execution time: 0.0262
INFO - 2016-12-10 03:46:39 --> Config Class Initialized
INFO - 2016-12-10 03:46:39 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:46:39 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:46:39 --> Utf8 Class Initialized
INFO - 2016-12-10 03:46:39 --> URI Class Initialized
INFO - 2016-12-10 03:46:39 --> Router Class Initialized
INFO - 2016-12-10 03:46:39 --> Output Class Initialized
INFO - 2016-12-10 03:46:39 --> Security Class Initialized
DEBUG - 2016-12-10 03:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:46:39 --> Input Class Initialized
INFO - 2016-12-10 03:46:39 --> Language Class Initialized
INFO - 2016-12-10 03:46:39 --> Loader Class Initialized
INFO - 2016-12-10 03:46:39 --> Database Driver Class Initialized
INFO - 2016-12-10 03:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:46:39 --> Controller Class Initialized
INFO - 2016-12-10 03:46:39 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:46:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:46:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:46:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:46:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:46:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:46:39 --> Final output sent to browser
DEBUG - 2016-12-10 03:46:39 --> Total execution time: 0.0136
INFO - 2016-12-10 03:46:43 --> Config Class Initialized
INFO - 2016-12-10 03:46:43 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:46:43 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:46:43 --> Utf8 Class Initialized
INFO - 2016-12-10 03:46:43 --> URI Class Initialized
INFO - 2016-12-10 03:46:43 --> Router Class Initialized
INFO - 2016-12-10 03:46:43 --> Output Class Initialized
INFO - 2016-12-10 03:46:43 --> Security Class Initialized
DEBUG - 2016-12-10 03:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:46:43 --> Input Class Initialized
INFO - 2016-12-10 03:46:43 --> Language Class Initialized
INFO - 2016-12-10 03:46:43 --> Loader Class Initialized
INFO - 2016-12-10 03:46:43 --> Database Driver Class Initialized
INFO - 2016-12-10 03:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:46:43 --> Controller Class Initialized
INFO - 2016-12-10 03:46:43 --> Helper loaded: date_helper
INFO - 2016-12-10 03:46:43 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:46:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:46:43 --> Helper loaded: form_helper
INFO - 2016-12-10 03:46:43 --> Form Validation Class Initialized
INFO - 2016-12-10 03:46:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 03:46:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-10 03:46:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pagos.php
INFO - 2016-12-10 03:46:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pagos.php
INFO - 2016-12-10 03:46:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 03:46:43 --> Final output sent to browser
DEBUG - 2016-12-10 03:46:43 --> Total execution time: 0.0705
INFO - 2016-12-10 03:46:43 --> Config Class Initialized
INFO - 2016-12-10 03:46:43 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:46:43 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:46:43 --> Utf8 Class Initialized
INFO - 2016-12-10 03:46:43 --> URI Class Initialized
INFO - 2016-12-10 03:46:43 --> Router Class Initialized
INFO - 2016-12-10 03:46:43 --> Output Class Initialized
INFO - 2016-12-10 03:46:43 --> Security Class Initialized
DEBUG - 2016-12-10 03:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:46:43 --> Input Class Initialized
INFO - 2016-12-10 03:46:43 --> Language Class Initialized
INFO - 2016-12-10 03:46:43 --> Loader Class Initialized
INFO - 2016-12-10 03:46:43 --> Database Driver Class Initialized
INFO - 2016-12-10 03:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:46:43 --> Controller Class Initialized
INFO - 2016-12-10 03:46:43 --> Helper loaded: date_helper
INFO - 2016-12-10 03:46:43 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:46:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:46:43 --> Helper loaded: form_helper
INFO - 2016-12-10 03:46:43 --> Form Validation Class Initialized
INFO - 2016-12-10 03:46:43 --> Final output sent to browser
DEBUG - 2016-12-10 03:46:43 --> Total execution time: 0.0147
INFO - 2016-12-10 03:46:43 --> Config Class Initialized
INFO - 2016-12-10 03:46:43 --> Hooks Class Initialized
DEBUG - 2016-12-10 03:46:43 --> UTF-8 Support Enabled
INFO - 2016-12-10 03:46:43 --> Utf8 Class Initialized
INFO - 2016-12-10 03:46:43 --> URI Class Initialized
INFO - 2016-12-10 03:46:43 --> Router Class Initialized
INFO - 2016-12-10 03:46:43 --> Output Class Initialized
INFO - 2016-12-10 03:46:43 --> Security Class Initialized
DEBUG - 2016-12-10 03:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 03:46:43 --> Input Class Initialized
INFO - 2016-12-10 03:46:43 --> Language Class Initialized
INFO - 2016-12-10 03:46:43 --> Loader Class Initialized
INFO - 2016-12-10 03:46:43 --> Database Driver Class Initialized
INFO - 2016-12-10 03:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 03:46:43 --> Controller Class Initialized
INFO - 2016-12-10 03:46:43 --> Helper loaded: url_helper
DEBUG - 2016-12-10 03:46:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 03:46:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 03:46:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 03:46:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 03:46:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 03:46:43 --> Final output sent to browser
DEBUG - 2016-12-10 03:46:43 --> Total execution time: 0.0137
INFO - 2016-12-10 04:15:56 --> Config Class Initialized
INFO - 2016-12-10 04:15:56 --> Hooks Class Initialized
DEBUG - 2016-12-10 04:15:56 --> UTF-8 Support Enabled
INFO - 2016-12-10 04:15:56 --> Utf8 Class Initialized
INFO - 2016-12-10 04:15:56 --> URI Class Initialized
INFO - 2016-12-10 04:15:56 --> Router Class Initialized
INFO - 2016-12-10 04:15:56 --> Output Class Initialized
INFO - 2016-12-10 04:15:56 --> Security Class Initialized
DEBUG - 2016-12-10 04:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 04:15:56 --> Input Class Initialized
INFO - 2016-12-10 04:15:56 --> Language Class Initialized
INFO - 2016-12-10 04:15:56 --> Loader Class Initialized
INFO - 2016-12-10 04:15:56 --> Database Driver Class Initialized
INFO - 2016-12-10 04:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 04:15:56 --> Controller Class Initialized
DEBUG - 2016-12-10 04:15:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 04:15:56 --> Helper loaded: url_helper
INFO - 2016-12-10 04:15:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 04:15:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-10 04:15:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 04:15:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-10 04:15:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-10 04:15:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 04:15:56 --> Final output sent to browser
DEBUG - 2016-12-10 04:15:56 --> Total execution time: 0.0134
INFO - 2016-12-10 04:15:57 --> Config Class Initialized
INFO - 2016-12-10 04:15:57 --> Hooks Class Initialized
DEBUG - 2016-12-10 04:15:57 --> UTF-8 Support Enabled
INFO - 2016-12-10 04:15:57 --> Utf8 Class Initialized
INFO - 2016-12-10 04:15:57 --> URI Class Initialized
INFO - 2016-12-10 04:15:57 --> Router Class Initialized
INFO - 2016-12-10 04:15:57 --> Output Class Initialized
INFO - 2016-12-10 04:15:57 --> Security Class Initialized
DEBUG - 2016-12-10 04:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 04:15:57 --> Input Class Initialized
INFO - 2016-12-10 04:15:57 --> Language Class Initialized
INFO - 2016-12-10 04:15:57 --> Loader Class Initialized
INFO - 2016-12-10 04:15:57 --> Database Driver Class Initialized
INFO - 2016-12-10 04:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 04:15:57 --> Controller Class Initialized
INFO - 2016-12-10 04:15:57 --> Helper loaded: url_helper
DEBUG - 2016-12-10 04:15:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 04:15:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 04:15:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 04:15:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 04:15:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 04:15:57 --> Final output sent to browser
DEBUG - 2016-12-10 04:15:57 --> Total execution time: 0.0140
INFO - 2016-12-10 04:15:58 --> Config Class Initialized
INFO - 2016-12-10 04:15:58 --> Hooks Class Initialized
DEBUG - 2016-12-10 04:15:58 --> UTF-8 Support Enabled
INFO - 2016-12-10 04:15:58 --> Utf8 Class Initialized
INFO - 2016-12-10 04:15:58 --> URI Class Initialized
INFO - 2016-12-10 04:15:58 --> Router Class Initialized
INFO - 2016-12-10 04:15:58 --> Output Class Initialized
INFO - 2016-12-10 04:15:58 --> Security Class Initialized
DEBUG - 2016-12-10 04:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 04:15:58 --> Input Class Initialized
INFO - 2016-12-10 04:15:58 --> Language Class Initialized
INFO - 2016-12-10 04:15:58 --> Loader Class Initialized
INFO - 2016-12-10 04:15:58 --> Database Driver Class Initialized
INFO - 2016-12-10 04:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 04:15:58 --> Controller Class Initialized
DEBUG - 2016-12-10 04:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 04:15:58 --> Helper loaded: url_helper
INFO - 2016-12-10 04:15:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 04:15:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 04:15:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 04:15:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 04:15:58 --> Final output sent to browser
DEBUG - 2016-12-10 04:15:58 --> Total execution time: 0.0121
INFO - 2016-12-10 04:15:58 --> Config Class Initialized
INFO - 2016-12-10 04:15:58 --> Hooks Class Initialized
DEBUG - 2016-12-10 04:15:58 --> UTF-8 Support Enabled
INFO - 2016-12-10 04:15:58 --> Utf8 Class Initialized
INFO - 2016-12-10 04:15:58 --> URI Class Initialized
INFO - 2016-12-10 04:15:58 --> Router Class Initialized
INFO - 2016-12-10 04:15:58 --> Output Class Initialized
INFO - 2016-12-10 04:15:58 --> Security Class Initialized
DEBUG - 2016-12-10 04:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 04:15:58 --> Input Class Initialized
INFO - 2016-12-10 04:15:58 --> Language Class Initialized
INFO - 2016-12-10 04:15:58 --> Loader Class Initialized
INFO - 2016-12-10 04:15:58 --> Database Driver Class Initialized
INFO - 2016-12-10 04:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 04:15:58 --> Controller Class Initialized
INFO - 2016-12-10 04:15:58 --> Helper loaded: url_helper
DEBUG - 2016-12-10 04:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 04:15:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 04:15:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 04:15:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 04:15:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 04:15:58 --> Final output sent to browser
DEBUG - 2016-12-10 04:15:58 --> Total execution time: 0.0138
INFO - 2016-12-10 04:57:13 --> Config Class Initialized
INFO - 2016-12-10 04:57:13 --> Hooks Class Initialized
DEBUG - 2016-12-10 04:57:13 --> UTF-8 Support Enabled
INFO - 2016-12-10 04:57:13 --> Utf8 Class Initialized
INFO - 2016-12-10 04:57:13 --> URI Class Initialized
INFO - 2016-12-10 04:57:13 --> Router Class Initialized
INFO - 2016-12-10 04:57:13 --> Output Class Initialized
INFO - 2016-12-10 04:57:13 --> Security Class Initialized
DEBUG - 2016-12-10 04:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 04:57:13 --> Input Class Initialized
INFO - 2016-12-10 04:57:13 --> Language Class Initialized
INFO - 2016-12-10 04:57:13 --> Loader Class Initialized
INFO - 2016-12-10 04:57:13 --> Database Driver Class Initialized
INFO - 2016-12-10 04:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 04:57:13 --> Controller Class Initialized
ERROR - 2016-12-10 04:57:13 --> Severity: Parsing Error --> syntax error, unexpected ''tbl_persona_productos.id_grad' (T_CONSTANT_ENCAPSED_STRING), expecting ')' /home/graduafe/public_html/application/models/Persona_productos_modelo.php 46
INFO - 2016-12-10 04:57:13 --> Config Class Initialized
INFO - 2016-12-10 04:57:13 --> Hooks Class Initialized
DEBUG - 2016-12-10 04:57:13 --> UTF-8 Support Enabled
INFO - 2016-12-10 04:57:13 --> Utf8 Class Initialized
INFO - 2016-12-10 04:57:13 --> URI Class Initialized
INFO - 2016-12-10 04:57:13 --> Router Class Initialized
INFO - 2016-12-10 04:57:13 --> Output Class Initialized
INFO - 2016-12-10 04:57:13 --> Security Class Initialized
DEBUG - 2016-12-10 04:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 04:57:13 --> Input Class Initialized
INFO - 2016-12-10 04:57:13 --> Language Class Initialized
INFO - 2016-12-10 04:57:13 --> Loader Class Initialized
INFO - 2016-12-10 04:57:13 --> Database Driver Class Initialized
INFO - 2016-12-10 04:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 04:57:13 --> Controller Class Initialized
INFO - 2016-12-10 04:57:13 --> Helper loaded: url_helper
DEBUG - 2016-12-10 04:57:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 04:57:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 04:57:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 04:57:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 04:57:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 04:57:13 --> Final output sent to browser
DEBUG - 2016-12-10 04:57:13 --> Total execution time: 0.0139
INFO - 2016-12-10 04:57:47 --> Config Class Initialized
INFO - 2016-12-10 04:57:47 --> Hooks Class Initialized
DEBUG - 2016-12-10 04:57:47 --> UTF-8 Support Enabled
INFO - 2016-12-10 04:57:47 --> Utf8 Class Initialized
INFO - 2016-12-10 04:57:47 --> URI Class Initialized
INFO - 2016-12-10 04:57:47 --> Router Class Initialized
INFO - 2016-12-10 04:57:47 --> Output Class Initialized
INFO - 2016-12-10 04:57:47 --> Security Class Initialized
DEBUG - 2016-12-10 04:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 04:57:47 --> Input Class Initialized
INFO - 2016-12-10 04:57:47 --> Language Class Initialized
INFO - 2016-12-10 04:57:47 --> Loader Class Initialized
INFO - 2016-12-10 04:57:47 --> Database Driver Class Initialized
INFO - 2016-12-10 04:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 04:57:47 --> Controller Class Initialized
DEBUG - 2016-12-10 04:57:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 04:57:47 --> Helper loaded: url_helper
INFO - 2016-12-10 04:57:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 04:57:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-10 04:57:47 --> Severity: Notice --> Undefined variable: productos /home/graduafe/public_html/application/views/usuario/pages/saldo.php 26
ERROR - 2016-12-10 04:57:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/graduafe/public_html/application/views/usuario/pages/saldo.php 26
ERROR - 2016-12-10 04:57:47 --> Severity: Notice --> Undefined variable: total /home/graduafe/public_html/application/views/usuario/pages/saldo.php 43
INFO - 2016-12-10 04:57:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 04:57:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 04:57:47 --> Final output sent to browser
DEBUG - 2016-12-10 04:57:47 --> Total execution time: 0.0139
INFO - 2016-12-10 04:57:47 --> Config Class Initialized
INFO - 2016-12-10 04:57:47 --> Hooks Class Initialized
DEBUG - 2016-12-10 04:57:47 --> UTF-8 Support Enabled
INFO - 2016-12-10 04:57:47 --> Utf8 Class Initialized
INFO - 2016-12-10 04:57:47 --> URI Class Initialized
INFO - 2016-12-10 04:57:47 --> Router Class Initialized
INFO - 2016-12-10 04:57:47 --> Output Class Initialized
INFO - 2016-12-10 04:57:47 --> Security Class Initialized
DEBUG - 2016-12-10 04:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 04:57:47 --> Input Class Initialized
INFO - 2016-12-10 04:57:47 --> Language Class Initialized
INFO - 2016-12-10 04:57:47 --> Loader Class Initialized
INFO - 2016-12-10 04:57:47 --> Database Driver Class Initialized
INFO - 2016-12-10 04:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 04:57:47 --> Controller Class Initialized
INFO - 2016-12-10 04:57:47 --> Helper loaded: url_helper
DEBUG - 2016-12-10 04:57:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 04:57:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 04:57:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 04:57:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 04:57:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 04:57:47 --> Final output sent to browser
DEBUG - 2016-12-10 04:57:47 --> Total execution time: 0.0198
INFO - 2016-12-10 04:59:01 --> Config Class Initialized
INFO - 2016-12-10 04:59:01 --> Hooks Class Initialized
DEBUG - 2016-12-10 04:59:01 --> UTF-8 Support Enabled
INFO - 2016-12-10 04:59:01 --> Utf8 Class Initialized
INFO - 2016-12-10 04:59:01 --> URI Class Initialized
INFO - 2016-12-10 04:59:01 --> Router Class Initialized
INFO - 2016-12-10 04:59:01 --> Output Class Initialized
INFO - 2016-12-10 04:59:01 --> Security Class Initialized
DEBUG - 2016-12-10 04:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 04:59:01 --> Input Class Initialized
INFO - 2016-12-10 04:59:01 --> Language Class Initialized
INFO - 2016-12-10 04:59:01 --> Loader Class Initialized
INFO - 2016-12-10 04:59:01 --> Database Driver Class Initialized
INFO - 2016-12-10 04:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 04:59:01 --> Controller Class Initialized
DEBUG - 2016-12-10 04:59:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 04:59:01 --> Helper loaded: url_helper
INFO - 2016-12-10 04:59:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 04:59:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 04:59:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 04:59:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 04:59:01 --> Final output sent to browser
DEBUG - 2016-12-10 04:59:01 --> Total execution time: 0.0130
INFO - 2016-12-10 04:59:01 --> Config Class Initialized
INFO - 2016-12-10 04:59:01 --> Hooks Class Initialized
DEBUG - 2016-12-10 04:59:01 --> UTF-8 Support Enabled
INFO - 2016-12-10 04:59:01 --> Utf8 Class Initialized
INFO - 2016-12-10 04:59:01 --> URI Class Initialized
INFO - 2016-12-10 04:59:01 --> Router Class Initialized
INFO - 2016-12-10 04:59:01 --> Output Class Initialized
INFO - 2016-12-10 04:59:01 --> Security Class Initialized
DEBUG - 2016-12-10 04:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 04:59:01 --> Input Class Initialized
INFO - 2016-12-10 04:59:01 --> Language Class Initialized
INFO - 2016-12-10 04:59:01 --> Loader Class Initialized
INFO - 2016-12-10 04:59:01 --> Database Driver Class Initialized
INFO - 2016-12-10 04:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 04:59:01 --> Controller Class Initialized
INFO - 2016-12-10 04:59:01 --> Helper loaded: url_helper
DEBUG - 2016-12-10 04:59:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 04:59:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 04:59:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 04:59:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 04:59:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 04:59:01 --> Final output sent to browser
DEBUG - 2016-12-10 04:59:01 --> Total execution time: 0.0140
INFO - 2016-12-10 04:59:05 --> Config Class Initialized
INFO - 2016-12-10 04:59:05 --> Hooks Class Initialized
DEBUG - 2016-12-10 04:59:05 --> UTF-8 Support Enabled
INFO - 2016-12-10 04:59:05 --> Utf8 Class Initialized
INFO - 2016-12-10 04:59:05 --> URI Class Initialized
INFO - 2016-12-10 04:59:05 --> Router Class Initialized
INFO - 2016-12-10 04:59:05 --> Output Class Initialized
INFO - 2016-12-10 04:59:05 --> Security Class Initialized
DEBUG - 2016-12-10 04:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 04:59:05 --> Input Class Initialized
INFO - 2016-12-10 04:59:05 --> Language Class Initialized
INFO - 2016-12-10 04:59:05 --> Loader Class Initialized
INFO - 2016-12-10 04:59:05 --> Database Driver Class Initialized
INFO - 2016-12-10 04:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 04:59:05 --> Controller Class Initialized
DEBUG - 2016-12-10 04:59:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 04:59:05 --> Helper loaded: url_helper
INFO - 2016-12-10 04:59:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 04:59:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-10 04:59:05 --> Severity: Notice --> Undefined variable: productos /home/graduafe/public_html/application/views/usuario/pages/saldo.php 26
ERROR - 2016-12-10 04:59:05 --> Severity: Notice --> Undefined variable: productos /home/graduafe/public_html/application/views/usuario/pages/saldo.php 27
ERROR - 2016-12-10 04:59:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/graduafe/public_html/application/views/usuario/pages/saldo.php 27
ERROR - 2016-12-10 04:59:05 --> Severity: Notice --> Undefined variable: total /home/graduafe/public_html/application/views/usuario/pages/saldo.php 44
INFO - 2016-12-10 04:59:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 04:59:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 04:59:05 --> Final output sent to browser
DEBUG - 2016-12-10 04:59:05 --> Total execution time: 0.0135
INFO - 2016-12-10 04:59:05 --> Config Class Initialized
INFO - 2016-12-10 04:59:05 --> Hooks Class Initialized
DEBUG - 2016-12-10 04:59:05 --> UTF-8 Support Enabled
INFO - 2016-12-10 04:59:05 --> Utf8 Class Initialized
INFO - 2016-12-10 04:59:05 --> URI Class Initialized
INFO - 2016-12-10 04:59:05 --> Router Class Initialized
INFO - 2016-12-10 04:59:05 --> Output Class Initialized
INFO - 2016-12-10 04:59:05 --> Security Class Initialized
DEBUG - 2016-12-10 04:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 04:59:05 --> Input Class Initialized
INFO - 2016-12-10 04:59:05 --> Language Class Initialized
INFO - 2016-12-10 04:59:05 --> Loader Class Initialized
INFO - 2016-12-10 04:59:05 --> Database Driver Class Initialized
INFO - 2016-12-10 04:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 04:59:05 --> Controller Class Initialized
INFO - 2016-12-10 04:59:05 --> Helper loaded: url_helper
DEBUG - 2016-12-10 04:59:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 04:59:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 04:59:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 04:59:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 04:59:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 04:59:05 --> Final output sent to browser
DEBUG - 2016-12-10 04:59:05 --> Total execution time: 0.0136
INFO - 2016-12-10 04:59:58 --> Config Class Initialized
INFO - 2016-12-10 04:59:58 --> Hooks Class Initialized
DEBUG - 2016-12-10 04:59:58 --> UTF-8 Support Enabled
INFO - 2016-12-10 04:59:58 --> Utf8 Class Initialized
INFO - 2016-12-10 04:59:58 --> URI Class Initialized
INFO - 2016-12-10 04:59:58 --> Router Class Initialized
INFO - 2016-12-10 04:59:58 --> Output Class Initialized
INFO - 2016-12-10 04:59:58 --> Security Class Initialized
DEBUG - 2016-12-10 04:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 04:59:58 --> Input Class Initialized
INFO - 2016-12-10 04:59:58 --> Language Class Initialized
INFO - 2016-12-10 04:59:58 --> Loader Class Initialized
INFO - 2016-12-10 04:59:58 --> Database Driver Class Initialized
INFO - 2016-12-10 04:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 04:59:58 --> Controller Class Initialized
DEBUG - 2016-12-10 04:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 04:59:58 --> Helper loaded: url_helper
INFO - 2016-12-10 04:59:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 04:59:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-10 04:59:58 --> Severity: Error --> Cannot use object of type stdClass as array /home/graduafe/public_html/application/views/usuario/pages/saldo.php 32
INFO - 2016-12-10 04:59:58 --> Config Class Initialized
INFO - 2016-12-10 04:59:58 --> Hooks Class Initialized
DEBUG - 2016-12-10 04:59:58 --> UTF-8 Support Enabled
INFO - 2016-12-10 04:59:58 --> Utf8 Class Initialized
INFO - 2016-12-10 04:59:58 --> URI Class Initialized
INFO - 2016-12-10 04:59:58 --> Router Class Initialized
INFO - 2016-12-10 04:59:58 --> Output Class Initialized
INFO - 2016-12-10 04:59:58 --> Security Class Initialized
DEBUG - 2016-12-10 04:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 04:59:58 --> Input Class Initialized
INFO - 2016-12-10 04:59:58 --> Language Class Initialized
INFO - 2016-12-10 04:59:58 --> Loader Class Initialized
INFO - 2016-12-10 04:59:58 --> Database Driver Class Initialized
INFO - 2016-12-10 04:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 04:59:58 --> Controller Class Initialized
INFO - 2016-12-10 04:59:58 --> Helper loaded: url_helper
DEBUG - 2016-12-10 04:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 04:59:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 04:59:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 04:59:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 04:59:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 04:59:58 --> Final output sent to browser
DEBUG - 2016-12-10 04:59:58 --> Total execution time: 0.0134
INFO - 2016-12-10 05:00:11 --> Config Class Initialized
INFO - 2016-12-10 05:00:11 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:00:11 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:00:11 --> Utf8 Class Initialized
INFO - 2016-12-10 05:00:11 --> URI Class Initialized
INFO - 2016-12-10 05:00:11 --> Router Class Initialized
INFO - 2016-12-10 05:00:11 --> Output Class Initialized
INFO - 2016-12-10 05:00:11 --> Security Class Initialized
DEBUG - 2016-12-10 05:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:00:11 --> Input Class Initialized
INFO - 2016-12-10 05:00:11 --> Language Class Initialized
INFO - 2016-12-10 05:00:11 --> Loader Class Initialized
INFO - 2016-12-10 05:00:11 --> Database Driver Class Initialized
INFO - 2016-12-10 05:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:00:11 --> Controller Class Initialized
DEBUG - 2016-12-10 05:00:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:00:11 --> Helper loaded: url_helper
INFO - 2016-12-10 05:00:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:00:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-10 05:00:11 --> Severity: Error --> Cannot use object of type stdClass as array /home/graduafe/public_html/application/views/usuario/pages/saldo.php 32
INFO - 2016-12-10 05:00:11 --> Config Class Initialized
INFO - 2016-12-10 05:00:11 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:00:11 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:00:11 --> Utf8 Class Initialized
INFO - 2016-12-10 05:00:11 --> URI Class Initialized
INFO - 2016-12-10 05:00:11 --> Router Class Initialized
INFO - 2016-12-10 05:00:11 --> Output Class Initialized
INFO - 2016-12-10 05:00:11 --> Security Class Initialized
DEBUG - 2016-12-10 05:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:00:11 --> Input Class Initialized
INFO - 2016-12-10 05:00:11 --> Language Class Initialized
INFO - 2016-12-10 05:00:11 --> Loader Class Initialized
INFO - 2016-12-10 05:00:11 --> Database Driver Class Initialized
INFO - 2016-12-10 05:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:00:11 --> Controller Class Initialized
INFO - 2016-12-10 05:00:11 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:00:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:00:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:00:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 05:00:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 05:00:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:00:11 --> Final output sent to browser
DEBUG - 2016-12-10 05:00:11 --> Total execution time: 0.0137
INFO - 2016-12-10 05:00:13 --> Config Class Initialized
INFO - 2016-12-10 05:00:13 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:00:13 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:00:13 --> Utf8 Class Initialized
INFO - 2016-12-10 05:00:13 --> URI Class Initialized
INFO - 2016-12-10 05:00:13 --> Router Class Initialized
INFO - 2016-12-10 05:00:13 --> Output Class Initialized
INFO - 2016-12-10 05:00:13 --> Security Class Initialized
DEBUG - 2016-12-10 05:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:00:13 --> Input Class Initialized
INFO - 2016-12-10 05:00:13 --> Language Class Initialized
INFO - 2016-12-10 05:00:13 --> Loader Class Initialized
INFO - 2016-12-10 05:00:13 --> Database Driver Class Initialized
INFO - 2016-12-10 05:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:00:13 --> Controller Class Initialized
DEBUG - 2016-12-10 05:00:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:00:13 --> Helper loaded: url_helper
INFO - 2016-12-10 05:00:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:00:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-10 05:00:13 --> Severity: Error --> Cannot use object of type stdClass as array /home/graduafe/public_html/application/views/usuario/pages/saldo.php 32
INFO - 2016-12-10 05:00:13 --> Config Class Initialized
INFO - 2016-12-10 05:00:13 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:00:13 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:00:13 --> Utf8 Class Initialized
INFO - 2016-12-10 05:00:13 --> URI Class Initialized
INFO - 2016-12-10 05:00:13 --> Router Class Initialized
INFO - 2016-12-10 05:00:13 --> Output Class Initialized
INFO - 2016-12-10 05:00:13 --> Security Class Initialized
DEBUG - 2016-12-10 05:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:00:13 --> Input Class Initialized
INFO - 2016-12-10 05:00:13 --> Language Class Initialized
INFO - 2016-12-10 05:00:13 --> Loader Class Initialized
INFO - 2016-12-10 05:00:13 --> Database Driver Class Initialized
INFO - 2016-12-10 05:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:00:13 --> Controller Class Initialized
INFO - 2016-12-10 05:00:13 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:00:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:00:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:00:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 05:00:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 05:00:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:00:13 --> Final output sent to browser
DEBUG - 2016-12-10 05:00:13 --> Total execution time: 0.0142
INFO - 2016-12-10 05:00:14 --> Config Class Initialized
INFO - 2016-12-10 05:00:14 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:00:14 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:00:14 --> Utf8 Class Initialized
INFO - 2016-12-10 05:00:14 --> URI Class Initialized
INFO - 2016-12-10 05:00:14 --> Router Class Initialized
INFO - 2016-12-10 05:00:14 --> Output Class Initialized
INFO - 2016-12-10 05:00:14 --> Security Class Initialized
DEBUG - 2016-12-10 05:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:00:14 --> Input Class Initialized
INFO - 2016-12-10 05:00:14 --> Language Class Initialized
INFO - 2016-12-10 05:00:14 --> Loader Class Initialized
INFO - 2016-12-10 05:00:14 --> Database Driver Class Initialized
INFO - 2016-12-10 05:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:00:14 --> Controller Class Initialized
DEBUG - 2016-12-10 05:00:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:00:14 --> Helper loaded: url_helper
INFO - 2016-12-10 05:00:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:00:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-10 05:00:14 --> Severity: Error --> Cannot use object of type stdClass as array /home/graduafe/public_html/application/views/usuario/pages/saldo.php 32
INFO - 2016-12-10 05:00:15 --> Config Class Initialized
INFO - 2016-12-10 05:00:15 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:00:15 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:00:15 --> Utf8 Class Initialized
INFO - 2016-12-10 05:00:15 --> URI Class Initialized
INFO - 2016-12-10 05:00:15 --> Router Class Initialized
INFO - 2016-12-10 05:00:15 --> Output Class Initialized
INFO - 2016-12-10 05:00:15 --> Security Class Initialized
DEBUG - 2016-12-10 05:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:00:15 --> Input Class Initialized
INFO - 2016-12-10 05:00:15 --> Language Class Initialized
INFO - 2016-12-10 05:00:15 --> Loader Class Initialized
INFO - 2016-12-10 05:00:15 --> Database Driver Class Initialized
INFO - 2016-12-10 05:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:00:15 --> Controller Class Initialized
INFO - 2016-12-10 05:00:15 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:00:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:00:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:00:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 05:00:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 05:00:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:00:15 --> Final output sent to browser
DEBUG - 2016-12-10 05:00:15 --> Total execution time: 0.0138
INFO - 2016-12-10 05:02:25 --> Config Class Initialized
INFO - 2016-12-10 05:02:25 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:02:25 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:02:25 --> Utf8 Class Initialized
INFO - 2016-12-10 05:02:25 --> URI Class Initialized
INFO - 2016-12-10 05:02:25 --> Router Class Initialized
INFO - 2016-12-10 05:02:25 --> Output Class Initialized
INFO - 2016-12-10 05:02:25 --> Security Class Initialized
DEBUG - 2016-12-10 05:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:02:25 --> Input Class Initialized
INFO - 2016-12-10 05:02:25 --> Language Class Initialized
INFO - 2016-12-10 05:02:25 --> Loader Class Initialized
INFO - 2016-12-10 05:02:25 --> Database Driver Class Initialized
INFO - 2016-12-10 05:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:02:25 --> Controller Class Initialized
DEBUG - 2016-12-10 05:02:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:02:25 --> Helper loaded: url_helper
INFO - 2016-12-10 05:02:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:02:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-10 05:02:25 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:25 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:25 --> Severity: Notice --> Undefined variable: total /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:25 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 36
ERROR - 2016-12-10 05:02:25 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 36
ERROR - 2016-12-10 05:02:25 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:25 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:25 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 36
ERROR - 2016-12-10 05:02:25 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 36
ERROR - 2016-12-10 05:02:25 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:25 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:25 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 36
ERROR - 2016-12-10 05:02:25 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 36
ERROR - 2016-12-10 05:02:25 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:25 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:25 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 36
ERROR - 2016-12-10 05:02:25 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 36
ERROR - 2016-12-10 05:02:25 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:25 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:25 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 36
ERROR - 2016-12-10 05:02:25 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 36
INFO - 2016-12-10 05:02:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 05:02:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:02:25 --> Final output sent to browser
DEBUG - 2016-12-10 05:02:25 --> Total execution time: 0.0160
INFO - 2016-12-10 05:02:25 --> Config Class Initialized
INFO - 2016-12-10 05:02:25 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:02:25 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:02:25 --> Utf8 Class Initialized
INFO - 2016-12-10 05:02:25 --> URI Class Initialized
INFO - 2016-12-10 05:02:25 --> Router Class Initialized
INFO - 2016-12-10 05:02:25 --> Output Class Initialized
INFO - 2016-12-10 05:02:25 --> Security Class Initialized
DEBUG - 2016-12-10 05:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:02:25 --> Input Class Initialized
INFO - 2016-12-10 05:02:25 --> Language Class Initialized
INFO - 2016-12-10 05:02:25 --> Loader Class Initialized
INFO - 2016-12-10 05:02:25 --> Database Driver Class Initialized
INFO - 2016-12-10 05:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:02:25 --> Controller Class Initialized
INFO - 2016-12-10 05:02:25 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:02:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:02:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:02:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 05:02:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 05:02:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:02:25 --> Final output sent to browser
DEBUG - 2016-12-10 05:02:25 --> Total execution time: 0.0590
INFO - 2016-12-10 05:02:47 --> Config Class Initialized
INFO - 2016-12-10 05:02:47 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:02:47 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:02:47 --> Utf8 Class Initialized
INFO - 2016-12-10 05:02:47 --> URI Class Initialized
INFO - 2016-12-10 05:02:47 --> Router Class Initialized
INFO - 2016-12-10 05:02:47 --> Output Class Initialized
INFO - 2016-12-10 05:02:47 --> Security Class Initialized
DEBUG - 2016-12-10 05:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:02:47 --> Input Class Initialized
INFO - 2016-12-10 05:02:47 --> Language Class Initialized
INFO - 2016-12-10 05:02:47 --> Loader Class Initialized
INFO - 2016-12-10 05:02:47 --> Database Driver Class Initialized
INFO - 2016-12-10 05:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:02:47 --> Controller Class Initialized
DEBUG - 2016-12-10 05:02:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:02:47 --> Helper loaded: url_helper
INFO - 2016-12-10 05:02:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:02:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-10 05:02:47 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:47 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:47 --> Severity: Notice --> Undefined variable: total /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:47 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 36
ERROR - 2016-12-10 05:02:47 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 36
ERROR - 2016-12-10 05:02:47 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:47 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:47 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 36
ERROR - 2016-12-10 05:02:47 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 36
ERROR - 2016-12-10 05:02:47 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:47 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:47 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 36
ERROR - 2016-12-10 05:02:47 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 36
ERROR - 2016-12-10 05:02:47 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:47 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:47 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 36
ERROR - 2016-12-10 05:02:47 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 36
ERROR - 2016-12-10 05:02:47 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:47 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:47 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 36
ERROR - 2016-12-10 05:02:47 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 36
INFO - 2016-12-10 05:02:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 05:02:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:02:47 --> Final output sent to browser
DEBUG - 2016-12-10 05:02:47 --> Total execution time: 0.0150
INFO - 2016-12-10 05:02:48 --> Config Class Initialized
INFO - 2016-12-10 05:02:48 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:02:48 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:02:48 --> Utf8 Class Initialized
INFO - 2016-12-10 05:02:48 --> URI Class Initialized
INFO - 2016-12-10 05:02:48 --> Router Class Initialized
INFO - 2016-12-10 05:02:48 --> Output Class Initialized
INFO - 2016-12-10 05:02:48 --> Security Class Initialized
DEBUG - 2016-12-10 05:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:02:48 --> Input Class Initialized
INFO - 2016-12-10 05:02:48 --> Language Class Initialized
INFO - 2016-12-10 05:02:48 --> Loader Class Initialized
INFO - 2016-12-10 05:02:48 --> Database Driver Class Initialized
INFO - 2016-12-10 05:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:02:48 --> Controller Class Initialized
INFO - 2016-12-10 05:02:48 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:02:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:02:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:02:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 05:02:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 05:02:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:02:48 --> Final output sent to browser
DEBUG - 2016-12-10 05:02:48 --> Total execution time: 0.0155
INFO - 2016-12-10 05:02:49 --> Config Class Initialized
INFO - 2016-12-10 05:02:49 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:02:49 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:02:49 --> Utf8 Class Initialized
INFO - 2016-12-10 05:02:49 --> URI Class Initialized
INFO - 2016-12-10 05:02:49 --> Router Class Initialized
INFO - 2016-12-10 05:02:49 --> Output Class Initialized
INFO - 2016-12-10 05:02:49 --> Security Class Initialized
DEBUG - 2016-12-10 05:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:02:49 --> Input Class Initialized
INFO - 2016-12-10 05:02:49 --> Language Class Initialized
INFO - 2016-12-10 05:02:49 --> Loader Class Initialized
INFO - 2016-12-10 05:02:49 --> Database Driver Class Initialized
INFO - 2016-12-10 05:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:02:49 --> Controller Class Initialized
DEBUG - 2016-12-10 05:02:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:02:49 --> Helper loaded: url_helper
INFO - 2016-12-10 05:02:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:02:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-10 05:02:49 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:49 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:49 --> Severity: Notice --> Undefined variable: total /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:49 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:49 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:49 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:49 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:49 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:49 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:49 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:02:49 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
INFO - 2016-12-10 05:02:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 05:02:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:02:49 --> Final output sent to browser
DEBUG - 2016-12-10 05:02:49 --> Total execution time: 0.0150
INFO - 2016-12-10 05:02:50 --> Config Class Initialized
INFO - 2016-12-10 05:02:50 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:02:50 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:02:50 --> Utf8 Class Initialized
INFO - 2016-12-10 05:02:50 --> URI Class Initialized
INFO - 2016-12-10 05:02:50 --> Router Class Initialized
INFO - 2016-12-10 05:02:50 --> Output Class Initialized
INFO - 2016-12-10 05:02:50 --> Security Class Initialized
DEBUG - 2016-12-10 05:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:02:50 --> Input Class Initialized
INFO - 2016-12-10 05:02:50 --> Language Class Initialized
INFO - 2016-12-10 05:02:50 --> Loader Class Initialized
INFO - 2016-12-10 05:02:50 --> Database Driver Class Initialized
INFO - 2016-12-10 05:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:02:50 --> Controller Class Initialized
INFO - 2016-12-10 05:02:50 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:02:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:02:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:02:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 05:02:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 05:02:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:02:50 --> Final output sent to browser
DEBUG - 2016-12-10 05:02:50 --> Total execution time: 0.0140
INFO - 2016-12-10 05:03:28 --> Config Class Initialized
INFO - 2016-12-10 05:03:28 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:03:28 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:03:28 --> Utf8 Class Initialized
INFO - 2016-12-10 05:03:28 --> URI Class Initialized
INFO - 2016-12-10 05:03:28 --> Router Class Initialized
INFO - 2016-12-10 05:03:28 --> Output Class Initialized
INFO - 2016-12-10 05:03:28 --> Security Class Initialized
DEBUG - 2016-12-10 05:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:03:28 --> Input Class Initialized
INFO - 2016-12-10 05:03:28 --> Language Class Initialized
INFO - 2016-12-10 05:03:28 --> Loader Class Initialized
INFO - 2016-12-10 05:03:28 --> Database Driver Class Initialized
INFO - 2016-12-10 05:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:03:28 --> Controller Class Initialized
DEBUG - 2016-12-10 05:03:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:03:28 --> Helper loaded: url_helper
INFO - 2016-12-10 05:03:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:03:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-10 05:03:28 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:03:28 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:03:28 --> Severity: Notice --> Undefined variable: total /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:03:28 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:03:28 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:03:28 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:03:28 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:03:28 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:03:28 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:03:28 --> Severity: Notice --> Undefined variable: prodcuto /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
ERROR - 2016-12-10 05:03:28 --> Severity: Notice --> Trying to get property of non-object /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
INFO - 2016-12-10 05:03:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 05:03:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:03:28 --> Final output sent to browser
DEBUG - 2016-12-10 05:03:28 --> Total execution time: 0.0238
INFO - 2016-12-10 05:03:28 --> Config Class Initialized
INFO - 2016-12-10 05:03:28 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:03:28 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:03:28 --> Utf8 Class Initialized
INFO - 2016-12-10 05:03:28 --> URI Class Initialized
INFO - 2016-12-10 05:03:28 --> Router Class Initialized
INFO - 2016-12-10 05:03:28 --> Output Class Initialized
INFO - 2016-12-10 05:03:28 --> Security Class Initialized
DEBUG - 2016-12-10 05:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:03:28 --> Input Class Initialized
INFO - 2016-12-10 05:03:28 --> Language Class Initialized
INFO - 2016-12-10 05:03:28 --> Loader Class Initialized
INFO - 2016-12-10 05:03:28 --> Database Driver Class Initialized
INFO - 2016-12-10 05:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:03:28 --> Controller Class Initialized
INFO - 2016-12-10 05:03:28 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:03:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:03:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:03:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 05:03:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 05:03:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:03:28 --> Final output sent to browser
DEBUG - 2016-12-10 05:03:28 --> Total execution time: 0.0139
INFO - 2016-12-10 05:03:30 --> Config Class Initialized
INFO - 2016-12-10 05:03:30 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:03:30 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:03:30 --> Utf8 Class Initialized
INFO - 2016-12-10 05:03:30 --> URI Class Initialized
INFO - 2016-12-10 05:03:30 --> Router Class Initialized
INFO - 2016-12-10 05:03:30 --> Output Class Initialized
INFO - 2016-12-10 05:03:30 --> Security Class Initialized
DEBUG - 2016-12-10 05:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:03:30 --> Input Class Initialized
INFO - 2016-12-10 05:03:30 --> Language Class Initialized
INFO - 2016-12-10 05:03:31 --> Loader Class Initialized
INFO - 2016-12-10 05:03:31 --> Database Driver Class Initialized
INFO - 2016-12-10 05:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:03:31 --> Controller Class Initialized
DEBUG - 2016-12-10 05:03:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:03:31 --> Helper loaded: url_helper
INFO - 2016-12-10 05:03:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:03:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-10 05:03:31 --> Severity: Notice --> Undefined variable: total /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
INFO - 2016-12-10 05:03:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 05:03:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:03:31 --> Final output sent to browser
DEBUG - 2016-12-10 05:03:31 --> Total execution time: 0.0662
INFO - 2016-12-10 05:03:31 --> Config Class Initialized
INFO - 2016-12-10 05:03:31 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:03:31 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:03:31 --> Utf8 Class Initialized
INFO - 2016-12-10 05:03:31 --> URI Class Initialized
INFO - 2016-12-10 05:03:31 --> Router Class Initialized
INFO - 2016-12-10 05:03:31 --> Output Class Initialized
INFO - 2016-12-10 05:03:31 --> Security Class Initialized
DEBUG - 2016-12-10 05:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:03:31 --> Input Class Initialized
INFO - 2016-12-10 05:03:31 --> Language Class Initialized
INFO - 2016-12-10 05:03:31 --> Loader Class Initialized
INFO - 2016-12-10 05:03:31 --> Database Driver Class Initialized
INFO - 2016-12-10 05:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:03:31 --> Controller Class Initialized
INFO - 2016-12-10 05:03:31 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:03:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:03:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:03:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 05:03:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 05:03:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:03:31 --> Final output sent to browser
DEBUG - 2016-12-10 05:03:31 --> Total execution time: 0.0142
INFO - 2016-12-10 05:04:01 --> Config Class Initialized
INFO - 2016-12-10 05:04:01 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:04:01 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:04:01 --> Utf8 Class Initialized
INFO - 2016-12-10 05:04:01 --> URI Class Initialized
INFO - 2016-12-10 05:04:01 --> Router Class Initialized
INFO - 2016-12-10 05:04:01 --> Output Class Initialized
INFO - 2016-12-10 05:04:01 --> Security Class Initialized
DEBUG - 2016-12-10 05:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:04:01 --> Input Class Initialized
INFO - 2016-12-10 05:04:01 --> Language Class Initialized
INFO - 2016-12-10 05:04:01 --> Loader Class Initialized
INFO - 2016-12-10 05:04:01 --> Database Driver Class Initialized
INFO - 2016-12-10 05:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:04:01 --> Controller Class Initialized
DEBUG - 2016-12-10 05:04:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:04:01 --> Helper loaded: url_helper
INFO - 2016-12-10 05:04:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:04:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 05:04:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 05:04:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:04:01 --> Final output sent to browser
DEBUG - 2016-12-10 05:04:01 --> Total execution time: 0.0211
INFO - 2016-12-10 05:04:02 --> Config Class Initialized
INFO - 2016-12-10 05:04:02 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:04:02 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:04:02 --> Utf8 Class Initialized
INFO - 2016-12-10 05:04:02 --> URI Class Initialized
INFO - 2016-12-10 05:04:02 --> Router Class Initialized
INFO - 2016-12-10 05:04:02 --> Output Class Initialized
INFO - 2016-12-10 05:04:02 --> Security Class Initialized
DEBUG - 2016-12-10 05:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:04:02 --> Input Class Initialized
INFO - 2016-12-10 05:04:02 --> Language Class Initialized
INFO - 2016-12-10 05:04:02 --> Loader Class Initialized
INFO - 2016-12-10 05:04:02 --> Database Driver Class Initialized
INFO - 2016-12-10 05:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:04:02 --> Controller Class Initialized
INFO - 2016-12-10 05:04:02 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:04:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:04:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:04:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 05:04:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 05:04:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:04:02 --> Final output sent to browser
DEBUG - 2016-12-10 05:04:02 --> Total execution time: 0.0143
INFO - 2016-12-10 05:46:54 --> Config Class Initialized
INFO - 2016-12-10 05:46:54 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:46:54 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:46:54 --> Utf8 Class Initialized
INFO - 2016-12-10 05:46:54 --> URI Class Initialized
INFO - 2016-12-10 05:46:54 --> Router Class Initialized
INFO - 2016-12-10 05:46:54 --> Output Class Initialized
INFO - 2016-12-10 05:46:54 --> Security Class Initialized
DEBUG - 2016-12-10 05:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:46:54 --> Input Class Initialized
INFO - 2016-12-10 05:46:54 --> Language Class Initialized
INFO - 2016-12-10 05:46:54 --> Loader Class Initialized
INFO - 2016-12-10 05:46:54 --> Database Driver Class Initialized
INFO - 2016-12-10 05:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:46:54 --> Controller Class Initialized
DEBUG - 2016-12-10 05:46:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:46:54 --> Helper loaded: url_helper
INFO - 2016-12-10 05:46:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:46:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-10 05:46:54 --> Query error: Unknown column 'bl_registro_lugares.lugar_1' in 'field list' - Invalid query: SELECT `bl_registro_lugares`.`lugar_1`, `tbl_registro_lugares`.`lugar_2`, `tbl_registro_lugares`.`numero_infantes`, `tbl_graduacion`.`costo_10`, `tbl_graduacion`.`costo_12`, `tbl_graduacion`.`costo_18`, `tbl_graduacion`.`costo_infante`, `tbl_registro_lugares`.`id_tipo_lugar`
FROM `tbl_registro_lugares`
JOIN `tbl_graduacion` ON `tbl_graduacion`.`id_graduacion` = `tbl_registro_lugares`.`id_graduacion`
WHERE `tbl_persona_productos`.`id_persona` = '5'
AND `tbl_persona_productos`.`id_graduacion` = '26'
INFO - 2016-12-10 05:46:55 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-10 05:46:55 --> Config Class Initialized
INFO - 2016-12-10 05:46:55 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:46:55 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:46:55 --> Utf8 Class Initialized
INFO - 2016-12-10 05:46:55 --> URI Class Initialized
INFO - 2016-12-10 05:46:55 --> Router Class Initialized
INFO - 2016-12-10 05:46:55 --> Output Class Initialized
INFO - 2016-12-10 05:46:55 --> Security Class Initialized
DEBUG - 2016-12-10 05:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:46:55 --> Input Class Initialized
INFO - 2016-12-10 05:46:55 --> Language Class Initialized
INFO - 2016-12-10 05:46:55 --> Loader Class Initialized
INFO - 2016-12-10 05:46:55 --> Database Driver Class Initialized
INFO - 2016-12-10 05:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:46:55 --> Controller Class Initialized
INFO - 2016-12-10 05:46:55 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:46:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:46:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:46:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 05:46:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 05:46:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:46:55 --> Final output sent to browser
DEBUG - 2016-12-10 05:46:55 --> Total execution time: 0.1209
INFO - 2016-12-10 05:47:13 --> Config Class Initialized
INFO - 2016-12-10 05:47:13 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:47:13 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:47:13 --> Utf8 Class Initialized
INFO - 2016-12-10 05:47:13 --> URI Class Initialized
INFO - 2016-12-10 05:47:13 --> Router Class Initialized
INFO - 2016-12-10 05:47:13 --> Output Class Initialized
INFO - 2016-12-10 05:47:13 --> Security Class Initialized
DEBUG - 2016-12-10 05:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:47:13 --> Input Class Initialized
INFO - 2016-12-10 05:47:13 --> Language Class Initialized
INFO - 2016-12-10 05:47:13 --> Loader Class Initialized
INFO - 2016-12-10 05:47:13 --> Database Driver Class Initialized
INFO - 2016-12-10 05:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:47:13 --> Controller Class Initialized
DEBUG - 2016-12-10 05:47:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:47:13 --> Helper loaded: url_helper
INFO - 2016-12-10 05:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-10 05:47:13 --> Query error: Unknown column 'tbl_persona_productos.id_persona' in 'where clause' - Invalid query: SELECT `tbl_registro_lugares`.`lugar_1`, `tbl_registro_lugares`.`lugar_2`, `tbl_registro_lugares`.`numero_infantes`, `tbl_graduacion`.`costo_10`, `tbl_graduacion`.`costo_12`, `tbl_graduacion`.`costo_18`, `tbl_graduacion`.`costo_infante`, `tbl_registro_lugares`.`id_tipo_lugar`
FROM `tbl_registro_lugares`
JOIN `tbl_graduacion` ON `tbl_graduacion`.`id_graduacion` = `tbl_registro_lugares`.`id_graduacion`
WHERE `tbl_persona_productos`.`id_persona` = '5'
AND `tbl_persona_productos`.`id_graduacion` = '26'
INFO - 2016-12-10 05:47:13 --> Language file loaded: language/english/db_lang.php
INFO - 2016-12-10 05:47:13 --> Config Class Initialized
INFO - 2016-12-10 05:47:13 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:47:13 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:47:13 --> Utf8 Class Initialized
INFO - 2016-12-10 05:47:13 --> URI Class Initialized
INFO - 2016-12-10 05:47:13 --> Router Class Initialized
INFO - 2016-12-10 05:47:13 --> Output Class Initialized
INFO - 2016-12-10 05:47:13 --> Security Class Initialized
DEBUG - 2016-12-10 05:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:47:13 --> Input Class Initialized
INFO - 2016-12-10 05:47:13 --> Language Class Initialized
INFO - 2016-12-10 05:47:13 --> Loader Class Initialized
INFO - 2016-12-10 05:47:13 --> Database Driver Class Initialized
INFO - 2016-12-10 05:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:47:13 --> Controller Class Initialized
INFO - 2016-12-10 05:47:13 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:47:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 05:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 05:47:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:47:13 --> Final output sent to browser
DEBUG - 2016-12-10 05:47:13 --> Total execution time: 0.0138
INFO - 2016-12-10 05:47:46 --> Config Class Initialized
INFO - 2016-12-10 05:47:46 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:47:46 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:47:46 --> Utf8 Class Initialized
INFO - 2016-12-10 05:47:46 --> URI Class Initialized
INFO - 2016-12-10 05:47:46 --> Router Class Initialized
INFO - 2016-12-10 05:47:46 --> Output Class Initialized
INFO - 2016-12-10 05:47:46 --> Security Class Initialized
DEBUG - 2016-12-10 05:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:47:46 --> Input Class Initialized
INFO - 2016-12-10 05:47:46 --> Language Class Initialized
INFO - 2016-12-10 05:47:46 --> Loader Class Initialized
INFO - 2016-12-10 05:47:46 --> Database Driver Class Initialized
INFO - 2016-12-10 05:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:47:46 --> Controller Class Initialized
DEBUG - 2016-12-10 05:47:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:47:46 --> Helper loaded: url_helper
INFO - 2016-12-10 05:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:47:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-10 05:47:46 --> Severity: Parsing Error --> syntax error, unexpected '1.' (T_DNUMBER), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /home/graduafe/public_html/application/views/usuario/pages/saldo.php 53
INFO - 2016-12-10 05:47:47 --> Config Class Initialized
INFO - 2016-12-10 05:47:47 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:47:47 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:47:47 --> Utf8 Class Initialized
INFO - 2016-12-10 05:47:47 --> URI Class Initialized
INFO - 2016-12-10 05:47:47 --> Router Class Initialized
INFO - 2016-12-10 05:47:47 --> Output Class Initialized
INFO - 2016-12-10 05:47:47 --> Security Class Initialized
DEBUG - 2016-12-10 05:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:47:47 --> Input Class Initialized
INFO - 2016-12-10 05:47:47 --> Language Class Initialized
INFO - 2016-12-10 05:47:47 --> Loader Class Initialized
INFO - 2016-12-10 05:47:47 --> Database Driver Class Initialized
INFO - 2016-12-10 05:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:47:47 --> Controller Class Initialized
INFO - 2016-12-10 05:47:47 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:47:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 05:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 05:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:47:47 --> Final output sent to browser
DEBUG - 2016-12-10 05:47:47 --> Total execution time: 0.0432
INFO - 2016-12-10 05:49:01 --> Config Class Initialized
INFO - 2016-12-10 05:49:01 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:49:01 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:49:01 --> Utf8 Class Initialized
INFO - 2016-12-10 05:49:01 --> URI Class Initialized
INFO - 2016-12-10 05:49:01 --> Router Class Initialized
INFO - 2016-12-10 05:49:01 --> Output Class Initialized
INFO - 2016-12-10 05:49:01 --> Security Class Initialized
DEBUG - 2016-12-10 05:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:49:01 --> Input Class Initialized
INFO - 2016-12-10 05:49:01 --> Language Class Initialized
INFO - 2016-12-10 05:49:01 --> Loader Class Initialized
INFO - 2016-12-10 05:49:01 --> Database Driver Class Initialized
INFO - 2016-12-10 05:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:49:01 --> Controller Class Initialized
DEBUG - 2016-12-10 05:49:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:49:01 --> Helper loaded: url_helper
INFO - 2016-12-10 05:49:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:49:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-10 05:49:01 --> Severity: Parsing Error --> syntax error, unexpected '1.' (T_DNUMBER), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /home/graduafe/public_html/application/views/usuario/pages/saldo.php 53
INFO - 2016-12-10 05:49:01 --> Config Class Initialized
INFO - 2016-12-10 05:49:01 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:49:01 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:49:01 --> Utf8 Class Initialized
INFO - 2016-12-10 05:49:01 --> URI Class Initialized
INFO - 2016-12-10 05:49:01 --> Router Class Initialized
INFO - 2016-12-10 05:49:01 --> Output Class Initialized
INFO - 2016-12-10 05:49:01 --> Security Class Initialized
DEBUG - 2016-12-10 05:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:49:01 --> Input Class Initialized
INFO - 2016-12-10 05:49:01 --> Language Class Initialized
INFO - 2016-12-10 05:49:01 --> Loader Class Initialized
INFO - 2016-12-10 05:49:01 --> Database Driver Class Initialized
INFO - 2016-12-10 05:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:49:01 --> Controller Class Initialized
INFO - 2016-12-10 05:49:01 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:49:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:49:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:49:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 05:49:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 05:49:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:49:01 --> Final output sent to browser
DEBUG - 2016-12-10 05:49:01 --> Total execution time: 0.0138
INFO - 2016-12-10 05:49:03 --> Config Class Initialized
INFO - 2016-12-10 05:49:03 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:49:03 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:49:03 --> Utf8 Class Initialized
INFO - 2016-12-10 05:49:03 --> URI Class Initialized
INFO - 2016-12-10 05:49:03 --> Router Class Initialized
INFO - 2016-12-10 05:49:03 --> Output Class Initialized
INFO - 2016-12-10 05:49:03 --> Security Class Initialized
DEBUG - 2016-12-10 05:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:49:03 --> Input Class Initialized
INFO - 2016-12-10 05:49:03 --> Language Class Initialized
INFO - 2016-12-10 05:49:03 --> Loader Class Initialized
INFO - 2016-12-10 05:49:03 --> Database Driver Class Initialized
INFO - 2016-12-10 05:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:49:03 --> Controller Class Initialized
DEBUG - 2016-12-10 05:49:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:49:03 --> Helper loaded: url_helper
INFO - 2016-12-10 05:49:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:49:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-10 05:49:03 --> Severity: Parsing Error --> syntax error, unexpected '1.' (T_DNUMBER), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /home/graduafe/public_html/application/views/usuario/pages/saldo.php 53
INFO - 2016-12-10 05:49:03 --> Config Class Initialized
INFO - 2016-12-10 05:49:03 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:49:03 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:49:03 --> Utf8 Class Initialized
INFO - 2016-12-10 05:49:03 --> URI Class Initialized
INFO - 2016-12-10 05:49:03 --> Router Class Initialized
INFO - 2016-12-10 05:49:03 --> Output Class Initialized
INFO - 2016-12-10 05:49:03 --> Security Class Initialized
DEBUG - 2016-12-10 05:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:49:03 --> Input Class Initialized
INFO - 2016-12-10 05:49:03 --> Language Class Initialized
INFO - 2016-12-10 05:49:03 --> Loader Class Initialized
INFO - 2016-12-10 05:49:03 --> Database Driver Class Initialized
INFO - 2016-12-10 05:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:49:03 --> Controller Class Initialized
INFO - 2016-12-10 05:49:03 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:49:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:49:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:49:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 05:49:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 05:49:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:49:03 --> Final output sent to browser
DEBUG - 2016-12-10 05:49:03 --> Total execution time: 0.0143
INFO - 2016-12-10 05:49:04 --> Config Class Initialized
INFO - 2016-12-10 05:49:04 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:49:04 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:49:04 --> Utf8 Class Initialized
INFO - 2016-12-10 05:49:04 --> URI Class Initialized
INFO - 2016-12-10 05:49:04 --> Router Class Initialized
INFO - 2016-12-10 05:49:04 --> Output Class Initialized
INFO - 2016-12-10 05:49:04 --> Security Class Initialized
DEBUG - 2016-12-10 05:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:49:04 --> Input Class Initialized
INFO - 2016-12-10 05:49:04 --> Language Class Initialized
INFO - 2016-12-10 05:49:04 --> Loader Class Initialized
INFO - 2016-12-10 05:49:04 --> Database Driver Class Initialized
INFO - 2016-12-10 05:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:49:04 --> Controller Class Initialized
DEBUG - 2016-12-10 05:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:49:04 --> Helper loaded: url_helper
INFO - 2016-12-10 05:49:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:49:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-10 05:49:04 --> Severity: Parsing Error --> syntax error, unexpected '1.' (T_DNUMBER), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /home/graduafe/public_html/application/views/usuario/pages/saldo.php 53
INFO - 2016-12-10 05:49:04 --> Config Class Initialized
INFO - 2016-12-10 05:49:04 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:49:04 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:49:04 --> Utf8 Class Initialized
INFO - 2016-12-10 05:49:04 --> URI Class Initialized
INFO - 2016-12-10 05:49:04 --> Router Class Initialized
INFO - 2016-12-10 05:49:04 --> Output Class Initialized
INFO - 2016-12-10 05:49:04 --> Security Class Initialized
DEBUG - 2016-12-10 05:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:49:04 --> Input Class Initialized
INFO - 2016-12-10 05:49:04 --> Language Class Initialized
INFO - 2016-12-10 05:49:04 --> Loader Class Initialized
INFO - 2016-12-10 05:49:04 --> Database Driver Class Initialized
INFO - 2016-12-10 05:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:49:04 --> Controller Class Initialized
INFO - 2016-12-10 05:49:04 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:49:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:49:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 05:49:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 05:49:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:49:04 --> Final output sent to browser
DEBUG - 2016-12-10 05:49:04 --> Total execution time: 0.0136
INFO - 2016-12-10 05:49:26 --> Config Class Initialized
INFO - 2016-12-10 05:49:26 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:49:26 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:49:26 --> Utf8 Class Initialized
INFO - 2016-12-10 05:49:26 --> URI Class Initialized
INFO - 2016-12-10 05:49:26 --> Router Class Initialized
INFO - 2016-12-10 05:49:26 --> Output Class Initialized
INFO - 2016-12-10 05:49:26 --> Security Class Initialized
DEBUG - 2016-12-10 05:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:49:26 --> Input Class Initialized
INFO - 2016-12-10 05:49:26 --> Language Class Initialized
INFO - 2016-12-10 05:49:26 --> Loader Class Initialized
INFO - 2016-12-10 05:49:26 --> Database Driver Class Initialized
INFO - 2016-12-10 05:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:49:26 --> Controller Class Initialized
DEBUG - 2016-12-10 05:49:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:49:26 --> Helper loaded: url_helper
INFO - 2016-12-10 05:49:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:49:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-10 05:49:26 --> Severity: Parsing Error --> syntax error, unexpected end of file /home/graduafe/public_html/application/views/usuario/pages/saldo.php 55
INFO - 2016-12-10 05:49:26 --> Config Class Initialized
INFO - 2016-12-10 05:49:26 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:49:26 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:49:26 --> Utf8 Class Initialized
INFO - 2016-12-10 05:49:26 --> URI Class Initialized
INFO - 2016-12-10 05:49:26 --> Router Class Initialized
INFO - 2016-12-10 05:49:26 --> Output Class Initialized
INFO - 2016-12-10 05:49:26 --> Security Class Initialized
DEBUG - 2016-12-10 05:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:49:26 --> Input Class Initialized
INFO - 2016-12-10 05:49:26 --> Language Class Initialized
INFO - 2016-12-10 05:49:26 --> Loader Class Initialized
INFO - 2016-12-10 05:49:26 --> Database Driver Class Initialized
INFO - 2016-12-10 05:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:49:26 --> Controller Class Initialized
INFO - 2016-12-10 05:49:26 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:49:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:49:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:49:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 05:49:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 05:49:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:49:26 --> Final output sent to browser
DEBUG - 2016-12-10 05:49:26 --> Total execution time: 0.0131
INFO - 2016-12-10 05:50:05 --> Config Class Initialized
INFO - 2016-12-10 05:50:05 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:50:05 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:50:05 --> Utf8 Class Initialized
INFO - 2016-12-10 05:50:05 --> URI Class Initialized
INFO - 2016-12-10 05:50:05 --> Router Class Initialized
INFO - 2016-12-10 05:50:05 --> Output Class Initialized
INFO - 2016-12-10 05:50:05 --> Security Class Initialized
DEBUG - 2016-12-10 05:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:50:05 --> Input Class Initialized
INFO - 2016-12-10 05:50:05 --> Language Class Initialized
INFO - 2016-12-10 05:50:05 --> Loader Class Initialized
INFO - 2016-12-10 05:50:05 --> Database Driver Class Initialized
INFO - 2016-12-10 05:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:50:05 --> Controller Class Initialized
DEBUG - 2016-12-10 05:50:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:50:05 --> Helper loaded: url_helper
INFO - 2016-12-10 05:50:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:50:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-10 05:50:05 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/graduafe/public_html/application/views/usuario/pages/saldo.php 79
INFO - 2016-12-10 05:50:05 --> Config Class Initialized
INFO - 2016-12-10 05:50:05 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:50:05 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:50:05 --> Utf8 Class Initialized
INFO - 2016-12-10 05:50:05 --> URI Class Initialized
INFO - 2016-12-10 05:50:05 --> Router Class Initialized
INFO - 2016-12-10 05:50:05 --> Output Class Initialized
INFO - 2016-12-10 05:50:05 --> Security Class Initialized
DEBUG - 2016-12-10 05:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:50:05 --> Input Class Initialized
INFO - 2016-12-10 05:50:05 --> Language Class Initialized
INFO - 2016-12-10 05:50:05 --> Loader Class Initialized
INFO - 2016-12-10 05:50:05 --> Database Driver Class Initialized
INFO - 2016-12-10 05:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:50:05 --> Controller Class Initialized
INFO - 2016-12-10 05:50:05 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:50:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:50:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:50:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 05:50:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 05:50:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:50:05 --> Final output sent to browser
DEBUG - 2016-12-10 05:50:05 --> Total execution time: 0.0133
INFO - 2016-12-10 05:50:06 --> Config Class Initialized
INFO - 2016-12-10 05:50:06 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:50:06 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:50:06 --> Utf8 Class Initialized
INFO - 2016-12-10 05:50:06 --> URI Class Initialized
INFO - 2016-12-10 05:50:06 --> Router Class Initialized
INFO - 2016-12-10 05:50:06 --> Output Class Initialized
INFO - 2016-12-10 05:50:06 --> Security Class Initialized
DEBUG - 2016-12-10 05:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:50:06 --> Input Class Initialized
INFO - 2016-12-10 05:50:06 --> Language Class Initialized
INFO - 2016-12-10 05:50:06 --> Loader Class Initialized
INFO - 2016-12-10 05:50:06 --> Database Driver Class Initialized
INFO - 2016-12-10 05:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:50:06 --> Controller Class Initialized
DEBUG - 2016-12-10 05:50:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:50:06 --> Helper loaded: url_helper
INFO - 2016-12-10 05:50:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:50:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-10 05:50:06 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting ',' or ';' /home/graduafe/public_html/application/views/usuario/pages/saldo.php 35
INFO - 2016-12-10 05:50:06 --> Config Class Initialized
INFO - 2016-12-10 05:50:06 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:50:06 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:50:06 --> Utf8 Class Initialized
INFO - 2016-12-10 05:50:06 --> URI Class Initialized
INFO - 2016-12-10 05:50:06 --> Router Class Initialized
INFO - 2016-12-10 05:50:06 --> Output Class Initialized
INFO - 2016-12-10 05:50:06 --> Security Class Initialized
DEBUG - 2016-12-10 05:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:50:06 --> Input Class Initialized
INFO - 2016-12-10 05:50:06 --> Language Class Initialized
INFO - 2016-12-10 05:50:06 --> Loader Class Initialized
INFO - 2016-12-10 05:50:06 --> Database Driver Class Initialized
INFO - 2016-12-10 05:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:50:06 --> Controller Class Initialized
INFO - 2016-12-10 05:50:06 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:50:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:50:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:50:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 05:50:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 05:50:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:50:06 --> Final output sent to browser
DEBUG - 2016-12-10 05:50:06 --> Total execution time: 0.0137
INFO - 2016-12-10 05:50:08 --> Config Class Initialized
INFO - 2016-12-10 05:50:08 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:50:08 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:50:08 --> Utf8 Class Initialized
INFO - 2016-12-10 05:50:08 --> URI Class Initialized
INFO - 2016-12-10 05:50:08 --> Router Class Initialized
INFO - 2016-12-10 05:50:08 --> Output Class Initialized
INFO - 2016-12-10 05:50:08 --> Security Class Initialized
DEBUG - 2016-12-10 05:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:50:08 --> Input Class Initialized
INFO - 2016-12-10 05:50:08 --> Language Class Initialized
INFO - 2016-12-10 05:50:08 --> Loader Class Initialized
INFO - 2016-12-10 05:50:08 --> Database Driver Class Initialized
INFO - 2016-12-10 05:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:50:08 --> Controller Class Initialized
DEBUG - 2016-12-10 05:50:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:50:08 --> Helper loaded: url_helper
INFO - 2016-12-10 05:50:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:50:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 05:50:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 05:50:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:50:08 --> Final output sent to browser
DEBUG - 2016-12-10 05:50:08 --> Total execution time: 0.0149
INFO - 2016-12-10 05:50:09 --> Config Class Initialized
INFO - 2016-12-10 05:50:09 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:50:09 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:50:09 --> Utf8 Class Initialized
INFO - 2016-12-10 05:50:09 --> URI Class Initialized
INFO - 2016-12-10 05:50:09 --> Router Class Initialized
INFO - 2016-12-10 05:50:09 --> Output Class Initialized
INFO - 2016-12-10 05:50:09 --> Security Class Initialized
DEBUG - 2016-12-10 05:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:50:09 --> Input Class Initialized
INFO - 2016-12-10 05:50:09 --> Language Class Initialized
INFO - 2016-12-10 05:50:09 --> Loader Class Initialized
INFO - 2016-12-10 05:50:09 --> Database Driver Class Initialized
INFO - 2016-12-10 05:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:50:09 --> Controller Class Initialized
INFO - 2016-12-10 05:50:09 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:50:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:50:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 05:50:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 05:50:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:50:09 --> Final output sent to browser
DEBUG - 2016-12-10 05:50:09 --> Total execution time: 0.0156
INFO - 2016-12-10 05:50:11 --> Config Class Initialized
INFO - 2016-12-10 05:50:11 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:50:11 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:50:11 --> Utf8 Class Initialized
INFO - 2016-12-10 05:50:11 --> URI Class Initialized
INFO - 2016-12-10 05:50:11 --> Router Class Initialized
INFO - 2016-12-10 05:50:11 --> Output Class Initialized
INFO - 2016-12-10 05:50:11 --> Security Class Initialized
DEBUG - 2016-12-10 05:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:50:11 --> Input Class Initialized
INFO - 2016-12-10 05:50:11 --> Language Class Initialized
INFO - 2016-12-10 05:50:11 --> Loader Class Initialized
INFO - 2016-12-10 05:50:11 --> Database Driver Class Initialized
INFO - 2016-12-10 05:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:50:11 --> Controller Class Initialized
DEBUG - 2016-12-10 05:50:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:50:11 --> Helper loaded: url_helper
INFO - 2016-12-10 05:50:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:50:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 05:50:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 05:50:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:50:11 --> Final output sent to browser
DEBUG - 2016-12-10 05:50:11 --> Total execution time: 0.0137
INFO - 2016-12-10 05:50:11 --> Config Class Initialized
INFO - 2016-12-10 05:50:11 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:50:11 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:50:11 --> Utf8 Class Initialized
INFO - 2016-12-10 05:50:11 --> URI Class Initialized
INFO - 2016-12-10 05:50:11 --> Router Class Initialized
INFO - 2016-12-10 05:50:11 --> Output Class Initialized
INFO - 2016-12-10 05:50:11 --> Security Class Initialized
DEBUG - 2016-12-10 05:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:50:11 --> Input Class Initialized
INFO - 2016-12-10 05:50:11 --> Language Class Initialized
INFO - 2016-12-10 05:50:11 --> Loader Class Initialized
INFO - 2016-12-10 05:50:11 --> Database Driver Class Initialized
INFO - 2016-12-10 05:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:50:11 --> Controller Class Initialized
INFO - 2016-12-10 05:50:11 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:50:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:50:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:50:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 05:50:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 05:50:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:50:11 --> Final output sent to browser
DEBUG - 2016-12-10 05:50:11 --> Total execution time: 0.0130
INFO - 2016-12-10 05:50:57 --> Config Class Initialized
INFO - 2016-12-10 05:50:57 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:50:57 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:50:57 --> Utf8 Class Initialized
INFO - 2016-12-10 05:50:57 --> URI Class Initialized
INFO - 2016-12-10 05:50:57 --> Router Class Initialized
INFO - 2016-12-10 05:50:57 --> Output Class Initialized
INFO - 2016-12-10 05:50:57 --> Security Class Initialized
DEBUG - 2016-12-10 05:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:50:57 --> Input Class Initialized
INFO - 2016-12-10 05:50:57 --> Language Class Initialized
INFO - 2016-12-10 05:50:57 --> Loader Class Initialized
INFO - 2016-12-10 05:50:57 --> Database Driver Class Initialized
INFO - 2016-12-10 05:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:50:57 --> Controller Class Initialized
DEBUG - 2016-12-10 05:50:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:50:57 --> Helper loaded: url_helper
INFO - 2016-12-10 05:50:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:50:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 05:50:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 05:50:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:50:57 --> Final output sent to browser
DEBUG - 2016-12-10 05:50:57 --> Total execution time: 0.0138
INFO - 2016-12-10 05:50:58 --> Config Class Initialized
INFO - 2016-12-10 05:50:58 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:50:58 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:50:58 --> Utf8 Class Initialized
INFO - 2016-12-10 05:50:58 --> URI Class Initialized
INFO - 2016-12-10 05:50:58 --> Router Class Initialized
INFO - 2016-12-10 05:50:58 --> Output Class Initialized
INFO - 2016-12-10 05:50:58 --> Security Class Initialized
DEBUG - 2016-12-10 05:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:50:58 --> Input Class Initialized
INFO - 2016-12-10 05:50:58 --> Language Class Initialized
INFO - 2016-12-10 05:50:58 --> Loader Class Initialized
INFO - 2016-12-10 05:50:58 --> Database Driver Class Initialized
INFO - 2016-12-10 05:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:50:58 --> Controller Class Initialized
INFO - 2016-12-10 05:50:58 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:50:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 05:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 05:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:50:58 --> Final output sent to browser
DEBUG - 2016-12-10 05:50:58 --> Total execution time: 0.0141
INFO - 2016-12-10 05:53:09 --> Config Class Initialized
INFO - 2016-12-10 05:53:09 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:53:09 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:53:09 --> Utf8 Class Initialized
INFO - 2016-12-10 05:53:09 --> URI Class Initialized
INFO - 2016-12-10 05:53:09 --> Router Class Initialized
INFO - 2016-12-10 05:53:09 --> Output Class Initialized
INFO - 2016-12-10 05:53:09 --> Security Class Initialized
DEBUG - 2016-12-10 05:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:53:09 --> Input Class Initialized
INFO - 2016-12-10 05:53:09 --> Language Class Initialized
INFO - 2016-12-10 05:53:09 --> Loader Class Initialized
INFO - 2016-12-10 05:53:09 --> Database Driver Class Initialized
INFO - 2016-12-10 05:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:53:09 --> Controller Class Initialized
INFO - 2016-12-10 05:53:09 --> Helper loaded: date_helper
INFO - 2016-12-10 05:53:09 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:53:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:53:09 --> Helper loaded: form_helper
INFO - 2016-12-10 05:53:09 --> Form Validation Class Initialized
INFO - 2016-12-10 05:53:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 05:53:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-10 05:53:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pagos.php
INFO - 2016-12-10 05:53:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pagos.php
INFO - 2016-12-10 05:53:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 05:53:09 --> Final output sent to browser
DEBUG - 2016-12-10 05:53:09 --> Total execution time: 0.1936
INFO - 2016-12-10 05:53:10 --> Config Class Initialized
INFO - 2016-12-10 05:53:10 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:53:10 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:53:10 --> Utf8 Class Initialized
INFO - 2016-12-10 05:53:10 --> URI Class Initialized
INFO - 2016-12-10 05:53:10 --> Router Class Initialized
INFO - 2016-12-10 05:53:10 --> Output Class Initialized
INFO - 2016-12-10 05:53:10 --> Security Class Initialized
DEBUG - 2016-12-10 05:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:53:10 --> Input Class Initialized
INFO - 2016-12-10 05:53:10 --> Language Class Initialized
INFO - 2016-12-10 05:53:10 --> Loader Class Initialized
INFO - 2016-12-10 05:53:10 --> Database Driver Class Initialized
INFO - 2016-12-10 05:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:53:10 --> Controller Class Initialized
INFO - 2016-12-10 05:53:10 --> Helper loaded: date_helper
INFO - 2016-12-10 05:53:10 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:53:10 --> Helper loaded: form_helper
INFO - 2016-12-10 05:53:10 --> Form Validation Class Initialized
INFO - 2016-12-10 05:53:10 --> Final output sent to browser
DEBUG - 2016-12-10 05:53:10 --> Total execution time: 0.0147
INFO - 2016-12-10 05:53:10 --> Config Class Initialized
INFO - 2016-12-10 05:53:10 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:53:10 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:53:10 --> Utf8 Class Initialized
INFO - 2016-12-10 05:53:10 --> URI Class Initialized
INFO - 2016-12-10 05:53:10 --> Router Class Initialized
INFO - 2016-12-10 05:53:10 --> Output Class Initialized
INFO - 2016-12-10 05:53:10 --> Security Class Initialized
DEBUG - 2016-12-10 05:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:53:10 --> Input Class Initialized
INFO - 2016-12-10 05:53:10 --> Language Class Initialized
INFO - 2016-12-10 05:53:10 --> Loader Class Initialized
INFO - 2016-12-10 05:53:10 --> Database Driver Class Initialized
INFO - 2016-12-10 05:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:53:10 --> Controller Class Initialized
INFO - 2016-12-10 05:53:10 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:53:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:53:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 05:53:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 05:53:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:53:10 --> Final output sent to browser
DEBUG - 2016-12-10 05:53:10 --> Total execution time: 0.0137
INFO - 2016-12-10 05:53:12 --> Config Class Initialized
INFO - 2016-12-10 05:53:12 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:53:12 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:53:12 --> Utf8 Class Initialized
INFO - 2016-12-10 05:53:12 --> URI Class Initialized
INFO - 2016-12-10 05:53:12 --> Router Class Initialized
INFO - 2016-12-10 05:53:12 --> Output Class Initialized
INFO - 2016-12-10 05:53:12 --> Security Class Initialized
DEBUG - 2016-12-10 05:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:53:12 --> Input Class Initialized
INFO - 2016-12-10 05:53:12 --> Language Class Initialized
INFO - 2016-12-10 05:53:12 --> Loader Class Initialized
INFO - 2016-12-10 05:53:12 --> Database Driver Class Initialized
INFO - 2016-12-10 05:53:12 --> Config Class Initialized
INFO - 2016-12-10 05:53:12 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:53:12 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:53:12 --> Utf8 Class Initialized
INFO - 2016-12-10 05:53:12 --> URI Class Initialized
INFO - 2016-12-10 05:53:12 --> Router Class Initialized
INFO - 2016-12-10 05:53:12 --> Output Class Initialized
INFO - 2016-12-10 05:53:12 --> Security Class Initialized
DEBUG - 2016-12-10 05:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:53:12 --> Input Class Initialized
INFO - 2016-12-10 05:53:12 --> Language Class Initialized
INFO - 2016-12-10 05:53:12 --> Loader Class Initialized
INFO - 2016-12-10 05:53:12 --> Database Driver Class Initialized
INFO - 2016-12-10 05:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:53:12 --> Controller Class Initialized
INFO - 2016-12-10 05:53:12 --> Helper loaded: date_helper
INFO - 2016-12-10 05:53:12 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:53:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:53:12 --> Helper loaded: form_helper
INFO - 2016-12-10 05:53:12 --> Form Validation Class Initialized
INFO - 2016-12-10 05:53:12 --> Final output sent to browser
DEBUG - 2016-12-10 05:53:12 --> Total execution time: 0.0845
INFO - 2016-12-10 05:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:53:12 --> Controller Class Initialized
INFO - 2016-12-10 05:53:12 --> Helper loaded: date_helper
INFO - 2016-12-10 05:53:12 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:53:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:53:12 --> Helper loaded: form_helper
INFO - 2016-12-10 05:53:12 --> Form Validation Class Initialized
INFO - 2016-12-10 05:53:12 --> Final output sent to browser
DEBUG - 2016-12-10 05:53:12 --> Total execution time: 0.0310
INFO - 2016-12-10 05:59:50 --> Config Class Initialized
INFO - 2016-12-10 05:59:50 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:59:50 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:59:50 --> Utf8 Class Initialized
INFO - 2016-12-10 05:59:50 --> URI Class Initialized
INFO - 2016-12-10 05:59:50 --> Router Class Initialized
INFO - 2016-12-10 05:59:50 --> Output Class Initialized
INFO - 2016-12-10 05:59:50 --> Security Class Initialized
DEBUG - 2016-12-10 05:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:59:50 --> Input Class Initialized
INFO - 2016-12-10 05:59:50 --> Language Class Initialized
INFO - 2016-12-10 05:59:50 --> Loader Class Initialized
INFO - 2016-12-10 05:59:50 --> Database Driver Class Initialized
INFO - 2016-12-10 05:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:59:50 --> Controller Class Initialized
DEBUG - 2016-12-10 05:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:59:50 --> Helper loaded: url_helper
INFO - 2016-12-10 05:59:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:59:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 05:59:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 05:59:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:59:50 --> Final output sent to browser
DEBUG - 2016-12-10 05:59:50 --> Total execution time: 0.0145
INFO - 2016-12-10 05:59:51 --> Config Class Initialized
INFO - 2016-12-10 05:59:51 --> Hooks Class Initialized
DEBUG - 2016-12-10 05:59:51 --> UTF-8 Support Enabled
INFO - 2016-12-10 05:59:51 --> Utf8 Class Initialized
INFO - 2016-12-10 05:59:51 --> URI Class Initialized
INFO - 2016-12-10 05:59:51 --> Router Class Initialized
INFO - 2016-12-10 05:59:51 --> Output Class Initialized
INFO - 2016-12-10 05:59:51 --> Security Class Initialized
DEBUG - 2016-12-10 05:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 05:59:51 --> Input Class Initialized
INFO - 2016-12-10 05:59:51 --> Language Class Initialized
INFO - 2016-12-10 05:59:51 --> Loader Class Initialized
INFO - 2016-12-10 05:59:51 --> Database Driver Class Initialized
INFO - 2016-12-10 05:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 05:59:51 --> Controller Class Initialized
INFO - 2016-12-10 05:59:51 --> Helper loaded: url_helper
DEBUG - 2016-12-10 05:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 05:59:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 05:59:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 05:59:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 05:59:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 05:59:51 --> Final output sent to browser
DEBUG - 2016-12-10 05:59:51 --> Total execution time: 0.0133
INFO - 2016-12-10 06:01:37 --> Config Class Initialized
INFO - 2016-12-10 06:01:37 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:01:37 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:01:37 --> Utf8 Class Initialized
INFO - 2016-12-10 06:01:37 --> URI Class Initialized
INFO - 2016-12-10 06:01:37 --> Router Class Initialized
INFO - 2016-12-10 06:01:37 --> Output Class Initialized
INFO - 2016-12-10 06:01:37 --> Security Class Initialized
DEBUG - 2016-12-10 06:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:01:37 --> Input Class Initialized
INFO - 2016-12-10 06:01:37 --> Language Class Initialized
INFO - 2016-12-10 06:01:37 --> Loader Class Initialized
INFO - 2016-12-10 06:01:37 --> Database Driver Class Initialized
INFO - 2016-12-10 06:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:01:37 --> Controller Class Initialized
INFO - 2016-12-10 06:01:37 --> Upload Class Initialized
INFO - 2016-12-10 06:01:38 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:01:38 --> Helper loaded: form_helper
INFO - 2016-12-10 06:01:38 --> Form Validation Class Initialized
INFO - 2016-12-10 06:01:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 06:01:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-10 06:01:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2016-12-10 06:01:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2016-12-10 06:01:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-10 06:01:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 06:01:38 --> Final output sent to browser
DEBUG - 2016-12-10 06:01:38 --> Total execution time: 1.4639
INFO - 2016-12-10 06:01:39 --> Config Class Initialized
INFO - 2016-12-10 06:01:39 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:01:39 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:01:39 --> Utf8 Class Initialized
INFO - 2016-12-10 06:01:39 --> URI Class Initialized
INFO - 2016-12-10 06:01:39 --> Router Class Initialized
INFO - 2016-12-10 06:01:39 --> Output Class Initialized
INFO - 2016-12-10 06:01:39 --> Security Class Initialized
DEBUG - 2016-12-10 06:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:01:39 --> Input Class Initialized
INFO - 2016-12-10 06:01:39 --> Language Class Initialized
INFO - 2016-12-10 06:01:39 --> Loader Class Initialized
INFO - 2016-12-10 06:01:39 --> Database Driver Class Initialized
INFO - 2016-12-10 06:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:01:39 --> Controller Class Initialized
INFO - 2016-12-10 06:01:39 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:01:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:01:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:01:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:01:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:01:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:01:39 --> Final output sent to browser
DEBUG - 2016-12-10 06:01:39 --> Total execution time: 0.1666
INFO - 2016-12-10 06:08:38 --> Config Class Initialized
INFO - 2016-12-10 06:08:38 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:08:38 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:08:38 --> Utf8 Class Initialized
INFO - 2016-12-10 06:08:38 --> URI Class Initialized
INFO - 2016-12-10 06:08:38 --> Router Class Initialized
INFO - 2016-12-10 06:08:38 --> Output Class Initialized
INFO - 2016-12-10 06:08:38 --> Security Class Initialized
DEBUG - 2016-12-10 06:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:08:38 --> Input Class Initialized
INFO - 2016-12-10 06:08:38 --> Language Class Initialized
INFO - 2016-12-10 06:08:38 --> Loader Class Initialized
INFO - 2016-12-10 06:08:38 --> Database Driver Class Initialized
INFO - 2016-12-10 06:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:08:38 --> Controller Class Initialized
DEBUG - 2016-12-10 06:08:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:08:38 --> Helper loaded: url_helper
INFO - 2016-12-10 06:08:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:08:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 06:08:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 06:08:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-10 06:08:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:08:38 --> Final output sent to browser
DEBUG - 2016-12-10 06:08:38 --> Total execution time: 0.4126
INFO - 2016-12-10 06:08:39 --> Config Class Initialized
INFO - 2016-12-10 06:08:39 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:08:39 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:08:39 --> Utf8 Class Initialized
INFO - 2016-12-10 06:08:39 --> URI Class Initialized
INFO - 2016-12-10 06:08:39 --> Router Class Initialized
INFO - 2016-12-10 06:08:39 --> Output Class Initialized
INFO - 2016-12-10 06:08:39 --> Security Class Initialized
DEBUG - 2016-12-10 06:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:08:39 --> Input Class Initialized
INFO - 2016-12-10 06:08:39 --> Language Class Initialized
INFO - 2016-12-10 06:08:39 --> Loader Class Initialized
INFO - 2016-12-10 06:08:39 --> Database Driver Class Initialized
INFO - 2016-12-10 06:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:08:39 --> Controller Class Initialized
INFO - 2016-12-10 06:08:39 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:08:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:08:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:08:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:08:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:08:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:08:39 --> Final output sent to browser
DEBUG - 2016-12-10 06:08:39 --> Total execution time: 0.0373
INFO - 2016-12-10 06:09:00 --> Config Class Initialized
INFO - 2016-12-10 06:09:00 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:09:00 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:09:00 --> Utf8 Class Initialized
INFO - 2016-12-10 06:09:00 --> URI Class Initialized
INFO - 2016-12-10 06:09:00 --> Router Class Initialized
INFO - 2016-12-10 06:09:00 --> Output Class Initialized
INFO - 2016-12-10 06:09:00 --> Security Class Initialized
DEBUG - 2016-12-10 06:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:09:00 --> Input Class Initialized
INFO - 2016-12-10 06:09:00 --> Language Class Initialized
INFO - 2016-12-10 06:09:00 --> Loader Class Initialized
INFO - 2016-12-10 06:09:01 --> Database Driver Class Initialized
INFO - 2016-12-10 06:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:09:01 --> Controller Class Initialized
DEBUG - 2016-12-10 06:09:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:09:01 --> Helper loaded: url_helper
INFO - 2016-12-10 06:09:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:09:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 06:09:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 06:09:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-10 06:09:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:09:01 --> Final output sent to browser
DEBUG - 2016-12-10 06:09:01 --> Total execution time: 0.0147
INFO - 2016-12-10 06:09:01 --> Config Class Initialized
INFO - 2016-12-10 06:09:01 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:09:01 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:09:01 --> Utf8 Class Initialized
INFO - 2016-12-10 06:09:01 --> URI Class Initialized
INFO - 2016-12-10 06:09:01 --> Router Class Initialized
INFO - 2016-12-10 06:09:01 --> Output Class Initialized
INFO - 2016-12-10 06:09:01 --> Security Class Initialized
DEBUG - 2016-12-10 06:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:09:01 --> Input Class Initialized
INFO - 2016-12-10 06:09:01 --> Language Class Initialized
INFO - 2016-12-10 06:09:01 --> Loader Class Initialized
INFO - 2016-12-10 06:09:01 --> Database Driver Class Initialized
INFO - 2016-12-10 06:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:09:01 --> Controller Class Initialized
INFO - 2016-12-10 06:09:01 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:09:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:09:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:09:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:09:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:09:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:09:01 --> Final output sent to browser
DEBUG - 2016-12-10 06:09:01 --> Total execution time: 0.0134
INFO - 2016-12-10 06:09:03 --> Config Class Initialized
INFO - 2016-12-10 06:09:03 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:09:03 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:09:03 --> Utf8 Class Initialized
INFO - 2016-12-10 06:09:03 --> URI Class Initialized
INFO - 2016-12-10 06:09:03 --> Router Class Initialized
INFO - 2016-12-10 06:09:03 --> Output Class Initialized
INFO - 2016-12-10 06:09:03 --> Security Class Initialized
DEBUG - 2016-12-10 06:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:09:03 --> Input Class Initialized
INFO - 2016-12-10 06:09:03 --> Language Class Initialized
INFO - 2016-12-10 06:09:03 --> Loader Class Initialized
INFO - 2016-12-10 06:09:03 --> Database Driver Class Initialized
INFO - 2016-12-10 06:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:09:03 --> Controller Class Initialized
DEBUG - 2016-12-10 06:09:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:09:03 --> Helper loaded: url_helper
INFO - 2016-12-10 06:09:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:09:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 06:09:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 06:09:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-10 06:09:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:09:03 --> Final output sent to browser
DEBUG - 2016-12-10 06:09:03 --> Total execution time: 0.0148
INFO - 2016-12-10 06:09:03 --> Config Class Initialized
INFO - 2016-12-10 06:09:03 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:09:03 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:09:03 --> Utf8 Class Initialized
INFO - 2016-12-10 06:09:03 --> URI Class Initialized
INFO - 2016-12-10 06:09:03 --> Router Class Initialized
INFO - 2016-12-10 06:09:03 --> Output Class Initialized
INFO - 2016-12-10 06:09:03 --> Security Class Initialized
DEBUG - 2016-12-10 06:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:09:03 --> Input Class Initialized
INFO - 2016-12-10 06:09:03 --> Language Class Initialized
INFO - 2016-12-10 06:09:03 --> Loader Class Initialized
INFO - 2016-12-10 06:09:03 --> Database Driver Class Initialized
INFO - 2016-12-10 06:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:09:03 --> Controller Class Initialized
INFO - 2016-12-10 06:09:03 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:09:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:09:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:09:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:09:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:09:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:09:03 --> Final output sent to browser
DEBUG - 2016-12-10 06:09:03 --> Total execution time: 0.0134
INFO - 2016-12-10 06:09:24 --> Config Class Initialized
INFO - 2016-12-10 06:09:24 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:09:24 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:09:24 --> Utf8 Class Initialized
INFO - 2016-12-10 06:09:24 --> URI Class Initialized
INFO - 2016-12-10 06:09:24 --> Router Class Initialized
INFO - 2016-12-10 06:09:24 --> Output Class Initialized
INFO - 2016-12-10 06:09:24 --> Security Class Initialized
DEBUG - 2016-12-10 06:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:09:24 --> Input Class Initialized
INFO - 2016-12-10 06:09:24 --> Language Class Initialized
INFO - 2016-12-10 06:09:24 --> Loader Class Initialized
INFO - 2016-12-10 06:09:24 --> Database Driver Class Initialized
INFO - 2016-12-10 06:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:09:24 --> Controller Class Initialized
DEBUG - 2016-12-10 06:09:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:09:24 --> Helper loaded: url_helper
INFO - 2016-12-10 06:09:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:09:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-10 06:09:24 --> Severity: Parsing Error --> syntax error, unexpected end of file /home/graduafe/public_html/application/views/usuario/pages/saldo.php 101
INFO - 2016-12-10 06:09:24 --> Config Class Initialized
INFO - 2016-12-10 06:09:24 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:09:24 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:09:24 --> Utf8 Class Initialized
INFO - 2016-12-10 06:09:24 --> URI Class Initialized
INFO - 2016-12-10 06:09:24 --> Router Class Initialized
INFO - 2016-12-10 06:09:24 --> Output Class Initialized
INFO - 2016-12-10 06:09:24 --> Security Class Initialized
DEBUG - 2016-12-10 06:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:09:24 --> Input Class Initialized
INFO - 2016-12-10 06:09:24 --> Language Class Initialized
INFO - 2016-12-10 06:09:24 --> Loader Class Initialized
INFO - 2016-12-10 06:09:24 --> Database Driver Class Initialized
INFO - 2016-12-10 06:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:09:24 --> Controller Class Initialized
INFO - 2016-12-10 06:09:24 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:09:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:09:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:09:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:09:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:09:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:09:24 --> Final output sent to browser
DEBUG - 2016-12-10 06:09:24 --> Total execution time: 0.0134
INFO - 2016-12-10 06:09:30 --> Config Class Initialized
INFO - 2016-12-10 06:09:30 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:09:30 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:09:30 --> Utf8 Class Initialized
INFO - 2016-12-10 06:09:30 --> URI Class Initialized
INFO - 2016-12-10 06:09:30 --> Router Class Initialized
INFO - 2016-12-10 06:09:30 --> Output Class Initialized
INFO - 2016-12-10 06:09:30 --> Security Class Initialized
DEBUG - 2016-12-10 06:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:09:30 --> Input Class Initialized
INFO - 2016-12-10 06:09:30 --> Language Class Initialized
INFO - 2016-12-10 06:09:30 --> Loader Class Initialized
INFO - 2016-12-10 06:09:30 --> Database Driver Class Initialized
INFO - 2016-12-10 06:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:09:30 --> Controller Class Initialized
DEBUG - 2016-12-10 06:09:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:09:30 --> Helper loaded: url_helper
INFO - 2016-12-10 06:09:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:09:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 06:09:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 06:09:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-10 06:09:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:09:30 --> Final output sent to browser
DEBUG - 2016-12-10 06:09:30 --> Total execution time: 0.0155
INFO - 2016-12-10 06:09:30 --> Config Class Initialized
INFO - 2016-12-10 06:09:30 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:09:30 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:09:30 --> Utf8 Class Initialized
INFO - 2016-12-10 06:09:30 --> URI Class Initialized
INFO - 2016-12-10 06:09:30 --> Router Class Initialized
INFO - 2016-12-10 06:09:30 --> Output Class Initialized
INFO - 2016-12-10 06:09:30 --> Security Class Initialized
DEBUG - 2016-12-10 06:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:09:30 --> Input Class Initialized
INFO - 2016-12-10 06:09:30 --> Language Class Initialized
INFO - 2016-12-10 06:09:30 --> Loader Class Initialized
INFO - 2016-12-10 06:09:30 --> Database Driver Class Initialized
INFO - 2016-12-10 06:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:09:30 --> Controller Class Initialized
INFO - 2016-12-10 06:09:30 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:09:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:09:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:09:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:09:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:09:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:09:30 --> Final output sent to browser
DEBUG - 2016-12-10 06:09:30 --> Total execution time: 0.0138
INFO - 2016-12-10 06:09:38 --> Config Class Initialized
INFO - 2016-12-10 06:09:38 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:09:38 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:09:38 --> Utf8 Class Initialized
INFO - 2016-12-10 06:09:38 --> URI Class Initialized
INFO - 2016-12-10 06:09:38 --> Router Class Initialized
INFO - 2016-12-10 06:09:38 --> Output Class Initialized
INFO - 2016-12-10 06:09:38 --> Security Class Initialized
DEBUG - 2016-12-10 06:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:09:38 --> Input Class Initialized
INFO - 2016-12-10 06:09:38 --> Language Class Initialized
ERROR - 2016-12-10 06:09:38 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-10 06:10:10 --> Config Class Initialized
INFO - 2016-12-10 06:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:10:10 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:10:10 --> Utf8 Class Initialized
INFO - 2016-12-10 06:10:10 --> URI Class Initialized
INFO - 2016-12-10 06:10:10 --> Router Class Initialized
INFO - 2016-12-10 06:10:10 --> Output Class Initialized
INFO - 2016-12-10 06:10:10 --> Security Class Initialized
DEBUG - 2016-12-10 06:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:10:10 --> Input Class Initialized
INFO - 2016-12-10 06:10:10 --> Language Class Initialized
INFO - 2016-12-10 06:10:10 --> Loader Class Initialized
INFO - 2016-12-10 06:10:10 --> Database Driver Class Initialized
INFO - 2016-12-10 06:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:10:10 --> Controller Class Initialized
DEBUG - 2016-12-10 06:10:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:10:10 --> Helper loaded: url_helper
INFO - 2016-12-10 06:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 06:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 06:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-10 06:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:10:10 --> Final output sent to browser
DEBUG - 2016-12-10 06:10:10 --> Total execution time: 0.0148
INFO - 2016-12-10 06:10:10 --> Config Class Initialized
INFO - 2016-12-10 06:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:10:10 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:10:10 --> Utf8 Class Initialized
INFO - 2016-12-10 06:10:10 --> URI Class Initialized
INFO - 2016-12-10 06:10:10 --> Router Class Initialized
INFO - 2016-12-10 06:10:10 --> Output Class Initialized
INFO - 2016-12-10 06:10:10 --> Security Class Initialized
DEBUG - 2016-12-10 06:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:10:10 --> Input Class Initialized
INFO - 2016-12-10 06:10:10 --> Language Class Initialized
ERROR - 2016-12-10 06:10:10 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-10 06:10:10 --> Config Class Initialized
INFO - 2016-12-10 06:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:10:10 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:10:10 --> Utf8 Class Initialized
INFO - 2016-12-10 06:10:10 --> URI Class Initialized
INFO - 2016-12-10 06:10:10 --> Router Class Initialized
INFO - 2016-12-10 06:10:10 --> Output Class Initialized
INFO - 2016-12-10 06:10:10 --> Security Class Initialized
DEBUG - 2016-12-10 06:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:10:10 --> Input Class Initialized
INFO - 2016-12-10 06:10:10 --> Language Class Initialized
INFO - 2016-12-10 06:10:10 --> Loader Class Initialized
INFO - 2016-12-10 06:10:10 --> Database Driver Class Initialized
INFO - 2016-12-10 06:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:10:10 --> Controller Class Initialized
INFO - 2016-12-10 06:10:10 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:10:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:10:10 --> Final output sent to browser
DEBUG - 2016-12-10 06:10:10 --> Total execution time: 0.0137
INFO - 2016-12-10 06:10:28 --> Config Class Initialized
INFO - 2016-12-10 06:10:28 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:10:28 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:10:28 --> Utf8 Class Initialized
INFO - 2016-12-10 06:10:28 --> URI Class Initialized
INFO - 2016-12-10 06:10:28 --> Router Class Initialized
INFO - 2016-12-10 06:10:28 --> Output Class Initialized
INFO - 2016-12-10 06:10:28 --> Security Class Initialized
DEBUG - 2016-12-10 06:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:10:28 --> Input Class Initialized
INFO - 2016-12-10 06:10:28 --> Language Class Initialized
INFO - 2016-12-10 06:10:28 --> Loader Class Initialized
INFO - 2016-12-10 06:10:28 --> Database Driver Class Initialized
INFO - 2016-12-10 06:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:10:28 --> Controller Class Initialized
DEBUG - 2016-12-10 06:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:10:28 --> Helper loaded: url_helper
INFO - 2016-12-10 06:10:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:10:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 06:10:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 06:10:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-10 06:10:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:10:28 --> Final output sent to browser
DEBUG - 2016-12-10 06:10:28 --> Total execution time: 0.0707
INFO - 2016-12-10 06:10:29 --> Config Class Initialized
INFO - 2016-12-10 06:10:29 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:10:29 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:10:29 --> Utf8 Class Initialized
INFO - 2016-12-10 06:10:29 --> URI Class Initialized
INFO - 2016-12-10 06:10:29 --> Router Class Initialized
INFO - 2016-12-10 06:10:29 --> Output Class Initialized
INFO - 2016-12-10 06:10:29 --> Security Class Initialized
DEBUG - 2016-12-10 06:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:10:29 --> Input Class Initialized
INFO - 2016-12-10 06:10:29 --> Language Class Initialized
INFO - 2016-12-10 06:10:29 --> Loader Class Initialized
INFO - 2016-12-10 06:10:29 --> Database Driver Class Initialized
INFO - 2016-12-10 06:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:10:29 --> Controller Class Initialized
INFO - 2016-12-10 06:10:29 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:10:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:10:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:10:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:10:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:10:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:10:29 --> Final output sent to browser
DEBUG - 2016-12-10 06:10:29 --> Total execution time: 0.0138
INFO - 2016-12-10 06:10:31 --> Config Class Initialized
INFO - 2016-12-10 06:10:31 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:10:31 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:10:31 --> Utf8 Class Initialized
INFO - 2016-12-10 06:10:31 --> URI Class Initialized
INFO - 2016-12-10 06:10:31 --> Router Class Initialized
INFO - 2016-12-10 06:10:31 --> Output Class Initialized
INFO - 2016-12-10 06:10:31 --> Security Class Initialized
DEBUG - 2016-12-10 06:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:10:31 --> Input Class Initialized
INFO - 2016-12-10 06:10:31 --> Language Class Initialized
INFO - 2016-12-10 06:10:31 --> Loader Class Initialized
INFO - 2016-12-10 06:10:31 --> Database Driver Class Initialized
INFO - 2016-12-10 06:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:10:31 --> Controller Class Initialized
DEBUG - 2016-12-10 06:10:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:10:31 --> Helper loaded: url_helper
INFO - 2016-12-10 06:10:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:10:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 06:10:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 06:10:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-10 06:10:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:10:31 --> Final output sent to browser
DEBUG - 2016-12-10 06:10:31 --> Total execution time: 0.0149
INFO - 2016-12-10 06:10:31 --> Config Class Initialized
INFO - 2016-12-10 06:10:31 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:10:31 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:10:31 --> Utf8 Class Initialized
INFO - 2016-12-10 06:10:31 --> URI Class Initialized
INFO - 2016-12-10 06:10:31 --> Router Class Initialized
INFO - 2016-12-10 06:10:31 --> Output Class Initialized
INFO - 2016-12-10 06:10:31 --> Security Class Initialized
DEBUG - 2016-12-10 06:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:10:31 --> Input Class Initialized
INFO - 2016-12-10 06:10:31 --> Language Class Initialized
INFO - 2016-12-10 06:10:31 --> Loader Class Initialized
INFO - 2016-12-10 06:10:31 --> Database Driver Class Initialized
INFO - 2016-12-10 06:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:10:31 --> Controller Class Initialized
INFO - 2016-12-10 06:10:31 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:10:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:10:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:10:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:10:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:10:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:10:31 --> Final output sent to browser
DEBUG - 2016-12-10 06:10:31 --> Total execution time: 0.0135
INFO - 2016-12-10 06:11:50 --> Config Class Initialized
INFO - 2016-12-10 06:11:50 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:11:50 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:11:50 --> Utf8 Class Initialized
INFO - 2016-12-10 06:11:50 --> URI Class Initialized
INFO - 2016-12-10 06:11:50 --> Router Class Initialized
INFO - 2016-12-10 06:11:50 --> Output Class Initialized
INFO - 2016-12-10 06:11:50 --> Security Class Initialized
DEBUG - 2016-12-10 06:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:11:50 --> Input Class Initialized
INFO - 2016-12-10 06:11:50 --> Language Class Initialized
INFO - 2016-12-10 06:11:50 --> Loader Class Initialized
INFO - 2016-12-10 06:11:50 --> Database Driver Class Initialized
INFO - 2016-12-10 06:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:11:50 --> Controller Class Initialized
DEBUG - 2016-12-10 06:11:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:11:50 --> Helper loaded: url_helper
INFO - 2016-12-10 06:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 06:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 06:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-10 06:11:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-10 06:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:11:50 --> Final output sent to browser
DEBUG - 2016-12-10 06:11:50 --> Total execution time: 0.0143
INFO - 2016-12-10 06:11:51 --> Config Class Initialized
INFO - 2016-12-10 06:11:51 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:11:51 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:11:51 --> Utf8 Class Initialized
INFO - 2016-12-10 06:11:51 --> URI Class Initialized
INFO - 2016-12-10 06:11:51 --> Router Class Initialized
INFO - 2016-12-10 06:11:51 --> Output Class Initialized
INFO - 2016-12-10 06:11:51 --> Security Class Initialized
DEBUG - 2016-12-10 06:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:11:51 --> Input Class Initialized
INFO - 2016-12-10 06:11:51 --> Language Class Initialized
INFO - 2016-12-10 06:11:51 --> Loader Class Initialized
INFO - 2016-12-10 06:11:51 --> Database Driver Class Initialized
INFO - 2016-12-10 06:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:11:51 --> Controller Class Initialized
INFO - 2016-12-10 06:11:51 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:11:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:11:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:11:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:11:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:11:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:11:51 --> Final output sent to browser
DEBUG - 2016-12-10 06:11:51 --> Total execution time: 0.0132
INFO - 2016-12-10 06:12:03 --> Config Class Initialized
INFO - 2016-12-10 06:12:03 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:12:03 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:12:03 --> Utf8 Class Initialized
INFO - 2016-12-10 06:12:03 --> URI Class Initialized
INFO - 2016-12-10 06:12:03 --> Router Class Initialized
INFO - 2016-12-10 06:12:03 --> Output Class Initialized
INFO - 2016-12-10 06:12:03 --> Security Class Initialized
DEBUG - 2016-12-10 06:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:12:03 --> Input Class Initialized
INFO - 2016-12-10 06:12:03 --> Language Class Initialized
INFO - 2016-12-10 06:12:03 --> Loader Class Initialized
INFO - 2016-12-10 06:12:03 --> Database Driver Class Initialized
INFO - 2016-12-10 06:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:12:03 --> Controller Class Initialized
DEBUG - 2016-12-10 06:12:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:12:03 --> Helper loaded: url_helper
INFO - 2016-12-10 06:12:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:12:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 06:12:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 06:12:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-10 06:12:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-10 06:12:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:12:03 --> Final output sent to browser
DEBUG - 2016-12-10 06:12:03 --> Total execution time: 0.0149
INFO - 2016-12-10 06:12:03 --> Config Class Initialized
INFO - 2016-12-10 06:12:03 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:12:03 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:12:03 --> Utf8 Class Initialized
INFO - 2016-12-10 06:12:03 --> URI Class Initialized
INFO - 2016-12-10 06:12:03 --> Router Class Initialized
INFO - 2016-12-10 06:12:03 --> Output Class Initialized
INFO - 2016-12-10 06:12:03 --> Security Class Initialized
DEBUG - 2016-12-10 06:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:12:03 --> Input Class Initialized
INFO - 2016-12-10 06:12:03 --> Language Class Initialized
INFO - 2016-12-10 06:12:03 --> Loader Class Initialized
INFO - 2016-12-10 06:12:03 --> Database Driver Class Initialized
INFO - 2016-12-10 06:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:12:03 --> Controller Class Initialized
INFO - 2016-12-10 06:12:03 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:12:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:12:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:12:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:12:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:12:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:12:03 --> Final output sent to browser
DEBUG - 2016-12-10 06:12:03 --> Total execution time: 0.0139
INFO - 2016-12-10 06:12:04 --> Config Class Initialized
INFO - 2016-12-10 06:12:04 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:12:04 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:12:04 --> Utf8 Class Initialized
INFO - 2016-12-10 06:12:04 --> URI Class Initialized
INFO - 2016-12-10 06:12:04 --> Router Class Initialized
INFO - 2016-12-10 06:12:04 --> Output Class Initialized
INFO - 2016-12-10 06:12:04 --> Security Class Initialized
DEBUG - 2016-12-10 06:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:12:04 --> Input Class Initialized
INFO - 2016-12-10 06:12:04 --> Language Class Initialized
INFO - 2016-12-10 06:12:04 --> Loader Class Initialized
INFO - 2016-12-10 06:12:04 --> Database Driver Class Initialized
INFO - 2016-12-10 06:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:12:04 --> Controller Class Initialized
DEBUG - 2016-12-10 06:12:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:12:04 --> Helper loaded: url_helper
INFO - 2016-12-10 06:12:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:12:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 06:12:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 06:12:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-10 06:12:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-10 06:12:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:12:04 --> Final output sent to browser
DEBUG - 2016-12-10 06:12:04 --> Total execution time: 0.0154
INFO - 2016-12-10 06:12:05 --> Config Class Initialized
INFO - 2016-12-10 06:12:05 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:12:05 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:12:05 --> Utf8 Class Initialized
INFO - 2016-12-10 06:12:05 --> URI Class Initialized
INFO - 2016-12-10 06:12:05 --> Router Class Initialized
INFO - 2016-12-10 06:12:05 --> Output Class Initialized
INFO - 2016-12-10 06:12:05 --> Security Class Initialized
DEBUG - 2016-12-10 06:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:12:05 --> Input Class Initialized
INFO - 2016-12-10 06:12:05 --> Language Class Initialized
INFO - 2016-12-10 06:12:05 --> Loader Class Initialized
INFO - 2016-12-10 06:12:05 --> Database Driver Class Initialized
INFO - 2016-12-10 06:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:12:05 --> Controller Class Initialized
INFO - 2016-12-10 06:12:05 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:12:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:12:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:12:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:12:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:12:05 --> Final output sent to browser
DEBUG - 2016-12-10 06:12:05 --> Total execution time: 0.0140
INFO - 2016-12-10 06:15:21 --> Config Class Initialized
INFO - 2016-12-10 06:15:21 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:15:21 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:15:21 --> Utf8 Class Initialized
INFO - 2016-12-10 06:15:21 --> URI Class Initialized
INFO - 2016-12-10 06:15:21 --> Router Class Initialized
INFO - 2016-12-10 06:15:21 --> Output Class Initialized
INFO - 2016-12-10 06:15:21 --> Security Class Initialized
DEBUG - 2016-12-10 06:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:15:21 --> Input Class Initialized
INFO - 2016-12-10 06:15:21 --> Language Class Initialized
INFO - 2016-12-10 06:15:21 --> Loader Class Initialized
INFO - 2016-12-10 06:15:21 --> Database Driver Class Initialized
INFO - 2016-12-10 06:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:15:21 --> Controller Class Initialized
DEBUG - 2016-12-10 06:15:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:15:21 --> Helper loaded: url_helper
INFO - 2016-12-10 06:15:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:15:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-10 06:15:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 06:15:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-10 06:15:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-10 06:15:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:15:21 --> Final output sent to browser
DEBUG - 2016-12-10 06:15:21 --> Total execution time: 0.0384
INFO - 2016-12-10 06:15:22 --> Config Class Initialized
INFO - 2016-12-10 06:15:22 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:15:22 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:15:22 --> Utf8 Class Initialized
INFO - 2016-12-10 06:15:22 --> URI Class Initialized
INFO - 2016-12-10 06:15:22 --> Router Class Initialized
INFO - 2016-12-10 06:15:22 --> Output Class Initialized
INFO - 2016-12-10 06:15:22 --> Security Class Initialized
DEBUG - 2016-12-10 06:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:15:22 --> Input Class Initialized
INFO - 2016-12-10 06:15:22 --> Language Class Initialized
INFO - 2016-12-10 06:15:22 --> Loader Class Initialized
INFO - 2016-12-10 06:15:22 --> Database Driver Class Initialized
INFO - 2016-12-10 06:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:15:22 --> Controller Class Initialized
INFO - 2016-12-10 06:15:22 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:15:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:15:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:15:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:15:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:15:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:15:22 --> Final output sent to browser
DEBUG - 2016-12-10 06:15:22 --> Total execution time: 0.0141
INFO - 2016-12-10 06:15:23 --> Config Class Initialized
INFO - 2016-12-10 06:15:23 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:15:23 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:15:23 --> Utf8 Class Initialized
INFO - 2016-12-10 06:15:23 --> URI Class Initialized
INFO - 2016-12-10 06:15:23 --> Router Class Initialized
INFO - 2016-12-10 06:15:23 --> Output Class Initialized
INFO - 2016-12-10 06:15:23 --> Security Class Initialized
DEBUG - 2016-12-10 06:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:15:23 --> Input Class Initialized
INFO - 2016-12-10 06:15:23 --> Language Class Initialized
INFO - 2016-12-10 06:15:23 --> Loader Class Initialized
INFO - 2016-12-10 06:15:23 --> Database Driver Class Initialized
INFO - 2016-12-10 06:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:15:23 --> Controller Class Initialized
DEBUG - 2016-12-10 06:15:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:15:23 --> Helper loaded: url_helper
INFO - 2016-12-10 06:15:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:15:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-10 06:15:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 06:15:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-10 06:15:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-10 06:15:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:15:23 --> Final output sent to browser
DEBUG - 2016-12-10 06:15:23 --> Total execution time: 0.0126
INFO - 2016-12-10 06:15:23 --> Config Class Initialized
INFO - 2016-12-10 06:15:23 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:15:23 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:15:23 --> Utf8 Class Initialized
INFO - 2016-12-10 06:15:23 --> URI Class Initialized
INFO - 2016-12-10 06:15:23 --> Router Class Initialized
INFO - 2016-12-10 06:15:23 --> Output Class Initialized
INFO - 2016-12-10 06:15:23 --> Security Class Initialized
DEBUG - 2016-12-10 06:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:15:23 --> Input Class Initialized
INFO - 2016-12-10 06:15:23 --> Language Class Initialized
INFO - 2016-12-10 06:15:23 --> Loader Class Initialized
INFO - 2016-12-10 06:15:23 --> Database Driver Class Initialized
INFO - 2016-12-10 06:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:15:23 --> Controller Class Initialized
INFO - 2016-12-10 06:15:23 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:15:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:15:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:15:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:15:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:15:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:15:23 --> Final output sent to browser
DEBUG - 2016-12-10 06:15:23 --> Total execution time: 0.0138
INFO - 2016-12-10 06:15:25 --> Config Class Initialized
INFO - 2016-12-10 06:15:25 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:15:25 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:15:25 --> Utf8 Class Initialized
INFO - 2016-12-10 06:15:25 --> URI Class Initialized
INFO - 2016-12-10 06:15:25 --> Router Class Initialized
INFO - 2016-12-10 06:15:25 --> Output Class Initialized
INFO - 2016-12-10 06:15:25 --> Security Class Initialized
DEBUG - 2016-12-10 06:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:15:25 --> Input Class Initialized
INFO - 2016-12-10 06:15:25 --> Language Class Initialized
INFO - 2016-12-10 06:15:25 --> Loader Class Initialized
INFO - 2016-12-10 06:15:25 --> Database Driver Class Initialized
INFO - 2016-12-10 06:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:15:25 --> Controller Class Initialized
DEBUG - 2016-12-10 06:15:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:15:25 --> Helper loaded: url_helper
INFO - 2016-12-10 06:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-10 06:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 06:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-10 06:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-10 06:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:15:25 --> Final output sent to browser
DEBUG - 2016-12-10 06:15:25 --> Total execution time: 0.0119
INFO - 2016-12-10 06:15:25 --> Config Class Initialized
INFO - 2016-12-10 06:15:25 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:15:25 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:15:25 --> Utf8 Class Initialized
INFO - 2016-12-10 06:15:25 --> URI Class Initialized
INFO - 2016-12-10 06:15:25 --> Router Class Initialized
INFO - 2016-12-10 06:15:25 --> Output Class Initialized
INFO - 2016-12-10 06:15:25 --> Security Class Initialized
DEBUG - 2016-12-10 06:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:15:25 --> Input Class Initialized
INFO - 2016-12-10 06:15:25 --> Language Class Initialized
INFO - 2016-12-10 06:15:25 --> Loader Class Initialized
INFO - 2016-12-10 06:15:25 --> Database Driver Class Initialized
INFO - 2016-12-10 06:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:15:25 --> Controller Class Initialized
INFO - 2016-12-10 06:15:25 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:15:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:15:25 --> Final output sent to browser
DEBUG - 2016-12-10 06:15:25 --> Total execution time: 0.0140
INFO - 2016-12-10 06:15:25 --> Config Class Initialized
INFO - 2016-12-10 06:15:25 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:15:25 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:15:25 --> Utf8 Class Initialized
INFO - 2016-12-10 06:15:25 --> URI Class Initialized
INFO - 2016-12-10 06:15:25 --> Router Class Initialized
INFO - 2016-12-10 06:15:25 --> Output Class Initialized
INFO - 2016-12-10 06:15:25 --> Security Class Initialized
DEBUG - 2016-12-10 06:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:15:25 --> Input Class Initialized
INFO - 2016-12-10 06:15:25 --> Language Class Initialized
INFO - 2016-12-10 06:15:25 --> Loader Class Initialized
INFO - 2016-12-10 06:15:25 --> Database Driver Class Initialized
INFO - 2016-12-10 06:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:15:25 --> Controller Class Initialized
DEBUG - 2016-12-10 06:15:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:15:25 --> Helper loaded: url_helper
INFO - 2016-12-10 06:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 06:15:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 06:15:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-10 06:15:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-10 06:15:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:15:26 --> Final output sent to browser
DEBUG - 2016-12-10 06:15:26 --> Total execution time: 0.0143
INFO - 2016-12-10 06:15:26 --> Config Class Initialized
INFO - 2016-12-10 06:15:26 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:15:26 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:15:26 --> Utf8 Class Initialized
INFO - 2016-12-10 06:15:26 --> URI Class Initialized
INFO - 2016-12-10 06:15:26 --> Router Class Initialized
INFO - 2016-12-10 06:15:26 --> Output Class Initialized
INFO - 2016-12-10 06:15:26 --> Security Class Initialized
DEBUG - 2016-12-10 06:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:15:26 --> Input Class Initialized
INFO - 2016-12-10 06:15:26 --> Language Class Initialized
INFO - 2016-12-10 06:15:26 --> Loader Class Initialized
INFO - 2016-12-10 06:15:26 --> Database Driver Class Initialized
INFO - 2016-12-10 06:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:15:26 --> Controller Class Initialized
INFO - 2016-12-10 06:15:26 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:15:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:15:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:15:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:15:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:15:26 --> Final output sent to browser
DEBUG - 2016-12-10 06:15:26 --> Total execution time: 0.0137
INFO - 2016-12-10 06:40:43 --> Config Class Initialized
INFO - 2016-12-10 06:40:43 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:40:43 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:40:43 --> Utf8 Class Initialized
INFO - 2016-12-10 06:40:43 --> URI Class Initialized
INFO - 2016-12-10 06:40:43 --> Router Class Initialized
INFO - 2016-12-10 06:40:43 --> Output Class Initialized
INFO - 2016-12-10 06:40:43 --> Security Class Initialized
DEBUG - 2016-12-10 06:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:40:43 --> Input Class Initialized
INFO - 2016-12-10 06:40:43 --> Language Class Initialized
INFO - 2016-12-10 06:40:43 --> Loader Class Initialized
INFO - 2016-12-10 06:40:43 --> Database Driver Class Initialized
INFO - 2016-12-10 06:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:40:43 --> Controller Class Initialized
INFO - 2016-12-10 06:40:43 --> Upload Class Initialized
DEBUG - 2016-12-10 06:40:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:40:43 --> Helper loaded: url_helper
INFO - 2016-12-10 06:40:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:40:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 06:40:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 06:40:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-10 06:40:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-10 06:40:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:40:43 --> Final output sent to browser
DEBUG - 2016-12-10 06:40:43 --> Total execution time: 0.2186
INFO - 2016-12-10 06:40:43 --> Config Class Initialized
INFO - 2016-12-10 06:40:43 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:40:43 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:40:43 --> Utf8 Class Initialized
INFO - 2016-12-10 06:40:43 --> URI Class Initialized
INFO - 2016-12-10 06:40:43 --> Router Class Initialized
INFO - 2016-12-10 06:40:43 --> Output Class Initialized
INFO - 2016-12-10 06:40:43 --> Security Class Initialized
DEBUG - 2016-12-10 06:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:40:43 --> Input Class Initialized
INFO - 2016-12-10 06:40:43 --> Language Class Initialized
INFO - 2016-12-10 06:40:43 --> Loader Class Initialized
INFO - 2016-12-10 06:40:43 --> Database Driver Class Initialized
INFO - 2016-12-10 06:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:40:43 --> Controller Class Initialized
INFO - 2016-12-10 06:40:43 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:40:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:40:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:40:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:40:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:40:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:40:43 --> Final output sent to browser
DEBUG - 2016-12-10 06:40:43 --> Total execution time: 0.0332
INFO - 2016-12-10 06:40:53 --> Config Class Initialized
INFO - 2016-12-10 06:40:53 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:40:53 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:40:53 --> Utf8 Class Initialized
INFO - 2016-12-10 06:40:53 --> URI Class Initialized
INFO - 2016-12-10 06:40:53 --> Router Class Initialized
INFO - 2016-12-10 06:40:53 --> Output Class Initialized
INFO - 2016-12-10 06:40:53 --> Security Class Initialized
DEBUG - 2016-12-10 06:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:40:53 --> Input Class Initialized
INFO - 2016-12-10 06:40:53 --> Language Class Initialized
ERROR - 2016-12-10 06:40:53 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-10 06:41:49 --> Config Class Initialized
INFO - 2016-12-10 06:41:49 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:41:49 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:41:49 --> Utf8 Class Initialized
INFO - 2016-12-10 06:41:49 --> URI Class Initialized
INFO - 2016-12-10 06:41:49 --> Router Class Initialized
INFO - 2016-12-10 06:41:49 --> Output Class Initialized
INFO - 2016-12-10 06:41:49 --> Security Class Initialized
DEBUG - 2016-12-10 06:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:41:49 --> Input Class Initialized
INFO - 2016-12-10 06:41:49 --> Language Class Initialized
INFO - 2016-12-10 06:41:49 --> Loader Class Initialized
INFO - 2016-12-10 06:41:49 --> Database Driver Class Initialized
INFO - 2016-12-10 06:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:41:49 --> Controller Class Initialized
INFO - 2016-12-10 06:41:49 --> Upload Class Initialized
DEBUG - 2016-12-10 06:41:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:41:49 --> Helper loaded: url_helper
INFO - 2016-12-10 06:41:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:41:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 06:41:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 06:41:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-10 06:41:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-10 06:41:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:41:49 --> Final output sent to browser
DEBUG - 2016-12-10 06:41:49 --> Total execution time: 0.0154
INFO - 2016-12-10 06:41:49 --> Config Class Initialized
INFO - 2016-12-10 06:41:49 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:41:49 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:41:49 --> Utf8 Class Initialized
INFO - 2016-12-10 06:41:49 --> URI Class Initialized
INFO - 2016-12-10 06:41:49 --> Router Class Initialized
INFO - 2016-12-10 06:41:49 --> Output Class Initialized
INFO - 2016-12-10 06:41:49 --> Security Class Initialized
DEBUG - 2016-12-10 06:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:41:49 --> Input Class Initialized
INFO - 2016-12-10 06:41:49 --> Language Class Initialized
ERROR - 2016-12-10 06:41:49 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-10 06:41:49 --> Config Class Initialized
INFO - 2016-12-10 06:41:49 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:41:49 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:41:49 --> Utf8 Class Initialized
INFO - 2016-12-10 06:41:49 --> URI Class Initialized
INFO - 2016-12-10 06:41:49 --> Router Class Initialized
INFO - 2016-12-10 06:41:49 --> Output Class Initialized
INFO - 2016-12-10 06:41:49 --> Security Class Initialized
DEBUG - 2016-12-10 06:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:41:49 --> Input Class Initialized
INFO - 2016-12-10 06:41:49 --> Language Class Initialized
INFO - 2016-12-10 06:41:49 --> Loader Class Initialized
INFO - 2016-12-10 06:41:49 --> Database Driver Class Initialized
INFO - 2016-12-10 06:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:41:49 --> Controller Class Initialized
INFO - 2016-12-10 06:41:49 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:41:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:41:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:41:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:41:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:41:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:41:49 --> Final output sent to browser
DEBUG - 2016-12-10 06:41:49 --> Total execution time: 0.0135
INFO - 2016-12-10 06:46:38 --> Config Class Initialized
INFO - 2016-12-10 06:46:38 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:46:38 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:46:38 --> Utf8 Class Initialized
INFO - 2016-12-10 06:46:38 --> URI Class Initialized
INFO - 2016-12-10 06:46:38 --> Router Class Initialized
INFO - 2016-12-10 06:46:38 --> Output Class Initialized
INFO - 2016-12-10 06:46:38 --> Security Class Initialized
DEBUG - 2016-12-10 06:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:46:38 --> Input Class Initialized
INFO - 2016-12-10 06:46:38 --> Language Class Initialized
INFO - 2016-12-10 06:46:38 --> Loader Class Initialized
INFO - 2016-12-10 06:46:38 --> Database Driver Class Initialized
INFO - 2016-12-10 06:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:46:38 --> Controller Class Initialized
INFO - 2016-12-10 06:46:38 --> Upload Class Initialized
DEBUG - 2016-12-10 06:46:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:46:38 --> Helper loaded: url_helper
INFO - 2016-12-10 06:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 06:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 06:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-10 06:46:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-10 06:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:46:38 --> Final output sent to browser
DEBUG - 2016-12-10 06:46:38 --> Total execution time: 0.0166
INFO - 2016-12-10 06:46:38 --> Config Class Initialized
INFO - 2016-12-10 06:46:38 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:46:38 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:46:38 --> Utf8 Class Initialized
INFO - 2016-12-10 06:46:38 --> URI Class Initialized
INFO - 2016-12-10 06:46:38 --> Router Class Initialized
INFO - 2016-12-10 06:46:38 --> Output Class Initialized
INFO - 2016-12-10 06:46:38 --> Security Class Initialized
DEBUG - 2016-12-10 06:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:46:38 --> Input Class Initialized
INFO - 2016-12-10 06:46:38 --> Language Class Initialized
ERROR - 2016-12-10 06:46:38 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-10 06:46:39 --> Config Class Initialized
INFO - 2016-12-10 06:46:39 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:46:39 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:46:39 --> Utf8 Class Initialized
INFO - 2016-12-10 06:46:39 --> URI Class Initialized
INFO - 2016-12-10 06:46:39 --> Router Class Initialized
INFO - 2016-12-10 06:46:39 --> Output Class Initialized
INFO - 2016-12-10 06:46:39 --> Security Class Initialized
DEBUG - 2016-12-10 06:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:46:39 --> Input Class Initialized
INFO - 2016-12-10 06:46:39 --> Language Class Initialized
INFO - 2016-12-10 06:46:39 --> Loader Class Initialized
INFO - 2016-12-10 06:46:39 --> Database Driver Class Initialized
INFO - 2016-12-10 06:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:46:39 --> Controller Class Initialized
INFO - 2016-12-10 06:46:39 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:46:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:46:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:46:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:46:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:46:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:46:39 --> Final output sent to browser
DEBUG - 2016-12-10 06:46:39 --> Total execution time: 0.0139
INFO - 2016-12-10 06:46:46 --> Config Class Initialized
INFO - 2016-12-10 06:46:46 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:46:46 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:46:46 --> Utf8 Class Initialized
INFO - 2016-12-10 06:46:46 --> URI Class Initialized
INFO - 2016-12-10 06:46:46 --> Router Class Initialized
INFO - 2016-12-10 06:46:46 --> Output Class Initialized
INFO - 2016-12-10 06:46:46 --> Security Class Initialized
DEBUG - 2016-12-10 06:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:46:46 --> Input Class Initialized
INFO - 2016-12-10 06:46:46 --> Language Class Initialized
INFO - 2016-12-10 06:46:46 --> Loader Class Initialized
INFO - 2016-12-10 06:46:46 --> Database Driver Class Initialized
INFO - 2016-12-10 06:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:46:46 --> Controller Class Initialized
INFO - 2016-12-10 06:46:46 --> Upload Class Initialized
DEBUG - 2016-12-10 06:46:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:46:46 --> Helper loaded: url_helper
INFO - 2016-12-10 06:46:46 --> Final output sent to browser
DEBUG - 2016-12-10 06:46:46 --> Total execution time: 0.6365
INFO - 2016-12-10 06:47:18 --> Config Class Initialized
INFO - 2016-12-10 06:47:18 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:47:18 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:47:18 --> Utf8 Class Initialized
INFO - 2016-12-10 06:47:18 --> URI Class Initialized
INFO - 2016-12-10 06:47:18 --> Router Class Initialized
INFO - 2016-12-10 06:47:18 --> Output Class Initialized
INFO - 2016-12-10 06:47:18 --> Security Class Initialized
DEBUG - 2016-12-10 06:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:47:18 --> Input Class Initialized
INFO - 2016-12-10 06:47:18 --> Language Class Initialized
INFO - 2016-12-10 06:47:18 --> Loader Class Initialized
INFO - 2016-12-10 06:47:18 --> Database Driver Class Initialized
INFO - 2016-12-10 06:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:47:18 --> Controller Class Initialized
INFO - 2016-12-10 06:47:18 --> Upload Class Initialized
DEBUG - 2016-12-10 06:47:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:47:18 --> Helper loaded: url_helper
INFO - 2016-12-10 06:47:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:47:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 06:47:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 06:47:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-10 06:47:18 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-10 06:47:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:47:18 --> Final output sent to browser
DEBUG - 2016-12-10 06:47:18 --> Total execution time: 0.0155
INFO - 2016-12-10 06:47:19 --> Config Class Initialized
INFO - 2016-12-10 06:47:19 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:47:19 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:47:19 --> Utf8 Class Initialized
INFO - 2016-12-10 06:47:19 --> URI Class Initialized
INFO - 2016-12-10 06:47:19 --> Router Class Initialized
INFO - 2016-12-10 06:47:19 --> Output Class Initialized
INFO - 2016-12-10 06:47:19 --> Security Class Initialized
DEBUG - 2016-12-10 06:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:47:19 --> Input Class Initialized
INFO - 2016-12-10 06:47:19 --> Language Class Initialized
INFO - 2016-12-10 06:47:19 --> Loader Class Initialized
INFO - 2016-12-10 06:47:19 --> Database Driver Class Initialized
INFO - 2016-12-10 06:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:47:19 --> Controller Class Initialized
INFO - 2016-12-10 06:47:19 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:47:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:47:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:47:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:47:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:47:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:47:19 --> Final output sent to browser
DEBUG - 2016-12-10 06:47:19 --> Total execution time: 0.0140
INFO - 2016-12-10 06:47:19 --> Config Class Initialized
INFO - 2016-12-10 06:47:19 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:47:19 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:47:19 --> Utf8 Class Initialized
INFO - 2016-12-10 06:47:19 --> URI Class Initialized
INFO - 2016-12-10 06:47:19 --> Router Class Initialized
INFO - 2016-12-10 06:47:19 --> Output Class Initialized
INFO - 2016-12-10 06:47:19 --> Security Class Initialized
DEBUG - 2016-12-10 06:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:47:19 --> Input Class Initialized
INFO - 2016-12-10 06:47:19 --> Language Class Initialized
ERROR - 2016-12-10 06:47:19 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-10 06:47:24 --> Config Class Initialized
INFO - 2016-12-10 06:47:24 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:47:24 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:47:24 --> Utf8 Class Initialized
INFO - 2016-12-10 06:47:24 --> URI Class Initialized
INFO - 2016-12-10 06:47:24 --> Router Class Initialized
INFO - 2016-12-10 06:47:24 --> Output Class Initialized
INFO - 2016-12-10 06:47:24 --> Security Class Initialized
DEBUG - 2016-12-10 06:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:47:24 --> Input Class Initialized
INFO - 2016-12-10 06:47:24 --> Language Class Initialized
INFO - 2016-12-10 06:47:24 --> Loader Class Initialized
INFO - 2016-12-10 06:47:24 --> Database Driver Class Initialized
INFO - 2016-12-10 06:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:47:24 --> Controller Class Initialized
INFO - 2016-12-10 06:47:24 --> Upload Class Initialized
DEBUG - 2016-12-10 06:47:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:47:24 --> Helper loaded: url_helper
INFO - 2016-12-10 06:47:24 --> Final output sent to browser
DEBUG - 2016-12-10 06:47:24 --> Total execution time: 0.0134
INFO - 2016-12-10 06:47:34 --> Config Class Initialized
INFO - 2016-12-10 06:47:34 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:47:34 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:47:34 --> Utf8 Class Initialized
INFO - 2016-12-10 06:47:34 --> URI Class Initialized
INFO - 2016-12-10 06:47:34 --> Router Class Initialized
INFO - 2016-12-10 06:47:34 --> Output Class Initialized
INFO - 2016-12-10 06:47:34 --> Security Class Initialized
DEBUG - 2016-12-10 06:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:47:34 --> Input Class Initialized
INFO - 2016-12-10 06:47:34 --> Language Class Initialized
INFO - 2016-12-10 06:47:34 --> Loader Class Initialized
INFO - 2016-12-10 06:47:34 --> Database Driver Class Initialized
INFO - 2016-12-10 06:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:47:34 --> Controller Class Initialized
INFO - 2016-12-10 06:47:34 --> Upload Class Initialized
DEBUG - 2016-12-10 06:47:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:47:34 --> Helper loaded: url_helper
INFO - 2016-12-10 06:47:34 --> Final output sent to browser
DEBUG - 2016-12-10 06:47:34 --> Total execution time: 0.0163
INFO - 2016-12-10 06:47:54 --> Config Class Initialized
INFO - 2016-12-10 06:47:54 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:47:54 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:47:54 --> Utf8 Class Initialized
INFO - 2016-12-10 06:47:54 --> URI Class Initialized
INFO - 2016-12-10 06:47:54 --> Router Class Initialized
INFO - 2016-12-10 06:47:54 --> Output Class Initialized
INFO - 2016-12-10 06:47:54 --> Security Class Initialized
DEBUG - 2016-12-10 06:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:47:54 --> Input Class Initialized
INFO - 2016-12-10 06:47:54 --> Language Class Initialized
INFO - 2016-12-10 06:47:54 --> Loader Class Initialized
INFO - 2016-12-10 06:47:54 --> Database Driver Class Initialized
INFO - 2016-12-10 06:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:47:54 --> Controller Class Initialized
INFO - 2016-12-10 06:47:54 --> Helper loaded: date_helper
INFO - 2016-12-10 06:47:54 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:47:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:47:54 --> Helper loaded: form_helper
INFO - 2016-12-10 06:47:54 --> Form Validation Class Initialized
INFO - 2016-12-10 06:47:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 06:47:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-10 06:47:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pagos.php
INFO - 2016-12-10 06:47:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pagos.php
INFO - 2016-12-10 06:47:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 06:47:54 --> Final output sent to browser
DEBUG - 2016-12-10 06:47:54 --> Total execution time: 0.1724
INFO - 2016-12-10 06:47:54 --> Config Class Initialized
INFO - 2016-12-10 06:47:54 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:47:54 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:47:54 --> Utf8 Class Initialized
INFO - 2016-12-10 06:47:54 --> URI Class Initialized
INFO - 2016-12-10 06:47:54 --> Router Class Initialized
INFO - 2016-12-10 06:47:54 --> Output Class Initialized
INFO - 2016-12-10 06:47:54 --> Security Class Initialized
DEBUG - 2016-12-10 06:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:47:54 --> Input Class Initialized
INFO - 2016-12-10 06:47:54 --> Language Class Initialized
INFO - 2016-12-10 06:47:54 --> Loader Class Initialized
INFO - 2016-12-10 06:47:54 --> Database Driver Class Initialized
INFO - 2016-12-10 06:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:47:54 --> Controller Class Initialized
INFO - 2016-12-10 06:47:54 --> Helper loaded: date_helper
INFO - 2016-12-10 06:47:54 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:47:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:47:54 --> Helper loaded: form_helper
INFO - 2016-12-10 06:47:54 --> Form Validation Class Initialized
INFO - 2016-12-10 06:47:54 --> Final output sent to browser
DEBUG - 2016-12-10 06:47:54 --> Total execution time: 0.0146
INFO - 2016-12-10 06:47:54 --> Config Class Initialized
INFO - 2016-12-10 06:47:54 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:47:54 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:47:54 --> Utf8 Class Initialized
INFO - 2016-12-10 06:47:54 --> URI Class Initialized
INFO - 2016-12-10 06:47:54 --> Router Class Initialized
INFO - 2016-12-10 06:47:54 --> Output Class Initialized
INFO - 2016-12-10 06:47:54 --> Security Class Initialized
DEBUG - 2016-12-10 06:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:47:54 --> Input Class Initialized
INFO - 2016-12-10 06:47:54 --> Language Class Initialized
INFO - 2016-12-10 06:47:54 --> Loader Class Initialized
INFO - 2016-12-10 06:47:54 --> Database Driver Class Initialized
INFO - 2016-12-10 06:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:47:54 --> Controller Class Initialized
INFO - 2016-12-10 06:47:54 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:47:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:47:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:47:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:47:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:47:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:47:54 --> Final output sent to browser
DEBUG - 2016-12-10 06:47:54 --> Total execution time: 0.0142
INFO - 2016-12-10 06:48:25 --> Config Class Initialized
INFO - 2016-12-10 06:48:25 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:48:25 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:48:25 --> Utf8 Class Initialized
INFO - 2016-12-10 06:48:25 --> URI Class Initialized
INFO - 2016-12-10 06:48:25 --> Router Class Initialized
INFO - 2016-12-10 06:48:25 --> Output Class Initialized
INFO - 2016-12-10 06:48:25 --> Security Class Initialized
DEBUG - 2016-12-10 06:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:48:25 --> Input Class Initialized
INFO - 2016-12-10 06:48:25 --> Language Class Initialized
INFO - 2016-12-10 06:48:25 --> Loader Class Initialized
INFO - 2016-12-10 06:48:25 --> Database Driver Class Initialized
INFO - 2016-12-10 06:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:48:25 --> Controller Class Initialized
INFO - 2016-12-10 06:48:25 --> Helper loaded: date_helper
INFO - 2016-12-10 06:48:25 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:48:25 --> Helper loaded: form_helper
INFO - 2016-12-10 06:48:25 --> Form Validation Class Initialized
INFO - 2016-12-10 06:48:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 06:48:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-10 06:48:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pagos.php
INFO - 2016-12-10 06:48:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pagos.php
INFO - 2016-12-10 06:48:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 06:48:25 --> Final output sent to browser
DEBUG - 2016-12-10 06:48:25 --> Total execution time: 0.0154
INFO - 2016-12-10 06:48:25 --> Config Class Initialized
INFO - 2016-12-10 06:48:25 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:48:25 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:48:25 --> Utf8 Class Initialized
INFO - 2016-12-10 06:48:25 --> URI Class Initialized
INFO - 2016-12-10 06:48:25 --> Router Class Initialized
INFO - 2016-12-10 06:48:25 --> Output Class Initialized
INFO - 2016-12-10 06:48:25 --> Security Class Initialized
DEBUG - 2016-12-10 06:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:48:25 --> Input Class Initialized
INFO - 2016-12-10 06:48:25 --> Language Class Initialized
INFO - 2016-12-10 06:48:25 --> Loader Class Initialized
INFO - 2016-12-10 06:48:25 --> Database Driver Class Initialized
INFO - 2016-12-10 06:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:48:25 --> Controller Class Initialized
INFO - 2016-12-10 06:48:25 --> Helper loaded: date_helper
INFO - 2016-12-10 06:48:25 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:48:25 --> Helper loaded: form_helper
INFO - 2016-12-10 06:48:25 --> Form Validation Class Initialized
INFO - 2016-12-10 06:48:25 --> Final output sent to browser
DEBUG - 2016-12-10 06:48:25 --> Total execution time: 0.0151
INFO - 2016-12-10 06:48:26 --> Config Class Initialized
INFO - 2016-12-10 06:48:26 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:48:26 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:48:26 --> Utf8 Class Initialized
INFO - 2016-12-10 06:48:26 --> URI Class Initialized
INFO - 2016-12-10 06:48:26 --> Router Class Initialized
INFO - 2016-12-10 06:48:26 --> Output Class Initialized
INFO - 2016-12-10 06:48:26 --> Security Class Initialized
DEBUG - 2016-12-10 06:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:48:26 --> Input Class Initialized
INFO - 2016-12-10 06:48:26 --> Language Class Initialized
INFO - 2016-12-10 06:48:26 --> Loader Class Initialized
INFO - 2016-12-10 06:48:26 --> Database Driver Class Initialized
INFO - 2016-12-10 06:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:48:26 --> Controller Class Initialized
INFO - 2016-12-10 06:48:26 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:48:26 --> Final output sent to browser
DEBUG - 2016-12-10 06:48:26 --> Total execution time: 0.0136
INFO - 2016-12-10 06:48:30 --> Config Class Initialized
INFO - 2016-12-10 06:48:30 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:48:30 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:48:30 --> Utf8 Class Initialized
INFO - 2016-12-10 06:48:30 --> URI Class Initialized
INFO - 2016-12-10 06:48:30 --> Router Class Initialized
INFO - 2016-12-10 06:48:30 --> Output Class Initialized
INFO - 2016-12-10 06:48:30 --> Security Class Initialized
DEBUG - 2016-12-10 06:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:48:31 --> Input Class Initialized
INFO - 2016-12-10 06:48:31 --> Language Class Initialized
INFO - 2016-12-10 06:48:31 --> Loader Class Initialized
INFO - 2016-12-10 06:48:31 --> Database Driver Class Initialized
INFO - 2016-12-10 06:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:48:31 --> Controller Class Initialized
INFO - 2016-12-10 06:48:31 --> Config Class Initialized
INFO - 2016-12-10 06:48:31 --> Hooks Class Initialized
INFO - 2016-12-10 06:48:31 --> Helper loaded: date_helper
INFO - 2016-12-10 06:48:31 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:48:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-12-10 06:48:31 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:48:31 --> Utf8 Class Initialized
INFO - 2016-12-10 06:48:31 --> URI Class Initialized
INFO - 2016-12-10 06:48:31 --> Router Class Initialized
INFO - 2016-12-10 06:48:31 --> Helper loaded: form_helper
INFO - 2016-12-10 06:48:31 --> Form Validation Class Initialized
INFO - 2016-12-10 06:48:31 --> Output Class Initialized
INFO - 2016-12-10 06:48:31 --> Security Class Initialized
DEBUG - 2016-12-10 06:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:48:31 --> Input Class Initialized
INFO - 2016-12-10 06:48:31 --> Language Class Initialized
INFO - 2016-12-10 06:48:31 --> Loader Class Initialized
INFO - 2016-12-10 06:48:31 --> Database Driver Class Initialized
INFO - 2016-12-10 06:48:31 --> Final output sent to browser
DEBUG - 2016-12-10 06:48:31 --> Total execution time: 0.0916
INFO - 2016-12-10 06:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:48:31 --> Controller Class Initialized
INFO - 2016-12-10 06:48:31 --> Helper loaded: date_helper
INFO - 2016-12-10 06:48:31 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:48:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:48:31 --> Helper loaded: form_helper
INFO - 2016-12-10 06:48:31 --> Form Validation Class Initialized
INFO - 2016-12-10 06:48:31 --> Final output sent to browser
DEBUG - 2016-12-10 06:48:31 --> Total execution time: 0.0842
INFO - 2016-12-10 06:48:39 --> Config Class Initialized
INFO - 2016-12-10 06:48:39 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:48:39 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:48:39 --> Utf8 Class Initialized
INFO - 2016-12-10 06:48:39 --> URI Class Initialized
INFO - 2016-12-10 06:48:39 --> Router Class Initialized
INFO - 2016-12-10 06:48:39 --> Output Class Initialized
INFO - 2016-12-10 06:48:39 --> Security Class Initialized
DEBUG - 2016-12-10 06:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:48:39 --> Input Class Initialized
INFO - 2016-12-10 06:48:39 --> Language Class Initialized
ERROR - 2016-12-10 06:48:39 --> 404 Page Not Found: Imagenes_recibos/undefined
INFO - 2016-12-10 06:48:57 --> Config Class Initialized
INFO - 2016-12-10 06:48:57 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:48:57 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:48:57 --> Utf8 Class Initialized
INFO - 2016-12-10 06:48:57 --> URI Class Initialized
INFO - 2016-12-10 06:48:57 --> Router Class Initialized
INFO - 2016-12-10 06:48:57 --> Output Class Initialized
INFO - 2016-12-10 06:48:57 --> Security Class Initialized
DEBUG - 2016-12-10 06:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:48:57 --> Input Class Initialized
INFO - 2016-12-10 06:48:57 --> Language Class Initialized
INFO - 2016-12-10 06:48:57 --> Loader Class Initialized
INFO - 2016-12-10 06:48:57 --> Database Driver Class Initialized
INFO - 2016-12-10 06:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:48:57 --> Controller Class Initialized
INFO - 2016-12-10 06:48:57 --> Upload Class Initialized
DEBUG - 2016-12-10 06:48:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:48:57 --> Helper loaded: url_helper
INFO - 2016-12-10 06:48:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:48:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 06:48:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 06:48:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-10 06:48:57 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-10 06:48:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:48:57 --> Final output sent to browser
DEBUG - 2016-12-10 06:48:57 --> Total execution time: 0.0155
INFO - 2016-12-10 06:48:57 --> Config Class Initialized
INFO - 2016-12-10 06:48:57 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:48:57 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:48:57 --> Utf8 Class Initialized
INFO - 2016-12-10 06:48:57 --> URI Class Initialized
INFO - 2016-12-10 06:48:57 --> Router Class Initialized
INFO - 2016-12-10 06:48:57 --> Output Class Initialized
INFO - 2016-12-10 06:48:57 --> Security Class Initialized
DEBUG - 2016-12-10 06:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:48:57 --> Input Class Initialized
INFO - 2016-12-10 06:48:57 --> Language Class Initialized
ERROR - 2016-12-10 06:48:57 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-10 06:48:57 --> Config Class Initialized
INFO - 2016-12-10 06:48:57 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:48:57 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:48:57 --> Utf8 Class Initialized
INFO - 2016-12-10 06:48:57 --> URI Class Initialized
INFO - 2016-12-10 06:48:57 --> Router Class Initialized
INFO - 2016-12-10 06:48:57 --> Output Class Initialized
INFO - 2016-12-10 06:48:57 --> Security Class Initialized
DEBUG - 2016-12-10 06:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:48:57 --> Input Class Initialized
INFO - 2016-12-10 06:48:57 --> Language Class Initialized
INFO - 2016-12-10 06:48:57 --> Loader Class Initialized
INFO - 2016-12-10 06:48:57 --> Database Driver Class Initialized
INFO - 2016-12-10 06:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:48:57 --> Controller Class Initialized
INFO - 2016-12-10 06:48:57 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:48:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:48:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:48:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:48:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:48:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:48:57 --> Final output sent to browser
DEBUG - 2016-12-10 06:48:57 --> Total execution time: 0.0140
INFO - 2016-12-10 06:49:05 --> Config Class Initialized
INFO - 2016-12-10 06:49:05 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:49:05 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:49:05 --> Utf8 Class Initialized
INFO - 2016-12-10 06:49:05 --> URI Class Initialized
INFO - 2016-12-10 06:49:05 --> Router Class Initialized
INFO - 2016-12-10 06:49:05 --> Output Class Initialized
INFO - 2016-12-10 06:49:05 --> Security Class Initialized
DEBUG - 2016-12-10 06:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:49:05 --> Input Class Initialized
INFO - 2016-12-10 06:49:05 --> Language Class Initialized
INFO - 2016-12-10 06:49:05 --> Loader Class Initialized
INFO - 2016-12-10 06:49:06 --> Database Driver Class Initialized
INFO - 2016-12-10 06:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:49:06 --> Controller Class Initialized
INFO - 2016-12-10 06:49:06 --> Helper loaded: date_helper
INFO - 2016-12-10 06:49:06 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:49:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:49:06 --> Helper loaded: form_helper
INFO - 2016-12-10 06:49:06 --> Form Validation Class Initialized
INFO - 2016-12-10 06:49:06 --> Final output sent to browser
DEBUG - 2016-12-10 06:49:06 --> Total execution time: 0.0152
INFO - 2016-12-10 06:49:06 --> Config Class Initialized
INFO - 2016-12-10 06:49:06 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:49:06 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:49:06 --> Utf8 Class Initialized
INFO - 2016-12-10 06:49:06 --> URI Class Initialized
INFO - 2016-12-10 06:49:06 --> Router Class Initialized
INFO - 2016-12-10 06:49:06 --> Output Class Initialized
INFO - 2016-12-10 06:49:06 --> Security Class Initialized
DEBUG - 2016-12-10 06:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:49:06 --> Input Class Initialized
INFO - 2016-12-10 06:49:06 --> Language Class Initialized
INFO - 2016-12-10 06:49:06 --> Loader Class Initialized
INFO - 2016-12-10 06:49:06 --> Database Driver Class Initialized
INFO - 2016-12-10 06:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:49:06 --> Controller Class Initialized
INFO - 2016-12-10 06:49:06 --> Helper loaded: date_helper
INFO - 2016-12-10 06:49:06 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:49:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:49:06 --> Helper loaded: form_helper
INFO - 2016-12-10 06:49:06 --> Form Validation Class Initialized
INFO - 2016-12-10 06:49:06 --> Final output sent to browser
DEBUG - 2016-12-10 06:49:06 --> Total execution time: 0.0151
INFO - 2016-12-10 06:49:06 --> Config Class Initialized
INFO - 2016-12-10 06:49:06 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:49:06 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:49:06 --> Utf8 Class Initialized
INFO - 2016-12-10 06:49:06 --> URI Class Initialized
INFO - 2016-12-10 06:49:06 --> Router Class Initialized
INFO - 2016-12-10 06:49:06 --> Output Class Initialized
INFO - 2016-12-10 06:49:06 --> Security Class Initialized
DEBUG - 2016-12-10 06:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:49:06 --> Input Class Initialized
INFO - 2016-12-10 06:49:06 --> Language Class Initialized
INFO - 2016-12-10 06:49:06 --> Loader Class Initialized
INFO - 2016-12-10 06:49:06 --> Database Driver Class Initialized
INFO - 2016-12-10 06:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:49:06 --> Controller Class Initialized
INFO - 2016-12-10 06:49:06 --> Helper loaded: date_helper
INFO - 2016-12-10 06:49:06 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:49:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:49:06 --> Helper loaded: form_helper
INFO - 2016-12-10 06:49:06 --> Form Validation Class Initialized
INFO - 2016-12-10 06:49:06 --> Final output sent to browser
DEBUG - 2016-12-10 06:49:06 --> Total execution time: 0.0149
INFO - 2016-12-10 06:49:12 --> Config Class Initialized
INFO - 2016-12-10 06:49:12 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:49:12 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:49:12 --> Utf8 Class Initialized
INFO - 2016-12-10 06:49:12 --> URI Class Initialized
INFO - 2016-12-10 06:49:12 --> Router Class Initialized
INFO - 2016-12-10 06:49:12 --> Output Class Initialized
INFO - 2016-12-10 06:49:12 --> Security Class Initialized
DEBUG - 2016-12-10 06:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:49:12 --> Input Class Initialized
INFO - 2016-12-10 06:49:12 --> Language Class Initialized
INFO - 2016-12-10 06:49:12 --> Loader Class Initialized
INFO - 2016-12-10 06:49:12 --> Database Driver Class Initialized
INFO - 2016-12-10 06:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:49:12 --> Controller Class Initialized
INFO - 2016-12-10 06:49:12 --> Upload Class Initialized
DEBUG - 2016-12-10 06:49:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:49:12 --> Helper loaded: url_helper
INFO - 2016-12-10 06:49:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:49:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 06:49:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 06:49:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-10 06:49:12 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-10 06:49:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:49:12 --> Final output sent to browser
DEBUG - 2016-12-10 06:49:12 --> Total execution time: 0.0152
INFO - 2016-12-10 06:49:12 --> Config Class Initialized
INFO - 2016-12-10 06:49:12 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:49:12 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:49:12 --> Utf8 Class Initialized
INFO - 2016-12-10 06:49:12 --> URI Class Initialized
INFO - 2016-12-10 06:49:12 --> Router Class Initialized
INFO - 2016-12-10 06:49:12 --> Output Class Initialized
INFO - 2016-12-10 06:49:12 --> Security Class Initialized
DEBUG - 2016-12-10 06:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:49:12 --> Input Class Initialized
INFO - 2016-12-10 06:49:12 --> Language Class Initialized
ERROR - 2016-12-10 06:49:12 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-10 06:49:13 --> Config Class Initialized
INFO - 2016-12-10 06:49:13 --> Hooks Class Initialized
DEBUG - 2016-12-10 06:49:13 --> UTF-8 Support Enabled
INFO - 2016-12-10 06:49:13 --> Utf8 Class Initialized
INFO - 2016-12-10 06:49:13 --> URI Class Initialized
INFO - 2016-12-10 06:49:13 --> Router Class Initialized
INFO - 2016-12-10 06:49:13 --> Output Class Initialized
INFO - 2016-12-10 06:49:13 --> Security Class Initialized
DEBUG - 2016-12-10 06:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 06:49:13 --> Input Class Initialized
INFO - 2016-12-10 06:49:13 --> Language Class Initialized
INFO - 2016-12-10 06:49:13 --> Loader Class Initialized
INFO - 2016-12-10 06:49:13 --> Database Driver Class Initialized
INFO - 2016-12-10 06:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 06:49:13 --> Controller Class Initialized
INFO - 2016-12-10 06:49:13 --> Helper loaded: url_helper
DEBUG - 2016-12-10 06:49:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 06:49:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 06:49:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 06:49:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 06:49:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 06:49:13 --> Final output sent to browser
DEBUG - 2016-12-10 06:49:13 --> Total execution time: 0.0136
INFO - 2016-12-10 18:43:02 --> Config Class Initialized
INFO - 2016-12-10 18:43:03 --> Hooks Class Initialized
DEBUG - 2016-12-10 18:43:03 --> UTF-8 Support Enabled
INFO - 2016-12-10 18:43:03 --> Utf8 Class Initialized
INFO - 2016-12-10 18:43:03 --> URI Class Initialized
DEBUG - 2016-12-10 18:43:03 --> No URI present. Default controller set.
INFO - 2016-12-10 18:43:03 --> Router Class Initialized
INFO - 2016-12-10 18:43:03 --> Output Class Initialized
INFO - 2016-12-10 18:43:03 --> Security Class Initialized
DEBUG - 2016-12-10 18:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 18:43:03 --> Input Class Initialized
INFO - 2016-12-10 18:43:03 --> Language Class Initialized
INFO - 2016-12-10 18:43:03 --> Loader Class Initialized
INFO - 2016-12-10 18:43:03 --> Database Driver Class Initialized
INFO - 2016-12-10 18:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 18:43:04 --> Controller Class Initialized
INFO - 2016-12-10 18:43:04 --> Helper loaded: url_helper
DEBUG - 2016-12-10 18:43:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 18:43:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 18:43:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 18:43:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 18:43:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 18:43:04 --> Final output sent to browser
DEBUG - 2016-12-10 18:43:04 --> Total execution time: 1.8121
INFO - 2016-12-10 18:43:12 --> Config Class Initialized
INFO - 2016-12-10 18:43:12 --> Hooks Class Initialized
DEBUG - 2016-12-10 18:43:12 --> UTF-8 Support Enabled
INFO - 2016-12-10 18:43:12 --> Utf8 Class Initialized
INFO - 2016-12-10 18:43:12 --> URI Class Initialized
INFO - 2016-12-10 18:43:12 --> Router Class Initialized
INFO - 2016-12-10 18:43:12 --> Output Class Initialized
INFO - 2016-12-10 18:43:12 --> Security Class Initialized
DEBUG - 2016-12-10 18:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 18:43:12 --> Input Class Initialized
INFO - 2016-12-10 18:43:12 --> Language Class Initialized
INFO - 2016-12-10 18:43:12 --> Loader Class Initialized
INFO - 2016-12-10 18:43:12 --> Database Driver Class Initialized
INFO - 2016-12-10 18:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 18:43:12 --> Controller Class Initialized
INFO - 2016-12-10 18:43:12 --> Helper loaded: url_helper
DEBUG - 2016-12-10 18:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 18:43:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 18:43:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 18:43:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 18:43:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 18:43:12 --> Final output sent to browser
DEBUG - 2016-12-10 18:43:12 --> Total execution time: 0.0135
INFO - 2016-12-10 18:43:47 --> Config Class Initialized
INFO - 2016-12-10 18:43:47 --> Hooks Class Initialized
DEBUG - 2016-12-10 18:43:47 --> UTF-8 Support Enabled
INFO - 2016-12-10 18:43:47 --> Utf8 Class Initialized
INFO - 2016-12-10 18:43:47 --> URI Class Initialized
INFO - 2016-12-10 18:43:47 --> Router Class Initialized
INFO - 2016-12-10 18:43:47 --> Output Class Initialized
INFO - 2016-12-10 18:43:47 --> Security Class Initialized
DEBUG - 2016-12-10 18:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 18:43:47 --> Input Class Initialized
INFO - 2016-12-10 18:43:47 --> Language Class Initialized
INFO - 2016-12-10 18:43:47 --> Loader Class Initialized
INFO - 2016-12-10 18:43:47 --> Database Driver Class Initialized
INFO - 2016-12-10 18:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 18:43:47 --> Controller Class Initialized
INFO - 2016-12-10 18:43:47 --> Helper loaded: url_helper
DEBUG - 2016-12-10 18:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 18:43:50 --> Config Class Initialized
INFO - 2016-12-10 18:43:50 --> Hooks Class Initialized
DEBUG - 2016-12-10 18:43:50 --> UTF-8 Support Enabled
INFO - 2016-12-10 18:43:50 --> Utf8 Class Initialized
INFO - 2016-12-10 18:43:50 --> URI Class Initialized
INFO - 2016-12-10 18:43:50 --> Router Class Initialized
INFO - 2016-12-10 18:43:50 --> Output Class Initialized
INFO - 2016-12-10 18:43:50 --> Security Class Initialized
DEBUG - 2016-12-10 18:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 18:43:50 --> Input Class Initialized
INFO - 2016-12-10 18:43:50 --> Language Class Initialized
INFO - 2016-12-10 18:43:50 --> Loader Class Initialized
INFO - 2016-12-10 18:43:50 --> Database Driver Class Initialized
INFO - 2016-12-10 18:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 18:43:50 --> Controller Class Initialized
DEBUG - 2016-12-10 18:43:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 18:43:50 --> Helper loaded: url_helper
INFO - 2016-12-10 18:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 18:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2016-12-10 18:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-10 18:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 18:43:50 --> Final output sent to browser
DEBUG - 2016-12-10 18:43:50 --> Total execution time: 0.0275
INFO - 2016-12-10 18:43:51 --> Config Class Initialized
INFO - 2016-12-10 18:43:51 --> Hooks Class Initialized
DEBUG - 2016-12-10 18:43:51 --> UTF-8 Support Enabled
INFO - 2016-12-10 18:43:51 --> Utf8 Class Initialized
INFO - 2016-12-10 18:43:51 --> URI Class Initialized
INFO - 2016-12-10 18:43:51 --> Router Class Initialized
INFO - 2016-12-10 18:43:51 --> Output Class Initialized
INFO - 2016-12-10 18:43:51 --> Security Class Initialized
DEBUG - 2016-12-10 18:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 18:43:51 --> Input Class Initialized
INFO - 2016-12-10 18:43:51 --> Language Class Initialized
INFO - 2016-12-10 18:43:51 --> Loader Class Initialized
INFO - 2016-12-10 18:43:51 --> Database Driver Class Initialized
INFO - 2016-12-10 18:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 18:43:51 --> Controller Class Initialized
INFO - 2016-12-10 18:43:51 --> Helper loaded: url_helper
DEBUG - 2016-12-10 18:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 18:43:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 18:43:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 18:43:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 18:43:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 18:43:51 --> Final output sent to browser
DEBUG - 2016-12-10 18:43:51 --> Total execution time: 0.0130
INFO - 2016-12-10 18:44:02 --> Config Class Initialized
INFO - 2016-12-10 18:44:02 --> Hooks Class Initialized
DEBUG - 2016-12-10 18:44:02 --> UTF-8 Support Enabled
INFO - 2016-12-10 18:44:02 --> Utf8 Class Initialized
INFO - 2016-12-10 18:44:02 --> URI Class Initialized
DEBUG - 2016-12-10 18:44:02 --> No URI present. Default controller set.
INFO - 2016-12-10 18:44:02 --> Router Class Initialized
INFO - 2016-12-10 18:44:02 --> Output Class Initialized
INFO - 2016-12-10 18:44:02 --> Security Class Initialized
DEBUG - 2016-12-10 18:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 18:44:02 --> Input Class Initialized
INFO - 2016-12-10 18:44:02 --> Language Class Initialized
INFO - 2016-12-10 18:44:02 --> Loader Class Initialized
INFO - 2016-12-10 18:44:02 --> Database Driver Class Initialized
INFO - 2016-12-10 18:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 18:44:02 --> Controller Class Initialized
INFO - 2016-12-10 18:44:02 --> Helper loaded: url_helper
DEBUG - 2016-12-10 18:44:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 18:44:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 18:44:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 18:44:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 18:44:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 18:44:02 --> Final output sent to browser
DEBUG - 2016-12-10 18:44:02 --> Total execution time: 0.0132
INFO - 2016-12-10 18:44:05 --> Config Class Initialized
INFO - 2016-12-10 18:44:05 --> Hooks Class Initialized
DEBUG - 2016-12-10 18:44:05 --> UTF-8 Support Enabled
INFO - 2016-12-10 18:44:05 --> Utf8 Class Initialized
INFO - 2016-12-10 18:44:05 --> URI Class Initialized
INFO - 2016-12-10 18:44:05 --> Router Class Initialized
INFO - 2016-12-10 18:44:05 --> Output Class Initialized
INFO - 2016-12-10 18:44:05 --> Security Class Initialized
DEBUG - 2016-12-10 18:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 18:44:05 --> Input Class Initialized
INFO - 2016-12-10 18:44:05 --> Language Class Initialized
INFO - 2016-12-10 18:44:05 --> Loader Class Initialized
INFO - 2016-12-10 18:44:05 --> Database Driver Class Initialized
INFO - 2016-12-10 18:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 18:44:05 --> Controller Class Initialized
INFO - 2016-12-10 18:44:05 --> Helper loaded: url_helper
DEBUG - 2016-12-10 18:44:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 18:44:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 18:44:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 18:44:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 18:44:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 18:44:05 --> Final output sent to browser
DEBUG - 2016-12-10 18:44:05 --> Total execution time: 0.0138
INFO - 2016-12-10 18:44:11 --> Config Class Initialized
INFO - 2016-12-10 18:44:11 --> Hooks Class Initialized
DEBUG - 2016-12-10 18:44:11 --> UTF-8 Support Enabled
INFO - 2016-12-10 18:44:11 --> Utf8 Class Initialized
INFO - 2016-12-10 18:44:11 --> URI Class Initialized
INFO - 2016-12-10 18:44:11 --> Router Class Initialized
INFO - 2016-12-10 18:44:11 --> Output Class Initialized
INFO - 2016-12-10 18:44:11 --> Security Class Initialized
DEBUG - 2016-12-10 18:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 18:44:11 --> Input Class Initialized
INFO - 2016-12-10 18:44:11 --> Language Class Initialized
INFO - 2016-12-10 18:44:11 --> Loader Class Initialized
INFO - 2016-12-10 18:44:11 --> Database Driver Class Initialized
INFO - 2016-12-10 18:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 18:44:11 --> Controller Class Initialized
INFO - 2016-12-10 18:44:11 --> Helper loaded: url_helper
DEBUG - 2016-12-10 18:44:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 18:44:12 --> Config Class Initialized
INFO - 2016-12-10 18:44:12 --> Hooks Class Initialized
DEBUG - 2016-12-10 18:44:12 --> UTF-8 Support Enabled
INFO - 2016-12-10 18:44:12 --> Utf8 Class Initialized
INFO - 2016-12-10 18:44:12 --> URI Class Initialized
INFO - 2016-12-10 18:44:12 --> Router Class Initialized
INFO - 2016-12-10 18:44:12 --> Output Class Initialized
INFO - 2016-12-10 18:44:12 --> Security Class Initialized
DEBUG - 2016-12-10 18:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 18:44:12 --> Input Class Initialized
INFO - 2016-12-10 18:44:12 --> Language Class Initialized
INFO - 2016-12-10 18:44:12 --> Loader Class Initialized
INFO - 2016-12-10 18:44:12 --> Database Driver Class Initialized
INFO - 2016-12-10 18:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 18:44:12 --> Controller Class Initialized
DEBUG - 2016-12-10 18:44:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 18:44:12 --> Helper loaded: url_helper
INFO - 2016-12-10 18:44:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 18:44:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2016-12-10 18:44:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-10 18:44:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 18:44:12 --> Final output sent to browser
DEBUG - 2016-12-10 18:44:12 --> Total execution time: 0.0121
INFO - 2016-12-10 18:44:13 --> Config Class Initialized
INFO - 2016-12-10 18:44:13 --> Hooks Class Initialized
DEBUG - 2016-12-10 18:44:13 --> UTF-8 Support Enabled
INFO - 2016-12-10 18:44:13 --> Utf8 Class Initialized
INFO - 2016-12-10 18:44:13 --> URI Class Initialized
INFO - 2016-12-10 18:44:13 --> Router Class Initialized
INFO - 2016-12-10 18:44:13 --> Output Class Initialized
INFO - 2016-12-10 18:44:13 --> Security Class Initialized
DEBUG - 2016-12-10 18:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 18:44:13 --> Input Class Initialized
INFO - 2016-12-10 18:44:13 --> Language Class Initialized
INFO - 2016-12-10 18:44:13 --> Loader Class Initialized
INFO - 2016-12-10 18:44:13 --> Database Driver Class Initialized
INFO - 2016-12-10 18:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 18:44:13 --> Controller Class Initialized
INFO - 2016-12-10 18:44:13 --> Helper loaded: url_helper
DEBUG - 2016-12-10 18:44:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 18:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 18:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 18:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 18:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 18:44:13 --> Final output sent to browser
DEBUG - 2016-12-10 18:44:13 --> Total execution time: 0.0135
INFO - 2016-12-10 18:44:29 --> Config Class Initialized
INFO - 2016-12-10 18:44:29 --> Hooks Class Initialized
DEBUG - 2016-12-10 18:44:29 --> UTF-8 Support Enabled
INFO - 2016-12-10 18:44:29 --> Utf8 Class Initialized
INFO - 2016-12-10 18:44:29 --> URI Class Initialized
DEBUG - 2016-12-10 18:44:29 --> No URI present. Default controller set.
INFO - 2016-12-10 18:44:29 --> Router Class Initialized
INFO - 2016-12-10 18:44:29 --> Output Class Initialized
INFO - 2016-12-10 18:44:29 --> Security Class Initialized
DEBUG - 2016-12-10 18:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 18:44:29 --> Input Class Initialized
INFO - 2016-12-10 18:44:29 --> Language Class Initialized
INFO - 2016-12-10 18:44:29 --> Loader Class Initialized
INFO - 2016-12-10 18:44:29 --> Database Driver Class Initialized
INFO - 2016-12-10 18:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 18:44:29 --> Controller Class Initialized
INFO - 2016-12-10 18:44:29 --> Helper loaded: url_helper
DEBUG - 2016-12-10 18:44:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 18:44:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 18:44:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 18:44:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 18:44:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 18:44:29 --> Final output sent to browser
DEBUG - 2016-12-10 18:44:29 --> Total execution time: 0.0207
INFO - 2016-12-10 18:44:32 --> Config Class Initialized
INFO - 2016-12-10 18:44:32 --> Hooks Class Initialized
DEBUG - 2016-12-10 18:44:32 --> UTF-8 Support Enabled
INFO - 2016-12-10 18:44:32 --> Utf8 Class Initialized
INFO - 2016-12-10 18:44:32 --> URI Class Initialized
INFO - 2016-12-10 18:44:32 --> Router Class Initialized
INFO - 2016-12-10 18:44:32 --> Output Class Initialized
INFO - 2016-12-10 18:44:32 --> Security Class Initialized
DEBUG - 2016-12-10 18:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 18:44:32 --> Input Class Initialized
INFO - 2016-12-10 18:44:32 --> Language Class Initialized
INFO - 2016-12-10 18:44:32 --> Loader Class Initialized
INFO - 2016-12-10 18:44:32 --> Database Driver Class Initialized
INFO - 2016-12-10 18:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 18:44:32 --> Controller Class Initialized
INFO - 2016-12-10 18:44:32 --> Helper loaded: url_helper
DEBUG - 2016-12-10 18:44:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 18:44:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 18:44:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 18:44:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 18:44:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 18:44:32 --> Final output sent to browser
DEBUG - 2016-12-10 18:44:32 --> Total execution time: 0.0142
INFO - 2016-12-10 18:44:35 --> Config Class Initialized
INFO - 2016-12-10 18:44:35 --> Hooks Class Initialized
DEBUG - 2016-12-10 18:44:35 --> UTF-8 Support Enabled
INFO - 2016-12-10 18:44:35 --> Utf8 Class Initialized
INFO - 2016-12-10 18:44:35 --> URI Class Initialized
INFO - 2016-12-10 18:44:35 --> Router Class Initialized
INFO - 2016-12-10 18:44:35 --> Output Class Initialized
INFO - 2016-12-10 18:44:35 --> Security Class Initialized
DEBUG - 2016-12-10 18:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 18:44:35 --> Input Class Initialized
INFO - 2016-12-10 18:44:35 --> Language Class Initialized
INFO - 2016-12-10 18:44:35 --> Loader Class Initialized
INFO - 2016-12-10 18:44:35 --> Database Driver Class Initialized
INFO - 2016-12-10 18:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 18:44:35 --> Controller Class Initialized
INFO - 2016-12-10 18:44:35 --> Helper loaded: url_helper
DEBUG - 2016-12-10 18:44:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 18:44:35 --> Config Class Initialized
INFO - 2016-12-10 18:44:35 --> Hooks Class Initialized
DEBUG - 2016-12-10 18:44:35 --> UTF-8 Support Enabled
INFO - 2016-12-10 18:44:35 --> Utf8 Class Initialized
INFO - 2016-12-10 18:44:35 --> URI Class Initialized
INFO - 2016-12-10 18:44:35 --> Router Class Initialized
INFO - 2016-12-10 18:44:35 --> Output Class Initialized
INFO - 2016-12-10 18:44:35 --> Security Class Initialized
DEBUG - 2016-12-10 18:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 18:44:35 --> Input Class Initialized
INFO - 2016-12-10 18:44:35 --> Language Class Initialized
INFO - 2016-12-10 18:44:35 --> Loader Class Initialized
INFO - 2016-12-10 18:44:35 --> Database Driver Class Initialized
INFO - 2016-12-10 18:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 18:44:35 --> Controller Class Initialized
DEBUG - 2016-12-10 18:44:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 18:44:35 --> Helper loaded: url_helper
INFO - 2016-12-10 18:44:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 18:44:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2016-12-10 18:44:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-10 18:44:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 18:44:35 --> Final output sent to browser
DEBUG - 2016-12-10 18:44:35 --> Total execution time: 0.0122
INFO - 2016-12-10 18:44:37 --> Config Class Initialized
INFO - 2016-12-10 18:44:37 --> Hooks Class Initialized
DEBUG - 2016-12-10 18:44:37 --> UTF-8 Support Enabled
INFO - 2016-12-10 18:44:37 --> Utf8 Class Initialized
INFO - 2016-12-10 18:44:37 --> URI Class Initialized
INFO - 2016-12-10 18:44:37 --> Router Class Initialized
INFO - 2016-12-10 18:44:37 --> Output Class Initialized
INFO - 2016-12-10 18:44:37 --> Security Class Initialized
DEBUG - 2016-12-10 18:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 18:44:37 --> Input Class Initialized
INFO - 2016-12-10 18:44:37 --> Language Class Initialized
INFO - 2016-12-10 18:44:37 --> Loader Class Initialized
INFO - 2016-12-10 18:44:37 --> Database Driver Class Initialized
INFO - 2016-12-10 18:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 18:44:37 --> Controller Class Initialized
INFO - 2016-12-10 18:44:37 --> Helper loaded: url_helper
DEBUG - 2016-12-10 18:44:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 18:44:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 18:44:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 18:44:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 18:44:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 18:44:37 --> Final output sent to browser
DEBUG - 2016-12-10 18:44:37 --> Total execution time: 0.0220
INFO - 2016-12-10 18:44:42 --> Config Class Initialized
INFO - 2016-12-10 18:44:42 --> Hooks Class Initialized
DEBUG - 2016-12-10 18:44:42 --> UTF-8 Support Enabled
INFO - 2016-12-10 18:44:42 --> Utf8 Class Initialized
INFO - 2016-12-10 18:44:42 --> URI Class Initialized
DEBUG - 2016-12-10 18:44:42 --> No URI present. Default controller set.
INFO - 2016-12-10 18:44:42 --> Router Class Initialized
INFO - 2016-12-10 18:44:42 --> Output Class Initialized
INFO - 2016-12-10 18:44:42 --> Security Class Initialized
DEBUG - 2016-12-10 18:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 18:44:42 --> Input Class Initialized
INFO - 2016-12-10 18:44:42 --> Language Class Initialized
INFO - 2016-12-10 18:44:42 --> Loader Class Initialized
INFO - 2016-12-10 18:44:42 --> Database Driver Class Initialized
INFO - 2016-12-10 18:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 18:44:42 --> Controller Class Initialized
INFO - 2016-12-10 18:44:42 --> Helper loaded: url_helper
DEBUG - 2016-12-10 18:44:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 18:44:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 18:44:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 18:44:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 18:44:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 18:44:42 --> Final output sent to browser
DEBUG - 2016-12-10 18:44:42 --> Total execution time: 0.0132
INFO - 2016-12-10 18:44:43 --> Config Class Initialized
INFO - 2016-12-10 18:44:43 --> Hooks Class Initialized
DEBUG - 2016-12-10 18:44:43 --> UTF-8 Support Enabled
INFO - 2016-12-10 18:44:43 --> Utf8 Class Initialized
INFO - 2016-12-10 18:44:43 --> URI Class Initialized
INFO - 2016-12-10 18:44:43 --> Router Class Initialized
INFO - 2016-12-10 18:44:43 --> Output Class Initialized
INFO - 2016-12-10 18:44:43 --> Security Class Initialized
DEBUG - 2016-12-10 18:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 18:44:43 --> Input Class Initialized
INFO - 2016-12-10 18:44:43 --> Language Class Initialized
INFO - 2016-12-10 18:44:43 --> Loader Class Initialized
INFO - 2016-12-10 18:44:43 --> Database Driver Class Initialized
INFO - 2016-12-10 18:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 18:44:43 --> Controller Class Initialized
INFO - 2016-12-10 18:44:43 --> Helper loaded: url_helper
DEBUG - 2016-12-10 18:44:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 18:44:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 18:44:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 18:44:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 18:44:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 18:44:43 --> Final output sent to browser
DEBUG - 2016-12-10 18:44:43 --> Total execution time: 0.0139
INFO - 2016-12-10 18:44:57 --> Config Class Initialized
INFO - 2016-12-10 18:44:57 --> Hooks Class Initialized
DEBUG - 2016-12-10 18:44:57 --> UTF-8 Support Enabled
INFO - 2016-12-10 18:44:57 --> Utf8 Class Initialized
INFO - 2016-12-10 18:44:57 --> URI Class Initialized
INFO - 2016-12-10 18:44:57 --> Router Class Initialized
INFO - 2016-12-10 18:44:57 --> Output Class Initialized
INFO - 2016-12-10 18:44:57 --> Security Class Initialized
DEBUG - 2016-12-10 18:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 18:44:57 --> Input Class Initialized
INFO - 2016-12-10 18:44:57 --> Language Class Initialized
INFO - 2016-12-10 18:44:57 --> Loader Class Initialized
INFO - 2016-12-10 18:44:57 --> Database Driver Class Initialized
INFO - 2016-12-10 18:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 18:44:57 --> Controller Class Initialized
INFO - 2016-12-10 18:44:57 --> Helper loaded: url_helper
DEBUG - 2016-12-10 18:44:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 18:44:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 18:44:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 18:44:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 18:44:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 18:44:57 --> Final output sent to browser
DEBUG - 2016-12-10 18:44:57 --> Total execution time: 0.0140
INFO - 2016-12-10 18:45:02 --> Config Class Initialized
INFO - 2016-12-10 18:45:02 --> Hooks Class Initialized
DEBUG - 2016-12-10 18:45:02 --> UTF-8 Support Enabled
INFO - 2016-12-10 18:45:02 --> Utf8 Class Initialized
INFO - 2016-12-10 18:45:02 --> URI Class Initialized
INFO - 2016-12-10 18:45:02 --> Router Class Initialized
INFO - 2016-12-10 18:45:02 --> Output Class Initialized
INFO - 2016-12-10 18:45:02 --> Security Class Initialized
DEBUG - 2016-12-10 18:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 18:45:02 --> Input Class Initialized
INFO - 2016-12-10 18:45:02 --> Language Class Initialized
INFO - 2016-12-10 18:45:02 --> Loader Class Initialized
INFO - 2016-12-10 18:45:02 --> Database Driver Class Initialized
INFO - 2016-12-10 18:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 18:45:02 --> Controller Class Initialized
INFO - 2016-12-10 18:45:02 --> Helper loaded: url_helper
DEBUG - 2016-12-10 18:45:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 18:45:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 18:45:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 18:45:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 18:45:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 18:45:02 --> Final output sent to browser
DEBUG - 2016-12-10 18:45:02 --> Total execution time: 0.0142
INFO - 2016-12-10 22:04:13 --> Config Class Initialized
INFO - 2016-12-10 22:04:13 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:04:13 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:04:13 --> Utf8 Class Initialized
INFO - 2016-12-10 22:04:13 --> URI Class Initialized
INFO - 2016-12-10 22:04:13 --> Router Class Initialized
INFO - 2016-12-10 22:04:13 --> Output Class Initialized
INFO - 2016-12-10 22:04:13 --> Security Class Initialized
DEBUG - 2016-12-10 22:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:04:13 --> Input Class Initialized
INFO - 2016-12-10 22:04:13 --> Language Class Initialized
INFO - 2016-12-10 22:04:13 --> Loader Class Initialized
INFO - 2016-12-10 22:04:13 --> Database Driver Class Initialized
INFO - 2016-12-10 22:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:04:13 --> Controller Class Initialized
INFO - 2016-12-10 22:04:13 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:04:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:04:13 --> Config Class Initialized
INFO - 2016-12-10 22:04:13 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:04:13 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:04:13 --> Utf8 Class Initialized
INFO - 2016-12-10 22:04:13 --> URI Class Initialized
DEBUG - 2016-12-10 22:04:13 --> No URI present. Default controller set.
INFO - 2016-12-10 22:04:13 --> Router Class Initialized
INFO - 2016-12-10 22:04:13 --> Output Class Initialized
INFO - 2016-12-10 22:04:13 --> Security Class Initialized
DEBUG - 2016-12-10 22:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:04:13 --> Input Class Initialized
INFO - 2016-12-10 22:04:13 --> Language Class Initialized
INFO - 2016-12-10 22:04:13 --> Loader Class Initialized
INFO - 2016-12-10 22:04:13 --> Database Driver Class Initialized
INFO - 2016-12-10 22:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:04:13 --> Controller Class Initialized
INFO - 2016-12-10 22:04:13 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:04:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:04:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:04:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:04:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:04:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:04:13 --> Final output sent to browser
DEBUG - 2016-12-10 22:04:13 --> Total execution time: 0.0135
INFO - 2016-12-10 22:04:13 --> Config Class Initialized
INFO - 2016-12-10 22:04:13 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:04:13 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:04:13 --> Utf8 Class Initialized
INFO - 2016-12-10 22:04:13 --> URI Class Initialized
INFO - 2016-12-10 22:04:13 --> Router Class Initialized
INFO - 2016-12-10 22:04:13 --> Output Class Initialized
INFO - 2016-12-10 22:04:13 --> Security Class Initialized
DEBUG - 2016-12-10 22:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:04:13 --> Input Class Initialized
INFO - 2016-12-10 22:04:13 --> Language Class Initialized
INFO - 2016-12-10 22:04:13 --> Loader Class Initialized
INFO - 2016-12-10 22:04:13 --> Database Driver Class Initialized
INFO - 2016-12-10 22:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:04:13 --> Controller Class Initialized
INFO - 2016-12-10 22:04:13 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:04:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:04:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:04:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:04:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:04:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:04:13 --> Final output sent to browser
DEBUG - 2016-12-10 22:04:13 --> Total execution time: 0.0137
INFO - 2016-12-10 22:04:14 --> Config Class Initialized
INFO - 2016-12-10 22:04:14 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:04:14 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:04:14 --> Utf8 Class Initialized
INFO - 2016-12-10 22:04:14 --> URI Class Initialized
INFO - 2016-12-10 22:04:14 --> Router Class Initialized
INFO - 2016-12-10 22:04:14 --> Output Class Initialized
INFO - 2016-12-10 22:04:14 --> Security Class Initialized
DEBUG - 2016-12-10 22:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:04:14 --> Input Class Initialized
INFO - 2016-12-10 22:04:14 --> Language Class Initialized
INFO - 2016-12-10 22:04:14 --> Loader Class Initialized
INFO - 2016-12-10 22:04:14 --> Database Driver Class Initialized
INFO - 2016-12-10 22:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:04:14 --> Controller Class Initialized
INFO - 2016-12-10 22:04:14 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:04:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:04:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:04:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:04:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:04:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:04:14 --> Final output sent to browser
DEBUG - 2016-12-10 22:04:14 --> Total execution time: 0.0151
INFO - 2016-12-10 22:04:29 --> Config Class Initialized
INFO - 2016-12-10 22:04:29 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:04:29 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:04:29 --> Utf8 Class Initialized
INFO - 2016-12-10 22:04:29 --> URI Class Initialized
INFO - 2016-12-10 22:04:29 --> Router Class Initialized
INFO - 2016-12-10 22:04:29 --> Output Class Initialized
INFO - 2016-12-10 22:04:29 --> Security Class Initialized
DEBUG - 2016-12-10 22:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:04:29 --> Input Class Initialized
INFO - 2016-12-10 22:04:29 --> Language Class Initialized
INFO - 2016-12-10 22:04:29 --> Loader Class Initialized
INFO - 2016-12-10 22:04:29 --> Database Driver Class Initialized
INFO - 2016-12-10 22:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:04:29 --> Controller Class Initialized
INFO - 2016-12-10 22:04:29 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:04:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:04:30 --> Config Class Initialized
INFO - 2016-12-10 22:04:30 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:04:30 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:04:30 --> Utf8 Class Initialized
INFO - 2016-12-10 22:04:30 --> URI Class Initialized
INFO - 2016-12-10 22:04:30 --> Router Class Initialized
INFO - 2016-12-10 22:04:30 --> Output Class Initialized
INFO - 2016-12-10 22:04:30 --> Security Class Initialized
DEBUG - 2016-12-10 22:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:04:30 --> Input Class Initialized
INFO - 2016-12-10 22:04:30 --> Language Class Initialized
INFO - 2016-12-10 22:04:30 --> Loader Class Initialized
INFO - 2016-12-10 22:04:30 --> Database Driver Class Initialized
INFO - 2016-12-10 22:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:04:30 --> Controller Class Initialized
DEBUG - 2016-12-10 22:04:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:04:30 --> Helper loaded: url_helper
INFO - 2016-12-10 22:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 22:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-10 22:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-10 22:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:04:30 --> Final output sent to browser
DEBUG - 2016-12-10 22:04:30 --> Total execution time: 0.0802
INFO - 2016-12-10 22:04:30 --> Config Class Initialized
INFO - 2016-12-10 22:04:30 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:04:30 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:04:30 --> Utf8 Class Initialized
INFO - 2016-12-10 22:04:30 --> URI Class Initialized
INFO - 2016-12-10 22:04:30 --> Router Class Initialized
INFO - 2016-12-10 22:04:30 --> Output Class Initialized
INFO - 2016-12-10 22:04:30 --> Security Class Initialized
DEBUG - 2016-12-10 22:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:04:30 --> Input Class Initialized
INFO - 2016-12-10 22:04:30 --> Language Class Initialized
INFO - 2016-12-10 22:04:30 --> Loader Class Initialized
INFO - 2016-12-10 22:04:30 --> Database Driver Class Initialized
INFO - 2016-12-10 22:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:04:30 --> Controller Class Initialized
INFO - 2016-12-10 22:04:30 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:04:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:04:30 --> Final output sent to browser
DEBUG - 2016-12-10 22:04:30 --> Total execution time: 0.0135
INFO - 2016-12-10 22:04:39 --> Config Class Initialized
INFO - 2016-12-10 22:04:39 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:04:39 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:04:39 --> Utf8 Class Initialized
INFO - 2016-12-10 22:04:39 --> URI Class Initialized
INFO - 2016-12-10 22:04:39 --> Router Class Initialized
INFO - 2016-12-10 22:04:39 --> Output Class Initialized
INFO - 2016-12-10 22:04:39 --> Security Class Initialized
DEBUG - 2016-12-10 22:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:04:39 --> Input Class Initialized
INFO - 2016-12-10 22:04:39 --> Language Class Initialized
INFO - 2016-12-10 22:04:39 --> Loader Class Initialized
INFO - 2016-12-10 22:04:39 --> Database Driver Class Initialized
INFO - 2016-12-10 22:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:04:39 --> Controller Class Initialized
INFO - 2016-12-10 22:04:40 --> Helper loaded: date_helper
DEBUG - 2016-12-10 22:04:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:04:40 --> Helper loaded: url_helper
INFO - 2016-12-10 22:04:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:04:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 22:04:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-10 22:04:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-10 22:04:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:04:40 --> Final output sent to browser
DEBUG - 2016-12-10 22:04:40 --> Total execution time: 0.7702
INFO - 2016-12-10 22:04:41 --> Config Class Initialized
INFO - 2016-12-10 22:04:41 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:04:41 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:04:41 --> Utf8 Class Initialized
INFO - 2016-12-10 22:04:41 --> URI Class Initialized
INFO - 2016-12-10 22:04:41 --> Router Class Initialized
INFO - 2016-12-10 22:04:41 --> Output Class Initialized
INFO - 2016-12-10 22:04:41 --> Security Class Initialized
DEBUG - 2016-12-10 22:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:04:41 --> Input Class Initialized
INFO - 2016-12-10 22:04:41 --> Language Class Initialized
INFO - 2016-12-10 22:04:41 --> Loader Class Initialized
INFO - 2016-12-10 22:04:41 --> Database Driver Class Initialized
INFO - 2016-12-10 22:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:04:41 --> Controller Class Initialized
INFO - 2016-12-10 22:04:41 --> Helper loaded: date_helper
DEBUG - 2016-12-10 22:04:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:04:41 --> Helper loaded: url_helper
INFO - 2016-12-10 22:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 22:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-10 22:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-10 22:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:04:41 --> Final output sent to browser
DEBUG - 2016-12-10 22:04:41 --> Total execution time: 0.0172
INFO - 2016-12-10 22:04:41 --> Config Class Initialized
INFO - 2016-12-10 22:04:41 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:04:41 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:04:41 --> Utf8 Class Initialized
INFO - 2016-12-10 22:04:41 --> URI Class Initialized
INFO - 2016-12-10 22:04:41 --> Router Class Initialized
INFO - 2016-12-10 22:04:41 --> Output Class Initialized
INFO - 2016-12-10 22:04:41 --> Security Class Initialized
DEBUG - 2016-12-10 22:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:04:41 --> Input Class Initialized
INFO - 2016-12-10 22:04:41 --> Language Class Initialized
INFO - 2016-12-10 22:04:41 --> Loader Class Initialized
INFO - 2016-12-10 22:04:41 --> Database Driver Class Initialized
INFO - 2016-12-10 22:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:04:41 --> Controller Class Initialized
INFO - 2016-12-10 22:04:41 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:04:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:04:41 --> Final output sent to browser
DEBUG - 2016-12-10 22:04:41 --> Total execution time: 0.0138
INFO - 2016-12-10 22:05:00 --> Config Class Initialized
INFO - 2016-12-10 22:05:00 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:05:00 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:05:00 --> Utf8 Class Initialized
INFO - 2016-12-10 22:05:00 --> URI Class Initialized
INFO - 2016-12-10 22:05:00 --> Router Class Initialized
INFO - 2016-12-10 22:05:00 --> Output Class Initialized
INFO - 2016-12-10 22:05:00 --> Security Class Initialized
DEBUG - 2016-12-10 22:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:05:00 --> Input Class Initialized
INFO - 2016-12-10 22:05:00 --> Language Class Initialized
INFO - 2016-12-10 22:05:00 --> Loader Class Initialized
INFO - 2016-12-10 22:05:00 --> Database Driver Class Initialized
INFO - 2016-12-10 22:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:05:00 --> Controller Class Initialized
DEBUG - 2016-12-10 22:05:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:05:00 --> Helper loaded: url_helper
INFO - 2016-12-10 22:05:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:05:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-10 22:05:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 22:05:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-10 22:05:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-10 22:05:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:05:00 --> Final output sent to browser
DEBUG - 2016-12-10 22:05:00 --> Total execution time: 0.0905
INFO - 2016-12-10 22:05:01 --> Config Class Initialized
INFO - 2016-12-10 22:05:01 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:05:01 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:05:01 --> Utf8 Class Initialized
INFO - 2016-12-10 22:05:01 --> URI Class Initialized
INFO - 2016-12-10 22:05:01 --> Router Class Initialized
INFO - 2016-12-10 22:05:01 --> Output Class Initialized
INFO - 2016-12-10 22:05:01 --> Security Class Initialized
DEBUG - 2016-12-10 22:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:05:01 --> Input Class Initialized
INFO - 2016-12-10 22:05:01 --> Language Class Initialized
INFO - 2016-12-10 22:05:01 --> Loader Class Initialized
INFO - 2016-12-10 22:05:01 --> Database Driver Class Initialized
INFO - 2016-12-10 22:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:05:01 --> Controller Class Initialized
INFO - 2016-12-10 22:05:01 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:05:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:05:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:05:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:05:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:05:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:05:01 --> Final output sent to browser
DEBUG - 2016-12-10 22:05:01 --> Total execution time: 0.0139
INFO - 2016-12-10 22:05:08 --> Config Class Initialized
INFO - 2016-12-10 22:05:08 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:05:08 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:05:08 --> Utf8 Class Initialized
INFO - 2016-12-10 22:05:08 --> URI Class Initialized
INFO - 2016-12-10 22:05:08 --> Router Class Initialized
INFO - 2016-12-10 22:05:08 --> Output Class Initialized
INFO - 2016-12-10 22:05:08 --> Security Class Initialized
DEBUG - 2016-12-10 22:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:05:08 --> Input Class Initialized
INFO - 2016-12-10 22:05:08 --> Language Class Initialized
INFO - 2016-12-10 22:05:08 --> Loader Class Initialized
INFO - 2016-12-10 22:05:08 --> Database Driver Class Initialized
INFO - 2016-12-10 22:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:05:08 --> Controller Class Initialized
INFO - 2016-12-10 22:05:08 --> Upload Class Initialized
DEBUG - 2016-12-10 22:05:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:05:08 --> Helper loaded: url_helper
INFO - 2016-12-10 22:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 22:05:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 22:05:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-10 22:05:10 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-10 22:05:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:05:10 --> Final output sent to browser
DEBUG - 2016-12-10 22:05:10 --> Total execution time: 1.7914
INFO - 2016-12-10 22:05:10 --> Config Class Initialized
INFO - 2016-12-10 22:05:10 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:05:10 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:05:10 --> Utf8 Class Initialized
INFO - 2016-12-10 22:05:10 --> URI Class Initialized
INFO - 2016-12-10 22:05:10 --> Router Class Initialized
INFO - 2016-12-10 22:05:10 --> Output Class Initialized
INFO - 2016-12-10 22:05:10 --> Security Class Initialized
DEBUG - 2016-12-10 22:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:05:10 --> Input Class Initialized
INFO - 2016-12-10 22:05:10 --> Language Class Initialized
INFO - 2016-12-10 22:05:10 --> Loader Class Initialized
INFO - 2016-12-10 22:05:10 --> Database Driver Class Initialized
INFO - 2016-12-10 22:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:05:10 --> Controller Class Initialized
INFO - 2016-12-10 22:05:10 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:05:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:05:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:05:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:05:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:05:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:05:10 --> Final output sent to browser
DEBUG - 2016-12-10 22:05:10 --> Total execution time: 0.0166
INFO - 2016-12-10 22:05:33 --> Config Class Initialized
INFO - 2016-12-10 22:05:33 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:05:33 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:05:33 --> Utf8 Class Initialized
INFO - 2016-12-10 22:05:33 --> URI Class Initialized
INFO - 2016-12-10 22:05:33 --> Router Class Initialized
INFO - 2016-12-10 22:05:33 --> Output Class Initialized
INFO - 2016-12-10 22:05:33 --> Security Class Initialized
DEBUG - 2016-12-10 22:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:05:33 --> Input Class Initialized
INFO - 2016-12-10 22:05:33 --> Language Class Initialized
INFO - 2016-12-10 22:05:33 --> Loader Class Initialized
INFO - 2016-12-10 22:05:33 --> Database Driver Class Initialized
INFO - 2016-12-10 22:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:05:33 --> Controller Class Initialized
INFO - 2016-12-10 22:05:33 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:05:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:05:33 --> Helper loaded: form_helper
INFO - 2016-12-10 22:05:33 --> Form Validation Class Initialized
INFO - 2016-12-10 22:05:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 22:05:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2016-12-10 22:05:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 22:05:33 --> Final output sent to browser
DEBUG - 2016-12-10 22:05:33 --> Total execution time: 0.1623
INFO - 2016-12-10 22:05:34 --> Config Class Initialized
INFO - 2016-12-10 22:05:34 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:05:34 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:05:34 --> Utf8 Class Initialized
INFO - 2016-12-10 22:05:34 --> URI Class Initialized
INFO - 2016-12-10 22:05:34 --> Router Class Initialized
INFO - 2016-12-10 22:05:34 --> Output Class Initialized
INFO - 2016-12-10 22:05:34 --> Security Class Initialized
DEBUG - 2016-12-10 22:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:05:34 --> Input Class Initialized
INFO - 2016-12-10 22:05:34 --> Language Class Initialized
INFO - 2016-12-10 22:05:34 --> Loader Class Initialized
INFO - 2016-12-10 22:05:34 --> Database Driver Class Initialized
INFO - 2016-12-10 22:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:05:34 --> Controller Class Initialized
INFO - 2016-12-10 22:05:34 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:05:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:05:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:05:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:05:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:05:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:05:34 --> Final output sent to browser
DEBUG - 2016-12-10 22:05:34 --> Total execution time: 0.0130
INFO - 2016-12-10 22:05:43 --> Config Class Initialized
INFO - 2016-12-10 22:05:43 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:05:43 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:05:43 --> Utf8 Class Initialized
INFO - 2016-12-10 22:05:43 --> URI Class Initialized
INFO - 2016-12-10 22:05:43 --> Router Class Initialized
INFO - 2016-12-10 22:05:43 --> Output Class Initialized
INFO - 2016-12-10 22:05:43 --> Security Class Initialized
DEBUG - 2016-12-10 22:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:05:43 --> Input Class Initialized
INFO - 2016-12-10 22:05:43 --> Language Class Initialized
INFO - 2016-12-10 22:05:43 --> Loader Class Initialized
INFO - 2016-12-10 22:05:43 --> Database Driver Class Initialized
INFO - 2016-12-10 22:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:05:43 --> Controller Class Initialized
INFO - 2016-12-10 22:05:43 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:05:43 --> Helper loaded: form_helper
INFO - 2016-12-10 22:05:43 --> Form Validation Class Initialized
INFO - 2016-12-10 22:05:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-10 22:05:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 22:05:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2016-12-10 22:05:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 22:05:43 --> Final output sent to browser
DEBUG - 2016-12-10 22:05:43 --> Total execution time: 0.0702
INFO - 2016-12-10 22:05:43 --> Config Class Initialized
INFO - 2016-12-10 22:05:43 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:05:43 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:05:43 --> Utf8 Class Initialized
INFO - 2016-12-10 22:05:43 --> URI Class Initialized
INFO - 2016-12-10 22:05:43 --> Router Class Initialized
INFO - 2016-12-10 22:05:43 --> Output Class Initialized
INFO - 2016-12-10 22:05:43 --> Security Class Initialized
DEBUG - 2016-12-10 22:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:05:43 --> Input Class Initialized
INFO - 2016-12-10 22:05:43 --> Language Class Initialized
INFO - 2016-12-10 22:05:43 --> Loader Class Initialized
INFO - 2016-12-10 22:05:43 --> Database Driver Class Initialized
INFO - 2016-12-10 22:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:05:43 --> Controller Class Initialized
INFO - 2016-12-10 22:05:43 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:05:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:05:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:05:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:05:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:05:43 --> Final output sent to browser
DEBUG - 2016-12-10 22:05:43 --> Total execution time: 0.0141
INFO - 2016-12-10 22:05:48 --> Config Class Initialized
INFO - 2016-12-10 22:05:48 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:05:48 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:05:48 --> Utf8 Class Initialized
INFO - 2016-12-10 22:05:48 --> URI Class Initialized
INFO - 2016-12-10 22:05:48 --> Router Class Initialized
INFO - 2016-12-10 22:05:48 --> Output Class Initialized
INFO - 2016-12-10 22:05:48 --> Security Class Initialized
DEBUG - 2016-12-10 22:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:05:48 --> Input Class Initialized
INFO - 2016-12-10 22:05:48 --> Language Class Initialized
INFO - 2016-12-10 22:05:48 --> Loader Class Initialized
INFO - 2016-12-10 22:05:48 --> Database Driver Class Initialized
INFO - 2016-12-10 22:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:05:48 --> Controller Class Initialized
INFO - 2016-12-10 22:05:48 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:05:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:05:48 --> Helper loaded: form_helper
INFO - 2016-12-10 22:05:48 --> Form Validation Class Initialized
INFO - 2016-12-10 22:05:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-10 22:05:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 22:05:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2016-12-10 22:05:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 22:05:48 --> Final output sent to browser
DEBUG - 2016-12-10 22:05:48 --> Total execution time: 0.0149
INFO - 2016-12-10 22:05:48 --> Config Class Initialized
INFO - 2016-12-10 22:05:48 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:05:48 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:05:48 --> Utf8 Class Initialized
INFO - 2016-12-10 22:05:48 --> URI Class Initialized
INFO - 2016-12-10 22:05:48 --> Router Class Initialized
INFO - 2016-12-10 22:05:48 --> Output Class Initialized
INFO - 2016-12-10 22:05:48 --> Security Class Initialized
DEBUG - 2016-12-10 22:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:05:48 --> Input Class Initialized
INFO - 2016-12-10 22:05:48 --> Language Class Initialized
INFO - 2016-12-10 22:05:48 --> Loader Class Initialized
INFO - 2016-12-10 22:05:48 --> Database Driver Class Initialized
INFO - 2016-12-10 22:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:05:48 --> Controller Class Initialized
INFO - 2016-12-10 22:05:48 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:05:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:05:48 --> Final output sent to browser
DEBUG - 2016-12-10 22:05:48 --> Total execution time: 0.0136
INFO - 2016-12-10 22:05:55 --> Config Class Initialized
INFO - 2016-12-10 22:05:55 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:05:55 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:05:55 --> Utf8 Class Initialized
INFO - 2016-12-10 22:05:55 --> URI Class Initialized
INFO - 2016-12-10 22:05:55 --> Router Class Initialized
INFO - 2016-12-10 22:05:55 --> Output Class Initialized
INFO - 2016-12-10 22:05:55 --> Security Class Initialized
DEBUG - 2016-12-10 22:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:05:55 --> Input Class Initialized
INFO - 2016-12-10 22:05:55 --> Language Class Initialized
INFO - 2016-12-10 22:05:55 --> Loader Class Initialized
INFO - 2016-12-10 22:05:55 --> Database Driver Class Initialized
INFO - 2016-12-10 22:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:05:55 --> Controller Class Initialized
INFO - 2016-12-10 22:05:55 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:05:55 --> Helper loaded: form_helper
INFO - 2016-12-10 22:05:55 --> Form Validation Class Initialized
INFO - 2016-12-10 22:05:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-10 22:05:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 22:05:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2016-12-10 22:05:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 22:05:55 --> Final output sent to browser
DEBUG - 2016-12-10 22:05:55 --> Total execution time: 0.0664
INFO - 2016-12-10 22:05:56 --> Config Class Initialized
INFO - 2016-12-10 22:05:56 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:05:56 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:05:56 --> Utf8 Class Initialized
INFO - 2016-12-10 22:05:56 --> URI Class Initialized
INFO - 2016-12-10 22:05:56 --> Router Class Initialized
INFO - 2016-12-10 22:05:56 --> Output Class Initialized
INFO - 2016-12-10 22:05:56 --> Security Class Initialized
DEBUG - 2016-12-10 22:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:05:56 --> Input Class Initialized
INFO - 2016-12-10 22:05:56 --> Language Class Initialized
INFO - 2016-12-10 22:05:56 --> Loader Class Initialized
INFO - 2016-12-10 22:05:56 --> Database Driver Class Initialized
INFO - 2016-12-10 22:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:05:56 --> Controller Class Initialized
INFO - 2016-12-10 22:05:56 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:05:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:05:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:05:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:05:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:05:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:05:56 --> Final output sent to browser
DEBUG - 2016-12-10 22:05:56 --> Total execution time: 0.0139
INFO - 2016-12-10 22:07:00 --> Config Class Initialized
INFO - 2016-12-10 22:07:00 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:07:00 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:07:00 --> Utf8 Class Initialized
INFO - 2016-12-10 22:07:00 --> URI Class Initialized
INFO - 2016-12-10 22:07:00 --> Router Class Initialized
INFO - 2016-12-10 22:07:00 --> Output Class Initialized
INFO - 2016-12-10 22:07:00 --> Security Class Initialized
DEBUG - 2016-12-10 22:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:07:00 --> Input Class Initialized
INFO - 2016-12-10 22:07:00 --> Language Class Initialized
INFO - 2016-12-10 22:07:00 --> Loader Class Initialized
INFO - 2016-12-10 22:07:00 --> Database Driver Class Initialized
INFO - 2016-12-10 22:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:07:00 --> Controller Class Initialized
INFO - 2016-12-10 22:07:00 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:07:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:07:00 --> Helper loaded: form_helper
INFO - 2016-12-10 22:07:00 --> Form Validation Class Initialized
INFO - 2016-12-10 22:07:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-10 22:07:00 --> Config Class Initialized
INFO - 2016-12-10 22:07:00 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:07:00 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:07:00 --> Utf8 Class Initialized
INFO - 2016-12-10 22:07:00 --> URI Class Initialized
INFO - 2016-12-10 22:07:00 --> Router Class Initialized
INFO - 2016-12-10 22:07:00 --> Output Class Initialized
INFO - 2016-12-10 22:07:00 --> Security Class Initialized
DEBUG - 2016-12-10 22:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:07:00 --> Input Class Initialized
INFO - 2016-12-10 22:07:00 --> Language Class Initialized
INFO - 2016-12-10 22:07:00 --> Loader Class Initialized
INFO - 2016-12-10 22:07:00 --> Database Driver Class Initialized
INFO - 2016-12-10 22:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:07:00 --> Controller Class Initialized
INFO - 2016-12-10 22:07:00 --> Helper loaded: date_helper
INFO - 2016-12-10 22:07:00 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:07:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:07:00 --> Helper loaded: form_helper
INFO - 2016-12-10 22:07:00 --> Form Validation Class Initialized
INFO - 2016-12-10 22:07:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 22:07:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-10 22:07:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2016-12-10 22:07:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2016-12-10 22:07:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 22:07:00 --> Final output sent to browser
DEBUG - 2016-12-10 22:07:00 --> Total execution time: 0.0836
INFO - 2016-12-10 22:07:01 --> Config Class Initialized
INFO - 2016-12-10 22:07:01 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:07:01 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:07:01 --> Utf8 Class Initialized
INFO - 2016-12-10 22:07:01 --> URI Class Initialized
INFO - 2016-12-10 22:07:01 --> Router Class Initialized
INFO - 2016-12-10 22:07:01 --> Output Class Initialized
INFO - 2016-12-10 22:07:01 --> Security Class Initialized
DEBUG - 2016-12-10 22:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:07:01 --> Input Class Initialized
INFO - 2016-12-10 22:07:01 --> Language Class Initialized
INFO - 2016-12-10 22:07:01 --> Loader Class Initialized
INFO - 2016-12-10 22:07:01 --> Database Driver Class Initialized
INFO - 2016-12-10 22:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:07:01 --> Controller Class Initialized
INFO - 2016-12-10 22:07:01 --> Helper loaded: date_helper
INFO - 2016-12-10 22:07:01 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:07:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:07:01 --> Helper loaded: form_helper
INFO - 2016-12-10 22:07:01 --> Form Validation Class Initialized
INFO - 2016-12-10 22:07:01 --> Final output sent to browser
DEBUG - 2016-12-10 22:07:01 --> Total execution time: 0.0171
INFO - 2016-12-10 22:07:01 --> Config Class Initialized
INFO - 2016-12-10 22:07:01 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:07:01 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:07:01 --> Utf8 Class Initialized
INFO - 2016-12-10 22:07:01 --> URI Class Initialized
INFO - 2016-12-10 22:07:01 --> Router Class Initialized
INFO - 2016-12-10 22:07:01 --> Output Class Initialized
INFO - 2016-12-10 22:07:01 --> Security Class Initialized
DEBUG - 2016-12-10 22:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:07:01 --> Input Class Initialized
INFO - 2016-12-10 22:07:01 --> Language Class Initialized
INFO - 2016-12-10 22:07:01 --> Loader Class Initialized
INFO - 2016-12-10 22:07:01 --> Database Driver Class Initialized
INFO - 2016-12-10 22:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:07:01 --> Controller Class Initialized
INFO - 2016-12-10 22:07:01 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:07:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:07:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:07:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:07:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:07:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:07:01 --> Final output sent to browser
DEBUG - 2016-12-10 22:07:01 --> Total execution time: 0.0134
INFO - 2016-12-10 22:07:08 --> Config Class Initialized
INFO - 2016-12-10 22:07:08 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:07:08 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:07:08 --> Utf8 Class Initialized
INFO - 2016-12-10 22:07:08 --> URI Class Initialized
INFO - 2016-12-10 22:07:08 --> Router Class Initialized
INFO - 2016-12-10 22:07:08 --> Output Class Initialized
INFO - 2016-12-10 22:07:08 --> Security Class Initialized
DEBUG - 2016-12-10 22:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:07:08 --> Input Class Initialized
INFO - 2016-12-10 22:07:08 --> Language Class Initialized
INFO - 2016-12-10 22:07:08 --> Loader Class Initialized
INFO - 2016-12-10 22:07:08 --> Database Driver Class Initialized
INFO - 2016-12-10 22:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:07:08 --> Controller Class Initialized
INFO - 2016-12-10 22:07:08 --> Helper loaded: date_helper
INFO - 2016-12-10 22:07:08 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:07:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:07:08 --> Helper loaded: form_helper
INFO - 2016-12-10 22:07:08 --> Form Validation Class Initialized
INFO - 2016-12-10 22:07:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 22:07:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-10 22:07:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2016-12-10 22:07:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2016-12-10 22:07:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 22:07:08 --> Final output sent to browser
DEBUG - 2016-12-10 22:07:08 --> Total execution time: 0.0405
INFO - 2016-12-10 22:07:08 --> Config Class Initialized
INFO - 2016-12-10 22:07:08 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:07:08 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:07:08 --> Utf8 Class Initialized
INFO - 2016-12-10 22:07:08 --> URI Class Initialized
INFO - 2016-12-10 22:07:08 --> Router Class Initialized
INFO - 2016-12-10 22:07:08 --> Output Class Initialized
INFO - 2016-12-10 22:07:08 --> Security Class Initialized
DEBUG - 2016-12-10 22:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:07:08 --> Input Class Initialized
INFO - 2016-12-10 22:07:08 --> Language Class Initialized
INFO - 2016-12-10 22:07:08 --> Loader Class Initialized
INFO - 2016-12-10 22:07:08 --> Database Driver Class Initialized
INFO - 2016-12-10 22:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:07:08 --> Controller Class Initialized
INFO - 2016-12-10 22:07:08 --> Helper loaded: date_helper
INFO - 2016-12-10 22:07:08 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:07:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:07:08 --> Helper loaded: form_helper
INFO - 2016-12-10 22:07:08 --> Form Validation Class Initialized
INFO - 2016-12-10 22:07:08 --> Final output sent to browser
DEBUG - 2016-12-10 22:07:08 --> Total execution time: 0.0140
INFO - 2016-12-10 22:07:09 --> Config Class Initialized
INFO - 2016-12-10 22:07:09 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:07:09 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:07:09 --> Utf8 Class Initialized
INFO - 2016-12-10 22:07:09 --> URI Class Initialized
INFO - 2016-12-10 22:07:09 --> Router Class Initialized
INFO - 2016-12-10 22:07:09 --> Output Class Initialized
INFO - 2016-12-10 22:07:09 --> Security Class Initialized
DEBUG - 2016-12-10 22:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:07:09 --> Input Class Initialized
INFO - 2016-12-10 22:07:09 --> Language Class Initialized
INFO - 2016-12-10 22:07:09 --> Loader Class Initialized
INFO - 2016-12-10 22:07:09 --> Database Driver Class Initialized
INFO - 2016-12-10 22:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:07:09 --> Controller Class Initialized
INFO - 2016-12-10 22:07:09 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:07:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:07:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:07:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:07:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:07:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:07:09 --> Final output sent to browser
DEBUG - 2016-12-10 22:07:09 --> Total execution time: 0.0128
INFO - 2016-12-10 22:07:12 --> Config Class Initialized
INFO - 2016-12-10 22:07:12 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:07:12 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:07:12 --> Utf8 Class Initialized
INFO - 2016-12-10 22:07:12 --> URI Class Initialized
INFO - 2016-12-10 22:07:12 --> Router Class Initialized
INFO - 2016-12-10 22:07:12 --> Output Class Initialized
INFO - 2016-12-10 22:07:12 --> Security Class Initialized
DEBUG - 2016-12-10 22:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:07:12 --> Input Class Initialized
INFO - 2016-12-10 22:07:12 --> Language Class Initialized
INFO - 2016-12-10 22:07:12 --> Loader Class Initialized
INFO - 2016-12-10 22:07:12 --> Database Driver Class Initialized
INFO - 2016-12-10 22:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:07:12 --> Controller Class Initialized
INFO - 2016-12-10 22:07:12 --> Helper loaded: date_helper
INFO - 2016-12-10 22:07:12 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:07:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:07:12 --> Helper loaded: form_helper
INFO - 2016-12-10 22:07:12 --> Form Validation Class Initialized
INFO - 2016-12-10 22:07:12 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 22:07:12 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-10 22:07:12 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2016-12-10 22:07:12 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2016-12-10 22:07:12 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 22:07:12 --> Final output sent to browser
DEBUG - 2016-12-10 22:07:12 --> Total execution time: 0.0146
INFO - 2016-12-10 22:07:12 --> Config Class Initialized
INFO - 2016-12-10 22:07:12 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:07:12 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:07:12 --> Utf8 Class Initialized
INFO - 2016-12-10 22:07:12 --> URI Class Initialized
INFO - 2016-12-10 22:07:12 --> Router Class Initialized
INFO - 2016-12-10 22:07:12 --> Output Class Initialized
INFO - 2016-12-10 22:07:12 --> Security Class Initialized
DEBUG - 2016-12-10 22:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:07:12 --> Input Class Initialized
INFO - 2016-12-10 22:07:12 --> Language Class Initialized
INFO - 2016-12-10 22:07:12 --> Loader Class Initialized
INFO - 2016-12-10 22:07:12 --> Database Driver Class Initialized
INFO - 2016-12-10 22:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:07:12 --> Controller Class Initialized
INFO - 2016-12-10 22:07:12 --> Helper loaded: date_helper
INFO - 2016-12-10 22:07:12 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:07:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:07:12 --> Helper loaded: form_helper
INFO - 2016-12-10 22:07:12 --> Form Validation Class Initialized
INFO - 2016-12-10 22:07:12 --> Final output sent to browser
DEBUG - 2016-12-10 22:07:12 --> Total execution time: 0.0145
INFO - 2016-12-10 22:07:12 --> Config Class Initialized
INFO - 2016-12-10 22:07:12 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:07:12 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:07:12 --> Utf8 Class Initialized
INFO - 2016-12-10 22:07:12 --> URI Class Initialized
INFO - 2016-12-10 22:07:12 --> Router Class Initialized
INFO - 2016-12-10 22:07:12 --> Output Class Initialized
INFO - 2016-12-10 22:07:12 --> Security Class Initialized
DEBUG - 2016-12-10 22:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:07:12 --> Input Class Initialized
INFO - 2016-12-10 22:07:12 --> Language Class Initialized
INFO - 2016-12-10 22:07:12 --> Loader Class Initialized
INFO - 2016-12-10 22:07:12 --> Database Driver Class Initialized
INFO - 2016-12-10 22:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:07:12 --> Controller Class Initialized
INFO - 2016-12-10 22:07:12 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:07:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:07:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:07:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:07:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:07:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:07:12 --> Final output sent to browser
DEBUG - 2016-12-10 22:07:12 --> Total execution time: 0.0131
INFO - 2016-12-10 22:07:14 --> Config Class Initialized
INFO - 2016-12-10 22:07:14 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:07:14 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:07:14 --> Utf8 Class Initialized
INFO - 2016-12-10 22:07:14 --> URI Class Initialized
INFO - 2016-12-10 22:07:14 --> Router Class Initialized
INFO - 2016-12-10 22:07:14 --> Output Class Initialized
INFO - 2016-12-10 22:07:14 --> Security Class Initialized
DEBUG - 2016-12-10 22:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:07:14 --> Input Class Initialized
INFO - 2016-12-10 22:07:14 --> Language Class Initialized
INFO - 2016-12-10 22:07:14 --> Loader Class Initialized
INFO - 2016-12-10 22:07:14 --> Config Class Initialized
INFO - 2016-12-10 22:07:14 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:07:14 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:07:14 --> Utf8 Class Initialized
INFO - 2016-12-10 22:07:14 --> URI Class Initialized
INFO - 2016-12-10 22:07:14 --> Router Class Initialized
INFO - 2016-12-10 22:07:14 --> Database Driver Class Initialized
INFO - 2016-12-10 22:07:14 --> Output Class Initialized
INFO - 2016-12-10 22:07:14 --> Security Class Initialized
DEBUG - 2016-12-10 22:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:07:14 --> Input Class Initialized
INFO - 2016-12-10 22:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:07:14 --> Controller Class Initialized
INFO - 2016-12-10 22:07:14 --> Language Class Initialized
INFO - 2016-12-10 22:07:14 --> Helper loaded: date_helper
INFO - 2016-12-10 22:07:14 --> Loader Class Initialized
INFO - 2016-12-10 22:07:14 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:07:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:07:14 --> Helper loaded: form_helper
INFO - 2016-12-10 22:07:14 --> Form Validation Class Initialized
INFO - 2016-12-10 22:07:14 --> Database Driver Class Initialized
INFO - 2016-12-10 22:07:14 --> Final output sent to browser
DEBUG - 2016-12-10 22:07:14 --> Total execution time: 0.0149
INFO - 2016-12-10 22:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:07:14 --> Controller Class Initialized
INFO - 2016-12-10 22:07:14 --> Helper loaded: date_helper
INFO - 2016-12-10 22:07:14 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:07:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:07:14 --> Helper loaded: form_helper
INFO - 2016-12-10 22:07:14 --> Form Validation Class Initialized
INFO - 2016-12-10 22:07:14 --> Final output sent to browser
DEBUG - 2016-12-10 22:07:14 --> Total execution time: 0.0953
INFO - 2016-12-10 22:07:28 --> Config Class Initialized
INFO - 2016-12-10 22:07:28 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:07:28 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:07:28 --> Utf8 Class Initialized
INFO - 2016-12-10 22:07:28 --> URI Class Initialized
INFO - 2016-12-10 22:07:28 --> Router Class Initialized
INFO - 2016-12-10 22:07:28 --> Output Class Initialized
INFO - 2016-12-10 22:07:28 --> Security Class Initialized
DEBUG - 2016-12-10 22:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:07:28 --> Input Class Initialized
INFO - 2016-12-10 22:07:28 --> Language Class Initialized
INFO - 2016-12-10 22:07:28 --> Loader Class Initialized
INFO - 2016-12-10 22:07:28 --> Database Driver Class Initialized
INFO - 2016-12-10 22:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:07:28 --> Controller Class Initialized
INFO - 2016-12-10 22:07:28 --> Upload Class Initialized
INFO - 2016-12-10 22:07:28 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:07:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:07:28 --> Helper loaded: form_helper
INFO - 2016-12-10 22:07:28 --> Form Validation Class Initialized
INFO - 2016-12-10 22:07:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 22:07:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-10 22:07:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2016-12-10 22:07:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2016-12-10 22:07:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-10 22:07:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 22:07:28 --> Final output sent to browser
DEBUG - 2016-12-10 22:07:28 --> Total execution time: 0.0684
INFO - 2016-12-10 22:07:29 --> Config Class Initialized
INFO - 2016-12-10 22:07:29 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:07:29 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:07:29 --> Utf8 Class Initialized
INFO - 2016-12-10 22:07:29 --> URI Class Initialized
INFO - 2016-12-10 22:07:29 --> Router Class Initialized
INFO - 2016-12-10 22:07:29 --> Output Class Initialized
INFO - 2016-12-10 22:07:29 --> Security Class Initialized
DEBUG - 2016-12-10 22:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:07:29 --> Input Class Initialized
INFO - 2016-12-10 22:07:29 --> Language Class Initialized
INFO - 2016-12-10 22:07:29 --> Loader Class Initialized
INFO - 2016-12-10 22:07:29 --> Database Driver Class Initialized
INFO - 2016-12-10 22:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:07:29 --> Controller Class Initialized
INFO - 2016-12-10 22:07:29 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:07:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:07:29 --> Final output sent to browser
DEBUG - 2016-12-10 22:07:29 --> Total execution time: 0.0176
INFO - 2016-12-10 22:07:40 --> Config Class Initialized
INFO - 2016-12-10 22:07:40 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:07:40 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:07:40 --> Utf8 Class Initialized
INFO - 2016-12-10 22:07:40 --> URI Class Initialized
DEBUG - 2016-12-10 22:07:40 --> No URI present. Default controller set.
INFO - 2016-12-10 22:07:40 --> Router Class Initialized
INFO - 2016-12-10 22:07:40 --> Output Class Initialized
INFO - 2016-12-10 22:07:40 --> Security Class Initialized
DEBUG - 2016-12-10 22:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:07:40 --> Input Class Initialized
INFO - 2016-12-10 22:07:40 --> Language Class Initialized
INFO - 2016-12-10 22:07:40 --> Loader Class Initialized
INFO - 2016-12-10 22:07:40 --> Database Driver Class Initialized
INFO - 2016-12-10 22:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:07:40 --> Controller Class Initialized
INFO - 2016-12-10 22:07:40 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:07:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:07:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:07:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:07:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:07:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:07:40 --> Final output sent to browser
DEBUG - 2016-12-10 22:07:40 --> Total execution time: 0.0132
INFO - 2016-12-10 22:07:41 --> Config Class Initialized
INFO - 2016-12-10 22:07:41 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:07:41 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:07:41 --> Utf8 Class Initialized
INFO - 2016-12-10 22:07:41 --> URI Class Initialized
INFO - 2016-12-10 22:07:41 --> Router Class Initialized
INFO - 2016-12-10 22:07:41 --> Output Class Initialized
INFO - 2016-12-10 22:07:41 --> Security Class Initialized
DEBUG - 2016-12-10 22:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:07:41 --> Input Class Initialized
INFO - 2016-12-10 22:07:41 --> Language Class Initialized
INFO - 2016-12-10 22:07:41 --> Loader Class Initialized
INFO - 2016-12-10 22:07:41 --> Database Driver Class Initialized
INFO - 2016-12-10 22:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:07:41 --> Controller Class Initialized
INFO - 2016-12-10 22:07:41 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:07:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:07:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:07:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:07:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:07:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:07:41 --> Final output sent to browser
DEBUG - 2016-12-10 22:07:41 --> Total execution time: 0.0131
INFO - 2016-12-10 22:07:43 --> Config Class Initialized
INFO - 2016-12-10 22:07:43 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:07:43 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:07:43 --> Utf8 Class Initialized
INFO - 2016-12-10 22:07:43 --> URI Class Initialized
INFO - 2016-12-10 22:07:43 --> Router Class Initialized
INFO - 2016-12-10 22:07:43 --> Output Class Initialized
INFO - 2016-12-10 22:07:43 --> Security Class Initialized
DEBUG - 2016-12-10 22:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:07:43 --> Input Class Initialized
INFO - 2016-12-10 22:07:43 --> Language Class Initialized
INFO - 2016-12-10 22:07:43 --> Loader Class Initialized
INFO - 2016-12-10 22:07:43 --> Database Driver Class Initialized
INFO - 2016-12-10 22:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:07:43 --> Controller Class Initialized
INFO - 2016-12-10 22:07:43 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:07:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:07:45 --> Config Class Initialized
INFO - 2016-12-10 22:07:45 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:07:45 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:07:45 --> Utf8 Class Initialized
INFO - 2016-12-10 22:07:45 --> URI Class Initialized
INFO - 2016-12-10 22:07:45 --> Router Class Initialized
INFO - 2016-12-10 22:07:45 --> Output Class Initialized
INFO - 2016-12-10 22:07:45 --> Security Class Initialized
DEBUG - 2016-12-10 22:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:07:45 --> Input Class Initialized
INFO - 2016-12-10 22:07:45 --> Language Class Initialized
INFO - 2016-12-10 22:07:45 --> Loader Class Initialized
INFO - 2016-12-10 22:07:45 --> Database Driver Class Initialized
INFO - 2016-12-10 22:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:07:45 --> Controller Class Initialized
DEBUG - 2016-12-10 22:07:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:07:45 --> Helper loaded: url_helper
INFO - 2016-12-10 22:07:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:07:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 22:07:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-10 22:07:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-10 22:07:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:07:45 --> Final output sent to browser
DEBUG - 2016-12-10 22:07:45 --> Total execution time: 0.0136
INFO - 2016-12-10 22:07:45 --> Config Class Initialized
INFO - 2016-12-10 22:07:45 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:07:45 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:07:45 --> Utf8 Class Initialized
INFO - 2016-12-10 22:07:45 --> URI Class Initialized
INFO - 2016-12-10 22:07:45 --> Router Class Initialized
INFO - 2016-12-10 22:07:45 --> Output Class Initialized
INFO - 2016-12-10 22:07:45 --> Security Class Initialized
DEBUG - 2016-12-10 22:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:07:45 --> Input Class Initialized
INFO - 2016-12-10 22:07:45 --> Language Class Initialized
INFO - 2016-12-10 22:07:45 --> Loader Class Initialized
INFO - 2016-12-10 22:07:45 --> Database Driver Class Initialized
INFO - 2016-12-10 22:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:07:45 --> Controller Class Initialized
INFO - 2016-12-10 22:07:45 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:07:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:07:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:07:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:07:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:07:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:07:45 --> Final output sent to browser
DEBUG - 2016-12-10 22:07:45 --> Total execution time: 0.0137
INFO - 2016-12-10 22:07:48 --> Config Class Initialized
INFO - 2016-12-10 22:07:48 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:07:48 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:07:48 --> Utf8 Class Initialized
INFO - 2016-12-10 22:07:48 --> URI Class Initialized
INFO - 2016-12-10 22:07:48 --> Router Class Initialized
INFO - 2016-12-10 22:07:48 --> Output Class Initialized
INFO - 2016-12-10 22:07:48 --> Security Class Initialized
DEBUG - 2016-12-10 22:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:07:48 --> Input Class Initialized
INFO - 2016-12-10 22:07:48 --> Language Class Initialized
INFO - 2016-12-10 22:07:48 --> Loader Class Initialized
INFO - 2016-12-10 22:07:48 --> Database Driver Class Initialized
INFO - 2016-12-10 22:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:07:48 --> Controller Class Initialized
INFO - 2016-12-10 22:07:48 --> Helper loaded: date_helper
DEBUG - 2016-12-10 22:07:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:07:48 --> Helper loaded: url_helper
INFO - 2016-12-10 22:07:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:07:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 22:07:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-10 22:07:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-10 22:07:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:07:48 --> Final output sent to browser
DEBUG - 2016-12-10 22:07:48 --> Total execution time: 0.0166
INFO - 2016-12-10 22:07:48 --> Config Class Initialized
INFO - 2016-12-10 22:07:48 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:07:48 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:07:48 --> Utf8 Class Initialized
INFO - 2016-12-10 22:07:48 --> URI Class Initialized
INFO - 2016-12-10 22:07:48 --> Router Class Initialized
INFO - 2016-12-10 22:07:48 --> Output Class Initialized
INFO - 2016-12-10 22:07:48 --> Security Class Initialized
DEBUG - 2016-12-10 22:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:07:48 --> Input Class Initialized
INFO - 2016-12-10 22:07:48 --> Language Class Initialized
INFO - 2016-12-10 22:07:48 --> Loader Class Initialized
INFO - 2016-12-10 22:07:48 --> Database Driver Class Initialized
INFO - 2016-12-10 22:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:07:48 --> Controller Class Initialized
INFO - 2016-12-10 22:07:48 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:07:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:07:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:07:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:07:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:07:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:07:48 --> Final output sent to browser
DEBUG - 2016-12-10 22:07:48 --> Total execution time: 0.0134
INFO - 2016-12-10 22:07:55 --> Config Class Initialized
INFO - 2016-12-10 22:07:55 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:07:55 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:07:55 --> Utf8 Class Initialized
INFO - 2016-12-10 22:07:55 --> URI Class Initialized
INFO - 2016-12-10 22:07:55 --> Router Class Initialized
INFO - 2016-12-10 22:07:55 --> Output Class Initialized
INFO - 2016-12-10 22:07:55 --> Security Class Initialized
DEBUG - 2016-12-10 22:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:07:55 --> Input Class Initialized
INFO - 2016-12-10 22:07:55 --> Language Class Initialized
ERROR - 2016-12-10 22:07:55 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-10 22:08:49 --> Config Class Initialized
INFO - 2016-12-10 22:08:49 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:08:49 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:08:49 --> Utf8 Class Initialized
INFO - 2016-12-10 22:08:49 --> URI Class Initialized
DEBUG - 2016-12-10 22:08:49 --> No URI present. Default controller set.
INFO - 2016-12-10 22:08:49 --> Router Class Initialized
INFO - 2016-12-10 22:08:49 --> Output Class Initialized
INFO - 2016-12-10 22:08:49 --> Security Class Initialized
DEBUG - 2016-12-10 22:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:08:49 --> Input Class Initialized
INFO - 2016-12-10 22:08:49 --> Language Class Initialized
INFO - 2016-12-10 22:08:49 --> Loader Class Initialized
INFO - 2016-12-10 22:08:49 --> Database Driver Class Initialized
INFO - 2016-12-10 22:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:08:49 --> Controller Class Initialized
INFO - 2016-12-10 22:08:49 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:08:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:08:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:08:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:08:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:08:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:08:49 --> Final output sent to browser
DEBUG - 2016-12-10 22:08:49 --> Total execution time: 0.0137
INFO - 2016-12-10 22:08:50 --> Config Class Initialized
INFO - 2016-12-10 22:08:50 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:08:50 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:08:50 --> Utf8 Class Initialized
INFO - 2016-12-10 22:08:50 --> URI Class Initialized
INFO - 2016-12-10 22:08:50 --> Router Class Initialized
INFO - 2016-12-10 22:08:50 --> Output Class Initialized
INFO - 2016-12-10 22:08:50 --> Security Class Initialized
DEBUG - 2016-12-10 22:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:08:50 --> Input Class Initialized
INFO - 2016-12-10 22:08:50 --> Language Class Initialized
INFO - 2016-12-10 22:08:50 --> Loader Class Initialized
INFO - 2016-12-10 22:08:50 --> Database Driver Class Initialized
INFO - 2016-12-10 22:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:08:50 --> Controller Class Initialized
INFO - 2016-12-10 22:08:50 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:08:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:08:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:08:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:08:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:08:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:08:50 --> Final output sent to browser
DEBUG - 2016-12-10 22:08:50 --> Total execution time: 0.0130
INFO - 2016-12-10 22:08:55 --> Config Class Initialized
INFO - 2016-12-10 22:08:55 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:08:55 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:08:55 --> Utf8 Class Initialized
INFO - 2016-12-10 22:08:55 --> URI Class Initialized
INFO - 2016-12-10 22:08:55 --> Router Class Initialized
INFO - 2016-12-10 22:08:55 --> Output Class Initialized
INFO - 2016-12-10 22:08:55 --> Security Class Initialized
DEBUG - 2016-12-10 22:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:08:55 --> Input Class Initialized
INFO - 2016-12-10 22:08:55 --> Language Class Initialized
INFO - 2016-12-10 22:08:55 --> Loader Class Initialized
INFO - 2016-12-10 22:08:55 --> Database Driver Class Initialized
INFO - 2016-12-10 22:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:08:55 --> Controller Class Initialized
INFO - 2016-12-10 22:08:55 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:08:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:08:57 --> Config Class Initialized
INFO - 2016-12-10 22:08:57 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:08:57 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:08:57 --> Utf8 Class Initialized
INFO - 2016-12-10 22:08:57 --> URI Class Initialized
INFO - 2016-12-10 22:08:57 --> Router Class Initialized
INFO - 2016-12-10 22:08:57 --> Output Class Initialized
INFO - 2016-12-10 22:08:57 --> Security Class Initialized
DEBUG - 2016-12-10 22:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:08:57 --> Input Class Initialized
INFO - 2016-12-10 22:08:57 --> Language Class Initialized
INFO - 2016-12-10 22:08:57 --> Loader Class Initialized
INFO - 2016-12-10 22:08:57 --> Database Driver Class Initialized
INFO - 2016-12-10 22:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:08:57 --> Controller Class Initialized
DEBUG - 2016-12-10 22:08:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:08:57 --> Helper loaded: url_helper
INFO - 2016-12-10 22:08:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:08:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 22:08:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-10 22:08:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-10 22:08:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:08:57 --> Final output sent to browser
DEBUG - 2016-12-10 22:08:57 --> Total execution time: 0.0131
INFO - 2016-12-10 22:08:57 --> Config Class Initialized
INFO - 2016-12-10 22:08:57 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:08:57 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:08:57 --> Utf8 Class Initialized
INFO - 2016-12-10 22:08:57 --> URI Class Initialized
INFO - 2016-12-10 22:08:57 --> Router Class Initialized
INFO - 2016-12-10 22:08:57 --> Output Class Initialized
INFO - 2016-12-10 22:08:57 --> Security Class Initialized
DEBUG - 2016-12-10 22:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:08:57 --> Input Class Initialized
INFO - 2016-12-10 22:08:57 --> Language Class Initialized
INFO - 2016-12-10 22:08:57 --> Loader Class Initialized
INFO - 2016-12-10 22:08:57 --> Database Driver Class Initialized
INFO - 2016-12-10 22:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:08:57 --> Controller Class Initialized
INFO - 2016-12-10 22:08:57 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:08:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:08:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:08:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:08:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:08:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:08:57 --> Final output sent to browser
DEBUG - 2016-12-10 22:08:57 --> Total execution time: 0.0130
INFO - 2016-12-10 22:09:51 --> Config Class Initialized
INFO - 2016-12-10 22:09:51 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:09:51 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:09:51 --> Utf8 Class Initialized
INFO - 2016-12-10 22:09:51 --> URI Class Initialized
INFO - 2016-12-10 22:09:51 --> Router Class Initialized
INFO - 2016-12-10 22:09:51 --> Output Class Initialized
INFO - 2016-12-10 22:09:51 --> Security Class Initialized
DEBUG - 2016-12-10 22:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:09:51 --> Input Class Initialized
INFO - 2016-12-10 22:09:51 --> Language Class Initialized
INFO - 2016-12-10 22:09:51 --> Loader Class Initialized
INFO - 2016-12-10 22:09:51 --> Database Driver Class Initialized
INFO - 2016-12-10 22:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:09:51 --> Controller Class Initialized
DEBUG - 2016-12-10 22:09:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:09:51 --> Helper loaded: url_helper
INFO - 2016-12-10 22:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-10 22:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 22:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-10 22:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-10 22:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:09:51 --> Final output sent to browser
DEBUG - 2016-12-10 22:09:51 --> Total execution time: 0.0126
INFO - 2016-12-10 22:09:51 --> Config Class Initialized
INFO - 2016-12-10 22:09:51 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:09:51 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:09:51 --> Utf8 Class Initialized
INFO - 2016-12-10 22:09:51 --> URI Class Initialized
INFO - 2016-12-10 22:09:51 --> Router Class Initialized
INFO - 2016-12-10 22:09:51 --> Output Class Initialized
INFO - 2016-12-10 22:09:51 --> Security Class Initialized
DEBUG - 2016-12-10 22:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:09:51 --> Input Class Initialized
INFO - 2016-12-10 22:09:51 --> Language Class Initialized
INFO - 2016-12-10 22:09:51 --> Loader Class Initialized
INFO - 2016-12-10 22:09:51 --> Database Driver Class Initialized
INFO - 2016-12-10 22:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:09:51 --> Controller Class Initialized
INFO - 2016-12-10 22:09:51 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:09:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:09:51 --> Final output sent to browser
DEBUG - 2016-12-10 22:09:51 --> Total execution time: 0.0133
INFO - 2016-12-10 22:09:52 --> Config Class Initialized
INFO - 2016-12-10 22:09:52 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:09:52 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:09:52 --> Utf8 Class Initialized
INFO - 2016-12-10 22:09:52 --> URI Class Initialized
INFO - 2016-12-10 22:09:52 --> Router Class Initialized
INFO - 2016-12-10 22:09:52 --> Output Class Initialized
INFO - 2016-12-10 22:09:52 --> Security Class Initialized
DEBUG - 2016-12-10 22:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:09:52 --> Input Class Initialized
INFO - 2016-12-10 22:09:52 --> Language Class Initialized
INFO - 2016-12-10 22:09:52 --> Loader Class Initialized
INFO - 2016-12-10 22:09:52 --> Database Driver Class Initialized
INFO - 2016-12-10 22:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:09:52 --> Controller Class Initialized
INFO - 2016-12-10 22:09:52 --> Helper loaded: date_helper
DEBUG - 2016-12-10 22:09:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:09:52 --> Helper loaded: url_helper
INFO - 2016-12-10 22:09:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:09:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 22:09:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-10 22:09:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-10 22:09:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:09:52 --> Final output sent to browser
DEBUG - 2016-12-10 22:09:52 --> Total execution time: 0.0414
INFO - 2016-12-10 22:09:52 --> Config Class Initialized
INFO - 2016-12-10 22:09:52 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:09:52 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:09:52 --> Utf8 Class Initialized
INFO - 2016-12-10 22:09:52 --> URI Class Initialized
INFO - 2016-12-10 22:09:52 --> Router Class Initialized
INFO - 2016-12-10 22:09:52 --> Output Class Initialized
INFO - 2016-12-10 22:09:52 --> Security Class Initialized
DEBUG - 2016-12-10 22:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:09:52 --> Input Class Initialized
INFO - 2016-12-10 22:09:52 --> Language Class Initialized
INFO - 2016-12-10 22:09:52 --> Loader Class Initialized
INFO - 2016-12-10 22:09:52 --> Database Driver Class Initialized
INFO - 2016-12-10 22:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:09:52 --> Controller Class Initialized
INFO - 2016-12-10 22:09:52 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:09:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:09:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:09:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:09:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:09:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:09:52 --> Final output sent to browser
DEBUG - 2016-12-10 22:09:52 --> Total execution time: 0.0134
INFO - 2016-12-10 22:10:14 --> Config Class Initialized
INFO - 2016-12-10 22:10:14 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:10:14 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:10:14 --> Utf8 Class Initialized
INFO - 2016-12-10 22:10:14 --> URI Class Initialized
INFO - 2016-12-10 22:10:14 --> Router Class Initialized
INFO - 2016-12-10 22:10:14 --> Output Class Initialized
INFO - 2016-12-10 22:10:14 --> Security Class Initialized
DEBUG - 2016-12-10 22:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:10:14 --> Input Class Initialized
INFO - 2016-12-10 22:10:14 --> Language Class Initialized
INFO - 2016-12-10 22:10:14 --> Loader Class Initialized
INFO - 2016-12-10 22:10:14 --> Database Driver Class Initialized
INFO - 2016-12-10 22:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:10:14 --> Controller Class Initialized
INFO - 2016-12-10 22:10:14 --> Helper loaded: date_helper
INFO - 2016-12-10 22:10:14 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:10:14 --> Helper loaded: form_helper
INFO - 2016-12-10 22:10:14 --> Form Validation Class Initialized
INFO - 2016-12-10 22:10:14 --> Final output sent to browser
DEBUG - 2016-12-10 22:10:14 --> Total execution time: 0.0358
INFO - 2016-12-10 22:10:24 --> Config Class Initialized
INFO - 2016-12-10 22:10:24 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:10:24 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:10:24 --> Utf8 Class Initialized
INFO - 2016-12-10 22:10:24 --> URI Class Initialized
INFO - 2016-12-10 22:10:24 --> Router Class Initialized
INFO - 2016-12-10 22:10:24 --> Output Class Initialized
INFO - 2016-12-10 22:10:24 --> Security Class Initialized
DEBUG - 2016-12-10 22:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:10:24 --> Input Class Initialized
INFO - 2016-12-10 22:10:24 --> Language Class Initialized
INFO - 2016-12-10 22:10:24 --> Loader Class Initialized
INFO - 2016-12-10 22:10:24 --> Database Driver Class Initialized
INFO - 2016-12-10 22:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:10:24 --> Controller Class Initialized
INFO - 2016-12-10 22:10:24 --> Helper loaded: date_helper
INFO - 2016-12-10 22:10:24 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:10:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:10:24 --> Helper loaded: form_helper
INFO - 2016-12-10 22:10:24 --> Form Validation Class Initialized
INFO - 2016-12-10 22:10:24 --> Final output sent to browser
DEBUG - 2016-12-10 22:10:24 --> Total execution time: 0.0152
INFO - 2016-12-10 22:10:28 --> Config Class Initialized
INFO - 2016-12-10 22:10:28 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:10:28 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:10:28 --> Utf8 Class Initialized
INFO - 2016-12-10 22:10:28 --> URI Class Initialized
INFO - 2016-12-10 22:10:28 --> Router Class Initialized
INFO - 2016-12-10 22:10:28 --> Output Class Initialized
INFO - 2016-12-10 22:10:28 --> Security Class Initialized
DEBUG - 2016-12-10 22:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:10:28 --> Input Class Initialized
INFO - 2016-12-10 22:10:28 --> Language Class Initialized
INFO - 2016-12-10 22:10:28 --> Loader Class Initialized
INFO - 2016-12-10 22:10:28 --> Database Driver Class Initialized
INFO - 2016-12-10 22:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:10:28 --> Controller Class Initialized
INFO - 2016-12-10 22:10:28 --> Helper loaded: date_helper
INFO - 2016-12-10 22:10:28 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:10:28 --> Helper loaded: form_helper
INFO - 2016-12-10 22:10:28 --> Form Validation Class Initialized
INFO - 2016-12-10 22:10:28 --> Final output sent to browser
DEBUG - 2016-12-10 22:10:28 --> Total execution time: 0.0148
INFO - 2016-12-10 22:10:33 --> Config Class Initialized
INFO - 2016-12-10 22:10:33 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:10:33 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:10:33 --> Utf8 Class Initialized
INFO - 2016-12-10 22:10:33 --> URI Class Initialized
INFO - 2016-12-10 22:10:33 --> Router Class Initialized
INFO - 2016-12-10 22:10:33 --> Output Class Initialized
INFO - 2016-12-10 22:10:33 --> Security Class Initialized
DEBUG - 2016-12-10 22:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:10:33 --> Input Class Initialized
INFO - 2016-12-10 22:10:33 --> Language Class Initialized
INFO - 2016-12-10 22:10:33 --> Loader Class Initialized
INFO - 2016-12-10 22:10:33 --> Database Driver Class Initialized
INFO - 2016-12-10 22:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:10:33 --> Controller Class Initialized
INFO - 2016-12-10 22:10:33 --> Helper loaded: date_helper
INFO - 2016-12-10 22:10:33 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:10:33 --> Helper loaded: form_helper
INFO - 2016-12-10 22:10:33 --> Form Validation Class Initialized
INFO - 2016-12-10 22:10:33 --> Final output sent to browser
DEBUG - 2016-12-10 22:10:33 --> Total execution time: 0.0187
INFO - 2016-12-10 22:10:37 --> Config Class Initialized
INFO - 2016-12-10 22:10:37 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:10:37 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:10:37 --> Utf8 Class Initialized
INFO - 2016-12-10 22:10:37 --> URI Class Initialized
INFO - 2016-12-10 22:10:37 --> Router Class Initialized
INFO - 2016-12-10 22:10:37 --> Output Class Initialized
INFO - 2016-12-10 22:10:37 --> Security Class Initialized
DEBUG - 2016-12-10 22:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:10:37 --> Input Class Initialized
INFO - 2016-12-10 22:10:37 --> Language Class Initialized
INFO - 2016-12-10 22:10:37 --> Loader Class Initialized
INFO - 2016-12-10 22:10:37 --> Database Driver Class Initialized
INFO - 2016-12-10 22:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:10:37 --> Controller Class Initialized
INFO - 2016-12-10 22:10:37 --> Helper loaded: date_helper
INFO - 2016-12-10 22:10:37 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:10:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:10:37 --> Helper loaded: form_helper
INFO - 2016-12-10 22:10:37 --> Form Validation Class Initialized
INFO - 2016-12-10 22:10:37 --> Final output sent to browser
DEBUG - 2016-12-10 22:10:37 --> Total execution time: 0.0200
INFO - 2016-12-10 22:10:42 --> Config Class Initialized
INFO - 2016-12-10 22:10:42 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:10:42 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:10:42 --> Utf8 Class Initialized
INFO - 2016-12-10 22:10:42 --> URI Class Initialized
INFO - 2016-12-10 22:10:42 --> Router Class Initialized
INFO - 2016-12-10 22:10:42 --> Output Class Initialized
INFO - 2016-12-10 22:10:42 --> Security Class Initialized
DEBUG - 2016-12-10 22:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:10:42 --> Input Class Initialized
INFO - 2016-12-10 22:10:42 --> Language Class Initialized
INFO - 2016-12-10 22:10:42 --> Loader Class Initialized
INFO - 2016-12-10 22:10:42 --> Database Driver Class Initialized
INFO - 2016-12-10 22:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:10:42 --> Controller Class Initialized
INFO - 2016-12-10 22:10:42 --> Helper loaded: date_helper
INFO - 2016-12-10 22:10:42 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:10:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:10:42 --> Helper loaded: form_helper
INFO - 2016-12-10 22:10:42 --> Form Validation Class Initialized
INFO - 2016-12-10 22:10:42 --> Final output sent to browser
DEBUG - 2016-12-10 22:10:42 --> Total execution time: 0.0147
INFO - 2016-12-10 22:10:45 --> Config Class Initialized
INFO - 2016-12-10 22:10:45 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:10:45 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:10:45 --> Utf8 Class Initialized
INFO - 2016-12-10 22:10:45 --> URI Class Initialized
INFO - 2016-12-10 22:10:45 --> Router Class Initialized
INFO - 2016-12-10 22:10:45 --> Output Class Initialized
INFO - 2016-12-10 22:10:45 --> Security Class Initialized
DEBUG - 2016-12-10 22:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:10:45 --> Input Class Initialized
INFO - 2016-12-10 22:10:45 --> Language Class Initialized
INFO - 2016-12-10 22:10:45 --> Loader Class Initialized
INFO - 2016-12-10 22:10:45 --> Database Driver Class Initialized
INFO - 2016-12-10 22:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:10:45 --> Controller Class Initialized
INFO - 2016-12-10 22:10:45 --> Helper loaded: date_helper
INFO - 2016-12-10 22:10:45 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:10:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:10:45 --> Helper loaded: form_helper
INFO - 2016-12-10 22:10:45 --> Form Validation Class Initialized
INFO - 2016-12-10 22:10:45 --> Final output sent to browser
DEBUG - 2016-12-10 22:10:45 --> Total execution time: 0.0151
INFO - 2016-12-10 22:10:48 --> Config Class Initialized
INFO - 2016-12-10 22:10:48 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:10:48 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:10:48 --> Utf8 Class Initialized
INFO - 2016-12-10 22:10:48 --> URI Class Initialized
INFO - 2016-12-10 22:10:48 --> Router Class Initialized
INFO - 2016-12-10 22:10:48 --> Output Class Initialized
INFO - 2016-12-10 22:10:48 --> Security Class Initialized
DEBUG - 2016-12-10 22:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:10:48 --> Input Class Initialized
INFO - 2016-12-10 22:10:48 --> Language Class Initialized
INFO - 2016-12-10 22:10:48 --> Loader Class Initialized
INFO - 2016-12-10 22:10:48 --> Database Driver Class Initialized
INFO - 2016-12-10 22:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:10:48 --> Controller Class Initialized
INFO - 2016-12-10 22:10:48 --> Helper loaded: date_helper
INFO - 2016-12-10 22:10:48 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:10:48 --> Helper loaded: form_helper
INFO - 2016-12-10 22:10:48 --> Form Validation Class Initialized
INFO - 2016-12-10 22:10:48 --> Final output sent to browser
DEBUG - 2016-12-10 22:10:48 --> Total execution time: 0.0151
INFO - 2016-12-10 22:10:53 --> Config Class Initialized
INFO - 2016-12-10 22:10:53 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:10:53 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:10:53 --> Utf8 Class Initialized
INFO - 2016-12-10 22:10:53 --> URI Class Initialized
INFO - 2016-12-10 22:10:53 --> Router Class Initialized
INFO - 2016-12-10 22:10:53 --> Output Class Initialized
INFO - 2016-12-10 22:10:53 --> Security Class Initialized
DEBUG - 2016-12-10 22:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:10:53 --> Input Class Initialized
INFO - 2016-12-10 22:10:53 --> Language Class Initialized
INFO - 2016-12-10 22:10:53 --> Loader Class Initialized
INFO - 2016-12-10 22:10:53 --> Database Driver Class Initialized
INFO - 2016-12-10 22:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:10:53 --> Controller Class Initialized
INFO - 2016-12-10 22:10:53 --> Helper loaded: date_helper
INFO - 2016-12-10 22:10:53 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:10:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:10:53 --> Helper loaded: form_helper
INFO - 2016-12-10 22:10:53 --> Form Validation Class Initialized
INFO - 2016-12-10 22:10:53 --> Final output sent to browser
DEBUG - 2016-12-10 22:10:53 --> Total execution time: 0.0158
INFO - 2016-12-10 22:10:57 --> Config Class Initialized
INFO - 2016-12-10 22:10:57 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:10:57 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:10:57 --> Utf8 Class Initialized
INFO - 2016-12-10 22:10:57 --> URI Class Initialized
INFO - 2016-12-10 22:10:57 --> Router Class Initialized
INFO - 2016-12-10 22:10:57 --> Output Class Initialized
INFO - 2016-12-10 22:10:57 --> Security Class Initialized
DEBUG - 2016-12-10 22:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:10:57 --> Input Class Initialized
INFO - 2016-12-10 22:10:57 --> Language Class Initialized
INFO - 2016-12-10 22:10:57 --> Loader Class Initialized
INFO - 2016-12-10 22:10:57 --> Database Driver Class Initialized
INFO - 2016-12-10 22:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:10:57 --> Controller Class Initialized
INFO - 2016-12-10 22:10:57 --> Upload Class Initialized
DEBUG - 2016-12-10 22:10:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:10:57 --> Helper loaded: url_helper
INFO - 2016-12-10 22:10:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:10:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-10 22:10:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-10 22:10:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-10 22:10:57 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-10 22:10:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:10:57 --> Final output sent to browser
DEBUG - 2016-12-10 22:10:57 --> Total execution time: 0.0149
INFO - 2016-12-10 22:11:00 --> Config Class Initialized
INFO - 2016-12-10 22:11:00 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:11:00 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:11:00 --> Utf8 Class Initialized
INFO - 2016-12-10 22:11:00 --> URI Class Initialized
INFO - 2016-12-10 22:11:00 --> Router Class Initialized
INFO - 2016-12-10 22:11:00 --> Output Class Initialized
INFO - 2016-12-10 22:11:00 --> Security Class Initialized
DEBUG - 2016-12-10 22:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:11:00 --> Input Class Initialized
INFO - 2016-12-10 22:11:00 --> Language Class Initialized
INFO - 2016-12-10 22:11:00 --> Loader Class Initialized
INFO - 2016-12-10 22:11:00 --> Database Driver Class Initialized
INFO - 2016-12-10 22:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:11:00 --> Controller Class Initialized
INFO - 2016-12-10 22:11:00 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:11:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:11:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:11:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:11:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:11:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:11:00 --> Final output sent to browser
DEBUG - 2016-12-10 22:11:00 --> Total execution time: 0.0142
INFO - 2016-12-10 22:11:43 --> Config Class Initialized
INFO - 2016-12-10 22:11:43 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:11:43 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:11:43 --> Utf8 Class Initialized
INFO - 2016-12-10 22:11:43 --> URI Class Initialized
INFO - 2016-12-10 22:11:43 --> Router Class Initialized
INFO - 2016-12-10 22:11:43 --> Output Class Initialized
INFO - 2016-12-10 22:11:43 --> Security Class Initialized
DEBUG - 2016-12-10 22:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:11:43 --> Input Class Initialized
INFO - 2016-12-10 22:11:43 --> Language Class Initialized
INFO - 2016-12-10 22:11:43 --> Loader Class Initialized
INFO - 2016-12-10 22:11:43 --> Database Driver Class Initialized
INFO - 2016-12-10 22:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:11:43 --> Controller Class Initialized
INFO - 2016-12-10 22:11:43 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:11:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:11:43 --> Config Class Initialized
INFO - 2016-12-10 22:11:43 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:11:43 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:11:43 --> Utf8 Class Initialized
INFO - 2016-12-10 22:11:43 --> URI Class Initialized
INFO - 2016-12-10 22:11:43 --> Router Class Initialized
INFO - 2016-12-10 22:11:43 --> Output Class Initialized
INFO - 2016-12-10 22:11:43 --> Security Class Initialized
DEBUG - 2016-12-10 22:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:11:43 --> Input Class Initialized
INFO - 2016-12-10 22:11:43 --> Language Class Initialized
INFO - 2016-12-10 22:11:43 --> Loader Class Initialized
INFO - 2016-12-10 22:11:43 --> Database Driver Class Initialized
INFO - 2016-12-10 22:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:11:43 --> Controller Class Initialized
INFO - 2016-12-10 22:11:43 --> Helper loaded: date_helper
INFO - 2016-12-10 22:11:43 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:11:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:11:43 --> Helper loaded: form_helper
INFO - 2016-12-10 22:11:43 --> Form Validation Class Initialized
INFO - 2016-12-10 22:11:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 22:11:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-10 22:11:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2016-12-10 22:11:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2016-12-10 22:11:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 22:11:43 --> Final output sent to browser
DEBUG - 2016-12-10 22:11:43 --> Total execution time: 0.0146
INFO - 2016-12-10 22:11:44 --> Config Class Initialized
INFO - 2016-12-10 22:11:44 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:11:44 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:11:44 --> Utf8 Class Initialized
INFO - 2016-12-10 22:11:44 --> URI Class Initialized
INFO - 2016-12-10 22:11:44 --> Router Class Initialized
INFO - 2016-12-10 22:11:44 --> Output Class Initialized
INFO - 2016-12-10 22:11:44 --> Security Class Initialized
DEBUG - 2016-12-10 22:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:11:44 --> Input Class Initialized
INFO - 2016-12-10 22:11:44 --> Language Class Initialized
INFO - 2016-12-10 22:11:44 --> Loader Class Initialized
INFO - 2016-12-10 22:11:44 --> Database Driver Class Initialized
INFO - 2016-12-10 22:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:11:44 --> Controller Class Initialized
INFO - 2016-12-10 22:11:44 --> Helper loaded: date_helper
INFO - 2016-12-10 22:11:44 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:11:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:11:44 --> Helper loaded: form_helper
INFO - 2016-12-10 22:11:44 --> Form Validation Class Initialized
INFO - 2016-12-10 22:11:44 --> Final output sent to browser
DEBUG - 2016-12-10 22:11:44 --> Total execution time: 0.0149
INFO - 2016-12-10 22:11:44 --> Config Class Initialized
INFO - 2016-12-10 22:11:44 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:11:44 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:11:44 --> Utf8 Class Initialized
INFO - 2016-12-10 22:11:44 --> URI Class Initialized
INFO - 2016-12-10 22:11:44 --> Router Class Initialized
INFO - 2016-12-10 22:11:44 --> Output Class Initialized
INFO - 2016-12-10 22:11:44 --> Security Class Initialized
DEBUG - 2016-12-10 22:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:11:44 --> Input Class Initialized
INFO - 2016-12-10 22:11:44 --> Language Class Initialized
INFO - 2016-12-10 22:11:44 --> Loader Class Initialized
INFO - 2016-12-10 22:11:44 --> Database Driver Class Initialized
INFO - 2016-12-10 22:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:11:44 --> Controller Class Initialized
INFO - 2016-12-10 22:11:44 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:11:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:11:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:11:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:11:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:11:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:11:44 --> Final output sent to browser
DEBUG - 2016-12-10 22:11:44 --> Total execution time: 0.0851
INFO - 2016-12-10 22:11:48 --> Config Class Initialized
INFO - 2016-12-10 22:11:48 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:11:48 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:11:48 --> Utf8 Class Initialized
INFO - 2016-12-10 22:11:48 --> URI Class Initialized
INFO - 2016-12-10 22:11:48 --> Router Class Initialized
INFO - 2016-12-10 22:11:48 --> Output Class Initialized
INFO - 2016-12-10 22:11:48 --> Security Class Initialized
DEBUG - 2016-12-10 22:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:11:48 --> Input Class Initialized
INFO - 2016-12-10 22:11:48 --> Language Class Initialized
INFO - 2016-12-10 22:11:48 --> Loader Class Initialized
INFO - 2016-12-10 22:11:48 --> Config Class Initialized
INFO - 2016-12-10 22:11:48 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:11:48 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:11:48 --> Utf8 Class Initialized
INFO - 2016-12-10 22:11:48 --> Database Driver Class Initialized
INFO - 2016-12-10 22:11:48 --> URI Class Initialized
INFO - 2016-12-10 22:11:48 --> Router Class Initialized
INFO - 2016-12-10 22:11:48 --> Output Class Initialized
INFO - 2016-12-10 22:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:11:48 --> Controller Class Initialized
INFO - 2016-12-10 22:11:48 --> Security Class Initialized
DEBUG - 2016-12-10 22:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:11:48 --> Input Class Initialized
INFO - 2016-12-10 22:11:48 --> Helper loaded: date_helper
INFO - 2016-12-10 22:11:48 --> Language Class Initialized
INFO - 2016-12-10 22:11:48 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:11:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:11:48 --> Loader Class Initialized
INFO - 2016-12-10 22:11:48 --> Helper loaded: form_helper
INFO - 2016-12-10 22:11:48 --> Form Validation Class Initialized
INFO - 2016-12-10 22:11:48 --> Final output sent to browser
DEBUG - 2016-12-10 22:11:48 --> Total execution time: 0.0153
INFO - 2016-12-10 22:11:48 --> Database Driver Class Initialized
INFO - 2016-12-10 22:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:11:48 --> Controller Class Initialized
INFO - 2016-12-10 22:11:48 --> Helper loaded: date_helper
INFO - 2016-12-10 22:11:48 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:11:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:11:48 --> Helper loaded: form_helper
INFO - 2016-12-10 22:11:48 --> Form Validation Class Initialized
INFO - 2016-12-10 22:11:48 --> Final output sent to browser
DEBUG - 2016-12-10 22:11:48 --> Total execution time: 0.0871
INFO - 2016-12-10 22:18:56 --> Config Class Initialized
INFO - 2016-12-10 22:18:56 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:18:56 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:18:56 --> Utf8 Class Initialized
INFO - 2016-12-10 22:18:56 --> URI Class Initialized
INFO - 2016-12-10 22:18:56 --> Router Class Initialized
INFO - 2016-12-10 22:18:56 --> Output Class Initialized
INFO - 2016-12-10 22:18:56 --> Security Class Initialized
DEBUG - 2016-12-10 22:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:18:56 --> Input Class Initialized
INFO - 2016-12-10 22:18:56 --> Language Class Initialized
INFO - 2016-12-10 22:18:56 --> Loader Class Initialized
INFO - 2016-12-10 22:18:56 --> Database Driver Class Initialized
INFO - 2016-12-10 22:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:18:56 --> Controller Class Initialized
INFO - 2016-12-10 22:18:56 --> Helper loaded: date_helper
INFO - 2016-12-10 22:18:56 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:18:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:18:56 --> Helper loaded: form_helper
INFO - 2016-12-10 22:18:56 --> Form Validation Class Initialized
INFO - 2016-12-10 22:18:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 22:18:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-10 22:18:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2016-12-10 22:18:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2016-12-10 22:18:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 22:18:56 --> Final output sent to browser
DEBUG - 2016-12-10 22:18:56 --> Total execution time: 0.0151
INFO - 2016-12-10 22:18:57 --> Config Class Initialized
INFO - 2016-12-10 22:18:57 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:18:57 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:18:57 --> Utf8 Class Initialized
INFO - 2016-12-10 22:18:57 --> URI Class Initialized
INFO - 2016-12-10 22:18:57 --> Router Class Initialized
INFO - 2016-12-10 22:18:57 --> Output Class Initialized
INFO - 2016-12-10 22:18:57 --> Security Class Initialized
DEBUG - 2016-12-10 22:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:18:57 --> Input Class Initialized
INFO - 2016-12-10 22:18:57 --> Language Class Initialized
INFO - 2016-12-10 22:18:57 --> Loader Class Initialized
INFO - 2016-12-10 22:18:57 --> Database Driver Class Initialized
INFO - 2016-12-10 22:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:18:57 --> Controller Class Initialized
INFO - 2016-12-10 22:18:57 --> Helper loaded: date_helper
INFO - 2016-12-10 22:18:57 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:18:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:18:57 --> Helper loaded: form_helper
INFO - 2016-12-10 22:18:57 --> Form Validation Class Initialized
INFO - 2016-12-10 22:18:57 --> Final output sent to browser
DEBUG - 2016-12-10 22:18:57 --> Total execution time: 0.0148
INFO - 2016-12-10 22:18:57 --> Config Class Initialized
INFO - 2016-12-10 22:18:57 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:18:57 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:18:57 --> Utf8 Class Initialized
INFO - 2016-12-10 22:18:57 --> URI Class Initialized
INFO - 2016-12-10 22:18:57 --> Router Class Initialized
INFO - 2016-12-10 22:18:57 --> Output Class Initialized
INFO - 2016-12-10 22:18:57 --> Security Class Initialized
DEBUG - 2016-12-10 22:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:18:57 --> Input Class Initialized
INFO - 2016-12-10 22:18:57 --> Language Class Initialized
INFO - 2016-12-10 22:18:57 --> Loader Class Initialized
INFO - 2016-12-10 22:18:57 --> Database Driver Class Initialized
INFO - 2016-12-10 22:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:18:57 --> Controller Class Initialized
INFO - 2016-12-10 22:18:57 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:18:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:18:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:18:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:18:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:18:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:18:57 --> Final output sent to browser
DEBUG - 2016-12-10 22:18:57 --> Total execution time: 0.0142
INFO - 2016-12-10 22:18:57 --> Config Class Initialized
INFO - 2016-12-10 22:18:57 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:18:57 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:18:57 --> Utf8 Class Initialized
INFO - 2016-12-10 22:18:57 --> URI Class Initialized
INFO - 2016-12-10 22:18:57 --> Router Class Initialized
INFO - 2016-12-10 22:18:57 --> Output Class Initialized
INFO - 2016-12-10 22:18:57 --> Security Class Initialized
DEBUG - 2016-12-10 22:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:18:57 --> Input Class Initialized
INFO - 2016-12-10 22:18:57 --> Language Class Initialized
INFO - 2016-12-10 22:18:57 --> Loader Class Initialized
INFO - 2016-12-10 22:18:57 --> Database Driver Class Initialized
INFO - 2016-12-10 22:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:18:57 --> Controller Class Initialized
INFO - 2016-12-10 22:18:57 --> Helper loaded: date_helper
INFO - 2016-12-10 22:18:57 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:18:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:18:57 --> Helper loaded: form_helper
INFO - 2016-12-10 22:18:57 --> Form Validation Class Initialized
INFO - 2016-12-10 22:18:57 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 22:18:57 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-10 22:18:57 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pagos.php
INFO - 2016-12-10 22:18:57 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pagos.php
INFO - 2016-12-10 22:18:57 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 22:18:57 --> Final output sent to browser
DEBUG - 2016-12-10 22:18:57 --> Total execution time: 0.0635
INFO - 2016-12-10 22:18:58 --> Config Class Initialized
INFO - 2016-12-10 22:18:58 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:18:58 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:18:58 --> Utf8 Class Initialized
INFO - 2016-12-10 22:18:58 --> URI Class Initialized
INFO - 2016-12-10 22:18:58 --> Router Class Initialized
INFO - 2016-12-10 22:18:58 --> Output Class Initialized
INFO - 2016-12-10 22:18:58 --> Security Class Initialized
DEBUG - 2016-12-10 22:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:18:58 --> Input Class Initialized
INFO - 2016-12-10 22:18:58 --> Language Class Initialized
INFO - 2016-12-10 22:18:58 --> Loader Class Initialized
INFO - 2016-12-10 22:18:58 --> Database Driver Class Initialized
INFO - 2016-12-10 22:18:58 --> Config Class Initialized
INFO - 2016-12-10 22:18:58 --> Hooks Class Initialized
INFO - 2016-12-10 22:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:18:58 --> Controller Class Initialized
DEBUG - 2016-12-10 22:18:58 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:18:58 --> Utf8 Class Initialized
INFO - 2016-12-10 22:18:58 --> URI Class Initialized
INFO - 2016-12-10 22:18:58 --> Helper loaded: date_helper
INFO - 2016-12-10 22:18:58 --> Router Class Initialized
INFO - 2016-12-10 22:18:58 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:18:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:18:58 --> Output Class Initialized
INFO - 2016-12-10 22:18:58 --> Security Class Initialized
INFO - 2016-12-10 22:18:58 --> Helper loaded: form_helper
INFO - 2016-12-10 22:18:58 --> Form Validation Class Initialized
DEBUG - 2016-12-10 22:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:18:58 --> Input Class Initialized
INFO - 2016-12-10 22:18:58 --> Language Class Initialized
INFO - 2016-12-10 22:18:58 --> Loader Class Initialized
INFO - 2016-12-10 22:18:58 --> Database Driver Class Initialized
INFO - 2016-12-10 22:18:58 --> Final output sent to browser
DEBUG - 2016-12-10 22:18:58 --> Total execution time: 0.0192
INFO - 2016-12-10 22:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:18:58 --> Controller Class Initialized
INFO - 2016-12-10 22:18:58 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:18:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:18:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:18:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:18:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:18:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:18:58 --> Final output sent to browser
DEBUG - 2016-12-10 22:18:58 --> Total execution time: 0.0791
INFO - 2016-12-10 22:19:02 --> Config Class Initialized
INFO - 2016-12-10 22:19:02 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:19:02 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:19:02 --> Utf8 Class Initialized
INFO - 2016-12-10 22:19:02 --> URI Class Initialized
INFO - 2016-12-10 22:19:02 --> Router Class Initialized
INFO - 2016-12-10 22:19:02 --> Output Class Initialized
INFO - 2016-12-10 22:19:02 --> Security Class Initialized
DEBUG - 2016-12-10 22:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:19:02 --> Input Class Initialized
INFO - 2016-12-10 22:19:02 --> Language Class Initialized
INFO - 2016-12-10 22:19:02 --> Loader Class Initialized
INFO - 2016-12-10 22:19:02 --> Database Driver Class Initialized
INFO - 2016-12-10 22:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:19:02 --> Controller Class Initialized
INFO - 2016-12-10 22:19:02 --> Helper loaded: date_helper
INFO - 2016-12-10 22:19:02 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:19:02 --> Helper loaded: form_helper
INFO - 2016-12-10 22:19:02 --> Form Validation Class Initialized
INFO - 2016-12-10 22:19:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 22:19:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-10 22:19:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2016-12-10 22:19:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2016-12-10 22:19:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 22:19:02 --> Final output sent to browser
DEBUG - 2016-12-10 22:19:02 --> Total execution time: 0.0156
INFO - 2016-12-10 22:19:02 --> Config Class Initialized
INFO - 2016-12-10 22:19:02 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:19:02 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:19:02 --> Utf8 Class Initialized
INFO - 2016-12-10 22:19:02 --> URI Class Initialized
INFO - 2016-12-10 22:19:02 --> Router Class Initialized
INFO - 2016-12-10 22:19:02 --> Output Class Initialized
INFO - 2016-12-10 22:19:02 --> Security Class Initialized
DEBUG - 2016-12-10 22:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:19:02 --> Input Class Initialized
INFO - 2016-12-10 22:19:02 --> Language Class Initialized
INFO - 2016-12-10 22:19:02 --> Loader Class Initialized
INFO - 2016-12-10 22:19:02 --> Database Driver Class Initialized
INFO - 2016-12-10 22:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:19:02 --> Controller Class Initialized
INFO - 2016-12-10 22:19:02 --> Helper loaded: date_helper
INFO - 2016-12-10 22:19:02 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:19:02 --> Helper loaded: form_helper
INFO - 2016-12-10 22:19:02 --> Form Validation Class Initialized
INFO - 2016-12-10 22:19:02 --> Final output sent to browser
DEBUG - 2016-12-10 22:19:02 --> Total execution time: 0.0145
INFO - 2016-12-10 22:19:02 --> Config Class Initialized
INFO - 2016-12-10 22:19:02 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:19:02 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:19:02 --> Utf8 Class Initialized
INFO - 2016-12-10 22:19:02 --> URI Class Initialized
INFO - 2016-12-10 22:19:02 --> Router Class Initialized
INFO - 2016-12-10 22:19:02 --> Output Class Initialized
INFO - 2016-12-10 22:19:02 --> Security Class Initialized
DEBUG - 2016-12-10 22:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:19:02 --> Input Class Initialized
INFO - 2016-12-10 22:19:02 --> Language Class Initialized
INFO - 2016-12-10 22:19:02 --> Loader Class Initialized
INFO - 2016-12-10 22:19:02 --> Database Driver Class Initialized
INFO - 2016-12-10 22:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:19:02 --> Controller Class Initialized
INFO - 2016-12-10 22:19:02 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:19:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:19:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:19:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:19:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:19:02 --> Final output sent to browser
DEBUG - 2016-12-10 22:19:02 --> Total execution time: 0.0134
INFO - 2016-12-10 22:58:46 --> Config Class Initialized
INFO - 2016-12-10 22:58:46 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:58:46 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:58:46 --> Utf8 Class Initialized
INFO - 2016-12-10 22:58:46 --> URI Class Initialized
INFO - 2016-12-10 22:58:46 --> Router Class Initialized
INFO - 2016-12-10 22:58:46 --> Output Class Initialized
INFO - 2016-12-10 22:58:46 --> Security Class Initialized
DEBUG - 2016-12-10 22:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:58:46 --> Input Class Initialized
INFO - 2016-12-10 22:58:46 --> Language Class Initialized
INFO - 2016-12-10 22:58:46 --> Loader Class Initialized
INFO - 2016-12-10 22:58:47 --> Database Driver Class Initialized
INFO - 2016-12-10 22:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:58:47 --> Controller Class Initialized
INFO - 2016-12-10 22:58:47 --> Helper loaded: date_helper
INFO - 2016-12-10 22:58:47 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:58:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:58:47 --> Helper loaded: form_helper
INFO - 2016-12-10 22:58:47 --> Form Validation Class Initialized
INFO - 2016-12-10 22:58:47 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 22:58:47 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-10 22:58:47 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2016-12-10 22:58:47 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2016-12-10 22:58:47 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 22:58:47 --> Final output sent to browser
DEBUG - 2016-12-10 22:58:47 --> Total execution time: 1.1369
INFO - 2016-12-10 22:58:48 --> Config Class Initialized
INFO - 2016-12-10 22:58:48 --> Hooks Class Initialized
INFO - 2016-12-10 22:58:48 --> Config Class Initialized
INFO - 2016-12-10 22:58:48 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:58:48 --> UTF-8 Support Enabled
DEBUG - 2016-12-10 22:58:48 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:58:48 --> Utf8 Class Initialized
INFO - 2016-12-10 22:58:48 --> Utf8 Class Initialized
INFO - 2016-12-10 22:58:48 --> URI Class Initialized
INFO - 2016-12-10 22:58:48 --> URI Class Initialized
INFO - 2016-12-10 22:58:48 --> Router Class Initialized
INFO - 2016-12-10 22:58:48 --> Router Class Initialized
INFO - 2016-12-10 22:58:48 --> Output Class Initialized
INFO - 2016-12-10 22:58:48 --> Output Class Initialized
INFO - 2016-12-10 22:58:48 --> Security Class Initialized
INFO - 2016-12-10 22:58:48 --> Security Class Initialized
DEBUG - 2016-12-10 22:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-12-10 22:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:58:48 --> Input Class Initialized
INFO - 2016-12-10 22:58:48 --> Input Class Initialized
INFO - 2016-12-10 22:58:48 --> Language Class Initialized
INFO - 2016-12-10 22:58:48 --> Language Class Initialized
INFO - 2016-12-10 22:58:48 --> Loader Class Initialized
INFO - 2016-12-10 22:58:48 --> Loader Class Initialized
INFO - 2016-12-10 22:58:48 --> Database Driver Class Initialized
INFO - 2016-12-10 22:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:58:48 --> Controller Class Initialized
INFO - 2016-12-10 22:58:48 --> Helper loaded: url_helper
INFO - 2016-12-10 22:58:48 --> Database Driver Class Initialized
DEBUG - 2016-12-10 22:58:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:58:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:58:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:58:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:58:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:58:48 --> Final output sent to browser
DEBUG - 2016-12-10 22:58:48 --> Total execution time: 0.2837
INFO - 2016-12-10 22:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:58:48 --> Controller Class Initialized
INFO - 2016-12-10 22:58:48 --> Helper loaded: date_helper
INFO - 2016-12-10 22:58:48 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:58:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:58:48 --> Helper loaded: form_helper
INFO - 2016-12-10 22:58:48 --> Form Validation Class Initialized
INFO - 2016-12-10 22:58:48 --> Final output sent to browser
DEBUG - 2016-12-10 22:58:48 --> Total execution time: 0.2885
INFO - 2016-12-10 22:58:50 --> Config Class Initialized
INFO - 2016-12-10 22:58:50 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:58:50 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:58:50 --> Utf8 Class Initialized
INFO - 2016-12-10 22:58:50 --> URI Class Initialized
INFO - 2016-12-10 22:58:50 --> Router Class Initialized
INFO - 2016-12-10 22:58:50 --> Output Class Initialized
INFO - 2016-12-10 22:58:50 --> Security Class Initialized
DEBUG - 2016-12-10 22:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:58:50 --> Input Class Initialized
INFO - 2016-12-10 22:58:50 --> Language Class Initialized
ERROR - 2016-12-10 22:58:50 --> 404 Page Not Found: Admin_cupones_controller/index
INFO - 2016-12-10 22:58:50 --> Config Class Initialized
INFO - 2016-12-10 22:58:50 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:58:50 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:58:50 --> Utf8 Class Initialized
INFO - 2016-12-10 22:58:50 --> URI Class Initialized
INFO - 2016-12-10 22:58:50 --> Router Class Initialized
INFO - 2016-12-10 22:58:50 --> Output Class Initialized
INFO - 2016-12-10 22:58:50 --> Security Class Initialized
DEBUG - 2016-12-10 22:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:58:50 --> Input Class Initialized
INFO - 2016-12-10 22:58:50 --> Language Class Initialized
INFO - 2016-12-10 22:58:50 --> Loader Class Initialized
INFO - 2016-12-10 22:58:50 --> Database Driver Class Initialized
INFO - 2016-12-10 22:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:58:50 --> Controller Class Initialized
INFO - 2016-12-10 22:58:50 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:58:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:58:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:58:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:58:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:58:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:58:50 --> Final output sent to browser
DEBUG - 2016-12-10 22:58:50 --> Total execution time: 0.0702
INFO - 2016-12-10 22:58:56 --> Config Class Initialized
INFO - 2016-12-10 22:58:56 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:58:56 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:58:56 --> Utf8 Class Initialized
INFO - 2016-12-10 22:58:56 --> URI Class Initialized
INFO - 2016-12-10 22:58:56 --> Router Class Initialized
INFO - 2016-12-10 22:58:56 --> Output Class Initialized
INFO - 2016-12-10 22:58:56 --> Security Class Initialized
DEBUG - 2016-12-10 22:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:58:56 --> Input Class Initialized
INFO - 2016-12-10 22:58:56 --> Language Class Initialized
INFO - 2016-12-10 22:58:56 --> Loader Class Initialized
INFO - 2016-12-10 22:58:56 --> Database Driver Class Initialized
INFO - 2016-12-10 22:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:58:56 --> Controller Class Initialized
INFO - 2016-12-10 22:58:56 --> Helper loaded: date_helper
INFO - 2016-12-10 22:58:56 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:58:56 --> Helper loaded: form_helper
INFO - 2016-12-10 22:58:56 --> Form Validation Class Initialized
INFO - 2016-12-10 22:58:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 22:58:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-10 22:58:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2016-12-10 22:58:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2016-12-10 22:58:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 22:58:56 --> Final output sent to browser
DEBUG - 2016-12-10 22:58:56 --> Total execution time: 0.0240
INFO - 2016-12-10 22:58:57 --> Config Class Initialized
INFO - 2016-12-10 22:58:57 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:58:57 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:58:57 --> Utf8 Class Initialized
INFO - 2016-12-10 22:58:57 --> URI Class Initialized
INFO - 2016-12-10 22:58:57 --> Router Class Initialized
INFO - 2016-12-10 22:58:57 --> Output Class Initialized
INFO - 2016-12-10 22:58:57 --> Security Class Initialized
DEBUG - 2016-12-10 22:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:58:57 --> Input Class Initialized
INFO - 2016-12-10 22:58:57 --> Language Class Initialized
INFO - 2016-12-10 22:58:57 --> Loader Class Initialized
INFO - 2016-12-10 22:58:57 --> Database Driver Class Initialized
INFO - 2016-12-10 22:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:58:57 --> Controller Class Initialized
INFO - 2016-12-10 22:58:57 --> Helper loaded: date_helper
INFO - 2016-12-10 22:58:57 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:58:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:58:57 --> Helper loaded: form_helper
INFO - 2016-12-10 22:58:57 --> Form Validation Class Initialized
INFO - 2016-12-10 22:58:57 --> Final output sent to browser
DEBUG - 2016-12-10 22:58:57 --> Total execution time: 0.0805
INFO - 2016-12-10 22:58:57 --> Config Class Initialized
INFO - 2016-12-10 22:58:57 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:58:57 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:58:57 --> Utf8 Class Initialized
INFO - 2016-12-10 22:58:57 --> URI Class Initialized
INFO - 2016-12-10 22:58:57 --> Router Class Initialized
INFO - 2016-12-10 22:58:57 --> Output Class Initialized
INFO - 2016-12-10 22:58:57 --> Security Class Initialized
DEBUG - 2016-12-10 22:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:58:57 --> Input Class Initialized
INFO - 2016-12-10 22:58:57 --> Language Class Initialized
INFO - 2016-12-10 22:58:57 --> Loader Class Initialized
INFO - 2016-12-10 22:58:57 --> Database Driver Class Initialized
INFO - 2016-12-10 22:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:58:57 --> Controller Class Initialized
INFO - 2016-12-10 22:58:57 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:58:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:58:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:58:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:58:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:58:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:58:57 --> Final output sent to browser
DEBUG - 2016-12-10 22:58:57 --> Total execution time: 0.0138
INFO - 2016-12-10 22:59:17 --> Config Class Initialized
INFO - 2016-12-10 22:59:17 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:59:17 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:59:17 --> Utf8 Class Initialized
INFO - 2016-12-10 22:59:17 --> URI Class Initialized
INFO - 2016-12-10 22:59:17 --> Router Class Initialized
INFO - 2016-12-10 22:59:18 --> Output Class Initialized
INFO - 2016-12-10 22:59:18 --> Security Class Initialized
DEBUG - 2016-12-10 22:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:59:18 --> Input Class Initialized
INFO - 2016-12-10 22:59:18 --> Language Class Initialized
INFO - 2016-12-10 22:59:18 --> Loader Class Initialized
INFO - 2016-12-10 22:59:18 --> Database Driver Class Initialized
INFO - 2016-12-10 22:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:59:18 --> Controller Class Initialized
INFO - 2016-12-10 22:59:18 --> Upload Class Initialized
INFO - 2016-12-10 22:59:18 --> Helper loaded: date_helper
INFO - 2016-12-10 22:59:18 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:59:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:59:18 --> Helper loaded: form_helper
INFO - 2016-12-10 22:59:18 --> Form Validation Class Initialized
INFO - 2016-12-10 22:59:18 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 22:59:18 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
ERROR - 2016-12-10 22:59:18 --> Severity: Notice --> Undefined variable: lugares /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php 77
ERROR - 2016-12-10 22:59:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php 77
INFO - 2016-12-10 22:59:18 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2016-12-10 22:59:18 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-10 22:59:18 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 22:59:18 --> Final output sent to browser
DEBUG - 2016-12-10 22:59:18 --> Total execution time: 1.4124
INFO - 2016-12-10 22:59:21 --> Config Class Initialized
INFO - 2016-12-10 22:59:21 --> Hooks Class Initialized
DEBUG - 2016-12-10 22:59:21 --> UTF-8 Support Enabled
INFO - 2016-12-10 22:59:21 --> Utf8 Class Initialized
INFO - 2016-12-10 22:59:21 --> URI Class Initialized
INFO - 2016-12-10 22:59:21 --> Router Class Initialized
INFO - 2016-12-10 22:59:21 --> Output Class Initialized
INFO - 2016-12-10 22:59:21 --> Security Class Initialized
DEBUG - 2016-12-10 22:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 22:59:21 --> Input Class Initialized
INFO - 2016-12-10 22:59:21 --> Language Class Initialized
INFO - 2016-12-10 22:59:21 --> Loader Class Initialized
INFO - 2016-12-10 22:59:21 --> Database Driver Class Initialized
INFO - 2016-12-10 22:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 22:59:21 --> Controller Class Initialized
INFO - 2016-12-10 22:59:21 --> Helper loaded: url_helper
DEBUG - 2016-12-10 22:59:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 22:59:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 22:59:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 22:59:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 22:59:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 22:59:22 --> Final output sent to browser
DEBUG - 2016-12-10 22:59:22 --> Total execution time: 1.0573
INFO - 2016-12-10 23:05:04 --> Config Class Initialized
INFO - 2016-12-10 23:05:04 --> Hooks Class Initialized
DEBUG - 2016-12-10 23:05:04 --> UTF-8 Support Enabled
INFO - 2016-12-10 23:05:04 --> Utf8 Class Initialized
INFO - 2016-12-10 23:05:04 --> URI Class Initialized
INFO - 2016-12-10 23:05:04 --> Router Class Initialized
INFO - 2016-12-10 23:05:04 --> Output Class Initialized
INFO - 2016-12-10 23:05:04 --> Security Class Initialized
DEBUG - 2016-12-10 23:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 23:05:04 --> Input Class Initialized
INFO - 2016-12-10 23:05:04 --> Language Class Initialized
INFO - 2016-12-10 23:05:04 --> Loader Class Initialized
INFO - 2016-12-10 23:05:04 --> Database Driver Class Initialized
INFO - 2016-12-10 23:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 23:05:05 --> Controller Class Initialized
INFO - 2016-12-10 23:05:05 --> Upload Class Initialized
INFO - 2016-12-10 23:05:05 --> Helper loaded: date_helper
INFO - 2016-12-10 23:05:05 --> Helper loaded: url_helper
DEBUG - 2016-12-10 23:05:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 23:05:05 --> Helper loaded: form_helper
INFO - 2016-12-10 23:05:05 --> Form Validation Class Initialized
INFO - 2016-12-10 23:05:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 23:05:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
ERROR - 2016-12-10 23:05:05 --> Severity: Notice --> Undefined variable: lugares /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php 77
ERROR - 2016-12-10 23:05:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php 77
INFO - 2016-12-10 23:05:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2016-12-10 23:05:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-10 23:05:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 23:05:05 --> Final output sent to browser
DEBUG - 2016-12-10 23:05:05 --> Total execution time: 1.2053
INFO - 2016-12-10 23:05:07 --> Config Class Initialized
INFO - 2016-12-10 23:05:07 --> Hooks Class Initialized
INFO - 2016-12-10 23:05:07 --> Config Class Initialized
INFO - 2016-12-10 23:05:07 --> Hooks Class Initialized
DEBUG - 2016-12-10 23:05:07 --> UTF-8 Support Enabled
INFO - 2016-12-10 23:05:07 --> Utf8 Class Initialized
DEBUG - 2016-12-10 23:05:07 --> UTF-8 Support Enabled
INFO - 2016-12-10 23:05:07 --> Utf8 Class Initialized
INFO - 2016-12-10 23:05:07 --> URI Class Initialized
INFO - 2016-12-10 23:05:07 --> URI Class Initialized
INFO - 2016-12-10 23:05:07 --> Router Class Initialized
INFO - 2016-12-10 23:05:07 --> Router Class Initialized
INFO - 2016-12-10 23:05:07 --> Output Class Initialized
INFO - 2016-12-10 23:05:07 --> Security Class Initialized
INFO - 2016-12-10 23:05:07 --> Output Class Initialized
INFO - 2016-12-10 23:05:07 --> Security Class Initialized
DEBUG - 2016-12-10 23:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 23:05:07 --> Input Class Initialized
INFO - 2016-12-10 23:05:07 --> Language Class Initialized
DEBUG - 2016-12-10 23:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 23:05:07 --> Input Class Initialized
INFO - 2016-12-10 23:05:07 --> Loader Class Initialized
INFO - 2016-12-10 23:05:07 --> Language Class Initialized
INFO - 2016-12-10 23:05:08 --> Loader Class Initialized
INFO - 2016-12-10 23:05:08 --> Database Driver Class Initialized
INFO - 2016-12-10 23:05:08 --> Database Driver Class Initialized
INFO - 2016-12-10 23:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 23:05:08 --> Controller Class Initialized
INFO - 2016-12-10 23:05:08 --> Helper loaded: url_helper
DEBUG - 2016-12-10 23:05:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 23:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 23:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 23:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 23:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 23:05:08 --> Final output sent to browser
DEBUG - 2016-12-10 23:05:08 --> Total execution time: 0.8791
INFO - 2016-12-10 23:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 23:05:08 --> Controller Class Initialized
INFO - 2016-12-10 23:05:08 --> Upload Class Initialized
INFO - 2016-12-10 23:05:08 --> Helper loaded: date_helper
INFO - 2016-12-10 23:05:08 --> Helper loaded: url_helper
DEBUG - 2016-12-10 23:05:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 23:05:08 --> Helper loaded: form_helper
INFO - 2016-12-10 23:05:08 --> Form Validation Class Initialized
INFO - 2016-12-10 23:05:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 23:05:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
ERROR - 2016-12-10 23:05:08 --> Severity: Notice --> Undefined variable: lugares /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php 77
ERROR - 2016-12-10 23:05:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php 77
INFO - 2016-12-10 23:05:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2016-12-10 23:05:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-10 23:05:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 23:05:08 --> Final output sent to browser
DEBUG - 2016-12-10 23:05:08 --> Total execution time: 1.2066
INFO - 2016-12-10 23:05:09 --> Config Class Initialized
INFO - 2016-12-10 23:05:09 --> Hooks Class Initialized
DEBUG - 2016-12-10 23:05:09 --> UTF-8 Support Enabled
INFO - 2016-12-10 23:05:09 --> Utf8 Class Initialized
INFO - 2016-12-10 23:05:09 --> URI Class Initialized
INFO - 2016-12-10 23:05:09 --> Router Class Initialized
INFO - 2016-12-10 23:05:09 --> Output Class Initialized
INFO - 2016-12-10 23:05:09 --> Security Class Initialized
DEBUG - 2016-12-10 23:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 23:05:09 --> Input Class Initialized
INFO - 2016-12-10 23:05:09 --> Language Class Initialized
INFO - 2016-12-10 23:05:09 --> Loader Class Initialized
INFO - 2016-12-10 23:05:09 --> Database Driver Class Initialized
INFO - 2016-12-10 23:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 23:05:09 --> Controller Class Initialized
INFO - 2016-12-10 23:05:09 --> Helper loaded: url_helper
DEBUG - 2016-12-10 23:05:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 23:05:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 23:05:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 23:05:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 23:05:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 23:05:09 --> Final output sent to browser
DEBUG - 2016-12-10 23:05:09 --> Total execution time: 0.0240
INFO - 2016-12-10 23:09:33 --> Config Class Initialized
INFO - 2016-12-10 23:09:33 --> Hooks Class Initialized
DEBUG - 2016-12-10 23:09:33 --> UTF-8 Support Enabled
INFO - 2016-12-10 23:09:33 --> Utf8 Class Initialized
INFO - 2016-12-10 23:09:33 --> URI Class Initialized
INFO - 2016-12-10 23:09:33 --> Router Class Initialized
INFO - 2016-12-10 23:09:33 --> Output Class Initialized
INFO - 2016-12-10 23:09:33 --> Security Class Initialized
DEBUG - 2016-12-10 23:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 23:09:33 --> Input Class Initialized
INFO - 2016-12-10 23:09:33 --> Language Class Initialized
INFO - 2016-12-10 23:09:33 --> Loader Class Initialized
INFO - 2016-12-10 23:09:34 --> Database Driver Class Initialized
INFO - 2016-12-10 23:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 23:09:34 --> Controller Class Initialized
INFO - 2016-12-10 23:09:34 --> Upload Class Initialized
INFO - 2016-12-10 23:09:34 --> Helper loaded: date_helper
INFO - 2016-12-10 23:09:34 --> Helper loaded: url_helper
DEBUG - 2016-12-10 23:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 23:09:34 --> Helper loaded: form_helper
INFO - 2016-12-10 23:09:34 --> Form Validation Class Initialized
INFO - 2016-12-10 23:09:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 23:09:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
ERROR - 2016-12-10 23:09:34 --> Severity: Notice --> Undefined variable: lugares /home/graduafe/public_html/application/views/administrador/pages/cupones.php 77
ERROR - 2016-12-10 23:09:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/graduafe/public_html/application/views/administrador/pages/cupones.php 77
INFO - 2016-12-10 23:09:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/cupones.php
INFO - 2016-12-10 23:09:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/cupones.php
INFO - 2016-12-10 23:09:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-10 23:09:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 23:09:34 --> Final output sent to browser
DEBUG - 2016-12-10 23:09:34 --> Total execution time: 1.0906
INFO - 2016-12-10 23:09:35 --> Config Class Initialized
INFO - 2016-12-10 23:09:35 --> Hooks Class Initialized
DEBUG - 2016-12-10 23:09:35 --> UTF-8 Support Enabled
INFO - 2016-12-10 23:09:35 --> Utf8 Class Initialized
INFO - 2016-12-10 23:09:35 --> URI Class Initialized
INFO - 2016-12-10 23:09:35 --> Router Class Initialized
INFO - 2016-12-10 23:09:35 --> Output Class Initialized
INFO - 2016-12-10 23:09:35 --> Security Class Initialized
DEBUG - 2016-12-10 23:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 23:09:35 --> Input Class Initialized
INFO - 2016-12-10 23:09:35 --> Language Class Initialized
INFO - 2016-12-10 23:09:35 --> Loader Class Initialized
INFO - 2016-12-10 23:09:35 --> Database Driver Class Initialized
INFO - 2016-12-10 23:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 23:09:35 --> Controller Class Initialized
INFO - 2016-12-10 23:09:35 --> Helper loaded: url_helper
DEBUG - 2016-12-10 23:09:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 23:09:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 23:09:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 23:09:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 23:09:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 23:09:35 --> Final output sent to browser
DEBUG - 2016-12-10 23:09:35 --> Total execution time: 0.4087
INFO - 2016-12-10 23:14:32 --> Config Class Initialized
INFO - 2016-12-10 23:14:32 --> Hooks Class Initialized
DEBUG - 2016-12-10 23:14:32 --> UTF-8 Support Enabled
INFO - 2016-12-10 23:14:32 --> Utf8 Class Initialized
INFO - 2016-12-10 23:14:33 --> URI Class Initialized
DEBUG - 2016-12-10 23:14:33 --> No URI present. Default controller set.
INFO - 2016-12-10 23:14:33 --> Router Class Initialized
INFO - 2016-12-10 23:14:33 --> Output Class Initialized
INFO - 2016-12-10 23:14:33 --> Security Class Initialized
DEBUG - 2016-12-10 23:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 23:14:33 --> Input Class Initialized
INFO - 2016-12-10 23:14:33 --> Language Class Initialized
INFO - 2016-12-10 23:14:33 --> Loader Class Initialized
INFO - 2016-12-10 23:14:33 --> Database Driver Class Initialized
INFO - 2016-12-10 23:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 23:14:33 --> Controller Class Initialized
INFO - 2016-12-10 23:14:33 --> Helper loaded: url_helper
DEBUG - 2016-12-10 23:14:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 23:14:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 23:14:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 23:14:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 23:14:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 23:14:33 --> Final output sent to browser
DEBUG - 2016-12-10 23:14:33 --> Total execution time: 0.8404
INFO - 2016-12-10 23:18:50 --> Config Class Initialized
INFO - 2016-12-10 23:18:50 --> Hooks Class Initialized
DEBUG - 2016-12-10 23:18:50 --> UTF-8 Support Enabled
INFO - 2016-12-10 23:18:50 --> Utf8 Class Initialized
INFO - 2016-12-10 23:18:50 --> URI Class Initialized
INFO - 2016-12-10 23:18:50 --> Router Class Initialized
INFO - 2016-12-10 23:18:50 --> Output Class Initialized
INFO - 2016-12-10 23:18:50 --> Security Class Initialized
DEBUG - 2016-12-10 23:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 23:18:50 --> Input Class Initialized
INFO - 2016-12-10 23:18:50 --> Language Class Initialized
INFO - 2016-12-10 23:18:50 --> Loader Class Initialized
INFO - 2016-12-10 23:18:51 --> Database Driver Class Initialized
INFO - 2016-12-10 23:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 23:18:51 --> Controller Class Initialized
INFO - 2016-12-10 23:18:51 --> Upload Class Initialized
INFO - 2016-12-10 23:18:51 --> Helper loaded: date_helper
INFO - 2016-12-10 23:18:51 --> Helper loaded: url_helper
DEBUG - 2016-12-10 23:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 23:18:51 --> Helper loaded: form_helper
INFO - 2016-12-10 23:18:51 --> Form Validation Class Initialized
INFO - 2016-12-10 23:18:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 23:18:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
ERROR - 2016-12-10 23:18:51 --> Severity: Notice --> Undefined variable: lugares /home/graduafe/public_html/application/views/administrador/pages/cupones.php 77
ERROR - 2016-12-10 23:18:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/graduafe/public_html/application/views/administrador/pages/cupones.php 77
INFO - 2016-12-10 23:18:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/cupones.php
INFO - 2016-12-10 23:18:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/cupones.php
INFO - 2016-12-10 23:18:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-10 23:18:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 23:18:51 --> Final output sent to browser
DEBUG - 2016-12-10 23:18:51 --> Total execution time: 0.8996
INFO - 2016-12-10 23:18:52 --> Config Class Initialized
INFO - 2016-12-10 23:18:52 --> Hooks Class Initialized
DEBUG - 2016-12-10 23:18:52 --> UTF-8 Support Enabled
INFO - 2016-12-10 23:18:52 --> Utf8 Class Initialized
INFO - 2016-12-10 23:18:52 --> URI Class Initialized
INFO - 2016-12-10 23:18:52 --> Router Class Initialized
INFO - 2016-12-10 23:18:52 --> Output Class Initialized
INFO - 2016-12-10 23:18:52 --> Security Class Initialized
DEBUG - 2016-12-10 23:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 23:18:52 --> Input Class Initialized
INFO - 2016-12-10 23:18:52 --> Language Class Initialized
INFO - 2016-12-10 23:18:52 --> Loader Class Initialized
INFO - 2016-12-10 23:18:52 --> Database Driver Class Initialized
INFO - 2016-12-10 23:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 23:18:52 --> Controller Class Initialized
INFO - 2016-12-10 23:18:52 --> Helper loaded: url_helper
DEBUG - 2016-12-10 23:18:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 23:18:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 23:18:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 23:18:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 23:18:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 23:18:52 --> Final output sent to browser
DEBUG - 2016-12-10 23:18:52 --> Total execution time: 0.0608
INFO - 2016-12-10 23:21:22 --> Config Class Initialized
INFO - 2016-12-10 23:21:22 --> Hooks Class Initialized
DEBUG - 2016-12-10 23:21:22 --> UTF-8 Support Enabled
INFO - 2016-12-10 23:21:22 --> Utf8 Class Initialized
INFO - 2016-12-10 23:21:22 --> URI Class Initialized
INFO - 2016-12-10 23:21:22 --> Router Class Initialized
INFO - 2016-12-10 23:21:22 --> Output Class Initialized
INFO - 2016-12-10 23:21:22 --> Security Class Initialized
DEBUG - 2016-12-10 23:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 23:21:22 --> Input Class Initialized
INFO - 2016-12-10 23:21:22 --> Language Class Initialized
INFO - 2016-12-10 23:21:22 --> Loader Class Initialized
INFO - 2016-12-10 23:21:22 --> Database Driver Class Initialized
INFO - 2016-12-10 23:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 23:21:22 --> Controller Class Initialized
INFO - 2016-12-10 23:21:22 --> Upload Class Initialized
INFO - 2016-12-10 23:21:22 --> Helper loaded: date_helper
INFO - 2016-12-10 23:21:22 --> Helper loaded: url_helper
DEBUG - 2016-12-10 23:21:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 23:21:22 --> Helper loaded: form_helper
INFO - 2016-12-10 23:21:22 --> Form Validation Class Initialized
INFO - 2016-12-10 23:21:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 23:21:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
ERROR - 2016-12-10 23:21:22 --> Severity: Notice --> Undefined variable: lugares /home/graduafe/public_html/application/views/administrador/pages/cupones.php 77
ERROR - 2016-12-10 23:21:22 --> Severity: Warning --> Invalid argument supplied for foreach() /home/graduafe/public_html/application/views/administrador/pages/cupones.php 77
INFO - 2016-12-10 23:21:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/cupones.php
INFO - 2016-12-10 23:21:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/cupones.php
INFO - 2016-12-10 23:21:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-10 23:21:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 23:21:22 --> Final output sent to browser
DEBUG - 2016-12-10 23:21:22 --> Total execution time: 0.5749
INFO - 2016-12-10 23:21:23 --> Config Class Initialized
INFO - 2016-12-10 23:21:23 --> Hooks Class Initialized
DEBUG - 2016-12-10 23:21:23 --> UTF-8 Support Enabled
INFO - 2016-12-10 23:21:23 --> Utf8 Class Initialized
INFO - 2016-12-10 23:21:23 --> URI Class Initialized
INFO - 2016-12-10 23:21:23 --> Router Class Initialized
INFO - 2016-12-10 23:21:23 --> Output Class Initialized
INFO - 2016-12-10 23:21:23 --> Security Class Initialized
DEBUG - 2016-12-10 23:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 23:21:23 --> Input Class Initialized
INFO - 2016-12-10 23:21:23 --> Language Class Initialized
INFO - 2016-12-10 23:21:23 --> Loader Class Initialized
INFO - 2016-12-10 23:21:23 --> Database Driver Class Initialized
INFO - 2016-12-10 23:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 23:21:23 --> Controller Class Initialized
INFO - 2016-12-10 23:21:23 --> Helper loaded: url_helper
DEBUG - 2016-12-10 23:21:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 23:21:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 23:21:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 23:21:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 23:21:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 23:21:23 --> Final output sent to browser
DEBUG - 2016-12-10 23:21:23 --> Total execution time: 0.0468
INFO - 2016-12-10 23:22:14 --> Config Class Initialized
INFO - 2016-12-10 23:22:14 --> Hooks Class Initialized
DEBUG - 2016-12-10 23:22:14 --> UTF-8 Support Enabled
INFO - 2016-12-10 23:22:14 --> Utf8 Class Initialized
INFO - 2016-12-10 23:22:14 --> URI Class Initialized
INFO - 2016-12-10 23:22:14 --> Router Class Initialized
INFO - 2016-12-10 23:22:14 --> Output Class Initialized
INFO - 2016-12-10 23:22:14 --> Security Class Initialized
DEBUG - 2016-12-10 23:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 23:22:14 --> Input Class Initialized
INFO - 2016-12-10 23:22:14 --> Language Class Initialized
INFO - 2016-12-10 23:22:14 --> Loader Class Initialized
INFO - 2016-12-10 23:22:14 --> Database Driver Class Initialized
INFO - 2016-12-10 23:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 23:22:14 --> Controller Class Initialized
INFO - 2016-12-10 23:22:14 --> Upload Class Initialized
INFO - 2016-12-10 23:22:14 --> Helper loaded: date_helper
INFO - 2016-12-10 23:22:14 --> Helper loaded: url_helper
DEBUG - 2016-12-10 23:22:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 23:22:15 --> Helper loaded: form_helper
INFO - 2016-12-10 23:22:15 --> Form Validation Class Initialized
INFO - 2016-12-10 23:22:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-10 23:22:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
ERROR - 2016-12-10 23:22:15 --> Severity: Notice --> Undefined variable: lugares /home/graduafe/public_html/application/views/administrador/pages/cupones.php 77
ERROR - 2016-12-10 23:22:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/graduafe/public_html/application/views/administrador/pages/cupones.php 77
INFO - 2016-12-10 23:22:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/cupones.php
INFO - 2016-12-10 23:22:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/cupones.php
INFO - 2016-12-10 23:22:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-10 23:22:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-10 23:22:15 --> Final output sent to browser
DEBUG - 2016-12-10 23:22:15 --> Total execution time: 0.6003
INFO - 2016-12-10 23:22:15 --> Config Class Initialized
INFO - 2016-12-10 23:22:15 --> Hooks Class Initialized
DEBUG - 2016-12-10 23:22:15 --> UTF-8 Support Enabled
INFO - 2016-12-10 23:22:15 --> Utf8 Class Initialized
INFO - 2016-12-10 23:22:15 --> URI Class Initialized
INFO - 2016-12-10 23:22:15 --> Router Class Initialized
INFO - 2016-12-10 23:22:15 --> Output Class Initialized
INFO - 2016-12-10 23:22:15 --> Security Class Initialized
DEBUG - 2016-12-10 23:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-10 23:22:15 --> Input Class Initialized
INFO - 2016-12-10 23:22:15 --> Language Class Initialized
INFO - 2016-12-10 23:22:15 --> Loader Class Initialized
INFO - 2016-12-10 23:22:15 --> Database Driver Class Initialized
INFO - 2016-12-10 23:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-10 23:22:15 --> Controller Class Initialized
INFO - 2016-12-10 23:22:15 --> Helper loaded: url_helper
DEBUG - 2016-12-10 23:22:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-10 23:22:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-10 23:22:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-10 23:22:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-10 23:22:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-10 23:22:15 --> Final output sent to browser
DEBUG - 2016-12-10 23:22:15 --> Total execution time: 0.0269

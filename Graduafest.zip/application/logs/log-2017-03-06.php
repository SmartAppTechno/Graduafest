<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-06 00:20:00 --> Config Class Initialized
INFO - 2017-03-06 00:20:00 --> Hooks Class Initialized
DEBUG - 2017-03-06 00:20:00 --> UTF-8 Support Enabled
INFO - 2017-03-06 00:20:00 --> Utf8 Class Initialized
INFO - 2017-03-06 00:20:00 --> URI Class Initialized
INFO - 2017-03-06 00:20:00 --> Router Class Initialized
INFO - 2017-03-06 00:20:00 --> Output Class Initialized
INFO - 2017-03-06 00:20:00 --> Security Class Initialized
DEBUG - 2017-03-06 00:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 00:20:00 --> Input Class Initialized
INFO - 2017-03-06 00:20:00 --> Language Class Initialized
INFO - 2017-03-06 00:20:00 --> Loader Class Initialized
INFO - 2017-03-06 00:20:01 --> Database Driver Class Initialized
INFO - 2017-03-06 00:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 00:20:01 --> Controller Class Initialized
INFO - 2017-03-06 00:20:01 --> Helper loaded: url_helper
DEBUG - 2017-03-06 00:20:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 00:20:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-06 00:20:01 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-06 00:20:01 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-06 00:20:01 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-06 00:20:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 00:20:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 00:20:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 00:20:01 --> Final output sent to browser
DEBUG - 2017-03-06 00:20:01 --> Total execution time: 2.0425
INFO - 2017-03-06 00:44:31 --> Config Class Initialized
INFO - 2017-03-06 00:44:31 --> Hooks Class Initialized
DEBUG - 2017-03-06 00:44:31 --> UTF-8 Support Enabled
INFO - 2017-03-06 00:44:31 --> Utf8 Class Initialized
INFO - 2017-03-06 00:44:31 --> URI Class Initialized
DEBUG - 2017-03-06 00:44:31 --> No URI present. Default controller set.
INFO - 2017-03-06 00:44:31 --> Router Class Initialized
INFO - 2017-03-06 00:44:31 --> Output Class Initialized
INFO - 2017-03-06 00:44:31 --> Security Class Initialized
DEBUG - 2017-03-06 00:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 00:44:32 --> Input Class Initialized
INFO - 2017-03-06 00:44:32 --> Language Class Initialized
INFO - 2017-03-06 00:44:32 --> Loader Class Initialized
INFO - 2017-03-06 00:44:32 --> Database Driver Class Initialized
INFO - 2017-03-06 00:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 00:44:32 --> Controller Class Initialized
INFO - 2017-03-06 00:44:32 --> Helper loaded: url_helper
DEBUG - 2017-03-06 00:44:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 00:44:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 00:44:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 00:44:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 00:44:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 00:44:32 --> Final output sent to browser
DEBUG - 2017-03-06 00:44:32 --> Total execution time: 1.5010
INFO - 2017-03-06 00:44:51 --> Config Class Initialized
INFO - 2017-03-06 00:44:51 --> Hooks Class Initialized
DEBUG - 2017-03-06 00:44:51 --> UTF-8 Support Enabled
INFO - 2017-03-06 00:44:51 --> Utf8 Class Initialized
INFO - 2017-03-06 00:44:51 --> URI Class Initialized
INFO - 2017-03-06 00:44:52 --> Router Class Initialized
INFO - 2017-03-06 00:44:52 --> Output Class Initialized
INFO - 2017-03-06 00:44:52 --> Security Class Initialized
DEBUG - 2017-03-06 00:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 00:44:52 --> Input Class Initialized
INFO - 2017-03-06 00:44:52 --> Language Class Initialized
INFO - 2017-03-06 00:44:52 --> Loader Class Initialized
INFO - 2017-03-06 00:44:52 --> Database Driver Class Initialized
INFO - 2017-03-06 00:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 00:44:52 --> Controller Class Initialized
INFO - 2017-03-06 00:44:52 --> Helper loaded: url_helper
DEBUG - 2017-03-06 00:44:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 00:44:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 00:44:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 00:44:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 00:44:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 00:44:53 --> Final output sent to browser
DEBUG - 2017-03-06 00:44:53 --> Total execution time: 1.5070
INFO - 2017-03-06 01:49:27 --> Config Class Initialized
INFO - 2017-03-06 01:49:27 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:49:27 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:49:27 --> Utf8 Class Initialized
INFO - 2017-03-06 01:49:27 --> URI Class Initialized
DEBUG - 2017-03-06 01:49:27 --> No URI present. Default controller set.
INFO - 2017-03-06 01:49:27 --> Router Class Initialized
INFO - 2017-03-06 01:49:27 --> Output Class Initialized
INFO - 2017-03-06 01:49:27 --> Security Class Initialized
DEBUG - 2017-03-06 01:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:49:28 --> Input Class Initialized
INFO - 2017-03-06 01:49:28 --> Language Class Initialized
INFO - 2017-03-06 01:49:28 --> Loader Class Initialized
INFO - 2017-03-06 01:49:28 --> Database Driver Class Initialized
INFO - 2017-03-06 01:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:49:28 --> Controller Class Initialized
INFO - 2017-03-06 01:49:28 --> Helper loaded: url_helper
DEBUG - 2017-03-06 01:49:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 01:49:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 01:49:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 01:49:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 01:49:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 01:49:29 --> Final output sent to browser
DEBUG - 2017-03-06 01:49:29 --> Total execution time: 1.9426
INFO - 2017-03-06 01:49:38 --> Config Class Initialized
INFO - 2017-03-06 01:49:38 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:49:38 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:49:38 --> Utf8 Class Initialized
INFO - 2017-03-06 01:49:38 --> URI Class Initialized
INFO - 2017-03-06 01:49:38 --> Router Class Initialized
INFO - 2017-03-06 01:49:38 --> Output Class Initialized
INFO - 2017-03-06 01:49:38 --> Security Class Initialized
DEBUG - 2017-03-06 01:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:49:38 --> Input Class Initialized
INFO - 2017-03-06 01:49:38 --> Language Class Initialized
INFO - 2017-03-06 01:49:38 --> Loader Class Initialized
INFO - 2017-03-06 01:49:39 --> Database Driver Class Initialized
INFO - 2017-03-06 01:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:49:39 --> Controller Class Initialized
INFO - 2017-03-06 01:49:39 --> Helper loaded: url_helper
DEBUG - 2017-03-06 01:49:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 01:49:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 01:49:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 01:49:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 01:49:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 01:49:39 --> Final output sent to browser
DEBUG - 2017-03-06 01:49:39 --> Total execution time: 1.2256
INFO - 2017-03-06 01:49:55 --> Config Class Initialized
INFO - 2017-03-06 01:49:55 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:49:55 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:49:55 --> Utf8 Class Initialized
INFO - 2017-03-06 01:49:55 --> URI Class Initialized
INFO - 2017-03-06 01:49:55 --> Router Class Initialized
INFO - 2017-03-06 01:49:55 --> Output Class Initialized
INFO - 2017-03-06 01:49:55 --> Security Class Initialized
DEBUG - 2017-03-06 01:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:49:55 --> Input Class Initialized
INFO - 2017-03-06 01:49:55 --> Language Class Initialized
INFO - 2017-03-06 01:49:55 --> Loader Class Initialized
INFO - 2017-03-06 01:49:56 --> Database Driver Class Initialized
INFO - 2017-03-06 01:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:49:56 --> Controller Class Initialized
INFO - 2017-03-06 01:49:56 --> Helper loaded: url_helper
DEBUG - 2017-03-06 01:49:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 01:50:01 --> Config Class Initialized
INFO - 2017-03-06 01:50:01 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:50:01 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:50:01 --> Utf8 Class Initialized
INFO - 2017-03-06 01:50:01 --> URI Class Initialized
INFO - 2017-03-06 01:50:02 --> Router Class Initialized
INFO - 2017-03-06 01:50:02 --> Output Class Initialized
INFO - 2017-03-06 01:50:02 --> Security Class Initialized
DEBUG - 2017-03-06 01:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:50:02 --> Input Class Initialized
INFO - 2017-03-06 01:50:02 --> Language Class Initialized
INFO - 2017-03-06 01:50:02 --> Loader Class Initialized
INFO - 2017-03-06 01:50:02 --> Database Driver Class Initialized
INFO - 2017-03-06 01:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:50:02 --> Controller Class Initialized
INFO - 2017-03-06 01:50:02 --> Helper loaded: date_helper
DEBUG - 2017-03-06 01:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 01:50:02 --> Helper loaded: url_helper
INFO - 2017-03-06 01:50:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 01:50:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-06 01:50:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-06 01:50:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-06 01:50:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 01:50:02 --> Final output sent to browser
DEBUG - 2017-03-06 01:50:02 --> Total execution time: 1.1215
INFO - 2017-03-06 01:50:06 --> Config Class Initialized
INFO - 2017-03-06 01:50:06 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:50:06 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:50:06 --> Utf8 Class Initialized
INFO - 2017-03-06 01:50:06 --> URI Class Initialized
INFO - 2017-03-06 01:50:06 --> Router Class Initialized
INFO - 2017-03-06 01:50:06 --> Output Class Initialized
INFO - 2017-03-06 01:50:06 --> Security Class Initialized
DEBUG - 2017-03-06 01:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:50:06 --> Input Class Initialized
INFO - 2017-03-06 01:50:06 --> Language Class Initialized
INFO - 2017-03-06 01:50:06 --> Loader Class Initialized
INFO - 2017-03-06 01:50:06 --> Database Driver Class Initialized
INFO - 2017-03-06 01:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:50:06 --> Controller Class Initialized
INFO - 2017-03-06 01:50:06 --> Helper loaded: url_helper
DEBUG - 2017-03-06 01:50:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 01:50:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 01:50:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 01:50:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 01:50:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 01:50:07 --> Final output sent to browser
DEBUG - 2017-03-06 01:50:07 --> Total execution time: 0.3718
INFO - 2017-03-06 01:50:11 --> Config Class Initialized
INFO - 2017-03-06 01:50:11 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:50:11 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:50:11 --> Utf8 Class Initialized
INFO - 2017-03-06 01:50:11 --> URI Class Initialized
DEBUG - 2017-03-06 01:50:11 --> No URI present. Default controller set.
INFO - 2017-03-06 01:50:11 --> Router Class Initialized
INFO - 2017-03-06 01:50:11 --> Output Class Initialized
INFO - 2017-03-06 01:50:11 --> Security Class Initialized
DEBUG - 2017-03-06 01:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:50:11 --> Input Class Initialized
INFO - 2017-03-06 01:50:11 --> Language Class Initialized
INFO - 2017-03-06 01:50:11 --> Loader Class Initialized
INFO - 2017-03-06 01:50:11 --> Database Driver Class Initialized
INFO - 2017-03-06 01:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:50:11 --> Controller Class Initialized
INFO - 2017-03-06 01:50:11 --> Helper loaded: url_helper
DEBUG - 2017-03-06 01:50:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 01:50:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 01:50:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 01:50:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 01:50:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 01:50:11 --> Final output sent to browser
DEBUG - 2017-03-06 01:50:11 --> Total execution time: 0.0622
INFO - 2017-03-06 01:50:13 --> Config Class Initialized
INFO - 2017-03-06 01:50:13 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:50:13 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:50:13 --> Utf8 Class Initialized
INFO - 2017-03-06 01:50:13 --> URI Class Initialized
INFO - 2017-03-06 01:50:13 --> Router Class Initialized
INFO - 2017-03-06 01:50:13 --> Output Class Initialized
INFO - 2017-03-06 01:50:13 --> Security Class Initialized
DEBUG - 2017-03-06 01:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:50:13 --> Input Class Initialized
INFO - 2017-03-06 01:50:13 --> Language Class Initialized
INFO - 2017-03-06 01:50:13 --> Loader Class Initialized
INFO - 2017-03-06 01:50:13 --> Database Driver Class Initialized
INFO - 2017-03-06 01:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:50:13 --> Controller Class Initialized
INFO - 2017-03-06 01:50:13 --> Helper loaded: url_helper
DEBUG - 2017-03-06 01:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 01:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 01:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 01:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 01:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 01:50:13 --> Final output sent to browser
DEBUG - 2017-03-06 01:50:13 --> Total execution time: 0.7680
INFO - 2017-03-06 02:29:46 --> Config Class Initialized
INFO - 2017-03-06 02:29:46 --> Hooks Class Initialized
DEBUG - 2017-03-06 02:29:46 --> UTF-8 Support Enabled
INFO - 2017-03-06 02:29:46 --> Utf8 Class Initialized
INFO - 2017-03-06 02:29:46 --> URI Class Initialized
DEBUG - 2017-03-06 02:29:46 --> No URI present. Default controller set.
INFO - 2017-03-06 02:29:46 --> Router Class Initialized
INFO - 2017-03-06 02:29:46 --> Output Class Initialized
INFO - 2017-03-06 02:29:46 --> Security Class Initialized
DEBUG - 2017-03-06 02:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 02:29:46 --> Input Class Initialized
INFO - 2017-03-06 02:29:46 --> Language Class Initialized
INFO - 2017-03-06 02:29:46 --> Loader Class Initialized
INFO - 2017-03-06 02:29:46 --> Database Driver Class Initialized
INFO - 2017-03-06 02:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 02:29:47 --> Controller Class Initialized
INFO - 2017-03-06 02:29:47 --> Helper loaded: url_helper
DEBUG - 2017-03-06 02:29:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 02:29:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 02:29:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 02:29:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 02:29:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 02:29:47 --> Final output sent to browser
DEBUG - 2017-03-06 02:29:47 --> Total execution time: 2.0149
INFO - 2017-03-06 04:18:19 --> Config Class Initialized
INFO - 2017-03-06 04:18:19 --> Hooks Class Initialized
DEBUG - 2017-03-06 04:18:19 --> UTF-8 Support Enabled
INFO - 2017-03-06 04:18:19 --> Utf8 Class Initialized
INFO - 2017-03-06 04:18:19 --> URI Class Initialized
DEBUG - 2017-03-06 04:18:20 --> No URI present. Default controller set.
INFO - 2017-03-06 04:18:20 --> Router Class Initialized
INFO - 2017-03-06 04:18:20 --> Output Class Initialized
INFO - 2017-03-06 04:18:20 --> Security Class Initialized
DEBUG - 2017-03-06 04:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 04:18:20 --> Input Class Initialized
INFO - 2017-03-06 04:18:20 --> Language Class Initialized
INFO - 2017-03-06 04:18:20 --> Loader Class Initialized
INFO - 2017-03-06 04:18:20 --> Database Driver Class Initialized
INFO - 2017-03-06 04:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 04:18:20 --> Controller Class Initialized
INFO - 2017-03-06 04:18:20 --> Helper loaded: url_helper
DEBUG - 2017-03-06 04:18:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 04:18:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 04:18:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 04:18:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 04:18:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 04:18:21 --> Final output sent to browser
DEBUG - 2017-03-06 04:18:21 --> Total execution time: 1.7377
INFO - 2017-03-06 04:18:26 --> Config Class Initialized
INFO - 2017-03-06 04:18:26 --> Hooks Class Initialized
DEBUG - 2017-03-06 04:18:26 --> UTF-8 Support Enabled
INFO - 2017-03-06 04:18:26 --> Utf8 Class Initialized
INFO - 2017-03-06 04:18:26 --> URI Class Initialized
INFO - 2017-03-06 04:18:26 --> Router Class Initialized
INFO - 2017-03-06 04:18:26 --> Output Class Initialized
INFO - 2017-03-06 04:18:26 --> Security Class Initialized
DEBUG - 2017-03-06 04:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 04:18:26 --> Input Class Initialized
INFO - 2017-03-06 04:18:26 --> Language Class Initialized
INFO - 2017-03-06 04:18:26 --> Loader Class Initialized
INFO - 2017-03-06 04:18:26 --> Database Driver Class Initialized
INFO - 2017-03-06 04:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 04:18:26 --> Controller Class Initialized
INFO - 2017-03-06 04:18:26 --> Helper loaded: url_helper
DEBUG - 2017-03-06 04:18:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 04:18:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 04:18:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 04:18:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 04:18:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 04:18:26 --> Final output sent to browser
DEBUG - 2017-03-06 04:18:26 --> Total execution time: 0.0143
INFO - 2017-03-06 04:22:30 --> Config Class Initialized
INFO - 2017-03-06 04:22:30 --> Hooks Class Initialized
DEBUG - 2017-03-06 04:22:30 --> UTF-8 Support Enabled
INFO - 2017-03-06 04:22:30 --> Utf8 Class Initialized
INFO - 2017-03-06 04:22:30 --> URI Class Initialized
DEBUG - 2017-03-06 04:22:30 --> No URI present. Default controller set.
INFO - 2017-03-06 04:22:30 --> Router Class Initialized
INFO - 2017-03-06 04:22:30 --> Output Class Initialized
INFO - 2017-03-06 04:22:30 --> Security Class Initialized
DEBUG - 2017-03-06 04:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 04:22:30 --> Input Class Initialized
INFO - 2017-03-06 04:22:30 --> Language Class Initialized
INFO - 2017-03-06 04:22:30 --> Loader Class Initialized
INFO - 2017-03-06 04:22:30 --> Database Driver Class Initialized
INFO - 2017-03-06 04:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 04:22:31 --> Controller Class Initialized
INFO - 2017-03-06 04:22:31 --> Helper loaded: url_helper
DEBUG - 2017-03-06 04:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 04:22:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 04:22:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 04:22:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 04:22:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 04:22:31 --> Final output sent to browser
DEBUG - 2017-03-06 04:22:31 --> Total execution time: 1.4676
INFO - 2017-03-06 04:22:34 --> Config Class Initialized
INFO - 2017-03-06 04:22:34 --> Hooks Class Initialized
DEBUG - 2017-03-06 04:22:34 --> UTF-8 Support Enabled
INFO - 2017-03-06 04:22:34 --> Utf8 Class Initialized
INFO - 2017-03-06 04:22:34 --> URI Class Initialized
INFO - 2017-03-06 04:22:34 --> Router Class Initialized
INFO - 2017-03-06 04:22:34 --> Output Class Initialized
INFO - 2017-03-06 04:22:34 --> Security Class Initialized
DEBUG - 2017-03-06 04:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 04:22:34 --> Input Class Initialized
INFO - 2017-03-06 04:22:34 --> Language Class Initialized
INFO - 2017-03-06 04:22:34 --> Loader Class Initialized
INFO - 2017-03-06 04:22:34 --> Database Driver Class Initialized
INFO - 2017-03-06 04:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 04:22:34 --> Controller Class Initialized
INFO - 2017-03-06 04:22:34 --> Helper loaded: url_helper
DEBUG - 2017-03-06 04:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 04:22:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 04:22:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 04:22:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 04:22:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 04:22:34 --> Final output sent to browser
DEBUG - 2017-03-06 04:22:34 --> Total execution time: 0.0140
INFO - 2017-03-06 05:45:30 --> Config Class Initialized
INFO - 2017-03-06 05:45:30 --> Hooks Class Initialized
DEBUG - 2017-03-06 05:45:31 --> UTF-8 Support Enabled
INFO - 2017-03-06 05:45:31 --> Utf8 Class Initialized
INFO - 2017-03-06 05:45:31 --> URI Class Initialized
DEBUG - 2017-03-06 05:45:31 --> No URI present. Default controller set.
INFO - 2017-03-06 05:45:31 --> Router Class Initialized
INFO - 2017-03-06 05:45:31 --> Output Class Initialized
INFO - 2017-03-06 05:45:31 --> Security Class Initialized
DEBUG - 2017-03-06 05:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 05:45:31 --> Input Class Initialized
INFO - 2017-03-06 05:45:31 --> Language Class Initialized
INFO - 2017-03-06 05:45:31 --> Loader Class Initialized
INFO - 2017-03-06 05:45:31 --> Database Driver Class Initialized
INFO - 2017-03-06 05:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 05:45:32 --> Controller Class Initialized
INFO - 2017-03-06 05:45:32 --> Helper loaded: url_helper
DEBUG - 2017-03-06 05:45:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 05:45:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 05:45:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 05:45:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 05:45:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 05:45:32 --> Final output sent to browser
DEBUG - 2017-03-06 05:45:32 --> Total execution time: 1.9292
INFO - 2017-03-06 05:47:51 --> Config Class Initialized
INFO - 2017-03-06 05:47:51 --> Hooks Class Initialized
DEBUG - 2017-03-06 05:47:52 --> UTF-8 Support Enabled
INFO - 2017-03-06 05:47:52 --> Utf8 Class Initialized
INFO - 2017-03-06 05:47:52 --> URI Class Initialized
DEBUG - 2017-03-06 05:47:52 --> No URI present. Default controller set.
INFO - 2017-03-06 05:47:52 --> Router Class Initialized
INFO - 2017-03-06 05:47:52 --> Output Class Initialized
INFO - 2017-03-06 05:47:52 --> Security Class Initialized
DEBUG - 2017-03-06 05:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 05:47:52 --> Input Class Initialized
INFO - 2017-03-06 05:47:52 --> Language Class Initialized
INFO - 2017-03-06 05:47:52 --> Loader Class Initialized
INFO - 2017-03-06 05:47:52 --> Database Driver Class Initialized
INFO - 2017-03-06 05:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 05:47:52 --> Controller Class Initialized
INFO - 2017-03-06 05:47:52 --> Helper loaded: url_helper
DEBUG - 2017-03-06 05:47:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 05:47:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 05:47:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 05:47:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 05:47:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 05:47:53 --> Final output sent to browser
DEBUG - 2017-03-06 05:47:53 --> Total execution time: 1.5448
INFO - 2017-03-06 05:48:01 --> Config Class Initialized
INFO - 2017-03-06 05:48:01 --> Hooks Class Initialized
DEBUG - 2017-03-06 05:48:01 --> UTF-8 Support Enabled
INFO - 2017-03-06 05:48:01 --> Utf8 Class Initialized
INFO - 2017-03-06 05:48:01 --> URI Class Initialized
INFO - 2017-03-06 05:48:01 --> Router Class Initialized
INFO - 2017-03-06 05:48:01 --> Output Class Initialized
INFO - 2017-03-06 05:48:01 --> Security Class Initialized
DEBUG - 2017-03-06 05:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 05:48:01 --> Input Class Initialized
INFO - 2017-03-06 05:48:01 --> Language Class Initialized
INFO - 2017-03-06 05:48:01 --> Loader Class Initialized
INFO - 2017-03-06 05:48:02 --> Database Driver Class Initialized
INFO - 2017-03-06 05:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 05:48:02 --> Controller Class Initialized
INFO - 2017-03-06 05:48:02 --> Helper loaded: url_helper
DEBUG - 2017-03-06 05:48:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 05:48:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 05:48:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 05:48:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 05:48:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 05:48:02 --> Final output sent to browser
DEBUG - 2017-03-06 05:48:02 --> Total execution time: 1.8132
INFO - 2017-03-06 05:48:56 --> Config Class Initialized
INFO - 2017-03-06 05:48:56 --> Hooks Class Initialized
DEBUG - 2017-03-06 05:48:56 --> UTF-8 Support Enabled
INFO - 2017-03-06 05:48:56 --> Utf8 Class Initialized
INFO - 2017-03-06 05:48:56 --> URI Class Initialized
INFO - 2017-03-06 05:48:56 --> Router Class Initialized
INFO - 2017-03-06 05:48:56 --> Output Class Initialized
INFO - 2017-03-06 05:48:56 --> Security Class Initialized
DEBUG - 2017-03-06 05:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 05:48:56 --> Input Class Initialized
INFO - 2017-03-06 05:48:56 --> Language Class Initialized
INFO - 2017-03-06 05:48:56 --> Loader Class Initialized
INFO - 2017-03-06 05:48:57 --> Database Driver Class Initialized
INFO - 2017-03-06 05:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 05:48:57 --> Controller Class Initialized
INFO - 2017-03-06 05:48:57 --> Helper loaded: url_helper
DEBUG - 2017-03-06 05:48:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-06 05:48:59 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-06 05:48:59 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Dulce Maria Aguilar')
INFO - 2017-03-06 05:48:59 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-06 05:48:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-06 05:49:00 --> Config Class Initialized
INFO - 2017-03-06 05:49:00 --> Hooks Class Initialized
DEBUG - 2017-03-06 05:49:00 --> UTF-8 Support Enabled
INFO - 2017-03-06 05:49:00 --> Utf8 Class Initialized
INFO - 2017-03-06 05:49:00 --> URI Class Initialized
INFO - 2017-03-06 05:49:00 --> Router Class Initialized
INFO - 2017-03-06 05:49:00 --> Output Class Initialized
INFO - 2017-03-06 05:49:00 --> Security Class Initialized
DEBUG - 2017-03-06 05:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 05:49:00 --> Input Class Initialized
INFO - 2017-03-06 05:49:00 --> Language Class Initialized
INFO - 2017-03-06 05:49:00 --> Loader Class Initialized
INFO - 2017-03-06 05:49:00 --> Database Driver Class Initialized
INFO - 2017-03-06 05:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 05:49:00 --> Controller Class Initialized
INFO - 2017-03-06 05:49:00 --> Helper loaded: url_helper
DEBUG - 2017-03-06 05:49:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 05:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 05:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 05:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 05:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 05:49:00 --> Final output sent to browser
DEBUG - 2017-03-06 05:49:00 --> Total execution time: 0.1645
INFO - 2017-03-06 05:49:09 --> Config Class Initialized
INFO - 2017-03-06 05:49:09 --> Hooks Class Initialized
DEBUG - 2017-03-06 05:49:09 --> UTF-8 Support Enabled
INFO - 2017-03-06 05:49:09 --> Utf8 Class Initialized
INFO - 2017-03-06 05:49:09 --> URI Class Initialized
INFO - 2017-03-06 05:49:09 --> Router Class Initialized
INFO - 2017-03-06 05:49:09 --> Output Class Initialized
INFO - 2017-03-06 05:49:09 --> Security Class Initialized
DEBUG - 2017-03-06 05:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 05:49:09 --> Input Class Initialized
INFO - 2017-03-06 05:49:09 --> Language Class Initialized
INFO - 2017-03-06 05:49:09 --> Loader Class Initialized
INFO - 2017-03-06 05:49:09 --> Database Driver Class Initialized
INFO - 2017-03-06 05:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 05:49:09 --> Controller Class Initialized
INFO - 2017-03-06 05:49:09 --> Helper loaded: url_helper
DEBUG - 2017-03-06 05:49:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-06 05:49:09 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-06 05:49:09 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Dulce Maria Aguilar')
INFO - 2017-03-06 05:49:09 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-06 05:49:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-06 05:49:10 --> Config Class Initialized
INFO - 2017-03-06 05:49:10 --> Hooks Class Initialized
DEBUG - 2017-03-06 05:49:10 --> UTF-8 Support Enabled
INFO - 2017-03-06 05:49:10 --> Utf8 Class Initialized
INFO - 2017-03-06 05:49:10 --> URI Class Initialized
INFO - 2017-03-06 05:49:10 --> Router Class Initialized
INFO - 2017-03-06 05:49:10 --> Output Class Initialized
INFO - 2017-03-06 05:49:10 --> Security Class Initialized
DEBUG - 2017-03-06 05:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 05:49:10 --> Input Class Initialized
INFO - 2017-03-06 05:49:10 --> Language Class Initialized
INFO - 2017-03-06 05:49:10 --> Loader Class Initialized
INFO - 2017-03-06 05:49:10 --> Database Driver Class Initialized
INFO - 2017-03-06 05:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 05:49:10 --> Controller Class Initialized
INFO - 2017-03-06 05:49:10 --> Helper loaded: url_helper
DEBUG - 2017-03-06 05:49:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 05:49:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 05:49:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 05:49:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 05:49:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 05:49:10 --> Final output sent to browser
DEBUG - 2017-03-06 05:49:10 --> Total execution time: 0.0137
INFO - 2017-03-06 05:50:55 --> Config Class Initialized
INFO - 2017-03-06 05:50:55 --> Hooks Class Initialized
DEBUG - 2017-03-06 05:50:55 --> UTF-8 Support Enabled
INFO - 2017-03-06 05:50:55 --> Utf8 Class Initialized
INFO - 2017-03-06 05:50:55 --> URI Class Initialized
DEBUG - 2017-03-06 05:50:55 --> No URI present. Default controller set.
INFO - 2017-03-06 05:50:55 --> Router Class Initialized
INFO - 2017-03-06 05:50:55 --> Output Class Initialized
INFO - 2017-03-06 05:50:55 --> Security Class Initialized
DEBUG - 2017-03-06 05:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 05:50:56 --> Input Class Initialized
INFO - 2017-03-06 05:50:56 --> Language Class Initialized
INFO - 2017-03-06 05:50:56 --> Loader Class Initialized
INFO - 2017-03-06 05:50:56 --> Database Driver Class Initialized
INFO - 2017-03-06 05:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 05:50:56 --> Controller Class Initialized
INFO - 2017-03-06 05:50:56 --> Helper loaded: url_helper
DEBUG - 2017-03-06 05:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 05:50:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 05:50:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 05:50:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 05:50:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 05:50:57 --> Final output sent to browser
DEBUG - 2017-03-06 05:50:57 --> Total execution time: 1.7793
INFO - 2017-03-06 05:51:00 --> Config Class Initialized
INFO - 2017-03-06 05:51:00 --> Hooks Class Initialized
DEBUG - 2017-03-06 05:51:00 --> UTF-8 Support Enabled
INFO - 2017-03-06 05:51:00 --> Utf8 Class Initialized
INFO - 2017-03-06 05:51:00 --> URI Class Initialized
INFO - 2017-03-06 05:51:00 --> Router Class Initialized
INFO - 2017-03-06 05:51:00 --> Output Class Initialized
INFO - 2017-03-06 05:51:00 --> Security Class Initialized
DEBUG - 2017-03-06 05:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 05:51:00 --> Input Class Initialized
INFO - 2017-03-06 05:51:00 --> Language Class Initialized
INFO - 2017-03-06 05:51:00 --> Loader Class Initialized
INFO - 2017-03-06 05:51:00 --> Database Driver Class Initialized
INFO - 2017-03-06 05:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 05:51:00 --> Controller Class Initialized
INFO - 2017-03-06 05:51:00 --> Helper loaded: url_helper
DEBUG - 2017-03-06 05:51:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 05:51:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 05:51:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 05:51:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 05:51:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 05:51:01 --> Final output sent to browser
DEBUG - 2017-03-06 05:51:01 --> Total execution time: 1.2107
INFO - 2017-03-06 05:51:12 --> Config Class Initialized
INFO - 2017-03-06 05:51:12 --> Hooks Class Initialized
DEBUG - 2017-03-06 05:51:12 --> UTF-8 Support Enabled
INFO - 2017-03-06 05:51:12 --> Utf8 Class Initialized
INFO - 2017-03-06 05:51:12 --> URI Class Initialized
INFO - 2017-03-06 05:51:12 --> Router Class Initialized
INFO - 2017-03-06 05:51:12 --> Output Class Initialized
INFO - 2017-03-06 05:51:12 --> Security Class Initialized
DEBUG - 2017-03-06 05:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 05:51:12 --> Input Class Initialized
INFO - 2017-03-06 05:51:12 --> Language Class Initialized
INFO - 2017-03-06 05:51:12 --> Loader Class Initialized
INFO - 2017-03-06 05:51:13 --> Database Driver Class Initialized
INFO - 2017-03-06 05:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 05:51:13 --> Controller Class Initialized
INFO - 2017-03-06 05:51:13 --> Helper loaded: url_helper
DEBUG - 2017-03-06 05:51:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-06 05:51:14 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-06 05:51:14 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Dulce Maria Aguilar')
INFO - 2017-03-06 05:51:14 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-06 05:51:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-06 05:51:15 --> Config Class Initialized
INFO - 2017-03-06 05:51:15 --> Hooks Class Initialized
DEBUG - 2017-03-06 05:51:15 --> UTF-8 Support Enabled
INFO - 2017-03-06 05:51:15 --> Utf8 Class Initialized
INFO - 2017-03-06 05:51:15 --> URI Class Initialized
INFO - 2017-03-06 05:51:15 --> Router Class Initialized
INFO - 2017-03-06 05:51:15 --> Output Class Initialized
INFO - 2017-03-06 05:51:15 --> Security Class Initialized
DEBUG - 2017-03-06 05:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 05:51:15 --> Input Class Initialized
INFO - 2017-03-06 05:51:15 --> Language Class Initialized
INFO - 2017-03-06 05:51:15 --> Loader Class Initialized
INFO - 2017-03-06 05:51:15 --> Database Driver Class Initialized
INFO - 2017-03-06 05:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 05:51:15 --> Controller Class Initialized
INFO - 2017-03-06 05:51:15 --> Helper loaded: url_helper
DEBUG - 2017-03-06 05:51:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 05:51:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 05:51:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 05:51:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 05:51:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 05:51:15 --> Final output sent to browser
DEBUG - 2017-03-06 05:51:15 --> Total execution time: 0.1654
INFO - 2017-03-06 05:51:19 --> Config Class Initialized
INFO - 2017-03-06 05:51:19 --> Hooks Class Initialized
DEBUG - 2017-03-06 05:51:19 --> UTF-8 Support Enabled
INFO - 2017-03-06 05:51:19 --> Utf8 Class Initialized
INFO - 2017-03-06 05:51:19 --> URI Class Initialized
DEBUG - 2017-03-06 05:51:19 --> No URI present. Default controller set.
INFO - 2017-03-06 05:51:19 --> Router Class Initialized
INFO - 2017-03-06 05:51:19 --> Output Class Initialized
INFO - 2017-03-06 05:51:19 --> Security Class Initialized
DEBUG - 2017-03-06 05:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 05:51:19 --> Input Class Initialized
INFO - 2017-03-06 05:51:19 --> Language Class Initialized
INFO - 2017-03-06 05:51:19 --> Loader Class Initialized
INFO - 2017-03-06 05:51:19 --> Database Driver Class Initialized
INFO - 2017-03-06 05:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 05:51:19 --> Controller Class Initialized
INFO - 2017-03-06 05:51:19 --> Helper loaded: url_helper
DEBUG - 2017-03-06 05:51:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 05:51:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 05:51:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 05:51:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 05:51:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 05:51:19 --> Final output sent to browser
DEBUG - 2017-03-06 05:51:19 --> Total execution time: 0.1891
INFO - 2017-03-06 05:51:23 --> Config Class Initialized
INFO - 2017-03-06 05:51:23 --> Hooks Class Initialized
DEBUG - 2017-03-06 05:51:23 --> UTF-8 Support Enabled
INFO - 2017-03-06 05:51:23 --> Utf8 Class Initialized
INFO - 2017-03-06 05:51:23 --> URI Class Initialized
INFO - 2017-03-06 05:51:23 --> Router Class Initialized
INFO - 2017-03-06 05:51:23 --> Output Class Initialized
INFO - 2017-03-06 05:51:23 --> Security Class Initialized
DEBUG - 2017-03-06 05:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 05:51:24 --> Input Class Initialized
INFO - 2017-03-06 05:51:24 --> Language Class Initialized
INFO - 2017-03-06 05:51:24 --> Loader Class Initialized
INFO - 2017-03-06 05:51:24 --> Database Driver Class Initialized
INFO - 2017-03-06 05:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 05:51:24 --> Controller Class Initialized
INFO - 2017-03-06 05:51:24 --> Helper loaded: url_helper
DEBUG - 2017-03-06 05:51:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 05:51:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 05:51:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 05:51:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 05:51:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 05:51:24 --> Final output sent to browser
DEBUG - 2017-03-06 05:51:24 --> Total execution time: 1.2161
INFO - 2017-03-06 05:52:18 --> Config Class Initialized
INFO - 2017-03-06 05:52:18 --> Hooks Class Initialized
DEBUG - 2017-03-06 05:52:18 --> UTF-8 Support Enabled
INFO - 2017-03-06 05:52:18 --> Utf8 Class Initialized
INFO - 2017-03-06 05:52:18 --> URI Class Initialized
INFO - 2017-03-06 05:52:18 --> Router Class Initialized
INFO - 2017-03-06 05:52:18 --> Output Class Initialized
INFO - 2017-03-06 05:52:18 --> Security Class Initialized
DEBUG - 2017-03-06 05:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 05:52:18 --> Input Class Initialized
INFO - 2017-03-06 05:52:18 --> Language Class Initialized
INFO - 2017-03-06 05:52:18 --> Loader Class Initialized
INFO - 2017-03-06 05:52:19 --> Database Driver Class Initialized
INFO - 2017-03-06 05:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 05:52:19 --> Controller Class Initialized
INFO - 2017-03-06 05:52:19 --> Helper loaded: url_helper
DEBUG - 2017-03-06 05:52:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 05:52:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 05:52:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 05:52:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 05:52:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 05:52:19 --> Final output sent to browser
DEBUG - 2017-03-06 05:52:19 --> Total execution time: 1.5259
INFO - 2017-03-06 05:52:26 --> Config Class Initialized
INFO - 2017-03-06 05:52:26 --> Hooks Class Initialized
DEBUG - 2017-03-06 05:52:26 --> UTF-8 Support Enabled
INFO - 2017-03-06 05:52:26 --> Utf8 Class Initialized
INFO - 2017-03-06 05:52:26 --> URI Class Initialized
INFO - 2017-03-06 05:52:26 --> Router Class Initialized
INFO - 2017-03-06 05:52:26 --> Output Class Initialized
INFO - 2017-03-06 05:52:26 --> Security Class Initialized
DEBUG - 2017-03-06 05:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 05:52:26 --> Input Class Initialized
INFO - 2017-03-06 05:52:26 --> Language Class Initialized
INFO - 2017-03-06 05:52:26 --> Loader Class Initialized
INFO - 2017-03-06 05:52:27 --> Database Driver Class Initialized
INFO - 2017-03-06 05:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 05:52:27 --> Controller Class Initialized
INFO - 2017-03-06 05:52:27 --> Helper loaded: url_helper
DEBUG - 2017-03-06 05:52:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 05:52:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 05:52:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 05:52:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 05:52:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 05:52:27 --> Final output sent to browser
DEBUG - 2017-03-06 05:52:27 --> Total execution time: 1.4809
INFO - 2017-03-06 05:52:32 --> Config Class Initialized
INFO - 2017-03-06 05:52:32 --> Hooks Class Initialized
DEBUG - 2017-03-06 05:52:32 --> UTF-8 Support Enabled
INFO - 2017-03-06 05:52:32 --> Utf8 Class Initialized
INFO - 2017-03-06 05:52:32 --> URI Class Initialized
INFO - 2017-03-06 05:52:32 --> Router Class Initialized
INFO - 2017-03-06 05:52:32 --> Output Class Initialized
INFO - 2017-03-06 05:52:32 --> Security Class Initialized
DEBUG - 2017-03-06 05:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 05:52:33 --> Input Class Initialized
INFO - 2017-03-06 05:52:33 --> Language Class Initialized
INFO - 2017-03-06 05:52:33 --> Loader Class Initialized
INFO - 2017-03-06 05:52:33 --> Database Driver Class Initialized
INFO - 2017-03-06 05:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 05:52:33 --> Controller Class Initialized
INFO - 2017-03-06 05:52:33 --> Helper loaded: url_helper
DEBUG - 2017-03-06 05:52:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-06 05:52:35 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-06 05:52:35 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Dulce Maria Aguilar')
INFO - 2017-03-06 05:52:35 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-06 05:52:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-06 05:52:41 --> Config Class Initialized
INFO - 2017-03-06 05:52:41 --> Hooks Class Initialized
DEBUG - 2017-03-06 05:52:41 --> UTF-8 Support Enabled
INFO - 2017-03-06 05:52:41 --> Utf8 Class Initialized
INFO - 2017-03-06 05:52:41 --> URI Class Initialized
INFO - 2017-03-06 05:52:41 --> Router Class Initialized
INFO - 2017-03-06 05:52:41 --> Output Class Initialized
INFO - 2017-03-06 05:52:41 --> Security Class Initialized
DEBUG - 2017-03-06 05:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 05:52:41 --> Input Class Initialized
INFO - 2017-03-06 05:52:41 --> Language Class Initialized
INFO - 2017-03-06 05:52:41 --> Loader Class Initialized
INFO - 2017-03-06 05:52:41 --> Database Driver Class Initialized
INFO - 2017-03-06 05:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 05:52:41 --> Controller Class Initialized
INFO - 2017-03-06 05:52:41 --> Helper loaded: url_helper
DEBUG - 2017-03-06 05:52:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 05:52:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 05:52:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 05:52:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 05:52:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 05:52:42 --> Final output sent to browser
DEBUG - 2017-03-06 05:52:42 --> Total execution time: 1.0928
INFO - 2017-03-06 07:33:30 --> Config Class Initialized
INFO - 2017-03-06 07:33:30 --> Hooks Class Initialized
DEBUG - 2017-03-06 07:33:31 --> UTF-8 Support Enabled
INFO - 2017-03-06 07:33:31 --> Utf8 Class Initialized
INFO - 2017-03-06 07:33:31 --> URI Class Initialized
DEBUG - 2017-03-06 07:33:31 --> No URI present. Default controller set.
INFO - 2017-03-06 07:33:31 --> Router Class Initialized
INFO - 2017-03-06 07:33:31 --> Output Class Initialized
INFO - 2017-03-06 07:33:31 --> Security Class Initialized
DEBUG - 2017-03-06 07:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 07:33:31 --> Input Class Initialized
INFO - 2017-03-06 07:33:31 --> Language Class Initialized
INFO - 2017-03-06 07:33:31 --> Loader Class Initialized
INFO - 2017-03-06 07:33:31 --> Database Driver Class Initialized
INFO - 2017-03-06 07:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 07:33:32 --> Controller Class Initialized
INFO - 2017-03-06 07:33:32 --> Helper loaded: url_helper
DEBUG - 2017-03-06 07:33:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 07:33:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 07:33:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 07:33:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 07:33:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 07:33:32 --> Final output sent to browser
DEBUG - 2017-03-06 07:33:32 --> Total execution time: 1.7573
INFO - 2017-03-06 07:34:10 --> Config Class Initialized
INFO - 2017-03-06 07:34:10 --> Hooks Class Initialized
DEBUG - 2017-03-06 07:34:10 --> UTF-8 Support Enabled
INFO - 2017-03-06 07:34:10 --> Utf8 Class Initialized
INFO - 2017-03-06 07:34:10 --> URI Class Initialized
INFO - 2017-03-06 07:34:10 --> Router Class Initialized
INFO - 2017-03-06 07:34:10 --> Output Class Initialized
INFO - 2017-03-06 07:34:10 --> Security Class Initialized
DEBUG - 2017-03-06 07:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 07:34:10 --> Input Class Initialized
INFO - 2017-03-06 07:34:10 --> Language Class Initialized
INFO - 2017-03-06 07:34:10 --> Loader Class Initialized
INFO - 2017-03-06 07:34:11 --> Database Driver Class Initialized
INFO - 2017-03-06 07:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 07:34:11 --> Controller Class Initialized
INFO - 2017-03-06 07:34:11 --> Helper loaded: url_helper
DEBUG - 2017-03-06 07:34:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 07:34:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 07:34:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 07:34:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 07:34:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 07:34:11 --> Final output sent to browser
DEBUG - 2017-03-06 07:34:11 --> Total execution time: 1.5195
INFO - 2017-03-06 15:20:45 --> Config Class Initialized
INFO - 2017-03-06 15:20:45 --> Hooks Class Initialized
DEBUG - 2017-03-06 15:20:46 --> UTF-8 Support Enabled
INFO - 2017-03-06 15:20:46 --> Utf8 Class Initialized
INFO - 2017-03-06 15:20:46 --> URI Class Initialized
DEBUG - 2017-03-06 15:20:46 --> No URI present. Default controller set.
INFO - 2017-03-06 15:20:46 --> Router Class Initialized
INFO - 2017-03-06 15:20:46 --> Output Class Initialized
INFO - 2017-03-06 15:20:46 --> Security Class Initialized
DEBUG - 2017-03-06 15:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 15:20:46 --> Input Class Initialized
INFO - 2017-03-06 15:20:46 --> Language Class Initialized
INFO - 2017-03-06 15:20:46 --> Loader Class Initialized
INFO - 2017-03-06 15:20:47 --> Database Driver Class Initialized
INFO - 2017-03-06 15:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 15:20:48 --> Controller Class Initialized
INFO - 2017-03-06 15:20:48 --> Helper loaded: url_helper
DEBUG - 2017-03-06 15:20:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 15:20:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 15:20:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 15:20:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 15:20:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 15:20:49 --> Final output sent to browser
DEBUG - 2017-03-06 15:20:49 --> Total execution time: 3.5006
INFO - 2017-03-06 16:43:34 --> Config Class Initialized
INFO - 2017-03-06 16:43:34 --> Hooks Class Initialized
DEBUG - 2017-03-06 16:43:35 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:43:35 --> Utf8 Class Initialized
INFO - 2017-03-06 16:43:35 --> URI Class Initialized
DEBUG - 2017-03-06 16:43:35 --> No URI present. Default controller set.
INFO - 2017-03-06 16:43:35 --> Router Class Initialized
INFO - 2017-03-06 16:43:35 --> Output Class Initialized
INFO - 2017-03-06 16:43:35 --> Security Class Initialized
DEBUG - 2017-03-06 16:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:43:35 --> Input Class Initialized
INFO - 2017-03-06 16:43:35 --> Language Class Initialized
INFO - 2017-03-06 16:43:35 --> Loader Class Initialized
INFO - 2017-03-06 16:43:36 --> Database Driver Class Initialized
INFO - 2017-03-06 16:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:43:38 --> Controller Class Initialized
INFO - 2017-03-06 16:43:38 --> Helper loaded: url_helper
DEBUG - 2017-03-06 16:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 16:43:38 --> Config Class Initialized
INFO - 2017-03-06 16:43:38 --> Hooks Class Initialized
INFO - 2017-03-06 16:43:38 --> Config Class Initialized
INFO - 2017-03-06 16:43:38 --> Hooks Class Initialized
INFO - 2017-03-06 16:43:38 --> Config Class Initialized
INFO - 2017-03-06 16:43:38 --> Hooks Class Initialized
INFO - 2017-03-06 16:43:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 16:43:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
DEBUG - 2017-03-06 16:43:39 --> UTF-8 Support Enabled
DEBUG - 2017-03-06 16:43:39 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:43:39 --> Utf8 Class Initialized
INFO - 2017-03-06 16:43:39 --> Utf8 Class Initialized
INFO - 2017-03-06 16:43:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 16:43:39 --> URI Class Initialized
DEBUG - 2017-03-06 16:43:39 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:43:39 --> URI Class Initialized
INFO - 2017-03-06 16:43:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
DEBUG - 2017-03-06 16:43:39 --> No URI present. Default controller set.
INFO - 2017-03-06 16:43:39 --> Router Class Initialized
INFO - 2017-03-06 16:43:39 --> Utf8 Class Initialized
INFO - 2017-03-06 16:43:39 --> URI Class Initialized
DEBUG - 2017-03-06 16:43:39 --> No URI present. Default controller set.
INFO - 2017-03-06 16:43:39 --> Router Class Initialized
INFO - 2017-03-06 16:43:39 --> Final output sent to browser
DEBUG - 2017-03-06 16:43:39 --> Total execution time: 4.6696
DEBUG - 2017-03-06 16:43:39 --> No URI present. Default controller set.
INFO - 2017-03-06 16:43:39 --> Router Class Initialized
INFO - 2017-03-06 16:43:39 --> Output Class Initialized
INFO - 2017-03-06 16:43:39 --> Output Class Initialized
INFO - 2017-03-06 16:43:39 --> Security Class Initialized
INFO - 2017-03-06 16:43:40 --> Output Class Initialized
INFO - 2017-03-06 16:43:40 --> Security Class Initialized
INFO - 2017-03-06 16:43:40 --> Security Class Initialized
DEBUG - 2017-03-06 16:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-03-06 16:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:43:40 --> Input Class Initialized
INFO - 2017-03-06 16:43:40 --> Input Class Initialized
DEBUG - 2017-03-06 16:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:43:41 --> Input Class Initialized
INFO - 2017-03-06 16:43:41 --> Language Class Initialized
INFO - 2017-03-06 16:43:41 --> Language Class Initialized
INFO - 2017-03-06 16:43:41 --> Language Class Initialized
INFO - 2017-03-06 16:43:41 --> Loader Class Initialized
INFO - 2017-03-06 16:43:41 --> Loader Class Initialized
INFO - 2017-03-06 16:43:41 --> Loader Class Initialized
INFO - 2017-03-06 16:43:42 --> Database Driver Class Initialized
INFO - 2017-03-06 16:43:42 --> Database Driver Class Initialized
INFO - 2017-03-06 16:43:42 --> Database Driver Class Initialized
INFO - 2017-03-06 16:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:43:43 --> Controller Class Initialized
INFO - 2017-03-06 16:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:43:43 --> Controller Class Initialized
INFO - 2017-03-06 16:43:43 --> Helper loaded: url_helper
INFO - 2017-03-06 16:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:43:43 --> Helper loaded: url_helper
INFO - 2017-03-06 16:43:43 --> Controller Class Initialized
INFO - 2017-03-06 16:43:43 --> Helper loaded: url_helper
DEBUG - 2017-03-06 16:43:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-06 16:43:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-06 16:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 16:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 16:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 16:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 16:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 16:43:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 16:43:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 16:43:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 16:43:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 16:43:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 16:43:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:43:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:43:44 --> Final output sent to browser
DEBUG - 2017-03-06 16:43:44 --> Total execution time: 6.2588
INFO - 2017-03-06 16:43:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:43:45 --> Final output sent to browser
DEBUG - 2017-03-06 16:43:45 --> Total execution time: 6.3527
INFO - 2017-03-06 16:43:45 --> Final output sent to browser
DEBUG - 2017-03-06 16:43:45 --> Total execution time: 6.5948
INFO - 2017-03-06 16:44:03 --> Config Class Initialized
INFO - 2017-03-06 16:44:03 --> Hooks Class Initialized
DEBUG - 2017-03-06 16:44:03 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:44:03 --> Utf8 Class Initialized
INFO - 2017-03-06 16:44:03 --> URI Class Initialized
INFO - 2017-03-06 16:44:03 --> Config Class Initialized
INFO - 2017-03-06 16:44:03 --> Hooks Class Initialized
INFO - 2017-03-06 16:44:03 --> Config Class Initialized
INFO - 2017-03-06 16:44:03 --> Hooks Class Initialized
DEBUG - 2017-03-06 16:44:03 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:44:03 --> Utf8 Class Initialized
INFO - 2017-03-06 16:44:03 --> URI Class Initialized
DEBUG - 2017-03-06 16:44:03 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:44:03 --> Utf8 Class Initialized
INFO - 2017-03-06 16:44:03 --> URI Class Initialized
DEBUG - 2017-03-06 16:44:03 --> No URI present. Default controller set.
DEBUG - 2017-03-06 16:44:03 --> No URI present. Default controller set.
INFO - 2017-03-06 16:44:03 --> Router Class Initialized
DEBUG - 2017-03-06 16:44:03 --> No URI present. Default controller set.
INFO - 2017-03-06 16:44:03 --> Router Class Initialized
INFO - 2017-03-06 16:44:03 --> Router Class Initialized
INFO - 2017-03-06 16:44:03 --> Output Class Initialized
INFO - 2017-03-06 16:44:03 --> Output Class Initialized
INFO - 2017-03-06 16:44:03 --> Output Class Initialized
INFO - 2017-03-06 16:44:03 --> Security Class Initialized
INFO - 2017-03-06 16:44:03 --> Security Class Initialized
DEBUG - 2017-03-06 16:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:44:04 --> Input Class Initialized
INFO - 2017-03-06 16:44:04 --> Security Class Initialized
DEBUG - 2017-03-06 16:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:44:04 --> Input Class Initialized
INFO - 2017-03-06 16:44:04 --> Language Class Initialized
DEBUG - 2017-03-06 16:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:44:04 --> Input Class Initialized
INFO - 2017-03-06 16:44:04 --> Language Class Initialized
INFO - 2017-03-06 16:44:04 --> Language Class Initialized
INFO - 2017-03-06 16:44:04 --> Loader Class Initialized
INFO - 2017-03-06 16:44:04 --> Loader Class Initialized
INFO - 2017-03-06 16:44:04 --> Loader Class Initialized
INFO - 2017-03-06 16:44:04 --> Database Driver Class Initialized
INFO - 2017-03-06 16:44:04 --> Database Driver Class Initialized
INFO - 2017-03-06 16:44:04 --> Database Driver Class Initialized
INFO - 2017-03-06 16:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:44:05 --> Controller Class Initialized
INFO - 2017-03-06 16:44:05 --> Helper loaded: url_helper
INFO - 2017-03-06 16:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:44:05 --> Controller Class Initialized
INFO - 2017-03-06 16:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:44:05 --> Helper loaded: url_helper
INFO - 2017-03-06 16:44:05 --> Controller Class Initialized
DEBUG - 2017-03-06 16:44:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 16:44:05 --> Helper loaded: url_helper
DEBUG - 2017-03-06 16:44:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-06 16:44:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 16:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 16:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 16:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 16:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 16:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 16:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 16:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 16:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 16:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 16:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:44:06 --> Final output sent to browser
INFO - 2017-03-06 16:44:07 --> Final output sent to browser
DEBUG - 2017-03-06 16:44:07 --> Total execution time: 3.8506
DEBUG - 2017-03-06 16:44:07 --> Total execution time: 3.8506
INFO - 2017-03-06 16:44:07 --> Final output sent to browser
DEBUG - 2017-03-06 16:44:07 --> Total execution time: 3.8509
INFO - 2017-03-06 16:44:14 --> Config Class Initialized
INFO - 2017-03-06 16:44:14 --> Hooks Class Initialized
DEBUG - 2017-03-06 16:44:15 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:44:15 --> Utf8 Class Initialized
INFO - 2017-03-06 16:44:15 --> URI Class Initialized
DEBUG - 2017-03-06 16:44:15 --> No URI present. Default controller set.
INFO - 2017-03-06 16:44:15 --> Router Class Initialized
INFO - 2017-03-06 16:44:15 --> Output Class Initialized
INFO - 2017-03-06 16:44:15 --> Security Class Initialized
DEBUG - 2017-03-06 16:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:44:15 --> Input Class Initialized
INFO - 2017-03-06 16:44:15 --> Language Class Initialized
INFO - 2017-03-06 16:44:15 --> Loader Class Initialized
INFO - 2017-03-06 16:44:16 --> Database Driver Class Initialized
INFO - 2017-03-06 16:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:44:16 --> Controller Class Initialized
INFO - 2017-03-06 16:44:16 --> Helper loaded: url_helper
DEBUG - 2017-03-06 16:44:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 16:44:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 16:44:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 16:44:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 16:44:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:44:17 --> Final output sent to browser
DEBUG - 2017-03-06 16:44:17 --> Total execution time: 2.3452
INFO - 2017-03-06 16:45:04 --> Config Class Initialized
INFO - 2017-03-06 16:45:04 --> Hooks Class Initialized
DEBUG - 2017-03-06 16:45:05 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:45:05 --> Utf8 Class Initialized
INFO - 2017-03-06 16:45:05 --> URI Class Initialized
DEBUG - 2017-03-06 16:45:05 --> No URI present. Default controller set.
INFO - 2017-03-06 16:45:05 --> Router Class Initialized
INFO - 2017-03-06 16:45:05 --> Output Class Initialized
INFO - 2017-03-06 16:45:05 --> Security Class Initialized
DEBUG - 2017-03-06 16:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:45:05 --> Input Class Initialized
INFO - 2017-03-06 16:45:05 --> Language Class Initialized
INFO - 2017-03-06 16:45:05 --> Loader Class Initialized
INFO - 2017-03-06 16:45:05 --> Database Driver Class Initialized
INFO - 2017-03-06 16:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:45:06 --> Controller Class Initialized
INFO - 2017-03-06 16:45:06 --> Helper loaded: url_helper
DEBUG - 2017-03-06 16:45:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 16:45:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 16:45:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 16:45:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 16:45:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:45:06 --> Final output sent to browser
DEBUG - 2017-03-06 16:45:06 --> Total execution time: 2.9708
INFO - 2017-03-06 16:45:25 --> Config Class Initialized
INFO - 2017-03-06 16:45:25 --> Hooks Class Initialized
DEBUG - 2017-03-06 16:45:25 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:45:25 --> Utf8 Class Initialized
INFO - 2017-03-06 16:45:25 --> URI Class Initialized
DEBUG - 2017-03-06 16:45:25 --> No URI present. Default controller set.
INFO - 2017-03-06 16:45:25 --> Router Class Initialized
INFO - 2017-03-06 16:45:25 --> Output Class Initialized
INFO - 2017-03-06 16:45:25 --> Security Class Initialized
DEBUG - 2017-03-06 16:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:45:25 --> Input Class Initialized
INFO - 2017-03-06 16:45:25 --> Language Class Initialized
INFO - 2017-03-06 16:45:25 --> Loader Class Initialized
INFO - 2017-03-06 16:45:26 --> Database Driver Class Initialized
INFO - 2017-03-06 16:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:45:26 --> Controller Class Initialized
INFO - 2017-03-06 16:45:26 --> Helper loaded: url_helper
DEBUG - 2017-03-06 16:45:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 16:45:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 16:45:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 16:45:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 16:45:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:45:27 --> Final output sent to browser
DEBUG - 2017-03-06 16:45:27 --> Total execution time: 2.9007
INFO - 2017-03-06 16:45:41 --> Config Class Initialized
INFO - 2017-03-06 16:45:41 --> Hooks Class Initialized
DEBUG - 2017-03-06 16:45:41 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:45:41 --> Utf8 Class Initialized
INFO - 2017-03-06 16:45:41 --> URI Class Initialized
INFO - 2017-03-06 16:45:41 --> Router Class Initialized
INFO - 2017-03-06 16:45:41 --> Output Class Initialized
INFO - 2017-03-06 16:45:41 --> Security Class Initialized
DEBUG - 2017-03-06 16:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:45:41 --> Input Class Initialized
INFO - 2017-03-06 16:45:41 --> Language Class Initialized
INFO - 2017-03-06 16:45:41 --> Loader Class Initialized
INFO - 2017-03-06 16:45:42 --> Database Driver Class Initialized
INFO - 2017-03-06 16:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:45:42 --> Controller Class Initialized
INFO - 2017-03-06 16:45:42 --> Helper loaded: url_helper
DEBUG - 2017-03-06 16:45:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 16:45:57 --> Config Class Initialized
INFO - 2017-03-06 16:45:57 --> Hooks Class Initialized
DEBUG - 2017-03-06 16:45:57 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:45:57 --> Utf8 Class Initialized
INFO - 2017-03-06 16:45:57 --> URI Class Initialized
INFO - 2017-03-06 16:45:57 --> Config Class Initialized
INFO - 2017-03-06 16:45:57 --> Hooks Class Initialized
DEBUG - 2017-03-06 16:45:57 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:45:57 --> Router Class Initialized
INFO - 2017-03-06 16:45:57 --> Utf8 Class Initialized
INFO - 2017-03-06 16:45:57 --> URI Class Initialized
INFO - 2017-03-06 16:45:57 --> Router Class Initialized
INFO - 2017-03-06 16:45:57 --> Output Class Initialized
INFO - 2017-03-06 16:45:57 --> Output Class Initialized
INFO - 2017-03-06 16:45:57 --> Security Class Initialized
INFO - 2017-03-06 16:45:57 --> Security Class Initialized
DEBUG - 2017-03-06 16:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-03-06 16:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:45:58 --> Input Class Initialized
INFO - 2017-03-06 16:45:58 --> Input Class Initialized
INFO - 2017-03-06 16:45:58 --> Language Class Initialized
INFO - 2017-03-06 16:45:58 --> Language Class Initialized
INFO - 2017-03-06 16:45:58 --> Loader Class Initialized
INFO - 2017-03-06 16:45:58 --> Loader Class Initialized
INFO - 2017-03-06 16:45:59 --> Database Driver Class Initialized
INFO - 2017-03-06 16:45:59 --> Database Driver Class Initialized
INFO - 2017-03-06 16:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:46:00 --> Controller Class Initialized
INFO - 2017-03-06 16:46:00 --> Helper loaded: url_helper
INFO - 2017-03-06 16:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:46:01 --> Controller Class Initialized
DEBUG - 2017-03-06 16:46:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 16:46:01 --> Helper loaded: url_helper
DEBUG - 2017-03-06 16:46:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 16:46:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-06 16:46:02 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-06 16:46:03 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-06 16:46:03 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-06 16:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 16:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 16:46:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:46:05 --> Final output sent to browser
DEBUG - 2017-03-06 16:46:05 --> Total execution time: 8.1642
INFO - 2017-03-06 16:46:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-06 16:46:14 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-06 16:46:15 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-06 16:46:15 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-06 16:46:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 16:46:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 16:46:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:46:15 --> Final output sent to browser
DEBUG - 2017-03-06 16:46:15 --> Total execution time: 34.4145
INFO - 2017-03-06 16:46:33 --> Config Class Initialized
INFO - 2017-03-06 16:46:33 --> Hooks Class Initialized
INFO - 2017-03-06 16:46:34 --> Config Class Initialized
INFO - 2017-03-06 16:46:34 --> Hooks Class Initialized
INFO - 2017-03-06 16:46:34 --> Config Class Initialized
INFO - 2017-03-06 16:46:34 --> Hooks Class Initialized
DEBUG - 2017-03-06 16:46:34 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:46:34 --> Config Class Initialized
DEBUG - 2017-03-06 16:46:34 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:46:34 --> Hooks Class Initialized
INFO - 2017-03-06 16:46:34 --> Utf8 Class Initialized
DEBUG - 2017-03-06 16:46:34 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:46:34 --> Utf8 Class Initialized
INFO - 2017-03-06 16:46:34 --> Utf8 Class Initialized
INFO - 2017-03-06 16:46:34 --> URI Class Initialized
INFO - 2017-03-06 16:46:34 --> URI Class Initialized
DEBUG - 2017-03-06 16:46:34 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:46:34 --> Utf8 Class Initialized
INFO - 2017-03-06 16:46:34 --> URI Class Initialized
INFO - 2017-03-06 16:46:34 --> URI Class Initialized
INFO - 2017-03-06 16:46:34 --> Router Class Initialized
DEBUG - 2017-03-06 16:46:34 --> No URI present. Default controller set.
INFO - 2017-03-06 16:46:34 --> Router Class Initialized
INFO - 2017-03-06 16:46:34 --> Router Class Initialized
INFO - 2017-03-06 16:46:34 --> Router Class Initialized
INFO - 2017-03-06 16:46:34 --> Output Class Initialized
INFO - 2017-03-06 16:46:34 --> Output Class Initialized
INFO - 2017-03-06 16:46:34 --> Output Class Initialized
INFO - 2017-03-06 16:46:34 --> Security Class Initialized
INFO - 2017-03-06 16:46:34 --> Security Class Initialized
DEBUG - 2017-03-06 16:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:46:34 --> Input Class Initialized
INFO - 2017-03-06 16:46:34 --> Language Class Initialized
DEBUG - 2017-03-06 16:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:46:34 --> Output Class Initialized
INFO - 2017-03-06 16:46:34 --> Security Class Initialized
DEBUG - 2017-03-06 16:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:46:34 --> Input Class Initialized
INFO - 2017-03-06 16:46:34 --> Language Class Initialized
INFO - 2017-03-06 16:46:34 --> Security Class Initialized
INFO - 2017-03-06 16:46:34 --> Loader Class Initialized
DEBUG - 2017-03-06 16:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:46:35 --> Input Class Initialized
INFO - 2017-03-06 16:46:35 --> Language Class Initialized
INFO - 2017-03-06 16:46:35 --> Loader Class Initialized
INFO - 2017-03-06 16:46:35 --> Input Class Initialized
INFO - 2017-03-06 16:46:35 --> Language Class Initialized
INFO - 2017-03-06 16:46:35 --> Config Class Initialized
INFO - 2017-03-06 16:46:35 --> Hooks Class Initialized
INFO - 2017-03-06 16:46:35 --> Loader Class Initialized
DEBUG - 2017-03-06 16:46:35 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:46:35 --> Utf8 Class Initialized
INFO - 2017-03-06 16:46:35 --> Loader Class Initialized
INFO - 2017-03-06 16:46:35 --> Database Driver Class Initialized
INFO - 2017-03-06 16:46:35 --> Database Driver Class Initialized
INFO - 2017-03-06 16:46:35 --> URI Class Initialized
INFO - 2017-03-06 16:46:35 --> Database Driver Class Initialized
INFO - 2017-03-06 16:46:35 --> Database Driver Class Initialized
INFO - 2017-03-06 16:46:35 --> Router Class Initialized
INFO - 2017-03-06 16:46:35 --> Output Class Initialized
INFO - 2017-03-06 16:46:35 --> Security Class Initialized
DEBUG - 2017-03-06 16:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:46:35 --> Input Class Initialized
INFO - 2017-03-06 16:46:35 --> Language Class Initialized
INFO - 2017-03-06 16:46:35 --> Loader Class Initialized
INFO - 2017-03-06 16:46:35 --> Database Driver Class Initialized
INFO - 2017-03-06 16:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:46:35 --> Controller Class Initialized
INFO - 2017-03-06 16:46:35 --> Controller Class Initialized
INFO - 2017-03-06 16:46:35 --> Helper loaded: url_helper
DEBUG - 2017-03-06 16:46:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 16:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:46:36 --> Controller Class Initialized
INFO - 2017-03-06 16:46:36 --> Helper loaded: url_helper
DEBUG - 2017-03-06 16:46:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 16:46:36 --> Config Class Initialized
INFO - 2017-03-06 16:46:36 --> Hooks Class Initialized
DEBUG - 2017-03-06 16:46:36 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:46:36 --> Utf8 Class Initialized
INFO - 2017-03-06 16:46:36 --> Helper loaded: date_helper
INFO - 2017-03-06 16:46:36 --> URI Class Initialized
DEBUG - 2017-03-06 16:46:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 16:46:36 --> Helper loaded: url_helper
INFO - 2017-03-06 16:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 16:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 16:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 16:46:36 --> Router Class Initialized
ERROR - 2017-03-06 16:46:36 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
INFO - 2017-03-06 16:46:36 --> Output Class Initialized
INFO - 2017-03-06 16:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 16:46:36 --> Security Class Initialized
ERROR - 2017-03-06 16:46:36 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
INFO - 2017-03-06 16:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
DEBUG - 2017-03-06 16:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:46:36 --> Input Class Initialized
ERROR - 2017-03-06 16:46:36 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-06 16:46:36 --> Language Class Initialized
INFO - 2017-03-06 16:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 16:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 16:46:36 --> Loader Class Initialized
INFO - 2017-03-06 16:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:46:36 --> Final output sent to browser
DEBUG - 2017-03-06 16:46:36 --> Total execution time: 3.5582
INFO - 2017-03-06 16:46:36 --> Database Driver Class Initialized
INFO - 2017-03-06 16:46:36 --> Final output sent to browser
DEBUG - 2017-03-06 16:46:36 --> Total execution time: 3.5579
INFO - 2017-03-06 16:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:46:36 --> Controller Class Initialized
INFO - 2017-03-06 16:46:36 --> Helper loaded: url_helper
DEBUG - 2017-03-06 16:46:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 16:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-06 16:46:36 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-06 16:46:36 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-06 16:46:36 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-06 16:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 16:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 16:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:46:36 --> Final output sent to browser
DEBUG - 2017-03-06 16:46:36 --> Total execution time: 3.5670
INFO - 2017-03-06 16:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:46:36 --> Controller Class Initialized
INFO - 2017-03-06 16:46:36 --> Helper loaded: url_helper
DEBUG - 2017-03-06 16:46:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 16:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-06 16:46:36 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-06 16:46:36 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-06 16:46:36 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-06 16:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 16:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 16:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:46:36 --> Final output sent to browser
DEBUG - 2017-03-06 16:46:36 --> Total execution time: 1.7313
INFO - 2017-03-06 16:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-06 16:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-06 16:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:46:37 --> Controller Class Initialized
INFO - 2017-03-06 16:46:37 --> Helper loaded: url_helper
DEBUG - 2017-03-06 16:46:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 16:46:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 16:46:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 16:46:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 16:46:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:46:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-06 16:46:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:46:37 --> Final output sent to browser
DEBUG - 2017-03-06 16:46:37 --> Total execution time: 3.7850
INFO - 2017-03-06 16:46:37 --> Final output sent to browser
DEBUG - 2017-03-06 16:46:37 --> Total execution time: 2.1257
INFO - 2017-03-06 16:47:06 --> Config Class Initialized
INFO - 2017-03-06 16:47:06 --> Hooks Class Initialized
INFO - 2017-03-06 16:47:06 --> Config Class Initialized
INFO - 2017-03-06 16:47:06 --> Hooks Class Initialized
DEBUG - 2017-03-06 16:47:06 --> UTF-8 Support Enabled
DEBUG - 2017-03-06 16:47:06 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:47:06 --> Utf8 Class Initialized
INFO - 2017-03-06 16:47:06 --> Utf8 Class Initialized
INFO - 2017-03-06 16:47:06 --> URI Class Initialized
INFO - 2017-03-06 16:47:06 --> URI Class Initialized
INFO - 2017-03-06 16:47:06 --> Router Class Initialized
INFO - 2017-03-06 16:47:06 --> Router Class Initialized
INFO - 2017-03-06 16:47:06 --> Output Class Initialized
INFO - 2017-03-06 16:47:06 --> Output Class Initialized
INFO - 2017-03-06 16:47:06 --> Security Class Initialized
INFO - 2017-03-06 16:47:06 --> Security Class Initialized
DEBUG - 2017-03-06 16:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:47:06 --> Input Class Initialized
INFO - 2017-03-06 16:47:06 --> Language Class Initialized
DEBUG - 2017-03-06 16:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:47:06 --> Input Class Initialized
INFO - 2017-03-06 16:47:06 --> Language Class Initialized
INFO - 2017-03-06 16:47:06 --> Loader Class Initialized
INFO - 2017-03-06 16:47:06 --> Loader Class Initialized
INFO - 2017-03-06 16:47:07 --> Database Driver Class Initialized
INFO - 2017-03-06 16:47:07 --> Database Driver Class Initialized
INFO - 2017-03-06 16:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:47:07 --> Controller Class Initialized
INFO - 2017-03-06 16:47:07 --> Helper loaded: url_helper
DEBUG - 2017-03-06 16:47:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 16:47:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 16:47:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 16:47:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 16:47:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:47:08 --> Final output sent to browser
DEBUG - 2017-03-06 16:47:08 --> Total execution time: 2.4875
INFO - 2017-03-06 16:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:47:08 --> Controller Class Initialized
INFO - 2017-03-06 16:47:08 --> Helper loaded: url_helper
DEBUG - 2017-03-06 16:47:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 16:47:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 16:47:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 16:47:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 16:47:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:47:52 --> Config Class Initialized
INFO - 2017-03-06 16:47:52 --> Hooks Class Initialized
DEBUG - 2017-03-06 16:47:52 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:47:52 --> Utf8 Class Initialized
INFO - 2017-03-06 16:47:52 --> URI Class Initialized
INFO - 2017-03-06 16:47:52 --> Router Class Initialized
INFO - 2017-03-06 16:47:52 --> Output Class Initialized
INFO - 2017-03-06 16:47:52 --> Security Class Initialized
DEBUG - 2017-03-06 16:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:47:52 --> Input Class Initialized
INFO - 2017-03-06 16:47:52 --> Language Class Initialized
INFO - 2017-03-06 16:47:52 --> Loader Class Initialized
INFO - 2017-03-06 16:47:53 --> Database Driver Class Initialized
INFO - 2017-03-06 16:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:47:53 --> Controller Class Initialized
INFO - 2017-03-06 16:47:53 --> Helper loaded: url_helper
DEBUG - 2017-03-06 16:47:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 16:48:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-06 16:48:29 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-06 16:48:29 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-06 16:48:29 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-06 16:48:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 16:48:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 16:48:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:48:29 --> Final output sent to browser
DEBUG - 2017-03-06 16:48:29 --> Total execution time: 37.0933
INFO - 2017-03-06 16:50:02 --> Config Class Initialized
INFO - 2017-03-06 16:50:02 --> Hooks Class Initialized
DEBUG - 2017-03-06 16:50:02 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:50:02 --> Utf8 Class Initialized
INFO - 2017-03-06 16:50:02 --> URI Class Initialized
DEBUG - 2017-03-06 16:50:03 --> No URI present. Default controller set.
INFO - 2017-03-06 16:50:03 --> Router Class Initialized
INFO - 2017-03-06 16:50:03 --> Output Class Initialized
INFO - 2017-03-06 16:50:03 --> Security Class Initialized
DEBUG - 2017-03-06 16:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:50:03 --> Input Class Initialized
INFO - 2017-03-06 16:50:03 --> Language Class Initialized
INFO - 2017-03-06 16:50:03 --> Loader Class Initialized
INFO - 2017-03-06 16:50:03 --> Database Driver Class Initialized
INFO - 2017-03-06 16:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:50:03 --> Controller Class Initialized
INFO - 2017-03-06 16:50:03 --> Helper loaded: url_helper
DEBUG - 2017-03-06 16:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 16:50:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 16:50:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 16:50:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 16:50:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:50:04 --> Final output sent to browser
DEBUG - 2017-03-06 16:50:04 --> Total execution time: 2.1212
INFO - 2017-03-06 16:51:12 --> Config Class Initialized
INFO - 2017-03-06 16:51:12 --> Hooks Class Initialized
DEBUG - 2017-03-06 16:51:12 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:51:12 --> Utf8 Class Initialized
INFO - 2017-03-06 16:51:12 --> URI Class Initialized
DEBUG - 2017-03-06 16:51:12 --> No URI present. Default controller set.
INFO - 2017-03-06 16:51:12 --> Router Class Initialized
INFO - 2017-03-06 16:51:12 --> Output Class Initialized
INFO - 2017-03-06 16:51:12 --> Security Class Initialized
DEBUG - 2017-03-06 16:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:51:12 --> Input Class Initialized
INFO - 2017-03-06 16:51:12 --> Language Class Initialized
INFO - 2017-03-06 16:51:12 --> Loader Class Initialized
INFO - 2017-03-06 16:51:13 --> Database Driver Class Initialized
INFO - 2017-03-06 16:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:51:13 --> Controller Class Initialized
INFO - 2017-03-06 16:51:13 --> Helper loaded: url_helper
DEBUG - 2017-03-06 16:51:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 16:51:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 16:51:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 16:51:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 16:51:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:51:14 --> Final output sent to browser
DEBUG - 2017-03-06 16:51:14 --> Total execution time: 2.1842
INFO - 2017-03-06 16:52:05 --> Config Class Initialized
INFO - 2017-03-06 16:52:05 --> Hooks Class Initialized
DEBUG - 2017-03-06 16:52:05 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:52:05 --> Utf8 Class Initialized
INFO - 2017-03-06 16:52:05 --> URI Class Initialized
INFO - 2017-03-06 16:52:06 --> Router Class Initialized
INFO - 2017-03-06 16:52:06 --> Output Class Initialized
INFO - 2017-03-06 16:52:06 --> Security Class Initialized
DEBUG - 2017-03-06 16:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:52:06 --> Input Class Initialized
INFO - 2017-03-06 16:52:06 --> Language Class Initialized
INFO - 2017-03-06 16:52:06 --> Loader Class Initialized
INFO - 2017-03-06 16:52:06 --> Database Driver Class Initialized
INFO - 2017-03-06 16:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:52:06 --> Controller Class Initialized
INFO - 2017-03-06 16:52:06 --> Helper loaded: url_helper
DEBUG - 2017-03-06 16:52:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 16:52:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-06 16:52:28 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-06 16:52:28 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-06 16:52:28 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-06 16:52:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 16:52:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 16:52:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:52:28 --> Final output sent to browser
DEBUG - 2017-03-06 16:52:28 --> Total execution time: 22.9418
INFO - 2017-03-06 16:54:53 --> Config Class Initialized
INFO - 2017-03-06 16:54:53 --> Hooks Class Initialized
DEBUG - 2017-03-06 16:54:54 --> UTF-8 Support Enabled
INFO - 2017-03-06 16:54:54 --> Utf8 Class Initialized
INFO - 2017-03-06 16:54:54 --> URI Class Initialized
DEBUG - 2017-03-06 16:54:54 --> No URI present. Default controller set.
INFO - 2017-03-06 16:54:54 --> Router Class Initialized
INFO - 2017-03-06 16:54:54 --> Output Class Initialized
INFO - 2017-03-06 16:54:54 --> Security Class Initialized
DEBUG - 2017-03-06 16:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 16:54:54 --> Input Class Initialized
INFO - 2017-03-06 16:54:54 --> Language Class Initialized
INFO - 2017-03-06 16:54:54 --> Loader Class Initialized
INFO - 2017-03-06 16:54:54 --> Database Driver Class Initialized
INFO - 2017-03-06 16:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 16:54:55 --> Controller Class Initialized
INFO - 2017-03-06 16:54:55 --> Helper loaded: url_helper
DEBUG - 2017-03-06 16:54:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 16:54:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 16:54:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 16:54:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 16:54:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 16:54:55 --> Final output sent to browser
DEBUG - 2017-03-06 16:54:55 --> Total execution time: 1.8426
INFO - 2017-03-06 17:06:14 --> Config Class Initialized
INFO - 2017-03-06 17:06:14 --> Hooks Class Initialized
INFO - 2017-03-06 17:06:14 --> Config Class Initialized
INFO - 2017-03-06 17:06:14 --> Hooks Class Initialized
DEBUG - 2017-03-06 17:06:14 --> UTF-8 Support Enabled
DEBUG - 2017-03-06 17:06:14 --> UTF-8 Support Enabled
INFO - 2017-03-06 17:06:14 --> Utf8 Class Initialized
INFO - 2017-03-06 17:06:14 --> Utf8 Class Initialized
INFO - 2017-03-06 17:06:14 --> URI Class Initialized
INFO - 2017-03-06 17:06:14 --> URI Class Initialized
DEBUG - 2017-03-06 17:06:14 --> No URI present. Default controller set.
INFO - 2017-03-06 17:06:15 --> Router Class Initialized
DEBUG - 2017-03-06 17:06:15 --> No URI present. Default controller set.
INFO - 2017-03-06 17:06:15 --> Router Class Initialized
INFO - 2017-03-06 17:06:15 --> Output Class Initialized
INFO - 2017-03-06 17:06:15 --> Output Class Initialized
INFO - 2017-03-06 17:06:15 --> Security Class Initialized
DEBUG - 2017-03-06 17:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 17:06:15 --> Security Class Initialized
INFO - 2017-03-06 17:06:15 --> Input Class Initialized
DEBUG - 2017-03-06 17:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 17:06:15 --> Language Class Initialized
INFO - 2017-03-06 17:06:15 --> Input Class Initialized
INFO - 2017-03-06 17:06:15 --> Language Class Initialized
INFO - 2017-03-06 17:06:15 --> Loader Class Initialized
INFO - 2017-03-06 17:06:15 --> Loader Class Initialized
INFO - 2017-03-06 17:06:15 --> Database Driver Class Initialized
INFO - 2017-03-06 17:06:15 --> Database Driver Class Initialized
INFO - 2017-03-06 17:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 17:06:16 --> Controller Class Initialized
INFO - 2017-03-06 17:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 17:06:16 --> Helper loaded: url_helper
INFO - 2017-03-06 17:06:16 --> Controller Class Initialized
INFO - 2017-03-06 17:06:16 --> Helper loaded: url_helper
DEBUG - 2017-03-06 17:06:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-06 17:06:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 17:06:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 17:06:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 17:06:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 17:06:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 17:06:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 17:06:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 17:06:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 17:06:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 17:06:17 --> Final output sent to browser
DEBUG - 2017-03-06 17:06:17 --> Total execution time: 2.6174
INFO - 2017-03-06 17:06:17 --> Final output sent to browser
DEBUG - 2017-03-06 17:06:17 --> Total execution time: 2.6173
INFO - 2017-03-06 17:06:52 --> Config Class Initialized
INFO - 2017-03-06 17:06:52 --> Hooks Class Initialized
DEBUG - 2017-03-06 17:06:52 --> UTF-8 Support Enabled
INFO - 2017-03-06 17:06:52 --> Utf8 Class Initialized
INFO - 2017-03-06 17:06:53 --> URI Class Initialized
INFO - 2017-03-06 17:06:53 --> Router Class Initialized
INFO - 2017-03-06 17:06:53 --> Output Class Initialized
INFO - 2017-03-06 17:06:53 --> Security Class Initialized
DEBUG - 2017-03-06 17:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 17:06:53 --> Input Class Initialized
INFO - 2017-03-06 17:06:53 --> Language Class Initialized
INFO - 2017-03-06 17:06:53 --> Loader Class Initialized
INFO - 2017-03-06 17:06:53 --> Database Driver Class Initialized
INFO - 2017-03-06 17:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 17:06:54 --> Controller Class Initialized
INFO - 2017-03-06 17:06:54 --> Helper loaded: url_helper
DEBUG - 2017-03-06 17:06:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 17:06:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 17:06:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 17:06:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 17:06:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 17:06:54 --> Final output sent to browser
DEBUG - 2017-03-06 17:06:54 --> Total execution time: 2.4424
INFO - 2017-03-06 17:06:56 --> Config Class Initialized
INFO - 2017-03-06 17:06:56 --> Hooks Class Initialized
DEBUG - 2017-03-06 17:06:57 --> UTF-8 Support Enabled
INFO - 2017-03-06 17:06:57 --> Utf8 Class Initialized
INFO - 2017-03-06 17:06:57 --> URI Class Initialized
INFO - 2017-03-06 17:06:57 --> Router Class Initialized
INFO - 2017-03-06 17:06:57 --> Output Class Initialized
INFO - 2017-03-06 17:06:57 --> Security Class Initialized
DEBUG - 2017-03-06 17:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 17:06:57 --> Input Class Initialized
INFO - 2017-03-06 17:06:57 --> Language Class Initialized
INFO - 2017-03-06 17:06:57 --> Loader Class Initialized
INFO - 2017-03-06 17:06:58 --> Database Driver Class Initialized
INFO - 2017-03-06 17:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 17:06:58 --> Controller Class Initialized
INFO - 2017-03-06 17:06:58 --> Helper loaded: url_helper
DEBUG - 2017-03-06 17:06:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 17:06:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 17:06:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 17:06:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 17:06:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 17:06:59 --> Final output sent to browser
DEBUG - 2017-03-06 17:06:59 --> Total execution time: 2.6815
INFO - 2017-03-06 17:07:04 --> Config Class Initialized
INFO - 2017-03-06 17:07:04 --> Hooks Class Initialized
DEBUG - 2017-03-06 17:07:04 --> UTF-8 Support Enabled
INFO - 2017-03-06 17:07:04 --> Utf8 Class Initialized
INFO - 2017-03-06 17:07:04 --> URI Class Initialized
INFO - 2017-03-06 17:07:04 --> Router Class Initialized
INFO - 2017-03-06 17:07:04 --> Output Class Initialized
INFO - 2017-03-06 17:07:04 --> Security Class Initialized
DEBUG - 2017-03-06 17:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 17:07:04 --> Input Class Initialized
INFO - 2017-03-06 17:07:04 --> Language Class Initialized
INFO - 2017-03-06 17:07:04 --> Loader Class Initialized
INFO - 2017-03-06 17:07:04 --> Database Driver Class Initialized
INFO - 2017-03-06 17:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 17:07:05 --> Controller Class Initialized
INFO - 2017-03-06 17:07:05 --> Helper loaded: url_helper
DEBUG - 2017-03-06 17:07:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 17:07:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-06 17:07:06 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-06 17:07:06 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-06 17:07:06 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-06 17:07:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 17:07:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 17:07:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 17:07:06 --> Final output sent to browser
DEBUG - 2017-03-06 17:07:06 --> Total execution time: 2.4479
INFO - 2017-03-06 17:07:39 --> Config Class Initialized
INFO - 2017-03-06 17:07:39 --> Hooks Class Initialized
DEBUG - 2017-03-06 17:07:39 --> UTF-8 Support Enabled
INFO - 2017-03-06 17:07:39 --> Utf8 Class Initialized
INFO - 2017-03-06 17:07:39 --> URI Class Initialized
INFO - 2017-03-06 17:07:39 --> Router Class Initialized
INFO - 2017-03-06 17:07:40 --> Output Class Initialized
INFO - 2017-03-06 17:07:40 --> Security Class Initialized
DEBUG - 2017-03-06 17:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 17:07:40 --> Input Class Initialized
INFO - 2017-03-06 17:07:40 --> Language Class Initialized
INFO - 2017-03-06 17:07:40 --> Loader Class Initialized
INFO - 2017-03-06 17:07:40 --> Database Driver Class Initialized
INFO - 2017-03-06 17:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 17:07:40 --> Controller Class Initialized
INFO - 2017-03-06 17:07:40 --> Helper loaded: url_helper
DEBUG - 2017-03-06 17:07:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 17:07:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 17:07:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 17:07:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 17:07:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 17:07:41 --> Final output sent to browser
DEBUG - 2017-03-06 17:07:41 --> Total execution time: 1.7926
INFO - 2017-03-06 17:17:53 --> Config Class Initialized
INFO - 2017-03-06 17:17:54 --> Hooks Class Initialized
DEBUG - 2017-03-06 17:17:54 --> UTF-8 Support Enabled
INFO - 2017-03-06 17:17:54 --> Utf8 Class Initialized
INFO - 2017-03-06 17:17:54 --> URI Class Initialized
DEBUG - 2017-03-06 17:17:54 --> No URI present. Default controller set.
INFO - 2017-03-06 17:17:54 --> Router Class Initialized
INFO - 2017-03-06 17:17:55 --> Output Class Initialized
INFO - 2017-03-06 17:17:55 --> Security Class Initialized
DEBUG - 2017-03-06 17:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 17:17:55 --> Input Class Initialized
INFO - 2017-03-06 17:17:55 --> Language Class Initialized
INFO - 2017-03-06 17:17:55 --> Loader Class Initialized
INFO - 2017-03-06 17:17:55 --> Database Driver Class Initialized
INFO - 2017-03-06 17:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 17:17:58 --> Controller Class Initialized
INFO - 2017-03-06 17:17:58 --> Helper loaded: url_helper
DEBUG - 2017-03-06 17:17:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 17:17:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 17:17:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 17:18:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 17:18:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 17:18:15 --> Config Class Initialized
INFO - 2017-03-06 17:18:15 --> Hooks Class Initialized
DEBUG - 2017-03-06 17:18:15 --> UTF-8 Support Enabled
INFO - 2017-03-06 17:18:15 --> Utf8 Class Initialized
INFO - 2017-03-06 17:18:15 --> URI Class Initialized
INFO - 2017-03-06 17:18:15 --> Config Class Initialized
INFO - 2017-03-06 17:18:15 --> Hooks Class Initialized
DEBUG - 2017-03-06 17:18:15 --> UTF-8 Support Enabled
INFO - 2017-03-06 17:18:15 --> Utf8 Class Initialized
INFO - 2017-03-06 17:18:15 --> URI Class Initialized
DEBUG - 2017-03-06 17:18:16 --> No URI present. Default controller set.
INFO - 2017-03-06 17:18:16 --> Router Class Initialized
DEBUG - 2017-03-06 17:18:16 --> No URI present. Default controller set.
INFO - 2017-03-06 17:18:16 --> Router Class Initialized
INFO - 2017-03-06 17:18:16 --> Output Class Initialized
INFO - 2017-03-06 17:18:16 --> Output Class Initialized
INFO - 2017-03-06 17:18:16 --> Security Class Initialized
DEBUG - 2017-03-06 17:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 17:18:16 --> Input Class Initialized
INFO - 2017-03-06 17:18:16 --> Security Class Initialized
INFO - 2017-03-06 17:18:16 --> Language Class Initialized
DEBUG - 2017-03-06 17:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 17:18:16 --> Input Class Initialized
INFO - 2017-03-06 17:18:16 --> Loader Class Initialized
INFO - 2017-03-06 17:18:16 --> Language Class Initialized
INFO - 2017-03-06 17:18:16 --> Loader Class Initialized
INFO - 2017-03-06 17:18:16 --> Database Driver Class Initialized
INFO - 2017-03-06 17:18:16 --> Database Driver Class Initialized
INFO - 2017-03-06 17:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 17:18:17 --> Controller Class Initialized
INFO - 2017-03-06 17:18:17 --> Helper loaded: url_helper
INFO - 2017-03-06 17:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 17:18:17 --> Controller Class Initialized
INFO - 2017-03-06 17:18:17 --> Helper loaded: url_helper
DEBUG - 2017-03-06 17:18:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-06 17:18:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 17:18:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 17:18:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 17:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 17:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 17:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 17:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 17:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 17:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 17:18:18 --> Final output sent to browser
DEBUG - 2017-03-06 17:18:18 --> Total execution time: 3.3550
INFO - 2017-03-06 17:18:18 --> Final output sent to browser
DEBUG - 2017-03-06 17:18:18 --> Total execution time: 3.3548
INFO - 2017-03-06 17:18:33 --> Config Class Initialized
INFO - 2017-03-06 17:18:33 --> Hooks Class Initialized
DEBUG - 2017-03-06 17:18:33 --> UTF-8 Support Enabled
INFO - 2017-03-06 17:18:33 --> Utf8 Class Initialized
INFO - 2017-03-06 17:18:33 --> URI Class Initialized
DEBUG - 2017-03-06 17:18:33 --> No URI present. Default controller set.
INFO - 2017-03-06 17:18:33 --> Router Class Initialized
INFO - 2017-03-06 17:18:33 --> Output Class Initialized
INFO - 2017-03-06 17:18:33 --> Security Class Initialized
DEBUG - 2017-03-06 17:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 17:18:33 --> Input Class Initialized
INFO - 2017-03-06 17:18:33 --> Language Class Initialized
INFO - 2017-03-06 17:18:33 --> Loader Class Initialized
INFO - 2017-03-06 17:18:34 --> Database Driver Class Initialized
INFO - 2017-03-06 17:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 17:18:34 --> Controller Class Initialized
INFO - 2017-03-06 17:18:34 --> Helper loaded: url_helper
DEBUG - 2017-03-06 17:18:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 17:18:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 17:18:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 17:18:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 17:18:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 17:18:34 --> Final output sent to browser
DEBUG - 2017-03-06 17:18:34 --> Total execution time: 1.7997
INFO - 2017-03-06 17:19:05 --> Config Class Initialized
INFO - 2017-03-06 17:19:05 --> Hooks Class Initialized
DEBUG - 2017-03-06 17:19:05 --> UTF-8 Support Enabled
INFO - 2017-03-06 17:19:05 --> Utf8 Class Initialized
INFO - 2017-03-06 17:19:05 --> URI Class Initialized
INFO - 2017-03-06 17:19:05 --> Router Class Initialized
INFO - 2017-03-06 17:19:06 --> Output Class Initialized
INFO - 2017-03-06 17:19:06 --> Security Class Initialized
DEBUG - 2017-03-06 17:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 17:19:06 --> Input Class Initialized
INFO - 2017-03-06 17:19:06 --> Language Class Initialized
INFO - 2017-03-06 17:19:06 --> Loader Class Initialized
INFO - 2017-03-06 17:19:06 --> Database Driver Class Initialized
INFO - 2017-03-06 17:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 17:19:06 --> Controller Class Initialized
INFO - 2017-03-06 17:19:06 --> Helper loaded: url_helper
DEBUG - 2017-03-06 17:19:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 17:19:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 17:19:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 17:19:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 17:19:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 17:19:07 --> Final output sent to browser
DEBUG - 2017-03-06 17:19:07 --> Total execution time: 11.4545
INFO - 2017-03-06 17:19:31 --> Config Class Initialized
INFO - 2017-03-06 17:19:31 --> Hooks Class Initialized
DEBUG - 2017-03-06 17:19:32 --> UTF-8 Support Enabled
INFO - 2017-03-06 17:19:32 --> Utf8 Class Initialized
INFO - 2017-03-06 17:19:32 --> URI Class Initialized
INFO - 2017-03-06 17:19:32 --> Router Class Initialized
INFO - 2017-03-06 17:19:32 --> Output Class Initialized
INFO - 2017-03-06 17:19:32 --> Security Class Initialized
DEBUG - 2017-03-06 17:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 17:19:32 --> Input Class Initialized
INFO - 2017-03-06 17:19:32 --> Language Class Initialized
INFO - 2017-03-06 17:19:32 --> Loader Class Initialized
INFO - 2017-03-06 17:19:32 --> Database Driver Class Initialized
INFO - 2017-03-06 17:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 17:19:32 --> Controller Class Initialized
INFO - 2017-03-06 17:19:32 --> Helper loaded: url_helper
DEBUG - 2017-03-06 17:19:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 17:19:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-06 17:19:44 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-06 17:19:44 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-06 17:19:44 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-06 17:19:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 17:19:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 17:19:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 17:19:44 --> Final output sent to browser
DEBUG - 2017-03-06 17:19:44 --> Total execution time: 18.8157
INFO - 2017-03-06 17:20:05 --> Config Class Initialized
INFO - 2017-03-06 17:20:06 --> Hooks Class Initialized
DEBUG - 2017-03-06 17:20:06 --> UTF-8 Support Enabled
INFO - 2017-03-06 17:20:06 --> Utf8 Class Initialized
INFO - 2017-03-06 17:20:06 --> URI Class Initialized
INFO - 2017-03-06 17:20:06 --> Router Class Initialized
INFO - 2017-03-06 17:20:06 --> Output Class Initialized
INFO - 2017-03-06 17:20:06 --> Security Class Initialized
DEBUG - 2017-03-06 17:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 17:20:06 --> Input Class Initialized
INFO - 2017-03-06 17:20:06 --> Language Class Initialized
INFO - 2017-03-06 17:20:06 --> Loader Class Initialized
INFO - 2017-03-06 17:20:07 --> Database Driver Class Initialized
INFO - 2017-03-06 17:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 17:20:07 --> Controller Class Initialized
INFO - 2017-03-06 17:20:07 --> Helper loaded: url_helper
DEBUG - 2017-03-06 17:20:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 17:20:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 17:20:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 17:20:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 17:20:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 17:20:07 --> Final output sent to browser
DEBUG - 2017-03-06 17:20:07 --> Total execution time: 5.3722
INFO - 2017-03-06 17:22:50 --> Config Class Initialized
INFO - 2017-03-06 17:22:50 --> Hooks Class Initialized
DEBUG - 2017-03-06 17:22:50 --> UTF-8 Support Enabled
INFO - 2017-03-06 17:22:50 --> Utf8 Class Initialized
INFO - 2017-03-06 17:22:50 --> URI Class Initialized
INFO - 2017-03-06 17:22:50 --> Router Class Initialized
INFO - 2017-03-06 17:22:51 --> Output Class Initialized
INFO - 2017-03-06 17:22:51 --> Security Class Initialized
DEBUG - 2017-03-06 17:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 17:22:51 --> Input Class Initialized
INFO - 2017-03-06 17:22:51 --> Language Class Initialized
INFO - 2017-03-06 17:22:51 --> Loader Class Initialized
INFO - 2017-03-06 17:22:51 --> Database Driver Class Initialized
INFO - 2017-03-06 17:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 17:22:55 --> Controller Class Initialized
INFO - 2017-03-06 17:22:55 --> Config Class Initialized
INFO - 2017-03-06 17:22:55 --> Hooks Class Initialized
INFO - 2017-03-06 17:22:55 --> Helper loaded: url_helper
DEBUG - 2017-03-06 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-06 17:22:55 --> UTF-8 Support Enabled
INFO - 2017-03-06 17:22:55 --> Utf8 Class Initialized
INFO - 2017-03-06 17:22:55 --> URI Class Initialized
INFO - 2017-03-06 17:22:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 17:22:56 --> Router Class Initialized
ERROR - 2017-03-06 17:22:56 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
INFO - 2017-03-06 17:22:56 --> Output Class Initialized
ERROR - 2017-03-06 17:22:56 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-06 17:22:56 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-06 17:22:56 --> Security Class Initialized
INFO - 2017-03-06 17:22:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
DEBUG - 2017-03-06 17:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 17:22:56 --> Input Class Initialized
INFO - 2017-03-06 17:22:56 --> Language Class Initialized
INFO - 2017-03-06 17:22:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 17:22:56 --> Loader Class Initialized
INFO - 2017-03-06 17:22:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 17:22:57 --> Database Driver Class Initialized
INFO - 2017-03-06 17:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 17:22:58 --> Controller Class Initialized
INFO - 2017-03-06 17:22:58 --> Helper loaded: url_helper
DEBUG - 2017-03-06 17:22:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 17:22:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 17:22:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 17:22:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 17:22:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 17:22:59 --> Final output sent to browser
DEBUG - 2017-03-06 17:22:59 --> Total execution time: 5.2054
INFO - 2017-03-06 17:22:59 --> Final output sent to browser
DEBUG - 2017-03-06 17:22:59 --> Total execution time: 6.8997
INFO - 2017-03-06 17:23:01 --> Config Class Initialized
INFO - 2017-03-06 17:23:01 --> Hooks Class Initialized
DEBUG - 2017-03-06 17:23:02 --> UTF-8 Support Enabled
INFO - 2017-03-06 17:23:02 --> Utf8 Class Initialized
INFO - 2017-03-06 17:23:02 --> URI Class Initialized
DEBUG - 2017-03-06 17:23:02 --> No URI present. Default controller set.
INFO - 2017-03-06 17:23:02 --> Router Class Initialized
INFO - 2017-03-06 17:23:02 --> Output Class Initialized
INFO - 2017-03-06 17:23:02 --> Security Class Initialized
DEBUG - 2017-03-06 17:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 17:23:02 --> Input Class Initialized
INFO - 2017-03-06 17:23:03 --> Language Class Initialized
INFO - 2017-03-06 17:23:03 --> Loader Class Initialized
INFO - 2017-03-06 17:23:03 --> Database Driver Class Initialized
INFO - 2017-03-06 17:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 17:23:04 --> Controller Class Initialized
INFO - 2017-03-06 17:23:04 --> Helper loaded: url_helper
DEBUG - 2017-03-06 17:23:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 17:23:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 17:23:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 17:23:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 17:23:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 17:23:04 --> Final output sent to browser
DEBUG - 2017-03-06 17:23:04 --> Total execution time: 5.7253
INFO - 2017-03-06 17:24:13 --> Config Class Initialized
INFO - 2017-03-06 17:24:13 --> Hooks Class Initialized
DEBUG - 2017-03-06 17:24:14 --> UTF-8 Support Enabled
INFO - 2017-03-06 17:24:14 --> Utf8 Class Initialized
INFO - 2017-03-06 17:24:14 --> URI Class Initialized
INFO - 2017-03-06 17:24:14 --> Router Class Initialized
INFO - 2017-03-06 17:24:14 --> Output Class Initialized
INFO - 2017-03-06 17:24:14 --> Security Class Initialized
DEBUG - 2017-03-06 17:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 17:24:14 --> Input Class Initialized
INFO - 2017-03-06 17:24:14 --> Language Class Initialized
INFO - 2017-03-06 17:24:14 --> Loader Class Initialized
INFO - 2017-03-06 17:24:15 --> Database Driver Class Initialized
INFO - 2017-03-06 17:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 17:24:18 --> Controller Class Initialized
INFO - 2017-03-06 17:24:18 --> Helper loaded: url_helper
DEBUG - 2017-03-06 17:24:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 17:24:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-06 17:24:21 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-06 17:24:21 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-06 17:24:21 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-06 17:24:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 17:24:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 17:24:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 17:24:23 --> Final output sent to browser
DEBUG - 2017-03-06 17:24:23 --> Total execution time: 15.1311
INFO - 2017-03-06 17:24:24 --> Config Class Initialized
INFO - 2017-03-06 17:24:24 --> Hooks Class Initialized
DEBUG - 2017-03-06 17:24:25 --> UTF-8 Support Enabled
INFO - 2017-03-06 17:24:25 --> Utf8 Class Initialized
INFO - 2017-03-06 17:24:26 --> URI Class Initialized
DEBUG - 2017-03-06 17:24:28 --> No URI present. Default controller set.
INFO - 2017-03-06 17:24:28 --> Router Class Initialized
INFO - 2017-03-06 17:24:29 --> Output Class Initialized
INFO - 2017-03-06 17:24:30 --> Security Class Initialized
DEBUG - 2017-03-06 17:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 17:24:30 --> Input Class Initialized
INFO - 2017-03-06 17:24:30 --> Language Class Initialized
INFO - 2017-03-06 17:24:30 --> Loader Class Initialized
INFO - 2017-03-06 17:24:31 --> Database Driver Class Initialized
INFO - 2017-03-06 17:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 17:24:39 --> Controller Class Initialized
INFO - 2017-03-06 17:24:39 --> Helper loaded: url_helper
DEBUG - 2017-03-06 17:24:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 17:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 17:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 17:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 17:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 17:24:41 --> Final output sent to browser
DEBUG - 2017-03-06 17:24:41 --> Total execution time: 18.6019
INFO - 2017-03-06 18:45:45 --> Config Class Initialized
INFO - 2017-03-06 18:45:45 --> Hooks Class Initialized
DEBUG - 2017-03-06 18:45:46 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:45:46 --> Utf8 Class Initialized
INFO - 2017-03-06 18:45:47 --> URI Class Initialized
DEBUG - 2017-03-06 18:45:47 --> No URI present. Default controller set.
INFO - 2017-03-06 18:45:47 --> Router Class Initialized
INFO - 2017-03-06 18:45:47 --> Output Class Initialized
INFO - 2017-03-06 18:45:47 --> Security Class Initialized
DEBUG - 2017-03-06 18:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:45:47 --> Input Class Initialized
INFO - 2017-03-06 18:45:47 --> Language Class Initialized
INFO - 2017-03-06 18:45:48 --> Loader Class Initialized
INFO - 2017-03-06 18:45:48 --> Database Driver Class Initialized
INFO - 2017-03-06 18:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:45:49 --> Controller Class Initialized
INFO - 2017-03-06 18:45:49 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:45:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 18:45:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 18:45:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 18:45:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 18:45:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 18:45:49 --> Final output sent to browser
DEBUG - 2017-03-06 18:45:49 --> Total execution time: 4.5382
INFO - 2017-03-06 18:46:01 --> Config Class Initialized
INFO - 2017-03-06 18:46:01 --> Hooks Class Initialized
DEBUG - 2017-03-06 18:46:03 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:46:03 --> Utf8 Class Initialized
INFO - 2017-03-06 18:46:04 --> URI Class Initialized
DEBUG - 2017-03-06 18:46:04 --> No URI present. Default controller set.
INFO - 2017-03-06 18:46:04 --> Router Class Initialized
INFO - 2017-03-06 18:46:04 --> Output Class Initialized
INFO - 2017-03-06 18:46:04 --> Security Class Initialized
DEBUG - 2017-03-06 18:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:46:05 --> Input Class Initialized
INFO - 2017-03-06 18:46:05 --> Language Class Initialized
INFO - 2017-03-06 18:46:05 --> Loader Class Initialized
INFO - 2017-03-06 18:46:06 --> Database Driver Class Initialized
INFO - 2017-03-06 18:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:46:10 --> Controller Class Initialized
INFO - 2017-03-06 18:46:11 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:46:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 18:46:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 18:46:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 18:46:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 18:46:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 18:46:12 --> Final output sent to browser
DEBUG - 2017-03-06 18:46:12 --> Total execution time: 18.2621
INFO - 2017-03-06 18:46:26 --> Config Class Initialized
INFO - 2017-03-06 18:46:26 --> Hooks Class Initialized
DEBUG - 2017-03-06 18:46:26 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:46:26 --> Utf8 Class Initialized
INFO - 2017-03-06 18:46:26 --> URI Class Initialized
INFO - 2017-03-06 18:46:26 --> Router Class Initialized
INFO - 2017-03-06 18:46:26 --> Output Class Initialized
INFO - 2017-03-06 18:46:26 --> Security Class Initialized
DEBUG - 2017-03-06 18:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:46:26 --> Input Class Initialized
INFO - 2017-03-06 18:46:26 --> Language Class Initialized
INFO - 2017-03-06 18:46:26 --> Loader Class Initialized
INFO - 2017-03-06 18:46:27 --> Database Driver Class Initialized
INFO - 2017-03-06 18:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:46:27 --> Controller Class Initialized
INFO - 2017-03-06 18:46:27 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:46:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 18:46:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 18:46:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 18:46:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 18:46:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 18:46:28 --> Final output sent to browser
DEBUG - 2017-03-06 18:46:28 --> Total execution time: 2.0045
INFO - 2017-03-06 18:46:33 --> Config Class Initialized
INFO - 2017-03-06 18:46:34 --> Hooks Class Initialized
DEBUG - 2017-03-06 18:46:39 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:46:39 --> Utf8 Class Initialized
INFO - 2017-03-06 18:46:40 --> URI Class Initialized
INFO - 2017-03-06 18:46:40 --> Router Class Initialized
INFO - 2017-03-06 18:46:40 --> Output Class Initialized
INFO - 2017-03-06 18:46:40 --> Security Class Initialized
DEBUG - 2017-03-06 18:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:46:40 --> Input Class Initialized
INFO - 2017-03-06 18:46:41 --> Language Class Initialized
INFO - 2017-03-06 18:46:41 --> Loader Class Initialized
INFO - 2017-03-06 18:46:41 --> Database Driver Class Initialized
INFO - 2017-03-06 18:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:46:44 --> Controller Class Initialized
INFO - 2017-03-06 18:46:44 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:46:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 18:46:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-06 18:46:45 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-06 18:46:45 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-06 18:46:45 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-06 18:46:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 18:46:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 18:46:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 18:46:47 --> Final output sent to browser
DEBUG - 2017-03-06 18:46:47 --> Total execution time: 17.9828
INFO - 2017-03-06 18:47:13 --> Config Class Initialized
INFO - 2017-03-06 18:47:13 --> Hooks Class Initialized
DEBUG - 2017-03-06 18:47:13 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:47:13 --> Utf8 Class Initialized
INFO - 2017-03-06 18:47:13 --> URI Class Initialized
INFO - 2017-03-06 18:47:13 --> Router Class Initialized
INFO - 2017-03-06 18:47:13 --> Output Class Initialized
INFO - 2017-03-06 18:47:14 --> Security Class Initialized
DEBUG - 2017-03-06 18:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:47:14 --> Input Class Initialized
INFO - 2017-03-06 18:47:14 --> Language Class Initialized
INFO - 2017-03-06 18:47:14 --> Loader Class Initialized
INFO - 2017-03-06 18:47:14 --> Database Driver Class Initialized
INFO - 2017-03-06 18:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:47:16 --> Controller Class Initialized
INFO - 2017-03-06 18:47:17 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:47:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 18:47:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-06 18:47:18 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-06 18:47:18 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-06 18:47:18 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-06 18:47:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 18:47:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 18:47:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 18:47:18 --> Final output sent to browser
DEBUG - 2017-03-06 18:47:18 --> Total execution time: 5.3293
INFO - 2017-03-06 18:48:21 --> Config Class Initialized
INFO - 2017-03-06 18:48:21 --> Config Class Initialized
INFO - 2017-03-06 18:48:21 --> Hooks Class Initialized
INFO - 2017-03-06 18:48:21 --> Hooks Class Initialized
DEBUG - 2017-03-06 18:48:21 --> UTF-8 Support Enabled
DEBUG - 2017-03-06 18:48:21 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:48:21 --> Utf8 Class Initialized
INFO - 2017-03-06 18:48:21 --> Utf8 Class Initialized
INFO - 2017-03-06 18:48:21 --> URI Class Initialized
INFO - 2017-03-06 18:48:21 --> URI Class Initialized
INFO - 2017-03-06 18:48:21 --> Router Class Initialized
INFO - 2017-03-06 18:48:21 --> Router Class Initialized
INFO - 2017-03-06 18:48:21 --> Output Class Initialized
INFO - 2017-03-06 18:48:21 --> Output Class Initialized
INFO - 2017-03-06 18:48:21 --> Security Class Initialized
INFO - 2017-03-06 18:48:21 --> Security Class Initialized
DEBUG - 2017-03-06 18:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-03-06 18:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:48:21 --> Input Class Initialized
INFO - 2017-03-06 18:48:21 --> Input Class Initialized
INFO - 2017-03-06 18:48:21 --> Language Class Initialized
INFO - 2017-03-06 18:48:21 --> Language Class Initialized
INFO - 2017-03-06 18:48:21 --> Loader Class Initialized
INFO - 2017-03-06 18:48:21 --> Loader Class Initialized
INFO - 2017-03-06 18:48:22 --> Database Driver Class Initialized
INFO - 2017-03-06 18:48:22 --> Database Driver Class Initialized
INFO - 2017-03-06 18:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:48:22 --> Controller Class Initialized
INFO - 2017-03-06 18:48:22 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:48:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 18:48:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 18:48:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 18:48:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 18:48:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 18:48:23 --> Final output sent to browser
DEBUG - 2017-03-06 18:48:23 --> Total execution time: 1.8028
INFO - 2017-03-06 18:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:48:23 --> Controller Class Initialized
INFO - 2017-03-06 18:48:23 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:48:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 18:48:25 --> Config Class Initialized
INFO - 2017-03-06 18:48:25 --> Hooks Class Initialized
DEBUG - 2017-03-06 18:48:25 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:48:25 --> Utf8 Class Initialized
INFO - 2017-03-06 18:48:25 --> URI Class Initialized
INFO - 2017-03-06 18:48:25 --> Router Class Initialized
INFO - 2017-03-06 18:48:25 --> Output Class Initialized
INFO - 2017-03-06 18:48:25 --> Security Class Initialized
DEBUG - 2017-03-06 18:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:48:25 --> Input Class Initialized
INFO - 2017-03-06 18:48:25 --> Language Class Initialized
INFO - 2017-03-06 18:48:25 --> Loader Class Initialized
INFO - 2017-03-06 18:48:25 --> Database Driver Class Initialized
INFO - 2017-03-06 18:48:25 --> Config Class Initialized
INFO - 2017-03-06 18:48:25 --> Hooks Class Initialized
DEBUG - 2017-03-06 18:48:25 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:48:25 --> Utf8 Class Initialized
INFO - 2017-03-06 18:48:25 --> Config Class Initialized
INFO - 2017-03-06 18:48:25 --> Hooks Class Initialized
DEBUG - 2017-03-06 18:48:25 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:48:25 --> Utf8 Class Initialized
INFO - 2017-03-06 18:48:25 --> URI Class Initialized
INFO - 2017-03-06 18:48:25 --> Router Class Initialized
INFO - 2017-03-06 18:48:25 --> Output Class Initialized
INFO - 2017-03-06 18:48:25 --> Security Class Initialized
DEBUG - 2017-03-06 18:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:48:25 --> Input Class Initialized
INFO - 2017-03-06 18:48:25 --> Language Class Initialized
INFO - 2017-03-06 18:48:25 --> Loader Class Initialized
INFO - 2017-03-06 18:48:25 --> Database Driver Class Initialized
INFO - 2017-03-06 18:48:25 --> URI Class Initialized
INFO - 2017-03-06 18:48:25 --> Router Class Initialized
INFO - 2017-03-06 18:48:25 --> Output Class Initialized
INFO - 2017-03-06 18:48:25 --> Security Class Initialized
DEBUG - 2017-03-06 18:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:48:25 --> Input Class Initialized
INFO - 2017-03-06 18:48:25 --> Language Class Initialized
INFO - 2017-03-06 18:48:25 --> Loader Class Initialized
INFO - 2017-03-06 18:48:25 --> Database Driver Class Initialized
INFO - 2017-03-06 18:48:26 --> Config Class Initialized
INFO - 2017-03-06 18:48:26 --> Hooks Class Initialized
DEBUG - 2017-03-06 18:48:26 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:48:26 --> Utf8 Class Initialized
INFO - 2017-03-06 18:48:26 --> URI Class Initialized
INFO - 2017-03-06 18:48:26 --> Router Class Initialized
INFO - 2017-03-06 18:48:26 --> Output Class Initialized
INFO - 2017-03-06 18:48:26 --> Security Class Initialized
DEBUG - 2017-03-06 18:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:48:27 --> Input Class Initialized
INFO - 2017-03-06 18:48:27 --> Language Class Initialized
INFO - 2017-03-06 18:48:27 --> Loader Class Initialized
INFO - 2017-03-06 18:48:27 --> Database Driver Class Initialized
INFO - 2017-03-06 18:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:48:27 --> Controller Class Initialized
INFO - 2017-03-06 18:48:27 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:48:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-06 18:48:56 --> Severity: error --> Exception: timed out before SSL handshake /home/graduafe/public_html/application/libraries/facebook-api-php-codexworld/base_facebook.php 972
INFO - 2017-03-06 18:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:48:57 --> Controller Class Initialized
INFO - 2017-03-06 18:48:59 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:49:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 18:49:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 18:49:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 18:49:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 18:49:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 18:49:07 --> Final output sent to browser
DEBUG - 2017-03-06 18:49:07 --> Total execution time: 43.0907
INFO - 2017-03-06 18:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:49:08 --> Controller Class Initialized
INFO - 2017-03-06 18:49:10 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:49:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 18:49:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 18:49:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 18:49:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 18:49:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 18:49:14 --> Final output sent to browser
DEBUG - 2017-03-06 18:49:15 --> Total execution time: 50.2060
INFO - 2017-03-06 18:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:49:16 --> Controller Class Initialized
INFO - 2017-03-06 18:49:17 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:49:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 18:49:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 18:49:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 18:49:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 18:49:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 18:49:18 --> Final output sent to browser
DEBUG - 2017-03-06 18:49:18 --> Total execution time: 52.6888
INFO - 2017-03-06 18:49:18 --> Config Class Initialized
INFO - 2017-03-06 18:49:18 --> Hooks Class Initialized
INFO - 2017-03-06 18:49:18 --> Config Class Initialized
INFO - 2017-03-06 18:49:18 --> Hooks Class Initialized
INFO - 2017-03-06 18:49:18 --> Config Class Initialized
INFO - 2017-03-06 18:49:18 --> Hooks Class Initialized
DEBUG - 2017-03-06 18:49:18 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:49:18 --> Utf8 Class Initialized
DEBUG - 2017-03-06 18:49:18 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:49:18 --> Utf8 Class Initialized
INFO - 2017-03-06 18:49:18 --> URI Class Initialized
DEBUG - 2017-03-06 18:49:18 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:49:18 --> Utf8 Class Initialized
INFO - 2017-03-06 18:49:18 --> URI Class Initialized
INFO - 2017-03-06 18:49:18 --> Config Class Initialized
INFO - 2017-03-06 18:49:18 --> Hooks Class Initialized
DEBUG - 2017-03-06 18:49:18 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:49:18 --> Utf8 Class Initialized
INFO - 2017-03-06 18:49:18 --> URI Class Initialized
INFO - 2017-03-06 18:49:18 --> Router Class Initialized
INFO - 2017-03-06 18:49:18 --> URI Class Initialized
INFO - 2017-03-06 18:49:18 --> Router Class Initialized
INFO - 2017-03-06 18:49:18 --> Router Class Initialized
INFO - 2017-03-06 18:49:18 --> Config Class Initialized
INFO - 2017-03-06 18:49:18 --> Hooks Class Initialized
DEBUG - 2017-03-06 18:49:18 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:49:18 --> Utf8 Class Initialized
INFO - 2017-03-06 18:49:18 --> URI Class Initialized
INFO - 2017-03-06 18:49:18 --> Router Class Initialized
INFO - 2017-03-06 18:49:18 --> Router Class Initialized
INFO - 2017-03-06 18:49:18 --> Output Class Initialized
INFO - 2017-03-06 18:49:18 --> Security Class Initialized
INFO - 2017-03-06 18:49:18 --> Output Class Initialized
DEBUG - 2017-03-06 18:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:49:18 --> Input Class Initialized
INFO - 2017-03-06 18:49:18 --> Output Class Initialized
INFO - 2017-03-06 18:49:18 --> Language Class Initialized
INFO - 2017-03-06 18:49:18 --> Output Class Initialized
INFO - 2017-03-06 18:49:18 --> Output Class Initialized
INFO - 2017-03-06 18:49:18 --> Security Class Initialized
INFO - 2017-03-06 18:49:18 --> Security Class Initialized
DEBUG - 2017-03-06 18:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:49:18 --> Input Class Initialized
DEBUG - 2017-03-06 18:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:49:18 --> Input Class Initialized
INFO - 2017-03-06 18:49:18 --> Language Class Initialized
INFO - 2017-03-06 18:49:18 --> Language Class Initialized
INFO - 2017-03-06 18:49:18 --> Security Class Initialized
DEBUG - 2017-03-06 18:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:49:18 --> Input Class Initialized
INFO - 2017-03-06 18:49:18 --> Language Class Initialized
INFO - 2017-03-06 18:49:18 --> Security Class Initialized
DEBUG - 2017-03-06 18:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:49:18 --> Input Class Initialized
INFO - 2017-03-06 18:49:18 --> Language Class Initialized
INFO - 2017-03-06 18:49:18 --> Loader Class Initialized
INFO - 2017-03-06 18:49:19 --> Loader Class Initialized
INFO - 2017-03-06 18:49:19 --> Loader Class Initialized
INFO - 2017-03-06 18:49:19 --> Loader Class Initialized
INFO - 2017-03-06 18:49:19 --> Loader Class Initialized
INFO - 2017-03-06 18:49:19 --> Database Driver Class Initialized
INFO - 2017-03-06 18:49:19 --> Database Driver Class Initialized
INFO - 2017-03-06 18:49:19 --> Database Driver Class Initialized
INFO - 2017-03-06 18:49:19 --> Database Driver Class Initialized
INFO - 2017-03-06 18:49:19 --> Database Driver Class Initialized
INFO - 2017-03-06 18:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:49:19 --> Controller Class Initialized
INFO - 2017-03-06 18:49:19 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:49:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 18:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:49:25 --> Controller Class Initialized
INFO - 2017-03-06 18:49:25 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:49:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 18:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:49:30 --> Controller Class Initialized
INFO - 2017-03-06 18:49:30 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:49:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 18:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 18:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 18:49:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 18:49:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 18:49:31 --> Final output sent to browser
DEBUG - 2017-03-06 18:49:31 --> Total execution time: 12.8071
INFO - 2017-03-06 18:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:49:33 --> Controller Class Initialized
INFO - 2017-03-06 18:49:33 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:49:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 18:49:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 18:49:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 18:49:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 18:49:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 18:49:33 --> Final output sent to browser
DEBUG - 2017-03-06 18:49:33 --> Total execution time: 15.4730
INFO - 2017-03-06 18:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:49:33 --> Controller Class Initialized
INFO - 2017-03-06 18:49:33 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:49:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 18:49:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 18:49:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 18:49:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 18:49:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 18:49:34 --> Final output sent to browser
DEBUG - 2017-03-06 18:49:35 --> Total execution time: 15.9298
INFO - 2017-03-06 18:50:02 --> Config Class Initialized
INFO - 2017-03-06 18:50:02 --> Hooks Class Initialized
DEBUG - 2017-03-06 18:50:02 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:50:02 --> Utf8 Class Initialized
INFO - 2017-03-06 18:50:02 --> URI Class Initialized
INFO - 2017-03-06 18:50:02 --> Router Class Initialized
INFO - 2017-03-06 18:50:02 --> Output Class Initialized
INFO - 2017-03-06 18:50:02 --> Security Class Initialized
DEBUG - 2017-03-06 18:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:50:02 --> Input Class Initialized
INFO - 2017-03-06 18:50:02 --> Language Class Initialized
INFO - 2017-03-06 18:50:02 --> Loader Class Initialized
INFO - 2017-03-06 18:50:03 --> Database Driver Class Initialized
INFO - 2017-03-06 18:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:50:03 --> Controller Class Initialized
INFO - 2017-03-06 18:50:03 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 18:50:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 18:50:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 18:50:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 18:50:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 18:50:03 --> Final output sent to browser
DEBUG - 2017-03-06 18:50:03 --> Total execution time: 1.7043
INFO - 2017-03-06 18:58:26 --> Config Class Initialized
INFO - 2017-03-06 18:58:26 --> Hooks Class Initialized
DEBUG - 2017-03-06 18:58:26 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:58:26 --> Utf8 Class Initialized
INFO - 2017-03-06 18:58:26 --> URI Class Initialized
INFO - 2017-03-06 18:58:26 --> Router Class Initialized
INFO - 2017-03-06 18:58:26 --> Output Class Initialized
INFO - 2017-03-06 18:58:26 --> Security Class Initialized
DEBUG - 2017-03-06 18:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:58:26 --> Input Class Initialized
INFO - 2017-03-06 18:58:26 --> Language Class Initialized
INFO - 2017-03-06 18:58:26 --> Loader Class Initialized
INFO - 2017-03-06 18:58:26 --> Database Driver Class Initialized
INFO - 2017-03-06 18:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:58:27 --> Controller Class Initialized
INFO - 2017-03-06 18:58:27 --> Helper loaded: date_helper
DEBUG - 2017-03-06 18:58:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 18:58:27 --> Helper loaded: url_helper
INFO - 2017-03-06 18:58:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 18:58:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-06 18:58:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-06 18:58:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-06 18:58:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 18:58:27 --> Final output sent to browser
DEBUG - 2017-03-06 18:58:27 --> Total execution time: 1.8002
INFO - 2017-03-06 18:59:06 --> Config Class Initialized
INFO - 2017-03-06 18:59:06 --> Hooks Class Initialized
DEBUG - 2017-03-06 18:59:06 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:59:06 --> Utf8 Class Initialized
INFO - 2017-03-06 18:59:06 --> URI Class Initialized
DEBUG - 2017-03-06 18:59:06 --> No URI present. Default controller set.
INFO - 2017-03-06 18:59:06 --> Router Class Initialized
INFO - 2017-03-06 18:59:06 --> Output Class Initialized
INFO - 2017-03-06 18:59:06 --> Security Class Initialized
DEBUG - 2017-03-06 18:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:59:06 --> Input Class Initialized
INFO - 2017-03-06 18:59:06 --> Language Class Initialized
INFO - 2017-03-06 18:59:06 --> Loader Class Initialized
INFO - 2017-03-06 18:59:07 --> Database Driver Class Initialized
INFO - 2017-03-06 18:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:59:07 --> Controller Class Initialized
INFO - 2017-03-06 18:59:07 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:59:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 18:59:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 18:59:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 18:59:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 18:59:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 18:59:07 --> Final output sent to browser
DEBUG - 2017-03-06 18:59:07 --> Total execution time: 1.2461
INFO - 2017-03-06 18:59:20 --> Config Class Initialized
INFO - 2017-03-06 18:59:20 --> Hooks Class Initialized
DEBUG - 2017-03-06 18:59:20 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:59:20 --> Utf8 Class Initialized
INFO - 2017-03-06 18:59:20 --> URI Class Initialized
INFO - 2017-03-06 18:59:20 --> Router Class Initialized
INFO - 2017-03-06 18:59:20 --> Output Class Initialized
INFO - 2017-03-06 18:59:20 --> Security Class Initialized
DEBUG - 2017-03-06 18:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:59:20 --> Input Class Initialized
INFO - 2017-03-06 18:59:20 --> Language Class Initialized
INFO - 2017-03-06 18:59:20 --> Loader Class Initialized
INFO - 2017-03-06 18:59:21 --> Database Driver Class Initialized
INFO - 2017-03-06 18:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:59:21 --> Controller Class Initialized
INFO - 2017-03-06 18:59:21 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:59:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 18:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 18:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 18:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 18:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 18:59:21 --> Final output sent to browser
DEBUG - 2017-03-06 18:59:21 --> Total execution time: 1.2432
INFO - 2017-03-06 18:59:47 --> Config Class Initialized
INFO - 2017-03-06 18:59:47 --> Hooks Class Initialized
DEBUG - 2017-03-06 18:59:48 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:59:48 --> Utf8 Class Initialized
INFO - 2017-03-06 18:59:48 --> URI Class Initialized
INFO - 2017-03-06 18:59:48 --> Router Class Initialized
INFO - 2017-03-06 18:59:48 --> Output Class Initialized
INFO - 2017-03-06 18:59:48 --> Security Class Initialized
DEBUG - 2017-03-06 18:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:59:48 --> Input Class Initialized
INFO - 2017-03-06 18:59:48 --> Language Class Initialized
INFO - 2017-03-06 18:59:48 --> Loader Class Initialized
INFO - 2017-03-06 18:59:48 --> Database Driver Class Initialized
INFO - 2017-03-06 18:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:59:48 --> Controller Class Initialized
INFO - 2017-03-06 18:59:48 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:59:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-06 18:59:52 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-06 18:59:52 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Juhan Antonio')
INFO - 2017-03-06 18:59:52 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-06 18:59:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-06 18:59:52 --> Config Class Initialized
INFO - 2017-03-06 18:59:52 --> Hooks Class Initialized
DEBUG - 2017-03-06 18:59:52 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:59:52 --> Utf8 Class Initialized
INFO - 2017-03-06 18:59:52 --> URI Class Initialized
INFO - 2017-03-06 18:59:52 --> Router Class Initialized
INFO - 2017-03-06 18:59:52 --> Output Class Initialized
INFO - 2017-03-06 18:59:52 --> Security Class Initialized
DEBUG - 2017-03-06 18:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:59:52 --> Input Class Initialized
INFO - 2017-03-06 18:59:52 --> Language Class Initialized
INFO - 2017-03-06 18:59:52 --> Loader Class Initialized
INFO - 2017-03-06 18:59:52 --> Database Driver Class Initialized
INFO - 2017-03-06 18:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:59:52 --> Controller Class Initialized
INFO - 2017-03-06 18:59:52 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:59:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 18:59:52 --> Config Class Initialized
INFO - 2017-03-06 18:59:52 --> Hooks Class Initialized
DEBUG - 2017-03-06 18:59:52 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:59:52 --> Utf8 Class Initialized
INFO - 2017-03-06 18:59:52 --> URI Class Initialized
INFO - 2017-03-06 18:59:52 --> Router Class Initialized
INFO - 2017-03-06 18:59:52 --> Output Class Initialized
INFO - 2017-03-06 18:59:52 --> Security Class Initialized
DEBUG - 2017-03-06 18:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:59:52 --> Input Class Initialized
INFO - 2017-03-06 18:59:52 --> Language Class Initialized
INFO - 2017-03-06 18:59:52 --> Loader Class Initialized
INFO - 2017-03-06 18:59:52 --> Database Driver Class Initialized
ERROR - 2017-03-06 18:59:53 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-06 18:59:53 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Juhan Antonio')
INFO - 2017-03-06 18:59:53 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-06 18:59:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-06 18:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:59:53 --> Controller Class Initialized
INFO - 2017-03-06 18:59:53 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:59:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 18:59:53 --> Config Class Initialized
INFO - 2017-03-06 18:59:53 --> Hooks Class Initialized
DEBUG - 2017-03-06 18:59:53 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:59:53 --> Utf8 Class Initialized
INFO - 2017-03-06 18:59:53 --> URI Class Initialized
INFO - 2017-03-06 18:59:53 --> Router Class Initialized
INFO - 2017-03-06 18:59:53 --> Output Class Initialized
INFO - 2017-03-06 18:59:53 --> Security Class Initialized
DEBUG - 2017-03-06 18:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:59:53 --> Input Class Initialized
INFO - 2017-03-06 18:59:53 --> Language Class Initialized
INFO - 2017-03-06 18:59:53 --> Loader Class Initialized
INFO - 2017-03-06 18:59:53 --> Database Driver Class Initialized
ERROR - 2017-03-06 18:59:53 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-06 18:59:53 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Juhan Antonio')
INFO - 2017-03-06 18:59:53 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-06 18:59:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-06 18:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:59:53 --> Controller Class Initialized
INFO - 2017-03-06 18:59:53 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:59:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-06 18:59:53 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-06 18:59:53 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Juhan Antonio')
INFO - 2017-03-06 18:59:53 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-06 18:59:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-06 18:59:55 --> Config Class Initialized
INFO - 2017-03-06 18:59:55 --> Hooks Class Initialized
DEBUG - 2017-03-06 18:59:55 --> UTF-8 Support Enabled
INFO - 2017-03-06 18:59:55 --> Utf8 Class Initialized
INFO - 2017-03-06 18:59:55 --> URI Class Initialized
INFO - 2017-03-06 18:59:55 --> Router Class Initialized
INFO - 2017-03-06 18:59:55 --> Output Class Initialized
INFO - 2017-03-06 18:59:55 --> Security Class Initialized
DEBUG - 2017-03-06 18:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 18:59:55 --> Input Class Initialized
INFO - 2017-03-06 18:59:55 --> Language Class Initialized
INFO - 2017-03-06 18:59:55 --> Loader Class Initialized
INFO - 2017-03-06 18:59:55 --> Database Driver Class Initialized
INFO - 2017-03-06 18:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 18:59:55 --> Controller Class Initialized
INFO - 2017-03-06 18:59:55 --> Helper loaded: url_helper
DEBUG - 2017-03-06 18:59:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-06 19:00:18 --> Severity: error --> Exception: timed out before SSL handshake /home/graduafe/public_html/application/libraries/facebook-api-php-codexworld/base_facebook.php 972
INFO - 2017-03-06 19:00:29 --> Config Class Initialized
INFO - 2017-03-06 19:00:29 --> Hooks Class Initialized
DEBUG - 2017-03-06 19:00:29 --> UTF-8 Support Enabled
INFO - 2017-03-06 19:00:29 --> Utf8 Class Initialized
INFO - 2017-03-06 19:00:29 --> URI Class Initialized
INFO - 2017-03-06 19:00:29 --> Router Class Initialized
INFO - 2017-03-06 19:00:29 --> Output Class Initialized
INFO - 2017-03-06 19:00:29 --> Security Class Initialized
DEBUG - 2017-03-06 19:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 19:00:29 --> Input Class Initialized
INFO - 2017-03-06 19:00:29 --> Language Class Initialized
INFO - 2017-03-06 19:00:29 --> Loader Class Initialized
INFO - 2017-03-06 19:00:30 --> Database Driver Class Initialized
INFO - 2017-03-06 19:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 19:00:30 --> Controller Class Initialized
INFO - 2017-03-06 19:00:30 --> Helper loaded: url_helper
DEBUG - 2017-03-06 19:00:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 19:00:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 19:00:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 19:00:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 19:00:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 19:00:30 --> Final output sent to browser
DEBUG - 2017-03-06 19:00:30 --> Total execution time: 1.5011
INFO - 2017-03-06 19:05:16 --> Config Class Initialized
INFO - 2017-03-06 19:05:16 --> Hooks Class Initialized
DEBUG - 2017-03-06 19:05:16 --> UTF-8 Support Enabled
INFO - 2017-03-06 19:05:16 --> Utf8 Class Initialized
INFO - 2017-03-06 19:05:16 --> URI Class Initialized
INFO - 2017-03-06 19:05:17 --> Router Class Initialized
INFO - 2017-03-06 19:05:17 --> Output Class Initialized
INFO - 2017-03-06 19:05:17 --> Security Class Initialized
DEBUG - 2017-03-06 19:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 19:05:17 --> Input Class Initialized
INFO - 2017-03-06 19:05:17 --> Language Class Initialized
INFO - 2017-03-06 19:05:17 --> Loader Class Initialized
INFO - 2017-03-06 19:05:17 --> Database Driver Class Initialized
INFO - 2017-03-06 19:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 19:05:18 --> Controller Class Initialized
INFO - 2017-03-06 19:05:18 --> Helper loaded: url_helper
DEBUG - 2017-03-06 19:05:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-06 19:05:28 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-06 19:05:28 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Juhan Antonio')
INFO - 2017-03-06 19:05:28 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-06 19:05:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-06 19:05:29 --> Config Class Initialized
INFO - 2017-03-06 19:05:29 --> Hooks Class Initialized
INFO - 2017-03-06 19:05:29 --> Config Class Initialized
INFO - 2017-03-06 19:05:29 --> Hooks Class Initialized
DEBUG - 2017-03-06 19:05:29 --> UTF-8 Support Enabled
DEBUG - 2017-03-06 19:05:29 --> UTF-8 Support Enabled
INFO - 2017-03-06 19:05:29 --> Utf8 Class Initialized
INFO - 2017-03-06 19:05:29 --> Utf8 Class Initialized
INFO - 2017-03-06 19:05:29 --> URI Class Initialized
INFO - 2017-03-06 19:05:30 --> Router Class Initialized
INFO - 2017-03-06 19:05:30 --> URI Class Initialized
INFO - 2017-03-06 19:05:30 --> Output Class Initialized
INFO - 2017-03-06 19:05:30 --> Security Class Initialized
INFO - 2017-03-06 19:05:30 --> Config Class Initialized
INFO - 2017-03-06 19:05:30 --> Hooks Class Initialized
INFO - 2017-03-06 19:05:30 --> Router Class Initialized
DEBUG - 2017-03-06 19:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 19:05:31 --> Input Class Initialized
INFO - 2017-03-06 19:05:31 --> Output Class Initialized
INFO - 2017-03-06 19:05:31 --> Language Class Initialized
DEBUG - 2017-03-06 19:05:31 --> UTF-8 Support Enabled
INFO - 2017-03-06 19:05:31 --> Security Class Initialized
INFO - 2017-03-06 19:05:31 --> Utf8 Class Initialized
DEBUG - 2017-03-06 19:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 19:05:31 --> Input Class Initialized
INFO - 2017-03-06 19:05:31 --> URI Class Initialized
INFO - 2017-03-06 19:05:31 --> Loader Class Initialized
INFO - 2017-03-06 19:05:31 --> Language Class Initialized
INFO - 2017-03-06 19:05:31 --> Router Class Initialized
INFO - 2017-03-06 19:05:31 --> Loader Class Initialized
INFO - 2017-03-06 19:05:31 --> Output Class Initialized
INFO - 2017-03-06 19:05:31 --> Security Class Initialized
INFO - 2017-03-06 19:05:32 --> Database Driver Class Initialized
INFO - 2017-03-06 19:05:32 --> Config Class Initialized
DEBUG - 2017-03-06 19:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 19:05:32 --> Hooks Class Initialized
INFO - 2017-03-06 19:05:32 --> Database Driver Class Initialized
INFO - 2017-03-06 19:05:32 --> Input Class Initialized
INFO - 2017-03-06 19:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 19:05:32 --> Controller Class Initialized
INFO - 2017-03-06 19:05:32 --> Language Class Initialized
INFO - 2017-03-06 19:05:32 --> Helper loaded: url_helper
DEBUG - 2017-03-06 19:05:32 --> UTF-8 Support Enabled
INFO - 2017-03-06 19:05:32 --> Utf8 Class Initialized
INFO - 2017-03-06 19:05:32 --> Loader Class Initialized
DEBUG - 2017-03-06 19:05:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 19:05:32 --> URI Class Initialized
INFO - 2017-03-06 19:05:32 --> Router Class Initialized
INFO - 2017-03-06 19:05:33 --> Database Driver Class Initialized
INFO - 2017-03-06 19:05:33 --> Output Class Initialized
INFO - 2017-03-06 19:05:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 19:05:33 --> Security Class Initialized
DEBUG - 2017-03-06 19:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-03-06 19:05:33 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
INFO - 2017-03-06 19:05:33 --> Input Class Initialized
ERROR - 2017-03-06 19:05:33 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-06 19:05:33 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-06 19:05:33 --> Language Class Initialized
INFO - 2017-03-06 19:05:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 19:05:33 --> Loader Class Initialized
INFO - 2017-03-06 19:05:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 19:05:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 19:05:33 --> Final output sent to browser
DEBUG - 2017-03-06 19:05:33 --> Total execution time: 5.9791
INFO - 2017-03-06 19:05:34 --> Database Driver Class Initialized
INFO - 2017-03-06 19:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 19:05:34 --> Controller Class Initialized
INFO - 2017-03-06 19:05:34 --> Helper loaded: url_helper
DEBUG - 2017-03-06 19:05:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 19:05:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-06 19:05:34 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-06 19:05:34 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-06 19:05:34 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-06 19:05:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 19:05:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 19:05:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 19:05:34 --> Final output sent to browser
DEBUG - 2017-03-06 19:05:34 --> Total execution time: 5.6082
INFO - 2017-03-06 19:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 19:05:34 --> Controller Class Initialized
INFO - 2017-03-06 19:05:34 --> Helper loaded: url_helper
DEBUG - 2017-03-06 19:05:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 19:05:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-06 19:05:34 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-06 19:05:34 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-06 19:05:35 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-06 19:05:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 19:05:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 19:05:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 19:05:35 --> Final output sent to browser
DEBUG - 2017-03-06 19:05:35 --> Total execution time: 6.5909
INFO - 2017-03-06 19:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 19:05:35 --> Controller Class Initialized
INFO - 2017-03-06 19:05:35 --> Helper loaded: url_helper
DEBUG - 2017-03-06 19:05:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 19:05:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-06 19:05:35 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-06 19:05:35 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-06 19:05:35 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-06 19:05:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 19:05:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 19:05:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 19:05:35 --> Final output sent to browser
DEBUG - 2017-03-06 19:05:35 --> Total execution time: 4.8899
INFO - 2017-03-06 19:05:39 --> Config Class Initialized
INFO - 2017-03-06 19:05:39 --> Hooks Class Initialized
DEBUG - 2017-03-06 19:05:39 --> UTF-8 Support Enabled
INFO - 2017-03-06 19:05:39 --> Utf8 Class Initialized
INFO - 2017-03-06 19:05:39 --> URI Class Initialized
INFO - 2017-03-06 19:05:39 --> Router Class Initialized
INFO - 2017-03-06 19:05:39 --> Output Class Initialized
INFO - 2017-03-06 19:05:39 --> Security Class Initialized
DEBUG - 2017-03-06 19:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 19:05:39 --> Input Class Initialized
INFO - 2017-03-06 19:05:39 --> Language Class Initialized
INFO - 2017-03-06 19:05:39 --> Loader Class Initialized
INFO - 2017-03-06 19:05:39 --> Database Driver Class Initialized
INFO - 2017-03-06 19:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 19:05:40 --> Controller Class Initialized
INFO - 2017-03-06 19:05:40 --> Helper loaded: url_helper
DEBUG - 2017-03-06 19:05:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 19:05:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 19:05:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 19:05:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 19:05:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 19:05:41 --> Final output sent to browser
DEBUG - 2017-03-06 19:05:41 --> Total execution time: 3.0733
INFO - 2017-03-06 19:05:58 --> Config Class Initialized
INFO - 2017-03-06 19:05:58 --> Hooks Class Initialized
DEBUG - 2017-03-06 19:05:58 --> UTF-8 Support Enabled
INFO - 2017-03-06 19:05:58 --> Utf8 Class Initialized
INFO - 2017-03-06 19:05:58 --> URI Class Initialized
INFO - 2017-03-06 19:05:58 --> Router Class Initialized
INFO - 2017-03-06 19:05:58 --> Output Class Initialized
INFO - 2017-03-06 19:05:58 --> Security Class Initialized
DEBUG - 2017-03-06 19:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 19:05:59 --> Input Class Initialized
INFO - 2017-03-06 19:05:59 --> Language Class Initialized
INFO - 2017-03-06 19:05:59 --> Loader Class Initialized
INFO - 2017-03-06 19:05:59 --> Database Driver Class Initialized
INFO - 2017-03-06 19:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 19:05:59 --> Controller Class Initialized
INFO - 2017-03-06 19:05:59 --> Helper loaded: url_helper
DEBUG - 2017-03-06 19:05:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-06 19:06:20 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-06 19:06:26 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Juhan Antonio')
INFO - 2017-03-06 19:06:27 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-06 19:06:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-06 19:10:34 --> Config Class Initialized
INFO - 2017-03-06 19:10:35 --> Hooks Class Initialized
DEBUG - 2017-03-06 19:10:38 --> UTF-8 Support Enabled
INFO - 2017-03-06 19:10:40 --> Utf8 Class Initialized
INFO - 2017-03-06 19:10:42 --> URI Class Initialized
INFO - 2017-03-06 19:10:45 --> Router Class Initialized
INFO - 2017-03-06 19:10:48 --> Output Class Initialized
INFO - 2017-03-06 19:10:49 --> Security Class Initialized
DEBUG - 2017-03-06 19:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 19:10:50 --> Input Class Initialized
INFO - 2017-03-06 19:10:52 --> Language Class Initialized
INFO - 2017-03-06 19:10:53 --> Loader Class Initialized
INFO - 2017-03-06 19:10:56 --> Database Driver Class Initialized
INFO - 2017-03-06 19:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 19:10:59 --> Controller Class Initialized
INFO - 2017-03-06 19:10:59 --> Helper loaded: url_helper
DEBUG - 2017-03-06 19:11:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 19:11:19 --> Config Class Initialized
INFO - 2017-03-06 19:11:19 --> Config Class Initialized
INFO - 2017-03-06 19:11:20 --> Hooks Class Initialized
INFO - 2017-03-06 19:11:22 --> Hooks Class Initialized
DEBUG - 2017-03-06 19:11:26 --> UTF-8 Support Enabled
INFO - 2017-03-06 19:11:26 --> Utf8 Class Initialized
DEBUG - 2017-03-06 19:11:26 --> UTF-8 Support Enabled
INFO - 2017-03-06 19:11:26 --> Utf8 Class Initialized
INFO - 2017-03-06 19:11:26 --> URI Class Initialized
INFO - 2017-03-06 19:11:26 --> URI Class Initialized
INFO - 2017-03-06 19:11:27 --> Router Class Initialized
INFO - 2017-03-06 19:11:27 --> Router Class Initialized
INFO - 2017-03-06 19:11:27 --> Output Class Initialized
INFO - 2017-03-06 19:11:27 --> Output Class Initialized
INFO - 2017-03-06 19:11:27 --> Security Class Initialized
INFO - 2017-03-06 19:11:27 --> Security Class Initialized
DEBUG - 2017-03-06 19:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-03-06 19:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 19:11:27 --> Input Class Initialized
INFO - 2017-03-06 19:11:27 --> Input Class Initialized
INFO - 2017-03-06 19:11:27 --> Language Class Initialized
INFO - 2017-03-06 19:11:27 --> Language Class Initialized
INFO - 2017-03-06 19:11:27 --> Loader Class Initialized
INFO - 2017-03-06 19:11:27 --> Loader Class Initialized
INFO - 2017-03-06 19:11:27 --> Database Driver Class Initialized
INFO - 2017-03-06 19:11:27 --> Database Driver Class Initialized
ERROR - 2017-03-06 19:11:31 --> Severity: error --> Exception: timed out before SSL handshake /home/graduafe/public_html/application/libraries/facebook-api-php-codexworld/base_facebook.php 972
INFO - 2017-03-06 19:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 19:11:32 --> Controller Class Initialized
INFO - 2017-03-06 19:11:35 --> Helper loaded: url_helper
DEBUG - 2017-03-06 19:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 19:11:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-06 19:11:41 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-06 19:11:44 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-06 19:11:46 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-06 19:11:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 19:11:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 19:11:49 --> Config Class Initialized
INFO - 2017-03-06 19:11:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 19:11:50 --> Hooks Class Initialized
INFO - 2017-03-06 19:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 19:11:50 --> Controller Class Initialized
INFO - 2017-03-06 19:11:51 --> Helper loaded: url_helper
DEBUG - 2017-03-06 19:11:51 --> UTF-8 Support Enabled
INFO - 2017-03-06 19:11:51 --> Utf8 Class Initialized
DEBUG - 2017-03-06 19:11:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 19:11:53 --> URI Class Initialized
INFO - 2017-03-06 19:11:55 --> Router Class Initialized
INFO - 2017-03-06 19:11:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 19:11:57 --> Output Class Initialized
ERROR - 2017-03-06 19:11:59 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
INFO - 2017-03-06 19:11:59 --> Security Class Initialized
ERROR - 2017-03-06 19:12:00 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
DEBUG - 2017-03-06 19:12:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-03-06 19:12:03 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-06 19:12:04 --> Input Class Initialized
INFO - 2017-03-06 19:12:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 19:12:06 --> Language Class Initialized
INFO - 2017-03-06 19:12:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 19:12:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 19:12:10 --> Loader Class Initialized
INFO - 2017-03-06 19:12:13 --> Database Driver Class Initialized
INFO - 2017-03-06 19:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 19:12:18 --> Controller Class Initialized
INFO - 2017-03-06 19:12:19 --> Helper loaded: url_helper
DEBUG - 2017-03-06 19:12:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 19:12:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-06 19:12:21 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-06 19:12:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-06 19:12:26 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-06 19:12:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 19:12:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 19:12:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 19:12:35 --> Config Class Initialized
INFO - 2017-03-06 19:12:36 --> Hooks Class Initialized
INFO - 2017-03-06 19:12:38 --> Config Class Initialized
INFO - 2017-03-06 19:12:39 --> Hooks Class Initialized
DEBUG - 2017-03-06 19:12:40 --> UTF-8 Support Enabled
INFO - 2017-03-06 19:12:41 --> Utf8 Class Initialized
DEBUG - 2017-03-06 19:12:41 --> UTF-8 Support Enabled
INFO - 2017-03-06 19:12:41 --> Utf8 Class Initialized
INFO - 2017-03-06 19:12:41 --> URI Class Initialized
INFO - 2017-03-06 19:12:41 --> URI Class Initialized
INFO - 2017-03-06 19:12:42 --> Router Class Initialized
INFO - 2017-03-06 19:12:42 --> Router Class Initialized
INFO - 2017-03-06 19:12:42 --> Output Class Initialized
INFO - 2017-03-06 19:12:42 --> Output Class Initialized
INFO - 2017-03-06 19:12:42 --> Security Class Initialized
DEBUG - 2017-03-06 19:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 19:12:43 --> Security Class Initialized
INFO - 2017-03-06 19:12:43 --> Input Class Initialized
DEBUG - 2017-03-06 19:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 19:12:43 --> Input Class Initialized
INFO - 2017-03-06 19:12:43 --> Language Class Initialized
INFO - 2017-03-06 19:12:43 --> Language Class Initialized
INFO - 2017-03-06 19:12:43 --> Loader Class Initialized
INFO - 2017-03-06 19:12:43 --> Loader Class Initialized
INFO - 2017-03-06 19:12:44 --> Database Driver Class Initialized
INFO - 2017-03-06 19:12:44 --> Database Driver Class Initialized
INFO - 2017-03-06 19:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 19:12:45 --> Controller Class Initialized
INFO - 2017-03-06 19:12:45 --> Helper loaded: url_helper
DEBUG - 2017-03-06 19:12:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 19:12:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-06 19:12:46 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-06 19:12:46 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-06 19:12:46 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-06 19:12:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 19:12:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 19:12:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 19:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 19:12:47 --> Controller Class Initialized
INFO - 2017-03-06 19:12:48 --> Helper loaded: url_helper
DEBUG - 2017-03-06 19:12:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 19:12:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-06 19:12:51 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-06 19:12:52 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-06 19:12:53 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-06 19:12:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 19:12:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 19:12:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 20:44:49 --> Config Class Initialized
INFO - 2017-03-06 20:44:49 --> Hooks Class Initialized
DEBUG - 2017-03-06 20:44:49 --> UTF-8 Support Enabled
INFO - 2017-03-06 20:44:50 --> Utf8 Class Initialized
INFO - 2017-03-06 20:44:50 --> URI Class Initialized
DEBUG - 2017-03-06 20:44:50 --> No URI present. Default controller set.
INFO - 2017-03-06 20:44:50 --> Router Class Initialized
INFO - 2017-03-06 20:44:50 --> Output Class Initialized
INFO - 2017-03-06 20:44:50 --> Security Class Initialized
DEBUG - 2017-03-06 20:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 20:44:50 --> Input Class Initialized
INFO - 2017-03-06 20:44:50 --> Language Class Initialized
INFO - 2017-03-06 20:44:50 --> Loader Class Initialized
INFO - 2017-03-06 20:44:50 --> Database Driver Class Initialized
INFO - 2017-03-06 20:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 20:44:51 --> Controller Class Initialized
INFO - 2017-03-06 20:44:51 --> Helper loaded: url_helper
DEBUG - 2017-03-06 20:44:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 20:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 20:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 20:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 20:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 20:44:51 --> Final output sent to browser
DEBUG - 2017-03-06 20:44:51 --> Total execution time: 1.8029
INFO - 2017-03-06 20:44:58 --> Config Class Initialized
INFO - 2017-03-06 20:44:58 --> Hooks Class Initialized
DEBUG - 2017-03-06 20:44:58 --> UTF-8 Support Enabled
INFO - 2017-03-06 20:44:58 --> Utf8 Class Initialized
INFO - 2017-03-06 20:44:58 --> URI Class Initialized
INFO - 2017-03-06 20:44:58 --> Router Class Initialized
INFO - 2017-03-06 20:44:58 --> Output Class Initialized
INFO - 2017-03-06 20:44:58 --> Security Class Initialized
DEBUG - 2017-03-06 20:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 20:44:58 --> Input Class Initialized
INFO - 2017-03-06 20:44:58 --> Language Class Initialized
INFO - 2017-03-06 20:44:58 --> Loader Class Initialized
INFO - 2017-03-06 20:44:58 --> Database Driver Class Initialized
INFO - 2017-03-06 20:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 20:44:58 --> Controller Class Initialized
INFO - 2017-03-06 20:44:58 --> Helper loaded: url_helper
DEBUG - 2017-03-06 20:44:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 20:44:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 20:44:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 20:44:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 20:44:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 20:44:58 --> Final output sent to browser
DEBUG - 2017-03-06 20:44:58 --> Total execution time: 0.0160
INFO - 2017-03-06 20:46:37 --> Config Class Initialized
INFO - 2017-03-06 20:46:37 --> Hooks Class Initialized
DEBUG - 2017-03-06 20:46:37 --> UTF-8 Support Enabled
INFO - 2017-03-06 20:46:37 --> Utf8 Class Initialized
INFO - 2017-03-06 20:46:37 --> URI Class Initialized
DEBUG - 2017-03-06 20:46:37 --> No URI present. Default controller set.
INFO - 2017-03-06 20:46:37 --> Router Class Initialized
INFO - 2017-03-06 20:46:37 --> Output Class Initialized
INFO - 2017-03-06 20:46:37 --> Security Class Initialized
DEBUG - 2017-03-06 20:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 20:46:37 --> Input Class Initialized
INFO - 2017-03-06 20:46:37 --> Language Class Initialized
INFO - 2017-03-06 20:46:37 --> Loader Class Initialized
INFO - 2017-03-06 20:46:38 --> Database Driver Class Initialized
INFO - 2017-03-06 20:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 20:46:38 --> Controller Class Initialized
INFO - 2017-03-06 20:46:38 --> Helper loaded: url_helper
DEBUG - 2017-03-06 20:46:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 20:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 20:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 20:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 20:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 20:46:38 --> Final output sent to browser
DEBUG - 2017-03-06 20:46:38 --> Total execution time: 2.4042
INFO - 2017-03-06 20:46:40 --> Config Class Initialized
INFO - 2017-03-06 20:46:40 --> Hooks Class Initialized
DEBUG - 2017-03-06 20:46:40 --> UTF-8 Support Enabled
INFO - 2017-03-06 20:46:40 --> Utf8 Class Initialized
INFO - 2017-03-06 20:46:40 --> URI Class Initialized
INFO - 2017-03-06 20:46:40 --> Router Class Initialized
INFO - 2017-03-06 20:46:40 --> Output Class Initialized
INFO - 2017-03-06 20:46:40 --> Security Class Initialized
DEBUG - 2017-03-06 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 20:46:40 --> Input Class Initialized
INFO - 2017-03-06 20:46:40 --> Language Class Initialized
INFO - 2017-03-06 20:46:40 --> Loader Class Initialized
INFO - 2017-03-06 20:46:40 --> Database Driver Class Initialized
INFO - 2017-03-06 20:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 20:46:40 --> Controller Class Initialized
INFO - 2017-03-06 20:46:40 --> Helper loaded: url_helper
DEBUG - 2017-03-06 20:46:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 20:46:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 20:46:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 20:46:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 20:46:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 20:46:40 --> Final output sent to browser
DEBUG - 2017-03-06 20:46:40 --> Total execution time: 0.0338
INFO - 2017-03-06 20:47:43 --> Config Class Initialized
INFO - 2017-03-06 20:47:43 --> Hooks Class Initialized
DEBUG - 2017-03-06 20:47:43 --> UTF-8 Support Enabled
INFO - 2017-03-06 20:47:43 --> Utf8 Class Initialized
INFO - 2017-03-06 20:47:43 --> URI Class Initialized
INFO - 2017-03-06 20:47:43 --> Router Class Initialized
INFO - 2017-03-06 20:47:43 --> Output Class Initialized
INFO - 2017-03-06 20:47:43 --> Security Class Initialized
DEBUG - 2017-03-06 20:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 20:47:43 --> Input Class Initialized
INFO - 2017-03-06 20:47:43 --> Language Class Initialized
INFO - 2017-03-06 20:47:43 --> Loader Class Initialized
INFO - 2017-03-06 20:47:44 --> Database Driver Class Initialized
INFO - 2017-03-06 20:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 20:47:44 --> Controller Class Initialized
INFO - 2017-03-06 20:47:44 --> Helper loaded: url_helper
DEBUG - 2017-03-06 20:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 20:47:44 --> Final output sent to browser
DEBUG - 2017-03-06 20:47:44 --> Total execution time: 1.4371
INFO - 2017-03-06 20:59:52 --> Config Class Initialized
INFO - 2017-03-06 20:59:52 --> Hooks Class Initialized
DEBUG - 2017-03-06 20:59:53 --> UTF-8 Support Enabled
INFO - 2017-03-06 20:59:53 --> Utf8 Class Initialized
INFO - 2017-03-06 20:59:53 --> URI Class Initialized
DEBUG - 2017-03-06 20:59:53 --> No URI present. Default controller set.
INFO - 2017-03-06 20:59:53 --> Router Class Initialized
INFO - 2017-03-06 20:59:53 --> Output Class Initialized
INFO - 2017-03-06 20:59:53 --> Security Class Initialized
DEBUG - 2017-03-06 20:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 20:59:53 --> Input Class Initialized
INFO - 2017-03-06 20:59:53 --> Language Class Initialized
INFO - 2017-03-06 20:59:53 --> Loader Class Initialized
INFO - 2017-03-06 20:59:53 --> Database Driver Class Initialized
INFO - 2017-03-06 20:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 20:59:54 --> Controller Class Initialized
INFO - 2017-03-06 20:59:54 --> Helper loaded: url_helper
DEBUG - 2017-03-06 20:59:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 20:59:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 20:59:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 20:59:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 20:59:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 20:59:54 --> Final output sent to browser
DEBUG - 2017-03-06 20:59:54 --> Total execution time: 1.7344
INFO - 2017-03-06 21:56:18 --> Config Class Initialized
INFO - 2017-03-06 21:56:18 --> Hooks Class Initialized
DEBUG - 2017-03-06 21:56:19 --> UTF-8 Support Enabled
INFO - 2017-03-06 21:56:19 --> Utf8 Class Initialized
INFO - 2017-03-06 21:56:19 --> URI Class Initialized
DEBUG - 2017-03-06 21:56:19 --> No URI present. Default controller set.
INFO - 2017-03-06 21:56:19 --> Router Class Initialized
INFO - 2017-03-06 21:56:19 --> Output Class Initialized
INFO - 2017-03-06 21:56:19 --> Security Class Initialized
DEBUG - 2017-03-06 21:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 21:56:19 --> Input Class Initialized
INFO - 2017-03-06 21:56:19 --> Language Class Initialized
INFO - 2017-03-06 21:56:19 --> Loader Class Initialized
INFO - 2017-03-06 21:56:19 --> Database Driver Class Initialized
INFO - 2017-03-06 21:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 21:56:20 --> Controller Class Initialized
INFO - 2017-03-06 21:56:20 --> Helper loaded: url_helper
DEBUG - 2017-03-06 21:56:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 21:56:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 21:56:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 21:56:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 21:56:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 21:56:21 --> Final output sent to browser
DEBUG - 2017-03-06 21:56:21 --> Total execution time: 2.6425
INFO - 2017-03-06 22:16:27 --> Config Class Initialized
INFO - 2017-03-06 22:16:27 --> Hooks Class Initialized
DEBUG - 2017-03-06 22:16:28 --> UTF-8 Support Enabled
INFO - 2017-03-06 22:16:28 --> Utf8 Class Initialized
INFO - 2017-03-06 22:16:28 --> URI Class Initialized
DEBUG - 2017-03-06 22:16:28 --> No URI present. Default controller set.
INFO - 2017-03-06 22:16:28 --> Router Class Initialized
INFO - 2017-03-06 22:16:28 --> Output Class Initialized
INFO - 2017-03-06 22:16:28 --> Security Class Initialized
DEBUG - 2017-03-06 22:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 22:16:28 --> Input Class Initialized
INFO - 2017-03-06 22:16:28 --> Language Class Initialized
INFO - 2017-03-06 22:16:28 --> Loader Class Initialized
INFO - 2017-03-06 22:16:28 --> Database Driver Class Initialized
INFO - 2017-03-06 22:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 22:16:29 --> Controller Class Initialized
INFO - 2017-03-06 22:16:29 --> Helper loaded: url_helper
DEBUG - 2017-03-06 22:16:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 22:16:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 22:16:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 22:16:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 22:16:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 22:16:29 --> Final output sent to browser
DEBUG - 2017-03-06 22:16:29 --> Total execution time: 1.9736
INFO - 2017-03-06 22:16:45 --> Config Class Initialized
INFO - 2017-03-06 22:16:45 --> Hooks Class Initialized
DEBUG - 2017-03-06 22:16:45 --> UTF-8 Support Enabled
INFO - 2017-03-06 22:16:45 --> Utf8 Class Initialized
INFO - 2017-03-06 22:16:45 --> URI Class Initialized
INFO - 2017-03-06 22:16:45 --> Router Class Initialized
INFO - 2017-03-06 22:16:45 --> Output Class Initialized
INFO - 2017-03-06 22:16:45 --> Security Class Initialized
DEBUG - 2017-03-06 22:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 22:16:46 --> Input Class Initialized
INFO - 2017-03-06 22:16:46 --> Language Class Initialized
INFO - 2017-03-06 22:16:46 --> Loader Class Initialized
INFO - 2017-03-06 22:16:46 --> Database Driver Class Initialized
INFO - 2017-03-06 22:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 22:16:46 --> Controller Class Initialized
INFO - 2017-03-06 22:16:46 --> Helper loaded: url_helper
DEBUG - 2017-03-06 22:16:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 22:16:54 --> Config Class Initialized
INFO - 2017-03-06 22:16:54 --> Hooks Class Initialized
DEBUG - 2017-03-06 22:16:54 --> UTF-8 Support Enabled
INFO - 2017-03-06 22:16:54 --> Utf8 Class Initialized
INFO - 2017-03-06 22:16:54 --> URI Class Initialized
DEBUG - 2017-03-06 22:16:54 --> No URI present. Default controller set.
INFO - 2017-03-06 22:16:54 --> Router Class Initialized
INFO - 2017-03-06 22:16:54 --> Output Class Initialized
INFO - 2017-03-06 22:16:54 --> Security Class Initialized
DEBUG - 2017-03-06 22:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 22:16:54 --> Input Class Initialized
INFO - 2017-03-06 22:16:54 --> Language Class Initialized
INFO - 2017-03-06 22:16:54 --> Loader Class Initialized
INFO - 2017-03-06 22:16:54 --> Database Driver Class Initialized
INFO - 2017-03-06 22:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 22:16:54 --> Controller Class Initialized
INFO - 2017-03-06 22:16:54 --> Helper loaded: url_helper
DEBUG - 2017-03-06 22:16:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 22:16:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 22:16:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 22:16:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 22:16:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 22:16:55 --> Final output sent to browser
DEBUG - 2017-03-06 22:16:55 --> Total execution time: 0.2078
INFO - 2017-03-06 22:17:12 --> Config Class Initialized
INFO - 2017-03-06 22:17:12 --> Hooks Class Initialized
DEBUG - 2017-03-06 22:17:12 --> UTF-8 Support Enabled
INFO - 2017-03-06 22:17:12 --> Utf8 Class Initialized
INFO - 2017-03-06 22:17:12 --> URI Class Initialized
INFO - 2017-03-06 22:17:13 --> Router Class Initialized
INFO - 2017-03-06 22:17:13 --> Output Class Initialized
INFO - 2017-03-06 22:17:13 --> Security Class Initialized
DEBUG - 2017-03-06 22:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 22:17:13 --> Input Class Initialized
INFO - 2017-03-06 22:17:13 --> Language Class Initialized
INFO - 2017-03-06 22:17:13 --> Loader Class Initialized
INFO - 2017-03-06 22:17:13 --> Database Driver Class Initialized
INFO - 2017-03-06 22:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 22:17:13 --> Controller Class Initialized
INFO - 2017-03-06 22:17:13 --> Helper loaded: url_helper
DEBUG - 2017-03-06 22:17:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-06 22:17:15 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-06 22:17:15 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Danny Bernal')
INFO - 2017-03-06 22:17:15 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-06 22:17:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-06 22:17:15 --> Config Class Initialized
INFO - 2017-03-06 22:17:15 --> Hooks Class Initialized
DEBUG - 2017-03-06 22:17:15 --> UTF-8 Support Enabled
INFO - 2017-03-06 22:17:15 --> Utf8 Class Initialized
INFO - 2017-03-06 22:17:15 --> URI Class Initialized
INFO - 2017-03-06 22:17:15 --> Router Class Initialized
INFO - 2017-03-06 22:17:15 --> Output Class Initialized
INFO - 2017-03-06 22:17:15 --> Security Class Initialized
DEBUG - 2017-03-06 22:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 22:17:15 --> Input Class Initialized
INFO - 2017-03-06 22:17:15 --> Language Class Initialized
INFO - 2017-03-06 22:17:15 --> Loader Class Initialized
INFO - 2017-03-06 22:17:15 --> Database Driver Class Initialized
INFO - 2017-03-06 22:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 22:17:15 --> Controller Class Initialized
INFO - 2017-03-06 22:17:15 --> Helper loaded: url_helper
DEBUG - 2017-03-06 22:17:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 22:17:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 22:17:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 22:17:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 22:17:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 22:17:15 --> Final output sent to browser
DEBUG - 2017-03-06 22:17:15 --> Total execution time: 0.1702
INFO - 2017-03-06 22:17:28 --> Config Class Initialized
INFO - 2017-03-06 22:17:28 --> Hooks Class Initialized
DEBUG - 2017-03-06 22:17:28 --> UTF-8 Support Enabled
INFO - 2017-03-06 22:17:28 --> Utf8 Class Initialized
INFO - 2017-03-06 22:17:28 --> URI Class Initialized
DEBUG - 2017-03-06 22:17:28 --> No URI present. Default controller set.
INFO - 2017-03-06 22:17:28 --> Router Class Initialized
INFO - 2017-03-06 22:17:28 --> Output Class Initialized
INFO - 2017-03-06 22:17:28 --> Security Class Initialized
DEBUG - 2017-03-06 22:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 22:17:28 --> Input Class Initialized
INFO - 2017-03-06 22:17:28 --> Language Class Initialized
INFO - 2017-03-06 22:17:28 --> Loader Class Initialized
INFO - 2017-03-06 22:17:28 --> Database Driver Class Initialized
INFO - 2017-03-06 22:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 22:17:28 --> Controller Class Initialized
INFO - 2017-03-06 22:17:28 --> Helper loaded: url_helper
DEBUG - 2017-03-06 22:17:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 22:17:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 22:17:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 22:17:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 22:17:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 22:17:28 --> Final output sent to browser
DEBUG - 2017-03-06 22:17:28 --> Total execution time: 0.0145
INFO - 2017-03-06 22:17:49 --> Config Class Initialized
INFO - 2017-03-06 22:17:49 --> Hooks Class Initialized
DEBUG - 2017-03-06 22:17:49 --> UTF-8 Support Enabled
INFO - 2017-03-06 22:17:49 --> Utf8 Class Initialized
INFO - 2017-03-06 22:17:49 --> URI Class Initialized
DEBUG - 2017-03-06 22:17:49 --> No URI present. Default controller set.
INFO - 2017-03-06 22:17:49 --> Router Class Initialized
INFO - 2017-03-06 22:17:49 --> Output Class Initialized
INFO - 2017-03-06 22:17:49 --> Security Class Initialized
DEBUG - 2017-03-06 22:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 22:17:49 --> Input Class Initialized
INFO - 2017-03-06 22:17:49 --> Language Class Initialized
INFO - 2017-03-06 22:17:49 --> Loader Class Initialized
INFO - 2017-03-06 22:17:49 --> Database Driver Class Initialized
INFO - 2017-03-06 22:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 22:17:49 --> Controller Class Initialized
INFO - 2017-03-06 22:17:49 --> Helper loaded: url_helper
DEBUG - 2017-03-06 22:17:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 22:17:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 22:17:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 22:17:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 22:17:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 22:17:49 --> Final output sent to browser
DEBUG - 2017-03-06 22:17:49 --> Total execution time: 0.0135
INFO - 2017-03-06 22:18:14 --> Config Class Initialized
INFO - 2017-03-06 22:18:14 --> Hooks Class Initialized
DEBUG - 2017-03-06 22:18:14 --> UTF-8 Support Enabled
INFO - 2017-03-06 22:18:14 --> Utf8 Class Initialized
INFO - 2017-03-06 22:18:14 --> URI Class Initialized
INFO - 2017-03-06 22:18:14 --> Router Class Initialized
INFO - 2017-03-06 22:18:14 --> Output Class Initialized
INFO - 2017-03-06 22:18:14 --> Security Class Initialized
DEBUG - 2017-03-06 22:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 22:18:14 --> Input Class Initialized
INFO - 2017-03-06 22:18:14 --> Language Class Initialized
INFO - 2017-03-06 22:18:14 --> Loader Class Initialized
INFO - 2017-03-06 22:18:14 --> Database Driver Class Initialized
INFO - 2017-03-06 22:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 22:18:14 --> Controller Class Initialized
INFO - 2017-03-06 22:18:14 --> Helper loaded: url_helper
DEBUG - 2017-03-06 22:18:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-06 22:18:15 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-06 22:18:15 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Danny Bernal')
INFO - 2017-03-06 22:18:15 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-06 22:18:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-06 22:18:35 --> Config Class Initialized
INFO - 2017-03-06 22:18:35 --> Hooks Class Initialized
DEBUG - 2017-03-06 22:18:35 --> UTF-8 Support Enabled
INFO - 2017-03-06 22:18:35 --> Utf8 Class Initialized
INFO - 2017-03-06 22:18:35 --> URI Class Initialized
DEBUG - 2017-03-06 22:18:35 --> No URI present. Default controller set.
INFO - 2017-03-06 22:18:35 --> Router Class Initialized
INFO - 2017-03-06 22:18:35 --> Output Class Initialized
INFO - 2017-03-06 22:18:35 --> Security Class Initialized
DEBUG - 2017-03-06 22:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 22:18:35 --> Input Class Initialized
INFO - 2017-03-06 22:18:35 --> Language Class Initialized
INFO - 2017-03-06 22:18:35 --> Loader Class Initialized
INFO - 2017-03-06 22:18:35 --> Database Driver Class Initialized
INFO - 2017-03-06 22:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 22:18:35 --> Controller Class Initialized
INFO - 2017-03-06 22:18:35 --> Helper loaded: url_helper
DEBUG - 2017-03-06 22:18:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 22:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 22:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 22:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 22:18:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 22:18:35 --> Final output sent to browser
DEBUG - 2017-03-06 22:18:35 --> Total execution time: 0.0526
INFO - 2017-03-06 22:19:23 --> Config Class Initialized
INFO - 2017-03-06 22:19:23 --> Hooks Class Initialized
DEBUG - 2017-03-06 22:19:23 --> UTF-8 Support Enabled
INFO - 2017-03-06 22:19:23 --> Utf8 Class Initialized
INFO - 2017-03-06 22:19:23 --> URI Class Initialized
INFO - 2017-03-06 22:19:23 --> Router Class Initialized
INFO - 2017-03-06 22:19:23 --> Output Class Initialized
INFO - 2017-03-06 22:19:23 --> Security Class Initialized
DEBUG - 2017-03-06 22:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 22:19:23 --> Input Class Initialized
INFO - 2017-03-06 22:19:23 --> Language Class Initialized
INFO - 2017-03-06 22:19:23 --> Loader Class Initialized
INFO - 2017-03-06 22:19:23 --> Database Driver Class Initialized
INFO - 2017-03-06 22:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 22:19:23 --> Controller Class Initialized
INFO - 2017-03-06 22:19:23 --> Helper loaded: url_helper
DEBUG - 2017-03-06 22:19:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 22:19:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 22:19:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 22:19:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 22:19:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 22:19:23 --> Final output sent to browser
DEBUG - 2017-03-06 22:19:23 --> Total execution time: 0.0158
INFO - 2017-03-06 22:19:57 --> Config Class Initialized
INFO - 2017-03-06 22:19:57 --> Hooks Class Initialized
DEBUG - 2017-03-06 22:19:58 --> UTF-8 Support Enabled
INFO - 2017-03-06 22:19:58 --> Utf8 Class Initialized
INFO - 2017-03-06 22:19:58 --> URI Class Initialized
INFO - 2017-03-06 22:19:58 --> Router Class Initialized
INFO - 2017-03-06 22:19:58 --> Output Class Initialized
INFO - 2017-03-06 22:19:58 --> Security Class Initialized
DEBUG - 2017-03-06 22:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 22:19:58 --> Input Class Initialized
INFO - 2017-03-06 22:19:58 --> Language Class Initialized
INFO - 2017-03-06 22:19:58 --> Loader Class Initialized
INFO - 2017-03-06 22:19:58 --> Database Driver Class Initialized
INFO - 2017-03-06 22:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 22:19:59 --> Controller Class Initialized
INFO - 2017-03-06 22:19:59 --> Helper loaded: url_helper
DEBUG - 2017-03-06 22:19:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 22:19:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 22:19:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 22:19:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 22:19:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 22:19:59 --> Final output sent to browser
DEBUG - 2017-03-06 22:19:59 --> Total execution time: 1.9926
INFO - 2017-03-06 22:20:20 --> Config Class Initialized
INFO - 2017-03-06 22:20:20 --> Hooks Class Initialized
DEBUG - 2017-03-06 22:20:20 --> UTF-8 Support Enabled
INFO - 2017-03-06 22:20:20 --> Utf8 Class Initialized
INFO - 2017-03-06 22:20:20 --> URI Class Initialized
INFO - 2017-03-06 22:20:20 --> Router Class Initialized
INFO - 2017-03-06 22:20:20 --> Output Class Initialized
INFO - 2017-03-06 22:20:20 --> Security Class Initialized
DEBUG - 2017-03-06 22:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 22:20:20 --> Input Class Initialized
INFO - 2017-03-06 22:20:20 --> Language Class Initialized
INFO - 2017-03-06 22:20:20 --> Loader Class Initialized
INFO - 2017-03-06 22:20:20 --> Database Driver Class Initialized
INFO - 2017-03-06 22:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 22:20:21 --> Controller Class Initialized
INFO - 2017-03-06 22:20:21 --> Helper loaded: url_helper
DEBUG - 2017-03-06 22:20:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-06 22:20:22 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-06 22:20:22 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Danny Bernal')
INFO - 2017-03-06 22:20:22 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-06 22:20:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-06 22:34:39 --> Config Class Initialized
INFO - 2017-03-06 22:34:39 --> Hooks Class Initialized
DEBUG - 2017-03-06 22:34:40 --> UTF-8 Support Enabled
INFO - 2017-03-06 22:34:40 --> Utf8 Class Initialized
INFO - 2017-03-06 22:34:40 --> URI Class Initialized
INFO - 2017-03-06 22:34:40 --> Router Class Initialized
INFO - 2017-03-06 22:34:40 --> Output Class Initialized
INFO - 2017-03-06 22:34:40 --> Security Class Initialized
DEBUG - 2017-03-06 22:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 22:34:40 --> Input Class Initialized
INFO - 2017-03-06 22:34:40 --> Language Class Initialized
INFO - 2017-03-06 22:34:40 --> Loader Class Initialized
INFO - 2017-03-06 22:34:40 --> Database Driver Class Initialized
INFO - 2017-03-06 22:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 22:34:41 --> Controller Class Initialized
INFO - 2017-03-06 22:34:41 --> Helper loaded: date_helper
DEBUG - 2017-03-06 22:34:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 22:34:41 --> Helper loaded: url_helper
INFO - 2017-03-06 22:34:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 22:34:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-06 22:34:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-06 22:34:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-06 22:34:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 22:34:41 --> Final output sent to browser
DEBUG - 2017-03-06 22:34:41 --> Total execution time: 4.3945
INFO - 2017-03-06 22:35:26 --> Config Class Initialized
INFO - 2017-03-06 22:35:26 --> Hooks Class Initialized
DEBUG - 2017-03-06 22:35:28 --> UTF-8 Support Enabled
INFO - 2017-03-06 22:35:28 --> Utf8 Class Initialized
INFO - 2017-03-06 22:35:28 --> URI Class Initialized
INFO - 2017-03-06 22:35:28 --> Router Class Initialized
INFO - 2017-03-06 22:35:28 --> Output Class Initialized
INFO - 2017-03-06 22:35:28 --> Security Class Initialized
DEBUG - 2017-03-06 22:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 22:35:29 --> Input Class Initialized
INFO - 2017-03-06 22:35:29 --> Language Class Initialized
INFO - 2017-03-06 22:35:29 --> Loader Class Initialized
INFO - 2017-03-06 22:35:29 --> Database Driver Class Initialized
INFO - 2017-03-06 22:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 22:35:30 --> Controller Class Initialized
INFO - 2017-03-06 22:35:30 --> Helper loaded: url_helper
DEBUG - 2017-03-06 22:35:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-06 22:35:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-06 22:35:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-06 22:35:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-06 22:35:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-06 22:35:30 --> Final output sent to browser
DEBUG - 2017-03-06 22:35:30 --> Total execution time: 4.4290

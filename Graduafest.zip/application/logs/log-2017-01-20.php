<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-20 00:07:14 --> Config Class Initialized
INFO - 2017-01-20 00:07:14 --> Hooks Class Initialized
DEBUG - 2017-01-20 00:07:14 --> UTF-8 Support Enabled
INFO - 2017-01-20 00:07:14 --> Utf8 Class Initialized
INFO - 2017-01-20 00:07:14 --> URI Class Initialized
INFO - 2017-01-20 00:07:14 --> Router Class Initialized
INFO - 2017-01-20 00:07:14 --> Output Class Initialized
INFO - 2017-01-20 00:07:14 --> Security Class Initialized
DEBUG - 2017-01-20 00:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 00:07:14 --> Input Class Initialized
INFO - 2017-01-20 00:07:14 --> Language Class Initialized
INFO - 2017-01-20 00:07:14 --> Loader Class Initialized
INFO - 2017-01-20 00:07:14 --> Database Driver Class Initialized
INFO - 2017-01-20 00:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 00:07:14 --> Controller Class Initialized
INFO - 2017-01-20 00:07:14 --> Helper loaded: url_helper
DEBUG - 2017-01-20 00:07:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 00:07:14 --> Helper loaded: form_helper
INFO - 2017-01-20 00:07:14 --> Form Validation Class Initialized
INFO - 2017-01-20 00:07:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-20 00:07:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-20 00:07:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-20 00:07:14 --> Final output sent to browser
DEBUG - 2017-01-20 00:07:14 --> Total execution time: 0.0209
INFO - 2017-01-20 00:32:02 --> Config Class Initialized
INFO - 2017-01-20 00:32:02 --> Hooks Class Initialized
DEBUG - 2017-01-20 00:32:02 --> UTF-8 Support Enabled
INFO - 2017-01-20 00:32:02 --> Utf8 Class Initialized
INFO - 2017-01-20 00:32:02 --> URI Class Initialized
DEBUG - 2017-01-20 00:32:02 --> No URI present. Default controller set.
INFO - 2017-01-20 00:32:02 --> Router Class Initialized
INFO - 2017-01-20 00:32:02 --> Output Class Initialized
INFO - 2017-01-20 00:32:02 --> Security Class Initialized
DEBUG - 2017-01-20 00:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 00:32:02 --> Input Class Initialized
INFO - 2017-01-20 00:32:02 --> Language Class Initialized
INFO - 2017-01-20 00:32:02 --> Loader Class Initialized
INFO - 2017-01-20 00:32:02 --> Database Driver Class Initialized
INFO - 2017-01-20 00:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 00:32:02 --> Controller Class Initialized
INFO - 2017-01-20 00:32:02 --> Helper loaded: url_helper
DEBUG - 2017-01-20 00:32:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 00:32:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 00:32:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 00:32:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 00:32:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 00:32:02 --> Final output sent to browser
DEBUG - 2017-01-20 00:32:02 --> Total execution time: 0.0144
INFO - 2017-01-20 00:33:59 --> Config Class Initialized
INFO - 2017-01-20 00:33:59 --> Hooks Class Initialized
DEBUG - 2017-01-20 00:33:59 --> UTF-8 Support Enabled
INFO - 2017-01-20 00:33:59 --> Utf8 Class Initialized
INFO - 2017-01-20 00:33:59 --> URI Class Initialized
INFO - 2017-01-20 00:33:59 --> Router Class Initialized
INFO - 2017-01-20 00:33:59 --> Output Class Initialized
INFO - 2017-01-20 00:33:59 --> Security Class Initialized
DEBUG - 2017-01-20 00:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 00:33:59 --> Input Class Initialized
INFO - 2017-01-20 00:33:59 --> Language Class Initialized
INFO - 2017-01-20 00:33:59 --> Loader Class Initialized
INFO - 2017-01-20 00:33:59 --> Database Driver Class Initialized
INFO - 2017-01-20 00:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 00:33:59 --> Controller Class Initialized
INFO - 2017-01-20 00:33:59 --> Helper loaded: url_helper
DEBUG - 2017-01-20 00:33:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 00:34:01 --> Config Class Initialized
INFO - 2017-01-20 00:34:01 --> Hooks Class Initialized
DEBUG - 2017-01-20 00:34:01 --> UTF-8 Support Enabled
INFO - 2017-01-20 00:34:01 --> Utf8 Class Initialized
INFO - 2017-01-20 00:34:01 --> URI Class Initialized
INFO - 2017-01-20 00:34:01 --> Router Class Initialized
INFO - 2017-01-20 00:34:01 --> Output Class Initialized
INFO - 2017-01-20 00:34:01 --> Security Class Initialized
DEBUG - 2017-01-20 00:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 00:34:01 --> Input Class Initialized
INFO - 2017-01-20 00:34:01 --> Language Class Initialized
INFO - 2017-01-20 00:34:01 --> Loader Class Initialized
INFO - 2017-01-20 00:34:01 --> Database Driver Class Initialized
INFO - 2017-01-20 00:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 00:34:01 --> Controller Class Initialized
INFO - 2017-01-20 00:34:01 --> Helper loaded: date_helper
DEBUG - 2017-01-20 00:34:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 00:34:01 --> Helper loaded: url_helper
INFO - 2017-01-20 00:34:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 00:34:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-20 00:34:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-20 00:34:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-20 00:34:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 00:34:01 --> Final output sent to browser
DEBUG - 2017-01-20 00:34:01 --> Total execution time: 0.0255
INFO - 2017-01-20 00:34:04 --> Config Class Initialized
INFO - 2017-01-20 00:34:04 --> Hooks Class Initialized
DEBUG - 2017-01-20 00:34:04 --> UTF-8 Support Enabled
INFO - 2017-01-20 00:34:04 --> Utf8 Class Initialized
INFO - 2017-01-20 00:34:04 --> URI Class Initialized
INFO - 2017-01-20 00:34:04 --> Router Class Initialized
INFO - 2017-01-20 00:34:04 --> Output Class Initialized
INFO - 2017-01-20 00:34:04 --> Security Class Initialized
DEBUG - 2017-01-20 00:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 00:34:04 --> Input Class Initialized
INFO - 2017-01-20 00:34:04 --> Language Class Initialized
INFO - 2017-01-20 00:34:04 --> Loader Class Initialized
INFO - 2017-01-20 00:34:04 --> Database Driver Class Initialized
INFO - 2017-01-20 00:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 00:34:04 --> Controller Class Initialized
INFO - 2017-01-20 00:34:04 --> Helper loaded: url_helper
DEBUG - 2017-01-20 00:34:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 00:34:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 00:34:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 00:34:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 00:34:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 00:34:04 --> Final output sent to browser
DEBUG - 2017-01-20 00:34:04 --> Total execution time: 0.0136
INFO - 2017-01-20 00:34:09 --> Config Class Initialized
INFO - 2017-01-20 00:34:09 --> Hooks Class Initialized
DEBUG - 2017-01-20 00:34:09 --> UTF-8 Support Enabled
INFO - 2017-01-20 00:34:09 --> Utf8 Class Initialized
INFO - 2017-01-20 00:34:09 --> URI Class Initialized
DEBUG - 2017-01-20 00:34:09 --> No URI present. Default controller set.
INFO - 2017-01-20 00:34:09 --> Router Class Initialized
INFO - 2017-01-20 00:34:09 --> Output Class Initialized
INFO - 2017-01-20 00:34:09 --> Security Class Initialized
DEBUG - 2017-01-20 00:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 00:34:09 --> Input Class Initialized
INFO - 2017-01-20 00:34:09 --> Language Class Initialized
INFO - 2017-01-20 00:34:09 --> Loader Class Initialized
INFO - 2017-01-20 00:34:09 --> Database Driver Class Initialized
INFO - 2017-01-20 00:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 00:34:09 --> Controller Class Initialized
INFO - 2017-01-20 00:34:09 --> Helper loaded: url_helper
DEBUG - 2017-01-20 00:34:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 00:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 00:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 00:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 00:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 00:34:09 --> Final output sent to browser
DEBUG - 2017-01-20 00:34:09 --> Total execution time: 0.0139
INFO - 2017-01-20 02:43:27 --> Config Class Initialized
INFO - 2017-01-20 02:43:27 --> Hooks Class Initialized
DEBUG - 2017-01-20 02:43:27 --> UTF-8 Support Enabled
INFO - 2017-01-20 02:43:27 --> Utf8 Class Initialized
INFO - 2017-01-20 02:43:27 --> URI Class Initialized
DEBUG - 2017-01-20 02:43:27 --> No URI present. Default controller set.
INFO - 2017-01-20 02:43:27 --> Router Class Initialized
INFO - 2017-01-20 02:43:27 --> Output Class Initialized
INFO - 2017-01-20 02:43:27 --> Security Class Initialized
DEBUG - 2017-01-20 02:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 02:43:27 --> Input Class Initialized
INFO - 2017-01-20 02:43:27 --> Language Class Initialized
INFO - 2017-01-20 02:43:27 --> Loader Class Initialized
INFO - 2017-01-20 02:43:27 --> Database Driver Class Initialized
INFO - 2017-01-20 02:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 02:43:27 --> Controller Class Initialized
INFO - 2017-01-20 02:43:27 --> Helper loaded: url_helper
DEBUG - 2017-01-20 02:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 02:43:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 02:43:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 02:43:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 02:43:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 02:43:27 --> Final output sent to browser
DEBUG - 2017-01-20 02:43:27 --> Total execution time: 0.0142
INFO - 2017-01-20 02:43:32 --> Config Class Initialized
INFO - 2017-01-20 02:43:32 --> Hooks Class Initialized
DEBUG - 2017-01-20 02:43:32 --> UTF-8 Support Enabled
INFO - 2017-01-20 02:43:32 --> Utf8 Class Initialized
INFO - 2017-01-20 02:43:32 --> URI Class Initialized
DEBUG - 2017-01-20 02:43:32 --> No URI present. Default controller set.
INFO - 2017-01-20 02:43:32 --> Router Class Initialized
INFO - 2017-01-20 02:43:32 --> Output Class Initialized
INFO - 2017-01-20 02:43:32 --> Security Class Initialized
DEBUG - 2017-01-20 02:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 02:43:32 --> Input Class Initialized
INFO - 2017-01-20 02:43:32 --> Language Class Initialized
INFO - 2017-01-20 02:43:32 --> Loader Class Initialized
INFO - 2017-01-20 02:43:32 --> Database Driver Class Initialized
INFO - 2017-01-20 02:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 02:43:32 --> Controller Class Initialized
INFO - 2017-01-20 02:43:32 --> Helper loaded: url_helper
DEBUG - 2017-01-20 02:43:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 02:43:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 02:43:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 02:43:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 02:43:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 02:43:32 --> Final output sent to browser
DEBUG - 2017-01-20 02:43:32 --> Total execution time: 0.0139
INFO - 2017-01-20 02:43:38 --> Config Class Initialized
INFO - 2017-01-20 02:43:38 --> Hooks Class Initialized
DEBUG - 2017-01-20 02:43:38 --> UTF-8 Support Enabled
INFO - 2017-01-20 02:43:38 --> Utf8 Class Initialized
INFO - 2017-01-20 02:43:38 --> URI Class Initialized
INFO - 2017-01-20 02:43:38 --> Router Class Initialized
INFO - 2017-01-20 02:43:38 --> Output Class Initialized
INFO - 2017-01-20 02:43:38 --> Security Class Initialized
DEBUG - 2017-01-20 02:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 02:43:38 --> Input Class Initialized
INFO - 2017-01-20 02:43:38 --> Language Class Initialized
INFO - 2017-01-20 02:43:38 --> Loader Class Initialized
INFO - 2017-01-20 02:43:38 --> Database Driver Class Initialized
INFO - 2017-01-20 02:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 02:43:38 --> Controller Class Initialized
INFO - 2017-01-20 02:43:38 --> Helper loaded: url_helper
DEBUG - 2017-01-20 02:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 02:43:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 02:43:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 02:43:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 02:43:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 02:43:38 --> Final output sent to browser
DEBUG - 2017-01-20 02:43:38 --> Total execution time: 0.0139
INFO - 2017-01-20 02:44:44 --> Config Class Initialized
INFO - 2017-01-20 02:44:44 --> Hooks Class Initialized
DEBUG - 2017-01-20 02:44:44 --> UTF-8 Support Enabled
INFO - 2017-01-20 02:44:44 --> Utf8 Class Initialized
INFO - 2017-01-20 02:44:44 --> URI Class Initialized
INFO - 2017-01-20 02:44:44 --> Router Class Initialized
INFO - 2017-01-20 02:44:44 --> Output Class Initialized
INFO - 2017-01-20 02:44:44 --> Security Class Initialized
DEBUG - 2017-01-20 02:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 02:44:44 --> Input Class Initialized
INFO - 2017-01-20 02:44:44 --> Language Class Initialized
INFO - 2017-01-20 02:44:44 --> Loader Class Initialized
INFO - 2017-01-20 02:44:44 --> Database Driver Class Initialized
INFO - 2017-01-20 02:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 02:44:44 --> Controller Class Initialized
INFO - 2017-01-20 02:44:44 --> Helper loaded: url_helper
DEBUG - 2017-01-20 02:44:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 02:44:45 --> Config Class Initialized
INFO - 2017-01-20 02:44:45 --> Hooks Class Initialized
DEBUG - 2017-01-20 02:44:45 --> UTF-8 Support Enabled
INFO - 2017-01-20 02:44:45 --> Utf8 Class Initialized
INFO - 2017-01-20 02:44:45 --> URI Class Initialized
INFO - 2017-01-20 02:44:45 --> Router Class Initialized
INFO - 2017-01-20 02:44:45 --> Output Class Initialized
INFO - 2017-01-20 02:44:45 --> Security Class Initialized
DEBUG - 2017-01-20 02:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 02:44:45 --> Input Class Initialized
INFO - 2017-01-20 02:44:45 --> Language Class Initialized
INFO - 2017-01-20 02:44:45 --> Loader Class Initialized
INFO - 2017-01-20 02:44:45 --> Database Driver Class Initialized
INFO - 2017-01-20 02:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 02:44:45 --> Controller Class Initialized
INFO - 2017-01-20 02:44:45 --> Helper loaded: date_helper
DEBUG - 2017-01-20 02:44:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 02:44:45 --> Helper loaded: url_helper
INFO - 2017-01-20 02:44:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 02:44:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-20 02:44:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-20 02:44:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-20 02:44:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 02:44:45 --> Final output sent to browser
DEBUG - 2017-01-20 02:44:45 --> Total execution time: 0.0139
INFO - 2017-01-20 02:44:46 --> Config Class Initialized
INFO - 2017-01-20 02:44:46 --> Hooks Class Initialized
DEBUG - 2017-01-20 02:44:46 --> UTF-8 Support Enabled
INFO - 2017-01-20 02:44:46 --> Utf8 Class Initialized
INFO - 2017-01-20 02:44:46 --> URI Class Initialized
INFO - 2017-01-20 02:44:46 --> Router Class Initialized
INFO - 2017-01-20 02:44:46 --> Output Class Initialized
INFO - 2017-01-20 02:44:46 --> Security Class Initialized
DEBUG - 2017-01-20 02:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 02:44:46 --> Input Class Initialized
INFO - 2017-01-20 02:44:46 --> Language Class Initialized
INFO - 2017-01-20 02:44:46 --> Loader Class Initialized
INFO - 2017-01-20 02:44:46 --> Database Driver Class Initialized
INFO - 2017-01-20 02:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 02:44:46 --> Controller Class Initialized
INFO - 2017-01-20 02:44:46 --> Helper loaded: url_helper
DEBUG - 2017-01-20 02:44:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 02:44:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 02:44:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 02:44:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 02:44:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 02:44:46 --> Final output sent to browser
DEBUG - 2017-01-20 02:44:46 --> Total execution time: 0.0136
INFO - 2017-01-20 02:44:50 --> Config Class Initialized
INFO - 2017-01-20 02:44:50 --> Hooks Class Initialized
DEBUG - 2017-01-20 02:44:50 --> UTF-8 Support Enabled
INFO - 2017-01-20 02:44:50 --> Utf8 Class Initialized
INFO - 2017-01-20 02:44:50 --> URI Class Initialized
DEBUG - 2017-01-20 02:44:50 --> No URI present. Default controller set.
INFO - 2017-01-20 02:44:50 --> Router Class Initialized
INFO - 2017-01-20 02:44:50 --> Output Class Initialized
INFO - 2017-01-20 02:44:50 --> Security Class Initialized
DEBUG - 2017-01-20 02:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 02:44:50 --> Input Class Initialized
INFO - 2017-01-20 02:44:50 --> Language Class Initialized
INFO - 2017-01-20 02:44:50 --> Loader Class Initialized
INFO - 2017-01-20 02:44:50 --> Database Driver Class Initialized
INFO - 2017-01-20 02:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 02:44:50 --> Controller Class Initialized
INFO - 2017-01-20 02:44:50 --> Helper loaded: url_helper
DEBUG - 2017-01-20 02:44:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 02:44:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 02:44:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 02:44:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 02:44:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 02:44:50 --> Final output sent to browser
DEBUG - 2017-01-20 02:44:50 --> Total execution time: 0.0129
INFO - 2017-01-20 02:44:51 --> Config Class Initialized
INFO - 2017-01-20 02:44:51 --> Hooks Class Initialized
DEBUG - 2017-01-20 02:44:51 --> UTF-8 Support Enabled
INFO - 2017-01-20 02:44:51 --> Utf8 Class Initialized
INFO - 2017-01-20 02:44:51 --> URI Class Initialized
INFO - 2017-01-20 02:44:51 --> Router Class Initialized
INFO - 2017-01-20 02:44:51 --> Output Class Initialized
INFO - 2017-01-20 02:44:51 --> Security Class Initialized
DEBUG - 2017-01-20 02:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 02:44:51 --> Input Class Initialized
INFO - 2017-01-20 02:44:51 --> Language Class Initialized
INFO - 2017-01-20 02:44:51 --> Loader Class Initialized
INFO - 2017-01-20 02:44:51 --> Database Driver Class Initialized
INFO - 2017-01-20 02:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 02:44:51 --> Controller Class Initialized
INFO - 2017-01-20 02:44:51 --> Helper loaded: url_helper
DEBUG - 2017-01-20 02:44:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 02:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 02:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 02:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 02:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 02:44:51 --> Final output sent to browser
DEBUG - 2017-01-20 02:44:51 --> Total execution time: 0.0138
INFO - 2017-01-20 02:44:56 --> Config Class Initialized
INFO - 2017-01-20 02:44:56 --> Hooks Class Initialized
DEBUG - 2017-01-20 02:44:56 --> UTF-8 Support Enabled
INFO - 2017-01-20 02:44:56 --> Utf8 Class Initialized
INFO - 2017-01-20 02:44:56 --> URI Class Initialized
INFO - 2017-01-20 02:44:56 --> Router Class Initialized
INFO - 2017-01-20 02:44:56 --> Output Class Initialized
INFO - 2017-01-20 02:44:56 --> Security Class Initialized
DEBUG - 2017-01-20 02:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 02:44:56 --> Input Class Initialized
INFO - 2017-01-20 02:44:56 --> Language Class Initialized
INFO - 2017-01-20 02:44:56 --> Loader Class Initialized
INFO - 2017-01-20 02:44:56 --> Database Driver Class Initialized
INFO - 2017-01-20 02:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 02:44:56 --> Controller Class Initialized
INFO - 2017-01-20 02:44:56 --> Helper loaded: url_helper
DEBUG - 2017-01-20 02:44:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 02:44:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 02:44:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 02:44:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 02:44:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 02:44:56 --> Final output sent to browser
DEBUG - 2017-01-20 02:44:56 --> Total execution time: 0.0148
INFO - 2017-01-20 02:44:57 --> Config Class Initialized
INFO - 2017-01-20 02:44:57 --> Hooks Class Initialized
DEBUG - 2017-01-20 02:44:57 --> UTF-8 Support Enabled
INFO - 2017-01-20 02:44:57 --> Utf8 Class Initialized
INFO - 2017-01-20 02:44:57 --> URI Class Initialized
INFO - 2017-01-20 02:44:57 --> Router Class Initialized
INFO - 2017-01-20 02:44:57 --> Output Class Initialized
INFO - 2017-01-20 02:44:57 --> Security Class Initialized
DEBUG - 2017-01-20 02:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 02:44:57 --> Input Class Initialized
INFO - 2017-01-20 02:44:57 --> Language Class Initialized
INFO - 2017-01-20 02:44:57 --> Loader Class Initialized
INFO - 2017-01-20 02:44:57 --> Database Driver Class Initialized
INFO - 2017-01-20 02:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 02:44:57 --> Controller Class Initialized
INFO - 2017-01-20 02:44:57 --> Helper loaded: url_helper
DEBUG - 2017-01-20 02:44:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 02:44:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 02:44:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 02:44:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 02:44:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 02:44:57 --> Final output sent to browser
DEBUG - 2017-01-20 02:44:57 --> Total execution time: 0.0135
INFO - 2017-01-20 02:45:02 --> Config Class Initialized
INFO - 2017-01-20 02:45:02 --> Hooks Class Initialized
DEBUG - 2017-01-20 02:45:02 --> UTF-8 Support Enabled
INFO - 2017-01-20 02:45:02 --> Utf8 Class Initialized
INFO - 2017-01-20 02:45:02 --> URI Class Initialized
INFO - 2017-01-20 02:45:02 --> Router Class Initialized
INFO - 2017-01-20 02:45:02 --> Output Class Initialized
INFO - 2017-01-20 02:45:02 --> Security Class Initialized
DEBUG - 2017-01-20 02:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 02:45:02 --> Input Class Initialized
INFO - 2017-01-20 02:45:02 --> Language Class Initialized
INFO - 2017-01-20 02:45:02 --> Loader Class Initialized
INFO - 2017-01-20 02:45:02 --> Database Driver Class Initialized
INFO - 2017-01-20 02:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 02:45:02 --> Controller Class Initialized
INFO - 2017-01-20 02:45:02 --> Helper loaded: url_helper
DEBUG - 2017-01-20 02:45:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 02:45:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 02:45:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 02:45:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 02:45:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 02:45:02 --> Final output sent to browser
DEBUG - 2017-01-20 02:45:02 --> Total execution time: 0.0142
INFO - 2017-01-20 02:45:03 --> Config Class Initialized
INFO - 2017-01-20 02:45:03 --> Hooks Class Initialized
DEBUG - 2017-01-20 02:45:03 --> UTF-8 Support Enabled
INFO - 2017-01-20 02:45:03 --> Utf8 Class Initialized
INFO - 2017-01-20 02:45:03 --> URI Class Initialized
INFO - 2017-01-20 02:45:03 --> Router Class Initialized
INFO - 2017-01-20 02:45:03 --> Output Class Initialized
INFO - 2017-01-20 02:45:03 --> Security Class Initialized
DEBUG - 2017-01-20 02:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 02:45:03 --> Input Class Initialized
INFO - 2017-01-20 02:45:03 --> Language Class Initialized
INFO - 2017-01-20 02:45:03 --> Loader Class Initialized
INFO - 2017-01-20 02:45:03 --> Database Driver Class Initialized
INFO - 2017-01-20 02:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 02:45:03 --> Controller Class Initialized
INFO - 2017-01-20 02:45:03 --> Helper loaded: url_helper
DEBUG - 2017-01-20 02:45:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 02:45:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 02:45:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 02:45:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 02:45:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 02:45:03 --> Final output sent to browser
DEBUG - 2017-01-20 02:45:03 --> Total execution time: 0.0135
INFO - 2017-01-20 03:16:23 --> Config Class Initialized
INFO - 2017-01-20 03:16:23 --> Hooks Class Initialized
DEBUG - 2017-01-20 03:16:23 --> UTF-8 Support Enabled
INFO - 2017-01-20 03:16:23 --> Utf8 Class Initialized
INFO - 2017-01-20 03:16:23 --> URI Class Initialized
DEBUG - 2017-01-20 03:16:23 --> No URI present. Default controller set.
INFO - 2017-01-20 03:16:23 --> Router Class Initialized
INFO - 2017-01-20 03:16:23 --> Output Class Initialized
INFO - 2017-01-20 03:16:23 --> Security Class Initialized
DEBUG - 2017-01-20 03:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 03:16:23 --> Input Class Initialized
INFO - 2017-01-20 03:16:23 --> Language Class Initialized
INFO - 2017-01-20 03:16:23 --> Loader Class Initialized
INFO - 2017-01-20 03:16:23 --> Database Driver Class Initialized
INFO - 2017-01-20 03:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 03:16:23 --> Controller Class Initialized
INFO - 2017-01-20 03:16:23 --> Helper loaded: url_helper
DEBUG - 2017-01-20 03:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 03:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 03:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 03:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 03:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 03:16:23 --> Final output sent to browser
DEBUG - 2017-01-20 03:16:23 --> Total execution time: 0.0135
INFO - 2017-01-20 03:16:28 --> Config Class Initialized
INFO - 2017-01-20 03:16:28 --> Hooks Class Initialized
DEBUG - 2017-01-20 03:16:28 --> UTF-8 Support Enabled
INFO - 2017-01-20 03:16:28 --> Utf8 Class Initialized
INFO - 2017-01-20 03:16:28 --> URI Class Initialized
INFO - 2017-01-20 03:16:28 --> Router Class Initialized
INFO - 2017-01-20 03:16:28 --> Output Class Initialized
INFO - 2017-01-20 03:16:28 --> Security Class Initialized
DEBUG - 2017-01-20 03:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 03:16:28 --> Input Class Initialized
INFO - 2017-01-20 03:16:28 --> Language Class Initialized
INFO - 2017-01-20 03:16:28 --> Loader Class Initialized
INFO - 2017-01-20 03:16:28 --> Database Driver Class Initialized
INFO - 2017-01-20 03:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 03:16:28 --> Controller Class Initialized
INFO - 2017-01-20 03:16:28 --> Helper loaded: url_helper
DEBUG - 2017-01-20 03:16:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 03:16:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 03:16:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 03:16:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 03:16:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 03:16:28 --> Final output sent to browser
DEBUG - 2017-01-20 03:16:28 --> Total execution time: 0.0133
INFO - 2017-01-20 03:16:37 --> Config Class Initialized
INFO - 2017-01-20 03:16:37 --> Hooks Class Initialized
DEBUG - 2017-01-20 03:16:37 --> UTF-8 Support Enabled
INFO - 2017-01-20 03:16:37 --> Utf8 Class Initialized
INFO - 2017-01-20 03:16:37 --> URI Class Initialized
INFO - 2017-01-20 03:16:37 --> Router Class Initialized
INFO - 2017-01-20 03:16:37 --> Output Class Initialized
INFO - 2017-01-20 03:16:37 --> Security Class Initialized
DEBUG - 2017-01-20 03:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 03:16:37 --> Input Class Initialized
INFO - 2017-01-20 03:16:37 --> Language Class Initialized
INFO - 2017-01-20 03:16:37 --> Loader Class Initialized
INFO - 2017-01-20 03:16:37 --> Database Driver Class Initialized
INFO - 2017-01-20 03:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 03:16:37 --> Controller Class Initialized
INFO - 2017-01-20 03:16:37 --> Helper loaded: url_helper
DEBUG - 2017-01-20 03:16:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 03:16:38 --> Config Class Initialized
INFO - 2017-01-20 03:16:38 --> Hooks Class Initialized
DEBUG - 2017-01-20 03:16:38 --> UTF-8 Support Enabled
INFO - 2017-01-20 03:16:38 --> Utf8 Class Initialized
INFO - 2017-01-20 03:16:38 --> URI Class Initialized
INFO - 2017-01-20 03:16:38 --> Router Class Initialized
INFO - 2017-01-20 03:16:38 --> Output Class Initialized
INFO - 2017-01-20 03:16:38 --> Security Class Initialized
DEBUG - 2017-01-20 03:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 03:16:38 --> Input Class Initialized
INFO - 2017-01-20 03:16:38 --> Language Class Initialized
INFO - 2017-01-20 03:16:38 --> Loader Class Initialized
INFO - 2017-01-20 03:16:38 --> Database Driver Class Initialized
INFO - 2017-01-20 03:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 03:16:38 --> Controller Class Initialized
INFO - 2017-01-20 03:16:38 --> Helper loaded: date_helper
DEBUG - 2017-01-20 03:16:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 03:16:38 --> Helper loaded: url_helper
INFO - 2017-01-20 03:16:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 03:16:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-20 03:16:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-20 03:16:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-20 03:16:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 03:16:38 --> Final output sent to browser
DEBUG - 2017-01-20 03:16:38 --> Total execution time: 0.0141
INFO - 2017-01-20 03:16:39 --> Config Class Initialized
INFO - 2017-01-20 03:16:39 --> Hooks Class Initialized
DEBUG - 2017-01-20 03:16:39 --> UTF-8 Support Enabled
INFO - 2017-01-20 03:16:39 --> Utf8 Class Initialized
INFO - 2017-01-20 03:16:39 --> URI Class Initialized
INFO - 2017-01-20 03:16:39 --> Router Class Initialized
INFO - 2017-01-20 03:16:39 --> Output Class Initialized
INFO - 2017-01-20 03:16:39 --> Security Class Initialized
DEBUG - 2017-01-20 03:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 03:16:39 --> Input Class Initialized
INFO - 2017-01-20 03:16:39 --> Language Class Initialized
INFO - 2017-01-20 03:16:39 --> Loader Class Initialized
INFO - 2017-01-20 03:16:39 --> Database Driver Class Initialized
INFO - 2017-01-20 03:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 03:16:39 --> Controller Class Initialized
INFO - 2017-01-20 03:16:39 --> Helper loaded: url_helper
DEBUG - 2017-01-20 03:16:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 03:16:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 03:16:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 03:16:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 03:16:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 03:16:39 --> Final output sent to browser
DEBUG - 2017-01-20 03:16:39 --> Total execution time: 0.0134
INFO - 2017-01-20 03:16:44 --> Config Class Initialized
INFO - 2017-01-20 03:16:44 --> Hooks Class Initialized
DEBUG - 2017-01-20 03:16:44 --> UTF-8 Support Enabled
INFO - 2017-01-20 03:16:44 --> Utf8 Class Initialized
INFO - 2017-01-20 03:16:44 --> URI Class Initialized
DEBUG - 2017-01-20 03:16:44 --> No URI present. Default controller set.
INFO - 2017-01-20 03:16:44 --> Router Class Initialized
INFO - 2017-01-20 03:16:44 --> Output Class Initialized
INFO - 2017-01-20 03:16:44 --> Security Class Initialized
DEBUG - 2017-01-20 03:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 03:16:44 --> Input Class Initialized
INFO - 2017-01-20 03:16:44 --> Language Class Initialized
INFO - 2017-01-20 03:16:44 --> Loader Class Initialized
INFO - 2017-01-20 03:16:44 --> Database Driver Class Initialized
INFO - 2017-01-20 03:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 03:16:44 --> Controller Class Initialized
INFO - 2017-01-20 03:16:44 --> Helper loaded: url_helper
DEBUG - 2017-01-20 03:16:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 03:16:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 03:16:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 03:16:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 03:16:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 03:16:44 --> Final output sent to browser
DEBUG - 2017-01-20 03:16:44 --> Total execution time: 0.0132
INFO - 2017-01-20 03:16:46 --> Config Class Initialized
INFO - 2017-01-20 03:16:46 --> Hooks Class Initialized
DEBUG - 2017-01-20 03:16:46 --> UTF-8 Support Enabled
INFO - 2017-01-20 03:16:46 --> Utf8 Class Initialized
INFO - 2017-01-20 03:16:46 --> URI Class Initialized
INFO - 2017-01-20 03:16:46 --> Router Class Initialized
INFO - 2017-01-20 03:16:46 --> Output Class Initialized
INFO - 2017-01-20 03:16:46 --> Security Class Initialized
DEBUG - 2017-01-20 03:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 03:16:46 --> Input Class Initialized
INFO - 2017-01-20 03:16:46 --> Language Class Initialized
INFO - 2017-01-20 03:16:46 --> Loader Class Initialized
INFO - 2017-01-20 03:16:46 --> Database Driver Class Initialized
INFO - 2017-01-20 03:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 03:16:46 --> Controller Class Initialized
INFO - 2017-01-20 03:16:46 --> Helper loaded: url_helper
DEBUG - 2017-01-20 03:16:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 03:16:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 03:16:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 03:16:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 03:16:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 03:16:46 --> Final output sent to browser
DEBUG - 2017-01-20 03:16:46 --> Total execution time: 0.0129
INFO - 2017-01-20 03:39:17 --> Config Class Initialized
INFO - 2017-01-20 03:39:17 --> Hooks Class Initialized
DEBUG - 2017-01-20 03:39:17 --> UTF-8 Support Enabled
INFO - 2017-01-20 03:39:17 --> Utf8 Class Initialized
INFO - 2017-01-20 03:39:17 --> URI Class Initialized
DEBUG - 2017-01-20 03:39:17 --> No URI present. Default controller set.
INFO - 2017-01-20 03:39:17 --> Router Class Initialized
INFO - 2017-01-20 03:39:17 --> Output Class Initialized
INFO - 2017-01-20 03:39:17 --> Security Class Initialized
DEBUG - 2017-01-20 03:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 03:39:17 --> Input Class Initialized
INFO - 2017-01-20 03:39:17 --> Language Class Initialized
INFO - 2017-01-20 03:39:17 --> Loader Class Initialized
INFO - 2017-01-20 03:39:17 --> Database Driver Class Initialized
INFO - 2017-01-20 03:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 03:39:17 --> Controller Class Initialized
INFO - 2017-01-20 03:39:17 --> Helper loaded: url_helper
DEBUG - 2017-01-20 03:39:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 03:39:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 03:39:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 03:39:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 03:39:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 03:39:17 --> Final output sent to browser
DEBUG - 2017-01-20 03:39:17 --> Total execution time: 0.0129
INFO - 2017-01-20 03:39:24 --> Config Class Initialized
INFO - 2017-01-20 03:39:24 --> Hooks Class Initialized
DEBUG - 2017-01-20 03:39:24 --> UTF-8 Support Enabled
INFO - 2017-01-20 03:39:24 --> Utf8 Class Initialized
INFO - 2017-01-20 03:39:24 --> URI Class Initialized
INFO - 2017-01-20 03:39:24 --> Router Class Initialized
INFO - 2017-01-20 03:39:24 --> Output Class Initialized
INFO - 2017-01-20 03:39:24 --> Security Class Initialized
DEBUG - 2017-01-20 03:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 03:39:24 --> Input Class Initialized
INFO - 2017-01-20 03:39:24 --> Language Class Initialized
INFO - 2017-01-20 03:39:24 --> Loader Class Initialized
INFO - 2017-01-20 03:39:24 --> Database Driver Class Initialized
INFO - 2017-01-20 03:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 03:39:24 --> Controller Class Initialized
INFO - 2017-01-20 03:39:24 --> Helper loaded: url_helper
DEBUG - 2017-01-20 03:39:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 03:39:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 03:39:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 03:39:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 03:39:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 03:39:24 --> Final output sent to browser
DEBUG - 2017-01-20 03:39:24 --> Total execution time: 0.0140
INFO - 2017-01-20 03:40:33 --> Config Class Initialized
INFO - 2017-01-20 03:40:33 --> Hooks Class Initialized
DEBUG - 2017-01-20 03:40:33 --> UTF-8 Support Enabled
INFO - 2017-01-20 03:40:33 --> Utf8 Class Initialized
INFO - 2017-01-20 03:40:33 --> URI Class Initialized
INFO - 2017-01-20 03:40:33 --> Router Class Initialized
INFO - 2017-01-20 03:40:33 --> Output Class Initialized
INFO - 2017-01-20 03:40:33 --> Security Class Initialized
DEBUG - 2017-01-20 03:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 03:40:33 --> Input Class Initialized
INFO - 2017-01-20 03:40:33 --> Language Class Initialized
INFO - 2017-01-20 03:40:33 --> Loader Class Initialized
INFO - 2017-01-20 03:40:33 --> Database Driver Class Initialized
INFO - 2017-01-20 03:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 03:40:33 --> Controller Class Initialized
INFO - 2017-01-20 03:40:33 --> Helper loaded: url_helper
DEBUG - 2017-01-20 03:40:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 03:40:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 03:40:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 03:40:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 03:40:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 03:40:33 --> Final output sent to browser
DEBUG - 2017-01-20 03:40:33 --> Total execution time: 0.0141
INFO - 2017-01-20 03:40:35 --> Config Class Initialized
INFO - 2017-01-20 03:40:35 --> Hooks Class Initialized
DEBUG - 2017-01-20 03:40:35 --> UTF-8 Support Enabled
INFO - 2017-01-20 03:40:35 --> Utf8 Class Initialized
INFO - 2017-01-20 03:40:35 --> URI Class Initialized
INFO - 2017-01-20 03:40:35 --> Router Class Initialized
INFO - 2017-01-20 03:40:35 --> Output Class Initialized
INFO - 2017-01-20 03:40:35 --> Security Class Initialized
DEBUG - 2017-01-20 03:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 03:40:35 --> Input Class Initialized
INFO - 2017-01-20 03:40:35 --> Language Class Initialized
INFO - 2017-01-20 03:40:35 --> Loader Class Initialized
INFO - 2017-01-20 03:40:35 --> Database Driver Class Initialized
INFO - 2017-01-20 03:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 03:40:35 --> Controller Class Initialized
INFO - 2017-01-20 03:40:35 --> Helper loaded: url_helper
DEBUG - 2017-01-20 03:40:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 03:40:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 03:40:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 03:40:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 03:40:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 03:40:35 --> Final output sent to browser
DEBUG - 2017-01-20 03:40:35 --> Total execution time: 0.0136
INFO - 2017-01-20 03:52:00 --> Config Class Initialized
INFO - 2017-01-20 03:52:00 --> Hooks Class Initialized
DEBUG - 2017-01-20 03:52:00 --> UTF-8 Support Enabled
INFO - 2017-01-20 03:52:00 --> Utf8 Class Initialized
INFO - 2017-01-20 03:52:00 --> URI Class Initialized
INFO - 2017-01-20 03:52:00 --> Router Class Initialized
INFO - 2017-01-20 03:52:00 --> Output Class Initialized
INFO - 2017-01-20 03:52:00 --> Security Class Initialized
DEBUG - 2017-01-20 03:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 03:52:00 --> Input Class Initialized
INFO - 2017-01-20 03:52:00 --> Language Class Initialized
INFO - 2017-01-20 03:52:00 --> Loader Class Initialized
INFO - 2017-01-20 03:52:00 --> Database Driver Class Initialized
INFO - 2017-01-20 03:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 03:52:00 --> Controller Class Initialized
INFO - 2017-01-20 03:52:00 --> Helper loaded: url_helper
DEBUG - 2017-01-20 03:52:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-20 03:52:01 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-20 03:52:01 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Nancy Martinez')
INFO - 2017-01-20 03:52:01 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-20 03:52:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-20 03:52:02 --> Config Class Initialized
INFO - 2017-01-20 03:52:02 --> Hooks Class Initialized
DEBUG - 2017-01-20 03:52:02 --> UTF-8 Support Enabled
INFO - 2017-01-20 03:52:02 --> Utf8 Class Initialized
INFO - 2017-01-20 03:52:02 --> URI Class Initialized
INFO - 2017-01-20 03:52:02 --> Router Class Initialized
INFO - 2017-01-20 03:52:02 --> Output Class Initialized
INFO - 2017-01-20 03:52:02 --> Security Class Initialized
DEBUG - 2017-01-20 03:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 03:52:02 --> Input Class Initialized
INFO - 2017-01-20 03:52:02 --> Language Class Initialized
INFO - 2017-01-20 03:52:02 --> Loader Class Initialized
INFO - 2017-01-20 03:52:02 --> Database Driver Class Initialized
INFO - 2017-01-20 03:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 03:52:02 --> Controller Class Initialized
INFO - 2017-01-20 03:52:02 --> Helper loaded: url_helper
DEBUG - 2017-01-20 03:52:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 03:52:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 03:52:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 03:52:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 03:52:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 03:52:02 --> Final output sent to browser
DEBUG - 2017-01-20 03:52:02 --> Total execution time: 0.0136
INFO - 2017-01-20 06:06:32 --> Config Class Initialized
INFO - 2017-01-20 06:06:32 --> Hooks Class Initialized
DEBUG - 2017-01-20 06:06:32 --> UTF-8 Support Enabled
INFO - 2017-01-20 06:06:32 --> Utf8 Class Initialized
INFO - 2017-01-20 06:06:32 --> URI Class Initialized
INFO - 2017-01-20 06:06:32 --> Router Class Initialized
INFO - 2017-01-20 06:06:32 --> Output Class Initialized
INFO - 2017-01-20 06:06:32 --> Security Class Initialized
DEBUG - 2017-01-20 06:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 06:06:32 --> Input Class Initialized
INFO - 2017-01-20 06:06:32 --> Language Class Initialized
INFO - 2017-01-20 06:06:32 --> Loader Class Initialized
INFO - 2017-01-20 06:06:32 --> Database Driver Class Initialized
INFO - 2017-01-20 06:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 06:06:32 --> Controller Class Initialized
INFO - 2017-01-20 06:06:32 --> Helper loaded: url_helper
DEBUG - 2017-01-20 06:06:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 06:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 06:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 06:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 06:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 06:06:32 --> Final output sent to browser
DEBUG - 2017-01-20 06:06:32 --> Total execution time: 0.0669
INFO - 2017-01-20 06:06:32 --> Config Class Initialized
INFO - 2017-01-20 06:06:32 --> Hooks Class Initialized
DEBUG - 2017-01-20 06:06:32 --> UTF-8 Support Enabled
INFO - 2017-01-20 06:06:32 --> Utf8 Class Initialized
INFO - 2017-01-20 06:06:32 --> URI Class Initialized
DEBUG - 2017-01-20 06:06:32 --> No URI present. Default controller set.
INFO - 2017-01-20 06:06:32 --> Router Class Initialized
INFO - 2017-01-20 06:06:32 --> Output Class Initialized
INFO - 2017-01-20 06:06:32 --> Security Class Initialized
DEBUG - 2017-01-20 06:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 06:06:32 --> Input Class Initialized
INFO - 2017-01-20 06:06:32 --> Language Class Initialized
INFO - 2017-01-20 06:06:32 --> Loader Class Initialized
INFO - 2017-01-20 06:06:32 --> Database Driver Class Initialized
INFO - 2017-01-20 06:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 06:06:32 --> Controller Class Initialized
INFO - 2017-01-20 06:06:32 --> Helper loaded: url_helper
DEBUG - 2017-01-20 06:06:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 06:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 06:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 06:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 06:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 06:06:32 --> Final output sent to browser
DEBUG - 2017-01-20 06:06:32 --> Total execution time: 0.0241
INFO - 2017-01-20 12:54:19 --> Config Class Initialized
INFO - 2017-01-20 12:54:19 --> Hooks Class Initialized
DEBUG - 2017-01-20 12:54:19 --> UTF-8 Support Enabled
INFO - 2017-01-20 12:54:19 --> Utf8 Class Initialized
INFO - 2017-01-20 12:54:19 --> URI Class Initialized
INFO - 2017-01-20 12:54:19 --> Router Class Initialized
INFO - 2017-01-20 12:54:19 --> Output Class Initialized
INFO - 2017-01-20 12:54:19 --> Security Class Initialized
DEBUG - 2017-01-20 12:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 12:54:19 --> Input Class Initialized
INFO - 2017-01-20 12:54:19 --> Language Class Initialized
INFO - 2017-01-20 12:54:19 --> Loader Class Initialized
INFO - 2017-01-20 12:54:19 --> Database Driver Class Initialized
INFO - 2017-01-20 12:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 12:54:19 --> Controller Class Initialized
INFO - 2017-01-20 12:54:19 --> Helper loaded: url_helper
DEBUG - 2017-01-20 12:54:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 12:54:19 --> Helper loaded: form_helper
INFO - 2017-01-20 12:54:19 --> Form Validation Class Initialized
INFO - 2017-01-20 12:54:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-20 12:54:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-20 12:54:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-20 12:54:19 --> Final output sent to browser
DEBUG - 2017-01-20 12:54:19 --> Total execution time: 0.0240
INFO - 2017-01-20 13:39:16 --> Config Class Initialized
INFO - 2017-01-20 13:39:16 --> Hooks Class Initialized
DEBUG - 2017-01-20 13:39:16 --> UTF-8 Support Enabled
INFO - 2017-01-20 13:39:16 --> Utf8 Class Initialized
INFO - 2017-01-20 13:39:16 --> URI Class Initialized
DEBUG - 2017-01-20 13:39:16 --> No URI present. Default controller set.
INFO - 2017-01-20 13:39:16 --> Router Class Initialized
INFO - 2017-01-20 13:39:16 --> Output Class Initialized
INFO - 2017-01-20 13:39:16 --> Security Class Initialized
DEBUG - 2017-01-20 13:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 13:39:16 --> Input Class Initialized
INFO - 2017-01-20 13:39:16 --> Language Class Initialized
INFO - 2017-01-20 13:39:16 --> Loader Class Initialized
INFO - 2017-01-20 13:39:16 --> Database Driver Class Initialized
INFO - 2017-01-20 13:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 13:39:16 --> Controller Class Initialized
INFO - 2017-01-20 13:39:16 --> Helper loaded: url_helper
DEBUG - 2017-01-20 13:39:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 13:39:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 13:39:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 13:39:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 13:39:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 13:39:16 --> Final output sent to browser
DEBUG - 2017-01-20 13:39:16 --> Total execution time: 0.0180
INFO - 2017-01-20 16:15:40 --> Config Class Initialized
INFO - 2017-01-20 16:15:40 --> Hooks Class Initialized
DEBUG - 2017-01-20 16:15:40 --> UTF-8 Support Enabled
INFO - 2017-01-20 16:15:40 --> Utf8 Class Initialized
INFO - 2017-01-20 16:15:40 --> URI Class Initialized
DEBUG - 2017-01-20 16:15:40 --> No URI present. Default controller set.
INFO - 2017-01-20 16:15:40 --> Router Class Initialized
INFO - 2017-01-20 16:15:40 --> Output Class Initialized
INFO - 2017-01-20 16:15:40 --> Security Class Initialized
DEBUG - 2017-01-20 16:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 16:15:40 --> Input Class Initialized
INFO - 2017-01-20 16:15:40 --> Language Class Initialized
INFO - 2017-01-20 16:15:40 --> Loader Class Initialized
INFO - 2017-01-20 16:15:40 --> Database Driver Class Initialized
INFO - 2017-01-20 16:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 16:15:40 --> Controller Class Initialized
INFO - 2017-01-20 16:15:40 --> Helper loaded: url_helper
DEBUG - 2017-01-20 16:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 16:15:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 16:15:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 16:15:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 16:15:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 16:15:40 --> Final output sent to browser
DEBUG - 2017-01-20 16:15:40 --> Total execution time: 0.0529
INFO - 2017-01-20 17:51:38 --> Config Class Initialized
INFO - 2017-01-20 17:51:38 --> Hooks Class Initialized
DEBUG - 2017-01-20 17:51:38 --> UTF-8 Support Enabled
INFO - 2017-01-20 17:51:38 --> Utf8 Class Initialized
INFO - 2017-01-20 17:51:38 --> URI Class Initialized
DEBUG - 2017-01-20 17:51:38 --> No URI present. Default controller set.
INFO - 2017-01-20 17:51:38 --> Router Class Initialized
INFO - 2017-01-20 17:51:38 --> Output Class Initialized
INFO - 2017-01-20 17:51:38 --> Security Class Initialized
DEBUG - 2017-01-20 17:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 17:51:38 --> Input Class Initialized
INFO - 2017-01-20 17:51:38 --> Language Class Initialized
INFO - 2017-01-20 17:51:38 --> Loader Class Initialized
INFO - 2017-01-20 17:51:38 --> Database Driver Class Initialized
INFO - 2017-01-20 17:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 17:51:38 --> Controller Class Initialized
INFO - 2017-01-20 17:51:38 --> Helper loaded: url_helper
DEBUG - 2017-01-20 17:51:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 17:51:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 17:51:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 17:51:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 17:51:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 17:51:38 --> Final output sent to browser
DEBUG - 2017-01-20 17:51:38 --> Total execution time: 0.0387
INFO - 2017-01-20 17:51:47 --> Config Class Initialized
INFO - 2017-01-20 17:51:47 --> Hooks Class Initialized
DEBUG - 2017-01-20 17:51:47 --> UTF-8 Support Enabled
INFO - 2017-01-20 17:51:47 --> Utf8 Class Initialized
INFO - 2017-01-20 17:51:47 --> URI Class Initialized
INFO - 2017-01-20 17:51:47 --> Router Class Initialized
INFO - 2017-01-20 17:51:47 --> Output Class Initialized
INFO - 2017-01-20 17:51:47 --> Security Class Initialized
DEBUG - 2017-01-20 17:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 17:51:47 --> Input Class Initialized
INFO - 2017-01-20 17:51:47 --> Language Class Initialized
INFO - 2017-01-20 17:51:47 --> Loader Class Initialized
INFO - 2017-01-20 17:51:47 --> Database Driver Class Initialized
INFO - 2017-01-20 17:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 17:51:47 --> Controller Class Initialized
INFO - 2017-01-20 17:51:47 --> Helper loaded: url_helper
DEBUG - 2017-01-20 17:51:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 17:51:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 17:51:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 17:51:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 17:51:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 17:51:47 --> Final output sent to browser
DEBUG - 2017-01-20 17:51:47 --> Total execution time: 0.0220
INFO - 2017-01-20 18:02:15 --> Config Class Initialized
INFO - 2017-01-20 18:02:15 --> Hooks Class Initialized
DEBUG - 2017-01-20 18:02:15 --> UTF-8 Support Enabled
INFO - 2017-01-20 18:02:15 --> Utf8 Class Initialized
INFO - 2017-01-20 18:02:15 --> URI Class Initialized
DEBUG - 2017-01-20 18:02:15 --> No URI present. Default controller set.
INFO - 2017-01-20 18:02:15 --> Router Class Initialized
INFO - 2017-01-20 18:02:15 --> Output Class Initialized
INFO - 2017-01-20 18:02:15 --> Security Class Initialized
DEBUG - 2017-01-20 18:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 18:02:15 --> Input Class Initialized
INFO - 2017-01-20 18:02:15 --> Language Class Initialized
INFO - 2017-01-20 18:02:15 --> Loader Class Initialized
INFO - 2017-01-20 18:02:15 --> Database Driver Class Initialized
INFO - 2017-01-20 18:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 18:02:15 --> Controller Class Initialized
INFO - 2017-01-20 18:02:15 --> Helper loaded: url_helper
DEBUG - 2017-01-20 18:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 18:02:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 18:02:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 18:02:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 18:02:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 18:02:15 --> Final output sent to browser
DEBUG - 2017-01-20 18:02:15 --> Total execution time: 0.0138
INFO - 2017-01-20 18:02:19 --> Config Class Initialized
INFO - 2017-01-20 18:02:19 --> Hooks Class Initialized
DEBUG - 2017-01-20 18:02:19 --> UTF-8 Support Enabled
INFO - 2017-01-20 18:02:19 --> Utf8 Class Initialized
INFO - 2017-01-20 18:02:19 --> URI Class Initialized
INFO - 2017-01-20 18:02:19 --> Router Class Initialized
INFO - 2017-01-20 18:02:19 --> Output Class Initialized
INFO - 2017-01-20 18:02:19 --> Security Class Initialized
DEBUG - 2017-01-20 18:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 18:02:19 --> Input Class Initialized
INFO - 2017-01-20 18:02:19 --> Language Class Initialized
INFO - 2017-01-20 18:02:19 --> Loader Class Initialized
INFO - 2017-01-20 18:02:19 --> Database Driver Class Initialized
INFO - 2017-01-20 18:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 18:02:19 --> Controller Class Initialized
INFO - 2017-01-20 18:02:19 --> Helper loaded: url_helper
DEBUG - 2017-01-20 18:02:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 18:02:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 18:02:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 18:02:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 18:02:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 18:02:19 --> Final output sent to browser
DEBUG - 2017-01-20 18:02:19 --> Total execution time: 0.0142
INFO - 2017-01-20 18:02:37 --> Config Class Initialized
INFO - 2017-01-20 18:02:37 --> Hooks Class Initialized
DEBUG - 2017-01-20 18:02:37 --> UTF-8 Support Enabled
INFO - 2017-01-20 18:02:37 --> Utf8 Class Initialized
INFO - 2017-01-20 18:02:37 --> URI Class Initialized
INFO - 2017-01-20 18:02:37 --> Router Class Initialized
INFO - 2017-01-20 18:02:37 --> Output Class Initialized
INFO - 2017-01-20 18:02:37 --> Security Class Initialized
DEBUG - 2017-01-20 18:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 18:02:37 --> Input Class Initialized
INFO - 2017-01-20 18:02:37 --> Language Class Initialized
INFO - 2017-01-20 18:02:37 --> Loader Class Initialized
INFO - 2017-01-20 18:02:37 --> Database Driver Class Initialized
INFO - 2017-01-20 18:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 18:02:37 --> Controller Class Initialized
INFO - 2017-01-20 18:02:37 --> Helper loaded: url_helper
DEBUG - 2017-01-20 18:02:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 18:02:39 --> Config Class Initialized
INFO - 2017-01-20 18:02:39 --> Hooks Class Initialized
DEBUG - 2017-01-20 18:02:39 --> UTF-8 Support Enabled
INFO - 2017-01-20 18:02:39 --> Utf8 Class Initialized
INFO - 2017-01-20 18:02:39 --> URI Class Initialized
INFO - 2017-01-20 18:02:39 --> Router Class Initialized
INFO - 2017-01-20 18:02:39 --> Output Class Initialized
INFO - 2017-01-20 18:02:39 --> Security Class Initialized
DEBUG - 2017-01-20 18:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 18:02:39 --> Input Class Initialized
INFO - 2017-01-20 18:02:39 --> Language Class Initialized
INFO - 2017-01-20 18:02:40 --> Loader Class Initialized
INFO - 2017-01-20 18:02:40 --> Database Driver Class Initialized
INFO - 2017-01-20 18:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 18:02:40 --> Controller Class Initialized
INFO - 2017-01-20 18:02:40 --> Helper loaded: date_helper
DEBUG - 2017-01-20 18:02:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 18:02:40 --> Helper loaded: url_helper
INFO - 2017-01-20 18:02:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 18:02:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-20 18:02:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-20 18:02:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-20 18:02:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 18:02:40 --> Final output sent to browser
DEBUG - 2017-01-20 18:02:40 --> Total execution time: 0.5763
INFO - 2017-01-20 18:02:42 --> Config Class Initialized
INFO - 2017-01-20 18:02:42 --> Hooks Class Initialized
DEBUG - 2017-01-20 18:02:42 --> UTF-8 Support Enabled
INFO - 2017-01-20 18:02:42 --> Utf8 Class Initialized
INFO - 2017-01-20 18:02:42 --> URI Class Initialized
INFO - 2017-01-20 18:02:42 --> Router Class Initialized
INFO - 2017-01-20 18:02:42 --> Output Class Initialized
INFO - 2017-01-20 18:02:42 --> Security Class Initialized
DEBUG - 2017-01-20 18:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 18:02:42 --> Input Class Initialized
INFO - 2017-01-20 18:02:42 --> Language Class Initialized
INFO - 2017-01-20 18:02:42 --> Loader Class Initialized
INFO - 2017-01-20 18:02:42 --> Database Driver Class Initialized
INFO - 2017-01-20 18:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 18:02:42 --> Controller Class Initialized
INFO - 2017-01-20 18:02:42 --> Helper loaded: url_helper
DEBUG - 2017-01-20 18:02:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 18:02:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 18:02:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 18:02:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 18:02:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 18:02:42 --> Final output sent to browser
DEBUG - 2017-01-20 18:02:42 --> Total execution time: 0.0147
INFO - 2017-01-20 18:02:52 --> Config Class Initialized
INFO - 2017-01-20 18:02:52 --> Hooks Class Initialized
DEBUG - 2017-01-20 18:02:52 --> UTF-8 Support Enabled
INFO - 2017-01-20 18:02:52 --> Utf8 Class Initialized
INFO - 2017-01-20 18:02:52 --> URI Class Initialized
DEBUG - 2017-01-20 18:02:52 --> No URI present. Default controller set.
INFO - 2017-01-20 18:02:52 --> Router Class Initialized
INFO - 2017-01-20 18:02:52 --> Output Class Initialized
INFO - 2017-01-20 18:02:52 --> Security Class Initialized
DEBUG - 2017-01-20 18:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 18:02:52 --> Input Class Initialized
INFO - 2017-01-20 18:02:52 --> Language Class Initialized
INFO - 2017-01-20 18:02:52 --> Loader Class Initialized
INFO - 2017-01-20 18:02:52 --> Database Driver Class Initialized
INFO - 2017-01-20 18:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 18:02:52 --> Controller Class Initialized
INFO - 2017-01-20 18:02:52 --> Helper loaded: url_helper
DEBUG - 2017-01-20 18:02:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 18:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 18:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 18:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 18:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 18:02:52 --> Final output sent to browser
DEBUG - 2017-01-20 18:02:52 --> Total execution time: 0.0144
INFO - 2017-01-20 18:02:53 --> Config Class Initialized
INFO - 2017-01-20 18:02:53 --> Hooks Class Initialized
DEBUG - 2017-01-20 18:02:53 --> UTF-8 Support Enabled
INFO - 2017-01-20 18:02:53 --> Utf8 Class Initialized
INFO - 2017-01-20 18:02:53 --> URI Class Initialized
INFO - 2017-01-20 18:02:53 --> Router Class Initialized
INFO - 2017-01-20 18:02:53 --> Output Class Initialized
INFO - 2017-01-20 18:02:53 --> Security Class Initialized
DEBUG - 2017-01-20 18:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 18:02:53 --> Input Class Initialized
INFO - 2017-01-20 18:02:53 --> Language Class Initialized
INFO - 2017-01-20 18:02:53 --> Loader Class Initialized
INFO - 2017-01-20 18:02:53 --> Database Driver Class Initialized
INFO - 2017-01-20 18:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 18:02:53 --> Controller Class Initialized
INFO - 2017-01-20 18:02:53 --> Helper loaded: url_helper
DEBUG - 2017-01-20 18:02:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 18:02:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 18:02:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 18:02:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 18:02:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 18:02:53 --> Final output sent to browser
DEBUG - 2017-01-20 18:02:53 --> Total execution time: 0.0339
INFO - 2017-01-20 23:46:56 --> Config Class Initialized
INFO - 2017-01-20 23:46:56 --> Hooks Class Initialized
DEBUG - 2017-01-20 23:46:56 --> UTF-8 Support Enabled
INFO - 2017-01-20 23:46:56 --> Utf8 Class Initialized
INFO - 2017-01-20 23:46:56 --> URI Class Initialized
DEBUG - 2017-01-20 23:46:56 --> No URI present. Default controller set.
INFO - 2017-01-20 23:46:56 --> Router Class Initialized
INFO - 2017-01-20 23:46:56 --> Output Class Initialized
INFO - 2017-01-20 23:46:56 --> Security Class Initialized
DEBUG - 2017-01-20 23:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 23:46:56 --> Input Class Initialized
INFO - 2017-01-20 23:46:56 --> Language Class Initialized
INFO - 2017-01-20 23:46:56 --> Loader Class Initialized
INFO - 2017-01-20 23:46:56 --> Database Driver Class Initialized
INFO - 2017-01-20 23:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 23:46:56 --> Controller Class Initialized
INFO - 2017-01-20 23:46:56 --> Helper loaded: url_helper
DEBUG - 2017-01-20 23:46:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 23:46:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 23:46:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 23:46:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 23:46:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 23:46:57 --> Final output sent to browser
DEBUG - 2017-01-20 23:46:57 --> Total execution time: 0.9141
INFO - 2017-01-20 23:46:58 --> Config Class Initialized
INFO - 2017-01-20 23:46:58 --> Hooks Class Initialized
DEBUG - 2017-01-20 23:46:58 --> UTF-8 Support Enabled
INFO - 2017-01-20 23:46:58 --> Utf8 Class Initialized
INFO - 2017-01-20 23:46:58 --> URI Class Initialized
INFO - 2017-01-20 23:46:58 --> Router Class Initialized
INFO - 2017-01-20 23:46:58 --> Output Class Initialized
INFO - 2017-01-20 23:46:58 --> Security Class Initialized
DEBUG - 2017-01-20 23:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 23:46:58 --> Input Class Initialized
INFO - 2017-01-20 23:46:58 --> Language Class Initialized
INFO - 2017-01-20 23:46:58 --> Loader Class Initialized
INFO - 2017-01-20 23:46:58 --> Database Driver Class Initialized
INFO - 2017-01-20 23:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 23:46:58 --> Controller Class Initialized
INFO - 2017-01-20 23:46:58 --> Helper loaded: url_helper
DEBUG - 2017-01-20 23:46:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 23:46:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 23:46:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 23:46:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 23:46:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 23:46:58 --> Final output sent to browser
DEBUG - 2017-01-20 23:46:58 --> Total execution time: 0.0152
INFO - 2017-01-20 23:53:08 --> Config Class Initialized
INFO - 2017-01-20 23:53:08 --> Hooks Class Initialized
DEBUG - 2017-01-20 23:53:08 --> UTF-8 Support Enabled
INFO - 2017-01-20 23:53:08 --> Utf8 Class Initialized
INFO - 2017-01-20 23:53:08 --> URI Class Initialized
INFO - 2017-01-20 23:53:08 --> Router Class Initialized
INFO - 2017-01-20 23:53:08 --> Output Class Initialized
INFO - 2017-01-20 23:53:08 --> Security Class Initialized
DEBUG - 2017-01-20 23:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 23:53:08 --> Input Class Initialized
INFO - 2017-01-20 23:53:08 --> Language Class Initialized
INFO - 2017-01-20 23:53:08 --> Loader Class Initialized
INFO - 2017-01-20 23:53:08 --> Database Driver Class Initialized
INFO - 2017-01-20 23:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 23:53:08 --> Controller Class Initialized
INFO - 2017-01-20 23:53:08 --> Helper loaded: date_helper
DEBUG - 2017-01-20 23:53:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 23:53:08 --> Helper loaded: url_helper
INFO - 2017-01-20 23:53:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 23:53:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-20 23:53:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-20 23:53:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-20 23:53:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 23:53:08 --> Final output sent to browser
DEBUG - 2017-01-20 23:53:08 --> Total execution time: 0.0441
INFO - 2017-01-20 23:53:14 --> Config Class Initialized
INFO - 2017-01-20 23:53:14 --> Hooks Class Initialized
DEBUG - 2017-01-20 23:53:14 --> UTF-8 Support Enabled
INFO - 2017-01-20 23:53:14 --> Utf8 Class Initialized
INFO - 2017-01-20 23:53:14 --> URI Class Initialized
DEBUG - 2017-01-20 23:53:14 --> No URI present. Default controller set.
INFO - 2017-01-20 23:53:14 --> Router Class Initialized
INFO - 2017-01-20 23:53:14 --> Output Class Initialized
INFO - 2017-01-20 23:53:14 --> Security Class Initialized
DEBUG - 2017-01-20 23:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-20 23:53:14 --> Input Class Initialized
INFO - 2017-01-20 23:53:14 --> Language Class Initialized
INFO - 2017-01-20 23:53:14 --> Loader Class Initialized
INFO - 2017-01-20 23:53:14 --> Database Driver Class Initialized
INFO - 2017-01-20 23:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-20 23:53:14 --> Controller Class Initialized
INFO - 2017-01-20 23:53:14 --> Helper loaded: url_helper
DEBUG - 2017-01-20 23:53:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-20 23:53:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-20 23:53:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-20 23:53:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-20 23:53:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-20 23:53:14 --> Final output sent to browser
DEBUG - 2017-01-20 23:53:14 --> Total execution time: 0.0138

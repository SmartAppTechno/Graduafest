<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-14 00:02:01 --> Config Class Initialized
INFO - 2017-03-14 00:02:01 --> Hooks Class Initialized
DEBUG - 2017-03-14 00:02:02 --> UTF-8 Support Enabled
INFO - 2017-03-14 00:02:02 --> Utf8 Class Initialized
INFO - 2017-03-14 00:02:06 --> URI Class Initialized
INFO - 2017-03-14 00:02:06 --> Router Class Initialized
INFO - 2017-03-14 00:02:06 --> Output Class Initialized
INFO - 2017-03-14 00:02:06 --> Security Class Initialized
DEBUG - 2017-03-14 00:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 00:02:06 --> Input Class Initialized
INFO - 2017-03-14 00:02:06 --> Language Class Initialized
INFO - 2017-03-14 00:02:06 --> Loader Class Initialized
INFO - 2017-03-14 00:02:06 --> Database Driver Class Initialized
INFO - 2017-03-14 00:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 00:02:06 --> Controller Class Initialized
INFO - 2017-03-14 00:02:06 --> Helper loaded: url_helper
DEBUG - 2017-03-14 00:02:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 00:02:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 00:02:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 00:02:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 00:02:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 00:02:06 --> Final output sent to browser
DEBUG - 2017-03-14 00:02:06 --> Total execution time: 4.9705
INFO - 2017-03-14 00:02:10 --> Config Class Initialized
INFO - 2017-03-14 00:02:10 --> Hooks Class Initialized
DEBUG - 2017-03-14 00:02:10 --> UTF-8 Support Enabled
INFO - 2017-03-14 00:02:10 --> Utf8 Class Initialized
INFO - 2017-03-14 00:02:10 --> URI Class Initialized
DEBUG - 2017-03-14 00:02:10 --> No URI present. Default controller set.
INFO - 2017-03-14 00:02:10 --> Router Class Initialized
INFO - 2017-03-14 00:02:10 --> Output Class Initialized
INFO - 2017-03-14 00:02:10 --> Security Class Initialized
DEBUG - 2017-03-14 00:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 00:02:10 --> Input Class Initialized
INFO - 2017-03-14 00:02:10 --> Language Class Initialized
INFO - 2017-03-14 00:02:10 --> Loader Class Initialized
INFO - 2017-03-14 00:02:10 --> Database Driver Class Initialized
INFO - 2017-03-14 00:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 00:02:10 --> Controller Class Initialized
INFO - 2017-03-14 00:02:10 --> Helper loaded: url_helper
DEBUG - 2017-03-14 00:02:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 00:02:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 00:02:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 00:02:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 00:02:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 00:02:10 --> Final output sent to browser
DEBUG - 2017-03-14 00:02:10 --> Total execution time: 0.3139
INFO - 2017-03-14 00:09:08 --> Config Class Initialized
INFO - 2017-03-14 00:09:08 --> Hooks Class Initialized
DEBUG - 2017-03-14 00:09:08 --> UTF-8 Support Enabled
INFO - 2017-03-14 00:09:08 --> Utf8 Class Initialized
INFO - 2017-03-14 00:09:08 --> URI Class Initialized
DEBUG - 2017-03-14 00:09:08 --> No URI present. Default controller set.
INFO - 2017-03-14 00:09:08 --> Router Class Initialized
INFO - 2017-03-14 00:09:08 --> Output Class Initialized
INFO - 2017-03-14 00:09:08 --> Security Class Initialized
DEBUG - 2017-03-14 00:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 00:09:08 --> Input Class Initialized
INFO - 2017-03-14 00:09:08 --> Language Class Initialized
INFO - 2017-03-14 00:09:08 --> Loader Class Initialized
INFO - 2017-03-14 00:09:08 --> Database Driver Class Initialized
INFO - 2017-03-14 00:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 00:09:09 --> Controller Class Initialized
INFO - 2017-03-14 00:09:09 --> Helper loaded: url_helper
DEBUG - 2017-03-14 00:09:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 00:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 00:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 00:09:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 00:09:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 00:09:10 --> Final output sent to browser
DEBUG - 2017-03-14 00:09:10 --> Total execution time: 1.7477
INFO - 2017-03-14 00:09:15 --> Config Class Initialized
INFO - 2017-03-14 00:09:15 --> Config Class Initialized
INFO - 2017-03-14 00:09:15 --> Hooks Class Initialized
INFO - 2017-03-14 00:09:15 --> Hooks Class Initialized
DEBUG - 2017-03-14 00:09:15 --> UTF-8 Support Enabled
INFO - 2017-03-14 00:09:15 --> Utf8 Class Initialized
DEBUG - 2017-03-14 00:09:15 --> UTF-8 Support Enabled
INFO - 2017-03-14 00:09:15 --> URI Class Initialized
INFO - 2017-03-14 00:09:15 --> Utf8 Class Initialized
INFO - 2017-03-14 00:09:15 --> URI Class Initialized
DEBUG - 2017-03-14 00:09:15 --> No URI present. Default controller set.
INFO - 2017-03-14 00:09:15 --> Router Class Initialized
INFO - 2017-03-14 00:09:15 --> Router Class Initialized
INFO - 2017-03-14 00:09:15 --> Output Class Initialized
INFO - 2017-03-14 00:09:15 --> Output Class Initialized
INFO - 2017-03-14 00:09:15 --> Security Class Initialized
INFO - 2017-03-14 00:09:15 --> Security Class Initialized
DEBUG - 2017-03-14 00:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 00:09:15 --> Input Class Initialized
DEBUG - 2017-03-14 00:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 00:09:15 --> Language Class Initialized
INFO - 2017-03-14 00:09:15 --> Input Class Initialized
INFO - 2017-03-14 00:09:15 --> Language Class Initialized
INFO - 2017-03-14 00:09:15 --> Loader Class Initialized
INFO - 2017-03-14 00:09:15 --> Loader Class Initialized
INFO - 2017-03-14 00:09:16 --> Database Driver Class Initialized
INFO - 2017-03-14 00:09:16 --> Database Driver Class Initialized
INFO - 2017-03-14 00:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 00:09:16 --> Controller Class Initialized
INFO - 2017-03-14 00:09:16 --> Helper loaded: url_helper
DEBUG - 2017-03-14 00:09:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 00:09:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 00:09:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 00:09:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 00:09:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 00:09:16 --> Final output sent to browser
DEBUG - 2017-03-14 00:09:16 --> Total execution time: 1.2524
INFO - 2017-03-14 00:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 00:09:16 --> Controller Class Initialized
INFO - 2017-03-14 00:09:16 --> Helper loaded: url_helper
DEBUG - 2017-03-14 00:09:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 00:09:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 00:09:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 00:09:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 00:09:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 00:09:16 --> Final output sent to browser
DEBUG - 2017-03-14 00:09:16 --> Total execution time: 1.2745
INFO - 2017-03-14 00:09:19 --> Config Class Initialized
INFO - 2017-03-14 00:09:19 --> Hooks Class Initialized
DEBUG - 2017-03-14 00:09:19 --> UTF-8 Support Enabled
INFO - 2017-03-14 00:09:19 --> Utf8 Class Initialized
INFO - 2017-03-14 00:09:19 --> URI Class Initialized
INFO - 2017-03-14 00:09:19 --> Router Class Initialized
INFO - 2017-03-14 00:09:19 --> Output Class Initialized
INFO - 2017-03-14 00:09:19 --> Security Class Initialized
DEBUG - 2017-03-14 00:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 00:09:19 --> Input Class Initialized
INFO - 2017-03-14 00:09:19 --> Language Class Initialized
INFO - 2017-03-14 00:09:19 --> Loader Class Initialized
INFO - 2017-03-14 00:09:20 --> Database Driver Class Initialized
INFO - 2017-03-14 00:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 00:09:20 --> Controller Class Initialized
INFO - 2017-03-14 00:09:20 --> Helper loaded: url_helper
DEBUG - 2017-03-14 00:09:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 00:09:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 00:09:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 00:09:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 00:09:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 00:09:20 --> Final output sent to browser
DEBUG - 2017-03-14 00:09:20 --> Total execution time: 0.7695
INFO - 2017-03-14 00:09:52 --> Config Class Initialized
INFO - 2017-03-14 00:09:52 --> Hooks Class Initialized
DEBUG - 2017-03-14 00:09:52 --> UTF-8 Support Enabled
INFO - 2017-03-14 00:09:52 --> Utf8 Class Initialized
INFO - 2017-03-14 00:09:52 --> URI Class Initialized
INFO - 2017-03-14 00:09:52 --> Router Class Initialized
INFO - 2017-03-14 00:09:52 --> Output Class Initialized
INFO - 2017-03-14 00:09:52 --> Security Class Initialized
DEBUG - 2017-03-14 00:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 00:09:52 --> Input Class Initialized
INFO - 2017-03-14 00:09:52 --> Language Class Initialized
INFO - 2017-03-14 00:09:52 --> Loader Class Initialized
INFO - 2017-03-14 00:09:52 --> Database Driver Class Initialized
INFO - 2017-03-14 00:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 00:09:52 --> Controller Class Initialized
INFO - 2017-03-14 00:09:52 --> Helper loaded: url_helper
DEBUG - 2017-03-14 00:09:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 00:09:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 00:09:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 00:09:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 00:09:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 00:09:53 --> Final output sent to browser
DEBUG - 2017-03-14 00:09:53 --> Total execution time: 1.2697
INFO - 2017-03-14 00:09:55 --> Config Class Initialized
INFO - 2017-03-14 00:09:55 --> Hooks Class Initialized
DEBUG - 2017-03-14 00:09:55 --> UTF-8 Support Enabled
INFO - 2017-03-14 00:09:55 --> Utf8 Class Initialized
INFO - 2017-03-14 00:09:55 --> URI Class Initialized
INFO - 2017-03-14 00:09:55 --> Router Class Initialized
INFO - 2017-03-14 00:09:55 --> Output Class Initialized
INFO - 2017-03-14 00:09:55 --> Security Class Initialized
DEBUG - 2017-03-14 00:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 00:09:55 --> Input Class Initialized
INFO - 2017-03-14 00:09:55 --> Language Class Initialized
INFO - 2017-03-14 00:09:55 --> Loader Class Initialized
INFO - 2017-03-14 00:09:55 --> Database Driver Class Initialized
INFO - 2017-03-14 00:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 00:09:55 --> Controller Class Initialized
INFO - 2017-03-14 00:09:55 --> Helper loaded: url_helper
DEBUG - 2017-03-14 00:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 00:09:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 00:09:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 00:09:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 00:09:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 00:09:55 --> Final output sent to browser
DEBUG - 2017-03-14 00:09:55 --> Total execution time: 0.0269
INFO - 2017-03-14 00:10:01 --> Config Class Initialized
INFO - 2017-03-14 00:10:01 --> Hooks Class Initialized
DEBUG - 2017-03-14 00:10:01 --> UTF-8 Support Enabled
INFO - 2017-03-14 00:10:01 --> Utf8 Class Initialized
INFO - 2017-03-14 00:10:01 --> URI Class Initialized
INFO - 2017-03-14 00:10:01 --> Router Class Initialized
INFO - 2017-03-14 00:10:01 --> Output Class Initialized
INFO - 2017-03-14 00:10:01 --> Security Class Initialized
DEBUG - 2017-03-14 00:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 00:10:01 --> Input Class Initialized
INFO - 2017-03-14 00:10:01 --> Language Class Initialized
INFO - 2017-03-14 00:10:01 --> Loader Class Initialized
INFO - 2017-03-14 00:10:01 --> Database Driver Class Initialized
INFO - 2017-03-14 00:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 00:10:01 --> Controller Class Initialized
INFO - 2017-03-14 00:10:01 --> Helper loaded: url_helper
DEBUG - 2017-03-14 00:10:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 00:10:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 00:10:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 00:10:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 00:10:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 00:10:01 --> Final output sent to browser
DEBUG - 2017-03-14 00:10:01 --> Total execution time: 0.0139
INFO - 2017-03-14 00:10:03 --> Config Class Initialized
INFO - 2017-03-14 00:10:03 --> Hooks Class Initialized
DEBUG - 2017-03-14 00:10:03 --> UTF-8 Support Enabled
INFO - 2017-03-14 00:10:03 --> Utf8 Class Initialized
INFO - 2017-03-14 00:10:03 --> URI Class Initialized
INFO - 2017-03-14 00:10:03 --> Router Class Initialized
INFO - 2017-03-14 00:10:03 --> Output Class Initialized
INFO - 2017-03-14 00:10:03 --> Security Class Initialized
DEBUG - 2017-03-14 00:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 00:10:03 --> Input Class Initialized
INFO - 2017-03-14 00:10:03 --> Language Class Initialized
INFO - 2017-03-14 00:10:03 --> Loader Class Initialized
INFO - 2017-03-14 00:10:03 --> Database Driver Class Initialized
INFO - 2017-03-14 00:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 00:10:03 --> Controller Class Initialized
INFO - 2017-03-14 00:10:03 --> Helper loaded: url_helper
DEBUG - 2017-03-14 00:10:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 00:10:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 00:10:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 00:10:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 00:10:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 00:10:03 --> Final output sent to browser
DEBUG - 2017-03-14 00:10:03 --> Total execution time: 0.0137
INFO - 2017-03-14 00:10:03 --> Config Class Initialized
INFO - 2017-03-14 00:10:03 --> Hooks Class Initialized
DEBUG - 2017-03-14 00:10:03 --> UTF-8 Support Enabled
INFO - 2017-03-14 00:10:03 --> Utf8 Class Initialized
INFO - 2017-03-14 00:10:03 --> URI Class Initialized
INFO - 2017-03-14 00:10:03 --> Router Class Initialized
INFO - 2017-03-14 00:10:03 --> Output Class Initialized
INFO - 2017-03-14 00:10:03 --> Security Class Initialized
DEBUG - 2017-03-14 00:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 00:10:03 --> Input Class Initialized
INFO - 2017-03-14 00:10:03 --> Language Class Initialized
INFO - 2017-03-14 00:10:03 --> Loader Class Initialized
INFO - 2017-03-14 00:10:03 --> Database Driver Class Initialized
INFO - 2017-03-14 00:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 00:10:03 --> Controller Class Initialized
INFO - 2017-03-14 00:10:03 --> Helper loaded: url_helper
DEBUG - 2017-03-14 00:10:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 00:10:05 --> Config Class Initialized
INFO - 2017-03-14 00:10:05 --> Hooks Class Initialized
DEBUG - 2017-03-14 00:10:05 --> UTF-8 Support Enabled
INFO - 2017-03-14 00:10:05 --> Utf8 Class Initialized
INFO - 2017-03-14 00:10:05 --> URI Class Initialized
INFO - 2017-03-14 00:10:05 --> Router Class Initialized
INFO - 2017-03-14 00:10:05 --> Output Class Initialized
INFO - 2017-03-14 00:10:05 --> Security Class Initialized
DEBUG - 2017-03-14 00:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 00:10:05 --> Input Class Initialized
INFO - 2017-03-14 00:10:05 --> Language Class Initialized
INFO - 2017-03-14 00:10:05 --> Loader Class Initialized
INFO - 2017-03-14 00:10:05 --> Database Driver Class Initialized
INFO - 2017-03-14 00:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 00:10:05 --> Controller Class Initialized
INFO - 2017-03-14 00:10:05 --> Helper loaded: date_helper
DEBUG - 2017-03-14 00:10:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 00:10:05 --> Helper loaded: url_helper
INFO - 2017-03-14 00:10:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 00:10:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 00:10:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 00:10:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 00:10:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 00:10:05 --> Final output sent to browser
DEBUG - 2017-03-14 00:10:05 --> Total execution time: 0.1208
INFO - 2017-03-14 00:10:06 --> Config Class Initialized
INFO - 2017-03-14 00:10:06 --> Hooks Class Initialized
DEBUG - 2017-03-14 00:10:06 --> UTF-8 Support Enabled
INFO - 2017-03-14 00:10:06 --> Utf8 Class Initialized
INFO - 2017-03-14 00:10:06 --> URI Class Initialized
INFO - 2017-03-14 00:10:06 --> Router Class Initialized
INFO - 2017-03-14 00:10:06 --> Output Class Initialized
INFO - 2017-03-14 00:10:06 --> Security Class Initialized
DEBUG - 2017-03-14 00:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 00:10:06 --> Input Class Initialized
INFO - 2017-03-14 00:10:06 --> Language Class Initialized
INFO - 2017-03-14 00:10:06 --> Loader Class Initialized
INFO - 2017-03-14 00:10:06 --> Database Driver Class Initialized
INFO - 2017-03-14 00:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 00:10:06 --> Controller Class Initialized
INFO - 2017-03-14 00:10:06 --> Helper loaded: url_helper
DEBUG - 2017-03-14 00:10:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 00:10:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 00:10:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 00:10:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 00:10:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 00:10:06 --> Final output sent to browser
DEBUG - 2017-03-14 00:10:06 --> Total execution time: 0.0145
INFO - 2017-03-14 00:10:41 --> Config Class Initialized
INFO - 2017-03-14 00:10:41 --> Hooks Class Initialized
DEBUG - 2017-03-14 00:10:41 --> UTF-8 Support Enabled
INFO - 2017-03-14 00:10:41 --> Utf8 Class Initialized
INFO - 2017-03-14 00:10:41 --> URI Class Initialized
INFO - 2017-03-14 00:10:41 --> Router Class Initialized
INFO - 2017-03-14 00:10:41 --> Output Class Initialized
INFO - 2017-03-14 00:10:41 --> Security Class Initialized
DEBUG - 2017-03-14 00:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 00:10:41 --> Input Class Initialized
INFO - 2017-03-14 00:10:41 --> Language Class Initialized
INFO - 2017-03-14 00:10:41 --> Loader Class Initialized
INFO - 2017-03-14 00:10:41 --> Database Driver Class Initialized
INFO - 2017-03-14 00:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 00:10:41 --> Controller Class Initialized
INFO - 2017-03-14 00:10:41 --> Helper loaded: url_helper
DEBUG - 2017-03-14 00:10:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 00:10:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 00:10:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 00:10:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 00:10:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 00:10:41 --> Final output sent to browser
DEBUG - 2017-03-14 00:10:41 --> Total execution time: 0.0615
INFO - 2017-03-14 00:10:42 --> Config Class Initialized
INFO - 2017-03-14 00:10:42 --> Hooks Class Initialized
DEBUG - 2017-03-14 00:10:42 --> UTF-8 Support Enabled
INFO - 2017-03-14 00:10:42 --> Utf8 Class Initialized
INFO - 2017-03-14 00:10:42 --> URI Class Initialized
INFO - 2017-03-14 00:10:42 --> Router Class Initialized
INFO - 2017-03-14 00:10:42 --> Output Class Initialized
INFO - 2017-03-14 00:10:42 --> Security Class Initialized
DEBUG - 2017-03-14 00:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 00:10:42 --> Input Class Initialized
INFO - 2017-03-14 00:10:42 --> Language Class Initialized
INFO - 2017-03-14 00:10:42 --> Loader Class Initialized
INFO - 2017-03-14 00:10:42 --> Database Driver Class Initialized
INFO - 2017-03-14 00:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 00:10:42 --> Controller Class Initialized
INFO - 2017-03-14 00:10:42 --> Helper loaded: url_helper
DEBUG - 2017-03-14 00:10:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 00:10:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 00:10:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 00:10:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 00:10:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 00:10:42 --> Final output sent to browser
DEBUG - 2017-03-14 00:10:42 --> Total execution time: 0.0139
INFO - 2017-03-14 00:10:42 --> Config Class Initialized
INFO - 2017-03-14 00:10:42 --> Hooks Class Initialized
DEBUG - 2017-03-14 00:10:42 --> UTF-8 Support Enabled
INFO - 2017-03-14 00:10:42 --> Utf8 Class Initialized
INFO - 2017-03-14 00:10:42 --> URI Class Initialized
INFO - 2017-03-14 00:10:42 --> Router Class Initialized
INFO - 2017-03-14 00:10:42 --> Output Class Initialized
INFO - 2017-03-14 00:10:42 --> Security Class Initialized
DEBUG - 2017-03-14 00:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 00:10:42 --> Input Class Initialized
INFO - 2017-03-14 00:10:42 --> Language Class Initialized
INFO - 2017-03-14 00:10:42 --> Loader Class Initialized
INFO - 2017-03-14 00:10:42 --> Database Driver Class Initialized
INFO - 2017-03-14 00:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 00:10:42 --> Controller Class Initialized
INFO - 2017-03-14 00:10:42 --> Helper loaded: url_helper
DEBUG - 2017-03-14 00:10:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 00:10:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 00:10:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 00:10:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 00:10:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 00:10:42 --> Final output sent to browser
DEBUG - 2017-03-14 00:10:42 --> Total execution time: 0.0134
INFO - 2017-03-14 00:10:44 --> Config Class Initialized
INFO - 2017-03-14 00:10:44 --> Hooks Class Initialized
DEBUG - 2017-03-14 00:10:44 --> UTF-8 Support Enabled
INFO - 2017-03-14 00:10:44 --> Utf8 Class Initialized
INFO - 2017-03-14 00:10:44 --> URI Class Initialized
INFO - 2017-03-14 00:10:44 --> Router Class Initialized
INFO - 2017-03-14 00:10:44 --> Output Class Initialized
INFO - 2017-03-14 00:10:44 --> Security Class Initialized
DEBUG - 2017-03-14 00:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 00:10:44 --> Input Class Initialized
INFO - 2017-03-14 00:10:44 --> Language Class Initialized
INFO - 2017-03-14 00:10:44 --> Loader Class Initialized
INFO - 2017-03-14 00:10:44 --> Database Driver Class Initialized
INFO - 2017-03-14 00:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 00:10:44 --> Controller Class Initialized
INFO - 2017-03-14 00:10:44 --> Helper loaded: url_helper
DEBUG - 2017-03-14 00:10:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 00:10:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 00:10:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 00:10:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 00:10:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 00:10:44 --> Final output sent to browser
DEBUG - 2017-03-14 00:10:44 --> Total execution time: 0.0142
INFO - 2017-03-14 00:10:46 --> Config Class Initialized
INFO - 2017-03-14 00:10:46 --> Hooks Class Initialized
DEBUG - 2017-03-14 00:10:46 --> UTF-8 Support Enabled
INFO - 2017-03-14 00:10:46 --> Utf8 Class Initialized
INFO - 2017-03-14 00:10:46 --> URI Class Initialized
INFO - 2017-03-14 00:10:46 --> Router Class Initialized
INFO - 2017-03-14 00:10:46 --> Output Class Initialized
INFO - 2017-03-14 00:10:46 --> Security Class Initialized
DEBUG - 2017-03-14 00:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 00:10:46 --> Input Class Initialized
INFO - 2017-03-14 00:10:46 --> Language Class Initialized
INFO - 2017-03-14 00:10:46 --> Loader Class Initialized
INFO - 2017-03-14 00:10:46 --> Database Driver Class Initialized
INFO - 2017-03-14 00:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 00:10:46 --> Controller Class Initialized
INFO - 2017-03-14 00:10:46 --> Helper loaded: url_helper
DEBUG - 2017-03-14 00:10:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 00:10:47 --> Config Class Initialized
INFO - 2017-03-14 00:10:47 --> Hooks Class Initialized
DEBUG - 2017-03-14 00:10:47 --> UTF-8 Support Enabled
INFO - 2017-03-14 00:10:47 --> Utf8 Class Initialized
INFO - 2017-03-14 00:10:47 --> URI Class Initialized
INFO - 2017-03-14 00:10:47 --> Router Class Initialized
INFO - 2017-03-14 00:10:47 --> Output Class Initialized
INFO - 2017-03-14 00:10:47 --> Security Class Initialized
DEBUG - 2017-03-14 00:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 00:10:47 --> Input Class Initialized
INFO - 2017-03-14 00:10:47 --> Language Class Initialized
INFO - 2017-03-14 00:10:47 --> Loader Class Initialized
INFO - 2017-03-14 00:10:47 --> Database Driver Class Initialized
INFO - 2017-03-14 00:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 00:10:47 --> Controller Class Initialized
INFO - 2017-03-14 00:10:47 --> Helper loaded: date_helper
DEBUG - 2017-03-14 00:10:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 00:10:47 --> Helper loaded: url_helper
INFO - 2017-03-14 00:10:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 00:10:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 00:10:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 00:10:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 00:10:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 00:10:47 --> Final output sent to browser
DEBUG - 2017-03-14 00:10:47 --> Total execution time: 0.0138
INFO - 2017-03-14 00:10:48 --> Config Class Initialized
INFO - 2017-03-14 00:10:48 --> Hooks Class Initialized
DEBUG - 2017-03-14 00:10:48 --> UTF-8 Support Enabled
INFO - 2017-03-14 00:10:48 --> Utf8 Class Initialized
INFO - 2017-03-14 00:10:48 --> URI Class Initialized
INFO - 2017-03-14 00:10:48 --> Router Class Initialized
INFO - 2017-03-14 00:10:48 --> Output Class Initialized
INFO - 2017-03-14 00:10:48 --> Security Class Initialized
DEBUG - 2017-03-14 00:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 00:10:48 --> Input Class Initialized
INFO - 2017-03-14 00:10:48 --> Language Class Initialized
INFO - 2017-03-14 00:10:48 --> Loader Class Initialized
INFO - 2017-03-14 00:10:48 --> Database Driver Class Initialized
INFO - 2017-03-14 00:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 00:10:48 --> Controller Class Initialized
INFO - 2017-03-14 00:10:48 --> Helper loaded: url_helper
DEBUG - 2017-03-14 00:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 00:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 00:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 00:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 00:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 00:10:48 --> Final output sent to browser
DEBUG - 2017-03-14 00:10:48 --> Total execution time: 0.0143
INFO - 2017-03-14 01:20:45 --> Config Class Initialized
INFO - 2017-03-14 01:20:45 --> Hooks Class Initialized
DEBUG - 2017-03-14 01:20:45 --> UTF-8 Support Enabled
INFO - 2017-03-14 01:20:45 --> Utf8 Class Initialized
INFO - 2017-03-14 01:20:45 --> URI Class Initialized
DEBUG - 2017-03-14 01:20:45 --> No URI present. Default controller set.
INFO - 2017-03-14 01:20:45 --> Router Class Initialized
INFO - 2017-03-14 01:20:45 --> Output Class Initialized
INFO - 2017-03-14 01:20:45 --> Security Class Initialized
DEBUG - 2017-03-14 01:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 01:20:45 --> Input Class Initialized
INFO - 2017-03-14 01:20:45 --> Language Class Initialized
INFO - 2017-03-14 01:20:45 --> Loader Class Initialized
INFO - 2017-03-14 01:20:46 --> Database Driver Class Initialized
INFO - 2017-03-14 01:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 01:20:46 --> Controller Class Initialized
INFO - 2017-03-14 01:20:46 --> Helper loaded: url_helper
DEBUG - 2017-03-14 01:20:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 01:20:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 01:20:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 01:20:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 01:20:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 01:20:47 --> Final output sent to browser
DEBUG - 2017-03-14 01:20:47 --> Total execution time: 1.4878
INFO - 2017-03-14 01:25:23 --> Config Class Initialized
INFO - 2017-03-14 01:25:23 --> Hooks Class Initialized
DEBUG - 2017-03-14 01:25:23 --> UTF-8 Support Enabled
INFO - 2017-03-14 01:25:23 --> Utf8 Class Initialized
INFO - 2017-03-14 01:25:23 --> URI Class Initialized
INFO - 2017-03-14 01:25:23 --> Router Class Initialized
INFO - 2017-03-14 01:25:23 --> Output Class Initialized
INFO - 2017-03-14 01:25:24 --> Security Class Initialized
DEBUG - 2017-03-14 01:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 01:25:24 --> Input Class Initialized
INFO - 2017-03-14 01:25:24 --> Language Class Initialized
INFO - 2017-03-14 01:25:24 --> Loader Class Initialized
INFO - 2017-03-14 01:25:24 --> Database Driver Class Initialized
INFO - 2017-03-14 01:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 01:25:24 --> Controller Class Initialized
INFO - 2017-03-14 01:25:25 --> Helper loaded: date_helper
DEBUG - 2017-03-14 01:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 01:25:25 --> Helper loaded: url_helper
INFO - 2017-03-14 01:25:25 --> Helper loaded: download_helper
INFO - 2017-03-14 01:25:26 --> Config Class Initialized
INFO - 2017-03-14 01:25:26 --> Hooks Class Initialized
DEBUG - 2017-03-14 01:25:26 --> UTF-8 Support Enabled
INFO - 2017-03-14 01:25:26 --> Utf8 Class Initialized
INFO - 2017-03-14 01:25:26 --> URI Class Initialized
DEBUG - 2017-03-14 01:25:26 --> No URI present. Default controller set.
INFO - 2017-03-14 01:25:26 --> Router Class Initialized
INFO - 2017-03-14 01:25:26 --> Output Class Initialized
INFO - 2017-03-14 01:25:26 --> Security Class Initialized
DEBUG - 2017-03-14 01:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 01:25:26 --> Input Class Initialized
INFO - 2017-03-14 01:25:26 --> Language Class Initialized
INFO - 2017-03-14 01:25:26 --> Loader Class Initialized
INFO - 2017-03-14 01:25:26 --> Database Driver Class Initialized
INFO - 2017-03-14 01:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 01:25:26 --> Controller Class Initialized
INFO - 2017-03-14 01:25:26 --> Helper loaded: url_helper
DEBUG - 2017-03-14 01:25:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 01:25:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 01:25:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 01:25:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 01:25:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 01:25:26 --> Final output sent to browser
DEBUG - 2017-03-14 01:25:26 --> Total execution time: 0.2620
INFO - 2017-03-14 01:25:41 --> Config Class Initialized
INFO - 2017-03-14 01:25:41 --> Hooks Class Initialized
DEBUG - 2017-03-14 01:25:41 --> UTF-8 Support Enabled
INFO - 2017-03-14 01:25:41 --> Utf8 Class Initialized
INFO - 2017-03-14 01:25:41 --> URI Class Initialized
INFO - 2017-03-14 01:25:41 --> Router Class Initialized
INFO - 2017-03-14 01:25:41 --> Output Class Initialized
INFO - 2017-03-14 01:25:41 --> Security Class Initialized
DEBUG - 2017-03-14 01:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 01:25:41 --> Input Class Initialized
INFO - 2017-03-14 01:25:41 --> Language Class Initialized
INFO - 2017-03-14 01:25:41 --> Loader Class Initialized
INFO - 2017-03-14 01:25:41 --> Database Driver Class Initialized
INFO - 2017-03-14 01:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 01:25:41 --> Controller Class Initialized
INFO - 2017-03-14 01:25:41 --> Helper loaded: url_helper
DEBUG - 2017-03-14 01:25:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 01:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 01:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 01:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 01:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 01:25:41 --> Final output sent to browser
DEBUG - 2017-03-14 01:25:41 --> Total execution time: 0.0136
INFO - 2017-03-14 01:43:41 --> Config Class Initialized
INFO - 2017-03-14 01:43:41 --> Hooks Class Initialized
DEBUG - 2017-03-14 01:43:41 --> UTF-8 Support Enabled
INFO - 2017-03-14 01:43:41 --> Utf8 Class Initialized
INFO - 2017-03-14 01:43:41 --> URI Class Initialized
INFO - 2017-03-14 01:43:41 --> Router Class Initialized
INFO - 2017-03-14 01:43:41 --> Output Class Initialized
INFO - 2017-03-14 01:43:41 --> Security Class Initialized
DEBUG - 2017-03-14 01:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 01:43:41 --> Input Class Initialized
INFO - 2017-03-14 01:43:41 --> Language Class Initialized
INFO - 2017-03-14 01:43:41 --> Loader Class Initialized
INFO - 2017-03-14 01:43:41 --> Database Driver Class Initialized
INFO - 2017-03-14 01:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 01:43:42 --> Controller Class Initialized
INFO - 2017-03-14 01:43:42 --> Helper loaded: date_helper
DEBUG - 2017-03-14 01:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 01:43:42 --> Helper loaded: url_helper
INFO - 2017-03-14 01:43:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 01:43:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 01:43:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 01:43:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 01:43:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 01:43:42 --> Final output sent to browser
DEBUG - 2017-03-14 01:43:42 --> Total execution time: 1.3529
INFO - 2017-03-14 01:43:44 --> Config Class Initialized
INFO - 2017-03-14 01:43:44 --> Hooks Class Initialized
DEBUG - 2017-03-14 01:43:44 --> UTF-8 Support Enabled
INFO - 2017-03-14 01:43:44 --> Utf8 Class Initialized
INFO - 2017-03-14 01:43:44 --> URI Class Initialized
INFO - 2017-03-14 01:43:44 --> Router Class Initialized
INFO - 2017-03-14 01:43:44 --> Output Class Initialized
INFO - 2017-03-14 01:43:44 --> Security Class Initialized
DEBUG - 2017-03-14 01:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 01:43:44 --> Input Class Initialized
INFO - 2017-03-14 01:43:44 --> Language Class Initialized
INFO - 2017-03-14 01:43:45 --> Loader Class Initialized
INFO - 2017-03-14 01:43:45 --> Database Driver Class Initialized
INFO - 2017-03-14 01:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 01:43:45 --> Controller Class Initialized
INFO - 2017-03-14 01:43:45 --> Helper loaded: url_helper
DEBUG - 2017-03-14 01:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 01:43:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 01:43:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 01:43:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 01:43:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 01:43:45 --> Final output sent to browser
DEBUG - 2017-03-14 01:43:45 --> Total execution time: 0.2489
INFO - 2017-03-14 01:55:40 --> Config Class Initialized
INFO - 2017-03-14 01:55:40 --> Hooks Class Initialized
DEBUG - 2017-03-14 01:55:40 --> UTF-8 Support Enabled
INFO - 2017-03-14 01:55:40 --> Utf8 Class Initialized
INFO - 2017-03-14 01:55:40 --> URI Class Initialized
DEBUG - 2017-03-14 01:55:40 --> No URI present. Default controller set.
INFO - 2017-03-14 01:55:40 --> Router Class Initialized
INFO - 2017-03-14 01:55:40 --> Output Class Initialized
INFO - 2017-03-14 01:55:40 --> Security Class Initialized
DEBUG - 2017-03-14 01:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 01:55:41 --> Input Class Initialized
INFO - 2017-03-14 01:55:41 --> Language Class Initialized
INFO - 2017-03-14 01:55:41 --> Loader Class Initialized
INFO - 2017-03-14 01:55:41 --> Database Driver Class Initialized
INFO - 2017-03-14 01:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 01:55:41 --> Controller Class Initialized
INFO - 2017-03-14 01:55:41 --> Helper loaded: url_helper
DEBUG - 2017-03-14 01:55:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 01:55:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 01:55:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 01:55:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 01:55:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 01:55:42 --> Final output sent to browser
DEBUG - 2017-03-14 01:55:42 --> Total execution time: 1.4626
INFO - 2017-03-14 01:56:22 --> Config Class Initialized
INFO - 2017-03-14 01:56:22 --> Hooks Class Initialized
DEBUG - 2017-03-14 01:56:22 --> UTF-8 Support Enabled
INFO - 2017-03-14 01:56:22 --> Utf8 Class Initialized
INFO - 2017-03-14 01:56:22 --> URI Class Initialized
INFO - 2017-03-14 01:56:22 --> Router Class Initialized
INFO - 2017-03-14 01:56:22 --> Output Class Initialized
INFO - 2017-03-14 01:56:22 --> Security Class Initialized
DEBUG - 2017-03-14 01:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 01:56:22 --> Input Class Initialized
INFO - 2017-03-14 01:56:22 --> Language Class Initialized
INFO - 2017-03-14 01:56:22 --> Loader Class Initialized
INFO - 2017-03-14 01:56:22 --> Database Driver Class Initialized
INFO - 2017-03-14 01:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 01:56:22 --> Controller Class Initialized
INFO - 2017-03-14 01:56:22 --> Helper loaded: url_helper
DEBUG - 2017-03-14 01:56:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 01:56:24 --> Config Class Initialized
INFO - 2017-03-14 01:56:24 --> Hooks Class Initialized
DEBUG - 2017-03-14 01:56:24 --> UTF-8 Support Enabled
INFO - 2017-03-14 01:56:24 --> Utf8 Class Initialized
INFO - 2017-03-14 01:56:24 --> URI Class Initialized
INFO - 2017-03-14 01:56:24 --> Router Class Initialized
INFO - 2017-03-14 01:56:24 --> Output Class Initialized
INFO - 2017-03-14 01:56:24 --> Security Class Initialized
DEBUG - 2017-03-14 01:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 01:56:24 --> Input Class Initialized
INFO - 2017-03-14 01:56:24 --> Language Class Initialized
INFO - 2017-03-14 01:56:24 --> Loader Class Initialized
INFO - 2017-03-14 01:56:24 --> Database Driver Class Initialized
INFO - 2017-03-14 01:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 01:56:24 --> Controller Class Initialized
INFO - 2017-03-14 01:56:24 --> Helper loaded: url_helper
DEBUG - 2017-03-14 01:56:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 01:56:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 01:56:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 01:56:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 01:56:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 01:56:24 --> Final output sent to browser
DEBUG - 2017-03-14 01:56:24 --> Total execution time: 0.0139
INFO - 2017-03-14 01:56:24 --> Config Class Initialized
INFO - 2017-03-14 01:56:24 --> Hooks Class Initialized
DEBUG - 2017-03-14 01:56:24 --> UTF-8 Support Enabled
INFO - 2017-03-14 01:56:24 --> Utf8 Class Initialized
INFO - 2017-03-14 01:56:24 --> URI Class Initialized
INFO - 2017-03-14 01:56:24 --> Router Class Initialized
INFO - 2017-03-14 01:56:24 --> Output Class Initialized
INFO - 2017-03-14 01:56:24 --> Security Class Initialized
DEBUG - 2017-03-14 01:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 01:56:24 --> Input Class Initialized
INFO - 2017-03-14 01:56:24 --> Language Class Initialized
INFO - 2017-03-14 01:56:24 --> Loader Class Initialized
INFO - 2017-03-14 01:56:24 --> Database Driver Class Initialized
INFO - 2017-03-14 01:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 01:56:24 --> Controller Class Initialized
INFO - 2017-03-14 01:56:24 --> Helper loaded: url_helper
DEBUG - 2017-03-14 01:56:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 01:56:25 --> Config Class Initialized
INFO - 2017-03-14 01:56:25 --> Hooks Class Initialized
DEBUG - 2017-03-14 01:56:25 --> UTF-8 Support Enabled
INFO - 2017-03-14 01:56:25 --> Utf8 Class Initialized
INFO - 2017-03-14 01:56:25 --> URI Class Initialized
INFO - 2017-03-14 01:56:25 --> Router Class Initialized
INFO - 2017-03-14 01:56:25 --> Output Class Initialized
INFO - 2017-03-14 01:56:25 --> Security Class Initialized
DEBUG - 2017-03-14 01:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 01:56:25 --> Input Class Initialized
INFO - 2017-03-14 01:56:25 --> Language Class Initialized
INFO - 2017-03-14 01:56:25 --> Loader Class Initialized
INFO - 2017-03-14 01:56:25 --> Database Driver Class Initialized
INFO - 2017-03-14 01:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 01:56:25 --> Controller Class Initialized
INFO - 2017-03-14 01:56:25 --> Helper loaded: date_helper
DEBUG - 2017-03-14 01:56:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 01:56:25 --> Helper loaded: url_helper
INFO - 2017-03-14 01:56:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 01:56:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 01:56:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 01:56:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 01:56:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 01:56:25 --> Final output sent to browser
DEBUG - 2017-03-14 01:56:25 --> Total execution time: 0.0955
INFO - 2017-03-14 01:56:26 --> Config Class Initialized
INFO - 2017-03-14 01:56:26 --> Hooks Class Initialized
DEBUG - 2017-03-14 01:56:26 --> UTF-8 Support Enabled
INFO - 2017-03-14 01:56:26 --> Utf8 Class Initialized
INFO - 2017-03-14 01:56:26 --> URI Class Initialized
INFO - 2017-03-14 01:56:26 --> Router Class Initialized
INFO - 2017-03-14 01:56:26 --> Output Class Initialized
INFO - 2017-03-14 01:56:26 --> Security Class Initialized
DEBUG - 2017-03-14 01:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 01:56:26 --> Input Class Initialized
INFO - 2017-03-14 01:56:26 --> Language Class Initialized
INFO - 2017-03-14 01:56:26 --> Loader Class Initialized
INFO - 2017-03-14 01:56:26 --> Database Driver Class Initialized
INFO - 2017-03-14 01:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 01:56:26 --> Controller Class Initialized
INFO - 2017-03-14 01:56:26 --> Helper loaded: url_helper
DEBUG - 2017-03-14 01:56:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 01:56:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 01:56:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 01:56:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 01:56:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 01:56:26 --> Final output sent to browser
DEBUG - 2017-03-14 01:56:26 --> Total execution time: 0.0140
INFO - 2017-03-14 01:56:45 --> Config Class Initialized
INFO - 2017-03-14 01:56:45 --> Hooks Class Initialized
DEBUG - 2017-03-14 01:56:45 --> UTF-8 Support Enabled
INFO - 2017-03-14 01:56:45 --> Utf8 Class Initialized
INFO - 2017-03-14 01:56:45 --> URI Class Initialized
DEBUG - 2017-03-14 01:56:45 --> No URI present. Default controller set.
INFO - 2017-03-14 01:56:45 --> Router Class Initialized
INFO - 2017-03-14 01:56:45 --> Output Class Initialized
INFO - 2017-03-14 01:56:45 --> Security Class Initialized
DEBUG - 2017-03-14 01:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 01:56:45 --> Input Class Initialized
INFO - 2017-03-14 01:56:45 --> Language Class Initialized
INFO - 2017-03-14 01:56:45 --> Loader Class Initialized
INFO - 2017-03-14 01:56:45 --> Database Driver Class Initialized
INFO - 2017-03-14 01:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 01:56:45 --> Controller Class Initialized
INFO - 2017-03-14 01:56:45 --> Helper loaded: url_helper
DEBUG - 2017-03-14 01:56:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 01:56:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 01:56:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 01:56:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 01:56:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 01:56:45 --> Final output sent to browser
DEBUG - 2017-03-14 01:56:45 --> Total execution time: 0.0142
INFO - 2017-03-14 01:56:46 --> Config Class Initialized
INFO - 2017-03-14 01:56:46 --> Hooks Class Initialized
DEBUG - 2017-03-14 01:56:46 --> UTF-8 Support Enabled
INFO - 2017-03-14 01:56:46 --> Utf8 Class Initialized
INFO - 2017-03-14 01:56:46 --> URI Class Initialized
INFO - 2017-03-14 01:56:46 --> Router Class Initialized
INFO - 2017-03-14 01:56:46 --> Output Class Initialized
INFO - 2017-03-14 01:56:46 --> Security Class Initialized
DEBUG - 2017-03-14 01:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 01:56:46 --> Input Class Initialized
INFO - 2017-03-14 01:56:46 --> Language Class Initialized
INFO - 2017-03-14 01:56:46 --> Loader Class Initialized
INFO - 2017-03-14 01:56:46 --> Database Driver Class Initialized
INFO - 2017-03-14 01:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 01:56:46 --> Controller Class Initialized
INFO - 2017-03-14 01:56:46 --> Helper loaded: url_helper
DEBUG - 2017-03-14 01:56:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 01:56:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 01:56:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 01:56:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 01:56:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 01:56:46 --> Final output sent to browser
DEBUG - 2017-03-14 01:56:46 --> Total execution time: 0.0136
INFO - 2017-03-14 01:59:19 --> Config Class Initialized
INFO - 2017-03-14 01:59:19 --> Hooks Class Initialized
DEBUG - 2017-03-14 01:59:19 --> UTF-8 Support Enabled
INFO - 2017-03-14 01:59:20 --> Utf8 Class Initialized
INFO - 2017-03-14 01:59:20 --> URI Class Initialized
INFO - 2017-03-14 01:59:20 --> Router Class Initialized
INFO - 2017-03-14 01:59:20 --> Output Class Initialized
INFO - 2017-03-14 01:59:20 --> Security Class Initialized
DEBUG - 2017-03-14 01:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 01:59:20 --> Input Class Initialized
INFO - 2017-03-14 01:59:20 --> Language Class Initialized
INFO - 2017-03-14 01:59:20 --> Loader Class Initialized
INFO - 2017-03-14 01:59:20 --> Database Driver Class Initialized
INFO - 2017-03-14 01:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 01:59:20 --> Controller Class Initialized
INFO - 2017-03-14 01:59:20 --> Helper loaded: url_helper
DEBUG - 2017-03-14 01:59:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 01:59:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 01:59:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 01:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 01:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 01:59:21 --> Final output sent to browser
DEBUG - 2017-03-14 01:59:21 --> Total execution time: 1.2625
INFO - 2017-03-14 01:59:22 --> Config Class Initialized
INFO - 2017-03-14 01:59:22 --> Hooks Class Initialized
DEBUG - 2017-03-14 01:59:22 --> UTF-8 Support Enabled
INFO - 2017-03-14 01:59:22 --> Utf8 Class Initialized
INFO - 2017-03-14 01:59:22 --> URI Class Initialized
INFO - 2017-03-14 01:59:22 --> Router Class Initialized
INFO - 2017-03-14 01:59:22 --> Output Class Initialized
INFO - 2017-03-14 01:59:22 --> Security Class Initialized
DEBUG - 2017-03-14 01:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 01:59:22 --> Input Class Initialized
INFO - 2017-03-14 01:59:22 --> Language Class Initialized
INFO - 2017-03-14 01:59:22 --> Loader Class Initialized
INFO - 2017-03-14 01:59:22 --> Database Driver Class Initialized
INFO - 2017-03-14 01:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 01:59:22 --> Controller Class Initialized
INFO - 2017-03-14 01:59:22 --> Helper loaded: url_helper
DEBUG - 2017-03-14 01:59:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 01:59:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 01:59:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 01:59:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 01:59:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 01:59:22 --> Final output sent to browser
DEBUG - 2017-03-14 01:59:22 --> Total execution time: 0.0138
INFO - 2017-03-14 01:59:39 --> Config Class Initialized
INFO - 2017-03-14 01:59:39 --> Hooks Class Initialized
DEBUG - 2017-03-14 01:59:39 --> UTF-8 Support Enabled
INFO - 2017-03-14 01:59:39 --> Utf8 Class Initialized
INFO - 2017-03-14 01:59:39 --> URI Class Initialized
INFO - 2017-03-14 01:59:39 --> Router Class Initialized
INFO - 2017-03-14 01:59:39 --> Output Class Initialized
INFO - 2017-03-14 01:59:39 --> Security Class Initialized
DEBUG - 2017-03-14 01:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 01:59:39 --> Input Class Initialized
INFO - 2017-03-14 01:59:39 --> Language Class Initialized
INFO - 2017-03-14 01:59:39 --> Loader Class Initialized
INFO - 2017-03-14 01:59:39 --> Database Driver Class Initialized
INFO - 2017-03-14 01:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 01:59:39 --> Controller Class Initialized
INFO - 2017-03-14 01:59:39 --> Helper loaded: url_helper
DEBUG - 2017-03-14 01:59:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 01:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 01:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 01:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 01:59:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 01:59:39 --> Final output sent to browser
DEBUG - 2017-03-14 01:59:39 --> Total execution time: 0.0151
INFO - 2017-03-14 01:59:40 --> Config Class Initialized
INFO - 2017-03-14 01:59:40 --> Hooks Class Initialized
DEBUG - 2017-03-14 01:59:40 --> UTF-8 Support Enabled
INFO - 2017-03-14 01:59:40 --> Utf8 Class Initialized
INFO - 2017-03-14 01:59:40 --> URI Class Initialized
INFO - 2017-03-14 01:59:40 --> Router Class Initialized
INFO - 2017-03-14 01:59:40 --> Output Class Initialized
INFO - 2017-03-14 01:59:40 --> Security Class Initialized
DEBUG - 2017-03-14 01:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 01:59:40 --> Input Class Initialized
INFO - 2017-03-14 01:59:40 --> Language Class Initialized
INFO - 2017-03-14 01:59:40 --> Loader Class Initialized
INFO - 2017-03-14 01:59:40 --> Database Driver Class Initialized
INFO - 2017-03-14 01:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 01:59:40 --> Controller Class Initialized
INFO - 2017-03-14 01:59:40 --> Helper loaded: url_helper
DEBUG - 2017-03-14 01:59:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 01:59:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 01:59:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 01:59:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 01:59:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 01:59:40 --> Final output sent to browser
DEBUG - 2017-03-14 01:59:40 --> Total execution time: 0.0142
INFO - 2017-03-14 02:00:04 --> Config Class Initialized
INFO - 2017-03-14 02:00:04 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:00:04 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:00:04 --> Utf8 Class Initialized
INFO - 2017-03-14 02:00:04 --> URI Class Initialized
INFO - 2017-03-14 02:00:04 --> Router Class Initialized
INFO - 2017-03-14 02:00:04 --> Output Class Initialized
INFO - 2017-03-14 02:00:04 --> Security Class Initialized
DEBUG - 2017-03-14 02:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:00:04 --> Input Class Initialized
INFO - 2017-03-14 02:00:04 --> Language Class Initialized
INFO - 2017-03-14 02:00:04 --> Loader Class Initialized
INFO - 2017-03-14 02:00:04 --> Database Driver Class Initialized
INFO - 2017-03-14 02:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:00:04 --> Controller Class Initialized
INFO - 2017-03-14 02:00:04 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:00:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:00:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:00:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:00:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:00:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:00:04 --> Final output sent to browser
DEBUG - 2017-03-14 02:00:04 --> Total execution time: 0.0145
INFO - 2017-03-14 02:00:05 --> Config Class Initialized
INFO - 2017-03-14 02:00:05 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:00:05 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:00:05 --> Utf8 Class Initialized
INFO - 2017-03-14 02:00:05 --> URI Class Initialized
INFO - 2017-03-14 02:00:05 --> Router Class Initialized
INFO - 2017-03-14 02:00:05 --> Output Class Initialized
INFO - 2017-03-14 02:00:05 --> Security Class Initialized
DEBUG - 2017-03-14 02:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:00:05 --> Input Class Initialized
INFO - 2017-03-14 02:00:05 --> Language Class Initialized
INFO - 2017-03-14 02:00:05 --> Loader Class Initialized
INFO - 2017-03-14 02:00:05 --> Database Driver Class Initialized
INFO - 2017-03-14 02:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:00:05 --> Controller Class Initialized
INFO - 2017-03-14 02:00:05 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:00:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:00:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:00:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:00:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:00:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:00:05 --> Final output sent to browser
DEBUG - 2017-03-14 02:00:05 --> Total execution time: 0.0169
INFO - 2017-03-14 02:00:36 --> Config Class Initialized
INFO - 2017-03-14 02:00:36 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:00:36 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:00:36 --> Utf8 Class Initialized
INFO - 2017-03-14 02:00:36 --> URI Class Initialized
INFO - 2017-03-14 02:00:36 --> Router Class Initialized
INFO - 2017-03-14 02:00:36 --> Output Class Initialized
INFO - 2017-03-14 02:00:36 --> Security Class Initialized
DEBUG - 2017-03-14 02:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:00:36 --> Input Class Initialized
INFO - 2017-03-14 02:00:36 --> Language Class Initialized
INFO - 2017-03-14 02:00:36 --> Loader Class Initialized
INFO - 2017-03-14 02:00:36 --> Database Driver Class Initialized
INFO - 2017-03-14 02:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:00:36 --> Controller Class Initialized
INFO - 2017-03-14 02:00:36 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:00:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:00:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:00:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:00:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:00:36 --> Final output sent to browser
DEBUG - 2017-03-14 02:00:36 --> Total execution time: 0.0152
INFO - 2017-03-14 02:00:40 --> Config Class Initialized
INFO - 2017-03-14 02:00:40 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:00:40 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:00:40 --> Utf8 Class Initialized
INFO - 2017-03-14 02:00:40 --> URI Class Initialized
INFO - 2017-03-14 02:00:40 --> Router Class Initialized
INFO - 2017-03-14 02:00:40 --> Output Class Initialized
INFO - 2017-03-14 02:00:40 --> Security Class Initialized
DEBUG - 2017-03-14 02:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:00:40 --> Input Class Initialized
INFO - 2017-03-14 02:00:40 --> Language Class Initialized
INFO - 2017-03-14 02:00:40 --> Loader Class Initialized
INFO - 2017-03-14 02:00:40 --> Database Driver Class Initialized
INFO - 2017-03-14 02:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:00:40 --> Controller Class Initialized
INFO - 2017-03-14 02:00:40 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:00:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:00:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:00:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:00:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:00:40 --> Final output sent to browser
DEBUG - 2017-03-14 02:00:40 --> Total execution time: 0.0137
INFO - 2017-03-14 02:01:11 --> Config Class Initialized
INFO - 2017-03-14 02:01:11 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:01:11 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:01:11 --> Utf8 Class Initialized
INFO - 2017-03-14 02:01:11 --> URI Class Initialized
INFO - 2017-03-14 02:01:11 --> Router Class Initialized
INFO - 2017-03-14 02:01:11 --> Output Class Initialized
INFO - 2017-03-14 02:01:11 --> Security Class Initialized
DEBUG - 2017-03-14 02:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:01:11 --> Input Class Initialized
INFO - 2017-03-14 02:01:11 --> Language Class Initialized
INFO - 2017-03-14 02:01:11 --> Loader Class Initialized
INFO - 2017-03-14 02:01:11 --> Database Driver Class Initialized
INFO - 2017-03-14 02:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:01:12 --> Controller Class Initialized
INFO - 2017-03-14 02:01:12 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:01:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:01:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:01:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:01:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:01:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:01:12 --> Final output sent to browser
DEBUG - 2017-03-14 02:01:12 --> Total execution time: 1.4108
INFO - 2017-03-14 02:01:15 --> Config Class Initialized
INFO - 2017-03-14 02:01:15 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:01:15 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:01:15 --> Utf8 Class Initialized
INFO - 2017-03-14 02:01:15 --> URI Class Initialized
INFO - 2017-03-14 02:01:15 --> Router Class Initialized
INFO - 2017-03-14 02:01:15 --> Output Class Initialized
INFO - 2017-03-14 02:01:15 --> Security Class Initialized
DEBUG - 2017-03-14 02:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:01:15 --> Input Class Initialized
INFO - 2017-03-14 02:01:15 --> Language Class Initialized
INFO - 2017-03-14 02:01:15 --> Loader Class Initialized
INFO - 2017-03-14 02:01:15 --> Database Driver Class Initialized
INFO - 2017-03-14 02:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:01:15 --> Controller Class Initialized
INFO - 2017-03-14 02:01:15 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:01:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:01:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:01:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:01:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:01:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:01:16 --> Final output sent to browser
DEBUG - 2017-03-14 02:01:16 --> Total execution time: 1.2161
INFO - 2017-03-14 02:01:19 --> Config Class Initialized
INFO - 2017-03-14 02:01:19 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:01:19 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:01:19 --> Utf8 Class Initialized
INFO - 2017-03-14 02:01:19 --> URI Class Initialized
INFO - 2017-03-14 02:01:19 --> Router Class Initialized
INFO - 2017-03-14 02:01:19 --> Output Class Initialized
INFO - 2017-03-14 02:01:19 --> Security Class Initialized
DEBUG - 2017-03-14 02:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:01:19 --> Input Class Initialized
INFO - 2017-03-14 02:01:19 --> Language Class Initialized
INFO - 2017-03-14 02:01:19 --> Loader Class Initialized
INFO - 2017-03-14 02:01:19 --> Database Driver Class Initialized
INFO - 2017-03-14 02:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:01:19 --> Controller Class Initialized
INFO - 2017-03-14 02:01:19 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:01:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:01:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:01:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:01:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:01:19 --> Final output sent to browser
DEBUG - 2017-03-14 02:01:19 --> Total execution time: 0.0304
INFO - 2017-03-14 02:01:21 --> Config Class Initialized
INFO - 2017-03-14 02:01:21 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:01:21 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:01:21 --> Utf8 Class Initialized
INFO - 2017-03-14 02:01:21 --> URI Class Initialized
INFO - 2017-03-14 02:01:21 --> Router Class Initialized
INFO - 2017-03-14 02:01:21 --> Output Class Initialized
INFO - 2017-03-14 02:01:21 --> Security Class Initialized
DEBUG - 2017-03-14 02:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:01:21 --> Input Class Initialized
INFO - 2017-03-14 02:01:21 --> Language Class Initialized
INFO - 2017-03-14 02:01:21 --> Loader Class Initialized
INFO - 2017-03-14 02:01:21 --> Database Driver Class Initialized
INFO - 2017-03-14 02:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:01:21 --> Controller Class Initialized
INFO - 2017-03-14 02:01:21 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:01:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:01:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:01:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:01:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:01:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:01:21 --> Final output sent to browser
DEBUG - 2017-03-14 02:01:21 --> Total execution time: 0.0156
INFO - 2017-03-14 02:01:28 --> Config Class Initialized
INFO - 2017-03-14 02:01:28 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:01:28 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:01:28 --> Utf8 Class Initialized
INFO - 2017-03-14 02:01:28 --> URI Class Initialized
INFO - 2017-03-14 02:01:28 --> Router Class Initialized
INFO - 2017-03-14 02:01:28 --> Output Class Initialized
INFO - 2017-03-14 02:01:28 --> Security Class Initialized
DEBUG - 2017-03-14 02:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:01:28 --> Input Class Initialized
INFO - 2017-03-14 02:01:28 --> Language Class Initialized
INFO - 2017-03-14 02:01:28 --> Loader Class Initialized
INFO - 2017-03-14 02:01:28 --> Database Driver Class Initialized
INFO - 2017-03-14 02:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:01:28 --> Controller Class Initialized
INFO - 2017-03-14 02:01:28 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:01:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:01:30 --> Config Class Initialized
INFO - 2017-03-14 02:01:30 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:01:30 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:01:30 --> Utf8 Class Initialized
INFO - 2017-03-14 02:01:30 --> URI Class Initialized
INFO - 2017-03-14 02:01:30 --> Router Class Initialized
INFO - 2017-03-14 02:01:30 --> Output Class Initialized
INFO - 2017-03-14 02:01:30 --> Security Class Initialized
DEBUG - 2017-03-14 02:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:01:30 --> Input Class Initialized
INFO - 2017-03-14 02:01:30 --> Language Class Initialized
INFO - 2017-03-14 02:01:30 --> Loader Class Initialized
INFO - 2017-03-14 02:01:30 --> Database Driver Class Initialized
INFO - 2017-03-14 02:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:01:30 --> Controller Class Initialized
INFO - 2017-03-14 02:01:30 --> Helper loaded: date_helper
DEBUG - 2017-03-14 02:01:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:01:30 --> Helper loaded: url_helper
INFO - 2017-03-14 02:01:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:01:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 02:01:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 02:01:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 02:01:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:01:30 --> Final output sent to browser
DEBUG - 2017-03-14 02:01:30 --> Total execution time: 0.0935
INFO - 2017-03-14 02:01:30 --> Config Class Initialized
INFO - 2017-03-14 02:01:30 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:01:30 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:01:30 --> Utf8 Class Initialized
INFO - 2017-03-14 02:01:30 --> URI Class Initialized
INFO - 2017-03-14 02:01:30 --> Router Class Initialized
INFO - 2017-03-14 02:01:30 --> Output Class Initialized
INFO - 2017-03-14 02:01:30 --> Security Class Initialized
DEBUG - 2017-03-14 02:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:01:30 --> Input Class Initialized
INFO - 2017-03-14 02:01:30 --> Language Class Initialized
INFO - 2017-03-14 02:01:30 --> Loader Class Initialized
INFO - 2017-03-14 02:01:30 --> Database Driver Class Initialized
INFO - 2017-03-14 02:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:01:30 --> Controller Class Initialized
INFO - 2017-03-14 02:01:30 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:01:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:01:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:01:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:01:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:01:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:01:30 --> Final output sent to browser
DEBUG - 2017-03-14 02:01:30 --> Total execution time: 0.0134
INFO - 2017-03-14 02:01:33 --> Config Class Initialized
INFO - 2017-03-14 02:01:33 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:01:33 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:01:33 --> Utf8 Class Initialized
INFO - 2017-03-14 02:01:33 --> URI Class Initialized
DEBUG - 2017-03-14 02:01:33 --> No URI present. Default controller set.
INFO - 2017-03-14 02:01:33 --> Router Class Initialized
INFO - 2017-03-14 02:01:33 --> Output Class Initialized
INFO - 2017-03-14 02:01:33 --> Security Class Initialized
DEBUG - 2017-03-14 02:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:01:33 --> Input Class Initialized
INFO - 2017-03-14 02:01:33 --> Language Class Initialized
INFO - 2017-03-14 02:01:33 --> Loader Class Initialized
INFO - 2017-03-14 02:01:33 --> Database Driver Class Initialized
INFO - 2017-03-14 02:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:01:33 --> Controller Class Initialized
INFO - 2017-03-14 02:01:33 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:01:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:01:33 --> Final output sent to browser
DEBUG - 2017-03-14 02:01:33 --> Total execution time: 0.0128
INFO - 2017-03-14 02:01:34 --> Config Class Initialized
INFO - 2017-03-14 02:01:34 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:01:34 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:01:34 --> Utf8 Class Initialized
INFO - 2017-03-14 02:01:34 --> URI Class Initialized
INFO - 2017-03-14 02:01:34 --> Router Class Initialized
INFO - 2017-03-14 02:01:34 --> Output Class Initialized
INFO - 2017-03-14 02:01:34 --> Security Class Initialized
DEBUG - 2017-03-14 02:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:01:34 --> Input Class Initialized
INFO - 2017-03-14 02:01:34 --> Language Class Initialized
INFO - 2017-03-14 02:01:34 --> Loader Class Initialized
INFO - 2017-03-14 02:01:34 --> Database Driver Class Initialized
INFO - 2017-03-14 02:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:01:34 --> Controller Class Initialized
INFO - 2017-03-14 02:01:34 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:01:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:01:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:01:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:01:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:01:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:01:34 --> Final output sent to browser
DEBUG - 2017-03-14 02:01:34 --> Total execution time: 0.0133
INFO - 2017-03-14 02:01:55 --> Config Class Initialized
INFO - 2017-03-14 02:01:55 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:01:55 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:01:55 --> Utf8 Class Initialized
INFO - 2017-03-14 02:01:55 --> URI Class Initialized
INFO - 2017-03-14 02:01:55 --> Router Class Initialized
INFO - 2017-03-14 02:01:55 --> Output Class Initialized
INFO - 2017-03-14 02:01:55 --> Security Class Initialized
DEBUG - 2017-03-14 02:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:01:55 --> Input Class Initialized
INFO - 2017-03-14 02:01:55 --> Language Class Initialized
INFO - 2017-03-14 02:01:55 --> Loader Class Initialized
INFO - 2017-03-14 02:01:55 --> Database Driver Class Initialized
INFO - 2017-03-14 02:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:01:55 --> Controller Class Initialized
INFO - 2017-03-14 02:01:55 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:01:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:01:55 --> Final output sent to browser
DEBUG - 2017-03-14 02:01:55 --> Total execution time: 0.0144
INFO - 2017-03-14 02:02:00 --> Config Class Initialized
INFO - 2017-03-14 02:02:00 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:02:00 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:02:00 --> Utf8 Class Initialized
INFO - 2017-03-14 02:02:00 --> URI Class Initialized
INFO - 2017-03-14 02:02:00 --> Router Class Initialized
INFO - 2017-03-14 02:02:00 --> Output Class Initialized
INFO - 2017-03-14 02:02:00 --> Security Class Initialized
DEBUG - 2017-03-14 02:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:02:00 --> Input Class Initialized
INFO - 2017-03-14 02:02:00 --> Language Class Initialized
INFO - 2017-03-14 02:02:00 --> Loader Class Initialized
INFO - 2017-03-14 02:02:00 --> Database Driver Class Initialized
INFO - 2017-03-14 02:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:02:00 --> Controller Class Initialized
INFO - 2017-03-14 02:02:00 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:02:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:02:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:02:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:02:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:02:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:02:00 --> Final output sent to browser
DEBUG - 2017-03-14 02:02:00 --> Total execution time: 0.0134
INFO - 2017-03-14 02:02:01 --> Config Class Initialized
INFO - 2017-03-14 02:02:01 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:02:01 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:02:01 --> Utf8 Class Initialized
INFO - 2017-03-14 02:02:01 --> URI Class Initialized
INFO - 2017-03-14 02:02:01 --> Router Class Initialized
INFO - 2017-03-14 02:02:01 --> Output Class Initialized
INFO - 2017-03-14 02:02:01 --> Security Class Initialized
DEBUG - 2017-03-14 02:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:02:01 --> Input Class Initialized
INFO - 2017-03-14 02:02:01 --> Language Class Initialized
INFO - 2017-03-14 02:02:01 --> Loader Class Initialized
INFO - 2017-03-14 02:02:01 --> Database Driver Class Initialized
INFO - 2017-03-14 02:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:02:01 --> Controller Class Initialized
INFO - 2017-03-14 02:02:01 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:02:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:02:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:02:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:02:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:02:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:02:01 --> Final output sent to browser
DEBUG - 2017-03-14 02:02:01 --> Total execution time: 0.0152
INFO - 2017-03-14 02:02:04 --> Config Class Initialized
INFO - 2017-03-14 02:02:04 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:02:04 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:02:04 --> Utf8 Class Initialized
INFO - 2017-03-14 02:02:04 --> URI Class Initialized
INFO - 2017-03-14 02:02:04 --> Router Class Initialized
INFO - 2017-03-14 02:02:04 --> Output Class Initialized
INFO - 2017-03-14 02:02:04 --> Security Class Initialized
DEBUG - 2017-03-14 02:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:02:04 --> Input Class Initialized
INFO - 2017-03-14 02:02:04 --> Language Class Initialized
INFO - 2017-03-14 02:02:04 --> Loader Class Initialized
INFO - 2017-03-14 02:02:04 --> Database Driver Class Initialized
INFO - 2017-03-14 02:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:02:04 --> Controller Class Initialized
INFO - 2017-03-14 02:02:04 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:02:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:02:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:02:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:02:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:02:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:02:04 --> Final output sent to browser
DEBUG - 2017-03-14 02:02:04 --> Total execution time: 0.0133
INFO - 2017-03-14 02:02:24 --> Config Class Initialized
INFO - 2017-03-14 02:02:24 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:02:24 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:02:24 --> Utf8 Class Initialized
INFO - 2017-03-14 02:02:24 --> URI Class Initialized
INFO - 2017-03-14 02:02:24 --> Router Class Initialized
INFO - 2017-03-14 02:02:24 --> Output Class Initialized
INFO - 2017-03-14 02:02:24 --> Security Class Initialized
DEBUG - 2017-03-14 02:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:02:24 --> Input Class Initialized
INFO - 2017-03-14 02:02:24 --> Language Class Initialized
INFO - 2017-03-14 02:02:24 --> Loader Class Initialized
INFO - 2017-03-14 02:02:24 --> Database Driver Class Initialized
INFO - 2017-03-14 02:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:02:24 --> Controller Class Initialized
INFO - 2017-03-14 02:02:24 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:02:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:02:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:02:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:02:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:02:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:02:24 --> Final output sent to browser
DEBUG - 2017-03-14 02:02:24 --> Total execution time: 0.0147
INFO - 2017-03-14 02:02:26 --> Config Class Initialized
INFO - 2017-03-14 02:02:26 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:02:26 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:02:26 --> Utf8 Class Initialized
INFO - 2017-03-14 02:02:26 --> URI Class Initialized
INFO - 2017-03-14 02:02:26 --> Router Class Initialized
INFO - 2017-03-14 02:02:26 --> Output Class Initialized
INFO - 2017-03-14 02:02:26 --> Security Class Initialized
DEBUG - 2017-03-14 02:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:02:26 --> Input Class Initialized
INFO - 2017-03-14 02:02:26 --> Language Class Initialized
INFO - 2017-03-14 02:02:26 --> Loader Class Initialized
INFO - 2017-03-14 02:02:26 --> Database Driver Class Initialized
INFO - 2017-03-14 02:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:02:26 --> Controller Class Initialized
INFO - 2017-03-14 02:02:26 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:02:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:02:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:02:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:02:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:02:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:02:26 --> Final output sent to browser
DEBUG - 2017-03-14 02:02:26 --> Total execution time: 0.0141
INFO - 2017-03-14 02:04:46 --> Config Class Initialized
INFO - 2017-03-14 02:04:46 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:04:46 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:04:46 --> Utf8 Class Initialized
INFO - 2017-03-14 02:04:46 --> URI Class Initialized
INFO - 2017-03-14 02:04:46 --> Router Class Initialized
INFO - 2017-03-14 02:04:46 --> Output Class Initialized
INFO - 2017-03-14 02:04:46 --> Security Class Initialized
DEBUG - 2017-03-14 02:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:04:46 --> Input Class Initialized
INFO - 2017-03-14 02:04:46 --> Language Class Initialized
INFO - 2017-03-14 02:04:46 --> Loader Class Initialized
INFO - 2017-03-14 02:04:47 --> Database Driver Class Initialized
INFO - 2017-03-14 02:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:04:47 --> Controller Class Initialized
INFO - 2017-03-14 02:04:47 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:04:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:04:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:04:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:04:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:04:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:04:47 --> Final output sent to browser
DEBUG - 2017-03-14 02:04:47 --> Total execution time: 1.2714
INFO - 2017-03-14 02:04:48 --> Config Class Initialized
INFO - 2017-03-14 02:04:48 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:04:48 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:04:48 --> Utf8 Class Initialized
INFO - 2017-03-14 02:04:48 --> URI Class Initialized
INFO - 2017-03-14 02:04:48 --> Router Class Initialized
INFO - 2017-03-14 02:04:48 --> Output Class Initialized
INFO - 2017-03-14 02:04:48 --> Security Class Initialized
DEBUG - 2017-03-14 02:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:04:48 --> Input Class Initialized
INFO - 2017-03-14 02:04:48 --> Language Class Initialized
INFO - 2017-03-14 02:04:48 --> Loader Class Initialized
INFO - 2017-03-14 02:04:48 --> Database Driver Class Initialized
INFO - 2017-03-14 02:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:04:48 --> Controller Class Initialized
INFO - 2017-03-14 02:04:48 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:04:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:04:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:04:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:04:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:04:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:04:48 --> Final output sent to browser
DEBUG - 2017-03-14 02:04:48 --> Total execution time: 0.0199
INFO - 2017-03-14 02:05:06 --> Config Class Initialized
INFO - 2017-03-14 02:05:06 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:05:06 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:05:06 --> Utf8 Class Initialized
INFO - 2017-03-14 02:05:06 --> URI Class Initialized
INFO - 2017-03-14 02:05:06 --> Router Class Initialized
INFO - 2017-03-14 02:05:06 --> Output Class Initialized
INFO - 2017-03-14 02:05:06 --> Security Class Initialized
DEBUG - 2017-03-14 02:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:05:06 --> Input Class Initialized
INFO - 2017-03-14 02:05:06 --> Language Class Initialized
INFO - 2017-03-14 02:05:06 --> Loader Class Initialized
INFO - 2017-03-14 02:05:06 --> Database Driver Class Initialized
INFO - 2017-03-14 02:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:05:07 --> Controller Class Initialized
INFO - 2017-03-14 02:05:07 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:05:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:05:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:05:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:05:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:05:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:05:07 --> Final output sent to browser
DEBUG - 2017-03-14 02:05:07 --> Total execution time: 1.2831
INFO - 2017-03-14 02:05:08 --> Config Class Initialized
INFO - 2017-03-14 02:05:08 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:05:08 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:05:08 --> Utf8 Class Initialized
INFO - 2017-03-14 02:05:08 --> URI Class Initialized
INFO - 2017-03-14 02:05:08 --> Router Class Initialized
INFO - 2017-03-14 02:05:08 --> Output Class Initialized
INFO - 2017-03-14 02:05:08 --> Security Class Initialized
DEBUG - 2017-03-14 02:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:05:08 --> Input Class Initialized
INFO - 2017-03-14 02:05:08 --> Language Class Initialized
INFO - 2017-03-14 02:05:08 --> Loader Class Initialized
INFO - 2017-03-14 02:05:08 --> Database Driver Class Initialized
INFO - 2017-03-14 02:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:05:08 --> Controller Class Initialized
INFO - 2017-03-14 02:05:08 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:05:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:05:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:05:08 --> Final output sent to browser
DEBUG - 2017-03-14 02:05:08 --> Total execution time: 0.0140
INFO - 2017-03-14 02:05:22 --> Config Class Initialized
INFO - 2017-03-14 02:05:22 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:05:22 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:05:22 --> Utf8 Class Initialized
INFO - 2017-03-14 02:05:22 --> URI Class Initialized
INFO - 2017-03-14 02:05:22 --> Router Class Initialized
INFO - 2017-03-14 02:05:22 --> Output Class Initialized
INFO - 2017-03-14 02:05:22 --> Security Class Initialized
DEBUG - 2017-03-14 02:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:05:23 --> Input Class Initialized
INFO - 2017-03-14 02:05:23 --> Language Class Initialized
INFO - 2017-03-14 02:05:23 --> Loader Class Initialized
INFO - 2017-03-14 02:05:23 --> Database Driver Class Initialized
INFO - 2017-03-14 02:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:05:23 --> Controller Class Initialized
INFO - 2017-03-14 02:05:23 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:05:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:05:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:05:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:05:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:05:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:05:24 --> Final output sent to browser
DEBUG - 2017-03-14 02:05:24 --> Total execution time: 1.2859
INFO - 2017-03-14 02:05:25 --> Config Class Initialized
INFO - 2017-03-14 02:05:25 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:05:25 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:05:25 --> Utf8 Class Initialized
INFO - 2017-03-14 02:05:25 --> URI Class Initialized
INFO - 2017-03-14 02:05:25 --> Router Class Initialized
INFO - 2017-03-14 02:05:25 --> Output Class Initialized
INFO - 2017-03-14 02:05:25 --> Security Class Initialized
DEBUG - 2017-03-14 02:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:05:25 --> Input Class Initialized
INFO - 2017-03-14 02:05:25 --> Language Class Initialized
INFO - 2017-03-14 02:05:25 --> Loader Class Initialized
INFO - 2017-03-14 02:05:25 --> Database Driver Class Initialized
INFO - 2017-03-14 02:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:05:25 --> Controller Class Initialized
INFO - 2017-03-14 02:05:25 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:05:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:05:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:05:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:05:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:05:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:05:25 --> Final output sent to browser
DEBUG - 2017-03-14 02:05:25 --> Total execution time: 0.5597
INFO - 2017-03-14 02:05:38 --> Config Class Initialized
INFO - 2017-03-14 02:05:38 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:05:38 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:05:38 --> Utf8 Class Initialized
INFO - 2017-03-14 02:05:38 --> URI Class Initialized
INFO - 2017-03-14 02:05:38 --> Router Class Initialized
INFO - 2017-03-14 02:05:38 --> Output Class Initialized
INFO - 2017-03-14 02:05:38 --> Security Class Initialized
DEBUG - 2017-03-14 02:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:05:38 --> Input Class Initialized
INFO - 2017-03-14 02:05:38 --> Language Class Initialized
INFO - 2017-03-14 02:05:38 --> Loader Class Initialized
INFO - 2017-03-14 02:05:38 --> Database Driver Class Initialized
INFO - 2017-03-14 02:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:05:38 --> Controller Class Initialized
INFO - 2017-03-14 02:05:38 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:05:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:05:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:05:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:05:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:05:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:05:38 --> Final output sent to browser
DEBUG - 2017-03-14 02:05:38 --> Total execution time: 0.0296
INFO - 2017-03-14 02:05:39 --> Config Class Initialized
INFO - 2017-03-14 02:05:39 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:05:39 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:05:39 --> Utf8 Class Initialized
INFO - 2017-03-14 02:05:39 --> URI Class Initialized
INFO - 2017-03-14 02:05:39 --> Router Class Initialized
INFO - 2017-03-14 02:05:39 --> Output Class Initialized
INFO - 2017-03-14 02:05:39 --> Security Class Initialized
DEBUG - 2017-03-14 02:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:05:39 --> Input Class Initialized
INFO - 2017-03-14 02:05:39 --> Language Class Initialized
INFO - 2017-03-14 02:05:39 --> Loader Class Initialized
INFO - 2017-03-14 02:05:39 --> Database Driver Class Initialized
INFO - 2017-03-14 02:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:05:39 --> Controller Class Initialized
INFO - 2017-03-14 02:05:39 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:05:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:05:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:05:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:05:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:05:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:05:39 --> Final output sent to browser
DEBUG - 2017-03-14 02:05:39 --> Total execution time: 0.0133
INFO - 2017-03-14 02:05:52 --> Config Class Initialized
INFO - 2017-03-14 02:05:52 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:05:52 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:05:52 --> Utf8 Class Initialized
INFO - 2017-03-14 02:05:52 --> URI Class Initialized
INFO - 2017-03-14 02:05:52 --> Router Class Initialized
INFO - 2017-03-14 02:05:52 --> Output Class Initialized
INFO - 2017-03-14 02:05:52 --> Security Class Initialized
DEBUG - 2017-03-14 02:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:05:52 --> Input Class Initialized
INFO - 2017-03-14 02:05:52 --> Language Class Initialized
INFO - 2017-03-14 02:05:52 --> Loader Class Initialized
INFO - 2017-03-14 02:05:52 --> Database Driver Class Initialized
INFO - 2017-03-14 02:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:05:52 --> Controller Class Initialized
INFO - 2017-03-14 02:05:52 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:05:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:05:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:05:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:05:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:05:52 --> Final output sent to browser
DEBUG - 2017-03-14 02:05:52 --> Total execution time: 0.0146
INFO - 2017-03-14 02:05:53 --> Config Class Initialized
INFO - 2017-03-14 02:05:53 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:05:53 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:05:53 --> Utf8 Class Initialized
INFO - 2017-03-14 02:05:53 --> URI Class Initialized
INFO - 2017-03-14 02:05:53 --> Router Class Initialized
INFO - 2017-03-14 02:05:53 --> Output Class Initialized
INFO - 2017-03-14 02:05:53 --> Security Class Initialized
DEBUG - 2017-03-14 02:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:05:53 --> Input Class Initialized
INFO - 2017-03-14 02:05:53 --> Language Class Initialized
INFO - 2017-03-14 02:05:53 --> Loader Class Initialized
INFO - 2017-03-14 02:05:53 --> Database Driver Class Initialized
INFO - 2017-03-14 02:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:05:53 --> Controller Class Initialized
INFO - 2017-03-14 02:05:53 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:05:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:05:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:05:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:05:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:05:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:05:53 --> Final output sent to browser
DEBUG - 2017-03-14 02:05:53 --> Total execution time: 0.0134
INFO - 2017-03-14 02:15:59 --> Config Class Initialized
INFO - 2017-03-14 02:15:59 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:15:59 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:15:59 --> Utf8 Class Initialized
INFO - 2017-03-14 02:15:59 --> URI Class Initialized
DEBUG - 2017-03-14 02:15:59 --> No URI present. Default controller set.
INFO - 2017-03-14 02:15:59 --> Router Class Initialized
INFO - 2017-03-14 02:15:59 --> Output Class Initialized
INFO - 2017-03-14 02:15:59 --> Security Class Initialized
DEBUG - 2017-03-14 02:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:15:59 --> Input Class Initialized
INFO - 2017-03-14 02:15:59 --> Language Class Initialized
INFO - 2017-03-14 02:15:59 --> Loader Class Initialized
INFO - 2017-03-14 02:16:00 --> Database Driver Class Initialized
INFO - 2017-03-14 02:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:16:00 --> Controller Class Initialized
INFO - 2017-03-14 02:16:00 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:16:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:16:00 --> Final output sent to browser
DEBUG - 2017-03-14 02:16:00 --> Total execution time: 1.4836
INFO - 2017-03-14 02:16:03 --> Config Class Initialized
INFO - 2017-03-14 02:16:03 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:16:03 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:16:03 --> Utf8 Class Initialized
INFO - 2017-03-14 02:16:03 --> URI Class Initialized
INFO - 2017-03-14 02:16:03 --> Router Class Initialized
INFO - 2017-03-14 02:16:03 --> Output Class Initialized
INFO - 2017-03-14 02:16:03 --> Security Class Initialized
DEBUG - 2017-03-14 02:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:16:03 --> Input Class Initialized
INFO - 2017-03-14 02:16:03 --> Language Class Initialized
INFO - 2017-03-14 02:16:03 --> Loader Class Initialized
INFO - 2017-03-14 02:16:04 --> Database Driver Class Initialized
INFO - 2017-03-14 02:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:16:04 --> Controller Class Initialized
INFO - 2017-03-14 02:16:04 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:16:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:16:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:16:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:16:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:16:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:16:04 --> Final output sent to browser
DEBUG - 2017-03-14 02:16:04 --> Total execution time: 1.2327
INFO - 2017-03-14 02:16:55 --> Config Class Initialized
INFO - 2017-03-14 02:16:55 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:16:55 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:16:55 --> Utf8 Class Initialized
INFO - 2017-03-14 02:16:55 --> URI Class Initialized
INFO - 2017-03-14 02:16:55 --> Router Class Initialized
INFO - 2017-03-14 02:16:55 --> Output Class Initialized
INFO - 2017-03-14 02:16:55 --> Security Class Initialized
DEBUG - 2017-03-14 02:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:16:55 --> Input Class Initialized
INFO - 2017-03-14 02:16:55 --> Language Class Initialized
INFO - 2017-03-14 02:16:55 --> Loader Class Initialized
INFO - 2017-03-14 02:16:55 --> Database Driver Class Initialized
INFO - 2017-03-14 02:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:16:56 --> Controller Class Initialized
INFO - 2017-03-14 02:16:56 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:16:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:16:56 --> Helper loaded: form_helper
INFO - 2017-03-14 02:16:56 --> Form Validation Class Initialized
INFO - 2017-03-14 02:16:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-14 02:16:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-03-14 02:16:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-14 02:16:56 --> Final output sent to browser
DEBUG - 2017-03-14 02:16:56 --> Total execution time: 1.6746
INFO - 2017-03-14 02:16:57 --> Config Class Initialized
INFO - 2017-03-14 02:16:57 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:16:57 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:16:57 --> Utf8 Class Initialized
INFO - 2017-03-14 02:16:57 --> URI Class Initialized
INFO - 2017-03-14 02:16:57 --> Router Class Initialized
INFO - 2017-03-14 02:16:57 --> Output Class Initialized
INFO - 2017-03-14 02:16:57 --> Security Class Initialized
DEBUG - 2017-03-14 02:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:16:57 --> Input Class Initialized
INFO - 2017-03-14 02:16:57 --> Language Class Initialized
INFO - 2017-03-14 02:16:57 --> Loader Class Initialized
INFO - 2017-03-14 02:16:57 --> Database Driver Class Initialized
INFO - 2017-03-14 02:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:16:57 --> Controller Class Initialized
INFO - 2017-03-14 02:16:57 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:16:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:16:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:16:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:16:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:16:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:16:57 --> Final output sent to browser
DEBUG - 2017-03-14 02:16:57 --> Total execution time: 0.2623
INFO - 2017-03-14 02:17:41 --> Config Class Initialized
INFO - 2017-03-14 02:17:41 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:17:41 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:17:41 --> Utf8 Class Initialized
INFO - 2017-03-14 02:17:41 --> URI Class Initialized
INFO - 2017-03-14 02:17:41 --> Router Class Initialized
INFO - 2017-03-14 02:17:41 --> Output Class Initialized
INFO - 2017-03-14 02:17:41 --> Security Class Initialized
DEBUG - 2017-03-14 02:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:17:41 --> Input Class Initialized
INFO - 2017-03-14 02:17:41 --> Language Class Initialized
INFO - 2017-03-14 02:17:41 --> Loader Class Initialized
INFO - 2017-03-14 02:17:41 --> Database Driver Class Initialized
INFO - 2017-03-14 02:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:17:42 --> Controller Class Initialized
INFO - 2017-03-14 02:17:42 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:17:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:17:42 --> Final output sent to browser
DEBUG - 2017-03-14 02:17:42 --> Total execution time: 1.2557
INFO - 2017-03-14 02:17:42 --> Config Class Initialized
INFO - 2017-03-14 02:17:42 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:17:42 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:17:42 --> Utf8 Class Initialized
INFO - 2017-03-14 02:17:42 --> URI Class Initialized
INFO - 2017-03-14 02:17:42 --> Router Class Initialized
INFO - 2017-03-14 02:17:42 --> Output Class Initialized
INFO - 2017-03-14 02:17:42 --> Security Class Initialized
DEBUG - 2017-03-14 02:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:17:42 --> Input Class Initialized
INFO - 2017-03-14 02:17:42 --> Language Class Initialized
INFO - 2017-03-14 02:17:42 --> Loader Class Initialized
INFO - 2017-03-14 02:17:42 --> Database Driver Class Initialized
INFO - 2017-03-14 02:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:17:42 --> Controller Class Initialized
INFO - 2017-03-14 02:17:42 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:17:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:17:42 --> Final output sent to browser
DEBUG - 2017-03-14 02:17:42 --> Total execution time: 0.0163
INFO - 2017-03-14 02:18:07 --> Config Class Initialized
INFO - 2017-03-14 02:18:07 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:18:07 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:18:07 --> Utf8 Class Initialized
INFO - 2017-03-14 02:18:07 --> URI Class Initialized
INFO - 2017-03-14 02:18:07 --> Router Class Initialized
INFO - 2017-03-14 02:18:07 --> Output Class Initialized
INFO - 2017-03-14 02:18:07 --> Security Class Initialized
DEBUG - 2017-03-14 02:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:18:07 --> Input Class Initialized
INFO - 2017-03-14 02:18:07 --> Language Class Initialized
INFO - 2017-03-14 02:18:07 --> Loader Class Initialized
INFO - 2017-03-14 02:18:07 --> Database Driver Class Initialized
INFO - 2017-03-14 02:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:18:07 --> Controller Class Initialized
INFO - 2017-03-14 02:18:07 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:18:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:18:07 --> Helper loaded: form_helper
INFO - 2017-03-14 02:18:07 --> Form Validation Class Initialized
INFO - 2017-03-14 02:18:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-14 02:18:07 --> Config Class Initialized
INFO - 2017-03-14 02:18:07 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:18:07 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:18:07 --> Utf8 Class Initialized
INFO - 2017-03-14 02:18:07 --> URI Class Initialized
INFO - 2017-03-14 02:18:07 --> Router Class Initialized
INFO - 2017-03-14 02:18:07 --> Output Class Initialized
INFO - 2017-03-14 02:18:07 --> Security Class Initialized
DEBUG - 2017-03-14 02:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:18:07 --> Input Class Initialized
INFO - 2017-03-14 02:18:07 --> Language Class Initialized
INFO - 2017-03-14 02:18:07 --> Loader Class Initialized
INFO - 2017-03-14 02:18:07 --> Database Driver Class Initialized
INFO - 2017-03-14 02:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:18:07 --> Controller Class Initialized
INFO - 2017-03-14 02:18:08 --> Helper loaded: date_helper
INFO - 2017-03-14 02:18:08 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:18:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:18:08 --> Helper loaded: form_helper
INFO - 2017-03-14 02:18:08 --> Form Validation Class Initialized
INFO - 2017-03-14 02:18:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-14 02:18:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-14 02:18:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-03-14 02:18:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-03-14 02:18:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-14 02:18:08 --> Final output sent to browser
DEBUG - 2017-03-14 02:18:08 --> Total execution time: 0.6997
INFO - 2017-03-14 02:18:08 --> Config Class Initialized
INFO - 2017-03-14 02:18:08 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:18:08 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:18:08 --> Utf8 Class Initialized
INFO - 2017-03-14 02:18:08 --> URI Class Initialized
INFO - 2017-03-14 02:18:08 --> Router Class Initialized
INFO - 2017-03-14 02:18:08 --> Output Class Initialized
INFO - 2017-03-14 02:18:08 --> Security Class Initialized
DEBUG - 2017-03-14 02:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:18:08 --> Input Class Initialized
INFO - 2017-03-14 02:18:08 --> Language Class Initialized
INFO - 2017-03-14 02:18:08 --> Loader Class Initialized
INFO - 2017-03-14 02:18:08 --> Database Driver Class Initialized
INFO - 2017-03-14 02:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:18:08 --> Controller Class Initialized
INFO - 2017-03-14 02:18:08 --> Helper loaded: date_helper
INFO - 2017-03-14 02:18:08 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:18:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:18:08 --> Helper loaded: form_helper
INFO - 2017-03-14 02:18:08 --> Form Validation Class Initialized
INFO - 2017-03-14 02:18:08 --> Final output sent to browser
DEBUG - 2017-03-14 02:18:08 --> Total execution time: 0.0535
INFO - 2017-03-14 02:18:09 --> Config Class Initialized
INFO - 2017-03-14 02:18:09 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:18:09 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:18:09 --> Utf8 Class Initialized
INFO - 2017-03-14 02:18:09 --> URI Class Initialized
INFO - 2017-03-14 02:18:09 --> Router Class Initialized
INFO - 2017-03-14 02:18:09 --> Output Class Initialized
INFO - 2017-03-14 02:18:09 --> Security Class Initialized
DEBUG - 2017-03-14 02:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:18:09 --> Input Class Initialized
INFO - 2017-03-14 02:18:09 --> Language Class Initialized
INFO - 2017-03-14 02:18:09 --> Loader Class Initialized
INFO - 2017-03-14 02:18:09 --> Database Driver Class Initialized
INFO - 2017-03-14 02:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:18:09 --> Controller Class Initialized
INFO - 2017-03-14 02:18:09 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:18:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:18:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:18:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:18:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:18:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:18:09 --> Final output sent to browser
DEBUG - 2017-03-14 02:18:09 --> Total execution time: 0.0149
INFO - 2017-03-14 02:18:13 --> Config Class Initialized
INFO - 2017-03-14 02:18:13 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:18:13 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:18:13 --> Utf8 Class Initialized
INFO - 2017-03-14 02:18:13 --> URI Class Initialized
INFO - 2017-03-14 02:18:13 --> Router Class Initialized
INFO - 2017-03-14 02:18:13 --> Output Class Initialized
INFO - 2017-03-14 02:18:13 --> Security Class Initialized
DEBUG - 2017-03-14 02:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:18:13 --> Input Class Initialized
INFO - 2017-03-14 02:18:13 --> Language Class Initialized
INFO - 2017-03-14 02:18:13 --> Loader Class Initialized
INFO - 2017-03-14 02:18:13 --> Database Driver Class Initialized
INFO - 2017-03-14 02:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:18:13 --> Controller Class Initialized
INFO - 2017-03-14 02:18:13 --> Helper loaded: date_helper
INFO - 2017-03-14 02:18:13 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:18:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:18:13 --> Helper loaded: form_helper
INFO - 2017-03-14 02:18:13 --> Form Validation Class Initialized
INFO - 2017-03-14 02:18:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-14 02:18:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-14 02:18:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-03-14 02:18:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-03-14 02:18:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-14 02:18:13 --> Final output sent to browser
DEBUG - 2017-03-14 02:18:13 --> Total execution time: 0.2977
INFO - 2017-03-14 02:18:14 --> Config Class Initialized
INFO - 2017-03-14 02:18:14 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:18:14 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:18:14 --> Utf8 Class Initialized
INFO - 2017-03-14 02:18:14 --> URI Class Initialized
INFO - 2017-03-14 02:18:14 --> Router Class Initialized
INFO - 2017-03-14 02:18:14 --> Output Class Initialized
INFO - 2017-03-14 02:18:14 --> Security Class Initialized
DEBUG - 2017-03-14 02:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:18:14 --> Input Class Initialized
INFO - 2017-03-14 02:18:14 --> Language Class Initialized
INFO - 2017-03-14 02:18:14 --> Loader Class Initialized
INFO - 2017-03-14 02:18:14 --> Database Driver Class Initialized
INFO - 2017-03-14 02:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:18:14 --> Controller Class Initialized
INFO - 2017-03-14 02:18:14 --> Helper loaded: date_helper
INFO - 2017-03-14 02:18:14 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:18:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:18:14 --> Helper loaded: form_helper
INFO - 2017-03-14 02:18:14 --> Form Validation Class Initialized
INFO - 2017-03-14 02:18:14 --> Final output sent to browser
DEBUG - 2017-03-14 02:18:14 --> Total execution time: 0.0155
INFO - 2017-03-14 02:18:14 --> Config Class Initialized
INFO - 2017-03-14 02:18:14 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:18:14 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:18:14 --> Utf8 Class Initialized
INFO - 2017-03-14 02:18:14 --> URI Class Initialized
INFO - 2017-03-14 02:18:14 --> Router Class Initialized
INFO - 2017-03-14 02:18:14 --> Output Class Initialized
INFO - 2017-03-14 02:18:14 --> Security Class Initialized
DEBUG - 2017-03-14 02:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:18:14 --> Input Class Initialized
INFO - 2017-03-14 02:18:14 --> Language Class Initialized
INFO - 2017-03-14 02:18:14 --> Loader Class Initialized
INFO - 2017-03-14 02:18:14 --> Database Driver Class Initialized
INFO - 2017-03-14 02:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:18:14 --> Controller Class Initialized
INFO - 2017-03-14 02:18:14 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:18:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:18:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:18:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:18:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:18:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:18:14 --> Final output sent to browser
DEBUG - 2017-03-14 02:18:14 --> Total execution time: 0.0649
INFO - 2017-03-14 02:18:37 --> Config Class Initialized
INFO - 2017-03-14 02:18:37 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:18:37 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:18:37 --> Utf8 Class Initialized
INFO - 2017-03-14 02:18:37 --> URI Class Initialized
INFO - 2017-03-14 02:18:37 --> Router Class Initialized
INFO - 2017-03-14 02:18:37 --> Output Class Initialized
INFO - 2017-03-14 02:18:37 --> Security Class Initialized
DEBUG - 2017-03-14 02:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:18:37 --> Input Class Initialized
INFO - 2017-03-14 02:18:37 --> Language Class Initialized
INFO - 2017-03-14 02:18:37 --> Loader Class Initialized
INFO - 2017-03-14 02:18:37 --> Database Driver Class Initialized
INFO - 2017-03-14 02:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:18:37 --> Controller Class Initialized
INFO - 2017-03-14 02:18:37 --> Helper loaded: date_helper
INFO - 2017-03-14 02:18:37 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:18:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:18:37 --> Helper loaded: form_helper
INFO - 2017-03-14 02:18:37 --> Form Validation Class Initialized
INFO - 2017-03-14 02:18:37 --> Final output sent to browser
DEBUG - 2017-03-14 02:18:37 --> Total execution time: 0.0151
INFO - 2017-03-14 02:18:41 --> Config Class Initialized
INFO - 2017-03-14 02:18:41 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:18:41 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:18:41 --> Utf8 Class Initialized
INFO - 2017-03-14 02:18:41 --> URI Class Initialized
INFO - 2017-03-14 02:18:41 --> Router Class Initialized
INFO - 2017-03-14 02:18:41 --> Output Class Initialized
INFO - 2017-03-14 02:18:41 --> Security Class Initialized
DEBUG - 2017-03-14 02:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:18:41 --> Input Class Initialized
INFO - 2017-03-14 02:18:41 --> Language Class Initialized
INFO - 2017-03-14 02:18:41 --> Loader Class Initialized
INFO - 2017-03-14 02:18:41 --> Database Driver Class Initialized
INFO - 2017-03-14 02:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:18:41 --> Controller Class Initialized
INFO - 2017-03-14 02:18:41 --> Helper loaded: date_helper
INFO - 2017-03-14 02:18:41 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:18:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:18:41 --> Helper loaded: form_helper
INFO - 2017-03-14 02:18:41 --> Form Validation Class Initialized
INFO - 2017-03-14 02:18:41 --> Final output sent to browser
DEBUG - 2017-03-14 02:18:41 --> Total execution time: 0.0158
INFO - 2017-03-14 02:18:45 --> Config Class Initialized
INFO - 2017-03-14 02:18:45 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:18:45 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:18:45 --> Utf8 Class Initialized
INFO - 2017-03-14 02:18:45 --> URI Class Initialized
INFO - 2017-03-14 02:18:45 --> Router Class Initialized
INFO - 2017-03-14 02:18:45 --> Output Class Initialized
INFO - 2017-03-14 02:18:45 --> Security Class Initialized
DEBUG - 2017-03-14 02:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:18:45 --> Input Class Initialized
INFO - 2017-03-14 02:18:45 --> Language Class Initialized
INFO - 2017-03-14 02:18:45 --> Loader Class Initialized
INFO - 2017-03-14 02:18:45 --> Database Driver Class Initialized
INFO - 2017-03-14 02:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:18:45 --> Controller Class Initialized
INFO - 2017-03-14 02:18:45 --> Helper loaded: date_helper
INFO - 2017-03-14 02:18:45 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:18:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:18:45 --> Helper loaded: form_helper
INFO - 2017-03-14 02:18:45 --> Form Validation Class Initialized
INFO - 2017-03-14 02:18:45 --> Final output sent to browser
DEBUG - 2017-03-14 02:18:45 --> Total execution time: 0.0155
INFO - 2017-03-14 02:18:45 --> Config Class Initialized
INFO - 2017-03-14 02:18:45 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:18:45 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:18:45 --> Utf8 Class Initialized
INFO - 2017-03-14 02:18:45 --> URI Class Initialized
INFO - 2017-03-14 02:18:45 --> Router Class Initialized
INFO - 2017-03-14 02:18:45 --> Output Class Initialized
INFO - 2017-03-14 02:18:45 --> Security Class Initialized
DEBUG - 2017-03-14 02:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:18:45 --> Input Class Initialized
INFO - 2017-03-14 02:18:45 --> Language Class Initialized
INFO - 2017-03-14 02:18:45 --> Loader Class Initialized
INFO - 2017-03-14 02:18:45 --> Database Driver Class Initialized
INFO - 2017-03-14 02:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:18:45 --> Controller Class Initialized
INFO - 2017-03-14 02:18:45 --> Helper loaded: date_helper
INFO - 2017-03-14 02:18:45 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:18:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:18:45 --> Helper loaded: form_helper
INFO - 2017-03-14 02:18:45 --> Form Validation Class Initialized
INFO - 2017-03-14 02:18:45 --> Final output sent to browser
DEBUG - 2017-03-14 02:18:45 --> Total execution time: 0.0143
INFO - 2017-03-14 02:18:51 --> Config Class Initialized
INFO - 2017-03-14 02:18:51 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:18:51 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:18:51 --> Utf8 Class Initialized
INFO - 2017-03-14 02:18:51 --> URI Class Initialized
INFO - 2017-03-14 02:18:51 --> Router Class Initialized
INFO - 2017-03-14 02:18:51 --> Output Class Initialized
INFO - 2017-03-14 02:18:51 --> Security Class Initialized
DEBUG - 2017-03-14 02:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:18:51 --> Input Class Initialized
INFO - 2017-03-14 02:18:51 --> Language Class Initialized
INFO - 2017-03-14 02:18:51 --> Loader Class Initialized
INFO - 2017-03-14 02:18:51 --> Database Driver Class Initialized
INFO - 2017-03-14 02:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:18:51 --> Controller Class Initialized
INFO - 2017-03-14 02:18:51 --> Helper loaded: date_helper
INFO - 2017-03-14 02:18:51 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:18:51 --> Helper loaded: form_helper
INFO - 2017-03-14 02:18:51 --> Form Validation Class Initialized
INFO - 2017-03-14 02:18:51 --> Final output sent to browser
DEBUG - 2017-03-14 02:18:51 --> Total execution time: 0.0145
INFO - 2017-03-14 02:18:51 --> Config Class Initialized
INFO - 2017-03-14 02:18:51 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:18:51 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:18:51 --> Utf8 Class Initialized
INFO - 2017-03-14 02:18:51 --> URI Class Initialized
INFO - 2017-03-14 02:18:51 --> Router Class Initialized
INFO - 2017-03-14 02:18:51 --> Output Class Initialized
INFO - 2017-03-14 02:18:51 --> Security Class Initialized
DEBUG - 2017-03-14 02:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:18:51 --> Input Class Initialized
INFO - 2017-03-14 02:18:51 --> Language Class Initialized
INFO - 2017-03-14 02:18:51 --> Loader Class Initialized
INFO - 2017-03-14 02:18:51 --> Database Driver Class Initialized
INFO - 2017-03-14 02:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:18:51 --> Controller Class Initialized
INFO - 2017-03-14 02:18:51 --> Helper loaded: date_helper
INFO - 2017-03-14 02:18:51 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:18:51 --> Helper loaded: form_helper
INFO - 2017-03-14 02:18:51 --> Form Validation Class Initialized
INFO - 2017-03-14 02:18:51 --> Final output sent to browser
DEBUG - 2017-03-14 02:18:51 --> Total execution time: 0.0155
INFO - 2017-03-14 02:18:52 --> Config Class Initialized
INFO - 2017-03-14 02:18:52 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:18:52 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:18:52 --> Utf8 Class Initialized
INFO - 2017-03-14 02:18:52 --> URI Class Initialized
INFO - 2017-03-14 02:18:52 --> Router Class Initialized
INFO - 2017-03-14 02:18:52 --> Output Class Initialized
INFO - 2017-03-14 02:18:52 --> Security Class Initialized
DEBUG - 2017-03-14 02:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:18:52 --> Input Class Initialized
INFO - 2017-03-14 02:18:52 --> Language Class Initialized
INFO - 2017-03-14 02:18:52 --> Loader Class Initialized
INFO - 2017-03-14 02:18:52 --> Database Driver Class Initialized
INFO - 2017-03-14 02:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:18:52 --> Controller Class Initialized
INFO - 2017-03-14 02:18:52 --> Helper loaded: date_helper
INFO - 2017-03-14 02:18:52 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:18:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:18:52 --> Helper loaded: form_helper
INFO - 2017-03-14 02:18:52 --> Form Validation Class Initialized
INFO - 2017-03-14 02:18:52 --> Final output sent to browser
DEBUG - 2017-03-14 02:18:52 --> Total execution time: 0.0153
INFO - 2017-03-14 02:18:57 --> Config Class Initialized
INFO - 2017-03-14 02:18:57 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:18:57 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:18:57 --> Utf8 Class Initialized
INFO - 2017-03-14 02:18:57 --> URI Class Initialized
INFO - 2017-03-14 02:18:57 --> Router Class Initialized
INFO - 2017-03-14 02:18:57 --> Output Class Initialized
INFO - 2017-03-14 02:18:57 --> Security Class Initialized
DEBUG - 2017-03-14 02:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:18:57 --> Input Class Initialized
INFO - 2017-03-14 02:18:57 --> Language Class Initialized
INFO - 2017-03-14 02:18:57 --> Loader Class Initialized
INFO - 2017-03-14 02:18:57 --> Database Driver Class Initialized
INFO - 2017-03-14 02:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:18:57 --> Controller Class Initialized
INFO - 2017-03-14 02:18:57 --> Helper loaded: date_helper
INFO - 2017-03-14 02:18:57 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:18:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:18:57 --> Helper loaded: form_helper
INFO - 2017-03-14 02:18:57 --> Form Validation Class Initialized
INFO - 2017-03-14 02:18:57 --> Final output sent to browser
DEBUG - 2017-03-14 02:18:57 --> Total execution time: 0.0151
INFO - 2017-03-14 02:18:58 --> Config Class Initialized
INFO - 2017-03-14 02:18:58 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:18:58 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:18:58 --> Utf8 Class Initialized
INFO - 2017-03-14 02:18:58 --> URI Class Initialized
INFO - 2017-03-14 02:18:58 --> Router Class Initialized
INFO - 2017-03-14 02:18:58 --> Output Class Initialized
INFO - 2017-03-14 02:18:58 --> Security Class Initialized
DEBUG - 2017-03-14 02:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:18:58 --> Input Class Initialized
INFO - 2017-03-14 02:18:58 --> Language Class Initialized
INFO - 2017-03-14 02:18:58 --> Loader Class Initialized
INFO - 2017-03-14 02:18:58 --> Database Driver Class Initialized
INFO - 2017-03-14 02:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:18:58 --> Controller Class Initialized
INFO - 2017-03-14 02:18:58 --> Helper loaded: date_helper
INFO - 2017-03-14 02:18:58 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:18:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:18:58 --> Helper loaded: form_helper
INFO - 2017-03-14 02:18:58 --> Form Validation Class Initialized
INFO - 2017-03-14 02:18:58 --> Final output sent to browser
DEBUG - 2017-03-14 02:18:58 --> Total execution time: 0.0151
INFO - 2017-03-14 02:18:59 --> Config Class Initialized
INFO - 2017-03-14 02:18:59 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:18:59 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:18:59 --> Utf8 Class Initialized
INFO - 2017-03-14 02:18:59 --> URI Class Initialized
INFO - 2017-03-14 02:18:59 --> Router Class Initialized
INFO - 2017-03-14 02:18:59 --> Output Class Initialized
INFO - 2017-03-14 02:18:59 --> Security Class Initialized
DEBUG - 2017-03-14 02:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:18:59 --> Input Class Initialized
INFO - 2017-03-14 02:18:59 --> Language Class Initialized
INFO - 2017-03-14 02:18:59 --> Loader Class Initialized
INFO - 2017-03-14 02:18:59 --> Database Driver Class Initialized
INFO - 2017-03-14 02:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:18:59 --> Controller Class Initialized
INFO - 2017-03-14 02:18:59 --> Helper loaded: date_helper
INFO - 2017-03-14 02:18:59 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:18:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:18:59 --> Helper loaded: form_helper
INFO - 2017-03-14 02:18:59 --> Form Validation Class Initialized
INFO - 2017-03-14 02:18:59 --> Final output sent to browser
DEBUG - 2017-03-14 02:18:59 --> Total execution time: 0.0243
INFO - 2017-03-14 02:19:29 --> Config Class Initialized
INFO - 2017-03-14 02:19:29 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:19:29 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:19:29 --> Utf8 Class Initialized
INFO - 2017-03-14 02:19:29 --> URI Class Initialized
INFO - 2017-03-14 02:19:29 --> Router Class Initialized
INFO - 2017-03-14 02:19:29 --> Output Class Initialized
INFO - 2017-03-14 02:19:29 --> Security Class Initialized
DEBUG - 2017-03-14 02:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:19:29 --> Input Class Initialized
INFO - 2017-03-14 02:19:29 --> Language Class Initialized
INFO - 2017-03-14 02:19:29 --> Loader Class Initialized
INFO - 2017-03-14 02:19:29 --> Database Driver Class Initialized
INFO - 2017-03-14 02:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:19:29 --> Controller Class Initialized
INFO - 2017-03-14 02:19:29 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:19:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:19:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:19:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:19:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:19:29 --> Final output sent to browser
DEBUG - 2017-03-14 02:19:29 --> Total execution time: 0.7363
INFO - 2017-03-14 02:19:30 --> Config Class Initialized
INFO - 2017-03-14 02:19:30 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:19:30 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:19:30 --> Utf8 Class Initialized
INFO - 2017-03-14 02:19:30 --> URI Class Initialized
INFO - 2017-03-14 02:19:30 --> Router Class Initialized
INFO - 2017-03-14 02:19:30 --> Output Class Initialized
INFO - 2017-03-14 02:19:30 --> Security Class Initialized
DEBUG - 2017-03-14 02:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:19:30 --> Input Class Initialized
INFO - 2017-03-14 02:19:30 --> Language Class Initialized
INFO - 2017-03-14 02:19:30 --> Loader Class Initialized
INFO - 2017-03-14 02:19:30 --> Database Driver Class Initialized
INFO - 2017-03-14 02:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:19:30 --> Controller Class Initialized
INFO - 2017-03-14 02:19:30 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:19:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:19:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:19:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:19:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:19:30 --> Final output sent to browser
DEBUG - 2017-03-14 02:19:30 --> Total execution time: 0.0133
INFO - 2017-03-14 02:19:43 --> Config Class Initialized
INFO - 2017-03-14 02:19:43 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:19:43 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:19:43 --> Utf8 Class Initialized
INFO - 2017-03-14 02:19:43 --> URI Class Initialized
INFO - 2017-03-14 02:19:43 --> Router Class Initialized
INFO - 2017-03-14 02:19:43 --> Output Class Initialized
INFO - 2017-03-14 02:19:43 --> Security Class Initialized
DEBUG - 2017-03-14 02:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:19:43 --> Input Class Initialized
INFO - 2017-03-14 02:19:43 --> Language Class Initialized
INFO - 2017-03-14 02:19:43 --> Loader Class Initialized
INFO - 2017-03-14 02:19:43 --> Database Driver Class Initialized
INFO - 2017-03-14 02:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:19:43 --> Controller Class Initialized
INFO - 2017-03-14 02:19:43 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:19:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:19:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:19:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:19:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:19:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:19:43 --> Final output sent to browser
DEBUG - 2017-03-14 02:19:43 --> Total execution time: 0.0140
INFO - 2017-03-14 02:19:44 --> Config Class Initialized
INFO - 2017-03-14 02:19:44 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:19:44 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:19:44 --> Utf8 Class Initialized
INFO - 2017-03-14 02:19:44 --> URI Class Initialized
INFO - 2017-03-14 02:19:44 --> Router Class Initialized
INFO - 2017-03-14 02:19:44 --> Output Class Initialized
INFO - 2017-03-14 02:19:44 --> Security Class Initialized
DEBUG - 2017-03-14 02:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:19:44 --> Input Class Initialized
INFO - 2017-03-14 02:19:44 --> Language Class Initialized
INFO - 2017-03-14 02:19:44 --> Loader Class Initialized
INFO - 2017-03-14 02:19:44 --> Database Driver Class Initialized
INFO - 2017-03-14 02:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:19:44 --> Controller Class Initialized
INFO - 2017-03-14 02:19:44 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:19:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:19:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:19:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:19:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:19:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:19:44 --> Final output sent to browser
DEBUG - 2017-03-14 02:19:44 --> Total execution time: 0.0135
INFO - 2017-03-14 02:20:14 --> Config Class Initialized
INFO - 2017-03-14 02:20:14 --> Config Class Initialized
INFO - 2017-03-14 02:20:14 --> Hooks Class Initialized
INFO - 2017-03-14 02:20:14 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:20:14 --> UTF-8 Support Enabled
DEBUG - 2017-03-14 02:20:14 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:20:14 --> Utf8 Class Initialized
INFO - 2017-03-14 02:20:14 --> Utf8 Class Initialized
INFO - 2017-03-14 02:20:14 --> URI Class Initialized
INFO - 2017-03-14 02:20:14 --> URI Class Initialized
INFO - 2017-03-14 02:20:14 --> Router Class Initialized
INFO - 2017-03-14 02:20:14 --> Router Class Initialized
INFO - 2017-03-14 02:20:14 --> Output Class Initialized
INFO - 2017-03-14 02:20:14 --> Output Class Initialized
INFO - 2017-03-14 02:20:14 --> Security Class Initialized
INFO - 2017-03-14 02:20:14 --> Security Class Initialized
DEBUG - 2017-03-14 02:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:20:14 --> Input Class Initialized
INFO - 2017-03-14 02:20:14 --> Language Class Initialized
DEBUG - 2017-03-14 02:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:20:14 --> Input Class Initialized
INFO - 2017-03-14 02:20:14 --> Language Class Initialized
INFO - 2017-03-14 02:20:14 --> Loader Class Initialized
INFO - 2017-03-14 02:20:14 --> Loader Class Initialized
INFO - 2017-03-14 02:20:14 --> Database Driver Class Initialized
INFO - 2017-03-14 02:20:14 --> Database Driver Class Initialized
INFO - 2017-03-14 02:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:20:14 --> Controller Class Initialized
INFO - 2017-03-14 02:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:20:14 --> Helper loaded: url_helper
INFO - 2017-03-14 02:20:14 --> Controller Class Initialized
INFO - 2017-03-14 02:20:14 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:20:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-14 02:20:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:20:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:20:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:20:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:20:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:20:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:20:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:20:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:20:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:20:15 --> Final output sent to browser
DEBUG - 2017-03-14 02:20:15 --> Total execution time: 1.2877
INFO - 2017-03-14 02:20:15 --> Final output sent to browser
DEBUG - 2017-03-14 02:20:15 --> Total execution time: 1.2832
INFO - 2017-03-14 02:20:16 --> Config Class Initialized
INFO - 2017-03-14 02:20:16 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:20:16 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:20:16 --> Utf8 Class Initialized
INFO - 2017-03-14 02:20:16 --> URI Class Initialized
INFO - 2017-03-14 02:20:16 --> Router Class Initialized
INFO - 2017-03-14 02:20:16 --> Output Class Initialized
INFO - 2017-03-14 02:20:16 --> Security Class Initialized
DEBUG - 2017-03-14 02:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:20:16 --> Input Class Initialized
INFO - 2017-03-14 02:20:16 --> Language Class Initialized
INFO - 2017-03-14 02:20:16 --> Loader Class Initialized
INFO - 2017-03-14 02:20:16 --> Config Class Initialized
INFO - 2017-03-14 02:20:16 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:20:16 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:20:16 --> Utf8 Class Initialized
INFO - 2017-03-14 02:20:16 --> URI Class Initialized
INFO - 2017-03-14 02:20:16 --> Router Class Initialized
INFO - 2017-03-14 02:20:16 --> Output Class Initialized
INFO - 2017-03-14 02:20:16 --> Security Class Initialized
DEBUG - 2017-03-14 02:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:20:16 --> Input Class Initialized
INFO - 2017-03-14 02:20:16 --> Language Class Initialized
INFO - 2017-03-14 02:20:16 --> Loader Class Initialized
INFO - 2017-03-14 02:20:16 --> Database Driver Class Initialized
INFO - 2017-03-14 02:20:16 --> Database Driver Class Initialized
INFO - 2017-03-14 02:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:20:16 --> Controller Class Initialized
INFO - 2017-03-14 02:20:16 --> Helper loaded: url_helper
INFO - 2017-03-14 02:20:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-03-14 02:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:20:16 --> Controller Class Initialized
INFO - 2017-03-14 02:20:16 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:20:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:20:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:20:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:20:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:20:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:20:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:20:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:20:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:20:16 --> Final output sent to browser
DEBUG - 2017-03-14 02:20:16 --> Total execution time: 0.3602
INFO - 2017-03-14 02:20:16 --> Final output sent to browser
DEBUG - 2017-03-14 02:20:16 --> Total execution time: 0.9026
INFO - 2017-03-14 02:20:36 --> Config Class Initialized
INFO - 2017-03-14 02:20:36 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:20:36 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:20:36 --> Utf8 Class Initialized
INFO - 2017-03-14 02:20:36 --> URI Class Initialized
INFO - 2017-03-14 02:20:36 --> Router Class Initialized
INFO - 2017-03-14 02:20:36 --> Output Class Initialized
INFO - 2017-03-14 02:20:36 --> Security Class Initialized
DEBUG - 2017-03-14 02:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:20:36 --> Input Class Initialized
INFO - 2017-03-14 02:20:36 --> Language Class Initialized
INFO - 2017-03-14 02:20:36 --> Loader Class Initialized
INFO - 2017-03-14 02:20:36 --> Database Driver Class Initialized
INFO - 2017-03-14 02:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:20:36 --> Controller Class Initialized
INFO - 2017-03-14 02:20:36 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:20:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:20:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:20:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:20:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:20:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:20:37 --> Final output sent to browser
DEBUG - 2017-03-14 02:20:37 --> Total execution time: 1.2273
INFO - 2017-03-14 02:20:37 --> Config Class Initialized
INFO - 2017-03-14 02:20:37 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:20:37 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:20:37 --> Utf8 Class Initialized
INFO - 2017-03-14 02:20:37 --> URI Class Initialized
INFO - 2017-03-14 02:20:37 --> Router Class Initialized
INFO - 2017-03-14 02:20:37 --> Output Class Initialized
INFO - 2017-03-14 02:20:37 --> Security Class Initialized
DEBUG - 2017-03-14 02:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:20:37 --> Input Class Initialized
INFO - 2017-03-14 02:20:37 --> Language Class Initialized
INFO - 2017-03-14 02:20:37 --> Loader Class Initialized
INFO - 2017-03-14 02:20:37 --> Database Driver Class Initialized
INFO - 2017-03-14 02:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:20:37 --> Controller Class Initialized
INFO - 2017-03-14 02:20:37 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:20:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:20:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:20:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:20:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:20:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:20:37 --> Final output sent to browser
DEBUG - 2017-03-14 02:20:37 --> Total execution time: 0.0133
INFO - 2017-03-14 02:20:44 --> Config Class Initialized
INFO - 2017-03-14 02:20:44 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:20:44 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:20:44 --> Utf8 Class Initialized
INFO - 2017-03-14 02:20:44 --> URI Class Initialized
INFO - 2017-03-14 02:20:44 --> Router Class Initialized
INFO - 2017-03-14 02:20:44 --> Output Class Initialized
INFO - 2017-03-14 02:20:44 --> Security Class Initialized
DEBUG - 2017-03-14 02:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:20:44 --> Input Class Initialized
INFO - 2017-03-14 02:20:44 --> Language Class Initialized
INFO - 2017-03-14 02:20:44 --> Loader Class Initialized
INFO - 2017-03-14 02:20:44 --> Database Driver Class Initialized
INFO - 2017-03-14 02:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:20:44 --> Controller Class Initialized
INFO - 2017-03-14 02:20:44 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:20:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:20:44 --> Final output sent to browser
DEBUG - 2017-03-14 02:20:44 --> Total execution time: 0.0145
INFO - 2017-03-14 02:20:44 --> Config Class Initialized
INFO - 2017-03-14 02:20:44 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:20:44 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:20:44 --> Utf8 Class Initialized
INFO - 2017-03-14 02:20:44 --> URI Class Initialized
INFO - 2017-03-14 02:20:44 --> Router Class Initialized
INFO - 2017-03-14 02:20:44 --> Output Class Initialized
INFO - 2017-03-14 02:20:44 --> Security Class Initialized
DEBUG - 2017-03-14 02:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:20:44 --> Input Class Initialized
INFO - 2017-03-14 02:20:44 --> Language Class Initialized
INFO - 2017-03-14 02:20:44 --> Loader Class Initialized
INFO - 2017-03-14 02:20:44 --> Database Driver Class Initialized
INFO - 2017-03-14 02:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:20:44 --> Controller Class Initialized
INFO - 2017-03-14 02:20:44 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:20:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:20:44 --> Final output sent to browser
DEBUG - 2017-03-14 02:20:44 --> Total execution time: 0.0135
INFO - 2017-03-14 02:21:02 --> Config Class Initialized
INFO - 2017-03-14 02:21:02 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:21:02 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:21:02 --> Utf8 Class Initialized
INFO - 2017-03-14 02:21:02 --> URI Class Initialized
INFO - 2017-03-14 02:21:02 --> Router Class Initialized
INFO - 2017-03-14 02:21:02 --> Output Class Initialized
INFO - 2017-03-14 02:21:02 --> Security Class Initialized
DEBUG - 2017-03-14 02:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:21:02 --> Input Class Initialized
INFO - 2017-03-14 02:21:02 --> Language Class Initialized
INFO - 2017-03-14 02:21:02 --> Loader Class Initialized
INFO - 2017-03-14 02:21:02 --> Database Driver Class Initialized
INFO - 2017-03-14 02:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:21:02 --> Controller Class Initialized
INFO - 2017-03-14 02:21:02 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:21:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:21:06 --> Config Class Initialized
INFO - 2017-03-14 02:21:06 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:21:06 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:21:06 --> Utf8 Class Initialized
INFO - 2017-03-14 02:21:06 --> URI Class Initialized
INFO - 2017-03-14 02:21:06 --> Router Class Initialized
INFO - 2017-03-14 02:21:06 --> Output Class Initialized
INFO - 2017-03-14 02:21:06 --> Security Class Initialized
DEBUG - 2017-03-14 02:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:21:06 --> Input Class Initialized
INFO - 2017-03-14 02:21:06 --> Language Class Initialized
INFO - 2017-03-14 02:21:06 --> Loader Class Initialized
INFO - 2017-03-14 02:21:06 --> Database Driver Class Initialized
INFO - 2017-03-14 02:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:21:06 --> Controller Class Initialized
INFO - 2017-03-14 02:21:06 --> Helper loaded: date_helper
DEBUG - 2017-03-14 02:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:21:06 --> Helper loaded: url_helper
INFO - 2017-03-14 02:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-14 02:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-14 02:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 02:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:21:06 --> Final output sent to browser
DEBUG - 2017-03-14 02:21:06 --> Total execution time: 0.4029
INFO - 2017-03-14 02:21:07 --> Config Class Initialized
INFO - 2017-03-14 02:21:07 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:21:07 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:21:07 --> Utf8 Class Initialized
INFO - 2017-03-14 02:21:07 --> URI Class Initialized
INFO - 2017-03-14 02:21:07 --> Router Class Initialized
INFO - 2017-03-14 02:21:07 --> Output Class Initialized
INFO - 2017-03-14 02:21:07 --> Security Class Initialized
DEBUG - 2017-03-14 02:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:21:07 --> Input Class Initialized
INFO - 2017-03-14 02:21:07 --> Language Class Initialized
INFO - 2017-03-14 02:21:07 --> Loader Class Initialized
INFO - 2017-03-14 02:21:07 --> Database Driver Class Initialized
INFO - 2017-03-14 02:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:21:07 --> Controller Class Initialized
INFO - 2017-03-14 02:21:07 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:21:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:21:08 --> Config Class Initialized
INFO - 2017-03-14 02:21:08 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:21:08 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:21:08 --> Utf8 Class Initialized
INFO - 2017-03-14 02:21:08 --> URI Class Initialized
INFO - 2017-03-14 02:21:08 --> Router Class Initialized
INFO - 2017-03-14 02:21:08 --> Output Class Initialized
INFO - 2017-03-14 02:21:08 --> Security Class Initialized
DEBUG - 2017-03-14 02:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:21:08 --> Input Class Initialized
INFO - 2017-03-14 02:21:08 --> Language Class Initialized
INFO - 2017-03-14 02:21:08 --> Loader Class Initialized
INFO - 2017-03-14 02:21:08 --> Database Driver Class Initialized
INFO - 2017-03-14 02:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:21:08 --> Controller Class Initialized
INFO - 2017-03-14 02:21:08 --> Helper loaded: date_helper
DEBUG - 2017-03-14 02:21:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:21:08 --> Helper loaded: url_helper
INFO - 2017-03-14 02:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 02:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 02:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 02:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:21:08 --> Final output sent to browser
DEBUG - 2017-03-14 02:21:08 --> Total execution time: 0.0216
INFO - 2017-03-14 02:21:08 --> Config Class Initialized
INFO - 2017-03-14 02:21:08 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:21:08 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:21:08 --> Utf8 Class Initialized
INFO - 2017-03-14 02:21:08 --> URI Class Initialized
INFO - 2017-03-14 02:21:08 --> Router Class Initialized
INFO - 2017-03-14 02:21:08 --> Output Class Initialized
INFO - 2017-03-14 02:21:08 --> Security Class Initialized
DEBUG - 2017-03-14 02:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:21:08 --> Input Class Initialized
INFO - 2017-03-14 02:21:08 --> Language Class Initialized
INFO - 2017-03-14 02:21:08 --> Loader Class Initialized
INFO - 2017-03-14 02:21:08 --> Database Driver Class Initialized
INFO - 2017-03-14 02:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:21:08 --> Controller Class Initialized
INFO - 2017-03-14 02:21:08 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:21:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:21:08 --> Final output sent to browser
DEBUG - 2017-03-14 02:21:08 --> Total execution time: 0.0308
INFO - 2017-03-14 02:21:35 --> Config Class Initialized
INFO - 2017-03-14 02:21:35 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:21:35 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:21:35 --> Utf8 Class Initialized
INFO - 2017-03-14 02:21:35 --> URI Class Initialized
INFO - 2017-03-14 02:21:35 --> Router Class Initialized
INFO - 2017-03-14 02:21:35 --> Output Class Initialized
INFO - 2017-03-14 02:21:35 --> Security Class Initialized
DEBUG - 2017-03-14 02:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:21:35 --> Input Class Initialized
INFO - 2017-03-14 02:21:35 --> Language Class Initialized
INFO - 2017-03-14 02:21:35 --> Loader Class Initialized
INFO - 2017-03-14 02:21:35 --> Database Driver Class Initialized
INFO - 2017-03-14 02:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:21:35 --> Controller Class Initialized
INFO - 2017-03-14 02:21:35 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:21:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:21:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:21:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:21:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:21:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:21:35 --> Final output sent to browser
DEBUG - 2017-03-14 02:21:35 --> Total execution time: 0.0146
INFO - 2017-03-14 02:21:45 --> Config Class Initialized
INFO - 2017-03-14 02:21:45 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:21:45 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:21:45 --> Utf8 Class Initialized
INFO - 2017-03-14 02:21:45 --> URI Class Initialized
DEBUG - 2017-03-14 02:21:45 --> No URI present. Default controller set.
INFO - 2017-03-14 02:21:45 --> Router Class Initialized
INFO - 2017-03-14 02:21:45 --> Output Class Initialized
INFO - 2017-03-14 02:21:45 --> Security Class Initialized
DEBUG - 2017-03-14 02:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:21:45 --> Input Class Initialized
INFO - 2017-03-14 02:21:45 --> Language Class Initialized
INFO - 2017-03-14 02:21:45 --> Loader Class Initialized
INFO - 2017-03-14 02:21:45 --> Database Driver Class Initialized
INFO - 2017-03-14 02:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:21:45 --> Controller Class Initialized
INFO - 2017-03-14 02:21:45 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:21:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:21:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:21:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:21:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:21:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:21:45 --> Final output sent to browser
DEBUG - 2017-03-14 02:21:45 --> Total execution time: 0.0139
INFO - 2017-03-14 02:21:46 --> Config Class Initialized
INFO - 2017-03-14 02:21:46 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:21:46 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:21:46 --> Utf8 Class Initialized
INFO - 2017-03-14 02:21:46 --> URI Class Initialized
INFO - 2017-03-14 02:21:46 --> Router Class Initialized
INFO - 2017-03-14 02:21:46 --> Output Class Initialized
INFO - 2017-03-14 02:21:46 --> Security Class Initialized
DEBUG - 2017-03-14 02:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:21:46 --> Input Class Initialized
INFO - 2017-03-14 02:21:46 --> Language Class Initialized
INFO - 2017-03-14 02:21:46 --> Loader Class Initialized
INFO - 2017-03-14 02:21:46 --> Database Driver Class Initialized
INFO - 2017-03-14 02:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:21:46 --> Controller Class Initialized
INFO - 2017-03-14 02:21:46 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:21:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:21:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:21:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:21:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:21:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:21:46 --> Final output sent to browser
DEBUG - 2017-03-14 02:21:46 --> Total execution time: 0.0694
INFO - 2017-03-14 02:22:10 --> Config Class Initialized
INFO - 2017-03-14 02:22:10 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:22:10 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:22:10 --> Utf8 Class Initialized
INFO - 2017-03-14 02:22:10 --> URI Class Initialized
INFO - 2017-03-14 02:22:10 --> Router Class Initialized
INFO - 2017-03-14 02:22:10 --> Output Class Initialized
INFO - 2017-03-14 02:22:10 --> Security Class Initialized
DEBUG - 2017-03-14 02:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:22:10 --> Input Class Initialized
INFO - 2017-03-14 02:22:10 --> Language Class Initialized
INFO - 2017-03-14 02:22:10 --> Loader Class Initialized
INFO - 2017-03-14 02:22:11 --> Database Driver Class Initialized
INFO - 2017-03-14 02:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:22:11 --> Controller Class Initialized
INFO - 2017-03-14 02:22:11 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:22:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:22:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:22:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:22:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:22:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:22:11 --> Final output sent to browser
DEBUG - 2017-03-14 02:22:11 --> Total execution time: 1.2704
INFO - 2017-03-14 02:22:12 --> Config Class Initialized
INFO - 2017-03-14 02:22:12 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:22:12 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:22:12 --> Utf8 Class Initialized
INFO - 2017-03-14 02:22:12 --> URI Class Initialized
INFO - 2017-03-14 02:22:12 --> Router Class Initialized
INFO - 2017-03-14 02:22:12 --> Output Class Initialized
INFO - 2017-03-14 02:22:12 --> Security Class Initialized
DEBUG - 2017-03-14 02:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:22:12 --> Input Class Initialized
INFO - 2017-03-14 02:22:12 --> Language Class Initialized
INFO - 2017-03-14 02:22:12 --> Loader Class Initialized
INFO - 2017-03-14 02:22:13 --> Database Driver Class Initialized
INFO - 2017-03-14 02:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:22:13 --> Controller Class Initialized
INFO - 2017-03-14 02:22:13 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:22:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:22:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:22:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:22:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:22:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:22:13 --> Final output sent to browser
DEBUG - 2017-03-14 02:22:13 --> Total execution time: 1.2460
INFO - 2017-03-14 02:22:25 --> Config Class Initialized
INFO - 2017-03-14 02:22:25 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:22:25 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:22:25 --> Utf8 Class Initialized
INFO - 2017-03-14 02:22:25 --> URI Class Initialized
INFO - 2017-03-14 02:22:25 --> Router Class Initialized
INFO - 2017-03-14 02:22:25 --> Output Class Initialized
INFO - 2017-03-14 02:22:25 --> Security Class Initialized
DEBUG - 2017-03-14 02:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:22:25 --> Input Class Initialized
INFO - 2017-03-14 02:22:25 --> Language Class Initialized
INFO - 2017-03-14 02:22:25 --> Loader Class Initialized
INFO - 2017-03-14 02:22:25 --> Database Driver Class Initialized
INFO - 2017-03-14 02:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:22:26 --> Controller Class Initialized
INFO - 2017-03-14 02:22:26 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:22:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:22:27 --> Config Class Initialized
INFO - 2017-03-14 02:22:27 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:22:27 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:22:27 --> Utf8 Class Initialized
INFO - 2017-03-14 02:22:27 --> URI Class Initialized
INFO - 2017-03-14 02:22:27 --> Router Class Initialized
INFO - 2017-03-14 02:22:27 --> Output Class Initialized
INFO - 2017-03-14 02:22:27 --> Security Class Initialized
DEBUG - 2017-03-14 02:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:22:27 --> Input Class Initialized
INFO - 2017-03-14 02:22:27 --> Language Class Initialized
INFO - 2017-03-14 02:22:27 --> Loader Class Initialized
INFO - 2017-03-14 02:22:27 --> Database Driver Class Initialized
INFO - 2017-03-14 02:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:22:27 --> Controller Class Initialized
INFO - 2017-03-14 02:22:27 --> Helper loaded: date_helper
DEBUG - 2017-03-14 02:22:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:22:27 --> Helper loaded: url_helper
INFO - 2017-03-14 02:22:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:22:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-14 02:22:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-14 02:22:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 02:22:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:22:28 --> Final output sent to browser
DEBUG - 2017-03-14 02:22:28 --> Total execution time: 1.0978
INFO - 2017-03-14 02:22:29 --> Config Class Initialized
INFO - 2017-03-14 02:22:29 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:22:30 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:22:30 --> Utf8 Class Initialized
INFO - 2017-03-14 02:22:30 --> URI Class Initialized
INFO - 2017-03-14 02:22:30 --> Router Class Initialized
INFO - 2017-03-14 02:22:30 --> Output Class Initialized
INFO - 2017-03-14 02:22:30 --> Security Class Initialized
DEBUG - 2017-03-14 02:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:22:30 --> Input Class Initialized
INFO - 2017-03-14 02:22:30 --> Language Class Initialized
INFO - 2017-03-14 02:22:30 --> Loader Class Initialized
INFO - 2017-03-14 02:22:30 --> Database Driver Class Initialized
INFO - 2017-03-14 02:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:22:30 --> Controller Class Initialized
INFO - 2017-03-14 02:22:30 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:22:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:22:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:22:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:22:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:22:30 --> Final output sent to browser
DEBUG - 2017-03-14 02:22:30 --> Total execution time: 0.6304
INFO - 2017-03-14 02:22:31 --> Config Class Initialized
INFO - 2017-03-14 02:22:31 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:22:31 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:22:31 --> Utf8 Class Initialized
INFO - 2017-03-14 02:22:31 --> URI Class Initialized
INFO - 2017-03-14 02:22:31 --> Router Class Initialized
INFO - 2017-03-14 02:22:31 --> Output Class Initialized
INFO - 2017-03-14 02:22:31 --> Security Class Initialized
DEBUG - 2017-03-14 02:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:22:31 --> Input Class Initialized
INFO - 2017-03-14 02:22:31 --> Language Class Initialized
INFO - 2017-03-14 02:22:31 --> Loader Class Initialized
INFO - 2017-03-14 02:22:31 --> Database Driver Class Initialized
INFO - 2017-03-14 02:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:22:31 --> Controller Class Initialized
INFO - 2017-03-14 02:22:31 --> Helper loaded: date_helper
DEBUG - 2017-03-14 02:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:22:31 --> Helper loaded: url_helper
INFO - 2017-03-14 02:22:31 --> Helper loaded: download_helper
INFO - 2017-03-14 02:22:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:22:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-14 02:22:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-14 02:22:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-14 02:22:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:22:32 --> Final output sent to browser
DEBUG - 2017-03-14 02:22:32 --> Total execution time: 0.7312
INFO - 2017-03-14 02:22:33 --> Config Class Initialized
INFO - 2017-03-14 02:22:33 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:22:33 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:22:33 --> Utf8 Class Initialized
INFO - 2017-03-14 02:22:33 --> URI Class Initialized
INFO - 2017-03-14 02:22:33 --> Router Class Initialized
INFO - 2017-03-14 02:22:33 --> Output Class Initialized
INFO - 2017-03-14 02:22:33 --> Security Class Initialized
DEBUG - 2017-03-14 02:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:22:33 --> Input Class Initialized
INFO - 2017-03-14 02:22:33 --> Language Class Initialized
INFO - 2017-03-14 02:22:33 --> Loader Class Initialized
INFO - 2017-03-14 02:22:33 --> Database Driver Class Initialized
INFO - 2017-03-14 02:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:22:33 --> Controller Class Initialized
INFO - 2017-03-14 02:22:33 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:22:33 --> Final output sent to browser
DEBUG - 2017-03-14 02:22:33 --> Total execution time: 0.0141
INFO - 2017-03-14 02:22:33 --> Config Class Initialized
INFO - 2017-03-14 02:22:33 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:22:33 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:22:33 --> Utf8 Class Initialized
INFO - 2017-03-14 02:22:33 --> URI Class Initialized
INFO - 2017-03-14 02:22:33 --> Router Class Initialized
INFO - 2017-03-14 02:22:33 --> Output Class Initialized
INFO - 2017-03-14 02:22:33 --> Security Class Initialized
DEBUG - 2017-03-14 02:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:22:33 --> Input Class Initialized
INFO - 2017-03-14 02:22:33 --> Language Class Initialized
INFO - 2017-03-14 02:22:33 --> Loader Class Initialized
INFO - 2017-03-14 02:22:33 --> Database Driver Class Initialized
INFO - 2017-03-14 02:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:22:33 --> Controller Class Initialized
INFO - 2017-03-14 02:22:33 --> Helper loaded: date_helper
DEBUG - 2017-03-14 02:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:22:33 --> Helper loaded: url_helper
INFO - 2017-03-14 02:22:33 --> Helper loaded: download_helper
INFO - 2017-03-14 02:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-14 02:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-14 02:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-14 02:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:22:33 --> Final output sent to browser
DEBUG - 2017-03-14 02:22:33 --> Total execution time: 0.0378
INFO - 2017-03-14 02:22:38 --> Config Class Initialized
INFO - 2017-03-14 02:22:38 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:22:38 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:22:38 --> Utf8 Class Initialized
INFO - 2017-03-14 02:22:38 --> URI Class Initialized
INFO - 2017-03-14 02:22:38 --> Router Class Initialized
INFO - 2017-03-14 02:22:38 --> Output Class Initialized
INFO - 2017-03-14 02:22:38 --> Security Class Initialized
DEBUG - 2017-03-14 02:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:22:38 --> Input Class Initialized
INFO - 2017-03-14 02:22:38 --> Language Class Initialized
INFO - 2017-03-14 02:22:38 --> Loader Class Initialized
INFO - 2017-03-14 02:22:38 --> Database Driver Class Initialized
INFO - 2017-03-14 02:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:22:38 --> Controller Class Initialized
INFO - 2017-03-14 02:22:38 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:22:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:22:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:22:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:22:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:22:38 --> Final output sent to browser
DEBUG - 2017-03-14 02:22:38 --> Total execution time: 0.0138
INFO - 2017-03-14 02:22:53 --> Config Class Initialized
INFO - 2017-03-14 02:22:53 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:22:53 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:22:53 --> Utf8 Class Initialized
INFO - 2017-03-14 02:22:53 --> URI Class Initialized
INFO - 2017-03-14 02:22:53 --> Router Class Initialized
INFO - 2017-03-14 02:22:53 --> Output Class Initialized
INFO - 2017-03-14 02:22:53 --> Security Class Initialized
DEBUG - 2017-03-14 02:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:22:53 --> Input Class Initialized
INFO - 2017-03-14 02:22:53 --> Language Class Initialized
INFO - 2017-03-14 02:22:53 --> Loader Class Initialized
INFO - 2017-03-14 02:22:53 --> Database Driver Class Initialized
INFO - 2017-03-14 02:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:22:53 --> Controller Class Initialized
INFO - 2017-03-14 02:22:53 --> Helper loaded: date_helper
INFO - 2017-03-14 02:22:53 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:22:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:22:53 --> Helper loaded: form_helper
INFO - 2017-03-14 02:22:53 --> Form Validation Class Initialized
INFO - 2017-03-14 02:22:53 --> Final output sent to browser
DEBUG - 2017-03-14 02:22:53 --> Total execution time: 0.2048
INFO - 2017-03-14 02:23:12 --> Config Class Initialized
INFO - 2017-03-14 02:23:12 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:23:12 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:23:12 --> Utf8 Class Initialized
INFO - 2017-03-14 02:23:12 --> URI Class Initialized
INFO - 2017-03-14 02:23:12 --> Router Class Initialized
INFO - 2017-03-14 02:23:12 --> Output Class Initialized
INFO - 2017-03-14 02:23:12 --> Security Class Initialized
DEBUG - 2017-03-14 02:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:23:12 --> Input Class Initialized
INFO - 2017-03-14 02:23:12 --> Language Class Initialized
INFO - 2017-03-14 02:23:12 --> Loader Class Initialized
INFO - 2017-03-14 02:23:12 --> Database Driver Class Initialized
INFO - 2017-03-14 02:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:23:12 --> Controller Class Initialized
INFO - 2017-03-14 02:23:12 --> Helper loaded: date_helper
INFO - 2017-03-14 02:23:12 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:23:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:23:12 --> Helper loaded: form_helper
INFO - 2017-03-14 02:23:12 --> Form Validation Class Initialized
INFO - 2017-03-14 02:23:12 --> Final output sent to browser
DEBUG - 2017-03-14 02:23:12 --> Total execution time: 0.0151
INFO - 2017-03-14 02:23:18 --> Config Class Initialized
INFO - 2017-03-14 02:23:18 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:23:18 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:23:18 --> Utf8 Class Initialized
INFO - 2017-03-14 02:23:18 --> URI Class Initialized
INFO - 2017-03-14 02:23:18 --> Router Class Initialized
INFO - 2017-03-14 02:23:18 --> Output Class Initialized
INFO - 2017-03-14 02:23:18 --> Security Class Initialized
DEBUG - 2017-03-14 02:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:23:18 --> Input Class Initialized
INFO - 2017-03-14 02:23:18 --> Language Class Initialized
INFO - 2017-03-14 02:23:18 --> Loader Class Initialized
INFO - 2017-03-14 02:23:18 --> Database Driver Class Initialized
INFO - 2017-03-14 02:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:23:18 --> Controller Class Initialized
INFO - 2017-03-14 02:23:18 --> Upload Class Initialized
INFO - 2017-03-14 02:23:18 --> Helper loaded: date_helper
DEBUG - 2017-03-14 02:23:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:23:18 --> Helper loaded: url_helper
INFO - 2017-03-14 02:23:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:23:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-14 02:23:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-03-14 02:23:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-03-14 02:23:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-14 02:23:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:23:19 --> Final output sent to browser
DEBUG - 2017-03-14 02:23:19 --> Total execution time: 0.9683
INFO - 2017-03-14 02:23:19 --> Config Class Initialized
INFO - 2017-03-14 02:23:19 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:23:19 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:23:19 --> Utf8 Class Initialized
INFO - 2017-03-14 02:23:19 --> URI Class Initialized
INFO - 2017-03-14 02:23:19 --> Router Class Initialized
INFO - 2017-03-14 02:23:19 --> Output Class Initialized
INFO - 2017-03-14 02:23:19 --> Security Class Initialized
DEBUG - 2017-03-14 02:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:23:19 --> Input Class Initialized
INFO - 2017-03-14 02:23:19 --> Language Class Initialized
INFO - 2017-03-14 02:23:19 --> Loader Class Initialized
INFO - 2017-03-14 02:23:19 --> Database Driver Class Initialized
INFO - 2017-03-14 02:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:23:19 --> Controller Class Initialized
INFO - 2017-03-14 02:23:19 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:23:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:23:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:23:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:23:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:23:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:23:19 --> Final output sent to browser
DEBUG - 2017-03-14 02:23:19 --> Total execution time: 0.0138
INFO - 2017-03-14 02:23:24 --> Config Class Initialized
INFO - 2017-03-14 02:23:24 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:23:24 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:23:24 --> Utf8 Class Initialized
INFO - 2017-03-14 02:23:24 --> URI Class Initialized
INFO - 2017-03-14 02:23:24 --> Router Class Initialized
INFO - 2017-03-14 02:23:24 --> Output Class Initialized
INFO - 2017-03-14 02:23:24 --> Security Class Initialized
DEBUG - 2017-03-14 02:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:23:24 --> Input Class Initialized
INFO - 2017-03-14 02:23:24 --> Language Class Initialized
INFO - 2017-03-14 02:23:24 --> Loader Class Initialized
INFO - 2017-03-14 02:23:24 --> Database Driver Class Initialized
INFO - 2017-03-14 02:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:23:24 --> Controller Class Initialized
INFO - 2017-03-14 02:23:24 --> Upload Class Initialized
INFO - 2017-03-14 02:23:24 --> Helper loaded: date_helper
DEBUG - 2017-03-14 02:23:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:23:24 --> Helper loaded: url_helper
INFO - 2017-03-14 02:23:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:23:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-14 02:23:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-03-14 02:23:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-03-14 02:23:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-14 02:23:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:23:24 --> Final output sent to browser
DEBUG - 2017-03-14 02:23:24 --> Total execution time: 0.0162
INFO - 2017-03-14 02:23:25 --> Config Class Initialized
INFO - 2017-03-14 02:23:25 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:23:25 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:23:25 --> Utf8 Class Initialized
INFO - 2017-03-14 02:23:25 --> URI Class Initialized
INFO - 2017-03-14 02:23:25 --> Router Class Initialized
INFO - 2017-03-14 02:23:25 --> Output Class Initialized
INFO - 2017-03-14 02:23:25 --> Security Class Initialized
DEBUG - 2017-03-14 02:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:23:25 --> Input Class Initialized
INFO - 2017-03-14 02:23:25 --> Language Class Initialized
INFO - 2017-03-14 02:23:25 --> Loader Class Initialized
INFO - 2017-03-14 02:23:25 --> Database Driver Class Initialized
INFO - 2017-03-14 02:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:23:25 --> Controller Class Initialized
INFO - 2017-03-14 02:23:25 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:23:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:23:25 --> Final output sent to browser
DEBUG - 2017-03-14 02:23:25 --> Total execution time: 0.0136
INFO - 2017-03-14 02:23:53 --> Config Class Initialized
INFO - 2017-03-14 02:23:53 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:23:53 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:23:53 --> Utf8 Class Initialized
INFO - 2017-03-14 02:23:53 --> URI Class Initialized
INFO - 2017-03-14 02:23:53 --> Router Class Initialized
INFO - 2017-03-14 02:23:53 --> Output Class Initialized
INFO - 2017-03-14 02:23:53 --> Security Class Initialized
DEBUG - 2017-03-14 02:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:23:53 --> Input Class Initialized
INFO - 2017-03-14 02:23:53 --> Language Class Initialized
INFO - 2017-03-14 02:23:53 --> Loader Class Initialized
INFO - 2017-03-14 02:23:54 --> Database Driver Class Initialized
INFO - 2017-03-14 02:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:23:54 --> Controller Class Initialized
INFO - 2017-03-14 02:23:54 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:23:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:23:54 --> Config Class Initialized
INFO - 2017-03-14 02:23:54 --> Config Class Initialized
INFO - 2017-03-14 02:23:54 --> Hooks Class Initialized
INFO - 2017-03-14 02:23:54 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:23:54 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:23:54 --> Utf8 Class Initialized
DEBUG - 2017-03-14 02:23:54 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:23:54 --> Utf8 Class Initialized
INFO - 2017-03-14 02:23:54 --> URI Class Initialized
INFO - 2017-03-14 02:23:54 --> URI Class Initialized
DEBUG - 2017-03-14 02:23:54 --> No URI present. Default controller set.
INFO - 2017-03-14 02:23:54 --> Router Class Initialized
INFO - 2017-03-14 02:23:54 --> Router Class Initialized
INFO - 2017-03-14 02:23:54 --> Output Class Initialized
INFO - 2017-03-14 02:23:54 --> Output Class Initialized
INFO - 2017-03-14 02:23:54 --> Security Class Initialized
INFO - 2017-03-14 02:23:54 --> Security Class Initialized
DEBUG - 2017-03-14 02:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:23:54 --> Input Class Initialized
DEBUG - 2017-03-14 02:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:23:54 --> Input Class Initialized
INFO - 2017-03-14 02:23:54 --> Language Class Initialized
INFO - 2017-03-14 02:23:54 --> Language Class Initialized
INFO - 2017-03-14 02:23:54 --> Loader Class Initialized
INFO - 2017-03-14 02:23:54 --> Loader Class Initialized
INFO - 2017-03-14 02:23:54 --> Database Driver Class Initialized
INFO - 2017-03-14 02:23:54 --> Database Driver Class Initialized
INFO - 2017-03-14 02:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:23:54 --> Controller Class Initialized
INFO - 2017-03-14 02:23:54 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:23:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:23:54 --> Controller Class Initialized
INFO - 2017-03-14 02:23:54 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:23:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:23:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:23:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:23:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:23:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:23:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:23:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:23:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:23:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:23:54 --> Final output sent to browser
DEBUG - 2017-03-14 02:23:54 --> Total execution time: 0.1794
INFO - 2017-03-14 02:23:54 --> Final output sent to browser
DEBUG - 2017-03-14 02:23:54 --> Total execution time: 0.1796
INFO - 2017-03-14 02:23:55 --> Config Class Initialized
INFO - 2017-03-14 02:23:55 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:23:55 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:23:55 --> Utf8 Class Initialized
INFO - 2017-03-14 02:23:55 --> URI Class Initialized
INFO - 2017-03-14 02:23:55 --> Router Class Initialized
INFO - 2017-03-14 02:23:55 --> Output Class Initialized
INFO - 2017-03-14 02:23:55 --> Security Class Initialized
DEBUG - 2017-03-14 02:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:23:55 --> Input Class Initialized
INFO - 2017-03-14 02:23:55 --> Language Class Initialized
INFO - 2017-03-14 02:23:55 --> Loader Class Initialized
INFO - 2017-03-14 02:23:55 --> Database Driver Class Initialized
INFO - 2017-03-14 02:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:23:55 --> Controller Class Initialized
INFO - 2017-03-14 02:23:55 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:23:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:23:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:23:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:23:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:23:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:23:55 --> Final output sent to browser
DEBUG - 2017-03-14 02:23:55 --> Total execution time: 0.0146
INFO - 2017-03-14 02:24:23 --> Config Class Initialized
INFO - 2017-03-14 02:24:23 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:24:23 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:24:23 --> Utf8 Class Initialized
INFO - 2017-03-14 02:24:23 --> URI Class Initialized
INFO - 2017-03-14 02:24:23 --> Router Class Initialized
INFO - 2017-03-14 02:24:23 --> Output Class Initialized
INFO - 2017-03-14 02:24:23 --> Security Class Initialized
DEBUG - 2017-03-14 02:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:24:23 --> Input Class Initialized
INFO - 2017-03-14 02:24:23 --> Language Class Initialized
INFO - 2017-03-14 02:24:23 --> Loader Class Initialized
INFO - 2017-03-14 02:24:23 --> Database Driver Class Initialized
INFO - 2017-03-14 02:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:24:24 --> Controller Class Initialized
INFO - 2017-03-14 02:24:24 --> Helper loaded: date_helper
DEBUG - 2017-03-14 02:24:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:24:24 --> Helper loaded: url_helper
INFO - 2017-03-14 02:24:24 --> Helper loaded: download_helper
INFO - 2017-03-14 02:24:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:24:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-14 02:24:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-14 02:24:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-14 02:24:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:24:24 --> Final output sent to browser
DEBUG - 2017-03-14 02:24:24 --> Total execution time: 1.1492
INFO - 2017-03-14 02:24:25 --> Config Class Initialized
INFO - 2017-03-14 02:24:25 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:24:25 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:24:25 --> Utf8 Class Initialized
INFO - 2017-03-14 02:24:25 --> URI Class Initialized
INFO - 2017-03-14 02:24:25 --> Router Class Initialized
INFO - 2017-03-14 02:24:25 --> Output Class Initialized
INFO - 2017-03-14 02:24:25 --> Security Class Initialized
DEBUG - 2017-03-14 02:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:24:25 --> Input Class Initialized
INFO - 2017-03-14 02:24:25 --> Language Class Initialized
INFO - 2017-03-14 02:24:25 --> Loader Class Initialized
INFO - 2017-03-14 02:24:25 --> Database Driver Class Initialized
INFO - 2017-03-14 02:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:24:25 --> Controller Class Initialized
INFO - 2017-03-14 02:24:25 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:24:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:24:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:24:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:24:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:24:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:24:25 --> Final output sent to browser
DEBUG - 2017-03-14 02:24:25 --> Total execution time: 0.2546
INFO - 2017-03-14 02:25:36 --> Config Class Initialized
INFO - 2017-03-14 02:25:36 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:25:36 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:25:36 --> Utf8 Class Initialized
INFO - 2017-03-14 02:25:36 --> URI Class Initialized
INFO - 2017-03-14 02:25:36 --> Router Class Initialized
INFO - 2017-03-14 02:25:36 --> Output Class Initialized
INFO - 2017-03-14 02:25:36 --> Security Class Initialized
DEBUG - 2017-03-14 02:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:25:36 --> Input Class Initialized
INFO - 2017-03-14 02:25:36 --> Language Class Initialized
INFO - 2017-03-14 02:25:36 --> Loader Class Initialized
INFO - 2017-03-14 02:25:36 --> Database Driver Class Initialized
INFO - 2017-03-14 02:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:25:36 --> Controller Class Initialized
INFO - 2017-03-14 02:25:36 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:25:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:25:36 --> Config Class Initialized
INFO - 2017-03-14 02:25:36 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:25:36 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:25:36 --> Utf8 Class Initialized
INFO - 2017-03-14 02:25:36 --> URI Class Initialized
INFO - 2017-03-14 02:25:36 --> Router Class Initialized
INFO - 2017-03-14 02:25:36 --> Output Class Initialized
INFO - 2017-03-14 02:25:36 --> Security Class Initialized
DEBUG - 2017-03-14 02:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:25:36 --> Input Class Initialized
INFO - 2017-03-14 02:25:36 --> Language Class Initialized
INFO - 2017-03-14 02:25:36 --> Loader Class Initialized
INFO - 2017-03-14 02:25:36 --> Database Driver Class Initialized
INFO - 2017-03-14 02:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:25:36 --> Controller Class Initialized
INFO - 2017-03-14 02:25:36 --> Helper loaded: date_helper
DEBUG - 2017-03-14 02:25:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:25:36 --> Helper loaded: url_helper
INFO - 2017-03-14 02:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-14 02:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-14 02:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 02:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:25:36 --> Final output sent to browser
DEBUG - 2017-03-14 02:25:36 --> Total execution time: 0.0436
INFO - 2017-03-14 02:25:37 --> Config Class Initialized
INFO - 2017-03-14 02:25:37 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:25:37 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:25:37 --> Utf8 Class Initialized
INFO - 2017-03-14 02:25:37 --> URI Class Initialized
INFO - 2017-03-14 02:25:37 --> Router Class Initialized
INFO - 2017-03-14 02:25:37 --> Output Class Initialized
INFO - 2017-03-14 02:25:37 --> Security Class Initialized
DEBUG - 2017-03-14 02:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:25:37 --> Input Class Initialized
INFO - 2017-03-14 02:25:37 --> Language Class Initialized
INFO - 2017-03-14 02:25:37 --> Loader Class Initialized
INFO - 2017-03-14 02:25:37 --> Database Driver Class Initialized
INFO - 2017-03-14 02:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:25:37 --> Controller Class Initialized
INFO - 2017-03-14 02:25:37 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:25:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:25:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:25:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:25:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:25:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:25:37 --> Final output sent to browser
DEBUG - 2017-03-14 02:25:37 --> Total execution time: 0.0145
INFO - 2017-03-14 02:25:39 --> Config Class Initialized
INFO - 2017-03-14 02:25:39 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:25:39 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:25:39 --> Utf8 Class Initialized
INFO - 2017-03-14 02:25:39 --> URI Class Initialized
INFO - 2017-03-14 02:25:39 --> Router Class Initialized
INFO - 2017-03-14 02:25:39 --> Output Class Initialized
INFO - 2017-03-14 02:25:39 --> Security Class Initialized
DEBUG - 2017-03-14 02:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:25:39 --> Input Class Initialized
INFO - 2017-03-14 02:25:39 --> Language Class Initialized
INFO - 2017-03-14 02:25:39 --> Loader Class Initialized
INFO - 2017-03-14 02:25:39 --> Database Driver Class Initialized
INFO - 2017-03-14 02:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:25:39 --> Controller Class Initialized
INFO - 2017-03-14 02:25:39 --> Helper loaded: date_helper
DEBUG - 2017-03-14 02:25:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:25:39 --> Helper loaded: url_helper
INFO - 2017-03-14 02:25:39 --> Helper loaded: download_helper
INFO - 2017-03-14 02:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-14 02:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-14 02:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-14 02:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:25:39 --> Final output sent to browser
DEBUG - 2017-03-14 02:25:39 --> Total execution time: 0.0618
INFO - 2017-03-14 02:25:41 --> Config Class Initialized
INFO - 2017-03-14 02:25:41 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:25:41 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:25:41 --> Utf8 Class Initialized
INFO - 2017-03-14 02:25:41 --> URI Class Initialized
INFO - 2017-03-14 02:25:41 --> Router Class Initialized
INFO - 2017-03-14 02:25:41 --> Output Class Initialized
INFO - 2017-03-14 02:25:41 --> Security Class Initialized
DEBUG - 2017-03-14 02:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:25:41 --> Input Class Initialized
INFO - 2017-03-14 02:25:41 --> Language Class Initialized
INFO - 2017-03-14 02:25:41 --> Loader Class Initialized
INFO - 2017-03-14 02:25:41 --> Database Driver Class Initialized
INFO - 2017-03-14 02:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:25:41 --> Controller Class Initialized
INFO - 2017-03-14 02:25:41 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:25:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:25:41 --> Final output sent to browser
DEBUG - 2017-03-14 02:25:41 --> Total execution time: 0.0135
INFO - 2017-03-14 02:25:51 --> Config Class Initialized
INFO - 2017-03-14 02:25:51 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:25:51 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:25:51 --> Utf8 Class Initialized
INFO - 2017-03-14 02:25:51 --> URI Class Initialized
INFO - 2017-03-14 02:25:51 --> Router Class Initialized
INFO - 2017-03-14 02:25:51 --> Output Class Initialized
INFO - 2017-03-14 02:25:51 --> Security Class Initialized
DEBUG - 2017-03-14 02:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:25:51 --> Input Class Initialized
INFO - 2017-03-14 02:25:51 --> Language Class Initialized
INFO - 2017-03-14 02:25:51 --> Loader Class Initialized
INFO - 2017-03-14 02:25:52 --> Database Driver Class Initialized
INFO - 2017-03-14 02:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:25:52 --> Controller Class Initialized
INFO - 2017-03-14 02:25:52 --> Upload Class Initialized
INFO - 2017-03-14 02:25:52 --> Helper loaded: date_helper
DEBUG - 2017-03-14 02:25:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:25:52 --> Helper loaded: url_helper
INFO - 2017-03-14 02:25:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:25:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-14 02:25:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-03-14 02:25:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-03-14 02:25:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-14 02:25:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:25:52 --> Final output sent to browser
DEBUG - 2017-03-14 02:25:52 --> Total execution time: 0.6692
INFO - 2017-03-14 02:25:52 --> Config Class Initialized
INFO - 2017-03-14 02:25:52 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:25:52 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:25:52 --> Utf8 Class Initialized
INFO - 2017-03-14 02:25:52 --> URI Class Initialized
INFO - 2017-03-14 02:25:52 --> Router Class Initialized
INFO - 2017-03-14 02:25:52 --> Output Class Initialized
INFO - 2017-03-14 02:25:52 --> Security Class Initialized
DEBUG - 2017-03-14 02:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:25:52 --> Input Class Initialized
INFO - 2017-03-14 02:25:52 --> Language Class Initialized
INFO - 2017-03-14 02:25:52 --> Loader Class Initialized
INFO - 2017-03-14 02:25:52 --> Database Driver Class Initialized
INFO - 2017-03-14 02:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:25:52 --> Controller Class Initialized
INFO - 2017-03-14 02:25:52 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:25:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:25:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:25:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:25:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:25:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:25:52 --> Final output sent to browser
DEBUG - 2017-03-14 02:25:52 --> Total execution time: 0.0354
INFO - 2017-03-14 02:25:56 --> Config Class Initialized
INFO - 2017-03-14 02:25:56 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:25:56 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:25:56 --> Utf8 Class Initialized
INFO - 2017-03-14 02:25:56 --> URI Class Initialized
INFO - 2017-03-14 02:25:56 --> Router Class Initialized
INFO - 2017-03-14 02:25:56 --> Output Class Initialized
INFO - 2017-03-14 02:25:56 --> Security Class Initialized
DEBUG - 2017-03-14 02:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:25:56 --> Input Class Initialized
INFO - 2017-03-14 02:25:56 --> Language Class Initialized
INFO - 2017-03-14 02:25:56 --> Loader Class Initialized
INFO - 2017-03-14 02:25:56 --> Database Driver Class Initialized
INFO - 2017-03-14 02:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:25:56 --> Controller Class Initialized
INFO - 2017-03-14 02:25:56 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:25:56 --> Config Class Initialized
INFO - 2017-03-14 02:25:56 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:25:56 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:25:56 --> Utf8 Class Initialized
INFO - 2017-03-14 02:25:56 --> URI Class Initialized
DEBUG - 2017-03-14 02:25:56 --> No URI present. Default controller set.
INFO - 2017-03-14 02:25:56 --> Router Class Initialized
INFO - 2017-03-14 02:25:56 --> Config Class Initialized
INFO - 2017-03-14 02:25:56 --> Hooks Class Initialized
INFO - 2017-03-14 02:25:56 --> Output Class Initialized
INFO - 2017-03-14 02:25:56 --> Security Class Initialized
DEBUG - 2017-03-14 02:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:25:56 --> Input Class Initialized
INFO - 2017-03-14 02:25:56 --> Language Class Initialized
INFO - 2017-03-14 02:25:56 --> Loader Class Initialized
DEBUG - 2017-03-14 02:25:56 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:25:56 --> Utf8 Class Initialized
INFO - 2017-03-14 02:25:56 --> URI Class Initialized
INFO - 2017-03-14 02:25:56 --> Router Class Initialized
INFO - 2017-03-14 02:25:56 --> Database Driver Class Initialized
INFO - 2017-03-14 02:25:56 --> Output Class Initialized
INFO - 2017-03-14 02:25:56 --> Security Class Initialized
DEBUG - 2017-03-14 02:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:25:56 --> Input Class Initialized
INFO - 2017-03-14 02:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:25:56 --> Controller Class Initialized
INFO - 2017-03-14 02:25:56 --> Language Class Initialized
INFO - 2017-03-14 02:25:56 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:25:56 --> Loader Class Initialized
INFO - 2017-03-14 02:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:25:56 --> Database Driver Class Initialized
INFO - 2017-03-14 02:25:56 --> Final output sent to browser
DEBUG - 2017-03-14 02:25:56 --> Total execution time: 0.0757
INFO - 2017-03-14 02:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:25:56 --> Controller Class Initialized
INFO - 2017-03-14 02:25:56 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:25:56 --> Final output sent to browser
DEBUG - 2017-03-14 02:25:56 --> Total execution time: 0.0848
INFO - 2017-03-14 02:25:57 --> Config Class Initialized
INFO - 2017-03-14 02:25:57 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:25:57 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:25:57 --> Utf8 Class Initialized
INFO - 2017-03-14 02:25:57 --> URI Class Initialized
INFO - 2017-03-14 02:25:57 --> Router Class Initialized
INFO - 2017-03-14 02:25:57 --> Output Class Initialized
INFO - 2017-03-14 02:25:57 --> Security Class Initialized
DEBUG - 2017-03-14 02:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:25:57 --> Input Class Initialized
INFO - 2017-03-14 02:25:57 --> Language Class Initialized
INFO - 2017-03-14 02:25:57 --> Loader Class Initialized
INFO - 2017-03-14 02:25:57 --> Database Driver Class Initialized
INFO - 2017-03-14 02:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:25:57 --> Controller Class Initialized
INFO - 2017-03-14 02:25:57 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:25:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:25:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:25:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:25:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:25:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:25:57 --> Final output sent to browser
DEBUG - 2017-03-14 02:25:57 --> Total execution time: 0.0135
INFO - 2017-03-14 02:25:59 --> Config Class Initialized
INFO - 2017-03-14 02:25:59 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:25:59 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:25:59 --> Utf8 Class Initialized
INFO - 2017-03-14 02:25:59 --> URI Class Initialized
INFO - 2017-03-14 02:25:59 --> Router Class Initialized
INFO - 2017-03-14 02:25:59 --> Output Class Initialized
INFO - 2017-03-14 02:25:59 --> Security Class Initialized
DEBUG - 2017-03-14 02:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:25:59 --> Input Class Initialized
INFO - 2017-03-14 02:25:59 --> Language Class Initialized
INFO - 2017-03-14 02:25:59 --> Loader Class Initialized
INFO - 2017-03-14 02:25:59 --> Database Driver Class Initialized
INFO - 2017-03-14 02:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:25:59 --> Controller Class Initialized
INFO - 2017-03-14 02:25:59 --> Helper loaded: date_helper
INFO - 2017-03-14 02:25:59 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:25:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:25:59 --> Helper loaded: form_helper
INFO - 2017-03-14 02:25:59 --> Form Validation Class Initialized
INFO - 2017-03-14 02:25:59 --> Config Class Initialized
INFO - 2017-03-14 02:25:59 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:25:59 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:25:59 --> Utf8 Class Initialized
INFO - 2017-03-14 02:25:59 --> URI Class Initialized
INFO - 2017-03-14 02:25:59 --> Router Class Initialized
INFO - 2017-03-14 02:25:59 --> Output Class Initialized
INFO - 2017-03-14 02:25:59 --> Security Class Initialized
DEBUG - 2017-03-14 02:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:25:59 --> Input Class Initialized
INFO - 2017-03-14 02:25:59 --> Language Class Initialized
INFO - 2017-03-14 02:25:59 --> Loader Class Initialized
INFO - 2017-03-14 02:25:59 --> Database Driver Class Initialized
INFO - 2017-03-14 02:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:25:59 --> Controller Class Initialized
INFO - 2017-03-14 02:25:59 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:25:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:25:59 --> Helper loaded: form_helper
INFO - 2017-03-14 02:25:59 --> Form Validation Class Initialized
INFO - 2017-03-14 02:25:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-14 02:25:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-03-14 02:25:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-14 02:25:59 --> Final output sent to browser
DEBUG - 2017-03-14 02:25:59 --> Total execution time: 0.0575
INFO - 2017-03-14 02:26:00 --> Config Class Initialized
INFO - 2017-03-14 02:26:00 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:26:00 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:26:00 --> Utf8 Class Initialized
INFO - 2017-03-14 02:26:00 --> URI Class Initialized
INFO - 2017-03-14 02:26:00 --> Router Class Initialized
INFO - 2017-03-14 02:26:00 --> Output Class Initialized
INFO - 2017-03-14 02:26:00 --> Security Class Initialized
DEBUG - 2017-03-14 02:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:26:00 --> Input Class Initialized
INFO - 2017-03-14 02:26:00 --> Language Class Initialized
INFO - 2017-03-14 02:26:00 --> Loader Class Initialized
INFO - 2017-03-14 02:26:00 --> Database Driver Class Initialized
INFO - 2017-03-14 02:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:26:00 --> Controller Class Initialized
INFO - 2017-03-14 02:26:00 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:26:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:26:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:26:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:26:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:26:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:26:00 --> Final output sent to browser
DEBUG - 2017-03-14 02:26:00 --> Total execution time: 0.0138
INFO - 2017-03-14 02:26:15 --> Config Class Initialized
INFO - 2017-03-14 02:26:15 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:26:15 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:26:15 --> Utf8 Class Initialized
INFO - 2017-03-14 02:26:15 --> URI Class Initialized
INFO - 2017-03-14 02:26:15 --> Router Class Initialized
INFO - 2017-03-14 02:26:15 --> Output Class Initialized
INFO - 2017-03-14 02:26:15 --> Security Class Initialized
DEBUG - 2017-03-14 02:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:26:15 --> Input Class Initialized
INFO - 2017-03-14 02:26:15 --> Language Class Initialized
INFO - 2017-03-14 02:26:15 --> Loader Class Initialized
INFO - 2017-03-14 02:26:15 --> Database Driver Class Initialized
INFO - 2017-03-14 02:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:26:15 --> Controller Class Initialized
INFO - 2017-03-14 02:26:15 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:26:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:26:15 --> Helper loaded: form_helper
INFO - 2017-03-14 02:26:15 --> Form Validation Class Initialized
INFO - 2017-03-14 02:26:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-14 02:26:15 --> Config Class Initialized
INFO - 2017-03-14 02:26:15 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:26:15 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:26:15 --> Utf8 Class Initialized
INFO - 2017-03-14 02:26:15 --> URI Class Initialized
INFO - 2017-03-14 02:26:15 --> Router Class Initialized
INFO - 2017-03-14 02:26:15 --> Output Class Initialized
INFO - 2017-03-14 02:26:15 --> Security Class Initialized
DEBUG - 2017-03-14 02:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:26:15 --> Input Class Initialized
INFO - 2017-03-14 02:26:15 --> Language Class Initialized
INFO - 2017-03-14 02:26:15 --> Loader Class Initialized
INFO - 2017-03-14 02:26:15 --> Database Driver Class Initialized
INFO - 2017-03-14 02:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:26:15 --> Controller Class Initialized
INFO - 2017-03-14 02:26:15 --> Helper loaded: date_helper
INFO - 2017-03-14 02:26:15 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:26:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:26:15 --> Helper loaded: form_helper
INFO - 2017-03-14 02:26:15 --> Form Validation Class Initialized
INFO - 2017-03-14 02:26:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-14 02:26:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-14 02:26:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-03-14 02:26:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-03-14 02:26:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-14 02:26:15 --> Final output sent to browser
DEBUG - 2017-03-14 02:26:15 --> Total execution time: 0.0662
INFO - 2017-03-14 02:26:15 --> Config Class Initialized
INFO - 2017-03-14 02:26:15 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:26:15 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:26:15 --> Utf8 Class Initialized
INFO - 2017-03-14 02:26:15 --> URI Class Initialized
INFO - 2017-03-14 02:26:15 --> Router Class Initialized
INFO - 2017-03-14 02:26:15 --> Output Class Initialized
INFO - 2017-03-14 02:26:15 --> Security Class Initialized
DEBUG - 2017-03-14 02:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:26:15 --> Input Class Initialized
INFO - 2017-03-14 02:26:15 --> Language Class Initialized
INFO - 2017-03-14 02:26:15 --> Loader Class Initialized
INFO - 2017-03-14 02:26:15 --> Database Driver Class Initialized
INFO - 2017-03-14 02:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:26:15 --> Controller Class Initialized
INFO - 2017-03-14 02:26:15 --> Helper loaded: date_helper
INFO - 2017-03-14 02:26:15 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:26:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:26:15 --> Helper loaded: form_helper
INFO - 2017-03-14 02:26:15 --> Form Validation Class Initialized
INFO - 2017-03-14 02:26:15 --> Final output sent to browser
DEBUG - 2017-03-14 02:26:15 --> Total execution time: 0.0142
INFO - 2017-03-14 02:26:15 --> Config Class Initialized
INFO - 2017-03-14 02:26:15 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:26:15 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:26:15 --> Utf8 Class Initialized
INFO - 2017-03-14 02:26:15 --> URI Class Initialized
INFO - 2017-03-14 02:26:15 --> Router Class Initialized
INFO - 2017-03-14 02:26:15 --> Output Class Initialized
INFO - 2017-03-14 02:26:15 --> Security Class Initialized
DEBUG - 2017-03-14 02:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:26:15 --> Input Class Initialized
INFO - 2017-03-14 02:26:15 --> Language Class Initialized
INFO - 2017-03-14 02:26:15 --> Loader Class Initialized
INFO - 2017-03-14 02:26:15 --> Database Driver Class Initialized
INFO - 2017-03-14 02:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:26:15 --> Controller Class Initialized
INFO - 2017-03-14 02:26:15 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:26:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:26:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:26:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:26:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:26:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:26:15 --> Final output sent to browser
DEBUG - 2017-03-14 02:26:15 --> Total execution time: 0.0136
INFO - 2017-03-14 02:26:18 --> Config Class Initialized
INFO - 2017-03-14 02:26:18 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:26:18 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:26:18 --> Utf8 Class Initialized
INFO - 2017-03-14 02:26:18 --> URI Class Initialized
INFO - 2017-03-14 02:26:18 --> Router Class Initialized
INFO - 2017-03-14 02:26:18 --> Output Class Initialized
INFO - 2017-03-14 02:26:18 --> Security Class Initialized
DEBUG - 2017-03-14 02:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:26:18 --> Input Class Initialized
INFO - 2017-03-14 02:26:18 --> Language Class Initialized
INFO - 2017-03-14 02:26:18 --> Loader Class Initialized
INFO - 2017-03-14 02:26:18 --> Database Driver Class Initialized
INFO - 2017-03-14 02:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:26:18 --> Controller Class Initialized
INFO - 2017-03-14 02:26:18 --> Upload Class Initialized
INFO - 2017-03-14 02:26:18 --> Helper loaded: date_helper
INFO - 2017-03-14 02:26:18 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:26:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:26:18 --> Helper loaded: form_helper
INFO - 2017-03-14 02:26:18 --> Form Validation Class Initialized
INFO - 2017-03-14 02:26:18 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-14 02:26:18 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-14 02:26:18 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/cupones.php
INFO - 2017-03-14 02:26:18 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/cupones.php
INFO - 2017-03-14 02:26:18 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-14 02:26:18 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-14 02:26:18 --> Final output sent to browser
DEBUG - 2017-03-14 02:26:18 --> Total execution time: 0.0998
INFO - 2017-03-14 02:26:19 --> Config Class Initialized
INFO - 2017-03-14 02:26:19 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:26:19 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:26:19 --> Utf8 Class Initialized
INFO - 2017-03-14 02:26:19 --> URI Class Initialized
INFO - 2017-03-14 02:26:19 --> Router Class Initialized
INFO - 2017-03-14 02:26:19 --> Output Class Initialized
INFO - 2017-03-14 02:26:19 --> Security Class Initialized
DEBUG - 2017-03-14 02:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:26:19 --> Input Class Initialized
INFO - 2017-03-14 02:26:19 --> Language Class Initialized
INFO - 2017-03-14 02:26:19 --> Loader Class Initialized
INFO - 2017-03-14 02:26:19 --> Database Driver Class Initialized
INFO - 2017-03-14 02:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:26:19 --> Controller Class Initialized
INFO - 2017-03-14 02:26:19 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:26:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:26:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:26:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:26:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:26:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:26:19 --> Final output sent to browser
DEBUG - 2017-03-14 02:26:19 --> Total execution time: 0.0133
INFO - 2017-03-14 02:26:19 --> Config Class Initialized
INFO - 2017-03-14 02:26:19 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:26:19 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:26:19 --> Utf8 Class Initialized
INFO - 2017-03-14 02:26:19 --> URI Class Initialized
INFO - 2017-03-14 02:26:19 --> Router Class Initialized
INFO - 2017-03-14 02:26:19 --> Output Class Initialized
INFO - 2017-03-14 02:26:19 --> Security Class Initialized
DEBUG - 2017-03-14 02:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:26:19 --> Input Class Initialized
INFO - 2017-03-14 02:26:19 --> Language Class Initialized
INFO - 2017-03-14 02:26:19 --> Loader Class Initialized
INFO - 2017-03-14 02:26:19 --> Database Driver Class Initialized
INFO - 2017-03-14 02:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:26:19 --> Controller Class Initialized
INFO - 2017-03-14 02:26:19 --> Helper loaded: date_helper
INFO - 2017-03-14 02:26:19 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:26:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:26:19 --> Helper loaded: form_helper
INFO - 2017-03-14 02:26:19 --> Form Validation Class Initialized
INFO - 2017-03-14 02:26:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-14 02:26:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-14 02:26:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-03-14 02:26:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-03-14 02:26:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-14 02:26:19 --> Final output sent to browser
DEBUG - 2017-03-14 02:26:19 --> Total execution time: 0.0153
INFO - 2017-03-14 02:26:19 --> Config Class Initialized
INFO - 2017-03-14 02:26:19 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:26:19 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:26:19 --> Utf8 Class Initialized
INFO - 2017-03-14 02:26:19 --> URI Class Initialized
INFO - 2017-03-14 02:26:19 --> Router Class Initialized
INFO - 2017-03-14 02:26:19 --> Config Class Initialized
INFO - 2017-03-14 02:26:19 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:26:19 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:26:19 --> Utf8 Class Initialized
INFO - 2017-03-14 02:26:19 --> Output Class Initialized
INFO - 2017-03-14 02:26:19 --> Security Class Initialized
DEBUG - 2017-03-14 02:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:26:19 --> Input Class Initialized
INFO - 2017-03-14 02:26:19 --> Language Class Initialized
INFO - 2017-03-14 02:26:19 --> Loader Class Initialized
INFO - 2017-03-14 02:26:19 --> Database Driver Class Initialized
INFO - 2017-03-14 02:26:19 --> URI Class Initialized
INFO - 2017-03-14 02:26:19 --> Router Class Initialized
INFO - 2017-03-14 02:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:26:19 --> Controller Class Initialized
INFO - 2017-03-14 02:26:19 --> Output Class Initialized
INFO - 2017-03-14 02:26:19 --> Helper loaded: date_helper
INFO - 2017-03-14 02:26:19 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:26:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:26:19 --> Helper loaded: form_helper
INFO - 2017-03-14 02:26:19 --> Form Validation Class Initialized
INFO - 2017-03-14 02:26:19 --> Security Class Initialized
DEBUG - 2017-03-14 02:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:26:19 --> Input Class Initialized
INFO - 2017-03-14 02:26:19 --> Language Class Initialized
INFO - 2017-03-14 02:26:19 --> Loader Class Initialized
INFO - 2017-03-14 02:26:20 --> Database Driver Class Initialized
INFO - 2017-03-14 02:26:20 --> Final output sent to browser
DEBUG - 2017-03-14 02:26:20 --> Total execution time: 0.0329
INFO - 2017-03-14 02:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:26:20 --> Controller Class Initialized
INFO - 2017-03-14 02:26:20 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:26:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:26:20 --> Final output sent to browser
DEBUG - 2017-03-14 02:26:20 --> Total execution time: 0.0828
INFO - 2017-03-14 02:26:24 --> Config Class Initialized
INFO - 2017-03-14 02:26:24 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:26:24 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:26:24 --> Config Class Initialized
INFO - 2017-03-14 02:26:24 --> Utf8 Class Initialized
INFO - 2017-03-14 02:26:24 --> Hooks Class Initialized
INFO - 2017-03-14 02:26:24 --> URI Class Initialized
DEBUG - 2017-03-14 02:26:24 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:26:24 --> Utf8 Class Initialized
INFO - 2017-03-14 02:26:24 --> Router Class Initialized
INFO - 2017-03-14 02:26:24 --> URI Class Initialized
INFO - 2017-03-14 02:26:24 --> Router Class Initialized
INFO - 2017-03-14 02:26:24 --> Output Class Initialized
INFO - 2017-03-14 02:26:24 --> Security Class Initialized
INFO - 2017-03-14 02:26:24 --> Output Class Initialized
DEBUG - 2017-03-14 02:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:26:24 --> Input Class Initialized
INFO - 2017-03-14 02:26:24 --> Security Class Initialized
INFO - 2017-03-14 02:26:24 --> Language Class Initialized
DEBUG - 2017-03-14 02:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:26:24 --> Input Class Initialized
INFO - 2017-03-14 02:26:24 --> Language Class Initialized
INFO - 2017-03-14 02:26:24 --> Loader Class Initialized
INFO - 2017-03-14 02:26:24 --> Loader Class Initialized
INFO - 2017-03-14 02:26:24 --> Database Driver Class Initialized
INFO - 2017-03-14 02:26:24 --> Database Driver Class Initialized
INFO - 2017-03-14 02:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:26:24 --> Controller Class Initialized
INFO - 2017-03-14 02:26:24 --> Helper loaded: date_helper
INFO - 2017-03-14 02:26:24 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:26:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:26:24 --> Helper loaded: form_helper
INFO - 2017-03-14 02:26:24 --> Form Validation Class Initialized
INFO - 2017-03-14 02:26:24 --> Final output sent to browser
DEBUG - 2017-03-14 02:26:24 --> Total execution time: 0.0859
INFO - 2017-03-14 02:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:26:24 --> Controller Class Initialized
INFO - 2017-03-14 02:26:24 --> Helper loaded: date_helper
INFO - 2017-03-14 02:26:24 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:26:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:26:24 --> Helper loaded: form_helper
INFO - 2017-03-14 02:26:24 --> Form Validation Class Initialized
INFO - 2017-03-14 02:26:24 --> Final output sent to browser
DEBUG - 2017-03-14 02:26:24 --> Total execution time: 0.0966
INFO - 2017-03-14 02:26:31 --> Config Class Initialized
INFO - 2017-03-14 02:26:31 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:26:31 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:26:31 --> Utf8 Class Initialized
INFO - 2017-03-14 02:26:31 --> URI Class Initialized
INFO - 2017-03-14 02:26:31 --> Config Class Initialized
INFO - 2017-03-14 02:26:31 --> Hooks Class Initialized
INFO - 2017-03-14 02:26:31 --> Router Class Initialized
INFO - 2017-03-14 02:26:31 --> Output Class Initialized
DEBUG - 2017-03-14 02:26:31 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:26:31 --> Utf8 Class Initialized
INFO - 2017-03-14 02:26:31 --> Security Class Initialized
INFO - 2017-03-14 02:26:31 --> URI Class Initialized
DEBUG - 2017-03-14 02:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:26:31 --> Input Class Initialized
INFO - 2017-03-14 02:26:31 --> Router Class Initialized
INFO - 2017-03-14 02:26:31 --> Language Class Initialized
INFO - 2017-03-14 02:26:31 --> Output Class Initialized
INFO - 2017-03-14 02:26:31 --> Loader Class Initialized
INFO - 2017-03-14 02:26:31 --> Security Class Initialized
DEBUG - 2017-03-14 02:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:26:31 --> Input Class Initialized
INFO - 2017-03-14 02:26:31 --> Language Class Initialized
INFO - 2017-03-14 02:26:31 --> Loader Class Initialized
INFO - 2017-03-14 02:26:31 --> Database Driver Class Initialized
INFO - 2017-03-14 02:26:31 --> Database Driver Class Initialized
INFO - 2017-03-14 02:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:26:31 --> Controller Class Initialized
INFO - 2017-03-14 02:26:31 --> Helper loaded: date_helper
INFO - 2017-03-14 02:26:31 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:26:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:26:31 --> Helper loaded: form_helper
INFO - 2017-03-14 02:26:31 --> Form Validation Class Initialized
INFO - 2017-03-14 02:26:31 --> Final output sent to browser
DEBUG - 2017-03-14 02:26:31 --> Total execution time: 0.4230
INFO - 2017-03-14 02:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:26:31 --> Controller Class Initialized
INFO - 2017-03-14 02:26:31 --> Helper loaded: date_helper
INFO - 2017-03-14 02:26:31 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:26:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:26:31 --> Helper loaded: form_helper
INFO - 2017-03-14 02:26:31 --> Form Validation Class Initialized
INFO - 2017-03-14 02:26:31 --> Final output sent to browser
DEBUG - 2017-03-14 02:26:31 --> Total execution time: 0.7674
INFO - 2017-03-14 02:27:38 --> Config Class Initialized
INFO - 2017-03-14 02:27:38 --> Config Class Initialized
INFO - 2017-03-14 02:27:38 --> Hooks Class Initialized
INFO - 2017-03-14 02:27:38 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:27:38 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:27:38 --> Utf8 Class Initialized
DEBUG - 2017-03-14 02:27:38 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:27:38 --> URI Class Initialized
INFO - 2017-03-14 02:27:38 --> Utf8 Class Initialized
INFO - 2017-03-14 02:27:38 --> URI Class Initialized
INFO - 2017-03-14 02:27:38 --> Router Class Initialized
INFO - 2017-03-14 02:27:38 --> Router Class Initialized
INFO - 2017-03-14 02:27:38 --> Output Class Initialized
INFO - 2017-03-14 02:27:38 --> Output Class Initialized
INFO - 2017-03-14 02:27:38 --> Security Class Initialized
INFO - 2017-03-14 02:27:38 --> Security Class Initialized
DEBUG - 2017-03-14 02:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:27:38 --> Input Class Initialized
INFO - 2017-03-14 02:27:38 --> Language Class Initialized
DEBUG - 2017-03-14 02:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:27:38 --> Input Class Initialized
INFO - 2017-03-14 02:27:38 --> Language Class Initialized
INFO - 2017-03-14 02:27:38 --> Loader Class Initialized
INFO - 2017-03-14 02:27:38 --> Loader Class Initialized
INFO - 2017-03-14 02:27:39 --> Database Driver Class Initialized
INFO - 2017-03-14 02:27:39 --> Database Driver Class Initialized
INFO - 2017-03-14 02:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:27:39 --> Controller Class Initialized
INFO - 2017-03-14 02:27:39 --> Helper loaded: date_helper
INFO - 2017-03-14 02:27:39 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:27:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:27:39 --> Helper loaded: form_helper
INFO - 2017-03-14 02:27:39 --> Form Validation Class Initialized
INFO - 2017-03-14 02:27:39 --> Final output sent to browser
DEBUG - 2017-03-14 02:27:39 --> Total execution time: 1.1549
INFO - 2017-03-14 02:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:27:39 --> Controller Class Initialized
INFO - 2017-03-14 02:27:39 --> Helper loaded: date_helper
INFO - 2017-03-14 02:27:39 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:27:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:27:39 --> Helper loaded: form_helper
INFO - 2017-03-14 02:27:39 --> Form Validation Class Initialized
INFO - 2017-03-14 02:27:39 --> Final output sent to browser
DEBUG - 2017-03-14 02:27:39 --> Total execution time: 1.1622
INFO - 2017-03-14 02:27:51 --> Config Class Initialized
INFO - 2017-03-14 02:27:51 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:27:51 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:27:51 --> Utf8 Class Initialized
INFO - 2017-03-14 02:27:51 --> URI Class Initialized
INFO - 2017-03-14 02:27:51 --> Router Class Initialized
INFO - 2017-03-14 02:27:51 --> Output Class Initialized
INFO - 2017-03-14 02:27:51 --> Security Class Initialized
DEBUG - 2017-03-14 02:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:27:51 --> Input Class Initialized
INFO - 2017-03-14 02:27:51 --> Language Class Initialized
INFO - 2017-03-14 02:27:51 --> Loader Class Initialized
INFO - 2017-03-14 02:27:51 --> Config Class Initialized
INFO - 2017-03-14 02:27:51 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:27:51 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:27:51 --> Utf8 Class Initialized
INFO - 2017-03-14 02:27:51 --> URI Class Initialized
INFO - 2017-03-14 02:27:51 --> Router Class Initialized
INFO - 2017-03-14 02:27:51 --> Output Class Initialized
INFO - 2017-03-14 02:27:51 --> Security Class Initialized
DEBUG - 2017-03-14 02:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:27:51 --> Input Class Initialized
INFO - 2017-03-14 02:27:51 --> Language Class Initialized
INFO - 2017-03-14 02:27:51 --> Database Driver Class Initialized
INFO - 2017-03-14 02:27:51 --> Loader Class Initialized
INFO - 2017-03-14 02:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:27:51 --> Controller Class Initialized
INFO - 2017-03-14 02:27:51 --> Helper loaded: date_helper
INFO - 2017-03-14 02:27:51 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:27:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:27:51 --> Database Driver Class Initialized
INFO - 2017-03-14 02:27:51 --> Helper loaded: form_helper
INFO - 2017-03-14 02:27:51 --> Form Validation Class Initialized
INFO - 2017-03-14 02:27:51 --> Final output sent to browser
DEBUG - 2017-03-14 02:27:51 --> Total execution time: 0.0193
INFO - 2017-03-14 02:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:27:51 --> Controller Class Initialized
INFO - 2017-03-14 02:27:51 --> Helper loaded: date_helper
INFO - 2017-03-14 02:27:51 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:27:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:27:51 --> Helper loaded: form_helper
INFO - 2017-03-14 02:27:51 --> Form Validation Class Initialized
INFO - 2017-03-14 02:27:51 --> Final output sent to browser
DEBUG - 2017-03-14 02:27:51 --> Total execution time: 0.0910
INFO - 2017-03-14 02:28:04 --> Config Class Initialized
INFO - 2017-03-14 02:28:04 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:28:04 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:28:04 --> Utf8 Class Initialized
INFO - 2017-03-14 02:28:04 --> URI Class Initialized
INFO - 2017-03-14 02:28:04 --> Router Class Initialized
INFO - 2017-03-14 02:28:04 --> Output Class Initialized
INFO - 2017-03-14 02:28:04 --> Security Class Initialized
DEBUG - 2017-03-14 02:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:28:04 --> Input Class Initialized
INFO - 2017-03-14 02:28:04 --> Language Class Initialized
INFO - 2017-03-14 02:28:04 --> Loader Class Initialized
INFO - 2017-03-14 02:28:04 --> Database Driver Class Initialized
INFO - 2017-03-14 02:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:28:04 --> Controller Class Initialized
INFO - 2017-03-14 02:28:04 --> Helper loaded: date_helper
INFO - 2017-03-14 02:28:04 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:28:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:28:04 --> Helper loaded: form_helper
INFO - 2017-03-14 02:28:04 --> Form Validation Class Initialized
INFO - 2017-03-14 02:28:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-14 02:28:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-14 02:28:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-03-14 02:28:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-03-14 02:28:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-14 02:28:04 --> Final output sent to browser
DEBUG - 2017-03-14 02:28:04 --> Total execution time: 0.1724
INFO - 2017-03-14 02:28:04 --> Config Class Initialized
INFO - 2017-03-14 02:28:04 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:28:04 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:28:04 --> Utf8 Class Initialized
INFO - 2017-03-14 02:28:04 --> URI Class Initialized
INFO - 2017-03-14 02:28:04 --> Router Class Initialized
INFO - 2017-03-14 02:28:04 --> Output Class Initialized
INFO - 2017-03-14 02:28:04 --> Security Class Initialized
DEBUG - 2017-03-14 02:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:28:04 --> Input Class Initialized
INFO - 2017-03-14 02:28:04 --> Language Class Initialized
INFO - 2017-03-14 02:28:04 --> Loader Class Initialized
INFO - 2017-03-14 02:28:04 --> Database Driver Class Initialized
INFO - 2017-03-14 02:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:28:05 --> Controller Class Initialized
INFO - 2017-03-14 02:28:05 --> Helper loaded: date_helper
INFO - 2017-03-14 02:28:05 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:28:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:28:05 --> Helper loaded: form_helper
INFO - 2017-03-14 02:28:05 --> Form Validation Class Initialized
INFO - 2017-03-14 02:28:05 --> Final output sent to browser
DEBUG - 2017-03-14 02:28:05 --> Total execution time: 0.3096
INFO - 2017-03-14 02:28:05 --> Config Class Initialized
INFO - 2017-03-14 02:28:05 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:28:05 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:28:05 --> Utf8 Class Initialized
INFO - 2017-03-14 02:28:05 --> URI Class Initialized
INFO - 2017-03-14 02:28:05 --> Router Class Initialized
INFO - 2017-03-14 02:28:05 --> Output Class Initialized
INFO - 2017-03-14 02:28:05 --> Security Class Initialized
DEBUG - 2017-03-14 02:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:28:05 --> Input Class Initialized
INFO - 2017-03-14 02:28:05 --> Language Class Initialized
INFO - 2017-03-14 02:28:05 --> Loader Class Initialized
INFO - 2017-03-14 02:28:05 --> Database Driver Class Initialized
INFO - 2017-03-14 02:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:28:05 --> Controller Class Initialized
INFO - 2017-03-14 02:28:05 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:28:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:28:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:28:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:28:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:28:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:28:05 --> Final output sent to browser
DEBUG - 2017-03-14 02:28:05 --> Total execution time: 0.2670
INFO - 2017-03-14 02:28:10 --> Config Class Initialized
INFO - 2017-03-14 02:28:10 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:28:10 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:28:10 --> Utf8 Class Initialized
INFO - 2017-03-14 02:28:10 --> URI Class Initialized
INFO - 2017-03-14 02:28:10 --> Router Class Initialized
INFO - 2017-03-14 02:28:10 --> Output Class Initialized
INFO - 2017-03-14 02:28:10 --> Security Class Initialized
DEBUG - 2017-03-14 02:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:28:10 --> Input Class Initialized
INFO - 2017-03-14 02:28:10 --> Language Class Initialized
INFO - 2017-03-14 02:28:10 --> Loader Class Initialized
INFO - 2017-03-14 02:28:10 --> Database Driver Class Initialized
INFO - 2017-03-14 02:28:10 --> Config Class Initialized
INFO - 2017-03-14 02:28:10 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:28:10 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:28:10 --> Utf8 Class Initialized
INFO - 2017-03-14 02:28:10 --> URI Class Initialized
INFO - 2017-03-14 02:28:10 --> Router Class Initialized
INFO - 2017-03-14 02:28:10 --> Output Class Initialized
INFO - 2017-03-14 02:28:10 --> Security Class Initialized
DEBUG - 2017-03-14 02:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:28:10 --> Input Class Initialized
INFO - 2017-03-14 02:28:10 --> Language Class Initialized
INFO - 2017-03-14 02:28:10 --> Loader Class Initialized
INFO - 2017-03-14 02:28:10 --> Database Driver Class Initialized
INFO - 2017-03-14 02:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:28:10 --> Controller Class Initialized
INFO - 2017-03-14 02:28:10 --> Helper loaded: date_helper
INFO - 2017-03-14 02:28:10 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:28:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:28:10 --> Helper loaded: form_helper
INFO - 2017-03-14 02:28:10 --> Form Validation Class Initialized
INFO - 2017-03-14 02:28:10 --> Final output sent to browser
DEBUG - 2017-03-14 02:28:10 --> Total execution time: 0.0255
INFO - 2017-03-14 02:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:28:10 --> Controller Class Initialized
INFO - 2017-03-14 02:28:10 --> Helper loaded: date_helper
INFO - 2017-03-14 02:28:10 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:28:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:28:10 --> Helper loaded: form_helper
INFO - 2017-03-14 02:28:10 --> Form Validation Class Initialized
INFO - 2017-03-14 02:28:10 --> Final output sent to browser
DEBUG - 2017-03-14 02:28:10 --> Total execution time: 0.0253
INFO - 2017-03-14 02:28:13 --> Config Class Initialized
INFO - 2017-03-14 02:28:13 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:28:13 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:28:13 --> Utf8 Class Initialized
INFO - 2017-03-14 02:28:13 --> URI Class Initialized
INFO - 2017-03-14 02:28:13 --> Router Class Initialized
INFO - 2017-03-14 02:28:13 --> Output Class Initialized
INFO - 2017-03-14 02:28:13 --> Security Class Initialized
DEBUG - 2017-03-14 02:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:28:13 --> Input Class Initialized
INFO - 2017-03-14 02:28:13 --> Language Class Initialized
INFO - 2017-03-14 02:28:13 --> Loader Class Initialized
INFO - 2017-03-14 02:28:13 --> Database Driver Class Initialized
INFO - 2017-03-14 02:28:13 --> Config Class Initialized
INFO - 2017-03-14 02:28:13 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:28:13 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:28:13 --> Utf8 Class Initialized
INFO - 2017-03-14 02:28:13 --> URI Class Initialized
INFO - 2017-03-14 02:28:13 --> Router Class Initialized
INFO - 2017-03-14 02:28:13 --> Output Class Initialized
INFO - 2017-03-14 02:28:13 --> Security Class Initialized
DEBUG - 2017-03-14 02:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:28:13 --> Input Class Initialized
INFO - 2017-03-14 02:28:13 --> Language Class Initialized
INFO - 2017-03-14 02:28:13 --> Loader Class Initialized
INFO - 2017-03-14 02:28:13 --> Database Driver Class Initialized
INFO - 2017-03-14 02:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:28:13 --> Controller Class Initialized
INFO - 2017-03-14 02:28:13 --> Helper loaded: date_helper
INFO - 2017-03-14 02:28:13 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:28:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:28:13 --> Helper loaded: form_helper
INFO - 2017-03-14 02:28:13 --> Form Validation Class Initialized
INFO - 2017-03-14 02:28:13 --> Final output sent to browser
DEBUG - 2017-03-14 02:28:13 --> Total execution time: 0.0267
INFO - 2017-03-14 02:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:28:13 --> Controller Class Initialized
INFO - 2017-03-14 02:28:13 --> Helper loaded: date_helper
INFO - 2017-03-14 02:28:13 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:28:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:28:13 --> Helper loaded: form_helper
INFO - 2017-03-14 02:28:13 --> Form Validation Class Initialized
INFO - 2017-03-14 02:28:13 --> Final output sent to browser
DEBUG - 2017-03-14 02:28:13 --> Total execution time: 0.0210
INFO - 2017-03-14 02:28:24 --> Config Class Initialized
INFO - 2017-03-14 02:28:24 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:28:24 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:28:24 --> Utf8 Class Initialized
INFO - 2017-03-14 02:28:24 --> URI Class Initialized
INFO - 2017-03-14 02:28:24 --> Router Class Initialized
INFO - 2017-03-14 02:28:24 --> Output Class Initialized
INFO - 2017-03-14 02:28:24 --> Security Class Initialized
DEBUG - 2017-03-14 02:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:28:24 --> Input Class Initialized
INFO - 2017-03-14 02:28:24 --> Language Class Initialized
INFO - 2017-03-14 02:28:24 --> Loader Class Initialized
INFO - 2017-03-14 02:28:24 --> Database Driver Class Initialized
INFO - 2017-03-14 02:28:24 --> Config Class Initialized
INFO - 2017-03-14 02:28:24 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:28:24 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:28:24 --> Utf8 Class Initialized
INFO - 2017-03-14 02:28:24 --> URI Class Initialized
INFO - 2017-03-14 02:28:24 --> Router Class Initialized
INFO - 2017-03-14 02:28:24 --> Output Class Initialized
INFO - 2017-03-14 02:28:24 --> Security Class Initialized
DEBUG - 2017-03-14 02:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:28:24 --> Input Class Initialized
INFO - 2017-03-14 02:28:24 --> Language Class Initialized
INFO - 2017-03-14 02:28:24 --> Loader Class Initialized
INFO - 2017-03-14 02:28:24 --> Database Driver Class Initialized
INFO - 2017-03-14 02:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:28:24 --> Controller Class Initialized
INFO - 2017-03-14 02:28:24 --> Helper loaded: date_helper
INFO - 2017-03-14 02:28:24 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:28:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:28:24 --> Helper loaded: form_helper
INFO - 2017-03-14 02:28:24 --> Form Validation Class Initialized
INFO - 2017-03-14 02:28:24 --> Final output sent to browser
DEBUG - 2017-03-14 02:28:24 --> Total execution time: 0.0306
INFO - 2017-03-14 02:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:28:24 --> Controller Class Initialized
INFO - 2017-03-14 02:28:24 --> Helper loaded: date_helper
INFO - 2017-03-14 02:28:24 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:28:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:28:24 --> Helper loaded: form_helper
INFO - 2017-03-14 02:28:24 --> Form Validation Class Initialized
INFO - 2017-03-14 02:28:24 --> Final output sent to browser
DEBUG - 2017-03-14 02:28:24 --> Total execution time: 0.0259
INFO - 2017-03-14 02:28:32 --> Config Class Initialized
INFO - 2017-03-14 02:28:32 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:28:32 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:28:32 --> Utf8 Class Initialized
INFO - 2017-03-14 02:28:32 --> URI Class Initialized
INFO - 2017-03-14 02:28:32 --> Router Class Initialized
INFO - 2017-03-14 02:28:32 --> Output Class Initialized
INFO - 2017-03-14 02:28:32 --> Security Class Initialized
DEBUG - 2017-03-14 02:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:28:32 --> Input Class Initialized
INFO - 2017-03-14 02:28:32 --> Language Class Initialized
INFO - 2017-03-14 02:28:32 --> Loader Class Initialized
INFO - 2017-03-14 02:28:32 --> Database Driver Class Initialized
INFO - 2017-03-14 02:28:32 --> Config Class Initialized
INFO - 2017-03-14 02:28:32 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:28:32 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:28:32 --> Utf8 Class Initialized
INFO - 2017-03-14 02:28:32 --> URI Class Initialized
INFO - 2017-03-14 02:28:32 --> Router Class Initialized
INFO - 2017-03-14 02:28:32 --> Output Class Initialized
INFO - 2017-03-14 02:28:32 --> Security Class Initialized
DEBUG - 2017-03-14 02:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:28:32 --> Input Class Initialized
INFO - 2017-03-14 02:28:32 --> Language Class Initialized
INFO - 2017-03-14 02:28:32 --> Loader Class Initialized
INFO - 2017-03-14 02:28:33 --> Database Driver Class Initialized
INFO - 2017-03-14 02:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:28:33 --> Controller Class Initialized
INFO - 2017-03-14 02:28:33 --> Helper loaded: date_helper
INFO - 2017-03-14 02:28:33 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:28:33 --> Helper loaded: form_helper
INFO - 2017-03-14 02:28:33 --> Form Validation Class Initialized
INFO - 2017-03-14 02:28:33 --> Final output sent to browser
DEBUG - 2017-03-14 02:28:33 --> Total execution time: 0.0277
INFO - 2017-03-14 02:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:28:33 --> Controller Class Initialized
INFO - 2017-03-14 02:28:33 --> Helper loaded: date_helper
INFO - 2017-03-14 02:28:33 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:28:33 --> Helper loaded: form_helper
INFO - 2017-03-14 02:28:33 --> Form Validation Class Initialized
INFO - 2017-03-14 02:28:33 --> Final output sent to browser
DEBUG - 2017-03-14 02:28:33 --> Total execution time: 0.0721
INFO - 2017-03-14 02:28:38 --> Config Class Initialized
INFO - 2017-03-14 02:28:38 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:28:38 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:28:38 --> Utf8 Class Initialized
INFO - 2017-03-14 02:28:38 --> URI Class Initialized
INFO - 2017-03-14 02:28:38 --> Router Class Initialized
INFO - 2017-03-14 02:28:38 --> Output Class Initialized
INFO - 2017-03-14 02:28:38 --> Security Class Initialized
DEBUG - 2017-03-14 02:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:28:38 --> Input Class Initialized
INFO - 2017-03-14 02:28:38 --> Language Class Initialized
INFO - 2017-03-14 02:28:38 --> Loader Class Initialized
INFO - 2017-03-14 02:28:38 --> Config Class Initialized
INFO - 2017-03-14 02:28:38 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:28:38 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:28:38 --> Utf8 Class Initialized
INFO - 2017-03-14 02:28:38 --> URI Class Initialized
INFO - 2017-03-14 02:28:38 --> Router Class Initialized
INFO - 2017-03-14 02:28:38 --> Output Class Initialized
INFO - 2017-03-14 02:28:38 --> Security Class Initialized
DEBUG - 2017-03-14 02:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:28:38 --> Input Class Initialized
INFO - 2017-03-14 02:28:38 --> Language Class Initialized
INFO - 2017-03-14 02:28:38 --> Loader Class Initialized
INFO - 2017-03-14 02:28:38 --> Database Driver Class Initialized
INFO - 2017-03-14 02:28:38 --> Database Driver Class Initialized
INFO - 2017-03-14 02:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:28:38 --> Controller Class Initialized
INFO - 2017-03-14 02:28:38 --> Helper loaded: date_helper
INFO - 2017-03-14 02:28:38 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:28:38 --> Helper loaded: form_helper
INFO - 2017-03-14 02:28:38 --> Form Validation Class Initialized
INFO - 2017-03-14 02:28:38 --> Final output sent to browser
DEBUG - 2017-03-14 02:28:38 --> Total execution time: 0.0238
INFO - 2017-03-14 02:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:28:38 --> Controller Class Initialized
INFO - 2017-03-14 02:28:38 --> Helper loaded: date_helper
INFO - 2017-03-14 02:28:38 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:28:38 --> Helper loaded: form_helper
INFO - 2017-03-14 02:28:38 --> Form Validation Class Initialized
INFO - 2017-03-14 02:28:38 --> Final output sent to browser
DEBUG - 2017-03-14 02:28:38 --> Total execution time: 0.0338
INFO - 2017-03-14 02:28:43 --> Config Class Initialized
INFO - 2017-03-14 02:28:43 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:28:43 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:28:43 --> Utf8 Class Initialized
INFO - 2017-03-14 02:28:43 --> URI Class Initialized
INFO - 2017-03-14 02:28:43 --> Router Class Initialized
INFO - 2017-03-14 02:28:43 --> Output Class Initialized
INFO - 2017-03-14 02:28:43 --> Security Class Initialized
DEBUG - 2017-03-14 02:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:28:43 --> Input Class Initialized
INFO - 2017-03-14 02:28:43 --> Language Class Initialized
INFO - 2017-03-14 02:28:43 --> Loader Class Initialized
INFO - 2017-03-14 02:28:43 --> Database Driver Class Initialized
INFO - 2017-03-14 02:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:28:43 --> Controller Class Initialized
INFO - 2017-03-14 02:28:43 --> Helper loaded: date_helper
INFO - 2017-03-14 02:28:43 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:28:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:28:43 --> Helper loaded: form_helper
INFO - 2017-03-14 02:28:43 --> Form Validation Class Initialized
INFO - 2017-03-14 02:28:43 --> Final output sent to browser
DEBUG - 2017-03-14 02:28:43 --> Total execution time: 0.0154
INFO - 2017-03-14 02:28:46 --> Config Class Initialized
INFO - 2017-03-14 02:28:46 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:28:46 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:28:46 --> Utf8 Class Initialized
INFO - 2017-03-14 02:28:46 --> URI Class Initialized
INFO - 2017-03-14 02:28:46 --> Router Class Initialized
INFO - 2017-03-14 02:28:46 --> Output Class Initialized
INFO - 2017-03-14 02:28:46 --> Security Class Initialized
DEBUG - 2017-03-14 02:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:28:46 --> Input Class Initialized
INFO - 2017-03-14 02:28:46 --> Language Class Initialized
INFO - 2017-03-14 02:28:46 --> Loader Class Initialized
INFO - 2017-03-14 02:28:46 --> Database Driver Class Initialized
INFO - 2017-03-14 02:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:28:46 --> Controller Class Initialized
INFO - 2017-03-14 02:28:46 --> Helper loaded: date_helper
INFO - 2017-03-14 02:28:46 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:28:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:28:46 --> Helper loaded: form_helper
INFO - 2017-03-14 02:28:46 --> Form Validation Class Initialized
INFO - 2017-03-14 02:28:46 --> Final output sent to browser
DEBUG - 2017-03-14 02:28:46 --> Total execution time: 0.0162
INFO - 2017-03-14 02:29:47 --> Config Class Initialized
INFO - 2017-03-14 02:29:47 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:29:48 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:29:48 --> Utf8 Class Initialized
INFO - 2017-03-14 02:29:48 --> URI Class Initialized
INFO - 2017-03-14 02:29:48 --> Router Class Initialized
INFO - 2017-03-14 02:29:48 --> Output Class Initialized
INFO - 2017-03-14 02:29:48 --> Security Class Initialized
DEBUG - 2017-03-14 02:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:29:48 --> Input Class Initialized
INFO - 2017-03-14 02:29:48 --> Language Class Initialized
INFO - 2017-03-14 02:29:48 --> Loader Class Initialized
INFO - 2017-03-14 02:29:48 --> Database Driver Class Initialized
INFO - 2017-03-14 02:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:29:48 --> Controller Class Initialized
INFO - 2017-03-14 02:29:48 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:29:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:29:49 --> Config Class Initialized
INFO - 2017-03-14 02:29:49 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:29:49 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:29:49 --> Utf8 Class Initialized
INFO - 2017-03-14 02:29:49 --> URI Class Initialized
INFO - 2017-03-14 02:29:49 --> Router Class Initialized
INFO - 2017-03-14 02:29:49 --> Output Class Initialized
INFO - 2017-03-14 02:29:49 --> Security Class Initialized
DEBUG - 2017-03-14 02:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:29:49 --> Input Class Initialized
INFO - 2017-03-14 02:29:49 --> Language Class Initialized
INFO - 2017-03-14 02:29:49 --> Loader Class Initialized
INFO - 2017-03-14 02:29:49 --> Database Driver Class Initialized
INFO - 2017-03-14 02:29:49 --> Config Class Initialized
INFO - 2017-03-14 02:29:49 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:29:49 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:29:49 --> Utf8 Class Initialized
INFO - 2017-03-14 02:29:49 --> URI Class Initialized
INFO - 2017-03-14 02:29:49 --> Router Class Initialized
INFO - 2017-03-14 02:29:49 --> Output Class Initialized
INFO - 2017-03-14 02:29:49 --> Security Class Initialized
DEBUG - 2017-03-14 02:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:29:49 --> Input Class Initialized
INFO - 2017-03-14 02:29:49 --> Language Class Initialized
INFO - 2017-03-14 02:29:49 --> Loader Class Initialized
INFO - 2017-03-14 02:29:49 --> Database Driver Class Initialized
INFO - 2017-03-14 02:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:29:49 --> Controller Class Initialized
INFO - 2017-03-14 02:29:49 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:29:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:29:49 --> Controller Class Initialized
INFO - 2017-03-14 02:29:49 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:29:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:29:49 --> Helper loaded: form_helper
INFO - 2017-03-14 02:29:49 --> Form Validation Class Initialized
INFO - 2017-03-14 02:29:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:29:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-14 02:29:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:29:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-03-14 02:29:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:29:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:29:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-14 02:29:49 --> Final output sent to browser
DEBUG - 2017-03-14 02:29:49 --> Total execution time: 0.5229
INFO - 2017-03-14 02:29:49 --> Final output sent to browser
DEBUG - 2017-03-14 02:29:49 --> Total execution time: 0.5193
INFO - 2017-03-14 02:29:50 --> Config Class Initialized
INFO - 2017-03-14 02:29:50 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:29:51 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:29:51 --> Utf8 Class Initialized
INFO - 2017-03-14 02:29:51 --> URI Class Initialized
INFO - 2017-03-14 02:29:51 --> Router Class Initialized
INFO - 2017-03-14 02:29:51 --> Output Class Initialized
INFO - 2017-03-14 02:29:51 --> Security Class Initialized
DEBUG - 2017-03-14 02:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:29:51 --> Input Class Initialized
INFO - 2017-03-14 02:29:51 --> Language Class Initialized
INFO - 2017-03-14 02:29:51 --> Loader Class Initialized
INFO - 2017-03-14 02:29:51 --> Database Driver Class Initialized
INFO - 2017-03-14 02:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:29:51 --> Controller Class Initialized
INFO - 2017-03-14 02:29:51 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:29:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:29:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:29:52 --> Final output sent to browser
DEBUG - 2017-03-14 02:29:52 --> Total execution time: 1.3478
INFO - 2017-03-14 02:31:00 --> Config Class Initialized
INFO - 2017-03-14 02:31:00 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:31:01 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:31:01 --> Utf8 Class Initialized
INFO - 2017-03-14 02:31:01 --> URI Class Initialized
INFO - 2017-03-14 02:31:01 --> Router Class Initialized
INFO - 2017-03-14 02:31:01 --> Output Class Initialized
INFO - 2017-03-14 02:31:01 --> Security Class Initialized
DEBUG - 2017-03-14 02:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:31:01 --> Input Class Initialized
INFO - 2017-03-14 02:31:01 --> Language Class Initialized
INFO - 2017-03-14 02:31:01 --> Loader Class Initialized
INFO - 2017-03-14 02:31:01 --> Database Driver Class Initialized
INFO - 2017-03-14 02:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:31:05 --> Controller Class Initialized
INFO - 2017-03-14 02:31:05 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:31:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:31:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:31:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:31:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:31:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:31:05 --> Final output sent to browser
DEBUG - 2017-03-14 02:31:05 --> Total execution time: 4.9668
INFO - 2017-03-14 02:31:06 --> Config Class Initialized
INFO - 2017-03-14 02:31:06 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:31:06 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:31:06 --> Utf8 Class Initialized
INFO - 2017-03-14 02:31:06 --> URI Class Initialized
DEBUG - 2017-03-14 02:31:06 --> No URI present. Default controller set.
INFO - 2017-03-14 02:31:06 --> Router Class Initialized
INFO - 2017-03-14 02:31:06 --> Output Class Initialized
INFO - 2017-03-14 02:31:06 --> Security Class Initialized
DEBUG - 2017-03-14 02:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:31:06 --> Input Class Initialized
INFO - 2017-03-14 02:31:06 --> Language Class Initialized
INFO - 2017-03-14 02:31:06 --> Loader Class Initialized
INFO - 2017-03-14 02:31:06 --> Database Driver Class Initialized
INFO - 2017-03-14 02:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:31:06 --> Controller Class Initialized
INFO - 2017-03-14 02:31:06 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:31:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:31:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:31:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:31:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:31:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:31:06 --> Final output sent to browser
DEBUG - 2017-03-14 02:31:06 --> Total execution time: 0.0145
INFO - 2017-03-14 02:39:29 --> Config Class Initialized
INFO - 2017-03-14 02:39:29 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:39:29 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:39:29 --> Utf8 Class Initialized
INFO - 2017-03-14 02:39:29 --> URI Class Initialized
INFO - 2017-03-14 02:39:29 --> Router Class Initialized
INFO - 2017-03-14 02:39:29 --> Output Class Initialized
INFO - 2017-03-14 02:39:29 --> Security Class Initialized
DEBUG - 2017-03-14 02:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:39:29 --> Input Class Initialized
INFO - 2017-03-14 02:39:29 --> Language Class Initialized
INFO - 2017-03-14 02:39:29 --> Loader Class Initialized
INFO - 2017-03-14 02:39:29 --> Database Driver Class Initialized
INFO - 2017-03-14 02:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:39:29 --> Controller Class Initialized
INFO - 2017-03-14 02:39:29 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:39:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:39:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:39:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:39:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:39:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:39:29 --> Final output sent to browser
DEBUG - 2017-03-14 02:39:29 --> Total execution time: 0.2660
INFO - 2017-03-14 02:40:25 --> Config Class Initialized
INFO - 2017-03-14 02:40:25 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:40:25 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:40:25 --> Utf8 Class Initialized
INFO - 2017-03-14 02:40:25 --> URI Class Initialized
DEBUG - 2017-03-14 02:40:25 --> No URI present. Default controller set.
INFO - 2017-03-14 02:40:25 --> Router Class Initialized
INFO - 2017-03-14 02:40:25 --> Output Class Initialized
INFO - 2017-03-14 02:40:25 --> Security Class Initialized
DEBUG - 2017-03-14 02:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:40:26 --> Input Class Initialized
INFO - 2017-03-14 02:40:26 --> Language Class Initialized
INFO - 2017-03-14 02:40:26 --> Loader Class Initialized
INFO - 2017-03-14 02:40:26 --> Database Driver Class Initialized
INFO - 2017-03-14 02:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:40:26 --> Controller Class Initialized
INFO - 2017-03-14 02:40:26 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:40:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:40:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:40:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:40:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:40:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:40:26 --> Final output sent to browser
DEBUG - 2017-03-14 02:40:26 --> Total execution time: 0.4674
INFO - 2017-03-14 02:46:24 --> Config Class Initialized
INFO - 2017-03-14 02:46:24 --> Hooks Class Initialized
DEBUG - 2017-03-14 02:46:24 --> UTF-8 Support Enabled
INFO - 2017-03-14 02:46:24 --> Utf8 Class Initialized
INFO - 2017-03-14 02:46:24 --> URI Class Initialized
DEBUG - 2017-03-14 02:46:24 --> No URI present. Default controller set.
INFO - 2017-03-14 02:46:24 --> Router Class Initialized
INFO - 2017-03-14 02:46:24 --> Output Class Initialized
INFO - 2017-03-14 02:46:24 --> Security Class Initialized
DEBUG - 2017-03-14 02:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 02:46:24 --> Input Class Initialized
INFO - 2017-03-14 02:46:24 --> Language Class Initialized
INFO - 2017-03-14 02:46:24 --> Loader Class Initialized
INFO - 2017-03-14 02:46:25 --> Database Driver Class Initialized
INFO - 2017-03-14 02:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 02:46:25 --> Controller Class Initialized
INFO - 2017-03-14 02:46:25 --> Helper loaded: url_helper
DEBUG - 2017-03-14 02:46:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 02:46:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 02:46:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 02:46:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 02:46:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 02:46:25 --> Final output sent to browser
DEBUG - 2017-03-14 02:46:25 --> Total execution time: 1.4655
INFO - 2017-03-14 03:06:21 --> Config Class Initialized
INFO - 2017-03-14 03:06:21 --> Hooks Class Initialized
DEBUG - 2017-03-14 03:06:21 --> UTF-8 Support Enabled
INFO - 2017-03-14 03:06:21 --> Utf8 Class Initialized
INFO - 2017-03-14 03:06:21 --> URI Class Initialized
DEBUG - 2017-03-14 03:06:21 --> No URI present. Default controller set.
INFO - 2017-03-14 03:06:21 --> Router Class Initialized
INFO - 2017-03-14 03:06:21 --> Output Class Initialized
INFO - 2017-03-14 03:06:21 --> Security Class Initialized
DEBUG - 2017-03-14 03:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 03:06:21 --> Input Class Initialized
INFO - 2017-03-14 03:06:21 --> Language Class Initialized
INFO - 2017-03-14 03:06:21 --> Loader Class Initialized
INFO - 2017-03-14 03:06:21 --> Database Driver Class Initialized
INFO - 2017-03-14 03:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 03:06:22 --> Controller Class Initialized
INFO - 2017-03-14 03:06:22 --> Helper loaded: url_helper
DEBUG - 2017-03-14 03:06:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 03:06:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 03:06:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 03:06:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 03:06:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 03:06:22 --> Final output sent to browser
DEBUG - 2017-03-14 03:06:22 --> Total execution time: 1.2844
INFO - 2017-03-14 03:06:28 --> Config Class Initialized
INFO - 2017-03-14 03:06:28 --> Hooks Class Initialized
DEBUG - 2017-03-14 03:06:28 --> UTF-8 Support Enabled
INFO - 2017-03-14 03:06:28 --> Utf8 Class Initialized
INFO - 2017-03-14 03:06:28 --> URI Class Initialized
INFO - 2017-03-14 03:06:28 --> Router Class Initialized
INFO - 2017-03-14 03:06:28 --> Output Class Initialized
INFO - 2017-03-14 03:06:28 --> Security Class Initialized
DEBUG - 2017-03-14 03:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 03:06:28 --> Input Class Initialized
INFO - 2017-03-14 03:06:28 --> Language Class Initialized
INFO - 2017-03-14 03:06:28 --> Loader Class Initialized
INFO - 2017-03-14 03:06:29 --> Database Driver Class Initialized
INFO - 2017-03-14 03:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 03:06:29 --> Controller Class Initialized
INFO - 2017-03-14 03:06:29 --> Helper loaded: url_helper
DEBUG - 2017-03-14 03:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 03:06:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 03:06:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 03:06:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 03:06:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 03:06:29 --> Final output sent to browser
DEBUG - 2017-03-14 03:06:29 --> Total execution time: 1.3523
INFO - 2017-03-14 03:36:13 --> Config Class Initialized
INFO - 2017-03-14 03:36:13 --> Hooks Class Initialized
DEBUG - 2017-03-14 03:36:13 --> UTF-8 Support Enabled
INFO - 2017-03-14 03:36:13 --> Utf8 Class Initialized
INFO - 2017-03-14 03:36:13 --> URI Class Initialized
DEBUG - 2017-03-14 03:36:13 --> No URI present. Default controller set.
INFO - 2017-03-14 03:36:13 --> Router Class Initialized
INFO - 2017-03-14 03:36:13 --> Output Class Initialized
INFO - 2017-03-14 03:36:13 --> Security Class Initialized
DEBUG - 2017-03-14 03:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 03:36:13 --> Input Class Initialized
INFO - 2017-03-14 03:36:13 --> Language Class Initialized
INFO - 2017-03-14 03:36:13 --> Loader Class Initialized
INFO - 2017-03-14 03:36:14 --> Database Driver Class Initialized
INFO - 2017-03-14 03:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 03:36:14 --> Controller Class Initialized
INFO - 2017-03-14 03:36:14 --> Helper loaded: url_helper
DEBUG - 2017-03-14 03:36:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 03:36:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 03:36:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 03:36:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 03:36:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 03:36:14 --> Final output sent to browser
DEBUG - 2017-03-14 03:36:14 --> Total execution time: 1.2127
INFO - 2017-03-14 03:37:17 --> Config Class Initialized
INFO - 2017-03-14 03:37:17 --> Hooks Class Initialized
DEBUG - 2017-03-14 03:37:17 --> UTF-8 Support Enabled
INFO - 2017-03-14 03:37:17 --> Utf8 Class Initialized
INFO - 2017-03-14 03:37:17 --> URI Class Initialized
INFO - 2017-03-14 03:37:18 --> Router Class Initialized
INFO - 2017-03-14 03:37:18 --> Output Class Initialized
INFO - 2017-03-14 03:37:18 --> Security Class Initialized
DEBUG - 2017-03-14 03:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 03:37:18 --> Input Class Initialized
INFO - 2017-03-14 03:37:18 --> Language Class Initialized
INFO - 2017-03-14 03:37:18 --> Loader Class Initialized
INFO - 2017-03-14 03:37:18 --> Database Driver Class Initialized
INFO - 2017-03-14 03:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 03:37:18 --> Controller Class Initialized
INFO - 2017-03-14 03:37:18 --> Helper loaded: url_helper
DEBUG - 2017-03-14 03:37:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 03:37:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 03:37:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 03:37:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 03:37:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 03:37:19 --> Final output sent to browser
DEBUG - 2017-03-14 03:37:19 --> Total execution time: 1.2154
INFO - 2017-03-14 03:37:20 --> Config Class Initialized
INFO - 2017-03-14 03:37:20 --> Hooks Class Initialized
DEBUG - 2017-03-14 03:37:20 --> UTF-8 Support Enabled
INFO - 2017-03-14 03:37:20 --> Utf8 Class Initialized
INFO - 2017-03-14 03:37:20 --> URI Class Initialized
INFO - 2017-03-14 03:37:20 --> Router Class Initialized
INFO - 2017-03-14 03:37:20 --> Output Class Initialized
INFO - 2017-03-14 03:37:20 --> Security Class Initialized
DEBUG - 2017-03-14 03:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 03:37:20 --> Input Class Initialized
INFO - 2017-03-14 03:37:20 --> Language Class Initialized
INFO - 2017-03-14 03:37:20 --> Loader Class Initialized
INFO - 2017-03-14 03:37:20 --> Database Driver Class Initialized
INFO - 2017-03-14 03:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 03:37:20 --> Controller Class Initialized
INFO - 2017-03-14 03:37:20 --> Helper loaded: url_helper
DEBUG - 2017-03-14 03:37:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-14 03:37:22 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-14 03:37:22 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Ivon Es')
INFO - 2017-03-14 03:37:22 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-14 03:37:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-14 03:37:25 --> Config Class Initialized
INFO - 2017-03-14 03:37:25 --> Hooks Class Initialized
DEBUG - 2017-03-14 03:37:25 --> UTF-8 Support Enabled
INFO - 2017-03-14 03:37:25 --> Utf8 Class Initialized
INFO - 2017-03-14 03:37:25 --> URI Class Initialized
INFO - 2017-03-14 03:37:25 --> Router Class Initialized
INFO - 2017-03-14 03:37:25 --> Output Class Initialized
INFO - 2017-03-14 03:37:25 --> Security Class Initialized
DEBUG - 2017-03-14 03:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 03:37:25 --> Input Class Initialized
INFO - 2017-03-14 03:37:25 --> Language Class Initialized
INFO - 2017-03-14 03:37:25 --> Loader Class Initialized
INFO - 2017-03-14 03:37:25 --> Database Driver Class Initialized
INFO - 2017-03-14 03:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 03:37:25 --> Controller Class Initialized
INFO - 2017-03-14 03:37:25 --> Helper loaded: url_helper
DEBUG - 2017-03-14 03:37:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-14 03:37:25 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-14 03:37:25 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Ivon Es')
INFO - 2017-03-14 03:37:25 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-14 03:37:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-14 03:37:34 --> Config Class Initialized
INFO - 2017-03-14 03:37:34 --> Hooks Class Initialized
DEBUG - 2017-03-14 03:37:34 --> UTF-8 Support Enabled
INFO - 2017-03-14 03:37:34 --> Utf8 Class Initialized
INFO - 2017-03-14 03:37:34 --> URI Class Initialized
INFO - 2017-03-14 03:37:34 --> Router Class Initialized
INFO - 2017-03-14 03:37:34 --> Output Class Initialized
INFO - 2017-03-14 03:37:34 --> Security Class Initialized
DEBUG - 2017-03-14 03:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 03:37:34 --> Input Class Initialized
INFO - 2017-03-14 03:37:34 --> Language Class Initialized
INFO - 2017-03-14 03:37:34 --> Loader Class Initialized
INFO - 2017-03-14 03:37:34 --> Database Driver Class Initialized
INFO - 2017-03-14 03:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 03:37:34 --> Controller Class Initialized
INFO - 2017-03-14 03:37:34 --> Helper loaded: url_helper
DEBUG - 2017-03-14 03:37:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 03:37:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 03:37:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 03:37:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 03:37:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 03:37:34 --> Final output sent to browser
DEBUG - 2017-03-14 03:37:34 --> Total execution time: 0.0142
INFO - 2017-03-14 03:37:54 --> Config Class Initialized
INFO - 2017-03-14 03:37:54 --> Hooks Class Initialized
DEBUG - 2017-03-14 03:37:54 --> UTF-8 Support Enabled
INFO - 2017-03-14 03:37:54 --> Utf8 Class Initialized
INFO - 2017-03-14 03:37:54 --> URI Class Initialized
INFO - 2017-03-14 03:37:54 --> Router Class Initialized
INFO - 2017-03-14 03:37:54 --> Output Class Initialized
INFO - 2017-03-14 03:37:54 --> Security Class Initialized
DEBUG - 2017-03-14 03:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 03:37:54 --> Input Class Initialized
INFO - 2017-03-14 03:37:54 --> Language Class Initialized
INFO - 2017-03-14 03:37:54 --> Loader Class Initialized
INFO - 2017-03-14 03:37:54 --> Database Driver Class Initialized
INFO - 2017-03-14 03:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 03:37:54 --> Controller Class Initialized
INFO - 2017-03-14 03:37:54 --> Helper loaded: url_helper
DEBUG - 2017-03-14 03:37:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-14 03:37:54 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-14 03:37:54 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Ivon Es')
INFO - 2017-03-14 03:37:54 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-14 03:37:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-14 03:37:55 --> Config Class Initialized
INFO - 2017-03-14 03:37:55 --> Hooks Class Initialized
DEBUG - 2017-03-14 03:37:55 --> UTF-8 Support Enabled
INFO - 2017-03-14 03:37:55 --> Utf8 Class Initialized
INFO - 2017-03-14 03:37:55 --> URI Class Initialized
INFO - 2017-03-14 03:37:55 --> Router Class Initialized
INFO - 2017-03-14 03:37:55 --> Output Class Initialized
INFO - 2017-03-14 03:37:55 --> Security Class Initialized
DEBUG - 2017-03-14 03:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 03:37:55 --> Input Class Initialized
INFO - 2017-03-14 03:37:55 --> Language Class Initialized
INFO - 2017-03-14 03:37:55 --> Loader Class Initialized
INFO - 2017-03-14 03:37:55 --> Database Driver Class Initialized
INFO - 2017-03-14 03:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 03:37:55 --> Controller Class Initialized
INFO - 2017-03-14 03:37:55 --> Helper loaded: url_helper
DEBUG - 2017-03-14 03:37:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 03:37:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 03:37:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 03:37:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 03:37:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 03:37:55 --> Final output sent to browser
DEBUG - 2017-03-14 03:37:55 --> Total execution time: 0.0144
INFO - 2017-03-14 03:38:01 --> Config Class Initialized
INFO - 2017-03-14 03:38:01 --> Hooks Class Initialized
DEBUG - 2017-03-14 03:38:01 --> UTF-8 Support Enabled
INFO - 2017-03-14 03:38:01 --> Utf8 Class Initialized
INFO - 2017-03-14 03:38:01 --> URI Class Initialized
DEBUG - 2017-03-14 03:38:01 --> No URI present. Default controller set.
INFO - 2017-03-14 03:38:01 --> Router Class Initialized
INFO - 2017-03-14 03:38:01 --> Output Class Initialized
INFO - 2017-03-14 03:38:01 --> Security Class Initialized
DEBUG - 2017-03-14 03:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 03:38:01 --> Input Class Initialized
INFO - 2017-03-14 03:38:01 --> Language Class Initialized
INFO - 2017-03-14 03:38:01 --> Loader Class Initialized
INFO - 2017-03-14 03:38:01 --> Database Driver Class Initialized
INFO - 2017-03-14 03:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 03:38:01 --> Controller Class Initialized
INFO - 2017-03-14 03:38:01 --> Helper loaded: url_helper
DEBUG - 2017-03-14 03:38:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 03:38:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 03:38:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 03:38:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 03:38:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 03:38:01 --> Final output sent to browser
DEBUG - 2017-03-14 03:38:01 --> Total execution time: 0.0141
INFO - 2017-03-14 03:38:06 --> Config Class Initialized
INFO - 2017-03-14 03:38:06 --> Hooks Class Initialized
DEBUG - 2017-03-14 03:38:06 --> UTF-8 Support Enabled
INFO - 2017-03-14 03:38:06 --> Utf8 Class Initialized
INFO - 2017-03-14 03:38:06 --> URI Class Initialized
INFO - 2017-03-14 03:38:06 --> Router Class Initialized
INFO - 2017-03-14 03:38:06 --> Output Class Initialized
INFO - 2017-03-14 03:38:06 --> Security Class Initialized
DEBUG - 2017-03-14 03:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 03:38:06 --> Input Class Initialized
INFO - 2017-03-14 03:38:06 --> Language Class Initialized
INFO - 2017-03-14 03:38:06 --> Loader Class Initialized
INFO - 2017-03-14 03:38:06 --> Database Driver Class Initialized
INFO - 2017-03-14 03:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 03:38:06 --> Controller Class Initialized
INFO - 2017-03-14 03:38:06 --> Helper loaded: url_helper
DEBUG - 2017-03-14 03:38:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 03:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 03:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 03:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 03:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 03:38:06 --> Final output sent to browser
DEBUG - 2017-03-14 03:38:06 --> Total execution time: 0.0223
INFO - 2017-03-14 03:51:01 --> Config Class Initialized
INFO - 2017-03-14 03:51:01 --> Hooks Class Initialized
DEBUG - 2017-03-14 03:51:02 --> UTF-8 Support Enabled
INFO - 2017-03-14 03:51:02 --> Utf8 Class Initialized
INFO - 2017-03-14 03:51:02 --> URI Class Initialized
DEBUG - 2017-03-14 03:51:02 --> No URI present. Default controller set.
INFO - 2017-03-14 03:51:02 --> Router Class Initialized
INFO - 2017-03-14 03:51:02 --> Output Class Initialized
INFO - 2017-03-14 03:51:02 --> Security Class Initialized
DEBUG - 2017-03-14 03:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 03:51:02 --> Input Class Initialized
INFO - 2017-03-14 03:51:02 --> Language Class Initialized
INFO - 2017-03-14 03:51:02 --> Loader Class Initialized
INFO - 2017-03-14 03:51:02 --> Database Driver Class Initialized
INFO - 2017-03-14 03:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 03:51:02 --> Controller Class Initialized
INFO - 2017-03-14 03:51:02 --> Helper loaded: url_helper
DEBUG - 2017-03-14 03:51:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 03:51:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 03:51:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 03:51:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 03:51:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 03:51:03 --> Final output sent to browser
DEBUG - 2017-03-14 03:51:03 --> Total execution time: 1.2627
INFO - 2017-03-14 03:51:12 --> Config Class Initialized
INFO - 2017-03-14 03:51:12 --> Hooks Class Initialized
DEBUG - 2017-03-14 03:51:12 --> UTF-8 Support Enabled
INFO - 2017-03-14 03:51:12 --> Utf8 Class Initialized
INFO - 2017-03-14 03:51:12 --> URI Class Initialized
INFO - 2017-03-14 03:51:12 --> Router Class Initialized
INFO - 2017-03-14 03:51:12 --> Output Class Initialized
INFO - 2017-03-14 03:51:12 --> Security Class Initialized
DEBUG - 2017-03-14 03:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 03:51:12 --> Input Class Initialized
INFO - 2017-03-14 03:51:12 --> Language Class Initialized
INFO - 2017-03-14 03:51:12 --> Loader Class Initialized
INFO - 2017-03-14 03:51:12 --> Database Driver Class Initialized
INFO - 2017-03-14 03:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 03:51:13 --> Controller Class Initialized
INFO - 2017-03-14 03:51:13 --> Helper loaded: url_helper
DEBUG - 2017-03-14 03:51:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 03:51:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 03:51:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 03:51:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 03:51:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 03:51:13 --> Final output sent to browser
DEBUG - 2017-03-14 03:51:13 --> Total execution time: 1.2331
INFO - 2017-03-14 03:52:44 --> Config Class Initialized
INFO - 2017-03-14 03:52:44 --> Hooks Class Initialized
DEBUG - 2017-03-14 03:52:44 --> UTF-8 Support Enabled
INFO - 2017-03-14 03:52:44 --> Utf8 Class Initialized
INFO - 2017-03-14 03:52:44 --> URI Class Initialized
INFO - 2017-03-14 03:52:44 --> Router Class Initialized
INFO - 2017-03-14 03:52:45 --> Output Class Initialized
INFO - 2017-03-14 03:52:45 --> Security Class Initialized
DEBUG - 2017-03-14 03:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 03:52:45 --> Input Class Initialized
INFO - 2017-03-14 03:52:45 --> Language Class Initialized
INFO - 2017-03-14 03:52:45 --> Loader Class Initialized
INFO - 2017-03-14 03:52:45 --> Database Driver Class Initialized
INFO - 2017-03-14 03:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 03:52:45 --> Controller Class Initialized
INFO - 2017-03-14 03:52:45 --> Helper loaded: url_helper
DEBUG - 2017-03-14 03:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 03:52:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-14 03:52:45 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-14 03:52:45 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-14 03:52:45 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-14 03:52:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 03:52:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 03:52:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 03:52:45 --> Final output sent to browser
DEBUG - 2017-03-14 03:52:45 --> Total execution time: 1.2094
INFO - 2017-03-14 03:52:47 --> Config Class Initialized
INFO - 2017-03-14 03:52:47 --> Hooks Class Initialized
DEBUG - 2017-03-14 03:52:47 --> UTF-8 Support Enabled
INFO - 2017-03-14 03:52:47 --> Utf8 Class Initialized
INFO - 2017-03-14 03:52:47 --> URI Class Initialized
INFO - 2017-03-14 03:52:47 --> Router Class Initialized
INFO - 2017-03-14 03:52:47 --> Output Class Initialized
INFO - 2017-03-14 03:52:47 --> Security Class Initialized
DEBUG - 2017-03-14 03:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 03:52:47 --> Input Class Initialized
INFO - 2017-03-14 03:52:47 --> Language Class Initialized
INFO - 2017-03-14 03:52:47 --> Loader Class Initialized
INFO - 2017-03-14 03:52:47 --> Database Driver Class Initialized
INFO - 2017-03-14 03:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 03:52:47 --> Controller Class Initialized
INFO - 2017-03-14 03:52:47 --> Helper loaded: url_helper
DEBUG - 2017-03-14 03:52:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 03:52:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 03:52:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 03:52:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 03:52:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 03:52:47 --> Final output sent to browser
DEBUG - 2017-03-14 03:52:47 --> Total execution time: 0.0146
INFO - 2017-03-14 03:55:27 --> Config Class Initialized
INFO - 2017-03-14 03:55:27 --> Hooks Class Initialized
DEBUG - 2017-03-14 03:55:27 --> UTF-8 Support Enabled
INFO - 2017-03-14 03:55:27 --> Utf8 Class Initialized
INFO - 2017-03-14 03:55:27 --> URI Class Initialized
DEBUG - 2017-03-14 03:55:28 --> No URI present. Default controller set.
INFO - 2017-03-14 03:55:28 --> Router Class Initialized
INFO - 2017-03-14 03:55:28 --> Output Class Initialized
INFO - 2017-03-14 03:55:28 --> Security Class Initialized
DEBUG - 2017-03-14 03:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 03:55:28 --> Input Class Initialized
INFO - 2017-03-14 03:55:28 --> Language Class Initialized
INFO - 2017-03-14 03:55:28 --> Loader Class Initialized
INFO - 2017-03-14 03:55:28 --> Database Driver Class Initialized
INFO - 2017-03-14 03:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 03:55:28 --> Controller Class Initialized
INFO - 2017-03-14 03:55:28 --> Helper loaded: url_helper
DEBUG - 2017-03-14 03:55:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 03:55:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 03:55:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 03:55:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 03:55:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 03:55:29 --> Final output sent to browser
DEBUG - 2017-03-14 03:55:29 --> Total execution time: 1.2166
INFO - 2017-03-14 03:55:57 --> Config Class Initialized
INFO - 2017-03-14 03:55:57 --> Hooks Class Initialized
DEBUG - 2017-03-14 03:55:57 --> UTF-8 Support Enabled
INFO - 2017-03-14 03:55:57 --> Utf8 Class Initialized
INFO - 2017-03-14 03:55:57 --> URI Class Initialized
INFO - 2017-03-14 03:55:58 --> Router Class Initialized
INFO - 2017-03-14 03:55:58 --> Output Class Initialized
INFO - 2017-03-14 03:55:58 --> Security Class Initialized
DEBUG - 2017-03-14 03:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 03:55:58 --> Input Class Initialized
INFO - 2017-03-14 03:55:58 --> Language Class Initialized
INFO - 2017-03-14 03:55:58 --> Loader Class Initialized
INFO - 2017-03-14 03:55:58 --> Database Driver Class Initialized
INFO - 2017-03-14 03:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 03:55:58 --> Controller Class Initialized
INFO - 2017-03-14 03:55:58 --> Helper loaded: url_helper
DEBUG - 2017-03-14 03:55:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 03:56:00 --> Config Class Initialized
INFO - 2017-03-14 03:56:00 --> Hooks Class Initialized
DEBUG - 2017-03-14 03:56:00 --> UTF-8 Support Enabled
INFO - 2017-03-14 03:56:00 --> Utf8 Class Initialized
INFO - 2017-03-14 03:56:00 --> URI Class Initialized
INFO - 2017-03-14 03:56:00 --> Router Class Initialized
INFO - 2017-03-14 03:56:00 --> Output Class Initialized
INFO - 2017-03-14 03:56:00 --> Security Class Initialized
DEBUG - 2017-03-14 03:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 03:56:00 --> Input Class Initialized
INFO - 2017-03-14 03:56:00 --> Language Class Initialized
INFO - 2017-03-14 03:56:00 --> Loader Class Initialized
INFO - 2017-03-14 03:56:00 --> Database Driver Class Initialized
INFO - 2017-03-14 03:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 03:56:00 --> Controller Class Initialized
INFO - 2017-03-14 03:56:00 --> Helper loaded: date_helper
DEBUG - 2017-03-14 03:56:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 03:56:00 --> Helper loaded: url_helper
INFO - 2017-03-14 03:56:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 03:56:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 03:56:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 03:56:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 03:56:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 03:56:00 --> Final output sent to browser
DEBUG - 2017-03-14 03:56:00 --> Total execution time: 0.1022
INFO - 2017-03-14 04:04:31 --> Config Class Initialized
INFO - 2017-03-14 04:04:31 --> Hooks Class Initialized
DEBUG - 2017-03-14 04:04:31 --> UTF-8 Support Enabled
INFO - 2017-03-14 04:04:31 --> Utf8 Class Initialized
INFO - 2017-03-14 04:04:31 --> URI Class Initialized
INFO - 2017-03-14 04:04:31 --> Router Class Initialized
INFO - 2017-03-14 04:04:31 --> Output Class Initialized
INFO - 2017-03-14 04:04:31 --> Security Class Initialized
DEBUG - 2017-03-14 04:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 04:04:31 --> Input Class Initialized
INFO - 2017-03-14 04:04:31 --> Language Class Initialized
INFO - 2017-03-14 04:04:31 --> Loader Class Initialized
INFO - 2017-03-14 04:04:31 --> Database Driver Class Initialized
INFO - 2017-03-14 04:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 04:04:32 --> Controller Class Initialized
INFO - 2017-03-14 04:04:32 --> Helper loaded: url_helper
DEBUG - 2017-03-14 04:04:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 04:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-14 04:04:32 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-14 04:04:32 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-14 04:04:32 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-14 04:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 04:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 04:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 04:04:32 --> Final output sent to browser
DEBUG - 2017-03-14 04:04:32 --> Total execution time: 1.4994
INFO - 2017-03-14 04:55:54 --> Config Class Initialized
INFO - 2017-03-14 04:55:54 --> Hooks Class Initialized
DEBUG - 2017-03-14 04:55:54 --> UTF-8 Support Enabled
INFO - 2017-03-14 04:55:54 --> Utf8 Class Initialized
INFO - 2017-03-14 04:55:54 --> URI Class Initialized
DEBUG - 2017-03-14 04:55:54 --> No URI present. Default controller set.
INFO - 2017-03-14 04:55:54 --> Router Class Initialized
INFO - 2017-03-14 04:55:54 --> Output Class Initialized
INFO - 2017-03-14 04:55:54 --> Security Class Initialized
DEBUG - 2017-03-14 04:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 04:55:54 --> Input Class Initialized
INFO - 2017-03-14 04:55:54 --> Language Class Initialized
INFO - 2017-03-14 04:55:54 --> Loader Class Initialized
INFO - 2017-03-14 04:55:55 --> Database Driver Class Initialized
INFO - 2017-03-14 04:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 04:55:55 --> Controller Class Initialized
INFO - 2017-03-14 04:55:55 --> Helper loaded: url_helper
DEBUG - 2017-03-14 04:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 04:55:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 04:55:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 04:55:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 04:55:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 04:55:55 --> Final output sent to browser
DEBUG - 2017-03-14 04:55:55 --> Total execution time: 1.2071
INFO - 2017-03-14 04:56:20 --> Config Class Initialized
INFO - 2017-03-14 04:56:20 --> Hooks Class Initialized
DEBUG - 2017-03-14 04:56:20 --> UTF-8 Support Enabled
INFO - 2017-03-14 04:56:20 --> Utf8 Class Initialized
INFO - 2017-03-14 04:56:20 --> URI Class Initialized
INFO - 2017-03-14 04:56:20 --> Router Class Initialized
INFO - 2017-03-14 04:56:20 --> Output Class Initialized
INFO - 2017-03-14 04:56:20 --> Security Class Initialized
DEBUG - 2017-03-14 04:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 04:56:20 --> Input Class Initialized
INFO - 2017-03-14 04:56:20 --> Language Class Initialized
INFO - 2017-03-14 04:56:20 --> Loader Class Initialized
INFO - 2017-03-14 04:56:20 --> Database Driver Class Initialized
INFO - 2017-03-14 04:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 04:56:20 --> Controller Class Initialized
INFO - 2017-03-14 04:56:20 --> Helper loaded: url_helper
DEBUG - 2017-03-14 04:56:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 04:56:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-14 04:56:20 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-14 04:56:20 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-14 04:56:20 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-14 04:56:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 04:56:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 04:56:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 04:56:20 --> Final output sent to browser
DEBUG - 2017-03-14 04:56:20 --> Total execution time: 0.0356
INFO - 2017-03-14 04:59:20 --> Config Class Initialized
INFO - 2017-03-14 04:59:20 --> Hooks Class Initialized
DEBUG - 2017-03-14 04:59:20 --> UTF-8 Support Enabled
INFO - 2017-03-14 04:59:20 --> Utf8 Class Initialized
INFO - 2017-03-14 04:59:20 --> URI Class Initialized
INFO - 2017-03-14 04:59:20 --> Router Class Initialized
INFO - 2017-03-14 04:59:20 --> Output Class Initialized
INFO - 2017-03-14 04:59:20 --> Security Class Initialized
DEBUG - 2017-03-14 04:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 04:59:21 --> Input Class Initialized
INFO - 2017-03-14 04:59:21 --> Language Class Initialized
INFO - 2017-03-14 04:59:21 --> Loader Class Initialized
INFO - 2017-03-14 04:59:21 --> Database Driver Class Initialized
INFO - 2017-03-14 04:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 04:59:21 --> Controller Class Initialized
INFO - 2017-03-14 04:59:21 --> Helper loaded: url_helper
DEBUG - 2017-03-14 04:59:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 04:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 04:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 04:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 04:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 04:59:21 --> Final output sent to browser
DEBUG - 2017-03-14 04:59:21 --> Total execution time: 1.2126
INFO - 2017-03-14 04:59:21 --> Config Class Initialized
INFO - 2017-03-14 04:59:21 --> Hooks Class Initialized
DEBUG - 2017-03-14 04:59:21 --> UTF-8 Support Enabled
INFO - 2017-03-14 04:59:21 --> Utf8 Class Initialized
INFO - 2017-03-14 04:59:21 --> URI Class Initialized
DEBUG - 2017-03-14 04:59:21 --> No URI present. Default controller set.
INFO - 2017-03-14 04:59:21 --> Router Class Initialized
INFO - 2017-03-14 04:59:21 --> Output Class Initialized
INFO - 2017-03-14 04:59:21 --> Security Class Initialized
DEBUG - 2017-03-14 04:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 04:59:21 --> Input Class Initialized
INFO - 2017-03-14 04:59:21 --> Language Class Initialized
INFO - 2017-03-14 04:59:21 --> Loader Class Initialized
INFO - 2017-03-14 04:59:21 --> Database Driver Class Initialized
INFO - 2017-03-14 04:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 04:59:21 --> Controller Class Initialized
INFO - 2017-03-14 04:59:21 --> Helper loaded: url_helper
DEBUG - 2017-03-14 04:59:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 04:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 04:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 04:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 04:59:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 04:59:21 --> Final output sent to browser
DEBUG - 2017-03-14 04:59:21 --> Total execution time: 0.0133
INFO - 2017-03-14 05:01:05 --> Config Class Initialized
INFO - 2017-03-14 05:01:05 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:01:05 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:01:05 --> Utf8 Class Initialized
INFO - 2017-03-14 05:01:05 --> URI Class Initialized
INFO - 2017-03-14 05:01:05 --> Router Class Initialized
INFO - 2017-03-14 05:01:05 --> Output Class Initialized
INFO - 2017-03-14 05:01:05 --> Security Class Initialized
DEBUG - 2017-03-14 05:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:01:05 --> Input Class Initialized
INFO - 2017-03-14 05:01:05 --> Language Class Initialized
INFO - 2017-03-14 05:01:05 --> Loader Class Initialized
INFO - 2017-03-14 05:01:06 --> Database Driver Class Initialized
INFO - 2017-03-14 05:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:01:06 --> Controller Class Initialized
INFO - 2017-03-14 05:01:06 --> Helper loaded: url_helper
DEBUG - 2017-03-14 05:01:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:01:09 --> Config Class Initialized
INFO - 2017-03-14 05:01:09 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:01:09 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:01:09 --> Utf8 Class Initialized
INFO - 2017-03-14 05:01:09 --> URI Class Initialized
INFO - 2017-03-14 05:01:09 --> Router Class Initialized
INFO - 2017-03-14 05:01:09 --> Output Class Initialized
INFO - 2017-03-14 05:01:09 --> Security Class Initialized
DEBUG - 2017-03-14 05:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:01:09 --> Input Class Initialized
INFO - 2017-03-14 05:01:09 --> Language Class Initialized
INFO - 2017-03-14 05:01:09 --> Loader Class Initialized
INFO - 2017-03-14 05:01:09 --> Database Driver Class Initialized
INFO - 2017-03-14 05:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:01:10 --> Controller Class Initialized
INFO - 2017-03-14 05:01:10 --> Helper loaded: date_helper
DEBUG - 2017-03-14 05:01:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:01:10 --> Helper loaded: url_helper
INFO - 2017-03-14 05:01:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 05:01:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 05:01:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 05:01:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 05:01:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 05:01:10 --> Final output sent to browser
DEBUG - 2017-03-14 05:01:10 --> Total execution time: 1.1324
INFO - 2017-03-14 05:06:04 --> Config Class Initialized
INFO - 2017-03-14 05:06:04 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:06:04 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:06:04 --> Utf8 Class Initialized
INFO - 2017-03-14 05:06:04 --> URI Class Initialized
DEBUG - 2017-03-14 05:06:04 --> No URI present. Default controller set.
INFO - 2017-03-14 05:06:04 --> Router Class Initialized
INFO - 2017-03-14 05:06:04 --> Output Class Initialized
INFO - 2017-03-14 05:06:04 --> Security Class Initialized
DEBUG - 2017-03-14 05:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:06:04 --> Input Class Initialized
INFO - 2017-03-14 05:06:04 --> Language Class Initialized
INFO - 2017-03-14 05:06:04 --> Loader Class Initialized
INFO - 2017-03-14 05:06:05 --> Database Driver Class Initialized
INFO - 2017-03-14 05:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:06:05 --> Controller Class Initialized
INFO - 2017-03-14 05:06:05 --> Helper loaded: url_helper
DEBUG - 2017-03-14 05:06:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:06:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 05:06:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 05:06:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 05:06:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 05:06:05 --> Final output sent to browser
DEBUG - 2017-03-14 05:06:05 --> Total execution time: 1.2827
INFO - 2017-03-14 05:09:23 --> Config Class Initialized
INFO - 2017-03-14 05:09:23 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:09:23 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:09:23 --> Utf8 Class Initialized
INFO - 2017-03-14 05:09:23 --> URI Class Initialized
INFO - 2017-03-14 05:09:23 --> Router Class Initialized
INFO - 2017-03-14 05:09:23 --> Output Class Initialized
INFO - 2017-03-14 05:09:23 --> Security Class Initialized
DEBUG - 2017-03-14 05:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:09:23 --> Input Class Initialized
INFO - 2017-03-14 05:09:23 --> Language Class Initialized
INFO - 2017-03-14 05:09:23 --> Loader Class Initialized
INFO - 2017-03-14 05:09:24 --> Database Driver Class Initialized
INFO - 2017-03-14 05:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:09:24 --> Controller Class Initialized
INFO - 2017-03-14 05:09:24 --> Helper loaded: url_helper
DEBUG - 2017-03-14 05:09:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:09:28 --> Config Class Initialized
INFO - 2017-03-14 05:09:28 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:09:28 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:09:28 --> Utf8 Class Initialized
INFO - 2017-03-14 05:09:28 --> URI Class Initialized
INFO - 2017-03-14 05:09:28 --> Router Class Initialized
INFO - 2017-03-14 05:09:28 --> Output Class Initialized
INFO - 2017-03-14 05:09:28 --> Security Class Initialized
DEBUG - 2017-03-14 05:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:09:29 --> Input Class Initialized
INFO - 2017-03-14 05:09:29 --> Language Class Initialized
INFO - 2017-03-14 05:09:29 --> Loader Class Initialized
INFO - 2017-03-14 05:09:29 --> Database Driver Class Initialized
INFO - 2017-03-14 05:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:09:29 --> Controller Class Initialized
INFO - 2017-03-14 05:09:29 --> Helper loaded: url_helper
DEBUG - 2017-03-14 05:09:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:09:30 --> Config Class Initialized
INFO - 2017-03-14 05:09:30 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:09:30 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:09:30 --> Utf8 Class Initialized
INFO - 2017-03-14 05:09:30 --> URI Class Initialized
INFO - 2017-03-14 05:09:30 --> Router Class Initialized
INFO - 2017-03-14 05:09:30 --> Output Class Initialized
INFO - 2017-03-14 05:09:30 --> Security Class Initialized
DEBUG - 2017-03-14 05:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:09:30 --> Input Class Initialized
INFO - 2017-03-14 05:09:30 --> Language Class Initialized
INFO - 2017-03-14 05:09:30 --> Loader Class Initialized
INFO - 2017-03-14 05:09:30 --> Database Driver Class Initialized
INFO - 2017-03-14 05:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:09:31 --> Controller Class Initialized
INFO - 2017-03-14 05:09:31 --> Helper loaded: url_helper
DEBUG - 2017-03-14 05:09:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:09:31 --> Config Class Initialized
INFO - 2017-03-14 05:09:31 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:09:31 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:09:31 --> Utf8 Class Initialized
INFO - 2017-03-14 05:09:31 --> URI Class Initialized
INFO - 2017-03-14 05:09:31 --> Router Class Initialized
INFO - 2017-03-14 05:09:31 --> Output Class Initialized
INFO - 2017-03-14 05:09:31 --> Security Class Initialized
DEBUG - 2017-03-14 05:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:09:31 --> Input Class Initialized
INFO - 2017-03-14 05:09:31 --> Language Class Initialized
INFO - 2017-03-14 05:09:31 --> Loader Class Initialized
INFO - 2017-03-14 05:09:31 --> Database Driver Class Initialized
INFO - 2017-03-14 05:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:09:31 --> Controller Class Initialized
INFO - 2017-03-14 05:09:31 --> Helper loaded: date_helper
DEBUG - 2017-03-14 05:09:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:09:31 --> Helper loaded: url_helper
INFO - 2017-03-14 05:09:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 05:09:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 05:09:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 05:09:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 05:09:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 05:09:31 --> Final output sent to browser
DEBUG - 2017-03-14 05:09:31 --> Total execution time: 0.1432
INFO - 2017-03-14 05:09:32 --> Config Class Initialized
INFO - 2017-03-14 05:09:32 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:09:32 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:09:32 --> Utf8 Class Initialized
INFO - 2017-03-14 05:09:32 --> URI Class Initialized
INFO - 2017-03-14 05:09:32 --> Router Class Initialized
INFO - 2017-03-14 05:09:32 --> Output Class Initialized
INFO - 2017-03-14 05:09:32 --> Security Class Initialized
DEBUG - 2017-03-14 05:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:09:32 --> Input Class Initialized
INFO - 2017-03-14 05:09:32 --> Language Class Initialized
INFO - 2017-03-14 05:09:32 --> Loader Class Initialized
INFO - 2017-03-14 05:09:32 --> Database Driver Class Initialized
INFO - 2017-03-14 05:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:09:32 --> Controller Class Initialized
INFO - 2017-03-14 05:09:32 --> Helper loaded: url_helper
DEBUG - 2017-03-14 05:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:09:33 --> Config Class Initialized
INFO - 2017-03-14 05:09:33 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:09:33 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:09:33 --> Utf8 Class Initialized
INFO - 2017-03-14 05:09:33 --> URI Class Initialized
INFO - 2017-03-14 05:09:33 --> Router Class Initialized
INFO - 2017-03-14 05:09:33 --> Output Class Initialized
INFO - 2017-03-14 05:09:33 --> Security Class Initialized
DEBUG - 2017-03-14 05:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:09:33 --> Input Class Initialized
INFO - 2017-03-14 05:09:33 --> Language Class Initialized
INFO - 2017-03-14 05:09:33 --> Loader Class Initialized
INFO - 2017-03-14 05:09:33 --> Database Driver Class Initialized
INFO - 2017-03-14 05:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:09:33 --> Controller Class Initialized
INFO - 2017-03-14 05:09:33 --> Helper loaded: date_helper
DEBUG - 2017-03-14 05:09:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:09:33 --> Helper loaded: url_helper
INFO - 2017-03-14 05:09:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 05:09:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 05:09:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 05:09:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 05:09:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 05:09:33 --> Final output sent to browser
DEBUG - 2017-03-14 05:09:33 --> Total execution time: 0.4597
INFO - 2017-03-14 05:09:34 --> Config Class Initialized
INFO - 2017-03-14 05:09:34 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:09:35 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:09:35 --> Utf8 Class Initialized
INFO - 2017-03-14 05:09:35 --> URI Class Initialized
INFO - 2017-03-14 05:09:35 --> Router Class Initialized
INFO - 2017-03-14 05:09:35 --> Output Class Initialized
INFO - 2017-03-14 05:09:35 --> Security Class Initialized
DEBUG - 2017-03-14 05:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:09:35 --> Input Class Initialized
INFO - 2017-03-14 05:09:35 --> Language Class Initialized
INFO - 2017-03-14 05:09:35 --> Loader Class Initialized
INFO - 2017-03-14 05:09:35 --> Database Driver Class Initialized
INFO - 2017-03-14 05:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:09:35 --> Controller Class Initialized
INFO - 2017-03-14 05:09:35 --> Helper loaded: url_helper
DEBUG - 2017-03-14 05:09:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:09:37 --> Config Class Initialized
INFO - 2017-03-14 05:09:37 --> Hooks Class Initialized
INFO - 2017-03-14 05:09:38 --> Config Class Initialized
INFO - 2017-03-14 05:09:38 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:09:38 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:09:38 --> Utf8 Class Initialized
DEBUG - 2017-03-14 05:09:38 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:09:38 --> Utf8 Class Initialized
INFO - 2017-03-14 05:09:38 --> URI Class Initialized
INFO - 2017-03-14 05:09:38 --> URI Class Initialized
INFO - 2017-03-14 05:09:38 --> Router Class Initialized
INFO - 2017-03-14 05:09:38 --> Router Class Initialized
INFO - 2017-03-14 05:09:38 --> Output Class Initialized
INFO - 2017-03-14 05:09:38 --> Output Class Initialized
INFO - 2017-03-14 05:09:38 --> Security Class Initialized
INFO - 2017-03-14 05:09:38 --> Security Class Initialized
DEBUG - 2017-03-14 05:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:09:38 --> Input Class Initialized
INFO - 2017-03-14 05:09:38 --> Language Class Initialized
DEBUG - 2017-03-14 05:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:09:38 --> Input Class Initialized
INFO - 2017-03-14 05:09:38 --> Language Class Initialized
INFO - 2017-03-14 05:09:38 --> Loader Class Initialized
INFO - 2017-03-14 05:09:38 --> Loader Class Initialized
INFO - 2017-03-14 05:09:38 --> Database Driver Class Initialized
INFO - 2017-03-14 05:09:38 --> Database Driver Class Initialized
INFO - 2017-03-14 05:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:09:38 --> Controller Class Initialized
INFO - 2017-03-14 05:09:38 --> Helper loaded: date_helper
DEBUG - 2017-03-14 05:09:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:09:38 --> Helper loaded: url_helper
INFO - 2017-03-14 05:09:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 05:09:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 05:09:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 05:09:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 05:09:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 05:09:39 --> Final output sent to browser
DEBUG - 2017-03-14 05:09:39 --> Total execution time: 1.1134
INFO - 2017-03-14 05:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:09:39 --> Controller Class Initialized
INFO - 2017-03-14 05:09:39 --> Helper loaded: date_helper
DEBUG - 2017-03-14 05:09:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:09:39 --> Helper loaded: url_helper
INFO - 2017-03-14 05:09:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 05:09:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 05:09:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 05:09:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 05:09:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 05:09:39 --> Final output sent to browser
DEBUG - 2017-03-14 05:09:39 --> Total execution time: 1.8064
INFO - 2017-03-14 05:11:02 --> Config Class Initialized
INFO - 2017-03-14 05:11:02 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:11:02 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:11:02 --> Utf8 Class Initialized
INFO - 2017-03-14 05:11:02 --> URI Class Initialized
INFO - 2017-03-14 05:11:02 --> Router Class Initialized
INFO - 2017-03-14 05:11:02 --> Output Class Initialized
INFO - 2017-03-14 05:11:02 --> Security Class Initialized
DEBUG - 2017-03-14 05:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:11:03 --> Input Class Initialized
INFO - 2017-03-14 05:11:03 --> Language Class Initialized
INFO - 2017-03-14 05:11:03 --> Loader Class Initialized
INFO - 2017-03-14 05:11:03 --> Database Driver Class Initialized
INFO - 2017-03-14 05:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:11:03 --> Controller Class Initialized
INFO - 2017-03-14 05:11:03 --> Helper loaded: url_helper
DEBUG - 2017-03-14 05:11:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:11:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 05:11:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 05:11:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 05:11:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 05:11:04 --> Final output sent to browser
DEBUG - 2017-03-14 05:11:04 --> Total execution time: 1.8179
INFO - 2017-03-14 05:11:04 --> Config Class Initialized
INFO - 2017-03-14 05:11:04 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:11:04 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:11:04 --> Utf8 Class Initialized
INFO - 2017-03-14 05:11:04 --> URI Class Initialized
INFO - 2017-03-14 05:11:04 --> Router Class Initialized
INFO - 2017-03-14 05:11:04 --> Output Class Initialized
INFO - 2017-03-14 05:11:04 --> Security Class Initialized
DEBUG - 2017-03-14 05:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:11:04 --> Input Class Initialized
INFO - 2017-03-14 05:11:04 --> Language Class Initialized
INFO - 2017-03-14 05:11:04 --> Loader Class Initialized
INFO - 2017-03-14 05:11:04 --> Database Driver Class Initialized
INFO - 2017-03-14 05:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:11:04 --> Controller Class Initialized
INFO - 2017-03-14 05:11:04 --> Helper loaded: url_helper
DEBUG - 2017-03-14 05:11:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:11:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 05:11:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 05:11:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 05:11:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 05:11:04 --> Final output sent to browser
DEBUG - 2017-03-14 05:11:04 --> Total execution time: 0.0819
INFO - 2017-03-14 05:14:11 --> Config Class Initialized
INFO - 2017-03-14 05:14:11 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:14:11 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:14:11 --> Utf8 Class Initialized
INFO - 2017-03-14 05:14:11 --> URI Class Initialized
DEBUG - 2017-03-14 05:14:12 --> No URI present. Default controller set.
INFO - 2017-03-14 05:14:12 --> Router Class Initialized
INFO - 2017-03-14 05:14:12 --> Output Class Initialized
INFO - 2017-03-14 05:14:12 --> Security Class Initialized
DEBUG - 2017-03-14 05:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:14:12 --> Input Class Initialized
INFO - 2017-03-14 05:14:12 --> Language Class Initialized
INFO - 2017-03-14 05:14:12 --> Loader Class Initialized
INFO - 2017-03-14 05:14:12 --> Database Driver Class Initialized
INFO - 2017-03-14 05:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:14:12 --> Controller Class Initialized
INFO - 2017-03-14 05:14:12 --> Helper loaded: url_helper
DEBUG - 2017-03-14 05:14:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:14:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 05:14:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 05:14:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 05:14:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 05:14:13 --> Final output sent to browser
DEBUG - 2017-03-14 05:14:13 --> Total execution time: 1.6376
INFO - 2017-03-14 05:14:17 --> Config Class Initialized
INFO - 2017-03-14 05:14:17 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:14:17 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:14:17 --> Utf8 Class Initialized
INFO - 2017-03-14 05:14:17 --> URI Class Initialized
INFO - 2017-03-14 05:14:17 --> Router Class Initialized
INFO - 2017-03-14 05:14:17 --> Output Class Initialized
INFO - 2017-03-14 05:14:17 --> Security Class Initialized
DEBUG - 2017-03-14 05:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:14:17 --> Input Class Initialized
INFO - 2017-03-14 05:14:17 --> Language Class Initialized
INFO - 2017-03-14 05:14:17 --> Loader Class Initialized
INFO - 2017-03-14 05:14:17 --> Database Driver Class Initialized
INFO - 2017-03-14 05:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:14:17 --> Controller Class Initialized
INFO - 2017-03-14 05:14:17 --> Helper loaded: url_helper
DEBUG - 2017-03-14 05:14:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:14:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 05:14:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 05:14:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 05:14:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 05:14:17 --> Final output sent to browser
DEBUG - 2017-03-14 05:14:17 --> Total execution time: 0.0140
INFO - 2017-03-14 05:14:49 --> Config Class Initialized
INFO - 2017-03-14 05:14:49 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:14:50 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:14:50 --> Utf8 Class Initialized
INFO - 2017-03-14 05:14:50 --> URI Class Initialized
INFO - 2017-03-14 05:14:50 --> Router Class Initialized
INFO - 2017-03-14 05:14:50 --> Output Class Initialized
INFO - 2017-03-14 05:14:50 --> Security Class Initialized
DEBUG - 2017-03-14 05:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:14:50 --> Input Class Initialized
INFO - 2017-03-14 05:14:50 --> Language Class Initialized
INFO - 2017-03-14 05:14:50 --> Loader Class Initialized
INFO - 2017-03-14 05:14:50 --> Database Driver Class Initialized
INFO - 2017-03-14 05:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:14:50 --> Controller Class Initialized
INFO - 2017-03-14 05:14:50 --> Helper loaded: url_helper
DEBUG - 2017-03-14 05:14:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:14:51 --> Config Class Initialized
INFO - 2017-03-14 05:14:51 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:14:51 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:14:51 --> Utf8 Class Initialized
INFO - 2017-03-14 05:14:51 --> URI Class Initialized
INFO - 2017-03-14 05:14:51 --> Router Class Initialized
INFO - 2017-03-14 05:14:51 --> Output Class Initialized
INFO - 2017-03-14 05:14:51 --> Security Class Initialized
DEBUG - 2017-03-14 05:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:14:51 --> Input Class Initialized
INFO - 2017-03-14 05:14:51 --> Language Class Initialized
INFO - 2017-03-14 05:14:51 --> Loader Class Initialized
INFO - 2017-03-14 05:14:51 --> Database Driver Class Initialized
INFO - 2017-03-14 05:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:14:51 --> Controller Class Initialized
INFO - 2017-03-14 05:14:51 --> Helper loaded: date_helper
DEBUG - 2017-03-14 05:14:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:14:51 --> Helper loaded: url_helper
INFO - 2017-03-14 05:14:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 05:14:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-14 05:14:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-14 05:14:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 05:14:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 05:14:51 --> Final output sent to browser
DEBUG - 2017-03-14 05:14:51 --> Total execution time: 0.1231
INFO - 2017-03-14 05:14:54 --> Config Class Initialized
INFO - 2017-03-14 05:14:54 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:14:54 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:14:54 --> Utf8 Class Initialized
INFO - 2017-03-14 05:14:54 --> URI Class Initialized
INFO - 2017-03-14 05:14:54 --> Router Class Initialized
INFO - 2017-03-14 05:14:54 --> Output Class Initialized
INFO - 2017-03-14 05:14:54 --> Security Class Initialized
DEBUG - 2017-03-14 05:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:14:54 --> Input Class Initialized
INFO - 2017-03-14 05:14:54 --> Language Class Initialized
INFO - 2017-03-14 05:14:54 --> Loader Class Initialized
INFO - 2017-03-14 05:14:54 --> Database Driver Class Initialized
INFO - 2017-03-14 05:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:14:54 --> Controller Class Initialized
INFO - 2017-03-14 05:14:54 --> Helper loaded: url_helper
DEBUG - 2017-03-14 05:14:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:14:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 05:14:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 05:14:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 05:14:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 05:14:54 --> Final output sent to browser
DEBUG - 2017-03-14 05:14:54 --> Total execution time: 0.0408
INFO - 2017-03-14 05:17:24 --> Config Class Initialized
INFO - 2017-03-14 05:17:24 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:17:24 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:17:24 --> Utf8 Class Initialized
INFO - 2017-03-14 05:17:24 --> URI Class Initialized
INFO - 2017-03-14 05:17:24 --> Router Class Initialized
INFO - 2017-03-14 05:17:24 --> Output Class Initialized
INFO - 2017-03-14 05:17:24 --> Security Class Initialized
DEBUG - 2017-03-14 05:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:17:25 --> Input Class Initialized
INFO - 2017-03-14 05:17:25 --> Language Class Initialized
INFO - 2017-03-14 05:17:25 --> Loader Class Initialized
INFO - 2017-03-14 05:17:25 --> Database Driver Class Initialized
INFO - 2017-03-14 05:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:17:25 --> Controller Class Initialized
INFO - 2017-03-14 05:17:25 --> Helper loaded: date_helper
DEBUG - 2017-03-14 05:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:17:25 --> Helper loaded: url_helper
INFO - 2017-03-14 05:17:25 --> Helper loaded: download_helper
INFO - 2017-03-14 05:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 05:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-14 05:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-14 05:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-14 05:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 05:17:25 --> Final output sent to browser
DEBUG - 2017-03-14 05:17:25 --> Total execution time: 1.1960
INFO - 2017-03-14 05:17:26 --> Config Class Initialized
INFO - 2017-03-14 05:17:26 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:17:26 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:17:26 --> Utf8 Class Initialized
INFO - 2017-03-14 05:17:26 --> URI Class Initialized
INFO - 2017-03-14 05:17:26 --> Router Class Initialized
INFO - 2017-03-14 05:17:26 --> Output Class Initialized
INFO - 2017-03-14 05:17:26 --> Security Class Initialized
DEBUG - 2017-03-14 05:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:17:26 --> Input Class Initialized
INFO - 2017-03-14 05:17:26 --> Language Class Initialized
INFO - 2017-03-14 05:17:26 --> Loader Class Initialized
INFO - 2017-03-14 05:17:26 --> Database Driver Class Initialized
INFO - 2017-03-14 05:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:17:26 --> Controller Class Initialized
INFO - 2017-03-14 05:17:26 --> Helper loaded: url_helper
DEBUG - 2017-03-14 05:17:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:17:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 05:17:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 05:17:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 05:17:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 05:17:27 --> Final output sent to browser
DEBUG - 2017-03-14 05:17:27 --> Total execution time: 0.2469
INFO - 2017-03-14 05:17:42 --> Config Class Initialized
INFO - 2017-03-14 05:17:42 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:17:42 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:17:42 --> Utf8 Class Initialized
INFO - 2017-03-14 05:17:42 --> URI Class Initialized
INFO - 2017-03-14 05:17:42 --> Router Class Initialized
INFO - 2017-03-14 05:17:42 --> Output Class Initialized
INFO - 2017-03-14 05:17:42 --> Security Class Initialized
DEBUG - 2017-03-14 05:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:17:42 --> Input Class Initialized
INFO - 2017-03-14 05:17:42 --> Language Class Initialized
INFO - 2017-03-14 05:17:42 --> Loader Class Initialized
INFO - 2017-03-14 05:17:42 --> Database Driver Class Initialized
INFO - 2017-03-14 05:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:17:42 --> Controller Class Initialized
INFO - 2017-03-14 05:17:42 --> Helper loaded: date_helper
DEBUG - 2017-03-14 05:17:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:17:42 --> Helper loaded: url_helper
INFO - 2017-03-14 05:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 05:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-14 05:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-14 05:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 05:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 05:17:42 --> Final output sent to browser
DEBUG - 2017-03-14 05:17:42 --> Total execution time: 0.0501
INFO - 2017-03-14 05:17:43 --> Config Class Initialized
INFO - 2017-03-14 05:17:43 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:17:43 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:17:43 --> Utf8 Class Initialized
INFO - 2017-03-14 05:17:43 --> URI Class Initialized
INFO - 2017-03-14 05:17:43 --> Router Class Initialized
INFO - 2017-03-14 05:17:43 --> Output Class Initialized
INFO - 2017-03-14 05:17:43 --> Security Class Initialized
DEBUG - 2017-03-14 05:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:17:43 --> Input Class Initialized
INFO - 2017-03-14 05:17:43 --> Language Class Initialized
INFO - 2017-03-14 05:17:43 --> Loader Class Initialized
INFO - 2017-03-14 05:17:43 --> Database Driver Class Initialized
INFO - 2017-03-14 05:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:17:43 --> Controller Class Initialized
INFO - 2017-03-14 05:17:43 --> Helper loaded: url_helper
DEBUG - 2017-03-14 05:17:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:17:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 05:17:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 05:17:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 05:17:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 05:17:44 --> Final output sent to browser
DEBUG - 2017-03-14 05:17:44 --> Total execution time: 0.0135
INFO - 2017-03-14 05:17:54 --> Config Class Initialized
INFO - 2017-03-14 05:17:54 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:17:54 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:17:54 --> Utf8 Class Initialized
INFO - 2017-03-14 05:17:54 --> URI Class Initialized
INFO - 2017-03-14 05:17:54 --> Router Class Initialized
INFO - 2017-03-14 05:17:54 --> Output Class Initialized
INFO - 2017-03-14 05:17:54 --> Security Class Initialized
DEBUG - 2017-03-14 05:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:17:54 --> Input Class Initialized
INFO - 2017-03-14 05:17:54 --> Language Class Initialized
INFO - 2017-03-14 05:17:54 --> Loader Class Initialized
INFO - 2017-03-14 05:17:54 --> Database Driver Class Initialized
INFO - 2017-03-14 05:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:17:54 --> Controller Class Initialized
INFO - 2017-03-14 05:17:54 --> Helper loaded: date_helper
DEBUG - 2017-03-14 05:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:17:54 --> Helper loaded: url_helper
INFO - 2017-03-14 05:17:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 05:17:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-14 05:17:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-14 05:17:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 05:17:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 05:17:54 --> Final output sent to browser
DEBUG - 2017-03-14 05:17:54 --> Total execution time: 0.0148
INFO - 2017-03-14 05:17:55 --> Config Class Initialized
INFO - 2017-03-14 05:17:55 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:17:55 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:17:55 --> Utf8 Class Initialized
INFO - 2017-03-14 05:17:55 --> URI Class Initialized
INFO - 2017-03-14 05:17:55 --> Router Class Initialized
INFO - 2017-03-14 05:17:55 --> Output Class Initialized
INFO - 2017-03-14 05:17:55 --> Security Class Initialized
DEBUG - 2017-03-14 05:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:17:55 --> Input Class Initialized
INFO - 2017-03-14 05:17:55 --> Language Class Initialized
INFO - 2017-03-14 05:17:55 --> Loader Class Initialized
INFO - 2017-03-14 05:17:55 --> Database Driver Class Initialized
INFO - 2017-03-14 05:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:17:55 --> Controller Class Initialized
INFO - 2017-03-14 05:17:55 --> Helper loaded: url_helper
DEBUG - 2017-03-14 05:17:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:17:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 05:17:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 05:17:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 05:17:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 05:17:55 --> Final output sent to browser
DEBUG - 2017-03-14 05:17:55 --> Total execution time: 0.0143
INFO - 2017-03-14 05:20:58 --> Config Class Initialized
INFO - 2017-03-14 05:20:58 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:20:58 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:20:58 --> Utf8 Class Initialized
INFO - 2017-03-14 05:20:58 --> URI Class Initialized
DEBUG - 2017-03-14 05:20:58 --> No URI present. Default controller set.
INFO - 2017-03-14 05:20:58 --> Router Class Initialized
INFO - 2017-03-14 05:20:58 --> Output Class Initialized
INFO - 2017-03-14 05:20:58 --> Security Class Initialized
DEBUG - 2017-03-14 05:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:20:58 --> Input Class Initialized
INFO - 2017-03-14 05:20:58 --> Language Class Initialized
INFO - 2017-03-14 05:20:58 --> Loader Class Initialized
INFO - 2017-03-14 05:20:58 --> Database Driver Class Initialized
INFO - 2017-03-14 05:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:20:58 --> Controller Class Initialized
INFO - 2017-03-14 05:20:58 --> Helper loaded: url_helper
DEBUG - 2017-03-14 05:20:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:20:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 05:20:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 05:20:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 05:20:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 05:20:58 --> Final output sent to browser
DEBUG - 2017-03-14 05:20:58 --> Total execution time: 0.0518
INFO - 2017-03-14 05:21:03 --> Config Class Initialized
INFO - 2017-03-14 05:21:03 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:21:03 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:21:03 --> Utf8 Class Initialized
INFO - 2017-03-14 05:21:03 --> URI Class Initialized
INFO - 2017-03-14 05:21:03 --> Router Class Initialized
INFO - 2017-03-14 05:21:03 --> Output Class Initialized
INFO - 2017-03-14 05:21:03 --> Security Class Initialized
DEBUG - 2017-03-14 05:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:21:03 --> Input Class Initialized
INFO - 2017-03-14 05:21:03 --> Language Class Initialized
INFO - 2017-03-14 05:21:03 --> Loader Class Initialized
INFO - 2017-03-14 05:21:03 --> Database Driver Class Initialized
INFO - 2017-03-14 05:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:21:03 --> Controller Class Initialized
INFO - 2017-03-14 05:21:03 --> Helper loaded: url_helper
DEBUG - 2017-03-14 05:21:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:21:05 --> Config Class Initialized
INFO - 2017-03-14 05:21:05 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:21:05 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:21:05 --> Utf8 Class Initialized
INFO - 2017-03-14 05:21:05 --> URI Class Initialized
INFO - 2017-03-14 05:21:05 --> Router Class Initialized
INFO - 2017-03-14 05:21:05 --> Output Class Initialized
INFO - 2017-03-14 05:21:05 --> Security Class Initialized
DEBUG - 2017-03-14 05:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:21:05 --> Input Class Initialized
INFO - 2017-03-14 05:21:05 --> Language Class Initialized
INFO - 2017-03-14 05:21:05 --> Loader Class Initialized
INFO - 2017-03-14 05:21:05 --> Database Driver Class Initialized
INFO - 2017-03-14 05:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:21:05 --> Controller Class Initialized
INFO - 2017-03-14 05:21:05 --> Helper loaded: date_helper
DEBUG - 2017-03-14 05:21:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:21:05 --> Helper loaded: url_helper
INFO - 2017-03-14 05:21:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 05:21:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 05:21:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 05:21:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 05:21:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 05:21:05 --> Final output sent to browser
DEBUG - 2017-03-14 05:21:05 --> Total execution time: 0.0247
INFO - 2017-03-14 05:31:57 --> Config Class Initialized
INFO - 2017-03-14 05:31:57 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:31:57 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:31:57 --> Utf8 Class Initialized
INFO - 2017-03-14 05:31:57 --> URI Class Initialized
DEBUG - 2017-03-14 05:31:57 --> No URI present. Default controller set.
INFO - 2017-03-14 05:31:57 --> Router Class Initialized
INFO - 2017-03-14 05:31:57 --> Output Class Initialized
INFO - 2017-03-14 05:31:57 --> Security Class Initialized
DEBUG - 2017-03-14 05:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:31:57 --> Input Class Initialized
INFO - 2017-03-14 05:31:57 --> Language Class Initialized
INFO - 2017-03-14 05:31:57 --> Loader Class Initialized
INFO - 2017-03-14 05:31:57 --> Database Driver Class Initialized
INFO - 2017-03-14 05:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:31:57 --> Controller Class Initialized
INFO - 2017-03-14 05:31:57 --> Helper loaded: url_helper
DEBUG - 2017-03-14 05:31:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:31:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 05:31:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 05:31:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 05:31:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 05:31:57 --> Final output sent to browser
DEBUG - 2017-03-14 05:31:57 --> Total execution time: 0.0220
INFO - 2017-03-14 05:32:05 --> Config Class Initialized
INFO - 2017-03-14 05:32:05 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:32:05 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:32:05 --> Utf8 Class Initialized
INFO - 2017-03-14 05:32:05 --> URI Class Initialized
INFO - 2017-03-14 05:32:05 --> Router Class Initialized
INFO - 2017-03-14 05:32:05 --> Output Class Initialized
INFO - 2017-03-14 05:32:05 --> Security Class Initialized
DEBUG - 2017-03-14 05:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:32:05 --> Input Class Initialized
INFO - 2017-03-14 05:32:05 --> Language Class Initialized
INFO - 2017-03-14 05:32:05 --> Loader Class Initialized
INFO - 2017-03-14 05:32:05 --> Database Driver Class Initialized
INFO - 2017-03-14 05:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:32:05 --> Controller Class Initialized
INFO - 2017-03-14 05:32:05 --> Helper loaded: url_helper
DEBUG - 2017-03-14 05:32:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:32:05 --> Config Class Initialized
INFO - 2017-03-14 05:32:05 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:32:05 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:32:05 --> Utf8 Class Initialized
INFO - 2017-03-14 05:32:05 --> URI Class Initialized
INFO - 2017-03-14 05:32:05 --> Router Class Initialized
INFO - 2017-03-14 05:32:05 --> Output Class Initialized
INFO - 2017-03-14 05:32:05 --> Security Class Initialized
DEBUG - 2017-03-14 05:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:32:05 --> Input Class Initialized
INFO - 2017-03-14 05:32:05 --> Language Class Initialized
INFO - 2017-03-14 05:32:05 --> Loader Class Initialized
INFO - 2017-03-14 05:32:05 --> Database Driver Class Initialized
INFO - 2017-03-14 05:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:32:05 --> Controller Class Initialized
INFO - 2017-03-14 05:32:05 --> Helper loaded: date_helper
DEBUG - 2017-03-14 05:32:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:32:05 --> Helper loaded: url_helper
INFO - 2017-03-14 05:32:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 05:32:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 05:32:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 05:32:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 05:32:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 05:32:05 --> Final output sent to browser
DEBUG - 2017-03-14 05:32:05 --> Total execution time: 0.0142
INFO - 2017-03-14 05:32:09 --> Config Class Initialized
INFO - 2017-03-14 05:32:09 --> Hooks Class Initialized
DEBUG - 2017-03-14 05:32:09 --> UTF-8 Support Enabled
INFO - 2017-03-14 05:32:09 --> Utf8 Class Initialized
INFO - 2017-03-14 05:32:09 --> URI Class Initialized
DEBUG - 2017-03-14 05:32:09 --> No URI present. Default controller set.
INFO - 2017-03-14 05:32:09 --> Router Class Initialized
INFO - 2017-03-14 05:32:09 --> Output Class Initialized
INFO - 2017-03-14 05:32:09 --> Security Class Initialized
DEBUG - 2017-03-14 05:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 05:32:09 --> Input Class Initialized
INFO - 2017-03-14 05:32:09 --> Language Class Initialized
INFO - 2017-03-14 05:32:09 --> Loader Class Initialized
INFO - 2017-03-14 05:32:09 --> Database Driver Class Initialized
INFO - 2017-03-14 05:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 05:32:09 --> Controller Class Initialized
INFO - 2017-03-14 05:32:09 --> Helper loaded: url_helper
DEBUG - 2017-03-14 05:32:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 05:32:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 05:32:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 05:32:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 05:32:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 05:32:09 --> Final output sent to browser
DEBUG - 2017-03-14 05:32:09 --> Total execution time: 0.0140
INFO - 2017-03-14 06:00:38 --> Config Class Initialized
INFO - 2017-03-14 06:00:38 --> Hooks Class Initialized
DEBUG - 2017-03-14 06:00:38 --> UTF-8 Support Enabled
INFO - 2017-03-14 06:00:38 --> Utf8 Class Initialized
INFO - 2017-03-14 06:00:38 --> URI Class Initialized
DEBUG - 2017-03-14 06:00:38 --> No URI present. Default controller set.
INFO - 2017-03-14 06:00:38 --> Router Class Initialized
INFO - 2017-03-14 06:00:38 --> Output Class Initialized
INFO - 2017-03-14 06:00:38 --> Security Class Initialized
DEBUG - 2017-03-14 06:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 06:00:38 --> Input Class Initialized
INFO - 2017-03-14 06:00:38 --> Language Class Initialized
INFO - 2017-03-14 06:00:38 --> Loader Class Initialized
INFO - 2017-03-14 06:00:39 --> Database Driver Class Initialized
INFO - 2017-03-14 06:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 06:00:39 --> Controller Class Initialized
INFO - 2017-03-14 06:00:39 --> Helper loaded: url_helper
DEBUG - 2017-03-14 06:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 06:00:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 06:00:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 06:00:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 06:00:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 06:00:39 --> Final output sent to browser
DEBUG - 2017-03-14 06:00:39 --> Total execution time: 1.2294
INFO - 2017-03-14 06:01:56 --> Config Class Initialized
INFO - 2017-03-14 06:01:56 --> Hooks Class Initialized
DEBUG - 2017-03-14 06:01:56 --> UTF-8 Support Enabled
INFO - 2017-03-14 06:01:56 --> Utf8 Class Initialized
INFO - 2017-03-14 06:01:56 --> URI Class Initialized
DEBUG - 2017-03-14 06:01:56 --> No URI present. Default controller set.
INFO - 2017-03-14 06:01:56 --> Router Class Initialized
INFO - 2017-03-14 06:01:56 --> Output Class Initialized
INFO - 2017-03-14 06:01:56 --> Security Class Initialized
DEBUG - 2017-03-14 06:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 06:01:56 --> Input Class Initialized
INFO - 2017-03-14 06:01:56 --> Language Class Initialized
INFO - 2017-03-14 06:01:56 --> Loader Class Initialized
INFO - 2017-03-14 06:01:57 --> Database Driver Class Initialized
INFO - 2017-03-14 06:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 06:01:57 --> Controller Class Initialized
INFO - 2017-03-14 06:01:57 --> Helper loaded: url_helper
DEBUG - 2017-03-14 06:01:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 06:01:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 06:01:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 06:01:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 06:01:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 06:01:57 --> Final output sent to browser
DEBUG - 2017-03-14 06:01:57 --> Total execution time: 1.2214
INFO - 2017-03-14 09:20:43 --> Config Class Initialized
INFO - 2017-03-14 09:20:43 --> Hooks Class Initialized
DEBUG - 2017-03-14 09:20:43 --> UTF-8 Support Enabled
INFO - 2017-03-14 09:20:43 --> Utf8 Class Initialized
INFO - 2017-03-14 09:20:43 --> URI Class Initialized
INFO - 2017-03-14 09:20:43 --> Router Class Initialized
INFO - 2017-03-14 09:20:43 --> Output Class Initialized
INFO - 2017-03-14 09:20:43 --> Security Class Initialized
DEBUG - 2017-03-14 09:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 09:20:44 --> Input Class Initialized
INFO - 2017-03-14 09:20:44 --> Language Class Initialized
INFO - 2017-03-14 09:20:44 --> Loader Class Initialized
INFO - 2017-03-14 09:20:44 --> Database Driver Class Initialized
INFO - 2017-03-14 09:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 09:20:44 --> Controller Class Initialized
INFO - 2017-03-14 09:20:44 --> Helper loaded: url_helper
DEBUG - 2017-03-14 09:20:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 09:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 09:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 09:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 09:20:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 09:20:44 --> Final output sent to browser
DEBUG - 2017-03-14 09:20:44 --> Total execution time: 1.2128
INFO - 2017-03-14 09:20:48 --> Config Class Initialized
INFO - 2017-03-14 09:20:48 --> Hooks Class Initialized
DEBUG - 2017-03-14 09:20:48 --> UTF-8 Support Enabled
INFO - 2017-03-14 09:20:48 --> Utf8 Class Initialized
INFO - 2017-03-14 09:20:48 --> URI Class Initialized
DEBUG - 2017-03-14 09:20:48 --> No URI present. Default controller set.
INFO - 2017-03-14 09:20:48 --> Router Class Initialized
INFO - 2017-03-14 09:20:48 --> Output Class Initialized
INFO - 2017-03-14 09:20:48 --> Security Class Initialized
DEBUG - 2017-03-14 09:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 09:20:48 --> Input Class Initialized
INFO - 2017-03-14 09:20:48 --> Language Class Initialized
INFO - 2017-03-14 09:20:48 --> Loader Class Initialized
INFO - 2017-03-14 09:20:48 --> Database Driver Class Initialized
INFO - 2017-03-14 09:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 09:20:48 --> Controller Class Initialized
INFO - 2017-03-14 09:20:48 --> Helper loaded: url_helper
DEBUG - 2017-03-14 09:20:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 09:20:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 09:20:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 09:20:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 09:20:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 09:20:48 --> Final output sent to browser
DEBUG - 2017-03-14 09:20:48 --> Total execution time: 0.0135
INFO - 2017-03-14 10:53:19 --> Config Class Initialized
INFO - 2017-03-14 10:53:19 --> Hooks Class Initialized
DEBUG - 2017-03-14 10:53:19 --> UTF-8 Support Enabled
INFO - 2017-03-14 10:53:19 --> Utf8 Class Initialized
INFO - 2017-03-14 10:53:19 --> URI Class Initialized
INFO - 2017-03-14 10:53:19 --> Router Class Initialized
INFO - 2017-03-14 10:53:19 --> Output Class Initialized
INFO - 2017-03-14 10:53:19 --> Security Class Initialized
DEBUG - 2017-03-14 10:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 10:53:19 --> Input Class Initialized
INFO - 2017-03-14 10:53:19 --> Language Class Initialized
INFO - 2017-03-14 10:53:19 --> Loader Class Initialized
INFO - 2017-03-14 10:53:19 --> Database Driver Class Initialized
INFO - 2017-03-14 10:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 10:53:19 --> Controller Class Initialized
INFO - 2017-03-14 10:53:19 --> Helper loaded: url_helper
DEBUG - 2017-03-14 10:53:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 10:53:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 10:53:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 10:53:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 10:53:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 10:53:20 --> Final output sent to browser
DEBUG - 2017-03-14 10:53:20 --> Total execution time: 1.1724
INFO - 2017-03-14 10:53:20 --> Config Class Initialized
INFO - 2017-03-14 10:53:20 --> Hooks Class Initialized
DEBUG - 2017-03-14 10:53:20 --> UTF-8 Support Enabled
INFO - 2017-03-14 10:53:20 --> Utf8 Class Initialized
INFO - 2017-03-14 10:53:20 --> URI Class Initialized
DEBUG - 2017-03-14 10:53:20 --> No URI present. Default controller set.
INFO - 2017-03-14 10:53:20 --> Router Class Initialized
INFO - 2017-03-14 10:53:20 --> Output Class Initialized
INFO - 2017-03-14 10:53:20 --> Security Class Initialized
DEBUG - 2017-03-14 10:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 10:53:20 --> Input Class Initialized
INFO - 2017-03-14 10:53:20 --> Language Class Initialized
INFO - 2017-03-14 10:53:20 --> Loader Class Initialized
INFO - 2017-03-14 10:53:20 --> Database Driver Class Initialized
INFO - 2017-03-14 10:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 10:53:20 --> Controller Class Initialized
INFO - 2017-03-14 10:53:20 --> Helper loaded: url_helper
DEBUG - 2017-03-14 10:53:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 10:53:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 10:53:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 10:53:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 10:53:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 10:53:20 --> Final output sent to browser
DEBUG - 2017-03-14 10:53:20 --> Total execution time: 0.0134
INFO - 2017-03-14 11:47:49 --> Config Class Initialized
INFO - 2017-03-14 11:47:49 --> Hooks Class Initialized
DEBUG - 2017-03-14 11:47:49 --> UTF-8 Support Enabled
INFO - 2017-03-14 11:47:49 --> Utf8 Class Initialized
INFO - 2017-03-14 11:47:49 --> URI Class Initialized
INFO - 2017-03-14 11:47:49 --> Router Class Initialized
INFO - 2017-03-14 11:47:49 --> Output Class Initialized
INFO - 2017-03-14 11:47:49 --> Security Class Initialized
DEBUG - 2017-03-14 11:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 11:47:50 --> Input Class Initialized
INFO - 2017-03-14 11:47:50 --> Language Class Initialized
INFO - 2017-03-14 11:47:50 --> Loader Class Initialized
INFO - 2017-03-14 11:47:50 --> Database Driver Class Initialized
INFO - 2017-03-14 11:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 11:47:50 --> Controller Class Initialized
INFO - 2017-03-14 11:47:50 --> Helper loaded: url_helper
DEBUG - 2017-03-14 11:47:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 11:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 11:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 11:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 11:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 11:47:50 --> Final output sent to browser
DEBUG - 2017-03-14 11:47:50 --> Total execution time: 1.2544
INFO - 2017-03-14 11:47:51 --> Config Class Initialized
INFO - 2017-03-14 11:47:51 --> Hooks Class Initialized
DEBUG - 2017-03-14 11:47:51 --> UTF-8 Support Enabled
INFO - 2017-03-14 11:47:51 --> Utf8 Class Initialized
INFO - 2017-03-14 11:47:51 --> URI Class Initialized
DEBUG - 2017-03-14 11:47:51 --> No URI present. Default controller set.
INFO - 2017-03-14 11:47:51 --> Router Class Initialized
INFO - 2017-03-14 11:47:51 --> Output Class Initialized
INFO - 2017-03-14 11:47:51 --> Security Class Initialized
DEBUG - 2017-03-14 11:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 11:47:51 --> Input Class Initialized
INFO - 2017-03-14 11:47:51 --> Language Class Initialized
INFO - 2017-03-14 11:47:51 --> Loader Class Initialized
INFO - 2017-03-14 11:47:51 --> Database Driver Class Initialized
INFO - 2017-03-14 11:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 11:47:51 --> Controller Class Initialized
INFO - 2017-03-14 11:47:51 --> Helper loaded: url_helper
DEBUG - 2017-03-14 11:47:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 11:47:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 11:47:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 11:47:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 11:47:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 11:47:51 --> Final output sent to browser
DEBUG - 2017-03-14 11:47:51 --> Total execution time: 0.0325
INFO - 2017-03-14 12:22:47 --> Config Class Initialized
INFO - 2017-03-14 12:22:47 --> Hooks Class Initialized
DEBUG - 2017-03-14 12:22:47 --> UTF-8 Support Enabled
INFO - 2017-03-14 12:22:47 --> Utf8 Class Initialized
INFO - 2017-03-14 12:22:47 --> URI Class Initialized
DEBUG - 2017-03-14 12:22:47 --> No URI present. Default controller set.
INFO - 2017-03-14 12:22:47 --> Router Class Initialized
INFO - 2017-03-14 12:22:47 --> Output Class Initialized
INFO - 2017-03-14 12:22:47 --> Security Class Initialized
DEBUG - 2017-03-14 12:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 12:22:47 --> Input Class Initialized
INFO - 2017-03-14 12:22:47 --> Language Class Initialized
INFO - 2017-03-14 12:22:47 --> Loader Class Initialized
INFO - 2017-03-14 12:22:48 --> Database Driver Class Initialized
INFO - 2017-03-14 12:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 12:22:48 --> Controller Class Initialized
INFO - 2017-03-14 12:22:48 --> Helper loaded: url_helper
DEBUG - 2017-03-14 12:22:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 12:22:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 12:22:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 12:22:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 12:22:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 12:22:48 --> Final output sent to browser
DEBUG - 2017-03-14 12:22:48 --> Total execution time: 1.2177
INFO - 2017-03-14 13:15:39 --> Config Class Initialized
INFO - 2017-03-14 13:15:39 --> Hooks Class Initialized
DEBUG - 2017-03-14 13:15:39 --> UTF-8 Support Enabled
INFO - 2017-03-14 13:15:39 --> Utf8 Class Initialized
INFO - 2017-03-14 13:15:39 --> URI Class Initialized
DEBUG - 2017-03-14 13:15:39 --> No URI present. Default controller set.
INFO - 2017-03-14 13:15:39 --> Router Class Initialized
INFO - 2017-03-14 13:15:39 --> Output Class Initialized
INFO - 2017-03-14 13:15:39 --> Security Class Initialized
DEBUG - 2017-03-14 13:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 13:15:40 --> Input Class Initialized
INFO - 2017-03-14 13:15:40 --> Language Class Initialized
INFO - 2017-03-14 13:15:40 --> Loader Class Initialized
INFO - 2017-03-14 13:15:40 --> Database Driver Class Initialized
INFO - 2017-03-14 13:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 13:15:40 --> Controller Class Initialized
INFO - 2017-03-14 13:15:40 --> Helper loaded: url_helper
DEBUG - 2017-03-14 13:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 13:15:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 13:15:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 13:15:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 13:15:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 13:15:40 --> Final output sent to browser
DEBUG - 2017-03-14 13:15:40 --> Total execution time: 1.2711
INFO - 2017-03-14 13:27:49 --> Config Class Initialized
INFO - 2017-03-14 13:27:49 --> Hooks Class Initialized
DEBUG - 2017-03-14 13:27:49 --> UTF-8 Support Enabled
INFO - 2017-03-14 13:27:49 --> Utf8 Class Initialized
INFO - 2017-03-14 13:27:49 --> URI Class Initialized
INFO - 2017-03-14 13:27:49 --> Router Class Initialized
INFO - 2017-03-14 13:27:49 --> Output Class Initialized
INFO - 2017-03-14 13:27:49 --> Security Class Initialized
DEBUG - 2017-03-14 13:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 13:27:49 --> Input Class Initialized
INFO - 2017-03-14 13:27:49 --> Language Class Initialized
INFO - 2017-03-14 13:27:49 --> Loader Class Initialized
INFO - 2017-03-14 13:27:49 --> Database Driver Class Initialized
INFO - 2017-03-14 13:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 13:27:50 --> Controller Class Initialized
INFO - 2017-03-14 13:27:50 --> Helper loaded: url_helper
DEBUG - 2017-03-14 13:27:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 13:27:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 13:27:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 13:27:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 13:27:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 13:27:50 --> Final output sent to browser
DEBUG - 2017-03-14 13:27:50 --> Total execution time: 1.2170
INFO - 2017-03-14 13:27:51 --> Config Class Initialized
INFO - 2017-03-14 13:27:51 --> Hooks Class Initialized
DEBUG - 2017-03-14 13:27:51 --> UTF-8 Support Enabled
INFO - 2017-03-14 13:27:51 --> Utf8 Class Initialized
INFO - 2017-03-14 13:27:51 --> URI Class Initialized
DEBUG - 2017-03-14 13:27:51 --> No URI present. Default controller set.
INFO - 2017-03-14 13:27:51 --> Router Class Initialized
INFO - 2017-03-14 13:27:51 --> Output Class Initialized
INFO - 2017-03-14 13:27:51 --> Security Class Initialized
DEBUG - 2017-03-14 13:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 13:27:51 --> Input Class Initialized
INFO - 2017-03-14 13:27:51 --> Language Class Initialized
INFO - 2017-03-14 13:27:51 --> Loader Class Initialized
INFO - 2017-03-14 13:27:51 --> Database Driver Class Initialized
INFO - 2017-03-14 13:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 13:27:51 --> Controller Class Initialized
INFO - 2017-03-14 13:27:51 --> Helper loaded: url_helper
DEBUG - 2017-03-14 13:27:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 13:27:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 13:27:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 13:27:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 13:27:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 13:27:51 --> Final output sent to browser
DEBUG - 2017-03-14 13:27:51 --> Total execution time: 0.0539
INFO - 2017-03-14 13:58:31 --> Config Class Initialized
INFO - 2017-03-14 13:58:31 --> Hooks Class Initialized
DEBUG - 2017-03-14 13:58:31 --> UTF-8 Support Enabled
INFO - 2017-03-14 13:58:31 --> Utf8 Class Initialized
INFO - 2017-03-14 13:58:31 --> URI Class Initialized
DEBUG - 2017-03-14 13:58:31 --> No URI present. Default controller set.
INFO - 2017-03-14 13:58:31 --> Router Class Initialized
INFO - 2017-03-14 13:58:31 --> Output Class Initialized
INFO - 2017-03-14 13:58:31 --> Security Class Initialized
DEBUG - 2017-03-14 13:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 13:58:31 --> Input Class Initialized
INFO - 2017-03-14 13:58:31 --> Language Class Initialized
INFO - 2017-03-14 13:58:31 --> Loader Class Initialized
INFO - 2017-03-14 13:58:31 --> Database Driver Class Initialized
INFO - 2017-03-14 13:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 13:58:32 --> Controller Class Initialized
INFO - 2017-03-14 13:58:32 --> Helper loaded: url_helper
DEBUG - 2017-03-14 13:58:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 13:58:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 13:58:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 13:58:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 13:58:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 13:58:32 --> Final output sent to browser
DEBUG - 2017-03-14 13:58:32 --> Total execution time: 1.2214
INFO - 2017-03-14 14:03:40 --> Config Class Initialized
INFO - 2017-03-14 14:03:40 --> Hooks Class Initialized
DEBUG - 2017-03-14 14:03:40 --> UTF-8 Support Enabled
INFO - 2017-03-14 14:03:40 --> Utf8 Class Initialized
INFO - 2017-03-14 14:03:40 --> URI Class Initialized
INFO - 2017-03-14 14:03:40 --> Router Class Initialized
INFO - 2017-03-14 14:03:40 --> Output Class Initialized
INFO - 2017-03-14 14:03:40 --> Security Class Initialized
DEBUG - 2017-03-14 14:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 14:03:41 --> Input Class Initialized
INFO - 2017-03-14 14:03:41 --> Language Class Initialized
INFO - 2017-03-14 14:03:41 --> Loader Class Initialized
INFO - 2017-03-14 14:03:41 --> Database Driver Class Initialized
INFO - 2017-03-14 14:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 14:03:41 --> Controller Class Initialized
INFO - 2017-03-14 14:03:42 --> Helper loaded: date_helper
DEBUG - 2017-03-14 14:03:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 14:03:42 --> Helper loaded: url_helper
INFO - 2017-03-14 14:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 14:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 14:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 14:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 14:03:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 14:03:42 --> Final output sent to browser
DEBUG - 2017-03-14 14:03:42 --> Total execution time: 1.5408
INFO - 2017-03-14 15:15:37 --> Config Class Initialized
INFO - 2017-03-14 15:15:37 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:15:37 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:15:37 --> Utf8 Class Initialized
INFO - 2017-03-14 15:15:37 --> URI Class Initialized
DEBUG - 2017-03-14 15:15:37 --> No URI present. Default controller set.
INFO - 2017-03-14 15:15:37 --> Router Class Initialized
INFO - 2017-03-14 15:15:37 --> Output Class Initialized
INFO - 2017-03-14 15:15:37 --> Security Class Initialized
DEBUG - 2017-03-14 15:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:15:37 --> Input Class Initialized
INFO - 2017-03-14 15:15:37 --> Language Class Initialized
INFO - 2017-03-14 15:15:37 --> Loader Class Initialized
INFO - 2017-03-14 15:15:38 --> Database Driver Class Initialized
INFO - 2017-03-14 15:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:15:38 --> Controller Class Initialized
INFO - 2017-03-14 15:15:38 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:15:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:15:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:15:38 --> Final output sent to browser
DEBUG - 2017-03-14 15:15:38 --> Total execution time: 1.4672
INFO - 2017-03-14 15:23:48 --> Config Class Initialized
INFO - 2017-03-14 15:23:48 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:23:48 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:23:48 --> Utf8 Class Initialized
INFO - 2017-03-14 15:23:48 --> URI Class Initialized
DEBUG - 2017-03-14 15:23:48 --> No URI present. Default controller set.
INFO - 2017-03-14 15:23:48 --> Router Class Initialized
INFO - 2017-03-14 15:23:48 --> Output Class Initialized
INFO - 2017-03-14 15:23:48 --> Security Class Initialized
DEBUG - 2017-03-14 15:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:23:48 --> Input Class Initialized
INFO - 2017-03-14 15:23:48 --> Language Class Initialized
INFO - 2017-03-14 15:23:48 --> Loader Class Initialized
INFO - 2017-03-14 15:23:49 --> Database Driver Class Initialized
INFO - 2017-03-14 15:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:23:49 --> Controller Class Initialized
INFO - 2017-03-14 15:23:49 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:23:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:23:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:23:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:23:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:23:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:23:50 --> Final output sent to browser
DEBUG - 2017-03-14 15:23:50 --> Total execution time: 1.4736
INFO - 2017-03-14 15:24:07 --> Config Class Initialized
INFO - 2017-03-14 15:24:07 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:24:07 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:24:07 --> Utf8 Class Initialized
INFO - 2017-03-14 15:24:07 --> URI Class Initialized
INFO - 2017-03-14 15:24:07 --> Router Class Initialized
INFO - 2017-03-14 15:24:07 --> Output Class Initialized
INFO - 2017-03-14 15:24:07 --> Security Class Initialized
DEBUG - 2017-03-14 15:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:24:07 --> Input Class Initialized
INFO - 2017-03-14 15:24:07 --> Language Class Initialized
INFO - 2017-03-14 15:24:07 --> Loader Class Initialized
INFO - 2017-03-14 15:24:07 --> Database Driver Class Initialized
INFO - 2017-03-14 15:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:24:07 --> Controller Class Initialized
INFO - 2017-03-14 15:24:07 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:24:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:24:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:24:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:24:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:24:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:24:07 --> Final output sent to browser
DEBUG - 2017-03-14 15:24:07 --> Total execution time: 0.0140
INFO - 2017-03-14 15:24:31 --> Config Class Initialized
INFO - 2017-03-14 15:24:31 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:24:31 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:24:31 --> Utf8 Class Initialized
INFO - 2017-03-14 15:24:31 --> URI Class Initialized
INFO - 2017-03-14 15:24:31 --> Router Class Initialized
INFO - 2017-03-14 15:24:31 --> Output Class Initialized
INFO - 2017-03-14 15:24:31 --> Security Class Initialized
DEBUG - 2017-03-14 15:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:24:31 --> Input Class Initialized
INFO - 2017-03-14 15:24:31 --> Language Class Initialized
INFO - 2017-03-14 15:24:31 --> Loader Class Initialized
INFO - 2017-03-14 15:24:31 --> Database Driver Class Initialized
INFO - 2017-03-14 15:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:24:31 --> Controller Class Initialized
INFO - 2017-03-14 15:24:31 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:24:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:24:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-14 15:24:31 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-14 15:24:31 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-14 15:24:31 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-14 15:24:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:24:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:24:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:24:31 --> Final output sent to browser
DEBUG - 2017-03-14 15:24:31 --> Total execution time: 0.0595
INFO - 2017-03-14 15:24:34 --> Config Class Initialized
INFO - 2017-03-14 15:24:34 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:24:34 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:24:34 --> Utf8 Class Initialized
INFO - 2017-03-14 15:24:34 --> URI Class Initialized
INFO - 2017-03-14 15:24:34 --> Router Class Initialized
INFO - 2017-03-14 15:24:34 --> Output Class Initialized
INFO - 2017-03-14 15:24:34 --> Security Class Initialized
DEBUG - 2017-03-14 15:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:24:34 --> Input Class Initialized
INFO - 2017-03-14 15:24:34 --> Language Class Initialized
INFO - 2017-03-14 15:24:34 --> Loader Class Initialized
INFO - 2017-03-14 15:24:34 --> Database Driver Class Initialized
INFO - 2017-03-14 15:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:24:34 --> Controller Class Initialized
INFO - 2017-03-14 15:24:34 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:24:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:24:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:24:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:24:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:24:34 --> Final output sent to browser
DEBUG - 2017-03-14 15:24:34 --> Total execution time: 0.0137
INFO - 2017-03-14 15:24:52 --> Config Class Initialized
INFO - 2017-03-14 15:24:52 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:24:52 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:24:52 --> Utf8 Class Initialized
INFO - 2017-03-14 15:24:52 --> URI Class Initialized
INFO - 2017-03-14 15:24:52 --> Router Class Initialized
INFO - 2017-03-14 15:24:52 --> Output Class Initialized
INFO - 2017-03-14 15:24:52 --> Security Class Initialized
DEBUG - 2017-03-14 15:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:24:52 --> Input Class Initialized
INFO - 2017-03-14 15:24:52 --> Language Class Initialized
INFO - 2017-03-14 15:24:52 --> Loader Class Initialized
INFO - 2017-03-14 15:24:52 --> Database Driver Class Initialized
INFO - 2017-03-14 15:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:24:52 --> Controller Class Initialized
INFO - 2017-03-14 15:24:52 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:24:54 --> Config Class Initialized
INFO - 2017-03-14 15:24:54 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:24:54 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:24:54 --> Utf8 Class Initialized
INFO - 2017-03-14 15:24:54 --> URI Class Initialized
INFO - 2017-03-14 15:24:54 --> Router Class Initialized
INFO - 2017-03-14 15:24:54 --> Output Class Initialized
INFO - 2017-03-14 15:24:54 --> Security Class Initialized
DEBUG - 2017-03-14 15:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:24:54 --> Input Class Initialized
INFO - 2017-03-14 15:24:54 --> Language Class Initialized
INFO - 2017-03-14 15:24:54 --> Loader Class Initialized
INFO - 2017-03-14 15:24:54 --> Database Driver Class Initialized
INFO - 2017-03-14 15:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:24:54 --> Controller Class Initialized
INFO - 2017-03-14 15:24:54 --> Helper loaded: date_helper
DEBUG - 2017-03-14 15:24:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:24:54 --> Helper loaded: url_helper
INFO - 2017-03-14 15:24:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:24:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 15:24:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 15:24:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 15:24:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:24:54 --> Final output sent to browser
DEBUG - 2017-03-14 15:24:54 --> Total execution time: 0.3566
INFO - 2017-03-14 15:24:55 --> Config Class Initialized
INFO - 2017-03-14 15:24:55 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:24:55 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:24:55 --> Utf8 Class Initialized
INFO - 2017-03-14 15:24:55 --> URI Class Initialized
INFO - 2017-03-14 15:24:55 --> Router Class Initialized
INFO - 2017-03-14 15:24:55 --> Output Class Initialized
INFO - 2017-03-14 15:24:55 --> Security Class Initialized
DEBUG - 2017-03-14 15:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:24:55 --> Input Class Initialized
INFO - 2017-03-14 15:24:55 --> Language Class Initialized
INFO - 2017-03-14 15:24:55 --> Loader Class Initialized
INFO - 2017-03-14 15:24:55 --> Database Driver Class Initialized
INFO - 2017-03-14 15:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:24:55 --> Controller Class Initialized
INFO - 2017-03-14 15:24:55 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:24:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:24:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:24:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:24:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:24:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:24:55 --> Final output sent to browser
DEBUG - 2017-03-14 15:24:55 --> Total execution time: 0.0140
INFO - 2017-03-14 15:25:01 --> Config Class Initialized
INFO - 2017-03-14 15:25:01 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:25:01 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:25:01 --> Utf8 Class Initialized
INFO - 2017-03-14 15:25:01 --> URI Class Initialized
DEBUG - 2017-03-14 15:25:01 --> No URI present. Default controller set.
INFO - 2017-03-14 15:25:01 --> Router Class Initialized
INFO - 2017-03-14 15:25:01 --> Output Class Initialized
INFO - 2017-03-14 15:25:01 --> Security Class Initialized
DEBUG - 2017-03-14 15:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:25:01 --> Input Class Initialized
INFO - 2017-03-14 15:25:01 --> Language Class Initialized
INFO - 2017-03-14 15:25:01 --> Loader Class Initialized
INFO - 2017-03-14 15:25:01 --> Database Driver Class Initialized
INFO - 2017-03-14 15:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:25:01 --> Controller Class Initialized
INFO - 2017-03-14 15:25:01 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:25:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:25:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:25:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:25:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:25:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:25:01 --> Final output sent to browser
DEBUG - 2017-03-14 15:25:01 --> Total execution time: 0.7818
INFO - 2017-03-14 15:25:03 --> Config Class Initialized
INFO - 2017-03-14 15:25:03 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:25:03 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:25:03 --> Utf8 Class Initialized
INFO - 2017-03-14 15:25:03 --> URI Class Initialized
INFO - 2017-03-14 15:25:03 --> Router Class Initialized
INFO - 2017-03-14 15:25:03 --> Output Class Initialized
INFO - 2017-03-14 15:25:03 --> Security Class Initialized
DEBUG - 2017-03-14 15:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:25:03 --> Input Class Initialized
INFO - 2017-03-14 15:25:03 --> Language Class Initialized
INFO - 2017-03-14 15:25:03 --> Loader Class Initialized
INFO - 2017-03-14 15:25:03 --> Database Driver Class Initialized
INFO - 2017-03-14 15:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:25:03 --> Controller Class Initialized
INFO - 2017-03-14 15:25:03 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:25:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:25:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:25:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:25:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:25:03 --> Final output sent to browser
DEBUG - 2017-03-14 15:25:03 --> Total execution time: 0.0140
INFO - 2017-03-14 15:30:11 --> Config Class Initialized
INFO - 2017-03-14 15:30:11 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:30:11 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:30:11 --> Utf8 Class Initialized
INFO - 2017-03-14 15:30:11 --> URI Class Initialized
DEBUG - 2017-03-14 15:30:11 --> No URI present. Default controller set.
INFO - 2017-03-14 15:30:11 --> Router Class Initialized
INFO - 2017-03-14 15:30:11 --> Output Class Initialized
INFO - 2017-03-14 15:30:11 --> Security Class Initialized
DEBUG - 2017-03-14 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:30:11 --> Input Class Initialized
INFO - 2017-03-14 15:30:11 --> Language Class Initialized
INFO - 2017-03-14 15:30:11 --> Loader Class Initialized
INFO - 2017-03-14 15:30:11 --> Database Driver Class Initialized
INFO - 2017-03-14 15:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:30:12 --> Controller Class Initialized
INFO - 2017-03-14 15:30:12 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:30:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:30:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:30:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:30:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:30:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:30:12 --> Final output sent to browser
DEBUG - 2017-03-14 15:30:12 --> Total execution time: 1.4709
INFO - 2017-03-14 15:30:33 --> Config Class Initialized
INFO - 2017-03-14 15:30:33 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:30:33 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:30:33 --> Utf8 Class Initialized
INFO - 2017-03-14 15:30:33 --> URI Class Initialized
DEBUG - 2017-03-14 15:30:34 --> No URI present. Default controller set.
INFO - 2017-03-14 15:30:34 --> Router Class Initialized
INFO - 2017-03-14 15:30:34 --> Output Class Initialized
INFO - 2017-03-14 15:30:34 --> Security Class Initialized
DEBUG - 2017-03-14 15:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:30:34 --> Input Class Initialized
INFO - 2017-03-14 15:30:34 --> Language Class Initialized
INFO - 2017-03-14 15:30:34 --> Loader Class Initialized
INFO - 2017-03-14 15:30:34 --> Database Driver Class Initialized
INFO - 2017-03-14 15:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:30:35 --> Controller Class Initialized
INFO - 2017-03-14 15:30:35 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:30:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:30:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:30:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:30:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:30:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:30:35 --> Final output sent to browser
DEBUG - 2017-03-14 15:30:35 --> Total execution time: 1.8999
INFO - 2017-03-14 15:30:41 --> Config Class Initialized
INFO - 2017-03-14 15:30:41 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:30:41 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:30:41 --> Utf8 Class Initialized
INFO - 2017-03-14 15:30:41 --> URI Class Initialized
INFO - 2017-03-14 15:30:41 --> Router Class Initialized
INFO - 2017-03-14 15:30:41 --> Output Class Initialized
INFO - 2017-03-14 15:30:41 --> Security Class Initialized
DEBUG - 2017-03-14 15:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:30:41 --> Input Class Initialized
INFO - 2017-03-14 15:30:41 --> Language Class Initialized
INFO - 2017-03-14 15:30:41 --> Loader Class Initialized
INFO - 2017-03-14 15:30:41 --> Database Driver Class Initialized
INFO - 2017-03-14 15:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:30:41 --> Controller Class Initialized
INFO - 2017-03-14 15:30:41 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:30:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:30:46 --> Config Class Initialized
INFO - 2017-03-14 15:30:46 --> Config Class Initialized
INFO - 2017-03-14 15:30:46 --> Hooks Class Initialized
INFO - 2017-03-14 15:30:46 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:30:46 --> UTF-8 Support Enabled
DEBUG - 2017-03-14 15:30:46 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:30:46 --> Utf8 Class Initialized
INFO - 2017-03-14 15:30:46 --> Utf8 Class Initialized
INFO - 2017-03-14 15:30:46 --> URI Class Initialized
INFO - 2017-03-14 15:30:46 --> URI Class Initialized
INFO - 2017-03-14 15:30:46 --> Router Class Initialized
INFO - 2017-03-14 15:30:46 --> Router Class Initialized
INFO - 2017-03-14 15:30:46 --> Output Class Initialized
INFO - 2017-03-14 15:30:46 --> Output Class Initialized
INFO - 2017-03-14 15:30:46 --> Security Class Initialized
INFO - 2017-03-14 15:30:46 --> Security Class Initialized
DEBUG - 2017-03-14 15:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:30:46 --> Input Class Initialized
INFO - 2017-03-14 15:30:46 --> Language Class Initialized
DEBUG - 2017-03-14 15:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:30:46 --> Input Class Initialized
INFO - 2017-03-14 15:30:46 --> Language Class Initialized
INFO - 2017-03-14 15:30:46 --> Loader Class Initialized
INFO - 2017-03-14 15:30:47 --> Loader Class Initialized
INFO - 2017-03-14 15:30:47 --> Database Driver Class Initialized
INFO - 2017-03-14 15:30:47 --> Database Driver Class Initialized
INFO - 2017-03-14 15:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:30:47 --> Controller Class Initialized
INFO - 2017-03-14 15:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:30:47 --> Controller Class Initialized
INFO - 2017-03-14 15:30:47 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:30:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:30:47 --> Helper loaded: date_helper
DEBUG - 2017-03-14 15:30:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:30:47 --> Helper loaded: url_helper
INFO - 2017-03-14 15:30:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:30:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:30:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 15:30:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:30:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 15:30:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 15:30:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:30:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:30:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:30:47 --> Final output sent to browser
DEBUG - 2017-03-14 15:30:47 --> Total execution time: 1.3434
INFO - 2017-03-14 15:30:47 --> Final output sent to browser
DEBUG - 2017-03-14 15:30:47 --> Total execution time: 1.2859
INFO - 2017-03-14 15:30:51 --> Config Class Initialized
INFO - 2017-03-14 15:30:51 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:30:51 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:30:51 --> Utf8 Class Initialized
INFO - 2017-03-14 15:30:51 --> URI Class Initialized
INFO - 2017-03-14 15:30:51 --> Router Class Initialized
INFO - 2017-03-14 15:30:51 --> Output Class Initialized
INFO - 2017-03-14 15:30:51 --> Security Class Initialized
DEBUG - 2017-03-14 15:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:30:51 --> Input Class Initialized
INFO - 2017-03-14 15:30:51 --> Language Class Initialized
INFO - 2017-03-14 15:30:51 --> Loader Class Initialized
INFO - 2017-03-14 15:30:51 --> Database Driver Class Initialized
INFO - 2017-03-14 15:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:30:51 --> Controller Class Initialized
INFO - 2017-03-14 15:30:51 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:30:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:30:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:30:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:30:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:30:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:30:51 --> Final output sent to browser
DEBUG - 2017-03-14 15:30:51 --> Total execution time: 0.0142
INFO - 2017-03-14 15:30:55 --> Config Class Initialized
INFO - 2017-03-14 15:30:55 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:30:55 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:30:55 --> Utf8 Class Initialized
INFO - 2017-03-14 15:30:55 --> URI Class Initialized
DEBUG - 2017-03-14 15:30:55 --> No URI present. Default controller set.
INFO - 2017-03-14 15:30:55 --> Router Class Initialized
INFO - 2017-03-14 15:30:55 --> Output Class Initialized
INFO - 2017-03-14 15:30:55 --> Security Class Initialized
DEBUG - 2017-03-14 15:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:30:55 --> Input Class Initialized
INFO - 2017-03-14 15:30:55 --> Language Class Initialized
INFO - 2017-03-14 15:30:55 --> Loader Class Initialized
INFO - 2017-03-14 15:30:55 --> Database Driver Class Initialized
INFO - 2017-03-14 15:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:30:55 --> Controller Class Initialized
INFO - 2017-03-14 15:30:55 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:30:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:30:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:30:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:30:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:30:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:30:55 --> Final output sent to browser
DEBUG - 2017-03-14 15:30:55 --> Total execution time: 0.0319
INFO - 2017-03-14 15:31:26 --> Config Class Initialized
INFO - 2017-03-14 15:31:26 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:31:26 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:31:26 --> Utf8 Class Initialized
INFO - 2017-03-14 15:31:26 --> URI Class Initialized
INFO - 2017-03-14 15:31:26 --> Router Class Initialized
INFO - 2017-03-14 15:31:26 --> Output Class Initialized
INFO - 2017-03-14 15:31:26 --> Security Class Initialized
DEBUG - 2017-03-14 15:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:31:26 --> Input Class Initialized
INFO - 2017-03-14 15:31:26 --> Language Class Initialized
INFO - 2017-03-14 15:31:26 --> Loader Class Initialized
INFO - 2017-03-14 15:31:26 --> Database Driver Class Initialized
INFO - 2017-03-14 15:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:31:26 --> Controller Class Initialized
INFO - 2017-03-14 15:31:26 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:31:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:31:29 --> Config Class Initialized
INFO - 2017-03-14 15:31:29 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:31:29 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:31:29 --> Utf8 Class Initialized
INFO - 2017-03-14 15:31:29 --> URI Class Initialized
INFO - 2017-03-14 15:31:29 --> Router Class Initialized
INFO - 2017-03-14 15:31:29 --> Output Class Initialized
INFO - 2017-03-14 15:31:29 --> Security Class Initialized
DEBUG - 2017-03-14 15:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:31:29 --> Input Class Initialized
INFO - 2017-03-14 15:31:29 --> Language Class Initialized
INFO - 2017-03-14 15:31:29 --> Loader Class Initialized
INFO - 2017-03-14 15:31:29 --> Database Driver Class Initialized
INFO - 2017-03-14 15:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:31:29 --> Controller Class Initialized
INFO - 2017-03-14 15:31:29 --> Helper loaded: date_helper
DEBUG - 2017-03-14 15:31:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:31:29 --> Helper loaded: url_helper
INFO - 2017-03-14 15:31:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:31:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 15:31:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 15:31:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 15:31:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:31:29 --> Final output sent to browser
DEBUG - 2017-03-14 15:31:29 --> Total execution time: 0.1092
INFO - 2017-03-14 15:31:30 --> Config Class Initialized
INFO - 2017-03-14 15:31:30 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:31:30 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:31:30 --> Utf8 Class Initialized
INFO - 2017-03-14 15:31:30 --> URI Class Initialized
INFO - 2017-03-14 15:31:30 --> Router Class Initialized
INFO - 2017-03-14 15:31:30 --> Output Class Initialized
INFO - 2017-03-14 15:31:30 --> Security Class Initialized
DEBUG - 2017-03-14 15:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:31:30 --> Input Class Initialized
INFO - 2017-03-14 15:31:30 --> Language Class Initialized
INFO - 2017-03-14 15:31:30 --> Loader Class Initialized
INFO - 2017-03-14 15:31:30 --> Database Driver Class Initialized
INFO - 2017-03-14 15:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:31:30 --> Controller Class Initialized
INFO - 2017-03-14 15:31:30 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:31:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:31:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:31:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:31:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:31:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:31:30 --> Final output sent to browser
DEBUG - 2017-03-14 15:31:30 --> Total execution time: 0.0309
INFO - 2017-03-14 15:31:34 --> Config Class Initialized
INFO - 2017-03-14 15:31:34 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:31:34 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:31:34 --> Utf8 Class Initialized
INFO - 2017-03-14 15:31:34 --> URI Class Initialized
DEBUG - 2017-03-14 15:31:34 --> No URI present. Default controller set.
INFO - 2017-03-14 15:31:34 --> Router Class Initialized
INFO - 2017-03-14 15:31:34 --> Output Class Initialized
INFO - 2017-03-14 15:31:34 --> Security Class Initialized
DEBUG - 2017-03-14 15:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:31:34 --> Input Class Initialized
INFO - 2017-03-14 15:31:34 --> Language Class Initialized
INFO - 2017-03-14 15:31:34 --> Loader Class Initialized
INFO - 2017-03-14 15:31:34 --> Database Driver Class Initialized
INFO - 2017-03-14 15:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:31:34 --> Controller Class Initialized
INFO - 2017-03-14 15:31:34 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:31:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:31:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:31:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:31:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:31:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:31:34 --> Final output sent to browser
DEBUG - 2017-03-14 15:31:34 --> Total execution time: 0.0232
INFO - 2017-03-14 15:31:46 --> Config Class Initialized
INFO - 2017-03-14 15:31:46 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:31:46 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:31:46 --> Utf8 Class Initialized
INFO - 2017-03-14 15:31:46 --> URI Class Initialized
INFO - 2017-03-14 15:31:46 --> Router Class Initialized
INFO - 2017-03-14 15:31:46 --> Output Class Initialized
INFO - 2017-03-14 15:31:46 --> Security Class Initialized
DEBUG - 2017-03-14 15:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:31:46 --> Input Class Initialized
INFO - 2017-03-14 15:31:46 --> Language Class Initialized
INFO - 2017-03-14 15:31:46 --> Loader Class Initialized
INFO - 2017-03-14 15:31:46 --> Database Driver Class Initialized
INFO - 2017-03-14 15:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:31:46 --> Controller Class Initialized
INFO - 2017-03-14 15:31:46 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:31:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:31:46 --> Final output sent to browser
DEBUG - 2017-03-14 15:31:46 --> Total execution time: 0.0134
INFO - 2017-03-14 15:33:47 --> Config Class Initialized
INFO - 2017-03-14 15:33:47 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:33:47 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:33:47 --> Utf8 Class Initialized
INFO - 2017-03-14 15:33:47 --> URI Class Initialized
DEBUG - 2017-03-14 15:33:48 --> No URI present. Default controller set.
INFO - 2017-03-14 15:33:48 --> Router Class Initialized
INFO - 2017-03-14 15:33:48 --> Output Class Initialized
INFO - 2017-03-14 15:33:48 --> Security Class Initialized
DEBUG - 2017-03-14 15:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:33:48 --> Input Class Initialized
INFO - 2017-03-14 15:33:48 --> Language Class Initialized
INFO - 2017-03-14 15:33:48 --> Loader Class Initialized
INFO - 2017-03-14 15:33:48 --> Database Driver Class Initialized
INFO - 2017-03-14 15:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:33:49 --> Controller Class Initialized
INFO - 2017-03-14 15:33:49 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:33:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:33:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:33:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:33:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:33:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:33:49 --> Final output sent to browser
DEBUG - 2017-03-14 15:33:49 --> Total execution time: 1.5218
INFO - 2017-03-14 15:34:09 --> Config Class Initialized
INFO - 2017-03-14 15:34:09 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:34:09 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:34:09 --> Utf8 Class Initialized
INFO - 2017-03-14 15:34:09 --> URI Class Initialized
INFO - 2017-03-14 15:34:09 --> Router Class Initialized
INFO - 2017-03-14 15:34:09 --> Output Class Initialized
INFO - 2017-03-14 15:34:09 --> Security Class Initialized
DEBUG - 2017-03-14 15:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:34:09 --> Input Class Initialized
INFO - 2017-03-14 15:34:09 --> Language Class Initialized
INFO - 2017-03-14 15:34:09 --> Loader Class Initialized
INFO - 2017-03-14 15:34:09 --> Database Driver Class Initialized
INFO - 2017-03-14 15:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:34:09 --> Controller Class Initialized
INFO - 2017-03-14 15:34:09 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:34:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-14 15:34:09 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-14 15:34:09 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-14 15:34:09 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-14 15:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:34:09 --> Final output sent to browser
DEBUG - 2017-03-14 15:34:09 --> Total execution time: 0.0447
INFO - 2017-03-14 15:34:12 --> Config Class Initialized
INFO - 2017-03-14 15:34:12 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:34:12 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:34:12 --> Utf8 Class Initialized
INFO - 2017-03-14 15:34:12 --> URI Class Initialized
INFO - 2017-03-14 15:34:12 --> Router Class Initialized
INFO - 2017-03-14 15:34:12 --> Output Class Initialized
INFO - 2017-03-14 15:34:12 --> Security Class Initialized
DEBUG - 2017-03-14 15:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:34:12 --> Input Class Initialized
INFO - 2017-03-14 15:34:12 --> Language Class Initialized
INFO - 2017-03-14 15:34:12 --> Loader Class Initialized
INFO - 2017-03-14 15:34:12 --> Database Driver Class Initialized
INFO - 2017-03-14 15:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:34:12 --> Controller Class Initialized
INFO - 2017-03-14 15:34:12 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:34:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:34:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:34:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:34:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:34:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:34:12 --> Final output sent to browser
DEBUG - 2017-03-14 15:34:12 --> Total execution time: 0.0139
INFO - 2017-03-14 15:34:19 --> Config Class Initialized
INFO - 2017-03-14 15:34:19 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:34:19 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:34:19 --> Utf8 Class Initialized
INFO - 2017-03-14 15:34:19 --> URI Class Initialized
INFO - 2017-03-14 15:34:19 --> Router Class Initialized
INFO - 2017-03-14 15:34:19 --> Output Class Initialized
INFO - 2017-03-14 15:34:19 --> Security Class Initialized
DEBUG - 2017-03-14 15:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:34:19 --> Input Class Initialized
INFO - 2017-03-14 15:34:19 --> Language Class Initialized
INFO - 2017-03-14 15:34:19 --> Loader Class Initialized
INFO - 2017-03-14 15:34:19 --> Database Driver Class Initialized
INFO - 2017-03-14 15:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:34:19 --> Controller Class Initialized
INFO - 2017-03-14 15:34:19 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:34:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:34:21 --> Config Class Initialized
INFO - 2017-03-14 15:34:21 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:34:21 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:34:21 --> Utf8 Class Initialized
INFO - 2017-03-14 15:34:21 --> URI Class Initialized
INFO - 2017-03-14 15:34:21 --> Router Class Initialized
INFO - 2017-03-14 15:34:21 --> Output Class Initialized
INFO - 2017-03-14 15:34:21 --> Security Class Initialized
DEBUG - 2017-03-14 15:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:34:21 --> Input Class Initialized
INFO - 2017-03-14 15:34:21 --> Language Class Initialized
INFO - 2017-03-14 15:34:21 --> Loader Class Initialized
INFO - 2017-03-14 15:34:21 --> Database Driver Class Initialized
INFO - 2017-03-14 15:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:34:21 --> Controller Class Initialized
INFO - 2017-03-14 15:34:21 --> Helper loaded: date_helper
DEBUG - 2017-03-14 15:34:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:34:21 --> Helper loaded: url_helper
INFO - 2017-03-14 15:34:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:34:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 15:34:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 15:34:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 15:34:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:34:21 --> Final output sent to browser
DEBUG - 2017-03-14 15:34:21 --> Total execution time: 0.0995
INFO - 2017-03-14 15:34:31 --> Config Class Initialized
INFO - 2017-03-14 15:34:31 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:34:31 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:34:31 --> Utf8 Class Initialized
INFO - 2017-03-14 15:34:31 --> URI Class Initialized
INFO - 2017-03-14 15:34:31 --> Router Class Initialized
INFO - 2017-03-14 15:34:31 --> Output Class Initialized
INFO - 2017-03-14 15:34:31 --> Security Class Initialized
DEBUG - 2017-03-14 15:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:34:31 --> Input Class Initialized
INFO - 2017-03-14 15:34:31 --> Language Class Initialized
INFO - 2017-03-14 15:34:31 --> Loader Class Initialized
INFO - 2017-03-14 15:34:31 --> Database Driver Class Initialized
INFO - 2017-03-14 15:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:34:31 --> Controller Class Initialized
INFO - 2017-03-14 15:34:31 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:34:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:34:31 --> Config Class Initialized
INFO - 2017-03-14 15:34:31 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:34:31 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:34:31 --> Utf8 Class Initialized
INFO - 2017-03-14 15:34:31 --> URI Class Initialized
INFO - 2017-03-14 15:34:31 --> Router Class Initialized
INFO - 2017-03-14 15:34:31 --> Output Class Initialized
INFO - 2017-03-14 15:34:31 --> Security Class Initialized
DEBUG - 2017-03-14 15:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:34:31 --> Input Class Initialized
INFO - 2017-03-14 15:34:31 --> Language Class Initialized
INFO - 2017-03-14 15:34:31 --> Loader Class Initialized
INFO - 2017-03-14 15:34:31 --> Database Driver Class Initialized
INFO - 2017-03-14 15:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:34:31 --> Controller Class Initialized
INFO - 2017-03-14 15:34:31 --> Helper loaded: date_helper
DEBUG - 2017-03-14 15:34:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:34:31 --> Helper loaded: url_helper
INFO - 2017-03-14 15:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 15:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 15:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 15:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:34:31 --> Final output sent to browser
DEBUG - 2017-03-14 15:34:31 --> Total execution time: 0.0142
INFO - 2017-03-14 15:34:34 --> Config Class Initialized
INFO - 2017-03-14 15:34:34 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:34:34 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:34:34 --> Utf8 Class Initialized
INFO - 2017-03-14 15:34:34 --> URI Class Initialized
INFO - 2017-03-14 15:34:34 --> Router Class Initialized
INFO - 2017-03-14 15:34:34 --> Output Class Initialized
INFO - 2017-03-14 15:34:34 --> Security Class Initialized
DEBUG - 2017-03-14 15:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:34:34 --> Input Class Initialized
INFO - 2017-03-14 15:34:34 --> Language Class Initialized
INFO - 2017-03-14 15:34:34 --> Loader Class Initialized
INFO - 2017-03-14 15:34:34 --> Database Driver Class Initialized
INFO - 2017-03-14 15:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:34:34 --> Controller Class Initialized
INFO - 2017-03-14 15:34:34 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:34:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:34:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-14 15:34:34 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-14 15:34:34 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-14 15:34:34 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-14 15:34:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:34:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:34:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:34:34 --> Final output sent to browser
DEBUG - 2017-03-14 15:34:34 --> Total execution time: 0.0160
INFO - 2017-03-14 15:34:36 --> Config Class Initialized
INFO - 2017-03-14 15:34:36 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:34:36 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:34:36 --> Utf8 Class Initialized
INFO - 2017-03-14 15:34:36 --> URI Class Initialized
INFO - 2017-03-14 15:34:36 --> Router Class Initialized
INFO - 2017-03-14 15:34:36 --> Output Class Initialized
INFO - 2017-03-14 15:34:36 --> Security Class Initialized
DEBUG - 2017-03-14 15:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:34:36 --> Input Class Initialized
INFO - 2017-03-14 15:34:36 --> Language Class Initialized
INFO - 2017-03-14 15:34:36 --> Loader Class Initialized
INFO - 2017-03-14 15:34:36 --> Database Driver Class Initialized
INFO - 2017-03-14 15:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:34:36 --> Controller Class Initialized
INFO - 2017-03-14 15:34:36 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:34:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:34:36 --> Final output sent to browser
DEBUG - 2017-03-14 15:34:36 --> Total execution time: 0.0143
INFO - 2017-03-14 15:34:38 --> Config Class Initialized
INFO - 2017-03-14 15:34:38 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:34:38 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:34:38 --> Utf8 Class Initialized
INFO - 2017-03-14 15:34:38 --> URI Class Initialized
DEBUG - 2017-03-14 15:34:38 --> No URI present. Default controller set.
INFO - 2017-03-14 15:34:38 --> Router Class Initialized
INFO - 2017-03-14 15:34:38 --> Output Class Initialized
INFO - 2017-03-14 15:34:38 --> Security Class Initialized
DEBUG - 2017-03-14 15:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:34:38 --> Input Class Initialized
INFO - 2017-03-14 15:34:38 --> Language Class Initialized
INFO - 2017-03-14 15:34:38 --> Loader Class Initialized
INFO - 2017-03-14 15:34:38 --> Database Driver Class Initialized
INFO - 2017-03-14 15:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:34:38 --> Controller Class Initialized
INFO - 2017-03-14 15:34:38 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:34:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:34:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:34:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:34:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:34:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:34:38 --> Final output sent to browser
DEBUG - 2017-03-14 15:34:38 --> Total execution time: 0.0135
INFO - 2017-03-14 15:34:50 --> Config Class Initialized
INFO - 2017-03-14 15:34:50 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:34:50 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:34:50 --> Utf8 Class Initialized
INFO - 2017-03-14 15:34:50 --> URI Class Initialized
INFO - 2017-03-14 15:34:50 --> Router Class Initialized
INFO - 2017-03-14 15:34:50 --> Output Class Initialized
INFO - 2017-03-14 15:34:50 --> Security Class Initialized
DEBUG - 2017-03-14 15:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:34:50 --> Input Class Initialized
INFO - 2017-03-14 15:34:50 --> Language Class Initialized
INFO - 2017-03-14 15:34:50 --> Loader Class Initialized
INFO - 2017-03-14 15:34:50 --> Database Driver Class Initialized
INFO - 2017-03-14 15:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:34:50 --> Controller Class Initialized
INFO - 2017-03-14 15:34:51 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:34:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:34:52 --> Config Class Initialized
INFO - 2017-03-14 15:34:52 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:34:52 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:34:52 --> Utf8 Class Initialized
INFO - 2017-03-14 15:34:52 --> URI Class Initialized
INFO - 2017-03-14 15:34:52 --> Router Class Initialized
INFO - 2017-03-14 15:34:52 --> Output Class Initialized
INFO - 2017-03-14 15:34:52 --> Security Class Initialized
DEBUG - 2017-03-14 15:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:34:52 --> Input Class Initialized
INFO - 2017-03-14 15:34:52 --> Language Class Initialized
INFO - 2017-03-14 15:34:52 --> Loader Class Initialized
INFO - 2017-03-14 15:34:52 --> Database Driver Class Initialized
INFO - 2017-03-14 15:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:34:52 --> Controller Class Initialized
INFO - 2017-03-14 15:34:52 --> Helper loaded: date_helper
DEBUG - 2017-03-14 15:34:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:34:52 --> Helper loaded: url_helper
INFO - 2017-03-14 15:34:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:34:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 15:34:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 15:34:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 15:34:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:34:52 --> Final output sent to browser
DEBUG - 2017-03-14 15:34:52 --> Total execution time: 0.0141
INFO - 2017-03-14 15:34:54 --> Config Class Initialized
INFO - 2017-03-14 15:34:54 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:34:54 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:34:54 --> Utf8 Class Initialized
INFO - 2017-03-14 15:34:54 --> URI Class Initialized
INFO - 2017-03-14 15:34:54 --> Router Class Initialized
INFO - 2017-03-14 15:34:54 --> Output Class Initialized
INFO - 2017-03-14 15:34:54 --> Security Class Initialized
DEBUG - 2017-03-14 15:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:34:54 --> Input Class Initialized
INFO - 2017-03-14 15:34:54 --> Language Class Initialized
INFO - 2017-03-14 15:34:54 --> Loader Class Initialized
INFO - 2017-03-14 15:34:54 --> Database Driver Class Initialized
INFO - 2017-03-14 15:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:34:54 --> Controller Class Initialized
INFO - 2017-03-14 15:34:54 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:34:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:34:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:34:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:34:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:34:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:34:54 --> Final output sent to browser
DEBUG - 2017-03-14 15:34:54 --> Total execution time: 0.0140
INFO - 2017-03-14 15:35:02 --> Config Class Initialized
INFO - 2017-03-14 15:35:02 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:35:02 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:35:02 --> Utf8 Class Initialized
INFO - 2017-03-14 15:35:02 --> URI Class Initialized
DEBUG - 2017-03-14 15:35:02 --> No URI present. Default controller set.
INFO - 2017-03-14 15:35:02 --> Router Class Initialized
INFO - 2017-03-14 15:35:02 --> Output Class Initialized
INFO - 2017-03-14 15:35:02 --> Security Class Initialized
DEBUG - 2017-03-14 15:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:35:02 --> Input Class Initialized
INFO - 2017-03-14 15:35:02 --> Language Class Initialized
INFO - 2017-03-14 15:35:02 --> Loader Class Initialized
INFO - 2017-03-14 15:35:02 --> Database Driver Class Initialized
INFO - 2017-03-14 15:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:35:02 --> Controller Class Initialized
INFO - 2017-03-14 15:35:02 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:35:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:35:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:35:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:35:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:35:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:35:02 --> Final output sent to browser
DEBUG - 2017-03-14 15:35:02 --> Total execution time: 0.0335
INFO - 2017-03-14 15:35:05 --> Config Class Initialized
INFO - 2017-03-14 15:35:05 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:35:05 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:35:05 --> Utf8 Class Initialized
INFO - 2017-03-14 15:35:05 --> URI Class Initialized
INFO - 2017-03-14 15:35:05 --> Router Class Initialized
INFO - 2017-03-14 15:35:05 --> Output Class Initialized
INFO - 2017-03-14 15:35:05 --> Security Class Initialized
DEBUG - 2017-03-14 15:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:35:05 --> Input Class Initialized
INFO - 2017-03-14 15:35:05 --> Language Class Initialized
INFO - 2017-03-14 15:35:05 --> Loader Class Initialized
INFO - 2017-03-14 15:35:05 --> Database Driver Class Initialized
INFO - 2017-03-14 15:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:35:05 --> Controller Class Initialized
INFO - 2017-03-14 15:35:05 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:35:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:35:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:35:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:35:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:35:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:35:05 --> Final output sent to browser
DEBUG - 2017-03-14 15:35:05 --> Total execution time: 0.0138
INFO - 2017-03-14 15:44:26 --> Config Class Initialized
INFO - 2017-03-14 15:44:26 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:44:26 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:44:27 --> Utf8 Class Initialized
INFO - 2017-03-14 15:44:27 --> URI Class Initialized
DEBUG - 2017-03-14 15:44:27 --> No URI present. Default controller set.
INFO - 2017-03-14 15:44:27 --> Router Class Initialized
INFO - 2017-03-14 15:44:27 --> Output Class Initialized
INFO - 2017-03-14 15:44:27 --> Security Class Initialized
DEBUG - 2017-03-14 15:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:44:27 --> Input Class Initialized
INFO - 2017-03-14 15:44:27 --> Language Class Initialized
INFO - 2017-03-14 15:44:27 --> Loader Class Initialized
INFO - 2017-03-14 15:44:27 --> Database Driver Class Initialized
INFO - 2017-03-14 15:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:44:28 --> Controller Class Initialized
INFO - 2017-03-14 15:44:28 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:44:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:44:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:44:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:44:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:44:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:44:28 --> Final output sent to browser
DEBUG - 2017-03-14 15:44:28 --> Total execution time: 1.7492
INFO - 2017-03-14 15:44:32 --> Config Class Initialized
INFO - 2017-03-14 15:44:32 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:44:32 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:44:32 --> Utf8 Class Initialized
INFO - 2017-03-14 15:44:32 --> URI Class Initialized
INFO - 2017-03-14 15:44:32 --> Router Class Initialized
INFO - 2017-03-14 15:44:32 --> Output Class Initialized
INFO - 2017-03-14 15:44:32 --> Security Class Initialized
DEBUG - 2017-03-14 15:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:44:32 --> Input Class Initialized
INFO - 2017-03-14 15:44:32 --> Language Class Initialized
INFO - 2017-03-14 15:44:32 --> Loader Class Initialized
INFO - 2017-03-14 15:44:32 --> Database Driver Class Initialized
INFO - 2017-03-14 15:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:44:32 --> Controller Class Initialized
INFO - 2017-03-14 15:44:32 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:44:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:44:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:44:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:44:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:44:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:44:32 --> Final output sent to browser
DEBUG - 2017-03-14 15:44:32 --> Total execution time: 0.0139
INFO - 2017-03-14 15:44:48 --> Config Class Initialized
INFO - 2017-03-14 15:44:48 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:44:48 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:44:48 --> Utf8 Class Initialized
INFO - 2017-03-14 15:44:48 --> URI Class Initialized
INFO - 2017-03-14 15:44:48 --> Router Class Initialized
INFO - 2017-03-14 15:44:48 --> Output Class Initialized
INFO - 2017-03-14 15:44:48 --> Security Class Initialized
DEBUG - 2017-03-14 15:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:44:48 --> Input Class Initialized
INFO - 2017-03-14 15:44:48 --> Language Class Initialized
INFO - 2017-03-14 15:44:48 --> Loader Class Initialized
INFO - 2017-03-14 15:44:48 --> Database Driver Class Initialized
INFO - 2017-03-14 15:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:44:49 --> Controller Class Initialized
INFO - 2017-03-14 15:44:49 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:44:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:44:50 --> Config Class Initialized
INFO - 2017-03-14 15:44:50 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:44:50 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:44:50 --> Utf8 Class Initialized
INFO - 2017-03-14 15:44:50 --> URI Class Initialized
INFO - 2017-03-14 15:44:50 --> Router Class Initialized
INFO - 2017-03-14 15:44:50 --> Output Class Initialized
INFO - 2017-03-14 15:44:50 --> Security Class Initialized
DEBUG - 2017-03-14 15:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:44:50 --> Input Class Initialized
INFO - 2017-03-14 15:44:50 --> Language Class Initialized
INFO - 2017-03-14 15:44:50 --> Loader Class Initialized
INFO - 2017-03-14 15:44:50 --> Database Driver Class Initialized
INFO - 2017-03-14 15:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:44:50 --> Controller Class Initialized
INFO - 2017-03-14 15:44:50 --> Helper loaded: date_helper
DEBUG - 2017-03-14 15:44:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:44:50 --> Helper loaded: url_helper
INFO - 2017-03-14 15:44:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:44:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 15:44:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 15:44:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 15:44:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:44:50 --> Final output sent to browser
DEBUG - 2017-03-14 15:44:50 --> Total execution time: 0.1173
INFO - 2017-03-14 15:44:51 --> Config Class Initialized
INFO - 2017-03-14 15:44:51 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:44:51 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:44:51 --> Utf8 Class Initialized
INFO - 2017-03-14 15:44:51 --> URI Class Initialized
INFO - 2017-03-14 15:44:51 --> Router Class Initialized
INFO - 2017-03-14 15:44:51 --> Output Class Initialized
INFO - 2017-03-14 15:44:51 --> Security Class Initialized
DEBUG - 2017-03-14 15:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:44:51 --> Input Class Initialized
INFO - 2017-03-14 15:44:51 --> Language Class Initialized
INFO - 2017-03-14 15:44:51 --> Loader Class Initialized
INFO - 2017-03-14 15:44:51 --> Database Driver Class Initialized
INFO - 2017-03-14 15:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:44:51 --> Controller Class Initialized
INFO - 2017-03-14 15:44:51 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:44:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:44:51 --> Final output sent to browser
DEBUG - 2017-03-14 15:44:51 --> Total execution time: 0.0446
INFO - 2017-03-14 15:49:39 --> Config Class Initialized
INFO - 2017-03-14 15:49:39 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:49:39 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:49:40 --> Utf8 Class Initialized
INFO - 2017-03-14 15:49:40 --> URI Class Initialized
DEBUG - 2017-03-14 15:49:40 --> No URI present. Default controller set.
INFO - 2017-03-14 15:49:40 --> Router Class Initialized
INFO - 2017-03-14 15:49:40 --> Output Class Initialized
INFO - 2017-03-14 15:49:40 --> Security Class Initialized
DEBUG - 2017-03-14 15:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:49:40 --> Input Class Initialized
INFO - 2017-03-14 15:49:40 --> Language Class Initialized
INFO - 2017-03-14 15:49:40 --> Loader Class Initialized
INFO - 2017-03-14 15:49:40 --> Database Driver Class Initialized
INFO - 2017-03-14 15:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:49:41 --> Controller Class Initialized
INFO - 2017-03-14 15:49:41 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:49:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:49:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:49:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:49:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:49:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:49:41 --> Final output sent to browser
DEBUG - 2017-03-14 15:49:41 --> Total execution time: 1.5844
INFO - 2017-03-14 15:55:47 --> Config Class Initialized
INFO - 2017-03-14 15:55:47 --> Hooks Class Initialized
DEBUG - 2017-03-14 15:55:47 --> UTF-8 Support Enabled
INFO - 2017-03-14 15:55:47 --> Utf8 Class Initialized
INFO - 2017-03-14 15:55:47 --> URI Class Initialized
DEBUG - 2017-03-14 15:55:47 --> No URI present. Default controller set.
INFO - 2017-03-14 15:55:47 --> Router Class Initialized
INFO - 2017-03-14 15:55:47 --> Output Class Initialized
INFO - 2017-03-14 15:55:47 --> Security Class Initialized
DEBUG - 2017-03-14 15:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 15:55:47 --> Input Class Initialized
INFO - 2017-03-14 15:55:47 --> Language Class Initialized
INFO - 2017-03-14 15:55:48 --> Loader Class Initialized
INFO - 2017-03-14 15:55:48 --> Database Driver Class Initialized
INFO - 2017-03-14 15:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 15:55:48 --> Controller Class Initialized
INFO - 2017-03-14 15:55:48 --> Helper loaded: url_helper
DEBUG - 2017-03-14 15:55:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 15:55:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 15:55:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 15:55:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 15:55:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 15:55:49 --> Final output sent to browser
DEBUG - 2017-03-14 15:55:49 --> Total execution time: 1.5293
INFO - 2017-03-14 16:08:57 --> Config Class Initialized
INFO - 2017-03-14 16:08:57 --> Hooks Class Initialized
DEBUG - 2017-03-14 16:08:57 --> UTF-8 Support Enabled
INFO - 2017-03-14 16:08:57 --> Utf8 Class Initialized
INFO - 2017-03-14 16:08:57 --> URI Class Initialized
INFO - 2017-03-14 16:08:57 --> Router Class Initialized
INFO - 2017-03-14 16:08:57 --> Output Class Initialized
INFO - 2017-03-14 16:08:57 --> Security Class Initialized
DEBUG - 2017-03-14 16:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 16:08:57 --> Input Class Initialized
INFO - 2017-03-14 16:08:57 --> Language Class Initialized
INFO - 2017-03-14 16:08:57 --> Loader Class Initialized
INFO - 2017-03-14 16:08:57 --> Database Driver Class Initialized
INFO - 2017-03-14 16:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 16:08:58 --> Controller Class Initialized
INFO - 2017-03-14 16:08:58 --> Helper loaded: url_helper
DEBUG - 2017-03-14 16:08:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 16:08:58 --> Final output sent to browser
DEBUG - 2017-03-14 16:08:58 --> Total execution time: 0.9811
INFO - 2017-03-14 16:49:29 --> Config Class Initialized
INFO - 2017-03-14 16:49:29 --> Hooks Class Initialized
DEBUG - 2017-03-14 16:49:30 --> UTF-8 Support Enabled
INFO - 2017-03-14 16:49:30 --> Utf8 Class Initialized
INFO - 2017-03-14 16:49:30 --> URI Class Initialized
DEBUG - 2017-03-14 16:49:30 --> No URI present. Default controller set.
INFO - 2017-03-14 16:49:30 --> Router Class Initialized
INFO - 2017-03-14 16:49:30 --> Output Class Initialized
INFO - 2017-03-14 16:49:30 --> Security Class Initialized
DEBUG - 2017-03-14 16:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 16:49:30 --> Input Class Initialized
INFO - 2017-03-14 16:49:30 --> Language Class Initialized
INFO - 2017-03-14 16:49:30 --> Loader Class Initialized
INFO - 2017-03-14 16:49:30 --> Database Driver Class Initialized
INFO - 2017-03-14 16:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 16:49:30 --> Controller Class Initialized
INFO - 2017-03-14 16:49:30 --> Helper loaded: url_helper
DEBUG - 2017-03-14 16:49:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 16:49:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 16:49:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 16:49:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 16:49:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 16:49:31 --> Final output sent to browser
DEBUG - 2017-03-14 16:49:31 --> Total execution time: 1.2376
INFO - 2017-03-14 17:29:00 --> Config Class Initialized
INFO - 2017-03-14 17:29:00 --> Hooks Class Initialized
DEBUG - 2017-03-14 17:29:01 --> UTF-8 Support Enabled
INFO - 2017-03-14 17:29:01 --> Utf8 Class Initialized
INFO - 2017-03-14 17:29:01 --> URI Class Initialized
DEBUG - 2017-03-14 17:29:01 --> No URI present. Default controller set.
INFO - 2017-03-14 17:29:01 --> Router Class Initialized
INFO - 2017-03-14 17:29:01 --> Output Class Initialized
INFO - 2017-03-14 17:29:01 --> Security Class Initialized
DEBUG - 2017-03-14 17:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 17:29:01 --> Input Class Initialized
INFO - 2017-03-14 17:29:01 --> Language Class Initialized
INFO - 2017-03-14 17:29:01 --> Loader Class Initialized
INFO - 2017-03-14 17:29:01 --> Database Driver Class Initialized
INFO - 2017-03-14 17:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 17:29:02 --> Controller Class Initialized
INFO - 2017-03-14 17:29:02 --> Helper loaded: url_helper
DEBUG - 2017-03-14 17:29:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 17:29:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 17:29:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 17:29:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 17:29:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 17:29:02 --> Final output sent to browser
DEBUG - 2017-03-14 17:29:02 --> Total execution time: 1.5175
INFO - 2017-03-14 17:29:10 --> Config Class Initialized
INFO - 2017-03-14 17:29:10 --> Hooks Class Initialized
DEBUG - 2017-03-14 17:29:10 --> UTF-8 Support Enabled
INFO - 2017-03-14 17:29:10 --> Utf8 Class Initialized
INFO - 2017-03-14 17:29:10 --> URI Class Initialized
DEBUG - 2017-03-14 17:29:10 --> No URI present. Default controller set.
INFO - 2017-03-14 17:29:10 --> Router Class Initialized
INFO - 2017-03-14 17:29:10 --> Output Class Initialized
INFO - 2017-03-14 17:29:10 --> Security Class Initialized
DEBUG - 2017-03-14 17:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 17:29:10 --> Input Class Initialized
INFO - 2017-03-14 17:29:10 --> Language Class Initialized
INFO - 2017-03-14 17:29:10 --> Loader Class Initialized
INFO - 2017-03-14 17:29:10 --> Database Driver Class Initialized
INFO - 2017-03-14 17:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 17:29:10 --> Controller Class Initialized
INFO - 2017-03-14 17:29:10 --> Helper loaded: url_helper
DEBUG - 2017-03-14 17:29:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 17:29:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 17:29:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 17:29:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 17:29:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 17:29:10 --> Final output sent to browser
DEBUG - 2017-03-14 17:29:10 --> Total execution time: 0.0141
INFO - 2017-03-14 17:30:14 --> Config Class Initialized
INFO - 2017-03-14 17:30:14 --> Hooks Class Initialized
DEBUG - 2017-03-14 17:30:14 --> UTF-8 Support Enabled
INFO - 2017-03-14 17:30:14 --> Utf8 Class Initialized
INFO - 2017-03-14 17:30:14 --> URI Class Initialized
INFO - 2017-03-14 17:30:14 --> Router Class Initialized
INFO - 2017-03-14 17:30:14 --> Output Class Initialized
INFO - 2017-03-14 17:30:14 --> Security Class Initialized
DEBUG - 2017-03-14 17:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 17:30:14 --> Input Class Initialized
INFO - 2017-03-14 17:30:14 --> Language Class Initialized
INFO - 2017-03-14 17:30:14 --> Loader Class Initialized
INFO - 2017-03-14 17:30:14 --> Database Driver Class Initialized
INFO - 2017-03-14 17:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 17:30:15 --> Controller Class Initialized
INFO - 2017-03-14 17:30:15 --> Helper loaded: url_helper
DEBUG - 2017-03-14 17:30:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 17:30:18 --> Config Class Initialized
INFO - 2017-03-14 17:30:18 --> Hooks Class Initialized
DEBUG - 2017-03-14 17:30:18 --> UTF-8 Support Enabled
INFO - 2017-03-14 17:30:18 --> Utf8 Class Initialized
INFO - 2017-03-14 17:30:18 --> URI Class Initialized
INFO - 2017-03-14 17:30:18 --> Router Class Initialized
INFO - 2017-03-14 17:30:18 --> Output Class Initialized
INFO - 2017-03-14 17:30:18 --> Security Class Initialized
DEBUG - 2017-03-14 17:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 17:30:18 --> Input Class Initialized
INFO - 2017-03-14 17:30:18 --> Language Class Initialized
INFO - 2017-03-14 17:30:18 --> Loader Class Initialized
INFO - 2017-03-14 17:30:19 --> Database Driver Class Initialized
INFO - 2017-03-14 17:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 17:30:19 --> Controller Class Initialized
INFO - 2017-03-14 17:30:19 --> Helper loaded: date_helper
DEBUG - 2017-03-14 17:30:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 17:30:19 --> Helper loaded: url_helper
INFO - 2017-03-14 17:30:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 17:30:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 17:30:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 17:30:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 17:30:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 17:30:19 --> Final output sent to browser
DEBUG - 2017-03-14 17:30:19 --> Total execution time: 1.4114
INFO - 2017-03-14 18:18:15 --> Config Class Initialized
INFO - 2017-03-14 18:18:15 --> Hooks Class Initialized
DEBUG - 2017-03-14 18:18:16 --> UTF-8 Support Enabled
INFO - 2017-03-14 18:18:16 --> Utf8 Class Initialized
INFO - 2017-03-14 18:18:16 --> URI Class Initialized
DEBUG - 2017-03-14 18:18:16 --> No URI present. Default controller set.
INFO - 2017-03-14 18:18:16 --> Router Class Initialized
INFO - 2017-03-14 18:18:16 --> Output Class Initialized
INFO - 2017-03-14 18:18:16 --> Security Class Initialized
DEBUG - 2017-03-14 18:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 18:18:16 --> Input Class Initialized
INFO - 2017-03-14 18:18:16 --> Language Class Initialized
INFO - 2017-03-14 18:18:16 --> Loader Class Initialized
INFO - 2017-03-14 18:18:16 --> Database Driver Class Initialized
INFO - 2017-03-14 18:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 18:18:16 --> Controller Class Initialized
INFO - 2017-03-14 18:18:16 --> Helper loaded: url_helper
DEBUG - 2017-03-14 18:18:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 18:18:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 18:18:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 18:18:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 18:18:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 18:18:17 --> Final output sent to browser
DEBUG - 2017-03-14 18:18:17 --> Total execution time: 1.3043
INFO - 2017-03-14 19:03:00 --> Config Class Initialized
INFO - 2017-03-14 19:03:00 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:03:00 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:03:00 --> Utf8 Class Initialized
INFO - 2017-03-14 19:03:00 --> URI Class Initialized
DEBUG - 2017-03-14 19:03:00 --> No URI present. Default controller set.
INFO - 2017-03-14 19:03:00 --> Router Class Initialized
INFO - 2017-03-14 19:03:00 --> Output Class Initialized
INFO - 2017-03-14 19:03:00 --> Security Class Initialized
DEBUG - 2017-03-14 19:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:03:00 --> Input Class Initialized
INFO - 2017-03-14 19:03:00 --> Language Class Initialized
INFO - 2017-03-14 19:03:00 --> Loader Class Initialized
INFO - 2017-03-14 19:03:01 --> Database Driver Class Initialized
INFO - 2017-03-14 19:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:03:01 --> Controller Class Initialized
INFO - 2017-03-14 19:03:01 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:03:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:03:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:03:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:03:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:03:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:03:01 --> Final output sent to browser
DEBUG - 2017-03-14 19:03:01 --> Total execution time: 1.5507
INFO - 2017-03-14 19:03:03 --> Config Class Initialized
INFO - 2017-03-14 19:03:03 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:03:03 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:03:03 --> Utf8 Class Initialized
INFO - 2017-03-14 19:03:03 --> URI Class Initialized
DEBUG - 2017-03-14 19:03:03 --> No URI present. Default controller set.
INFO - 2017-03-14 19:03:03 --> Router Class Initialized
INFO - 2017-03-14 19:03:03 --> Output Class Initialized
INFO - 2017-03-14 19:03:03 --> Security Class Initialized
DEBUG - 2017-03-14 19:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:03:04 --> Input Class Initialized
INFO - 2017-03-14 19:03:04 --> Language Class Initialized
INFO - 2017-03-14 19:03:04 --> Loader Class Initialized
INFO - 2017-03-14 19:03:04 --> Database Driver Class Initialized
INFO - 2017-03-14 19:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:03:04 --> Controller Class Initialized
INFO - 2017-03-14 19:03:04 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:03:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:03:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:03:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:03:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:03:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:03:04 --> Final output sent to browser
DEBUG - 2017-03-14 19:03:04 --> Total execution time: 2.0718
INFO - 2017-03-14 19:03:16 --> Config Class Initialized
INFO - 2017-03-14 19:03:16 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:03:16 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:03:16 --> Utf8 Class Initialized
INFO - 2017-03-14 19:03:16 --> URI Class Initialized
INFO - 2017-03-14 19:03:16 --> Router Class Initialized
INFO - 2017-03-14 19:03:16 --> Output Class Initialized
INFO - 2017-03-14 19:03:16 --> Security Class Initialized
DEBUG - 2017-03-14 19:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:03:16 --> Input Class Initialized
INFO - 2017-03-14 19:03:16 --> Language Class Initialized
INFO - 2017-03-14 19:03:16 --> Loader Class Initialized
INFO - 2017-03-14 19:03:17 --> Database Driver Class Initialized
INFO - 2017-03-14 19:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:03:18 --> Controller Class Initialized
INFO - 2017-03-14 19:03:18 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:03:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:03:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:03:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:03:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:03:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:03:18 --> Final output sent to browser
DEBUG - 2017-03-14 19:03:18 --> Total execution time: 2.3727
INFO - 2017-03-14 19:03:20 --> Config Class Initialized
INFO - 2017-03-14 19:03:20 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:03:20 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:03:20 --> Utf8 Class Initialized
INFO - 2017-03-14 19:03:20 --> URI Class Initialized
INFO - 2017-03-14 19:03:20 --> Router Class Initialized
INFO - 2017-03-14 19:03:21 --> Output Class Initialized
INFO - 2017-03-14 19:03:21 --> Security Class Initialized
DEBUG - 2017-03-14 19:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:03:21 --> Input Class Initialized
INFO - 2017-03-14 19:03:21 --> Language Class Initialized
INFO - 2017-03-14 19:03:21 --> Loader Class Initialized
INFO - 2017-03-14 19:03:21 --> Database Driver Class Initialized
INFO - 2017-03-14 19:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:03:21 --> Controller Class Initialized
INFO - 2017-03-14 19:03:21 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:03:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:03:24 --> Config Class Initialized
INFO - 2017-03-14 19:03:24 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:03:24 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:03:24 --> Utf8 Class Initialized
INFO - 2017-03-14 19:03:24 --> URI Class Initialized
INFO - 2017-03-14 19:03:24 --> Router Class Initialized
INFO - 2017-03-14 19:03:24 --> Output Class Initialized
INFO - 2017-03-14 19:03:24 --> Security Class Initialized
DEBUG - 2017-03-14 19:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:03:24 --> Input Class Initialized
INFO - 2017-03-14 19:03:24 --> Language Class Initialized
INFO - 2017-03-14 19:03:24 --> Loader Class Initialized
INFO - 2017-03-14 19:03:24 --> Database Driver Class Initialized
INFO - 2017-03-14 19:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:03:24 --> Controller Class Initialized
INFO - 2017-03-14 19:03:24 --> Helper loaded: date_helper
DEBUG - 2017-03-14 19:03:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:03:25 --> Helper loaded: url_helper
INFO - 2017-03-14 19:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 19:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 19:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 19:03:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:03:25 --> Final output sent to browser
DEBUG - 2017-03-14 19:03:25 --> Total execution time: 1.0960
INFO - 2017-03-14 19:03:29 --> Config Class Initialized
INFO - 2017-03-14 19:03:29 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:03:29 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:03:29 --> Utf8 Class Initialized
INFO - 2017-03-14 19:03:29 --> URI Class Initialized
INFO - 2017-03-14 19:03:29 --> Router Class Initialized
INFO - 2017-03-14 19:03:29 --> Output Class Initialized
INFO - 2017-03-14 19:03:29 --> Security Class Initialized
DEBUG - 2017-03-14 19:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:03:29 --> Input Class Initialized
INFO - 2017-03-14 19:03:29 --> Language Class Initialized
INFO - 2017-03-14 19:03:29 --> Loader Class Initialized
INFO - 2017-03-14 19:03:29 --> Database Driver Class Initialized
INFO - 2017-03-14 19:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:03:30 --> Controller Class Initialized
INFO - 2017-03-14 19:03:30 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:03:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:03:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:03:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:03:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:03:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:03:30 --> Final output sent to browser
DEBUG - 2017-03-14 19:03:30 --> Total execution time: 3.3210
INFO - 2017-03-14 19:03:33 --> Config Class Initialized
INFO - 2017-03-14 19:03:33 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:03:33 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:03:33 --> Utf8 Class Initialized
INFO - 2017-03-14 19:03:33 --> URI Class Initialized
DEBUG - 2017-03-14 19:03:33 --> No URI present. Default controller set.
INFO - 2017-03-14 19:03:33 --> Router Class Initialized
INFO - 2017-03-14 19:03:33 --> Output Class Initialized
INFO - 2017-03-14 19:03:33 --> Security Class Initialized
DEBUG - 2017-03-14 19:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:03:33 --> Input Class Initialized
INFO - 2017-03-14 19:03:33 --> Language Class Initialized
INFO - 2017-03-14 19:03:33 --> Loader Class Initialized
INFO - 2017-03-14 19:03:34 --> Database Driver Class Initialized
INFO - 2017-03-14 19:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:03:34 --> Controller Class Initialized
INFO - 2017-03-14 19:03:34 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:03:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:03:34 --> Final output sent to browser
DEBUG - 2017-03-14 19:03:34 --> Total execution time: 1.2537
INFO - 2017-03-14 19:03:37 --> Config Class Initialized
INFO - 2017-03-14 19:03:37 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:03:37 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:03:37 --> Utf8 Class Initialized
INFO - 2017-03-14 19:03:37 --> URI Class Initialized
INFO - 2017-03-14 19:03:37 --> Router Class Initialized
INFO - 2017-03-14 19:03:37 --> Output Class Initialized
INFO - 2017-03-14 19:03:37 --> Security Class Initialized
DEBUG - 2017-03-14 19:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:03:37 --> Input Class Initialized
INFO - 2017-03-14 19:03:37 --> Language Class Initialized
INFO - 2017-03-14 19:03:37 --> Loader Class Initialized
INFO - 2017-03-14 19:03:37 --> Database Driver Class Initialized
INFO - 2017-03-14 19:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:03:37 --> Controller Class Initialized
INFO - 2017-03-14 19:03:37 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:03:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:03:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:03:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:03:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:03:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:03:37 --> Final output sent to browser
DEBUG - 2017-03-14 19:03:37 --> Total execution time: 0.0136
INFO - 2017-03-14 19:04:02 --> Config Class Initialized
INFO - 2017-03-14 19:04:02 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:04:02 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:04:02 --> Utf8 Class Initialized
INFO - 2017-03-14 19:04:02 --> URI Class Initialized
INFO - 2017-03-14 19:04:02 --> Router Class Initialized
INFO - 2017-03-14 19:04:02 --> Output Class Initialized
INFO - 2017-03-14 19:04:02 --> Security Class Initialized
DEBUG - 2017-03-14 19:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:04:02 --> Input Class Initialized
INFO - 2017-03-14 19:04:02 --> Language Class Initialized
INFO - 2017-03-14 19:04:02 --> Loader Class Initialized
INFO - 2017-03-14 19:04:03 --> Database Driver Class Initialized
INFO - 2017-03-14 19:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:04:04 --> Controller Class Initialized
INFO - 2017-03-14 19:04:04 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:04:07 --> Config Class Initialized
INFO - 2017-03-14 19:04:07 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:04:07 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:04:07 --> Utf8 Class Initialized
INFO - 2017-03-14 19:04:07 --> URI Class Initialized
INFO - 2017-03-14 19:04:07 --> Router Class Initialized
INFO - 2017-03-14 19:04:07 --> Output Class Initialized
INFO - 2017-03-14 19:04:07 --> Security Class Initialized
DEBUG - 2017-03-14 19:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:04:07 --> Input Class Initialized
INFO - 2017-03-14 19:04:07 --> Language Class Initialized
INFO - 2017-03-14 19:04:07 --> Loader Class Initialized
INFO - 2017-03-14 19:04:07 --> Database Driver Class Initialized
INFO - 2017-03-14 19:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:04:07 --> Controller Class Initialized
INFO - 2017-03-14 19:04:07 --> Helper loaded: date_helper
DEBUG - 2017-03-14 19:04:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:04:07 --> Helper loaded: url_helper
INFO - 2017-03-14 19:04:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:04:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 19:04:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 19:04:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 19:04:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:04:07 --> Final output sent to browser
DEBUG - 2017-03-14 19:04:07 --> Total execution time: 0.7784
INFO - 2017-03-14 19:04:09 --> Config Class Initialized
INFO - 2017-03-14 19:04:09 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:04:09 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:04:09 --> Utf8 Class Initialized
INFO - 2017-03-14 19:04:09 --> URI Class Initialized
INFO - 2017-03-14 19:04:09 --> Router Class Initialized
INFO - 2017-03-14 19:04:09 --> Output Class Initialized
INFO - 2017-03-14 19:04:09 --> Security Class Initialized
DEBUG - 2017-03-14 19:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:04:09 --> Input Class Initialized
INFO - 2017-03-14 19:04:09 --> Language Class Initialized
INFO - 2017-03-14 19:04:09 --> Loader Class Initialized
INFO - 2017-03-14 19:04:09 --> Database Driver Class Initialized
INFO - 2017-03-14 19:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:04:09 --> Controller Class Initialized
INFO - 2017-03-14 19:04:09 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:04:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:04:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:04:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:04:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:04:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:04:09 --> Final output sent to browser
DEBUG - 2017-03-14 19:04:09 --> Total execution time: 0.1530
INFO - 2017-03-14 19:04:30 --> Config Class Initialized
INFO - 2017-03-14 19:04:30 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:04:30 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:04:30 --> Utf8 Class Initialized
INFO - 2017-03-14 19:04:30 --> URI Class Initialized
DEBUG - 2017-03-14 19:04:31 --> No URI present. Default controller set.
INFO - 2017-03-14 19:04:31 --> Router Class Initialized
INFO - 2017-03-14 19:04:31 --> Output Class Initialized
INFO - 2017-03-14 19:04:31 --> Security Class Initialized
DEBUG - 2017-03-14 19:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:04:31 --> Input Class Initialized
INFO - 2017-03-14 19:04:31 --> Language Class Initialized
INFO - 2017-03-14 19:04:31 --> Loader Class Initialized
INFO - 2017-03-14 19:04:31 --> Database Driver Class Initialized
INFO - 2017-03-14 19:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:04:31 --> Controller Class Initialized
INFO - 2017-03-14 19:04:31 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:04:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:04:31 --> Final output sent to browser
DEBUG - 2017-03-14 19:04:31 --> Total execution time: 0.0523
INFO - 2017-03-14 19:04:32 --> Config Class Initialized
INFO - 2017-03-14 19:04:32 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:04:32 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:04:32 --> Utf8 Class Initialized
INFO - 2017-03-14 19:04:32 --> URI Class Initialized
INFO - 2017-03-14 19:04:32 --> Router Class Initialized
INFO - 2017-03-14 19:04:32 --> Output Class Initialized
INFO - 2017-03-14 19:04:32 --> Security Class Initialized
DEBUG - 2017-03-14 19:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:04:32 --> Input Class Initialized
INFO - 2017-03-14 19:04:32 --> Language Class Initialized
INFO - 2017-03-14 19:04:32 --> Loader Class Initialized
INFO - 2017-03-14 19:04:32 --> Database Driver Class Initialized
INFO - 2017-03-14 19:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:04:32 --> Controller Class Initialized
INFO - 2017-03-14 19:04:32 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:04:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:04:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:04:32 --> Final output sent to browser
DEBUG - 2017-03-14 19:04:32 --> Total execution time: 0.0156
INFO - 2017-03-14 19:04:37 --> Config Class Initialized
INFO - 2017-03-14 19:04:37 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:04:37 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:04:37 --> Utf8 Class Initialized
INFO - 2017-03-14 19:04:37 --> URI Class Initialized
INFO - 2017-03-14 19:04:37 --> Router Class Initialized
INFO - 2017-03-14 19:04:37 --> Output Class Initialized
INFO - 2017-03-14 19:04:37 --> Security Class Initialized
DEBUG - 2017-03-14 19:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:04:37 --> Input Class Initialized
INFO - 2017-03-14 19:04:37 --> Language Class Initialized
INFO - 2017-03-14 19:04:37 --> Loader Class Initialized
INFO - 2017-03-14 19:04:37 --> Database Driver Class Initialized
INFO - 2017-03-14 19:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:04:37 --> Controller Class Initialized
INFO - 2017-03-14 19:04:37 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:04:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:04:38 --> Config Class Initialized
INFO - 2017-03-14 19:04:38 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:04:38 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:04:38 --> Utf8 Class Initialized
INFO - 2017-03-14 19:04:38 --> URI Class Initialized
INFO - 2017-03-14 19:04:38 --> Router Class Initialized
INFO - 2017-03-14 19:04:38 --> Output Class Initialized
INFO - 2017-03-14 19:04:38 --> Security Class Initialized
DEBUG - 2017-03-14 19:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:04:38 --> Input Class Initialized
INFO - 2017-03-14 19:04:38 --> Language Class Initialized
INFO - 2017-03-14 19:04:38 --> Loader Class Initialized
INFO - 2017-03-14 19:04:38 --> Database Driver Class Initialized
INFO - 2017-03-14 19:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:04:38 --> Controller Class Initialized
INFO - 2017-03-14 19:04:38 --> Helper loaded: date_helper
DEBUG - 2017-03-14 19:04:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:04:38 --> Helper loaded: url_helper
INFO - 2017-03-14 19:04:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:04:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 19:04:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 19:04:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 19:04:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:04:38 --> Final output sent to browser
DEBUG - 2017-03-14 19:04:38 --> Total execution time: 0.0142
INFO - 2017-03-14 19:04:39 --> Config Class Initialized
INFO - 2017-03-14 19:04:39 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:04:39 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:04:39 --> Utf8 Class Initialized
INFO - 2017-03-14 19:04:39 --> URI Class Initialized
INFO - 2017-03-14 19:04:39 --> Router Class Initialized
INFO - 2017-03-14 19:04:39 --> Output Class Initialized
INFO - 2017-03-14 19:04:39 --> Security Class Initialized
DEBUG - 2017-03-14 19:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:04:39 --> Input Class Initialized
INFO - 2017-03-14 19:04:39 --> Language Class Initialized
INFO - 2017-03-14 19:04:39 --> Loader Class Initialized
INFO - 2017-03-14 19:04:39 --> Database Driver Class Initialized
INFO - 2017-03-14 19:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:04:39 --> Controller Class Initialized
INFO - 2017-03-14 19:04:39 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:04:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:04:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:04:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:04:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:04:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:04:39 --> Final output sent to browser
DEBUG - 2017-03-14 19:04:39 --> Total execution time: 0.0136
INFO - 2017-03-14 19:04:44 --> Config Class Initialized
INFO - 2017-03-14 19:04:44 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:04:44 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:04:44 --> Utf8 Class Initialized
INFO - 2017-03-14 19:04:44 --> URI Class Initialized
DEBUG - 2017-03-14 19:04:44 --> No URI present. Default controller set.
INFO - 2017-03-14 19:04:44 --> Router Class Initialized
INFO - 2017-03-14 19:04:44 --> Output Class Initialized
INFO - 2017-03-14 19:04:44 --> Security Class Initialized
DEBUG - 2017-03-14 19:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:04:44 --> Input Class Initialized
INFO - 2017-03-14 19:04:44 --> Language Class Initialized
INFO - 2017-03-14 19:04:44 --> Loader Class Initialized
INFO - 2017-03-14 19:04:44 --> Database Driver Class Initialized
INFO - 2017-03-14 19:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:04:44 --> Controller Class Initialized
INFO - 2017-03-14 19:04:44 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:04:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:04:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:04:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:04:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:04:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:04:44 --> Final output sent to browser
DEBUG - 2017-03-14 19:04:44 --> Total execution time: 0.0150
INFO - 2017-03-14 19:04:46 --> Config Class Initialized
INFO - 2017-03-14 19:04:46 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:04:46 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:04:46 --> Utf8 Class Initialized
INFO - 2017-03-14 19:04:46 --> URI Class Initialized
INFO - 2017-03-14 19:04:46 --> Router Class Initialized
INFO - 2017-03-14 19:04:46 --> Output Class Initialized
INFO - 2017-03-14 19:04:46 --> Security Class Initialized
DEBUG - 2017-03-14 19:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:04:46 --> Input Class Initialized
INFO - 2017-03-14 19:04:46 --> Language Class Initialized
INFO - 2017-03-14 19:04:46 --> Loader Class Initialized
INFO - 2017-03-14 19:04:46 --> Database Driver Class Initialized
INFO - 2017-03-14 19:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:04:46 --> Controller Class Initialized
INFO - 2017-03-14 19:04:46 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:04:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:04:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:04:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:04:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:04:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:04:46 --> Final output sent to browser
DEBUG - 2017-03-14 19:04:46 --> Total execution time: 0.0154
INFO - 2017-03-14 19:05:09 --> Config Class Initialized
INFO - 2017-03-14 19:05:09 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:05:09 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:05:09 --> Utf8 Class Initialized
INFO - 2017-03-14 19:05:09 --> URI Class Initialized
INFO - 2017-03-14 19:05:09 --> Router Class Initialized
INFO - 2017-03-14 19:05:09 --> Output Class Initialized
INFO - 2017-03-14 19:05:09 --> Security Class Initialized
DEBUG - 2017-03-14 19:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:05:09 --> Input Class Initialized
INFO - 2017-03-14 19:05:09 --> Language Class Initialized
INFO - 2017-03-14 19:05:09 --> Loader Class Initialized
INFO - 2017-03-14 19:05:10 --> Database Driver Class Initialized
INFO - 2017-03-14 19:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:05:10 --> Controller Class Initialized
INFO - 2017-03-14 19:05:10 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:05:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:05:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:05:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:05:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:05:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:05:11 --> Final output sent to browser
DEBUG - 2017-03-14 19:05:11 --> Total execution time: 1.5709
INFO - 2017-03-14 19:05:14 --> Config Class Initialized
INFO - 2017-03-14 19:05:14 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:05:14 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:05:14 --> Utf8 Class Initialized
INFO - 2017-03-14 19:05:14 --> URI Class Initialized
INFO - 2017-03-14 19:05:14 --> Router Class Initialized
INFO - 2017-03-14 19:05:14 --> Output Class Initialized
INFO - 2017-03-14 19:05:14 --> Security Class Initialized
DEBUG - 2017-03-14 19:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:05:14 --> Input Class Initialized
INFO - 2017-03-14 19:05:14 --> Language Class Initialized
INFO - 2017-03-14 19:05:14 --> Loader Class Initialized
INFO - 2017-03-14 19:05:14 --> Database Driver Class Initialized
INFO - 2017-03-14 19:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:05:14 --> Controller Class Initialized
INFO - 2017-03-14 19:05:14 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:05:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:05:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:05:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:05:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:05:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:05:14 --> Final output sent to browser
DEBUG - 2017-03-14 19:05:14 --> Total execution time: 0.0886
INFO - 2017-03-14 19:05:34 --> Config Class Initialized
INFO - 2017-03-14 19:05:34 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:05:34 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:05:34 --> Utf8 Class Initialized
INFO - 2017-03-14 19:05:34 --> URI Class Initialized
INFO - 2017-03-14 19:05:34 --> Router Class Initialized
INFO - 2017-03-14 19:05:34 --> Output Class Initialized
INFO - 2017-03-14 19:05:34 --> Security Class Initialized
DEBUG - 2017-03-14 19:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:05:34 --> Input Class Initialized
INFO - 2017-03-14 19:05:34 --> Language Class Initialized
INFO - 2017-03-14 19:05:34 --> Loader Class Initialized
INFO - 2017-03-14 19:05:34 --> Database Driver Class Initialized
INFO - 2017-03-14 19:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:05:34 --> Controller Class Initialized
INFO - 2017-03-14 19:05:34 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:05:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:05:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:05:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:05:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:05:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:05:34 --> Final output sent to browser
DEBUG - 2017-03-14 19:05:34 --> Total execution time: 0.2065
INFO - 2017-03-14 19:05:36 --> Config Class Initialized
INFO - 2017-03-14 19:05:36 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:05:36 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:05:36 --> Utf8 Class Initialized
INFO - 2017-03-14 19:05:36 --> URI Class Initialized
INFO - 2017-03-14 19:05:36 --> Router Class Initialized
INFO - 2017-03-14 19:05:36 --> Output Class Initialized
INFO - 2017-03-14 19:05:36 --> Security Class Initialized
DEBUG - 2017-03-14 19:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:05:36 --> Input Class Initialized
INFO - 2017-03-14 19:05:36 --> Language Class Initialized
INFO - 2017-03-14 19:05:36 --> Loader Class Initialized
INFO - 2017-03-14 19:05:36 --> Database Driver Class Initialized
INFO - 2017-03-14 19:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:05:36 --> Controller Class Initialized
INFO - 2017-03-14 19:05:36 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:05:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:05:36 --> Final output sent to browser
DEBUG - 2017-03-14 19:05:36 --> Total execution time: 0.0136
INFO - 2017-03-14 19:05:44 --> Config Class Initialized
INFO - 2017-03-14 19:05:44 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:05:44 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:05:44 --> Utf8 Class Initialized
INFO - 2017-03-14 19:05:44 --> URI Class Initialized
INFO - 2017-03-14 19:05:44 --> Router Class Initialized
INFO - 2017-03-14 19:05:44 --> Output Class Initialized
INFO - 2017-03-14 19:05:44 --> Security Class Initialized
DEBUG - 2017-03-14 19:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:05:44 --> Input Class Initialized
INFO - 2017-03-14 19:05:44 --> Language Class Initialized
INFO - 2017-03-14 19:05:44 --> Loader Class Initialized
INFO - 2017-03-14 19:05:44 --> Database Driver Class Initialized
INFO - 2017-03-14 19:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:05:44 --> Controller Class Initialized
INFO - 2017-03-14 19:05:44 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:05:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:05:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:05:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:05:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:05:44 --> Final output sent to browser
DEBUG - 2017-03-14 19:05:44 --> Total execution time: 0.0152
INFO - 2017-03-14 19:05:46 --> Config Class Initialized
INFO - 2017-03-14 19:05:46 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:05:46 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:05:46 --> Utf8 Class Initialized
INFO - 2017-03-14 19:05:46 --> URI Class Initialized
INFO - 2017-03-14 19:05:46 --> Router Class Initialized
INFO - 2017-03-14 19:05:46 --> Output Class Initialized
INFO - 2017-03-14 19:05:46 --> Security Class Initialized
DEBUG - 2017-03-14 19:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:05:46 --> Input Class Initialized
INFO - 2017-03-14 19:05:46 --> Language Class Initialized
INFO - 2017-03-14 19:05:46 --> Loader Class Initialized
INFO - 2017-03-14 19:05:46 --> Database Driver Class Initialized
INFO - 2017-03-14 19:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:05:46 --> Controller Class Initialized
INFO - 2017-03-14 19:05:46 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:05:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:05:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:05:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:05:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:05:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:05:46 --> Final output sent to browser
DEBUG - 2017-03-14 19:05:46 --> Total execution time: 0.0139
INFO - 2017-03-14 19:05:48 --> Config Class Initialized
INFO - 2017-03-14 19:05:48 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:05:48 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:05:48 --> Utf8 Class Initialized
INFO - 2017-03-14 19:05:48 --> URI Class Initialized
INFO - 2017-03-14 19:05:48 --> Router Class Initialized
INFO - 2017-03-14 19:05:48 --> Output Class Initialized
INFO - 2017-03-14 19:05:48 --> Security Class Initialized
DEBUG - 2017-03-14 19:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:05:48 --> Input Class Initialized
INFO - 2017-03-14 19:05:48 --> Language Class Initialized
INFO - 2017-03-14 19:05:48 --> Loader Class Initialized
INFO - 2017-03-14 19:05:48 --> Database Driver Class Initialized
INFO - 2017-03-14 19:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:05:48 --> Controller Class Initialized
INFO - 2017-03-14 19:05:48 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:05:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:05:48 --> Final output sent to browser
DEBUG - 2017-03-14 19:05:48 --> Total execution time: 0.0151
INFO - 2017-03-14 19:05:50 --> Config Class Initialized
INFO - 2017-03-14 19:05:50 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:05:50 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:05:50 --> Utf8 Class Initialized
INFO - 2017-03-14 19:05:50 --> URI Class Initialized
INFO - 2017-03-14 19:05:50 --> Router Class Initialized
INFO - 2017-03-14 19:05:50 --> Output Class Initialized
INFO - 2017-03-14 19:05:50 --> Security Class Initialized
DEBUG - 2017-03-14 19:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:05:50 --> Input Class Initialized
INFO - 2017-03-14 19:05:50 --> Language Class Initialized
INFO - 2017-03-14 19:05:50 --> Loader Class Initialized
INFO - 2017-03-14 19:05:50 --> Database Driver Class Initialized
INFO - 2017-03-14 19:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:05:50 --> Controller Class Initialized
INFO - 2017-03-14 19:05:50 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:05:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:05:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:05:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:05:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:05:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:05:50 --> Final output sent to browser
DEBUG - 2017-03-14 19:05:50 --> Total execution time: 0.0138
INFO - 2017-03-14 19:05:51 --> Config Class Initialized
INFO - 2017-03-14 19:05:51 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:05:51 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:05:51 --> Utf8 Class Initialized
INFO - 2017-03-14 19:05:51 --> URI Class Initialized
INFO - 2017-03-14 19:05:51 --> Router Class Initialized
INFO - 2017-03-14 19:05:51 --> Output Class Initialized
INFO - 2017-03-14 19:05:51 --> Security Class Initialized
DEBUG - 2017-03-14 19:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:05:51 --> Input Class Initialized
INFO - 2017-03-14 19:05:51 --> Language Class Initialized
INFO - 2017-03-14 19:05:51 --> Loader Class Initialized
INFO - 2017-03-14 19:05:51 --> Database Driver Class Initialized
INFO - 2017-03-14 19:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:05:51 --> Controller Class Initialized
INFO - 2017-03-14 19:05:51 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:05:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:05:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:05:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:05:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:05:51 --> Final output sent to browser
DEBUG - 2017-03-14 19:05:51 --> Total execution time: 0.0177
INFO - 2017-03-14 19:05:53 --> Config Class Initialized
INFO - 2017-03-14 19:05:53 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:05:53 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:05:53 --> Utf8 Class Initialized
INFO - 2017-03-14 19:05:53 --> URI Class Initialized
INFO - 2017-03-14 19:05:53 --> Router Class Initialized
INFO - 2017-03-14 19:05:53 --> Output Class Initialized
INFO - 2017-03-14 19:05:53 --> Security Class Initialized
DEBUG - 2017-03-14 19:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:05:53 --> Input Class Initialized
INFO - 2017-03-14 19:05:53 --> Language Class Initialized
INFO - 2017-03-14 19:05:53 --> Loader Class Initialized
INFO - 2017-03-14 19:05:53 --> Database Driver Class Initialized
INFO - 2017-03-14 19:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:05:54 --> Controller Class Initialized
INFO - 2017-03-14 19:05:54 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:05:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:05:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:05:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:05:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:05:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:05:54 --> Final output sent to browser
DEBUG - 2017-03-14 19:05:54 --> Total execution time: 1.2532
INFO - 2017-03-14 19:06:02 --> Config Class Initialized
INFO - 2017-03-14 19:06:02 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:06:02 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:06:02 --> Utf8 Class Initialized
INFO - 2017-03-14 19:06:02 --> URI Class Initialized
DEBUG - 2017-03-14 19:06:02 --> No URI present. Default controller set.
INFO - 2017-03-14 19:06:02 --> Router Class Initialized
INFO - 2017-03-14 19:06:02 --> Output Class Initialized
INFO - 2017-03-14 19:06:02 --> Security Class Initialized
DEBUG - 2017-03-14 19:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:06:02 --> Input Class Initialized
INFO - 2017-03-14 19:06:02 --> Language Class Initialized
INFO - 2017-03-14 19:06:02 --> Loader Class Initialized
INFO - 2017-03-14 19:06:03 --> Database Driver Class Initialized
INFO - 2017-03-14 19:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:06:03 --> Controller Class Initialized
INFO - 2017-03-14 19:06:03 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:06:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:06:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:06:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:06:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:06:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:06:03 --> Final output sent to browser
DEBUG - 2017-03-14 19:06:03 --> Total execution time: 1.2315
INFO - 2017-03-14 19:06:06 --> Config Class Initialized
INFO - 2017-03-14 19:06:06 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:06:06 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:06:06 --> Utf8 Class Initialized
INFO - 2017-03-14 19:06:06 --> URI Class Initialized
INFO - 2017-03-14 19:06:06 --> Router Class Initialized
INFO - 2017-03-14 19:06:06 --> Output Class Initialized
INFO - 2017-03-14 19:06:06 --> Security Class Initialized
DEBUG - 2017-03-14 19:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:06:06 --> Input Class Initialized
INFO - 2017-03-14 19:06:06 --> Language Class Initialized
INFO - 2017-03-14 19:06:06 --> Loader Class Initialized
INFO - 2017-03-14 19:06:06 --> Database Driver Class Initialized
INFO - 2017-03-14 19:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:06:06 --> Controller Class Initialized
INFO - 2017-03-14 19:06:06 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:06:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:06:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:06:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:06:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:06:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:06:06 --> Final output sent to browser
DEBUG - 2017-03-14 19:06:06 --> Total execution time: 0.0137
INFO - 2017-03-14 19:06:18 --> Config Class Initialized
INFO - 2017-03-14 19:06:18 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:06:18 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:06:18 --> Utf8 Class Initialized
INFO - 2017-03-14 19:06:18 --> URI Class Initialized
INFO - 2017-03-14 19:06:18 --> Router Class Initialized
INFO - 2017-03-14 19:06:19 --> Output Class Initialized
INFO - 2017-03-14 19:06:19 --> Security Class Initialized
DEBUG - 2017-03-14 19:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:06:19 --> Input Class Initialized
INFO - 2017-03-14 19:06:19 --> Language Class Initialized
INFO - 2017-03-14 19:06:19 --> Loader Class Initialized
INFO - 2017-03-14 19:06:19 --> Database Driver Class Initialized
INFO - 2017-03-14 19:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:06:19 --> Controller Class Initialized
INFO - 2017-03-14 19:06:19 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:06:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:06:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:06:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:06:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:06:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:06:20 --> Final output sent to browser
DEBUG - 2017-03-14 19:06:20 --> Total execution time: 1.5306
INFO - 2017-03-14 19:06:22 --> Config Class Initialized
INFO - 2017-03-14 19:06:22 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:06:22 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:06:23 --> Utf8 Class Initialized
INFO - 2017-03-14 19:06:23 --> URI Class Initialized
INFO - 2017-03-14 19:06:23 --> Router Class Initialized
INFO - 2017-03-14 19:06:23 --> Output Class Initialized
INFO - 2017-03-14 19:06:23 --> Security Class Initialized
DEBUG - 2017-03-14 19:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:06:23 --> Input Class Initialized
INFO - 2017-03-14 19:06:23 --> Language Class Initialized
INFO - 2017-03-14 19:06:23 --> Loader Class Initialized
INFO - 2017-03-14 19:06:23 --> Database Driver Class Initialized
INFO - 2017-03-14 19:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:06:23 --> Controller Class Initialized
INFO - 2017-03-14 19:06:23 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:06:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:06:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:06:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:06:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:06:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:06:24 --> Final output sent to browser
DEBUG - 2017-03-14 19:06:24 --> Total execution time: 1.2240
INFO - 2017-03-14 19:06:26 --> Config Class Initialized
INFO - 2017-03-14 19:06:26 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:06:26 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:06:26 --> Utf8 Class Initialized
INFO - 2017-03-14 19:06:26 --> URI Class Initialized
INFO - 2017-03-14 19:06:26 --> Router Class Initialized
INFO - 2017-03-14 19:06:26 --> Output Class Initialized
INFO - 2017-03-14 19:06:26 --> Security Class Initialized
DEBUG - 2017-03-14 19:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:06:26 --> Input Class Initialized
INFO - 2017-03-14 19:06:26 --> Language Class Initialized
INFO - 2017-03-14 19:06:26 --> Loader Class Initialized
INFO - 2017-03-14 19:06:26 --> Database Driver Class Initialized
INFO - 2017-03-14 19:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:06:26 --> Controller Class Initialized
INFO - 2017-03-14 19:06:26 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:06:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:06:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:06:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:06:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:06:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:06:27 --> Final output sent to browser
DEBUG - 2017-03-14 19:06:27 --> Total execution time: 1.4212
INFO - 2017-03-14 19:06:31 --> Config Class Initialized
INFO - 2017-03-14 19:06:31 --> Hooks Class Initialized
INFO - 2017-03-14 19:06:31 --> Config Class Initialized
INFO - 2017-03-14 19:06:31 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:06:31 --> UTF-8 Support Enabled
DEBUG - 2017-03-14 19:06:31 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:06:31 --> Utf8 Class Initialized
INFO - 2017-03-14 19:06:31 --> Utf8 Class Initialized
INFO - 2017-03-14 19:06:31 --> URI Class Initialized
INFO - 2017-03-14 19:06:31 --> URI Class Initialized
INFO - 2017-03-14 19:06:32 --> Router Class Initialized
INFO - 2017-03-14 19:06:32 --> Router Class Initialized
INFO - 2017-03-14 19:06:32 --> Output Class Initialized
INFO - 2017-03-14 19:06:32 --> Output Class Initialized
INFO - 2017-03-14 19:06:32 --> Security Class Initialized
INFO - 2017-03-14 19:06:32 --> Security Class Initialized
DEBUG - 2017-03-14 19:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:06:32 --> Input Class Initialized
INFO - 2017-03-14 19:06:32 --> Language Class Initialized
DEBUG - 2017-03-14 19:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:06:32 --> Input Class Initialized
INFO - 2017-03-14 19:06:32 --> Language Class Initialized
INFO - 2017-03-14 19:06:32 --> Loader Class Initialized
INFO - 2017-03-14 19:06:32 --> Loader Class Initialized
INFO - 2017-03-14 19:06:32 --> Database Driver Class Initialized
INFO - 2017-03-14 19:06:32 --> Database Driver Class Initialized
INFO - 2017-03-14 19:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:06:33 --> Controller Class Initialized
INFO - 2017-03-14 19:06:33 --> Controller Class Initialized
INFO - 2017-03-14 19:06:33 --> Helper loaded: url_helper
INFO - 2017-03-14 19:06:33 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:06:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-14 19:06:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:06:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:06:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:06:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:06:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:06:33 --> Final output sent to browser
DEBUG - 2017-03-14 19:06:33 --> Total execution time: 1.7626
INFO - 2017-03-14 19:06:36 --> Config Class Initialized
INFO - 2017-03-14 19:06:36 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:06:36 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:06:36 --> Utf8 Class Initialized
INFO - 2017-03-14 19:06:36 --> URI Class Initialized
INFO - 2017-03-14 19:06:36 --> Router Class Initialized
INFO - 2017-03-14 19:06:36 --> Output Class Initialized
INFO - 2017-03-14 19:06:36 --> Security Class Initialized
DEBUG - 2017-03-14 19:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:06:36 --> Input Class Initialized
INFO - 2017-03-14 19:06:36 --> Language Class Initialized
INFO - 2017-03-14 19:06:37 --> Loader Class Initialized
INFO - 2017-03-14 19:06:37 --> Config Class Initialized
INFO - 2017-03-14 19:06:37 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:06:37 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:06:37 --> Database Driver Class Initialized
INFO - 2017-03-14 19:06:37 --> Utf8 Class Initialized
INFO - 2017-03-14 19:06:37 --> URI Class Initialized
INFO - 2017-03-14 19:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:06:37 --> Router Class Initialized
INFO - 2017-03-14 19:06:37 --> Controller Class Initialized
INFO - 2017-03-14 19:06:37 --> Output Class Initialized
INFO - 2017-03-14 19:06:38 --> Security Class Initialized
DEBUG - 2017-03-14 19:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:06:38 --> Input Class Initialized
INFO - 2017-03-14 19:06:38 --> Helper loaded: date_helper
DEBUG - 2017-03-14 19:06:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:06:38 --> Language Class Initialized
INFO - 2017-03-14 19:06:38 --> Helper loaded: url_helper
INFO - 2017-03-14 19:06:38 --> Loader Class Initialized
INFO - 2017-03-14 19:06:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:06:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 19:06:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 19:06:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 19:06:38 --> Database Driver Class Initialized
INFO - 2017-03-14 19:06:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:06:38 --> Final output sent to browser
DEBUG - 2017-03-14 19:06:38 --> Total execution time: 2.4981
INFO - 2017-03-14 19:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:06:39 --> Controller Class Initialized
INFO - 2017-03-14 19:06:39 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:06:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:06:41 --> Config Class Initialized
INFO - 2017-03-14 19:06:41 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:06:42 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:06:42 --> Utf8 Class Initialized
INFO - 2017-03-14 19:06:42 --> URI Class Initialized
INFO - 2017-03-14 19:06:42 --> Router Class Initialized
INFO - 2017-03-14 19:06:43 --> Output Class Initialized
INFO - 2017-03-14 19:06:44 --> Security Class Initialized
DEBUG - 2017-03-14 19:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:06:44 --> Input Class Initialized
INFO - 2017-03-14 19:06:44 --> Language Class Initialized
INFO - 2017-03-14 19:06:44 --> Loader Class Initialized
INFO - 2017-03-14 19:06:44 --> Database Driver Class Initialized
INFO - 2017-03-14 19:06:45 --> Config Class Initialized
INFO - 2017-03-14 19:06:45 --> Hooks Class Initialized
INFO - 2017-03-14 19:06:45 --> Config Class Initialized
INFO - 2017-03-14 19:06:45 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:06:45 --> UTF-8 Support Enabled
DEBUG - 2017-03-14 19:06:45 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:06:45 --> Utf8 Class Initialized
INFO - 2017-03-14 19:06:45 --> Utf8 Class Initialized
INFO - 2017-03-14 19:06:45 --> URI Class Initialized
INFO - 2017-03-14 19:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:06:45 --> Controller Class Initialized
INFO - 2017-03-14 19:06:45 --> URI Class Initialized
INFO - 2017-03-14 19:06:45 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:06:45 --> No URI present. Default controller set.
INFO - 2017-03-14 19:06:45 --> Router Class Initialized
INFO - 2017-03-14 19:06:45 --> Router Class Initialized
DEBUG - 2017-03-14 19:06:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:06:45 --> Output Class Initialized
INFO - 2017-03-14 19:06:45 --> Output Class Initialized
INFO - 2017-03-14 19:06:45 --> Security Class Initialized
INFO - 2017-03-14 19:06:45 --> Security Class Initialized
DEBUG - 2017-03-14 19:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:06:45 --> Input Class Initialized
DEBUG - 2017-03-14 19:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:06:45 --> Input Class Initialized
INFO - 2017-03-14 19:06:45 --> Language Class Initialized
INFO - 2017-03-14 19:06:45 --> Language Class Initialized
INFO - 2017-03-14 19:06:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:06:45 --> Loader Class Initialized
INFO - 2017-03-14 19:06:45 --> Loader Class Initialized
INFO - 2017-03-14 19:06:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:06:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:06:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:06:46 --> Database Driver Class Initialized
INFO - 2017-03-14 19:06:46 --> Database Driver Class Initialized
INFO - 2017-03-14 19:06:46 --> Final output sent to browser
DEBUG - 2017-03-14 19:06:46 --> Total execution time: 4.8398
INFO - 2017-03-14 19:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:06:46 --> Controller Class Initialized
INFO - 2017-03-14 19:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:06:46 --> Controller Class Initialized
INFO - 2017-03-14 19:06:46 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:06:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:06:46 --> Helper loaded: date_helper
DEBUG - 2017-03-14 19:06:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:06:46 --> Helper loaded: url_helper
INFO - 2017-03-14 19:06:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:06:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:06:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:06:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 19:06:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 19:06:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 19:06:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:06:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:06:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:06:47 --> Final output sent to browser
DEBUG - 2017-03-14 19:06:47 --> Total execution time: 1.9882
INFO - 2017-03-14 19:06:47 --> Final output sent to browser
DEBUG - 2017-03-14 19:06:47 --> Total execution time: 1.9866
INFO - 2017-03-14 19:06:48 --> Config Class Initialized
INFO - 2017-03-14 19:06:48 --> Config Class Initialized
INFO - 2017-03-14 19:06:48 --> Hooks Class Initialized
INFO - 2017-03-14 19:06:48 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:06:48 --> UTF-8 Support Enabled
DEBUG - 2017-03-14 19:06:48 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:06:48 --> Utf8 Class Initialized
INFO - 2017-03-14 19:06:48 --> Utf8 Class Initialized
INFO - 2017-03-14 19:06:48 --> URI Class Initialized
INFO - 2017-03-14 19:06:48 --> URI Class Initialized
INFO - 2017-03-14 19:06:48 --> Router Class Initialized
INFO - 2017-03-14 19:06:48 --> Router Class Initialized
INFO - 2017-03-14 19:06:49 --> Output Class Initialized
INFO - 2017-03-14 19:06:49 --> Output Class Initialized
INFO - 2017-03-14 19:06:49 --> Security Class Initialized
INFO - 2017-03-14 19:06:49 --> Security Class Initialized
DEBUG - 2017-03-14 19:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:06:49 --> Input Class Initialized
DEBUG - 2017-03-14 19:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:06:49 --> Input Class Initialized
INFO - 2017-03-14 19:06:49 --> Language Class Initialized
INFO - 2017-03-14 19:06:49 --> Loader Class Initialized
INFO - 2017-03-14 19:06:49 --> Language Class Initialized
INFO - 2017-03-14 19:06:49 --> Loader Class Initialized
INFO - 2017-03-14 19:06:50 --> Database Driver Class Initialized
INFO - 2017-03-14 19:06:50 --> Database Driver Class Initialized
INFO - 2017-03-14 19:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:06:50 --> Controller Class Initialized
INFO - 2017-03-14 19:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:06:50 --> Helper loaded: url_helper
INFO - 2017-03-14 19:06:50 --> Controller Class Initialized
INFO - 2017-03-14 19:06:50 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:06:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-14 19:06:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:06:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:06:51 --> Final output sent to browser
DEBUG - 2017-03-14 19:06:51 --> Total execution time: 2.5099
INFO - 2017-03-14 19:06:51 --> Final output sent to browser
DEBUG - 2017-03-14 19:06:51 --> Total execution time: 2.5100
INFO - 2017-03-14 19:07:49 --> Config Class Initialized
INFO - 2017-03-14 19:07:49 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:07:49 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:07:49 --> Utf8 Class Initialized
INFO - 2017-03-14 19:07:49 --> URI Class Initialized
INFO - 2017-03-14 19:07:49 --> Router Class Initialized
INFO - 2017-03-14 19:07:49 --> Output Class Initialized
INFO - 2017-03-14 19:07:49 --> Security Class Initialized
DEBUG - 2017-03-14 19:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:07:49 --> Input Class Initialized
INFO - 2017-03-14 19:07:49 --> Language Class Initialized
INFO - 2017-03-14 19:07:49 --> Loader Class Initialized
INFO - 2017-03-14 19:07:50 --> Database Driver Class Initialized
INFO - 2017-03-14 19:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:07:50 --> Controller Class Initialized
INFO - 2017-03-14 19:07:50 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:07:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:07:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:07:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:07:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:07:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:07:50 --> Final output sent to browser
DEBUG - 2017-03-14 19:07:50 --> Total execution time: 1.2585
INFO - 2017-03-14 19:07:52 --> Config Class Initialized
INFO - 2017-03-14 19:07:52 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:07:52 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:07:52 --> Utf8 Class Initialized
INFO - 2017-03-14 19:07:52 --> URI Class Initialized
INFO - 2017-03-14 19:07:52 --> Router Class Initialized
INFO - 2017-03-14 19:07:52 --> Output Class Initialized
INFO - 2017-03-14 19:07:52 --> Security Class Initialized
DEBUG - 2017-03-14 19:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:07:52 --> Input Class Initialized
INFO - 2017-03-14 19:07:52 --> Language Class Initialized
INFO - 2017-03-14 19:07:52 --> Loader Class Initialized
INFO - 2017-03-14 19:07:52 --> Database Driver Class Initialized
INFO - 2017-03-14 19:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:07:52 --> Controller Class Initialized
INFO - 2017-03-14 19:07:52 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:07:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:07:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:07:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:07:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:07:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:07:52 --> Final output sent to browser
DEBUG - 2017-03-14 19:07:52 --> Total execution time: 0.0142
INFO - 2017-03-14 19:08:04 --> Config Class Initialized
INFO - 2017-03-14 19:08:04 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:08:04 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:08:04 --> Utf8 Class Initialized
INFO - 2017-03-14 19:08:04 --> URI Class Initialized
DEBUG - 2017-03-14 19:08:04 --> No URI present. Default controller set.
INFO - 2017-03-14 19:08:04 --> Router Class Initialized
INFO - 2017-03-14 19:08:04 --> Output Class Initialized
INFO - 2017-03-14 19:08:04 --> Security Class Initialized
DEBUG - 2017-03-14 19:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:08:04 --> Input Class Initialized
INFO - 2017-03-14 19:08:04 --> Language Class Initialized
INFO - 2017-03-14 19:08:04 --> Loader Class Initialized
INFO - 2017-03-14 19:08:04 --> Database Driver Class Initialized
INFO - 2017-03-14 19:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:08:04 --> Controller Class Initialized
INFO - 2017-03-14 19:08:04 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:08:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:08:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:08:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:08:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:08:04 --> Final output sent to browser
DEBUG - 2017-03-14 19:08:04 --> Total execution time: 0.0134
INFO - 2017-03-14 19:08:05 --> Config Class Initialized
INFO - 2017-03-14 19:08:05 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:08:05 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:08:05 --> Utf8 Class Initialized
INFO - 2017-03-14 19:08:05 --> URI Class Initialized
INFO - 2017-03-14 19:08:05 --> Router Class Initialized
INFO - 2017-03-14 19:08:05 --> Output Class Initialized
INFO - 2017-03-14 19:08:05 --> Security Class Initialized
DEBUG - 2017-03-14 19:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:08:05 --> Input Class Initialized
INFO - 2017-03-14 19:08:05 --> Language Class Initialized
INFO - 2017-03-14 19:08:05 --> Loader Class Initialized
INFO - 2017-03-14 19:08:05 --> Database Driver Class Initialized
INFO - 2017-03-14 19:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:08:05 --> Controller Class Initialized
INFO - 2017-03-14 19:08:05 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:08:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:08:05 --> Final output sent to browser
DEBUG - 2017-03-14 19:08:05 --> Total execution time: 0.0147
INFO - 2017-03-14 19:08:12 --> Config Class Initialized
INFO - 2017-03-14 19:08:12 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:08:12 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:08:12 --> Utf8 Class Initialized
INFO - 2017-03-14 19:08:12 --> URI Class Initialized
INFO - 2017-03-14 19:08:12 --> Router Class Initialized
INFO - 2017-03-14 19:08:12 --> Output Class Initialized
INFO - 2017-03-14 19:08:12 --> Security Class Initialized
DEBUG - 2017-03-14 19:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:08:12 --> Input Class Initialized
INFO - 2017-03-14 19:08:12 --> Language Class Initialized
INFO - 2017-03-14 19:08:12 --> Loader Class Initialized
INFO - 2017-03-14 19:08:12 --> Database Driver Class Initialized
INFO - 2017-03-14 19:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:08:12 --> Controller Class Initialized
INFO - 2017-03-14 19:08:12 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:08:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:08:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:08:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:08:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:08:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:08:12 --> Final output sent to browser
DEBUG - 2017-03-14 19:08:12 --> Total execution time: 0.0487
INFO - 2017-03-14 19:08:13 --> Config Class Initialized
INFO - 2017-03-14 19:08:13 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:08:13 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:08:13 --> Utf8 Class Initialized
INFO - 2017-03-14 19:08:13 --> URI Class Initialized
INFO - 2017-03-14 19:08:13 --> Router Class Initialized
INFO - 2017-03-14 19:08:13 --> Output Class Initialized
INFO - 2017-03-14 19:08:13 --> Security Class Initialized
DEBUG - 2017-03-14 19:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:08:13 --> Input Class Initialized
INFO - 2017-03-14 19:08:13 --> Language Class Initialized
INFO - 2017-03-14 19:08:13 --> Loader Class Initialized
INFO - 2017-03-14 19:08:13 --> Database Driver Class Initialized
INFO - 2017-03-14 19:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:08:13 --> Controller Class Initialized
INFO - 2017-03-14 19:08:13 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:08:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:08:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:08:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:08:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:08:13 --> Final output sent to browser
DEBUG - 2017-03-14 19:08:13 --> Total execution time: 0.0149
INFO - 2017-03-14 19:08:14 --> Config Class Initialized
INFO - 2017-03-14 19:08:14 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:08:14 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:08:14 --> Utf8 Class Initialized
INFO - 2017-03-14 19:08:14 --> URI Class Initialized
DEBUG - 2017-03-14 19:08:14 --> No URI present. Default controller set.
INFO - 2017-03-14 19:08:14 --> Router Class Initialized
INFO - 2017-03-14 19:08:14 --> Output Class Initialized
INFO - 2017-03-14 19:08:14 --> Security Class Initialized
DEBUG - 2017-03-14 19:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:08:14 --> Input Class Initialized
INFO - 2017-03-14 19:08:14 --> Language Class Initialized
INFO - 2017-03-14 19:08:14 --> Loader Class Initialized
INFO - 2017-03-14 19:08:14 --> Database Driver Class Initialized
INFO - 2017-03-14 19:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:08:14 --> Controller Class Initialized
INFO - 2017-03-14 19:08:14 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:08:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:08:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:08:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:08:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:08:14 --> Final output sent to browser
DEBUG - 2017-03-14 19:08:14 --> Total execution time: 0.0134
INFO - 2017-03-14 19:08:15 --> Config Class Initialized
INFO - 2017-03-14 19:08:15 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:08:15 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:08:15 --> Utf8 Class Initialized
INFO - 2017-03-14 19:08:15 --> URI Class Initialized
INFO - 2017-03-14 19:08:15 --> Router Class Initialized
INFO - 2017-03-14 19:08:15 --> Output Class Initialized
INFO - 2017-03-14 19:08:15 --> Security Class Initialized
DEBUG - 2017-03-14 19:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:08:15 --> Input Class Initialized
INFO - 2017-03-14 19:08:15 --> Language Class Initialized
INFO - 2017-03-14 19:08:15 --> Loader Class Initialized
INFO - 2017-03-14 19:08:15 --> Database Driver Class Initialized
INFO - 2017-03-14 19:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:08:15 --> Controller Class Initialized
INFO - 2017-03-14 19:08:15 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:08:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:08:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:08:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:08:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:08:15 --> Final output sent to browser
DEBUG - 2017-03-14 19:08:15 --> Total execution time: 0.0141
INFO - 2017-03-14 19:08:21 --> Config Class Initialized
INFO - 2017-03-14 19:08:21 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:08:21 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:08:21 --> Utf8 Class Initialized
INFO - 2017-03-14 19:08:21 --> URI Class Initialized
INFO - 2017-03-14 19:08:21 --> Router Class Initialized
INFO - 2017-03-14 19:08:21 --> Output Class Initialized
INFO - 2017-03-14 19:08:21 --> Security Class Initialized
DEBUG - 2017-03-14 19:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:08:21 --> Input Class Initialized
INFO - 2017-03-14 19:08:21 --> Language Class Initialized
INFO - 2017-03-14 19:08:21 --> Loader Class Initialized
INFO - 2017-03-14 19:08:21 --> Database Driver Class Initialized
INFO - 2017-03-14 19:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:08:21 --> Controller Class Initialized
INFO - 2017-03-14 19:08:21 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:08:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:08:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:08:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:08:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:08:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:08:21 --> Final output sent to browser
DEBUG - 2017-03-14 19:08:21 --> Total execution time: 0.0165
INFO - 2017-03-14 19:08:22 --> Config Class Initialized
INFO - 2017-03-14 19:08:22 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:08:22 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:08:22 --> Utf8 Class Initialized
INFO - 2017-03-14 19:08:22 --> URI Class Initialized
INFO - 2017-03-14 19:08:22 --> Router Class Initialized
INFO - 2017-03-14 19:08:22 --> Output Class Initialized
INFO - 2017-03-14 19:08:22 --> Security Class Initialized
DEBUG - 2017-03-14 19:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:08:22 --> Input Class Initialized
INFO - 2017-03-14 19:08:22 --> Language Class Initialized
INFO - 2017-03-14 19:08:22 --> Loader Class Initialized
INFO - 2017-03-14 19:08:22 --> Database Driver Class Initialized
INFO - 2017-03-14 19:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:08:22 --> Controller Class Initialized
INFO - 2017-03-14 19:08:22 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:08:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:08:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:08:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:08:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:08:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:08:22 --> Final output sent to browser
DEBUG - 2017-03-14 19:08:22 --> Total execution time: 0.0139
INFO - 2017-03-14 19:08:32 --> Config Class Initialized
INFO - 2017-03-14 19:08:32 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:08:32 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:08:32 --> Utf8 Class Initialized
INFO - 2017-03-14 19:08:32 --> URI Class Initialized
INFO - 2017-03-14 19:08:32 --> Router Class Initialized
INFO - 2017-03-14 19:08:32 --> Output Class Initialized
INFO - 2017-03-14 19:08:32 --> Security Class Initialized
DEBUG - 2017-03-14 19:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:08:32 --> Input Class Initialized
INFO - 2017-03-14 19:08:32 --> Language Class Initialized
INFO - 2017-03-14 19:08:32 --> Loader Class Initialized
INFO - 2017-03-14 19:08:32 --> Database Driver Class Initialized
INFO - 2017-03-14 19:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:08:32 --> Controller Class Initialized
INFO - 2017-03-14 19:08:32 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:08:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:08:33 --> Config Class Initialized
INFO - 2017-03-14 19:08:33 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:08:33 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:08:33 --> Utf8 Class Initialized
INFO - 2017-03-14 19:08:33 --> URI Class Initialized
INFO - 2017-03-14 19:08:33 --> Router Class Initialized
INFO - 2017-03-14 19:08:33 --> Output Class Initialized
INFO - 2017-03-14 19:08:33 --> Security Class Initialized
DEBUG - 2017-03-14 19:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:08:33 --> Input Class Initialized
INFO - 2017-03-14 19:08:33 --> Language Class Initialized
INFO - 2017-03-14 19:08:33 --> Loader Class Initialized
INFO - 2017-03-14 19:08:33 --> Database Driver Class Initialized
INFO - 2017-03-14 19:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:08:33 --> Controller Class Initialized
INFO - 2017-03-14 19:08:33 --> Helper loaded: date_helper
DEBUG - 2017-03-14 19:08:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:08:33 --> Helper loaded: url_helper
INFO - 2017-03-14 19:08:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:08:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 19:08:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 19:08:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 19:08:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:08:33 --> Final output sent to browser
DEBUG - 2017-03-14 19:08:33 --> Total execution time: 0.0949
INFO - 2017-03-14 19:08:35 --> Config Class Initialized
INFO - 2017-03-14 19:08:35 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:08:35 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:08:35 --> Utf8 Class Initialized
INFO - 2017-03-14 19:08:35 --> URI Class Initialized
INFO - 2017-03-14 19:08:35 --> Router Class Initialized
INFO - 2017-03-14 19:08:35 --> Output Class Initialized
INFO - 2017-03-14 19:08:35 --> Security Class Initialized
DEBUG - 2017-03-14 19:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:08:35 --> Input Class Initialized
INFO - 2017-03-14 19:08:35 --> Language Class Initialized
INFO - 2017-03-14 19:08:35 --> Loader Class Initialized
INFO - 2017-03-14 19:08:35 --> Database Driver Class Initialized
INFO - 2017-03-14 19:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:08:35 --> Controller Class Initialized
INFO - 2017-03-14 19:08:35 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:08:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:08:35 --> Final output sent to browser
DEBUG - 2017-03-14 19:08:35 --> Total execution time: 0.0139
INFO - 2017-03-14 19:08:49 --> Config Class Initialized
INFO - 2017-03-14 19:08:49 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:08:49 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:08:49 --> Utf8 Class Initialized
INFO - 2017-03-14 19:08:49 --> URI Class Initialized
DEBUG - 2017-03-14 19:08:49 --> No URI present. Default controller set.
INFO - 2017-03-14 19:08:49 --> Router Class Initialized
INFO - 2017-03-14 19:08:49 --> Output Class Initialized
INFO - 2017-03-14 19:08:49 --> Security Class Initialized
DEBUG - 2017-03-14 19:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:08:49 --> Input Class Initialized
INFO - 2017-03-14 19:08:49 --> Language Class Initialized
INFO - 2017-03-14 19:08:49 --> Loader Class Initialized
INFO - 2017-03-14 19:08:49 --> Database Driver Class Initialized
INFO - 2017-03-14 19:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:08:49 --> Controller Class Initialized
INFO - 2017-03-14 19:08:49 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:08:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:08:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:08:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:08:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:08:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:08:49 --> Final output sent to browser
DEBUG - 2017-03-14 19:08:49 --> Total execution time: 0.0140
INFO - 2017-03-14 19:23:11 --> Config Class Initialized
INFO - 2017-03-14 19:23:11 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:23:11 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:23:11 --> Utf8 Class Initialized
INFO - 2017-03-14 19:23:11 --> URI Class Initialized
DEBUG - 2017-03-14 19:23:11 --> No URI present. Default controller set.
INFO - 2017-03-14 19:23:11 --> Router Class Initialized
INFO - 2017-03-14 19:23:11 --> Output Class Initialized
INFO - 2017-03-14 19:23:11 --> Security Class Initialized
DEBUG - 2017-03-14 19:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:23:11 --> Input Class Initialized
INFO - 2017-03-14 19:23:11 --> Language Class Initialized
INFO - 2017-03-14 19:23:11 --> Loader Class Initialized
INFO - 2017-03-14 19:23:11 --> Database Driver Class Initialized
INFO - 2017-03-14 19:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:23:12 --> Controller Class Initialized
INFO - 2017-03-14 19:23:12 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:23:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:23:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:23:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:23:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:23:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:23:12 --> Final output sent to browser
DEBUG - 2017-03-14 19:23:12 --> Total execution time: 1.4948
INFO - 2017-03-14 19:23:24 --> Config Class Initialized
INFO - 2017-03-14 19:23:24 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:23:24 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:23:24 --> Utf8 Class Initialized
INFO - 2017-03-14 19:23:24 --> URI Class Initialized
INFO - 2017-03-14 19:23:24 --> Router Class Initialized
INFO - 2017-03-14 19:23:24 --> Output Class Initialized
INFO - 2017-03-14 19:23:24 --> Security Class Initialized
DEBUG - 2017-03-14 19:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:23:24 --> Input Class Initialized
INFO - 2017-03-14 19:23:24 --> Language Class Initialized
INFO - 2017-03-14 19:23:24 --> Loader Class Initialized
INFO - 2017-03-14 19:23:24 --> Database Driver Class Initialized
INFO - 2017-03-14 19:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:23:24 --> Controller Class Initialized
INFO - 2017-03-14 19:23:24 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:23:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:23:24 --> Config Class Initialized
INFO - 2017-03-14 19:23:24 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:23:24 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:23:24 --> Utf8 Class Initialized
INFO - 2017-03-14 19:23:24 --> URI Class Initialized
INFO - 2017-03-14 19:23:24 --> Router Class Initialized
INFO - 2017-03-14 19:23:24 --> Output Class Initialized
INFO - 2017-03-14 19:23:24 --> Security Class Initialized
DEBUG - 2017-03-14 19:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:23:24 --> Input Class Initialized
INFO - 2017-03-14 19:23:24 --> Language Class Initialized
INFO - 2017-03-14 19:23:24 --> Loader Class Initialized
INFO - 2017-03-14 19:23:24 --> Database Driver Class Initialized
INFO - 2017-03-14 19:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:23:24 --> Controller Class Initialized
INFO - 2017-03-14 19:23:24 --> Helper loaded: date_helper
DEBUG - 2017-03-14 19:23:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:23:24 --> Helper loaded: url_helper
INFO - 2017-03-14 19:23:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:23:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 19:23:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 19:23:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 19:23:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:23:24 --> Final output sent to browser
DEBUG - 2017-03-14 19:23:24 --> Total execution time: 0.0998
INFO - 2017-03-14 19:23:25 --> Config Class Initialized
INFO - 2017-03-14 19:23:25 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:23:25 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:23:25 --> Utf8 Class Initialized
INFO - 2017-03-14 19:23:25 --> URI Class Initialized
INFO - 2017-03-14 19:23:25 --> Router Class Initialized
INFO - 2017-03-14 19:23:25 --> Output Class Initialized
INFO - 2017-03-14 19:23:25 --> Security Class Initialized
DEBUG - 2017-03-14 19:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:23:25 --> Input Class Initialized
INFO - 2017-03-14 19:23:25 --> Language Class Initialized
INFO - 2017-03-14 19:23:25 --> Loader Class Initialized
INFO - 2017-03-14 19:23:25 --> Database Driver Class Initialized
INFO - 2017-03-14 19:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:23:25 --> Controller Class Initialized
INFO - 2017-03-14 19:23:25 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:23:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:23:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:23:25 --> Final output sent to browser
DEBUG - 2017-03-14 19:23:25 --> Total execution time: 0.0143
INFO - 2017-03-14 19:43:53 --> Config Class Initialized
INFO - 2017-03-14 19:43:53 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:43:53 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:43:53 --> Utf8 Class Initialized
INFO - 2017-03-14 19:43:53 --> URI Class Initialized
DEBUG - 2017-03-14 19:43:53 --> No URI present. Default controller set.
INFO - 2017-03-14 19:43:53 --> Router Class Initialized
INFO - 2017-03-14 19:43:53 --> Output Class Initialized
INFO - 2017-03-14 19:43:53 --> Security Class Initialized
DEBUG - 2017-03-14 19:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:43:53 --> Input Class Initialized
INFO - 2017-03-14 19:43:53 --> Language Class Initialized
INFO - 2017-03-14 19:43:53 --> Loader Class Initialized
INFO - 2017-03-14 19:43:53 --> Database Driver Class Initialized
INFO - 2017-03-14 19:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:43:54 --> Controller Class Initialized
INFO - 2017-03-14 19:43:54 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:43:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:43:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:43:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:43:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:43:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:43:54 --> Final output sent to browser
DEBUG - 2017-03-14 19:43:54 --> Total execution time: 1.6780
INFO - 2017-03-14 19:43:58 --> Config Class Initialized
INFO - 2017-03-14 19:43:58 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:43:58 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:43:58 --> Utf8 Class Initialized
INFO - 2017-03-14 19:43:58 --> URI Class Initialized
INFO - 2017-03-14 19:43:58 --> Router Class Initialized
INFO - 2017-03-14 19:43:58 --> Output Class Initialized
INFO - 2017-03-14 19:43:58 --> Security Class Initialized
DEBUG - 2017-03-14 19:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:43:58 --> Input Class Initialized
INFO - 2017-03-14 19:43:58 --> Language Class Initialized
INFO - 2017-03-14 19:43:58 --> Loader Class Initialized
INFO - 2017-03-14 19:43:58 --> Database Driver Class Initialized
INFO - 2017-03-14 19:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:43:58 --> Controller Class Initialized
INFO - 2017-03-14 19:43:58 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:43:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:43:58 --> Final output sent to browser
DEBUG - 2017-03-14 19:43:58 --> Total execution time: 0.0139
INFO - 2017-03-14 19:46:52 --> Config Class Initialized
INFO - 2017-03-14 19:46:52 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:46:52 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:46:52 --> Utf8 Class Initialized
INFO - 2017-03-14 19:46:52 --> URI Class Initialized
INFO - 2017-03-14 19:46:52 --> Router Class Initialized
INFO - 2017-03-14 19:46:52 --> Output Class Initialized
INFO - 2017-03-14 19:46:52 --> Security Class Initialized
DEBUG - 2017-03-14 19:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:46:52 --> Input Class Initialized
INFO - 2017-03-14 19:46:52 --> Language Class Initialized
INFO - 2017-03-14 19:46:52 --> Loader Class Initialized
INFO - 2017-03-14 19:46:53 --> Database Driver Class Initialized
INFO - 2017-03-14 19:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:46:53 --> Controller Class Initialized
INFO - 2017-03-14 19:46:53 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:46:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:46:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:46:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:46:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:46:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:46:53 --> Final output sent to browser
DEBUG - 2017-03-14 19:46:53 --> Total execution time: 1.2793
INFO - 2017-03-14 19:46:55 --> Config Class Initialized
INFO - 2017-03-14 19:46:55 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:46:55 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:46:55 --> Utf8 Class Initialized
INFO - 2017-03-14 19:46:55 --> URI Class Initialized
INFO - 2017-03-14 19:46:55 --> Router Class Initialized
INFO - 2017-03-14 19:46:55 --> Output Class Initialized
INFO - 2017-03-14 19:46:55 --> Security Class Initialized
DEBUG - 2017-03-14 19:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:46:55 --> Input Class Initialized
INFO - 2017-03-14 19:46:55 --> Language Class Initialized
INFO - 2017-03-14 19:46:55 --> Loader Class Initialized
INFO - 2017-03-14 19:46:55 --> Database Driver Class Initialized
INFO - 2017-03-14 19:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:46:55 --> Controller Class Initialized
INFO - 2017-03-14 19:46:55 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:46:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:46:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:46:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:46:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:46:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:46:55 --> Final output sent to browser
DEBUG - 2017-03-14 19:46:55 --> Total execution time: 0.0143
INFO - 2017-03-14 19:47:17 --> Config Class Initialized
INFO - 2017-03-14 19:47:17 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:47:17 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:47:17 --> Utf8 Class Initialized
INFO - 2017-03-14 19:47:17 --> URI Class Initialized
INFO - 2017-03-14 19:47:17 --> Router Class Initialized
INFO - 2017-03-14 19:47:17 --> Output Class Initialized
INFO - 2017-03-14 19:47:17 --> Security Class Initialized
DEBUG - 2017-03-14 19:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:47:17 --> Input Class Initialized
INFO - 2017-03-14 19:47:17 --> Language Class Initialized
INFO - 2017-03-14 19:47:17 --> Loader Class Initialized
INFO - 2017-03-14 19:47:17 --> Database Driver Class Initialized
INFO - 2017-03-14 19:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:47:17 --> Controller Class Initialized
INFO - 2017-03-14 19:47:17 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:47:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:47:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:47:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:47:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:47:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:47:17 --> Final output sent to browser
DEBUG - 2017-03-14 19:47:17 --> Total execution time: 0.0157
INFO - 2017-03-14 19:47:18 --> Config Class Initialized
INFO - 2017-03-14 19:47:18 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:47:18 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:47:18 --> Utf8 Class Initialized
INFO - 2017-03-14 19:47:18 --> URI Class Initialized
INFO - 2017-03-14 19:47:18 --> Router Class Initialized
INFO - 2017-03-14 19:47:18 --> Output Class Initialized
INFO - 2017-03-14 19:47:18 --> Security Class Initialized
DEBUG - 2017-03-14 19:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:47:18 --> Input Class Initialized
INFO - 2017-03-14 19:47:18 --> Language Class Initialized
INFO - 2017-03-14 19:47:18 --> Loader Class Initialized
INFO - 2017-03-14 19:47:18 --> Database Driver Class Initialized
INFO - 2017-03-14 19:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:47:18 --> Controller Class Initialized
INFO - 2017-03-14 19:47:18 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:47:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:47:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:47:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:47:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:47:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:47:18 --> Final output sent to browser
DEBUG - 2017-03-14 19:47:18 --> Total execution time: 0.0144
INFO - 2017-03-14 19:47:28 --> Config Class Initialized
INFO - 2017-03-14 19:47:28 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:47:28 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:47:28 --> Utf8 Class Initialized
INFO - 2017-03-14 19:47:28 --> URI Class Initialized
INFO - 2017-03-14 19:47:28 --> Router Class Initialized
INFO - 2017-03-14 19:47:28 --> Output Class Initialized
INFO - 2017-03-14 19:47:28 --> Security Class Initialized
DEBUG - 2017-03-14 19:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:47:28 --> Input Class Initialized
INFO - 2017-03-14 19:47:28 --> Language Class Initialized
INFO - 2017-03-14 19:47:28 --> Loader Class Initialized
INFO - 2017-03-14 19:47:28 --> Database Driver Class Initialized
INFO - 2017-03-14 19:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:47:28 --> Controller Class Initialized
INFO - 2017-03-14 19:47:28 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:47:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:47:30 --> Config Class Initialized
INFO - 2017-03-14 19:47:30 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:47:30 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:47:30 --> Utf8 Class Initialized
INFO - 2017-03-14 19:47:30 --> URI Class Initialized
INFO - 2017-03-14 19:47:30 --> Router Class Initialized
INFO - 2017-03-14 19:47:30 --> Output Class Initialized
INFO - 2017-03-14 19:47:30 --> Security Class Initialized
DEBUG - 2017-03-14 19:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:47:30 --> Input Class Initialized
INFO - 2017-03-14 19:47:30 --> Language Class Initialized
INFO - 2017-03-14 19:47:30 --> Loader Class Initialized
INFO - 2017-03-14 19:47:30 --> Database Driver Class Initialized
INFO - 2017-03-14 19:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:47:30 --> Controller Class Initialized
INFO - 2017-03-14 19:47:30 --> Helper loaded: date_helper
DEBUG - 2017-03-14 19:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:47:30 --> Helper loaded: url_helper
INFO - 2017-03-14 19:47:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:47:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 19:47:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 19:47:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 19:47:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:47:30 --> Final output sent to browser
DEBUG - 2017-03-14 19:47:30 --> Total execution time: 0.0931
INFO - 2017-03-14 19:47:30 --> Config Class Initialized
INFO - 2017-03-14 19:47:30 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:47:30 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:47:30 --> Utf8 Class Initialized
INFO - 2017-03-14 19:47:30 --> URI Class Initialized
INFO - 2017-03-14 19:47:30 --> Router Class Initialized
INFO - 2017-03-14 19:47:30 --> Output Class Initialized
INFO - 2017-03-14 19:47:30 --> Security Class Initialized
DEBUG - 2017-03-14 19:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:47:30 --> Input Class Initialized
INFO - 2017-03-14 19:47:30 --> Language Class Initialized
INFO - 2017-03-14 19:47:30 --> Loader Class Initialized
INFO - 2017-03-14 19:47:30 --> Database Driver Class Initialized
INFO - 2017-03-14 19:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:47:30 --> Controller Class Initialized
INFO - 2017-03-14 19:47:30 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:47:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:47:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:47:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:47:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:47:30 --> Final output sent to browser
DEBUG - 2017-03-14 19:47:30 --> Total execution time: 0.0145
INFO - 2017-03-14 19:47:41 --> Config Class Initialized
INFO - 2017-03-14 19:47:41 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:47:41 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:47:41 --> Utf8 Class Initialized
INFO - 2017-03-14 19:47:41 --> URI Class Initialized
DEBUG - 2017-03-14 19:47:41 --> No URI present. Default controller set.
INFO - 2017-03-14 19:47:41 --> Router Class Initialized
INFO - 2017-03-14 19:47:41 --> Output Class Initialized
INFO - 2017-03-14 19:47:41 --> Security Class Initialized
DEBUG - 2017-03-14 19:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:47:41 --> Input Class Initialized
INFO - 2017-03-14 19:47:41 --> Language Class Initialized
INFO - 2017-03-14 19:47:41 --> Loader Class Initialized
INFO - 2017-03-14 19:47:41 --> Database Driver Class Initialized
INFO - 2017-03-14 19:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:47:41 --> Controller Class Initialized
INFO - 2017-03-14 19:47:41 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:47:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:47:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:47:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:47:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:47:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:47:42 --> Final output sent to browser
DEBUG - 2017-03-14 19:47:42 --> Total execution time: 1.2555
INFO - 2017-03-14 19:47:43 --> Config Class Initialized
INFO - 2017-03-14 19:47:43 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:47:43 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:47:43 --> Utf8 Class Initialized
INFO - 2017-03-14 19:47:43 --> URI Class Initialized
DEBUG - 2017-03-14 19:47:43 --> No URI present. Default controller set.
INFO - 2017-03-14 19:47:43 --> Router Class Initialized
INFO - 2017-03-14 19:47:43 --> Output Class Initialized
INFO - 2017-03-14 19:47:43 --> Security Class Initialized
DEBUG - 2017-03-14 19:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:47:43 --> Input Class Initialized
INFO - 2017-03-14 19:47:43 --> Language Class Initialized
INFO - 2017-03-14 19:47:43 --> Loader Class Initialized
INFO - 2017-03-14 19:47:43 --> Database Driver Class Initialized
INFO - 2017-03-14 19:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:47:43 --> Controller Class Initialized
INFO - 2017-03-14 19:47:43 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:47:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:47:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:47:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:47:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:47:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:47:43 --> Final output sent to browser
DEBUG - 2017-03-14 19:47:43 --> Total execution time: 0.0227
INFO - 2017-03-14 19:47:43 --> Config Class Initialized
INFO - 2017-03-14 19:47:43 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:47:43 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:47:43 --> Utf8 Class Initialized
INFO - 2017-03-14 19:47:43 --> URI Class Initialized
INFO - 2017-03-14 19:47:43 --> Router Class Initialized
INFO - 2017-03-14 19:47:43 --> Output Class Initialized
INFO - 2017-03-14 19:47:43 --> Security Class Initialized
DEBUG - 2017-03-14 19:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:47:43 --> Input Class Initialized
INFO - 2017-03-14 19:47:43 --> Language Class Initialized
INFO - 2017-03-14 19:47:43 --> Loader Class Initialized
INFO - 2017-03-14 19:47:43 --> Database Driver Class Initialized
INFO - 2017-03-14 19:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:47:43 --> Controller Class Initialized
INFO - 2017-03-14 19:47:43 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:47:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:47:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:47:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:47:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:47:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:47:43 --> Final output sent to browser
DEBUG - 2017-03-14 19:47:43 --> Total execution time: 0.0140
INFO - 2017-03-14 19:49:21 --> Config Class Initialized
INFO - 2017-03-14 19:49:21 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:49:21 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:49:21 --> Utf8 Class Initialized
INFO - 2017-03-14 19:49:21 --> URI Class Initialized
DEBUG - 2017-03-14 19:49:21 --> No URI present. Default controller set.
INFO - 2017-03-14 19:49:21 --> Router Class Initialized
INFO - 2017-03-14 19:49:21 --> Output Class Initialized
INFO - 2017-03-14 19:49:21 --> Security Class Initialized
DEBUG - 2017-03-14 19:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:49:21 --> Input Class Initialized
INFO - 2017-03-14 19:49:21 --> Language Class Initialized
INFO - 2017-03-14 19:49:21 --> Loader Class Initialized
INFO - 2017-03-14 19:49:22 --> Database Driver Class Initialized
INFO - 2017-03-14 19:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:49:22 --> Controller Class Initialized
INFO - 2017-03-14 19:49:22 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:49:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:49:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:49:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:49:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:49:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:49:22 --> Final output sent to browser
DEBUG - 2017-03-14 19:49:22 --> Total execution time: 1.6891
INFO - 2017-03-14 19:49:27 --> Config Class Initialized
INFO - 2017-03-14 19:49:27 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:49:27 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:49:27 --> Utf8 Class Initialized
INFO - 2017-03-14 19:49:27 --> URI Class Initialized
INFO - 2017-03-14 19:49:27 --> Router Class Initialized
INFO - 2017-03-14 19:49:27 --> Output Class Initialized
INFO - 2017-03-14 19:49:27 --> Security Class Initialized
DEBUG - 2017-03-14 19:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:49:27 --> Input Class Initialized
INFO - 2017-03-14 19:49:27 --> Language Class Initialized
INFO - 2017-03-14 19:49:27 --> Loader Class Initialized
INFO - 2017-03-14 19:49:27 --> Database Driver Class Initialized
INFO - 2017-03-14 19:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:49:28 --> Controller Class Initialized
INFO - 2017-03-14 19:49:28 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:49:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:49:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:49:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:49:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:49:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:49:28 --> Final output sent to browser
DEBUG - 2017-03-14 19:49:28 --> Total execution time: 2.3492
INFO - 2017-03-14 19:49:33 --> Config Class Initialized
INFO - 2017-03-14 19:49:33 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:49:33 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:49:33 --> Utf8 Class Initialized
INFO - 2017-03-14 19:49:33 --> URI Class Initialized
INFO - 2017-03-14 19:49:33 --> Router Class Initialized
INFO - 2017-03-14 19:49:33 --> Output Class Initialized
INFO - 2017-03-14 19:49:33 --> Security Class Initialized
DEBUG - 2017-03-14 19:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:49:33 --> Input Class Initialized
INFO - 2017-03-14 19:49:33 --> Language Class Initialized
INFO - 2017-03-14 19:49:33 --> Loader Class Initialized
INFO - 2017-03-14 19:49:34 --> Database Driver Class Initialized
INFO - 2017-03-14 19:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:49:34 --> Controller Class Initialized
INFO - 2017-03-14 19:49:34 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:49:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:49:36 --> Config Class Initialized
INFO - 2017-03-14 19:49:36 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:49:36 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:49:36 --> Utf8 Class Initialized
INFO - 2017-03-14 19:49:36 --> URI Class Initialized
INFO - 2017-03-14 19:49:36 --> Router Class Initialized
INFO - 2017-03-14 19:49:37 --> Output Class Initialized
INFO - 2017-03-14 19:49:37 --> Security Class Initialized
DEBUG - 2017-03-14 19:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:49:37 --> Input Class Initialized
INFO - 2017-03-14 19:49:37 --> Language Class Initialized
INFO - 2017-03-14 19:49:37 --> Loader Class Initialized
INFO - 2017-03-14 19:49:37 --> Database Driver Class Initialized
INFO - 2017-03-14 19:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:49:37 --> Controller Class Initialized
INFO - 2017-03-14 19:49:37 --> Helper loaded: date_helper
DEBUG - 2017-03-14 19:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:49:37 --> Helper loaded: url_helper
INFO - 2017-03-14 19:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 19:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 19:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 19:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:49:37 --> Final output sent to browser
DEBUG - 2017-03-14 19:49:37 --> Total execution time: 1.0843
INFO - 2017-03-14 19:49:38 --> Config Class Initialized
INFO - 2017-03-14 19:49:38 --> Hooks Class Initialized
DEBUG - 2017-03-14 19:49:38 --> UTF-8 Support Enabled
INFO - 2017-03-14 19:49:38 --> Utf8 Class Initialized
INFO - 2017-03-14 19:49:38 --> URI Class Initialized
INFO - 2017-03-14 19:49:38 --> Router Class Initialized
INFO - 2017-03-14 19:49:38 --> Output Class Initialized
INFO - 2017-03-14 19:49:38 --> Security Class Initialized
DEBUG - 2017-03-14 19:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 19:49:38 --> Input Class Initialized
INFO - 2017-03-14 19:49:38 --> Language Class Initialized
INFO - 2017-03-14 19:49:38 --> Loader Class Initialized
INFO - 2017-03-14 19:49:38 --> Database Driver Class Initialized
INFO - 2017-03-14 19:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 19:49:38 --> Controller Class Initialized
INFO - 2017-03-14 19:49:38 --> Helper loaded: url_helper
DEBUG - 2017-03-14 19:49:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 19:49:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 19:49:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 19:49:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 19:49:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 19:49:39 --> Final output sent to browser
DEBUG - 2017-03-14 19:49:39 --> Total execution time: 0.3191
INFO - 2017-03-14 20:18:47 --> Config Class Initialized
INFO - 2017-03-14 20:18:47 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:18:47 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:18:47 --> Utf8 Class Initialized
INFO - 2017-03-14 20:18:47 --> URI Class Initialized
DEBUG - 2017-03-14 20:18:47 --> No URI present. Default controller set.
INFO - 2017-03-14 20:18:47 --> Router Class Initialized
INFO - 2017-03-14 20:18:47 --> Output Class Initialized
INFO - 2017-03-14 20:18:47 --> Security Class Initialized
DEBUG - 2017-03-14 20:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:18:47 --> Input Class Initialized
INFO - 2017-03-14 20:18:47 --> Language Class Initialized
INFO - 2017-03-14 20:18:47 --> Loader Class Initialized
INFO - 2017-03-14 20:18:48 --> Database Driver Class Initialized
INFO - 2017-03-14 20:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:18:48 --> Controller Class Initialized
INFO - 2017-03-14 20:18:48 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:18:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:18:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:18:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:18:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:18:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:18:48 --> Final output sent to browser
DEBUG - 2017-03-14 20:18:48 --> Total execution time: 1.2460
INFO - 2017-03-14 20:18:56 --> Config Class Initialized
INFO - 2017-03-14 20:18:56 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:18:56 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:18:56 --> Utf8 Class Initialized
INFO - 2017-03-14 20:18:56 --> URI Class Initialized
INFO - 2017-03-14 20:18:56 --> Router Class Initialized
INFO - 2017-03-14 20:18:56 --> Output Class Initialized
INFO - 2017-03-14 20:18:56 --> Security Class Initialized
DEBUG - 2017-03-14 20:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:18:56 --> Input Class Initialized
INFO - 2017-03-14 20:18:56 --> Language Class Initialized
INFO - 2017-03-14 20:18:56 --> Loader Class Initialized
INFO - 2017-03-14 20:18:56 --> Database Driver Class Initialized
INFO - 2017-03-14 20:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:18:56 --> Controller Class Initialized
INFO - 2017-03-14 20:18:56 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:18:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:18:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:18:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:18:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:18:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:18:56 --> Final output sent to browser
DEBUG - 2017-03-14 20:18:56 --> Total execution time: 0.0137
INFO - 2017-03-14 20:19:03 --> Config Class Initialized
INFO - 2017-03-14 20:19:03 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:19:03 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:19:03 --> Utf8 Class Initialized
INFO - 2017-03-14 20:19:03 --> URI Class Initialized
INFO - 2017-03-14 20:19:03 --> Router Class Initialized
INFO - 2017-03-14 20:19:03 --> Output Class Initialized
INFO - 2017-03-14 20:19:03 --> Security Class Initialized
DEBUG - 2017-03-14 20:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:19:03 --> Input Class Initialized
INFO - 2017-03-14 20:19:03 --> Language Class Initialized
INFO - 2017-03-14 20:19:03 --> Loader Class Initialized
INFO - 2017-03-14 20:19:03 --> Database Driver Class Initialized
INFO - 2017-03-14 20:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:19:03 --> Controller Class Initialized
INFO - 2017-03-14 20:19:03 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:19:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-14 20:19:05 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-14 20:19:05 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Evelin Rodriguez')
INFO - 2017-03-14 20:19:05 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-14 20:19:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-14 20:19:05 --> Config Class Initialized
INFO - 2017-03-14 20:19:05 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:19:05 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:19:05 --> Utf8 Class Initialized
INFO - 2017-03-14 20:19:05 --> URI Class Initialized
INFO - 2017-03-14 20:19:05 --> Router Class Initialized
INFO - 2017-03-14 20:19:05 --> Output Class Initialized
INFO - 2017-03-14 20:19:05 --> Security Class Initialized
DEBUG - 2017-03-14 20:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:19:05 --> Input Class Initialized
INFO - 2017-03-14 20:19:05 --> Language Class Initialized
INFO - 2017-03-14 20:19:05 --> Loader Class Initialized
INFO - 2017-03-14 20:19:05 --> Database Driver Class Initialized
INFO - 2017-03-14 20:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:19:05 --> Controller Class Initialized
INFO - 2017-03-14 20:19:05 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:19:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:19:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:19:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:19:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:19:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:19:05 --> Final output sent to browser
DEBUG - 2017-03-14 20:19:05 --> Total execution time: 0.0140
INFO - 2017-03-14 20:19:06 --> Config Class Initialized
INFO - 2017-03-14 20:19:06 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:19:06 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:19:06 --> Utf8 Class Initialized
INFO - 2017-03-14 20:19:06 --> URI Class Initialized
DEBUG - 2017-03-14 20:19:06 --> No URI present. Default controller set.
INFO - 2017-03-14 20:19:06 --> Router Class Initialized
INFO - 2017-03-14 20:19:06 --> Output Class Initialized
INFO - 2017-03-14 20:19:06 --> Security Class Initialized
DEBUG - 2017-03-14 20:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:19:06 --> Input Class Initialized
INFO - 2017-03-14 20:19:06 --> Language Class Initialized
INFO - 2017-03-14 20:19:06 --> Loader Class Initialized
INFO - 2017-03-14 20:19:06 --> Database Driver Class Initialized
INFO - 2017-03-14 20:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:19:06 --> Controller Class Initialized
INFO - 2017-03-14 20:19:06 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:19:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:19:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:19:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:19:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:19:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:19:06 --> Final output sent to browser
DEBUG - 2017-03-14 20:19:06 --> Total execution time: 0.0138
INFO - 2017-03-14 20:19:09 --> Config Class Initialized
INFO - 2017-03-14 20:19:09 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:19:09 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:19:09 --> Utf8 Class Initialized
INFO - 2017-03-14 20:19:09 --> URI Class Initialized
INFO - 2017-03-14 20:19:09 --> Router Class Initialized
INFO - 2017-03-14 20:19:09 --> Output Class Initialized
INFO - 2017-03-14 20:19:09 --> Security Class Initialized
DEBUG - 2017-03-14 20:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:19:09 --> Input Class Initialized
INFO - 2017-03-14 20:19:09 --> Language Class Initialized
INFO - 2017-03-14 20:19:09 --> Loader Class Initialized
INFO - 2017-03-14 20:19:09 --> Database Driver Class Initialized
INFO - 2017-03-14 20:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:19:09 --> Controller Class Initialized
INFO - 2017-03-14 20:19:09 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:19:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:19:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:19:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:19:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:19:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:19:09 --> Final output sent to browser
DEBUG - 2017-03-14 20:19:09 --> Total execution time: 0.0139
INFO - 2017-03-14 20:19:36 --> Config Class Initialized
INFO - 2017-03-14 20:19:36 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:19:36 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:19:36 --> Utf8 Class Initialized
INFO - 2017-03-14 20:19:36 --> URI Class Initialized
INFO - 2017-03-14 20:19:36 --> Router Class Initialized
INFO - 2017-03-14 20:19:36 --> Output Class Initialized
INFO - 2017-03-14 20:19:36 --> Security Class Initialized
DEBUG - 2017-03-14 20:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:19:36 --> Input Class Initialized
INFO - 2017-03-14 20:19:36 --> Language Class Initialized
INFO - 2017-03-14 20:19:36 --> Loader Class Initialized
INFO - 2017-03-14 20:19:36 --> Database Driver Class Initialized
INFO - 2017-03-14 20:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:19:36 --> Controller Class Initialized
INFO - 2017-03-14 20:19:36 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:19:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:19:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:19:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:19:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:19:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:19:36 --> Final output sent to browser
DEBUG - 2017-03-14 20:19:36 --> Total execution time: 0.0146
INFO - 2017-03-14 20:19:37 --> Config Class Initialized
INFO - 2017-03-14 20:19:37 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:19:37 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:19:37 --> Utf8 Class Initialized
INFO - 2017-03-14 20:19:37 --> URI Class Initialized
INFO - 2017-03-14 20:19:37 --> Router Class Initialized
INFO - 2017-03-14 20:19:37 --> Output Class Initialized
INFO - 2017-03-14 20:19:37 --> Security Class Initialized
DEBUG - 2017-03-14 20:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:19:37 --> Input Class Initialized
INFO - 2017-03-14 20:19:37 --> Language Class Initialized
INFO - 2017-03-14 20:19:37 --> Loader Class Initialized
INFO - 2017-03-14 20:19:37 --> Database Driver Class Initialized
INFO - 2017-03-14 20:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:19:37 --> Controller Class Initialized
INFO - 2017-03-14 20:19:37 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:19:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:19:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:19:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:19:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:19:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:19:37 --> Final output sent to browser
DEBUG - 2017-03-14 20:19:37 --> Total execution time: 0.0138
INFO - 2017-03-14 20:19:59 --> Config Class Initialized
INFO - 2017-03-14 20:19:59 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:19:59 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:19:59 --> Utf8 Class Initialized
INFO - 2017-03-14 20:19:59 --> URI Class Initialized
INFO - 2017-03-14 20:19:59 --> Router Class Initialized
INFO - 2017-03-14 20:19:59 --> Output Class Initialized
INFO - 2017-03-14 20:19:59 --> Security Class Initialized
DEBUG - 2017-03-14 20:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:19:59 --> Input Class Initialized
INFO - 2017-03-14 20:19:59 --> Language Class Initialized
INFO - 2017-03-14 20:19:59 --> Loader Class Initialized
INFO - 2017-03-14 20:19:59 --> Database Driver Class Initialized
INFO - 2017-03-14 20:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:19:59 --> Controller Class Initialized
INFO - 2017-03-14 20:19:59 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:19:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:19:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:19:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:19:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:19:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:19:59 --> Final output sent to browser
DEBUG - 2017-03-14 20:19:59 --> Total execution time: 0.0152
INFO - 2017-03-14 20:20:02 --> Config Class Initialized
INFO - 2017-03-14 20:20:02 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:20:02 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:20:02 --> Utf8 Class Initialized
INFO - 2017-03-14 20:20:02 --> URI Class Initialized
INFO - 2017-03-14 20:20:02 --> Router Class Initialized
INFO - 2017-03-14 20:20:02 --> Output Class Initialized
INFO - 2017-03-14 20:20:02 --> Security Class Initialized
DEBUG - 2017-03-14 20:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:20:02 --> Input Class Initialized
INFO - 2017-03-14 20:20:02 --> Language Class Initialized
INFO - 2017-03-14 20:20:02 --> Loader Class Initialized
INFO - 2017-03-14 20:20:02 --> Database Driver Class Initialized
INFO - 2017-03-14 20:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:20:02 --> Controller Class Initialized
INFO - 2017-03-14 20:20:02 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:20:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:20:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:20:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:20:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:20:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:20:02 --> Final output sent to browser
DEBUG - 2017-03-14 20:20:02 --> Total execution time: 0.0141
INFO - 2017-03-14 20:20:23 --> Config Class Initialized
INFO - 2017-03-14 20:20:23 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:20:23 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:20:23 --> Utf8 Class Initialized
INFO - 2017-03-14 20:20:23 --> URI Class Initialized
INFO - 2017-03-14 20:20:23 --> Router Class Initialized
INFO - 2017-03-14 20:20:23 --> Output Class Initialized
INFO - 2017-03-14 20:20:23 --> Security Class Initialized
DEBUG - 2017-03-14 20:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:20:23 --> Input Class Initialized
INFO - 2017-03-14 20:20:23 --> Language Class Initialized
INFO - 2017-03-14 20:20:23 --> Loader Class Initialized
INFO - 2017-03-14 20:20:23 --> Database Driver Class Initialized
INFO - 2017-03-14 20:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:20:23 --> Controller Class Initialized
INFO - 2017-03-14 20:20:23 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:20:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:20:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:20:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:20:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:20:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:20:23 --> Final output sent to browser
DEBUG - 2017-03-14 20:20:23 --> Total execution time: 0.0549
INFO - 2017-03-14 20:20:26 --> Config Class Initialized
INFO - 2017-03-14 20:20:26 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:20:26 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:20:26 --> Utf8 Class Initialized
INFO - 2017-03-14 20:20:26 --> URI Class Initialized
INFO - 2017-03-14 20:20:27 --> Router Class Initialized
INFO - 2017-03-14 20:20:27 --> Output Class Initialized
INFO - 2017-03-14 20:20:27 --> Security Class Initialized
DEBUG - 2017-03-14 20:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:20:27 --> Input Class Initialized
INFO - 2017-03-14 20:20:27 --> Language Class Initialized
INFO - 2017-03-14 20:20:27 --> Loader Class Initialized
INFO - 2017-03-14 20:20:27 --> Database Driver Class Initialized
INFO - 2017-03-14 20:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:20:27 --> Controller Class Initialized
INFO - 2017-03-14 20:20:27 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:20:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:20:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:20:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:20:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:20:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:20:27 --> Final output sent to browser
DEBUG - 2017-03-14 20:20:27 --> Total execution time: 0.9819
INFO - 2017-03-14 20:20:30 --> Config Class Initialized
INFO - 2017-03-14 20:20:30 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:20:30 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:20:30 --> Utf8 Class Initialized
INFO - 2017-03-14 20:20:30 --> URI Class Initialized
INFO - 2017-03-14 20:20:30 --> Router Class Initialized
INFO - 2017-03-14 20:20:30 --> Output Class Initialized
INFO - 2017-03-14 20:20:30 --> Security Class Initialized
DEBUG - 2017-03-14 20:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:20:30 --> Input Class Initialized
INFO - 2017-03-14 20:20:30 --> Language Class Initialized
INFO - 2017-03-14 20:20:30 --> Loader Class Initialized
INFO - 2017-03-14 20:20:30 --> Database Driver Class Initialized
INFO - 2017-03-14 20:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:20:30 --> Controller Class Initialized
INFO - 2017-03-14 20:20:30 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:20:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-14 20:20:31 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-14 20:20:31 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Evelin Rodriguez')
INFO - 2017-03-14 20:20:31 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-14 20:20:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-14 20:20:32 --> Config Class Initialized
INFO - 2017-03-14 20:20:32 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:20:32 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:20:32 --> Utf8 Class Initialized
INFO - 2017-03-14 20:20:32 --> URI Class Initialized
INFO - 2017-03-14 20:20:32 --> Router Class Initialized
INFO - 2017-03-14 20:20:32 --> Output Class Initialized
INFO - 2017-03-14 20:20:32 --> Security Class Initialized
DEBUG - 2017-03-14 20:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:20:32 --> Input Class Initialized
INFO - 2017-03-14 20:20:32 --> Language Class Initialized
INFO - 2017-03-14 20:20:32 --> Loader Class Initialized
INFO - 2017-03-14 20:20:32 --> Database Driver Class Initialized
INFO - 2017-03-14 20:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:20:32 --> Controller Class Initialized
INFO - 2017-03-14 20:20:32 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:20:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:20:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:20:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:20:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:20:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:20:32 --> Final output sent to browser
DEBUG - 2017-03-14 20:20:32 --> Total execution time: 0.0146
INFO - 2017-03-14 20:20:53 --> Config Class Initialized
INFO - 2017-03-14 20:20:53 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:20:53 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:20:53 --> Utf8 Class Initialized
INFO - 2017-03-14 20:20:53 --> URI Class Initialized
DEBUG - 2017-03-14 20:20:53 --> No URI present. Default controller set.
INFO - 2017-03-14 20:20:53 --> Router Class Initialized
INFO - 2017-03-14 20:20:53 --> Output Class Initialized
INFO - 2017-03-14 20:20:53 --> Security Class Initialized
DEBUG - 2017-03-14 20:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:20:53 --> Input Class Initialized
INFO - 2017-03-14 20:20:53 --> Language Class Initialized
INFO - 2017-03-14 20:20:53 --> Loader Class Initialized
INFO - 2017-03-14 20:20:57 --> Database Driver Class Initialized
INFO - 2017-03-14 20:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:20:57 --> Controller Class Initialized
INFO - 2017-03-14 20:20:57 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:20:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:20:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:20:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:20:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:20:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:20:57 --> Final output sent to browser
DEBUG - 2017-03-14 20:20:57 --> Total execution time: 4.7373
INFO - 2017-03-14 20:21:01 --> Config Class Initialized
INFO - 2017-03-14 20:21:01 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:21:01 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:21:01 --> Utf8 Class Initialized
INFO - 2017-03-14 20:21:01 --> URI Class Initialized
INFO - 2017-03-14 20:21:01 --> Router Class Initialized
INFO - 2017-03-14 20:21:01 --> Output Class Initialized
INFO - 2017-03-14 20:21:01 --> Security Class Initialized
DEBUG - 2017-03-14 20:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:21:01 --> Input Class Initialized
INFO - 2017-03-14 20:21:01 --> Language Class Initialized
INFO - 2017-03-14 20:21:01 --> Loader Class Initialized
INFO - 2017-03-14 20:21:01 --> Database Driver Class Initialized
INFO - 2017-03-14 20:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:21:01 --> Controller Class Initialized
INFO - 2017-03-14 20:21:01 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:21:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:21:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:21:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:21:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:21:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:21:01 --> Final output sent to browser
DEBUG - 2017-03-14 20:21:01 --> Total execution time: 0.0138
INFO - 2017-03-14 20:21:13 --> Config Class Initialized
INFO - 2017-03-14 20:21:13 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:21:13 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:21:13 --> Utf8 Class Initialized
INFO - 2017-03-14 20:21:13 --> URI Class Initialized
INFO - 2017-03-14 20:21:13 --> Router Class Initialized
INFO - 2017-03-14 20:21:13 --> Output Class Initialized
INFO - 2017-03-14 20:21:13 --> Security Class Initialized
DEBUG - 2017-03-14 20:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:21:13 --> Input Class Initialized
INFO - 2017-03-14 20:21:13 --> Language Class Initialized
INFO - 2017-03-14 20:21:13 --> Loader Class Initialized
INFO - 2017-03-14 20:21:13 --> Database Driver Class Initialized
INFO - 2017-03-14 20:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:21:13 --> Controller Class Initialized
INFO - 2017-03-14 20:21:13 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:21:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:21:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:21:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:21:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:21:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:21:13 --> Final output sent to browser
DEBUG - 2017-03-14 20:21:13 --> Total execution time: 0.0141
INFO - 2017-03-14 20:21:13 --> Config Class Initialized
INFO - 2017-03-14 20:21:13 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:21:13 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:21:13 --> Utf8 Class Initialized
INFO - 2017-03-14 20:21:13 --> URI Class Initialized
INFO - 2017-03-14 20:21:13 --> Router Class Initialized
INFO - 2017-03-14 20:21:13 --> Output Class Initialized
INFO - 2017-03-14 20:21:13 --> Security Class Initialized
DEBUG - 2017-03-14 20:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:21:13 --> Input Class Initialized
INFO - 2017-03-14 20:21:13 --> Language Class Initialized
INFO - 2017-03-14 20:21:13 --> Loader Class Initialized
INFO - 2017-03-14 20:21:13 --> Database Driver Class Initialized
INFO - 2017-03-14 20:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:21:13 --> Controller Class Initialized
INFO - 2017-03-14 20:21:13 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:21:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-14 20:21:14 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-14 20:21:14 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Evelin Rodriguez')
INFO - 2017-03-14 20:21:14 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-14 20:21:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-14 20:21:14 --> Config Class Initialized
INFO - 2017-03-14 20:21:14 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:21:14 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:21:14 --> Utf8 Class Initialized
INFO - 2017-03-14 20:21:14 --> URI Class Initialized
INFO - 2017-03-14 20:21:14 --> Router Class Initialized
INFO - 2017-03-14 20:21:14 --> Output Class Initialized
INFO - 2017-03-14 20:21:14 --> Security Class Initialized
DEBUG - 2017-03-14 20:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:21:14 --> Input Class Initialized
INFO - 2017-03-14 20:21:14 --> Language Class Initialized
INFO - 2017-03-14 20:21:14 --> Loader Class Initialized
INFO - 2017-03-14 20:21:14 --> Database Driver Class Initialized
INFO - 2017-03-14 20:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:21:14 --> Controller Class Initialized
INFO - 2017-03-14 20:21:14 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:21:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:21:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:21:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:21:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:21:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:21:14 --> Final output sent to browser
DEBUG - 2017-03-14 20:21:14 --> Total execution time: 0.0397
INFO - 2017-03-14 20:21:16 --> Config Class Initialized
INFO - 2017-03-14 20:21:16 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:21:16 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:21:16 --> Utf8 Class Initialized
INFO - 2017-03-14 20:21:16 --> URI Class Initialized
DEBUG - 2017-03-14 20:21:16 --> No URI present. Default controller set.
INFO - 2017-03-14 20:21:16 --> Router Class Initialized
INFO - 2017-03-14 20:21:16 --> Output Class Initialized
INFO - 2017-03-14 20:21:16 --> Security Class Initialized
DEBUG - 2017-03-14 20:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:21:16 --> Input Class Initialized
INFO - 2017-03-14 20:21:16 --> Language Class Initialized
INFO - 2017-03-14 20:21:16 --> Loader Class Initialized
INFO - 2017-03-14 20:21:16 --> Database Driver Class Initialized
INFO - 2017-03-14 20:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:21:16 --> Controller Class Initialized
INFO - 2017-03-14 20:21:16 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:21:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:21:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:21:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:21:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:21:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:21:16 --> Final output sent to browser
DEBUG - 2017-03-14 20:21:16 --> Total execution time: 0.0136
INFO - 2017-03-14 20:23:21 --> Config Class Initialized
INFO - 2017-03-14 20:23:21 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:23:21 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:23:21 --> Utf8 Class Initialized
INFO - 2017-03-14 20:23:21 --> URI Class Initialized
DEBUG - 2017-03-14 20:23:21 --> No URI present. Default controller set.
INFO - 2017-03-14 20:23:21 --> Router Class Initialized
INFO - 2017-03-14 20:23:21 --> Output Class Initialized
INFO - 2017-03-14 20:23:21 --> Security Class Initialized
DEBUG - 2017-03-14 20:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:23:21 --> Input Class Initialized
INFO - 2017-03-14 20:23:21 --> Language Class Initialized
INFO - 2017-03-14 20:23:21 --> Loader Class Initialized
INFO - 2017-03-14 20:23:21 --> Database Driver Class Initialized
INFO - 2017-03-14 20:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:23:21 --> Controller Class Initialized
INFO - 2017-03-14 20:23:21 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:23:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:23:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:23:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:23:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:23:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:23:21 --> Final output sent to browser
DEBUG - 2017-03-14 20:23:21 --> Total execution time: 0.2050
INFO - 2017-03-14 20:23:24 --> Config Class Initialized
INFO - 2017-03-14 20:23:24 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:23:24 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:23:24 --> Utf8 Class Initialized
INFO - 2017-03-14 20:23:24 --> URI Class Initialized
INFO - 2017-03-14 20:23:24 --> Router Class Initialized
INFO - 2017-03-14 20:23:24 --> Output Class Initialized
INFO - 2017-03-14 20:23:24 --> Security Class Initialized
DEBUG - 2017-03-14 20:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:23:24 --> Input Class Initialized
INFO - 2017-03-14 20:23:24 --> Language Class Initialized
INFO - 2017-03-14 20:23:24 --> Loader Class Initialized
INFO - 2017-03-14 20:23:24 --> Database Driver Class Initialized
INFO - 2017-03-14 20:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:23:24 --> Controller Class Initialized
INFO - 2017-03-14 20:23:24 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:23:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:23:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:23:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:23:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:23:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:23:24 --> Final output sent to browser
DEBUG - 2017-03-14 20:23:24 --> Total execution time: 0.0138
INFO - 2017-03-14 20:23:28 --> Config Class Initialized
INFO - 2017-03-14 20:23:28 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:23:28 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:23:28 --> Utf8 Class Initialized
INFO - 2017-03-14 20:23:28 --> URI Class Initialized
INFO - 2017-03-14 20:23:28 --> Router Class Initialized
INFO - 2017-03-14 20:23:28 --> Output Class Initialized
INFO - 2017-03-14 20:23:28 --> Security Class Initialized
DEBUG - 2017-03-14 20:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:23:28 --> Input Class Initialized
INFO - 2017-03-14 20:23:28 --> Language Class Initialized
INFO - 2017-03-14 20:23:28 --> Loader Class Initialized
INFO - 2017-03-14 20:23:28 --> Database Driver Class Initialized
INFO - 2017-03-14 20:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:23:28 --> Controller Class Initialized
INFO - 2017-03-14 20:23:28 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:23:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-14 20:23:28 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-14 20:23:28 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Evelin Rodriguez')
INFO - 2017-03-14 20:23:28 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-14 20:23:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-14 20:23:29 --> Config Class Initialized
INFO - 2017-03-14 20:23:29 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:23:29 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:23:29 --> Utf8 Class Initialized
INFO - 2017-03-14 20:23:29 --> URI Class Initialized
INFO - 2017-03-14 20:23:29 --> Router Class Initialized
INFO - 2017-03-14 20:23:29 --> Output Class Initialized
INFO - 2017-03-14 20:23:29 --> Security Class Initialized
DEBUG - 2017-03-14 20:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:23:29 --> Input Class Initialized
INFO - 2017-03-14 20:23:29 --> Language Class Initialized
INFO - 2017-03-14 20:23:29 --> Loader Class Initialized
INFO - 2017-03-14 20:23:29 --> Database Driver Class Initialized
INFO - 2017-03-14 20:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:23:29 --> Controller Class Initialized
INFO - 2017-03-14 20:23:29 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:23:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:23:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:23:29 --> Final output sent to browser
DEBUG - 2017-03-14 20:23:29 --> Total execution time: 0.0144
INFO - 2017-03-14 20:23:38 --> Config Class Initialized
INFO - 2017-03-14 20:23:38 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:23:38 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:23:38 --> Utf8 Class Initialized
INFO - 2017-03-14 20:23:38 --> URI Class Initialized
DEBUG - 2017-03-14 20:23:38 --> No URI present. Default controller set.
INFO - 2017-03-14 20:23:38 --> Router Class Initialized
INFO - 2017-03-14 20:23:38 --> Output Class Initialized
INFO - 2017-03-14 20:23:38 --> Security Class Initialized
DEBUG - 2017-03-14 20:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:23:38 --> Input Class Initialized
INFO - 2017-03-14 20:23:38 --> Language Class Initialized
INFO - 2017-03-14 20:23:38 --> Loader Class Initialized
INFO - 2017-03-14 20:23:38 --> Database Driver Class Initialized
INFO - 2017-03-14 20:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:23:38 --> Controller Class Initialized
INFO - 2017-03-14 20:23:38 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:23:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:23:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:23:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:23:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:23:38 --> Final output sent to browser
DEBUG - 2017-03-14 20:23:38 --> Total execution time: 0.0141
INFO - 2017-03-14 20:23:41 --> Config Class Initialized
INFO - 2017-03-14 20:23:41 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:23:41 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:23:41 --> Utf8 Class Initialized
INFO - 2017-03-14 20:23:41 --> URI Class Initialized
INFO - 2017-03-14 20:23:41 --> Router Class Initialized
INFO - 2017-03-14 20:23:41 --> Output Class Initialized
INFO - 2017-03-14 20:23:41 --> Security Class Initialized
DEBUG - 2017-03-14 20:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:23:41 --> Input Class Initialized
INFO - 2017-03-14 20:23:41 --> Language Class Initialized
INFO - 2017-03-14 20:23:41 --> Loader Class Initialized
INFO - 2017-03-14 20:23:41 --> Database Driver Class Initialized
INFO - 2017-03-14 20:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:23:41 --> Controller Class Initialized
INFO - 2017-03-14 20:23:41 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:23:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:23:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:23:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:23:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:23:41 --> Final output sent to browser
DEBUG - 2017-03-14 20:23:41 --> Total execution time: 0.0143
INFO - 2017-03-14 20:24:15 --> Config Class Initialized
INFO - 2017-03-14 20:24:15 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:24:15 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:24:15 --> Utf8 Class Initialized
INFO - 2017-03-14 20:24:15 --> URI Class Initialized
INFO - 2017-03-14 20:24:15 --> Router Class Initialized
INFO - 2017-03-14 20:24:15 --> Output Class Initialized
INFO - 2017-03-14 20:24:15 --> Security Class Initialized
DEBUG - 2017-03-14 20:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:24:15 --> Input Class Initialized
INFO - 2017-03-14 20:24:15 --> Language Class Initialized
INFO - 2017-03-14 20:24:15 --> Loader Class Initialized
INFO - 2017-03-14 20:24:16 --> Database Driver Class Initialized
INFO - 2017-03-14 20:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:24:16 --> Controller Class Initialized
INFO - 2017-03-14 20:24:16 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:24:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:24:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:24:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:24:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:24:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:24:16 --> Final output sent to browser
DEBUG - 2017-03-14 20:24:16 --> Total execution time: 1.2626
INFO - 2017-03-14 20:24:17 --> Config Class Initialized
INFO - 2017-03-14 20:24:17 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:24:17 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:24:17 --> Utf8 Class Initialized
INFO - 2017-03-14 20:24:17 --> URI Class Initialized
INFO - 2017-03-14 20:24:17 --> Router Class Initialized
INFO - 2017-03-14 20:24:17 --> Output Class Initialized
INFO - 2017-03-14 20:24:17 --> Security Class Initialized
DEBUG - 2017-03-14 20:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:24:17 --> Input Class Initialized
INFO - 2017-03-14 20:24:17 --> Language Class Initialized
INFO - 2017-03-14 20:24:17 --> Loader Class Initialized
INFO - 2017-03-14 20:24:17 --> Database Driver Class Initialized
INFO - 2017-03-14 20:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:24:17 --> Controller Class Initialized
INFO - 2017-03-14 20:24:17 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:24:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:24:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:24:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:24:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:24:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:24:18 --> Final output sent to browser
DEBUG - 2017-03-14 20:24:18 --> Total execution time: 0.0135
INFO - 2017-03-14 20:24:39 --> Config Class Initialized
INFO - 2017-03-14 20:24:39 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:24:39 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:24:39 --> Utf8 Class Initialized
INFO - 2017-03-14 20:24:39 --> URI Class Initialized
INFO - 2017-03-14 20:24:39 --> Router Class Initialized
INFO - 2017-03-14 20:24:39 --> Output Class Initialized
INFO - 2017-03-14 20:24:39 --> Security Class Initialized
DEBUG - 2017-03-14 20:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:24:39 --> Input Class Initialized
INFO - 2017-03-14 20:24:39 --> Language Class Initialized
INFO - 2017-03-14 20:24:39 --> Loader Class Initialized
INFO - 2017-03-14 20:24:39 --> Database Driver Class Initialized
INFO - 2017-03-14 20:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:24:39 --> Controller Class Initialized
INFO - 2017-03-14 20:24:39 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:24:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:24:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:24:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:24:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:24:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:24:39 --> Final output sent to browser
DEBUG - 2017-03-14 20:24:39 --> Total execution time: 0.0155
INFO - 2017-03-14 20:24:40 --> Config Class Initialized
INFO - 2017-03-14 20:24:40 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:24:40 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:24:40 --> Utf8 Class Initialized
INFO - 2017-03-14 20:24:40 --> URI Class Initialized
INFO - 2017-03-14 20:24:40 --> Router Class Initialized
INFO - 2017-03-14 20:24:40 --> Output Class Initialized
INFO - 2017-03-14 20:24:40 --> Security Class Initialized
DEBUG - 2017-03-14 20:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:24:40 --> Input Class Initialized
INFO - 2017-03-14 20:24:40 --> Language Class Initialized
INFO - 2017-03-14 20:24:40 --> Loader Class Initialized
INFO - 2017-03-14 20:24:40 --> Database Driver Class Initialized
INFO - 2017-03-14 20:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:24:40 --> Controller Class Initialized
INFO - 2017-03-14 20:24:40 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:24:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:24:40 --> Final output sent to browser
DEBUG - 2017-03-14 20:24:40 --> Total execution time: 0.0139
INFO - 2017-03-14 20:24:55 --> Config Class Initialized
INFO - 2017-03-14 20:24:55 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:24:55 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:24:55 --> Utf8 Class Initialized
INFO - 2017-03-14 20:24:55 --> URI Class Initialized
INFO - 2017-03-14 20:24:55 --> Router Class Initialized
INFO - 2017-03-14 20:24:55 --> Output Class Initialized
INFO - 2017-03-14 20:24:55 --> Security Class Initialized
DEBUG - 2017-03-14 20:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:24:55 --> Input Class Initialized
INFO - 2017-03-14 20:24:55 --> Language Class Initialized
INFO - 2017-03-14 20:24:55 --> Loader Class Initialized
INFO - 2017-03-14 20:24:55 --> Database Driver Class Initialized
INFO - 2017-03-14 20:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:24:55 --> Controller Class Initialized
INFO - 2017-03-14 20:24:55 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:24:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:24:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:24:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:24:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:24:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:24:55 --> Final output sent to browser
DEBUG - 2017-03-14 20:24:55 --> Total execution time: 0.0144
INFO - 2017-03-14 20:24:57 --> Config Class Initialized
INFO - 2017-03-14 20:24:57 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:24:57 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:24:57 --> Utf8 Class Initialized
INFO - 2017-03-14 20:24:57 --> URI Class Initialized
INFO - 2017-03-14 20:24:57 --> Router Class Initialized
INFO - 2017-03-14 20:24:57 --> Output Class Initialized
INFO - 2017-03-14 20:24:57 --> Security Class Initialized
DEBUG - 2017-03-14 20:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:24:57 --> Input Class Initialized
INFO - 2017-03-14 20:24:57 --> Language Class Initialized
INFO - 2017-03-14 20:24:57 --> Loader Class Initialized
INFO - 2017-03-14 20:24:57 --> Database Driver Class Initialized
INFO - 2017-03-14 20:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:24:57 --> Controller Class Initialized
INFO - 2017-03-14 20:24:57 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:24:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:24:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:24:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:24:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:24:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:24:57 --> Final output sent to browser
DEBUG - 2017-03-14 20:24:57 --> Total execution time: 0.0145
INFO - 2017-03-14 20:25:00 --> Config Class Initialized
INFO - 2017-03-14 20:25:00 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:25:00 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:25:00 --> Utf8 Class Initialized
INFO - 2017-03-14 20:25:00 --> URI Class Initialized
INFO - 2017-03-14 20:25:00 --> Router Class Initialized
INFO - 2017-03-14 20:25:00 --> Output Class Initialized
INFO - 2017-03-14 20:25:00 --> Security Class Initialized
DEBUG - 2017-03-14 20:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:25:00 --> Input Class Initialized
INFO - 2017-03-14 20:25:00 --> Language Class Initialized
INFO - 2017-03-14 20:25:00 --> Loader Class Initialized
INFO - 2017-03-14 20:25:00 --> Database Driver Class Initialized
INFO - 2017-03-14 20:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:25:00 --> Controller Class Initialized
INFO - 2017-03-14 20:25:00 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:25:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-14 20:25:02 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
INFO - 2017-03-14 20:25:02 --> Config Class Initialized
INFO - 2017-03-14 20:25:02 --> Hooks Class Initialized
ERROR - 2017-03-14 20:25:02 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Evelin Rodriguez')
INFO - 2017-03-14 20:25:02 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-14 20:25:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
DEBUG - 2017-03-14 20:25:02 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:25:02 --> Utf8 Class Initialized
INFO - 2017-03-14 20:25:02 --> URI Class Initialized
INFO - 2017-03-14 20:25:02 --> Router Class Initialized
INFO - 2017-03-14 20:25:02 --> Output Class Initialized
INFO - 2017-03-14 20:25:02 --> Security Class Initialized
DEBUG - 2017-03-14 20:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:25:02 --> Input Class Initialized
INFO - 2017-03-14 20:25:02 --> Language Class Initialized
INFO - 2017-03-14 20:25:02 --> Loader Class Initialized
INFO - 2017-03-14 20:25:02 --> Database Driver Class Initialized
INFO - 2017-03-14 20:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:25:02 --> Controller Class Initialized
INFO - 2017-03-14 20:25:02 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:25:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:25:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:25:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:25:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:25:02 --> Final output sent to browser
DEBUG - 2017-03-14 20:25:02 --> Total execution time: 0.3538
INFO - 2017-03-14 20:25:02 --> Config Class Initialized
INFO - 2017-03-14 20:25:02 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:25:02 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:25:02 --> Utf8 Class Initialized
INFO - 2017-03-14 20:25:02 --> URI Class Initialized
INFO - 2017-03-14 20:25:02 --> Router Class Initialized
INFO - 2017-03-14 20:25:02 --> Output Class Initialized
INFO - 2017-03-14 20:25:02 --> Security Class Initialized
DEBUG - 2017-03-14 20:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:25:02 --> Input Class Initialized
INFO - 2017-03-14 20:25:02 --> Language Class Initialized
INFO - 2017-03-14 20:25:02 --> Loader Class Initialized
INFO - 2017-03-14 20:25:02 --> Database Driver Class Initialized
INFO - 2017-03-14 20:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:25:02 --> Controller Class Initialized
INFO - 2017-03-14 20:25:02 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:25:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-14 20:25:03 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-14 20:25:03 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Evelin Rodriguez')
INFO - 2017-03-14 20:25:03 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-14 20:25:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-14 20:25:03 --> Config Class Initialized
INFO - 2017-03-14 20:25:03 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:25:03 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:25:03 --> Utf8 Class Initialized
INFO - 2017-03-14 20:25:03 --> URI Class Initialized
INFO - 2017-03-14 20:25:03 --> Router Class Initialized
INFO - 2017-03-14 20:25:03 --> Output Class Initialized
INFO - 2017-03-14 20:25:03 --> Security Class Initialized
DEBUG - 2017-03-14 20:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:25:03 --> Input Class Initialized
INFO - 2017-03-14 20:25:03 --> Language Class Initialized
INFO - 2017-03-14 20:25:03 --> Loader Class Initialized
INFO - 2017-03-14 20:25:03 --> Database Driver Class Initialized
INFO - 2017-03-14 20:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:25:03 --> Controller Class Initialized
INFO - 2017-03-14 20:25:03 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:25:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:25:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:25:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:25:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:25:03 --> Final output sent to browser
DEBUG - 2017-03-14 20:25:03 --> Total execution time: 0.0140
INFO - 2017-03-14 20:28:29 --> Config Class Initialized
INFO - 2017-03-14 20:28:29 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:28:29 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:28:29 --> Utf8 Class Initialized
INFO - 2017-03-14 20:28:29 --> URI Class Initialized
DEBUG - 2017-03-14 20:28:29 --> No URI present. Default controller set.
INFO - 2017-03-14 20:28:29 --> Router Class Initialized
INFO - 2017-03-14 20:28:29 --> Output Class Initialized
INFO - 2017-03-14 20:28:29 --> Security Class Initialized
DEBUG - 2017-03-14 20:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:28:29 --> Input Class Initialized
INFO - 2017-03-14 20:28:29 --> Language Class Initialized
INFO - 2017-03-14 20:28:30 --> Loader Class Initialized
INFO - 2017-03-14 20:28:30 --> Database Driver Class Initialized
INFO - 2017-03-14 20:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:28:30 --> Controller Class Initialized
INFO - 2017-03-14 20:28:30 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:28:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:28:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:28:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:28:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:28:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:28:31 --> Final output sent to browser
DEBUG - 2017-03-14 20:28:31 --> Total execution time: 1.5277
INFO - 2017-03-14 20:28:37 --> Config Class Initialized
INFO - 2017-03-14 20:28:37 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:28:37 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:28:37 --> Utf8 Class Initialized
INFO - 2017-03-14 20:28:37 --> URI Class Initialized
INFO - 2017-03-14 20:28:37 --> Router Class Initialized
INFO - 2017-03-14 20:28:37 --> Output Class Initialized
INFO - 2017-03-14 20:28:37 --> Security Class Initialized
DEBUG - 2017-03-14 20:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:28:37 --> Input Class Initialized
INFO - 2017-03-14 20:28:37 --> Language Class Initialized
INFO - 2017-03-14 20:28:37 --> Loader Class Initialized
INFO - 2017-03-14 20:28:37 --> Database Driver Class Initialized
INFO - 2017-03-14 20:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:28:38 --> Controller Class Initialized
INFO - 2017-03-14 20:28:38 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:28:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:28:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:28:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:28:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:28:38 --> Final output sent to browser
DEBUG - 2017-03-14 20:28:38 --> Total execution time: 1.2932
INFO - 2017-03-14 20:31:29 --> Config Class Initialized
INFO - 2017-03-14 20:31:29 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:31:29 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:31:29 --> Utf8 Class Initialized
INFO - 2017-03-14 20:31:29 --> URI Class Initialized
INFO - 2017-03-14 20:31:29 --> Router Class Initialized
INFO - 2017-03-14 20:31:29 --> Output Class Initialized
INFO - 2017-03-14 20:31:29 --> Security Class Initialized
DEBUG - 2017-03-14 20:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:31:29 --> Input Class Initialized
INFO - 2017-03-14 20:31:29 --> Language Class Initialized
INFO - 2017-03-14 20:31:29 --> Loader Class Initialized
INFO - 2017-03-14 20:31:29 --> Database Driver Class Initialized
INFO - 2017-03-14 20:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:31:30 --> Controller Class Initialized
INFO - 2017-03-14 20:31:30 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:31:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:31:34 --> Config Class Initialized
INFO - 2017-03-14 20:31:34 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:31:34 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:31:34 --> Utf8 Class Initialized
INFO - 2017-03-14 20:31:34 --> URI Class Initialized
INFO - 2017-03-14 20:31:34 --> Router Class Initialized
INFO - 2017-03-14 20:31:34 --> Output Class Initialized
INFO - 2017-03-14 20:31:34 --> Security Class Initialized
DEBUG - 2017-03-14 20:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:31:34 --> Input Class Initialized
INFO - 2017-03-14 20:31:34 --> Language Class Initialized
INFO - 2017-03-14 20:31:35 --> Loader Class Initialized
INFO - 2017-03-14 20:31:35 --> Database Driver Class Initialized
INFO - 2017-03-14 20:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:31:35 --> Controller Class Initialized
INFO - 2017-03-14 20:31:35 --> Helper loaded: date_helper
DEBUG - 2017-03-14 20:31:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:31:35 --> Helper loaded: url_helper
INFO - 2017-03-14 20:31:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:31:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 20:31:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 20:31:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 20:31:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:31:35 --> Final output sent to browser
DEBUG - 2017-03-14 20:31:35 --> Total execution time: 1.1628
INFO - 2017-03-14 20:31:36 --> Config Class Initialized
INFO - 2017-03-14 20:31:36 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:31:36 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:31:36 --> Utf8 Class Initialized
INFO - 2017-03-14 20:31:36 --> URI Class Initialized
INFO - 2017-03-14 20:31:36 --> Router Class Initialized
INFO - 2017-03-14 20:31:36 --> Output Class Initialized
INFO - 2017-03-14 20:31:36 --> Security Class Initialized
DEBUG - 2017-03-14 20:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:31:36 --> Input Class Initialized
INFO - 2017-03-14 20:31:36 --> Language Class Initialized
INFO - 2017-03-14 20:31:36 --> Loader Class Initialized
INFO - 2017-03-14 20:31:36 --> Database Driver Class Initialized
INFO - 2017-03-14 20:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:31:36 --> Controller Class Initialized
INFO - 2017-03-14 20:31:36 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:31:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:31:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:31:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:31:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:31:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:31:36 --> Final output sent to browser
DEBUG - 2017-03-14 20:31:36 --> Total execution time: 0.2519
INFO - 2017-03-14 20:31:45 --> Config Class Initialized
INFO - 2017-03-14 20:31:45 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:31:45 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:31:45 --> Utf8 Class Initialized
INFO - 2017-03-14 20:31:45 --> URI Class Initialized
DEBUG - 2017-03-14 20:31:45 --> No URI present. Default controller set.
INFO - 2017-03-14 20:31:45 --> Router Class Initialized
INFO - 2017-03-14 20:31:45 --> Output Class Initialized
INFO - 2017-03-14 20:31:45 --> Security Class Initialized
DEBUG - 2017-03-14 20:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:31:45 --> Input Class Initialized
INFO - 2017-03-14 20:31:45 --> Language Class Initialized
INFO - 2017-03-14 20:31:45 --> Loader Class Initialized
INFO - 2017-03-14 20:31:45 --> Database Driver Class Initialized
INFO - 2017-03-14 20:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:31:45 --> Controller Class Initialized
INFO - 2017-03-14 20:31:45 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:31:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:31:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:31:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:31:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:31:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:31:45 --> Final output sent to browser
DEBUG - 2017-03-14 20:31:45 --> Total execution time: 0.0145
INFO - 2017-03-14 20:31:47 --> Config Class Initialized
INFO - 2017-03-14 20:31:47 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:31:47 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:31:47 --> Utf8 Class Initialized
INFO - 2017-03-14 20:31:47 --> URI Class Initialized
INFO - 2017-03-14 20:31:47 --> Router Class Initialized
INFO - 2017-03-14 20:31:47 --> Output Class Initialized
INFO - 2017-03-14 20:31:47 --> Security Class Initialized
DEBUG - 2017-03-14 20:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:31:47 --> Input Class Initialized
INFO - 2017-03-14 20:31:47 --> Language Class Initialized
INFO - 2017-03-14 20:31:47 --> Loader Class Initialized
INFO - 2017-03-14 20:31:47 --> Database Driver Class Initialized
INFO - 2017-03-14 20:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:31:47 --> Controller Class Initialized
INFO - 2017-03-14 20:31:47 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:31:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:31:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:31:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:31:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:31:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:31:47 --> Final output sent to browser
DEBUG - 2017-03-14 20:31:47 --> Total execution time: 0.0901
INFO - 2017-03-14 20:32:08 --> Config Class Initialized
INFO - 2017-03-14 20:32:08 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:32:08 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:32:08 --> Utf8 Class Initialized
INFO - 2017-03-14 20:32:08 --> URI Class Initialized
INFO - 2017-03-14 20:32:08 --> Router Class Initialized
INFO - 2017-03-14 20:32:08 --> Output Class Initialized
INFO - 2017-03-14 20:32:08 --> Security Class Initialized
DEBUG - 2017-03-14 20:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:32:08 --> Input Class Initialized
INFO - 2017-03-14 20:32:08 --> Language Class Initialized
INFO - 2017-03-14 20:32:08 --> Loader Class Initialized
INFO - 2017-03-14 20:32:08 --> Database Driver Class Initialized
INFO - 2017-03-14 20:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:32:08 --> Controller Class Initialized
INFO - 2017-03-14 20:32:08 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:32:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:32:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:32:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:32:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:32:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:32:08 --> Final output sent to browser
DEBUG - 2017-03-14 20:32:08 --> Total execution time: 0.2308
INFO - 2017-03-14 20:32:09 --> Config Class Initialized
INFO - 2017-03-14 20:32:09 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:32:09 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:32:09 --> Utf8 Class Initialized
INFO - 2017-03-14 20:32:09 --> URI Class Initialized
INFO - 2017-03-14 20:32:09 --> Router Class Initialized
INFO - 2017-03-14 20:32:09 --> Output Class Initialized
INFO - 2017-03-14 20:32:09 --> Security Class Initialized
DEBUG - 2017-03-14 20:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:32:09 --> Input Class Initialized
INFO - 2017-03-14 20:32:09 --> Language Class Initialized
INFO - 2017-03-14 20:32:09 --> Loader Class Initialized
INFO - 2017-03-14 20:32:09 --> Database Driver Class Initialized
INFO - 2017-03-14 20:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:32:09 --> Controller Class Initialized
INFO - 2017-03-14 20:32:09 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:32:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:32:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:32:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:32:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:32:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:32:09 --> Final output sent to browser
DEBUG - 2017-03-14 20:32:09 --> Total execution time: 0.0138
INFO - 2017-03-14 20:32:22 --> Config Class Initialized
INFO - 2017-03-14 20:32:22 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:32:22 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:32:22 --> Utf8 Class Initialized
INFO - 2017-03-14 20:32:22 --> URI Class Initialized
INFO - 2017-03-14 20:32:22 --> Router Class Initialized
INFO - 2017-03-14 20:32:22 --> Output Class Initialized
INFO - 2017-03-14 20:32:22 --> Security Class Initialized
DEBUG - 2017-03-14 20:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:32:22 --> Input Class Initialized
INFO - 2017-03-14 20:32:22 --> Language Class Initialized
INFO - 2017-03-14 20:32:22 --> Loader Class Initialized
INFO - 2017-03-14 20:32:22 --> Database Driver Class Initialized
INFO - 2017-03-14 20:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:32:22 --> Controller Class Initialized
INFO - 2017-03-14 20:32:22 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:32:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:32:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:32:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:32:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:32:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:32:22 --> Final output sent to browser
DEBUG - 2017-03-14 20:32:22 --> Total execution time: 0.0145
INFO - 2017-03-14 20:32:23 --> Config Class Initialized
INFO - 2017-03-14 20:32:23 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:32:23 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:32:23 --> Utf8 Class Initialized
INFO - 2017-03-14 20:32:23 --> URI Class Initialized
INFO - 2017-03-14 20:32:23 --> Router Class Initialized
INFO - 2017-03-14 20:32:23 --> Output Class Initialized
INFO - 2017-03-14 20:32:23 --> Security Class Initialized
DEBUG - 2017-03-14 20:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:32:23 --> Input Class Initialized
INFO - 2017-03-14 20:32:23 --> Language Class Initialized
INFO - 2017-03-14 20:32:23 --> Loader Class Initialized
INFO - 2017-03-14 20:32:23 --> Database Driver Class Initialized
INFO - 2017-03-14 20:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:32:23 --> Controller Class Initialized
INFO - 2017-03-14 20:32:23 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:32:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:32:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:32:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:32:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:32:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:32:23 --> Final output sent to browser
DEBUG - 2017-03-14 20:32:23 --> Total execution time: 0.0140
INFO - 2017-03-14 20:55:02 --> Config Class Initialized
INFO - 2017-03-14 20:55:02 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:55:02 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:55:02 --> Utf8 Class Initialized
INFO - 2017-03-14 20:55:02 --> URI Class Initialized
DEBUG - 2017-03-14 20:55:03 --> No URI present. Default controller set.
INFO - 2017-03-14 20:55:03 --> Router Class Initialized
INFO - 2017-03-14 20:55:03 --> Output Class Initialized
INFO - 2017-03-14 20:55:03 --> Security Class Initialized
DEBUG - 2017-03-14 20:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:55:03 --> Input Class Initialized
INFO - 2017-03-14 20:55:03 --> Language Class Initialized
INFO - 2017-03-14 20:55:03 --> Loader Class Initialized
INFO - 2017-03-14 20:55:07 --> Database Driver Class Initialized
INFO - 2017-03-14 20:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:55:07 --> Controller Class Initialized
INFO - 2017-03-14 20:55:07 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:55:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:55:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:55:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:55:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:55:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:55:07 --> Final output sent to browser
DEBUG - 2017-03-14 20:55:07 --> Total execution time: 4.7455
INFO - 2017-03-14 20:55:10 --> Config Class Initialized
INFO - 2017-03-14 20:55:10 --> Hooks Class Initialized
DEBUG - 2017-03-14 20:55:10 --> UTF-8 Support Enabled
INFO - 2017-03-14 20:55:10 --> Utf8 Class Initialized
INFO - 2017-03-14 20:55:10 --> URI Class Initialized
INFO - 2017-03-14 20:55:10 --> Router Class Initialized
INFO - 2017-03-14 20:55:10 --> Output Class Initialized
INFO - 2017-03-14 20:55:10 --> Security Class Initialized
DEBUG - 2017-03-14 20:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 20:55:10 --> Input Class Initialized
INFO - 2017-03-14 20:55:10 --> Language Class Initialized
INFO - 2017-03-14 20:55:10 --> Loader Class Initialized
INFO - 2017-03-14 20:55:10 --> Database Driver Class Initialized
INFO - 2017-03-14 20:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 20:55:10 --> Controller Class Initialized
INFO - 2017-03-14 20:55:10 --> Helper loaded: url_helper
DEBUG - 2017-03-14 20:55:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 20:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 20:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 20:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 20:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 20:55:10 --> Final output sent to browser
DEBUG - 2017-03-14 20:55:10 --> Total execution time: 0.0140
INFO - 2017-03-14 21:16:04 --> Config Class Initialized
INFO - 2017-03-14 21:16:04 --> Hooks Class Initialized
DEBUG - 2017-03-14 21:16:04 --> UTF-8 Support Enabled
INFO - 2017-03-14 21:16:04 --> Utf8 Class Initialized
INFO - 2017-03-14 21:16:04 --> URI Class Initialized
DEBUG - 2017-03-14 21:16:04 --> No URI present. Default controller set.
INFO - 2017-03-14 21:16:04 --> Router Class Initialized
INFO - 2017-03-14 21:16:04 --> Output Class Initialized
INFO - 2017-03-14 21:16:04 --> Security Class Initialized
DEBUG - 2017-03-14 21:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 21:16:04 --> Input Class Initialized
INFO - 2017-03-14 21:16:04 --> Language Class Initialized
INFO - 2017-03-14 21:16:04 --> Loader Class Initialized
INFO - 2017-03-14 21:16:04 --> Database Driver Class Initialized
INFO - 2017-03-14 21:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 21:16:04 --> Controller Class Initialized
INFO - 2017-03-14 21:16:04 --> Helper loaded: url_helper
DEBUG - 2017-03-14 21:16:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 21:16:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 21:16:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 21:16:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 21:16:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 21:16:05 --> Final output sent to browser
DEBUG - 2017-03-14 21:16:05 --> Total execution time: 0.6493
INFO - 2017-03-14 21:19:26 --> Config Class Initialized
INFO - 2017-03-14 21:19:26 --> Hooks Class Initialized
DEBUG - 2017-03-14 21:19:27 --> UTF-8 Support Enabled
INFO - 2017-03-14 21:19:27 --> Utf8 Class Initialized
INFO - 2017-03-14 21:19:27 --> URI Class Initialized
INFO - 2017-03-14 21:19:27 --> Router Class Initialized
INFO - 2017-03-14 21:19:27 --> Output Class Initialized
INFO - 2017-03-14 21:19:27 --> Security Class Initialized
DEBUG - 2017-03-14 21:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 21:19:27 --> Input Class Initialized
INFO - 2017-03-14 21:19:27 --> Language Class Initialized
INFO - 2017-03-14 21:19:27 --> Loader Class Initialized
INFO - 2017-03-14 21:19:27 --> Database Driver Class Initialized
INFO - 2017-03-14 21:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 21:19:28 --> Controller Class Initialized
INFO - 2017-03-14 21:19:28 --> Helper loaded: date_helper
DEBUG - 2017-03-14 21:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 21:19:28 --> Helper loaded: url_helper
INFO - 2017-03-14 21:19:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 21:19:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 21:19:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 21:19:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 21:19:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 21:19:28 --> Final output sent to browser
DEBUG - 2017-03-14 21:19:28 --> Total execution time: 1.7926
INFO - 2017-03-14 21:20:19 --> Config Class Initialized
INFO - 2017-03-14 21:20:19 --> Hooks Class Initialized
DEBUG - 2017-03-14 21:20:19 --> UTF-8 Support Enabled
INFO - 2017-03-14 21:20:19 --> Utf8 Class Initialized
INFO - 2017-03-14 21:20:19 --> URI Class Initialized
INFO - 2017-03-14 21:20:20 --> Router Class Initialized
INFO - 2017-03-14 21:20:20 --> Output Class Initialized
INFO - 2017-03-14 21:20:20 --> Security Class Initialized
DEBUG - 2017-03-14 21:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 21:20:20 --> Input Class Initialized
INFO - 2017-03-14 21:20:20 --> Language Class Initialized
INFO - 2017-03-14 21:20:20 --> Loader Class Initialized
INFO - 2017-03-14 21:20:20 --> Database Driver Class Initialized
INFO - 2017-03-14 21:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 21:20:20 --> Controller Class Initialized
INFO - 2017-03-14 21:20:20 --> Helper loaded: url_helper
DEBUG - 2017-03-14 21:20:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 21:20:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 21:20:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 21:20:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 21:20:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 21:20:21 --> Final output sent to browser
DEBUG - 2017-03-14 21:20:21 --> Total execution time: 1.2230
INFO - 2017-03-14 21:24:19 --> Config Class Initialized
INFO - 2017-03-14 21:24:19 --> Hooks Class Initialized
DEBUG - 2017-03-14 21:24:20 --> UTF-8 Support Enabled
INFO - 2017-03-14 21:24:20 --> Utf8 Class Initialized
INFO - 2017-03-14 21:24:20 --> URI Class Initialized
INFO - 2017-03-14 21:24:20 --> Router Class Initialized
INFO - 2017-03-14 21:24:20 --> Output Class Initialized
INFO - 2017-03-14 21:24:20 --> Security Class Initialized
DEBUG - 2017-03-14 21:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 21:24:20 --> Input Class Initialized
INFO - 2017-03-14 21:24:20 --> Language Class Initialized
INFO - 2017-03-14 21:24:20 --> Loader Class Initialized
INFO - 2017-03-14 21:24:20 --> Database Driver Class Initialized
INFO - 2017-03-14 21:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 21:24:21 --> Controller Class Initialized
INFO - 2017-03-14 21:24:21 --> Helper loaded: date_helper
DEBUG - 2017-03-14 21:24:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 21:24:21 --> Helper loaded: url_helper
INFO - 2017-03-14 21:24:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 21:24:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 21:24:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 21:24:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 21:24:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 21:24:21 --> Final output sent to browser
DEBUG - 2017-03-14 21:24:21 --> Total execution time: 1.5854
INFO - 2017-03-14 21:24:23 --> Config Class Initialized
INFO - 2017-03-14 21:24:23 --> Hooks Class Initialized
DEBUG - 2017-03-14 21:24:23 --> UTF-8 Support Enabled
INFO - 2017-03-14 21:24:23 --> Utf8 Class Initialized
INFO - 2017-03-14 21:24:23 --> URI Class Initialized
INFO - 2017-03-14 21:24:23 --> Router Class Initialized
INFO - 2017-03-14 21:24:23 --> Output Class Initialized
INFO - 2017-03-14 21:24:23 --> Security Class Initialized
DEBUG - 2017-03-14 21:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 21:24:23 --> Input Class Initialized
INFO - 2017-03-14 21:24:23 --> Language Class Initialized
INFO - 2017-03-14 21:24:23 --> Loader Class Initialized
INFO - 2017-03-14 21:24:23 --> Database Driver Class Initialized
INFO - 2017-03-14 21:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 21:24:23 --> Controller Class Initialized
INFO - 2017-03-14 21:24:23 --> Helper loaded: url_helper
DEBUG - 2017-03-14 21:24:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 21:24:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 21:24:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 21:24:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 21:24:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 21:24:23 --> Final output sent to browser
DEBUG - 2017-03-14 21:24:23 --> Total execution time: 0.2548
INFO - 2017-03-14 22:12:52 --> Config Class Initialized
INFO - 2017-03-14 22:12:52 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:12:52 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:12:52 --> Utf8 Class Initialized
INFO - 2017-03-14 22:12:52 --> URI Class Initialized
DEBUG - 2017-03-14 22:12:52 --> No URI present. Default controller set.
INFO - 2017-03-14 22:12:52 --> Router Class Initialized
INFO - 2017-03-14 22:12:52 --> Output Class Initialized
INFO - 2017-03-14 22:12:52 --> Security Class Initialized
DEBUG - 2017-03-14 22:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:12:52 --> Input Class Initialized
INFO - 2017-03-14 22:12:52 --> Language Class Initialized
INFO - 2017-03-14 22:12:53 --> Loader Class Initialized
INFO - 2017-03-14 22:12:53 --> Database Driver Class Initialized
INFO - 2017-03-14 22:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:12:54 --> Controller Class Initialized
INFO - 2017-03-14 22:12:54 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:12:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:12:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 22:12:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 22:12:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 22:12:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 22:12:54 --> Final output sent to browser
DEBUG - 2017-03-14 22:12:54 --> Total execution time: 2.0292
INFO - 2017-03-14 22:12:56 --> Config Class Initialized
INFO - 2017-03-14 22:12:56 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:12:56 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:12:56 --> Utf8 Class Initialized
INFO - 2017-03-14 22:12:56 --> URI Class Initialized
INFO - 2017-03-14 22:12:56 --> Router Class Initialized
INFO - 2017-03-14 22:12:56 --> Output Class Initialized
INFO - 2017-03-14 22:12:56 --> Security Class Initialized
DEBUG - 2017-03-14 22:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:12:56 --> Input Class Initialized
INFO - 2017-03-14 22:12:56 --> Language Class Initialized
INFO - 2017-03-14 22:12:56 --> Loader Class Initialized
INFO - 2017-03-14 22:12:56 --> Database Driver Class Initialized
INFO - 2017-03-14 22:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:12:57 --> Controller Class Initialized
INFO - 2017-03-14 22:12:57 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:12:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 22:12:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 22:12:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 22:12:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 22:12:57 --> Final output sent to browser
DEBUG - 2017-03-14 22:12:57 --> Total execution time: 1.2429
INFO - 2017-03-14 22:13:06 --> Config Class Initialized
INFO - 2017-03-14 22:13:06 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:13:06 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:13:06 --> Utf8 Class Initialized
INFO - 2017-03-14 22:13:06 --> URI Class Initialized
INFO - 2017-03-14 22:13:06 --> Router Class Initialized
INFO - 2017-03-14 22:13:06 --> Output Class Initialized
INFO - 2017-03-14 22:13:06 --> Security Class Initialized
DEBUG - 2017-03-14 22:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:13:06 --> Input Class Initialized
INFO - 2017-03-14 22:13:06 --> Language Class Initialized
INFO - 2017-03-14 22:13:06 --> Loader Class Initialized
INFO - 2017-03-14 22:13:07 --> Database Driver Class Initialized
INFO - 2017-03-14 22:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:13:07 --> Controller Class Initialized
INFO - 2017-03-14 22:13:08 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:13:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:13:08 --> Helper loaded: form_helper
INFO - 2017-03-14 22:13:08 --> Form Validation Class Initialized
INFO - 2017-03-14 22:13:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-14 22:13:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-03-14 22:13:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-14 22:13:08 --> Final output sent to browser
DEBUG - 2017-03-14 22:13:08 --> Total execution time: 1.9750
INFO - 2017-03-14 22:13:09 --> Config Class Initialized
INFO - 2017-03-14 22:13:09 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:13:09 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:13:09 --> Utf8 Class Initialized
INFO - 2017-03-14 22:13:09 --> URI Class Initialized
INFO - 2017-03-14 22:13:09 --> Router Class Initialized
INFO - 2017-03-14 22:13:09 --> Output Class Initialized
INFO - 2017-03-14 22:13:09 --> Security Class Initialized
DEBUG - 2017-03-14 22:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:13:09 --> Input Class Initialized
INFO - 2017-03-14 22:13:09 --> Language Class Initialized
INFO - 2017-03-14 22:13:09 --> Loader Class Initialized
INFO - 2017-03-14 22:13:09 --> Database Driver Class Initialized
INFO - 2017-03-14 22:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:13:09 --> Controller Class Initialized
INFO - 2017-03-14 22:13:09 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:13:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:13:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 22:13:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 22:13:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 22:13:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 22:13:10 --> Final output sent to browser
DEBUG - 2017-03-14 22:13:10 --> Total execution time: 1.0738
INFO - 2017-03-14 22:13:24 --> Config Class Initialized
INFO - 2017-03-14 22:13:24 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:13:24 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:13:24 --> Utf8 Class Initialized
INFO - 2017-03-14 22:13:24 --> URI Class Initialized
INFO - 2017-03-14 22:13:24 --> Router Class Initialized
INFO - 2017-03-14 22:13:24 --> Output Class Initialized
INFO - 2017-03-14 22:13:24 --> Security Class Initialized
DEBUG - 2017-03-14 22:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:13:24 --> Input Class Initialized
INFO - 2017-03-14 22:13:24 --> Language Class Initialized
INFO - 2017-03-14 22:13:24 --> Loader Class Initialized
INFO - 2017-03-14 22:13:24 --> Database Driver Class Initialized
INFO - 2017-03-14 22:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:13:25 --> Controller Class Initialized
INFO - 2017-03-14 22:13:25 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:13:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:13:25 --> Helper loaded: form_helper
INFO - 2017-03-14 22:13:25 --> Form Validation Class Initialized
INFO - 2017-03-14 22:13:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-14 22:13:25 --> Config Class Initialized
INFO - 2017-03-14 22:13:25 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:13:25 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:13:25 --> Utf8 Class Initialized
INFO - 2017-03-14 22:13:25 --> URI Class Initialized
INFO - 2017-03-14 22:13:25 --> Router Class Initialized
INFO - 2017-03-14 22:13:25 --> Output Class Initialized
INFO - 2017-03-14 22:13:25 --> Security Class Initialized
DEBUG - 2017-03-14 22:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:13:25 --> Input Class Initialized
INFO - 2017-03-14 22:13:25 --> Language Class Initialized
INFO - 2017-03-14 22:13:25 --> Loader Class Initialized
INFO - 2017-03-14 22:13:25 --> Database Driver Class Initialized
INFO - 2017-03-14 22:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:13:25 --> Controller Class Initialized
INFO - 2017-03-14 22:13:25 --> Helper loaded: date_helper
INFO - 2017-03-14 22:13:25 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:13:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:13:25 --> Helper loaded: form_helper
INFO - 2017-03-14 22:13:25 --> Form Validation Class Initialized
INFO - 2017-03-14 22:13:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-14 22:13:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-14 22:13:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-03-14 22:13:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-03-14 22:13:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-14 22:13:26 --> Final output sent to browser
DEBUG - 2017-03-14 22:13:26 --> Total execution time: 0.2123
INFO - 2017-03-14 22:13:26 --> Config Class Initialized
INFO - 2017-03-14 22:13:26 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:13:26 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:13:26 --> Utf8 Class Initialized
INFO - 2017-03-14 22:13:26 --> URI Class Initialized
INFO - 2017-03-14 22:13:26 --> Router Class Initialized
INFO - 2017-03-14 22:13:26 --> Output Class Initialized
INFO - 2017-03-14 22:13:26 --> Security Class Initialized
DEBUG - 2017-03-14 22:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:13:26 --> Input Class Initialized
INFO - 2017-03-14 22:13:26 --> Language Class Initialized
INFO - 2017-03-14 22:13:26 --> Loader Class Initialized
INFO - 2017-03-14 22:13:26 --> Database Driver Class Initialized
INFO - 2017-03-14 22:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:13:26 --> Controller Class Initialized
INFO - 2017-03-14 22:13:26 --> Helper loaded: date_helper
INFO - 2017-03-14 22:13:26 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:13:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:13:26 --> Helper loaded: form_helper
INFO - 2017-03-14 22:13:26 --> Form Validation Class Initialized
INFO - 2017-03-14 22:13:26 --> Config Class Initialized
INFO - 2017-03-14 22:13:26 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:13:26 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:13:26 --> Utf8 Class Initialized
INFO - 2017-03-14 22:13:26 --> URI Class Initialized
INFO - 2017-03-14 22:13:26 --> Router Class Initialized
INFO - 2017-03-14 22:13:26 --> Output Class Initialized
INFO - 2017-03-14 22:13:26 --> Security Class Initialized
DEBUG - 2017-03-14 22:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:13:26 --> Input Class Initialized
INFO - 2017-03-14 22:13:26 --> Language Class Initialized
INFO - 2017-03-14 22:13:26 --> Loader Class Initialized
INFO - 2017-03-14 22:13:26 --> Database Driver Class Initialized
INFO - 2017-03-14 22:13:26 --> Final output sent to browser
DEBUG - 2017-03-14 22:13:26 --> Total execution time: 0.1299
INFO - 2017-03-14 22:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:13:26 --> Controller Class Initialized
INFO - 2017-03-14 22:13:26 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:13:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:13:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 22:13:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 22:13:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 22:13:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 22:13:26 --> Final output sent to browser
DEBUG - 2017-03-14 22:13:26 --> Total execution time: 0.3014
INFO - 2017-03-14 22:32:30 --> Config Class Initialized
INFO - 2017-03-14 22:32:30 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:32:30 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:32:30 --> Utf8 Class Initialized
INFO - 2017-03-14 22:32:30 --> URI Class Initialized
DEBUG - 2017-03-14 22:32:30 --> No URI present. Default controller set.
INFO - 2017-03-14 22:32:31 --> Router Class Initialized
INFO - 2017-03-14 22:32:31 --> Output Class Initialized
INFO - 2017-03-14 22:32:31 --> Security Class Initialized
DEBUG - 2017-03-14 22:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:32:31 --> Input Class Initialized
INFO - 2017-03-14 22:32:31 --> Language Class Initialized
INFO - 2017-03-14 22:32:31 --> Loader Class Initialized
INFO - 2017-03-14 22:32:31 --> Database Driver Class Initialized
INFO - 2017-03-14 22:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:32:32 --> Controller Class Initialized
INFO - 2017-03-14 22:32:32 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:32:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:32:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 22:32:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 22:32:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 22:32:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 22:32:34 --> Final output sent to browser
DEBUG - 2017-03-14 22:32:34 --> Total execution time: 3.8839
INFO - 2017-03-14 22:32:41 --> Config Class Initialized
INFO - 2017-03-14 22:32:41 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:32:41 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:32:41 --> Utf8 Class Initialized
INFO - 2017-03-14 22:32:41 --> URI Class Initialized
INFO - 2017-03-14 22:32:41 --> Router Class Initialized
INFO - 2017-03-14 22:32:41 --> Output Class Initialized
INFO - 2017-03-14 22:32:41 --> Security Class Initialized
DEBUG - 2017-03-14 22:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:32:42 --> Input Class Initialized
INFO - 2017-03-14 22:32:42 --> Language Class Initialized
INFO - 2017-03-14 22:32:42 --> Loader Class Initialized
INFO - 2017-03-14 22:32:42 --> Database Driver Class Initialized
INFO - 2017-03-14 22:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:32:42 --> Controller Class Initialized
INFO - 2017-03-14 22:32:42 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:32:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:32:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 22:32:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 22:32:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 22:32:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 22:32:42 --> Final output sent to browser
DEBUG - 2017-03-14 22:32:42 --> Total execution time: 1.5196
INFO - 2017-03-14 22:33:52 --> Config Class Initialized
INFO - 2017-03-14 22:33:52 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:33:52 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:33:52 --> Utf8 Class Initialized
INFO - 2017-03-14 22:33:52 --> URI Class Initialized
INFO - 2017-03-14 22:33:52 --> Router Class Initialized
INFO - 2017-03-14 22:33:52 --> Output Class Initialized
INFO - 2017-03-14 22:33:52 --> Security Class Initialized
DEBUG - 2017-03-14 22:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:33:52 --> Input Class Initialized
INFO - 2017-03-14 22:33:52 --> Language Class Initialized
INFO - 2017-03-14 22:33:52 --> Loader Class Initialized
INFO - 2017-03-14 22:33:52 --> Database Driver Class Initialized
INFO - 2017-03-14 22:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:33:53 --> Controller Class Initialized
INFO - 2017-03-14 22:33:53 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:33:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:33:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 22:33:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 22:33:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 22:33:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 22:33:53 --> Final output sent to browser
DEBUG - 2017-03-14 22:33:53 --> Total execution time: 1.2669
INFO - 2017-03-14 22:33:55 --> Config Class Initialized
INFO - 2017-03-14 22:33:55 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:33:55 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:33:55 --> Utf8 Class Initialized
INFO - 2017-03-14 22:33:55 --> URI Class Initialized
INFO - 2017-03-14 22:33:55 --> Router Class Initialized
INFO - 2017-03-14 22:33:55 --> Output Class Initialized
INFO - 2017-03-14 22:33:55 --> Security Class Initialized
DEBUG - 2017-03-14 22:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:33:55 --> Input Class Initialized
INFO - 2017-03-14 22:33:55 --> Language Class Initialized
INFO - 2017-03-14 22:33:55 --> Loader Class Initialized
INFO - 2017-03-14 22:33:55 --> Database Driver Class Initialized
INFO - 2017-03-14 22:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:33:55 --> Controller Class Initialized
INFO - 2017-03-14 22:33:55 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:33:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:33:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 22:33:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 22:33:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 22:33:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 22:33:55 --> Final output sent to browser
DEBUG - 2017-03-14 22:33:55 --> Total execution time: 0.0136
INFO - 2017-03-14 22:35:34 --> Config Class Initialized
INFO - 2017-03-14 22:35:34 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:35:34 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:35:34 --> Utf8 Class Initialized
INFO - 2017-03-14 22:35:34 --> URI Class Initialized
INFO - 2017-03-14 22:35:34 --> Router Class Initialized
INFO - 2017-03-14 22:35:34 --> Output Class Initialized
INFO - 2017-03-14 22:35:34 --> Security Class Initialized
DEBUG - 2017-03-14 22:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:35:34 --> Input Class Initialized
INFO - 2017-03-14 22:35:34 --> Language Class Initialized
INFO - 2017-03-14 22:35:34 --> Loader Class Initialized
INFO - 2017-03-14 22:35:34 --> Database Driver Class Initialized
INFO - 2017-03-14 22:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:35:35 --> Controller Class Initialized
INFO - 2017-03-14 22:35:35 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:35:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:35:37 --> Config Class Initialized
INFO - 2017-03-14 22:35:37 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:35:37 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:35:37 --> Utf8 Class Initialized
INFO - 2017-03-14 22:35:37 --> URI Class Initialized
INFO - 2017-03-14 22:35:37 --> Router Class Initialized
INFO - 2017-03-14 22:35:37 --> Output Class Initialized
INFO - 2017-03-14 22:35:37 --> Security Class Initialized
DEBUG - 2017-03-14 22:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:35:37 --> Input Class Initialized
INFO - 2017-03-14 22:35:37 --> Language Class Initialized
INFO - 2017-03-14 22:35:37 --> Loader Class Initialized
INFO - 2017-03-14 22:35:37 --> Database Driver Class Initialized
INFO - 2017-03-14 22:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:35:37 --> Controller Class Initialized
INFO - 2017-03-14 22:35:37 --> Helper loaded: date_helper
DEBUG - 2017-03-14 22:35:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:35:37 --> Helper loaded: url_helper
INFO - 2017-03-14 22:35:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 22:35:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 22:35:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 22:35:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 22:35:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 22:35:37 --> Final output sent to browser
DEBUG - 2017-03-14 22:35:37 --> Total execution time: 0.1032
INFO - 2017-03-14 22:35:38 --> Config Class Initialized
INFO - 2017-03-14 22:35:38 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:35:38 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:35:38 --> Utf8 Class Initialized
INFO - 2017-03-14 22:35:38 --> URI Class Initialized
INFO - 2017-03-14 22:35:38 --> Router Class Initialized
INFO - 2017-03-14 22:35:38 --> Output Class Initialized
INFO - 2017-03-14 22:35:38 --> Security Class Initialized
DEBUG - 2017-03-14 22:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:35:38 --> Input Class Initialized
INFO - 2017-03-14 22:35:38 --> Language Class Initialized
INFO - 2017-03-14 22:35:38 --> Loader Class Initialized
INFO - 2017-03-14 22:35:38 --> Database Driver Class Initialized
INFO - 2017-03-14 22:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:35:38 --> Controller Class Initialized
INFO - 2017-03-14 22:35:38 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:35:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:35:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 22:35:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 22:35:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 22:35:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 22:35:38 --> Final output sent to browser
DEBUG - 2017-03-14 22:35:38 --> Total execution time: 0.0378
INFO - 2017-03-14 22:35:44 --> Config Class Initialized
INFO - 2017-03-14 22:35:44 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:35:44 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:35:44 --> Utf8 Class Initialized
INFO - 2017-03-14 22:35:44 --> URI Class Initialized
INFO - 2017-03-14 22:35:44 --> Router Class Initialized
INFO - 2017-03-14 22:35:44 --> Output Class Initialized
INFO - 2017-03-14 22:35:44 --> Security Class Initialized
DEBUG - 2017-03-14 22:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:35:44 --> Input Class Initialized
INFO - 2017-03-14 22:35:44 --> Language Class Initialized
INFO - 2017-03-14 22:35:44 --> Loader Class Initialized
INFO - 2017-03-14 22:35:44 --> Database Driver Class Initialized
INFO - 2017-03-14 22:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:35:44 --> Controller Class Initialized
INFO - 2017-03-14 22:35:44 --> Helper loaded: date_helper
DEBUG - 2017-03-14 22:35:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:35:44 --> Helper loaded: url_helper
INFO - 2017-03-14 22:35:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 22:35:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 22:35:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 22:35:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 22:35:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 22:35:44 --> Final output sent to browser
DEBUG - 2017-03-14 22:35:44 --> Total execution time: 0.0163
INFO - 2017-03-14 22:35:46 --> Config Class Initialized
INFO - 2017-03-14 22:35:46 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:35:46 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:35:46 --> Utf8 Class Initialized
INFO - 2017-03-14 22:35:46 --> URI Class Initialized
INFO - 2017-03-14 22:35:46 --> Router Class Initialized
INFO - 2017-03-14 22:35:46 --> Output Class Initialized
INFO - 2017-03-14 22:35:46 --> Security Class Initialized
DEBUG - 2017-03-14 22:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:35:46 --> Input Class Initialized
INFO - 2017-03-14 22:35:46 --> Language Class Initialized
INFO - 2017-03-14 22:35:46 --> Loader Class Initialized
INFO - 2017-03-14 22:35:46 --> Database Driver Class Initialized
INFO - 2017-03-14 22:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:35:46 --> Controller Class Initialized
INFO - 2017-03-14 22:35:46 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:35:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:35:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 22:35:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 22:35:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 22:35:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 22:35:46 --> Final output sent to browser
DEBUG - 2017-03-14 22:35:46 --> Total execution time: 0.0138
INFO - 2017-03-14 22:35:56 --> Config Class Initialized
INFO - 2017-03-14 22:35:56 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:35:56 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:35:56 --> Utf8 Class Initialized
INFO - 2017-03-14 22:35:56 --> URI Class Initialized
DEBUG - 2017-03-14 22:35:56 --> No URI present. Default controller set.
INFO - 2017-03-14 22:35:57 --> Router Class Initialized
INFO - 2017-03-14 22:35:57 --> Output Class Initialized
INFO - 2017-03-14 22:35:57 --> Security Class Initialized
DEBUG - 2017-03-14 22:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:35:57 --> Input Class Initialized
INFO - 2017-03-14 22:35:57 --> Language Class Initialized
INFO - 2017-03-14 22:35:57 --> Loader Class Initialized
INFO - 2017-03-14 22:35:57 --> Database Driver Class Initialized
INFO - 2017-03-14 22:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:35:57 --> Controller Class Initialized
INFO - 2017-03-14 22:35:57 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:35:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:35:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 22:35:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 22:35:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 22:35:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 22:35:59 --> Final output sent to browser
DEBUG - 2017-03-14 22:35:59 --> Total execution time: 1.4677
INFO - 2017-03-14 22:36:02 --> Config Class Initialized
INFO - 2017-03-14 22:36:02 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:36:02 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:36:02 --> Utf8 Class Initialized
INFO - 2017-03-14 22:36:02 --> URI Class Initialized
INFO - 2017-03-14 22:36:02 --> Router Class Initialized
INFO - 2017-03-14 22:36:03 --> Output Class Initialized
INFO - 2017-03-14 22:36:03 --> Security Class Initialized
DEBUG - 2017-03-14 22:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:36:03 --> Input Class Initialized
INFO - 2017-03-14 22:36:03 --> Language Class Initialized
INFO - 2017-03-14 22:36:03 --> Loader Class Initialized
INFO - 2017-03-14 22:36:03 --> Database Driver Class Initialized
INFO - 2017-03-14 22:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:36:03 --> Controller Class Initialized
INFO - 2017-03-14 22:36:03 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:36:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:36:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 22:36:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 22:36:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 22:36:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 22:36:04 --> Final output sent to browser
DEBUG - 2017-03-14 22:36:04 --> Total execution time: 1.2352
INFO - 2017-03-14 22:37:01 --> Config Class Initialized
INFO - 2017-03-14 22:37:01 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:37:02 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:37:02 --> Utf8 Class Initialized
INFO - 2017-03-14 22:37:02 --> URI Class Initialized
INFO - 2017-03-14 22:37:02 --> Router Class Initialized
INFO - 2017-03-14 22:37:02 --> Output Class Initialized
INFO - 2017-03-14 22:37:02 --> Security Class Initialized
DEBUG - 2017-03-14 22:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:37:02 --> Input Class Initialized
INFO - 2017-03-14 22:37:02 --> Language Class Initialized
INFO - 2017-03-14 22:37:02 --> Loader Class Initialized
INFO - 2017-03-14 22:37:02 --> Database Driver Class Initialized
INFO - 2017-03-14 22:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:37:03 --> Controller Class Initialized
INFO - 2017-03-14 22:37:03 --> Helper loaded: date_helper
DEBUG - 2017-03-14 22:37:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:37:03 --> Helper loaded: url_helper
INFO - 2017-03-14 22:37:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 22:37:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 22:37:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 22:37:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 22:37:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 22:37:03 --> Final output sent to browser
DEBUG - 2017-03-14 22:37:03 --> Total execution time: 1.4792
INFO - 2017-03-14 22:37:04 --> Config Class Initialized
INFO - 2017-03-14 22:37:04 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:37:04 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:37:04 --> Utf8 Class Initialized
INFO - 2017-03-14 22:37:04 --> URI Class Initialized
INFO - 2017-03-14 22:37:04 --> Router Class Initialized
INFO - 2017-03-14 22:37:04 --> Output Class Initialized
INFO - 2017-03-14 22:37:04 --> Security Class Initialized
DEBUG - 2017-03-14 22:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:37:04 --> Input Class Initialized
INFO - 2017-03-14 22:37:04 --> Language Class Initialized
INFO - 2017-03-14 22:37:04 --> Loader Class Initialized
INFO - 2017-03-14 22:37:04 --> Database Driver Class Initialized
INFO - 2017-03-14 22:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:37:04 --> Controller Class Initialized
INFO - 2017-03-14 22:37:04 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:37:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:37:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 22:37:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 22:37:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 22:37:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 22:37:05 --> Final output sent to browser
DEBUG - 2017-03-14 22:37:05 --> Total execution time: 0.2626
INFO - 2017-03-14 22:37:10 --> Config Class Initialized
INFO - 2017-03-14 22:37:10 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:37:10 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:37:10 --> Utf8 Class Initialized
INFO - 2017-03-14 22:37:10 --> URI Class Initialized
INFO - 2017-03-14 22:37:10 --> Router Class Initialized
INFO - 2017-03-14 22:37:10 --> Output Class Initialized
INFO - 2017-03-14 22:37:10 --> Security Class Initialized
DEBUG - 2017-03-14 22:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:37:10 --> Input Class Initialized
INFO - 2017-03-14 22:37:10 --> Language Class Initialized
INFO - 2017-03-14 22:37:11 --> Loader Class Initialized
INFO - 2017-03-14 22:37:11 --> Database Driver Class Initialized
INFO - 2017-03-14 22:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:37:11 --> Controller Class Initialized
INFO - 2017-03-14 22:37:11 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:37:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:37:13 --> Config Class Initialized
INFO - 2017-03-14 22:37:13 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:37:13 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:37:13 --> Utf8 Class Initialized
INFO - 2017-03-14 22:37:13 --> URI Class Initialized
INFO - 2017-03-14 22:37:13 --> Router Class Initialized
INFO - 2017-03-14 22:37:13 --> Output Class Initialized
INFO - 2017-03-14 22:37:13 --> Security Class Initialized
DEBUG - 2017-03-14 22:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:37:13 --> Input Class Initialized
INFO - 2017-03-14 22:37:13 --> Language Class Initialized
INFO - 2017-03-14 22:37:13 --> Loader Class Initialized
INFO - 2017-03-14 22:37:14 --> Database Driver Class Initialized
INFO - 2017-03-14 22:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:37:14 --> Controller Class Initialized
INFO - 2017-03-14 22:37:14 --> Helper loaded: date_helper
DEBUG - 2017-03-14 22:37:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:37:14 --> Helper loaded: url_helper
INFO - 2017-03-14 22:37:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 22:37:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 22:37:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 22:37:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 22:37:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 22:37:14 --> Final output sent to browser
DEBUG - 2017-03-14 22:37:14 --> Total execution time: 0.8598
INFO - 2017-03-14 22:50:51 --> Config Class Initialized
INFO - 2017-03-14 22:50:51 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:50:51 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:50:51 --> Utf8 Class Initialized
INFO - 2017-03-14 22:50:51 --> URI Class Initialized
DEBUG - 2017-03-14 22:50:51 --> No URI present. Default controller set.
INFO - 2017-03-14 22:50:51 --> Router Class Initialized
INFO - 2017-03-14 22:50:51 --> Output Class Initialized
INFO - 2017-03-14 22:50:51 --> Security Class Initialized
DEBUG - 2017-03-14 22:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:50:51 --> Input Class Initialized
INFO - 2017-03-14 22:50:51 --> Language Class Initialized
INFO - 2017-03-14 22:50:51 --> Loader Class Initialized
INFO - 2017-03-14 22:50:51 --> Database Driver Class Initialized
INFO - 2017-03-14 22:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:50:52 --> Controller Class Initialized
INFO - 2017-03-14 22:50:52 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:50:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 22:50:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 22:50:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 22:50:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 22:50:52 --> Final output sent to browser
DEBUG - 2017-03-14 22:50:52 --> Total execution time: 1.7293
INFO - 2017-03-14 22:50:58 --> Config Class Initialized
INFO - 2017-03-14 22:50:58 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:50:58 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:50:58 --> Utf8 Class Initialized
INFO - 2017-03-14 22:50:58 --> URI Class Initialized
INFO - 2017-03-14 22:50:58 --> Router Class Initialized
INFO - 2017-03-14 22:50:58 --> Output Class Initialized
INFO - 2017-03-14 22:50:58 --> Security Class Initialized
DEBUG - 2017-03-14 22:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:50:58 --> Input Class Initialized
INFO - 2017-03-14 22:50:58 --> Language Class Initialized
INFO - 2017-03-14 22:50:58 --> Loader Class Initialized
INFO - 2017-03-14 22:50:59 --> Database Driver Class Initialized
INFO - 2017-03-14 22:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:50:59 --> Controller Class Initialized
INFO - 2017-03-14 22:50:59 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:50:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:50:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 22:50:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 22:50:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 22:50:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 22:50:59 --> Final output sent to browser
DEBUG - 2017-03-14 22:50:59 --> Total execution time: 1.2221
INFO - 2017-03-14 22:51:06 --> Config Class Initialized
INFO - 2017-03-14 22:51:06 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:51:07 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:51:07 --> Utf8 Class Initialized
INFO - 2017-03-14 22:51:07 --> URI Class Initialized
INFO - 2017-03-14 22:51:07 --> Router Class Initialized
INFO - 2017-03-14 22:51:07 --> Output Class Initialized
INFO - 2017-03-14 22:51:07 --> Security Class Initialized
DEBUG - 2017-03-14 22:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:51:07 --> Input Class Initialized
INFO - 2017-03-14 22:51:07 --> Language Class Initialized
INFO - 2017-03-14 22:51:07 --> Loader Class Initialized
INFO - 2017-03-14 22:51:07 --> Database Driver Class Initialized
INFO - 2017-03-14 22:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:51:08 --> Controller Class Initialized
INFO - 2017-03-14 22:51:08 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:51:18 --> Config Class Initialized
INFO - 2017-03-14 22:51:18 --> Config Class Initialized
INFO - 2017-03-14 22:51:18 --> Hooks Class Initialized
INFO - 2017-03-14 22:51:18 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:51:18 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:51:18 --> Utf8 Class Initialized
DEBUG - 2017-03-14 22:51:18 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:51:18 --> URI Class Initialized
INFO - 2017-03-14 22:51:18 --> Utf8 Class Initialized
INFO - 2017-03-14 22:51:18 --> URI Class Initialized
INFO - 2017-03-14 22:51:18 --> Router Class Initialized
INFO - 2017-03-14 22:51:19 --> Router Class Initialized
INFO - 2017-03-14 22:51:19 --> Output Class Initialized
INFO - 2017-03-14 22:51:19 --> Output Class Initialized
INFO - 2017-03-14 22:51:19 --> Security Class Initialized
INFO - 2017-03-14 22:51:19 --> Security Class Initialized
DEBUG - 2017-03-14 22:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:51:19 --> Input Class Initialized
INFO - 2017-03-14 22:51:19 --> Language Class Initialized
DEBUG - 2017-03-14 22:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:51:19 --> Input Class Initialized
INFO - 2017-03-14 22:51:19 --> Language Class Initialized
INFO - 2017-03-14 22:51:19 --> Loader Class Initialized
INFO - 2017-03-14 22:51:19 --> Loader Class Initialized
INFO - 2017-03-14 22:51:19 --> Database Driver Class Initialized
INFO - 2017-03-14 22:51:19 --> Database Driver Class Initialized
INFO - 2017-03-14 22:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:51:19 --> Controller Class Initialized
INFO - 2017-03-14 22:51:19 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:51:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:51:20 --> Controller Class Initialized
INFO - 2017-03-14 22:51:20 --> Helper loaded: date_helper
DEBUG - 2017-03-14 22:51:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:51:20 --> Helper loaded: url_helper
INFO - 2017-03-14 22:51:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 22:51:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 22:51:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 22:51:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 22:51:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 22:51:20 --> Final output sent to browser
DEBUG - 2017-03-14 22:51:20 --> Total execution time: 2.0211
INFO - 2017-03-14 22:51:20 --> Config Class Initialized
INFO - 2017-03-14 22:51:20 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:51:20 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:51:20 --> Utf8 Class Initialized
INFO - 2017-03-14 22:51:20 --> URI Class Initialized
INFO - 2017-03-14 22:51:20 --> Router Class Initialized
INFO - 2017-03-14 22:51:20 --> Output Class Initialized
INFO - 2017-03-14 22:51:20 --> Security Class Initialized
DEBUG - 2017-03-14 22:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:51:20 --> Input Class Initialized
INFO - 2017-03-14 22:51:20 --> Language Class Initialized
INFO - 2017-03-14 22:51:20 --> Loader Class Initialized
INFO - 2017-03-14 22:51:20 --> Database Driver Class Initialized
INFO - 2017-03-14 22:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:51:20 --> Controller Class Initialized
INFO - 2017-03-14 22:51:20 --> Helper loaded: date_helper
DEBUG - 2017-03-14 22:51:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:51:20 --> Helper loaded: url_helper
INFO - 2017-03-14 22:51:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 22:51:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 22:51:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 22:51:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 22:51:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 22:51:20 --> Final output sent to browser
DEBUG - 2017-03-14 22:51:20 --> Total execution time: 0.0156
INFO - 2017-03-14 22:51:21 --> Config Class Initialized
INFO - 2017-03-14 22:51:21 --> Hooks Class Initialized
DEBUG - 2017-03-14 22:51:21 --> UTF-8 Support Enabled
INFO - 2017-03-14 22:51:21 --> Utf8 Class Initialized
INFO - 2017-03-14 22:51:21 --> URI Class Initialized
INFO - 2017-03-14 22:51:21 --> Router Class Initialized
INFO - 2017-03-14 22:51:21 --> Output Class Initialized
INFO - 2017-03-14 22:51:21 --> Security Class Initialized
DEBUG - 2017-03-14 22:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 22:51:21 --> Input Class Initialized
INFO - 2017-03-14 22:51:21 --> Language Class Initialized
INFO - 2017-03-14 22:51:21 --> Loader Class Initialized
INFO - 2017-03-14 22:51:21 --> Database Driver Class Initialized
INFO - 2017-03-14 22:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 22:51:21 --> Controller Class Initialized
INFO - 2017-03-14 22:51:21 --> Helper loaded: url_helper
DEBUG - 2017-03-14 22:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 22:51:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 22:51:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 22:51:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 22:51:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 22:51:21 --> Final output sent to browser
DEBUG - 2017-03-14 22:51:21 --> Total execution time: 0.3124
INFO - 2017-03-14 23:00:19 --> Config Class Initialized
INFO - 2017-03-14 23:00:19 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:00:19 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:00:19 --> Utf8 Class Initialized
INFO - 2017-03-14 23:00:19 --> URI Class Initialized
DEBUG - 2017-03-14 23:00:19 --> No URI present. Default controller set.
INFO - 2017-03-14 23:00:19 --> Router Class Initialized
INFO - 2017-03-14 23:00:19 --> Output Class Initialized
INFO - 2017-03-14 23:00:19 --> Security Class Initialized
DEBUG - 2017-03-14 23:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:00:19 --> Input Class Initialized
INFO - 2017-03-14 23:00:19 --> Language Class Initialized
INFO - 2017-03-14 23:00:19 --> Loader Class Initialized
INFO - 2017-03-14 23:00:20 --> Database Driver Class Initialized
INFO - 2017-03-14 23:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:00:20 --> Controller Class Initialized
INFO - 2017-03-14 23:00:20 --> Helper loaded: url_helper
DEBUG - 2017-03-14 23:00:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:00:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 23:00:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 23:00:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 23:00:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 23:00:20 --> Final output sent to browser
DEBUG - 2017-03-14 23:00:20 --> Total execution time: 1.4711
INFO - 2017-03-14 23:00:28 --> Config Class Initialized
INFO - 2017-03-14 23:00:28 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:00:28 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:00:28 --> Utf8 Class Initialized
INFO - 2017-03-14 23:00:28 --> URI Class Initialized
INFO - 2017-03-14 23:00:28 --> Router Class Initialized
INFO - 2017-03-14 23:00:28 --> Output Class Initialized
INFO - 2017-03-14 23:00:28 --> Security Class Initialized
DEBUG - 2017-03-14 23:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:00:28 --> Input Class Initialized
INFO - 2017-03-14 23:00:28 --> Language Class Initialized
INFO - 2017-03-14 23:00:28 --> Loader Class Initialized
INFO - 2017-03-14 23:00:28 --> Database Driver Class Initialized
INFO - 2017-03-14 23:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:00:28 --> Controller Class Initialized
INFO - 2017-03-14 23:00:28 --> Helper loaded: url_helper
DEBUG - 2017-03-14 23:00:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:00:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 23:00:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 23:00:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 23:00:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 23:00:28 --> Final output sent to browser
DEBUG - 2017-03-14 23:00:28 --> Total execution time: 0.0190
INFO - 2017-03-14 23:07:31 --> Config Class Initialized
INFO - 2017-03-14 23:07:31 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:07:31 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:07:31 --> Utf8 Class Initialized
INFO - 2017-03-14 23:07:31 --> URI Class Initialized
INFO - 2017-03-14 23:07:31 --> Router Class Initialized
INFO - 2017-03-14 23:07:31 --> Output Class Initialized
INFO - 2017-03-14 23:07:31 --> Security Class Initialized
DEBUG - 2017-03-14 23:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:07:31 --> Input Class Initialized
INFO - 2017-03-14 23:07:31 --> Language Class Initialized
INFO - 2017-03-14 23:07:31 --> Loader Class Initialized
INFO - 2017-03-14 23:07:31 --> Database Driver Class Initialized
INFO - 2017-03-14 23:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:07:32 --> Controller Class Initialized
INFO - 2017-03-14 23:07:32 --> Helper loaded: url_helper
DEBUG - 2017-03-14 23:07:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:07:33 --> Config Class Initialized
INFO - 2017-03-14 23:07:33 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:07:33 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:07:33 --> Utf8 Class Initialized
INFO - 2017-03-14 23:07:33 --> URI Class Initialized
INFO - 2017-03-14 23:07:33 --> Router Class Initialized
INFO - 2017-03-14 23:07:33 --> Output Class Initialized
INFO - 2017-03-14 23:07:33 --> Security Class Initialized
DEBUG - 2017-03-14 23:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:07:33 --> Input Class Initialized
INFO - 2017-03-14 23:07:33 --> Language Class Initialized
INFO - 2017-03-14 23:07:33 --> Loader Class Initialized
INFO - 2017-03-14 23:07:33 --> Config Class Initialized
INFO - 2017-03-14 23:07:33 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:07:33 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:07:33 --> Utf8 Class Initialized
INFO - 2017-03-14 23:07:33 --> URI Class Initialized
INFO - 2017-03-14 23:07:33 --> Router Class Initialized
INFO - 2017-03-14 23:07:33 --> Output Class Initialized
INFO - 2017-03-14 23:07:33 --> Database Driver Class Initialized
INFO - 2017-03-14 23:07:33 --> Security Class Initialized
DEBUG - 2017-03-14 23:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:07:33 --> Input Class Initialized
INFO - 2017-03-14 23:07:33 --> Language Class Initialized
INFO - 2017-03-14 23:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:07:33 --> Controller Class Initialized
INFO - 2017-03-14 23:07:33 --> Helper loaded: url_helper
DEBUG - 2017-03-14 23:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:07:33 --> Helper loaded: form_helper
INFO - 2017-03-14 23:07:33 --> Loader Class Initialized
INFO - 2017-03-14 23:07:33 --> Form Validation Class Initialized
INFO - 2017-03-14 23:07:33 --> Database Driver Class Initialized
INFO - 2017-03-14 23:07:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-14 23:07:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-03-14 23:07:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-14 23:07:33 --> Final output sent to browser
DEBUG - 2017-03-14 23:07:33 --> Total execution time: 0.1659
INFO - 2017-03-14 23:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:07:33 --> Controller Class Initialized
INFO - 2017-03-14 23:07:33 --> Helper loaded: url_helper
DEBUG - 2017-03-14 23:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:07:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 23:07:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 23:07:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 23:07:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 23:07:33 --> Final output sent to browser
DEBUG - 2017-03-14 23:07:33 --> Total execution time: 0.4296
INFO - 2017-03-14 23:07:34 --> Config Class Initialized
INFO - 2017-03-14 23:07:34 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:07:34 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:07:34 --> Utf8 Class Initialized
INFO - 2017-03-14 23:07:34 --> URI Class Initialized
INFO - 2017-03-14 23:07:34 --> Router Class Initialized
INFO - 2017-03-14 23:07:34 --> Output Class Initialized
INFO - 2017-03-14 23:07:34 --> Security Class Initialized
DEBUG - 2017-03-14 23:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:07:34 --> Input Class Initialized
INFO - 2017-03-14 23:07:34 --> Language Class Initialized
INFO - 2017-03-14 23:07:34 --> Loader Class Initialized
INFO - 2017-03-14 23:07:34 --> Database Driver Class Initialized
INFO - 2017-03-14 23:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:07:34 --> Controller Class Initialized
INFO - 2017-03-14 23:07:34 --> Helper loaded: url_helper
DEBUG - 2017-03-14 23:07:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:07:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 23:07:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 23:07:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 23:07:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 23:07:34 --> Final output sent to browser
DEBUG - 2017-03-14 23:07:34 --> Total execution time: 0.2517
INFO - 2017-03-14 23:08:57 --> Config Class Initialized
INFO - 2017-03-14 23:08:57 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:08:57 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:08:57 --> Utf8 Class Initialized
INFO - 2017-03-14 23:08:57 --> URI Class Initialized
DEBUG - 2017-03-14 23:08:57 --> No URI present. Default controller set.
INFO - 2017-03-14 23:08:57 --> Router Class Initialized
INFO - 2017-03-14 23:08:57 --> Output Class Initialized
INFO - 2017-03-14 23:08:57 --> Security Class Initialized
DEBUG - 2017-03-14 23:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:08:57 --> Input Class Initialized
INFO - 2017-03-14 23:08:57 --> Language Class Initialized
INFO - 2017-03-14 23:08:57 --> Loader Class Initialized
INFO - 2017-03-14 23:08:58 --> Database Driver Class Initialized
INFO - 2017-03-14 23:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:08:58 --> Controller Class Initialized
INFO - 2017-03-14 23:08:58 --> Helper loaded: url_helper
DEBUG - 2017-03-14 23:08:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:08:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 23:08:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 23:08:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 23:08:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 23:08:59 --> Final output sent to browser
DEBUG - 2017-03-14 23:08:59 --> Total execution time: 1.6119
INFO - 2017-03-14 23:26:37 --> Config Class Initialized
INFO - 2017-03-14 23:26:37 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:26:37 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:26:37 --> Utf8 Class Initialized
INFO - 2017-03-14 23:26:37 --> URI Class Initialized
INFO - 2017-03-14 23:26:38 --> Router Class Initialized
INFO - 2017-03-14 23:26:38 --> Output Class Initialized
INFO - 2017-03-14 23:26:38 --> Security Class Initialized
DEBUG - 2017-03-14 23:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:26:38 --> Input Class Initialized
INFO - 2017-03-14 23:26:38 --> Language Class Initialized
INFO - 2017-03-14 23:26:38 --> Loader Class Initialized
INFO - 2017-03-14 23:26:38 --> Database Driver Class Initialized
INFO - 2017-03-14 23:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:26:38 --> Controller Class Initialized
INFO - 2017-03-14 23:26:38 --> Helper loaded: date_helper
DEBUG - 2017-03-14 23:26:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:26:39 --> Helper loaded: url_helper
INFO - 2017-03-14 23:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 23:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 23:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 23:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 23:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 23:26:39 --> Final output sent to browser
DEBUG - 2017-03-14 23:26:39 --> Total execution time: 1.3331
INFO - 2017-03-14 23:26:43 --> Config Class Initialized
INFO - 2017-03-14 23:26:43 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:26:43 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:26:43 --> Utf8 Class Initialized
INFO - 2017-03-14 23:26:43 --> URI Class Initialized
INFO - 2017-03-14 23:26:43 --> Router Class Initialized
INFO - 2017-03-14 23:26:43 --> Output Class Initialized
INFO - 2017-03-14 23:26:43 --> Security Class Initialized
DEBUG - 2017-03-14 23:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:26:43 --> Input Class Initialized
INFO - 2017-03-14 23:26:43 --> Language Class Initialized
INFO - 2017-03-14 23:26:43 --> Loader Class Initialized
INFO - 2017-03-14 23:26:43 --> Database Driver Class Initialized
INFO - 2017-03-14 23:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:26:43 --> Controller Class Initialized
INFO - 2017-03-14 23:26:43 --> Helper loaded: url_helper
DEBUG - 2017-03-14 23:26:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:26:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 23:26:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 23:26:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 23:26:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 23:26:43 --> Final output sent to browser
DEBUG - 2017-03-14 23:26:43 --> Total execution time: 0.2612
INFO - 2017-03-14 23:38:11 --> Config Class Initialized
INFO - 2017-03-14 23:38:11 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:38:12 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:38:12 --> Utf8 Class Initialized
INFO - 2017-03-14 23:38:12 --> URI Class Initialized
INFO - 2017-03-14 23:38:12 --> Router Class Initialized
INFO - 2017-03-14 23:38:12 --> Output Class Initialized
INFO - 2017-03-14 23:38:12 --> Security Class Initialized
DEBUG - 2017-03-14 23:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:38:12 --> Input Class Initialized
INFO - 2017-03-14 23:38:12 --> Language Class Initialized
INFO - 2017-03-14 23:38:12 --> Loader Class Initialized
INFO - 2017-03-14 23:38:12 --> Database Driver Class Initialized
INFO - 2017-03-14 23:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:38:13 --> Controller Class Initialized
INFO - 2017-03-14 23:38:13 --> Helper loaded: date_helper
DEBUG - 2017-03-14 23:38:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:38:13 --> Helper loaded: url_helper
INFO - 2017-03-14 23:38:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 23:38:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 23:38:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 23:38:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 23:38:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 23:38:13 --> Final output sent to browser
DEBUG - 2017-03-14 23:38:13 --> Total execution time: 1.3594
INFO - 2017-03-14 23:38:14 --> Config Class Initialized
INFO - 2017-03-14 23:38:14 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:38:14 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:38:14 --> Utf8 Class Initialized
INFO - 2017-03-14 23:38:14 --> URI Class Initialized
INFO - 2017-03-14 23:38:14 --> Router Class Initialized
INFO - 2017-03-14 23:38:14 --> Output Class Initialized
INFO - 2017-03-14 23:38:14 --> Security Class Initialized
DEBUG - 2017-03-14 23:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:38:14 --> Input Class Initialized
INFO - 2017-03-14 23:38:14 --> Language Class Initialized
INFO - 2017-03-14 23:38:14 --> Loader Class Initialized
INFO - 2017-03-14 23:38:14 --> Database Driver Class Initialized
INFO - 2017-03-14 23:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:38:14 --> Controller Class Initialized
INFO - 2017-03-14 23:38:14 --> Helper loaded: url_helper
DEBUG - 2017-03-14 23:38:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:38:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 23:38:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 23:38:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 23:38:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 23:38:14 --> Final output sent to browser
DEBUG - 2017-03-14 23:38:14 --> Total execution time: 0.2593
INFO - 2017-03-14 23:38:32 --> Config Class Initialized
INFO - 2017-03-14 23:38:32 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:38:32 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:38:32 --> Utf8 Class Initialized
INFO - 2017-03-14 23:38:32 --> URI Class Initialized
INFO - 2017-03-14 23:38:32 --> Router Class Initialized
INFO - 2017-03-14 23:38:33 --> Output Class Initialized
INFO - 2017-03-14 23:38:33 --> Security Class Initialized
DEBUG - 2017-03-14 23:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:38:33 --> Input Class Initialized
INFO - 2017-03-14 23:38:33 --> Language Class Initialized
INFO - 2017-03-14 23:38:33 --> Loader Class Initialized
INFO - 2017-03-14 23:38:33 --> Database Driver Class Initialized
INFO - 2017-03-14 23:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:38:33 --> Controller Class Initialized
INFO - 2017-03-14 23:38:33 --> Helper loaded: date_helper
DEBUG - 2017-03-14 23:38:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:38:33 --> Helper loaded: url_helper
INFO - 2017-03-14 23:38:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 23:38:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 23:38:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 23:38:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 23:38:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 23:38:34 --> Final output sent to browser
DEBUG - 2017-03-14 23:38:34 --> Total execution time: 1.3511
INFO - 2017-03-14 23:38:36 --> Config Class Initialized
INFO - 2017-03-14 23:38:36 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:38:36 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:38:36 --> Utf8 Class Initialized
INFO - 2017-03-14 23:38:36 --> URI Class Initialized
INFO - 2017-03-14 23:38:36 --> Router Class Initialized
INFO - 2017-03-14 23:38:36 --> Output Class Initialized
INFO - 2017-03-14 23:38:36 --> Security Class Initialized
DEBUG - 2017-03-14 23:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:38:36 --> Input Class Initialized
INFO - 2017-03-14 23:38:36 --> Language Class Initialized
INFO - 2017-03-14 23:38:36 --> Loader Class Initialized
INFO - 2017-03-14 23:38:36 --> Database Driver Class Initialized
INFO - 2017-03-14 23:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:38:36 --> Controller Class Initialized
INFO - 2017-03-14 23:38:36 --> Helper loaded: url_helper
DEBUG - 2017-03-14 23:38:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:38:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 23:38:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 23:38:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 23:38:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 23:38:36 --> Final output sent to browser
DEBUG - 2017-03-14 23:38:36 --> Total execution time: 0.2407
INFO - 2017-03-14 23:46:40 --> Config Class Initialized
INFO - 2017-03-14 23:46:40 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:46:40 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:46:40 --> Utf8 Class Initialized
INFO - 2017-03-14 23:46:40 --> URI Class Initialized
DEBUG - 2017-03-14 23:46:40 --> No URI present. Default controller set.
INFO - 2017-03-14 23:46:40 --> Router Class Initialized
INFO - 2017-03-14 23:46:40 --> Output Class Initialized
INFO - 2017-03-14 23:46:40 --> Security Class Initialized
DEBUG - 2017-03-14 23:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:46:41 --> Input Class Initialized
INFO - 2017-03-14 23:46:41 --> Language Class Initialized
INFO - 2017-03-14 23:46:41 --> Loader Class Initialized
INFO - 2017-03-14 23:46:41 --> Database Driver Class Initialized
INFO - 2017-03-14 23:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:46:41 --> Controller Class Initialized
INFO - 2017-03-14 23:46:41 --> Helper loaded: url_helper
DEBUG - 2017-03-14 23:46:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:46:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 23:46:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 23:46:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 23:46:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 23:46:41 --> Final output sent to browser
DEBUG - 2017-03-14 23:46:41 --> Total execution time: 1.2238
INFO - 2017-03-14 23:46:44 --> Config Class Initialized
INFO - 2017-03-14 23:46:44 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:46:44 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:46:44 --> Utf8 Class Initialized
INFO - 2017-03-14 23:46:44 --> URI Class Initialized
INFO - 2017-03-14 23:46:44 --> Router Class Initialized
INFO - 2017-03-14 23:46:44 --> Output Class Initialized
INFO - 2017-03-14 23:46:44 --> Security Class Initialized
DEBUG - 2017-03-14 23:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:46:44 --> Input Class Initialized
INFO - 2017-03-14 23:46:44 --> Language Class Initialized
INFO - 2017-03-14 23:46:44 --> Loader Class Initialized
INFO - 2017-03-14 23:46:45 --> Database Driver Class Initialized
INFO - 2017-03-14 23:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:46:45 --> Controller Class Initialized
INFO - 2017-03-14 23:46:45 --> Helper loaded: url_helper
DEBUG - 2017-03-14 23:46:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:46:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 23:46:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 23:46:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 23:46:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 23:46:45 --> Final output sent to browser
DEBUG - 2017-03-14 23:46:45 --> Total execution time: 0.0139
INFO - 2017-03-14 23:47:05 --> Config Class Initialized
INFO - 2017-03-14 23:47:05 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:47:05 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:47:05 --> Utf8 Class Initialized
INFO - 2017-03-14 23:47:05 --> URI Class Initialized
INFO - 2017-03-14 23:47:05 --> Router Class Initialized
INFO - 2017-03-14 23:47:05 --> Output Class Initialized
INFO - 2017-03-14 23:47:05 --> Security Class Initialized
DEBUG - 2017-03-14 23:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:47:05 --> Input Class Initialized
INFO - 2017-03-14 23:47:05 --> Language Class Initialized
INFO - 2017-03-14 23:47:05 --> Loader Class Initialized
INFO - 2017-03-14 23:47:05 --> Database Driver Class Initialized
INFO - 2017-03-14 23:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:47:05 --> Controller Class Initialized
INFO - 2017-03-14 23:47:05 --> Helper loaded: url_helper
DEBUG - 2017-03-14 23:47:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:47:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-14 23:47:05 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-14 23:47:05 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-14 23:47:05 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-14 23:47:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 23:47:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 23:47:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 23:47:05 --> Final output sent to browser
DEBUG - 2017-03-14 23:47:05 --> Total execution time: 0.3164
INFO - 2017-03-14 23:47:06 --> Config Class Initialized
INFO - 2017-03-14 23:47:06 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:47:06 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:47:06 --> Utf8 Class Initialized
INFO - 2017-03-14 23:47:06 --> URI Class Initialized
INFO - 2017-03-14 23:47:06 --> Router Class Initialized
INFO - 2017-03-14 23:47:06 --> Output Class Initialized
INFO - 2017-03-14 23:47:06 --> Security Class Initialized
DEBUG - 2017-03-14 23:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:47:06 --> Input Class Initialized
INFO - 2017-03-14 23:47:06 --> Language Class Initialized
INFO - 2017-03-14 23:47:06 --> Loader Class Initialized
INFO - 2017-03-14 23:47:06 --> Database Driver Class Initialized
INFO - 2017-03-14 23:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:47:06 --> Controller Class Initialized
INFO - 2017-03-14 23:47:06 --> Helper loaded: url_helper
DEBUG - 2017-03-14 23:47:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:47:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 23:47:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 23:47:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 23:47:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 23:47:06 --> Final output sent to browser
DEBUG - 2017-03-14 23:47:06 --> Total execution time: 0.0138
INFO - 2017-03-14 23:47:27 --> Config Class Initialized
INFO - 2017-03-14 23:47:27 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:47:27 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:47:27 --> Utf8 Class Initialized
INFO - 2017-03-14 23:47:27 --> URI Class Initialized
INFO - 2017-03-14 23:47:27 --> Router Class Initialized
INFO - 2017-03-14 23:47:27 --> Output Class Initialized
INFO - 2017-03-14 23:47:27 --> Security Class Initialized
DEBUG - 2017-03-14 23:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:47:27 --> Input Class Initialized
INFO - 2017-03-14 23:47:27 --> Language Class Initialized
INFO - 2017-03-14 23:47:27 --> Loader Class Initialized
INFO - 2017-03-14 23:47:27 --> Database Driver Class Initialized
INFO - 2017-03-14 23:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:47:27 --> Controller Class Initialized
INFO - 2017-03-14 23:47:27 --> Helper loaded: url_helper
DEBUG - 2017-03-14 23:47:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:47:29 --> Config Class Initialized
INFO - 2017-03-14 23:47:29 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:47:29 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:47:29 --> Utf8 Class Initialized
INFO - 2017-03-14 23:47:29 --> URI Class Initialized
INFO - 2017-03-14 23:47:29 --> Router Class Initialized
INFO - 2017-03-14 23:47:29 --> Output Class Initialized
INFO - 2017-03-14 23:47:29 --> Security Class Initialized
DEBUG - 2017-03-14 23:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:47:29 --> Input Class Initialized
INFO - 2017-03-14 23:47:29 --> Language Class Initialized
INFO - 2017-03-14 23:47:29 --> Loader Class Initialized
INFO - 2017-03-14 23:47:29 --> Database Driver Class Initialized
INFO - 2017-03-14 23:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:47:29 --> Controller Class Initialized
INFO - 2017-03-14 23:47:29 --> Helper loaded: date_helper
DEBUG - 2017-03-14 23:47:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:47:29 --> Helper loaded: url_helper
INFO - 2017-03-14 23:47:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 23:47:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 23:47:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 23:47:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 23:47:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 23:47:29 --> Final output sent to browser
DEBUG - 2017-03-14 23:47:29 --> Total execution time: 0.1008
INFO - 2017-03-14 23:47:30 --> Config Class Initialized
INFO - 2017-03-14 23:47:30 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:47:30 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:47:30 --> Utf8 Class Initialized
INFO - 2017-03-14 23:47:30 --> URI Class Initialized
INFO - 2017-03-14 23:47:30 --> Router Class Initialized
INFO - 2017-03-14 23:47:30 --> Output Class Initialized
INFO - 2017-03-14 23:47:30 --> Security Class Initialized
DEBUG - 2017-03-14 23:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:47:30 --> Input Class Initialized
INFO - 2017-03-14 23:47:30 --> Language Class Initialized
INFO - 2017-03-14 23:47:30 --> Loader Class Initialized
INFO - 2017-03-14 23:47:30 --> Database Driver Class Initialized
INFO - 2017-03-14 23:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:47:30 --> Controller Class Initialized
INFO - 2017-03-14 23:47:30 --> Helper loaded: url_helper
DEBUG - 2017-03-14 23:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:47:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 23:47:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 23:47:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 23:47:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 23:47:30 --> Final output sent to browser
DEBUG - 2017-03-14 23:47:30 --> Total execution time: 0.0143
INFO - 2017-03-14 23:47:35 --> Config Class Initialized
INFO - 2017-03-14 23:47:35 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:47:35 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:47:35 --> Utf8 Class Initialized
INFO - 2017-03-14 23:47:35 --> URI Class Initialized
DEBUG - 2017-03-14 23:47:35 --> No URI present. Default controller set.
INFO - 2017-03-14 23:47:35 --> Router Class Initialized
INFO - 2017-03-14 23:47:35 --> Output Class Initialized
INFO - 2017-03-14 23:47:35 --> Security Class Initialized
DEBUG - 2017-03-14 23:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:47:35 --> Input Class Initialized
INFO - 2017-03-14 23:47:35 --> Language Class Initialized
INFO - 2017-03-14 23:47:35 --> Loader Class Initialized
INFO - 2017-03-14 23:47:35 --> Database Driver Class Initialized
INFO - 2017-03-14 23:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:47:35 --> Controller Class Initialized
INFO - 2017-03-14 23:47:35 --> Helper loaded: url_helper
DEBUG - 2017-03-14 23:47:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:47:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 23:47:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 23:47:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 23:47:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 23:47:35 --> Final output sent to browser
DEBUG - 2017-03-14 23:47:35 --> Total execution time: 0.0585
INFO - 2017-03-14 23:47:36 --> Config Class Initialized
INFO - 2017-03-14 23:47:36 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:47:36 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:47:36 --> Utf8 Class Initialized
INFO - 2017-03-14 23:47:36 --> URI Class Initialized
INFO - 2017-03-14 23:47:36 --> Router Class Initialized
INFO - 2017-03-14 23:47:36 --> Output Class Initialized
INFO - 2017-03-14 23:47:36 --> Security Class Initialized
DEBUG - 2017-03-14 23:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:47:36 --> Input Class Initialized
INFO - 2017-03-14 23:47:36 --> Language Class Initialized
INFO - 2017-03-14 23:47:36 --> Loader Class Initialized
INFO - 2017-03-14 23:47:36 --> Database Driver Class Initialized
INFO - 2017-03-14 23:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:47:36 --> Controller Class Initialized
INFO - 2017-03-14 23:47:36 --> Helper loaded: url_helper
DEBUG - 2017-03-14 23:47:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:47:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 23:47:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 23:47:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 23:47:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 23:47:36 --> Final output sent to browser
DEBUG - 2017-03-14 23:47:36 --> Total execution time: 0.0138
INFO - 2017-03-14 23:48:23 --> Config Class Initialized
INFO - 2017-03-14 23:48:23 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:48:24 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:48:24 --> Utf8 Class Initialized
INFO - 2017-03-14 23:48:24 --> URI Class Initialized
INFO - 2017-03-14 23:48:24 --> Router Class Initialized
INFO - 2017-03-14 23:48:24 --> Output Class Initialized
INFO - 2017-03-14 23:48:24 --> Security Class Initialized
DEBUG - 2017-03-14 23:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:48:24 --> Input Class Initialized
INFO - 2017-03-14 23:48:24 --> Language Class Initialized
INFO - 2017-03-14 23:48:24 --> Loader Class Initialized
INFO - 2017-03-14 23:48:24 --> Database Driver Class Initialized
INFO - 2017-03-14 23:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:48:24 --> Controller Class Initialized
INFO - 2017-03-14 23:48:24 --> Helper loaded: url_helper
DEBUG - 2017-03-14 23:48:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:48:26 --> Config Class Initialized
INFO - 2017-03-14 23:48:26 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:48:26 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:48:26 --> Utf8 Class Initialized
INFO - 2017-03-14 23:48:26 --> URI Class Initialized
INFO - 2017-03-14 23:48:26 --> Router Class Initialized
INFO - 2017-03-14 23:48:26 --> Output Class Initialized
INFO - 2017-03-14 23:48:26 --> Security Class Initialized
DEBUG - 2017-03-14 23:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:48:26 --> Input Class Initialized
INFO - 2017-03-14 23:48:26 --> Language Class Initialized
INFO - 2017-03-14 23:48:26 --> Loader Class Initialized
INFO - 2017-03-14 23:48:26 --> Database Driver Class Initialized
INFO - 2017-03-14 23:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:48:26 --> Controller Class Initialized
INFO - 2017-03-14 23:48:26 --> Helper loaded: date_helper
DEBUG - 2017-03-14 23:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:48:26 --> Helper loaded: url_helper
INFO - 2017-03-14 23:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 23:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-14 23:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-14 23:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-14 23:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 23:48:26 --> Final output sent to browser
DEBUG - 2017-03-14 23:48:26 --> Total execution time: 0.1210
INFO - 2017-03-14 23:48:27 --> Config Class Initialized
INFO - 2017-03-14 23:48:27 --> Hooks Class Initialized
DEBUG - 2017-03-14 23:48:27 --> UTF-8 Support Enabled
INFO - 2017-03-14 23:48:27 --> Utf8 Class Initialized
INFO - 2017-03-14 23:48:27 --> URI Class Initialized
INFO - 2017-03-14 23:48:27 --> Router Class Initialized
INFO - 2017-03-14 23:48:27 --> Output Class Initialized
INFO - 2017-03-14 23:48:27 --> Security Class Initialized
DEBUG - 2017-03-14 23:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-14 23:48:27 --> Input Class Initialized
INFO - 2017-03-14 23:48:27 --> Language Class Initialized
INFO - 2017-03-14 23:48:27 --> Loader Class Initialized
INFO - 2017-03-14 23:48:27 --> Database Driver Class Initialized
INFO - 2017-03-14 23:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-14 23:48:27 --> Controller Class Initialized
INFO - 2017-03-14 23:48:27 --> Helper loaded: url_helper
DEBUG - 2017-03-14 23:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-14 23:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-14 23:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-14 23:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-14 23:48:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-14 23:48:27 --> Final output sent to browser
DEBUG - 2017-03-14 23:48:27 --> Total execution time: 0.0490

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-15 00:07:47 --> Config Class Initialized
INFO - 2017-03-15 00:07:47 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:07:47 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:07:47 --> Utf8 Class Initialized
INFO - 2017-03-15 00:07:47 --> URI Class Initialized
DEBUG - 2017-03-15 00:07:47 --> No URI present. Default controller set.
INFO - 2017-03-15 00:07:47 --> Router Class Initialized
INFO - 2017-03-15 00:07:47 --> Output Class Initialized
INFO - 2017-03-15 00:07:47 --> Security Class Initialized
DEBUG - 2017-03-15 00:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:07:47 --> Input Class Initialized
INFO - 2017-03-15 00:07:47 --> Language Class Initialized
INFO - 2017-03-15 00:07:47 --> Loader Class Initialized
INFO - 2017-03-15 00:07:48 --> Database Driver Class Initialized
INFO - 2017-03-15 00:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:07:48 --> Controller Class Initialized
INFO - 2017-03-15 00:07:48 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:07:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:07:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:07:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:07:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:07:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:07:48 --> Final output sent to browser
DEBUG - 2017-03-15 00:07:48 --> Total execution time: 1.7926
INFO - 2017-03-15 00:07:58 --> Config Class Initialized
INFO - 2017-03-15 00:07:58 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:07:58 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:07:58 --> Utf8 Class Initialized
INFO - 2017-03-15 00:07:58 --> URI Class Initialized
INFO - 2017-03-15 00:07:58 --> Router Class Initialized
INFO - 2017-03-15 00:07:58 --> Output Class Initialized
INFO - 2017-03-15 00:07:58 --> Security Class Initialized
DEBUG - 2017-03-15 00:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:07:58 --> Input Class Initialized
INFO - 2017-03-15 00:07:58 --> Language Class Initialized
INFO - 2017-03-15 00:07:58 --> Loader Class Initialized
INFO - 2017-03-15 00:07:58 --> Database Driver Class Initialized
INFO - 2017-03-15 00:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:07:58 --> Controller Class Initialized
INFO - 2017-03-15 00:07:58 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:07:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:07:59 --> Config Class Initialized
INFO - 2017-03-15 00:07:59 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:07:59 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:07:59 --> Utf8 Class Initialized
INFO - 2017-03-15 00:07:59 --> URI Class Initialized
INFO - 2017-03-15 00:07:59 --> Router Class Initialized
INFO - 2017-03-15 00:07:59 --> Output Class Initialized
INFO - 2017-03-15 00:07:59 --> Security Class Initialized
DEBUG - 2017-03-15 00:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:07:59 --> Input Class Initialized
INFO - 2017-03-15 00:07:59 --> Language Class Initialized
INFO - 2017-03-15 00:07:59 --> Loader Class Initialized
INFO - 2017-03-15 00:07:59 --> Database Driver Class Initialized
INFO - 2017-03-15 00:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:07:59 --> Controller Class Initialized
INFO - 2017-03-15 00:07:59 --> Helper loaded: date_helper
DEBUG - 2017-03-15 00:07:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:07:59 --> Helper loaded: url_helper
INFO - 2017-03-15 00:07:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:07:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 00:07:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 00:07:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 00:07:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:07:59 --> Final output sent to browser
DEBUG - 2017-03-15 00:07:59 --> Total execution time: 0.0808
INFO - 2017-03-15 00:08:08 --> Config Class Initialized
INFO - 2017-03-15 00:08:08 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:08:08 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:08:08 --> Utf8 Class Initialized
INFO - 2017-03-15 00:08:08 --> URI Class Initialized
DEBUG - 2017-03-15 00:08:08 --> No URI present. Default controller set.
INFO - 2017-03-15 00:08:08 --> Router Class Initialized
INFO - 2017-03-15 00:08:08 --> Output Class Initialized
INFO - 2017-03-15 00:08:08 --> Security Class Initialized
DEBUG - 2017-03-15 00:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:08:08 --> Input Class Initialized
INFO - 2017-03-15 00:08:08 --> Language Class Initialized
INFO - 2017-03-15 00:08:08 --> Loader Class Initialized
INFO - 2017-03-15 00:08:08 --> Database Driver Class Initialized
INFO - 2017-03-15 00:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:08:08 --> Controller Class Initialized
INFO - 2017-03-15 00:08:08 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:08:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:08:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:08:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:08:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:08:08 --> Final output sent to browser
DEBUG - 2017-03-15 00:08:08 --> Total execution time: 0.0139
INFO - 2017-03-15 00:08:17 --> Config Class Initialized
INFO - 2017-03-15 00:08:17 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:08:17 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:08:17 --> Utf8 Class Initialized
INFO - 2017-03-15 00:08:17 --> URI Class Initialized
INFO - 2017-03-15 00:08:17 --> Router Class Initialized
INFO - 2017-03-15 00:08:17 --> Output Class Initialized
INFO - 2017-03-15 00:08:17 --> Security Class Initialized
DEBUG - 2017-03-15 00:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:08:17 --> Input Class Initialized
INFO - 2017-03-15 00:08:17 --> Language Class Initialized
INFO - 2017-03-15 00:08:17 --> Loader Class Initialized
INFO - 2017-03-15 00:08:17 --> Database Driver Class Initialized
INFO - 2017-03-15 00:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:08:17 --> Controller Class Initialized
INFO - 2017-03-15 00:08:17 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:08:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:08:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:08:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:08:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:08:17 --> Final output sent to browser
DEBUG - 2017-03-15 00:08:17 --> Total execution time: 0.0146
INFO - 2017-03-15 00:08:24 --> Config Class Initialized
INFO - 2017-03-15 00:08:24 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:08:24 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:08:24 --> Utf8 Class Initialized
INFO - 2017-03-15 00:08:24 --> URI Class Initialized
INFO - 2017-03-15 00:08:24 --> Router Class Initialized
INFO - 2017-03-15 00:08:24 --> Output Class Initialized
INFO - 2017-03-15 00:08:24 --> Security Class Initialized
DEBUG - 2017-03-15 00:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:08:24 --> Input Class Initialized
INFO - 2017-03-15 00:08:24 --> Language Class Initialized
INFO - 2017-03-15 00:08:24 --> Loader Class Initialized
INFO - 2017-03-15 00:08:24 --> Database Driver Class Initialized
INFO - 2017-03-15 00:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:08:24 --> Controller Class Initialized
INFO - 2017-03-15 00:08:24 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:08:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:08:25 --> Config Class Initialized
INFO - 2017-03-15 00:08:25 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:08:25 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:08:25 --> Utf8 Class Initialized
INFO - 2017-03-15 00:08:25 --> URI Class Initialized
INFO - 2017-03-15 00:08:25 --> Router Class Initialized
INFO - 2017-03-15 00:08:25 --> Output Class Initialized
INFO - 2017-03-15 00:08:25 --> Security Class Initialized
DEBUG - 2017-03-15 00:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:08:25 --> Input Class Initialized
INFO - 2017-03-15 00:08:25 --> Language Class Initialized
INFO - 2017-03-15 00:08:25 --> Loader Class Initialized
INFO - 2017-03-15 00:08:25 --> Database Driver Class Initialized
INFO - 2017-03-15 00:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:08:25 --> Controller Class Initialized
INFO - 2017-03-15 00:08:25 --> Helper loaded: date_helper
DEBUG - 2017-03-15 00:08:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:08:25 --> Helper loaded: url_helper
INFO - 2017-03-15 00:08:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:08:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 00:08:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 00:08:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 00:08:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:08:25 --> Final output sent to browser
DEBUG - 2017-03-15 00:08:25 --> Total execution time: 0.0152
INFO - 2017-03-15 00:11:12 --> Config Class Initialized
INFO - 2017-03-15 00:11:12 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:11:12 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:11:12 --> Utf8 Class Initialized
INFO - 2017-03-15 00:11:12 --> URI Class Initialized
INFO - 2017-03-15 00:11:12 --> Router Class Initialized
INFO - 2017-03-15 00:11:12 --> Output Class Initialized
INFO - 2017-03-15 00:11:12 --> Security Class Initialized
DEBUG - 2017-03-15 00:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:11:12 --> Input Class Initialized
INFO - 2017-03-15 00:11:12 --> Language Class Initialized
INFO - 2017-03-15 00:11:12 --> Loader Class Initialized
INFO - 2017-03-15 00:11:12 --> Database Driver Class Initialized
INFO - 2017-03-15 00:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:11:12 --> Controller Class Initialized
INFO - 2017-03-15 00:11:12 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:11:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-15 00:11:12 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`, `contraseña`) VALUES (NULL, NULL, NULL)
INFO - 2017-03-15 00:11:12 --> Language file loaded: language/english/db_lang.php
INFO - 2017-03-15 00:11:13 --> Config Class Initialized
INFO - 2017-03-15 00:11:13 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:11:13 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:11:13 --> Utf8 Class Initialized
INFO - 2017-03-15 00:11:13 --> URI Class Initialized
INFO - 2017-03-15 00:11:13 --> Router Class Initialized
INFO - 2017-03-15 00:11:13 --> Output Class Initialized
INFO - 2017-03-15 00:11:13 --> Security Class Initialized
DEBUG - 2017-03-15 00:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:11:13 --> Input Class Initialized
INFO - 2017-03-15 00:11:13 --> Language Class Initialized
INFO - 2017-03-15 00:11:13 --> Loader Class Initialized
INFO - 2017-03-15 00:11:13 --> Database Driver Class Initialized
INFO - 2017-03-15 00:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:11:13 --> Controller Class Initialized
INFO - 2017-03-15 00:11:13 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:11:13 --> Final output sent to browser
DEBUG - 2017-03-15 00:11:13 --> Total execution time: 0.0140
INFO - 2017-03-15 00:11:15 --> Config Class Initialized
INFO - 2017-03-15 00:11:15 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:11:15 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:11:15 --> Utf8 Class Initialized
INFO - 2017-03-15 00:11:15 --> URI Class Initialized
INFO - 2017-03-15 00:11:15 --> Router Class Initialized
INFO - 2017-03-15 00:11:15 --> Output Class Initialized
INFO - 2017-03-15 00:11:15 --> Security Class Initialized
DEBUG - 2017-03-15 00:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:11:15 --> Input Class Initialized
INFO - 2017-03-15 00:11:15 --> Language Class Initialized
INFO - 2017-03-15 00:11:15 --> Loader Class Initialized
INFO - 2017-03-15 00:11:15 --> Database Driver Class Initialized
INFO - 2017-03-15 00:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:11:15 --> Controller Class Initialized
INFO - 2017-03-15 00:11:15 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:11:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:11:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:11:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:11:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:11:15 --> Final output sent to browser
DEBUG - 2017-03-15 00:11:15 --> Total execution time: 0.0137
INFO - 2017-03-15 00:11:15 --> Config Class Initialized
INFO - 2017-03-15 00:11:15 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:11:15 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:11:15 --> Utf8 Class Initialized
INFO - 2017-03-15 00:11:15 --> URI Class Initialized
INFO - 2017-03-15 00:11:15 --> Router Class Initialized
INFO - 2017-03-15 00:11:15 --> Output Class Initialized
INFO - 2017-03-15 00:11:15 --> Security Class Initialized
DEBUG - 2017-03-15 00:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:11:15 --> Input Class Initialized
INFO - 2017-03-15 00:11:15 --> Language Class Initialized
INFO - 2017-03-15 00:11:15 --> Loader Class Initialized
INFO - 2017-03-15 00:11:15 --> Database Driver Class Initialized
INFO - 2017-03-15 00:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:11:15 --> Controller Class Initialized
INFO - 2017-03-15 00:11:15 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:11:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:11:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:11:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:11:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:11:15 --> Final output sent to browser
DEBUG - 2017-03-15 00:11:15 --> Total execution time: 0.0140
INFO - 2017-03-15 00:11:18 --> Config Class Initialized
INFO - 2017-03-15 00:11:18 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:11:18 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:11:18 --> Utf8 Class Initialized
INFO - 2017-03-15 00:11:18 --> URI Class Initialized
DEBUG - 2017-03-15 00:11:18 --> No URI present. Default controller set.
INFO - 2017-03-15 00:11:18 --> Router Class Initialized
INFO - 2017-03-15 00:11:18 --> Output Class Initialized
INFO - 2017-03-15 00:11:18 --> Security Class Initialized
DEBUG - 2017-03-15 00:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:11:18 --> Input Class Initialized
INFO - 2017-03-15 00:11:18 --> Language Class Initialized
INFO - 2017-03-15 00:11:18 --> Loader Class Initialized
INFO - 2017-03-15 00:11:18 --> Database Driver Class Initialized
INFO - 2017-03-15 00:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:11:18 --> Controller Class Initialized
INFO - 2017-03-15 00:11:18 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:11:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:11:18 --> Final output sent to browser
DEBUG - 2017-03-15 00:11:18 --> Total execution time: 0.0135
INFO - 2017-03-15 00:11:24 --> Config Class Initialized
INFO - 2017-03-15 00:11:24 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:11:24 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:11:24 --> Utf8 Class Initialized
INFO - 2017-03-15 00:11:24 --> URI Class Initialized
INFO - 2017-03-15 00:11:24 --> Router Class Initialized
INFO - 2017-03-15 00:11:24 --> Output Class Initialized
INFO - 2017-03-15 00:11:24 --> Security Class Initialized
DEBUG - 2017-03-15 00:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:11:24 --> Input Class Initialized
INFO - 2017-03-15 00:11:24 --> Language Class Initialized
INFO - 2017-03-15 00:11:24 --> Loader Class Initialized
INFO - 2017-03-15 00:11:24 --> Database Driver Class Initialized
INFO - 2017-03-15 00:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:11:24 --> Controller Class Initialized
INFO - 2017-03-15 00:11:24 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:11:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:11:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:11:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:11:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:11:24 --> Final output sent to browser
DEBUG - 2017-03-15 00:11:24 --> Total execution time: 0.0142
INFO - 2017-03-15 00:11:45 --> Config Class Initialized
INFO - 2017-03-15 00:11:45 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:11:45 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:11:45 --> Utf8 Class Initialized
INFO - 2017-03-15 00:11:45 --> URI Class Initialized
INFO - 2017-03-15 00:11:45 --> Router Class Initialized
INFO - 2017-03-15 00:11:45 --> Output Class Initialized
INFO - 2017-03-15 00:11:45 --> Security Class Initialized
DEBUG - 2017-03-15 00:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:11:45 --> Input Class Initialized
INFO - 2017-03-15 00:11:45 --> Language Class Initialized
INFO - 2017-03-15 00:11:45 --> Loader Class Initialized
INFO - 2017-03-15 00:11:45 --> Database Driver Class Initialized
INFO - 2017-03-15 00:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:11:45 --> Controller Class Initialized
INFO - 2017-03-15 00:11:45 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:11:45 --> Final output sent to browser
DEBUG - 2017-03-15 00:11:45 --> Total execution time: 0.0146
INFO - 2017-03-15 00:11:48 --> Config Class Initialized
INFO - 2017-03-15 00:11:48 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:11:48 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:11:48 --> Utf8 Class Initialized
INFO - 2017-03-15 00:11:48 --> URI Class Initialized
INFO - 2017-03-15 00:11:48 --> Router Class Initialized
INFO - 2017-03-15 00:11:48 --> Output Class Initialized
INFO - 2017-03-15 00:11:48 --> Security Class Initialized
DEBUG - 2017-03-15 00:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:11:48 --> Input Class Initialized
INFO - 2017-03-15 00:11:48 --> Language Class Initialized
INFO - 2017-03-15 00:11:48 --> Loader Class Initialized
INFO - 2017-03-15 00:11:48 --> Database Driver Class Initialized
INFO - 2017-03-15 00:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:11:48 --> Controller Class Initialized
INFO - 2017-03-15 00:11:48 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:11:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:11:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:11:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:11:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:11:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:11:48 --> Final output sent to browser
DEBUG - 2017-03-15 00:11:48 --> Total execution time: 0.0140
INFO - 2017-03-15 00:11:59 --> Config Class Initialized
INFO - 2017-03-15 00:11:59 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:11:59 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:11:59 --> Utf8 Class Initialized
INFO - 2017-03-15 00:11:59 --> URI Class Initialized
INFO - 2017-03-15 00:11:59 --> Router Class Initialized
INFO - 2017-03-15 00:11:59 --> Output Class Initialized
INFO - 2017-03-15 00:11:59 --> Security Class Initialized
DEBUG - 2017-03-15 00:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:11:59 --> Input Class Initialized
INFO - 2017-03-15 00:11:59 --> Language Class Initialized
INFO - 2017-03-15 00:11:59 --> Loader Class Initialized
INFO - 2017-03-15 00:11:59 --> Database Driver Class Initialized
INFO - 2017-03-15 00:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:11:59 --> Controller Class Initialized
INFO - 2017-03-15 00:11:59 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:11:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:11:59 --> Config Class Initialized
INFO - 2017-03-15 00:11:59 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:11:59 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:11:59 --> Utf8 Class Initialized
INFO - 2017-03-15 00:11:59 --> URI Class Initialized
INFO - 2017-03-15 00:11:59 --> Router Class Initialized
INFO - 2017-03-15 00:11:59 --> Output Class Initialized
INFO - 2017-03-15 00:11:59 --> Security Class Initialized
DEBUG - 2017-03-15 00:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:11:59 --> Input Class Initialized
INFO - 2017-03-15 00:11:59 --> Language Class Initialized
INFO - 2017-03-15 00:11:59 --> Loader Class Initialized
INFO - 2017-03-15 00:11:59 --> Database Driver Class Initialized
INFO - 2017-03-15 00:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:11:59 --> Controller Class Initialized
INFO - 2017-03-15 00:11:59 --> Helper loaded: date_helper
DEBUG - 2017-03-15 00:11:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:11:59 --> Helper loaded: url_helper
INFO - 2017-03-15 00:11:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:11:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 00:11:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 00:11:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 00:11:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:11:59 --> Final output sent to browser
DEBUG - 2017-03-15 00:11:59 --> Total execution time: 0.0262
INFO - 2017-03-15 00:12:01 --> Config Class Initialized
INFO - 2017-03-15 00:12:01 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:12:01 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:12:01 --> Utf8 Class Initialized
INFO - 2017-03-15 00:12:01 --> URI Class Initialized
INFO - 2017-03-15 00:12:01 --> Router Class Initialized
INFO - 2017-03-15 00:12:01 --> Output Class Initialized
INFO - 2017-03-15 00:12:01 --> Security Class Initialized
DEBUG - 2017-03-15 00:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:12:01 --> Input Class Initialized
INFO - 2017-03-15 00:12:01 --> Language Class Initialized
INFO - 2017-03-15 00:12:01 --> Loader Class Initialized
INFO - 2017-03-15 00:12:01 --> Database Driver Class Initialized
INFO - 2017-03-15 00:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:12:01 --> Controller Class Initialized
INFO - 2017-03-15 00:12:01 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:12:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:12:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:12:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:12:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:12:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:12:01 --> Final output sent to browser
DEBUG - 2017-03-15 00:12:01 --> Total execution time: 0.0144
INFO - 2017-03-15 00:14:14 --> Config Class Initialized
INFO - 2017-03-15 00:14:14 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:14:14 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:14:14 --> Utf8 Class Initialized
INFO - 2017-03-15 00:14:14 --> URI Class Initialized
DEBUG - 2017-03-15 00:14:14 --> No URI present. Default controller set.
INFO - 2017-03-15 00:14:14 --> Router Class Initialized
INFO - 2017-03-15 00:14:14 --> Output Class Initialized
INFO - 2017-03-15 00:14:14 --> Security Class Initialized
DEBUG - 2017-03-15 00:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:14:15 --> Input Class Initialized
INFO - 2017-03-15 00:14:15 --> Language Class Initialized
INFO - 2017-03-15 00:14:15 --> Loader Class Initialized
INFO - 2017-03-15 00:14:15 --> Database Driver Class Initialized
INFO - 2017-03-15 00:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:14:15 --> Controller Class Initialized
INFO - 2017-03-15 00:14:15 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:14:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:14:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:14:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:14:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:14:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:14:15 --> Final output sent to browser
DEBUG - 2017-03-15 00:14:15 --> Total execution time: 1.2430
INFO - 2017-03-15 00:14:21 --> Config Class Initialized
INFO - 2017-03-15 00:14:21 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:14:21 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:14:21 --> Utf8 Class Initialized
INFO - 2017-03-15 00:14:21 --> URI Class Initialized
INFO - 2017-03-15 00:14:21 --> Router Class Initialized
INFO - 2017-03-15 00:14:21 --> Output Class Initialized
INFO - 2017-03-15 00:14:21 --> Security Class Initialized
DEBUG - 2017-03-15 00:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:14:21 --> Input Class Initialized
INFO - 2017-03-15 00:14:21 --> Language Class Initialized
INFO - 2017-03-15 00:14:21 --> Loader Class Initialized
INFO - 2017-03-15 00:14:22 --> Database Driver Class Initialized
INFO - 2017-03-15 00:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:14:22 --> Controller Class Initialized
INFO - 2017-03-15 00:14:22 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:14:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:14:22 --> Final output sent to browser
DEBUG - 2017-03-15 00:14:22 --> Total execution time: 1.2189
INFO - 2017-03-15 00:19:38 --> Config Class Initialized
INFO - 2017-03-15 00:19:38 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:19:38 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:19:39 --> Utf8 Class Initialized
INFO - 2017-03-15 00:19:39 --> URI Class Initialized
DEBUG - 2017-03-15 00:19:39 --> No URI present. Default controller set.
INFO - 2017-03-15 00:19:39 --> Router Class Initialized
INFO - 2017-03-15 00:19:39 --> Output Class Initialized
INFO - 2017-03-15 00:19:39 --> Security Class Initialized
DEBUG - 2017-03-15 00:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:19:39 --> Input Class Initialized
INFO - 2017-03-15 00:19:39 --> Language Class Initialized
INFO - 2017-03-15 00:19:39 --> Loader Class Initialized
INFO - 2017-03-15 00:19:39 --> Database Driver Class Initialized
INFO - 2017-03-15 00:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:19:40 --> Controller Class Initialized
INFO - 2017-03-15 00:19:40 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:19:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:19:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:19:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:19:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:19:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:19:40 --> Final output sent to browser
DEBUG - 2017-03-15 00:19:40 --> Total execution time: 1.5130
INFO - 2017-03-15 00:19:46 --> Config Class Initialized
INFO - 2017-03-15 00:19:46 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:19:46 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:19:46 --> Utf8 Class Initialized
INFO - 2017-03-15 00:19:46 --> URI Class Initialized
INFO - 2017-03-15 00:19:46 --> Router Class Initialized
INFO - 2017-03-15 00:19:46 --> Output Class Initialized
INFO - 2017-03-15 00:19:46 --> Security Class Initialized
DEBUG - 2017-03-15 00:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:19:46 --> Input Class Initialized
INFO - 2017-03-15 00:19:46 --> Language Class Initialized
INFO - 2017-03-15 00:19:46 --> Loader Class Initialized
INFO - 2017-03-15 00:19:46 --> Database Driver Class Initialized
INFO - 2017-03-15 00:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:19:46 --> Controller Class Initialized
INFO - 2017-03-15 00:19:46 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:19:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:19:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:19:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:19:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:19:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:19:46 --> Final output sent to browser
DEBUG - 2017-03-15 00:19:46 --> Total execution time: 0.0138
INFO - 2017-03-15 00:20:26 --> Config Class Initialized
INFO - 2017-03-15 00:20:26 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:20:26 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:20:26 --> Utf8 Class Initialized
INFO - 2017-03-15 00:20:26 --> URI Class Initialized
INFO - 2017-03-15 00:20:26 --> Router Class Initialized
INFO - 2017-03-15 00:20:26 --> Output Class Initialized
INFO - 2017-03-15 00:20:26 --> Security Class Initialized
DEBUG - 2017-03-15 00:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:20:26 --> Input Class Initialized
INFO - 2017-03-15 00:20:26 --> Language Class Initialized
INFO - 2017-03-15 00:20:26 --> Loader Class Initialized
INFO - 2017-03-15 00:20:26 --> Database Driver Class Initialized
INFO - 2017-03-15 00:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:20:26 --> Controller Class Initialized
INFO - 2017-03-15 00:20:26 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:20:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:20:28 --> Config Class Initialized
INFO - 2017-03-15 00:20:28 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:20:28 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:20:28 --> Utf8 Class Initialized
INFO - 2017-03-15 00:20:28 --> URI Class Initialized
INFO - 2017-03-15 00:20:28 --> Router Class Initialized
INFO - 2017-03-15 00:20:28 --> Output Class Initialized
INFO - 2017-03-15 00:20:28 --> Security Class Initialized
DEBUG - 2017-03-15 00:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:20:28 --> Input Class Initialized
INFO - 2017-03-15 00:20:28 --> Language Class Initialized
INFO - 2017-03-15 00:20:28 --> Loader Class Initialized
INFO - 2017-03-15 00:20:28 --> Database Driver Class Initialized
INFO - 2017-03-15 00:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:20:28 --> Controller Class Initialized
INFO - 2017-03-15 00:20:28 --> Helper loaded: date_helper
DEBUG - 2017-03-15 00:20:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:20:28 --> Helper loaded: url_helper
INFO - 2017-03-15 00:20:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:20:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 00:20:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 00:20:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 00:20:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:20:28 --> Final output sent to browser
DEBUG - 2017-03-15 00:20:28 --> Total execution time: 0.0933
INFO - 2017-03-15 00:20:29 --> Config Class Initialized
INFO - 2017-03-15 00:20:29 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:20:29 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:20:29 --> Utf8 Class Initialized
INFO - 2017-03-15 00:20:29 --> URI Class Initialized
INFO - 2017-03-15 00:20:29 --> Router Class Initialized
INFO - 2017-03-15 00:20:29 --> Output Class Initialized
INFO - 2017-03-15 00:20:29 --> Security Class Initialized
DEBUG - 2017-03-15 00:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:20:29 --> Input Class Initialized
INFO - 2017-03-15 00:20:29 --> Language Class Initialized
INFO - 2017-03-15 00:20:29 --> Loader Class Initialized
INFO - 2017-03-15 00:20:29 --> Database Driver Class Initialized
INFO - 2017-03-15 00:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:20:29 --> Controller Class Initialized
INFO - 2017-03-15 00:20:29 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:20:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:20:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:20:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:20:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:20:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:20:29 --> Final output sent to browser
DEBUG - 2017-03-15 00:20:29 --> Total execution time: 0.0135
INFO - 2017-03-15 00:20:38 --> Config Class Initialized
INFO - 2017-03-15 00:20:38 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:20:38 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:20:38 --> Utf8 Class Initialized
INFO - 2017-03-15 00:20:38 --> URI Class Initialized
DEBUG - 2017-03-15 00:20:38 --> No URI present. Default controller set.
INFO - 2017-03-15 00:20:38 --> Router Class Initialized
INFO - 2017-03-15 00:20:38 --> Output Class Initialized
INFO - 2017-03-15 00:20:38 --> Security Class Initialized
DEBUG - 2017-03-15 00:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:20:38 --> Input Class Initialized
INFO - 2017-03-15 00:20:38 --> Language Class Initialized
INFO - 2017-03-15 00:20:38 --> Loader Class Initialized
INFO - 2017-03-15 00:20:38 --> Database Driver Class Initialized
INFO - 2017-03-15 00:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:20:38 --> Controller Class Initialized
INFO - 2017-03-15 00:20:38 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:20:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:20:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:20:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:20:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:20:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:20:38 --> Final output sent to browser
DEBUG - 2017-03-15 00:20:38 --> Total execution time: 0.0143
INFO - 2017-03-15 00:20:40 --> Config Class Initialized
INFO - 2017-03-15 00:20:40 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:20:40 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:20:40 --> Utf8 Class Initialized
INFO - 2017-03-15 00:20:40 --> URI Class Initialized
INFO - 2017-03-15 00:20:40 --> Router Class Initialized
INFO - 2017-03-15 00:20:40 --> Output Class Initialized
INFO - 2017-03-15 00:20:40 --> Security Class Initialized
DEBUG - 2017-03-15 00:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:20:40 --> Input Class Initialized
INFO - 2017-03-15 00:20:40 --> Language Class Initialized
INFO - 2017-03-15 00:20:40 --> Loader Class Initialized
INFO - 2017-03-15 00:20:40 --> Database Driver Class Initialized
INFO - 2017-03-15 00:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:20:40 --> Controller Class Initialized
INFO - 2017-03-15 00:20:40 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:20:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:20:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:20:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:20:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:20:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:20:40 --> Final output sent to browser
DEBUG - 2017-03-15 00:20:40 --> Total execution time: 0.0148
INFO - 2017-03-15 00:20:56 --> Config Class Initialized
INFO - 2017-03-15 00:20:56 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:20:56 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:20:56 --> Utf8 Class Initialized
INFO - 2017-03-15 00:20:56 --> URI Class Initialized
INFO - 2017-03-15 00:20:56 --> Router Class Initialized
INFO - 2017-03-15 00:20:56 --> Output Class Initialized
INFO - 2017-03-15 00:20:56 --> Security Class Initialized
DEBUG - 2017-03-15 00:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:20:56 --> Input Class Initialized
INFO - 2017-03-15 00:20:56 --> Language Class Initialized
INFO - 2017-03-15 00:20:56 --> Loader Class Initialized
INFO - 2017-03-15 00:20:57 --> Database Driver Class Initialized
INFO - 2017-03-15 00:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:20:57 --> Controller Class Initialized
INFO - 2017-03-15 00:20:57 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:20:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:21:02 --> Config Class Initialized
INFO - 2017-03-15 00:21:02 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:21:03 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:21:03 --> Utf8 Class Initialized
INFO - 2017-03-15 00:21:03 --> URI Class Initialized
INFO - 2017-03-15 00:21:03 --> Router Class Initialized
INFO - 2017-03-15 00:21:03 --> Output Class Initialized
INFO - 2017-03-15 00:21:03 --> Security Class Initialized
DEBUG - 2017-03-15 00:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:21:03 --> Input Class Initialized
INFO - 2017-03-15 00:21:03 --> Language Class Initialized
INFO - 2017-03-15 00:21:03 --> Loader Class Initialized
INFO - 2017-03-15 00:21:03 --> Database Driver Class Initialized
INFO - 2017-03-15 00:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:21:04 --> Controller Class Initialized
INFO - 2017-03-15 00:21:04 --> Helper loaded: date_helper
DEBUG - 2017-03-15 00:21:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:21:04 --> Helper loaded: url_helper
INFO - 2017-03-15 00:21:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:21:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 00:21:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 00:21:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 00:21:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:21:04 --> Final output sent to browser
DEBUG - 2017-03-15 00:21:04 --> Total execution time: 1.6183
INFO - 2017-03-15 00:21:07 --> Config Class Initialized
INFO - 2017-03-15 00:21:07 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:21:07 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:21:07 --> Utf8 Class Initialized
INFO - 2017-03-15 00:21:07 --> URI Class Initialized
INFO - 2017-03-15 00:21:07 --> Router Class Initialized
INFO - 2017-03-15 00:21:07 --> Output Class Initialized
INFO - 2017-03-15 00:21:07 --> Security Class Initialized
DEBUG - 2017-03-15 00:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:21:07 --> Input Class Initialized
INFO - 2017-03-15 00:21:07 --> Language Class Initialized
INFO - 2017-03-15 00:21:08 --> Loader Class Initialized
INFO - 2017-03-15 00:21:08 --> Database Driver Class Initialized
INFO - 2017-03-15 00:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:21:08 --> Controller Class Initialized
INFO - 2017-03-15 00:21:08 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:21:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:21:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:21:08 --> Final output sent to browser
DEBUG - 2017-03-15 00:21:08 --> Total execution time: 1.4436
INFO - 2017-03-15 00:21:52 --> Config Class Initialized
INFO - 2017-03-15 00:21:52 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:21:52 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:21:52 --> Utf8 Class Initialized
INFO - 2017-03-15 00:21:52 --> URI Class Initialized
INFO - 2017-03-15 00:21:52 --> Router Class Initialized
INFO - 2017-03-15 00:21:52 --> Output Class Initialized
INFO - 2017-03-15 00:21:52 --> Security Class Initialized
DEBUG - 2017-03-15 00:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:21:52 --> Input Class Initialized
INFO - 2017-03-15 00:21:52 --> Language Class Initialized
INFO - 2017-03-15 00:21:52 --> Loader Class Initialized
INFO - 2017-03-15 00:21:52 --> Database Driver Class Initialized
INFO - 2017-03-15 00:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:21:52 --> Controller Class Initialized
INFO - 2017-03-15 00:21:52 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:21:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:21:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:21:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:21:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:21:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:21:52 --> Final output sent to browser
DEBUG - 2017-03-15 00:21:52 --> Total execution time: 0.2829
INFO - 2017-03-15 00:22:21 --> Config Class Initialized
INFO - 2017-03-15 00:22:21 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:22:21 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:22:21 --> Utf8 Class Initialized
INFO - 2017-03-15 00:22:21 --> URI Class Initialized
DEBUG - 2017-03-15 00:22:21 --> No URI present. Default controller set.
INFO - 2017-03-15 00:22:21 --> Router Class Initialized
INFO - 2017-03-15 00:22:21 --> Output Class Initialized
INFO - 2017-03-15 00:22:21 --> Security Class Initialized
DEBUG - 2017-03-15 00:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:22:21 --> Input Class Initialized
INFO - 2017-03-15 00:22:21 --> Language Class Initialized
INFO - 2017-03-15 00:22:21 --> Loader Class Initialized
INFO - 2017-03-15 00:22:21 --> Database Driver Class Initialized
INFO - 2017-03-15 00:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:22:21 --> Controller Class Initialized
INFO - 2017-03-15 00:22:21 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:22:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:22:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:22:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:22:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:22:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:22:21 --> Final output sent to browser
DEBUG - 2017-03-15 00:22:21 --> Total execution time: 0.0137
INFO - 2017-03-15 00:22:59 --> Config Class Initialized
INFO - 2017-03-15 00:22:59 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:22:59 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:22:59 --> Utf8 Class Initialized
INFO - 2017-03-15 00:22:59 --> URI Class Initialized
DEBUG - 2017-03-15 00:22:59 --> No URI present. Default controller set.
INFO - 2017-03-15 00:22:59 --> Router Class Initialized
INFO - 2017-03-15 00:22:59 --> Output Class Initialized
INFO - 2017-03-15 00:22:59 --> Security Class Initialized
DEBUG - 2017-03-15 00:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:23:00 --> Input Class Initialized
INFO - 2017-03-15 00:23:00 --> Language Class Initialized
INFO - 2017-03-15 00:23:00 --> Loader Class Initialized
INFO - 2017-03-15 00:23:00 --> Database Driver Class Initialized
INFO - 2017-03-15 00:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:23:00 --> Controller Class Initialized
INFO - 2017-03-15 00:23:00 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:23:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:23:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:23:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:23:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:23:01 --> Final output sent to browser
DEBUG - 2017-03-15 00:23:01 --> Total execution time: 1.5841
INFO - 2017-03-15 00:23:05 --> Config Class Initialized
INFO - 2017-03-15 00:23:05 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:23:05 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:23:05 --> Utf8 Class Initialized
INFO - 2017-03-15 00:23:05 --> URI Class Initialized
INFO - 2017-03-15 00:23:05 --> Router Class Initialized
INFO - 2017-03-15 00:23:05 --> Output Class Initialized
INFO - 2017-03-15 00:23:05 --> Security Class Initialized
DEBUG - 2017-03-15 00:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:23:05 --> Input Class Initialized
INFO - 2017-03-15 00:23:05 --> Language Class Initialized
INFO - 2017-03-15 00:23:05 --> Loader Class Initialized
INFO - 2017-03-15 00:23:05 --> Database Driver Class Initialized
INFO - 2017-03-15 00:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:23:05 --> Controller Class Initialized
INFO - 2017-03-15 00:23:05 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:23:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:23:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:23:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:23:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:23:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:23:05 --> Final output sent to browser
DEBUG - 2017-03-15 00:23:05 --> Total execution time: 0.0134
INFO - 2017-03-15 00:23:16 --> Config Class Initialized
INFO - 2017-03-15 00:23:16 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:23:16 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:23:16 --> Utf8 Class Initialized
INFO - 2017-03-15 00:23:16 --> URI Class Initialized
INFO - 2017-03-15 00:23:16 --> Router Class Initialized
INFO - 2017-03-15 00:23:16 --> Output Class Initialized
INFO - 2017-03-15 00:23:16 --> Security Class Initialized
DEBUG - 2017-03-15 00:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:23:16 --> Input Class Initialized
INFO - 2017-03-15 00:23:16 --> Language Class Initialized
INFO - 2017-03-15 00:23:16 --> Loader Class Initialized
INFO - 2017-03-15 00:23:16 --> Database Driver Class Initialized
INFO - 2017-03-15 00:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:23:16 --> Controller Class Initialized
INFO - 2017-03-15 00:23:16 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:23:17 --> Config Class Initialized
INFO - 2017-03-15 00:23:17 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:23:17 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:23:17 --> Utf8 Class Initialized
INFO - 2017-03-15 00:23:17 --> URI Class Initialized
INFO - 2017-03-15 00:23:17 --> Router Class Initialized
INFO - 2017-03-15 00:23:17 --> Output Class Initialized
INFO - 2017-03-15 00:23:17 --> Security Class Initialized
DEBUG - 2017-03-15 00:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:23:17 --> Input Class Initialized
INFO - 2017-03-15 00:23:17 --> Language Class Initialized
INFO - 2017-03-15 00:23:17 --> Loader Class Initialized
INFO - 2017-03-15 00:23:17 --> Database Driver Class Initialized
INFO - 2017-03-15 00:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:23:17 --> Controller Class Initialized
INFO - 2017-03-15 00:23:17 --> Helper loaded: date_helper
DEBUG - 2017-03-15 00:23:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:23:17 --> Helper loaded: url_helper
INFO - 2017-03-15 00:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 00:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 00:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 00:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:23:17 --> Final output sent to browser
DEBUG - 2017-03-15 00:23:17 --> Total execution time: 0.0929
INFO - 2017-03-15 00:23:18 --> Config Class Initialized
INFO - 2017-03-15 00:23:18 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:23:18 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:23:18 --> Utf8 Class Initialized
INFO - 2017-03-15 00:23:18 --> URI Class Initialized
INFO - 2017-03-15 00:23:18 --> Router Class Initialized
INFO - 2017-03-15 00:23:18 --> Output Class Initialized
INFO - 2017-03-15 00:23:18 --> Security Class Initialized
DEBUG - 2017-03-15 00:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:23:18 --> Input Class Initialized
INFO - 2017-03-15 00:23:18 --> Language Class Initialized
INFO - 2017-03-15 00:23:18 --> Loader Class Initialized
INFO - 2017-03-15 00:23:18 --> Database Driver Class Initialized
INFO - 2017-03-15 00:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:23:18 --> Controller Class Initialized
INFO - 2017-03-15 00:23:18 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:23:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:23:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:23:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:23:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:23:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:23:18 --> Final output sent to browser
DEBUG - 2017-03-15 00:23:18 --> Total execution time: 0.0144
INFO - 2017-03-15 00:24:42 --> Config Class Initialized
INFO - 2017-03-15 00:24:42 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:24:42 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:24:42 --> Utf8 Class Initialized
INFO - 2017-03-15 00:24:42 --> URI Class Initialized
DEBUG - 2017-03-15 00:24:42 --> No URI present. Default controller set.
INFO - 2017-03-15 00:24:42 --> Router Class Initialized
INFO - 2017-03-15 00:24:42 --> Output Class Initialized
INFO - 2017-03-15 00:24:42 --> Security Class Initialized
DEBUG - 2017-03-15 00:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:24:42 --> Input Class Initialized
INFO - 2017-03-15 00:24:42 --> Language Class Initialized
INFO - 2017-03-15 00:24:42 --> Loader Class Initialized
INFO - 2017-03-15 00:24:43 --> Database Driver Class Initialized
INFO - 2017-03-15 00:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:24:43 --> Controller Class Initialized
INFO - 2017-03-15 00:24:43 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:24:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:24:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:24:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:24:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:24:44 --> Final output sent to browser
DEBUG - 2017-03-15 00:24:44 --> Total execution time: 1.8209
INFO - 2017-03-15 00:24:57 --> Config Class Initialized
INFO - 2017-03-15 00:24:57 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:24:57 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:24:57 --> Utf8 Class Initialized
INFO - 2017-03-15 00:24:57 --> URI Class Initialized
INFO - 2017-03-15 00:24:57 --> Router Class Initialized
INFO - 2017-03-15 00:24:57 --> Output Class Initialized
INFO - 2017-03-15 00:24:57 --> Security Class Initialized
DEBUG - 2017-03-15 00:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:24:57 --> Input Class Initialized
INFO - 2017-03-15 00:24:57 --> Language Class Initialized
INFO - 2017-03-15 00:24:57 --> Loader Class Initialized
INFO - 2017-03-15 00:24:57 --> Database Driver Class Initialized
INFO - 2017-03-15 00:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:24:57 --> Controller Class Initialized
INFO - 2017-03-15 00:24:57 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:24:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:24:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:24:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:24:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:24:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:24:57 --> Final output sent to browser
DEBUG - 2017-03-15 00:24:57 --> Total execution time: 0.1283
INFO - 2017-03-15 00:26:08 --> Config Class Initialized
INFO - 2017-03-15 00:26:08 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:26:08 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:26:08 --> Utf8 Class Initialized
INFO - 2017-03-15 00:26:08 --> URI Class Initialized
DEBUG - 2017-03-15 00:26:08 --> No URI present. Default controller set.
INFO - 2017-03-15 00:26:08 --> Router Class Initialized
INFO - 2017-03-15 00:26:08 --> Output Class Initialized
INFO - 2017-03-15 00:26:08 --> Security Class Initialized
DEBUG - 2017-03-15 00:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:26:08 --> Input Class Initialized
INFO - 2017-03-15 00:26:08 --> Language Class Initialized
INFO - 2017-03-15 00:26:08 --> Loader Class Initialized
INFO - 2017-03-15 00:26:08 --> Database Driver Class Initialized
INFO - 2017-03-15 00:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:26:08 --> Controller Class Initialized
INFO - 2017-03-15 00:26:08 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:26:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:26:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:26:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:26:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:26:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:26:08 --> Final output sent to browser
DEBUG - 2017-03-15 00:26:08 --> Total execution time: 0.0133
INFO - 2017-03-15 00:26:45 --> Config Class Initialized
INFO - 2017-03-15 00:26:45 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:26:45 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:26:45 --> Utf8 Class Initialized
INFO - 2017-03-15 00:26:45 --> URI Class Initialized
INFO - 2017-03-15 00:26:45 --> Router Class Initialized
INFO - 2017-03-15 00:26:45 --> Output Class Initialized
INFO - 2017-03-15 00:26:45 --> Security Class Initialized
DEBUG - 2017-03-15 00:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:26:45 --> Input Class Initialized
INFO - 2017-03-15 00:26:45 --> Language Class Initialized
INFO - 2017-03-15 00:26:45 --> Loader Class Initialized
INFO - 2017-03-15 00:26:45 --> Database Driver Class Initialized
INFO - 2017-03-15 00:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:26:45 --> Controller Class Initialized
INFO - 2017-03-15 00:26:45 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:26:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:26:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:26:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:26:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:26:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:26:45 --> Final output sent to browser
DEBUG - 2017-03-15 00:26:45 --> Total execution time: 0.0250
INFO - 2017-03-15 00:26:45 --> Config Class Initialized
INFO - 2017-03-15 00:26:45 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:26:45 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:26:45 --> Utf8 Class Initialized
INFO - 2017-03-15 00:26:45 --> URI Class Initialized
DEBUG - 2017-03-15 00:26:45 --> No URI present. Default controller set.
INFO - 2017-03-15 00:26:45 --> Router Class Initialized
INFO - 2017-03-15 00:26:45 --> Output Class Initialized
INFO - 2017-03-15 00:26:45 --> Security Class Initialized
DEBUG - 2017-03-15 00:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:26:45 --> Input Class Initialized
INFO - 2017-03-15 00:26:45 --> Language Class Initialized
INFO - 2017-03-15 00:26:45 --> Loader Class Initialized
INFO - 2017-03-15 00:26:45 --> Database Driver Class Initialized
INFO - 2017-03-15 00:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:26:45 --> Controller Class Initialized
INFO - 2017-03-15 00:26:45 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:26:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:26:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:26:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:26:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:26:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:26:45 --> Final output sent to browser
DEBUG - 2017-03-15 00:26:45 --> Total execution time: 0.0139
INFO - 2017-03-15 00:26:51 --> Config Class Initialized
INFO - 2017-03-15 00:26:51 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:26:51 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:26:51 --> Utf8 Class Initialized
INFO - 2017-03-15 00:26:51 --> URI Class Initialized
INFO - 2017-03-15 00:26:51 --> Router Class Initialized
INFO - 2017-03-15 00:26:51 --> Output Class Initialized
INFO - 2017-03-15 00:26:51 --> Security Class Initialized
DEBUG - 2017-03-15 00:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:26:51 --> Input Class Initialized
INFO - 2017-03-15 00:26:51 --> Language Class Initialized
INFO - 2017-03-15 00:26:51 --> Loader Class Initialized
INFO - 2017-03-15 00:26:51 --> Database Driver Class Initialized
INFO - 2017-03-15 00:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:26:51 --> Controller Class Initialized
INFO - 2017-03-15 00:26:51 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:26:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:26:52 --> Config Class Initialized
INFO - 2017-03-15 00:26:52 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:26:52 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:26:52 --> Utf8 Class Initialized
INFO - 2017-03-15 00:26:52 --> URI Class Initialized
INFO - 2017-03-15 00:26:52 --> Router Class Initialized
INFO - 2017-03-15 00:26:52 --> Output Class Initialized
INFO - 2017-03-15 00:26:52 --> Security Class Initialized
DEBUG - 2017-03-15 00:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:26:52 --> Input Class Initialized
INFO - 2017-03-15 00:26:52 --> Language Class Initialized
INFO - 2017-03-15 00:26:52 --> Loader Class Initialized
INFO - 2017-03-15 00:26:52 --> Database Driver Class Initialized
INFO - 2017-03-15 00:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:26:53 --> Controller Class Initialized
INFO - 2017-03-15 00:26:53 --> Helper loaded: date_helper
DEBUG - 2017-03-15 00:26:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:26:53 --> Helper loaded: url_helper
INFO - 2017-03-15 00:26:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:26:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 00:26:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 00:26:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 00:26:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:26:53 --> Final output sent to browser
DEBUG - 2017-03-15 00:26:53 --> Total execution time: 0.3296
INFO - 2017-03-15 00:27:48 --> Config Class Initialized
INFO - 2017-03-15 00:27:49 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:27:49 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:27:49 --> Utf8 Class Initialized
INFO - 2017-03-15 00:27:49 --> URI Class Initialized
INFO - 2017-03-15 00:27:49 --> Router Class Initialized
INFO - 2017-03-15 00:27:49 --> Output Class Initialized
INFO - 2017-03-15 00:27:49 --> Security Class Initialized
DEBUG - 2017-03-15 00:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:27:49 --> Input Class Initialized
INFO - 2017-03-15 00:27:49 --> Language Class Initialized
INFO - 2017-03-15 00:27:49 --> Loader Class Initialized
INFO - 2017-03-15 00:27:49 --> Database Driver Class Initialized
INFO - 2017-03-15 00:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:27:49 --> Controller Class Initialized
INFO - 2017-03-15 00:27:49 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:27:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:27:51 --> Config Class Initialized
INFO - 2017-03-15 00:27:51 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:27:51 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:27:51 --> Utf8 Class Initialized
INFO - 2017-03-15 00:27:51 --> URI Class Initialized
INFO - 2017-03-15 00:27:51 --> Router Class Initialized
INFO - 2017-03-15 00:27:51 --> Output Class Initialized
INFO - 2017-03-15 00:27:51 --> Security Class Initialized
DEBUG - 2017-03-15 00:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:27:51 --> Input Class Initialized
INFO - 2017-03-15 00:27:51 --> Language Class Initialized
INFO - 2017-03-15 00:27:51 --> Loader Class Initialized
INFO - 2017-03-15 00:27:51 --> Database Driver Class Initialized
INFO - 2017-03-15 00:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:27:51 --> Controller Class Initialized
INFO - 2017-03-15 00:27:51 --> Helper loaded: date_helper
DEBUG - 2017-03-15 00:27:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:27:51 --> Helper loaded: url_helper
INFO - 2017-03-15 00:27:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:27:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 00:27:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 00:27:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 00:27:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:27:51 --> Final output sent to browser
DEBUG - 2017-03-15 00:27:52 --> Total execution time: 0.1032
INFO - 2017-03-15 00:28:11 --> Config Class Initialized
INFO - 2017-03-15 00:28:11 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:28:11 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:28:11 --> Utf8 Class Initialized
INFO - 2017-03-15 00:28:11 --> URI Class Initialized
DEBUG - 2017-03-15 00:28:11 --> No URI present. Default controller set.
INFO - 2017-03-15 00:28:11 --> Router Class Initialized
INFO - 2017-03-15 00:28:11 --> Output Class Initialized
INFO - 2017-03-15 00:28:11 --> Security Class Initialized
DEBUG - 2017-03-15 00:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:28:11 --> Input Class Initialized
INFO - 2017-03-15 00:28:11 --> Language Class Initialized
INFO - 2017-03-15 00:28:11 --> Loader Class Initialized
INFO - 2017-03-15 00:28:11 --> Database Driver Class Initialized
INFO - 2017-03-15 00:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:28:11 --> Controller Class Initialized
INFO - 2017-03-15 00:28:11 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:28:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:28:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:28:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:28:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:28:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:28:11 --> Final output sent to browser
DEBUG - 2017-03-15 00:28:11 --> Total execution time: 0.0508
INFO - 2017-03-15 00:28:11 --> Config Class Initialized
INFO - 2017-03-15 00:28:11 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:28:11 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:28:11 --> Utf8 Class Initialized
INFO - 2017-03-15 00:28:11 --> URI Class Initialized
DEBUG - 2017-03-15 00:28:11 --> No URI present. Default controller set.
INFO - 2017-03-15 00:28:11 --> Router Class Initialized
INFO - 2017-03-15 00:28:11 --> Output Class Initialized
INFO - 2017-03-15 00:28:11 --> Security Class Initialized
DEBUG - 2017-03-15 00:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:28:11 --> Input Class Initialized
INFO - 2017-03-15 00:28:11 --> Language Class Initialized
INFO - 2017-03-15 00:28:11 --> Loader Class Initialized
INFO - 2017-03-15 00:28:11 --> Database Driver Class Initialized
INFO - 2017-03-15 00:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:28:11 --> Controller Class Initialized
INFO - 2017-03-15 00:28:11 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:28:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:28:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:28:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:28:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:28:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:28:11 --> Final output sent to browser
DEBUG - 2017-03-15 00:28:11 --> Total execution time: 0.0135
INFO - 2017-03-15 00:28:24 --> Config Class Initialized
INFO - 2017-03-15 00:28:24 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:28:24 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:28:24 --> Utf8 Class Initialized
INFO - 2017-03-15 00:28:24 --> URI Class Initialized
INFO - 2017-03-15 00:28:24 --> Router Class Initialized
INFO - 2017-03-15 00:28:24 --> Output Class Initialized
INFO - 2017-03-15 00:28:24 --> Security Class Initialized
DEBUG - 2017-03-15 00:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:28:24 --> Input Class Initialized
INFO - 2017-03-15 00:28:24 --> Language Class Initialized
INFO - 2017-03-15 00:28:24 --> Loader Class Initialized
INFO - 2017-03-15 00:28:24 --> Database Driver Class Initialized
INFO - 2017-03-15 00:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:28:24 --> Controller Class Initialized
INFO - 2017-03-15 00:28:24 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:28:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:28:25 --> Config Class Initialized
INFO - 2017-03-15 00:28:25 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:28:25 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:28:25 --> Utf8 Class Initialized
INFO - 2017-03-15 00:28:25 --> URI Class Initialized
INFO - 2017-03-15 00:28:25 --> Router Class Initialized
INFO - 2017-03-15 00:28:25 --> Output Class Initialized
INFO - 2017-03-15 00:28:25 --> Security Class Initialized
DEBUG - 2017-03-15 00:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:28:25 --> Input Class Initialized
INFO - 2017-03-15 00:28:25 --> Language Class Initialized
INFO - 2017-03-15 00:28:25 --> Loader Class Initialized
INFO - 2017-03-15 00:28:25 --> Database Driver Class Initialized
INFO - 2017-03-15 00:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:28:25 --> Controller Class Initialized
INFO - 2017-03-15 00:28:25 --> Helper loaded: date_helper
DEBUG - 2017-03-15 00:28:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:28:25 --> Helper loaded: url_helper
INFO - 2017-03-15 00:28:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:28:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 00:28:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 00:28:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 00:28:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:28:25 --> Final output sent to browser
DEBUG - 2017-03-15 00:28:25 --> Total execution time: 0.0140
INFO - 2017-03-15 00:38:01 --> Config Class Initialized
INFO - 2017-03-15 00:38:01 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:38:01 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:38:01 --> Utf8 Class Initialized
INFO - 2017-03-15 00:38:01 --> URI Class Initialized
DEBUG - 2017-03-15 00:38:01 --> No URI present. Default controller set.
INFO - 2017-03-15 00:38:01 --> Router Class Initialized
INFO - 2017-03-15 00:38:01 --> Output Class Initialized
INFO - 2017-03-15 00:38:02 --> Security Class Initialized
DEBUG - 2017-03-15 00:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:38:02 --> Input Class Initialized
INFO - 2017-03-15 00:38:02 --> Language Class Initialized
INFO - 2017-03-15 00:38:02 --> Loader Class Initialized
INFO - 2017-03-15 00:38:02 --> Database Driver Class Initialized
INFO - 2017-03-15 00:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:38:06 --> Controller Class Initialized
INFO - 2017-03-15 00:38:06 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:38:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:38:06 --> Final output sent to browser
DEBUG - 2017-03-15 00:38:06 --> Total execution time: 5.0170
INFO - 2017-03-15 00:38:09 --> Config Class Initialized
INFO - 2017-03-15 00:38:09 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:38:09 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:38:09 --> Utf8 Class Initialized
INFO - 2017-03-15 00:38:09 --> URI Class Initialized
INFO - 2017-03-15 00:38:09 --> Router Class Initialized
INFO - 2017-03-15 00:38:09 --> Output Class Initialized
INFO - 2017-03-15 00:38:09 --> Security Class Initialized
DEBUG - 2017-03-15 00:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:38:09 --> Input Class Initialized
INFO - 2017-03-15 00:38:09 --> Language Class Initialized
INFO - 2017-03-15 00:38:09 --> Loader Class Initialized
INFO - 2017-03-15 00:38:09 --> Database Driver Class Initialized
INFO - 2017-03-15 00:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:38:09 --> Controller Class Initialized
INFO - 2017-03-15 00:38:09 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:38:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:38:09 --> Final output sent to browser
DEBUG - 2017-03-15 00:38:09 --> Total execution time: 0.0140
INFO - 2017-03-15 00:38:14 --> Config Class Initialized
INFO - 2017-03-15 00:38:14 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:38:14 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:38:14 --> Utf8 Class Initialized
INFO - 2017-03-15 00:38:14 --> URI Class Initialized
INFO - 2017-03-15 00:38:14 --> Router Class Initialized
INFO - 2017-03-15 00:38:14 --> Output Class Initialized
INFO - 2017-03-15 00:38:14 --> Security Class Initialized
DEBUG - 2017-03-15 00:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:38:14 --> Input Class Initialized
INFO - 2017-03-15 00:38:14 --> Language Class Initialized
INFO - 2017-03-15 00:38:14 --> Loader Class Initialized
INFO - 2017-03-15 00:38:14 --> Database Driver Class Initialized
INFO - 2017-03-15 00:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:38:14 --> Controller Class Initialized
INFO - 2017-03-15 00:38:14 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:38:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:38:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-15 00:38:14 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-15 00:38:14 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-15 00:38:14 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-15 00:38:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:38:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:38:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:38:14 --> Final output sent to browser
DEBUG - 2017-03-15 00:38:14 --> Total execution time: 0.0896
INFO - 2017-03-15 00:38:15 --> Config Class Initialized
INFO - 2017-03-15 00:38:15 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:38:15 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:38:15 --> Utf8 Class Initialized
INFO - 2017-03-15 00:38:15 --> URI Class Initialized
INFO - 2017-03-15 00:38:15 --> Router Class Initialized
INFO - 2017-03-15 00:38:15 --> Output Class Initialized
INFO - 2017-03-15 00:38:15 --> Security Class Initialized
DEBUG - 2017-03-15 00:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:38:15 --> Input Class Initialized
INFO - 2017-03-15 00:38:15 --> Language Class Initialized
INFO - 2017-03-15 00:38:15 --> Loader Class Initialized
INFO - 2017-03-15 00:38:15 --> Database Driver Class Initialized
INFO - 2017-03-15 00:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:38:15 --> Controller Class Initialized
INFO - 2017-03-15 00:38:15 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:38:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:38:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:38:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:38:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:38:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:38:15 --> Final output sent to browser
DEBUG - 2017-03-15 00:38:15 --> Total execution time: 0.0137
INFO - 2017-03-15 00:38:41 --> Config Class Initialized
INFO - 2017-03-15 00:38:41 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:38:41 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:38:41 --> Utf8 Class Initialized
INFO - 2017-03-15 00:38:41 --> URI Class Initialized
INFO - 2017-03-15 00:38:41 --> Router Class Initialized
INFO - 2017-03-15 00:38:41 --> Output Class Initialized
INFO - 2017-03-15 00:38:41 --> Security Class Initialized
DEBUG - 2017-03-15 00:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:38:41 --> Input Class Initialized
INFO - 2017-03-15 00:38:41 --> Language Class Initialized
INFO - 2017-03-15 00:38:41 --> Loader Class Initialized
INFO - 2017-03-15 00:38:41 --> Database Driver Class Initialized
INFO - 2017-03-15 00:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:38:41 --> Controller Class Initialized
INFO - 2017-03-15 00:38:41 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:38:43 --> Config Class Initialized
INFO - 2017-03-15 00:38:43 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:38:43 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:38:43 --> Utf8 Class Initialized
INFO - 2017-03-15 00:38:43 --> URI Class Initialized
INFO - 2017-03-15 00:38:43 --> Router Class Initialized
INFO - 2017-03-15 00:38:43 --> Output Class Initialized
INFO - 2017-03-15 00:38:43 --> Security Class Initialized
DEBUG - 2017-03-15 00:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:38:43 --> Input Class Initialized
INFO - 2017-03-15 00:38:43 --> Language Class Initialized
INFO - 2017-03-15 00:38:43 --> Loader Class Initialized
INFO - 2017-03-15 00:38:43 --> Database Driver Class Initialized
INFO - 2017-03-15 00:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:38:43 --> Controller Class Initialized
INFO - 2017-03-15 00:38:43 --> Helper loaded: date_helper
DEBUG - 2017-03-15 00:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:38:43 --> Helper loaded: url_helper
INFO - 2017-03-15 00:38:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:38:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 00:38:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 00:38:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 00:38:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:38:43 --> Final output sent to browser
DEBUG - 2017-03-15 00:38:43 --> Total execution time: 0.1179
INFO - 2017-03-15 00:38:44 --> Config Class Initialized
INFO - 2017-03-15 00:38:44 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:38:44 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:38:44 --> Utf8 Class Initialized
INFO - 2017-03-15 00:38:44 --> URI Class Initialized
INFO - 2017-03-15 00:38:44 --> Router Class Initialized
INFO - 2017-03-15 00:38:44 --> Output Class Initialized
INFO - 2017-03-15 00:38:44 --> Security Class Initialized
DEBUG - 2017-03-15 00:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:38:44 --> Input Class Initialized
INFO - 2017-03-15 00:38:44 --> Language Class Initialized
INFO - 2017-03-15 00:38:44 --> Loader Class Initialized
INFO - 2017-03-15 00:38:44 --> Database Driver Class Initialized
INFO - 2017-03-15 00:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:38:44 --> Controller Class Initialized
INFO - 2017-03-15 00:38:44 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:38:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:38:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:38:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:38:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:38:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:38:44 --> Final output sent to browser
DEBUG - 2017-03-15 00:38:44 --> Total execution time: 0.1444
INFO - 2017-03-15 00:38:50 --> Config Class Initialized
INFO - 2017-03-15 00:38:50 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:38:50 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:38:50 --> Utf8 Class Initialized
INFO - 2017-03-15 00:38:50 --> URI Class Initialized
INFO - 2017-03-15 00:38:50 --> Router Class Initialized
INFO - 2017-03-15 00:38:50 --> Output Class Initialized
INFO - 2017-03-15 00:38:50 --> Security Class Initialized
DEBUG - 2017-03-15 00:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:38:50 --> Input Class Initialized
INFO - 2017-03-15 00:38:50 --> Language Class Initialized
INFO - 2017-03-15 00:38:50 --> Loader Class Initialized
INFO - 2017-03-15 00:38:50 --> Database Driver Class Initialized
INFO - 2017-03-15 00:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:38:50 --> Controller Class Initialized
INFO - 2017-03-15 00:38:50 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:38:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:38:50 --> Config Class Initialized
INFO - 2017-03-15 00:38:50 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:38:50 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:38:50 --> Utf8 Class Initialized
INFO - 2017-03-15 00:38:50 --> URI Class Initialized
INFO - 2017-03-15 00:38:50 --> Router Class Initialized
INFO - 2017-03-15 00:38:50 --> Output Class Initialized
INFO - 2017-03-15 00:38:50 --> Security Class Initialized
DEBUG - 2017-03-15 00:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:38:50 --> Input Class Initialized
INFO - 2017-03-15 00:38:50 --> Language Class Initialized
INFO - 2017-03-15 00:38:50 --> Loader Class Initialized
INFO - 2017-03-15 00:38:50 --> Database Driver Class Initialized
INFO - 2017-03-15 00:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:38:50 --> Controller Class Initialized
INFO - 2017-03-15 00:38:50 --> Helper loaded: date_helper
DEBUG - 2017-03-15 00:38:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:38:50 --> Helper loaded: url_helper
INFO - 2017-03-15 00:38:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:38:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 00:38:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 00:38:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 00:38:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:38:50 --> Final output sent to browser
DEBUG - 2017-03-15 00:38:50 --> Total execution time: 0.0135
INFO - 2017-03-15 00:38:51 --> Config Class Initialized
INFO - 2017-03-15 00:38:51 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:38:51 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:38:51 --> Utf8 Class Initialized
INFO - 2017-03-15 00:38:51 --> URI Class Initialized
INFO - 2017-03-15 00:38:51 --> Router Class Initialized
INFO - 2017-03-15 00:38:51 --> Output Class Initialized
INFO - 2017-03-15 00:38:51 --> Security Class Initialized
DEBUG - 2017-03-15 00:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:38:51 --> Input Class Initialized
INFO - 2017-03-15 00:38:51 --> Language Class Initialized
INFO - 2017-03-15 00:38:51 --> Loader Class Initialized
INFO - 2017-03-15 00:38:51 --> Database Driver Class Initialized
INFO - 2017-03-15 00:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:38:51 --> Controller Class Initialized
INFO - 2017-03-15 00:38:51 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:38:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:38:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:38:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:38:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:38:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:38:51 --> Final output sent to browser
DEBUG - 2017-03-15 00:38:51 --> Total execution time: 0.0139
INFO - 2017-03-15 00:38:59 --> Config Class Initialized
INFO - 2017-03-15 00:38:59 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:38:59 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:38:59 --> Utf8 Class Initialized
INFO - 2017-03-15 00:38:59 --> URI Class Initialized
DEBUG - 2017-03-15 00:38:59 --> No URI present. Default controller set.
INFO - 2017-03-15 00:38:59 --> Router Class Initialized
INFO - 2017-03-15 00:38:59 --> Output Class Initialized
INFO - 2017-03-15 00:38:59 --> Security Class Initialized
DEBUG - 2017-03-15 00:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:38:59 --> Input Class Initialized
INFO - 2017-03-15 00:38:59 --> Language Class Initialized
INFO - 2017-03-15 00:38:59 --> Loader Class Initialized
INFO - 2017-03-15 00:38:59 --> Database Driver Class Initialized
INFO - 2017-03-15 00:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:38:59 --> Controller Class Initialized
INFO - 2017-03-15 00:38:59 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:38:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:38:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:38:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:38:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:38:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:38:59 --> Final output sent to browser
DEBUG - 2017-03-15 00:38:59 --> Total execution time: 0.0543
INFO - 2017-03-15 00:39:01 --> Config Class Initialized
INFO - 2017-03-15 00:39:01 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:39:01 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:39:01 --> Utf8 Class Initialized
INFO - 2017-03-15 00:39:01 --> URI Class Initialized
INFO - 2017-03-15 00:39:01 --> Router Class Initialized
INFO - 2017-03-15 00:39:01 --> Output Class Initialized
INFO - 2017-03-15 00:39:01 --> Security Class Initialized
DEBUG - 2017-03-15 00:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:39:01 --> Input Class Initialized
INFO - 2017-03-15 00:39:01 --> Language Class Initialized
INFO - 2017-03-15 00:39:01 --> Loader Class Initialized
INFO - 2017-03-15 00:39:01 --> Database Driver Class Initialized
INFO - 2017-03-15 00:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:39:01 --> Controller Class Initialized
INFO - 2017-03-15 00:39:01 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:39:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:39:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:39:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:39:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:39:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:39:01 --> Final output sent to browser
DEBUG - 2017-03-15 00:39:01 --> Total execution time: 0.0138
INFO - 2017-03-15 00:39:22 --> Config Class Initialized
INFO - 2017-03-15 00:39:22 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:39:22 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:39:22 --> Utf8 Class Initialized
INFO - 2017-03-15 00:39:22 --> URI Class Initialized
DEBUG - 2017-03-15 00:39:22 --> No URI present. Default controller set.
INFO - 2017-03-15 00:39:22 --> Router Class Initialized
INFO - 2017-03-15 00:39:22 --> Output Class Initialized
INFO - 2017-03-15 00:39:22 --> Security Class Initialized
DEBUG - 2017-03-15 00:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:39:22 --> Input Class Initialized
INFO - 2017-03-15 00:39:22 --> Language Class Initialized
INFO - 2017-03-15 00:39:22 --> Loader Class Initialized
INFO - 2017-03-15 00:39:22 --> Database Driver Class Initialized
INFO - 2017-03-15 00:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:39:22 --> Controller Class Initialized
INFO - 2017-03-15 00:39:22 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:39:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:39:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:39:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:39:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:39:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:39:22 --> Final output sent to browser
DEBUG - 2017-03-15 00:39:22 --> Total execution time: 0.0138
INFO - 2017-03-15 00:39:24 --> Config Class Initialized
INFO - 2017-03-15 00:39:24 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:39:24 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:39:24 --> Utf8 Class Initialized
INFO - 2017-03-15 00:39:24 --> URI Class Initialized
INFO - 2017-03-15 00:39:24 --> Router Class Initialized
INFO - 2017-03-15 00:39:24 --> Output Class Initialized
INFO - 2017-03-15 00:39:24 --> Security Class Initialized
DEBUG - 2017-03-15 00:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:39:24 --> Input Class Initialized
INFO - 2017-03-15 00:39:24 --> Language Class Initialized
INFO - 2017-03-15 00:39:24 --> Loader Class Initialized
INFO - 2017-03-15 00:39:24 --> Database Driver Class Initialized
INFO - 2017-03-15 00:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:39:24 --> Controller Class Initialized
INFO - 2017-03-15 00:39:24 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:39:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:39:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:39:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:39:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:39:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:39:24 --> Final output sent to browser
DEBUG - 2017-03-15 00:39:24 --> Total execution time: 0.0141
INFO - 2017-03-15 00:39:26 --> Config Class Initialized
INFO - 2017-03-15 00:39:26 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:39:26 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:39:26 --> Utf8 Class Initialized
INFO - 2017-03-15 00:39:26 --> URI Class Initialized
INFO - 2017-03-15 00:39:26 --> Router Class Initialized
INFO - 2017-03-15 00:39:26 --> Output Class Initialized
INFO - 2017-03-15 00:39:26 --> Security Class Initialized
DEBUG - 2017-03-15 00:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:39:26 --> Input Class Initialized
INFO - 2017-03-15 00:39:26 --> Language Class Initialized
INFO - 2017-03-15 00:39:26 --> Loader Class Initialized
INFO - 2017-03-15 00:39:26 --> Database Driver Class Initialized
INFO - 2017-03-15 00:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:39:26 --> Controller Class Initialized
INFO - 2017-03-15 00:39:26 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:39:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:39:28 --> Config Class Initialized
INFO - 2017-03-15 00:39:28 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:39:28 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:39:28 --> Utf8 Class Initialized
INFO - 2017-03-15 00:39:28 --> URI Class Initialized
INFO - 2017-03-15 00:39:28 --> Router Class Initialized
INFO - 2017-03-15 00:39:28 --> Output Class Initialized
INFO - 2017-03-15 00:39:28 --> Security Class Initialized
DEBUG - 2017-03-15 00:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:39:28 --> Input Class Initialized
INFO - 2017-03-15 00:39:28 --> Language Class Initialized
INFO - 2017-03-15 00:39:28 --> Loader Class Initialized
INFO - 2017-03-15 00:39:28 --> Database Driver Class Initialized
INFO - 2017-03-15 00:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:39:28 --> Controller Class Initialized
INFO - 2017-03-15 00:39:28 --> Helper loaded: date_helper
DEBUG - 2017-03-15 00:39:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:39:28 --> Helper loaded: url_helper
INFO - 2017-03-15 00:39:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:39:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 00:39:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 00:39:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 00:39:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:39:28 --> Final output sent to browser
DEBUG - 2017-03-15 00:39:28 --> Total execution time: 1.1650
INFO - 2017-03-15 00:39:29 --> Config Class Initialized
INFO - 2017-03-15 00:39:29 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:39:29 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:39:29 --> Utf8 Class Initialized
INFO - 2017-03-15 00:39:29 --> URI Class Initialized
INFO - 2017-03-15 00:39:29 --> Router Class Initialized
INFO - 2017-03-15 00:39:29 --> Output Class Initialized
INFO - 2017-03-15 00:39:29 --> Security Class Initialized
DEBUG - 2017-03-15 00:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:39:29 --> Input Class Initialized
INFO - 2017-03-15 00:39:29 --> Language Class Initialized
INFO - 2017-03-15 00:39:29 --> Loader Class Initialized
INFO - 2017-03-15 00:39:29 --> Database Driver Class Initialized
INFO - 2017-03-15 00:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:39:29 --> Controller Class Initialized
INFO - 2017-03-15 00:39:29 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:39:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:39:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:39:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:39:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:39:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:39:29 --> Final output sent to browser
DEBUG - 2017-03-15 00:39:29 --> Total execution time: 0.0138
INFO - 2017-03-15 00:39:40 --> Config Class Initialized
INFO - 2017-03-15 00:39:40 --> Hooks Class Initialized
DEBUG - 2017-03-15 00:39:40 --> UTF-8 Support Enabled
INFO - 2017-03-15 00:39:40 --> Utf8 Class Initialized
INFO - 2017-03-15 00:39:40 --> URI Class Initialized
DEBUG - 2017-03-15 00:39:40 --> No URI present. Default controller set.
INFO - 2017-03-15 00:39:40 --> Router Class Initialized
INFO - 2017-03-15 00:39:40 --> Output Class Initialized
INFO - 2017-03-15 00:39:40 --> Security Class Initialized
DEBUG - 2017-03-15 00:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 00:39:41 --> Input Class Initialized
INFO - 2017-03-15 00:39:41 --> Language Class Initialized
INFO - 2017-03-15 00:39:41 --> Loader Class Initialized
INFO - 2017-03-15 00:39:41 --> Database Driver Class Initialized
INFO - 2017-03-15 00:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 00:39:41 --> Controller Class Initialized
INFO - 2017-03-15 00:39:41 --> Helper loaded: url_helper
DEBUG - 2017-03-15 00:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 00:39:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 00:39:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 00:39:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 00:39:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 00:39:42 --> Final output sent to browser
DEBUG - 2017-03-15 00:39:42 --> Total execution time: 2.0514
INFO - 2017-03-15 01:23:49 --> Config Class Initialized
INFO - 2017-03-15 01:23:49 --> Hooks Class Initialized
DEBUG - 2017-03-15 01:23:49 --> UTF-8 Support Enabled
INFO - 2017-03-15 01:23:49 --> Utf8 Class Initialized
INFO - 2017-03-15 01:23:49 --> URI Class Initialized
DEBUG - 2017-03-15 01:23:49 --> No URI present. Default controller set.
INFO - 2017-03-15 01:23:49 --> Router Class Initialized
INFO - 2017-03-15 01:23:50 --> Output Class Initialized
INFO - 2017-03-15 01:23:50 --> Security Class Initialized
DEBUG - 2017-03-15 01:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 01:23:50 --> Input Class Initialized
INFO - 2017-03-15 01:23:50 --> Language Class Initialized
INFO - 2017-03-15 01:23:50 --> Loader Class Initialized
INFO - 2017-03-15 01:23:50 --> Database Driver Class Initialized
INFO - 2017-03-15 01:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 01:23:50 --> Controller Class Initialized
INFO - 2017-03-15 01:23:50 --> Helper loaded: url_helper
DEBUG - 2017-03-15 01:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 01:23:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 01:23:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 01:23:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 01:23:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 01:23:51 --> Final output sent to browser
DEBUG - 2017-03-15 01:23:51 --> Total execution time: 1.4789
INFO - 2017-03-15 01:23:59 --> Config Class Initialized
INFO - 2017-03-15 01:23:59 --> Hooks Class Initialized
DEBUG - 2017-03-15 01:23:59 --> UTF-8 Support Enabled
INFO - 2017-03-15 01:23:59 --> Utf8 Class Initialized
INFO - 2017-03-15 01:23:59 --> URI Class Initialized
INFO - 2017-03-15 01:23:59 --> Router Class Initialized
INFO - 2017-03-15 01:23:59 --> Output Class Initialized
INFO - 2017-03-15 01:23:59 --> Security Class Initialized
DEBUG - 2017-03-15 01:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 01:23:59 --> Input Class Initialized
INFO - 2017-03-15 01:23:59 --> Language Class Initialized
INFO - 2017-03-15 01:23:59 --> Loader Class Initialized
INFO - 2017-03-15 01:23:59 --> Database Driver Class Initialized
INFO - 2017-03-15 01:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 01:23:59 --> Controller Class Initialized
INFO - 2017-03-15 01:23:59 --> Helper loaded: url_helper
DEBUG - 2017-03-15 01:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 01:24:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 01:24:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 01:24:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 01:24:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 01:24:00 --> Final output sent to browser
DEBUG - 2017-03-15 01:24:00 --> Total execution time: 1.2452
INFO - 2017-03-15 01:25:01 --> Config Class Initialized
INFO - 2017-03-15 01:25:01 --> Hooks Class Initialized
DEBUG - 2017-03-15 01:25:02 --> UTF-8 Support Enabled
INFO - 2017-03-15 01:25:02 --> Utf8 Class Initialized
INFO - 2017-03-15 01:25:02 --> URI Class Initialized
INFO - 2017-03-15 01:25:02 --> Router Class Initialized
INFO - 2017-03-15 01:25:02 --> Output Class Initialized
INFO - 2017-03-15 01:25:02 --> Security Class Initialized
DEBUG - 2017-03-15 01:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 01:25:02 --> Input Class Initialized
INFO - 2017-03-15 01:25:02 --> Language Class Initialized
INFO - 2017-03-15 01:25:02 --> Loader Class Initialized
INFO - 2017-03-15 01:25:02 --> Database Driver Class Initialized
INFO - 2017-03-15 01:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 01:25:02 --> Controller Class Initialized
INFO - 2017-03-15 01:25:02 --> Helper loaded: url_helper
DEBUG - 2017-03-15 01:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 01:25:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 01:25:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 01:25:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 01:25:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 01:25:03 --> Final output sent to browser
DEBUG - 2017-03-15 01:25:03 --> Total execution time: 1.3414
INFO - 2017-03-15 01:25:05 --> Config Class Initialized
INFO - 2017-03-15 01:25:05 --> Hooks Class Initialized
DEBUG - 2017-03-15 01:25:05 --> UTF-8 Support Enabled
INFO - 2017-03-15 01:25:05 --> Utf8 Class Initialized
INFO - 2017-03-15 01:25:05 --> URI Class Initialized
INFO - 2017-03-15 01:25:05 --> Router Class Initialized
INFO - 2017-03-15 01:25:05 --> Output Class Initialized
INFO - 2017-03-15 01:25:05 --> Security Class Initialized
DEBUG - 2017-03-15 01:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 01:25:05 --> Input Class Initialized
INFO - 2017-03-15 01:25:05 --> Language Class Initialized
INFO - 2017-03-15 01:25:05 --> Loader Class Initialized
INFO - 2017-03-15 01:25:05 --> Database Driver Class Initialized
INFO - 2017-03-15 01:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 01:25:05 --> Controller Class Initialized
INFO - 2017-03-15 01:25:05 --> Helper loaded: url_helper
DEBUG - 2017-03-15 01:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 01:25:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 01:25:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 01:25:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 01:25:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 01:25:05 --> Final output sent to browser
DEBUG - 2017-03-15 01:25:05 --> Total execution time: 0.0143
INFO - 2017-03-15 01:46:34 --> Config Class Initialized
INFO - 2017-03-15 01:46:34 --> Hooks Class Initialized
DEBUG - 2017-03-15 01:46:35 --> UTF-8 Support Enabled
INFO - 2017-03-15 01:46:35 --> Utf8 Class Initialized
INFO - 2017-03-15 01:46:35 --> URI Class Initialized
DEBUG - 2017-03-15 01:46:35 --> No URI present. Default controller set.
INFO - 2017-03-15 01:46:35 --> Router Class Initialized
INFO - 2017-03-15 01:46:35 --> Output Class Initialized
INFO - 2017-03-15 01:46:35 --> Security Class Initialized
DEBUG - 2017-03-15 01:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 01:46:35 --> Input Class Initialized
INFO - 2017-03-15 01:46:35 --> Language Class Initialized
INFO - 2017-03-15 01:46:35 --> Loader Class Initialized
INFO - 2017-03-15 01:46:35 --> Database Driver Class Initialized
INFO - 2017-03-15 01:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 01:46:36 --> Controller Class Initialized
INFO - 2017-03-15 01:46:36 --> Helper loaded: url_helper
DEBUG - 2017-03-15 01:46:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 01:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 01:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 01:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 01:46:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 01:46:36 --> Final output sent to browser
DEBUG - 2017-03-15 01:46:36 --> Total execution time: 1.4877
INFO - 2017-03-15 01:48:08 --> Config Class Initialized
INFO - 2017-03-15 01:48:08 --> Hooks Class Initialized
DEBUG - 2017-03-15 01:48:08 --> UTF-8 Support Enabled
INFO - 2017-03-15 01:48:08 --> Utf8 Class Initialized
INFO - 2017-03-15 01:48:08 --> URI Class Initialized
INFO - 2017-03-15 01:48:08 --> Router Class Initialized
INFO - 2017-03-15 01:48:08 --> Output Class Initialized
INFO - 2017-03-15 01:48:08 --> Security Class Initialized
DEBUG - 2017-03-15 01:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 01:48:09 --> Input Class Initialized
INFO - 2017-03-15 01:48:09 --> Language Class Initialized
INFO - 2017-03-15 01:48:09 --> Loader Class Initialized
INFO - 2017-03-15 01:48:09 --> Database Driver Class Initialized
INFO - 2017-03-15 01:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 01:48:09 --> Controller Class Initialized
INFO - 2017-03-15 01:48:09 --> Helper loaded: url_helper
DEBUG - 2017-03-15 01:48:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 01:48:11 --> Config Class Initialized
INFO - 2017-03-15 01:48:11 --> Hooks Class Initialized
DEBUG - 2017-03-15 01:48:11 --> UTF-8 Support Enabled
INFO - 2017-03-15 01:48:11 --> Utf8 Class Initialized
INFO - 2017-03-15 01:48:11 --> URI Class Initialized
INFO - 2017-03-15 01:48:11 --> Router Class Initialized
INFO - 2017-03-15 01:48:11 --> Output Class Initialized
INFO - 2017-03-15 01:48:11 --> Security Class Initialized
DEBUG - 2017-03-15 01:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 01:48:11 --> Input Class Initialized
INFO - 2017-03-15 01:48:11 --> Language Class Initialized
INFO - 2017-03-15 01:48:11 --> Loader Class Initialized
INFO - 2017-03-15 01:48:11 --> Database Driver Class Initialized
INFO - 2017-03-15 01:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 01:48:11 --> Controller Class Initialized
INFO - 2017-03-15 01:48:11 --> Helper loaded: date_helper
DEBUG - 2017-03-15 01:48:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 01:48:11 --> Helper loaded: url_helper
INFO - 2017-03-15 01:48:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 01:48:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 01:48:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 01:48:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 01:48:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 01:48:11 --> Final output sent to browser
DEBUG - 2017-03-15 01:48:11 --> Total execution time: 0.1694
INFO - 2017-03-15 01:48:32 --> Config Class Initialized
INFO - 2017-03-15 01:48:32 --> Hooks Class Initialized
DEBUG - 2017-03-15 01:48:32 --> UTF-8 Support Enabled
INFO - 2017-03-15 01:48:32 --> Utf8 Class Initialized
INFO - 2017-03-15 01:48:32 --> URI Class Initialized
INFO - 2017-03-15 01:48:32 --> Router Class Initialized
INFO - 2017-03-15 01:48:32 --> Output Class Initialized
INFO - 2017-03-15 01:48:32 --> Security Class Initialized
DEBUG - 2017-03-15 01:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 01:48:32 --> Input Class Initialized
INFO - 2017-03-15 01:48:32 --> Language Class Initialized
INFO - 2017-03-15 01:48:32 --> Loader Class Initialized
INFO - 2017-03-15 01:48:32 --> Database Driver Class Initialized
INFO - 2017-03-15 01:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 01:48:32 --> Controller Class Initialized
INFO - 2017-03-15 01:48:32 --> Helper loaded: url_helper
DEBUG - 2017-03-15 01:48:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 01:48:33 --> Config Class Initialized
INFO - 2017-03-15 01:48:33 --> Hooks Class Initialized
DEBUG - 2017-03-15 01:48:33 --> UTF-8 Support Enabled
INFO - 2017-03-15 01:48:33 --> Utf8 Class Initialized
INFO - 2017-03-15 01:48:33 --> URI Class Initialized
INFO - 2017-03-15 01:48:33 --> Router Class Initialized
INFO - 2017-03-15 01:48:33 --> Output Class Initialized
INFO - 2017-03-15 01:48:33 --> Security Class Initialized
DEBUG - 2017-03-15 01:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 01:48:33 --> Input Class Initialized
INFO - 2017-03-15 01:48:33 --> Language Class Initialized
INFO - 2017-03-15 01:48:33 --> Loader Class Initialized
INFO - 2017-03-15 01:48:33 --> Database Driver Class Initialized
INFO - 2017-03-15 01:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 01:48:33 --> Controller Class Initialized
INFO - 2017-03-15 01:48:33 --> Helper loaded: date_helper
DEBUG - 2017-03-15 01:48:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 01:48:33 --> Helper loaded: url_helper
INFO - 2017-03-15 01:48:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 01:48:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 01:48:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 01:48:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 01:48:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 01:48:33 --> Final output sent to browser
DEBUG - 2017-03-15 01:48:33 --> Total execution time: 0.0140
INFO - 2017-03-15 01:48:43 --> Config Class Initialized
INFO - 2017-03-15 01:48:43 --> Hooks Class Initialized
DEBUG - 2017-03-15 01:48:43 --> UTF-8 Support Enabled
INFO - 2017-03-15 01:48:43 --> Utf8 Class Initialized
INFO - 2017-03-15 01:48:43 --> URI Class Initialized
DEBUG - 2017-03-15 01:48:43 --> No URI present. Default controller set.
INFO - 2017-03-15 01:48:43 --> Router Class Initialized
INFO - 2017-03-15 01:48:43 --> Output Class Initialized
INFO - 2017-03-15 01:48:43 --> Security Class Initialized
DEBUG - 2017-03-15 01:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 01:48:43 --> Input Class Initialized
INFO - 2017-03-15 01:48:43 --> Language Class Initialized
INFO - 2017-03-15 01:48:43 --> Loader Class Initialized
INFO - 2017-03-15 01:48:43 --> Database Driver Class Initialized
INFO - 2017-03-15 01:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 01:48:43 --> Controller Class Initialized
INFO - 2017-03-15 01:48:43 --> Helper loaded: url_helper
DEBUG - 2017-03-15 01:48:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 01:48:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 01:48:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 01:48:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 01:48:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 01:48:43 --> Final output sent to browser
DEBUG - 2017-03-15 01:48:43 --> Total execution time: 0.0405
INFO - 2017-03-15 01:49:10 --> Config Class Initialized
INFO - 2017-03-15 01:49:10 --> Hooks Class Initialized
DEBUG - 2017-03-15 01:49:10 --> UTF-8 Support Enabled
INFO - 2017-03-15 01:49:10 --> Utf8 Class Initialized
INFO - 2017-03-15 01:49:10 --> URI Class Initialized
INFO - 2017-03-15 01:49:10 --> Router Class Initialized
INFO - 2017-03-15 01:49:10 --> Output Class Initialized
INFO - 2017-03-15 01:49:10 --> Security Class Initialized
DEBUG - 2017-03-15 01:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 01:49:11 --> Input Class Initialized
INFO - 2017-03-15 01:49:11 --> Language Class Initialized
INFO - 2017-03-15 01:49:11 --> Loader Class Initialized
INFO - 2017-03-15 01:49:11 --> Database Driver Class Initialized
INFO - 2017-03-15 01:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 01:49:11 --> Controller Class Initialized
INFO - 2017-03-15 01:49:11 --> Helper loaded: url_helper
DEBUG - 2017-03-15 01:49:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 01:49:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 01:49:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 01:49:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 01:49:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 01:49:11 --> Final output sent to browser
DEBUG - 2017-03-15 01:49:11 --> Total execution time: 1.2314
INFO - 2017-03-15 01:49:37 --> Config Class Initialized
INFO - 2017-03-15 01:49:37 --> Hooks Class Initialized
DEBUG - 2017-03-15 01:49:37 --> UTF-8 Support Enabled
INFO - 2017-03-15 01:49:37 --> Utf8 Class Initialized
INFO - 2017-03-15 01:49:37 --> URI Class Initialized
INFO - 2017-03-15 01:49:37 --> Router Class Initialized
INFO - 2017-03-15 01:49:37 --> Output Class Initialized
INFO - 2017-03-15 01:49:37 --> Security Class Initialized
DEBUG - 2017-03-15 01:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 01:49:37 --> Input Class Initialized
INFO - 2017-03-15 01:49:37 --> Language Class Initialized
INFO - 2017-03-15 01:49:37 --> Loader Class Initialized
INFO - 2017-03-15 01:49:37 --> Database Driver Class Initialized
INFO - 2017-03-15 01:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 01:49:37 --> Controller Class Initialized
INFO - 2017-03-15 01:49:37 --> Helper loaded: url_helper
DEBUG - 2017-03-15 01:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 01:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 01:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 01:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 01:49:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 01:49:37 --> Final output sent to browser
DEBUG - 2017-03-15 01:49:37 --> Total execution time: 0.0149
INFO - 2017-03-15 02:11:30 --> Config Class Initialized
INFO - 2017-03-15 02:11:30 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:11:30 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:11:30 --> Utf8 Class Initialized
INFO - 2017-03-15 02:11:30 --> URI Class Initialized
DEBUG - 2017-03-15 02:11:30 --> No URI present. Default controller set.
INFO - 2017-03-15 02:11:30 --> Router Class Initialized
INFO - 2017-03-15 02:11:30 --> Output Class Initialized
INFO - 2017-03-15 02:11:30 --> Security Class Initialized
DEBUG - 2017-03-15 02:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:11:31 --> Input Class Initialized
INFO - 2017-03-15 02:11:31 --> Language Class Initialized
INFO - 2017-03-15 02:11:31 --> Loader Class Initialized
INFO - 2017-03-15 02:11:31 --> Database Driver Class Initialized
INFO - 2017-03-15 02:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:11:31 --> Controller Class Initialized
INFO - 2017-03-15 02:11:31 --> Helper loaded: url_helper
DEBUG - 2017-03-15 02:11:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:11:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 02:11:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 02:11:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 02:11:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 02:11:32 --> Final output sent to browser
DEBUG - 2017-03-15 02:11:32 --> Total execution time: 1.4789
INFO - 2017-03-15 02:11:37 --> Config Class Initialized
INFO - 2017-03-15 02:11:37 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:11:37 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:11:37 --> Utf8 Class Initialized
INFO - 2017-03-15 02:11:37 --> URI Class Initialized
INFO - 2017-03-15 02:11:37 --> Router Class Initialized
INFO - 2017-03-15 02:11:37 --> Output Class Initialized
INFO - 2017-03-15 02:11:37 --> Security Class Initialized
DEBUG - 2017-03-15 02:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:11:37 --> Input Class Initialized
INFO - 2017-03-15 02:11:37 --> Language Class Initialized
INFO - 2017-03-15 02:11:37 --> Loader Class Initialized
INFO - 2017-03-15 02:11:37 --> Database Driver Class Initialized
INFO - 2017-03-15 02:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:11:37 --> Controller Class Initialized
INFO - 2017-03-15 02:11:37 --> Helper loaded: url_helper
DEBUG - 2017-03-15 02:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:11:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 02:11:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 02:11:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 02:11:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 02:11:37 --> Final output sent to browser
DEBUG - 2017-03-15 02:11:37 --> Total execution time: 0.0138
INFO - 2017-03-15 02:11:44 --> Config Class Initialized
INFO - 2017-03-15 02:11:44 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:11:44 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:11:44 --> Utf8 Class Initialized
INFO - 2017-03-15 02:11:44 --> URI Class Initialized
INFO - 2017-03-15 02:11:44 --> Router Class Initialized
INFO - 2017-03-15 02:11:44 --> Output Class Initialized
INFO - 2017-03-15 02:11:44 --> Security Class Initialized
DEBUG - 2017-03-15 02:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:11:44 --> Input Class Initialized
INFO - 2017-03-15 02:11:44 --> Language Class Initialized
INFO - 2017-03-15 02:11:44 --> Loader Class Initialized
INFO - 2017-03-15 02:11:44 --> Database Driver Class Initialized
INFO - 2017-03-15 02:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:11:44 --> Controller Class Initialized
INFO - 2017-03-15 02:11:44 --> Helper loaded: url_helper
DEBUG - 2017-03-15 02:11:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:11:46 --> Config Class Initialized
INFO - 2017-03-15 02:11:46 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:11:46 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:11:46 --> Utf8 Class Initialized
INFO - 2017-03-15 02:11:46 --> URI Class Initialized
INFO - 2017-03-15 02:11:46 --> Router Class Initialized
INFO - 2017-03-15 02:11:46 --> Output Class Initialized
INFO - 2017-03-15 02:11:46 --> Security Class Initialized
DEBUG - 2017-03-15 02:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:11:46 --> Input Class Initialized
INFO - 2017-03-15 02:11:46 --> Language Class Initialized
INFO - 2017-03-15 02:11:46 --> Loader Class Initialized
INFO - 2017-03-15 02:11:46 --> Database Driver Class Initialized
INFO - 2017-03-15 02:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:11:46 --> Controller Class Initialized
INFO - 2017-03-15 02:11:46 --> Helper loaded: date_helper
DEBUG - 2017-03-15 02:11:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:11:46 --> Helper loaded: url_helper
INFO - 2017-03-15 02:11:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 02:11:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 02:11:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 02:11:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 02:11:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 02:11:46 --> Final output sent to browser
DEBUG - 2017-03-15 02:11:46 --> Total execution time: 0.6044
INFO - 2017-03-15 02:11:47 --> Config Class Initialized
INFO - 2017-03-15 02:11:47 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:11:47 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:11:47 --> Utf8 Class Initialized
INFO - 2017-03-15 02:11:47 --> URI Class Initialized
INFO - 2017-03-15 02:11:47 --> Router Class Initialized
INFO - 2017-03-15 02:11:47 --> Output Class Initialized
INFO - 2017-03-15 02:11:47 --> Security Class Initialized
DEBUG - 2017-03-15 02:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:11:47 --> Input Class Initialized
INFO - 2017-03-15 02:11:47 --> Language Class Initialized
INFO - 2017-03-15 02:11:47 --> Loader Class Initialized
INFO - 2017-03-15 02:11:47 --> Database Driver Class Initialized
INFO - 2017-03-15 02:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:11:47 --> Controller Class Initialized
INFO - 2017-03-15 02:11:47 --> Helper loaded: url_helper
DEBUG - 2017-03-15 02:11:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:11:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 02:11:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 02:11:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 02:11:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 02:11:47 --> Final output sent to browser
DEBUG - 2017-03-15 02:11:47 --> Total execution time: 0.0139
INFO - 2017-03-15 02:13:54 --> Config Class Initialized
INFO - 2017-03-15 02:13:54 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:13:54 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:13:54 --> Utf8 Class Initialized
INFO - 2017-03-15 02:13:54 --> URI Class Initialized
DEBUG - 2017-03-15 02:13:54 --> No URI present. Default controller set.
INFO - 2017-03-15 02:13:54 --> Router Class Initialized
INFO - 2017-03-15 02:13:54 --> Output Class Initialized
INFO - 2017-03-15 02:13:54 --> Security Class Initialized
DEBUG - 2017-03-15 02:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:13:54 --> Input Class Initialized
INFO - 2017-03-15 02:13:54 --> Language Class Initialized
INFO - 2017-03-15 02:13:54 --> Loader Class Initialized
INFO - 2017-03-15 02:13:55 --> Database Driver Class Initialized
INFO - 2017-03-15 02:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:13:55 --> Controller Class Initialized
INFO - 2017-03-15 02:13:55 --> Helper loaded: url_helper
DEBUG - 2017-03-15 02:13:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:13:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 02:13:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 02:13:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 02:13:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 02:13:55 --> Final output sent to browser
DEBUG - 2017-03-15 02:13:55 --> Total execution time: 1.2204
INFO - 2017-03-15 02:13:59 --> Config Class Initialized
INFO - 2017-03-15 02:13:59 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:13:59 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:13:59 --> Utf8 Class Initialized
INFO - 2017-03-15 02:13:59 --> URI Class Initialized
INFO - 2017-03-15 02:13:59 --> Router Class Initialized
INFO - 2017-03-15 02:13:59 --> Output Class Initialized
INFO - 2017-03-15 02:13:59 --> Security Class Initialized
DEBUG - 2017-03-15 02:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:13:59 --> Input Class Initialized
INFO - 2017-03-15 02:13:59 --> Language Class Initialized
INFO - 2017-03-15 02:13:59 --> Loader Class Initialized
INFO - 2017-03-15 02:13:59 --> Database Driver Class Initialized
INFO - 2017-03-15 02:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:13:59 --> Controller Class Initialized
INFO - 2017-03-15 02:13:59 --> Helper loaded: url_helper
DEBUG - 2017-03-15 02:13:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:13:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 02:13:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 02:13:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 02:13:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 02:13:59 --> Final output sent to browser
DEBUG - 2017-03-15 02:13:59 --> Total execution time: 0.0145
INFO - 2017-03-15 02:14:06 --> Config Class Initialized
INFO - 2017-03-15 02:14:06 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:14:06 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:14:06 --> Utf8 Class Initialized
INFO - 2017-03-15 02:14:06 --> URI Class Initialized
INFO - 2017-03-15 02:14:06 --> Router Class Initialized
INFO - 2017-03-15 02:14:06 --> Output Class Initialized
INFO - 2017-03-15 02:14:06 --> Security Class Initialized
DEBUG - 2017-03-15 02:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:14:06 --> Input Class Initialized
INFO - 2017-03-15 02:14:06 --> Language Class Initialized
INFO - 2017-03-15 02:14:06 --> Loader Class Initialized
INFO - 2017-03-15 02:14:06 --> Database Driver Class Initialized
INFO - 2017-03-15 02:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:14:06 --> Controller Class Initialized
INFO - 2017-03-15 02:14:06 --> Helper loaded: url_helper
DEBUG - 2017-03-15 02:14:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:14:08 --> Config Class Initialized
INFO - 2017-03-15 02:14:08 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:14:08 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:14:08 --> Utf8 Class Initialized
INFO - 2017-03-15 02:14:08 --> URI Class Initialized
INFO - 2017-03-15 02:14:08 --> Router Class Initialized
INFO - 2017-03-15 02:14:08 --> Output Class Initialized
INFO - 2017-03-15 02:14:08 --> Security Class Initialized
DEBUG - 2017-03-15 02:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:14:08 --> Input Class Initialized
INFO - 2017-03-15 02:14:08 --> Language Class Initialized
INFO - 2017-03-15 02:14:08 --> Loader Class Initialized
INFO - 2017-03-15 02:14:08 --> Database Driver Class Initialized
INFO - 2017-03-15 02:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:14:08 --> Controller Class Initialized
INFO - 2017-03-15 02:14:08 --> Helper loaded: date_helper
DEBUG - 2017-03-15 02:14:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:14:08 --> Helper loaded: url_helper
INFO - 2017-03-15 02:14:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 02:14:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 02:14:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 02:14:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 02:14:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 02:14:08 --> Final output sent to browser
DEBUG - 2017-03-15 02:14:08 --> Total execution time: 0.1036
INFO - 2017-03-15 02:14:09 --> Config Class Initialized
INFO - 2017-03-15 02:14:09 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:14:09 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:14:09 --> Utf8 Class Initialized
INFO - 2017-03-15 02:14:09 --> URI Class Initialized
INFO - 2017-03-15 02:14:09 --> Router Class Initialized
INFO - 2017-03-15 02:14:09 --> Output Class Initialized
INFO - 2017-03-15 02:14:09 --> Security Class Initialized
DEBUG - 2017-03-15 02:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:14:09 --> Input Class Initialized
INFO - 2017-03-15 02:14:09 --> Language Class Initialized
INFO - 2017-03-15 02:14:09 --> Loader Class Initialized
INFO - 2017-03-15 02:14:09 --> Database Driver Class Initialized
INFO - 2017-03-15 02:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:14:09 --> Controller Class Initialized
INFO - 2017-03-15 02:14:09 --> Helper loaded: url_helper
DEBUG - 2017-03-15 02:14:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:14:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 02:14:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 02:14:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 02:14:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 02:14:09 --> Final output sent to browser
DEBUG - 2017-03-15 02:14:09 --> Total execution time: 0.0138
INFO - 2017-03-15 02:14:18 --> Config Class Initialized
INFO - 2017-03-15 02:14:18 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:14:18 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:14:18 --> Utf8 Class Initialized
INFO - 2017-03-15 02:14:18 --> URI Class Initialized
DEBUG - 2017-03-15 02:14:18 --> No URI present. Default controller set.
INFO - 2017-03-15 02:14:18 --> Router Class Initialized
INFO - 2017-03-15 02:14:18 --> Output Class Initialized
INFO - 2017-03-15 02:14:18 --> Security Class Initialized
DEBUG - 2017-03-15 02:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:14:18 --> Input Class Initialized
INFO - 2017-03-15 02:14:18 --> Language Class Initialized
INFO - 2017-03-15 02:14:19 --> Loader Class Initialized
INFO - 2017-03-15 02:14:19 --> Database Driver Class Initialized
INFO - 2017-03-15 02:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:14:19 --> Controller Class Initialized
INFO - 2017-03-15 02:14:19 --> Helper loaded: url_helper
DEBUG - 2017-03-15 02:14:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:14:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 02:14:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 02:14:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 02:14:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 02:14:19 --> Final output sent to browser
DEBUG - 2017-03-15 02:14:19 --> Total execution time: 1.3439
INFO - 2017-03-15 02:14:21 --> Config Class Initialized
INFO - 2017-03-15 02:14:21 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:14:21 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:14:21 --> Utf8 Class Initialized
INFO - 2017-03-15 02:14:21 --> URI Class Initialized
INFO - 2017-03-15 02:14:21 --> Router Class Initialized
INFO - 2017-03-15 02:14:22 --> Output Class Initialized
INFO - 2017-03-15 02:14:22 --> Security Class Initialized
DEBUG - 2017-03-15 02:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:14:22 --> Input Class Initialized
INFO - 2017-03-15 02:14:22 --> Language Class Initialized
INFO - 2017-03-15 02:14:22 --> Loader Class Initialized
INFO - 2017-03-15 02:14:22 --> Database Driver Class Initialized
INFO - 2017-03-15 02:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:14:22 --> Controller Class Initialized
INFO - 2017-03-15 02:14:22 --> Helper loaded: url_helper
DEBUG - 2017-03-15 02:14:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 02:14:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 02:14:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 02:14:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 02:14:23 --> Final output sent to browser
DEBUG - 2017-03-15 02:14:23 --> Total execution time: 1.3069
INFO - 2017-03-15 02:14:41 --> Config Class Initialized
INFO - 2017-03-15 02:14:41 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:14:41 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:14:41 --> Utf8 Class Initialized
INFO - 2017-03-15 02:14:41 --> URI Class Initialized
INFO - 2017-03-15 02:14:41 --> Router Class Initialized
INFO - 2017-03-15 02:14:41 --> Output Class Initialized
INFO - 2017-03-15 02:14:41 --> Security Class Initialized
DEBUG - 2017-03-15 02:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:14:41 --> Input Class Initialized
INFO - 2017-03-15 02:14:41 --> Language Class Initialized
INFO - 2017-03-15 02:14:41 --> Loader Class Initialized
INFO - 2017-03-15 02:14:42 --> Database Driver Class Initialized
INFO - 2017-03-15 02:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:14:42 --> Controller Class Initialized
INFO - 2017-03-15 02:14:42 --> Helper loaded: url_helper
DEBUG - 2017-03-15 02:14:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:14:43 --> Config Class Initialized
INFO - 2017-03-15 02:14:43 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:14:43 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:14:43 --> Utf8 Class Initialized
INFO - 2017-03-15 02:14:43 --> URI Class Initialized
INFO - 2017-03-15 02:14:43 --> Router Class Initialized
INFO - 2017-03-15 02:14:43 --> Output Class Initialized
INFO - 2017-03-15 02:14:43 --> Security Class Initialized
DEBUG - 2017-03-15 02:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:14:43 --> Input Class Initialized
INFO - 2017-03-15 02:14:43 --> Language Class Initialized
INFO - 2017-03-15 02:14:43 --> Loader Class Initialized
INFO - 2017-03-15 02:14:43 --> Database Driver Class Initialized
INFO - 2017-03-15 02:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:14:43 --> Controller Class Initialized
INFO - 2017-03-15 02:14:44 --> Helper loaded: date_helper
DEBUG - 2017-03-15 02:14:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:14:44 --> Helper loaded: url_helper
INFO - 2017-03-15 02:14:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 02:14:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 02:14:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 02:14:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 02:14:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 02:14:44 --> Final output sent to browser
DEBUG - 2017-03-15 02:14:44 --> Total execution time: 0.1268
INFO - 2017-03-15 02:14:45 --> Config Class Initialized
INFO - 2017-03-15 02:14:45 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:14:45 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:14:45 --> Utf8 Class Initialized
INFO - 2017-03-15 02:14:45 --> URI Class Initialized
INFO - 2017-03-15 02:14:45 --> Router Class Initialized
INFO - 2017-03-15 02:14:45 --> Output Class Initialized
INFO - 2017-03-15 02:14:45 --> Security Class Initialized
DEBUG - 2017-03-15 02:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:14:45 --> Input Class Initialized
INFO - 2017-03-15 02:14:45 --> Language Class Initialized
INFO - 2017-03-15 02:14:45 --> Loader Class Initialized
INFO - 2017-03-15 02:14:45 --> Database Driver Class Initialized
INFO - 2017-03-15 02:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:14:45 --> Controller Class Initialized
INFO - 2017-03-15 02:14:45 --> Helper loaded: url_helper
DEBUG - 2017-03-15 02:14:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:14:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 02:14:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 02:14:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 02:14:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 02:14:45 --> Final output sent to browser
DEBUG - 2017-03-15 02:14:45 --> Total execution time: 0.0428
INFO - 2017-03-15 02:14:47 --> Config Class Initialized
INFO - 2017-03-15 02:14:47 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:14:47 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:14:47 --> Utf8 Class Initialized
INFO - 2017-03-15 02:14:47 --> URI Class Initialized
DEBUG - 2017-03-15 02:14:47 --> No URI present. Default controller set.
INFO - 2017-03-15 02:14:47 --> Router Class Initialized
INFO - 2017-03-15 02:14:47 --> Output Class Initialized
INFO - 2017-03-15 02:14:47 --> Security Class Initialized
DEBUG - 2017-03-15 02:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:14:47 --> Input Class Initialized
INFO - 2017-03-15 02:14:47 --> Language Class Initialized
INFO - 2017-03-15 02:14:47 --> Loader Class Initialized
INFO - 2017-03-15 02:14:47 --> Database Driver Class Initialized
INFO - 2017-03-15 02:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:14:47 --> Controller Class Initialized
INFO - 2017-03-15 02:14:47 --> Helper loaded: url_helper
DEBUG - 2017-03-15 02:14:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:14:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 02:14:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 02:14:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 02:14:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 02:14:47 --> Final output sent to browser
DEBUG - 2017-03-15 02:14:47 --> Total execution time: 0.0139
INFO - 2017-03-15 02:14:48 --> Config Class Initialized
INFO - 2017-03-15 02:14:48 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:14:48 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:14:48 --> Utf8 Class Initialized
INFO - 2017-03-15 02:14:48 --> URI Class Initialized
INFO - 2017-03-15 02:14:48 --> Router Class Initialized
INFO - 2017-03-15 02:14:48 --> Output Class Initialized
INFO - 2017-03-15 02:14:48 --> Security Class Initialized
DEBUG - 2017-03-15 02:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:14:48 --> Input Class Initialized
INFO - 2017-03-15 02:14:48 --> Language Class Initialized
INFO - 2017-03-15 02:14:48 --> Loader Class Initialized
INFO - 2017-03-15 02:14:48 --> Database Driver Class Initialized
INFO - 2017-03-15 02:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:14:48 --> Controller Class Initialized
INFO - 2017-03-15 02:14:48 --> Helper loaded: url_helper
DEBUG - 2017-03-15 02:14:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:14:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 02:14:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 02:14:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 02:14:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 02:14:48 --> Final output sent to browser
DEBUG - 2017-03-15 02:14:48 --> Total execution time: 0.0146
INFO - 2017-03-15 02:15:08 --> Config Class Initialized
INFO - 2017-03-15 02:15:08 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:15:08 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:15:08 --> Utf8 Class Initialized
INFO - 2017-03-15 02:15:08 --> URI Class Initialized
INFO - 2017-03-15 02:15:08 --> Router Class Initialized
INFO - 2017-03-15 02:15:08 --> Output Class Initialized
INFO - 2017-03-15 02:15:08 --> Security Class Initialized
DEBUG - 2017-03-15 02:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:15:08 --> Input Class Initialized
INFO - 2017-03-15 02:15:08 --> Language Class Initialized
INFO - 2017-03-15 02:15:08 --> Loader Class Initialized
INFO - 2017-03-15 02:15:08 --> Database Driver Class Initialized
INFO - 2017-03-15 02:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:15:08 --> Controller Class Initialized
INFO - 2017-03-15 02:15:08 --> Helper loaded: url_helper
DEBUG - 2017-03-15 02:15:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:15:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 02:15:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 02:15:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 02:15:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 02:15:08 --> Final output sent to browser
DEBUG - 2017-03-15 02:15:08 --> Total execution time: 0.0146
INFO - 2017-03-15 02:15:10 --> Config Class Initialized
INFO - 2017-03-15 02:15:10 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:15:10 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:15:10 --> Utf8 Class Initialized
INFO - 2017-03-15 02:15:10 --> URI Class Initialized
INFO - 2017-03-15 02:15:10 --> Router Class Initialized
INFO - 2017-03-15 02:15:10 --> Output Class Initialized
INFO - 2017-03-15 02:15:10 --> Security Class Initialized
DEBUG - 2017-03-15 02:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:15:10 --> Input Class Initialized
INFO - 2017-03-15 02:15:10 --> Language Class Initialized
INFO - 2017-03-15 02:15:10 --> Loader Class Initialized
INFO - 2017-03-15 02:15:10 --> Database Driver Class Initialized
INFO - 2017-03-15 02:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:15:10 --> Controller Class Initialized
INFO - 2017-03-15 02:15:10 --> Helper loaded: url_helper
DEBUG - 2017-03-15 02:15:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:15:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 02:15:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 02:15:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 02:15:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 02:15:10 --> Final output sent to browser
DEBUG - 2017-03-15 02:15:10 --> Total execution time: 0.0300
INFO - 2017-03-15 02:37:06 --> Config Class Initialized
INFO - 2017-03-15 02:37:06 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:37:06 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:37:06 --> Utf8 Class Initialized
INFO - 2017-03-15 02:37:06 --> URI Class Initialized
DEBUG - 2017-03-15 02:37:06 --> No URI present. Default controller set.
INFO - 2017-03-15 02:37:06 --> Router Class Initialized
INFO - 2017-03-15 02:37:06 --> Output Class Initialized
INFO - 2017-03-15 02:37:06 --> Security Class Initialized
DEBUG - 2017-03-15 02:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:37:06 --> Input Class Initialized
INFO - 2017-03-15 02:37:06 --> Language Class Initialized
INFO - 2017-03-15 02:37:06 --> Loader Class Initialized
INFO - 2017-03-15 02:37:07 --> Database Driver Class Initialized
INFO - 2017-03-15 02:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:37:07 --> Controller Class Initialized
INFO - 2017-03-15 02:37:07 --> Helper loaded: url_helper
DEBUG - 2017-03-15 02:37:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:37:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 02:37:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 02:37:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 02:37:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 02:37:08 --> Final output sent to browser
DEBUG - 2017-03-15 02:37:08 --> Total execution time: 1.4926
INFO - 2017-03-15 02:37:17 --> Config Class Initialized
INFO - 2017-03-15 02:37:17 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:37:17 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:37:17 --> Utf8 Class Initialized
INFO - 2017-03-15 02:37:17 --> URI Class Initialized
INFO - 2017-03-15 02:37:17 --> Router Class Initialized
INFO - 2017-03-15 02:37:17 --> Output Class Initialized
INFO - 2017-03-15 02:37:17 --> Security Class Initialized
DEBUG - 2017-03-15 02:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:37:17 --> Input Class Initialized
INFO - 2017-03-15 02:37:17 --> Language Class Initialized
INFO - 2017-03-15 02:37:17 --> Loader Class Initialized
INFO - 2017-03-15 02:37:17 --> Database Driver Class Initialized
INFO - 2017-03-15 02:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:37:17 --> Controller Class Initialized
INFO - 2017-03-15 02:37:17 --> Helper loaded: url_helper
DEBUG - 2017-03-15 02:37:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:37:18 --> Config Class Initialized
INFO - 2017-03-15 02:37:18 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:37:18 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:37:18 --> Utf8 Class Initialized
INFO - 2017-03-15 02:37:18 --> URI Class Initialized
INFO - 2017-03-15 02:37:18 --> Router Class Initialized
INFO - 2017-03-15 02:37:18 --> Output Class Initialized
INFO - 2017-03-15 02:37:18 --> Security Class Initialized
DEBUG - 2017-03-15 02:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:37:18 --> Input Class Initialized
INFO - 2017-03-15 02:37:18 --> Language Class Initialized
INFO - 2017-03-15 02:37:18 --> Loader Class Initialized
INFO - 2017-03-15 02:37:18 --> Database Driver Class Initialized
INFO - 2017-03-15 02:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:37:18 --> Controller Class Initialized
INFO - 2017-03-15 02:37:18 --> Helper loaded: url_helper
DEBUG - 2017-03-15 02:37:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:37:19 --> Config Class Initialized
INFO - 2017-03-15 02:37:19 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:37:19 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:37:19 --> Utf8 Class Initialized
INFO - 2017-03-15 02:37:19 --> URI Class Initialized
INFO - 2017-03-15 02:37:19 --> Router Class Initialized
INFO - 2017-03-15 02:37:19 --> Output Class Initialized
INFO - 2017-03-15 02:37:19 --> Security Class Initialized
DEBUG - 2017-03-15 02:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:37:19 --> Input Class Initialized
INFO - 2017-03-15 02:37:19 --> Language Class Initialized
INFO - 2017-03-15 02:37:19 --> Loader Class Initialized
INFO - 2017-03-15 02:37:19 --> Database Driver Class Initialized
INFO - 2017-03-15 02:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:37:19 --> Controller Class Initialized
INFO - 2017-03-15 02:37:19 --> Helper loaded: date_helper
DEBUG - 2017-03-15 02:37:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:37:19 --> Helper loaded: url_helper
INFO - 2017-03-15 02:37:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 02:37:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 02:37:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 02:37:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 02:37:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 02:37:19 --> Final output sent to browser
DEBUG - 2017-03-15 02:37:19 --> Total execution time: 0.0914
INFO - 2017-03-15 02:37:24 --> Config Class Initialized
INFO - 2017-03-15 02:37:24 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:37:24 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:37:24 --> Utf8 Class Initialized
INFO - 2017-03-15 02:37:24 --> URI Class Initialized
DEBUG - 2017-03-15 02:37:24 --> No URI present. Default controller set.
INFO - 2017-03-15 02:37:24 --> Router Class Initialized
INFO - 2017-03-15 02:37:24 --> Output Class Initialized
INFO - 2017-03-15 02:37:24 --> Security Class Initialized
DEBUG - 2017-03-15 02:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:37:24 --> Input Class Initialized
INFO - 2017-03-15 02:37:24 --> Language Class Initialized
INFO - 2017-03-15 02:37:24 --> Loader Class Initialized
INFO - 2017-03-15 02:37:24 --> Database Driver Class Initialized
INFO - 2017-03-15 02:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:37:24 --> Controller Class Initialized
INFO - 2017-03-15 02:37:24 --> Helper loaded: url_helper
DEBUG - 2017-03-15 02:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:37:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 02:37:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 02:37:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 02:37:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 02:37:24 --> Final output sent to browser
DEBUG - 2017-03-15 02:37:24 --> Total execution time: 0.0137
INFO - 2017-03-15 02:48:35 --> Config Class Initialized
INFO - 2017-03-15 02:48:35 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:48:35 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:48:35 --> Utf8 Class Initialized
INFO - 2017-03-15 02:48:35 --> URI Class Initialized
INFO - 2017-03-15 02:48:35 --> Router Class Initialized
INFO - 2017-03-15 02:48:35 --> Output Class Initialized
INFO - 2017-03-15 02:48:35 --> Security Class Initialized
DEBUG - 2017-03-15 02:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:48:36 --> Input Class Initialized
INFO - 2017-03-15 02:48:36 --> Language Class Initialized
INFO - 2017-03-15 02:48:36 --> Loader Class Initialized
INFO - 2017-03-15 02:48:36 --> Database Driver Class Initialized
INFO - 2017-03-15 02:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:48:36 --> Controller Class Initialized
INFO - 2017-03-15 02:48:36 --> Helper loaded: date_helper
DEBUG - 2017-03-15 02:48:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:48:36 --> Helper loaded: url_helper
INFO - 2017-03-15 02:48:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 02:48:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 02:48:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 02:48:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 02:48:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 02:48:37 --> Final output sent to browser
DEBUG - 2017-03-15 02:48:37 --> Total execution time: 1.4293
INFO - 2017-03-15 02:48:38 --> Config Class Initialized
INFO - 2017-03-15 02:48:38 --> Hooks Class Initialized
DEBUG - 2017-03-15 02:48:38 --> UTF-8 Support Enabled
INFO - 2017-03-15 02:48:38 --> Utf8 Class Initialized
INFO - 2017-03-15 02:48:38 --> URI Class Initialized
INFO - 2017-03-15 02:48:38 --> Router Class Initialized
INFO - 2017-03-15 02:48:38 --> Output Class Initialized
INFO - 2017-03-15 02:48:38 --> Security Class Initialized
DEBUG - 2017-03-15 02:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 02:48:38 --> Input Class Initialized
INFO - 2017-03-15 02:48:38 --> Language Class Initialized
INFO - 2017-03-15 02:48:38 --> Loader Class Initialized
INFO - 2017-03-15 02:48:38 --> Database Driver Class Initialized
INFO - 2017-03-15 02:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 02:48:38 --> Controller Class Initialized
INFO - 2017-03-15 02:48:38 --> Helper loaded: url_helper
DEBUG - 2017-03-15 02:48:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 02:48:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 02:48:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 02:48:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 02:48:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 02:48:39 --> Final output sent to browser
DEBUG - 2017-03-15 02:48:39 --> Total execution time: 0.2439
INFO - 2017-03-15 03:01:15 --> Config Class Initialized
INFO - 2017-03-15 03:01:15 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:01:15 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:01:15 --> Utf8 Class Initialized
INFO - 2017-03-15 03:01:15 --> URI Class Initialized
DEBUG - 2017-03-15 03:01:15 --> No URI present. Default controller set.
INFO - 2017-03-15 03:01:15 --> Router Class Initialized
INFO - 2017-03-15 03:01:15 --> Output Class Initialized
INFO - 2017-03-15 03:01:15 --> Security Class Initialized
DEBUG - 2017-03-15 03:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:01:15 --> Input Class Initialized
INFO - 2017-03-15 03:01:15 --> Language Class Initialized
INFO - 2017-03-15 03:01:15 --> Loader Class Initialized
INFO - 2017-03-15 03:01:16 --> Database Driver Class Initialized
INFO - 2017-03-15 03:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:01:16 --> Controller Class Initialized
INFO - 2017-03-15 03:01:16 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:01:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:01:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:01:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:01:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:01:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:01:16 --> Final output sent to browser
DEBUG - 2017-03-15 03:01:16 --> Total execution time: 1.2337
INFO - 2017-03-15 03:01:22 --> Config Class Initialized
INFO - 2017-03-15 03:01:22 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:01:22 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:01:22 --> Utf8 Class Initialized
INFO - 2017-03-15 03:01:22 --> URI Class Initialized
DEBUG - 2017-03-15 03:01:22 --> No URI present. Default controller set.
INFO - 2017-03-15 03:01:22 --> Router Class Initialized
INFO - 2017-03-15 03:01:22 --> Output Class Initialized
INFO - 2017-03-15 03:01:22 --> Security Class Initialized
DEBUG - 2017-03-15 03:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:01:22 --> Input Class Initialized
INFO - 2017-03-15 03:01:22 --> Language Class Initialized
INFO - 2017-03-15 03:01:22 --> Loader Class Initialized
INFO - 2017-03-15 03:01:22 --> Database Driver Class Initialized
INFO - 2017-03-15 03:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:01:23 --> Controller Class Initialized
INFO - 2017-03-15 03:01:23 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:01:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:01:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:01:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:01:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:01:23 --> Final output sent to browser
DEBUG - 2017-03-15 03:01:23 --> Total execution time: 0.4781
INFO - 2017-03-15 03:01:34 --> Config Class Initialized
INFO - 2017-03-15 03:01:34 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:01:34 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:01:34 --> Utf8 Class Initialized
INFO - 2017-03-15 03:01:34 --> URI Class Initialized
INFO - 2017-03-15 03:01:34 --> Router Class Initialized
INFO - 2017-03-15 03:01:34 --> Output Class Initialized
INFO - 2017-03-15 03:01:34 --> Security Class Initialized
DEBUG - 2017-03-15 03:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:01:34 --> Input Class Initialized
INFO - 2017-03-15 03:01:34 --> Language Class Initialized
INFO - 2017-03-15 03:01:34 --> Loader Class Initialized
INFO - 2017-03-15 03:01:35 --> Database Driver Class Initialized
INFO - 2017-03-15 03:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:01:35 --> Controller Class Initialized
INFO - 2017-03-15 03:01:35 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:01:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:01:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:01:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:01:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:01:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:01:35 --> Final output sent to browser
DEBUG - 2017-03-15 03:01:35 --> Total execution time: 1.2738
INFO - 2017-03-15 03:01:54 --> Config Class Initialized
INFO - 2017-03-15 03:01:54 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:01:54 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:01:54 --> Utf8 Class Initialized
INFO - 2017-03-15 03:01:54 --> URI Class Initialized
INFO - 2017-03-15 03:01:54 --> Router Class Initialized
INFO - 2017-03-15 03:01:54 --> Output Class Initialized
INFO - 2017-03-15 03:01:54 --> Security Class Initialized
DEBUG - 2017-03-15 03:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:01:54 --> Input Class Initialized
INFO - 2017-03-15 03:01:54 --> Language Class Initialized
INFO - 2017-03-15 03:01:54 --> Loader Class Initialized
INFO - 2017-03-15 03:01:54 --> Database Driver Class Initialized
INFO - 2017-03-15 03:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:01:54 --> Controller Class Initialized
INFO - 2017-03-15 03:01:54 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:01:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:01:56 --> Config Class Initialized
INFO - 2017-03-15 03:01:56 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:01:56 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:01:56 --> Utf8 Class Initialized
INFO - 2017-03-15 03:01:56 --> URI Class Initialized
INFO - 2017-03-15 03:01:56 --> Router Class Initialized
INFO - 2017-03-15 03:01:56 --> Output Class Initialized
INFO - 2017-03-15 03:01:56 --> Security Class Initialized
DEBUG - 2017-03-15 03:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:01:56 --> Input Class Initialized
INFO - 2017-03-15 03:01:56 --> Language Class Initialized
INFO - 2017-03-15 03:01:56 --> Loader Class Initialized
INFO - 2017-03-15 03:01:56 --> Database Driver Class Initialized
INFO - 2017-03-15 03:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:01:56 --> Controller Class Initialized
INFO - 2017-03-15 03:01:56 --> Helper loaded: date_helper
DEBUG - 2017-03-15 03:01:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:01:56 --> Helper loaded: url_helper
INFO - 2017-03-15 03:01:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:01:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 03:01:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 03:01:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 03:01:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:01:56 --> Final output sent to browser
DEBUG - 2017-03-15 03:01:56 --> Total execution time: 0.1233
INFO - 2017-03-15 03:01:58 --> Config Class Initialized
INFO - 2017-03-15 03:01:58 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:01:58 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:01:58 --> Utf8 Class Initialized
INFO - 2017-03-15 03:01:58 --> URI Class Initialized
INFO - 2017-03-15 03:01:58 --> Router Class Initialized
INFO - 2017-03-15 03:01:58 --> Output Class Initialized
INFO - 2017-03-15 03:01:58 --> Security Class Initialized
DEBUG - 2017-03-15 03:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:01:58 --> Input Class Initialized
INFO - 2017-03-15 03:01:58 --> Language Class Initialized
INFO - 2017-03-15 03:01:58 --> Loader Class Initialized
INFO - 2017-03-15 03:01:58 --> Database Driver Class Initialized
INFO - 2017-03-15 03:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:01:58 --> Controller Class Initialized
INFO - 2017-03-15 03:01:58 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:01:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:01:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:01:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:01:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:01:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:01:58 --> Final output sent to browser
DEBUG - 2017-03-15 03:01:58 --> Total execution time: 0.0140
INFO - 2017-03-15 03:17:44 --> Config Class Initialized
INFO - 2017-03-15 03:17:44 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:17:44 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:17:44 --> Utf8 Class Initialized
INFO - 2017-03-15 03:17:44 --> URI Class Initialized
DEBUG - 2017-03-15 03:17:44 --> No URI present. Default controller set.
INFO - 2017-03-15 03:17:44 --> Router Class Initialized
INFO - 2017-03-15 03:17:44 --> Output Class Initialized
INFO - 2017-03-15 03:17:44 --> Security Class Initialized
DEBUG - 2017-03-15 03:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:17:44 --> Input Class Initialized
INFO - 2017-03-15 03:17:44 --> Language Class Initialized
INFO - 2017-03-15 03:17:44 --> Loader Class Initialized
INFO - 2017-03-15 03:17:45 --> Database Driver Class Initialized
INFO - 2017-03-15 03:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:17:45 --> Controller Class Initialized
INFO - 2017-03-15 03:17:45 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:17:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:17:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:17:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:17:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:17:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:17:46 --> Final output sent to browser
DEBUG - 2017-03-15 03:17:46 --> Total execution time: 1.5302
INFO - 2017-03-15 03:17:51 --> Config Class Initialized
INFO - 2017-03-15 03:17:51 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:17:51 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:17:51 --> Utf8 Class Initialized
INFO - 2017-03-15 03:17:51 --> URI Class Initialized
INFO - 2017-03-15 03:17:51 --> Router Class Initialized
INFO - 2017-03-15 03:17:51 --> Output Class Initialized
INFO - 2017-03-15 03:17:51 --> Security Class Initialized
DEBUG - 2017-03-15 03:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:17:51 --> Input Class Initialized
INFO - 2017-03-15 03:17:51 --> Language Class Initialized
INFO - 2017-03-15 03:17:51 --> Loader Class Initialized
INFO - 2017-03-15 03:17:51 --> Database Driver Class Initialized
INFO - 2017-03-15 03:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:17:51 --> Controller Class Initialized
INFO - 2017-03-15 03:17:51 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:17:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:17:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:17:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:17:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:17:51 --> Final output sent to browser
DEBUG - 2017-03-15 03:17:51 --> Total execution time: 0.0141
INFO - 2017-03-15 03:18:40 --> Config Class Initialized
INFO - 2017-03-15 03:18:40 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:18:40 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:18:40 --> Utf8 Class Initialized
INFO - 2017-03-15 03:18:40 --> URI Class Initialized
INFO - 2017-03-15 03:18:40 --> Router Class Initialized
INFO - 2017-03-15 03:18:40 --> Output Class Initialized
INFO - 2017-03-15 03:18:40 --> Security Class Initialized
DEBUG - 2017-03-15 03:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:18:41 --> Input Class Initialized
INFO - 2017-03-15 03:18:41 --> Language Class Initialized
INFO - 2017-03-15 03:18:41 --> Loader Class Initialized
INFO - 2017-03-15 03:18:41 --> Database Driver Class Initialized
INFO - 2017-03-15 03:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:18:41 --> Controller Class Initialized
INFO - 2017-03-15 03:18:41 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:18:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:18:44 --> Config Class Initialized
INFO - 2017-03-15 03:18:44 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:18:44 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:18:44 --> Utf8 Class Initialized
INFO - 2017-03-15 03:18:44 --> URI Class Initialized
INFO - 2017-03-15 03:18:44 --> Router Class Initialized
INFO - 2017-03-15 03:18:44 --> Output Class Initialized
INFO - 2017-03-15 03:18:44 --> Security Class Initialized
DEBUG - 2017-03-15 03:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:18:44 --> Input Class Initialized
INFO - 2017-03-15 03:18:44 --> Language Class Initialized
INFO - 2017-03-15 03:18:44 --> Loader Class Initialized
INFO - 2017-03-15 03:18:44 --> Database Driver Class Initialized
INFO - 2017-03-15 03:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:18:45 --> Controller Class Initialized
INFO - 2017-03-15 03:18:45 --> Helper loaded: date_helper
DEBUG - 2017-03-15 03:18:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:18:45 --> Helper loaded: url_helper
INFO - 2017-03-15 03:18:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:18:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 03:18:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 03:18:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 03:18:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:18:45 --> Final output sent to browser
DEBUG - 2017-03-15 03:18:45 --> Total execution time: 1.1071
INFO - 2017-03-15 03:18:47 --> Config Class Initialized
INFO - 2017-03-15 03:18:47 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:18:47 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:18:47 --> Utf8 Class Initialized
INFO - 2017-03-15 03:18:47 --> URI Class Initialized
INFO - 2017-03-15 03:18:47 --> Router Class Initialized
INFO - 2017-03-15 03:18:47 --> Output Class Initialized
INFO - 2017-03-15 03:18:47 --> Security Class Initialized
DEBUG - 2017-03-15 03:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:18:47 --> Input Class Initialized
INFO - 2017-03-15 03:18:47 --> Language Class Initialized
INFO - 2017-03-15 03:18:47 --> Loader Class Initialized
INFO - 2017-03-15 03:18:48 --> Database Driver Class Initialized
INFO - 2017-03-15 03:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:18:48 --> Controller Class Initialized
INFO - 2017-03-15 03:18:48 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:18:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:18:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:18:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:18:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:18:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:18:48 --> Final output sent to browser
DEBUG - 2017-03-15 03:18:48 --> Total execution time: 1.2484
INFO - 2017-03-15 03:18:50 --> Config Class Initialized
INFO - 2017-03-15 03:18:50 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:18:50 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:18:50 --> Utf8 Class Initialized
INFO - 2017-03-15 03:18:50 --> URI Class Initialized
INFO - 2017-03-15 03:18:50 --> Router Class Initialized
INFO - 2017-03-15 03:18:50 --> Output Class Initialized
INFO - 2017-03-15 03:18:50 --> Security Class Initialized
DEBUG - 2017-03-15 03:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:18:50 --> Input Class Initialized
INFO - 2017-03-15 03:18:50 --> Language Class Initialized
INFO - 2017-03-15 03:18:50 --> Loader Class Initialized
INFO - 2017-03-15 03:18:50 --> Database Driver Class Initialized
INFO - 2017-03-15 03:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:18:50 --> Controller Class Initialized
INFO - 2017-03-15 03:18:50 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:18:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:18:52 --> Config Class Initialized
INFO - 2017-03-15 03:18:52 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:18:52 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:18:52 --> Utf8 Class Initialized
INFO - 2017-03-15 03:18:52 --> URI Class Initialized
INFO - 2017-03-15 03:18:52 --> Router Class Initialized
INFO - 2017-03-15 03:18:52 --> Output Class Initialized
INFO - 2017-03-15 03:18:52 --> Security Class Initialized
DEBUG - 2017-03-15 03:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:18:52 --> Input Class Initialized
INFO - 2017-03-15 03:18:52 --> Language Class Initialized
INFO - 2017-03-15 03:18:52 --> Loader Class Initialized
INFO - 2017-03-15 03:18:52 --> Database Driver Class Initialized
INFO - 2017-03-15 03:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:18:52 --> Controller Class Initialized
INFO - 2017-03-15 03:18:52 --> Helper loaded: date_helper
DEBUG - 2017-03-15 03:18:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:18:52 --> Helper loaded: url_helper
INFO - 2017-03-15 03:18:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:18:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 03:18:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 03:18:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 03:18:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:18:52 --> Final output sent to browser
DEBUG - 2017-03-15 03:18:52 --> Total execution time: 0.0967
INFO - 2017-03-15 03:18:54 --> Config Class Initialized
INFO - 2017-03-15 03:18:54 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:18:54 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:18:54 --> Utf8 Class Initialized
INFO - 2017-03-15 03:18:54 --> URI Class Initialized
INFO - 2017-03-15 03:18:54 --> Router Class Initialized
INFO - 2017-03-15 03:18:54 --> Output Class Initialized
INFO - 2017-03-15 03:18:54 --> Security Class Initialized
DEBUG - 2017-03-15 03:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:18:54 --> Input Class Initialized
INFO - 2017-03-15 03:18:54 --> Language Class Initialized
INFO - 2017-03-15 03:18:54 --> Loader Class Initialized
INFO - 2017-03-15 03:18:54 --> Database Driver Class Initialized
INFO - 2017-03-15 03:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:18:54 --> Controller Class Initialized
INFO - 2017-03-15 03:18:54 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:18:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:18:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:18:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:18:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:18:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:18:54 --> Final output sent to browser
DEBUG - 2017-03-15 03:18:54 --> Total execution time: 0.0144
INFO - 2017-03-15 03:18:57 --> Config Class Initialized
INFO - 2017-03-15 03:18:57 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:18:57 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:18:57 --> Utf8 Class Initialized
INFO - 2017-03-15 03:18:57 --> URI Class Initialized
DEBUG - 2017-03-15 03:18:57 --> No URI present. Default controller set.
INFO - 2017-03-15 03:18:57 --> Router Class Initialized
INFO - 2017-03-15 03:18:57 --> Output Class Initialized
INFO - 2017-03-15 03:18:57 --> Security Class Initialized
DEBUG - 2017-03-15 03:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:18:57 --> Input Class Initialized
INFO - 2017-03-15 03:18:57 --> Language Class Initialized
INFO - 2017-03-15 03:18:57 --> Loader Class Initialized
INFO - 2017-03-15 03:18:58 --> Database Driver Class Initialized
INFO - 2017-03-15 03:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:18:58 --> Controller Class Initialized
INFO - 2017-03-15 03:18:58 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:18:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:18:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:18:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:18:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:18:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:18:58 --> Final output sent to browser
DEBUG - 2017-03-15 03:18:58 --> Total execution time: 1.3376
INFO - 2017-03-15 03:19:02 --> Config Class Initialized
INFO - 2017-03-15 03:19:02 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:19:02 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:19:02 --> Utf8 Class Initialized
INFO - 2017-03-15 03:19:02 --> URI Class Initialized
INFO - 2017-03-15 03:19:02 --> Router Class Initialized
INFO - 2017-03-15 03:19:02 --> Output Class Initialized
INFO - 2017-03-15 03:19:02 --> Security Class Initialized
DEBUG - 2017-03-15 03:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:19:02 --> Input Class Initialized
INFO - 2017-03-15 03:19:02 --> Language Class Initialized
INFO - 2017-03-15 03:19:03 --> Loader Class Initialized
INFO - 2017-03-15 03:19:03 --> Database Driver Class Initialized
INFO - 2017-03-15 03:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:19:03 --> Controller Class Initialized
INFO - 2017-03-15 03:19:03 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:19:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:19:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:19:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:19:04 --> Final output sent to browser
DEBUG - 2017-03-15 03:19:04 --> Total execution time: 1.4705
INFO - 2017-03-15 03:19:29 --> Config Class Initialized
INFO - 2017-03-15 03:19:29 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:19:29 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:19:29 --> Utf8 Class Initialized
INFO - 2017-03-15 03:19:29 --> URI Class Initialized
INFO - 2017-03-15 03:19:29 --> Router Class Initialized
INFO - 2017-03-15 03:19:29 --> Output Class Initialized
INFO - 2017-03-15 03:19:29 --> Security Class Initialized
DEBUG - 2017-03-15 03:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:19:29 --> Input Class Initialized
INFO - 2017-03-15 03:19:29 --> Language Class Initialized
INFO - 2017-03-15 03:19:29 --> Loader Class Initialized
INFO - 2017-03-15 03:19:29 --> Database Driver Class Initialized
INFO - 2017-03-15 03:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:19:29 --> Controller Class Initialized
INFO - 2017-03-15 03:19:29 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:19:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:19:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:19:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:19:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:19:29 --> Final output sent to browser
DEBUG - 2017-03-15 03:19:29 --> Total execution time: 0.4033
INFO - 2017-03-15 03:19:34 --> Config Class Initialized
INFO - 2017-03-15 03:19:34 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:19:34 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:19:34 --> Utf8 Class Initialized
INFO - 2017-03-15 03:19:34 --> URI Class Initialized
INFO - 2017-03-15 03:19:34 --> Router Class Initialized
INFO - 2017-03-15 03:19:34 --> Output Class Initialized
INFO - 2017-03-15 03:19:34 --> Security Class Initialized
DEBUG - 2017-03-15 03:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:19:34 --> Input Class Initialized
INFO - 2017-03-15 03:19:34 --> Language Class Initialized
INFO - 2017-03-15 03:19:34 --> Loader Class Initialized
INFO - 2017-03-15 03:19:34 --> Database Driver Class Initialized
INFO - 2017-03-15 03:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:19:34 --> Controller Class Initialized
INFO - 2017-03-15 03:19:34 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:19:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:19:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:19:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:19:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:19:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:19:34 --> Final output sent to browser
DEBUG - 2017-03-15 03:19:34 --> Total execution time: 0.0138
INFO - 2017-03-15 03:19:37 --> Config Class Initialized
INFO - 2017-03-15 03:19:37 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:19:37 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:19:37 --> Utf8 Class Initialized
INFO - 2017-03-15 03:19:37 --> URI Class Initialized
INFO - 2017-03-15 03:19:37 --> Router Class Initialized
INFO - 2017-03-15 03:19:37 --> Output Class Initialized
INFO - 2017-03-15 03:19:37 --> Security Class Initialized
DEBUG - 2017-03-15 03:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:19:37 --> Input Class Initialized
INFO - 2017-03-15 03:19:37 --> Language Class Initialized
INFO - 2017-03-15 03:19:37 --> Loader Class Initialized
INFO - 2017-03-15 03:19:37 --> Database Driver Class Initialized
INFO - 2017-03-15 03:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:19:37 --> Controller Class Initialized
INFO - 2017-03-15 03:19:37 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:19:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:19:40 --> Config Class Initialized
INFO - 2017-03-15 03:19:40 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:19:40 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:19:40 --> Utf8 Class Initialized
INFO - 2017-03-15 03:19:40 --> URI Class Initialized
INFO - 2017-03-15 03:19:40 --> Router Class Initialized
INFO - 2017-03-15 03:19:40 --> Output Class Initialized
INFO - 2017-03-15 03:19:40 --> Security Class Initialized
DEBUG - 2017-03-15 03:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:19:40 --> Input Class Initialized
INFO - 2017-03-15 03:19:40 --> Language Class Initialized
INFO - 2017-03-15 03:19:40 --> Loader Class Initialized
INFO - 2017-03-15 03:19:40 --> Database Driver Class Initialized
INFO - 2017-03-15 03:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:19:40 --> Controller Class Initialized
INFO - 2017-03-15 03:19:40 --> Helper loaded: date_helper
DEBUG - 2017-03-15 03:19:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:19:40 --> Helper loaded: url_helper
INFO - 2017-03-15 03:19:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:19:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 03:19:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 03:19:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 03:19:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:19:40 --> Final output sent to browser
DEBUG - 2017-03-15 03:19:40 --> Total execution time: 0.1024
INFO - 2017-03-15 03:19:41 --> Config Class Initialized
INFO - 2017-03-15 03:19:41 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:19:41 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:19:41 --> Utf8 Class Initialized
INFO - 2017-03-15 03:19:41 --> URI Class Initialized
INFO - 2017-03-15 03:19:41 --> Router Class Initialized
INFO - 2017-03-15 03:19:41 --> Output Class Initialized
INFO - 2017-03-15 03:19:41 --> Security Class Initialized
DEBUG - 2017-03-15 03:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:19:41 --> Input Class Initialized
INFO - 2017-03-15 03:19:41 --> Language Class Initialized
INFO - 2017-03-15 03:19:41 --> Loader Class Initialized
INFO - 2017-03-15 03:19:41 --> Database Driver Class Initialized
INFO - 2017-03-15 03:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:19:41 --> Controller Class Initialized
INFO - 2017-03-15 03:19:41 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:19:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:19:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:19:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:19:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:19:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:19:41 --> Final output sent to browser
DEBUG - 2017-03-15 03:19:41 --> Total execution time: 0.0147
INFO - 2017-03-15 03:19:51 --> Config Class Initialized
INFO - 2017-03-15 03:19:51 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:19:51 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:19:51 --> Utf8 Class Initialized
INFO - 2017-03-15 03:19:51 --> URI Class Initialized
DEBUG - 2017-03-15 03:19:51 --> No URI present. Default controller set.
INFO - 2017-03-15 03:19:51 --> Router Class Initialized
INFO - 2017-03-15 03:19:51 --> Output Class Initialized
INFO - 2017-03-15 03:19:51 --> Security Class Initialized
DEBUG - 2017-03-15 03:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:19:51 --> Input Class Initialized
INFO - 2017-03-15 03:19:51 --> Language Class Initialized
INFO - 2017-03-15 03:19:51 --> Loader Class Initialized
INFO - 2017-03-15 03:19:51 --> Database Driver Class Initialized
INFO - 2017-03-15 03:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:19:51 --> Controller Class Initialized
INFO - 2017-03-15 03:19:51 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:19:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:19:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:19:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:19:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:19:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:19:51 --> Final output sent to browser
DEBUG - 2017-03-15 03:19:51 --> Total execution time: 0.0141
INFO - 2017-03-15 03:19:52 --> Config Class Initialized
INFO - 2017-03-15 03:19:52 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:19:52 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:19:52 --> Utf8 Class Initialized
INFO - 2017-03-15 03:19:52 --> URI Class Initialized
INFO - 2017-03-15 03:19:52 --> Router Class Initialized
INFO - 2017-03-15 03:19:52 --> Output Class Initialized
INFO - 2017-03-15 03:19:52 --> Security Class Initialized
DEBUG - 2017-03-15 03:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:19:52 --> Input Class Initialized
INFO - 2017-03-15 03:19:52 --> Language Class Initialized
INFO - 2017-03-15 03:19:52 --> Loader Class Initialized
INFO - 2017-03-15 03:19:53 --> Database Driver Class Initialized
INFO - 2017-03-15 03:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:19:53 --> Controller Class Initialized
INFO - 2017-03-15 03:19:53 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:19:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:19:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:19:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:19:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:19:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:19:53 --> Final output sent to browser
DEBUG - 2017-03-15 03:19:53 --> Total execution time: 0.0728
INFO - 2017-03-15 03:20:05 --> Config Class Initialized
INFO - 2017-03-15 03:20:05 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:20:05 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:20:05 --> Utf8 Class Initialized
INFO - 2017-03-15 03:20:05 --> URI Class Initialized
INFO - 2017-03-15 03:20:05 --> Router Class Initialized
INFO - 2017-03-15 03:20:05 --> Output Class Initialized
INFO - 2017-03-15 03:20:05 --> Security Class Initialized
DEBUG - 2017-03-15 03:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:20:05 --> Input Class Initialized
INFO - 2017-03-15 03:20:05 --> Language Class Initialized
INFO - 2017-03-15 03:20:05 --> Loader Class Initialized
INFO - 2017-03-15 03:20:05 --> Database Driver Class Initialized
INFO - 2017-03-15 03:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:20:05 --> Controller Class Initialized
INFO - 2017-03-15 03:20:05 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:20:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:20:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:20:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:20:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:20:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:20:05 --> Final output sent to browser
DEBUG - 2017-03-15 03:20:05 --> Total execution time: 0.0149
INFO - 2017-03-15 03:20:08 --> Config Class Initialized
INFO - 2017-03-15 03:20:08 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:20:08 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:20:08 --> Utf8 Class Initialized
INFO - 2017-03-15 03:20:08 --> URI Class Initialized
INFO - 2017-03-15 03:20:08 --> Router Class Initialized
INFO - 2017-03-15 03:20:08 --> Output Class Initialized
INFO - 2017-03-15 03:20:08 --> Security Class Initialized
DEBUG - 2017-03-15 03:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:20:08 --> Input Class Initialized
INFO - 2017-03-15 03:20:08 --> Language Class Initialized
INFO - 2017-03-15 03:20:08 --> Loader Class Initialized
INFO - 2017-03-15 03:20:08 --> Database Driver Class Initialized
INFO - 2017-03-15 03:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:20:08 --> Controller Class Initialized
INFO - 2017-03-15 03:20:08 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:20:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:20:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:20:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:20:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:20:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:20:08 --> Final output sent to browser
DEBUG - 2017-03-15 03:20:08 --> Total execution time: 0.0146
INFO - 2017-03-15 03:20:23 --> Config Class Initialized
INFO - 2017-03-15 03:20:23 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:20:23 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:20:23 --> Utf8 Class Initialized
INFO - 2017-03-15 03:20:23 --> URI Class Initialized
INFO - 2017-03-15 03:20:23 --> Router Class Initialized
INFO - 2017-03-15 03:20:23 --> Output Class Initialized
INFO - 2017-03-15 03:20:23 --> Security Class Initialized
DEBUG - 2017-03-15 03:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:20:23 --> Input Class Initialized
INFO - 2017-03-15 03:20:23 --> Language Class Initialized
INFO - 2017-03-15 03:20:23 --> Loader Class Initialized
INFO - 2017-03-15 03:20:23 --> Database Driver Class Initialized
INFO - 2017-03-15 03:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:20:23 --> Controller Class Initialized
INFO - 2017-03-15 03:20:23 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:20:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:20:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:20:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:20:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:20:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:20:23 --> Final output sent to browser
DEBUG - 2017-03-15 03:20:23 --> Total execution time: 0.0143
INFO - 2017-03-15 03:20:27 --> Config Class Initialized
INFO - 2017-03-15 03:20:27 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:20:27 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:20:27 --> Utf8 Class Initialized
INFO - 2017-03-15 03:20:27 --> URI Class Initialized
INFO - 2017-03-15 03:20:27 --> Router Class Initialized
INFO - 2017-03-15 03:20:27 --> Output Class Initialized
INFO - 2017-03-15 03:20:27 --> Security Class Initialized
DEBUG - 2017-03-15 03:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:20:27 --> Input Class Initialized
INFO - 2017-03-15 03:20:27 --> Language Class Initialized
INFO - 2017-03-15 03:20:27 --> Loader Class Initialized
INFO - 2017-03-15 03:20:27 --> Database Driver Class Initialized
INFO - 2017-03-15 03:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:20:27 --> Controller Class Initialized
INFO - 2017-03-15 03:20:27 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:20:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:20:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:20:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:20:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:20:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:20:27 --> Final output sent to browser
DEBUG - 2017-03-15 03:20:27 --> Total execution time: 0.0141
INFO - 2017-03-15 03:20:33 --> Config Class Initialized
INFO - 2017-03-15 03:20:33 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:20:33 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:20:33 --> Utf8 Class Initialized
INFO - 2017-03-15 03:20:33 --> URI Class Initialized
INFO - 2017-03-15 03:20:33 --> Router Class Initialized
INFO - 2017-03-15 03:20:33 --> Output Class Initialized
INFO - 2017-03-15 03:20:33 --> Security Class Initialized
DEBUG - 2017-03-15 03:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:20:33 --> Input Class Initialized
INFO - 2017-03-15 03:20:33 --> Language Class Initialized
INFO - 2017-03-15 03:20:33 --> Loader Class Initialized
INFO - 2017-03-15 03:20:33 --> Database Driver Class Initialized
INFO - 2017-03-15 03:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:20:33 --> Controller Class Initialized
INFO - 2017-03-15 03:20:33 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:20:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:20:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:20:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:20:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:20:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:20:33 --> Final output sent to browser
DEBUG - 2017-03-15 03:20:33 --> Total execution time: 0.0143
INFO - 2017-03-15 03:20:36 --> Config Class Initialized
INFO - 2017-03-15 03:20:36 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:20:36 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:20:36 --> Utf8 Class Initialized
INFO - 2017-03-15 03:20:36 --> URI Class Initialized
INFO - 2017-03-15 03:20:36 --> Router Class Initialized
INFO - 2017-03-15 03:20:36 --> Output Class Initialized
INFO - 2017-03-15 03:20:36 --> Security Class Initialized
DEBUG - 2017-03-15 03:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:20:36 --> Input Class Initialized
INFO - 2017-03-15 03:20:36 --> Language Class Initialized
INFO - 2017-03-15 03:20:36 --> Loader Class Initialized
INFO - 2017-03-15 03:20:36 --> Database Driver Class Initialized
INFO - 2017-03-15 03:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:20:36 --> Controller Class Initialized
INFO - 2017-03-15 03:20:36 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:20:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:20:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:20:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:20:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:20:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:20:36 --> Final output sent to browser
DEBUG - 2017-03-15 03:20:36 --> Total execution time: 0.0139
INFO - 2017-03-15 03:20:38 --> Config Class Initialized
INFO - 2017-03-15 03:20:38 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:20:38 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:20:38 --> Utf8 Class Initialized
INFO - 2017-03-15 03:20:38 --> URI Class Initialized
INFO - 2017-03-15 03:20:38 --> Router Class Initialized
INFO - 2017-03-15 03:20:38 --> Output Class Initialized
INFO - 2017-03-15 03:20:38 --> Security Class Initialized
DEBUG - 2017-03-15 03:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:20:38 --> Input Class Initialized
INFO - 2017-03-15 03:20:38 --> Language Class Initialized
INFO - 2017-03-15 03:20:38 --> Loader Class Initialized
INFO - 2017-03-15 03:20:38 --> Database Driver Class Initialized
INFO - 2017-03-15 03:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:20:38 --> Controller Class Initialized
INFO - 2017-03-15 03:20:38 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:20:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:20:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:20:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:20:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:20:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:20:38 --> Final output sent to browser
DEBUG - 2017-03-15 03:20:38 --> Total execution time: 0.0148
INFO - 2017-03-15 03:20:42 --> Config Class Initialized
INFO - 2017-03-15 03:20:42 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:20:42 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:20:42 --> Utf8 Class Initialized
INFO - 2017-03-15 03:20:42 --> URI Class Initialized
INFO - 2017-03-15 03:20:42 --> Router Class Initialized
INFO - 2017-03-15 03:20:42 --> Output Class Initialized
INFO - 2017-03-15 03:20:42 --> Security Class Initialized
DEBUG - 2017-03-15 03:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:20:42 --> Input Class Initialized
INFO - 2017-03-15 03:20:42 --> Language Class Initialized
INFO - 2017-03-15 03:20:42 --> Loader Class Initialized
INFO - 2017-03-15 03:20:42 --> Database Driver Class Initialized
INFO - 2017-03-15 03:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:20:42 --> Controller Class Initialized
INFO - 2017-03-15 03:20:42 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:20:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:20:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:20:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:20:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:20:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:20:42 --> Final output sent to browser
DEBUG - 2017-03-15 03:20:42 --> Total execution time: 0.0140
INFO - 2017-03-15 03:21:05 --> Config Class Initialized
INFO - 2017-03-15 03:21:05 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:21:05 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:21:05 --> Utf8 Class Initialized
INFO - 2017-03-15 03:21:05 --> URI Class Initialized
INFO - 2017-03-15 03:21:05 --> Router Class Initialized
INFO - 2017-03-15 03:21:05 --> Output Class Initialized
INFO - 2017-03-15 03:21:05 --> Security Class Initialized
DEBUG - 2017-03-15 03:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:21:05 --> Input Class Initialized
INFO - 2017-03-15 03:21:05 --> Language Class Initialized
INFO - 2017-03-15 03:21:05 --> Loader Class Initialized
INFO - 2017-03-15 03:21:05 --> Database Driver Class Initialized
INFO - 2017-03-15 03:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:21:06 --> Controller Class Initialized
INFO - 2017-03-15 03:21:06 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:21:06 --> Final output sent to browser
DEBUG - 2017-03-15 03:21:06 --> Total execution time: 1.5108
INFO - 2017-03-15 03:21:11 --> Config Class Initialized
INFO - 2017-03-15 03:21:11 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:21:11 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:21:11 --> Utf8 Class Initialized
INFO - 2017-03-15 03:21:11 --> URI Class Initialized
INFO - 2017-03-15 03:21:11 --> Router Class Initialized
INFO - 2017-03-15 03:21:11 --> Output Class Initialized
INFO - 2017-03-15 03:21:11 --> Security Class Initialized
DEBUG - 2017-03-15 03:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:21:11 --> Input Class Initialized
INFO - 2017-03-15 03:21:11 --> Language Class Initialized
INFO - 2017-03-15 03:21:11 --> Loader Class Initialized
INFO - 2017-03-15 03:21:11 --> Database Driver Class Initialized
INFO - 2017-03-15 03:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:21:11 --> Controller Class Initialized
INFO - 2017-03-15 03:21:11 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:21:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:21:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:21:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:21:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:21:11 --> Final output sent to browser
DEBUG - 2017-03-15 03:21:11 --> Total execution time: 0.0148
INFO - 2017-03-15 03:21:13 --> Config Class Initialized
INFO - 2017-03-15 03:21:13 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:21:13 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:21:13 --> Utf8 Class Initialized
INFO - 2017-03-15 03:21:13 --> URI Class Initialized
INFO - 2017-03-15 03:21:13 --> Router Class Initialized
INFO - 2017-03-15 03:21:13 --> Output Class Initialized
INFO - 2017-03-15 03:21:13 --> Security Class Initialized
DEBUG - 2017-03-15 03:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:21:13 --> Input Class Initialized
INFO - 2017-03-15 03:21:13 --> Language Class Initialized
INFO - 2017-03-15 03:21:13 --> Loader Class Initialized
INFO - 2017-03-15 03:21:13 --> Database Driver Class Initialized
INFO - 2017-03-15 03:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:21:13 --> Controller Class Initialized
INFO - 2017-03-15 03:21:13 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:21:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:21:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:21:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:21:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:21:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:21:13 --> Final output sent to browser
DEBUG - 2017-03-15 03:21:13 --> Total execution time: 0.0146
INFO - 2017-03-15 03:21:17 --> Config Class Initialized
INFO - 2017-03-15 03:21:17 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:21:17 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:21:17 --> Utf8 Class Initialized
INFO - 2017-03-15 03:21:17 --> URI Class Initialized
INFO - 2017-03-15 03:21:17 --> Router Class Initialized
INFO - 2017-03-15 03:21:17 --> Output Class Initialized
INFO - 2017-03-15 03:21:17 --> Security Class Initialized
DEBUG - 2017-03-15 03:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:21:17 --> Input Class Initialized
INFO - 2017-03-15 03:21:17 --> Language Class Initialized
INFO - 2017-03-15 03:21:17 --> Loader Class Initialized
INFO - 2017-03-15 03:21:17 --> Database Driver Class Initialized
INFO - 2017-03-15 03:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:21:17 --> Controller Class Initialized
INFO - 2017-03-15 03:21:17 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:21:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:21:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:21:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:21:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:21:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:21:17 --> Final output sent to browser
DEBUG - 2017-03-15 03:21:17 --> Total execution time: 0.0140
INFO - 2017-03-15 03:21:19 --> Config Class Initialized
INFO - 2017-03-15 03:21:19 --> Hooks Class Initialized
DEBUG - 2017-03-15 03:21:19 --> UTF-8 Support Enabled
INFO - 2017-03-15 03:21:19 --> Utf8 Class Initialized
INFO - 2017-03-15 03:21:19 --> URI Class Initialized
INFO - 2017-03-15 03:21:19 --> Router Class Initialized
INFO - 2017-03-15 03:21:19 --> Output Class Initialized
INFO - 2017-03-15 03:21:19 --> Security Class Initialized
DEBUG - 2017-03-15 03:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 03:21:19 --> Input Class Initialized
INFO - 2017-03-15 03:21:19 --> Language Class Initialized
INFO - 2017-03-15 03:21:19 --> Loader Class Initialized
INFO - 2017-03-15 03:21:19 --> Database Driver Class Initialized
INFO - 2017-03-15 03:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 03:21:19 --> Controller Class Initialized
INFO - 2017-03-15 03:21:19 --> Helper loaded: url_helper
DEBUG - 2017-03-15 03:21:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 03:21:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 03:21:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 03:21:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 03:21:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 03:21:19 --> Final output sent to browser
DEBUG - 2017-03-15 03:21:19 --> Total execution time: 0.0152
INFO - 2017-03-15 04:12:56 --> Config Class Initialized
INFO - 2017-03-15 04:12:56 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:12:56 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:12:56 --> Utf8 Class Initialized
INFO - 2017-03-15 04:12:56 --> URI Class Initialized
DEBUG - 2017-03-15 04:12:56 --> No URI present. Default controller set.
INFO - 2017-03-15 04:12:57 --> Router Class Initialized
INFO - 2017-03-15 04:12:57 --> Output Class Initialized
INFO - 2017-03-15 04:12:57 --> Security Class Initialized
DEBUG - 2017-03-15 04:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:12:57 --> Input Class Initialized
INFO - 2017-03-15 04:12:57 --> Language Class Initialized
INFO - 2017-03-15 04:12:57 --> Loader Class Initialized
INFO - 2017-03-15 04:12:57 --> Database Driver Class Initialized
INFO - 2017-03-15 04:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:12:57 --> Controller Class Initialized
INFO - 2017-03-15 04:12:57 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:12:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:12:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:12:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:12:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:12:58 --> Final output sent to browser
DEBUG - 2017-03-15 04:12:58 --> Total execution time: 1.4837
INFO - 2017-03-15 04:13:02 --> Config Class Initialized
INFO - 2017-03-15 04:13:02 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:13:02 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:13:02 --> Utf8 Class Initialized
INFO - 2017-03-15 04:13:02 --> URI Class Initialized
INFO - 2017-03-15 04:13:02 --> Router Class Initialized
INFO - 2017-03-15 04:13:02 --> Output Class Initialized
INFO - 2017-03-15 04:13:02 --> Security Class Initialized
DEBUG - 2017-03-15 04:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:13:02 --> Input Class Initialized
INFO - 2017-03-15 04:13:02 --> Language Class Initialized
INFO - 2017-03-15 04:13:02 --> Loader Class Initialized
INFO - 2017-03-15 04:13:02 --> Database Driver Class Initialized
INFO - 2017-03-15 04:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:13:02 --> Controller Class Initialized
INFO - 2017-03-15 04:13:02 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:13:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:13:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:13:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:13:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:13:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:13:02 --> Final output sent to browser
DEBUG - 2017-03-15 04:13:02 --> Total execution time: 0.0139
INFO - 2017-03-15 04:13:09 --> Config Class Initialized
INFO - 2017-03-15 04:13:09 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:13:09 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:13:09 --> Utf8 Class Initialized
INFO - 2017-03-15 04:13:09 --> URI Class Initialized
INFO - 2017-03-15 04:13:09 --> Router Class Initialized
INFO - 2017-03-15 04:13:09 --> Output Class Initialized
INFO - 2017-03-15 04:13:09 --> Security Class Initialized
DEBUG - 2017-03-15 04:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:13:09 --> Input Class Initialized
INFO - 2017-03-15 04:13:09 --> Language Class Initialized
INFO - 2017-03-15 04:13:09 --> Loader Class Initialized
INFO - 2017-03-15 04:13:09 --> Database Driver Class Initialized
INFO - 2017-03-15 04:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:13:09 --> Controller Class Initialized
INFO - 2017-03-15 04:13:09 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:13:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:13:12 --> Config Class Initialized
INFO - 2017-03-15 04:13:12 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:13:12 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:13:12 --> Utf8 Class Initialized
INFO - 2017-03-15 04:13:12 --> URI Class Initialized
INFO - 2017-03-15 04:13:12 --> Router Class Initialized
INFO - 2017-03-15 04:13:12 --> Output Class Initialized
INFO - 2017-03-15 04:13:12 --> Security Class Initialized
DEBUG - 2017-03-15 04:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:13:12 --> Input Class Initialized
INFO - 2017-03-15 04:13:12 --> Language Class Initialized
INFO - 2017-03-15 04:13:12 --> Loader Class Initialized
INFO - 2017-03-15 04:13:12 --> Database Driver Class Initialized
INFO - 2017-03-15 04:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:13:13 --> Controller Class Initialized
INFO - 2017-03-15 04:13:13 --> Helper loaded: date_helper
DEBUG - 2017-03-15 04:13:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:13:13 --> Helper loaded: url_helper
INFO - 2017-03-15 04:13:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:13:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 04:13:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 04:13:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 04:13:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:13:13 --> Final output sent to browser
DEBUG - 2017-03-15 04:13:13 --> Total execution time: 1.1018
INFO - 2017-03-15 04:13:14 --> Config Class Initialized
INFO - 2017-03-15 04:13:14 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:13:14 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:13:14 --> Utf8 Class Initialized
INFO - 2017-03-15 04:13:14 --> URI Class Initialized
INFO - 2017-03-15 04:13:14 --> Router Class Initialized
INFO - 2017-03-15 04:13:14 --> Output Class Initialized
INFO - 2017-03-15 04:13:14 --> Security Class Initialized
DEBUG - 2017-03-15 04:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:13:14 --> Input Class Initialized
INFO - 2017-03-15 04:13:14 --> Language Class Initialized
INFO - 2017-03-15 04:13:14 --> Loader Class Initialized
INFO - 2017-03-15 04:13:14 --> Database Driver Class Initialized
INFO - 2017-03-15 04:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:13:15 --> Controller Class Initialized
INFO - 2017-03-15 04:13:15 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:13:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:13:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:13:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:13:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:13:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:13:15 --> Final output sent to browser
DEBUG - 2017-03-15 04:13:15 --> Total execution time: 1.2658
INFO - 2017-03-15 04:40:51 --> Config Class Initialized
INFO - 2017-03-15 04:40:51 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:40:51 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:40:51 --> Utf8 Class Initialized
INFO - 2017-03-15 04:40:51 --> URI Class Initialized
DEBUG - 2017-03-15 04:40:51 --> No URI present. Default controller set.
INFO - 2017-03-15 04:40:51 --> Router Class Initialized
INFO - 2017-03-15 04:40:51 --> Output Class Initialized
INFO - 2017-03-15 04:40:51 --> Security Class Initialized
DEBUG - 2017-03-15 04:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:40:51 --> Input Class Initialized
INFO - 2017-03-15 04:40:51 --> Language Class Initialized
INFO - 2017-03-15 04:40:51 --> Loader Class Initialized
INFO - 2017-03-15 04:40:52 --> Database Driver Class Initialized
INFO - 2017-03-15 04:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:40:52 --> Controller Class Initialized
INFO - 2017-03-15 04:40:52 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:40:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:40:52 --> Final output sent to browser
DEBUG - 2017-03-15 04:40:52 --> Total execution time: 1.2705
INFO - 2017-03-15 04:40:57 --> Config Class Initialized
INFO - 2017-03-15 04:40:57 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:40:57 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:40:57 --> Utf8 Class Initialized
INFO - 2017-03-15 04:40:57 --> URI Class Initialized
INFO - 2017-03-15 04:40:57 --> Router Class Initialized
INFO - 2017-03-15 04:40:57 --> Output Class Initialized
INFO - 2017-03-15 04:40:57 --> Security Class Initialized
DEBUG - 2017-03-15 04:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:40:57 --> Input Class Initialized
INFO - 2017-03-15 04:40:57 --> Language Class Initialized
INFO - 2017-03-15 04:40:57 --> Loader Class Initialized
INFO - 2017-03-15 04:40:57 --> Database Driver Class Initialized
INFO - 2017-03-15 04:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:40:57 --> Controller Class Initialized
INFO - 2017-03-15 04:40:57 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:40:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:40:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:40:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:40:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:40:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:40:57 --> Final output sent to browser
DEBUG - 2017-03-15 04:40:57 --> Total execution time: 0.0142
INFO - 2017-03-15 04:41:00 --> Config Class Initialized
INFO - 2017-03-15 04:41:00 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:41:00 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:41:00 --> Utf8 Class Initialized
INFO - 2017-03-15 04:41:00 --> URI Class Initialized
INFO - 2017-03-15 04:41:00 --> Router Class Initialized
INFO - 2017-03-15 04:41:00 --> Output Class Initialized
INFO - 2017-03-15 04:41:00 --> Security Class Initialized
DEBUG - 2017-03-15 04:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:41:00 --> Input Class Initialized
INFO - 2017-03-15 04:41:00 --> Language Class Initialized
INFO - 2017-03-15 04:41:00 --> Loader Class Initialized
INFO - 2017-03-15 04:41:00 --> Database Driver Class Initialized
INFO - 2017-03-15 04:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:41:00 --> Controller Class Initialized
INFO - 2017-03-15 04:41:00 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:41:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:41:02 --> Config Class Initialized
INFO - 2017-03-15 04:41:02 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:41:02 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:41:02 --> Utf8 Class Initialized
INFO - 2017-03-15 04:41:02 --> URI Class Initialized
INFO - 2017-03-15 04:41:02 --> Router Class Initialized
INFO - 2017-03-15 04:41:02 --> Output Class Initialized
INFO - 2017-03-15 04:41:02 --> Security Class Initialized
DEBUG - 2017-03-15 04:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:41:02 --> Input Class Initialized
INFO - 2017-03-15 04:41:02 --> Language Class Initialized
INFO - 2017-03-15 04:41:02 --> Loader Class Initialized
INFO - 2017-03-15 04:41:02 --> Database Driver Class Initialized
INFO - 2017-03-15 04:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:41:02 --> Controller Class Initialized
INFO - 2017-03-15 04:41:02 --> Helper loaded: date_helper
DEBUG - 2017-03-15 04:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:41:06 --> Helper loaded: url_helper
INFO - 2017-03-15 04:41:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:41:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 04:41:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 04:41:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 04:41:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:41:06 --> Final output sent to browser
DEBUG - 2017-03-15 04:41:06 --> Total execution time: 4.3068
INFO - 2017-03-15 04:41:07 --> Config Class Initialized
INFO - 2017-03-15 04:41:07 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:41:07 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:41:07 --> Utf8 Class Initialized
INFO - 2017-03-15 04:41:07 --> URI Class Initialized
INFO - 2017-03-15 04:41:07 --> Router Class Initialized
INFO - 2017-03-15 04:41:08 --> Output Class Initialized
INFO - 2017-03-15 04:41:08 --> Security Class Initialized
DEBUG - 2017-03-15 04:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:41:08 --> Input Class Initialized
INFO - 2017-03-15 04:41:08 --> Language Class Initialized
INFO - 2017-03-15 04:41:08 --> Loader Class Initialized
INFO - 2017-03-15 04:41:08 --> Database Driver Class Initialized
INFO - 2017-03-15 04:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:41:08 --> Controller Class Initialized
INFO - 2017-03-15 04:41:08 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:41:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:41:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:41:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:41:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:41:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:41:08 --> Final output sent to browser
DEBUG - 2017-03-15 04:41:08 --> Total execution time: 0.1661
INFO - 2017-03-15 04:41:14 --> Config Class Initialized
INFO - 2017-03-15 04:41:14 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:41:14 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:41:14 --> Utf8 Class Initialized
INFO - 2017-03-15 04:41:14 --> URI Class Initialized
DEBUG - 2017-03-15 04:41:14 --> No URI present. Default controller set.
INFO - 2017-03-15 04:41:14 --> Router Class Initialized
INFO - 2017-03-15 04:41:14 --> Output Class Initialized
INFO - 2017-03-15 04:41:14 --> Security Class Initialized
DEBUG - 2017-03-15 04:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:41:14 --> Input Class Initialized
INFO - 2017-03-15 04:41:14 --> Language Class Initialized
INFO - 2017-03-15 04:41:14 --> Loader Class Initialized
INFO - 2017-03-15 04:41:14 --> Database Driver Class Initialized
INFO - 2017-03-15 04:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:41:14 --> Controller Class Initialized
INFO - 2017-03-15 04:41:14 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:41:14 --> Final output sent to browser
DEBUG - 2017-03-15 04:41:14 --> Total execution time: 0.0151
INFO - 2017-03-15 04:41:15 --> Config Class Initialized
INFO - 2017-03-15 04:41:15 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:41:15 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:41:15 --> Utf8 Class Initialized
INFO - 2017-03-15 04:41:15 --> URI Class Initialized
INFO - 2017-03-15 04:41:15 --> Router Class Initialized
INFO - 2017-03-15 04:41:15 --> Output Class Initialized
INFO - 2017-03-15 04:41:15 --> Security Class Initialized
DEBUG - 2017-03-15 04:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:41:15 --> Input Class Initialized
INFO - 2017-03-15 04:41:15 --> Language Class Initialized
INFO - 2017-03-15 04:41:15 --> Loader Class Initialized
INFO - 2017-03-15 04:41:15 --> Database Driver Class Initialized
INFO - 2017-03-15 04:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:41:15 --> Controller Class Initialized
INFO - 2017-03-15 04:41:15 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:41:15 --> Final output sent to browser
DEBUG - 2017-03-15 04:41:15 --> Total execution time: 0.0150
INFO - 2017-03-15 04:41:36 --> Config Class Initialized
INFO - 2017-03-15 04:41:36 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:41:36 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:41:36 --> Utf8 Class Initialized
INFO - 2017-03-15 04:41:36 --> URI Class Initialized
INFO - 2017-03-15 04:41:36 --> Router Class Initialized
INFO - 2017-03-15 04:41:36 --> Output Class Initialized
INFO - 2017-03-15 04:41:36 --> Security Class Initialized
DEBUG - 2017-03-15 04:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:41:36 --> Input Class Initialized
INFO - 2017-03-15 04:41:36 --> Language Class Initialized
INFO - 2017-03-15 04:41:36 --> Loader Class Initialized
INFO - 2017-03-15 04:41:36 --> Database Driver Class Initialized
INFO - 2017-03-15 04:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:41:36 --> Controller Class Initialized
INFO - 2017-03-15 04:41:36 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:41:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:41:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:41:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:41:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:41:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:41:36 --> Final output sent to browser
DEBUG - 2017-03-15 04:41:36 --> Total execution time: 0.4019
INFO - 2017-03-15 04:41:37 --> Config Class Initialized
INFO - 2017-03-15 04:41:37 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:41:37 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:41:37 --> Utf8 Class Initialized
INFO - 2017-03-15 04:41:37 --> URI Class Initialized
INFO - 2017-03-15 04:41:37 --> Router Class Initialized
INFO - 2017-03-15 04:41:37 --> Output Class Initialized
INFO - 2017-03-15 04:41:37 --> Security Class Initialized
DEBUG - 2017-03-15 04:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:41:37 --> Input Class Initialized
INFO - 2017-03-15 04:41:37 --> Language Class Initialized
INFO - 2017-03-15 04:41:37 --> Loader Class Initialized
INFO - 2017-03-15 04:41:37 --> Database Driver Class Initialized
INFO - 2017-03-15 04:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:41:37 --> Controller Class Initialized
INFO - 2017-03-15 04:41:37 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:41:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:41:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:41:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:41:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:41:37 --> Final output sent to browser
DEBUG - 2017-03-15 04:41:37 --> Total execution time: 0.1316
INFO - 2017-03-15 04:41:52 --> Config Class Initialized
INFO - 2017-03-15 04:41:52 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:41:52 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:41:52 --> Utf8 Class Initialized
INFO - 2017-03-15 04:41:52 --> URI Class Initialized
INFO - 2017-03-15 04:41:52 --> Router Class Initialized
INFO - 2017-03-15 04:41:52 --> Output Class Initialized
INFO - 2017-03-15 04:41:52 --> Security Class Initialized
DEBUG - 2017-03-15 04:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:41:52 --> Input Class Initialized
INFO - 2017-03-15 04:41:52 --> Language Class Initialized
INFO - 2017-03-15 04:41:52 --> Loader Class Initialized
INFO - 2017-03-15 04:41:52 --> Database Driver Class Initialized
INFO - 2017-03-15 04:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:41:53 --> Controller Class Initialized
INFO - 2017-03-15 04:41:53 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:41:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:41:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:41:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:41:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:41:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:41:53 --> Final output sent to browser
DEBUG - 2017-03-15 04:41:53 --> Total execution time: 1.4377
INFO - 2017-03-15 04:41:55 --> Config Class Initialized
INFO - 2017-03-15 04:41:55 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:41:55 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:41:55 --> Utf8 Class Initialized
INFO - 2017-03-15 04:41:55 --> URI Class Initialized
INFO - 2017-03-15 04:41:55 --> Router Class Initialized
INFO - 2017-03-15 04:41:55 --> Output Class Initialized
INFO - 2017-03-15 04:41:55 --> Security Class Initialized
DEBUG - 2017-03-15 04:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:41:55 --> Input Class Initialized
INFO - 2017-03-15 04:41:55 --> Language Class Initialized
INFO - 2017-03-15 04:41:55 --> Loader Class Initialized
INFO - 2017-03-15 04:41:56 --> Database Driver Class Initialized
INFO - 2017-03-15 04:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:41:56 --> Controller Class Initialized
INFO - 2017-03-15 04:41:56 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:41:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:41:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:41:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:41:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:41:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:41:56 --> Final output sent to browser
DEBUG - 2017-03-15 04:41:56 --> Total execution time: 1.2654
INFO - 2017-03-15 04:42:36 --> Config Class Initialized
INFO - 2017-03-15 04:42:36 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:42:36 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:42:36 --> Utf8 Class Initialized
INFO - 2017-03-15 04:42:36 --> URI Class Initialized
INFO - 2017-03-15 04:42:36 --> Router Class Initialized
INFO - 2017-03-15 04:42:36 --> Output Class Initialized
INFO - 2017-03-15 04:42:36 --> Security Class Initialized
DEBUG - 2017-03-15 04:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:42:36 --> Input Class Initialized
INFO - 2017-03-15 04:42:36 --> Language Class Initialized
INFO - 2017-03-15 04:42:36 --> Loader Class Initialized
INFO - 2017-03-15 04:42:37 --> Database Driver Class Initialized
INFO - 2017-03-15 04:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:42:37 --> Controller Class Initialized
INFO - 2017-03-15 04:42:37 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:42:37 --> Final output sent to browser
DEBUG - 2017-03-15 04:42:37 --> Total execution time: 1.2671
INFO - 2017-03-15 04:42:38 --> Config Class Initialized
INFO - 2017-03-15 04:42:38 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:42:38 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:42:38 --> Utf8 Class Initialized
INFO - 2017-03-15 04:42:38 --> URI Class Initialized
INFO - 2017-03-15 04:42:38 --> Router Class Initialized
INFO - 2017-03-15 04:42:38 --> Output Class Initialized
INFO - 2017-03-15 04:42:38 --> Security Class Initialized
DEBUG - 2017-03-15 04:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:42:38 --> Input Class Initialized
INFO - 2017-03-15 04:42:38 --> Language Class Initialized
INFO - 2017-03-15 04:42:38 --> Loader Class Initialized
INFO - 2017-03-15 04:42:38 --> Database Driver Class Initialized
INFO - 2017-03-15 04:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:42:38 --> Controller Class Initialized
INFO - 2017-03-15 04:42:38 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:42:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:42:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:42:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:42:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:42:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:42:38 --> Final output sent to browser
DEBUG - 2017-03-15 04:42:38 --> Total execution time: 0.0142
INFO - 2017-03-15 04:43:01 --> Config Class Initialized
INFO - 2017-03-15 04:43:01 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:43:01 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:43:01 --> Utf8 Class Initialized
INFO - 2017-03-15 04:43:01 --> URI Class Initialized
INFO - 2017-03-15 04:43:01 --> Router Class Initialized
INFO - 2017-03-15 04:43:01 --> Output Class Initialized
INFO - 2017-03-15 04:43:01 --> Security Class Initialized
DEBUG - 2017-03-15 04:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:43:01 --> Input Class Initialized
INFO - 2017-03-15 04:43:01 --> Language Class Initialized
INFO - 2017-03-15 04:43:01 --> Loader Class Initialized
INFO - 2017-03-15 04:43:01 --> Database Driver Class Initialized
INFO - 2017-03-15 04:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:43:01 --> Controller Class Initialized
INFO - 2017-03-15 04:43:01 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:43:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:43:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:43:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:43:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:43:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:43:01 --> Final output sent to browser
DEBUG - 2017-03-15 04:43:01 --> Total execution time: 0.0148
INFO - 2017-03-15 04:43:02 --> Config Class Initialized
INFO - 2017-03-15 04:43:02 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:43:02 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:43:02 --> Utf8 Class Initialized
INFO - 2017-03-15 04:43:02 --> URI Class Initialized
INFO - 2017-03-15 04:43:02 --> Router Class Initialized
INFO - 2017-03-15 04:43:02 --> Output Class Initialized
INFO - 2017-03-15 04:43:02 --> Security Class Initialized
DEBUG - 2017-03-15 04:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:43:02 --> Input Class Initialized
INFO - 2017-03-15 04:43:02 --> Language Class Initialized
INFO - 2017-03-15 04:43:02 --> Loader Class Initialized
INFO - 2017-03-15 04:43:02 --> Database Driver Class Initialized
INFO - 2017-03-15 04:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:43:02 --> Controller Class Initialized
INFO - 2017-03-15 04:43:02 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:43:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:43:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:43:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:43:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:43:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:43:02 --> Final output sent to browser
DEBUG - 2017-03-15 04:43:02 --> Total execution time: 0.0140
INFO - 2017-03-15 04:43:12 --> Config Class Initialized
INFO - 2017-03-15 04:43:12 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:43:12 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:43:12 --> Utf8 Class Initialized
INFO - 2017-03-15 04:43:12 --> URI Class Initialized
INFO - 2017-03-15 04:43:12 --> Router Class Initialized
INFO - 2017-03-15 04:43:12 --> Output Class Initialized
INFO - 2017-03-15 04:43:12 --> Security Class Initialized
DEBUG - 2017-03-15 04:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:43:12 --> Input Class Initialized
INFO - 2017-03-15 04:43:12 --> Language Class Initialized
INFO - 2017-03-15 04:43:12 --> Loader Class Initialized
INFO - 2017-03-15 04:43:12 --> Database Driver Class Initialized
INFO - 2017-03-15 04:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:43:12 --> Controller Class Initialized
INFO - 2017-03-15 04:43:12 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:43:14 --> Config Class Initialized
INFO - 2017-03-15 04:43:14 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:43:14 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:43:14 --> Utf8 Class Initialized
INFO - 2017-03-15 04:43:14 --> URI Class Initialized
INFO - 2017-03-15 04:43:14 --> Router Class Initialized
INFO - 2017-03-15 04:43:14 --> Output Class Initialized
INFO - 2017-03-15 04:43:14 --> Security Class Initialized
DEBUG - 2017-03-15 04:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:43:14 --> Input Class Initialized
INFO - 2017-03-15 04:43:14 --> Language Class Initialized
INFO - 2017-03-15 04:43:14 --> Loader Class Initialized
INFO - 2017-03-15 04:43:14 --> Database Driver Class Initialized
INFO - 2017-03-15 04:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:43:14 --> Controller Class Initialized
INFO - 2017-03-15 04:43:14 --> Helper loaded: date_helper
DEBUG - 2017-03-15 04:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:43:14 --> Helper loaded: url_helper
INFO - 2017-03-15 04:43:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:43:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 04:43:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 04:43:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 04:43:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:43:14 --> Final output sent to browser
DEBUG - 2017-03-15 04:43:14 --> Total execution time: 0.0981
INFO - 2017-03-15 04:43:14 --> Config Class Initialized
INFO - 2017-03-15 04:43:14 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:43:14 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:43:14 --> Utf8 Class Initialized
INFO - 2017-03-15 04:43:14 --> URI Class Initialized
INFO - 2017-03-15 04:43:14 --> Router Class Initialized
INFO - 2017-03-15 04:43:14 --> Output Class Initialized
INFO - 2017-03-15 04:43:14 --> Security Class Initialized
DEBUG - 2017-03-15 04:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:43:14 --> Input Class Initialized
INFO - 2017-03-15 04:43:14 --> Language Class Initialized
INFO - 2017-03-15 04:43:14 --> Loader Class Initialized
INFO - 2017-03-15 04:43:14 --> Database Driver Class Initialized
INFO - 2017-03-15 04:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:43:14 --> Controller Class Initialized
INFO - 2017-03-15 04:43:14 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:43:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:43:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:43:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:43:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:43:14 --> Final output sent to browser
DEBUG - 2017-03-15 04:43:14 --> Total execution time: 0.0144
INFO - 2017-03-15 04:43:28 --> Config Class Initialized
INFO - 2017-03-15 04:43:28 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:43:28 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:43:28 --> Utf8 Class Initialized
INFO - 2017-03-15 04:43:28 --> URI Class Initialized
INFO - 2017-03-15 04:43:28 --> Router Class Initialized
INFO - 2017-03-15 04:43:28 --> Output Class Initialized
INFO - 2017-03-15 04:43:28 --> Security Class Initialized
DEBUG - 2017-03-15 04:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:43:28 --> Input Class Initialized
INFO - 2017-03-15 04:43:28 --> Language Class Initialized
INFO - 2017-03-15 04:43:29 --> Loader Class Initialized
INFO - 2017-03-15 04:43:29 --> Database Driver Class Initialized
INFO - 2017-03-15 04:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:43:29 --> Controller Class Initialized
INFO - 2017-03-15 04:43:29 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:43:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:43:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:43:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:43:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:43:30 --> Final output sent to browser
DEBUG - 2017-03-15 04:43:30 --> Total execution time: 1.5543
INFO - 2017-03-15 04:43:31 --> Config Class Initialized
INFO - 2017-03-15 04:43:31 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:43:31 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:43:31 --> Utf8 Class Initialized
INFO - 2017-03-15 04:43:31 --> URI Class Initialized
INFO - 2017-03-15 04:43:31 --> Router Class Initialized
INFO - 2017-03-15 04:43:31 --> Output Class Initialized
INFO - 2017-03-15 04:43:31 --> Security Class Initialized
DEBUG - 2017-03-15 04:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:43:31 --> Input Class Initialized
INFO - 2017-03-15 04:43:31 --> Language Class Initialized
INFO - 2017-03-15 04:43:32 --> Loader Class Initialized
INFO - 2017-03-15 04:43:32 --> Database Driver Class Initialized
INFO - 2017-03-15 04:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:43:32 --> Controller Class Initialized
INFO - 2017-03-15 04:43:32 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:43:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:43:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:43:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:43:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:43:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:43:32 --> Final output sent to browser
DEBUG - 2017-03-15 04:43:32 --> Total execution time: 1.0816
INFO - 2017-03-15 04:43:42 --> Config Class Initialized
INFO - 2017-03-15 04:43:42 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:43:42 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:43:42 --> Utf8 Class Initialized
INFO - 2017-03-15 04:43:42 --> URI Class Initialized
INFO - 2017-03-15 04:43:42 --> Router Class Initialized
INFO - 2017-03-15 04:43:42 --> Output Class Initialized
INFO - 2017-03-15 04:43:42 --> Security Class Initialized
DEBUG - 2017-03-15 04:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:43:42 --> Input Class Initialized
INFO - 2017-03-15 04:43:42 --> Language Class Initialized
INFO - 2017-03-15 04:43:42 --> Loader Class Initialized
INFO - 2017-03-15 04:43:42 --> Database Driver Class Initialized
INFO - 2017-03-15 04:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:43:42 --> Controller Class Initialized
INFO - 2017-03-15 04:43:42 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:43:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:43:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:43:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:43:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:43:42 --> Final output sent to browser
DEBUG - 2017-03-15 04:43:42 --> Total execution time: 0.2625
INFO - 2017-03-15 04:43:43 --> Config Class Initialized
INFO - 2017-03-15 04:43:43 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:43:43 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:43:43 --> Utf8 Class Initialized
INFO - 2017-03-15 04:43:43 --> URI Class Initialized
INFO - 2017-03-15 04:43:43 --> Router Class Initialized
INFO - 2017-03-15 04:43:43 --> Output Class Initialized
INFO - 2017-03-15 04:43:43 --> Security Class Initialized
DEBUG - 2017-03-15 04:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:43:43 --> Input Class Initialized
INFO - 2017-03-15 04:43:43 --> Language Class Initialized
INFO - 2017-03-15 04:43:43 --> Loader Class Initialized
INFO - 2017-03-15 04:43:43 --> Database Driver Class Initialized
INFO - 2017-03-15 04:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:43:43 --> Controller Class Initialized
INFO - 2017-03-15 04:43:43 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:43:43 --> Final output sent to browser
DEBUG - 2017-03-15 04:43:43 --> Total execution time: 0.0138
INFO - 2017-03-15 04:43:54 --> Config Class Initialized
INFO - 2017-03-15 04:43:54 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:43:54 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:43:54 --> Utf8 Class Initialized
INFO - 2017-03-15 04:43:54 --> URI Class Initialized
INFO - 2017-03-15 04:43:54 --> Router Class Initialized
INFO - 2017-03-15 04:43:54 --> Output Class Initialized
INFO - 2017-03-15 04:43:54 --> Security Class Initialized
DEBUG - 2017-03-15 04:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:43:54 --> Input Class Initialized
INFO - 2017-03-15 04:43:54 --> Language Class Initialized
INFO - 2017-03-15 04:43:54 --> Loader Class Initialized
INFO - 2017-03-15 04:43:54 --> Database Driver Class Initialized
INFO - 2017-03-15 04:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:43:54 --> Controller Class Initialized
INFO - 2017-03-15 04:43:54 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:43:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:43:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:43:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:43:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:43:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:43:54 --> Final output sent to browser
DEBUG - 2017-03-15 04:43:54 --> Total execution time: 0.0147
INFO - 2017-03-15 04:43:55 --> Config Class Initialized
INFO - 2017-03-15 04:43:55 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:43:55 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:43:55 --> Utf8 Class Initialized
INFO - 2017-03-15 04:43:55 --> URI Class Initialized
INFO - 2017-03-15 04:43:55 --> Router Class Initialized
INFO - 2017-03-15 04:43:55 --> Output Class Initialized
INFO - 2017-03-15 04:43:55 --> Security Class Initialized
DEBUG - 2017-03-15 04:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:43:55 --> Input Class Initialized
INFO - 2017-03-15 04:43:55 --> Language Class Initialized
INFO - 2017-03-15 04:43:55 --> Loader Class Initialized
INFO - 2017-03-15 04:43:55 --> Database Driver Class Initialized
INFO - 2017-03-15 04:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:43:55 --> Controller Class Initialized
INFO - 2017-03-15 04:43:55 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:43:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:43:55 --> Final output sent to browser
DEBUG - 2017-03-15 04:43:55 --> Total execution time: 0.0145
INFO - 2017-03-15 04:44:03 --> Config Class Initialized
INFO - 2017-03-15 04:44:03 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:44:03 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:44:03 --> Utf8 Class Initialized
INFO - 2017-03-15 04:44:03 --> URI Class Initialized
INFO - 2017-03-15 04:44:03 --> Router Class Initialized
INFO - 2017-03-15 04:44:03 --> Output Class Initialized
INFO - 2017-03-15 04:44:03 --> Security Class Initialized
DEBUG - 2017-03-15 04:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:44:03 --> Input Class Initialized
INFO - 2017-03-15 04:44:03 --> Language Class Initialized
INFO - 2017-03-15 04:44:03 --> Loader Class Initialized
INFO - 2017-03-15 04:44:03 --> Database Driver Class Initialized
INFO - 2017-03-15 04:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:44:03 --> Controller Class Initialized
INFO - 2017-03-15 04:44:03 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:44:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:44:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:44:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:44:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:44:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:44:03 --> Final output sent to browser
DEBUG - 2017-03-15 04:44:03 --> Total execution time: 0.0148
INFO - 2017-03-15 04:44:04 --> Config Class Initialized
INFO - 2017-03-15 04:44:04 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:44:04 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:44:04 --> Utf8 Class Initialized
INFO - 2017-03-15 04:44:04 --> URI Class Initialized
INFO - 2017-03-15 04:44:04 --> Router Class Initialized
INFO - 2017-03-15 04:44:04 --> Output Class Initialized
INFO - 2017-03-15 04:44:04 --> Security Class Initialized
DEBUG - 2017-03-15 04:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:44:04 --> Input Class Initialized
INFO - 2017-03-15 04:44:04 --> Language Class Initialized
INFO - 2017-03-15 04:44:04 --> Loader Class Initialized
INFO - 2017-03-15 04:44:04 --> Database Driver Class Initialized
INFO - 2017-03-15 04:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:44:04 --> Controller Class Initialized
INFO - 2017-03-15 04:44:04 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:44:04 --> Final output sent to browser
DEBUG - 2017-03-15 04:44:04 --> Total execution time: 0.0142
INFO - 2017-03-15 04:46:25 --> Config Class Initialized
INFO - 2017-03-15 04:46:25 --> Hooks Class Initialized
DEBUG - 2017-03-15 04:46:25 --> UTF-8 Support Enabled
INFO - 2017-03-15 04:46:25 --> Utf8 Class Initialized
INFO - 2017-03-15 04:46:25 --> URI Class Initialized
INFO - 2017-03-15 04:46:25 --> Router Class Initialized
INFO - 2017-03-15 04:46:25 --> Output Class Initialized
INFO - 2017-03-15 04:46:25 --> Security Class Initialized
DEBUG - 2017-03-15 04:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 04:46:25 --> Input Class Initialized
INFO - 2017-03-15 04:46:25 --> Language Class Initialized
INFO - 2017-03-15 04:46:25 --> Loader Class Initialized
INFO - 2017-03-15 04:46:26 --> Database Driver Class Initialized
INFO - 2017-03-15 04:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 04:46:26 --> Controller Class Initialized
INFO - 2017-03-15 04:46:26 --> Helper loaded: url_helper
DEBUG - 2017-03-15 04:46:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 04:46:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 04:46:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 04:46:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 04:46:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 04:46:26 --> Final output sent to browser
DEBUG - 2017-03-15 04:46:26 --> Total execution time: 1.4844
INFO - 2017-03-15 05:01:58 --> Config Class Initialized
INFO - 2017-03-15 05:01:58 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:01:58 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:01:58 --> Utf8 Class Initialized
INFO - 2017-03-15 05:01:58 --> URI Class Initialized
INFO - 2017-03-15 05:01:58 --> Router Class Initialized
INFO - 2017-03-15 05:01:58 --> Output Class Initialized
INFO - 2017-03-15 05:01:58 --> Security Class Initialized
DEBUG - 2017-03-15 05:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:01:58 --> Input Class Initialized
INFO - 2017-03-15 05:01:58 --> Language Class Initialized
INFO - 2017-03-15 05:01:58 --> Loader Class Initialized
INFO - 2017-03-15 05:01:59 --> Database Driver Class Initialized
INFO - 2017-03-15 05:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:01:59 --> Controller Class Initialized
INFO - 2017-03-15 05:01:59 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:01:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:01:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:01:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:02:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:02:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:02:00 --> Final output sent to browser
DEBUG - 2017-03-15 05:02:00 --> Total execution time: 1.5354
INFO - 2017-03-15 05:02:04 --> Config Class Initialized
INFO - 2017-03-15 05:02:04 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:02:04 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:02:04 --> Utf8 Class Initialized
INFO - 2017-03-15 05:02:04 --> URI Class Initialized
INFO - 2017-03-15 05:02:04 --> Router Class Initialized
INFO - 2017-03-15 05:02:04 --> Output Class Initialized
INFO - 2017-03-15 05:02:04 --> Security Class Initialized
DEBUG - 2017-03-15 05:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:02:04 --> Input Class Initialized
INFO - 2017-03-15 05:02:04 --> Language Class Initialized
INFO - 2017-03-15 05:02:04 --> Loader Class Initialized
INFO - 2017-03-15 05:02:04 --> Database Driver Class Initialized
INFO - 2017-03-15 05:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:02:05 --> Controller Class Initialized
INFO - 2017-03-15 05:02:05 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:02:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:02:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:02:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:02:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:02:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:02:05 --> Final output sent to browser
DEBUG - 2017-03-15 05:02:05 --> Total execution time: 1.3029
INFO - 2017-03-15 05:30:31 --> Config Class Initialized
INFO - 2017-03-15 05:30:31 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:30:31 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:30:31 --> Utf8 Class Initialized
INFO - 2017-03-15 05:30:31 --> URI Class Initialized
DEBUG - 2017-03-15 05:30:31 --> No URI present. Default controller set.
INFO - 2017-03-15 05:30:31 --> Router Class Initialized
INFO - 2017-03-15 05:30:31 --> Output Class Initialized
INFO - 2017-03-15 05:30:31 --> Security Class Initialized
DEBUG - 2017-03-15 05:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:30:31 --> Input Class Initialized
INFO - 2017-03-15 05:30:31 --> Language Class Initialized
INFO - 2017-03-15 05:30:31 --> Loader Class Initialized
INFO - 2017-03-15 05:30:31 --> Database Driver Class Initialized
INFO - 2017-03-15 05:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:30:31 --> Controller Class Initialized
INFO - 2017-03-15 05:30:31 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:30:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:30:32 --> Final output sent to browser
DEBUG - 2017-03-15 05:30:32 --> Total execution time: 1.2727
INFO - 2017-03-15 05:30:51 --> Config Class Initialized
INFO - 2017-03-15 05:30:51 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:30:51 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:30:51 --> Utf8 Class Initialized
INFO - 2017-03-15 05:30:51 --> URI Class Initialized
INFO - 2017-03-15 05:30:51 --> Router Class Initialized
INFO - 2017-03-15 05:30:51 --> Output Class Initialized
INFO - 2017-03-15 05:30:51 --> Security Class Initialized
DEBUG - 2017-03-15 05:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:30:51 --> Input Class Initialized
INFO - 2017-03-15 05:30:51 --> Language Class Initialized
INFO - 2017-03-15 05:30:51 --> Loader Class Initialized
INFO - 2017-03-15 05:30:51 --> Database Driver Class Initialized
INFO - 2017-03-15 05:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:30:51 --> Controller Class Initialized
INFO - 2017-03-15 05:30:51 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:30:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:30:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:30:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:30:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:30:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:30:51 --> Final output sent to browser
DEBUG - 2017-03-15 05:30:51 --> Total execution time: 0.0137
INFO - 2017-03-15 05:30:55 --> Config Class Initialized
INFO - 2017-03-15 05:30:55 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:30:55 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:30:55 --> Utf8 Class Initialized
INFO - 2017-03-15 05:30:55 --> URI Class Initialized
INFO - 2017-03-15 05:30:55 --> Router Class Initialized
INFO - 2017-03-15 05:30:55 --> Output Class Initialized
INFO - 2017-03-15 05:30:55 --> Security Class Initialized
DEBUG - 2017-03-15 05:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:30:55 --> Input Class Initialized
INFO - 2017-03-15 05:30:55 --> Language Class Initialized
INFO - 2017-03-15 05:30:55 --> Loader Class Initialized
INFO - 2017-03-15 05:30:55 --> Database Driver Class Initialized
INFO - 2017-03-15 05:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:30:55 --> Controller Class Initialized
INFO - 2017-03-15 05:30:55 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:30:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:30:58 --> Config Class Initialized
INFO - 2017-03-15 05:30:58 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:30:58 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:30:58 --> Utf8 Class Initialized
INFO - 2017-03-15 05:30:58 --> URI Class Initialized
INFO - 2017-03-15 05:30:58 --> Router Class Initialized
INFO - 2017-03-15 05:30:58 --> Output Class Initialized
INFO - 2017-03-15 05:30:58 --> Security Class Initialized
DEBUG - 2017-03-15 05:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:30:58 --> Input Class Initialized
INFO - 2017-03-15 05:30:58 --> Language Class Initialized
INFO - 2017-03-15 05:30:58 --> Loader Class Initialized
INFO - 2017-03-15 05:30:58 --> Database Driver Class Initialized
INFO - 2017-03-15 05:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:30:59 --> Controller Class Initialized
INFO - 2017-03-15 05:30:59 --> Helper loaded: date_helper
DEBUG - 2017-03-15 05:30:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:30:59 --> Helper loaded: url_helper
INFO - 2017-03-15 05:30:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:30:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 05:30:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 05:30:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 05:30:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:30:59 --> Final output sent to browser
DEBUG - 2017-03-15 05:30:59 --> Total execution time: 1.1302
INFO - 2017-03-15 05:31:00 --> Config Class Initialized
INFO - 2017-03-15 05:31:00 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:31:00 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:31:00 --> Utf8 Class Initialized
INFO - 2017-03-15 05:31:00 --> URI Class Initialized
INFO - 2017-03-15 05:31:00 --> Router Class Initialized
INFO - 2017-03-15 05:31:00 --> Output Class Initialized
INFO - 2017-03-15 05:31:00 --> Security Class Initialized
DEBUG - 2017-03-15 05:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:31:00 --> Input Class Initialized
INFO - 2017-03-15 05:31:00 --> Language Class Initialized
INFO - 2017-03-15 05:31:00 --> Loader Class Initialized
INFO - 2017-03-15 05:31:00 --> Database Driver Class Initialized
INFO - 2017-03-15 05:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:31:00 --> Controller Class Initialized
INFO - 2017-03-15 05:31:00 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:31:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:31:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:31:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:31:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:31:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:31:00 --> Final output sent to browser
DEBUG - 2017-03-15 05:31:00 --> Total execution time: 0.5672
INFO - 2017-03-15 05:31:13 --> Config Class Initialized
INFO - 2017-03-15 05:31:13 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:31:13 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:31:13 --> Utf8 Class Initialized
INFO - 2017-03-15 05:31:13 --> URI Class Initialized
DEBUG - 2017-03-15 05:31:13 --> No URI present. Default controller set.
INFO - 2017-03-15 05:31:13 --> Router Class Initialized
INFO - 2017-03-15 05:31:13 --> Output Class Initialized
INFO - 2017-03-15 05:31:13 --> Security Class Initialized
DEBUG - 2017-03-15 05:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:31:13 --> Input Class Initialized
INFO - 2017-03-15 05:31:13 --> Language Class Initialized
INFO - 2017-03-15 05:31:13 --> Loader Class Initialized
INFO - 2017-03-15 05:31:13 --> Database Driver Class Initialized
INFO - 2017-03-15 05:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:31:13 --> Controller Class Initialized
INFO - 2017-03-15 05:31:13 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:31:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:31:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:31:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:31:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:31:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:31:13 --> Final output sent to browser
DEBUG - 2017-03-15 05:31:13 --> Total execution time: 0.0133
INFO - 2017-03-15 05:31:14 --> Config Class Initialized
INFO - 2017-03-15 05:31:14 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:31:14 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:31:14 --> Utf8 Class Initialized
INFO - 2017-03-15 05:31:14 --> URI Class Initialized
INFO - 2017-03-15 05:31:14 --> Router Class Initialized
INFO - 2017-03-15 05:31:14 --> Output Class Initialized
INFO - 2017-03-15 05:31:14 --> Security Class Initialized
DEBUG - 2017-03-15 05:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:31:14 --> Input Class Initialized
INFO - 2017-03-15 05:31:14 --> Language Class Initialized
INFO - 2017-03-15 05:31:14 --> Loader Class Initialized
INFO - 2017-03-15 05:31:14 --> Database Driver Class Initialized
INFO - 2017-03-15 05:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:31:14 --> Controller Class Initialized
INFO - 2017-03-15 05:31:14 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:31:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:31:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:31:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:31:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:31:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:31:14 --> Final output sent to browser
DEBUG - 2017-03-15 05:31:14 --> Total execution time: 0.0138
INFO - 2017-03-15 05:32:23 --> Config Class Initialized
INFO - 2017-03-15 05:32:23 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:32:23 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:32:23 --> Utf8 Class Initialized
INFO - 2017-03-15 05:32:23 --> URI Class Initialized
INFO - 2017-03-15 05:32:23 --> Router Class Initialized
INFO - 2017-03-15 05:32:23 --> Output Class Initialized
INFO - 2017-03-15 05:32:23 --> Security Class Initialized
DEBUG - 2017-03-15 05:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:32:23 --> Input Class Initialized
INFO - 2017-03-15 05:32:23 --> Language Class Initialized
INFO - 2017-03-15 05:32:23 --> Loader Class Initialized
INFO - 2017-03-15 05:32:23 --> Database Driver Class Initialized
INFO - 2017-03-15 05:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:32:23 --> Controller Class Initialized
INFO - 2017-03-15 05:32:23 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:32:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:32:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:32:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:32:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:32:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:32:23 --> Final output sent to browser
DEBUG - 2017-03-15 05:32:23 --> Total execution time: 0.0306
INFO - 2017-03-15 05:32:24 --> Config Class Initialized
INFO - 2017-03-15 05:32:24 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:32:24 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:32:24 --> Utf8 Class Initialized
INFO - 2017-03-15 05:32:24 --> URI Class Initialized
INFO - 2017-03-15 05:32:24 --> Router Class Initialized
INFO - 2017-03-15 05:32:24 --> Output Class Initialized
INFO - 2017-03-15 05:32:24 --> Security Class Initialized
DEBUG - 2017-03-15 05:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:32:24 --> Input Class Initialized
INFO - 2017-03-15 05:32:24 --> Language Class Initialized
INFO - 2017-03-15 05:32:24 --> Loader Class Initialized
INFO - 2017-03-15 05:32:24 --> Database Driver Class Initialized
INFO - 2017-03-15 05:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:32:24 --> Controller Class Initialized
INFO - 2017-03-15 05:32:24 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:32:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:32:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:32:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:32:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:32:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:32:24 --> Final output sent to browser
DEBUG - 2017-03-15 05:32:24 --> Total execution time: 0.0137
INFO - 2017-03-15 05:32:36 --> Config Class Initialized
INFO - 2017-03-15 05:32:36 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:32:36 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:32:36 --> Utf8 Class Initialized
INFO - 2017-03-15 05:32:36 --> URI Class Initialized
INFO - 2017-03-15 05:32:36 --> Router Class Initialized
INFO - 2017-03-15 05:32:36 --> Output Class Initialized
INFO - 2017-03-15 05:32:36 --> Security Class Initialized
DEBUG - 2017-03-15 05:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:32:36 --> Input Class Initialized
INFO - 2017-03-15 05:32:36 --> Language Class Initialized
INFO - 2017-03-15 05:32:36 --> Loader Class Initialized
INFO - 2017-03-15 05:32:36 --> Database Driver Class Initialized
INFO - 2017-03-15 05:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:32:36 --> Controller Class Initialized
INFO - 2017-03-15 05:32:36 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:32:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:32:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:32:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:32:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:32:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:32:36 --> Final output sent to browser
DEBUG - 2017-03-15 05:32:36 --> Total execution time: 0.0144
INFO - 2017-03-15 05:32:36 --> Config Class Initialized
INFO - 2017-03-15 05:32:36 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:32:36 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:32:36 --> Utf8 Class Initialized
INFO - 2017-03-15 05:32:36 --> URI Class Initialized
INFO - 2017-03-15 05:32:36 --> Router Class Initialized
INFO - 2017-03-15 05:32:36 --> Output Class Initialized
INFO - 2017-03-15 05:32:36 --> Security Class Initialized
DEBUG - 2017-03-15 05:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:32:36 --> Input Class Initialized
INFO - 2017-03-15 05:32:36 --> Language Class Initialized
INFO - 2017-03-15 05:32:36 --> Loader Class Initialized
INFO - 2017-03-15 05:32:36 --> Database Driver Class Initialized
INFO - 2017-03-15 05:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:32:36 --> Controller Class Initialized
INFO - 2017-03-15 05:32:36 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:32:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:32:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:32:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:32:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:32:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:32:36 --> Final output sent to browser
DEBUG - 2017-03-15 05:32:36 --> Total execution time: 0.0140
INFO - 2017-03-15 05:32:50 --> Config Class Initialized
INFO - 2017-03-15 05:32:50 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:32:50 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:32:50 --> Utf8 Class Initialized
INFO - 2017-03-15 05:32:50 --> URI Class Initialized
INFO - 2017-03-15 05:32:50 --> Router Class Initialized
INFO - 2017-03-15 05:32:50 --> Output Class Initialized
INFO - 2017-03-15 05:32:50 --> Security Class Initialized
DEBUG - 2017-03-15 05:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:32:50 --> Input Class Initialized
INFO - 2017-03-15 05:32:50 --> Language Class Initialized
INFO - 2017-03-15 05:32:50 --> Loader Class Initialized
INFO - 2017-03-15 05:32:50 --> Database Driver Class Initialized
INFO - 2017-03-15 05:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:32:51 --> Controller Class Initialized
INFO - 2017-03-15 05:32:51 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:32:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:32:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:32:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:32:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:32:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:32:51 --> Final output sent to browser
DEBUG - 2017-03-15 05:32:51 --> Total execution time: 1.6037
INFO - 2017-03-15 05:32:53 --> Config Class Initialized
INFO - 2017-03-15 05:32:53 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:32:53 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:32:53 --> Utf8 Class Initialized
INFO - 2017-03-15 05:32:53 --> URI Class Initialized
INFO - 2017-03-15 05:32:53 --> Router Class Initialized
INFO - 2017-03-15 05:32:53 --> Output Class Initialized
INFO - 2017-03-15 05:32:53 --> Security Class Initialized
DEBUG - 2017-03-15 05:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:32:53 --> Input Class Initialized
INFO - 2017-03-15 05:32:53 --> Language Class Initialized
INFO - 2017-03-15 05:32:53 --> Loader Class Initialized
INFO - 2017-03-15 05:32:54 --> Database Driver Class Initialized
INFO - 2017-03-15 05:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:32:54 --> Controller Class Initialized
INFO - 2017-03-15 05:32:54 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:32:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:32:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:32:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:32:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:32:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:32:54 --> Final output sent to browser
DEBUG - 2017-03-15 05:32:54 --> Total execution time: 0.6331
INFO - 2017-03-15 05:33:24 --> Config Class Initialized
INFO - 2017-03-15 05:33:24 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:33:24 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:33:24 --> Utf8 Class Initialized
INFO - 2017-03-15 05:33:24 --> URI Class Initialized
INFO - 2017-03-15 05:33:24 --> Router Class Initialized
INFO - 2017-03-15 05:33:24 --> Output Class Initialized
INFO - 2017-03-15 05:33:24 --> Security Class Initialized
DEBUG - 2017-03-15 05:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:33:24 --> Input Class Initialized
INFO - 2017-03-15 05:33:24 --> Language Class Initialized
INFO - 2017-03-15 05:33:24 --> Loader Class Initialized
INFO - 2017-03-15 05:33:24 --> Database Driver Class Initialized
INFO - 2017-03-15 05:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:33:25 --> Controller Class Initialized
INFO - 2017-03-15 05:33:25 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:33:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:33:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:33:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:33:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:33:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:33:25 --> Final output sent to browser
DEBUG - 2017-03-15 05:33:25 --> Total execution time: 1.2634
INFO - 2017-03-15 05:33:26 --> Config Class Initialized
INFO - 2017-03-15 05:33:26 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:33:26 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:33:26 --> Utf8 Class Initialized
INFO - 2017-03-15 05:33:26 --> URI Class Initialized
INFO - 2017-03-15 05:33:26 --> Router Class Initialized
INFO - 2017-03-15 05:33:26 --> Output Class Initialized
INFO - 2017-03-15 05:33:26 --> Security Class Initialized
DEBUG - 2017-03-15 05:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:33:26 --> Input Class Initialized
INFO - 2017-03-15 05:33:26 --> Language Class Initialized
INFO - 2017-03-15 05:33:26 --> Loader Class Initialized
INFO - 2017-03-15 05:33:26 --> Database Driver Class Initialized
INFO - 2017-03-15 05:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:33:26 --> Controller Class Initialized
INFO - 2017-03-15 05:33:26 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:33:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:33:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:33:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:33:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:33:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:33:26 --> Final output sent to browser
DEBUG - 2017-03-15 05:33:26 --> Total execution time: 0.0146
INFO - 2017-03-15 05:33:42 --> Config Class Initialized
INFO - 2017-03-15 05:33:42 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:33:42 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:33:42 --> Utf8 Class Initialized
INFO - 2017-03-15 05:33:42 --> URI Class Initialized
INFO - 2017-03-15 05:33:42 --> Router Class Initialized
INFO - 2017-03-15 05:33:42 --> Output Class Initialized
INFO - 2017-03-15 05:33:42 --> Security Class Initialized
DEBUG - 2017-03-15 05:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:33:42 --> Input Class Initialized
INFO - 2017-03-15 05:33:42 --> Language Class Initialized
INFO - 2017-03-15 05:33:42 --> Loader Class Initialized
INFO - 2017-03-15 05:33:42 --> Database Driver Class Initialized
INFO - 2017-03-15 05:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:33:42 --> Controller Class Initialized
INFO - 2017-03-15 05:33:42 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:33:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:33:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:33:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:33:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:33:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:33:42 --> Final output sent to browser
DEBUG - 2017-03-15 05:33:42 --> Total execution time: 0.0147
INFO - 2017-03-15 05:33:42 --> Config Class Initialized
INFO - 2017-03-15 05:33:42 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:33:42 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:33:42 --> Utf8 Class Initialized
INFO - 2017-03-15 05:33:42 --> URI Class Initialized
INFO - 2017-03-15 05:33:42 --> Router Class Initialized
INFO - 2017-03-15 05:33:42 --> Output Class Initialized
INFO - 2017-03-15 05:33:42 --> Security Class Initialized
DEBUG - 2017-03-15 05:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:33:42 --> Input Class Initialized
INFO - 2017-03-15 05:33:42 --> Language Class Initialized
INFO - 2017-03-15 05:33:42 --> Loader Class Initialized
INFO - 2017-03-15 05:33:42 --> Database Driver Class Initialized
INFO - 2017-03-15 05:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:33:42 --> Controller Class Initialized
INFO - 2017-03-15 05:33:42 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:33:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:33:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:33:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:33:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:33:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:33:42 --> Final output sent to browser
DEBUG - 2017-03-15 05:33:42 --> Total execution time: 0.0144
INFO - 2017-03-15 05:33:56 --> Config Class Initialized
INFO - 2017-03-15 05:33:56 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:33:56 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:33:56 --> Utf8 Class Initialized
INFO - 2017-03-15 05:33:56 --> URI Class Initialized
INFO - 2017-03-15 05:33:56 --> Router Class Initialized
INFO - 2017-03-15 05:33:56 --> Output Class Initialized
INFO - 2017-03-15 05:33:56 --> Security Class Initialized
DEBUG - 2017-03-15 05:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:33:56 --> Input Class Initialized
INFO - 2017-03-15 05:33:56 --> Language Class Initialized
INFO - 2017-03-15 05:33:56 --> Loader Class Initialized
INFO - 2017-03-15 05:33:57 --> Database Driver Class Initialized
INFO - 2017-03-15 05:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:33:57 --> Controller Class Initialized
INFO - 2017-03-15 05:33:57 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:33:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:33:58 --> Config Class Initialized
INFO - 2017-03-15 05:33:58 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:33:58 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:33:58 --> Utf8 Class Initialized
INFO - 2017-03-15 05:33:58 --> URI Class Initialized
INFO - 2017-03-15 05:33:58 --> Router Class Initialized
INFO - 2017-03-15 05:33:58 --> Output Class Initialized
INFO - 2017-03-15 05:33:58 --> Security Class Initialized
DEBUG - 2017-03-15 05:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:33:58 --> Input Class Initialized
INFO - 2017-03-15 05:33:58 --> Language Class Initialized
INFO - 2017-03-15 05:33:58 --> Loader Class Initialized
INFO - 2017-03-15 05:33:58 --> Database Driver Class Initialized
INFO - 2017-03-15 05:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:33:58 --> Controller Class Initialized
INFO - 2017-03-15 05:33:58 --> Helper loaded: date_helper
DEBUG - 2017-03-15 05:33:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:33:58 --> Helper loaded: url_helper
INFO - 2017-03-15 05:33:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:33:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 05:33:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 05:33:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 05:33:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:33:58 --> Final output sent to browser
DEBUG - 2017-03-15 05:33:58 --> Total execution time: 0.1133
INFO - 2017-03-15 05:33:59 --> Config Class Initialized
INFO - 2017-03-15 05:33:59 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:33:59 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:33:59 --> Utf8 Class Initialized
INFO - 2017-03-15 05:33:59 --> URI Class Initialized
INFO - 2017-03-15 05:33:59 --> Router Class Initialized
INFO - 2017-03-15 05:33:59 --> Output Class Initialized
INFO - 2017-03-15 05:33:59 --> Security Class Initialized
DEBUG - 2017-03-15 05:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:33:59 --> Input Class Initialized
INFO - 2017-03-15 05:33:59 --> Language Class Initialized
INFO - 2017-03-15 05:33:59 --> Loader Class Initialized
INFO - 2017-03-15 05:33:59 --> Database Driver Class Initialized
INFO - 2017-03-15 05:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:33:59 --> Controller Class Initialized
INFO - 2017-03-15 05:33:59 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:33:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:33:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:33:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:33:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:33:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:33:59 --> Final output sent to browser
DEBUG - 2017-03-15 05:33:59 --> Total execution time: 0.0249
INFO - 2017-03-15 05:37:21 --> Config Class Initialized
INFO - 2017-03-15 05:37:21 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:37:21 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:37:21 --> Utf8 Class Initialized
INFO - 2017-03-15 05:37:21 --> URI Class Initialized
DEBUG - 2017-03-15 05:37:21 --> No URI present. Default controller set.
INFO - 2017-03-15 05:37:21 --> Router Class Initialized
INFO - 2017-03-15 05:37:21 --> Output Class Initialized
INFO - 2017-03-15 05:37:21 --> Security Class Initialized
DEBUG - 2017-03-15 05:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:37:21 --> Input Class Initialized
INFO - 2017-03-15 05:37:21 --> Language Class Initialized
INFO - 2017-03-15 05:37:21 --> Loader Class Initialized
INFO - 2017-03-15 05:37:21 --> Database Driver Class Initialized
INFO - 2017-03-15 05:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:37:22 --> Controller Class Initialized
INFO - 2017-03-15 05:37:22 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:37:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:37:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:37:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:37:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:37:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:37:22 --> Final output sent to browser
DEBUG - 2017-03-15 05:37:22 --> Total execution time: 1.2255
INFO - 2017-03-15 05:37:25 --> Config Class Initialized
INFO - 2017-03-15 05:37:25 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:37:25 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:37:25 --> Utf8 Class Initialized
INFO - 2017-03-15 05:37:25 --> URI Class Initialized
INFO - 2017-03-15 05:37:25 --> Router Class Initialized
INFO - 2017-03-15 05:37:25 --> Output Class Initialized
INFO - 2017-03-15 05:37:25 --> Security Class Initialized
DEBUG - 2017-03-15 05:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:37:25 --> Input Class Initialized
INFO - 2017-03-15 05:37:25 --> Language Class Initialized
INFO - 2017-03-15 05:37:25 --> Loader Class Initialized
INFO - 2017-03-15 05:37:25 --> Database Driver Class Initialized
INFO - 2017-03-15 05:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:37:25 --> Controller Class Initialized
INFO - 2017-03-15 05:37:25 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:37:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:37:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:37:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:37:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:37:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:37:25 --> Final output sent to browser
DEBUG - 2017-03-15 05:37:25 --> Total execution time: 0.0137
INFO - 2017-03-15 05:37:30 --> Config Class Initialized
INFO - 2017-03-15 05:37:30 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:37:30 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:37:30 --> Utf8 Class Initialized
INFO - 2017-03-15 05:37:30 --> URI Class Initialized
INFO - 2017-03-15 05:37:30 --> Router Class Initialized
INFO - 2017-03-15 05:37:30 --> Output Class Initialized
INFO - 2017-03-15 05:37:30 --> Security Class Initialized
DEBUG - 2017-03-15 05:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:37:30 --> Input Class Initialized
INFO - 2017-03-15 05:37:30 --> Language Class Initialized
INFO - 2017-03-15 05:37:30 --> Loader Class Initialized
INFO - 2017-03-15 05:37:30 --> Database Driver Class Initialized
INFO - 2017-03-15 05:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:37:30 --> Controller Class Initialized
INFO - 2017-03-15 05:37:30 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:37:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:37:30 --> Final output sent to browser
DEBUG - 2017-03-15 05:37:30 --> Total execution time: 0.0135
INFO - 2017-03-15 05:37:33 --> Config Class Initialized
INFO - 2017-03-15 05:37:33 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:37:33 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:37:33 --> Utf8 Class Initialized
INFO - 2017-03-15 05:37:33 --> URI Class Initialized
INFO - 2017-03-15 05:37:33 --> Router Class Initialized
INFO - 2017-03-15 05:37:33 --> Output Class Initialized
INFO - 2017-03-15 05:37:33 --> Security Class Initialized
DEBUG - 2017-03-15 05:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:37:33 --> Input Class Initialized
INFO - 2017-03-15 05:37:33 --> Language Class Initialized
INFO - 2017-03-15 05:37:33 --> Loader Class Initialized
INFO - 2017-03-15 05:37:33 --> Database Driver Class Initialized
INFO - 2017-03-15 05:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:37:33 --> Controller Class Initialized
INFO - 2017-03-15 05:37:33 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:37:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:37:34 --> Config Class Initialized
INFO - 2017-03-15 05:37:34 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:37:34 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:37:34 --> Utf8 Class Initialized
INFO - 2017-03-15 05:37:34 --> URI Class Initialized
INFO - 2017-03-15 05:37:34 --> Router Class Initialized
INFO - 2017-03-15 05:37:34 --> Output Class Initialized
INFO - 2017-03-15 05:37:34 --> Security Class Initialized
DEBUG - 2017-03-15 05:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:37:34 --> Input Class Initialized
INFO - 2017-03-15 05:37:34 --> Language Class Initialized
INFO - 2017-03-15 05:37:34 --> Loader Class Initialized
INFO - 2017-03-15 05:37:34 --> Database Driver Class Initialized
INFO - 2017-03-15 05:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:37:34 --> Controller Class Initialized
INFO - 2017-03-15 05:37:34 --> Helper loaded: date_helper
DEBUG - 2017-03-15 05:37:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:37:34 --> Helper loaded: url_helper
INFO - 2017-03-15 05:37:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:37:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 05:37:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 05:37:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 05:37:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:37:34 --> Final output sent to browser
DEBUG - 2017-03-15 05:37:34 --> Total execution time: 0.1041
INFO - 2017-03-15 05:37:35 --> Config Class Initialized
INFO - 2017-03-15 05:37:35 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:37:35 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:37:35 --> Utf8 Class Initialized
INFO - 2017-03-15 05:37:35 --> URI Class Initialized
INFO - 2017-03-15 05:37:35 --> Router Class Initialized
INFO - 2017-03-15 05:37:35 --> Output Class Initialized
INFO - 2017-03-15 05:37:35 --> Security Class Initialized
DEBUG - 2017-03-15 05:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:37:35 --> Input Class Initialized
INFO - 2017-03-15 05:37:35 --> Language Class Initialized
INFO - 2017-03-15 05:37:35 --> Loader Class Initialized
INFO - 2017-03-15 05:37:35 --> Database Driver Class Initialized
INFO - 2017-03-15 05:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:37:35 --> Controller Class Initialized
INFO - 2017-03-15 05:37:35 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:37:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:37:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:37:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:37:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:37:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:37:35 --> Final output sent to browser
DEBUG - 2017-03-15 05:37:35 --> Total execution time: 0.0139
INFO - 2017-03-15 05:37:37 --> Config Class Initialized
INFO - 2017-03-15 05:37:37 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:37:37 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:37:37 --> Utf8 Class Initialized
INFO - 2017-03-15 05:37:37 --> URI Class Initialized
DEBUG - 2017-03-15 05:37:37 --> No URI present. Default controller set.
INFO - 2017-03-15 05:37:37 --> Router Class Initialized
INFO - 2017-03-15 05:37:37 --> Output Class Initialized
INFO - 2017-03-15 05:37:37 --> Security Class Initialized
DEBUG - 2017-03-15 05:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:37:37 --> Input Class Initialized
INFO - 2017-03-15 05:37:37 --> Language Class Initialized
INFO - 2017-03-15 05:37:37 --> Loader Class Initialized
INFO - 2017-03-15 05:37:37 --> Database Driver Class Initialized
INFO - 2017-03-15 05:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:37:37 --> Controller Class Initialized
INFO - 2017-03-15 05:37:37 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:37:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:37:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:37:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:37:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:37:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:37:37 --> Final output sent to browser
DEBUG - 2017-03-15 05:37:37 --> Total execution time: 0.0135
INFO - 2017-03-15 05:37:38 --> Config Class Initialized
INFO - 2017-03-15 05:37:38 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:37:38 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:37:38 --> Utf8 Class Initialized
INFO - 2017-03-15 05:37:38 --> URI Class Initialized
INFO - 2017-03-15 05:37:38 --> Router Class Initialized
INFO - 2017-03-15 05:37:38 --> Output Class Initialized
INFO - 2017-03-15 05:37:38 --> Security Class Initialized
DEBUG - 2017-03-15 05:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:37:38 --> Input Class Initialized
INFO - 2017-03-15 05:37:38 --> Language Class Initialized
INFO - 2017-03-15 05:37:38 --> Loader Class Initialized
INFO - 2017-03-15 05:37:38 --> Database Driver Class Initialized
INFO - 2017-03-15 05:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:37:38 --> Controller Class Initialized
INFO - 2017-03-15 05:37:38 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:37:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:37:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:37:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:37:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:37:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:37:38 --> Final output sent to browser
DEBUG - 2017-03-15 05:37:38 --> Total execution time: 0.0140
INFO - 2017-03-15 05:38:02 --> Config Class Initialized
INFO - 2017-03-15 05:38:02 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:38:02 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:38:02 --> Utf8 Class Initialized
INFO - 2017-03-15 05:38:02 --> URI Class Initialized
INFO - 2017-03-15 05:38:02 --> Router Class Initialized
INFO - 2017-03-15 05:38:02 --> Output Class Initialized
INFO - 2017-03-15 05:38:02 --> Security Class Initialized
DEBUG - 2017-03-15 05:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:38:02 --> Input Class Initialized
INFO - 2017-03-15 05:38:02 --> Language Class Initialized
INFO - 2017-03-15 05:38:02 --> Loader Class Initialized
INFO - 2017-03-15 05:38:02 --> Database Driver Class Initialized
INFO - 2017-03-15 05:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:38:02 --> Controller Class Initialized
INFO - 2017-03-15 05:38:02 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:38:04 --> Config Class Initialized
INFO - 2017-03-15 05:38:04 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:38:04 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:38:04 --> Utf8 Class Initialized
INFO - 2017-03-15 05:38:04 --> URI Class Initialized
INFO - 2017-03-15 05:38:04 --> Router Class Initialized
INFO - 2017-03-15 05:38:04 --> Output Class Initialized
INFO - 2017-03-15 05:38:04 --> Security Class Initialized
DEBUG - 2017-03-15 05:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:38:05 --> Input Class Initialized
INFO - 2017-03-15 05:38:05 --> Language Class Initialized
INFO - 2017-03-15 05:38:05 --> Loader Class Initialized
INFO - 2017-03-15 05:38:05 --> Database Driver Class Initialized
INFO - 2017-03-15 05:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:38:05 --> Controller Class Initialized
INFO - 2017-03-15 05:38:05 --> Helper loaded: date_helper
DEBUG - 2017-03-15 05:38:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:38:05 --> Helper loaded: url_helper
INFO - 2017-03-15 05:38:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:38:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 05:38:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 05:38:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 05:38:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:38:05 --> Final output sent to browser
DEBUG - 2017-03-15 05:38:05 --> Total execution time: 1.1715
INFO - 2017-03-15 05:38:07 --> Config Class Initialized
INFO - 2017-03-15 05:38:07 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:38:07 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:38:07 --> Utf8 Class Initialized
INFO - 2017-03-15 05:38:07 --> URI Class Initialized
INFO - 2017-03-15 05:38:07 --> Router Class Initialized
INFO - 2017-03-15 05:38:07 --> Output Class Initialized
INFO - 2017-03-15 05:38:07 --> Security Class Initialized
DEBUG - 2017-03-15 05:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:38:07 --> Input Class Initialized
INFO - 2017-03-15 05:38:07 --> Language Class Initialized
INFO - 2017-03-15 05:38:07 --> Loader Class Initialized
INFO - 2017-03-15 05:38:08 --> Database Driver Class Initialized
INFO - 2017-03-15 05:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:38:08 --> Controller Class Initialized
INFO - 2017-03-15 05:38:08 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:38:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:38:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:38:08 --> Final output sent to browser
DEBUG - 2017-03-15 05:38:08 --> Total execution time: 1.0858
INFO - 2017-03-15 05:38:09 --> Config Class Initialized
INFO - 2017-03-15 05:38:09 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:38:09 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:38:09 --> Utf8 Class Initialized
INFO - 2017-03-15 05:38:09 --> URI Class Initialized
DEBUG - 2017-03-15 05:38:09 --> No URI present. Default controller set.
INFO - 2017-03-15 05:38:09 --> Router Class Initialized
INFO - 2017-03-15 05:38:09 --> Output Class Initialized
INFO - 2017-03-15 05:38:09 --> Security Class Initialized
DEBUG - 2017-03-15 05:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:38:09 --> Input Class Initialized
INFO - 2017-03-15 05:38:09 --> Language Class Initialized
INFO - 2017-03-15 05:38:09 --> Loader Class Initialized
INFO - 2017-03-15 05:38:09 --> Database Driver Class Initialized
INFO - 2017-03-15 05:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:38:09 --> Controller Class Initialized
INFO - 2017-03-15 05:38:09 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:38:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:38:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:38:09 --> Final output sent to browser
DEBUG - 2017-03-15 05:38:09 --> Total execution time: 0.0177
INFO - 2017-03-15 05:38:11 --> Config Class Initialized
INFO - 2017-03-15 05:38:11 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:38:11 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:38:11 --> Utf8 Class Initialized
INFO - 2017-03-15 05:38:11 --> URI Class Initialized
INFO - 2017-03-15 05:38:11 --> Router Class Initialized
INFO - 2017-03-15 05:38:11 --> Output Class Initialized
INFO - 2017-03-15 05:38:11 --> Security Class Initialized
DEBUG - 2017-03-15 05:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:38:11 --> Input Class Initialized
INFO - 2017-03-15 05:38:11 --> Language Class Initialized
INFO - 2017-03-15 05:38:11 --> Loader Class Initialized
INFO - 2017-03-15 05:38:11 --> Database Driver Class Initialized
INFO - 2017-03-15 05:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:38:11 --> Controller Class Initialized
INFO - 2017-03-15 05:38:11 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:38:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:38:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:38:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:38:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:38:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:38:11 --> Final output sent to browser
DEBUG - 2017-03-15 05:38:11 --> Total execution time: 0.0135
INFO - 2017-03-15 05:42:40 --> Config Class Initialized
INFO - 2017-03-15 05:42:40 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:42:40 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:42:40 --> Utf8 Class Initialized
INFO - 2017-03-15 05:42:40 --> URI Class Initialized
INFO - 2017-03-15 05:42:41 --> Router Class Initialized
INFO - 2017-03-15 05:42:41 --> Output Class Initialized
INFO - 2017-03-15 05:42:41 --> Security Class Initialized
DEBUG - 2017-03-15 05:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:42:41 --> Input Class Initialized
INFO - 2017-03-15 05:42:41 --> Language Class Initialized
INFO - 2017-03-15 05:42:41 --> Loader Class Initialized
INFO - 2017-03-15 05:42:41 --> Database Driver Class Initialized
INFO - 2017-03-15 05:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:42:42 --> Controller Class Initialized
INFO - 2017-03-15 05:42:42 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:42:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:42:43 --> Config Class Initialized
INFO - 2017-03-15 05:42:43 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:42:43 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:42:43 --> Utf8 Class Initialized
INFO - 2017-03-15 05:42:43 --> URI Class Initialized
INFO - 2017-03-15 05:42:44 --> Router Class Initialized
INFO - 2017-03-15 05:42:44 --> Output Class Initialized
INFO - 2017-03-15 05:42:44 --> Security Class Initialized
DEBUG - 2017-03-15 05:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:42:44 --> Input Class Initialized
INFO - 2017-03-15 05:42:44 --> Language Class Initialized
INFO - 2017-03-15 05:42:44 --> Loader Class Initialized
INFO - 2017-03-15 05:42:44 --> Database Driver Class Initialized
INFO - 2017-03-15 05:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:42:44 --> Controller Class Initialized
INFO - 2017-03-15 05:42:44 --> Helper loaded: date_helper
DEBUG - 2017-03-15 05:42:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:42:44 --> Helper loaded: url_helper
INFO - 2017-03-15 05:42:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:42:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 05:42:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 05:42:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 05:42:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:42:44 --> Final output sent to browser
DEBUG - 2017-03-15 05:42:44 --> Total execution time: 0.5145
INFO - 2017-03-15 05:42:44 --> Config Class Initialized
INFO - 2017-03-15 05:42:44 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:42:44 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:42:44 --> Utf8 Class Initialized
INFO - 2017-03-15 05:42:44 --> URI Class Initialized
INFO - 2017-03-15 05:42:44 --> Router Class Initialized
INFO - 2017-03-15 05:42:44 --> Output Class Initialized
INFO - 2017-03-15 05:42:44 --> Security Class Initialized
DEBUG - 2017-03-15 05:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:42:44 --> Input Class Initialized
INFO - 2017-03-15 05:42:44 --> Language Class Initialized
INFO - 2017-03-15 05:42:44 --> Loader Class Initialized
INFO - 2017-03-15 05:42:45 --> Database Driver Class Initialized
INFO - 2017-03-15 05:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:42:45 --> Controller Class Initialized
INFO - 2017-03-15 05:42:45 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:42:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:42:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:42:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:42:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:42:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:42:45 --> Final output sent to browser
DEBUG - 2017-03-15 05:42:45 --> Total execution time: 0.0355
INFO - 2017-03-15 05:42:48 --> Config Class Initialized
INFO - 2017-03-15 05:42:48 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:42:48 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:42:48 --> Utf8 Class Initialized
INFO - 2017-03-15 05:42:48 --> URI Class Initialized
DEBUG - 2017-03-15 05:42:48 --> No URI present. Default controller set.
INFO - 2017-03-15 05:42:48 --> Router Class Initialized
INFO - 2017-03-15 05:42:48 --> Output Class Initialized
INFO - 2017-03-15 05:42:48 --> Security Class Initialized
DEBUG - 2017-03-15 05:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:42:48 --> Input Class Initialized
INFO - 2017-03-15 05:42:48 --> Language Class Initialized
INFO - 2017-03-15 05:42:48 --> Loader Class Initialized
INFO - 2017-03-15 05:42:48 --> Database Driver Class Initialized
INFO - 2017-03-15 05:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:42:48 --> Controller Class Initialized
INFO - 2017-03-15 05:42:48 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:42:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:42:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:42:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:42:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:42:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:42:48 --> Final output sent to browser
DEBUG - 2017-03-15 05:42:48 --> Total execution time: 0.0144
INFO - 2017-03-15 05:42:49 --> Config Class Initialized
INFO - 2017-03-15 05:42:49 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:42:49 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:42:49 --> Utf8 Class Initialized
INFO - 2017-03-15 05:42:49 --> URI Class Initialized
INFO - 2017-03-15 05:42:49 --> Router Class Initialized
INFO - 2017-03-15 05:42:49 --> Output Class Initialized
INFO - 2017-03-15 05:42:49 --> Security Class Initialized
DEBUG - 2017-03-15 05:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:42:49 --> Input Class Initialized
INFO - 2017-03-15 05:42:49 --> Language Class Initialized
INFO - 2017-03-15 05:42:49 --> Loader Class Initialized
INFO - 2017-03-15 05:42:49 --> Database Driver Class Initialized
INFO - 2017-03-15 05:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:42:49 --> Controller Class Initialized
INFO - 2017-03-15 05:42:49 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:42:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:42:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:42:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:42:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:42:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:42:49 --> Final output sent to browser
DEBUG - 2017-03-15 05:42:49 --> Total execution time: 0.0135
INFO - 2017-03-15 05:43:05 --> Config Class Initialized
INFO - 2017-03-15 05:43:05 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:43:05 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:43:05 --> Utf8 Class Initialized
INFO - 2017-03-15 05:43:05 --> URI Class Initialized
INFO - 2017-03-15 05:43:05 --> Router Class Initialized
INFO - 2017-03-15 05:43:05 --> Output Class Initialized
INFO - 2017-03-15 05:43:05 --> Security Class Initialized
DEBUG - 2017-03-15 05:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:43:05 --> Input Class Initialized
INFO - 2017-03-15 05:43:05 --> Language Class Initialized
INFO - 2017-03-15 05:43:05 --> Loader Class Initialized
INFO - 2017-03-15 05:43:05 --> Database Driver Class Initialized
INFO - 2017-03-15 05:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:43:06 --> Controller Class Initialized
INFO - 2017-03-15 05:43:06 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:43:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:43:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:43:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:43:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:43:06 --> Final output sent to browser
DEBUG - 2017-03-15 05:43:06 --> Total execution time: 0.8724
INFO - 2017-03-15 05:43:07 --> Config Class Initialized
INFO - 2017-03-15 05:43:07 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:43:07 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:43:07 --> Utf8 Class Initialized
INFO - 2017-03-15 05:43:07 --> URI Class Initialized
INFO - 2017-03-15 05:43:07 --> Router Class Initialized
INFO - 2017-03-15 05:43:07 --> Output Class Initialized
INFO - 2017-03-15 05:43:07 --> Security Class Initialized
DEBUG - 2017-03-15 05:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:43:07 --> Input Class Initialized
INFO - 2017-03-15 05:43:07 --> Language Class Initialized
INFO - 2017-03-15 05:43:07 --> Loader Class Initialized
INFO - 2017-03-15 05:43:07 --> Database Driver Class Initialized
INFO - 2017-03-15 05:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:43:07 --> Controller Class Initialized
INFO - 2017-03-15 05:43:07 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:43:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:43:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:43:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:43:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:43:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:43:07 --> Final output sent to browser
DEBUG - 2017-03-15 05:43:07 --> Total execution time: 0.0136
INFO - 2017-03-15 05:43:21 --> Config Class Initialized
INFO - 2017-03-15 05:43:21 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:43:21 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:43:21 --> Utf8 Class Initialized
INFO - 2017-03-15 05:43:21 --> URI Class Initialized
INFO - 2017-03-15 05:43:21 --> Router Class Initialized
INFO - 2017-03-15 05:43:21 --> Output Class Initialized
INFO - 2017-03-15 05:43:22 --> Security Class Initialized
DEBUG - 2017-03-15 05:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:43:22 --> Input Class Initialized
INFO - 2017-03-15 05:43:22 --> Language Class Initialized
INFO - 2017-03-15 05:43:22 --> Loader Class Initialized
INFO - 2017-03-15 05:43:22 --> Database Driver Class Initialized
INFO - 2017-03-15 05:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:43:22 --> Controller Class Initialized
INFO - 2017-03-15 05:43:23 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:43:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:43:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:43:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:43:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:43:23 --> Final output sent to browser
DEBUG - 2017-03-15 05:43:23 --> Total execution time: 1.6941
INFO - 2017-03-15 05:43:25 --> Config Class Initialized
INFO - 2017-03-15 05:43:25 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:43:25 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:43:25 --> Utf8 Class Initialized
INFO - 2017-03-15 05:43:25 --> URI Class Initialized
INFO - 2017-03-15 05:43:25 --> Router Class Initialized
INFO - 2017-03-15 05:43:25 --> Output Class Initialized
INFO - 2017-03-15 05:43:25 --> Security Class Initialized
DEBUG - 2017-03-15 05:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:43:25 --> Input Class Initialized
INFO - 2017-03-15 05:43:25 --> Language Class Initialized
INFO - 2017-03-15 05:43:25 --> Loader Class Initialized
INFO - 2017-03-15 05:43:25 --> Database Driver Class Initialized
INFO - 2017-03-15 05:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:43:26 --> Controller Class Initialized
INFO - 2017-03-15 05:43:26 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:43:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:43:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:43:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:43:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:43:26 --> Final output sent to browser
DEBUG - 2017-03-15 05:43:26 --> Total execution time: 0.9556
INFO - 2017-03-15 05:43:28 --> Config Class Initialized
INFO - 2017-03-15 05:43:28 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:43:28 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:43:28 --> Utf8 Class Initialized
INFO - 2017-03-15 05:43:28 --> URI Class Initialized
INFO - 2017-03-15 05:43:28 --> Router Class Initialized
INFO - 2017-03-15 05:43:29 --> Output Class Initialized
INFO - 2017-03-15 05:43:29 --> Security Class Initialized
DEBUG - 2017-03-15 05:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:43:29 --> Input Class Initialized
INFO - 2017-03-15 05:43:29 --> Language Class Initialized
INFO - 2017-03-15 05:43:29 --> Loader Class Initialized
INFO - 2017-03-15 05:43:29 --> Database Driver Class Initialized
INFO - 2017-03-15 05:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:43:29 --> Controller Class Initialized
INFO - 2017-03-15 05:43:29 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:43:31 --> Config Class Initialized
INFO - 2017-03-15 05:43:31 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:43:31 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:43:31 --> Utf8 Class Initialized
INFO - 2017-03-15 05:43:31 --> URI Class Initialized
INFO - 2017-03-15 05:43:31 --> Router Class Initialized
INFO - 2017-03-15 05:43:31 --> Output Class Initialized
INFO - 2017-03-15 05:43:31 --> Security Class Initialized
DEBUG - 2017-03-15 05:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:43:32 --> Input Class Initialized
INFO - 2017-03-15 05:43:32 --> Language Class Initialized
INFO - 2017-03-15 05:43:32 --> Loader Class Initialized
INFO - 2017-03-15 05:43:32 --> Database Driver Class Initialized
INFO - 2017-03-15 05:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:43:32 --> Controller Class Initialized
INFO - 2017-03-15 05:43:32 --> Helper loaded: date_helper
DEBUG - 2017-03-15 05:43:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:43:32 --> Helper loaded: url_helper
INFO - 2017-03-15 05:43:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:43:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 05:43:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 05:43:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 05:43:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:43:32 --> Final output sent to browser
DEBUG - 2017-03-15 05:43:32 --> Total execution time: 1.2149
INFO - 2017-03-15 05:43:33 --> Config Class Initialized
INFO - 2017-03-15 05:43:33 --> Hooks Class Initialized
DEBUG - 2017-03-15 05:43:33 --> UTF-8 Support Enabled
INFO - 2017-03-15 05:43:33 --> Utf8 Class Initialized
INFO - 2017-03-15 05:43:33 --> URI Class Initialized
INFO - 2017-03-15 05:43:33 --> Router Class Initialized
INFO - 2017-03-15 05:43:33 --> Output Class Initialized
INFO - 2017-03-15 05:43:33 --> Security Class Initialized
DEBUG - 2017-03-15 05:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 05:43:33 --> Input Class Initialized
INFO - 2017-03-15 05:43:33 --> Language Class Initialized
INFO - 2017-03-15 05:43:33 --> Loader Class Initialized
INFO - 2017-03-15 05:43:33 --> Database Driver Class Initialized
INFO - 2017-03-15 05:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 05:43:33 --> Controller Class Initialized
INFO - 2017-03-15 05:43:33 --> Helper loaded: url_helper
DEBUG - 2017-03-15 05:43:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 05:43:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 05:43:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 05:43:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 05:43:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 05:43:33 --> Final output sent to browser
DEBUG - 2017-03-15 05:43:33 --> Total execution time: 0.5247
INFO - 2017-03-15 06:25:29 --> Config Class Initialized
INFO - 2017-03-15 06:25:29 --> Hooks Class Initialized
DEBUG - 2017-03-15 06:25:29 --> UTF-8 Support Enabled
INFO - 2017-03-15 06:25:29 --> Utf8 Class Initialized
INFO - 2017-03-15 06:25:29 --> URI Class Initialized
INFO - 2017-03-15 06:25:29 --> Router Class Initialized
INFO - 2017-03-15 06:25:29 --> Output Class Initialized
INFO - 2017-03-15 06:25:29 --> Security Class Initialized
DEBUG - 2017-03-15 06:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 06:25:29 --> Input Class Initialized
INFO - 2017-03-15 06:25:29 --> Language Class Initialized
INFO - 2017-03-15 06:25:29 --> Loader Class Initialized
INFO - 2017-03-15 06:25:30 --> Database Driver Class Initialized
INFO - 2017-03-15 06:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 06:25:30 --> Controller Class Initialized
INFO - 2017-03-15 06:25:30 --> Helper loaded: date_helper
DEBUG - 2017-03-15 06:25:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 06:25:30 --> Helper loaded: url_helper
INFO - 2017-03-15 06:25:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 06:25:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 06:25:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 06:25:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 06:25:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 06:25:30 --> Final output sent to browser
DEBUG - 2017-03-15 06:25:30 --> Total execution time: 1.6093
INFO - 2017-03-15 07:33:07 --> Config Class Initialized
INFO - 2017-03-15 07:33:07 --> Hooks Class Initialized
DEBUG - 2017-03-15 07:33:07 --> UTF-8 Support Enabled
INFO - 2017-03-15 07:33:07 --> Utf8 Class Initialized
INFO - 2017-03-15 07:33:07 --> URI Class Initialized
INFO - 2017-03-15 07:33:07 --> Router Class Initialized
INFO - 2017-03-15 07:33:07 --> Output Class Initialized
INFO - 2017-03-15 07:33:07 --> Security Class Initialized
DEBUG - 2017-03-15 07:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 07:33:07 --> Input Class Initialized
INFO - 2017-03-15 07:33:07 --> Language Class Initialized
INFO - 2017-03-15 07:33:07 --> Loader Class Initialized
INFO - 2017-03-15 07:33:08 --> Database Driver Class Initialized
INFO - 2017-03-15 07:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 07:33:08 --> Controller Class Initialized
INFO - 2017-03-15 07:33:08 --> Helper loaded: url_helper
DEBUG - 2017-03-15 07:33:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 07:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 07:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 07:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 07:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 07:33:08 --> Final output sent to browser
DEBUG - 2017-03-15 07:33:08 --> Total execution time: 1.4792
INFO - 2017-03-15 07:33:08 --> Config Class Initialized
INFO - 2017-03-15 07:33:08 --> Hooks Class Initialized
DEBUG - 2017-03-15 07:33:08 --> UTF-8 Support Enabled
INFO - 2017-03-15 07:33:08 --> Utf8 Class Initialized
INFO - 2017-03-15 07:33:08 --> URI Class Initialized
DEBUG - 2017-03-15 07:33:08 --> No URI present. Default controller set.
INFO - 2017-03-15 07:33:08 --> Router Class Initialized
INFO - 2017-03-15 07:33:08 --> Output Class Initialized
INFO - 2017-03-15 07:33:08 --> Security Class Initialized
DEBUG - 2017-03-15 07:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 07:33:08 --> Input Class Initialized
INFO - 2017-03-15 07:33:08 --> Language Class Initialized
INFO - 2017-03-15 07:33:08 --> Loader Class Initialized
INFO - 2017-03-15 07:33:08 --> Database Driver Class Initialized
INFO - 2017-03-15 07:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 07:33:08 --> Controller Class Initialized
INFO - 2017-03-15 07:33:08 --> Helper loaded: url_helper
DEBUG - 2017-03-15 07:33:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 07:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 07:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 07:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 07:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 07:33:08 --> Final output sent to browser
DEBUG - 2017-03-15 07:33:08 --> Total execution time: 0.0131
INFO - 2017-03-15 07:52:51 --> Config Class Initialized
INFO - 2017-03-15 07:52:51 --> Hooks Class Initialized
DEBUG - 2017-03-15 07:52:51 --> UTF-8 Support Enabled
INFO - 2017-03-15 07:52:51 --> Utf8 Class Initialized
INFO - 2017-03-15 07:52:51 --> URI Class Initialized
INFO - 2017-03-15 07:52:51 --> Router Class Initialized
INFO - 2017-03-15 07:52:51 --> Output Class Initialized
INFO - 2017-03-15 07:52:51 --> Security Class Initialized
DEBUG - 2017-03-15 07:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 07:52:51 --> Input Class Initialized
INFO - 2017-03-15 07:52:51 --> Language Class Initialized
INFO - 2017-03-15 07:52:51 --> Loader Class Initialized
INFO - 2017-03-15 07:52:51 --> Database Driver Class Initialized
INFO - 2017-03-15 07:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 07:52:52 --> Controller Class Initialized
INFO - 2017-03-15 07:52:52 --> Helper loaded: url_helper
DEBUG - 2017-03-15 07:52:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 07:52:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 07:52:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 07:52:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 07:52:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 07:52:52 --> Final output sent to browser
DEBUG - 2017-03-15 07:52:52 --> Total execution time: 1.4569
INFO - 2017-03-15 07:52:53 --> Config Class Initialized
INFO - 2017-03-15 07:52:53 --> Hooks Class Initialized
DEBUG - 2017-03-15 07:52:53 --> UTF-8 Support Enabled
INFO - 2017-03-15 07:52:53 --> Utf8 Class Initialized
INFO - 2017-03-15 07:52:53 --> URI Class Initialized
DEBUG - 2017-03-15 07:52:53 --> No URI present. Default controller set.
INFO - 2017-03-15 07:52:53 --> Router Class Initialized
INFO - 2017-03-15 07:52:53 --> Output Class Initialized
INFO - 2017-03-15 07:52:53 --> Security Class Initialized
DEBUG - 2017-03-15 07:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 07:52:53 --> Input Class Initialized
INFO - 2017-03-15 07:52:53 --> Language Class Initialized
INFO - 2017-03-15 07:52:53 --> Loader Class Initialized
INFO - 2017-03-15 07:52:53 --> Database Driver Class Initialized
INFO - 2017-03-15 07:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 07:52:53 --> Controller Class Initialized
INFO - 2017-03-15 07:52:53 --> Helper loaded: url_helper
DEBUG - 2017-03-15 07:52:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 07:52:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 07:52:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 07:52:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 07:52:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 07:52:53 --> Final output sent to browser
DEBUG - 2017-03-15 07:52:53 --> Total execution time: 0.0137
INFO - 2017-03-15 10:07:32 --> Config Class Initialized
INFO - 2017-03-15 10:07:32 --> Hooks Class Initialized
DEBUG - 2017-03-15 10:07:32 --> UTF-8 Support Enabled
INFO - 2017-03-15 10:07:32 --> Utf8 Class Initialized
INFO - 2017-03-15 10:07:32 --> URI Class Initialized
INFO - 2017-03-15 10:07:32 --> Router Class Initialized
INFO - 2017-03-15 10:07:32 --> Output Class Initialized
INFO - 2017-03-15 10:07:32 --> Security Class Initialized
DEBUG - 2017-03-15 10:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 10:07:32 --> Input Class Initialized
INFO - 2017-03-15 10:07:32 --> Language Class Initialized
INFO - 2017-03-15 10:07:32 --> Loader Class Initialized
INFO - 2017-03-15 10:07:33 --> Database Driver Class Initialized
INFO - 2017-03-15 10:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 10:07:33 --> Controller Class Initialized
INFO - 2017-03-15 10:07:33 --> Helper loaded: url_helper
DEBUG - 2017-03-15 10:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 10:07:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 10:07:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 10:07:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 10:07:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 10:07:33 --> Final output sent to browser
DEBUG - 2017-03-15 10:07:33 --> Total execution time: 1.3500
INFO - 2017-03-15 11:15:07 --> Config Class Initialized
INFO - 2017-03-15 11:15:07 --> Hooks Class Initialized
DEBUG - 2017-03-15 11:15:08 --> UTF-8 Support Enabled
INFO - 2017-03-15 11:15:08 --> Utf8 Class Initialized
INFO - 2017-03-15 11:15:08 --> URI Class Initialized
INFO - 2017-03-15 11:15:08 --> Router Class Initialized
INFO - 2017-03-15 11:15:08 --> Output Class Initialized
INFO - 2017-03-15 11:15:08 --> Security Class Initialized
DEBUG - 2017-03-15 11:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 11:15:08 --> Input Class Initialized
INFO - 2017-03-15 11:15:08 --> Language Class Initialized
INFO - 2017-03-15 11:15:08 --> Loader Class Initialized
INFO - 2017-03-15 11:15:08 --> Database Driver Class Initialized
INFO - 2017-03-15 11:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 11:15:09 --> Controller Class Initialized
INFO - 2017-03-15 11:15:09 --> Helper loaded: url_helper
DEBUG - 2017-03-15 11:15:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 11:15:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 11:15:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 11:15:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 11:15:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 11:15:09 --> Final output sent to browser
DEBUG - 2017-03-15 11:15:09 --> Total execution time: 1.3542
INFO - 2017-03-15 11:15:09 --> Config Class Initialized
INFO - 2017-03-15 11:15:09 --> Hooks Class Initialized
DEBUG - 2017-03-15 11:15:09 --> UTF-8 Support Enabled
INFO - 2017-03-15 11:15:09 --> Utf8 Class Initialized
INFO - 2017-03-15 11:15:09 --> URI Class Initialized
DEBUG - 2017-03-15 11:15:09 --> No URI present. Default controller set.
INFO - 2017-03-15 11:15:09 --> Router Class Initialized
INFO - 2017-03-15 11:15:09 --> Output Class Initialized
INFO - 2017-03-15 11:15:09 --> Security Class Initialized
DEBUG - 2017-03-15 11:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 11:15:09 --> Input Class Initialized
INFO - 2017-03-15 11:15:09 --> Language Class Initialized
INFO - 2017-03-15 11:15:09 --> Loader Class Initialized
INFO - 2017-03-15 11:15:09 --> Database Driver Class Initialized
INFO - 2017-03-15 11:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 11:15:09 --> Controller Class Initialized
INFO - 2017-03-15 11:15:09 --> Helper loaded: url_helper
DEBUG - 2017-03-15 11:15:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 11:15:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 11:15:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 11:15:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 11:15:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 11:15:09 --> Final output sent to browser
DEBUG - 2017-03-15 11:15:09 --> Total execution time: 0.0138
INFO - 2017-03-15 12:21:05 --> Config Class Initialized
INFO - 2017-03-15 12:21:05 --> Hooks Class Initialized
DEBUG - 2017-03-15 12:21:05 --> UTF-8 Support Enabled
INFO - 2017-03-15 12:21:05 --> Utf8 Class Initialized
INFO - 2017-03-15 12:21:05 --> URI Class Initialized
INFO - 2017-03-15 12:21:05 --> Router Class Initialized
INFO - 2017-03-15 12:21:05 --> Output Class Initialized
INFO - 2017-03-15 12:21:05 --> Security Class Initialized
DEBUG - 2017-03-15 12:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 12:21:05 --> Input Class Initialized
INFO - 2017-03-15 12:21:05 --> Language Class Initialized
INFO - 2017-03-15 12:21:05 --> Loader Class Initialized
INFO - 2017-03-15 12:21:06 --> Database Driver Class Initialized
INFO - 2017-03-15 12:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 12:21:06 --> Controller Class Initialized
INFO - 2017-03-15 12:21:06 --> Helper loaded: url_helper
DEBUG - 2017-03-15 12:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 12:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 12:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 12:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 12:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 12:21:06 --> Final output sent to browser
DEBUG - 2017-03-15 12:21:06 --> Total execution time: 1.2126
INFO - 2017-03-15 12:21:06 --> Config Class Initialized
INFO - 2017-03-15 12:21:06 --> Hooks Class Initialized
DEBUG - 2017-03-15 12:21:06 --> UTF-8 Support Enabled
INFO - 2017-03-15 12:21:06 --> Utf8 Class Initialized
INFO - 2017-03-15 12:21:06 --> URI Class Initialized
DEBUG - 2017-03-15 12:21:06 --> No URI present. Default controller set.
INFO - 2017-03-15 12:21:06 --> Router Class Initialized
INFO - 2017-03-15 12:21:06 --> Output Class Initialized
INFO - 2017-03-15 12:21:06 --> Security Class Initialized
DEBUG - 2017-03-15 12:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 12:21:06 --> Input Class Initialized
INFO - 2017-03-15 12:21:06 --> Language Class Initialized
INFO - 2017-03-15 12:21:06 --> Loader Class Initialized
INFO - 2017-03-15 12:21:06 --> Database Driver Class Initialized
INFO - 2017-03-15 12:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 12:21:06 --> Controller Class Initialized
INFO - 2017-03-15 12:21:06 --> Helper loaded: url_helper
DEBUG - 2017-03-15 12:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 12:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 12:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 12:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 12:21:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 12:21:06 --> Final output sent to browser
DEBUG - 2017-03-15 12:21:06 --> Total execution time: 0.0138
INFO - 2017-03-15 13:11:19 --> Config Class Initialized
INFO - 2017-03-15 13:11:19 --> Hooks Class Initialized
DEBUG - 2017-03-15 13:11:19 --> UTF-8 Support Enabled
INFO - 2017-03-15 13:11:19 --> Utf8 Class Initialized
INFO - 2017-03-15 13:11:19 --> URI Class Initialized
INFO - 2017-03-15 13:11:19 --> Router Class Initialized
INFO - 2017-03-15 13:11:19 --> Output Class Initialized
INFO - 2017-03-15 13:11:19 --> Security Class Initialized
DEBUG - 2017-03-15 13:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 13:11:19 --> Input Class Initialized
INFO - 2017-03-15 13:11:19 --> Language Class Initialized
INFO - 2017-03-15 13:11:19 --> Loader Class Initialized
INFO - 2017-03-15 13:11:20 --> Database Driver Class Initialized
INFO - 2017-03-15 13:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 13:11:20 --> Controller Class Initialized
INFO - 2017-03-15 13:11:20 --> Helper loaded: url_helper
DEBUG - 2017-03-15 13:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 13:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 13:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 13:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 13:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 13:11:20 --> Final output sent to browser
DEBUG - 2017-03-15 13:11:20 --> Total execution time: 1.2343
INFO - 2017-03-15 13:11:22 --> Config Class Initialized
INFO - 2017-03-15 13:11:22 --> Hooks Class Initialized
DEBUG - 2017-03-15 13:11:22 --> UTF-8 Support Enabled
INFO - 2017-03-15 13:11:22 --> Utf8 Class Initialized
INFO - 2017-03-15 13:11:22 --> URI Class Initialized
DEBUG - 2017-03-15 13:11:22 --> No URI present. Default controller set.
INFO - 2017-03-15 13:11:22 --> Router Class Initialized
INFO - 2017-03-15 13:11:22 --> Output Class Initialized
INFO - 2017-03-15 13:11:22 --> Security Class Initialized
DEBUG - 2017-03-15 13:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 13:11:22 --> Input Class Initialized
INFO - 2017-03-15 13:11:22 --> Language Class Initialized
INFO - 2017-03-15 13:11:22 --> Loader Class Initialized
INFO - 2017-03-15 13:11:23 --> Database Driver Class Initialized
INFO - 2017-03-15 13:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 13:11:23 --> Controller Class Initialized
INFO - 2017-03-15 13:11:23 --> Helper loaded: url_helper
DEBUG - 2017-03-15 13:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 13:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 13:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 13:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 13:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 13:11:23 --> Final output sent to browser
DEBUG - 2017-03-15 13:11:23 --> Total execution time: 1.2988
INFO - 2017-03-15 14:37:20 --> Config Class Initialized
INFO - 2017-03-15 14:37:20 --> Hooks Class Initialized
DEBUG - 2017-03-15 14:37:20 --> UTF-8 Support Enabled
INFO - 2017-03-15 14:37:20 --> Utf8 Class Initialized
INFO - 2017-03-15 14:37:20 --> URI Class Initialized
INFO - 2017-03-15 14:37:20 --> Router Class Initialized
INFO - 2017-03-15 14:37:21 --> Output Class Initialized
INFO - 2017-03-15 14:37:21 --> Security Class Initialized
DEBUG - 2017-03-15 14:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 14:37:21 --> Input Class Initialized
INFO - 2017-03-15 14:37:21 --> Language Class Initialized
INFO - 2017-03-15 14:37:21 --> Loader Class Initialized
INFO - 2017-03-15 14:37:21 --> Database Driver Class Initialized
INFO - 2017-03-15 14:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 14:37:21 --> Controller Class Initialized
INFO - 2017-03-15 14:37:22 --> Helper loaded: date_helper
DEBUG - 2017-03-15 14:37:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 14:37:22 --> Helper loaded: url_helper
INFO - 2017-03-15 14:37:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 14:37:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 14:37:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 14:37:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 14:37:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 14:37:22 --> Final output sent to browser
DEBUG - 2017-03-15 14:37:22 --> Total execution time: 1.7959
INFO - 2017-03-15 14:37:34 --> Config Class Initialized
INFO - 2017-03-15 14:37:34 --> Hooks Class Initialized
DEBUG - 2017-03-15 14:37:34 --> UTF-8 Support Enabled
INFO - 2017-03-15 14:37:34 --> Utf8 Class Initialized
INFO - 2017-03-15 14:37:34 --> URI Class Initialized
INFO - 2017-03-15 14:37:34 --> Router Class Initialized
INFO - 2017-03-15 14:37:34 --> Output Class Initialized
INFO - 2017-03-15 14:37:34 --> Security Class Initialized
DEBUG - 2017-03-15 14:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 14:37:34 --> Input Class Initialized
INFO - 2017-03-15 14:37:34 --> Language Class Initialized
INFO - 2017-03-15 14:37:34 --> Loader Class Initialized
INFO - 2017-03-15 14:37:34 --> Database Driver Class Initialized
INFO - 2017-03-15 14:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 14:37:34 --> Controller Class Initialized
INFO - 2017-03-15 14:37:34 --> Helper loaded: url_helper
DEBUG - 2017-03-15 14:37:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 14:37:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 14:37:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 14:37:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 14:37:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 14:37:35 --> Final output sent to browser
DEBUG - 2017-03-15 14:37:35 --> Total execution time: 1.0954
INFO - 2017-03-15 14:38:05 --> Config Class Initialized
INFO - 2017-03-15 14:38:05 --> Hooks Class Initialized
DEBUG - 2017-03-15 14:38:05 --> UTF-8 Support Enabled
INFO - 2017-03-15 14:38:05 --> Utf8 Class Initialized
INFO - 2017-03-15 14:38:05 --> URI Class Initialized
DEBUG - 2017-03-15 14:38:05 --> No URI present. Default controller set.
INFO - 2017-03-15 14:38:06 --> Router Class Initialized
INFO - 2017-03-15 14:38:06 --> Output Class Initialized
INFO - 2017-03-15 14:38:06 --> Security Class Initialized
DEBUG - 2017-03-15 14:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 14:38:06 --> Input Class Initialized
INFO - 2017-03-15 14:38:06 --> Language Class Initialized
INFO - 2017-03-15 14:38:06 --> Loader Class Initialized
INFO - 2017-03-15 14:38:06 --> Database Driver Class Initialized
INFO - 2017-03-15 14:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 14:38:06 --> Controller Class Initialized
INFO - 2017-03-15 14:38:06 --> Helper loaded: url_helper
DEBUG - 2017-03-15 14:38:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 14:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 14:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 14:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 14:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 14:38:06 --> Final output sent to browser
DEBUG - 2017-03-15 14:38:06 --> Total execution time: 0.9294
INFO - 2017-03-15 14:38:12 --> Config Class Initialized
INFO - 2017-03-15 14:38:12 --> Hooks Class Initialized
DEBUG - 2017-03-15 14:38:12 --> UTF-8 Support Enabled
INFO - 2017-03-15 14:38:12 --> Utf8 Class Initialized
INFO - 2017-03-15 14:38:12 --> URI Class Initialized
INFO - 2017-03-15 14:38:12 --> Router Class Initialized
INFO - 2017-03-15 14:38:12 --> Output Class Initialized
INFO - 2017-03-15 14:38:12 --> Security Class Initialized
DEBUG - 2017-03-15 14:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 14:38:12 --> Input Class Initialized
INFO - 2017-03-15 14:38:12 --> Language Class Initialized
INFO - 2017-03-15 14:38:12 --> Loader Class Initialized
INFO - 2017-03-15 14:38:13 --> Database Driver Class Initialized
INFO - 2017-03-15 14:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 14:38:13 --> Controller Class Initialized
INFO - 2017-03-15 14:38:13 --> Helper loaded: url_helper
DEBUG - 2017-03-15 14:38:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 14:38:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 14:38:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 14:38:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 14:38:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 14:38:13 --> Final output sent to browser
DEBUG - 2017-03-15 14:38:13 --> Total execution time: 1.2310
INFO - 2017-03-15 15:00:09 --> Config Class Initialized
INFO - 2017-03-15 15:00:09 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:00:09 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:00:09 --> Utf8 Class Initialized
INFO - 2017-03-15 15:00:09 --> URI Class Initialized
INFO - 2017-03-15 15:00:09 --> Router Class Initialized
INFO - 2017-03-15 15:00:09 --> Output Class Initialized
INFO - 2017-03-15 15:00:09 --> Security Class Initialized
DEBUG - 2017-03-15 15:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:00:09 --> Input Class Initialized
INFO - 2017-03-15 15:00:09 --> Language Class Initialized
INFO - 2017-03-15 15:00:10 --> Loader Class Initialized
INFO - 2017-03-15 15:00:10 --> Database Driver Class Initialized
INFO - 2017-03-15 15:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:00:10 --> Controller Class Initialized
INFO - 2017-03-15 15:00:10 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:00:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:00:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:00:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:00:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:00:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:00:11 --> Final output sent to browser
DEBUG - 2017-03-15 15:00:11 --> Total execution time: 1.4511
INFO - 2017-03-15 15:00:11 --> Config Class Initialized
INFO - 2017-03-15 15:00:11 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:00:11 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:00:11 --> Utf8 Class Initialized
INFO - 2017-03-15 15:00:11 --> URI Class Initialized
DEBUG - 2017-03-15 15:00:11 --> No URI present. Default controller set.
INFO - 2017-03-15 15:00:11 --> Router Class Initialized
INFO - 2017-03-15 15:00:11 --> Output Class Initialized
INFO - 2017-03-15 15:00:11 --> Security Class Initialized
DEBUG - 2017-03-15 15:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:00:11 --> Input Class Initialized
INFO - 2017-03-15 15:00:11 --> Language Class Initialized
INFO - 2017-03-15 15:00:11 --> Loader Class Initialized
INFO - 2017-03-15 15:00:11 --> Database Driver Class Initialized
INFO - 2017-03-15 15:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:00:11 --> Controller Class Initialized
INFO - 2017-03-15 15:00:11 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:00:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:00:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:00:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:00:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:00:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:00:11 --> Final output sent to browser
DEBUG - 2017-03-15 15:00:11 --> Total execution time: 0.0202
INFO - 2017-03-15 15:19:54 --> Config Class Initialized
INFO - 2017-03-15 15:19:54 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:19:54 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:19:54 --> Utf8 Class Initialized
INFO - 2017-03-15 15:19:54 --> URI Class Initialized
INFO - 2017-03-15 15:19:54 --> Router Class Initialized
INFO - 2017-03-15 15:19:54 --> Output Class Initialized
INFO - 2017-03-15 15:19:54 --> Security Class Initialized
DEBUG - 2017-03-15 15:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:19:54 --> Input Class Initialized
INFO - 2017-03-15 15:19:54 --> Language Class Initialized
INFO - 2017-03-15 15:19:54 --> Loader Class Initialized
INFO - 2017-03-15 15:19:55 --> Database Driver Class Initialized
INFO - 2017-03-15 15:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:19:55 --> Controller Class Initialized
INFO - 2017-03-15 15:19:55 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:19:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:19:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:19:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:19:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:19:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:19:55 --> Final output sent to browser
DEBUG - 2017-03-15 15:19:55 --> Total execution time: 1.5031
INFO - 2017-03-15 15:20:21 --> Config Class Initialized
INFO - 2017-03-15 15:20:21 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:20:21 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:20:21 --> Utf8 Class Initialized
INFO - 2017-03-15 15:20:21 --> URI Class Initialized
DEBUG - 2017-03-15 15:20:21 --> No URI present. Default controller set.
INFO - 2017-03-15 15:20:21 --> Router Class Initialized
INFO - 2017-03-15 15:20:21 --> Output Class Initialized
INFO - 2017-03-15 15:20:21 --> Security Class Initialized
DEBUG - 2017-03-15 15:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:20:21 --> Input Class Initialized
INFO - 2017-03-15 15:20:21 --> Language Class Initialized
INFO - 2017-03-15 15:20:21 --> Loader Class Initialized
INFO - 2017-03-15 15:20:22 --> Database Driver Class Initialized
INFO - 2017-03-15 15:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:20:22 --> Controller Class Initialized
INFO - 2017-03-15 15:20:22 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:20:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:20:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:20:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:20:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:20:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:20:22 --> Final output sent to browser
DEBUG - 2017-03-15 15:20:22 --> Total execution time: 1.4927
INFO - 2017-03-15 15:33:19 --> Config Class Initialized
INFO - 2017-03-15 15:33:19 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:33:20 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:33:20 --> Utf8 Class Initialized
INFO - 2017-03-15 15:33:20 --> URI Class Initialized
DEBUG - 2017-03-15 15:33:20 --> No URI present. Default controller set.
INFO - 2017-03-15 15:33:20 --> Router Class Initialized
INFO - 2017-03-15 15:33:20 --> Output Class Initialized
INFO - 2017-03-15 15:33:20 --> Security Class Initialized
DEBUG - 2017-03-15 15:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:33:20 --> Input Class Initialized
INFO - 2017-03-15 15:33:20 --> Language Class Initialized
INFO - 2017-03-15 15:33:20 --> Loader Class Initialized
INFO - 2017-03-15 15:33:20 --> Database Driver Class Initialized
INFO - 2017-03-15 15:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:33:21 --> Controller Class Initialized
INFO - 2017-03-15 15:33:21 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:33:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:33:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:33:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:33:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:33:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:33:21 --> Final output sent to browser
DEBUG - 2017-03-15 15:33:21 --> Total execution time: 1.4569
INFO - 2017-03-15 15:34:50 --> Config Class Initialized
INFO - 2017-03-15 15:34:50 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:34:50 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:34:50 --> Utf8 Class Initialized
INFO - 2017-03-15 15:34:50 --> URI Class Initialized
INFO - 2017-03-15 15:34:51 --> Router Class Initialized
INFO - 2017-03-15 15:34:51 --> Output Class Initialized
INFO - 2017-03-15 15:34:51 --> Security Class Initialized
DEBUG - 2017-03-15 15:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:34:51 --> Input Class Initialized
INFO - 2017-03-15 15:34:51 --> Language Class Initialized
INFO - 2017-03-15 15:34:51 --> Loader Class Initialized
INFO - 2017-03-15 15:34:51 --> Database Driver Class Initialized
INFO - 2017-03-15 15:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:34:51 --> Controller Class Initialized
INFO - 2017-03-15 15:34:51 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:34:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:34:53 --> Config Class Initialized
INFO - 2017-03-15 15:34:53 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:34:53 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:34:53 --> Utf8 Class Initialized
INFO - 2017-03-15 15:34:53 --> URI Class Initialized
INFO - 2017-03-15 15:34:53 --> Router Class Initialized
INFO - 2017-03-15 15:34:53 --> Output Class Initialized
INFO - 2017-03-15 15:34:53 --> Security Class Initialized
DEBUG - 2017-03-15 15:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:34:53 --> Input Class Initialized
INFO - 2017-03-15 15:34:53 --> Language Class Initialized
INFO - 2017-03-15 15:34:53 --> Loader Class Initialized
INFO - 2017-03-15 15:34:53 --> Database Driver Class Initialized
INFO - 2017-03-15 15:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:34:53 --> Controller Class Initialized
INFO - 2017-03-15 15:34:53 --> Helper loaded: date_helper
DEBUG - 2017-03-15 15:34:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:34:53 --> Helper loaded: url_helper
INFO - 2017-03-15 15:34:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:34:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-15 15:34:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-15 15:34:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 15:34:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:34:54 --> Final output sent to browser
DEBUG - 2017-03-15 15:34:54 --> Total execution time: 0.3311
INFO - 2017-03-15 15:35:23 --> Config Class Initialized
INFO - 2017-03-15 15:35:23 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:35:23 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:35:23 --> Utf8 Class Initialized
INFO - 2017-03-15 15:35:23 --> URI Class Initialized
INFO - 2017-03-15 15:35:23 --> Router Class Initialized
INFO - 2017-03-15 15:35:23 --> Output Class Initialized
INFO - 2017-03-15 15:35:23 --> Security Class Initialized
DEBUG - 2017-03-15 15:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:35:23 --> Input Class Initialized
INFO - 2017-03-15 15:35:23 --> Language Class Initialized
INFO - 2017-03-15 15:35:23 --> Loader Class Initialized
INFO - 2017-03-15 15:35:23 --> Database Driver Class Initialized
INFO - 2017-03-15 15:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:35:23 --> Controller Class Initialized
INFO - 2017-03-15 15:35:23 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:35:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:35:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:35:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:35:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:35:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:35:23 --> Final output sent to browser
DEBUG - 2017-03-15 15:35:23 --> Total execution time: 0.0369
INFO - 2017-03-15 15:36:13 --> Config Class Initialized
INFO - 2017-03-15 15:36:13 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:36:13 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:36:13 --> Utf8 Class Initialized
INFO - 2017-03-15 15:36:13 --> URI Class Initialized
INFO - 2017-03-15 15:36:13 --> Router Class Initialized
INFO - 2017-03-15 15:36:13 --> Output Class Initialized
INFO - 2017-03-15 15:36:14 --> Security Class Initialized
DEBUG - 2017-03-15 15:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:36:14 --> Input Class Initialized
INFO - 2017-03-15 15:36:14 --> Language Class Initialized
INFO - 2017-03-15 15:36:14 --> Loader Class Initialized
INFO - 2017-03-15 15:36:14 --> Database Driver Class Initialized
INFO - 2017-03-15 15:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:36:14 --> Controller Class Initialized
INFO - 2017-03-15 15:36:15 --> Helper loaded: date_helper
DEBUG - 2017-03-15 15:36:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:36:15 --> Helper loaded: url_helper
INFO - 2017-03-15 15:36:15 --> Helper loaded: download_helper
INFO - 2017-03-15 15:36:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:36:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-15 15:36:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-15 15:36:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-15 15:36:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:36:15 --> Final output sent to browser
DEBUG - 2017-03-15 15:36:15 --> Total execution time: 1.8876
INFO - 2017-03-15 15:36:57 --> Config Class Initialized
INFO - 2017-03-15 15:36:57 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:36:57 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:36:57 --> Utf8 Class Initialized
INFO - 2017-03-15 15:36:57 --> URI Class Initialized
INFO - 2017-03-15 15:36:57 --> Router Class Initialized
INFO - 2017-03-15 15:36:57 --> Output Class Initialized
INFO - 2017-03-15 15:36:57 --> Security Class Initialized
DEBUG - 2017-03-15 15:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:36:57 --> Input Class Initialized
INFO - 2017-03-15 15:36:57 --> Language Class Initialized
INFO - 2017-03-15 15:36:57 --> Loader Class Initialized
INFO - 2017-03-15 15:36:58 --> Database Driver Class Initialized
INFO - 2017-03-15 15:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:36:58 --> Controller Class Initialized
INFO - 2017-03-15 15:36:58 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:36:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:36:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:36:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:36:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:36:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:36:58 --> Final output sent to browser
DEBUG - 2017-03-15 15:36:58 --> Total execution time: 1.4461
INFO - 2017-03-15 15:40:26 --> Config Class Initialized
INFO - 2017-03-15 15:40:26 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:40:26 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:40:26 --> Utf8 Class Initialized
INFO - 2017-03-15 15:40:26 --> URI Class Initialized
INFO - 2017-03-15 15:40:26 --> Router Class Initialized
INFO - 2017-03-15 15:40:26 --> Output Class Initialized
INFO - 2017-03-15 15:40:26 --> Security Class Initialized
DEBUG - 2017-03-15 15:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:40:26 --> Input Class Initialized
INFO - 2017-03-15 15:40:26 --> Language Class Initialized
INFO - 2017-03-15 15:40:26 --> Loader Class Initialized
INFO - 2017-03-15 15:40:27 --> Database Driver Class Initialized
INFO - 2017-03-15 15:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:40:27 --> Controller Class Initialized
INFO - 2017-03-15 15:40:27 --> Helper loaded: date_helper
DEBUG - 2017-03-15 15:40:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:40:27 --> Helper loaded: url_helper
INFO - 2017-03-15 15:40:27 --> Helper loaded: download_helper
INFO - 2017-03-15 15:40:27 --> Final output sent to browser
DEBUG - 2017-03-15 15:40:27 --> Total execution time: 1.2790
INFO - 2017-03-15 15:40:31 --> Config Class Initialized
INFO - 2017-03-15 15:40:31 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:40:31 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:40:31 --> Utf8 Class Initialized
INFO - 2017-03-15 15:40:31 --> URI Class Initialized
INFO - 2017-03-15 15:40:31 --> Router Class Initialized
INFO - 2017-03-15 15:40:31 --> Output Class Initialized
INFO - 2017-03-15 15:40:31 --> Security Class Initialized
DEBUG - 2017-03-15 15:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:40:31 --> Input Class Initialized
INFO - 2017-03-15 15:40:31 --> Language Class Initialized
INFO - 2017-03-15 15:40:31 --> Loader Class Initialized
INFO - 2017-03-15 15:40:31 --> Database Driver Class Initialized
INFO - 2017-03-15 15:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:40:31 --> Controller Class Initialized
INFO - 2017-03-15 15:40:31 --> Helper loaded: date_helper
DEBUG - 2017-03-15 15:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:40:31 --> Helper loaded: url_helper
INFO - 2017-03-15 15:40:31 --> Helper loaded: download_helper
INFO - 2017-03-15 15:40:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:40:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-15 15:40:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-15 15:40:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-15 15:40:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:40:31 --> Final output sent to browser
DEBUG - 2017-03-15 15:40:31 --> Total execution time: 0.1235
INFO - 2017-03-15 15:40:33 --> Config Class Initialized
INFO - 2017-03-15 15:40:33 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:40:33 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:40:33 --> Utf8 Class Initialized
INFO - 2017-03-15 15:40:33 --> URI Class Initialized
INFO - 2017-03-15 15:40:33 --> Router Class Initialized
INFO - 2017-03-15 15:40:33 --> Output Class Initialized
INFO - 2017-03-15 15:40:33 --> Security Class Initialized
DEBUG - 2017-03-15 15:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:40:33 --> Input Class Initialized
INFO - 2017-03-15 15:40:33 --> Language Class Initialized
INFO - 2017-03-15 15:40:33 --> Loader Class Initialized
INFO - 2017-03-15 15:40:33 --> Database Driver Class Initialized
INFO - 2017-03-15 15:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:40:33 --> Controller Class Initialized
INFO - 2017-03-15 15:40:33 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:40:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:40:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:40:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:40:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:40:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:40:33 --> Final output sent to browser
DEBUG - 2017-03-15 15:40:33 --> Total execution time: 0.2490
INFO - 2017-03-15 15:42:24 --> Config Class Initialized
INFO - 2017-03-15 15:42:24 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:42:24 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:42:24 --> Utf8 Class Initialized
INFO - 2017-03-15 15:42:24 --> URI Class Initialized
INFO - 2017-03-15 15:42:24 --> Router Class Initialized
INFO - 2017-03-15 15:42:24 --> Output Class Initialized
INFO - 2017-03-15 15:42:24 --> Security Class Initialized
DEBUG - 2017-03-15 15:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:42:24 --> Input Class Initialized
INFO - 2017-03-15 15:42:24 --> Language Class Initialized
INFO - 2017-03-15 15:42:24 --> Loader Class Initialized
INFO - 2017-03-15 15:42:24 --> Database Driver Class Initialized
INFO - 2017-03-15 15:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:42:25 --> Controller Class Initialized
INFO - 2017-03-15 15:42:25 --> Helper loaded: date_helper
DEBUG - 2017-03-15 15:42:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:42:25 --> Helper loaded: url_helper
INFO - 2017-03-15 15:42:25 --> Helper loaded: download_helper
INFO - 2017-03-15 15:42:25 --> Final output sent to browser
DEBUG - 2017-03-15 15:42:25 --> Total execution time: 1.2913
INFO - 2017-03-15 15:42:26 --> Config Class Initialized
INFO - 2017-03-15 15:42:26 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:42:26 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:42:26 --> Utf8 Class Initialized
INFO - 2017-03-15 15:42:26 --> URI Class Initialized
INFO - 2017-03-15 15:42:26 --> Router Class Initialized
INFO - 2017-03-15 15:42:26 --> Output Class Initialized
INFO - 2017-03-15 15:42:26 --> Security Class Initialized
DEBUG - 2017-03-15 15:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:42:26 --> Input Class Initialized
INFO - 2017-03-15 15:42:26 --> Language Class Initialized
INFO - 2017-03-15 15:42:26 --> Loader Class Initialized
INFO - 2017-03-15 15:42:26 --> Database Driver Class Initialized
INFO - 2017-03-15 15:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:42:26 --> Controller Class Initialized
INFO - 2017-03-15 15:42:26 --> Helper loaded: date_helper
DEBUG - 2017-03-15 15:42:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:42:26 --> Helper loaded: url_helper
INFO - 2017-03-15 15:42:26 --> Helper loaded: download_helper
INFO - 2017-03-15 15:42:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:42:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-15 15:42:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-15 15:42:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-15 15:42:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:42:26 --> Final output sent to browser
DEBUG - 2017-03-15 15:42:26 --> Total execution time: 0.0895
INFO - 2017-03-15 15:42:35 --> Config Class Initialized
INFO - 2017-03-15 15:42:35 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:42:35 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:42:35 --> Utf8 Class Initialized
INFO - 2017-03-15 15:42:35 --> URI Class Initialized
INFO - 2017-03-15 15:42:35 --> Router Class Initialized
INFO - 2017-03-15 15:42:35 --> Output Class Initialized
INFO - 2017-03-15 15:42:35 --> Security Class Initialized
DEBUG - 2017-03-15 15:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:42:36 --> Input Class Initialized
INFO - 2017-03-15 15:42:36 --> Language Class Initialized
INFO - 2017-03-15 15:42:36 --> Loader Class Initialized
INFO - 2017-03-15 15:42:36 --> Database Driver Class Initialized
INFO - 2017-03-15 15:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:42:36 --> Controller Class Initialized
INFO - 2017-03-15 15:42:36 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:42:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:42:37 --> Final output sent to browser
DEBUG - 2017-03-15 15:42:37 --> Total execution time: 1.5229
INFO - 2017-03-15 15:42:57 --> Config Class Initialized
INFO - 2017-03-15 15:42:57 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:42:57 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:42:57 --> Utf8 Class Initialized
INFO - 2017-03-15 15:42:57 --> URI Class Initialized
INFO - 2017-03-15 15:42:57 --> Router Class Initialized
INFO - 2017-03-15 15:42:57 --> Output Class Initialized
INFO - 2017-03-15 15:42:57 --> Security Class Initialized
DEBUG - 2017-03-15 15:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:42:58 --> Input Class Initialized
INFO - 2017-03-15 15:42:58 --> Language Class Initialized
INFO - 2017-03-15 15:42:58 --> Loader Class Initialized
INFO - 2017-03-15 15:42:58 --> Database Driver Class Initialized
INFO - 2017-03-15 15:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:42:58 --> Controller Class Initialized
INFO - 2017-03-15 15:42:58 --> Helper loaded: date_helper
DEBUG - 2017-03-15 15:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:42:58 --> Helper loaded: url_helper
INFO - 2017-03-15 15:42:58 --> Helper loaded: download_helper
INFO - 2017-03-15 15:42:58 --> Final output sent to browser
DEBUG - 2017-03-15 15:42:58 --> Total execution time: 1.0247
INFO - 2017-03-15 15:43:01 --> Config Class Initialized
INFO - 2017-03-15 15:43:01 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:43:01 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:43:01 --> Utf8 Class Initialized
INFO - 2017-03-15 15:43:01 --> URI Class Initialized
INFO - 2017-03-15 15:43:01 --> Router Class Initialized
INFO - 2017-03-15 15:43:01 --> Output Class Initialized
INFO - 2017-03-15 15:43:01 --> Security Class Initialized
DEBUG - 2017-03-15 15:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:43:02 --> Input Class Initialized
INFO - 2017-03-15 15:43:02 --> Language Class Initialized
INFO - 2017-03-15 15:43:02 --> Loader Class Initialized
INFO - 2017-03-15 15:43:02 --> Database Driver Class Initialized
INFO - 2017-03-15 15:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:43:02 --> Controller Class Initialized
INFO - 2017-03-15 15:43:02 --> Helper loaded: date_helper
DEBUG - 2017-03-15 15:43:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:43:02 --> Helper loaded: url_helper
INFO - 2017-03-15 15:43:02 --> Helper loaded: download_helper
INFO - 2017-03-15 15:43:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:43:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-15 15:43:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-15 15:43:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-15 15:43:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:43:02 --> Final output sent to browser
DEBUG - 2017-03-15 15:43:02 --> Total execution time: 1.2756
INFO - 2017-03-15 15:43:05 --> Config Class Initialized
INFO - 2017-03-15 15:43:05 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:43:06 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:43:06 --> Utf8 Class Initialized
INFO - 2017-03-15 15:43:06 --> URI Class Initialized
INFO - 2017-03-15 15:43:06 --> Router Class Initialized
INFO - 2017-03-15 15:43:06 --> Output Class Initialized
INFO - 2017-03-15 15:43:06 --> Security Class Initialized
DEBUG - 2017-03-15 15:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:43:06 --> Input Class Initialized
INFO - 2017-03-15 15:43:06 --> Language Class Initialized
INFO - 2017-03-15 15:43:06 --> Loader Class Initialized
INFO - 2017-03-15 15:43:06 --> Database Driver Class Initialized
INFO - 2017-03-15 15:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:43:06 --> Controller Class Initialized
INFO - 2017-03-15 15:43:06 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:43:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:43:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:43:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:43:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:43:07 --> Final output sent to browser
DEBUG - 2017-03-15 15:43:07 --> Total execution time: 1.2611
INFO - 2017-03-15 15:43:09 --> Config Class Initialized
INFO - 2017-03-15 15:43:09 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:43:09 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:43:09 --> Utf8 Class Initialized
INFO - 2017-03-15 15:43:09 --> URI Class Initialized
INFO - 2017-03-15 15:43:09 --> Router Class Initialized
INFO - 2017-03-15 15:43:09 --> Output Class Initialized
INFO - 2017-03-15 15:43:09 --> Security Class Initialized
DEBUG - 2017-03-15 15:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:43:10 --> Input Class Initialized
INFO - 2017-03-15 15:43:10 --> Language Class Initialized
INFO - 2017-03-15 15:43:10 --> Loader Class Initialized
INFO - 2017-03-15 15:43:10 --> Database Driver Class Initialized
INFO - 2017-03-15 15:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:43:10 --> Controller Class Initialized
INFO - 2017-03-15 15:43:10 --> Helper loaded: date_helper
DEBUG - 2017-03-15 15:43:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:43:10 --> Helper loaded: url_helper
INFO - 2017-03-15 15:43:10 --> Helper loaded: download_helper
INFO - 2017-03-15 15:43:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:43:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-15 15:43:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-15 15:43:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-15 15:43:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:43:10 --> Final output sent to browser
DEBUG - 2017-03-15 15:43:10 --> Total execution time: 1.2029
INFO - 2017-03-15 15:43:12 --> Config Class Initialized
INFO - 2017-03-15 15:43:12 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:43:12 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:43:12 --> Utf8 Class Initialized
INFO - 2017-03-15 15:43:12 --> URI Class Initialized
INFO - 2017-03-15 15:43:12 --> Router Class Initialized
INFO - 2017-03-15 15:43:12 --> Output Class Initialized
INFO - 2017-03-15 15:43:12 --> Security Class Initialized
DEBUG - 2017-03-15 15:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:43:12 --> Input Class Initialized
INFO - 2017-03-15 15:43:12 --> Language Class Initialized
INFO - 2017-03-15 15:43:12 --> Loader Class Initialized
INFO - 2017-03-15 15:43:12 --> Database Driver Class Initialized
INFO - 2017-03-15 15:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:43:12 --> Controller Class Initialized
INFO - 2017-03-15 15:43:12 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:43:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:43:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:43:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:43:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:43:13 --> Final output sent to browser
DEBUG - 2017-03-15 15:43:13 --> Total execution time: 0.2565
INFO - 2017-03-15 15:43:45 --> Config Class Initialized
INFO - 2017-03-15 15:43:45 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:43:45 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:43:45 --> Utf8 Class Initialized
INFO - 2017-03-15 15:43:45 --> URI Class Initialized
INFO - 2017-03-15 15:43:45 --> Router Class Initialized
INFO - 2017-03-15 15:43:45 --> Output Class Initialized
INFO - 2017-03-15 15:43:45 --> Security Class Initialized
DEBUG - 2017-03-15 15:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:43:45 --> Input Class Initialized
INFO - 2017-03-15 15:43:45 --> Language Class Initialized
INFO - 2017-03-15 15:43:45 --> Loader Class Initialized
INFO - 2017-03-15 15:43:45 --> Database Driver Class Initialized
INFO - 2017-03-15 15:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:43:46 --> Controller Class Initialized
INFO - 2017-03-15 15:43:46 --> Helper loaded: date_helper
INFO - 2017-03-15 15:43:46 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:43:46 --> Helper loaded: form_helper
INFO - 2017-03-15 15:43:46 --> Form Validation Class Initialized
INFO - 2017-03-15 15:43:46 --> Final output sent to browser
DEBUG - 2017-03-15 15:43:46 --> Total execution time: 1.6740
INFO - 2017-03-15 15:44:24 --> Config Class Initialized
INFO - 2017-03-15 15:44:24 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:44:24 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:44:24 --> Utf8 Class Initialized
INFO - 2017-03-15 15:44:24 --> URI Class Initialized
INFO - 2017-03-15 15:44:24 --> Router Class Initialized
INFO - 2017-03-15 15:44:24 --> Output Class Initialized
INFO - 2017-03-15 15:44:24 --> Security Class Initialized
DEBUG - 2017-03-15 15:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:44:24 --> Input Class Initialized
INFO - 2017-03-15 15:44:24 --> Language Class Initialized
INFO - 2017-03-15 15:44:24 --> Loader Class Initialized
INFO - 2017-03-15 15:44:25 --> Database Driver Class Initialized
INFO - 2017-03-15 15:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:44:25 --> Controller Class Initialized
INFO - 2017-03-15 15:44:25 --> Helper loaded: date_helper
DEBUG - 2017-03-15 15:44:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:44:25 --> Helper loaded: url_helper
INFO - 2017-03-15 15:44:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:44:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-15 15:44:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-15 15:44:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 15:44:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:44:25 --> Final output sent to browser
DEBUG - 2017-03-15 15:44:25 --> Total execution time: 1.2733
INFO - 2017-03-15 15:44:26 --> Config Class Initialized
INFO - 2017-03-15 15:44:26 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:44:26 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:44:26 --> Utf8 Class Initialized
INFO - 2017-03-15 15:44:26 --> URI Class Initialized
INFO - 2017-03-15 15:44:26 --> Router Class Initialized
INFO - 2017-03-15 15:44:26 --> Output Class Initialized
INFO - 2017-03-15 15:44:26 --> Security Class Initialized
DEBUG - 2017-03-15 15:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:44:26 --> Input Class Initialized
INFO - 2017-03-15 15:44:26 --> Language Class Initialized
INFO - 2017-03-15 15:44:26 --> Loader Class Initialized
INFO - 2017-03-15 15:44:26 --> Database Driver Class Initialized
INFO - 2017-03-15 15:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:44:26 --> Controller Class Initialized
INFO - 2017-03-15 15:44:26 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:44:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:44:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:44:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:44:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:44:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:44:27 --> Final output sent to browser
DEBUG - 2017-03-15 15:44:27 --> Total execution time: 0.2680
INFO - 2017-03-15 15:45:59 --> Config Class Initialized
INFO - 2017-03-15 15:45:59 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:45:59 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:45:59 --> Utf8 Class Initialized
INFO - 2017-03-15 15:45:59 --> URI Class Initialized
INFO - 2017-03-15 15:45:59 --> Router Class Initialized
INFO - 2017-03-15 15:45:59 --> Output Class Initialized
INFO - 2017-03-15 15:45:59 --> Security Class Initialized
DEBUG - 2017-03-15 15:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:46:00 --> Input Class Initialized
INFO - 2017-03-15 15:46:00 --> Language Class Initialized
INFO - 2017-03-15 15:46:00 --> Loader Class Initialized
INFO - 2017-03-15 15:46:00 --> Database Driver Class Initialized
INFO - 2017-03-15 15:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:46:00 --> Controller Class Initialized
INFO - 2017-03-15 15:46:00 --> Helper loaded: date_helper
DEBUG - 2017-03-15 15:46:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:46:00 --> Helper loaded: url_helper
INFO - 2017-03-15 15:46:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:46:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-03-15 15:46:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-15 15:46:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-03-15 15:46:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-03-15 15:46:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:46:01 --> Final output sent to browser
DEBUG - 2017-03-15 15:46:01 --> Total execution time: 1.5711
INFO - 2017-03-15 15:46:04 --> Config Class Initialized
INFO - 2017-03-15 15:46:04 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:46:04 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:46:04 --> Utf8 Class Initialized
INFO - 2017-03-15 15:46:04 --> URI Class Initialized
INFO - 2017-03-15 15:46:04 --> Router Class Initialized
INFO - 2017-03-15 15:46:04 --> Output Class Initialized
INFO - 2017-03-15 15:46:04 --> Security Class Initialized
DEBUG - 2017-03-15 15:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:46:04 --> Input Class Initialized
INFO - 2017-03-15 15:46:04 --> Language Class Initialized
INFO - 2017-03-15 15:46:04 --> Loader Class Initialized
INFO - 2017-03-15 15:46:04 --> Database Driver Class Initialized
INFO - 2017-03-15 15:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:46:04 --> Controller Class Initialized
INFO - 2017-03-15 15:46:04 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:46:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:46:04 --> Final output sent to browser
DEBUG - 2017-03-15 15:46:04 --> Total execution time: 0.2626
INFO - 2017-03-15 15:46:06 --> Config Class Initialized
INFO - 2017-03-15 15:46:06 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:46:06 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:46:06 --> Utf8 Class Initialized
INFO - 2017-03-15 15:46:06 --> URI Class Initialized
INFO - 2017-03-15 15:46:06 --> Router Class Initialized
INFO - 2017-03-15 15:46:06 --> Output Class Initialized
INFO - 2017-03-15 15:46:06 --> Security Class Initialized
DEBUG - 2017-03-15 15:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:46:06 --> Input Class Initialized
INFO - 2017-03-15 15:46:06 --> Language Class Initialized
INFO - 2017-03-15 15:46:06 --> Loader Class Initialized
INFO - 2017-03-15 15:46:06 --> Database Driver Class Initialized
INFO - 2017-03-15 15:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:46:06 --> Controller Class Initialized
INFO - 2017-03-15 15:46:06 --> Upload Class Initialized
INFO - 2017-03-15 15:46:06 --> Helper loaded: date_helper
DEBUG - 2017-03-15 15:46:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:46:06 --> Helper loaded: url_helper
INFO - 2017-03-15 15:46:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:46:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-15 15:46:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-03-15 15:46:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-03-15 15:46:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-15 15:46:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:46:07 --> Final output sent to browser
DEBUG - 2017-03-15 15:46:07 --> Total execution time: 0.1950
INFO - 2017-03-15 15:46:08 --> Config Class Initialized
INFO - 2017-03-15 15:46:08 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:46:08 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:46:08 --> Utf8 Class Initialized
INFO - 2017-03-15 15:46:08 --> URI Class Initialized
INFO - 2017-03-15 15:46:08 --> Router Class Initialized
INFO - 2017-03-15 15:46:08 --> Output Class Initialized
INFO - 2017-03-15 15:46:08 --> Security Class Initialized
DEBUG - 2017-03-15 15:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:46:08 --> Input Class Initialized
INFO - 2017-03-15 15:46:08 --> Language Class Initialized
INFO - 2017-03-15 15:46:08 --> Loader Class Initialized
INFO - 2017-03-15 15:46:08 --> Database Driver Class Initialized
INFO - 2017-03-15 15:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:46:08 --> Controller Class Initialized
INFO - 2017-03-15 15:46:08 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:46:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:46:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:46:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:46:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:46:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:46:08 --> Final output sent to browser
DEBUG - 2017-03-15 15:46:08 --> Total execution time: 0.0136
INFO - 2017-03-15 15:46:41 --> Config Class Initialized
INFO - 2017-03-15 15:46:41 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:46:41 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:46:41 --> Utf8 Class Initialized
INFO - 2017-03-15 15:46:41 --> URI Class Initialized
INFO - 2017-03-15 15:46:41 --> Router Class Initialized
INFO - 2017-03-15 15:46:41 --> Output Class Initialized
INFO - 2017-03-15 15:46:41 --> Security Class Initialized
DEBUG - 2017-03-15 15:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:46:41 --> Input Class Initialized
INFO - 2017-03-15 15:46:41 --> Language Class Initialized
INFO - 2017-03-15 15:46:41 --> Loader Class Initialized
INFO - 2017-03-15 15:46:42 --> Database Driver Class Initialized
INFO - 2017-03-15 15:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:46:42 --> Controller Class Initialized
INFO - 2017-03-15 15:46:42 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:46:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:46:43 --> Config Class Initialized
INFO - 2017-03-15 15:46:43 --> Config Class Initialized
INFO - 2017-03-15 15:46:43 --> Hooks Class Initialized
INFO - 2017-03-15 15:46:43 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:46:43 --> UTF-8 Support Enabled
DEBUG - 2017-03-15 15:46:43 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:46:43 --> Utf8 Class Initialized
INFO - 2017-03-15 15:46:43 --> Utf8 Class Initialized
INFO - 2017-03-15 15:46:43 --> URI Class Initialized
INFO - 2017-03-15 15:46:43 --> URI Class Initialized
DEBUG - 2017-03-15 15:46:43 --> No URI present. Default controller set.
INFO - 2017-03-15 15:46:43 --> Router Class Initialized
INFO - 2017-03-15 15:46:43 --> Router Class Initialized
INFO - 2017-03-15 15:46:43 --> Output Class Initialized
INFO - 2017-03-15 15:46:43 --> Output Class Initialized
INFO - 2017-03-15 15:46:43 --> Security Class Initialized
INFO - 2017-03-15 15:46:43 --> Security Class Initialized
DEBUG - 2017-03-15 15:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:46:43 --> Input Class Initialized
INFO - 2017-03-15 15:46:43 --> Language Class Initialized
DEBUG - 2017-03-15 15:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:46:43 --> Input Class Initialized
INFO - 2017-03-15 15:46:43 --> Language Class Initialized
INFO - 2017-03-15 15:46:43 --> Loader Class Initialized
INFO - 2017-03-15 15:46:43 --> Loader Class Initialized
INFO - 2017-03-15 15:46:43 --> Database Driver Class Initialized
INFO - 2017-03-15 15:46:43 --> Database Driver Class Initialized
INFO - 2017-03-15 15:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:46:44 --> Controller Class Initialized
INFO - 2017-03-15 15:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:46:44 --> Controller Class Initialized
INFO - 2017-03-15 15:46:44 --> Helper loaded: url_helper
INFO - 2017-03-15 15:46:44 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:46:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-15 15:46:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:46:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:46:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:46:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:46:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:46:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:46:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:46:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:46:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:46:44 --> Final output sent to browser
DEBUG - 2017-03-15 15:46:44 --> Total execution time: 1.8380
INFO - 2017-03-15 15:46:44 --> Final output sent to browser
DEBUG - 2017-03-15 15:46:44 --> Total execution time: 1.8377
INFO - 2017-03-15 15:46:57 --> Config Class Initialized
INFO - 2017-03-15 15:46:57 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:46:58 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:46:58 --> Utf8 Class Initialized
INFO - 2017-03-15 15:46:58 --> URI Class Initialized
INFO - 2017-03-15 15:46:58 --> Router Class Initialized
INFO - 2017-03-15 15:46:58 --> Output Class Initialized
INFO - 2017-03-15 15:46:58 --> Security Class Initialized
DEBUG - 2017-03-15 15:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:46:58 --> Input Class Initialized
INFO - 2017-03-15 15:46:58 --> Language Class Initialized
INFO - 2017-03-15 15:46:58 --> Loader Class Initialized
INFO - 2017-03-15 15:46:58 --> Database Driver Class Initialized
INFO - 2017-03-15 15:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:46:59 --> Controller Class Initialized
INFO - 2017-03-15 15:46:59 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:46:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:46:59 --> Helper loaded: form_helper
INFO - 2017-03-15 15:46:59 --> Form Validation Class Initialized
INFO - 2017-03-15 15:46:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-15 15:46:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-03-15 15:46:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-15 15:46:59 --> Final output sent to browser
DEBUG - 2017-03-15 15:46:59 --> Total execution time: 1.4480
INFO - 2017-03-15 15:47:01 --> Config Class Initialized
INFO - 2017-03-15 15:47:01 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:47:01 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:47:01 --> Utf8 Class Initialized
INFO - 2017-03-15 15:47:01 --> URI Class Initialized
INFO - 2017-03-15 15:47:01 --> Router Class Initialized
INFO - 2017-03-15 15:47:01 --> Output Class Initialized
INFO - 2017-03-15 15:47:01 --> Security Class Initialized
DEBUG - 2017-03-15 15:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:47:01 --> Input Class Initialized
INFO - 2017-03-15 15:47:01 --> Language Class Initialized
INFO - 2017-03-15 15:47:01 --> Loader Class Initialized
INFO - 2017-03-15 15:47:02 --> Database Driver Class Initialized
INFO - 2017-03-15 15:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:47:02 --> Controller Class Initialized
INFO - 2017-03-15 15:47:02 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:47:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:47:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:47:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:47:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:47:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:47:02 --> Final output sent to browser
DEBUG - 2017-03-15 15:47:02 --> Total execution time: 1.2474
INFO - 2017-03-15 15:47:23 --> Config Class Initialized
INFO - 2017-03-15 15:47:23 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:47:23 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:47:23 --> Utf8 Class Initialized
INFO - 2017-03-15 15:47:23 --> URI Class Initialized
INFO - 2017-03-15 15:47:23 --> Router Class Initialized
INFO - 2017-03-15 15:47:23 --> Output Class Initialized
INFO - 2017-03-15 15:47:23 --> Security Class Initialized
DEBUG - 2017-03-15 15:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:47:23 --> Input Class Initialized
INFO - 2017-03-15 15:47:23 --> Language Class Initialized
INFO - 2017-03-15 15:47:23 --> Loader Class Initialized
INFO - 2017-03-15 15:47:24 --> Database Driver Class Initialized
INFO - 2017-03-15 15:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:47:24 --> Controller Class Initialized
INFO - 2017-03-15 15:47:24 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:47:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:47:24 --> Helper loaded: form_helper
INFO - 2017-03-15 15:47:24 --> Form Validation Class Initialized
INFO - 2017-03-15 15:47:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-15 15:47:24 --> Config Class Initialized
INFO - 2017-03-15 15:47:24 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:47:24 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:47:24 --> Utf8 Class Initialized
INFO - 2017-03-15 15:47:24 --> URI Class Initialized
INFO - 2017-03-15 15:47:24 --> Router Class Initialized
INFO - 2017-03-15 15:47:24 --> Output Class Initialized
INFO - 2017-03-15 15:47:24 --> Security Class Initialized
DEBUG - 2017-03-15 15:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:47:24 --> Input Class Initialized
INFO - 2017-03-15 15:47:24 --> Language Class Initialized
INFO - 2017-03-15 15:47:24 --> Loader Class Initialized
INFO - 2017-03-15 15:47:24 --> Database Driver Class Initialized
INFO - 2017-03-15 15:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:47:24 --> Controller Class Initialized
INFO - 2017-03-15 15:47:24 --> Helper loaded: date_helper
INFO - 2017-03-15 15:47:24 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:47:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:47:24 --> Helper loaded: form_helper
INFO - 2017-03-15 15:47:24 --> Form Validation Class Initialized
INFO - 2017-03-15 15:47:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-15 15:47:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-15 15:47:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-03-15 15:47:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-03-15 15:47:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-15 15:47:24 --> Final output sent to browser
DEBUG - 2017-03-15 15:47:24 --> Total execution time: 0.1810
INFO - 2017-03-15 15:47:25 --> Config Class Initialized
INFO - 2017-03-15 15:47:25 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:47:25 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:47:25 --> Utf8 Class Initialized
INFO - 2017-03-15 15:47:25 --> URI Class Initialized
INFO - 2017-03-15 15:47:25 --> Router Class Initialized
INFO - 2017-03-15 15:47:25 --> Output Class Initialized
INFO - 2017-03-15 15:47:25 --> Security Class Initialized
DEBUG - 2017-03-15 15:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:47:25 --> Input Class Initialized
INFO - 2017-03-15 15:47:25 --> Language Class Initialized
INFO - 2017-03-15 15:47:25 --> Loader Class Initialized
INFO - 2017-03-15 15:47:25 --> Database Driver Class Initialized
INFO - 2017-03-15 15:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:47:25 --> Controller Class Initialized
INFO - 2017-03-15 15:47:25 --> Helper loaded: date_helper
INFO - 2017-03-15 15:47:25 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:47:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:47:25 --> Helper loaded: form_helper
INFO - 2017-03-15 15:47:25 --> Form Validation Class Initialized
INFO - 2017-03-15 15:47:25 --> Final output sent to browser
DEBUG - 2017-03-15 15:47:25 --> Total execution time: 0.0148
INFO - 2017-03-15 15:47:32 --> Config Class Initialized
INFO - 2017-03-15 15:47:32 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:47:32 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:47:32 --> Utf8 Class Initialized
INFO - 2017-03-15 15:47:32 --> URI Class Initialized
INFO - 2017-03-15 15:47:32 --> Router Class Initialized
INFO - 2017-03-15 15:47:32 --> Output Class Initialized
INFO - 2017-03-15 15:47:32 --> Security Class Initialized
DEBUG - 2017-03-15 15:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:47:32 --> Input Class Initialized
INFO - 2017-03-15 15:47:32 --> Language Class Initialized
INFO - 2017-03-15 15:47:32 --> Loader Class Initialized
INFO - 2017-03-15 15:47:32 --> Database Driver Class Initialized
INFO - 2017-03-15 15:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:47:32 --> Controller Class Initialized
INFO - 2017-03-15 15:47:32 --> Helper loaded: date_helper
INFO - 2017-03-15 15:47:32 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:47:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:47:32 --> Helper loaded: form_helper
INFO - 2017-03-15 15:47:32 --> Form Validation Class Initialized
INFO - 2017-03-15 15:47:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-15 15:47:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-03-15 15:47:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-03-15 15:47:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-03-15 15:47:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-15 15:47:32 --> Final output sent to browser
DEBUG - 2017-03-15 15:47:32 --> Total execution time: 0.0673
INFO - 2017-03-15 15:47:33 --> Config Class Initialized
INFO - 2017-03-15 15:47:33 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:47:33 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:47:33 --> Utf8 Class Initialized
INFO - 2017-03-15 15:47:33 --> URI Class Initialized
INFO - 2017-03-15 15:47:33 --> Router Class Initialized
INFO - 2017-03-15 15:47:33 --> Output Class Initialized
INFO - 2017-03-15 15:47:33 --> Security Class Initialized
DEBUG - 2017-03-15 15:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:47:33 --> Input Class Initialized
INFO - 2017-03-15 15:47:33 --> Language Class Initialized
INFO - 2017-03-15 15:47:33 --> Loader Class Initialized
INFO - 2017-03-15 15:47:33 --> Database Driver Class Initialized
INFO - 2017-03-15 15:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:47:33 --> Controller Class Initialized
INFO - 2017-03-15 15:47:33 --> Helper loaded: date_helper
INFO - 2017-03-15 15:47:33 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:47:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:47:33 --> Helper loaded: form_helper
INFO - 2017-03-15 15:47:33 --> Form Validation Class Initialized
INFO - 2017-03-15 15:47:33 --> Final output sent to browser
DEBUG - 2017-03-15 15:47:33 --> Total execution time: 0.0145
INFO - 2017-03-15 15:47:39 --> Config Class Initialized
INFO - 2017-03-15 15:47:39 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:47:39 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:47:39 --> Utf8 Class Initialized
INFO - 2017-03-15 15:47:39 --> URI Class Initialized
INFO - 2017-03-15 15:47:39 --> Router Class Initialized
INFO - 2017-03-15 15:47:39 --> Output Class Initialized
INFO - 2017-03-15 15:47:39 --> Security Class Initialized
DEBUG - 2017-03-15 15:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:47:39 --> Input Class Initialized
INFO - 2017-03-15 15:47:39 --> Language Class Initialized
INFO - 2017-03-15 15:47:39 --> Loader Class Initialized
INFO - 2017-03-15 15:47:39 --> Database Driver Class Initialized
INFO - 2017-03-15 15:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:47:39 --> Controller Class Initialized
INFO - 2017-03-15 15:47:39 --> Helper loaded: date_helper
INFO - 2017-03-15 15:47:39 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:47:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:47:39 --> Helper loaded: form_helper
INFO - 2017-03-15 15:47:39 --> Form Validation Class Initialized
INFO - 2017-03-15 15:47:39 --> Final output sent to browser
DEBUG - 2017-03-15 15:47:39 --> Total execution time: 0.0147
INFO - 2017-03-15 15:47:49 --> Config Class Initialized
INFO - 2017-03-15 15:47:49 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:47:49 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:47:49 --> Utf8 Class Initialized
INFO - 2017-03-15 15:47:49 --> URI Class Initialized
INFO - 2017-03-15 15:47:49 --> Router Class Initialized
INFO - 2017-03-15 15:47:49 --> Output Class Initialized
INFO - 2017-03-15 15:47:49 --> Security Class Initialized
DEBUG - 2017-03-15 15:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:47:49 --> Input Class Initialized
INFO - 2017-03-15 15:47:49 --> Language Class Initialized
INFO - 2017-03-15 15:47:49 --> Loader Class Initialized
INFO - 2017-03-15 15:47:49 --> Database Driver Class Initialized
INFO - 2017-03-15 15:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:47:49 --> Controller Class Initialized
INFO - 2017-03-15 15:47:49 --> Helper loaded: date_helper
INFO - 2017-03-15 15:47:49 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:47:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:47:49 --> Helper loaded: form_helper
INFO - 2017-03-15 15:47:49 --> Form Validation Class Initialized
INFO - 2017-03-15 15:47:49 --> Final output sent to browser
DEBUG - 2017-03-15 15:47:49 --> Total execution time: 0.0149
INFO - 2017-03-15 15:47:54 --> Config Class Initialized
INFO - 2017-03-15 15:47:54 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:47:54 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:47:54 --> Utf8 Class Initialized
INFO - 2017-03-15 15:47:54 --> URI Class Initialized
INFO - 2017-03-15 15:47:54 --> Router Class Initialized
INFO - 2017-03-15 15:47:54 --> Output Class Initialized
INFO - 2017-03-15 15:47:54 --> Security Class Initialized
DEBUG - 2017-03-15 15:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:47:54 --> Input Class Initialized
INFO - 2017-03-15 15:47:54 --> Language Class Initialized
INFO - 2017-03-15 15:47:54 --> Loader Class Initialized
INFO - 2017-03-15 15:47:54 --> Database Driver Class Initialized
INFO - 2017-03-15 15:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:47:54 --> Controller Class Initialized
INFO - 2017-03-15 15:47:54 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:47:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:47:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:47:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:47:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:47:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:47:54 --> Final output sent to browser
DEBUG - 2017-03-15 15:47:54 --> Total execution time: 0.2932
INFO - 2017-03-15 15:48:12 --> Config Class Initialized
INFO - 2017-03-15 15:48:12 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:48:12 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:48:12 --> Utf8 Class Initialized
INFO - 2017-03-15 15:48:12 --> URI Class Initialized
INFO - 2017-03-15 15:48:12 --> Router Class Initialized
INFO - 2017-03-15 15:48:12 --> Output Class Initialized
INFO - 2017-03-15 15:48:12 --> Security Class Initialized
DEBUG - 2017-03-15 15:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:48:12 --> Input Class Initialized
INFO - 2017-03-15 15:48:12 --> Language Class Initialized
INFO - 2017-03-15 15:48:12 --> Loader Class Initialized
INFO - 2017-03-15 15:48:12 --> Database Driver Class Initialized
INFO - 2017-03-15 15:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:48:12 --> Controller Class Initialized
INFO - 2017-03-15 15:48:12 --> Helper loaded: date_helper
INFO - 2017-03-15 15:48:12 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:48:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:48:12 --> Helper loaded: form_helper
INFO - 2017-03-15 15:48:12 --> Form Validation Class Initialized
INFO - 2017-03-15 15:48:12 --> Final output sent to browser
DEBUG - 2017-03-15 15:48:12 --> Total execution time: 0.0224
INFO - 2017-03-15 15:48:17 --> Config Class Initialized
INFO - 2017-03-15 15:48:17 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:48:17 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:48:17 --> Utf8 Class Initialized
INFO - 2017-03-15 15:48:17 --> URI Class Initialized
INFO - 2017-03-15 15:48:17 --> Router Class Initialized
INFO - 2017-03-15 15:48:17 --> Output Class Initialized
INFO - 2017-03-15 15:48:17 --> Security Class Initialized
DEBUG - 2017-03-15 15:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:48:17 --> Input Class Initialized
INFO - 2017-03-15 15:48:17 --> Language Class Initialized
INFO - 2017-03-15 15:48:17 --> Loader Class Initialized
INFO - 2017-03-15 15:48:17 --> Database Driver Class Initialized
INFO - 2017-03-15 15:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:48:17 --> Controller Class Initialized
INFO - 2017-03-15 15:48:17 --> Helper loaded: date_helper
INFO - 2017-03-15 15:48:17 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:48:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:48:17 --> Helper loaded: form_helper
INFO - 2017-03-15 15:48:17 --> Form Validation Class Initialized
INFO - 2017-03-15 15:48:17 --> Final output sent to browser
DEBUG - 2017-03-15 15:48:17 --> Total execution time: 0.0171
INFO - 2017-03-15 15:48:18 --> Config Class Initialized
INFO - 2017-03-15 15:48:18 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:48:18 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:48:18 --> Utf8 Class Initialized
INFO - 2017-03-15 15:48:18 --> URI Class Initialized
INFO - 2017-03-15 15:48:18 --> Router Class Initialized
INFO - 2017-03-15 15:48:18 --> Output Class Initialized
INFO - 2017-03-15 15:48:18 --> Security Class Initialized
DEBUG - 2017-03-15 15:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:48:18 --> Input Class Initialized
INFO - 2017-03-15 15:48:18 --> Language Class Initialized
INFO - 2017-03-15 15:48:18 --> Loader Class Initialized
INFO - 2017-03-15 15:48:18 --> Database Driver Class Initialized
INFO - 2017-03-15 15:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:48:18 --> Controller Class Initialized
INFO - 2017-03-15 15:48:18 --> Helper loaded: date_helper
INFO - 2017-03-15 15:48:18 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:48:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:48:18 --> Helper loaded: form_helper
INFO - 2017-03-15 15:48:18 --> Form Validation Class Initialized
INFO - 2017-03-15 15:48:18 --> Final output sent to browser
DEBUG - 2017-03-15 15:48:18 --> Total execution time: 0.0152
INFO - 2017-03-15 15:48:25 --> Config Class Initialized
INFO - 2017-03-15 15:48:25 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:48:25 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:48:25 --> Utf8 Class Initialized
INFO - 2017-03-15 15:48:25 --> URI Class Initialized
INFO - 2017-03-15 15:48:25 --> Router Class Initialized
INFO - 2017-03-15 15:48:25 --> Output Class Initialized
INFO - 2017-03-15 15:48:25 --> Security Class Initialized
DEBUG - 2017-03-15 15:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:48:25 --> Input Class Initialized
INFO - 2017-03-15 15:48:25 --> Language Class Initialized
INFO - 2017-03-15 15:48:25 --> Loader Class Initialized
INFO - 2017-03-15 15:48:25 --> Database Driver Class Initialized
INFO - 2017-03-15 15:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:48:25 --> Controller Class Initialized
INFO - 2017-03-15 15:48:25 --> Helper loaded: date_helper
INFO - 2017-03-15 15:48:25 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:48:25 --> Helper loaded: form_helper
INFO - 2017-03-15 15:48:25 --> Form Validation Class Initialized
INFO - 2017-03-15 15:48:25 --> Final output sent to browser
DEBUG - 2017-03-15 15:48:25 --> Total execution time: 0.0152
INFO - 2017-03-15 15:48:26 --> Config Class Initialized
INFO - 2017-03-15 15:48:26 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:48:26 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:48:26 --> Utf8 Class Initialized
INFO - 2017-03-15 15:48:26 --> URI Class Initialized
INFO - 2017-03-15 15:48:26 --> Router Class Initialized
INFO - 2017-03-15 15:48:26 --> Output Class Initialized
INFO - 2017-03-15 15:48:26 --> Security Class Initialized
DEBUG - 2017-03-15 15:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:48:26 --> Input Class Initialized
INFO - 2017-03-15 15:48:26 --> Language Class Initialized
INFO - 2017-03-15 15:48:26 --> Loader Class Initialized
INFO - 2017-03-15 15:48:26 --> Database Driver Class Initialized
INFO - 2017-03-15 15:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:48:26 --> Controller Class Initialized
INFO - 2017-03-15 15:48:26 --> Helper loaded: date_helper
INFO - 2017-03-15 15:48:26 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:48:26 --> Helper loaded: form_helper
INFO - 2017-03-15 15:48:26 --> Form Validation Class Initialized
INFO - 2017-03-15 15:48:26 --> Final output sent to browser
DEBUG - 2017-03-15 15:48:26 --> Total execution time: 0.0150
INFO - 2017-03-15 15:48:31 --> Config Class Initialized
INFO - 2017-03-15 15:48:31 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:48:31 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:48:31 --> Utf8 Class Initialized
INFO - 2017-03-15 15:48:31 --> URI Class Initialized
INFO - 2017-03-15 15:48:32 --> Router Class Initialized
INFO - 2017-03-15 15:48:32 --> Output Class Initialized
INFO - 2017-03-15 15:48:32 --> Security Class Initialized
DEBUG - 2017-03-15 15:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:48:32 --> Input Class Initialized
INFO - 2017-03-15 15:48:32 --> Language Class Initialized
INFO - 2017-03-15 15:48:32 --> Loader Class Initialized
INFO - 2017-03-15 15:48:32 --> Database Driver Class Initialized
INFO - 2017-03-15 15:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:48:32 --> Controller Class Initialized
INFO - 2017-03-15 15:48:32 --> Helper loaded: date_helper
INFO - 2017-03-15 15:48:32 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:48:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:48:32 --> Helper loaded: form_helper
INFO - 2017-03-15 15:48:32 --> Form Validation Class Initialized
INFO - 2017-03-15 15:48:32 --> Final output sent to browser
DEBUG - 2017-03-15 15:48:32 --> Total execution time: 0.0193
INFO - 2017-03-15 15:48:32 --> Config Class Initialized
INFO - 2017-03-15 15:48:32 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:48:32 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:48:32 --> Utf8 Class Initialized
INFO - 2017-03-15 15:48:32 --> URI Class Initialized
INFO - 2017-03-15 15:48:32 --> Router Class Initialized
INFO - 2017-03-15 15:48:32 --> Output Class Initialized
INFO - 2017-03-15 15:48:32 --> Security Class Initialized
DEBUG - 2017-03-15 15:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:48:32 --> Input Class Initialized
INFO - 2017-03-15 15:48:32 --> Language Class Initialized
INFO - 2017-03-15 15:48:32 --> Loader Class Initialized
INFO - 2017-03-15 15:48:32 --> Database Driver Class Initialized
INFO - 2017-03-15 15:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:48:32 --> Controller Class Initialized
INFO - 2017-03-15 15:48:32 --> Helper loaded: date_helper
INFO - 2017-03-15 15:48:32 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:48:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:48:32 --> Helper loaded: form_helper
INFO - 2017-03-15 15:48:32 --> Form Validation Class Initialized
INFO - 2017-03-15 15:48:32 --> Final output sent to browser
DEBUG - 2017-03-15 15:48:32 --> Total execution time: 0.0149
INFO - 2017-03-15 15:48:36 --> Config Class Initialized
INFO - 2017-03-15 15:48:36 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:48:36 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:48:36 --> Utf8 Class Initialized
INFO - 2017-03-15 15:48:36 --> URI Class Initialized
INFO - 2017-03-15 15:48:36 --> Router Class Initialized
INFO - 2017-03-15 15:48:36 --> Output Class Initialized
INFO - 2017-03-15 15:48:36 --> Security Class Initialized
DEBUG - 2017-03-15 15:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:48:36 --> Input Class Initialized
INFO - 2017-03-15 15:48:36 --> Language Class Initialized
INFO - 2017-03-15 15:48:36 --> Loader Class Initialized
INFO - 2017-03-15 15:48:36 --> Database Driver Class Initialized
INFO - 2017-03-15 15:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:48:36 --> Controller Class Initialized
INFO - 2017-03-15 15:48:36 --> Helper loaded: date_helper
INFO - 2017-03-15 15:48:36 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:48:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:48:36 --> Helper loaded: form_helper
INFO - 2017-03-15 15:48:36 --> Form Validation Class Initialized
INFO - 2017-03-15 15:48:36 --> Final output sent to browser
DEBUG - 2017-03-15 15:48:36 --> Total execution time: 0.0146
INFO - 2017-03-15 15:48:44 --> Config Class Initialized
INFO - 2017-03-15 15:48:44 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:48:44 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:48:44 --> Utf8 Class Initialized
INFO - 2017-03-15 15:48:44 --> URI Class Initialized
INFO - 2017-03-15 15:48:44 --> Router Class Initialized
INFO - 2017-03-15 15:48:44 --> Output Class Initialized
INFO - 2017-03-15 15:48:44 --> Security Class Initialized
DEBUG - 2017-03-15 15:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:48:44 --> Input Class Initialized
INFO - 2017-03-15 15:48:44 --> Language Class Initialized
INFO - 2017-03-15 15:48:44 --> Loader Class Initialized
INFO - 2017-03-15 15:48:44 --> Database Driver Class Initialized
INFO - 2017-03-15 15:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:48:44 --> Controller Class Initialized
INFO - 2017-03-15 15:48:44 --> Helper loaded: date_helper
INFO - 2017-03-15 15:48:44 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:48:44 --> Helper loaded: form_helper
INFO - 2017-03-15 15:48:44 --> Form Validation Class Initialized
INFO - 2017-03-15 15:48:44 --> Final output sent to browser
DEBUG - 2017-03-15 15:48:44 --> Total execution time: 0.0144
INFO - 2017-03-15 15:48:48 --> Config Class Initialized
INFO - 2017-03-15 15:48:48 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:48:48 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:48:48 --> Utf8 Class Initialized
INFO - 2017-03-15 15:48:48 --> URI Class Initialized
INFO - 2017-03-15 15:48:48 --> Router Class Initialized
INFO - 2017-03-15 15:48:48 --> Output Class Initialized
INFO - 2017-03-15 15:48:48 --> Security Class Initialized
DEBUG - 2017-03-15 15:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:48:48 --> Input Class Initialized
INFO - 2017-03-15 15:48:48 --> Language Class Initialized
INFO - 2017-03-15 15:48:48 --> Loader Class Initialized
INFO - 2017-03-15 15:48:48 --> Database Driver Class Initialized
INFO - 2017-03-15 15:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:48:48 --> Controller Class Initialized
INFO - 2017-03-15 15:48:48 --> Helper loaded: date_helper
INFO - 2017-03-15 15:48:48 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:48:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:48:48 --> Helper loaded: form_helper
INFO - 2017-03-15 15:48:48 --> Form Validation Class Initialized
INFO - 2017-03-15 15:48:48 --> Final output sent to browser
DEBUG - 2017-03-15 15:48:48 --> Total execution time: 0.0147
INFO - 2017-03-15 15:49:02 --> Config Class Initialized
INFO - 2017-03-15 15:49:02 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:49:02 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:49:02 --> Utf8 Class Initialized
INFO - 2017-03-15 15:49:02 --> URI Class Initialized
INFO - 2017-03-15 15:49:02 --> Router Class Initialized
INFO - 2017-03-15 15:49:02 --> Output Class Initialized
INFO - 2017-03-15 15:49:02 --> Security Class Initialized
DEBUG - 2017-03-15 15:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:49:02 --> Input Class Initialized
INFO - 2017-03-15 15:49:02 --> Language Class Initialized
INFO - 2017-03-15 15:49:02 --> Loader Class Initialized
INFO - 2017-03-15 15:49:02 --> Database Driver Class Initialized
INFO - 2017-03-15 15:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:49:02 --> Controller Class Initialized
INFO - 2017-03-15 15:49:02 --> Helper loaded: date_helper
INFO - 2017-03-15 15:49:02 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:49:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:49:02 --> Helper loaded: form_helper
INFO - 2017-03-15 15:49:02 --> Form Validation Class Initialized
INFO - 2017-03-15 15:49:02 --> Final output sent to browser
DEBUG - 2017-03-15 15:49:02 --> Total execution time: 0.0166
INFO - 2017-03-15 15:49:03 --> Config Class Initialized
INFO - 2017-03-15 15:49:03 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:49:03 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:49:03 --> Utf8 Class Initialized
INFO - 2017-03-15 15:49:03 --> URI Class Initialized
INFO - 2017-03-15 15:49:03 --> Router Class Initialized
INFO - 2017-03-15 15:49:03 --> Output Class Initialized
INFO - 2017-03-15 15:49:03 --> Security Class Initialized
DEBUG - 2017-03-15 15:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:49:03 --> Input Class Initialized
INFO - 2017-03-15 15:49:03 --> Language Class Initialized
INFO - 2017-03-15 15:49:03 --> Loader Class Initialized
INFO - 2017-03-15 15:49:03 --> Database Driver Class Initialized
INFO - 2017-03-15 15:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:49:03 --> Controller Class Initialized
INFO - 2017-03-15 15:49:03 --> Helper loaded: date_helper
INFO - 2017-03-15 15:49:03 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:49:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:49:03 --> Helper loaded: form_helper
INFO - 2017-03-15 15:49:03 --> Form Validation Class Initialized
INFO - 2017-03-15 15:49:03 --> Final output sent to browser
DEBUG - 2017-03-15 15:49:03 --> Total execution time: 0.0152
INFO - 2017-03-15 15:49:18 --> Config Class Initialized
INFO - 2017-03-15 15:49:18 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:49:18 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:49:18 --> Utf8 Class Initialized
INFO - 2017-03-15 15:49:18 --> URI Class Initialized
INFO - 2017-03-15 15:49:18 --> Router Class Initialized
INFO - 2017-03-15 15:49:18 --> Output Class Initialized
INFO - 2017-03-15 15:49:18 --> Security Class Initialized
DEBUG - 2017-03-15 15:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:49:18 --> Input Class Initialized
INFO - 2017-03-15 15:49:18 --> Language Class Initialized
INFO - 2017-03-15 15:49:18 --> Loader Class Initialized
INFO - 2017-03-15 15:49:18 --> Database Driver Class Initialized
INFO - 2017-03-15 15:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:49:18 --> Controller Class Initialized
INFO - 2017-03-15 15:49:18 --> Helper loaded: date_helper
INFO - 2017-03-15 15:49:18 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:49:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:49:18 --> Helper loaded: form_helper
INFO - 2017-03-15 15:49:18 --> Form Validation Class Initialized
INFO - 2017-03-15 15:49:18 --> Final output sent to browser
DEBUG - 2017-03-15 15:49:18 --> Total execution time: 0.0166
INFO - 2017-03-15 15:49:19 --> Config Class Initialized
INFO - 2017-03-15 15:49:19 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:49:19 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:49:19 --> Utf8 Class Initialized
INFO - 2017-03-15 15:49:19 --> URI Class Initialized
INFO - 2017-03-15 15:49:19 --> Router Class Initialized
INFO - 2017-03-15 15:49:19 --> Output Class Initialized
INFO - 2017-03-15 15:49:19 --> Security Class Initialized
DEBUG - 2017-03-15 15:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:49:19 --> Input Class Initialized
INFO - 2017-03-15 15:49:19 --> Language Class Initialized
INFO - 2017-03-15 15:49:19 --> Loader Class Initialized
INFO - 2017-03-15 15:49:19 --> Database Driver Class Initialized
INFO - 2017-03-15 15:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:49:19 --> Controller Class Initialized
INFO - 2017-03-15 15:49:19 --> Helper loaded: date_helper
INFO - 2017-03-15 15:49:19 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:49:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:49:19 --> Helper loaded: form_helper
INFO - 2017-03-15 15:49:19 --> Form Validation Class Initialized
INFO - 2017-03-15 15:49:19 --> Final output sent to browser
DEBUG - 2017-03-15 15:49:19 --> Total execution time: 0.0158
INFO - 2017-03-15 15:49:23 --> Config Class Initialized
INFO - 2017-03-15 15:49:23 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:49:23 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:49:23 --> Utf8 Class Initialized
INFO - 2017-03-15 15:49:23 --> URI Class Initialized
INFO - 2017-03-15 15:49:23 --> Router Class Initialized
INFO - 2017-03-15 15:49:23 --> Output Class Initialized
INFO - 2017-03-15 15:49:23 --> Security Class Initialized
DEBUG - 2017-03-15 15:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:49:23 --> Input Class Initialized
INFO - 2017-03-15 15:49:23 --> Language Class Initialized
INFO - 2017-03-15 15:49:23 --> Loader Class Initialized
INFO - 2017-03-15 15:49:23 --> Database Driver Class Initialized
INFO - 2017-03-15 15:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:49:23 --> Controller Class Initialized
INFO - 2017-03-15 15:49:23 --> Helper loaded: date_helper
INFO - 2017-03-15 15:49:23 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:49:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:49:23 --> Helper loaded: form_helper
INFO - 2017-03-15 15:49:23 --> Form Validation Class Initialized
INFO - 2017-03-15 15:49:23 --> Final output sent to browser
DEBUG - 2017-03-15 15:49:23 --> Total execution time: 0.0165
INFO - 2017-03-15 15:49:24 --> Config Class Initialized
INFO - 2017-03-15 15:49:24 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:49:24 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:49:24 --> Utf8 Class Initialized
INFO - 2017-03-15 15:49:24 --> URI Class Initialized
INFO - 2017-03-15 15:49:24 --> Router Class Initialized
INFO - 2017-03-15 15:49:24 --> Output Class Initialized
INFO - 2017-03-15 15:49:24 --> Security Class Initialized
DEBUG - 2017-03-15 15:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:49:24 --> Input Class Initialized
INFO - 2017-03-15 15:49:24 --> Language Class Initialized
INFO - 2017-03-15 15:49:24 --> Loader Class Initialized
INFO - 2017-03-15 15:49:24 --> Database Driver Class Initialized
INFO - 2017-03-15 15:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:49:24 --> Controller Class Initialized
INFO - 2017-03-15 15:49:24 --> Helper loaded: date_helper
INFO - 2017-03-15 15:49:24 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:49:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:49:24 --> Helper loaded: form_helper
INFO - 2017-03-15 15:49:24 --> Form Validation Class Initialized
INFO - 2017-03-15 15:49:24 --> Final output sent to browser
DEBUG - 2017-03-15 15:49:24 --> Total execution time: 0.0147
INFO - 2017-03-15 15:49:29 --> Config Class Initialized
INFO - 2017-03-15 15:49:29 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:49:29 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:49:29 --> Utf8 Class Initialized
INFO - 2017-03-15 15:49:29 --> URI Class Initialized
INFO - 2017-03-15 15:49:29 --> Router Class Initialized
INFO - 2017-03-15 15:49:29 --> Output Class Initialized
INFO - 2017-03-15 15:49:29 --> Security Class Initialized
DEBUG - 2017-03-15 15:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:49:29 --> Input Class Initialized
INFO - 2017-03-15 15:49:29 --> Language Class Initialized
INFO - 2017-03-15 15:49:29 --> Loader Class Initialized
INFO - 2017-03-15 15:49:29 --> Database Driver Class Initialized
INFO - 2017-03-15 15:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:49:29 --> Controller Class Initialized
INFO - 2017-03-15 15:49:29 --> Helper loaded: date_helper
INFO - 2017-03-15 15:49:29 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:49:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:49:29 --> Helper loaded: form_helper
INFO - 2017-03-15 15:49:29 --> Form Validation Class Initialized
INFO - 2017-03-15 15:49:29 --> Final output sent to browser
DEBUG - 2017-03-15 15:49:29 --> Total execution time: 0.0149
INFO - 2017-03-15 15:49:34 --> Config Class Initialized
INFO - 2017-03-15 15:49:34 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:49:34 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:49:34 --> Utf8 Class Initialized
INFO - 2017-03-15 15:49:34 --> URI Class Initialized
INFO - 2017-03-15 15:49:34 --> Router Class Initialized
INFO - 2017-03-15 15:49:34 --> Output Class Initialized
INFO - 2017-03-15 15:49:34 --> Security Class Initialized
DEBUG - 2017-03-15 15:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:49:34 --> Input Class Initialized
INFO - 2017-03-15 15:49:34 --> Language Class Initialized
INFO - 2017-03-15 15:49:34 --> Loader Class Initialized
INFO - 2017-03-15 15:49:34 --> Database Driver Class Initialized
INFO - 2017-03-15 15:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:49:34 --> Controller Class Initialized
INFO - 2017-03-15 15:49:34 --> Helper loaded: date_helper
INFO - 2017-03-15 15:49:34 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:49:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:49:34 --> Helper loaded: form_helper
INFO - 2017-03-15 15:49:34 --> Form Validation Class Initialized
INFO - 2017-03-15 15:49:34 --> Final output sent to browser
DEBUG - 2017-03-15 15:49:34 --> Total execution time: 0.0163
INFO - 2017-03-15 15:49:35 --> Config Class Initialized
INFO - 2017-03-15 15:49:35 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:49:35 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:49:35 --> Utf8 Class Initialized
INFO - 2017-03-15 15:49:35 --> URI Class Initialized
INFO - 2017-03-15 15:49:35 --> Router Class Initialized
INFO - 2017-03-15 15:49:35 --> Output Class Initialized
INFO - 2017-03-15 15:49:35 --> Security Class Initialized
DEBUG - 2017-03-15 15:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:49:35 --> Input Class Initialized
INFO - 2017-03-15 15:49:35 --> Language Class Initialized
INFO - 2017-03-15 15:49:35 --> Loader Class Initialized
INFO - 2017-03-15 15:49:35 --> Database Driver Class Initialized
INFO - 2017-03-15 15:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:49:35 --> Controller Class Initialized
INFO - 2017-03-15 15:49:35 --> Helper loaded: date_helper
INFO - 2017-03-15 15:49:35 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:49:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:49:35 --> Helper loaded: form_helper
INFO - 2017-03-15 15:49:35 --> Form Validation Class Initialized
INFO - 2017-03-15 15:49:35 --> Final output sent to browser
DEBUG - 2017-03-15 15:49:35 --> Total execution time: 0.0151
INFO - 2017-03-15 15:49:36 --> Config Class Initialized
INFO - 2017-03-15 15:49:36 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:49:36 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:49:36 --> Utf8 Class Initialized
INFO - 2017-03-15 15:49:36 --> URI Class Initialized
INFO - 2017-03-15 15:49:36 --> Router Class Initialized
INFO - 2017-03-15 15:49:36 --> Output Class Initialized
INFO - 2017-03-15 15:49:36 --> Security Class Initialized
DEBUG - 2017-03-15 15:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:49:36 --> Input Class Initialized
INFO - 2017-03-15 15:49:36 --> Language Class Initialized
INFO - 2017-03-15 15:49:36 --> Loader Class Initialized
INFO - 2017-03-15 15:49:36 --> Database Driver Class Initialized
INFO - 2017-03-15 15:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:49:36 --> Controller Class Initialized
INFO - 2017-03-15 15:49:36 --> Helper loaded: date_helper
INFO - 2017-03-15 15:49:36 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:49:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:49:36 --> Helper loaded: form_helper
INFO - 2017-03-15 15:49:36 --> Form Validation Class Initialized
INFO - 2017-03-15 15:49:36 --> Final output sent to browser
DEBUG - 2017-03-15 15:49:36 --> Total execution time: 0.0146
INFO - 2017-03-15 15:49:39 --> Config Class Initialized
INFO - 2017-03-15 15:49:39 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:49:39 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:49:39 --> Utf8 Class Initialized
INFO - 2017-03-15 15:49:39 --> URI Class Initialized
INFO - 2017-03-15 15:49:39 --> Router Class Initialized
INFO - 2017-03-15 15:49:39 --> Output Class Initialized
INFO - 2017-03-15 15:49:39 --> Security Class Initialized
DEBUG - 2017-03-15 15:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:49:39 --> Input Class Initialized
INFO - 2017-03-15 15:49:39 --> Language Class Initialized
INFO - 2017-03-15 15:49:39 --> Loader Class Initialized
INFO - 2017-03-15 15:49:39 --> Database Driver Class Initialized
INFO - 2017-03-15 15:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:49:39 --> Controller Class Initialized
INFO - 2017-03-15 15:49:39 --> Helper loaded: date_helper
INFO - 2017-03-15 15:49:39 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:49:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:49:39 --> Helper loaded: form_helper
INFO - 2017-03-15 15:49:39 --> Form Validation Class Initialized
INFO - 2017-03-15 15:49:39 --> Final output sent to browser
DEBUG - 2017-03-15 15:49:39 --> Total execution time: 0.0148
INFO - 2017-03-15 15:49:57 --> Config Class Initialized
INFO - 2017-03-15 15:49:57 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:49:57 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:49:57 --> Utf8 Class Initialized
INFO - 2017-03-15 15:49:57 --> URI Class Initialized
INFO - 2017-03-15 15:49:57 --> Router Class Initialized
INFO - 2017-03-15 15:49:57 --> Output Class Initialized
INFO - 2017-03-15 15:49:57 --> Security Class Initialized
DEBUG - 2017-03-15 15:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:49:57 --> Input Class Initialized
INFO - 2017-03-15 15:49:57 --> Language Class Initialized
INFO - 2017-03-15 15:49:57 --> Loader Class Initialized
INFO - 2017-03-15 15:49:57 --> Database Driver Class Initialized
INFO - 2017-03-15 15:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:49:57 --> Controller Class Initialized
INFO - 2017-03-15 15:49:57 --> Helper loaded: date_helper
INFO - 2017-03-15 15:49:57 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:49:57 --> Helper loaded: form_helper
INFO - 2017-03-15 15:49:57 --> Form Validation Class Initialized
INFO - 2017-03-15 15:49:57 --> Final output sent to browser
DEBUG - 2017-03-15 15:49:57 --> Total execution time: 0.0156
INFO - 2017-03-15 15:50:09 --> Config Class Initialized
INFO - 2017-03-15 15:50:09 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:50:09 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:50:09 --> Utf8 Class Initialized
INFO - 2017-03-15 15:50:09 --> URI Class Initialized
INFO - 2017-03-15 15:50:09 --> Router Class Initialized
INFO - 2017-03-15 15:50:09 --> Output Class Initialized
INFO - 2017-03-15 15:50:09 --> Security Class Initialized
DEBUG - 2017-03-15 15:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:50:09 --> Input Class Initialized
INFO - 2017-03-15 15:50:09 --> Language Class Initialized
INFO - 2017-03-15 15:50:09 --> Loader Class Initialized
INFO - 2017-03-15 15:50:09 --> Database Driver Class Initialized
INFO - 2017-03-15 15:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:50:09 --> Controller Class Initialized
INFO - 2017-03-15 15:50:09 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:50:10 --> Config Class Initialized
INFO - 2017-03-15 15:50:10 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:50:10 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:50:10 --> Utf8 Class Initialized
INFO - 2017-03-15 15:50:10 --> URI Class Initialized
INFO - 2017-03-15 15:50:10 --> Router Class Initialized
INFO - 2017-03-15 15:50:10 --> Output Class Initialized
INFO - 2017-03-15 15:50:10 --> Security Class Initialized
DEBUG - 2017-03-15 15:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:50:10 --> Input Class Initialized
INFO - 2017-03-15 15:50:10 --> Language Class Initialized
INFO - 2017-03-15 15:50:10 --> Loader Class Initialized
INFO - 2017-03-15 15:50:10 --> Database Driver Class Initialized
INFO - 2017-03-15 15:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:50:10 --> Controller Class Initialized
INFO - 2017-03-15 15:50:10 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:50:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:50:10 --> Helper loaded: form_helper
INFO - 2017-03-15 15:50:10 --> Form Validation Class Initialized
INFO - 2017-03-15 15:50:10 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-15 15:50:10 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-03-15 15:50:10 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-15 15:50:10 --> Final output sent to browser
DEBUG - 2017-03-15 15:50:10 --> Total execution time: 0.0398
INFO - 2017-03-15 15:50:10 --> Config Class Initialized
INFO - 2017-03-15 15:50:10 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:50:10 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:50:10 --> Utf8 Class Initialized
INFO - 2017-03-15 15:50:10 --> URI Class Initialized
INFO - 2017-03-15 15:50:10 --> Router Class Initialized
INFO - 2017-03-15 15:50:10 --> Output Class Initialized
INFO - 2017-03-15 15:50:10 --> Security Class Initialized
DEBUG - 2017-03-15 15:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:50:10 --> Input Class Initialized
INFO - 2017-03-15 15:50:10 --> Language Class Initialized
INFO - 2017-03-15 15:50:10 --> Loader Class Initialized
INFO - 2017-03-15 15:50:10 --> Database Driver Class Initialized
INFO - 2017-03-15 15:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:50:10 --> Controller Class Initialized
INFO - 2017-03-15 15:50:10 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:50:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:50:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:50:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:50:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:50:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:50:10 --> Final output sent to browser
DEBUG - 2017-03-15 15:50:10 --> Total execution time: 0.0139
INFO - 2017-03-15 15:50:10 --> Config Class Initialized
INFO - 2017-03-15 15:50:10 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:50:10 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:50:10 --> Utf8 Class Initialized
INFO - 2017-03-15 15:50:10 --> URI Class Initialized
INFO - 2017-03-15 15:50:10 --> Router Class Initialized
INFO - 2017-03-15 15:50:10 --> Output Class Initialized
INFO - 2017-03-15 15:50:10 --> Security Class Initialized
DEBUG - 2017-03-15 15:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:50:10 --> Input Class Initialized
INFO - 2017-03-15 15:50:10 --> Language Class Initialized
INFO - 2017-03-15 15:50:10 --> Loader Class Initialized
INFO - 2017-03-15 15:50:10 --> Database Driver Class Initialized
INFO - 2017-03-15 15:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:50:10 --> Controller Class Initialized
INFO - 2017-03-15 15:50:10 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:50:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:50:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:50:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:50:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:50:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:50:10 --> Final output sent to browser
DEBUG - 2017-03-15 15:50:10 --> Total execution time: 0.0137
INFO - 2017-03-15 15:50:19 --> Config Class Initialized
INFO - 2017-03-15 15:50:19 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:50:20 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:50:20 --> Utf8 Class Initialized
INFO - 2017-03-15 15:50:20 --> URI Class Initialized
DEBUG - 2017-03-15 15:50:20 --> No URI present. Default controller set.
INFO - 2017-03-15 15:50:20 --> Router Class Initialized
INFO - 2017-03-15 15:50:20 --> Output Class Initialized
INFO - 2017-03-15 15:50:20 --> Security Class Initialized
DEBUG - 2017-03-15 15:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:50:20 --> Input Class Initialized
INFO - 2017-03-15 15:50:20 --> Language Class Initialized
INFO - 2017-03-15 15:50:20 --> Loader Class Initialized
INFO - 2017-03-15 15:50:20 --> Database Driver Class Initialized
INFO - 2017-03-15 15:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:50:21 --> Controller Class Initialized
INFO - 2017-03-15 15:50:21 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:50:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:50:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:50:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:50:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:50:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:50:21 --> Final output sent to browser
DEBUG - 2017-03-15 15:50:21 --> Total execution time: 1.4593
INFO - 2017-03-15 15:50:23 --> Config Class Initialized
INFO - 2017-03-15 15:50:23 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:50:23 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:50:23 --> Utf8 Class Initialized
INFO - 2017-03-15 15:50:23 --> URI Class Initialized
INFO - 2017-03-15 15:50:23 --> Router Class Initialized
INFO - 2017-03-15 15:50:23 --> Output Class Initialized
INFO - 2017-03-15 15:50:23 --> Security Class Initialized
DEBUG - 2017-03-15 15:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:50:23 --> Input Class Initialized
INFO - 2017-03-15 15:50:23 --> Language Class Initialized
INFO - 2017-03-15 15:50:23 --> Loader Class Initialized
INFO - 2017-03-15 15:50:23 --> Database Driver Class Initialized
INFO - 2017-03-15 15:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:50:23 --> Controller Class Initialized
INFO - 2017-03-15 15:50:23 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:50:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:50:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:50:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:50:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:50:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:50:23 --> Final output sent to browser
DEBUG - 2017-03-15 15:50:23 --> Total execution time: 0.0138
INFO - 2017-03-15 15:50:32 --> Config Class Initialized
INFO - 2017-03-15 15:50:32 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:50:32 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:50:32 --> Utf8 Class Initialized
INFO - 2017-03-15 15:50:32 --> URI Class Initialized
DEBUG - 2017-03-15 15:50:32 --> No URI present. Default controller set.
INFO - 2017-03-15 15:50:32 --> Router Class Initialized
INFO - 2017-03-15 15:50:32 --> Output Class Initialized
INFO - 2017-03-15 15:50:32 --> Security Class Initialized
DEBUG - 2017-03-15 15:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:50:32 --> Input Class Initialized
INFO - 2017-03-15 15:50:32 --> Language Class Initialized
INFO - 2017-03-15 15:50:32 --> Loader Class Initialized
INFO - 2017-03-15 15:50:32 --> Database Driver Class Initialized
INFO - 2017-03-15 15:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:50:32 --> Controller Class Initialized
INFO - 2017-03-15 15:50:33 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:50:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:50:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:50:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:50:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:50:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:50:33 --> Final output sent to browser
DEBUG - 2017-03-15 15:50:33 --> Total execution time: 0.2883
INFO - 2017-03-15 15:50:36 --> Config Class Initialized
INFO - 2017-03-15 15:50:36 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:50:36 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:50:36 --> Utf8 Class Initialized
INFO - 2017-03-15 15:50:36 --> URI Class Initialized
INFO - 2017-03-15 15:50:36 --> Router Class Initialized
INFO - 2017-03-15 15:50:36 --> Output Class Initialized
INFO - 2017-03-15 15:50:36 --> Security Class Initialized
DEBUG - 2017-03-15 15:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:50:36 --> Input Class Initialized
INFO - 2017-03-15 15:50:36 --> Language Class Initialized
INFO - 2017-03-15 15:50:36 --> Loader Class Initialized
INFO - 2017-03-15 15:50:36 --> Database Driver Class Initialized
INFO - 2017-03-15 15:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:50:36 --> Controller Class Initialized
INFO - 2017-03-15 15:50:36 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:50:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:50:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:50:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:50:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:50:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:50:36 --> Final output sent to browser
DEBUG - 2017-03-15 15:50:36 --> Total execution time: 0.0140
INFO - 2017-03-15 15:50:42 --> Config Class Initialized
INFO - 2017-03-15 15:50:42 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:50:42 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:50:42 --> Utf8 Class Initialized
INFO - 2017-03-15 15:50:42 --> URI Class Initialized
INFO - 2017-03-15 15:50:42 --> Router Class Initialized
INFO - 2017-03-15 15:50:42 --> Output Class Initialized
INFO - 2017-03-15 15:50:42 --> Security Class Initialized
DEBUG - 2017-03-15 15:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:50:42 --> Input Class Initialized
INFO - 2017-03-15 15:50:42 --> Language Class Initialized
INFO - 2017-03-15 15:50:42 --> Loader Class Initialized
INFO - 2017-03-15 15:50:42 --> Database Driver Class Initialized
INFO - 2017-03-15 15:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:50:42 --> Controller Class Initialized
INFO - 2017-03-15 15:50:42 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:50:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:50:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:50:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:50:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:50:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:50:42 --> Final output sent to browser
DEBUG - 2017-03-15 15:50:42 --> Total execution time: 0.0281
INFO - 2017-03-15 15:50:45 --> Config Class Initialized
INFO - 2017-03-15 15:50:45 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:50:45 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:50:45 --> Utf8 Class Initialized
INFO - 2017-03-15 15:50:45 --> URI Class Initialized
INFO - 2017-03-15 15:50:45 --> Router Class Initialized
INFO - 2017-03-15 15:50:45 --> Output Class Initialized
INFO - 2017-03-15 15:50:45 --> Security Class Initialized
DEBUG - 2017-03-15 15:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:50:45 --> Input Class Initialized
INFO - 2017-03-15 15:50:45 --> Language Class Initialized
INFO - 2017-03-15 15:50:45 --> Loader Class Initialized
INFO - 2017-03-15 15:50:45 --> Database Driver Class Initialized
INFO - 2017-03-15 15:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:50:45 --> Controller Class Initialized
INFO - 2017-03-15 15:50:45 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:50:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:50:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:50:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:50:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:50:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:50:45 --> Final output sent to browser
DEBUG - 2017-03-15 15:50:45 --> Total execution time: 0.0139
INFO - 2017-03-15 15:50:50 --> Config Class Initialized
INFO - 2017-03-15 15:50:50 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:50:50 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:50:50 --> Utf8 Class Initialized
INFO - 2017-03-15 15:50:50 --> URI Class Initialized
INFO - 2017-03-15 15:50:50 --> Router Class Initialized
INFO - 2017-03-15 15:50:50 --> Output Class Initialized
INFO - 2017-03-15 15:50:50 --> Security Class Initialized
DEBUG - 2017-03-15 15:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:50:50 --> Input Class Initialized
INFO - 2017-03-15 15:50:50 --> Language Class Initialized
INFO - 2017-03-15 15:50:50 --> Loader Class Initialized
INFO - 2017-03-15 15:50:50 --> Database Driver Class Initialized
INFO - 2017-03-15 15:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:50:50 --> Controller Class Initialized
INFO - 2017-03-15 15:50:50 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:50:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:50:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:50:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:50:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:50:50 --> Final output sent to browser
DEBUG - 2017-03-15 15:50:50 --> Total execution time: 0.0146
INFO - 2017-03-15 15:50:51 --> Config Class Initialized
INFO - 2017-03-15 15:50:51 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:50:51 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:50:51 --> Utf8 Class Initialized
INFO - 2017-03-15 15:50:51 --> URI Class Initialized
INFO - 2017-03-15 15:50:51 --> Router Class Initialized
INFO - 2017-03-15 15:50:51 --> Output Class Initialized
INFO - 2017-03-15 15:50:51 --> Security Class Initialized
DEBUG - 2017-03-15 15:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:50:51 --> Input Class Initialized
INFO - 2017-03-15 15:50:51 --> Language Class Initialized
INFO - 2017-03-15 15:50:51 --> Loader Class Initialized
INFO - 2017-03-15 15:50:51 --> Database Driver Class Initialized
INFO - 2017-03-15 15:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:50:51 --> Controller Class Initialized
INFO - 2017-03-15 15:50:51 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:50:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:50:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:50:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:50:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:50:51 --> Final output sent to browser
DEBUG - 2017-03-15 15:50:51 --> Total execution time: 0.0139
INFO - 2017-03-15 15:50:52 --> Config Class Initialized
INFO - 2017-03-15 15:50:52 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:50:52 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:50:52 --> Utf8 Class Initialized
INFO - 2017-03-15 15:50:52 --> URI Class Initialized
INFO - 2017-03-15 15:50:52 --> Router Class Initialized
INFO - 2017-03-15 15:50:52 --> Output Class Initialized
INFO - 2017-03-15 15:50:52 --> Security Class Initialized
DEBUG - 2017-03-15 15:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:50:52 --> Input Class Initialized
INFO - 2017-03-15 15:50:52 --> Language Class Initialized
INFO - 2017-03-15 15:50:52 --> Loader Class Initialized
INFO - 2017-03-15 15:50:52 --> Database Driver Class Initialized
INFO - 2017-03-15 15:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:50:52 --> Controller Class Initialized
INFO - 2017-03-15 15:50:52 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:50:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:50:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:50:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:50:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:50:52 --> Final output sent to browser
DEBUG - 2017-03-15 15:50:52 --> Total execution time: 0.1797
INFO - 2017-03-15 15:50:55 --> Config Class Initialized
INFO - 2017-03-15 15:50:55 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:50:55 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:50:55 --> Utf8 Class Initialized
INFO - 2017-03-15 15:50:55 --> URI Class Initialized
INFO - 2017-03-15 15:50:55 --> Router Class Initialized
INFO - 2017-03-15 15:50:55 --> Output Class Initialized
INFO - 2017-03-15 15:50:55 --> Security Class Initialized
DEBUG - 2017-03-15 15:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:50:55 --> Input Class Initialized
INFO - 2017-03-15 15:50:55 --> Language Class Initialized
INFO - 2017-03-15 15:50:55 --> Loader Class Initialized
INFO - 2017-03-15 15:50:55 --> Database Driver Class Initialized
INFO - 2017-03-15 15:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:50:55 --> Controller Class Initialized
INFO - 2017-03-15 15:50:55 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:50:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:50:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:50:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:50:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:50:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:50:55 --> Final output sent to browser
DEBUG - 2017-03-15 15:50:55 --> Total execution time: 0.0139
INFO - 2017-03-15 15:50:57 --> Config Class Initialized
INFO - 2017-03-15 15:50:57 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:50:57 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:50:57 --> Utf8 Class Initialized
INFO - 2017-03-15 15:50:57 --> URI Class Initialized
INFO - 2017-03-15 15:50:57 --> Router Class Initialized
INFO - 2017-03-15 15:50:57 --> Output Class Initialized
INFO - 2017-03-15 15:50:57 --> Security Class Initialized
DEBUG - 2017-03-15 15:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:50:57 --> Input Class Initialized
INFO - 2017-03-15 15:50:57 --> Language Class Initialized
INFO - 2017-03-15 15:50:57 --> Loader Class Initialized
INFO - 2017-03-15 15:50:57 --> Database Driver Class Initialized
INFO - 2017-03-15 15:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:50:57 --> Controller Class Initialized
INFO - 2017-03-15 15:50:57 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:50:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:50:58 --> Config Class Initialized
INFO - 2017-03-15 15:50:58 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:50:58 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:50:58 --> Utf8 Class Initialized
INFO - 2017-03-15 15:50:58 --> URI Class Initialized
INFO - 2017-03-15 15:50:58 --> Router Class Initialized
INFO - 2017-03-15 15:50:58 --> Output Class Initialized
INFO - 2017-03-15 15:50:58 --> Security Class Initialized
DEBUG - 2017-03-15 15:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:50:58 --> Input Class Initialized
INFO - 2017-03-15 15:50:58 --> Language Class Initialized
INFO - 2017-03-15 15:50:58 --> Loader Class Initialized
INFO - 2017-03-15 15:50:58 --> Database Driver Class Initialized
INFO - 2017-03-15 15:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:50:58 --> Controller Class Initialized
INFO - 2017-03-15 15:50:58 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:50:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:50:58 --> Config Class Initialized
INFO - 2017-03-15 15:50:58 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:50:58 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:50:58 --> Utf8 Class Initialized
INFO - 2017-03-15 15:50:58 --> URI Class Initialized
DEBUG - 2017-03-15 15:50:58 --> No URI present. Default controller set.
INFO - 2017-03-15 15:50:58 --> Router Class Initialized
INFO - 2017-03-15 15:50:58 --> Output Class Initialized
INFO - 2017-03-15 15:50:58 --> Security Class Initialized
DEBUG - 2017-03-15 15:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:50:58 --> Input Class Initialized
INFO - 2017-03-15 15:50:58 --> Language Class Initialized
INFO - 2017-03-15 15:50:58 --> Loader Class Initialized
INFO - 2017-03-15 15:50:58 --> Database Driver Class Initialized
INFO - 2017-03-15 15:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:50:58 --> Controller Class Initialized
INFO - 2017-03-15 15:50:58 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:50:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:50:58 --> Final output sent to browser
DEBUG - 2017-03-15 15:50:58 --> Total execution time: 0.0141
INFO - 2017-03-15 15:50:59 --> Config Class Initialized
INFO - 2017-03-15 15:50:59 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:50:59 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:50:59 --> Utf8 Class Initialized
INFO - 2017-03-15 15:50:59 --> URI Class Initialized
INFO - 2017-03-15 15:50:59 --> Router Class Initialized
INFO - 2017-03-15 15:50:59 --> Output Class Initialized
INFO - 2017-03-15 15:50:59 --> Security Class Initialized
DEBUG - 2017-03-15 15:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:50:59 --> Input Class Initialized
INFO - 2017-03-15 15:50:59 --> Language Class Initialized
INFO - 2017-03-15 15:50:59 --> Loader Class Initialized
INFO - 2017-03-15 15:50:59 --> Database Driver Class Initialized
INFO - 2017-03-15 15:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:50:59 --> Controller Class Initialized
INFO - 2017-03-15 15:50:59 --> Helper loaded: date_helper
DEBUG - 2017-03-15 15:50:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:50:59 --> Helper loaded: url_helper
INFO - 2017-03-15 15:51:00 --> Config Class Initialized
INFO - 2017-03-15 15:51:00 --> Hooks Class Initialized
INFO - 2017-03-15 15:51:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
DEBUG - 2017-03-15 15:51:00 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:51:00 --> Utf8 Class Initialized
INFO - 2017-03-15 15:51:00 --> URI Class Initialized
INFO - 2017-03-15 15:51:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-15 15:51:00 --> Router Class Initialized
INFO - 2017-03-15 15:51:00 --> Output Class Initialized
INFO - 2017-03-15 15:51:00 --> Security Class Initialized
INFO - 2017-03-15 15:51:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
DEBUG - 2017-03-15 15:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:51:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 15:51:00 --> Input Class Initialized
INFO - 2017-03-15 15:51:00 --> Language Class Initialized
INFO - 2017-03-15 15:51:00 --> Loader Class Initialized
INFO - 2017-03-15 15:51:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:51:00 --> Database Driver Class Initialized
INFO - 2017-03-15 15:51:00 --> Final output sent to browser
DEBUG - 2017-03-15 15:51:00 --> Total execution time: 1.0642
INFO - 2017-03-15 15:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:51:00 --> Controller Class Initialized
INFO - 2017-03-15 15:51:00 --> Helper loaded: date_helper
DEBUG - 2017-03-15 15:51:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:51:00 --> Helper loaded: url_helper
INFO - 2017-03-15 15:51:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:51:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-15 15:51:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-15 15:51:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 15:51:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:51:00 --> Final output sent to browser
DEBUG - 2017-03-15 15:51:00 --> Total execution time: 0.1944
INFO - 2017-03-15 15:51:01 --> Config Class Initialized
INFO - 2017-03-15 15:51:01 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:51:01 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:51:01 --> Utf8 Class Initialized
INFO - 2017-03-15 15:51:01 --> URI Class Initialized
INFO - 2017-03-15 15:51:01 --> Router Class Initialized
INFO - 2017-03-15 15:51:01 --> Output Class Initialized
INFO - 2017-03-15 15:51:01 --> Security Class Initialized
DEBUG - 2017-03-15 15:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:51:01 --> Input Class Initialized
INFO - 2017-03-15 15:51:01 --> Language Class Initialized
INFO - 2017-03-15 15:51:01 --> Loader Class Initialized
INFO - 2017-03-15 15:51:01 --> Database Driver Class Initialized
INFO - 2017-03-15 15:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:51:01 --> Controller Class Initialized
INFO - 2017-03-15 15:51:01 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:51:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:51:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:51:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:51:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:51:01 --> Final output sent to browser
DEBUG - 2017-03-15 15:51:01 --> Total execution time: 0.2496
INFO - 2017-03-15 15:51:01 --> Config Class Initialized
INFO - 2017-03-15 15:51:01 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:51:01 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:51:01 --> Utf8 Class Initialized
INFO - 2017-03-15 15:51:01 --> URI Class Initialized
INFO - 2017-03-15 15:51:01 --> Router Class Initialized
INFO - 2017-03-15 15:51:01 --> Output Class Initialized
INFO - 2017-03-15 15:51:01 --> Security Class Initialized
DEBUG - 2017-03-15 15:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:51:01 --> Input Class Initialized
INFO - 2017-03-15 15:51:01 --> Language Class Initialized
INFO - 2017-03-15 15:51:01 --> Loader Class Initialized
INFO - 2017-03-15 15:51:01 --> Database Driver Class Initialized
INFO - 2017-03-15 15:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:51:01 --> Controller Class Initialized
INFO - 2017-03-15 15:51:01 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:51:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:51:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:51:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:51:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:51:01 --> Final output sent to browser
DEBUG - 2017-03-15 15:51:01 --> Total execution time: 0.0143
INFO - 2017-03-15 15:51:09 --> Config Class Initialized
INFO - 2017-03-15 15:51:09 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:51:09 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:51:09 --> Utf8 Class Initialized
INFO - 2017-03-15 15:51:09 --> URI Class Initialized
INFO - 2017-03-15 15:51:09 --> Router Class Initialized
INFO - 2017-03-15 15:51:09 --> Output Class Initialized
INFO - 2017-03-15 15:51:09 --> Security Class Initialized
DEBUG - 2017-03-15 15:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:51:09 --> Input Class Initialized
INFO - 2017-03-15 15:51:09 --> Language Class Initialized
INFO - 2017-03-15 15:51:09 --> Loader Class Initialized
INFO - 2017-03-15 15:51:09 --> Database Driver Class Initialized
INFO - 2017-03-15 15:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:51:09 --> Controller Class Initialized
INFO - 2017-03-15 15:51:09 --> Helper loaded: date_helper
DEBUG - 2017-03-15 15:51:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:51:09 --> Helper loaded: url_helper
INFO - 2017-03-15 15:51:09 --> Helper loaded: download_helper
INFO - 2017-03-15 15:51:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:51:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-15 15:51:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-15 15:51:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-15 15:51:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:51:09 --> Final output sent to browser
DEBUG - 2017-03-15 15:51:09 --> Total execution time: 0.0652
INFO - 2017-03-15 15:51:12 --> Config Class Initialized
INFO - 2017-03-15 15:51:12 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:51:12 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:51:12 --> Utf8 Class Initialized
INFO - 2017-03-15 15:51:12 --> URI Class Initialized
INFO - 2017-03-15 15:51:12 --> Router Class Initialized
INFO - 2017-03-15 15:51:12 --> Output Class Initialized
INFO - 2017-03-15 15:51:12 --> Security Class Initialized
DEBUG - 2017-03-15 15:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:51:12 --> Input Class Initialized
INFO - 2017-03-15 15:51:12 --> Language Class Initialized
INFO - 2017-03-15 15:51:12 --> Loader Class Initialized
INFO - 2017-03-15 15:51:12 --> Database Driver Class Initialized
INFO - 2017-03-15 15:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:51:13 --> Controller Class Initialized
INFO - 2017-03-15 15:51:13 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:51:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:51:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:51:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:51:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:51:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:51:13 --> Final output sent to browser
DEBUG - 2017-03-15 15:51:13 --> Total execution time: 1.2498
INFO - 2017-03-15 15:52:16 --> Config Class Initialized
INFO - 2017-03-15 15:52:16 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:52:16 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:52:16 --> Utf8 Class Initialized
INFO - 2017-03-15 15:52:16 --> URI Class Initialized
INFO - 2017-03-15 15:52:16 --> Router Class Initialized
INFO - 2017-03-15 15:52:16 --> Output Class Initialized
INFO - 2017-03-15 15:52:16 --> Security Class Initialized
DEBUG - 2017-03-15 15:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:52:16 --> Input Class Initialized
INFO - 2017-03-15 15:52:16 --> Language Class Initialized
INFO - 2017-03-15 15:52:16 --> Loader Class Initialized
INFO - 2017-03-15 15:52:16 --> Database Driver Class Initialized
INFO - 2017-03-15 15:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:52:17 --> Controller Class Initialized
INFO - 2017-03-15 15:52:17 --> Helper loaded: date_helper
DEBUG - 2017-03-15 15:52:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:52:17 --> Helper loaded: url_helper
INFO - 2017-03-15 15:52:17 --> Helper loaded: download_helper
INFO - 2017-03-15 15:52:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:52:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-15 15:52:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-15 15:52:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-15 15:52:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:52:17 --> Final output sent to browser
DEBUG - 2017-03-15 15:52:17 --> Total execution time: 1.1511
INFO - 2017-03-15 15:52:18 --> Config Class Initialized
INFO - 2017-03-15 15:52:18 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:52:18 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:52:18 --> Utf8 Class Initialized
INFO - 2017-03-15 15:52:18 --> URI Class Initialized
INFO - 2017-03-15 15:52:18 --> Router Class Initialized
INFO - 2017-03-15 15:52:18 --> Output Class Initialized
INFO - 2017-03-15 15:52:18 --> Security Class Initialized
DEBUG - 2017-03-15 15:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:52:18 --> Input Class Initialized
INFO - 2017-03-15 15:52:18 --> Language Class Initialized
INFO - 2017-03-15 15:52:18 --> Loader Class Initialized
INFO - 2017-03-15 15:52:18 --> Database Driver Class Initialized
INFO - 2017-03-15 15:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:52:18 --> Controller Class Initialized
INFO - 2017-03-15 15:52:18 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:52:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:52:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:52:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:52:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:52:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:52:18 --> Final output sent to browser
DEBUG - 2017-03-15 15:52:18 --> Total execution time: 0.2690
INFO - 2017-03-15 15:52:25 --> Config Class Initialized
INFO - 2017-03-15 15:52:25 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:52:25 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:52:25 --> Utf8 Class Initialized
INFO - 2017-03-15 15:52:25 --> URI Class Initialized
INFO - 2017-03-15 15:52:25 --> Router Class Initialized
INFO - 2017-03-15 15:52:25 --> Output Class Initialized
INFO - 2017-03-15 15:52:25 --> Security Class Initialized
DEBUG - 2017-03-15 15:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:52:25 --> Input Class Initialized
INFO - 2017-03-15 15:52:25 --> Language Class Initialized
INFO - 2017-03-15 15:52:25 --> Loader Class Initialized
INFO - 2017-03-15 15:52:25 --> Database Driver Class Initialized
INFO - 2017-03-15 15:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:52:25 --> Controller Class Initialized
INFO - 2017-03-15 15:52:25 --> Helper loaded: date_helper
DEBUG - 2017-03-15 15:52:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:52:25 --> Helper loaded: url_helper
INFO - 2017-03-15 15:52:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:52:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-15 15:52:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-15 15:52:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 15:52:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:52:25 --> Final output sent to browser
DEBUG - 2017-03-15 15:52:25 --> Total execution time: 0.0572
INFO - 2017-03-15 15:52:26 --> Config Class Initialized
INFO - 2017-03-15 15:52:26 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:52:26 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:52:26 --> Utf8 Class Initialized
INFO - 2017-03-15 15:52:26 --> URI Class Initialized
INFO - 2017-03-15 15:52:26 --> Router Class Initialized
INFO - 2017-03-15 15:52:26 --> Output Class Initialized
INFO - 2017-03-15 15:52:26 --> Security Class Initialized
DEBUG - 2017-03-15 15:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:52:26 --> Input Class Initialized
INFO - 2017-03-15 15:52:26 --> Language Class Initialized
INFO - 2017-03-15 15:52:26 --> Loader Class Initialized
INFO - 2017-03-15 15:52:26 --> Database Driver Class Initialized
INFO - 2017-03-15 15:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:52:26 --> Controller Class Initialized
INFO - 2017-03-15 15:52:26 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:52:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:52:26 --> Final output sent to browser
DEBUG - 2017-03-15 15:52:26 --> Total execution time: 0.0139
INFO - 2017-03-15 15:52:28 --> Config Class Initialized
INFO - 2017-03-15 15:52:28 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:52:28 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:52:28 --> Utf8 Class Initialized
INFO - 2017-03-15 15:52:28 --> URI Class Initialized
INFO - 2017-03-15 15:52:28 --> Router Class Initialized
INFO - 2017-03-15 15:52:28 --> Output Class Initialized
INFO - 2017-03-15 15:52:28 --> Security Class Initialized
DEBUG - 2017-03-15 15:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:52:28 --> Input Class Initialized
INFO - 2017-03-15 15:52:28 --> Language Class Initialized
INFO - 2017-03-15 15:52:28 --> Loader Class Initialized
INFO - 2017-03-15 15:52:28 --> Database Driver Class Initialized
INFO - 2017-03-15 15:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:52:28 --> Controller Class Initialized
INFO - 2017-03-15 15:52:28 --> Helper loaded: date_helper
DEBUG - 2017-03-15 15:52:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:52:28 --> Helper loaded: url_helper
INFO - 2017-03-15 15:52:28 --> Helper loaded: download_helper
INFO - 2017-03-15 15:52:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:52:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-15 15:52:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-15 15:52:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-15 15:52:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:52:28 --> Final output sent to browser
DEBUG - 2017-03-15 15:52:28 --> Total execution time: 0.0206
INFO - 2017-03-15 15:53:16 --> Config Class Initialized
INFO - 2017-03-15 15:53:16 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:53:16 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:53:16 --> Utf8 Class Initialized
INFO - 2017-03-15 15:53:16 --> URI Class Initialized
INFO - 2017-03-15 15:53:16 --> Router Class Initialized
INFO - 2017-03-15 15:53:16 --> Output Class Initialized
INFO - 2017-03-15 15:53:16 --> Security Class Initialized
DEBUG - 2017-03-15 15:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:53:17 --> Input Class Initialized
INFO - 2017-03-15 15:53:17 --> Language Class Initialized
INFO - 2017-03-15 15:53:17 --> Loader Class Initialized
INFO - 2017-03-15 15:53:17 --> Database Driver Class Initialized
INFO - 2017-03-15 15:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:53:17 --> Controller Class Initialized
INFO - 2017-03-15 15:53:17 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:53:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:53:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:53:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:53:18 --> Final output sent to browser
DEBUG - 2017-03-15 15:53:18 --> Total execution time: 1.5835
INFO - 2017-03-15 15:54:08 --> Config Class Initialized
INFO - 2017-03-15 15:54:08 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:54:08 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:54:08 --> Utf8 Class Initialized
INFO - 2017-03-15 15:54:08 --> URI Class Initialized
INFO - 2017-03-15 15:54:08 --> Router Class Initialized
INFO - 2017-03-15 15:54:08 --> Output Class Initialized
INFO - 2017-03-15 15:54:08 --> Security Class Initialized
DEBUG - 2017-03-15 15:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:54:08 --> Input Class Initialized
INFO - 2017-03-15 15:54:08 --> Language Class Initialized
INFO - 2017-03-15 15:54:08 --> Loader Class Initialized
INFO - 2017-03-15 15:54:08 --> Database Driver Class Initialized
INFO - 2017-03-15 15:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:54:08 --> Controller Class Initialized
INFO - 2017-03-15 15:54:08 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:54:08 --> Config Class Initialized
INFO - 2017-03-15 15:54:08 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:54:08 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:54:08 --> Utf8 Class Initialized
INFO - 2017-03-15 15:54:08 --> URI Class Initialized
DEBUG - 2017-03-15 15:54:08 --> No URI present. Default controller set.
INFO - 2017-03-15 15:54:08 --> Router Class Initialized
INFO - 2017-03-15 15:54:08 --> Output Class Initialized
INFO - 2017-03-15 15:54:08 --> Security Class Initialized
DEBUG - 2017-03-15 15:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:54:08 --> Input Class Initialized
INFO - 2017-03-15 15:54:08 --> Language Class Initialized
INFO - 2017-03-15 15:54:08 --> Loader Class Initialized
INFO - 2017-03-15 15:54:08 --> Database Driver Class Initialized
INFO - 2017-03-15 15:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:54:08 --> Controller Class Initialized
INFO - 2017-03-15 15:54:08 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:54:08 --> Final output sent to browser
DEBUG - 2017-03-15 15:54:08 --> Total execution time: 0.0147
INFO - 2017-03-15 15:54:08 --> Config Class Initialized
INFO - 2017-03-15 15:54:08 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:54:08 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:54:08 --> Utf8 Class Initialized
INFO - 2017-03-15 15:54:08 --> URI Class Initialized
INFO - 2017-03-15 15:54:08 --> Router Class Initialized
INFO - 2017-03-15 15:54:08 --> Output Class Initialized
INFO - 2017-03-15 15:54:08 --> Security Class Initialized
DEBUG - 2017-03-15 15:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:54:08 --> Input Class Initialized
INFO - 2017-03-15 15:54:08 --> Language Class Initialized
INFO - 2017-03-15 15:54:08 --> Loader Class Initialized
INFO - 2017-03-15 15:54:08 --> Database Driver Class Initialized
INFO - 2017-03-15 15:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:54:08 --> Controller Class Initialized
INFO - 2017-03-15 15:54:08 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:54:08 --> Final output sent to browser
DEBUG - 2017-03-15 15:54:08 --> Total execution time: 0.0138
INFO - 2017-03-15 15:54:10 --> Config Class Initialized
INFO - 2017-03-15 15:54:10 --> Hooks Class Initialized
DEBUG - 2017-03-15 15:54:11 --> UTF-8 Support Enabled
INFO - 2017-03-15 15:54:11 --> Utf8 Class Initialized
INFO - 2017-03-15 15:54:11 --> URI Class Initialized
INFO - 2017-03-15 15:54:11 --> Router Class Initialized
INFO - 2017-03-15 15:54:11 --> Output Class Initialized
INFO - 2017-03-15 15:54:11 --> Security Class Initialized
DEBUG - 2017-03-15 15:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 15:54:11 --> Input Class Initialized
INFO - 2017-03-15 15:54:11 --> Language Class Initialized
INFO - 2017-03-15 15:54:11 --> Loader Class Initialized
INFO - 2017-03-15 15:54:11 --> Database Driver Class Initialized
INFO - 2017-03-15 15:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 15:54:11 --> Controller Class Initialized
INFO - 2017-03-15 15:54:11 --> Helper loaded: url_helper
DEBUG - 2017-03-15 15:54:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 15:54:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 15:54:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 15:54:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 15:54:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 15:54:12 --> Final output sent to browser
DEBUG - 2017-03-15 15:54:12 --> Total execution time: 1.2143
INFO - 2017-03-15 16:08:34 --> Config Class Initialized
INFO - 2017-03-15 16:08:34 --> Hooks Class Initialized
DEBUG - 2017-03-15 16:08:34 --> UTF-8 Support Enabled
INFO - 2017-03-15 16:08:34 --> Utf8 Class Initialized
INFO - 2017-03-15 16:08:34 --> URI Class Initialized
DEBUG - 2017-03-15 16:08:34 --> No URI present. Default controller set.
INFO - 2017-03-15 16:08:34 --> Router Class Initialized
INFO - 2017-03-15 16:08:34 --> Output Class Initialized
INFO - 2017-03-15 16:08:34 --> Security Class Initialized
DEBUG - 2017-03-15 16:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 16:08:34 --> Input Class Initialized
INFO - 2017-03-15 16:08:34 --> Language Class Initialized
INFO - 2017-03-15 16:08:35 --> Loader Class Initialized
INFO - 2017-03-15 16:08:35 --> Database Driver Class Initialized
INFO - 2017-03-15 16:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 16:08:35 --> Controller Class Initialized
INFO - 2017-03-15 16:08:35 --> Helper loaded: url_helper
DEBUG - 2017-03-15 16:08:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 16:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 16:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 16:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 16:08:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 16:08:35 --> Final output sent to browser
DEBUG - 2017-03-15 16:08:35 --> Total execution time: 1.2122
INFO - 2017-03-15 16:08:47 --> Config Class Initialized
INFO - 2017-03-15 16:08:47 --> Hooks Class Initialized
DEBUG - 2017-03-15 16:08:47 --> UTF-8 Support Enabled
INFO - 2017-03-15 16:08:47 --> Utf8 Class Initialized
INFO - 2017-03-15 16:08:47 --> URI Class Initialized
INFO - 2017-03-15 16:08:47 --> Router Class Initialized
INFO - 2017-03-15 16:08:47 --> Output Class Initialized
INFO - 2017-03-15 16:08:47 --> Security Class Initialized
DEBUG - 2017-03-15 16:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 16:08:47 --> Input Class Initialized
INFO - 2017-03-15 16:08:47 --> Language Class Initialized
INFO - 2017-03-15 16:08:47 --> Loader Class Initialized
INFO - 2017-03-15 16:08:47 --> Database Driver Class Initialized
INFO - 2017-03-15 16:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 16:08:47 --> Controller Class Initialized
INFO - 2017-03-15 16:08:47 --> Helper loaded: url_helper
DEBUG - 2017-03-15 16:08:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 16:08:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 16:08:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 16:08:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 16:08:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 16:08:47 --> Final output sent to browser
DEBUG - 2017-03-15 16:08:47 --> Total execution time: 0.0147
INFO - 2017-03-15 16:14:31 --> Config Class Initialized
INFO - 2017-03-15 16:14:31 --> Hooks Class Initialized
DEBUG - 2017-03-15 16:14:31 --> UTF-8 Support Enabled
INFO - 2017-03-15 16:14:31 --> Utf8 Class Initialized
INFO - 2017-03-15 16:14:31 --> URI Class Initialized
INFO - 2017-03-15 16:14:31 --> Router Class Initialized
INFO - 2017-03-15 16:14:31 --> Output Class Initialized
INFO - 2017-03-15 16:14:31 --> Security Class Initialized
DEBUG - 2017-03-15 16:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 16:14:31 --> Input Class Initialized
INFO - 2017-03-15 16:14:31 --> Language Class Initialized
INFO - 2017-03-15 16:14:31 --> Loader Class Initialized
INFO - 2017-03-15 16:14:32 --> Database Driver Class Initialized
INFO - 2017-03-15 16:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 16:14:32 --> Controller Class Initialized
INFO - 2017-03-15 16:14:32 --> Helper loaded: url_helper
DEBUG - 2017-03-15 16:14:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 16:14:33 --> Config Class Initialized
INFO - 2017-03-15 16:14:33 --> Hooks Class Initialized
DEBUG - 2017-03-15 16:14:33 --> UTF-8 Support Enabled
INFO - 2017-03-15 16:14:33 --> Utf8 Class Initialized
INFO - 2017-03-15 16:14:33 --> URI Class Initialized
INFO - 2017-03-15 16:14:33 --> Router Class Initialized
INFO - 2017-03-15 16:14:33 --> Output Class Initialized
INFO - 2017-03-15 16:14:33 --> Security Class Initialized
DEBUG - 2017-03-15 16:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 16:14:33 --> Input Class Initialized
INFO - 2017-03-15 16:14:33 --> Language Class Initialized
INFO - 2017-03-15 16:14:33 --> Loader Class Initialized
INFO - 2017-03-15 16:14:33 --> Database Driver Class Initialized
INFO - 2017-03-15 16:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 16:14:33 --> Controller Class Initialized
INFO - 2017-03-15 16:14:33 --> Helper loaded: date_helper
DEBUG - 2017-03-15 16:14:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 16:14:33 --> Helper loaded: url_helper
INFO - 2017-03-15 16:14:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 16:14:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 16:14:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 16:14:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 16:14:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 16:14:33 --> Final output sent to browser
DEBUG - 2017-03-15 16:14:33 --> Total execution time: 0.1086
INFO - 2017-03-15 16:14:34 --> Config Class Initialized
INFO - 2017-03-15 16:14:34 --> Hooks Class Initialized
DEBUG - 2017-03-15 16:14:34 --> UTF-8 Support Enabled
INFO - 2017-03-15 16:14:34 --> Utf8 Class Initialized
INFO - 2017-03-15 16:14:34 --> URI Class Initialized
INFO - 2017-03-15 16:14:34 --> Router Class Initialized
INFO - 2017-03-15 16:14:34 --> Output Class Initialized
INFO - 2017-03-15 16:14:34 --> Security Class Initialized
DEBUG - 2017-03-15 16:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 16:14:34 --> Input Class Initialized
INFO - 2017-03-15 16:14:34 --> Language Class Initialized
INFO - 2017-03-15 16:14:34 --> Loader Class Initialized
INFO - 2017-03-15 16:14:34 --> Database Driver Class Initialized
INFO - 2017-03-15 16:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 16:14:34 --> Controller Class Initialized
INFO - 2017-03-15 16:14:34 --> Helper loaded: url_helper
DEBUG - 2017-03-15 16:14:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 16:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 16:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 16:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 16:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 16:14:34 --> Final output sent to browser
DEBUG - 2017-03-15 16:14:34 --> Total execution time: 0.0516
INFO - 2017-03-15 16:14:53 --> Config Class Initialized
INFO - 2017-03-15 16:14:53 --> Hooks Class Initialized
DEBUG - 2017-03-15 16:14:53 --> UTF-8 Support Enabled
INFO - 2017-03-15 16:14:53 --> Utf8 Class Initialized
INFO - 2017-03-15 16:14:53 --> URI Class Initialized
DEBUG - 2017-03-15 16:14:53 --> No URI present. Default controller set.
INFO - 2017-03-15 16:14:53 --> Router Class Initialized
INFO - 2017-03-15 16:14:53 --> Output Class Initialized
INFO - 2017-03-15 16:14:53 --> Security Class Initialized
DEBUG - 2017-03-15 16:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 16:14:53 --> Input Class Initialized
INFO - 2017-03-15 16:14:53 --> Language Class Initialized
INFO - 2017-03-15 16:14:53 --> Loader Class Initialized
INFO - 2017-03-15 16:14:53 --> Database Driver Class Initialized
INFO - 2017-03-15 16:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 16:14:53 --> Controller Class Initialized
INFO - 2017-03-15 16:14:53 --> Helper loaded: url_helper
DEBUG - 2017-03-15 16:14:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 16:14:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 16:14:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 16:14:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 16:14:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 16:14:53 --> Final output sent to browser
DEBUG - 2017-03-15 16:14:53 --> Total execution time: 0.0140
INFO - 2017-03-15 16:14:54 --> Config Class Initialized
INFO - 2017-03-15 16:14:54 --> Hooks Class Initialized
DEBUG - 2017-03-15 16:14:54 --> UTF-8 Support Enabled
INFO - 2017-03-15 16:14:54 --> Utf8 Class Initialized
INFO - 2017-03-15 16:14:54 --> URI Class Initialized
INFO - 2017-03-15 16:14:54 --> Router Class Initialized
INFO - 2017-03-15 16:14:54 --> Output Class Initialized
INFO - 2017-03-15 16:14:54 --> Security Class Initialized
DEBUG - 2017-03-15 16:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 16:14:54 --> Input Class Initialized
INFO - 2017-03-15 16:14:54 --> Language Class Initialized
INFO - 2017-03-15 16:14:54 --> Loader Class Initialized
INFO - 2017-03-15 16:14:54 --> Database Driver Class Initialized
INFO - 2017-03-15 16:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 16:14:54 --> Controller Class Initialized
INFO - 2017-03-15 16:14:54 --> Helper loaded: url_helper
DEBUG - 2017-03-15 16:14:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 16:14:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 16:14:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 16:14:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 16:14:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 16:14:54 --> Final output sent to browser
DEBUG - 2017-03-15 16:14:54 --> Total execution time: 0.0144
INFO - 2017-03-15 16:41:00 --> Config Class Initialized
INFO - 2017-03-15 16:41:00 --> Config Class Initialized
INFO - 2017-03-15 16:41:00 --> Hooks Class Initialized
INFO - 2017-03-15 16:41:00 --> Hooks Class Initialized
DEBUG - 2017-03-15 16:41:00 --> UTF-8 Support Enabled
DEBUG - 2017-03-15 16:41:00 --> UTF-8 Support Enabled
INFO - 2017-03-15 16:41:00 --> Utf8 Class Initialized
INFO - 2017-03-15 16:41:00 --> Utf8 Class Initialized
INFO - 2017-03-15 16:41:00 --> URI Class Initialized
INFO - 2017-03-15 16:41:00 --> URI Class Initialized
INFO - 2017-03-15 16:41:00 --> Router Class Initialized
DEBUG - 2017-03-15 16:41:00 --> No URI present. Default controller set.
INFO - 2017-03-15 16:41:00 --> Router Class Initialized
INFO - 2017-03-15 16:41:00 --> Output Class Initialized
INFO - 2017-03-15 16:41:00 --> Security Class Initialized
INFO - 2017-03-15 16:41:00 --> Output Class Initialized
INFO - 2017-03-15 16:41:00 --> Security Class Initialized
DEBUG - 2017-03-15 16:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 16:41:00 --> Input Class Initialized
DEBUG - 2017-03-15 16:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 16:41:00 --> Input Class Initialized
INFO - 2017-03-15 16:41:00 --> Language Class Initialized
INFO - 2017-03-15 16:41:00 --> Language Class Initialized
INFO - 2017-03-15 16:41:00 --> Loader Class Initialized
INFO - 2017-03-15 16:41:00 --> Loader Class Initialized
INFO - 2017-03-15 16:41:00 --> Database Driver Class Initialized
INFO - 2017-03-15 16:41:00 --> Database Driver Class Initialized
INFO - 2017-03-15 16:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 16:41:01 --> Controller Class Initialized
INFO - 2017-03-15 16:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 16:41:01 --> Controller Class Initialized
INFO - 2017-03-15 16:41:01 --> Helper loaded: url_helper
INFO - 2017-03-15 16:41:01 --> Helper loaded: url_helper
DEBUG - 2017-03-15 16:41:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-15 16:41:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 16:41:01 --> Helper loaded: form_helper
INFO - 2017-03-15 16:41:01 --> Form Validation Class Initialized
INFO - 2017-03-15 16:41:01 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-03-15 16:41:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 16:41:01 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-03-15 16:41:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 16:41:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 16:41:01 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-03-15 16:41:01 --> Final output sent to browser
DEBUG - 2017-03-15 16:41:01 --> Total execution time: 1.3788
INFO - 2017-03-15 16:41:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 16:41:01 --> Final output sent to browser
DEBUG - 2017-03-15 16:41:01 --> Total execution time: 1.3844
INFO - 2017-03-15 16:41:02 --> Config Class Initialized
INFO - 2017-03-15 16:41:02 --> Hooks Class Initialized
DEBUG - 2017-03-15 16:41:02 --> UTF-8 Support Enabled
INFO - 2017-03-15 16:41:02 --> Utf8 Class Initialized
INFO - 2017-03-15 16:41:02 --> URI Class Initialized
INFO - 2017-03-15 16:41:02 --> Router Class Initialized
INFO - 2017-03-15 16:41:02 --> Output Class Initialized
INFO - 2017-03-15 16:41:02 --> Security Class Initialized
DEBUG - 2017-03-15 16:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 16:41:02 --> Input Class Initialized
INFO - 2017-03-15 16:41:02 --> Language Class Initialized
INFO - 2017-03-15 16:41:02 --> Loader Class Initialized
INFO - 2017-03-15 16:41:02 --> Database Driver Class Initialized
INFO - 2017-03-15 16:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 16:41:02 --> Controller Class Initialized
INFO - 2017-03-15 16:41:02 --> Helper loaded: url_helper
DEBUG - 2017-03-15 16:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 16:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 16:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 16:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 16:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 16:41:03 --> Final output sent to browser
DEBUG - 2017-03-15 16:41:03 --> Total execution time: 1.2188
INFO - 2017-03-15 16:46:47 --> Config Class Initialized
INFO - 2017-03-15 16:46:47 --> Hooks Class Initialized
DEBUG - 2017-03-15 16:46:47 --> UTF-8 Support Enabled
INFO - 2017-03-15 16:46:47 --> Utf8 Class Initialized
INFO - 2017-03-15 16:46:47 --> URI Class Initialized
DEBUG - 2017-03-15 16:46:47 --> No URI present. Default controller set.
INFO - 2017-03-15 16:46:47 --> Router Class Initialized
INFO - 2017-03-15 16:46:48 --> Output Class Initialized
INFO - 2017-03-15 16:46:48 --> Security Class Initialized
DEBUG - 2017-03-15 16:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 16:46:48 --> Input Class Initialized
INFO - 2017-03-15 16:46:48 --> Language Class Initialized
INFO - 2017-03-15 16:46:48 --> Loader Class Initialized
INFO - 2017-03-15 16:46:48 --> Database Driver Class Initialized
INFO - 2017-03-15 16:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 16:46:48 --> Controller Class Initialized
INFO - 2017-03-15 16:46:48 --> Helper loaded: url_helper
DEBUG - 2017-03-15 16:46:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 16:46:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 16:46:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 16:46:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 16:46:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 16:46:49 --> Final output sent to browser
DEBUG - 2017-03-15 16:46:49 --> Total execution time: 1.4204
INFO - 2017-03-15 16:46:58 --> Config Class Initialized
INFO - 2017-03-15 16:46:58 --> Hooks Class Initialized
DEBUG - 2017-03-15 16:46:58 --> UTF-8 Support Enabled
INFO - 2017-03-15 16:46:58 --> Utf8 Class Initialized
INFO - 2017-03-15 16:46:58 --> URI Class Initialized
INFO - 2017-03-15 16:46:59 --> Router Class Initialized
INFO - 2017-03-15 16:46:59 --> Output Class Initialized
INFO - 2017-03-15 16:46:59 --> Security Class Initialized
DEBUG - 2017-03-15 16:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 16:46:59 --> Input Class Initialized
INFO - 2017-03-15 16:46:59 --> Language Class Initialized
INFO - 2017-03-15 16:46:59 --> Loader Class Initialized
INFO - 2017-03-15 16:46:59 --> Database Driver Class Initialized
INFO - 2017-03-15 16:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 16:46:59 --> Controller Class Initialized
INFO - 2017-03-15 16:46:59 --> Helper loaded: url_helper
DEBUG - 2017-03-15 16:46:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 16:46:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 16:46:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 16:47:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 16:47:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 16:47:00 --> Final output sent to browser
DEBUG - 2017-03-15 16:47:00 --> Total execution time: 1.2124
INFO - 2017-03-15 16:48:09 --> Config Class Initialized
INFO - 2017-03-15 16:48:09 --> Hooks Class Initialized
DEBUG - 2017-03-15 16:48:09 --> UTF-8 Support Enabled
INFO - 2017-03-15 16:48:09 --> Utf8 Class Initialized
INFO - 2017-03-15 16:48:09 --> URI Class Initialized
INFO - 2017-03-15 16:48:10 --> Router Class Initialized
INFO - 2017-03-15 16:48:10 --> Output Class Initialized
INFO - 2017-03-15 16:48:10 --> Security Class Initialized
DEBUG - 2017-03-15 16:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 16:48:10 --> Input Class Initialized
INFO - 2017-03-15 16:48:10 --> Language Class Initialized
INFO - 2017-03-15 16:48:10 --> Loader Class Initialized
INFO - 2017-03-15 16:48:10 --> Database Driver Class Initialized
INFO - 2017-03-15 16:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 16:48:10 --> Controller Class Initialized
INFO - 2017-03-15 16:48:10 --> Helper loaded: url_helper
DEBUG - 2017-03-15 16:48:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 16:48:12 --> Config Class Initialized
INFO - 2017-03-15 16:48:12 --> Hooks Class Initialized
DEBUG - 2017-03-15 16:48:12 --> UTF-8 Support Enabled
INFO - 2017-03-15 16:48:12 --> Utf8 Class Initialized
INFO - 2017-03-15 16:48:12 --> URI Class Initialized
INFO - 2017-03-15 16:48:12 --> Router Class Initialized
INFO - 2017-03-15 16:48:12 --> Output Class Initialized
INFO - 2017-03-15 16:48:12 --> Security Class Initialized
DEBUG - 2017-03-15 16:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 16:48:12 --> Input Class Initialized
INFO - 2017-03-15 16:48:12 --> Language Class Initialized
INFO - 2017-03-15 16:48:12 --> Loader Class Initialized
INFO - 2017-03-15 16:48:12 --> Database Driver Class Initialized
INFO - 2017-03-15 16:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 16:48:12 --> Controller Class Initialized
INFO - 2017-03-15 16:48:12 --> Helper loaded: date_helper
DEBUG - 2017-03-15 16:48:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 16:48:12 --> Helper loaded: url_helper
INFO - 2017-03-15 16:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 16:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 16:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 16:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 16:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 16:48:12 --> Final output sent to browser
DEBUG - 2017-03-15 16:48:12 --> Total execution time: 0.1182
INFO - 2017-03-15 16:48:13 --> Config Class Initialized
INFO - 2017-03-15 16:48:13 --> Hooks Class Initialized
DEBUG - 2017-03-15 16:48:13 --> UTF-8 Support Enabled
INFO - 2017-03-15 16:48:13 --> Utf8 Class Initialized
INFO - 2017-03-15 16:48:13 --> URI Class Initialized
INFO - 2017-03-15 16:48:13 --> Router Class Initialized
INFO - 2017-03-15 16:48:13 --> Output Class Initialized
INFO - 2017-03-15 16:48:13 --> Security Class Initialized
DEBUG - 2017-03-15 16:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 16:48:13 --> Input Class Initialized
INFO - 2017-03-15 16:48:13 --> Language Class Initialized
INFO - 2017-03-15 16:48:13 --> Loader Class Initialized
INFO - 2017-03-15 16:48:13 --> Database Driver Class Initialized
INFO - 2017-03-15 16:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 16:48:13 --> Controller Class Initialized
INFO - 2017-03-15 16:48:13 --> Helper loaded: url_helper
DEBUG - 2017-03-15 16:48:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 16:48:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 16:48:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 16:48:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 16:48:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 16:48:13 --> Final output sent to browser
DEBUG - 2017-03-15 16:48:13 --> Total execution time: 0.0386
INFO - 2017-03-15 16:49:22 --> Config Class Initialized
INFO - 2017-03-15 16:49:22 --> Hooks Class Initialized
DEBUG - 2017-03-15 16:49:22 --> UTF-8 Support Enabled
INFO - 2017-03-15 16:49:22 --> Utf8 Class Initialized
INFO - 2017-03-15 16:49:22 --> URI Class Initialized
DEBUG - 2017-03-15 16:49:22 --> No URI present. Default controller set.
INFO - 2017-03-15 16:49:22 --> Router Class Initialized
INFO - 2017-03-15 16:49:22 --> Output Class Initialized
INFO - 2017-03-15 16:49:22 --> Security Class Initialized
DEBUG - 2017-03-15 16:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 16:49:22 --> Input Class Initialized
INFO - 2017-03-15 16:49:22 --> Language Class Initialized
INFO - 2017-03-15 16:49:22 --> Loader Class Initialized
INFO - 2017-03-15 16:49:22 --> Database Driver Class Initialized
INFO - 2017-03-15 16:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 16:49:22 --> Controller Class Initialized
INFO - 2017-03-15 16:49:22 --> Helper loaded: url_helper
DEBUG - 2017-03-15 16:49:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 16:49:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 16:49:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 16:49:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 16:49:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 16:49:22 --> Final output sent to browser
DEBUG - 2017-03-15 16:49:22 --> Total execution time: 0.0145
INFO - 2017-03-15 16:49:35 --> Config Class Initialized
INFO - 2017-03-15 16:49:35 --> Hooks Class Initialized
DEBUG - 2017-03-15 16:49:35 --> UTF-8 Support Enabled
INFO - 2017-03-15 16:49:35 --> Utf8 Class Initialized
INFO - 2017-03-15 16:49:35 --> URI Class Initialized
INFO - 2017-03-15 16:49:35 --> Router Class Initialized
INFO - 2017-03-15 16:49:35 --> Output Class Initialized
INFO - 2017-03-15 16:49:35 --> Security Class Initialized
DEBUG - 2017-03-15 16:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 16:49:35 --> Input Class Initialized
INFO - 2017-03-15 16:49:35 --> Language Class Initialized
INFO - 2017-03-15 16:49:35 --> Loader Class Initialized
INFO - 2017-03-15 16:49:35 --> Database Driver Class Initialized
INFO - 2017-03-15 16:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 16:49:35 --> Controller Class Initialized
INFO - 2017-03-15 16:49:35 --> Helper loaded: url_helper
DEBUG - 2017-03-15 16:49:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 16:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 16:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 16:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 16:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 16:49:35 --> Final output sent to browser
DEBUG - 2017-03-15 16:49:35 --> Total execution time: 0.0142
INFO - 2017-03-15 16:49:49 --> Config Class Initialized
INFO - 2017-03-15 16:49:49 --> Hooks Class Initialized
DEBUG - 2017-03-15 16:49:49 --> UTF-8 Support Enabled
INFO - 2017-03-15 16:49:49 --> Utf8 Class Initialized
INFO - 2017-03-15 16:49:49 --> URI Class Initialized
INFO - 2017-03-15 16:49:49 --> Router Class Initialized
INFO - 2017-03-15 16:49:49 --> Output Class Initialized
INFO - 2017-03-15 16:49:49 --> Security Class Initialized
DEBUG - 2017-03-15 16:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 16:49:49 --> Input Class Initialized
INFO - 2017-03-15 16:49:49 --> Language Class Initialized
INFO - 2017-03-15 16:49:49 --> Loader Class Initialized
INFO - 2017-03-15 16:49:49 --> Database Driver Class Initialized
INFO - 2017-03-15 16:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 16:49:49 --> Controller Class Initialized
INFO - 2017-03-15 16:49:49 --> Helper loaded: url_helper
DEBUG - 2017-03-15 16:49:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 16:49:50 --> Config Class Initialized
INFO - 2017-03-15 16:49:50 --> Hooks Class Initialized
DEBUG - 2017-03-15 16:49:50 --> UTF-8 Support Enabled
INFO - 2017-03-15 16:49:50 --> Utf8 Class Initialized
INFO - 2017-03-15 16:49:50 --> URI Class Initialized
INFO - 2017-03-15 16:49:50 --> Router Class Initialized
INFO - 2017-03-15 16:49:50 --> Output Class Initialized
INFO - 2017-03-15 16:49:50 --> Security Class Initialized
DEBUG - 2017-03-15 16:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 16:49:50 --> Input Class Initialized
INFO - 2017-03-15 16:49:50 --> Language Class Initialized
INFO - 2017-03-15 16:49:50 --> Loader Class Initialized
INFO - 2017-03-15 16:49:50 --> Database Driver Class Initialized
INFO - 2017-03-15 16:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 16:49:50 --> Controller Class Initialized
INFO - 2017-03-15 16:49:50 --> Helper loaded: date_helper
DEBUG - 2017-03-15 16:49:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 16:49:50 --> Helper loaded: url_helper
INFO - 2017-03-15 16:49:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 16:49:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 16:49:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 16:49:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 16:49:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 16:49:50 --> Final output sent to browser
DEBUG - 2017-03-15 16:49:50 --> Total execution time: 0.0143
INFO - 2017-03-15 16:49:52 --> Config Class Initialized
INFO - 2017-03-15 16:49:52 --> Hooks Class Initialized
DEBUG - 2017-03-15 16:49:52 --> UTF-8 Support Enabled
INFO - 2017-03-15 16:49:52 --> Utf8 Class Initialized
INFO - 2017-03-15 16:49:52 --> URI Class Initialized
INFO - 2017-03-15 16:49:52 --> Router Class Initialized
INFO - 2017-03-15 16:49:52 --> Output Class Initialized
INFO - 2017-03-15 16:49:52 --> Security Class Initialized
DEBUG - 2017-03-15 16:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 16:49:52 --> Input Class Initialized
INFO - 2017-03-15 16:49:52 --> Language Class Initialized
INFO - 2017-03-15 16:49:52 --> Loader Class Initialized
INFO - 2017-03-15 16:49:52 --> Database Driver Class Initialized
INFO - 2017-03-15 16:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 16:49:52 --> Controller Class Initialized
INFO - 2017-03-15 16:49:52 --> Helper loaded: url_helper
DEBUG - 2017-03-15 16:49:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 16:49:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 16:49:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 16:49:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 16:49:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 16:49:52 --> Final output sent to browser
DEBUG - 2017-03-15 16:49:52 --> Total execution time: 0.0138
INFO - 2017-03-15 16:49:55 --> Config Class Initialized
INFO - 2017-03-15 16:49:55 --> Hooks Class Initialized
DEBUG - 2017-03-15 16:49:55 --> UTF-8 Support Enabled
INFO - 2017-03-15 16:49:55 --> Utf8 Class Initialized
INFO - 2017-03-15 16:49:55 --> URI Class Initialized
DEBUG - 2017-03-15 16:49:55 --> No URI present. Default controller set.
INFO - 2017-03-15 16:49:55 --> Router Class Initialized
INFO - 2017-03-15 16:49:55 --> Output Class Initialized
INFO - 2017-03-15 16:49:55 --> Security Class Initialized
DEBUG - 2017-03-15 16:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 16:49:55 --> Input Class Initialized
INFO - 2017-03-15 16:49:55 --> Language Class Initialized
INFO - 2017-03-15 16:49:55 --> Loader Class Initialized
INFO - 2017-03-15 16:49:55 --> Database Driver Class Initialized
INFO - 2017-03-15 16:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 16:49:55 --> Controller Class Initialized
INFO - 2017-03-15 16:49:55 --> Helper loaded: url_helper
DEBUG - 2017-03-15 16:49:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 16:49:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 16:49:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 16:49:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 16:49:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 16:49:55 --> Final output sent to browser
DEBUG - 2017-03-15 16:49:55 --> Total execution time: 0.0138
INFO - 2017-03-15 16:49:57 --> Config Class Initialized
INFO - 2017-03-15 16:49:57 --> Hooks Class Initialized
DEBUG - 2017-03-15 16:49:57 --> UTF-8 Support Enabled
INFO - 2017-03-15 16:49:57 --> Utf8 Class Initialized
INFO - 2017-03-15 16:49:57 --> URI Class Initialized
INFO - 2017-03-15 16:49:57 --> Router Class Initialized
INFO - 2017-03-15 16:49:57 --> Output Class Initialized
INFO - 2017-03-15 16:49:57 --> Security Class Initialized
DEBUG - 2017-03-15 16:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 16:49:57 --> Input Class Initialized
INFO - 2017-03-15 16:49:57 --> Language Class Initialized
INFO - 2017-03-15 16:49:57 --> Loader Class Initialized
INFO - 2017-03-15 16:49:57 --> Database Driver Class Initialized
INFO - 2017-03-15 16:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 16:49:57 --> Controller Class Initialized
INFO - 2017-03-15 16:49:57 --> Helper loaded: url_helper
DEBUG - 2017-03-15 16:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 16:49:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 16:49:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 16:49:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 16:49:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 16:49:57 --> Final output sent to browser
DEBUG - 2017-03-15 16:49:57 --> Total execution time: 0.0137
INFO - 2017-03-15 17:22:52 --> Config Class Initialized
INFO - 2017-03-15 17:22:52 --> Hooks Class Initialized
DEBUG - 2017-03-15 17:22:52 --> UTF-8 Support Enabled
INFO - 2017-03-15 17:22:52 --> Utf8 Class Initialized
INFO - 2017-03-15 17:22:52 --> URI Class Initialized
INFO - 2017-03-15 17:22:52 --> Router Class Initialized
INFO - 2017-03-15 17:22:52 --> Output Class Initialized
INFO - 2017-03-15 17:22:52 --> Security Class Initialized
DEBUG - 2017-03-15 17:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 17:22:52 --> Input Class Initialized
INFO - 2017-03-15 17:22:52 --> Language Class Initialized
INFO - 2017-03-15 17:22:52 --> Loader Class Initialized
INFO - 2017-03-15 17:22:53 --> Database Driver Class Initialized
INFO - 2017-03-15 17:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 17:22:53 --> Controller Class Initialized
INFO - 2017-03-15 17:22:53 --> Helper loaded: url_helper
DEBUG - 2017-03-15 17:22:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 17:22:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 17:22:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 17:22:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 17:22:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 17:22:53 --> Final output sent to browser
DEBUG - 2017-03-15 17:22:53 --> Total execution time: 1.5176
INFO - 2017-03-15 17:22:56 --> Config Class Initialized
INFO - 2017-03-15 17:22:56 --> Hooks Class Initialized
DEBUG - 2017-03-15 17:22:56 --> UTF-8 Support Enabled
INFO - 2017-03-15 17:22:56 --> Utf8 Class Initialized
INFO - 2017-03-15 17:22:56 --> URI Class Initialized
DEBUG - 2017-03-15 17:22:56 --> No URI present. Default controller set.
INFO - 2017-03-15 17:22:56 --> Router Class Initialized
INFO - 2017-03-15 17:22:56 --> Output Class Initialized
INFO - 2017-03-15 17:22:56 --> Security Class Initialized
DEBUG - 2017-03-15 17:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 17:22:56 --> Input Class Initialized
INFO - 2017-03-15 17:22:56 --> Language Class Initialized
INFO - 2017-03-15 17:22:56 --> Loader Class Initialized
INFO - 2017-03-15 17:22:56 --> Database Driver Class Initialized
INFO - 2017-03-15 17:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 17:22:57 --> Controller Class Initialized
INFO - 2017-03-15 17:22:57 --> Helper loaded: url_helper
DEBUG - 2017-03-15 17:22:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 17:22:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 17:22:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 17:22:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 17:22:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 17:22:57 --> Final output sent to browser
DEBUG - 2017-03-15 17:22:57 --> Total execution time: 1.3074
INFO - 2017-03-15 18:43:14 --> Config Class Initialized
INFO - 2017-03-15 18:43:14 --> Hooks Class Initialized
DEBUG - 2017-03-15 18:43:15 --> UTF-8 Support Enabled
INFO - 2017-03-15 18:43:15 --> Utf8 Class Initialized
INFO - 2017-03-15 18:43:15 --> URI Class Initialized
INFO - 2017-03-15 18:43:15 --> Router Class Initialized
INFO - 2017-03-15 18:43:15 --> Output Class Initialized
INFO - 2017-03-15 18:43:15 --> Security Class Initialized
DEBUG - 2017-03-15 18:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 18:43:15 --> Input Class Initialized
INFO - 2017-03-15 18:43:15 --> Language Class Initialized
INFO - 2017-03-15 18:43:15 --> Loader Class Initialized
INFO - 2017-03-15 18:43:15 --> Database Driver Class Initialized
INFO - 2017-03-15 18:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 18:43:16 --> Controller Class Initialized
INFO - 2017-03-15 18:43:16 --> Helper loaded: date_helper
DEBUG - 2017-03-15 18:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 18:43:16 --> Helper loaded: url_helper
INFO - 2017-03-15 18:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 18:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 18:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 18:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 18:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 18:43:16 --> Final output sent to browser
DEBUG - 2017-03-15 18:43:16 --> Total execution time: 2.1363
INFO - 2017-03-15 19:46:13 --> Config Class Initialized
INFO - 2017-03-15 19:46:13 --> Hooks Class Initialized
DEBUG - 2017-03-15 19:46:13 --> UTF-8 Support Enabled
INFO - 2017-03-15 19:46:13 --> Utf8 Class Initialized
INFO - 2017-03-15 19:46:13 --> URI Class Initialized
INFO - 2017-03-15 19:46:13 --> Router Class Initialized
INFO - 2017-03-15 19:46:13 --> Output Class Initialized
INFO - 2017-03-15 19:46:13 --> Security Class Initialized
DEBUG - 2017-03-15 19:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 19:46:14 --> Input Class Initialized
INFO - 2017-03-15 19:46:14 --> Language Class Initialized
INFO - 2017-03-15 19:46:14 --> Loader Class Initialized
INFO - 2017-03-15 19:46:14 --> Database Driver Class Initialized
INFO - 2017-03-15 19:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 19:46:14 --> Controller Class Initialized
INFO - 2017-03-15 19:46:14 --> Helper loaded: url_helper
DEBUG - 2017-03-15 19:46:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 19:46:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 19:46:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 19:46:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 19:46:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 19:46:15 --> Final output sent to browser
DEBUG - 2017-03-15 19:46:15 --> Total execution time: 1.8260
INFO - 2017-03-15 20:11:21 --> Config Class Initialized
INFO - 2017-03-15 20:11:21 --> Hooks Class Initialized
DEBUG - 2017-03-15 20:11:22 --> UTF-8 Support Enabled
INFO - 2017-03-15 20:11:22 --> Utf8 Class Initialized
INFO - 2017-03-15 20:11:22 --> URI Class Initialized
DEBUG - 2017-03-15 20:11:22 --> No URI present. Default controller set.
INFO - 2017-03-15 20:11:22 --> Router Class Initialized
INFO - 2017-03-15 20:11:22 --> Output Class Initialized
INFO - 2017-03-15 20:11:22 --> Security Class Initialized
DEBUG - 2017-03-15 20:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 20:11:22 --> Input Class Initialized
INFO - 2017-03-15 20:11:22 --> Language Class Initialized
INFO - 2017-03-15 20:11:22 --> Loader Class Initialized
INFO - 2017-03-15 20:11:22 --> Database Driver Class Initialized
INFO - 2017-03-15 20:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 20:11:23 --> Controller Class Initialized
INFO - 2017-03-15 20:11:23 --> Helper loaded: url_helper
DEBUG - 2017-03-15 20:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 20:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 20:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 20:11:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 20:11:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 20:11:24 --> Final output sent to browser
DEBUG - 2017-03-15 20:11:24 --> Total execution time: 2.2460
INFO - 2017-03-15 20:11:40 --> Config Class Initialized
INFO - 2017-03-15 20:11:40 --> Hooks Class Initialized
DEBUG - 2017-03-15 20:11:40 --> UTF-8 Support Enabled
INFO - 2017-03-15 20:11:40 --> Utf8 Class Initialized
INFO - 2017-03-15 20:11:40 --> URI Class Initialized
DEBUG - 2017-03-15 20:11:40 --> No URI present. Default controller set.
INFO - 2017-03-15 20:11:40 --> Router Class Initialized
INFO - 2017-03-15 20:11:40 --> Output Class Initialized
INFO - 2017-03-15 20:11:40 --> Security Class Initialized
DEBUG - 2017-03-15 20:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 20:11:40 --> Input Class Initialized
INFO - 2017-03-15 20:11:40 --> Language Class Initialized
INFO - 2017-03-15 20:11:40 --> Loader Class Initialized
INFO - 2017-03-15 20:11:41 --> Database Driver Class Initialized
INFO - 2017-03-15 20:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 20:11:41 --> Controller Class Initialized
INFO - 2017-03-15 20:11:41 --> Helper loaded: url_helper
DEBUG - 2017-03-15 20:11:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 20:11:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 20:11:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 20:11:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 20:11:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 20:11:41 --> Final output sent to browser
DEBUG - 2017-03-15 20:11:41 --> Total execution time: 1.4898
INFO - 2017-03-15 20:11:45 --> Config Class Initialized
INFO - 2017-03-15 20:11:45 --> Hooks Class Initialized
DEBUG - 2017-03-15 20:11:45 --> UTF-8 Support Enabled
INFO - 2017-03-15 20:11:45 --> Utf8 Class Initialized
INFO - 2017-03-15 20:11:45 --> URI Class Initialized
DEBUG - 2017-03-15 20:11:45 --> No URI present. Default controller set.
INFO - 2017-03-15 20:11:45 --> Router Class Initialized
INFO - 2017-03-15 20:11:45 --> Output Class Initialized
INFO - 2017-03-15 20:11:45 --> Security Class Initialized
DEBUG - 2017-03-15 20:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 20:11:45 --> Input Class Initialized
INFO - 2017-03-15 20:11:45 --> Language Class Initialized
INFO - 2017-03-15 20:11:45 --> Loader Class Initialized
INFO - 2017-03-15 20:11:45 --> Database Driver Class Initialized
INFO - 2017-03-15 20:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 20:11:45 --> Controller Class Initialized
INFO - 2017-03-15 20:11:45 --> Helper loaded: url_helper
DEBUG - 2017-03-15 20:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 20:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 20:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 20:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 20:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 20:11:45 --> Final output sent to browser
DEBUG - 2017-03-15 20:11:45 --> Total execution time: 0.0134
INFO - 2017-03-15 20:12:04 --> Config Class Initialized
INFO - 2017-03-15 20:12:04 --> Hooks Class Initialized
DEBUG - 2017-03-15 20:12:04 --> UTF-8 Support Enabled
INFO - 2017-03-15 20:12:04 --> Utf8 Class Initialized
INFO - 2017-03-15 20:12:04 --> URI Class Initialized
INFO - 2017-03-15 20:12:04 --> Router Class Initialized
INFO - 2017-03-15 20:12:04 --> Output Class Initialized
INFO - 2017-03-15 20:12:04 --> Security Class Initialized
DEBUG - 2017-03-15 20:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 20:12:04 --> Input Class Initialized
INFO - 2017-03-15 20:12:04 --> Language Class Initialized
INFO - 2017-03-15 20:12:04 --> Loader Class Initialized
INFO - 2017-03-15 20:12:04 --> Database Driver Class Initialized
INFO - 2017-03-15 20:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 20:12:04 --> Controller Class Initialized
INFO - 2017-03-15 20:12:04 --> Helper loaded: url_helper
DEBUG - 2017-03-15 20:12:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 20:12:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 20:12:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 20:12:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 20:12:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 20:12:04 --> Final output sent to browser
DEBUG - 2017-03-15 20:12:04 --> Total execution time: 0.0144
INFO - 2017-03-15 20:12:18 --> Config Class Initialized
INFO - 2017-03-15 20:12:18 --> Hooks Class Initialized
DEBUG - 2017-03-15 20:12:18 --> UTF-8 Support Enabled
INFO - 2017-03-15 20:12:18 --> Utf8 Class Initialized
INFO - 2017-03-15 20:12:18 --> URI Class Initialized
INFO - 2017-03-15 20:12:18 --> Router Class Initialized
INFO - 2017-03-15 20:12:18 --> Output Class Initialized
INFO - 2017-03-15 20:12:18 --> Security Class Initialized
DEBUG - 2017-03-15 20:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 20:12:18 --> Input Class Initialized
INFO - 2017-03-15 20:12:18 --> Language Class Initialized
INFO - 2017-03-15 20:12:18 --> Loader Class Initialized
INFO - 2017-03-15 20:12:18 --> Database Driver Class Initialized
INFO - 2017-03-15 20:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 20:12:18 --> Controller Class Initialized
INFO - 2017-03-15 20:12:18 --> Helper loaded: url_helper
DEBUG - 2017-03-15 20:12:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-15 20:12:19 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-15 20:12:20 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jesús Iván')
INFO - 2017-03-15 20:12:20 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-15 20:12:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-15 20:12:20 --> Config Class Initialized
INFO - 2017-03-15 20:12:20 --> Hooks Class Initialized
DEBUG - 2017-03-15 20:12:20 --> UTF-8 Support Enabled
INFO - 2017-03-15 20:12:20 --> Utf8 Class Initialized
INFO - 2017-03-15 20:12:20 --> URI Class Initialized
INFO - 2017-03-15 20:12:20 --> Router Class Initialized
INFO - 2017-03-15 20:12:20 --> Output Class Initialized
INFO - 2017-03-15 20:12:20 --> Security Class Initialized
DEBUG - 2017-03-15 20:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 20:12:20 --> Input Class Initialized
INFO - 2017-03-15 20:12:20 --> Language Class Initialized
INFO - 2017-03-15 20:12:20 --> Loader Class Initialized
INFO - 2017-03-15 20:12:20 --> Database Driver Class Initialized
INFO - 2017-03-15 20:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 20:12:20 --> Controller Class Initialized
INFO - 2017-03-15 20:12:20 --> Helper loaded: url_helper
DEBUG - 2017-03-15 20:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 20:12:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 20:12:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 20:12:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 20:12:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 20:12:20 --> Final output sent to browser
DEBUG - 2017-03-15 20:12:20 --> Total execution time: 0.0138
INFO - 2017-03-15 20:12:26 --> Config Class Initialized
INFO - 2017-03-15 20:12:26 --> Hooks Class Initialized
DEBUG - 2017-03-15 20:12:26 --> UTF-8 Support Enabled
INFO - 2017-03-15 20:12:26 --> Utf8 Class Initialized
INFO - 2017-03-15 20:12:26 --> URI Class Initialized
INFO - 2017-03-15 20:12:26 --> Router Class Initialized
INFO - 2017-03-15 20:12:26 --> Output Class Initialized
INFO - 2017-03-15 20:12:26 --> Security Class Initialized
DEBUG - 2017-03-15 20:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 20:12:26 --> Input Class Initialized
INFO - 2017-03-15 20:12:26 --> Language Class Initialized
INFO - 2017-03-15 20:12:26 --> Loader Class Initialized
INFO - 2017-03-15 20:12:26 --> Database Driver Class Initialized
INFO - 2017-03-15 20:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 20:12:26 --> Controller Class Initialized
INFO - 2017-03-15 20:12:26 --> Helper loaded: url_helper
DEBUG - 2017-03-15 20:12:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-15 20:12:27 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-15 20:12:27 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jesús Iván')
INFO - 2017-03-15 20:12:27 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-15 20:12:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-15 20:12:32 --> Config Class Initialized
INFO - 2017-03-15 20:12:32 --> Hooks Class Initialized
DEBUG - 2017-03-15 20:12:32 --> UTF-8 Support Enabled
INFO - 2017-03-15 20:12:32 --> Utf8 Class Initialized
INFO - 2017-03-15 20:12:32 --> URI Class Initialized
INFO - 2017-03-15 20:12:32 --> Router Class Initialized
INFO - 2017-03-15 20:12:32 --> Output Class Initialized
INFO - 2017-03-15 20:12:32 --> Security Class Initialized
DEBUG - 2017-03-15 20:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 20:12:32 --> Input Class Initialized
INFO - 2017-03-15 20:12:32 --> Language Class Initialized
INFO - 2017-03-15 20:12:32 --> Loader Class Initialized
INFO - 2017-03-15 20:12:32 --> Database Driver Class Initialized
INFO - 2017-03-15 20:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 20:12:32 --> Controller Class Initialized
INFO - 2017-03-15 20:12:32 --> Helper loaded: url_helper
DEBUG - 2017-03-15 20:12:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 20:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 20:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 20:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 20:12:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 20:12:32 --> Final output sent to browser
DEBUG - 2017-03-15 20:12:32 --> Total execution time: 0.0135
INFO - 2017-03-15 20:12:34 --> Config Class Initialized
INFO - 2017-03-15 20:12:34 --> Hooks Class Initialized
DEBUG - 2017-03-15 20:12:34 --> UTF-8 Support Enabled
INFO - 2017-03-15 20:12:34 --> Utf8 Class Initialized
INFO - 2017-03-15 20:12:34 --> URI Class Initialized
DEBUG - 2017-03-15 20:12:34 --> No URI present. Default controller set.
INFO - 2017-03-15 20:12:34 --> Router Class Initialized
INFO - 2017-03-15 20:12:34 --> Output Class Initialized
INFO - 2017-03-15 20:12:34 --> Security Class Initialized
DEBUG - 2017-03-15 20:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 20:12:34 --> Input Class Initialized
INFO - 2017-03-15 20:12:34 --> Language Class Initialized
INFO - 2017-03-15 20:12:34 --> Loader Class Initialized
INFO - 2017-03-15 20:12:34 --> Database Driver Class Initialized
INFO - 2017-03-15 20:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 20:12:34 --> Controller Class Initialized
INFO - 2017-03-15 20:12:34 --> Helper loaded: url_helper
DEBUG - 2017-03-15 20:12:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 20:12:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 20:12:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 20:12:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 20:12:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 20:12:34 --> Final output sent to browser
DEBUG - 2017-03-15 20:12:34 --> Total execution time: 0.0139
INFO - 2017-03-15 20:12:37 --> Config Class Initialized
INFO - 2017-03-15 20:12:37 --> Hooks Class Initialized
DEBUG - 2017-03-15 20:12:37 --> UTF-8 Support Enabled
INFO - 2017-03-15 20:12:37 --> Utf8 Class Initialized
INFO - 2017-03-15 20:12:37 --> URI Class Initialized
INFO - 2017-03-15 20:12:37 --> Router Class Initialized
INFO - 2017-03-15 20:12:37 --> Output Class Initialized
INFO - 2017-03-15 20:12:37 --> Security Class Initialized
DEBUG - 2017-03-15 20:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 20:12:37 --> Input Class Initialized
INFO - 2017-03-15 20:12:37 --> Language Class Initialized
INFO - 2017-03-15 20:12:37 --> Loader Class Initialized
INFO - 2017-03-15 20:12:37 --> Database Driver Class Initialized
INFO - 2017-03-15 20:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 20:12:37 --> Controller Class Initialized
INFO - 2017-03-15 20:12:37 --> Helper loaded: url_helper
DEBUG - 2017-03-15 20:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 20:12:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 20:12:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 20:12:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 20:12:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 20:12:37 --> Final output sent to browser
DEBUG - 2017-03-15 20:12:37 --> Total execution time: 0.0149
INFO - 2017-03-15 20:12:55 --> Config Class Initialized
INFO - 2017-03-15 20:12:55 --> Hooks Class Initialized
DEBUG - 2017-03-15 20:12:55 --> UTF-8 Support Enabled
INFO - 2017-03-15 20:12:55 --> Utf8 Class Initialized
INFO - 2017-03-15 20:12:55 --> URI Class Initialized
INFO - 2017-03-15 20:12:55 --> Router Class Initialized
INFO - 2017-03-15 20:12:55 --> Output Class Initialized
INFO - 2017-03-15 20:12:55 --> Security Class Initialized
DEBUG - 2017-03-15 20:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 20:12:55 --> Input Class Initialized
INFO - 2017-03-15 20:12:55 --> Language Class Initialized
INFO - 2017-03-15 20:12:55 --> Loader Class Initialized
INFO - 2017-03-15 20:12:55 --> Database Driver Class Initialized
INFO - 2017-03-15 20:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 20:12:55 --> Controller Class Initialized
INFO - 2017-03-15 20:12:55 --> Helper loaded: url_helper
DEBUG - 2017-03-15 20:12:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-15 20:12:56 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-15 20:12:56 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jesús Iván')
INFO - 2017-03-15 20:12:56 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-15 20:12:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-15 20:12:56 --> Config Class Initialized
INFO - 2017-03-15 20:12:56 --> Hooks Class Initialized
DEBUG - 2017-03-15 20:12:56 --> UTF-8 Support Enabled
INFO - 2017-03-15 20:12:56 --> Utf8 Class Initialized
INFO - 2017-03-15 20:12:56 --> URI Class Initialized
INFO - 2017-03-15 20:12:56 --> Router Class Initialized
INFO - 2017-03-15 20:12:56 --> Output Class Initialized
INFO - 2017-03-15 20:12:56 --> Security Class Initialized
DEBUG - 2017-03-15 20:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 20:12:56 --> Input Class Initialized
INFO - 2017-03-15 20:12:56 --> Language Class Initialized
INFO - 2017-03-15 20:12:56 --> Loader Class Initialized
INFO - 2017-03-15 20:12:56 --> Database Driver Class Initialized
INFO - 2017-03-15 20:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 20:12:56 --> Controller Class Initialized
INFO - 2017-03-15 20:12:56 --> Helper loaded: url_helper
DEBUG - 2017-03-15 20:12:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 20:12:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 20:12:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 20:12:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 20:12:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 20:12:56 --> Final output sent to browser
DEBUG - 2017-03-15 20:12:56 --> Total execution time: 0.0145
INFO - 2017-03-15 22:02:24 --> Config Class Initialized
INFO - 2017-03-15 22:02:24 --> Hooks Class Initialized
DEBUG - 2017-03-15 22:02:25 --> UTF-8 Support Enabled
INFO - 2017-03-15 22:02:25 --> Utf8 Class Initialized
INFO - 2017-03-15 22:02:25 --> URI Class Initialized
INFO - 2017-03-15 22:02:25 --> Router Class Initialized
INFO - 2017-03-15 22:02:25 --> Output Class Initialized
INFO - 2017-03-15 22:02:25 --> Security Class Initialized
DEBUG - 2017-03-15 22:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 22:02:25 --> Input Class Initialized
INFO - 2017-03-15 22:02:25 --> Language Class Initialized
INFO - 2017-03-15 22:02:25 --> Loader Class Initialized
INFO - 2017-03-15 22:02:25 --> Database Driver Class Initialized
INFO - 2017-03-15 22:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 22:02:26 --> Controller Class Initialized
INFO - 2017-03-15 22:02:26 --> Helper loaded: date_helper
DEBUG - 2017-03-15 22:02:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 22:02:26 --> Helper loaded: url_helper
INFO - 2017-03-15 22:02:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 22:02:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 22:02:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 22:02:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 22:02:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 22:02:26 --> Final output sent to browser
DEBUG - 2017-03-15 22:02:26 --> Total execution time: 1.7011
INFO - 2017-03-15 22:02:28 --> Config Class Initialized
INFO - 2017-03-15 22:02:28 --> Hooks Class Initialized
DEBUG - 2017-03-15 22:02:28 --> UTF-8 Support Enabled
INFO - 2017-03-15 22:02:28 --> Utf8 Class Initialized
INFO - 2017-03-15 22:02:28 --> URI Class Initialized
INFO - 2017-03-15 22:02:28 --> Router Class Initialized
INFO - 2017-03-15 22:02:28 --> Output Class Initialized
INFO - 2017-03-15 22:02:28 --> Security Class Initialized
DEBUG - 2017-03-15 22:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 22:02:28 --> Input Class Initialized
INFO - 2017-03-15 22:02:28 --> Language Class Initialized
INFO - 2017-03-15 22:02:28 --> Loader Class Initialized
INFO - 2017-03-15 22:02:29 --> Database Driver Class Initialized
INFO - 2017-03-15 22:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 22:02:29 --> Controller Class Initialized
INFO - 2017-03-15 22:02:29 --> Helper loaded: url_helper
DEBUG - 2017-03-15 22:02:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 22:02:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 22:02:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 22:02:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 22:02:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 22:02:29 --> Final output sent to browser
DEBUG - 2017-03-15 22:02:29 --> Total execution time: 1.2599
INFO - 2017-03-15 22:03:26 --> Config Class Initialized
INFO - 2017-03-15 22:03:26 --> Hooks Class Initialized
DEBUG - 2017-03-15 22:03:26 --> UTF-8 Support Enabled
INFO - 2017-03-15 22:03:26 --> Utf8 Class Initialized
INFO - 2017-03-15 22:03:26 --> URI Class Initialized
INFO - 2017-03-15 22:03:27 --> Router Class Initialized
INFO - 2017-03-15 22:03:27 --> Output Class Initialized
INFO - 2017-03-15 22:03:27 --> Security Class Initialized
DEBUG - 2017-03-15 22:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 22:03:27 --> Input Class Initialized
INFO - 2017-03-15 22:03:27 --> Language Class Initialized
INFO - 2017-03-15 22:03:27 --> Loader Class Initialized
INFO - 2017-03-15 22:03:27 --> Database Driver Class Initialized
INFO - 2017-03-15 22:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 22:03:27 --> Controller Class Initialized
INFO - 2017-03-15 22:03:27 --> Helper loaded: date_helper
DEBUG - 2017-03-15 22:03:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 22:03:27 --> Helper loaded: url_helper
INFO - 2017-03-15 22:03:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 22:03:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 22:03:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 22:03:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 22:03:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 22:03:27 --> Final output sent to browser
DEBUG - 2017-03-15 22:03:27 --> Total execution time: 1.2371
INFO - 2017-03-15 22:03:30 --> Config Class Initialized
INFO - 2017-03-15 22:03:30 --> Hooks Class Initialized
DEBUG - 2017-03-15 22:03:30 --> UTF-8 Support Enabled
INFO - 2017-03-15 22:03:30 --> Utf8 Class Initialized
INFO - 2017-03-15 22:03:30 --> URI Class Initialized
INFO - 2017-03-15 22:03:30 --> Router Class Initialized
INFO - 2017-03-15 22:03:30 --> Output Class Initialized
INFO - 2017-03-15 22:03:30 --> Security Class Initialized
DEBUG - 2017-03-15 22:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 22:03:30 --> Input Class Initialized
INFO - 2017-03-15 22:03:30 --> Language Class Initialized
INFO - 2017-03-15 22:03:30 --> Loader Class Initialized
INFO - 2017-03-15 22:03:31 --> Database Driver Class Initialized
INFO - 2017-03-15 22:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 22:03:31 --> Controller Class Initialized
INFO - 2017-03-15 22:03:31 --> Helper loaded: url_helper
DEBUG - 2017-03-15 22:03:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 22:03:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 22:03:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 22:03:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 22:03:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 22:03:31 --> Final output sent to browser
DEBUG - 2017-03-15 22:03:31 --> Total execution time: 1.3129
INFO - 2017-03-15 22:51:14 --> Config Class Initialized
INFO - 2017-03-15 22:51:14 --> Hooks Class Initialized
DEBUG - 2017-03-15 22:51:14 --> UTF-8 Support Enabled
INFO - 2017-03-15 22:51:14 --> Utf8 Class Initialized
INFO - 2017-03-15 22:51:14 --> URI Class Initialized
DEBUG - 2017-03-15 22:51:14 --> No URI present. Default controller set.
INFO - 2017-03-15 22:51:14 --> Router Class Initialized
INFO - 2017-03-15 22:51:14 --> Output Class Initialized
INFO - 2017-03-15 22:51:14 --> Security Class Initialized
DEBUG - 2017-03-15 22:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 22:51:14 --> Input Class Initialized
INFO - 2017-03-15 22:51:14 --> Language Class Initialized
INFO - 2017-03-15 22:51:14 --> Loader Class Initialized
INFO - 2017-03-15 22:51:15 --> Database Driver Class Initialized
INFO - 2017-03-15 22:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 22:51:15 --> Controller Class Initialized
INFO - 2017-03-15 22:51:15 --> Helper loaded: url_helper
DEBUG - 2017-03-15 22:51:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 22:51:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 22:51:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 22:51:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 22:51:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 22:51:16 --> Final output sent to browser
DEBUG - 2017-03-15 22:51:16 --> Total execution time: 1.9509
INFO - 2017-03-15 22:51:23 --> Config Class Initialized
INFO - 2017-03-15 22:51:23 --> Hooks Class Initialized
DEBUG - 2017-03-15 22:51:23 --> UTF-8 Support Enabled
INFO - 2017-03-15 22:51:23 --> Utf8 Class Initialized
INFO - 2017-03-15 22:51:23 --> URI Class Initialized
INFO - 2017-03-15 22:51:23 --> Router Class Initialized
INFO - 2017-03-15 22:51:23 --> Output Class Initialized
INFO - 2017-03-15 22:51:23 --> Security Class Initialized
DEBUG - 2017-03-15 22:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 22:51:23 --> Input Class Initialized
INFO - 2017-03-15 22:51:23 --> Language Class Initialized
INFO - 2017-03-15 22:51:23 --> Loader Class Initialized
INFO - 2017-03-15 22:51:23 --> Database Driver Class Initialized
INFO - 2017-03-15 22:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 22:51:23 --> Controller Class Initialized
INFO - 2017-03-15 22:51:23 --> Helper loaded: url_helper
DEBUG - 2017-03-15 22:51:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 22:51:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 22:51:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 22:51:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 22:51:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 22:51:23 --> Final output sent to browser
DEBUG - 2017-03-15 22:51:23 --> Total execution time: 0.0291
INFO - 2017-03-15 22:51:27 --> Config Class Initialized
INFO - 2017-03-15 22:51:27 --> Hooks Class Initialized
DEBUG - 2017-03-15 22:51:27 --> UTF-8 Support Enabled
INFO - 2017-03-15 22:51:27 --> Utf8 Class Initialized
INFO - 2017-03-15 22:51:27 --> URI Class Initialized
INFO - 2017-03-15 22:51:27 --> Router Class Initialized
INFO - 2017-03-15 22:51:27 --> Output Class Initialized
INFO - 2017-03-15 22:51:27 --> Security Class Initialized
DEBUG - 2017-03-15 22:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 22:51:27 --> Input Class Initialized
INFO - 2017-03-15 22:51:27 --> Language Class Initialized
INFO - 2017-03-15 22:51:27 --> Loader Class Initialized
INFO - 2017-03-15 22:51:27 --> Database Driver Class Initialized
INFO - 2017-03-15 22:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 22:51:27 --> Controller Class Initialized
INFO - 2017-03-15 22:51:27 --> Helper loaded: url_helper
DEBUG - 2017-03-15 22:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 22:51:29 --> Config Class Initialized
INFO - 2017-03-15 22:51:29 --> Hooks Class Initialized
DEBUG - 2017-03-15 22:51:29 --> UTF-8 Support Enabled
INFO - 2017-03-15 22:51:29 --> Utf8 Class Initialized
INFO - 2017-03-15 22:51:29 --> URI Class Initialized
INFO - 2017-03-15 22:51:29 --> Router Class Initialized
INFO - 2017-03-15 22:51:29 --> Output Class Initialized
INFO - 2017-03-15 22:51:29 --> Security Class Initialized
DEBUG - 2017-03-15 22:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 22:51:29 --> Input Class Initialized
INFO - 2017-03-15 22:51:29 --> Language Class Initialized
INFO - 2017-03-15 22:51:29 --> Loader Class Initialized
INFO - 2017-03-15 22:51:29 --> Database Driver Class Initialized
INFO - 2017-03-15 22:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 22:51:29 --> Controller Class Initialized
INFO - 2017-03-15 22:51:29 --> Helper loaded: date_helper
DEBUG - 2017-03-15 22:51:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 22:51:29 --> Helper loaded: url_helper
INFO - 2017-03-15 22:51:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 22:51:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 22:51:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 22:51:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 22:51:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 22:51:29 --> Final output sent to browser
DEBUG - 2017-03-15 22:51:29 --> Total execution time: 0.0935
INFO - 2017-03-15 22:51:29 --> Config Class Initialized
INFO - 2017-03-15 22:51:29 --> Hooks Class Initialized
DEBUG - 2017-03-15 22:51:29 --> UTF-8 Support Enabled
INFO - 2017-03-15 22:51:29 --> Utf8 Class Initialized
INFO - 2017-03-15 22:51:29 --> URI Class Initialized
INFO - 2017-03-15 22:51:29 --> Router Class Initialized
INFO - 2017-03-15 22:51:29 --> Output Class Initialized
INFO - 2017-03-15 22:51:29 --> Security Class Initialized
DEBUG - 2017-03-15 22:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 22:51:29 --> Input Class Initialized
INFO - 2017-03-15 22:51:29 --> Language Class Initialized
INFO - 2017-03-15 22:51:29 --> Loader Class Initialized
INFO - 2017-03-15 22:51:29 --> Database Driver Class Initialized
INFO - 2017-03-15 22:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 22:51:29 --> Controller Class Initialized
INFO - 2017-03-15 22:51:29 --> Helper loaded: url_helper
DEBUG - 2017-03-15 22:51:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 22:51:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 22:51:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 22:51:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 22:51:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 22:51:29 --> Final output sent to browser
DEBUG - 2017-03-15 22:51:29 --> Total execution time: 0.0135
INFO - 2017-03-15 22:53:17 --> Config Class Initialized
INFO - 2017-03-15 22:53:17 --> Hooks Class Initialized
DEBUG - 2017-03-15 22:53:17 --> UTF-8 Support Enabled
INFO - 2017-03-15 22:53:17 --> Utf8 Class Initialized
INFO - 2017-03-15 22:53:17 --> URI Class Initialized
DEBUG - 2017-03-15 22:53:17 --> No URI present. Default controller set.
INFO - 2017-03-15 22:53:17 --> Router Class Initialized
INFO - 2017-03-15 22:53:17 --> Output Class Initialized
INFO - 2017-03-15 22:53:17 --> Security Class Initialized
DEBUG - 2017-03-15 22:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 22:53:17 --> Input Class Initialized
INFO - 2017-03-15 22:53:17 --> Language Class Initialized
INFO - 2017-03-15 22:53:18 --> Loader Class Initialized
INFO - 2017-03-15 22:53:18 --> Database Driver Class Initialized
INFO - 2017-03-15 22:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 22:53:18 --> Controller Class Initialized
INFO - 2017-03-15 22:53:18 --> Helper loaded: url_helper
DEBUG - 2017-03-15 22:53:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 22:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 22:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 22:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 22:53:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 22:53:18 --> Final output sent to browser
DEBUG - 2017-03-15 22:53:18 --> Total execution time: 1.2711
INFO - 2017-03-15 22:53:19 --> Config Class Initialized
INFO - 2017-03-15 22:53:19 --> Hooks Class Initialized
DEBUG - 2017-03-15 22:53:19 --> UTF-8 Support Enabled
INFO - 2017-03-15 22:53:19 --> Utf8 Class Initialized
INFO - 2017-03-15 22:53:19 --> URI Class Initialized
INFO - 2017-03-15 22:53:19 --> Router Class Initialized
INFO - 2017-03-15 22:53:19 --> Output Class Initialized
INFO - 2017-03-15 22:53:19 --> Security Class Initialized
DEBUG - 2017-03-15 22:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 22:53:19 --> Input Class Initialized
INFO - 2017-03-15 22:53:19 --> Language Class Initialized
INFO - 2017-03-15 22:53:19 --> Loader Class Initialized
INFO - 2017-03-15 22:53:19 --> Database Driver Class Initialized
INFO - 2017-03-15 22:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 22:53:19 --> Controller Class Initialized
INFO - 2017-03-15 22:53:19 --> Helper loaded: url_helper
DEBUG - 2017-03-15 22:53:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 22:53:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 22:53:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 22:53:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 22:53:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 22:53:19 --> Final output sent to browser
DEBUG - 2017-03-15 22:53:19 --> Total execution time: 0.0137
INFO - 2017-03-15 22:53:38 --> Config Class Initialized
INFO - 2017-03-15 22:53:38 --> Hooks Class Initialized
DEBUG - 2017-03-15 22:53:38 --> UTF-8 Support Enabled
INFO - 2017-03-15 22:53:38 --> Utf8 Class Initialized
INFO - 2017-03-15 22:53:38 --> URI Class Initialized
INFO - 2017-03-15 22:53:38 --> Router Class Initialized
INFO - 2017-03-15 22:53:38 --> Output Class Initialized
INFO - 2017-03-15 22:53:38 --> Security Class Initialized
DEBUG - 2017-03-15 22:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 22:53:38 --> Input Class Initialized
INFO - 2017-03-15 22:53:38 --> Language Class Initialized
INFO - 2017-03-15 22:53:38 --> Loader Class Initialized
INFO - 2017-03-15 22:53:38 --> Database Driver Class Initialized
INFO - 2017-03-15 22:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 22:53:38 --> Controller Class Initialized
INFO - 2017-03-15 22:53:38 --> Helper loaded: url_helper
DEBUG - 2017-03-15 22:53:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 22:53:39 --> Config Class Initialized
INFO - 2017-03-15 22:53:39 --> Hooks Class Initialized
DEBUG - 2017-03-15 22:53:39 --> UTF-8 Support Enabled
INFO - 2017-03-15 22:53:39 --> Utf8 Class Initialized
INFO - 2017-03-15 22:53:39 --> URI Class Initialized
INFO - 2017-03-15 22:53:39 --> Router Class Initialized
INFO - 2017-03-15 22:53:39 --> Output Class Initialized
INFO - 2017-03-15 22:53:39 --> Security Class Initialized
DEBUG - 2017-03-15 22:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 22:53:39 --> Input Class Initialized
INFO - 2017-03-15 22:53:39 --> Language Class Initialized
INFO - 2017-03-15 22:53:39 --> Loader Class Initialized
INFO - 2017-03-15 22:53:39 --> Database Driver Class Initialized
INFO - 2017-03-15 22:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 22:53:39 --> Controller Class Initialized
INFO - 2017-03-15 22:53:40 --> Helper loaded: date_helper
DEBUG - 2017-03-15 22:53:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 22:53:40 --> Helper loaded: url_helper
INFO - 2017-03-15 22:53:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 22:53:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 22:53:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 22:53:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 22:53:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 22:53:40 --> Final output sent to browser
DEBUG - 2017-03-15 22:53:40 --> Total execution time: 0.0846
INFO - 2017-03-15 22:53:40 --> Config Class Initialized
INFO - 2017-03-15 22:53:40 --> Hooks Class Initialized
DEBUG - 2017-03-15 22:53:40 --> UTF-8 Support Enabled
INFO - 2017-03-15 22:53:40 --> Utf8 Class Initialized
INFO - 2017-03-15 22:53:40 --> URI Class Initialized
INFO - 2017-03-15 22:53:40 --> Router Class Initialized
INFO - 2017-03-15 22:53:40 --> Output Class Initialized
INFO - 2017-03-15 22:53:40 --> Security Class Initialized
DEBUG - 2017-03-15 22:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 22:53:40 --> Input Class Initialized
INFO - 2017-03-15 22:53:40 --> Language Class Initialized
INFO - 2017-03-15 22:53:40 --> Loader Class Initialized
INFO - 2017-03-15 22:53:40 --> Database Driver Class Initialized
INFO - 2017-03-15 22:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 22:53:40 --> Controller Class Initialized
INFO - 2017-03-15 22:53:40 --> Helper loaded: url_helper
DEBUG - 2017-03-15 22:53:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 22:53:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 22:53:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 22:53:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 22:53:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 22:53:40 --> Final output sent to browser
DEBUG - 2017-03-15 22:53:40 --> Total execution time: 0.0128
INFO - 2017-03-15 23:02:34 --> Config Class Initialized
INFO - 2017-03-15 23:02:34 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:02:34 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:02:34 --> Utf8 Class Initialized
INFO - 2017-03-15 23:02:34 --> URI Class Initialized
DEBUG - 2017-03-15 23:02:35 --> No URI present. Default controller set.
INFO - 2017-03-15 23:02:35 --> Router Class Initialized
INFO - 2017-03-15 23:02:35 --> Output Class Initialized
INFO - 2017-03-15 23:02:35 --> Security Class Initialized
DEBUG - 2017-03-15 23:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:02:35 --> Input Class Initialized
INFO - 2017-03-15 23:02:35 --> Language Class Initialized
INFO - 2017-03-15 23:02:35 --> Loader Class Initialized
INFO - 2017-03-15 23:02:35 --> Database Driver Class Initialized
INFO - 2017-03-15 23:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:02:36 --> Controller Class Initialized
INFO - 2017-03-15 23:02:36 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:02:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:02:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:02:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:02:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:02:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:02:36 --> Final output sent to browser
DEBUG - 2017-03-15 23:02:36 --> Total execution time: 1.8580
INFO - 2017-03-15 23:02:57 --> Config Class Initialized
INFO - 2017-03-15 23:02:57 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:02:57 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:02:57 --> Utf8 Class Initialized
INFO - 2017-03-15 23:02:57 --> URI Class Initialized
INFO - 2017-03-15 23:02:57 --> Router Class Initialized
INFO - 2017-03-15 23:02:57 --> Output Class Initialized
INFO - 2017-03-15 23:02:57 --> Security Class Initialized
DEBUG - 2017-03-15 23:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:02:57 --> Input Class Initialized
INFO - 2017-03-15 23:02:57 --> Language Class Initialized
INFO - 2017-03-15 23:02:57 --> Loader Class Initialized
INFO - 2017-03-15 23:02:57 --> Database Driver Class Initialized
INFO - 2017-03-15 23:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:02:57 --> Controller Class Initialized
INFO - 2017-03-15 23:02:57 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:02:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:02:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:02:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:02:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:02:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:02:57 --> Final output sent to browser
DEBUG - 2017-03-15 23:02:57 --> Total execution time: 0.0131
INFO - 2017-03-15 23:03:00 --> Config Class Initialized
INFO - 2017-03-15 23:03:00 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:03:00 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:03:00 --> Utf8 Class Initialized
INFO - 2017-03-15 23:03:00 --> URI Class Initialized
INFO - 2017-03-15 23:03:00 --> Router Class Initialized
INFO - 2017-03-15 23:03:00 --> Output Class Initialized
INFO - 2017-03-15 23:03:00 --> Security Class Initialized
DEBUG - 2017-03-15 23:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:03:00 --> Input Class Initialized
INFO - 2017-03-15 23:03:00 --> Language Class Initialized
INFO - 2017-03-15 23:03:00 --> Loader Class Initialized
INFO - 2017-03-15 23:03:00 --> Database Driver Class Initialized
INFO - 2017-03-15 23:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:03:00 --> Controller Class Initialized
INFO - 2017-03-15 23:03:00 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:03:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:03:02 --> Config Class Initialized
INFO - 2017-03-15 23:03:02 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:03:02 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:03:02 --> Utf8 Class Initialized
INFO - 2017-03-15 23:03:02 --> URI Class Initialized
INFO - 2017-03-15 23:03:02 --> Router Class Initialized
INFO - 2017-03-15 23:03:02 --> Output Class Initialized
INFO - 2017-03-15 23:03:02 --> Security Class Initialized
DEBUG - 2017-03-15 23:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:03:02 --> Input Class Initialized
INFO - 2017-03-15 23:03:02 --> Language Class Initialized
INFO - 2017-03-15 23:03:02 --> Loader Class Initialized
INFO - 2017-03-15 23:03:02 --> Database Driver Class Initialized
INFO - 2017-03-15 23:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:03:02 --> Controller Class Initialized
INFO - 2017-03-15 23:03:02 --> Helper loaded: date_helper
DEBUG - 2017-03-15 23:03:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:03:06 --> Helper loaded: url_helper
INFO - 2017-03-15 23:03:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:03:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 23:03:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 23:03:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 23:03:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:03:06 --> Final output sent to browser
DEBUG - 2017-03-15 23:03:06 --> Total execution time: 4.1067
INFO - 2017-03-15 23:03:06 --> Config Class Initialized
INFO - 2017-03-15 23:03:06 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:03:06 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:03:06 --> Utf8 Class Initialized
INFO - 2017-03-15 23:03:06 --> URI Class Initialized
INFO - 2017-03-15 23:03:06 --> Router Class Initialized
INFO - 2017-03-15 23:03:06 --> Output Class Initialized
INFO - 2017-03-15 23:03:06 --> Security Class Initialized
DEBUG - 2017-03-15 23:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:03:06 --> Input Class Initialized
INFO - 2017-03-15 23:03:06 --> Language Class Initialized
INFO - 2017-03-15 23:03:06 --> Loader Class Initialized
INFO - 2017-03-15 23:03:06 --> Config Class Initialized
INFO - 2017-03-15 23:03:06 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:03:06 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:03:06 --> Utf8 Class Initialized
INFO - 2017-03-15 23:03:06 --> URI Class Initialized
INFO - 2017-03-15 23:03:06 --> Router Class Initialized
INFO - 2017-03-15 23:03:06 --> Output Class Initialized
INFO - 2017-03-15 23:03:06 --> Security Class Initialized
DEBUG - 2017-03-15 23:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:03:06 --> Input Class Initialized
INFO - 2017-03-15 23:03:06 --> Language Class Initialized
INFO - 2017-03-15 23:03:06 --> Database Driver Class Initialized
INFO - 2017-03-15 23:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:03:06 --> Controller Class Initialized
INFO - 2017-03-15 23:03:06 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:03:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:03:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:03:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:03:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:03:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:03:06 --> Final output sent to browser
DEBUG - 2017-03-15 23:03:06 --> Total execution time: 0.0270
INFO - 2017-03-15 23:03:06 --> Loader Class Initialized
INFO - 2017-03-15 23:03:06 --> Database Driver Class Initialized
INFO - 2017-03-15 23:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:03:06 --> Controller Class Initialized
INFO - 2017-03-15 23:03:06 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:03:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:03:07 --> Config Class Initialized
INFO - 2017-03-15 23:03:07 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:03:07 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:03:07 --> Utf8 Class Initialized
INFO - 2017-03-15 23:03:07 --> URI Class Initialized
INFO - 2017-03-15 23:03:07 --> Router Class Initialized
INFO - 2017-03-15 23:03:07 --> Output Class Initialized
INFO - 2017-03-15 23:03:07 --> Security Class Initialized
DEBUG - 2017-03-15 23:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:03:07 --> Input Class Initialized
INFO - 2017-03-15 23:03:07 --> Language Class Initialized
INFO - 2017-03-15 23:03:07 --> Loader Class Initialized
INFO - 2017-03-15 23:03:07 --> Database Driver Class Initialized
INFO - 2017-03-15 23:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:03:07 --> Controller Class Initialized
INFO - 2017-03-15 23:03:07 --> Helper loaded: date_helper
DEBUG - 2017-03-15 23:03:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:03:07 --> Helper loaded: url_helper
INFO - 2017-03-15 23:03:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:03:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 23:03:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 23:03:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 23:03:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:03:07 --> Final output sent to browser
DEBUG - 2017-03-15 23:03:07 --> Total execution time: 0.0807
INFO - 2017-03-15 23:03:08 --> Config Class Initialized
INFO - 2017-03-15 23:03:08 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:03:08 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:03:08 --> Utf8 Class Initialized
INFO - 2017-03-15 23:03:08 --> URI Class Initialized
INFO - 2017-03-15 23:03:08 --> Router Class Initialized
INFO - 2017-03-15 23:03:08 --> Output Class Initialized
INFO - 2017-03-15 23:03:08 --> Security Class Initialized
DEBUG - 2017-03-15 23:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:03:08 --> Input Class Initialized
INFO - 2017-03-15 23:03:08 --> Language Class Initialized
INFO - 2017-03-15 23:03:08 --> Loader Class Initialized
INFO - 2017-03-15 23:03:08 --> Database Driver Class Initialized
INFO - 2017-03-15 23:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:03:08 --> Controller Class Initialized
INFO - 2017-03-15 23:03:08 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:03:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:03:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:03:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:03:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:03:08 --> Final output sent to browser
DEBUG - 2017-03-15 23:03:08 --> Total execution time: 0.0136
INFO - 2017-03-15 23:03:10 --> Config Class Initialized
INFO - 2017-03-15 23:03:10 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:03:10 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:03:10 --> Utf8 Class Initialized
INFO - 2017-03-15 23:03:10 --> URI Class Initialized
DEBUG - 2017-03-15 23:03:10 --> No URI present. Default controller set.
INFO - 2017-03-15 23:03:10 --> Router Class Initialized
INFO - 2017-03-15 23:03:10 --> Output Class Initialized
INFO - 2017-03-15 23:03:10 --> Security Class Initialized
DEBUG - 2017-03-15 23:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:03:10 --> Input Class Initialized
INFO - 2017-03-15 23:03:10 --> Language Class Initialized
INFO - 2017-03-15 23:03:10 --> Loader Class Initialized
INFO - 2017-03-15 23:03:10 --> Database Driver Class Initialized
INFO - 2017-03-15 23:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:03:10 --> Controller Class Initialized
INFO - 2017-03-15 23:03:10 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:03:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:03:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:03:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:03:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:03:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:03:10 --> Final output sent to browser
DEBUG - 2017-03-15 23:03:10 --> Total execution time: 0.0130
INFO - 2017-03-15 23:03:10 --> Config Class Initialized
INFO - 2017-03-15 23:03:10 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:03:10 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:03:10 --> Utf8 Class Initialized
INFO - 2017-03-15 23:03:10 --> URI Class Initialized
INFO - 2017-03-15 23:03:10 --> Router Class Initialized
INFO - 2017-03-15 23:03:10 --> Output Class Initialized
INFO - 2017-03-15 23:03:10 --> Security Class Initialized
DEBUG - 2017-03-15 23:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:03:10 --> Input Class Initialized
INFO - 2017-03-15 23:03:10 --> Language Class Initialized
INFO - 2017-03-15 23:03:10 --> Loader Class Initialized
INFO - 2017-03-15 23:03:10 --> Database Driver Class Initialized
INFO - 2017-03-15 23:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:03:10 --> Controller Class Initialized
INFO - 2017-03-15 23:03:10 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:03:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:03:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:03:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:03:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:03:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:03:10 --> Final output sent to browser
DEBUG - 2017-03-15 23:03:10 --> Total execution time: 0.0131
INFO - 2017-03-15 23:42:11 --> Config Class Initialized
INFO - 2017-03-15 23:42:11 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:42:11 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:42:11 --> Utf8 Class Initialized
INFO - 2017-03-15 23:42:11 --> URI Class Initialized
INFO - 2017-03-15 23:42:11 --> Router Class Initialized
INFO - 2017-03-15 23:42:11 --> Output Class Initialized
INFO - 2017-03-15 23:42:11 --> Security Class Initialized
DEBUG - 2017-03-15 23:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:42:11 --> Input Class Initialized
INFO - 2017-03-15 23:42:11 --> Language Class Initialized
INFO - 2017-03-15 23:42:11 --> Loader Class Initialized
INFO - 2017-03-15 23:42:11 --> Database Driver Class Initialized
INFO - 2017-03-15 23:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:42:12 --> Controller Class Initialized
INFO - 2017-03-15 23:42:12 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:42:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:42:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:42:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:42:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:42:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:42:12 --> Final output sent to browser
DEBUG - 2017-03-15 23:42:12 --> Total execution time: 0.3850
INFO - 2017-03-15 23:43:15 --> Config Class Initialized
INFO - 2017-03-15 23:43:15 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:43:15 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:43:15 --> Utf8 Class Initialized
INFO - 2017-03-15 23:43:15 --> URI Class Initialized
INFO - 2017-03-15 23:43:15 --> Router Class Initialized
INFO - 2017-03-15 23:43:15 --> Output Class Initialized
INFO - 2017-03-15 23:43:15 --> Security Class Initialized
DEBUG - 2017-03-15 23:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:43:15 --> Input Class Initialized
INFO - 2017-03-15 23:43:15 --> Language Class Initialized
INFO - 2017-03-15 23:43:15 --> Loader Class Initialized
INFO - 2017-03-15 23:43:16 --> Database Driver Class Initialized
INFO - 2017-03-15 23:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:43:16 --> Controller Class Initialized
INFO - 2017-03-15 23:43:16 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:43:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-15 23:43:17 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-15 23:43:17 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-15 23:43:17 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-15 23:43:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:43:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:43:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:43:17 --> Final output sent to browser
DEBUG - 2017-03-15 23:43:17 --> Total execution time: 2.0903
INFO - 2017-03-15 23:43:19 --> Config Class Initialized
INFO - 2017-03-15 23:43:19 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:43:19 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:43:19 --> Utf8 Class Initialized
INFO - 2017-03-15 23:43:19 --> URI Class Initialized
DEBUG - 2017-03-15 23:43:19 --> No URI present. Default controller set.
INFO - 2017-03-15 23:43:19 --> Router Class Initialized
INFO - 2017-03-15 23:43:19 --> Output Class Initialized
INFO - 2017-03-15 23:43:19 --> Security Class Initialized
DEBUG - 2017-03-15 23:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:43:19 --> Input Class Initialized
INFO - 2017-03-15 23:43:19 --> Language Class Initialized
INFO - 2017-03-15 23:43:19 --> Loader Class Initialized
INFO - 2017-03-15 23:43:19 --> Database Driver Class Initialized
INFO - 2017-03-15 23:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:43:19 --> Controller Class Initialized
INFO - 2017-03-15 23:43:19 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:43:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:43:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:43:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:43:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:43:19 --> Final output sent to browser
DEBUG - 2017-03-15 23:43:19 --> Total execution time: 0.0295
INFO - 2017-03-15 23:43:23 --> Config Class Initialized
INFO - 2017-03-15 23:43:23 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:43:23 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:43:23 --> Utf8 Class Initialized
INFO - 2017-03-15 23:43:23 --> URI Class Initialized
INFO - 2017-03-15 23:43:23 --> Router Class Initialized
INFO - 2017-03-15 23:43:23 --> Output Class Initialized
INFO - 2017-03-15 23:43:23 --> Security Class Initialized
DEBUG - 2017-03-15 23:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:43:23 --> Input Class Initialized
INFO - 2017-03-15 23:43:23 --> Language Class Initialized
INFO - 2017-03-15 23:43:23 --> Loader Class Initialized
INFO - 2017-03-15 23:43:23 --> Database Driver Class Initialized
INFO - 2017-03-15 23:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:43:23 --> Controller Class Initialized
INFO - 2017-03-15 23:43:23 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:43:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:43:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:43:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:43:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:43:23 --> Final output sent to browser
DEBUG - 2017-03-15 23:43:23 --> Total execution time: 0.0140
INFO - 2017-03-15 23:43:36 --> Config Class Initialized
INFO - 2017-03-15 23:43:36 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:43:36 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:43:36 --> Utf8 Class Initialized
INFO - 2017-03-15 23:43:36 --> URI Class Initialized
INFO - 2017-03-15 23:43:36 --> Router Class Initialized
INFO - 2017-03-15 23:43:36 --> Output Class Initialized
INFO - 2017-03-15 23:43:36 --> Security Class Initialized
DEBUG - 2017-03-15 23:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:43:36 --> Input Class Initialized
INFO - 2017-03-15 23:43:36 --> Language Class Initialized
INFO - 2017-03-15 23:43:36 --> Loader Class Initialized
INFO - 2017-03-15 23:43:36 --> Database Driver Class Initialized
INFO - 2017-03-15 23:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:43:36 --> Controller Class Initialized
INFO - 2017-03-15 23:43:36 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:43:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-15 23:43:37 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-15 23:43:37 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jesús Iván')
INFO - 2017-03-15 23:43:37 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-15 23:43:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-15 23:43:38 --> Config Class Initialized
INFO - 2017-03-15 23:43:38 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:43:38 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:43:38 --> Utf8 Class Initialized
INFO - 2017-03-15 23:43:38 --> URI Class Initialized
INFO - 2017-03-15 23:43:38 --> Router Class Initialized
INFO - 2017-03-15 23:43:38 --> Output Class Initialized
INFO - 2017-03-15 23:43:38 --> Security Class Initialized
DEBUG - 2017-03-15 23:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:43:38 --> Input Class Initialized
INFO - 2017-03-15 23:43:38 --> Language Class Initialized
INFO - 2017-03-15 23:43:38 --> Loader Class Initialized
INFO - 2017-03-15 23:43:38 --> Database Driver Class Initialized
INFO - 2017-03-15 23:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:43:38 --> Controller Class Initialized
INFO - 2017-03-15 23:43:38 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:43:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:43:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:43:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:43:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:43:38 --> Final output sent to browser
DEBUG - 2017-03-15 23:43:38 --> Total execution time: 0.0138
INFO - 2017-03-15 23:43:41 --> Config Class Initialized
INFO - 2017-03-15 23:43:41 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:43:41 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:43:41 --> Utf8 Class Initialized
INFO - 2017-03-15 23:43:41 --> URI Class Initialized
DEBUG - 2017-03-15 23:43:41 --> No URI present. Default controller set.
INFO - 2017-03-15 23:43:41 --> Router Class Initialized
INFO - 2017-03-15 23:43:41 --> Output Class Initialized
INFO - 2017-03-15 23:43:41 --> Security Class Initialized
DEBUG - 2017-03-15 23:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:43:41 --> Input Class Initialized
INFO - 2017-03-15 23:43:41 --> Language Class Initialized
INFO - 2017-03-15 23:43:41 --> Loader Class Initialized
INFO - 2017-03-15 23:43:41 --> Database Driver Class Initialized
INFO - 2017-03-15 23:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:43:41 --> Controller Class Initialized
INFO - 2017-03-15 23:43:41 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:43:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:43:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:43:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:43:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:43:41 --> Final output sent to browser
DEBUG - 2017-03-15 23:43:41 --> Total execution time: 0.0130
INFO - 2017-03-15 23:43:43 --> Config Class Initialized
INFO - 2017-03-15 23:43:43 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:43:43 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:43:43 --> Utf8 Class Initialized
INFO - 2017-03-15 23:43:43 --> URI Class Initialized
INFO - 2017-03-15 23:43:43 --> Router Class Initialized
INFO - 2017-03-15 23:43:43 --> Output Class Initialized
INFO - 2017-03-15 23:43:43 --> Security Class Initialized
DEBUG - 2017-03-15 23:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:43:43 --> Input Class Initialized
INFO - 2017-03-15 23:43:43 --> Language Class Initialized
INFO - 2017-03-15 23:43:43 --> Loader Class Initialized
INFO - 2017-03-15 23:43:43 --> Database Driver Class Initialized
INFO - 2017-03-15 23:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:43:43 --> Controller Class Initialized
INFO - 2017-03-15 23:43:43 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:43:43 --> Final output sent to browser
DEBUG - 2017-03-15 23:43:43 --> Total execution time: 0.0485
INFO - 2017-03-15 23:44:00 --> Config Class Initialized
INFO - 2017-03-15 23:44:00 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:44:00 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:44:00 --> Utf8 Class Initialized
INFO - 2017-03-15 23:44:00 --> URI Class Initialized
INFO - 2017-03-15 23:44:00 --> Router Class Initialized
INFO - 2017-03-15 23:44:00 --> Output Class Initialized
INFO - 2017-03-15 23:44:00 --> Security Class Initialized
DEBUG - 2017-03-15 23:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:44:00 --> Input Class Initialized
INFO - 2017-03-15 23:44:00 --> Language Class Initialized
INFO - 2017-03-15 23:44:00 --> Loader Class Initialized
INFO - 2017-03-15 23:44:01 --> Database Driver Class Initialized
INFO - 2017-03-15 23:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:44:01 --> Controller Class Initialized
INFO - 2017-03-15 23:44:01 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:44:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-15 23:44:03 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-15 23:44:03 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jesús Iván')
INFO - 2017-03-15 23:44:03 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-15 23:44:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-15 23:44:05 --> Config Class Initialized
INFO - 2017-03-15 23:44:05 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:44:05 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:44:05 --> Utf8 Class Initialized
INFO - 2017-03-15 23:44:05 --> URI Class Initialized
INFO - 2017-03-15 23:44:05 --> Router Class Initialized
INFO - 2017-03-15 23:44:05 --> Output Class Initialized
INFO - 2017-03-15 23:44:05 --> Security Class Initialized
DEBUG - 2017-03-15 23:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:44:05 --> Input Class Initialized
INFO - 2017-03-15 23:44:05 --> Language Class Initialized
INFO - 2017-03-15 23:44:05 --> Loader Class Initialized
INFO - 2017-03-15 23:44:05 --> Database Driver Class Initialized
INFO - 2017-03-15 23:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:44:06 --> Controller Class Initialized
INFO - 2017-03-15 23:44:06 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:44:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:44:06 --> Final output sent to browser
DEBUG - 2017-03-15 23:44:06 --> Total execution time: 1.3337
INFO - 2017-03-15 23:47:36 --> Config Class Initialized
INFO - 2017-03-15 23:47:36 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:47:36 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:47:36 --> Utf8 Class Initialized
INFO - 2017-03-15 23:47:36 --> URI Class Initialized
DEBUG - 2017-03-15 23:47:36 --> No URI present. Default controller set.
INFO - 2017-03-15 23:47:36 --> Router Class Initialized
INFO - 2017-03-15 23:47:36 --> Output Class Initialized
INFO - 2017-03-15 23:47:36 --> Security Class Initialized
DEBUG - 2017-03-15 23:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:47:36 --> Input Class Initialized
INFO - 2017-03-15 23:47:36 --> Language Class Initialized
INFO - 2017-03-15 23:47:36 --> Loader Class Initialized
INFO - 2017-03-15 23:47:37 --> Database Driver Class Initialized
INFO - 2017-03-15 23:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:47:37 --> Controller Class Initialized
INFO - 2017-03-15 23:47:37 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:47:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:47:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:47:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:47:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:47:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:47:37 --> Final output sent to browser
DEBUG - 2017-03-15 23:47:37 --> Total execution time: 1.4824
INFO - 2017-03-15 23:47:43 --> Config Class Initialized
INFO - 2017-03-15 23:47:43 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:47:43 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:47:43 --> Utf8 Class Initialized
INFO - 2017-03-15 23:47:43 --> URI Class Initialized
INFO - 2017-03-15 23:47:43 --> Router Class Initialized
INFO - 2017-03-15 23:47:43 --> Output Class Initialized
INFO - 2017-03-15 23:47:43 --> Security Class Initialized
DEBUG - 2017-03-15 23:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:47:43 --> Input Class Initialized
INFO - 2017-03-15 23:47:43 --> Language Class Initialized
INFO - 2017-03-15 23:47:43 --> Loader Class Initialized
INFO - 2017-03-15 23:47:43 --> Database Driver Class Initialized
INFO - 2017-03-15 23:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:47:43 --> Controller Class Initialized
INFO - 2017-03-15 23:47:43 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:47:44 --> Final output sent to browser
DEBUG - 2017-03-15 23:47:44 --> Total execution time: 1.2789
INFO - 2017-03-15 23:47:53 --> Config Class Initialized
INFO - 2017-03-15 23:47:53 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:47:53 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:47:53 --> Utf8 Class Initialized
INFO - 2017-03-15 23:47:53 --> URI Class Initialized
DEBUG - 2017-03-15 23:47:53 --> No URI present. Default controller set.
INFO - 2017-03-15 23:47:53 --> Router Class Initialized
INFO - 2017-03-15 23:47:53 --> Output Class Initialized
INFO - 2017-03-15 23:47:53 --> Security Class Initialized
DEBUG - 2017-03-15 23:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:47:53 --> Input Class Initialized
INFO - 2017-03-15 23:47:53 --> Language Class Initialized
INFO - 2017-03-15 23:47:53 --> Loader Class Initialized
INFO - 2017-03-15 23:47:53 --> Database Driver Class Initialized
INFO - 2017-03-15 23:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:47:54 --> Controller Class Initialized
INFO - 2017-03-15 23:47:54 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:47:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:47:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:47:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:47:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:47:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:47:54 --> Final output sent to browser
DEBUG - 2017-03-15 23:47:54 --> Total execution time: 1.4460
INFO - 2017-03-15 23:47:54 --> Config Class Initialized
INFO - 2017-03-15 23:47:54 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:47:54 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:47:54 --> Utf8 Class Initialized
INFO - 2017-03-15 23:47:54 --> URI Class Initialized
DEBUG - 2017-03-15 23:47:54 --> No URI present. Default controller set.
INFO - 2017-03-15 23:47:54 --> Router Class Initialized
INFO - 2017-03-15 23:47:54 --> Output Class Initialized
INFO - 2017-03-15 23:47:54 --> Security Class Initialized
DEBUG - 2017-03-15 23:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:47:54 --> Input Class Initialized
INFO - 2017-03-15 23:47:54 --> Language Class Initialized
INFO - 2017-03-15 23:47:54 --> Loader Class Initialized
INFO - 2017-03-15 23:47:54 --> Database Driver Class Initialized
INFO - 2017-03-15 23:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:47:54 --> Controller Class Initialized
INFO - 2017-03-15 23:47:54 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:47:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:47:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:47:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:47:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:47:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:47:54 --> Final output sent to browser
DEBUG - 2017-03-15 23:47:54 --> Total execution time: 0.0134
INFO - 2017-03-15 23:48:01 --> Config Class Initialized
INFO - 2017-03-15 23:48:01 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:48:01 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:48:01 --> Utf8 Class Initialized
INFO - 2017-03-15 23:48:01 --> URI Class Initialized
INFO - 2017-03-15 23:48:01 --> Router Class Initialized
INFO - 2017-03-15 23:48:01 --> Output Class Initialized
INFO - 2017-03-15 23:48:01 --> Security Class Initialized
DEBUG - 2017-03-15 23:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:48:01 --> Input Class Initialized
INFO - 2017-03-15 23:48:01 --> Language Class Initialized
INFO - 2017-03-15 23:48:01 --> Loader Class Initialized
INFO - 2017-03-15 23:48:01 --> Database Driver Class Initialized
INFO - 2017-03-15 23:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:48:01 --> Controller Class Initialized
INFO - 2017-03-15 23:48:01 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:48:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:48:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-15 23:48:01 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-15 23:48:01 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-15 23:48:01 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-15 23:48:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:48:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:48:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:48:01 --> Final output sent to browser
DEBUG - 2017-03-15 23:48:01 --> Total execution time: 0.0791
INFO - 2017-03-15 23:48:03 --> Config Class Initialized
INFO - 2017-03-15 23:48:03 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:48:03 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:48:03 --> Utf8 Class Initialized
INFO - 2017-03-15 23:48:03 --> URI Class Initialized
INFO - 2017-03-15 23:48:03 --> Router Class Initialized
INFO - 2017-03-15 23:48:03 --> Output Class Initialized
INFO - 2017-03-15 23:48:03 --> Security Class Initialized
DEBUG - 2017-03-15 23:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:48:04 --> Input Class Initialized
INFO - 2017-03-15 23:48:04 --> Language Class Initialized
INFO - 2017-03-15 23:48:04 --> Loader Class Initialized
INFO - 2017-03-15 23:48:04 --> Database Driver Class Initialized
INFO - 2017-03-15 23:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:48:04 --> Controller Class Initialized
INFO - 2017-03-15 23:48:04 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:48:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:48:04 --> Final output sent to browser
DEBUG - 2017-03-15 23:48:04 --> Total execution time: 1.2142
INFO - 2017-03-15 23:48:12 --> Config Class Initialized
INFO - 2017-03-15 23:48:12 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:48:12 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:48:12 --> Utf8 Class Initialized
INFO - 2017-03-15 23:48:12 --> URI Class Initialized
INFO - 2017-03-15 23:48:12 --> Router Class Initialized
INFO - 2017-03-15 23:48:12 --> Output Class Initialized
INFO - 2017-03-15 23:48:12 --> Security Class Initialized
DEBUG - 2017-03-15 23:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:48:12 --> Input Class Initialized
INFO - 2017-03-15 23:48:12 --> Language Class Initialized
INFO - 2017-03-15 23:48:12 --> Loader Class Initialized
INFO - 2017-03-15 23:48:12 --> Database Driver Class Initialized
INFO - 2017-03-15 23:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:48:12 --> Controller Class Initialized
INFO - 2017-03-15 23:48:12 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:48:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-15 23:48:12 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-15 23:48:12 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-15 23:48:12 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-15 23:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:48:12 --> Final output sent to browser
DEBUG - 2017-03-15 23:48:12 --> Total execution time: 0.2625
INFO - 2017-03-15 23:48:12 --> Config Class Initialized
INFO - 2017-03-15 23:48:12 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:48:12 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:48:12 --> Utf8 Class Initialized
INFO - 2017-03-15 23:48:12 --> URI Class Initialized
INFO - 2017-03-15 23:48:12 --> Router Class Initialized
INFO - 2017-03-15 23:48:12 --> Output Class Initialized
INFO - 2017-03-15 23:48:12 --> Security Class Initialized
DEBUG - 2017-03-15 23:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:48:12 --> Input Class Initialized
INFO - 2017-03-15 23:48:12 --> Language Class Initialized
INFO - 2017-03-15 23:48:12 --> Loader Class Initialized
INFO - 2017-03-15 23:48:12 --> Database Driver Class Initialized
INFO - 2017-03-15 23:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:48:12 --> Controller Class Initialized
INFO - 2017-03-15 23:48:12 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:48:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-15 23:48:12 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-15 23:48:12 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-15 23:48:12 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-15 23:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:48:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:48:12 --> Final output sent to browser
DEBUG - 2017-03-15 23:48:12 --> Total execution time: 0.0372
INFO - 2017-03-15 23:49:10 --> Config Class Initialized
INFO - 2017-03-15 23:49:10 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:49:10 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:49:10 --> Utf8 Class Initialized
INFO - 2017-03-15 23:49:10 --> URI Class Initialized
INFO - 2017-03-15 23:49:10 --> Router Class Initialized
INFO - 2017-03-15 23:49:11 --> Output Class Initialized
INFO - 2017-03-15 23:49:11 --> Security Class Initialized
DEBUG - 2017-03-15 23:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:49:11 --> Input Class Initialized
INFO - 2017-03-15 23:49:11 --> Language Class Initialized
INFO - 2017-03-15 23:49:11 --> Loader Class Initialized
INFO - 2017-03-15 23:49:11 --> Database Driver Class Initialized
INFO - 2017-03-15 23:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:49:11 --> Controller Class Initialized
INFO - 2017-03-15 23:49:11 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:49:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-15 23:49:13 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-15 23:49:13 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jesús Iván')
INFO - 2017-03-15 23:49:13 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-15 23:49:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-15 23:49:14 --> Config Class Initialized
INFO - 2017-03-15 23:49:14 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:49:14 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:49:14 --> Utf8 Class Initialized
INFO - 2017-03-15 23:49:14 --> URI Class Initialized
INFO - 2017-03-15 23:49:14 --> Router Class Initialized
INFO - 2017-03-15 23:49:14 --> Output Class Initialized
INFO - 2017-03-15 23:49:14 --> Security Class Initialized
DEBUG - 2017-03-15 23:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:49:14 --> Input Class Initialized
INFO - 2017-03-15 23:49:14 --> Language Class Initialized
INFO - 2017-03-15 23:49:14 --> Loader Class Initialized
INFO - 2017-03-15 23:49:14 --> Database Driver Class Initialized
INFO - 2017-03-15 23:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:49:14 --> Controller Class Initialized
INFO - 2017-03-15 23:49:14 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:49:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:49:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:49:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:49:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:49:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:49:14 --> Final output sent to browser
DEBUG - 2017-03-15 23:49:14 --> Total execution time: 0.1682
INFO - 2017-03-15 23:49:22 --> Config Class Initialized
INFO - 2017-03-15 23:49:22 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:49:22 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:49:22 --> Utf8 Class Initialized
INFO - 2017-03-15 23:49:22 --> URI Class Initialized
INFO - 2017-03-15 23:49:22 --> Router Class Initialized
INFO - 2017-03-15 23:49:22 --> Output Class Initialized
INFO - 2017-03-15 23:49:22 --> Security Class Initialized
DEBUG - 2017-03-15 23:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:49:22 --> Input Class Initialized
INFO - 2017-03-15 23:49:22 --> Language Class Initialized
INFO - 2017-03-15 23:49:22 --> Loader Class Initialized
INFO - 2017-03-15 23:49:22 --> Config Class Initialized
INFO - 2017-03-15 23:49:22 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:49:22 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:49:22 --> Utf8 Class Initialized
INFO - 2017-03-15 23:49:22 --> URI Class Initialized
INFO - 2017-03-15 23:49:22 --> Router Class Initialized
INFO - 2017-03-15 23:49:22 --> Output Class Initialized
INFO - 2017-03-15 23:49:23 --> Database Driver Class Initialized
INFO - 2017-03-15 23:49:23 --> Security Class Initialized
DEBUG - 2017-03-15 23:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:49:23 --> Input Class Initialized
INFO - 2017-03-15 23:49:23 --> Language Class Initialized
INFO - 2017-03-15 23:49:23 --> Loader Class Initialized
INFO - 2017-03-15 23:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:49:23 --> Controller Class Initialized
INFO - 2017-03-15 23:49:23 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:49:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:49:23 --> Database Driver Class Initialized
INFO - 2017-03-15 23:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:49:23 --> Controller Class Initialized
INFO - 2017-03-15 23:49:23 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:49:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-15 23:49:23 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-15 23:49:23 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-15 23:49:23 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-15 23:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:49:23 --> Final output sent to browser
DEBUG - 2017-03-15 23:49:23 --> Total execution time: 0.3905
ERROR - 2017-03-15 23:49:23 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
INFO - 2017-03-15 23:49:23 --> Config Class Initialized
INFO - 2017-03-15 23:49:23 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:49:23 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:49:23 --> Utf8 Class Initialized
INFO - 2017-03-15 23:49:23 --> URI Class Initialized
INFO - 2017-03-15 23:49:23 --> Router Class Initialized
INFO - 2017-03-15 23:49:23 --> Output Class Initialized
INFO - 2017-03-15 23:49:23 --> Security Class Initialized
DEBUG - 2017-03-15 23:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:49:23 --> Input Class Initialized
INFO - 2017-03-15 23:49:23 --> Language Class Initialized
INFO - 2017-03-15 23:49:23 --> Loader Class Initialized
ERROR - 2017-03-15 23:49:23 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jesús Iván')
INFO - 2017-03-15 23:49:23 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-15 23:49:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-15 23:49:23 --> Database Driver Class Initialized
INFO - 2017-03-15 23:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:49:23 --> Controller Class Initialized
INFO - 2017-03-15 23:49:23 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:49:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-15 23:49:23 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-15 23:49:23 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-15 23:49:23 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-15 23:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:49:23 --> Final output sent to browser
DEBUG - 2017-03-15 23:49:23 --> Total execution time: 0.0866
INFO - 2017-03-15 23:49:23 --> Config Class Initialized
INFO - 2017-03-15 23:49:23 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:49:23 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:49:23 --> Utf8 Class Initialized
INFO - 2017-03-15 23:49:23 --> URI Class Initialized
INFO - 2017-03-15 23:49:23 --> Router Class Initialized
INFO - 2017-03-15 23:49:23 --> Output Class Initialized
INFO - 2017-03-15 23:49:23 --> Security Class Initialized
DEBUG - 2017-03-15 23:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:49:23 --> Input Class Initialized
INFO - 2017-03-15 23:49:23 --> Language Class Initialized
INFO - 2017-03-15 23:49:23 --> Loader Class Initialized
INFO - 2017-03-15 23:49:23 --> Database Driver Class Initialized
INFO - 2017-03-15 23:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:49:23 --> Controller Class Initialized
INFO - 2017-03-15 23:49:23 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:49:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:49:23 --> Final output sent to browser
DEBUG - 2017-03-15 23:49:23 --> Total execution time: 0.0377
INFO - 2017-03-15 23:49:29 --> Config Class Initialized
INFO - 2017-03-15 23:49:29 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:49:29 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:49:29 --> Utf8 Class Initialized
INFO - 2017-03-15 23:49:29 --> URI Class Initialized
DEBUG - 2017-03-15 23:49:30 --> No URI present. Default controller set.
INFO - 2017-03-15 23:49:30 --> Router Class Initialized
INFO - 2017-03-15 23:49:30 --> Output Class Initialized
INFO - 2017-03-15 23:49:30 --> Security Class Initialized
DEBUG - 2017-03-15 23:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:49:30 --> Input Class Initialized
INFO - 2017-03-15 23:49:30 --> Language Class Initialized
INFO - 2017-03-15 23:49:30 --> Loader Class Initialized
INFO - 2017-03-15 23:49:30 --> Database Driver Class Initialized
INFO - 2017-03-15 23:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:49:30 --> Controller Class Initialized
INFO - 2017-03-15 23:49:30 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:49:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:49:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:49:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:49:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:49:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:49:31 --> Final output sent to browser
DEBUG - 2017-03-15 23:49:31 --> Total execution time: 1.4614
INFO - 2017-03-15 23:49:33 --> Config Class Initialized
INFO - 2017-03-15 23:49:33 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:49:33 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:49:33 --> Utf8 Class Initialized
INFO - 2017-03-15 23:49:33 --> URI Class Initialized
INFO - 2017-03-15 23:49:33 --> Router Class Initialized
INFO - 2017-03-15 23:49:33 --> Output Class Initialized
INFO - 2017-03-15 23:49:33 --> Security Class Initialized
DEBUG - 2017-03-15 23:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:49:33 --> Input Class Initialized
INFO - 2017-03-15 23:49:33 --> Language Class Initialized
INFO - 2017-03-15 23:49:33 --> Loader Class Initialized
INFO - 2017-03-15 23:49:33 --> Database Driver Class Initialized
INFO - 2017-03-15 23:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:49:33 --> Controller Class Initialized
INFO - 2017-03-15 23:49:33 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:49:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:49:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:49:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:49:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:49:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:49:33 --> Final output sent to browser
DEBUG - 2017-03-15 23:49:33 --> Total execution time: 0.7613
INFO - 2017-03-15 23:56:27 --> Config Class Initialized
INFO - 2017-03-15 23:56:27 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:56:27 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:56:27 --> Utf8 Class Initialized
INFO - 2017-03-15 23:56:27 --> URI Class Initialized
INFO - 2017-03-15 23:56:27 --> Router Class Initialized
INFO - 2017-03-15 23:56:27 --> Output Class Initialized
INFO - 2017-03-15 23:56:27 --> Security Class Initialized
DEBUG - 2017-03-15 23:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:56:28 --> Input Class Initialized
INFO - 2017-03-15 23:56:28 --> Language Class Initialized
INFO - 2017-03-15 23:56:28 --> Loader Class Initialized
INFO - 2017-03-15 23:56:28 --> Database Driver Class Initialized
INFO - 2017-03-15 23:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:56:28 --> Controller Class Initialized
INFO - 2017-03-15 23:56:28 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:56:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-15 23:56:29 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-15 23:56:30 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Jesús Iván')
INFO - 2017-03-15 23:56:30 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-15 23:56:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-15 23:56:30 --> Config Class Initialized
INFO - 2017-03-15 23:56:30 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:56:30 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:56:30 --> Utf8 Class Initialized
INFO - 2017-03-15 23:56:30 --> URI Class Initialized
INFO - 2017-03-15 23:56:30 --> Router Class Initialized
INFO - 2017-03-15 23:56:30 --> Output Class Initialized
INFO - 2017-03-15 23:56:30 --> Security Class Initialized
DEBUG - 2017-03-15 23:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:56:30 --> Input Class Initialized
INFO - 2017-03-15 23:56:30 --> Language Class Initialized
INFO - 2017-03-15 23:56:30 --> Loader Class Initialized
INFO - 2017-03-15 23:56:30 --> Database Driver Class Initialized
INFO - 2017-03-15 23:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:56:30 --> Controller Class Initialized
INFO - 2017-03-15 23:56:30 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:56:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:56:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:56:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:56:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:56:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:56:30 --> Final output sent to browser
DEBUG - 2017-03-15 23:56:30 --> Total execution time: 0.1786
INFO - 2017-03-15 23:56:37 --> Config Class Initialized
INFO - 2017-03-15 23:56:37 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:56:37 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:56:37 --> Utf8 Class Initialized
INFO - 2017-03-15 23:56:37 --> URI Class Initialized
DEBUG - 2017-03-15 23:56:37 --> No URI present. Default controller set.
INFO - 2017-03-15 23:56:37 --> Router Class Initialized
INFO - 2017-03-15 23:56:37 --> Output Class Initialized
INFO - 2017-03-15 23:56:37 --> Security Class Initialized
DEBUG - 2017-03-15 23:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:56:37 --> Input Class Initialized
INFO - 2017-03-15 23:56:37 --> Language Class Initialized
INFO - 2017-03-15 23:56:37 --> Loader Class Initialized
INFO - 2017-03-15 23:56:37 --> Database Driver Class Initialized
INFO - 2017-03-15 23:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:56:37 --> Controller Class Initialized
INFO - 2017-03-15 23:56:37 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:56:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:56:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:56:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:56:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:56:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:56:37 --> Final output sent to browser
DEBUG - 2017-03-15 23:56:37 --> Total execution time: 0.0149
INFO - 2017-03-15 23:56:37 --> Config Class Initialized
INFO - 2017-03-15 23:56:37 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:56:37 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:56:37 --> Utf8 Class Initialized
INFO - 2017-03-15 23:56:37 --> URI Class Initialized
DEBUG - 2017-03-15 23:56:37 --> No URI present. Default controller set.
INFO - 2017-03-15 23:56:37 --> Router Class Initialized
INFO - 2017-03-15 23:56:37 --> Output Class Initialized
INFO - 2017-03-15 23:56:37 --> Security Class Initialized
DEBUG - 2017-03-15 23:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:56:37 --> Input Class Initialized
INFO - 2017-03-15 23:56:37 --> Language Class Initialized
INFO - 2017-03-15 23:56:37 --> Loader Class Initialized
INFO - 2017-03-15 23:56:37 --> Database Driver Class Initialized
INFO - 2017-03-15 23:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:56:37 --> Controller Class Initialized
INFO - 2017-03-15 23:56:37 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:56:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:56:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:56:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:56:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:56:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:56:37 --> Final output sent to browser
DEBUG - 2017-03-15 23:56:37 --> Total execution time: 0.0137
INFO - 2017-03-15 23:56:48 --> Config Class Initialized
INFO - 2017-03-15 23:56:48 --> Config Class Initialized
INFO - 2017-03-15 23:56:48 --> Hooks Class Initialized
INFO - 2017-03-15 23:56:48 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:56:49 --> UTF-8 Support Enabled
DEBUG - 2017-03-15 23:56:49 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:56:49 --> Utf8 Class Initialized
INFO - 2017-03-15 23:56:49 --> Utf8 Class Initialized
INFO - 2017-03-15 23:56:49 --> URI Class Initialized
INFO - 2017-03-15 23:56:49 --> URI Class Initialized
DEBUG - 2017-03-15 23:56:49 --> No URI present. Default controller set.
INFO - 2017-03-15 23:56:49 --> Router Class Initialized
INFO - 2017-03-15 23:56:49 --> Router Class Initialized
INFO - 2017-03-15 23:56:49 --> Output Class Initialized
INFO - 2017-03-15 23:56:49 --> Output Class Initialized
INFO - 2017-03-15 23:56:49 --> Security Class Initialized
INFO - 2017-03-15 23:56:49 --> Security Class Initialized
DEBUG - 2017-03-15 23:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:56:49 --> Input Class Initialized
INFO - 2017-03-15 23:56:49 --> Language Class Initialized
DEBUG - 2017-03-15 23:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:56:49 --> Input Class Initialized
INFO - 2017-03-15 23:56:49 --> Language Class Initialized
INFO - 2017-03-15 23:56:49 --> Loader Class Initialized
INFO - 2017-03-15 23:56:49 --> Loader Class Initialized
INFO - 2017-03-15 23:56:49 --> Database Driver Class Initialized
INFO - 2017-03-15 23:56:49 --> Database Driver Class Initialized
INFO - 2017-03-15 23:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:56:49 --> Controller Class Initialized
INFO - 2017-03-15 23:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:56:49 --> Controller Class Initialized
INFO - 2017-03-15 23:56:49 --> Helper loaded: url_helper
INFO - 2017-03-15 23:56:49 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:56:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-15 23:56:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:56:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:56:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:56:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
ERROR - 2017-03-15 23:56:50 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
INFO - 2017-03-15 23:56:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
ERROR - 2017-03-15 23:56:50 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-15 23:56:50 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-15 23:56:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:56:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:56:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:56:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:56:50 --> Final output sent to browser
DEBUG - 2017-03-15 23:56:50 --> Total execution time: 1.9826
INFO - 2017-03-15 23:56:50 --> Final output sent to browser
DEBUG - 2017-03-15 23:56:50 --> Total execution time: 1.9827
INFO - 2017-03-15 23:56:50 --> Config Class Initialized
INFO - 2017-03-15 23:56:50 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:56:50 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:56:50 --> Utf8 Class Initialized
INFO - 2017-03-15 23:56:50 --> URI Class Initialized
INFO - 2017-03-15 23:56:50 --> Router Class Initialized
INFO - 2017-03-15 23:56:50 --> Output Class Initialized
INFO - 2017-03-15 23:56:50 --> Security Class Initialized
DEBUG - 2017-03-15 23:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:56:50 --> Input Class Initialized
INFO - 2017-03-15 23:56:50 --> Language Class Initialized
INFO - 2017-03-15 23:56:50 --> Loader Class Initialized
INFO - 2017-03-15 23:56:50 --> Database Driver Class Initialized
INFO - 2017-03-15 23:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:56:50 --> Controller Class Initialized
INFO - 2017-03-15 23:56:50 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:56:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:56:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-15 23:56:50 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-15 23:56:50 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-15 23:56:50 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-15 23:56:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:56:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:56:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:56:50 --> Final output sent to browser
DEBUG - 2017-03-15 23:56:50 --> Total execution time: 0.0138
INFO - 2017-03-15 23:56:51 --> Config Class Initialized
INFO - 2017-03-15 23:56:51 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:56:51 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:56:51 --> Utf8 Class Initialized
INFO - 2017-03-15 23:56:51 --> URI Class Initialized
INFO - 2017-03-15 23:56:51 --> Router Class Initialized
INFO - 2017-03-15 23:56:51 --> Output Class Initialized
INFO - 2017-03-15 23:56:51 --> Security Class Initialized
DEBUG - 2017-03-15 23:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:56:51 --> Input Class Initialized
INFO - 2017-03-15 23:56:51 --> Language Class Initialized
INFO - 2017-03-15 23:56:51 --> Loader Class Initialized
INFO - 2017-03-15 23:56:51 --> Database Driver Class Initialized
INFO - 2017-03-15 23:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:56:51 --> Controller Class Initialized
INFO - 2017-03-15 23:56:51 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:56:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:56:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:56:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:56:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:56:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:56:51 --> Final output sent to browser
DEBUG - 2017-03-15 23:56:51 --> Total execution time: 0.0955
INFO - 2017-03-15 23:57:37 --> Config Class Initialized
INFO - 2017-03-15 23:57:37 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:57:37 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:57:37 --> Utf8 Class Initialized
INFO - 2017-03-15 23:57:37 --> URI Class Initialized
DEBUG - 2017-03-15 23:57:37 --> No URI present. Default controller set.
INFO - 2017-03-15 23:57:37 --> Router Class Initialized
INFO - 2017-03-15 23:57:37 --> Output Class Initialized
INFO - 2017-03-15 23:57:37 --> Security Class Initialized
DEBUG - 2017-03-15 23:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:57:37 --> Input Class Initialized
INFO - 2017-03-15 23:57:37 --> Language Class Initialized
INFO - 2017-03-15 23:57:37 --> Loader Class Initialized
INFO - 2017-03-15 23:57:38 --> Database Driver Class Initialized
INFO - 2017-03-15 23:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:57:38 --> Controller Class Initialized
INFO - 2017-03-15 23:57:38 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:57:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:57:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:57:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:57:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:57:38 --> Final output sent to browser
DEBUG - 2017-03-15 23:57:38 --> Total execution time: 1.4594
INFO - 2017-03-15 23:57:41 --> Config Class Initialized
INFO - 2017-03-15 23:57:41 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:57:41 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:57:41 --> Utf8 Class Initialized
INFO - 2017-03-15 23:57:41 --> URI Class Initialized
INFO - 2017-03-15 23:57:41 --> Router Class Initialized
INFO - 2017-03-15 23:57:41 --> Output Class Initialized
INFO - 2017-03-15 23:57:41 --> Security Class Initialized
DEBUG - 2017-03-15 23:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:57:41 --> Input Class Initialized
INFO - 2017-03-15 23:57:41 --> Language Class Initialized
INFO - 2017-03-15 23:57:41 --> Loader Class Initialized
INFO - 2017-03-15 23:57:42 --> Database Driver Class Initialized
INFO - 2017-03-15 23:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:57:42 --> Controller Class Initialized
INFO - 2017-03-15 23:57:42 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:57:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:57:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:57:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:57:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:57:42 --> Final output sent to browser
DEBUG - 2017-03-15 23:57:42 --> Total execution time: 1.2137
INFO - 2017-03-15 23:57:54 --> Config Class Initialized
INFO - 2017-03-15 23:57:54 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:57:55 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:57:55 --> Utf8 Class Initialized
INFO - 2017-03-15 23:57:55 --> URI Class Initialized
INFO - 2017-03-15 23:57:55 --> Router Class Initialized
INFO - 2017-03-15 23:57:55 --> Output Class Initialized
INFO - 2017-03-15 23:57:55 --> Security Class Initialized
DEBUG - 2017-03-15 23:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:57:55 --> Input Class Initialized
INFO - 2017-03-15 23:57:55 --> Language Class Initialized
INFO - 2017-03-15 23:57:55 --> Loader Class Initialized
INFO - 2017-03-15 23:57:55 --> Database Driver Class Initialized
INFO - 2017-03-15 23:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:57:55 --> Controller Class Initialized
INFO - 2017-03-15 23:57:55 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:57:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:57:58 --> Config Class Initialized
INFO - 2017-03-15 23:57:58 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:57:58 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:57:58 --> Utf8 Class Initialized
INFO - 2017-03-15 23:57:58 --> URI Class Initialized
INFO - 2017-03-15 23:57:58 --> Router Class Initialized
INFO - 2017-03-15 23:57:58 --> Output Class Initialized
INFO - 2017-03-15 23:57:58 --> Security Class Initialized
DEBUG - 2017-03-15 23:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:57:58 --> Input Class Initialized
INFO - 2017-03-15 23:57:58 --> Language Class Initialized
INFO - 2017-03-15 23:57:58 --> Loader Class Initialized
INFO - 2017-03-15 23:57:58 --> Database Driver Class Initialized
INFO - 2017-03-15 23:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:57:59 --> Controller Class Initialized
INFO - 2017-03-15 23:57:59 --> Helper loaded: date_helper
DEBUG - 2017-03-15 23:57:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:57:59 --> Helper loaded: url_helper
INFO - 2017-03-15 23:57:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:57:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-15 23:57:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-15 23:57:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-15 23:57:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:57:59 --> Final output sent to browser
DEBUG - 2017-03-15 23:57:59 --> Total execution time: 1.1177
INFO - 2017-03-15 23:58:00 --> Config Class Initialized
INFO - 2017-03-15 23:58:00 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:58:00 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:58:00 --> Utf8 Class Initialized
INFO - 2017-03-15 23:58:00 --> URI Class Initialized
INFO - 2017-03-15 23:58:00 --> Router Class Initialized
INFO - 2017-03-15 23:58:00 --> Output Class Initialized
INFO - 2017-03-15 23:58:00 --> Security Class Initialized
DEBUG - 2017-03-15 23:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:58:01 --> Input Class Initialized
INFO - 2017-03-15 23:58:01 --> Language Class Initialized
INFO - 2017-03-15 23:58:01 --> Loader Class Initialized
INFO - 2017-03-15 23:58:01 --> Database Driver Class Initialized
INFO - 2017-03-15 23:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:58:01 --> Controller Class Initialized
INFO - 2017-03-15 23:58:01 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:58:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:58:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:58:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:58:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:58:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:58:02 --> Final output sent to browser
DEBUG - 2017-03-15 23:58:02 --> Total execution time: 1.4850
INFO - 2017-03-15 23:58:35 --> Config Class Initialized
INFO - 2017-03-15 23:58:35 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:58:35 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:58:35 --> Utf8 Class Initialized
INFO - 2017-03-15 23:58:35 --> URI Class Initialized
INFO - 2017-03-15 23:58:35 --> Router Class Initialized
INFO - 2017-03-15 23:58:35 --> Output Class Initialized
INFO - 2017-03-15 23:58:35 --> Security Class Initialized
DEBUG - 2017-03-15 23:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:58:35 --> Input Class Initialized
INFO - 2017-03-15 23:58:35 --> Language Class Initialized
INFO - 2017-03-15 23:58:35 --> Loader Class Initialized
INFO - 2017-03-15 23:58:36 --> Database Driver Class Initialized
INFO - 2017-03-15 23:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:58:36 --> Controller Class Initialized
INFO - 2017-03-15 23:58:36 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:58:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:58:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:58:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:58:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:58:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:58:36 --> Final output sent to browser
DEBUG - 2017-03-15 23:58:36 --> Total execution time: 2.0239
INFO - 2017-03-15 23:58:38 --> Config Class Initialized
INFO - 2017-03-15 23:58:38 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:58:38 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:58:38 --> Utf8 Class Initialized
INFO - 2017-03-15 23:58:38 --> URI Class Initialized
INFO - 2017-03-15 23:58:38 --> Router Class Initialized
INFO - 2017-03-15 23:58:38 --> Output Class Initialized
INFO - 2017-03-15 23:58:38 --> Security Class Initialized
DEBUG - 2017-03-15 23:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:58:38 --> Input Class Initialized
INFO - 2017-03-15 23:58:38 --> Language Class Initialized
INFO - 2017-03-15 23:58:38 --> Loader Class Initialized
INFO - 2017-03-15 23:58:38 --> Database Driver Class Initialized
INFO - 2017-03-15 23:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:58:38 --> Controller Class Initialized
INFO - 2017-03-15 23:58:38 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:58:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:58:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:58:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:58:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:58:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:58:38 --> Final output sent to browser
DEBUG - 2017-03-15 23:58:38 --> Total execution time: 0.0211
INFO - 2017-03-15 23:58:51 --> Config Class Initialized
INFO - 2017-03-15 23:58:51 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:58:51 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:58:51 --> Utf8 Class Initialized
INFO - 2017-03-15 23:58:51 --> URI Class Initialized
INFO - 2017-03-15 23:58:52 --> Router Class Initialized
INFO - 2017-03-15 23:58:52 --> Output Class Initialized
INFO - 2017-03-15 23:58:52 --> Security Class Initialized
DEBUG - 2017-03-15 23:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:58:52 --> Input Class Initialized
INFO - 2017-03-15 23:58:52 --> Language Class Initialized
INFO - 2017-03-15 23:58:52 --> Loader Class Initialized
INFO - 2017-03-15 23:58:52 --> Database Driver Class Initialized
INFO - 2017-03-15 23:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:58:53 --> Controller Class Initialized
INFO - 2017-03-15 23:58:53 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:58:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:58:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:58:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:58:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:58:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:58:53 --> Final output sent to browser
DEBUG - 2017-03-15 23:58:53 --> Total execution time: 1.5510
INFO - 2017-03-15 23:58:53 --> Config Class Initialized
INFO - 2017-03-15 23:58:53 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:58:53 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:58:53 --> Utf8 Class Initialized
INFO - 2017-03-15 23:58:53 --> URI Class Initialized
INFO - 2017-03-15 23:58:53 --> Router Class Initialized
INFO - 2017-03-15 23:58:53 --> Output Class Initialized
INFO - 2017-03-15 23:58:53 --> Security Class Initialized
DEBUG - 2017-03-15 23:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:58:53 --> Input Class Initialized
INFO - 2017-03-15 23:58:53 --> Language Class Initialized
INFO - 2017-03-15 23:58:53 --> Loader Class Initialized
INFO - 2017-03-15 23:58:53 --> Database Driver Class Initialized
INFO - 2017-03-15 23:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:58:53 --> Controller Class Initialized
INFO - 2017-03-15 23:58:53 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:58:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:58:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:58:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:58:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:58:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:58:53 --> Final output sent to browser
DEBUG - 2017-03-15 23:58:53 --> Total execution time: 0.0135
INFO - 2017-03-15 23:58:58 --> Config Class Initialized
INFO - 2017-03-15 23:58:58 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:58:58 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:58:58 --> Utf8 Class Initialized
INFO - 2017-03-15 23:58:58 --> URI Class Initialized
INFO - 2017-03-15 23:58:58 --> Router Class Initialized
INFO - 2017-03-15 23:58:58 --> Output Class Initialized
INFO - 2017-03-15 23:58:58 --> Security Class Initialized
DEBUG - 2017-03-15 23:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:58:58 --> Input Class Initialized
INFO - 2017-03-15 23:58:58 --> Language Class Initialized
INFO - 2017-03-15 23:58:58 --> Loader Class Initialized
INFO - 2017-03-15 23:58:58 --> Database Driver Class Initialized
INFO - 2017-03-15 23:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:58:58 --> Controller Class Initialized
INFO - 2017-03-15 23:58:58 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:58:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:58:58 --> Final output sent to browser
DEBUG - 2017-03-15 23:58:58 --> Total execution time: 0.0441
INFO - 2017-03-15 23:58:59 --> Config Class Initialized
INFO - 2017-03-15 23:58:59 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:58:59 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:58:59 --> Utf8 Class Initialized
INFO - 2017-03-15 23:58:59 --> URI Class Initialized
INFO - 2017-03-15 23:58:59 --> Router Class Initialized
INFO - 2017-03-15 23:58:59 --> Output Class Initialized
INFO - 2017-03-15 23:58:59 --> Security Class Initialized
DEBUG - 2017-03-15 23:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:58:59 --> Input Class Initialized
INFO - 2017-03-15 23:58:59 --> Language Class Initialized
INFO - 2017-03-15 23:58:59 --> Loader Class Initialized
INFO - 2017-03-15 23:58:59 --> Database Driver Class Initialized
INFO - 2017-03-15 23:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:58:59 --> Controller Class Initialized
INFO - 2017-03-15 23:58:59 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:58:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:58:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:58:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:58:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:58:59 --> Final output sent to browser
DEBUG - 2017-03-15 23:58:59 --> Total execution time: 0.0136
INFO - 2017-03-15 23:59:43 --> Config Class Initialized
INFO - 2017-03-15 23:59:43 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:59:43 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:59:43 --> Utf8 Class Initialized
INFO - 2017-03-15 23:59:43 --> URI Class Initialized
INFO - 2017-03-15 23:59:43 --> Router Class Initialized
INFO - 2017-03-15 23:59:43 --> Output Class Initialized
INFO - 2017-03-15 23:59:43 --> Security Class Initialized
DEBUG - 2017-03-15 23:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:59:43 --> Input Class Initialized
INFO - 2017-03-15 23:59:43 --> Language Class Initialized
INFO - 2017-03-15 23:59:43 --> Loader Class Initialized
INFO - 2017-03-15 23:59:43 --> Database Driver Class Initialized
INFO - 2017-03-15 23:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:59:43 --> Controller Class Initialized
INFO - 2017-03-15 23:59:43 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:59:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:59:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:59:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:59:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:59:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:59:43 --> Final output sent to browser
DEBUG - 2017-03-15 23:59:43 --> Total execution time: 0.0598
INFO - 2017-03-15 23:59:44 --> Config Class Initialized
INFO - 2017-03-15 23:59:44 --> Hooks Class Initialized
DEBUG - 2017-03-15 23:59:44 --> UTF-8 Support Enabled
INFO - 2017-03-15 23:59:44 --> Utf8 Class Initialized
INFO - 2017-03-15 23:59:44 --> URI Class Initialized
INFO - 2017-03-15 23:59:44 --> Router Class Initialized
INFO - 2017-03-15 23:59:44 --> Output Class Initialized
INFO - 2017-03-15 23:59:44 --> Security Class Initialized
DEBUG - 2017-03-15 23:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-15 23:59:44 --> Input Class Initialized
INFO - 2017-03-15 23:59:44 --> Language Class Initialized
INFO - 2017-03-15 23:59:44 --> Loader Class Initialized
INFO - 2017-03-15 23:59:44 --> Database Driver Class Initialized
INFO - 2017-03-15 23:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-15 23:59:44 --> Controller Class Initialized
INFO - 2017-03-15 23:59:44 --> Helper loaded: url_helper
DEBUG - 2017-03-15 23:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-15 23:59:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-15 23:59:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-15 23:59:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-15 23:59:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-15 23:59:44 --> Final output sent to browser
DEBUG - 2017-03-15 23:59:44 --> Total execution time: 0.0136

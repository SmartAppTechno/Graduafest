<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-08 01:15:30 --> Config Class Initialized
INFO - 2017-02-08 01:15:30 --> Hooks Class Initialized
DEBUG - 2017-02-08 01:15:30 --> UTF-8 Support Enabled
INFO - 2017-02-08 01:15:30 --> Utf8 Class Initialized
INFO - 2017-02-08 01:15:30 --> URI Class Initialized
INFO - 2017-02-08 01:15:30 --> Router Class Initialized
INFO - 2017-02-08 01:15:30 --> Output Class Initialized
INFO - 2017-02-08 01:15:30 --> Security Class Initialized
DEBUG - 2017-02-08 01:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 01:15:31 --> Input Class Initialized
INFO - 2017-02-08 01:15:31 --> Language Class Initialized
INFO - 2017-02-08 01:15:31 --> Loader Class Initialized
INFO - 2017-02-08 01:15:31 --> Database Driver Class Initialized
INFO - 2017-02-08 01:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 01:15:31 --> Controller Class Initialized
INFO - 2017-02-08 01:15:31 --> Helper loaded: url_helper
DEBUG - 2017-02-08 01:15:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 01:15:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 01:15:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 01:15:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 01:15:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 01:15:32 --> Final output sent to browser
DEBUG - 2017-02-08 01:15:32 --> Total execution time: 2.0875
INFO - 2017-02-08 01:15:48 --> Config Class Initialized
INFO - 2017-02-08 01:15:48 --> Hooks Class Initialized
DEBUG - 2017-02-08 01:15:48 --> UTF-8 Support Enabled
INFO - 2017-02-08 01:15:48 --> Utf8 Class Initialized
INFO - 2017-02-08 01:15:48 --> URI Class Initialized
DEBUG - 2017-02-08 01:15:48 --> No URI present. Default controller set.
INFO - 2017-02-08 01:15:48 --> Router Class Initialized
INFO - 2017-02-08 01:15:48 --> Output Class Initialized
INFO - 2017-02-08 01:15:48 --> Security Class Initialized
DEBUG - 2017-02-08 01:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 01:15:48 --> Input Class Initialized
INFO - 2017-02-08 01:15:48 --> Language Class Initialized
INFO - 2017-02-08 01:15:48 --> Loader Class Initialized
INFO - 2017-02-08 01:15:48 --> Database Driver Class Initialized
INFO - 2017-02-08 01:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 01:15:48 --> Controller Class Initialized
INFO - 2017-02-08 01:15:48 --> Helper loaded: url_helper
DEBUG - 2017-02-08 01:15:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 01:15:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 01:15:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 01:15:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 01:15:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 01:15:48 --> Final output sent to browser
DEBUG - 2017-02-08 01:15:48 --> Total execution time: 0.0134
INFO - 2017-02-08 01:25:54 --> Config Class Initialized
INFO - 2017-02-08 01:25:54 --> Hooks Class Initialized
DEBUG - 2017-02-08 01:25:54 --> UTF-8 Support Enabled
INFO - 2017-02-08 01:25:54 --> Utf8 Class Initialized
INFO - 2017-02-08 01:25:54 --> URI Class Initialized
INFO - 2017-02-08 01:25:54 --> Router Class Initialized
INFO - 2017-02-08 01:25:54 --> Output Class Initialized
INFO - 2017-02-08 01:25:54 --> Security Class Initialized
DEBUG - 2017-02-08 01:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 01:25:54 --> Input Class Initialized
INFO - 2017-02-08 01:25:54 --> Language Class Initialized
INFO - 2017-02-08 01:25:54 --> Loader Class Initialized
INFO - 2017-02-08 01:25:54 --> Database Driver Class Initialized
INFO - 2017-02-08 01:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 01:25:54 --> Controller Class Initialized
INFO - 2017-02-08 01:25:54 --> Helper loaded: url_helper
DEBUG - 2017-02-08 01:25:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 01:25:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 01:25:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 01:25:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 01:25:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 01:25:54 --> Final output sent to browser
DEBUG - 2017-02-08 01:25:54 --> Total execution time: 0.0137
INFO - 2017-02-08 01:25:54 --> Config Class Initialized
INFO - 2017-02-08 01:25:54 --> Hooks Class Initialized
DEBUG - 2017-02-08 01:25:54 --> UTF-8 Support Enabled
INFO - 2017-02-08 01:25:54 --> Utf8 Class Initialized
INFO - 2017-02-08 01:25:54 --> URI Class Initialized
DEBUG - 2017-02-08 01:25:54 --> No URI present. Default controller set.
INFO - 2017-02-08 01:25:54 --> Router Class Initialized
INFO - 2017-02-08 01:25:54 --> Output Class Initialized
INFO - 2017-02-08 01:25:54 --> Security Class Initialized
DEBUG - 2017-02-08 01:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 01:25:54 --> Input Class Initialized
INFO - 2017-02-08 01:25:54 --> Language Class Initialized
INFO - 2017-02-08 01:25:54 --> Loader Class Initialized
INFO - 2017-02-08 01:25:54 --> Database Driver Class Initialized
INFO - 2017-02-08 01:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 01:25:54 --> Controller Class Initialized
INFO - 2017-02-08 01:25:54 --> Helper loaded: url_helper
DEBUG - 2017-02-08 01:25:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 01:25:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 01:25:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 01:25:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 01:25:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 01:25:54 --> Final output sent to browser
DEBUG - 2017-02-08 01:25:54 --> Total execution time: 0.0133
INFO - 2017-02-08 03:10:02 --> Config Class Initialized
INFO - 2017-02-08 03:10:02 --> Hooks Class Initialized
DEBUG - 2017-02-08 03:10:02 --> UTF-8 Support Enabled
INFO - 2017-02-08 03:10:02 --> Utf8 Class Initialized
INFO - 2017-02-08 03:10:02 --> URI Class Initialized
INFO - 2017-02-08 03:10:03 --> Router Class Initialized
INFO - 2017-02-08 03:10:03 --> Output Class Initialized
INFO - 2017-02-08 03:10:03 --> Security Class Initialized
DEBUG - 2017-02-08 03:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 03:10:03 --> Input Class Initialized
INFO - 2017-02-08 03:10:03 --> Language Class Initialized
INFO - 2017-02-08 03:10:03 --> Loader Class Initialized
INFO - 2017-02-08 03:10:03 --> Database Driver Class Initialized
INFO - 2017-02-08 03:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 03:10:04 --> Controller Class Initialized
INFO - 2017-02-08 03:10:04 --> Helper loaded: url_helper
DEBUG - 2017-02-08 03:10:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 03:10:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 03:10:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 03:10:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 03:10:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 03:10:04 --> Final output sent to browser
DEBUG - 2017-02-08 03:10:04 --> Total execution time: 1.7581
INFO - 2017-02-08 03:10:04 --> Config Class Initialized
INFO - 2017-02-08 03:10:04 --> Hooks Class Initialized
DEBUG - 2017-02-08 03:10:04 --> UTF-8 Support Enabled
INFO - 2017-02-08 03:10:04 --> Utf8 Class Initialized
INFO - 2017-02-08 03:10:04 --> URI Class Initialized
DEBUG - 2017-02-08 03:10:04 --> No URI present. Default controller set.
INFO - 2017-02-08 03:10:04 --> Router Class Initialized
INFO - 2017-02-08 03:10:04 --> Output Class Initialized
INFO - 2017-02-08 03:10:04 --> Security Class Initialized
DEBUG - 2017-02-08 03:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 03:10:04 --> Input Class Initialized
INFO - 2017-02-08 03:10:04 --> Language Class Initialized
INFO - 2017-02-08 03:10:04 --> Loader Class Initialized
INFO - 2017-02-08 03:10:04 --> Database Driver Class Initialized
INFO - 2017-02-08 03:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 03:10:04 --> Controller Class Initialized
INFO - 2017-02-08 03:10:04 --> Helper loaded: url_helper
DEBUG - 2017-02-08 03:10:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 03:10:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 03:10:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 03:10:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 03:10:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 03:10:04 --> Final output sent to browser
DEBUG - 2017-02-08 03:10:04 --> Total execution time: 0.0135
INFO - 2017-02-08 04:00:54 --> Config Class Initialized
INFO - 2017-02-08 04:00:54 --> Hooks Class Initialized
DEBUG - 2017-02-08 04:00:55 --> UTF-8 Support Enabled
INFO - 2017-02-08 04:00:55 --> Utf8 Class Initialized
INFO - 2017-02-08 04:00:55 --> URI Class Initialized
INFO - 2017-02-08 04:00:55 --> Router Class Initialized
INFO - 2017-02-08 04:00:55 --> Output Class Initialized
INFO - 2017-02-08 04:00:55 --> Security Class Initialized
DEBUG - 2017-02-08 04:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 04:00:55 --> Input Class Initialized
INFO - 2017-02-08 04:00:55 --> Language Class Initialized
ERROR - 2017-02-08 04:00:55 --> 404 Page Not Found: Phone/index.html
INFO - 2017-02-08 04:00:56 --> Config Class Initialized
INFO - 2017-02-08 04:00:56 --> Hooks Class Initialized
DEBUG - 2017-02-08 04:00:56 --> UTF-8 Support Enabled
INFO - 2017-02-08 04:00:56 --> Utf8 Class Initialized
INFO - 2017-02-08 04:00:56 --> URI Class Initialized
INFO - 2017-02-08 04:00:56 --> Router Class Initialized
INFO - 2017-02-08 04:00:56 --> Output Class Initialized
INFO - 2017-02-08 04:00:56 --> Security Class Initialized
DEBUG - 2017-02-08 04:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 04:00:56 --> Input Class Initialized
INFO - 2017-02-08 04:00:56 --> Language Class Initialized
INFO - 2017-02-08 04:00:56 --> Loader Class Initialized
INFO - 2017-02-08 04:00:56 --> Database Driver Class Initialized
INFO - 2017-02-08 04:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 04:00:57 --> Controller Class Initialized
INFO - 2017-02-08 04:00:57 --> Helper loaded: url_helper
DEBUG - 2017-02-08 04:00:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 04:00:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 04:00:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 04:00:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 04:00:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 04:00:57 --> Final output sent to browser
DEBUG - 2017-02-08 04:00:57 --> Total execution time: 0.9847
INFO - 2017-02-08 04:01:10 --> Config Class Initialized
INFO - 2017-02-08 04:01:10 --> Hooks Class Initialized
DEBUG - 2017-02-08 04:01:10 --> UTF-8 Support Enabled
INFO - 2017-02-08 04:01:10 --> Utf8 Class Initialized
INFO - 2017-02-08 04:01:10 --> URI Class Initialized
DEBUG - 2017-02-08 04:01:10 --> No URI present. Default controller set.
INFO - 2017-02-08 04:01:10 --> Router Class Initialized
INFO - 2017-02-08 04:01:10 --> Output Class Initialized
INFO - 2017-02-08 04:01:10 --> Security Class Initialized
DEBUG - 2017-02-08 04:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 04:01:10 --> Input Class Initialized
INFO - 2017-02-08 04:01:10 --> Language Class Initialized
INFO - 2017-02-08 04:01:10 --> Loader Class Initialized
INFO - 2017-02-08 04:01:10 --> Database Driver Class Initialized
INFO - 2017-02-08 04:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 04:01:10 --> Controller Class Initialized
INFO - 2017-02-08 04:01:10 --> Helper loaded: url_helper
DEBUG - 2017-02-08 04:01:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 04:01:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 04:01:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 04:01:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 04:01:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 04:01:10 --> Final output sent to browser
DEBUG - 2017-02-08 04:01:10 --> Total execution time: 0.0129
INFO - 2017-02-08 04:01:32 --> Config Class Initialized
INFO - 2017-02-08 04:01:32 --> Hooks Class Initialized
DEBUG - 2017-02-08 04:01:32 --> UTF-8 Support Enabled
INFO - 2017-02-08 04:01:32 --> Utf8 Class Initialized
INFO - 2017-02-08 04:01:32 --> URI Class Initialized
INFO - 2017-02-08 04:01:32 --> Router Class Initialized
INFO - 2017-02-08 04:01:32 --> Output Class Initialized
INFO - 2017-02-08 04:01:32 --> Security Class Initialized
DEBUG - 2017-02-08 04:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 04:01:32 --> Input Class Initialized
INFO - 2017-02-08 04:01:32 --> Language Class Initialized
INFO - 2017-02-08 04:01:33 --> Loader Class Initialized
INFO - 2017-02-08 04:01:33 --> Database Driver Class Initialized
INFO - 2017-02-08 04:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 04:01:33 --> Controller Class Initialized
INFO - 2017-02-08 04:01:33 --> Helper loaded: url_helper
DEBUG - 2017-02-08 04:01:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 04:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 04:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 04:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 04:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 04:01:33 --> Final output sent to browser
DEBUG - 2017-02-08 04:01:33 --> Total execution time: 0.4425
INFO - 2017-02-08 04:02:50 --> Config Class Initialized
INFO - 2017-02-08 04:02:50 --> Hooks Class Initialized
DEBUG - 2017-02-08 04:02:50 --> UTF-8 Support Enabled
INFO - 2017-02-08 04:02:50 --> Utf8 Class Initialized
INFO - 2017-02-08 04:02:50 --> URI Class Initialized
INFO - 2017-02-08 04:02:50 --> Router Class Initialized
INFO - 2017-02-08 04:02:50 --> Output Class Initialized
INFO - 2017-02-08 04:02:50 --> Security Class Initialized
DEBUG - 2017-02-08 04:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 04:02:50 --> Input Class Initialized
INFO - 2017-02-08 04:02:50 --> Language Class Initialized
INFO - 2017-02-08 04:02:50 --> Loader Class Initialized
INFO - 2017-02-08 04:02:51 --> Database Driver Class Initialized
INFO - 2017-02-08 04:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 04:02:51 --> Controller Class Initialized
INFO - 2017-02-08 04:02:51 --> Helper loaded: url_helper
DEBUG - 2017-02-08 04:02:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 04:02:52 --> Config Class Initialized
INFO - 2017-02-08 04:02:52 --> Hooks Class Initialized
DEBUG - 2017-02-08 04:02:52 --> UTF-8 Support Enabled
INFO - 2017-02-08 04:02:52 --> Utf8 Class Initialized
INFO - 2017-02-08 04:02:52 --> URI Class Initialized
INFO - 2017-02-08 04:02:52 --> Router Class Initialized
INFO - 2017-02-08 04:02:52 --> Output Class Initialized
INFO - 2017-02-08 04:02:52 --> Security Class Initialized
DEBUG - 2017-02-08 04:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 04:02:52 --> Input Class Initialized
INFO - 2017-02-08 04:02:52 --> Language Class Initialized
INFO - 2017-02-08 04:02:52 --> Loader Class Initialized
INFO - 2017-02-08 04:02:52 --> Database Driver Class Initialized
INFO - 2017-02-08 04:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 04:02:52 --> Controller Class Initialized
INFO - 2017-02-08 04:02:52 --> Helper loaded: date_helper
DEBUG - 2017-02-08 04:02:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 04:02:52 --> Helper loaded: url_helper
INFO - 2017-02-08 04:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 04:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-08 04:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-08 04:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-08 04:02:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 04:02:52 --> Final output sent to browser
DEBUG - 2017-02-08 04:02:52 --> Total execution time: 0.3923
INFO - 2017-02-08 04:02:54 --> Config Class Initialized
INFO - 2017-02-08 04:02:54 --> Hooks Class Initialized
DEBUG - 2017-02-08 04:02:54 --> UTF-8 Support Enabled
INFO - 2017-02-08 04:02:54 --> Utf8 Class Initialized
INFO - 2017-02-08 04:02:54 --> URI Class Initialized
INFO - 2017-02-08 04:02:54 --> Router Class Initialized
INFO - 2017-02-08 04:02:54 --> Output Class Initialized
INFO - 2017-02-08 04:02:54 --> Security Class Initialized
DEBUG - 2017-02-08 04:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 04:02:54 --> Input Class Initialized
INFO - 2017-02-08 04:02:54 --> Language Class Initialized
INFO - 2017-02-08 04:02:54 --> Loader Class Initialized
INFO - 2017-02-08 04:02:54 --> Database Driver Class Initialized
INFO - 2017-02-08 04:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 04:02:54 --> Controller Class Initialized
INFO - 2017-02-08 04:02:54 --> Helper loaded: url_helper
DEBUG - 2017-02-08 04:02:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 04:02:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 04:02:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 04:02:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 04:02:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 04:02:54 --> Final output sent to browser
DEBUG - 2017-02-08 04:02:54 --> Total execution time: 0.0730
INFO - 2017-02-08 04:03:03 --> Config Class Initialized
INFO - 2017-02-08 04:03:03 --> Hooks Class Initialized
DEBUG - 2017-02-08 04:03:03 --> UTF-8 Support Enabled
INFO - 2017-02-08 04:03:03 --> Utf8 Class Initialized
INFO - 2017-02-08 04:03:03 --> URI Class Initialized
DEBUG - 2017-02-08 04:03:03 --> No URI present. Default controller set.
INFO - 2017-02-08 04:03:03 --> Router Class Initialized
INFO - 2017-02-08 04:03:03 --> Output Class Initialized
INFO - 2017-02-08 04:03:03 --> Security Class Initialized
DEBUG - 2017-02-08 04:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 04:03:03 --> Input Class Initialized
INFO - 2017-02-08 04:03:03 --> Language Class Initialized
INFO - 2017-02-08 04:03:03 --> Loader Class Initialized
INFO - 2017-02-08 04:03:03 --> Database Driver Class Initialized
INFO - 2017-02-08 04:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 04:03:03 --> Controller Class Initialized
INFO - 2017-02-08 04:03:03 --> Helper loaded: url_helper
DEBUG - 2017-02-08 04:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 04:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 04:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 04:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 04:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 04:03:03 --> Final output sent to browser
DEBUG - 2017-02-08 04:03:03 --> Total execution time: 0.0127
INFO - 2017-02-08 04:03:05 --> Config Class Initialized
INFO - 2017-02-08 04:03:05 --> Hooks Class Initialized
DEBUG - 2017-02-08 04:03:05 --> UTF-8 Support Enabled
INFO - 2017-02-08 04:03:05 --> Utf8 Class Initialized
INFO - 2017-02-08 04:03:05 --> URI Class Initialized
INFO - 2017-02-08 04:03:05 --> Router Class Initialized
INFO - 2017-02-08 04:03:05 --> Output Class Initialized
INFO - 2017-02-08 04:03:05 --> Security Class Initialized
DEBUG - 2017-02-08 04:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 04:03:05 --> Input Class Initialized
INFO - 2017-02-08 04:03:05 --> Language Class Initialized
INFO - 2017-02-08 04:03:05 --> Loader Class Initialized
INFO - 2017-02-08 04:03:05 --> Database Driver Class Initialized
INFO - 2017-02-08 04:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 04:03:05 --> Controller Class Initialized
INFO - 2017-02-08 04:03:05 --> Helper loaded: url_helper
DEBUG - 2017-02-08 04:03:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 04:03:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 04:03:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 04:03:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 04:03:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 04:03:05 --> Final output sent to browser
DEBUG - 2017-02-08 04:03:05 --> Total execution time: 0.0135
INFO - 2017-02-08 04:03:27 --> Config Class Initialized
INFO - 2017-02-08 04:03:27 --> Hooks Class Initialized
DEBUG - 2017-02-08 04:03:27 --> UTF-8 Support Enabled
INFO - 2017-02-08 04:03:27 --> Utf8 Class Initialized
INFO - 2017-02-08 04:03:27 --> URI Class Initialized
INFO - 2017-02-08 04:03:27 --> Router Class Initialized
INFO - 2017-02-08 04:03:27 --> Output Class Initialized
INFO - 2017-02-08 04:03:27 --> Security Class Initialized
DEBUG - 2017-02-08 04:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 04:03:27 --> Input Class Initialized
INFO - 2017-02-08 04:03:27 --> Language Class Initialized
INFO - 2017-02-08 04:03:27 --> Loader Class Initialized
INFO - 2017-02-08 04:03:27 --> Database Driver Class Initialized
INFO - 2017-02-08 04:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 04:03:27 --> Controller Class Initialized
INFO - 2017-02-08 04:03:27 --> Helper loaded: url_helper
DEBUG - 2017-02-08 04:03:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 04:03:27 --> Config Class Initialized
INFO - 2017-02-08 04:03:27 --> Hooks Class Initialized
DEBUG - 2017-02-08 04:03:27 --> UTF-8 Support Enabled
INFO - 2017-02-08 04:03:27 --> Utf8 Class Initialized
INFO - 2017-02-08 04:03:27 --> URI Class Initialized
INFO - 2017-02-08 04:03:27 --> Router Class Initialized
INFO - 2017-02-08 04:03:27 --> Output Class Initialized
INFO - 2017-02-08 04:03:27 --> Security Class Initialized
DEBUG - 2017-02-08 04:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 04:03:27 --> Input Class Initialized
INFO - 2017-02-08 04:03:27 --> Language Class Initialized
INFO - 2017-02-08 04:03:27 --> Loader Class Initialized
INFO - 2017-02-08 04:03:27 --> Database Driver Class Initialized
INFO - 2017-02-08 04:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 04:03:27 --> Controller Class Initialized
INFO - 2017-02-08 04:03:27 --> Helper loaded: date_helper
DEBUG - 2017-02-08 04:03:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 04:03:27 --> Helper loaded: url_helper
INFO - 2017-02-08 04:03:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 04:03:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-08 04:03:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-08 04:03:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-08 04:03:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 04:03:27 --> Final output sent to browser
DEBUG - 2017-02-08 04:03:27 --> Total execution time: 0.0134
INFO - 2017-02-08 04:03:29 --> Config Class Initialized
INFO - 2017-02-08 04:03:29 --> Hooks Class Initialized
DEBUG - 2017-02-08 04:03:29 --> UTF-8 Support Enabled
INFO - 2017-02-08 04:03:29 --> Utf8 Class Initialized
INFO - 2017-02-08 04:03:29 --> URI Class Initialized
INFO - 2017-02-08 04:03:29 --> Router Class Initialized
INFO - 2017-02-08 04:03:29 --> Output Class Initialized
INFO - 2017-02-08 04:03:29 --> Security Class Initialized
DEBUG - 2017-02-08 04:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 04:03:29 --> Input Class Initialized
INFO - 2017-02-08 04:03:29 --> Language Class Initialized
INFO - 2017-02-08 04:03:29 --> Loader Class Initialized
INFO - 2017-02-08 04:03:29 --> Database Driver Class Initialized
INFO - 2017-02-08 04:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 04:03:29 --> Controller Class Initialized
INFO - 2017-02-08 04:03:29 --> Helper loaded: url_helper
DEBUG - 2017-02-08 04:03:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 04:03:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 04:03:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 04:03:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 04:03:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 04:03:29 --> Final output sent to browser
DEBUG - 2017-02-08 04:03:29 --> Total execution time: 0.0135
INFO - 2017-02-08 04:36:07 --> Config Class Initialized
INFO - 2017-02-08 04:36:07 --> Hooks Class Initialized
DEBUG - 2017-02-08 04:36:08 --> UTF-8 Support Enabled
INFO - 2017-02-08 04:36:08 --> Utf8 Class Initialized
INFO - 2017-02-08 04:36:08 --> URI Class Initialized
DEBUG - 2017-02-08 04:36:08 --> No URI present. Default controller set.
INFO - 2017-02-08 04:36:08 --> Router Class Initialized
INFO - 2017-02-08 04:36:08 --> Output Class Initialized
INFO - 2017-02-08 04:36:08 --> Security Class Initialized
DEBUG - 2017-02-08 04:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 04:36:08 --> Input Class Initialized
INFO - 2017-02-08 04:36:08 --> Language Class Initialized
INFO - 2017-02-08 04:36:08 --> Loader Class Initialized
INFO - 2017-02-08 04:36:08 --> Database Driver Class Initialized
INFO - 2017-02-08 04:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 04:36:08 --> Controller Class Initialized
INFO - 2017-02-08 04:36:08 --> Helper loaded: url_helper
DEBUG - 2017-02-08 04:36:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 04:36:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 04:36:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 04:36:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 04:36:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 04:36:09 --> Final output sent to browser
DEBUG - 2017-02-08 04:36:09 --> Total execution time: 1.5808
INFO - 2017-02-08 04:36:12 --> Config Class Initialized
INFO - 2017-02-08 04:36:12 --> Hooks Class Initialized
DEBUG - 2017-02-08 04:36:12 --> UTF-8 Support Enabled
INFO - 2017-02-08 04:36:12 --> Utf8 Class Initialized
INFO - 2017-02-08 04:36:12 --> URI Class Initialized
INFO - 2017-02-08 04:36:12 --> Router Class Initialized
INFO - 2017-02-08 04:36:12 --> Output Class Initialized
INFO - 2017-02-08 04:36:12 --> Security Class Initialized
DEBUG - 2017-02-08 04:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 04:36:12 --> Input Class Initialized
INFO - 2017-02-08 04:36:12 --> Language Class Initialized
INFO - 2017-02-08 04:36:12 --> Loader Class Initialized
INFO - 2017-02-08 04:36:12 --> Database Driver Class Initialized
INFO - 2017-02-08 04:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 04:36:12 --> Controller Class Initialized
INFO - 2017-02-08 04:36:12 --> Helper loaded: url_helper
DEBUG - 2017-02-08 04:36:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 04:36:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 04:36:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 04:36:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 04:36:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 04:36:12 --> Final output sent to browser
DEBUG - 2017-02-08 04:36:12 --> Total execution time: 0.0138
INFO - 2017-02-08 04:36:17 --> Config Class Initialized
INFO - 2017-02-08 04:36:17 --> Hooks Class Initialized
DEBUG - 2017-02-08 04:36:17 --> UTF-8 Support Enabled
INFO - 2017-02-08 04:36:17 --> Utf8 Class Initialized
INFO - 2017-02-08 04:36:17 --> URI Class Initialized
INFO - 2017-02-08 04:36:17 --> Router Class Initialized
INFO - 2017-02-08 04:36:17 --> Output Class Initialized
INFO - 2017-02-08 04:36:17 --> Security Class Initialized
DEBUG - 2017-02-08 04:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 04:36:17 --> Input Class Initialized
INFO - 2017-02-08 04:36:17 --> Language Class Initialized
INFO - 2017-02-08 04:36:17 --> Loader Class Initialized
INFO - 2017-02-08 04:36:17 --> Database Driver Class Initialized
INFO - 2017-02-08 04:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 04:36:17 --> Controller Class Initialized
INFO - 2017-02-08 04:36:17 --> Helper loaded: url_helper
DEBUG - 2017-02-08 04:36:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-08 04:36:19 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-08 04:36:19 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Fatty R. Ramos')
INFO - 2017-02-08 04:36:19 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-08 04:36:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-08 04:36:20 --> Config Class Initialized
INFO - 2017-02-08 04:36:20 --> Hooks Class Initialized
DEBUG - 2017-02-08 04:36:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 04:36:20 --> Utf8 Class Initialized
INFO - 2017-02-08 04:36:20 --> URI Class Initialized
INFO - 2017-02-08 04:36:20 --> Router Class Initialized
INFO - 2017-02-08 04:36:20 --> Output Class Initialized
INFO - 2017-02-08 04:36:20 --> Security Class Initialized
DEBUG - 2017-02-08 04:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 04:36:20 --> Input Class Initialized
INFO - 2017-02-08 04:36:20 --> Language Class Initialized
INFO - 2017-02-08 04:36:20 --> Loader Class Initialized
INFO - 2017-02-08 04:36:20 --> Database Driver Class Initialized
INFO - 2017-02-08 04:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 04:36:20 --> Controller Class Initialized
INFO - 2017-02-08 04:36:20 --> Helper loaded: url_helper
DEBUG - 2017-02-08 04:36:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 04:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 04:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 04:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 04:36:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 04:36:20 --> Final output sent to browser
DEBUG - 2017-02-08 04:36:20 --> Total execution time: 0.0134
INFO - 2017-02-08 05:10:44 --> Config Class Initialized
INFO - 2017-02-08 05:10:44 --> Hooks Class Initialized
DEBUG - 2017-02-08 05:10:45 --> UTF-8 Support Enabled
INFO - 2017-02-08 05:10:45 --> Utf8 Class Initialized
INFO - 2017-02-08 05:10:45 --> URI Class Initialized
DEBUG - 2017-02-08 05:10:45 --> No URI present. Default controller set.
INFO - 2017-02-08 05:10:45 --> Router Class Initialized
INFO - 2017-02-08 05:10:45 --> Output Class Initialized
INFO - 2017-02-08 05:10:45 --> Security Class Initialized
DEBUG - 2017-02-08 05:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 05:10:45 --> Input Class Initialized
INFO - 2017-02-08 05:10:45 --> Language Class Initialized
INFO - 2017-02-08 05:10:47 --> Loader Class Initialized
INFO - 2017-02-08 05:10:47 --> Database Driver Class Initialized
INFO - 2017-02-08 05:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 05:10:48 --> Controller Class Initialized
INFO - 2017-02-08 05:10:48 --> Helper loaded: url_helper
DEBUG - 2017-02-08 05:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 05:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 05:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 05:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 05:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 05:10:48 --> Final output sent to browser
DEBUG - 2017-02-08 05:10:48 --> Total execution time: 4.6346
INFO - 2017-02-08 05:11:44 --> Config Class Initialized
INFO - 2017-02-08 05:11:44 --> Hooks Class Initialized
DEBUG - 2017-02-08 05:11:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 05:11:44 --> Utf8 Class Initialized
INFO - 2017-02-08 05:11:44 --> URI Class Initialized
DEBUG - 2017-02-08 05:11:44 --> No URI present. Default controller set.
INFO - 2017-02-08 05:11:45 --> Router Class Initialized
INFO - 2017-02-08 05:11:45 --> Output Class Initialized
INFO - 2017-02-08 05:11:45 --> Security Class Initialized
DEBUG - 2017-02-08 05:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 05:11:45 --> Input Class Initialized
INFO - 2017-02-08 05:11:45 --> Language Class Initialized
INFO - 2017-02-08 05:11:45 --> Loader Class Initialized
INFO - 2017-02-08 05:11:45 --> Database Driver Class Initialized
INFO - 2017-02-08 05:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 05:11:45 --> Controller Class Initialized
INFO - 2017-02-08 05:11:45 --> Helper loaded: url_helper
DEBUG - 2017-02-08 05:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 05:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 05:11:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 05:11:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 05:11:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 05:11:46 --> Final output sent to browser
DEBUG - 2017-02-08 05:11:46 --> Total execution time: 1.3487
INFO - 2017-02-08 05:11:51 --> Config Class Initialized
INFO - 2017-02-08 05:11:51 --> Hooks Class Initialized
DEBUG - 2017-02-08 05:11:51 --> UTF-8 Support Enabled
INFO - 2017-02-08 05:11:51 --> Utf8 Class Initialized
INFO - 2017-02-08 05:11:51 --> URI Class Initialized
INFO - 2017-02-08 05:11:51 --> Router Class Initialized
INFO - 2017-02-08 05:11:51 --> Output Class Initialized
INFO - 2017-02-08 05:11:51 --> Security Class Initialized
DEBUG - 2017-02-08 05:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 05:11:51 --> Input Class Initialized
INFO - 2017-02-08 05:11:51 --> Language Class Initialized
INFO - 2017-02-08 05:11:51 --> Loader Class Initialized
INFO - 2017-02-08 05:11:51 --> Database Driver Class Initialized
INFO - 2017-02-08 05:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 05:11:51 --> Controller Class Initialized
INFO - 2017-02-08 05:11:51 --> Helper loaded: url_helper
DEBUG - 2017-02-08 05:11:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 05:11:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 05:11:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 05:11:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 05:11:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 05:11:51 --> Final output sent to browser
DEBUG - 2017-02-08 05:11:51 --> Total execution time: 0.0138
INFO - 2017-02-08 07:24:37 --> Config Class Initialized
INFO - 2017-02-08 07:24:37 --> Hooks Class Initialized
DEBUG - 2017-02-08 07:24:37 --> UTF-8 Support Enabled
INFO - 2017-02-08 07:24:37 --> Utf8 Class Initialized
INFO - 2017-02-08 07:24:37 --> URI Class Initialized
DEBUG - 2017-02-08 07:24:37 --> No URI present. Default controller set.
INFO - 2017-02-08 07:24:37 --> Router Class Initialized
INFO - 2017-02-08 07:24:37 --> Output Class Initialized
INFO - 2017-02-08 07:24:37 --> Security Class Initialized
DEBUG - 2017-02-08 07:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 07:24:37 --> Input Class Initialized
INFO - 2017-02-08 07:24:37 --> Language Class Initialized
INFO - 2017-02-08 07:24:37 --> Loader Class Initialized
INFO - 2017-02-08 07:24:38 --> Database Driver Class Initialized
INFO - 2017-02-08 07:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 07:24:38 --> Controller Class Initialized
INFO - 2017-02-08 07:24:38 --> Helper loaded: url_helper
DEBUG - 2017-02-08 07:24:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 07:24:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 07:24:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 07:24:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 07:24:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 07:24:38 --> Final output sent to browser
DEBUG - 2017-02-08 07:24:38 --> Total execution time: 1.2670
INFO - 2017-02-08 07:24:53 --> Config Class Initialized
INFO - 2017-02-08 07:24:53 --> Hooks Class Initialized
DEBUG - 2017-02-08 07:24:53 --> UTF-8 Support Enabled
INFO - 2017-02-08 07:24:53 --> Utf8 Class Initialized
INFO - 2017-02-08 07:24:53 --> URI Class Initialized
INFO - 2017-02-08 07:24:53 --> Router Class Initialized
INFO - 2017-02-08 07:24:53 --> Output Class Initialized
INFO - 2017-02-08 07:24:53 --> Security Class Initialized
DEBUG - 2017-02-08 07:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 07:24:53 --> Input Class Initialized
INFO - 2017-02-08 07:24:53 --> Language Class Initialized
INFO - 2017-02-08 07:24:53 --> Loader Class Initialized
INFO - 2017-02-08 07:24:53 --> Database Driver Class Initialized
INFO - 2017-02-08 07:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 07:24:53 --> Controller Class Initialized
INFO - 2017-02-08 07:24:53 --> Helper loaded: url_helper
DEBUG - 2017-02-08 07:24:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 07:24:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 07:24:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 07:24:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 07:24:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 07:24:53 --> Final output sent to browser
DEBUG - 2017-02-08 07:24:53 --> Total execution time: 0.0134
INFO - 2017-02-08 07:54:15 --> Config Class Initialized
INFO - 2017-02-08 07:54:15 --> Hooks Class Initialized
DEBUG - 2017-02-08 07:54:15 --> UTF-8 Support Enabled
INFO - 2017-02-08 07:54:15 --> Utf8 Class Initialized
INFO - 2017-02-08 07:54:15 --> URI Class Initialized
DEBUG - 2017-02-08 07:54:15 --> No URI present. Default controller set.
INFO - 2017-02-08 07:54:15 --> Router Class Initialized
INFO - 2017-02-08 07:54:15 --> Output Class Initialized
INFO - 2017-02-08 07:54:15 --> Security Class Initialized
DEBUG - 2017-02-08 07:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 07:54:15 --> Input Class Initialized
INFO - 2017-02-08 07:54:15 --> Language Class Initialized
INFO - 2017-02-08 07:54:15 --> Loader Class Initialized
INFO - 2017-02-08 07:54:16 --> Database Driver Class Initialized
INFO - 2017-02-08 07:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 07:54:16 --> Controller Class Initialized
INFO - 2017-02-08 07:54:16 --> Helper loaded: url_helper
DEBUG - 2017-02-08 07:54:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 07:54:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 07:54:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 07:54:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 07:54:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 07:54:16 --> Final output sent to browser
DEBUG - 2017-02-08 07:54:16 --> Total execution time: 1.2256
INFO - 2017-02-08 07:54:21 --> Config Class Initialized
INFO - 2017-02-08 07:54:21 --> Hooks Class Initialized
DEBUG - 2017-02-08 07:54:21 --> UTF-8 Support Enabled
INFO - 2017-02-08 07:54:21 --> Utf8 Class Initialized
INFO - 2017-02-08 07:54:21 --> URI Class Initialized
INFO - 2017-02-08 07:54:21 --> Router Class Initialized
INFO - 2017-02-08 07:54:21 --> Output Class Initialized
INFO - 2017-02-08 07:54:21 --> Security Class Initialized
DEBUG - 2017-02-08 07:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 07:54:21 --> Input Class Initialized
INFO - 2017-02-08 07:54:21 --> Language Class Initialized
INFO - 2017-02-08 07:54:21 --> Loader Class Initialized
INFO - 2017-02-08 07:54:21 --> Database Driver Class Initialized
INFO - 2017-02-08 07:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 07:54:21 --> Controller Class Initialized
INFO - 2017-02-08 07:54:21 --> Helper loaded: url_helper
DEBUG - 2017-02-08 07:54:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 07:54:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 07:54:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 07:54:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 07:54:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 07:54:21 --> Final output sent to browser
DEBUG - 2017-02-08 07:54:21 --> Total execution time: 0.0130
INFO - 2017-02-08 12:55:41 --> Config Class Initialized
INFO - 2017-02-08 12:55:41 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:55:41 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:55:41 --> Utf8 Class Initialized
INFO - 2017-02-08 12:55:41 --> URI Class Initialized
INFO - 2017-02-08 12:55:41 --> Router Class Initialized
INFO - 2017-02-08 12:55:41 --> Output Class Initialized
INFO - 2017-02-08 12:55:41 --> Security Class Initialized
DEBUG - 2017-02-08 12:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:55:41 --> Input Class Initialized
INFO - 2017-02-08 12:55:41 --> Language Class Initialized
INFO - 2017-02-08 12:55:41 --> Loader Class Initialized
INFO - 2017-02-08 12:55:41 --> Database Driver Class Initialized
INFO - 2017-02-08 12:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:55:42 --> Controller Class Initialized
INFO - 2017-02-08 12:55:42 --> Helper loaded: url_helper
DEBUG - 2017-02-08 12:55:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 12:55:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 12:55:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 12:55:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 12:55:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 12:55:42 --> Final output sent to browser
DEBUG - 2017-02-08 12:55:42 --> Total execution time: 1.5087
INFO - 2017-02-08 12:56:17 --> Config Class Initialized
INFO - 2017-02-08 12:56:17 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:56:17 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:56:17 --> Utf8 Class Initialized
INFO - 2017-02-08 12:56:17 --> URI Class Initialized
DEBUG - 2017-02-08 12:56:17 --> No URI present. Default controller set.
INFO - 2017-02-08 12:56:17 --> Router Class Initialized
INFO - 2017-02-08 12:56:17 --> Output Class Initialized
INFO - 2017-02-08 12:56:17 --> Security Class Initialized
DEBUG - 2017-02-08 12:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:56:17 --> Input Class Initialized
INFO - 2017-02-08 12:56:17 --> Language Class Initialized
INFO - 2017-02-08 12:56:17 --> Loader Class Initialized
INFO - 2017-02-08 12:56:17 --> Database Driver Class Initialized
INFO - 2017-02-08 12:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:56:17 --> Controller Class Initialized
INFO - 2017-02-08 12:56:17 --> Helper loaded: url_helper
DEBUG - 2017-02-08 12:56:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 12:56:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 12:56:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 12:56:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 12:56:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 12:56:17 --> Final output sent to browser
DEBUG - 2017-02-08 12:56:17 --> Total execution time: 0.0132
INFO - 2017-02-08 15:20:21 --> Config Class Initialized
INFO - 2017-02-08 15:20:22 --> Hooks Class Initialized
DEBUG - 2017-02-08 15:20:22 --> UTF-8 Support Enabled
INFO - 2017-02-08 15:20:22 --> Utf8 Class Initialized
INFO - 2017-02-08 15:20:22 --> URI Class Initialized
INFO - 2017-02-08 15:20:22 --> Router Class Initialized
INFO - 2017-02-08 15:20:22 --> Output Class Initialized
INFO - 2017-02-08 15:20:22 --> Security Class Initialized
DEBUG - 2017-02-08 15:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 15:20:22 --> Input Class Initialized
INFO - 2017-02-08 15:20:22 --> Language Class Initialized
INFO - 2017-02-08 15:20:22 --> Loader Class Initialized
INFO - 2017-02-08 15:20:23 --> Database Driver Class Initialized
INFO - 2017-02-08 15:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 15:20:23 --> Controller Class Initialized
INFO - 2017-02-08 15:20:23 --> Helper loaded: url_helper
DEBUG - 2017-02-08 15:20:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 15:20:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 15:20:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 15:20:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 15:20:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 15:20:23 --> Final output sent to browser
DEBUG - 2017-02-08 15:20:23 --> Total execution time: 1.9210
INFO - 2017-02-08 15:20:23 --> Config Class Initialized
INFO - 2017-02-08 15:20:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 15:20:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 15:20:23 --> Utf8 Class Initialized
INFO - 2017-02-08 15:20:23 --> URI Class Initialized
DEBUG - 2017-02-08 15:20:23 --> No URI present. Default controller set.
INFO - 2017-02-08 15:20:23 --> Router Class Initialized
INFO - 2017-02-08 15:20:23 --> Output Class Initialized
INFO - 2017-02-08 15:20:23 --> Security Class Initialized
DEBUG - 2017-02-08 15:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 15:20:23 --> Input Class Initialized
INFO - 2017-02-08 15:20:23 --> Language Class Initialized
INFO - 2017-02-08 15:20:23 --> Loader Class Initialized
INFO - 2017-02-08 15:20:23 --> Database Driver Class Initialized
INFO - 2017-02-08 15:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 15:20:23 --> Controller Class Initialized
INFO - 2017-02-08 15:20:23 --> Helper loaded: url_helper
DEBUG - 2017-02-08 15:20:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 15:20:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 15:20:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 15:20:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 15:20:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 15:20:23 --> Final output sent to browser
DEBUG - 2017-02-08 15:20:23 --> Total execution time: 0.0146
INFO - 2017-02-08 15:24:38 --> Config Class Initialized
INFO - 2017-02-08 15:24:38 --> Hooks Class Initialized
DEBUG - 2017-02-08 15:24:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 15:24:38 --> Utf8 Class Initialized
INFO - 2017-02-08 15:24:38 --> URI Class Initialized
INFO - 2017-02-08 15:24:38 --> Router Class Initialized
INFO - 2017-02-08 15:24:38 --> Output Class Initialized
INFO - 2017-02-08 15:24:38 --> Security Class Initialized
DEBUG - 2017-02-08 15:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 15:24:38 --> Input Class Initialized
INFO - 2017-02-08 15:24:38 --> Language Class Initialized
INFO - 2017-02-08 15:24:38 --> Loader Class Initialized
INFO - 2017-02-08 15:24:38 --> Database Driver Class Initialized
INFO - 2017-02-08 15:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 15:24:39 --> Controller Class Initialized
INFO - 2017-02-08 15:24:39 --> Helper loaded: url_helper
DEBUG - 2017-02-08 15:24:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 15:24:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 15:24:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 15:24:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 15:24:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 15:24:39 --> Final output sent to browser
DEBUG - 2017-02-08 15:24:39 --> Total execution time: 1.6626
INFO - 2017-02-08 15:24:40 --> Config Class Initialized
INFO - 2017-02-08 15:24:40 --> Hooks Class Initialized
DEBUG - 2017-02-08 15:24:40 --> UTF-8 Support Enabled
INFO - 2017-02-08 15:24:40 --> Utf8 Class Initialized
INFO - 2017-02-08 15:24:40 --> URI Class Initialized
DEBUG - 2017-02-08 15:24:40 --> No URI present. Default controller set.
INFO - 2017-02-08 15:24:40 --> Router Class Initialized
INFO - 2017-02-08 15:24:40 --> Output Class Initialized
INFO - 2017-02-08 15:24:40 --> Security Class Initialized
DEBUG - 2017-02-08 15:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 15:24:40 --> Input Class Initialized
INFO - 2017-02-08 15:24:40 --> Language Class Initialized
INFO - 2017-02-08 15:24:40 --> Loader Class Initialized
INFO - 2017-02-08 15:24:40 --> Database Driver Class Initialized
INFO - 2017-02-08 15:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 15:24:40 --> Controller Class Initialized
INFO - 2017-02-08 15:24:40 --> Helper loaded: url_helper
DEBUG - 2017-02-08 15:24:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 15:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 15:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 15:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 15:24:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 15:24:40 --> Final output sent to browser
DEBUG - 2017-02-08 15:24:40 --> Total execution time: 0.0158
INFO - 2017-02-08 15:26:02 --> Config Class Initialized
INFO - 2017-02-08 15:26:02 --> Hooks Class Initialized
DEBUG - 2017-02-08 15:26:02 --> UTF-8 Support Enabled
INFO - 2017-02-08 15:26:02 --> Utf8 Class Initialized
INFO - 2017-02-08 15:26:02 --> URI Class Initialized
DEBUG - 2017-02-08 15:26:02 --> No URI present. Default controller set.
INFO - 2017-02-08 15:26:02 --> Router Class Initialized
INFO - 2017-02-08 15:26:02 --> Output Class Initialized
INFO - 2017-02-08 15:26:02 --> Security Class Initialized
DEBUG - 2017-02-08 15:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 15:26:02 --> Input Class Initialized
INFO - 2017-02-08 15:26:02 --> Language Class Initialized
INFO - 2017-02-08 15:26:02 --> Loader Class Initialized
INFO - 2017-02-08 15:26:03 --> Database Driver Class Initialized
INFO - 2017-02-08 15:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 15:26:03 --> Controller Class Initialized
INFO - 2017-02-08 15:26:03 --> Helper loaded: url_helper
DEBUG - 2017-02-08 15:26:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 15:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 15:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 15:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 15:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 15:26:03 --> Final output sent to browser
DEBUG - 2017-02-08 15:26:03 --> Total execution time: 0.0590
INFO - 2017-02-08 16:27:37 --> Config Class Initialized
INFO - 2017-02-08 16:27:37 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:27:37 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:27:37 --> Utf8 Class Initialized
INFO - 2017-02-08 16:27:37 --> URI Class Initialized
DEBUG - 2017-02-08 16:27:37 --> No URI present. Default controller set.
INFO - 2017-02-08 16:27:37 --> Router Class Initialized
INFO - 2017-02-08 16:27:37 --> Output Class Initialized
INFO - 2017-02-08 16:27:37 --> Security Class Initialized
DEBUG - 2017-02-08 16:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:27:37 --> Input Class Initialized
INFO - 2017-02-08 16:27:37 --> Language Class Initialized
INFO - 2017-02-08 16:27:37 --> Loader Class Initialized
INFO - 2017-02-08 16:27:38 --> Database Driver Class Initialized
INFO - 2017-02-08 16:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:27:38 --> Controller Class Initialized
INFO - 2017-02-08 16:27:38 --> Helper loaded: url_helper
DEBUG - 2017-02-08 16:27:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 16:27:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 16:27:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 16:27:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 16:27:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 16:27:38 --> Final output sent to browser
DEBUG - 2017-02-08 16:27:38 --> Total execution time: 1.7498
INFO - 2017-02-08 16:27:43 --> Config Class Initialized
INFO - 2017-02-08 16:27:43 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:27:43 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:27:43 --> Utf8 Class Initialized
INFO - 2017-02-08 16:27:43 --> URI Class Initialized
INFO - 2017-02-08 16:27:43 --> Router Class Initialized
INFO - 2017-02-08 16:27:43 --> Output Class Initialized
INFO - 2017-02-08 16:27:43 --> Security Class Initialized
DEBUG - 2017-02-08 16:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:27:43 --> Input Class Initialized
INFO - 2017-02-08 16:27:43 --> Language Class Initialized
INFO - 2017-02-08 16:27:43 --> Loader Class Initialized
INFO - 2017-02-08 16:27:43 --> Database Driver Class Initialized
INFO - 2017-02-08 16:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:27:43 --> Controller Class Initialized
INFO - 2017-02-08 16:27:43 --> Helper loaded: url_helper
DEBUG - 2017-02-08 16:27:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 16:27:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 16:27:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 16:27:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 16:27:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 16:27:43 --> Final output sent to browser
DEBUG - 2017-02-08 16:27:43 --> Total execution time: 0.1028
INFO - 2017-02-08 17:52:24 --> Config Class Initialized
INFO - 2017-02-08 17:52:24 --> Hooks Class Initialized
DEBUG - 2017-02-08 17:52:24 --> UTF-8 Support Enabled
INFO - 2017-02-08 17:52:24 --> Utf8 Class Initialized
INFO - 2017-02-08 17:52:24 --> URI Class Initialized
DEBUG - 2017-02-08 17:52:24 --> No URI present. Default controller set.
INFO - 2017-02-08 17:52:24 --> Router Class Initialized
INFO - 2017-02-08 17:52:24 --> Output Class Initialized
INFO - 2017-02-08 17:52:24 --> Security Class Initialized
DEBUG - 2017-02-08 17:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 17:52:24 --> Input Class Initialized
INFO - 2017-02-08 17:52:24 --> Language Class Initialized
INFO - 2017-02-08 17:52:24 --> Loader Class Initialized
INFO - 2017-02-08 17:52:24 --> Database Driver Class Initialized
INFO - 2017-02-08 17:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 17:52:24 --> Controller Class Initialized
INFO - 2017-02-08 17:52:24 --> Helper loaded: url_helper
DEBUG - 2017-02-08 17:52:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 17:52:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 17:52:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 17:52:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 17:52:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 17:52:24 --> Final output sent to browser
DEBUG - 2017-02-08 17:52:24 --> Total execution time: 0.0277
INFO - 2017-02-08 17:52:29 --> Config Class Initialized
INFO - 2017-02-08 17:52:29 --> Hooks Class Initialized
DEBUG - 2017-02-08 17:52:29 --> UTF-8 Support Enabled
INFO - 2017-02-08 17:52:29 --> Utf8 Class Initialized
INFO - 2017-02-08 17:52:29 --> URI Class Initialized
INFO - 2017-02-08 17:52:29 --> Router Class Initialized
INFO - 2017-02-08 17:52:29 --> Output Class Initialized
INFO - 2017-02-08 17:52:29 --> Security Class Initialized
DEBUG - 2017-02-08 17:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 17:52:29 --> Input Class Initialized
INFO - 2017-02-08 17:52:29 --> Language Class Initialized
INFO - 2017-02-08 17:52:29 --> Loader Class Initialized
INFO - 2017-02-08 17:52:29 --> Database Driver Class Initialized
INFO - 2017-02-08 17:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 17:52:29 --> Controller Class Initialized
INFO - 2017-02-08 17:52:29 --> Helper loaded: url_helper
DEBUG - 2017-02-08 17:52:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 17:52:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 17:52:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 17:52:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 17:52:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 17:52:29 --> Final output sent to browser
DEBUG - 2017-02-08 17:52:29 --> Total execution time: 0.0139
INFO - 2017-02-08 17:53:42 --> Config Class Initialized
INFO - 2017-02-08 17:53:42 --> Hooks Class Initialized
DEBUG - 2017-02-08 17:53:42 --> UTF-8 Support Enabled
INFO - 2017-02-08 17:53:42 --> Utf8 Class Initialized
INFO - 2017-02-08 17:53:42 --> URI Class Initialized
INFO - 2017-02-08 17:53:42 --> Router Class Initialized
INFO - 2017-02-08 17:53:42 --> Output Class Initialized
INFO - 2017-02-08 17:53:42 --> Security Class Initialized
DEBUG - 2017-02-08 17:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 17:53:42 --> Input Class Initialized
INFO - 2017-02-08 17:53:42 --> Language Class Initialized
INFO - 2017-02-08 17:53:42 --> Loader Class Initialized
INFO - 2017-02-08 17:53:42 --> Database Driver Class Initialized
INFO - 2017-02-08 17:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 17:53:42 --> Controller Class Initialized
INFO - 2017-02-08 17:53:42 --> Helper loaded: url_helper
DEBUG - 2017-02-08 17:53:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 17:53:45 --> Config Class Initialized
INFO - 2017-02-08 17:53:45 --> Hooks Class Initialized
DEBUG - 2017-02-08 17:53:45 --> UTF-8 Support Enabled
INFO - 2017-02-08 17:53:45 --> Utf8 Class Initialized
INFO - 2017-02-08 17:53:45 --> URI Class Initialized
INFO - 2017-02-08 17:53:45 --> Router Class Initialized
INFO - 2017-02-08 17:53:45 --> Output Class Initialized
INFO - 2017-02-08 17:53:45 --> Security Class Initialized
DEBUG - 2017-02-08 17:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 17:53:45 --> Input Class Initialized
INFO - 2017-02-08 17:53:45 --> Language Class Initialized
INFO - 2017-02-08 17:53:45 --> Loader Class Initialized
INFO - 2017-02-08 17:53:45 --> Database Driver Class Initialized
INFO - 2017-02-08 17:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 17:53:45 --> Controller Class Initialized
INFO - 2017-02-08 17:53:45 --> Helper loaded: date_helper
DEBUG - 2017-02-08 17:53:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 17:53:45 --> Helper loaded: url_helper
INFO - 2017-02-08 17:53:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 17:53:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-08 17:53:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-08 17:53:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-08 17:53:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 17:53:46 --> Final output sent to browser
DEBUG - 2017-02-08 17:53:46 --> Total execution time: 0.5182
INFO - 2017-02-08 17:53:47 --> Config Class Initialized
INFO - 2017-02-08 17:53:47 --> Hooks Class Initialized
DEBUG - 2017-02-08 17:53:47 --> UTF-8 Support Enabled
INFO - 2017-02-08 17:53:47 --> Utf8 Class Initialized
INFO - 2017-02-08 17:53:47 --> URI Class Initialized
INFO - 2017-02-08 17:53:47 --> Router Class Initialized
INFO - 2017-02-08 17:53:47 --> Output Class Initialized
INFO - 2017-02-08 17:53:47 --> Security Class Initialized
DEBUG - 2017-02-08 17:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 17:53:47 --> Input Class Initialized
INFO - 2017-02-08 17:53:47 --> Language Class Initialized
INFO - 2017-02-08 17:53:47 --> Loader Class Initialized
INFO - 2017-02-08 17:53:47 --> Database Driver Class Initialized
INFO - 2017-02-08 17:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 17:53:47 --> Controller Class Initialized
INFO - 2017-02-08 17:53:47 --> Helper loaded: url_helper
DEBUG - 2017-02-08 17:53:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 17:53:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 17:53:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 17:53:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 17:53:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 17:53:47 --> Final output sent to browser
DEBUG - 2017-02-08 17:53:47 --> Total execution time: 0.0140
INFO - 2017-02-08 17:53:56 --> Config Class Initialized
INFO - 2017-02-08 17:53:56 --> Hooks Class Initialized
DEBUG - 2017-02-08 17:53:56 --> UTF-8 Support Enabled
INFO - 2017-02-08 17:53:56 --> Utf8 Class Initialized
INFO - 2017-02-08 17:53:56 --> URI Class Initialized
INFO - 2017-02-08 17:53:56 --> Router Class Initialized
INFO - 2017-02-08 17:53:56 --> Output Class Initialized
INFO - 2017-02-08 17:53:56 --> Security Class Initialized
DEBUG - 2017-02-08 17:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 17:53:56 --> Input Class Initialized
INFO - 2017-02-08 17:53:56 --> Language Class Initialized
INFO - 2017-02-08 17:53:56 --> Loader Class Initialized
INFO - 2017-02-08 17:53:56 --> Database Driver Class Initialized
INFO - 2017-02-08 17:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 17:53:56 --> Controller Class Initialized
INFO - 2017-02-08 17:53:56 --> Helper loaded: url_helper
DEBUG - 2017-02-08 17:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 17:53:57 --> Config Class Initialized
INFO - 2017-02-08 17:53:57 --> Hooks Class Initialized
DEBUG - 2017-02-08 17:53:57 --> UTF-8 Support Enabled
INFO - 2017-02-08 17:53:57 --> Utf8 Class Initialized
INFO - 2017-02-08 17:53:57 --> URI Class Initialized
INFO - 2017-02-08 17:53:57 --> Router Class Initialized
INFO - 2017-02-08 17:53:57 --> Output Class Initialized
INFO - 2017-02-08 17:53:57 --> Security Class Initialized
DEBUG - 2017-02-08 17:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 17:53:57 --> Input Class Initialized
INFO - 2017-02-08 17:53:57 --> Language Class Initialized
INFO - 2017-02-08 17:53:57 --> Loader Class Initialized
INFO - 2017-02-08 17:53:57 --> Database Driver Class Initialized
INFO - 2017-02-08 17:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 17:53:57 --> Controller Class Initialized
INFO - 2017-02-08 17:53:57 --> Helper loaded: date_helper
DEBUG - 2017-02-08 17:53:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 17:53:57 --> Helper loaded: url_helper
INFO - 2017-02-08 17:53:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 17:53:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-08 17:53:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-08 17:53:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-08 17:53:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 17:53:57 --> Final output sent to browser
DEBUG - 2017-02-08 17:53:57 --> Total execution time: 0.0138
INFO - 2017-02-08 17:53:58 --> Config Class Initialized
INFO - 2017-02-08 17:53:58 --> Hooks Class Initialized
DEBUG - 2017-02-08 17:53:58 --> UTF-8 Support Enabled
INFO - 2017-02-08 17:53:58 --> Utf8 Class Initialized
INFO - 2017-02-08 17:53:58 --> URI Class Initialized
INFO - 2017-02-08 17:53:58 --> Router Class Initialized
INFO - 2017-02-08 17:53:58 --> Output Class Initialized
INFO - 2017-02-08 17:53:58 --> Security Class Initialized
DEBUG - 2017-02-08 17:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 17:53:58 --> Input Class Initialized
INFO - 2017-02-08 17:53:58 --> Language Class Initialized
INFO - 2017-02-08 17:53:58 --> Loader Class Initialized
INFO - 2017-02-08 17:53:58 --> Database Driver Class Initialized
INFO - 2017-02-08 17:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 17:53:58 --> Controller Class Initialized
INFO - 2017-02-08 17:53:58 --> Helper loaded: url_helper
DEBUG - 2017-02-08 17:53:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 17:53:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 17:53:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 17:53:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 17:53:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 17:53:58 --> Final output sent to browser
DEBUG - 2017-02-08 17:53:58 --> Total execution time: 0.0134
INFO - 2017-02-08 17:54:04 --> Config Class Initialized
INFO - 2017-02-08 17:54:04 --> Hooks Class Initialized
DEBUG - 2017-02-08 17:54:04 --> UTF-8 Support Enabled
INFO - 2017-02-08 17:54:04 --> Utf8 Class Initialized
INFO - 2017-02-08 17:54:04 --> URI Class Initialized
INFO - 2017-02-08 17:54:04 --> Router Class Initialized
INFO - 2017-02-08 17:54:04 --> Output Class Initialized
INFO - 2017-02-08 17:54:04 --> Security Class Initialized
DEBUG - 2017-02-08 17:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 17:54:04 --> Input Class Initialized
INFO - 2017-02-08 17:54:04 --> Language Class Initialized
INFO - 2017-02-08 17:54:04 --> Loader Class Initialized
INFO - 2017-02-08 17:54:04 --> Database Driver Class Initialized
INFO - 2017-02-08 17:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 17:54:04 --> Controller Class Initialized
INFO - 2017-02-08 17:54:04 --> Helper loaded: url_helper
DEBUG - 2017-02-08 17:54:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 17:54:04 --> Config Class Initialized
INFO - 2017-02-08 17:54:04 --> Hooks Class Initialized
DEBUG - 2017-02-08 17:54:04 --> UTF-8 Support Enabled
INFO - 2017-02-08 17:54:04 --> Utf8 Class Initialized
INFO - 2017-02-08 17:54:04 --> URI Class Initialized
INFO - 2017-02-08 17:54:04 --> Router Class Initialized
INFO - 2017-02-08 17:54:04 --> Output Class Initialized
INFO - 2017-02-08 17:54:04 --> Security Class Initialized
DEBUG - 2017-02-08 17:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 17:54:04 --> Input Class Initialized
INFO - 2017-02-08 17:54:04 --> Language Class Initialized
INFO - 2017-02-08 17:54:04 --> Loader Class Initialized
INFO - 2017-02-08 17:54:04 --> Database Driver Class Initialized
INFO - 2017-02-08 17:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 17:54:04 --> Controller Class Initialized
INFO - 2017-02-08 17:54:04 --> Helper loaded: date_helper
DEBUG - 2017-02-08 17:54:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 17:54:04 --> Helper loaded: url_helper
INFO - 2017-02-08 17:54:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 17:54:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-08 17:54:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-08 17:54:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-08 17:54:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 17:54:04 --> Final output sent to browser
DEBUG - 2017-02-08 17:54:04 --> Total execution time: 0.0131
INFO - 2017-02-08 17:54:05 --> Config Class Initialized
INFO - 2017-02-08 17:54:05 --> Hooks Class Initialized
DEBUG - 2017-02-08 17:54:05 --> UTF-8 Support Enabled
INFO - 2017-02-08 17:54:05 --> Utf8 Class Initialized
INFO - 2017-02-08 17:54:05 --> URI Class Initialized
INFO - 2017-02-08 17:54:05 --> Router Class Initialized
INFO - 2017-02-08 17:54:05 --> Output Class Initialized
INFO - 2017-02-08 17:54:05 --> Security Class Initialized
DEBUG - 2017-02-08 17:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 17:54:05 --> Input Class Initialized
INFO - 2017-02-08 17:54:05 --> Language Class Initialized
INFO - 2017-02-08 17:54:05 --> Loader Class Initialized
INFO - 2017-02-08 17:54:05 --> Database Driver Class Initialized
INFO - 2017-02-08 17:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 17:54:05 --> Controller Class Initialized
INFO - 2017-02-08 17:54:05 --> Helper loaded: url_helper
DEBUG - 2017-02-08 17:54:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 17:54:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 17:54:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 17:54:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 17:54:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 17:54:05 --> Final output sent to browser
DEBUG - 2017-02-08 17:54:05 --> Total execution time: 0.0137
INFO - 2017-02-08 17:54:54 --> Config Class Initialized
INFO - 2017-02-08 17:54:54 --> Hooks Class Initialized
DEBUG - 2017-02-08 17:54:54 --> UTF-8 Support Enabled
INFO - 2017-02-08 17:54:54 --> Utf8 Class Initialized
INFO - 2017-02-08 17:54:54 --> URI Class Initialized
DEBUG - 2017-02-08 17:54:54 --> No URI present. Default controller set.
INFO - 2017-02-08 17:54:54 --> Router Class Initialized
INFO - 2017-02-08 17:54:54 --> Output Class Initialized
INFO - 2017-02-08 17:54:54 --> Security Class Initialized
DEBUG - 2017-02-08 17:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 17:54:54 --> Input Class Initialized
INFO - 2017-02-08 17:54:54 --> Language Class Initialized
INFO - 2017-02-08 17:54:54 --> Loader Class Initialized
INFO - 2017-02-08 17:54:54 --> Database Driver Class Initialized
INFO - 2017-02-08 17:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 17:54:54 --> Controller Class Initialized
INFO - 2017-02-08 17:54:54 --> Helper loaded: url_helper
DEBUG - 2017-02-08 17:54:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 17:54:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 17:54:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 17:54:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 17:54:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 17:54:54 --> Final output sent to browser
DEBUG - 2017-02-08 17:54:54 --> Total execution time: 0.0133
INFO - 2017-02-08 17:54:56 --> Config Class Initialized
INFO - 2017-02-08 17:54:56 --> Hooks Class Initialized
DEBUG - 2017-02-08 17:54:56 --> UTF-8 Support Enabled
INFO - 2017-02-08 17:54:56 --> Utf8 Class Initialized
INFO - 2017-02-08 17:54:56 --> URI Class Initialized
INFO - 2017-02-08 17:54:56 --> Router Class Initialized
INFO - 2017-02-08 17:54:56 --> Output Class Initialized
INFO - 2017-02-08 17:54:56 --> Security Class Initialized
DEBUG - 2017-02-08 17:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 17:54:56 --> Input Class Initialized
INFO - 2017-02-08 17:54:56 --> Language Class Initialized
INFO - 2017-02-08 17:54:56 --> Loader Class Initialized
INFO - 2017-02-08 17:54:56 --> Database Driver Class Initialized
INFO - 2017-02-08 17:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 17:54:56 --> Controller Class Initialized
INFO - 2017-02-08 17:54:56 --> Helper loaded: url_helper
DEBUG - 2017-02-08 17:54:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 17:54:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 17:54:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 17:54:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 17:54:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 17:54:56 --> Final output sent to browser
DEBUG - 2017-02-08 17:54:56 --> Total execution time: 0.0243
INFO - 2017-02-08 17:55:27 --> Config Class Initialized
INFO - 2017-02-08 17:55:27 --> Hooks Class Initialized
DEBUG - 2017-02-08 17:55:27 --> UTF-8 Support Enabled
INFO - 2017-02-08 17:55:27 --> Utf8 Class Initialized
INFO - 2017-02-08 17:55:27 --> URI Class Initialized
INFO - 2017-02-08 17:55:27 --> Router Class Initialized
INFO - 2017-02-08 17:55:27 --> Output Class Initialized
INFO - 2017-02-08 17:55:27 --> Security Class Initialized
DEBUG - 2017-02-08 17:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 17:55:27 --> Input Class Initialized
INFO - 2017-02-08 17:55:27 --> Language Class Initialized
INFO - 2017-02-08 17:55:27 --> Loader Class Initialized
INFO - 2017-02-08 17:55:27 --> Database Driver Class Initialized
INFO - 2017-02-08 17:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 17:55:27 --> Controller Class Initialized
INFO - 2017-02-08 17:55:27 --> Helper loaded: url_helper
DEBUG - 2017-02-08 17:55:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 17:55:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 17:55:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 17:55:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 17:55:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 17:55:27 --> Final output sent to browser
DEBUG - 2017-02-08 17:55:27 --> Total execution time: 0.0143
INFO - 2017-02-08 17:55:29 --> Config Class Initialized
INFO - 2017-02-08 17:55:29 --> Hooks Class Initialized
DEBUG - 2017-02-08 17:55:29 --> UTF-8 Support Enabled
INFO - 2017-02-08 17:55:29 --> Utf8 Class Initialized
INFO - 2017-02-08 17:55:29 --> URI Class Initialized
INFO - 2017-02-08 17:55:29 --> Router Class Initialized
INFO - 2017-02-08 17:55:29 --> Output Class Initialized
INFO - 2017-02-08 17:55:29 --> Security Class Initialized
DEBUG - 2017-02-08 17:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 17:55:29 --> Input Class Initialized
INFO - 2017-02-08 17:55:29 --> Language Class Initialized
INFO - 2017-02-08 17:55:29 --> Loader Class Initialized
INFO - 2017-02-08 17:55:29 --> Database Driver Class Initialized
INFO - 2017-02-08 17:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 17:55:29 --> Controller Class Initialized
INFO - 2017-02-08 17:55:29 --> Helper loaded: url_helper
DEBUG - 2017-02-08 17:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 17:55:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 17:55:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 17:55:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 17:55:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 17:55:29 --> Final output sent to browser
DEBUG - 2017-02-08 17:55:29 --> Total execution time: 0.0302
INFO - 2017-02-08 17:56:01 --> Config Class Initialized
INFO - 2017-02-08 17:56:01 --> Hooks Class Initialized
DEBUG - 2017-02-08 17:56:01 --> UTF-8 Support Enabled
INFO - 2017-02-08 17:56:01 --> Utf8 Class Initialized
INFO - 2017-02-08 17:56:01 --> URI Class Initialized
INFO - 2017-02-08 17:56:01 --> Router Class Initialized
INFO - 2017-02-08 17:56:01 --> Output Class Initialized
INFO - 2017-02-08 17:56:01 --> Security Class Initialized
DEBUG - 2017-02-08 17:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 17:56:01 --> Input Class Initialized
INFO - 2017-02-08 17:56:01 --> Language Class Initialized
INFO - 2017-02-08 17:56:01 --> Loader Class Initialized
INFO - 2017-02-08 17:56:01 --> Database Driver Class Initialized
INFO - 2017-02-08 17:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 17:56:01 --> Controller Class Initialized
INFO - 2017-02-08 17:56:01 --> Helper loaded: url_helper
DEBUG - 2017-02-08 17:56:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 17:56:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 17:56:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 17:56:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 17:56:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 17:56:01 --> Final output sent to browser
DEBUG - 2017-02-08 17:56:01 --> Total execution time: 0.0146
INFO - 2017-02-08 17:56:02 --> Config Class Initialized
INFO - 2017-02-08 17:56:02 --> Hooks Class Initialized
DEBUG - 2017-02-08 17:56:02 --> UTF-8 Support Enabled
INFO - 2017-02-08 17:56:02 --> Utf8 Class Initialized
INFO - 2017-02-08 17:56:02 --> URI Class Initialized
INFO - 2017-02-08 17:56:02 --> Router Class Initialized
INFO - 2017-02-08 17:56:02 --> Output Class Initialized
INFO - 2017-02-08 17:56:02 --> Security Class Initialized
DEBUG - 2017-02-08 17:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 17:56:02 --> Input Class Initialized
INFO - 2017-02-08 17:56:02 --> Language Class Initialized
INFO - 2017-02-08 17:56:02 --> Loader Class Initialized
INFO - 2017-02-08 17:56:02 --> Database Driver Class Initialized
INFO - 2017-02-08 17:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 17:56:02 --> Controller Class Initialized
INFO - 2017-02-08 17:56:02 --> Helper loaded: url_helper
DEBUG - 2017-02-08 17:56:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 17:56:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 17:56:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 17:56:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 17:56:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 17:56:02 --> Final output sent to browser
DEBUG - 2017-02-08 17:56:02 --> Total execution time: 0.0217
INFO - 2017-02-08 17:58:20 --> Config Class Initialized
INFO - 2017-02-08 17:58:20 --> Hooks Class Initialized
DEBUG - 2017-02-08 17:58:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 17:58:20 --> Utf8 Class Initialized
INFO - 2017-02-08 17:58:20 --> URI Class Initialized
INFO - 2017-02-08 17:58:20 --> Router Class Initialized
INFO - 2017-02-08 17:58:20 --> Output Class Initialized
INFO - 2017-02-08 17:58:20 --> Security Class Initialized
DEBUG - 2017-02-08 17:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 17:58:20 --> Input Class Initialized
INFO - 2017-02-08 17:58:20 --> Language Class Initialized
INFO - 2017-02-08 17:58:20 --> Loader Class Initialized
INFO - 2017-02-08 17:58:20 --> Database Driver Class Initialized
INFO - 2017-02-08 17:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 17:58:20 --> Controller Class Initialized
INFO - 2017-02-08 17:58:20 --> Helper loaded: url_helper
DEBUG - 2017-02-08 17:58:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 17:58:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 17:58:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 17:58:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 17:58:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 17:58:20 --> Final output sent to browser
DEBUG - 2017-02-08 17:58:20 --> Total execution time: 0.0143
INFO - 2017-02-08 17:58:21 --> Config Class Initialized
INFO - 2017-02-08 17:58:21 --> Hooks Class Initialized
DEBUG - 2017-02-08 17:58:21 --> UTF-8 Support Enabled
INFO - 2017-02-08 17:58:21 --> Utf8 Class Initialized
INFO - 2017-02-08 17:58:21 --> URI Class Initialized
INFO - 2017-02-08 17:58:21 --> Router Class Initialized
INFO - 2017-02-08 17:58:21 --> Output Class Initialized
INFO - 2017-02-08 17:58:21 --> Security Class Initialized
DEBUG - 2017-02-08 17:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 17:58:21 --> Input Class Initialized
INFO - 2017-02-08 17:58:21 --> Language Class Initialized
INFO - 2017-02-08 17:58:21 --> Loader Class Initialized
INFO - 2017-02-08 17:58:21 --> Database Driver Class Initialized
INFO - 2017-02-08 17:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 17:58:21 --> Controller Class Initialized
INFO - 2017-02-08 17:58:21 --> Helper loaded: url_helper
DEBUG - 2017-02-08 17:58:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 17:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 17:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 17:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 17:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 17:58:21 --> Final output sent to browser
DEBUG - 2017-02-08 17:58:21 --> Total execution time: 0.0135
INFO - 2017-02-08 17:58:36 --> Config Class Initialized
INFO - 2017-02-08 17:58:36 --> Hooks Class Initialized
DEBUG - 2017-02-08 17:58:36 --> UTF-8 Support Enabled
INFO - 2017-02-08 17:58:36 --> Utf8 Class Initialized
INFO - 2017-02-08 17:58:36 --> URI Class Initialized
INFO - 2017-02-08 17:58:36 --> Router Class Initialized
INFO - 2017-02-08 17:58:36 --> Output Class Initialized
INFO - 2017-02-08 17:58:36 --> Security Class Initialized
DEBUG - 2017-02-08 17:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 17:58:36 --> Input Class Initialized
INFO - 2017-02-08 17:58:36 --> Language Class Initialized
INFO - 2017-02-08 17:58:36 --> Loader Class Initialized
INFO - 2017-02-08 17:58:36 --> Database Driver Class Initialized
INFO - 2017-02-08 17:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 17:58:36 --> Controller Class Initialized
INFO - 2017-02-08 17:58:36 --> Helper loaded: url_helper
DEBUG - 2017-02-08 17:58:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 17:58:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 17:58:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 17:58:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 17:58:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 17:58:36 --> Final output sent to browser
DEBUG - 2017-02-08 17:58:36 --> Total execution time: 0.0151
INFO - 2017-02-08 17:58:37 --> Config Class Initialized
INFO - 2017-02-08 17:58:37 --> Hooks Class Initialized
DEBUG - 2017-02-08 17:58:37 --> UTF-8 Support Enabled
INFO - 2017-02-08 17:58:37 --> Utf8 Class Initialized
INFO - 2017-02-08 17:58:37 --> URI Class Initialized
INFO - 2017-02-08 17:58:37 --> Router Class Initialized
INFO - 2017-02-08 17:58:37 --> Output Class Initialized
INFO - 2017-02-08 17:58:37 --> Security Class Initialized
DEBUG - 2017-02-08 17:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 17:58:37 --> Input Class Initialized
INFO - 2017-02-08 17:58:37 --> Language Class Initialized
INFO - 2017-02-08 17:58:37 --> Loader Class Initialized
INFO - 2017-02-08 17:58:37 --> Database Driver Class Initialized
INFO - 2017-02-08 17:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 17:58:37 --> Controller Class Initialized
INFO - 2017-02-08 17:58:37 --> Helper loaded: url_helper
DEBUG - 2017-02-08 17:58:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 17:58:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 17:58:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 17:58:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 17:58:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 17:58:37 --> Final output sent to browser
DEBUG - 2017-02-08 17:58:37 --> Total execution time: 0.0274
INFO - 2017-02-08 18:01:32 --> Config Class Initialized
INFO - 2017-02-08 18:01:32 --> Hooks Class Initialized
DEBUG - 2017-02-08 18:01:32 --> UTF-8 Support Enabled
INFO - 2017-02-08 18:01:32 --> Utf8 Class Initialized
INFO - 2017-02-08 18:01:32 --> URI Class Initialized
INFO - 2017-02-08 18:01:32 --> Router Class Initialized
INFO - 2017-02-08 18:01:32 --> Output Class Initialized
INFO - 2017-02-08 18:01:32 --> Security Class Initialized
DEBUG - 2017-02-08 18:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 18:01:32 --> Input Class Initialized
INFO - 2017-02-08 18:01:32 --> Language Class Initialized
INFO - 2017-02-08 18:01:32 --> Loader Class Initialized
INFO - 2017-02-08 18:01:32 --> Database Driver Class Initialized
INFO - 2017-02-08 18:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 18:01:32 --> Controller Class Initialized
INFO - 2017-02-08 18:01:32 --> Helper loaded: url_helper
DEBUG - 2017-02-08 18:01:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 18:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 18:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 18:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 18:01:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 18:01:32 --> Final output sent to browser
DEBUG - 2017-02-08 18:01:32 --> Total execution time: 0.0150
INFO - 2017-02-08 18:01:34 --> Config Class Initialized
INFO - 2017-02-08 18:01:34 --> Hooks Class Initialized
DEBUG - 2017-02-08 18:01:34 --> UTF-8 Support Enabled
INFO - 2017-02-08 18:01:34 --> Utf8 Class Initialized
INFO - 2017-02-08 18:01:34 --> URI Class Initialized
INFO - 2017-02-08 18:01:34 --> Router Class Initialized
INFO - 2017-02-08 18:01:34 --> Output Class Initialized
INFO - 2017-02-08 18:01:34 --> Security Class Initialized
DEBUG - 2017-02-08 18:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 18:01:34 --> Input Class Initialized
INFO - 2017-02-08 18:01:34 --> Language Class Initialized
INFO - 2017-02-08 18:01:34 --> Loader Class Initialized
INFO - 2017-02-08 18:01:34 --> Database Driver Class Initialized
INFO - 2017-02-08 18:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 18:01:34 --> Controller Class Initialized
INFO - 2017-02-08 18:01:34 --> Helper loaded: url_helper
DEBUG - 2017-02-08 18:01:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 18:01:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 18:01:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 18:01:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 18:01:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 18:01:34 --> Final output sent to browser
DEBUG - 2017-02-08 18:01:34 --> Total execution time: 0.0139
INFO - 2017-02-08 19:31:55 --> Config Class Initialized
INFO - 2017-02-08 19:31:55 --> Hooks Class Initialized
DEBUG - 2017-02-08 19:31:56 --> UTF-8 Support Enabled
INFO - 2017-02-08 19:31:56 --> Utf8 Class Initialized
INFO - 2017-02-08 19:31:56 --> URI Class Initialized
DEBUG - 2017-02-08 19:31:56 --> No URI present. Default controller set.
INFO - 2017-02-08 19:31:56 --> Router Class Initialized
INFO - 2017-02-08 19:31:56 --> Output Class Initialized
INFO - 2017-02-08 19:31:56 --> Security Class Initialized
DEBUG - 2017-02-08 19:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 19:31:56 --> Input Class Initialized
INFO - 2017-02-08 19:31:56 --> Language Class Initialized
INFO - 2017-02-08 19:31:56 --> Loader Class Initialized
INFO - 2017-02-08 19:31:56 --> Database Driver Class Initialized
INFO - 2017-02-08 19:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 19:31:57 --> Controller Class Initialized
INFO - 2017-02-08 19:31:57 --> Helper loaded: url_helper
DEBUG - 2017-02-08 19:31:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 19:31:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 19:31:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 19:31:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 19:31:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 19:31:57 --> Final output sent to browser
DEBUG - 2017-02-08 19:31:57 --> Total execution time: 1.8010
INFO - 2017-02-08 19:49:38 --> Config Class Initialized
INFO - 2017-02-08 19:49:38 --> Hooks Class Initialized
DEBUG - 2017-02-08 19:49:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 19:49:38 --> Utf8 Class Initialized
INFO - 2017-02-08 19:49:38 --> URI Class Initialized
DEBUG - 2017-02-08 19:49:38 --> No URI present. Default controller set.
INFO - 2017-02-08 19:49:38 --> Router Class Initialized
INFO - 2017-02-08 19:49:38 --> Output Class Initialized
INFO - 2017-02-08 19:49:38 --> Security Class Initialized
DEBUG - 2017-02-08 19:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 19:49:38 --> Input Class Initialized
INFO - 2017-02-08 19:49:38 --> Language Class Initialized
INFO - 2017-02-08 19:49:38 --> Loader Class Initialized
INFO - 2017-02-08 19:49:38 --> Database Driver Class Initialized
INFO - 2017-02-08 19:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 19:49:38 --> Controller Class Initialized
INFO - 2017-02-08 19:49:38 --> Helper loaded: url_helper
DEBUG - 2017-02-08 19:49:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 19:49:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 19:49:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 19:49:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 19:49:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 19:49:38 --> Final output sent to browser
DEBUG - 2017-02-08 19:49:38 --> Total execution time: 0.0137
INFO - 2017-02-08 19:49:52 --> Config Class Initialized
INFO - 2017-02-08 19:49:52 --> Hooks Class Initialized
DEBUG - 2017-02-08 19:49:52 --> UTF-8 Support Enabled
INFO - 2017-02-08 19:49:52 --> Utf8 Class Initialized
INFO - 2017-02-08 19:49:52 --> URI Class Initialized
INFO - 2017-02-08 19:49:52 --> Router Class Initialized
INFO - 2017-02-08 19:49:52 --> Output Class Initialized
INFO - 2017-02-08 19:49:52 --> Security Class Initialized
DEBUG - 2017-02-08 19:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 19:49:52 --> Input Class Initialized
INFO - 2017-02-08 19:49:52 --> Language Class Initialized
INFO - 2017-02-08 19:49:52 --> Loader Class Initialized
INFO - 2017-02-08 19:49:52 --> Database Driver Class Initialized
INFO - 2017-02-08 19:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 19:49:52 --> Controller Class Initialized
INFO - 2017-02-08 19:49:52 --> Helper loaded: url_helper
DEBUG - 2017-02-08 19:49:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-08 19:49:54 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-08 19:49:54 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Fatty R. Ramos')
INFO - 2017-02-08 19:49:54 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-08 19:49:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-08 19:49:55 --> Config Class Initialized
INFO - 2017-02-08 19:49:55 --> Hooks Class Initialized
DEBUG - 2017-02-08 19:49:55 --> UTF-8 Support Enabled
INFO - 2017-02-08 19:49:55 --> Utf8 Class Initialized
INFO - 2017-02-08 19:49:55 --> URI Class Initialized
INFO - 2017-02-08 19:49:55 --> Router Class Initialized
INFO - 2017-02-08 19:49:55 --> Output Class Initialized
INFO - 2017-02-08 19:49:55 --> Security Class Initialized
DEBUG - 2017-02-08 19:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 19:49:55 --> Input Class Initialized
INFO - 2017-02-08 19:49:55 --> Language Class Initialized
INFO - 2017-02-08 19:49:55 --> Loader Class Initialized
INFO - 2017-02-08 19:49:55 --> Database Driver Class Initialized
INFO - 2017-02-08 19:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 19:49:55 --> Controller Class Initialized
INFO - 2017-02-08 19:49:55 --> Helper loaded: url_helper
DEBUG - 2017-02-08 19:49:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 19:49:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 19:49:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 19:49:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 19:49:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 19:49:55 --> Final output sent to browser
DEBUG - 2017-02-08 19:49:55 --> Total execution time: 0.0133
INFO - 2017-02-08 19:50:11 --> Config Class Initialized
INFO - 2017-02-08 19:50:11 --> Hooks Class Initialized
DEBUG - 2017-02-08 19:50:11 --> UTF-8 Support Enabled
INFO - 2017-02-08 19:50:11 --> Utf8 Class Initialized
INFO - 2017-02-08 19:50:11 --> URI Class Initialized
DEBUG - 2017-02-08 19:50:11 --> No URI present. Default controller set.
INFO - 2017-02-08 19:50:11 --> Router Class Initialized
INFO - 2017-02-08 19:50:11 --> Output Class Initialized
INFO - 2017-02-08 19:50:11 --> Security Class Initialized
DEBUG - 2017-02-08 19:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 19:50:11 --> Input Class Initialized
INFO - 2017-02-08 19:50:11 --> Language Class Initialized
INFO - 2017-02-08 19:50:11 --> Loader Class Initialized
INFO - 2017-02-08 19:50:11 --> Database Driver Class Initialized
INFO - 2017-02-08 19:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 19:50:12 --> Controller Class Initialized
INFO - 2017-02-08 19:50:12 --> Helper loaded: url_helper
DEBUG - 2017-02-08 19:50:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 19:50:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 19:50:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 19:50:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 19:50:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 19:50:12 --> Final output sent to browser
DEBUG - 2017-02-08 19:50:12 --> Total execution time: 0.8438
INFO - 2017-02-08 19:50:33 --> Config Class Initialized
INFO - 2017-02-08 19:50:33 --> Hooks Class Initialized
DEBUG - 2017-02-08 19:50:33 --> UTF-8 Support Enabled
INFO - 2017-02-08 19:50:33 --> Utf8 Class Initialized
INFO - 2017-02-08 19:50:33 --> URI Class Initialized
INFO - 2017-02-08 19:50:33 --> Router Class Initialized
INFO - 2017-02-08 19:50:33 --> Output Class Initialized
INFO - 2017-02-08 19:50:33 --> Security Class Initialized
DEBUG - 2017-02-08 19:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 19:50:34 --> Input Class Initialized
INFO - 2017-02-08 19:50:34 --> Language Class Initialized
INFO - 2017-02-08 19:50:34 --> Loader Class Initialized
INFO - 2017-02-08 19:50:34 --> Database Driver Class Initialized
INFO - 2017-02-08 19:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 19:50:34 --> Controller Class Initialized
INFO - 2017-02-08 19:50:34 --> Helper loaded: url_helper
DEBUG - 2017-02-08 19:50:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-08 19:50:36 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-08 19:50:36 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Fatty R. Ramos')
INFO - 2017-02-08 19:50:36 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-08 19:50:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-08 19:50:39 --> Config Class Initialized
INFO - 2017-02-08 19:50:39 --> Hooks Class Initialized
DEBUG - 2017-02-08 19:50:39 --> UTF-8 Support Enabled
INFO - 2017-02-08 19:50:39 --> Utf8 Class Initialized
INFO - 2017-02-08 19:50:39 --> URI Class Initialized
INFO - 2017-02-08 19:50:39 --> Router Class Initialized
INFO - 2017-02-08 19:50:39 --> Output Class Initialized
INFO - 2017-02-08 19:50:39 --> Security Class Initialized
DEBUG - 2017-02-08 19:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 19:50:39 --> Input Class Initialized
INFO - 2017-02-08 19:50:39 --> Language Class Initialized
INFO - 2017-02-08 19:50:39 --> Loader Class Initialized
INFO - 2017-02-08 19:50:39 --> Database Driver Class Initialized
INFO - 2017-02-08 19:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 19:50:39 --> Controller Class Initialized
INFO - 2017-02-08 19:50:39 --> Helper loaded: url_helper
DEBUG - 2017-02-08 19:50:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 19:50:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 19:50:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 19:50:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 19:50:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 19:50:39 --> Final output sent to browser
DEBUG - 2017-02-08 19:50:39 --> Total execution time: 0.1473
INFO - 2017-02-08 20:06:18 --> Config Class Initialized
INFO - 2017-02-08 20:06:18 --> Hooks Class Initialized
DEBUG - 2017-02-08 20:06:18 --> UTF-8 Support Enabled
INFO - 2017-02-08 20:06:18 --> Utf8 Class Initialized
INFO - 2017-02-08 20:06:18 --> URI Class Initialized
DEBUG - 2017-02-08 20:06:19 --> No URI present. Default controller set.
INFO - 2017-02-08 20:06:19 --> Router Class Initialized
INFO - 2017-02-08 20:06:19 --> Output Class Initialized
INFO - 2017-02-08 20:06:19 --> Security Class Initialized
DEBUG - 2017-02-08 20:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 20:06:19 --> Input Class Initialized
INFO - 2017-02-08 20:06:19 --> Language Class Initialized
INFO - 2017-02-08 20:06:19 --> Loader Class Initialized
INFO - 2017-02-08 20:06:19 --> Database Driver Class Initialized
INFO - 2017-02-08 20:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 20:06:20 --> Controller Class Initialized
INFO - 2017-02-08 20:06:20 --> Helper loaded: url_helper
DEBUG - 2017-02-08 20:06:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 20:06:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 20:06:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 20:06:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 20:06:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 20:06:20 --> Final output sent to browser
DEBUG - 2017-02-08 20:06:20 --> Total execution time: 1.7400
INFO - 2017-02-08 20:06:40 --> Config Class Initialized
INFO - 2017-02-08 20:06:40 --> Hooks Class Initialized
DEBUG - 2017-02-08 20:06:40 --> UTF-8 Support Enabled
INFO - 2017-02-08 20:06:40 --> Utf8 Class Initialized
INFO - 2017-02-08 20:06:40 --> URI Class Initialized
INFO - 2017-02-08 20:06:40 --> Router Class Initialized
INFO - 2017-02-08 20:06:40 --> Output Class Initialized
INFO - 2017-02-08 20:06:40 --> Security Class Initialized
DEBUG - 2017-02-08 20:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 20:06:40 --> Input Class Initialized
INFO - 2017-02-08 20:06:40 --> Language Class Initialized
INFO - 2017-02-08 20:06:40 --> Loader Class Initialized
INFO - 2017-02-08 20:06:40 --> Database Driver Class Initialized
INFO - 2017-02-08 20:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 20:06:40 --> Controller Class Initialized
INFO - 2017-02-08 20:06:40 --> Helper loaded: url_helper
DEBUG - 2017-02-08 20:06:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 20:06:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 20:06:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 20:06:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 20:06:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 20:06:40 --> Final output sent to browser
DEBUG - 2017-02-08 20:06:40 --> Total execution time: 0.0132
INFO - 2017-02-08 20:11:17 --> Config Class Initialized
INFO - 2017-02-08 20:11:17 --> Hooks Class Initialized
DEBUG - 2017-02-08 20:11:17 --> UTF-8 Support Enabled
INFO - 2017-02-08 20:11:17 --> Utf8 Class Initialized
INFO - 2017-02-08 20:11:17 --> URI Class Initialized
INFO - 2017-02-08 20:11:17 --> Router Class Initialized
INFO - 2017-02-08 20:11:17 --> Output Class Initialized
INFO - 2017-02-08 20:11:17 --> Security Class Initialized
DEBUG - 2017-02-08 20:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 20:11:17 --> Input Class Initialized
INFO - 2017-02-08 20:11:17 --> Language Class Initialized
INFO - 2017-02-08 20:11:17 --> Loader Class Initialized
INFO - 2017-02-08 20:11:17 --> Database Driver Class Initialized
INFO - 2017-02-08 20:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 20:11:17 --> Controller Class Initialized
INFO - 2017-02-08 20:11:17 --> Helper loaded: url_helper
DEBUG - 2017-02-08 20:11:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 20:11:18 --> Config Class Initialized
INFO - 2017-02-08 20:11:18 --> Hooks Class Initialized
DEBUG - 2017-02-08 20:11:18 --> UTF-8 Support Enabled
INFO - 2017-02-08 20:11:18 --> Utf8 Class Initialized
INFO - 2017-02-08 20:11:18 --> URI Class Initialized
INFO - 2017-02-08 20:11:18 --> Router Class Initialized
INFO - 2017-02-08 20:11:18 --> Output Class Initialized
INFO - 2017-02-08 20:11:18 --> Security Class Initialized
DEBUG - 2017-02-08 20:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 20:11:18 --> Input Class Initialized
INFO - 2017-02-08 20:11:18 --> Language Class Initialized
INFO - 2017-02-08 20:11:18 --> Loader Class Initialized
INFO - 2017-02-08 20:11:18 --> Database Driver Class Initialized
INFO - 2017-02-08 20:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 20:11:18 --> Controller Class Initialized
INFO - 2017-02-08 20:11:18 --> Helper loaded: date_helper
DEBUG - 2017-02-08 20:11:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 20:11:18 --> Helper loaded: url_helper
INFO - 2017-02-08 20:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 20:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-08 20:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-08 20:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-08 20:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 20:11:18 --> Final output sent to browser
DEBUG - 2017-02-08 20:11:18 --> Total execution time: 0.1156
INFO - 2017-02-08 20:11:20 --> Config Class Initialized
INFO - 2017-02-08 20:11:20 --> Hooks Class Initialized
DEBUG - 2017-02-08 20:11:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 20:11:20 --> Utf8 Class Initialized
INFO - 2017-02-08 20:11:20 --> URI Class Initialized
INFO - 2017-02-08 20:11:20 --> Router Class Initialized
INFO - 2017-02-08 20:11:20 --> Output Class Initialized
INFO - 2017-02-08 20:11:20 --> Security Class Initialized
DEBUG - 2017-02-08 20:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 20:11:20 --> Input Class Initialized
INFO - 2017-02-08 20:11:20 --> Language Class Initialized
INFO - 2017-02-08 20:11:20 --> Loader Class Initialized
INFO - 2017-02-08 20:11:20 --> Database Driver Class Initialized
INFO - 2017-02-08 20:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 20:11:20 --> Controller Class Initialized
INFO - 2017-02-08 20:11:20 --> Helper loaded: url_helper
DEBUG - 2017-02-08 20:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 20:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 20:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 20:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 20:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 20:11:20 --> Final output sent to browser
DEBUG - 2017-02-08 20:11:20 --> Total execution time: 0.2632
INFO - 2017-02-08 20:11:26 --> Config Class Initialized
INFO - 2017-02-08 20:11:26 --> Hooks Class Initialized
DEBUG - 2017-02-08 20:11:26 --> UTF-8 Support Enabled
INFO - 2017-02-08 20:11:26 --> Utf8 Class Initialized
INFO - 2017-02-08 20:11:26 --> URI Class Initialized
INFO - 2017-02-08 20:11:26 --> Router Class Initialized
INFO - 2017-02-08 20:11:26 --> Output Class Initialized
INFO - 2017-02-08 20:11:26 --> Security Class Initialized
DEBUG - 2017-02-08 20:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 20:11:26 --> Input Class Initialized
INFO - 2017-02-08 20:11:26 --> Language Class Initialized
INFO - 2017-02-08 20:11:26 --> Loader Class Initialized
INFO - 2017-02-08 20:11:26 --> Database Driver Class Initialized
INFO - 2017-02-08 20:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 20:11:26 --> Controller Class Initialized
INFO - 2017-02-08 20:11:26 --> Helper loaded: url_helper
DEBUG - 2017-02-08 20:11:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 20:11:27 --> Config Class Initialized
INFO - 2017-02-08 20:11:27 --> Hooks Class Initialized
DEBUG - 2017-02-08 20:11:27 --> UTF-8 Support Enabled
INFO - 2017-02-08 20:11:27 --> Utf8 Class Initialized
INFO - 2017-02-08 20:11:27 --> URI Class Initialized
INFO - 2017-02-08 20:11:27 --> Router Class Initialized
INFO - 2017-02-08 20:11:27 --> Output Class Initialized
INFO - 2017-02-08 20:11:27 --> Security Class Initialized
DEBUG - 2017-02-08 20:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 20:11:27 --> Input Class Initialized
INFO - 2017-02-08 20:11:27 --> Language Class Initialized
INFO - 2017-02-08 20:11:27 --> Loader Class Initialized
INFO - 2017-02-08 20:11:27 --> Database Driver Class Initialized
INFO - 2017-02-08 20:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 20:11:27 --> Controller Class Initialized
INFO - 2017-02-08 20:11:27 --> Helper loaded: date_helper
DEBUG - 2017-02-08 20:11:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 20:11:27 --> Helper loaded: url_helper
INFO - 2017-02-08 20:11:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 20:11:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-08 20:11:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-08 20:11:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-08 20:11:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 20:11:27 --> Final output sent to browser
DEBUG - 2017-02-08 20:11:27 --> Total execution time: 0.0149
INFO - 2017-02-08 20:11:28 --> Config Class Initialized
INFO - 2017-02-08 20:11:28 --> Hooks Class Initialized
DEBUG - 2017-02-08 20:11:28 --> UTF-8 Support Enabled
INFO - 2017-02-08 20:11:28 --> Utf8 Class Initialized
INFO - 2017-02-08 20:11:28 --> URI Class Initialized
INFO - 2017-02-08 20:11:28 --> Router Class Initialized
INFO - 2017-02-08 20:11:28 --> Output Class Initialized
INFO - 2017-02-08 20:11:28 --> Security Class Initialized
DEBUG - 2017-02-08 20:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 20:11:28 --> Input Class Initialized
INFO - 2017-02-08 20:11:28 --> Language Class Initialized
INFO - 2017-02-08 20:11:28 --> Loader Class Initialized
INFO - 2017-02-08 20:11:28 --> Database Driver Class Initialized
INFO - 2017-02-08 20:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 20:11:28 --> Controller Class Initialized
INFO - 2017-02-08 20:11:28 --> Helper loaded: url_helper
DEBUG - 2017-02-08 20:11:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 20:11:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 20:11:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 20:11:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 20:11:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 20:11:28 --> Final output sent to browser
DEBUG - 2017-02-08 20:11:28 --> Total execution time: 0.0142
INFO - 2017-02-08 21:35:48 --> Config Class Initialized
INFO - 2017-02-08 21:35:48 --> Config Class Initialized
INFO - 2017-02-08 21:35:49 --> Hooks Class Initialized
INFO - 2017-02-08 21:35:49 --> Hooks Class Initialized
DEBUG - 2017-02-08 21:35:49 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 21:35:49 --> UTF-8 Support Enabled
INFO - 2017-02-08 21:35:49 --> Utf8 Class Initialized
INFO - 2017-02-08 21:35:49 --> Utf8 Class Initialized
INFO - 2017-02-08 21:35:49 --> URI Class Initialized
INFO - 2017-02-08 21:35:49 --> URI Class Initialized
DEBUG - 2017-02-08 21:35:49 --> No URI present. Default controller set.
INFO - 2017-02-08 21:35:49 --> Router Class Initialized
INFO - 2017-02-08 21:35:49 --> Router Class Initialized
INFO - 2017-02-08 21:35:49 --> Output Class Initialized
INFO - 2017-02-08 21:35:49 --> Output Class Initialized
INFO - 2017-02-08 21:35:49 --> Security Class Initialized
INFO - 2017-02-08 21:35:49 --> Security Class Initialized
DEBUG - 2017-02-08 21:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 21:35:49 --> Input Class Initialized
INFO - 2017-02-08 21:35:49 --> Language Class Initialized
DEBUG - 2017-02-08 21:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 21:35:49 --> Input Class Initialized
INFO - 2017-02-08 21:35:49 --> Language Class Initialized
INFO - 2017-02-08 21:35:49 --> Loader Class Initialized
INFO - 2017-02-08 21:35:49 --> Loader Class Initialized
INFO - 2017-02-08 21:35:49 --> Database Driver Class Initialized
INFO - 2017-02-08 21:35:49 --> Database Driver Class Initialized
INFO - 2017-02-08 21:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 21:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 21:35:50 --> Controller Class Initialized
INFO - 2017-02-08 21:35:50 --> Controller Class Initialized
INFO - 2017-02-08 21:35:50 --> Helper loaded: url_helper
DEBUG - 2017-02-08 21:35:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 21:35:50 --> Helper loaded: url_helper
DEBUG - 2017-02-08 21:35:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 21:35:50 --> Helper loaded: form_helper
INFO - 2017-02-08 21:35:50 --> Form Validation Class Initialized
INFO - 2017-02-08 21:35:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-02-08 21:35:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-02-08 21:35:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-02-08 21:35:50 --> Final output sent to browser
DEBUG - 2017-02-08 21:35:50 --> Total execution time: 1.6379
INFO - 2017-02-08 21:35:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 21:35:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 21:35:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 21:35:50 --> Config Class Initialized
INFO - 2017-02-08 21:35:50 --> Hooks Class Initialized
DEBUG - 2017-02-08 21:35:50 --> UTF-8 Support Enabled
INFO - 2017-02-08 21:35:50 --> Utf8 Class Initialized
INFO - 2017-02-08 21:35:50 --> URI Class Initialized
INFO - 2017-02-08 21:35:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 21:35:50 --> Router Class Initialized
INFO - 2017-02-08 21:35:50 --> Output Class Initialized
INFO - 2017-02-08 21:35:50 --> Security Class Initialized
DEBUG - 2017-02-08 21:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 21:35:50 --> Input Class Initialized
INFO - 2017-02-08 21:35:50 --> Language Class Initialized
INFO - 2017-02-08 21:35:50 --> Loader Class Initialized
INFO - 2017-02-08 21:35:50 --> Database Driver Class Initialized
INFO - 2017-02-08 21:35:50 --> Final output sent to browser
DEBUG - 2017-02-08 21:35:50 --> Total execution time: 1.8038
INFO - 2017-02-08 21:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 21:35:50 --> Controller Class Initialized
INFO - 2017-02-08 21:35:50 --> Helper loaded: url_helper
DEBUG - 2017-02-08 21:35:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 21:35:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 21:35:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 21:35:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 21:35:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 21:35:50 --> Final output sent to browser
DEBUG - 2017-02-08 21:35:50 --> Total execution time: 0.0201
INFO - 2017-02-08 23:40:28 --> Config Class Initialized
INFO - 2017-02-08 23:40:28 --> Hooks Class Initialized
DEBUG - 2017-02-08 23:40:29 --> UTF-8 Support Enabled
INFO - 2017-02-08 23:40:29 --> Utf8 Class Initialized
INFO - 2017-02-08 23:40:29 --> URI Class Initialized
DEBUG - 2017-02-08 23:40:29 --> No URI present. Default controller set.
INFO - 2017-02-08 23:40:29 --> Router Class Initialized
INFO - 2017-02-08 23:40:29 --> Output Class Initialized
INFO - 2017-02-08 23:40:29 --> Security Class Initialized
DEBUG - 2017-02-08 23:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 23:40:29 --> Input Class Initialized
INFO - 2017-02-08 23:40:29 --> Language Class Initialized
INFO - 2017-02-08 23:40:29 --> Loader Class Initialized
INFO - 2017-02-08 23:40:29 --> Database Driver Class Initialized
INFO - 2017-02-08 23:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 23:40:29 --> Controller Class Initialized
INFO - 2017-02-08 23:40:29 --> Helper loaded: url_helper
DEBUG - 2017-02-08 23:40:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 23:40:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 23:40:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 23:40:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 23:40:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 23:40:30 --> Final output sent to browser
DEBUG - 2017-02-08 23:40:30 --> Total execution time: 1.4710
INFO - 2017-02-08 23:40:32 --> Config Class Initialized
INFO - 2017-02-08 23:40:32 --> Hooks Class Initialized
DEBUG - 2017-02-08 23:40:32 --> UTF-8 Support Enabled
INFO - 2017-02-08 23:40:32 --> Utf8 Class Initialized
INFO - 2017-02-08 23:40:32 --> URI Class Initialized
INFO - 2017-02-08 23:40:32 --> Router Class Initialized
INFO - 2017-02-08 23:40:32 --> Output Class Initialized
INFO - 2017-02-08 23:40:32 --> Security Class Initialized
DEBUG - 2017-02-08 23:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 23:40:32 --> Input Class Initialized
INFO - 2017-02-08 23:40:32 --> Language Class Initialized
INFO - 2017-02-08 23:40:32 --> Loader Class Initialized
INFO - 2017-02-08 23:40:32 --> Database Driver Class Initialized
INFO - 2017-02-08 23:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 23:40:32 --> Controller Class Initialized
INFO - 2017-02-08 23:40:32 --> Helper loaded: url_helper
DEBUG - 2017-02-08 23:40:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 23:40:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 23:40:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 23:40:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 23:40:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 23:40:32 --> Final output sent to browser
DEBUG - 2017-02-08 23:40:32 --> Total execution time: 0.1653
INFO - 2017-02-08 23:40:35 --> Config Class Initialized
INFO - 2017-02-08 23:40:35 --> Hooks Class Initialized
DEBUG - 2017-02-08 23:40:35 --> UTF-8 Support Enabled
INFO - 2017-02-08 23:40:35 --> Utf8 Class Initialized
INFO - 2017-02-08 23:40:35 --> URI Class Initialized
INFO - 2017-02-08 23:40:35 --> Router Class Initialized
INFO - 2017-02-08 23:40:35 --> Output Class Initialized
INFO - 2017-02-08 23:40:35 --> Security Class Initialized
DEBUG - 2017-02-08 23:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 23:40:35 --> Input Class Initialized
INFO - 2017-02-08 23:40:35 --> Language Class Initialized
INFO - 2017-02-08 23:40:35 --> Loader Class Initialized
INFO - 2017-02-08 23:40:35 --> Database Driver Class Initialized
INFO - 2017-02-08 23:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 23:40:35 --> Controller Class Initialized
INFO - 2017-02-08 23:40:35 --> Helper loaded: url_helper
DEBUG - 2017-02-08 23:40:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 23:40:37 --> Config Class Initialized
INFO - 2017-02-08 23:40:37 --> Hooks Class Initialized
DEBUG - 2017-02-08 23:40:37 --> UTF-8 Support Enabled
INFO - 2017-02-08 23:40:37 --> Utf8 Class Initialized
INFO - 2017-02-08 23:40:37 --> URI Class Initialized
INFO - 2017-02-08 23:40:37 --> Router Class Initialized
INFO - 2017-02-08 23:40:37 --> Output Class Initialized
INFO - 2017-02-08 23:40:37 --> Security Class Initialized
DEBUG - 2017-02-08 23:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 23:40:37 --> Input Class Initialized
INFO - 2017-02-08 23:40:37 --> Language Class Initialized
INFO - 2017-02-08 23:40:37 --> Loader Class Initialized
INFO - 2017-02-08 23:40:37 --> Database Driver Class Initialized
INFO - 2017-02-08 23:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 23:40:37 --> Controller Class Initialized
INFO - 2017-02-08 23:40:37 --> Helper loaded: date_helper
DEBUG - 2017-02-08 23:40:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 23:40:37 --> Helper loaded: url_helper
INFO - 2017-02-08 23:40:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 23:40:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-08 23:40:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-08 23:40:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-08 23:40:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 23:40:37 --> Final output sent to browser
DEBUG - 2017-02-08 23:40:37 --> Total execution time: 0.1209
INFO - 2017-02-08 23:40:38 --> Config Class Initialized
INFO - 2017-02-08 23:40:38 --> Hooks Class Initialized
DEBUG - 2017-02-08 23:40:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 23:40:38 --> Utf8 Class Initialized
INFO - 2017-02-08 23:40:38 --> URI Class Initialized
INFO - 2017-02-08 23:40:38 --> Router Class Initialized
INFO - 2017-02-08 23:40:38 --> Output Class Initialized
INFO - 2017-02-08 23:40:38 --> Security Class Initialized
DEBUG - 2017-02-08 23:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 23:40:38 --> Input Class Initialized
INFO - 2017-02-08 23:40:38 --> Language Class Initialized
INFO - 2017-02-08 23:40:38 --> Loader Class Initialized
INFO - 2017-02-08 23:40:38 --> Database Driver Class Initialized
INFO - 2017-02-08 23:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 23:40:38 --> Controller Class Initialized
INFO - 2017-02-08 23:40:38 --> Helper loaded: url_helper
DEBUG - 2017-02-08 23:40:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-08 23:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-08 23:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-08 23:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-08 23:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-08 23:40:38 --> Final output sent to browser
DEBUG - 2017-02-08 23:40:38 --> Total execution time: 0.0162

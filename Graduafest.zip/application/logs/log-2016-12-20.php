<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-20 01:25:20 --> Config Class Initialized
INFO - 2016-12-20 01:25:20 --> Hooks Class Initialized
DEBUG - 2016-12-20 01:25:20 --> UTF-8 Support Enabled
INFO - 2016-12-20 01:25:20 --> Utf8 Class Initialized
INFO - 2016-12-20 01:25:20 --> URI Class Initialized
DEBUG - 2016-12-20 01:25:20 --> No URI present. Default controller set.
INFO - 2016-12-20 01:25:20 --> Router Class Initialized
INFO - 2016-12-20 01:25:20 --> Output Class Initialized
INFO - 2016-12-20 01:25:20 --> Security Class Initialized
DEBUG - 2016-12-20 01:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 01:25:20 --> Input Class Initialized
INFO - 2016-12-20 01:25:20 --> Language Class Initialized
INFO - 2016-12-20 01:25:20 --> Loader Class Initialized
INFO - 2016-12-20 01:25:21 --> Database Driver Class Initialized
INFO - 2016-12-20 01:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 01:25:21 --> Controller Class Initialized
INFO - 2016-12-20 01:25:21 --> Helper loaded: url_helper
DEBUG - 2016-12-20 01:25:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 01:25:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 01:25:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-20 01:25:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-20 01:25:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 01:25:22 --> Final output sent to browser
DEBUG - 2016-12-20 01:25:22 --> Total execution time: 1.9278
INFO - 2016-12-20 01:25:23 --> Config Class Initialized
INFO - 2016-12-20 01:25:23 --> Hooks Class Initialized
DEBUG - 2016-12-20 01:25:23 --> UTF-8 Support Enabled
INFO - 2016-12-20 01:25:23 --> Utf8 Class Initialized
INFO - 2016-12-20 01:25:23 --> URI Class Initialized
INFO - 2016-12-20 01:25:23 --> Router Class Initialized
INFO - 2016-12-20 01:25:23 --> Output Class Initialized
INFO - 2016-12-20 01:25:23 --> Security Class Initialized
DEBUG - 2016-12-20 01:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 01:25:23 --> Input Class Initialized
INFO - 2016-12-20 01:25:23 --> Language Class Initialized
INFO - 2016-12-20 01:25:23 --> Loader Class Initialized
INFO - 2016-12-20 01:25:23 --> Database Driver Class Initialized
INFO - 2016-12-20 01:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 01:25:23 --> Controller Class Initialized
INFO - 2016-12-20 01:25:23 --> Helper loaded: url_helper
DEBUG - 2016-12-20 01:25:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 01:25:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 01:25:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-20 01:25:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-20 01:25:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 01:25:23 --> Final output sent to browser
DEBUG - 2016-12-20 01:25:23 --> Total execution time: 0.0135
INFO - 2016-12-20 01:25:56 --> Config Class Initialized
INFO - 2016-12-20 01:25:56 --> Hooks Class Initialized
DEBUG - 2016-12-20 01:25:56 --> UTF-8 Support Enabled
INFO - 2016-12-20 01:25:56 --> Utf8 Class Initialized
INFO - 2016-12-20 01:25:56 --> URI Class Initialized
INFO - 2016-12-20 01:25:56 --> Router Class Initialized
INFO - 2016-12-20 01:25:56 --> Output Class Initialized
INFO - 2016-12-20 01:25:56 --> Security Class Initialized
DEBUG - 2016-12-20 01:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 01:25:56 --> Input Class Initialized
INFO - 2016-12-20 01:25:56 --> Language Class Initialized
INFO - 2016-12-20 01:25:56 --> Loader Class Initialized
INFO - 2016-12-20 01:25:56 --> Database Driver Class Initialized
INFO - 2016-12-20 01:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 01:25:56 --> Controller Class Initialized
INFO - 2016-12-20 01:25:56 --> Helper loaded: url_helper
DEBUG - 2016-12-20 01:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 01:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2016-12-20 01:25:56 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 110
ERROR - 2016-12-20 01:25:56 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 137
ERROR - 2016-12-20 01:25:56 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 145
INFO - 2016-12-20 01:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-20 01:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-20 01:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 01:25:56 --> Final output sent to browser
DEBUG - 2016-12-20 01:25:56 --> Total execution time: 0.0730
INFO - 2016-12-20 01:25:56 --> Config Class Initialized
INFO - 2016-12-20 01:25:56 --> Hooks Class Initialized
DEBUG - 2016-12-20 01:25:56 --> UTF-8 Support Enabled
INFO - 2016-12-20 01:25:56 --> Utf8 Class Initialized
INFO - 2016-12-20 01:25:56 --> URI Class Initialized
INFO - 2016-12-20 01:25:56 --> Router Class Initialized
INFO - 2016-12-20 01:25:56 --> Output Class Initialized
INFO - 2016-12-20 01:25:56 --> Security Class Initialized
DEBUG - 2016-12-20 01:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 01:25:56 --> Input Class Initialized
INFO - 2016-12-20 01:25:56 --> Language Class Initialized
INFO - 2016-12-20 01:25:56 --> Loader Class Initialized
INFO - 2016-12-20 01:25:56 --> Database Driver Class Initialized
INFO - 2016-12-20 01:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 01:25:56 --> Controller Class Initialized
INFO - 2016-12-20 01:25:56 --> Helper loaded: url_helper
DEBUG - 2016-12-20 01:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 01:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 01:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-20 01:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-20 01:25:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 01:25:56 --> Final output sent to browser
DEBUG - 2016-12-20 01:25:56 --> Total execution time: 0.0132
INFO - 2016-12-20 01:26:32 --> Config Class Initialized
INFO - 2016-12-20 01:26:32 --> Hooks Class Initialized
DEBUG - 2016-12-20 01:26:32 --> UTF-8 Support Enabled
INFO - 2016-12-20 01:26:32 --> Utf8 Class Initialized
INFO - 2016-12-20 01:26:32 --> URI Class Initialized
INFO - 2016-12-20 01:26:32 --> Router Class Initialized
INFO - 2016-12-20 01:26:32 --> Output Class Initialized
INFO - 2016-12-20 01:26:32 --> Security Class Initialized
DEBUG - 2016-12-20 01:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 01:26:32 --> Input Class Initialized
INFO - 2016-12-20 01:26:32 --> Language Class Initialized
INFO - 2016-12-20 01:26:32 --> Loader Class Initialized
INFO - 2016-12-20 01:26:32 --> Database Driver Class Initialized
INFO - 2016-12-20 01:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 01:26:32 --> Controller Class Initialized
INFO - 2016-12-20 01:26:32 --> Helper loaded: url_helper
DEBUG - 2016-12-20 01:26:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 01:26:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 01:26:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-20 01:26:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-20 01:26:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 01:26:32 --> Final output sent to browser
DEBUG - 2016-12-20 01:26:32 --> Total execution time: 0.1741
INFO - 2016-12-20 01:26:33 --> Config Class Initialized
INFO - 2016-12-20 01:26:33 --> Hooks Class Initialized
DEBUG - 2016-12-20 01:26:33 --> UTF-8 Support Enabled
INFO - 2016-12-20 01:26:33 --> Utf8 Class Initialized
INFO - 2016-12-20 01:26:33 --> URI Class Initialized
INFO - 2016-12-20 01:26:33 --> Router Class Initialized
INFO - 2016-12-20 01:26:33 --> Output Class Initialized
INFO - 2016-12-20 01:26:33 --> Security Class Initialized
DEBUG - 2016-12-20 01:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 01:26:33 --> Input Class Initialized
INFO - 2016-12-20 01:26:33 --> Language Class Initialized
INFO - 2016-12-20 01:26:33 --> Loader Class Initialized
INFO - 2016-12-20 01:26:33 --> Database Driver Class Initialized
INFO - 2016-12-20 01:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 01:26:33 --> Controller Class Initialized
INFO - 2016-12-20 01:26:33 --> Helper loaded: url_helper
DEBUG - 2016-12-20 01:26:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 01:26:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 01:26:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-20 01:26:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-20 01:26:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 01:26:33 --> Final output sent to browser
DEBUG - 2016-12-20 01:26:33 --> Total execution time: 0.0128
INFO - 2016-12-20 01:26:48 --> Config Class Initialized
INFO - 2016-12-20 01:26:48 --> Hooks Class Initialized
DEBUG - 2016-12-20 01:26:48 --> UTF-8 Support Enabled
INFO - 2016-12-20 01:26:48 --> Utf8 Class Initialized
INFO - 2016-12-20 01:26:48 --> URI Class Initialized
INFO - 2016-12-20 01:26:48 --> Router Class Initialized
INFO - 2016-12-20 01:26:48 --> Output Class Initialized
INFO - 2016-12-20 01:26:48 --> Security Class Initialized
DEBUG - 2016-12-20 01:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 01:26:48 --> Input Class Initialized
INFO - 2016-12-20 01:26:48 --> Language Class Initialized
INFO - 2016-12-20 01:26:48 --> Loader Class Initialized
INFO - 2016-12-20 01:26:48 --> Database Driver Class Initialized
INFO - 2016-12-20 01:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 01:26:48 --> Controller Class Initialized
INFO - 2016-12-20 01:26:48 --> Helper loaded: url_helper
DEBUG - 2016-12-20 01:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 01:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 01:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-20 01:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-20 01:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 01:26:48 --> Final output sent to browser
DEBUG - 2016-12-20 01:26:48 --> Total execution time: 0.0551
INFO - 2016-12-20 01:27:19 --> Config Class Initialized
INFO - 2016-12-20 01:27:19 --> Hooks Class Initialized
DEBUG - 2016-12-20 01:27:19 --> UTF-8 Support Enabled
INFO - 2016-12-20 01:27:19 --> Utf8 Class Initialized
INFO - 2016-12-20 01:27:19 --> URI Class Initialized
INFO - 2016-12-20 01:27:19 --> Router Class Initialized
INFO - 2016-12-20 01:27:19 --> Output Class Initialized
INFO - 2016-12-20 01:27:19 --> Security Class Initialized
DEBUG - 2016-12-20 01:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 01:27:19 --> Input Class Initialized
INFO - 2016-12-20 01:27:19 --> Language Class Initialized
INFO - 2016-12-20 01:27:19 --> Loader Class Initialized
INFO - 2016-12-20 01:27:19 --> Database Driver Class Initialized
INFO - 2016-12-20 01:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 01:27:19 --> Controller Class Initialized
INFO - 2016-12-20 01:27:19 --> Helper loaded: url_helper
DEBUG - 2016-12-20 01:27:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 01:27:22 --> Config Class Initialized
INFO - 2016-12-20 01:27:22 --> Hooks Class Initialized
DEBUG - 2016-12-20 01:27:22 --> UTF-8 Support Enabled
INFO - 2016-12-20 01:27:22 --> Utf8 Class Initialized
INFO - 2016-12-20 01:27:22 --> URI Class Initialized
INFO - 2016-12-20 01:27:22 --> Router Class Initialized
INFO - 2016-12-20 01:27:22 --> Output Class Initialized
INFO - 2016-12-20 01:27:22 --> Security Class Initialized
DEBUG - 2016-12-20 01:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 01:27:22 --> Input Class Initialized
INFO - 2016-12-20 01:27:22 --> Language Class Initialized
INFO - 2016-12-20 01:27:22 --> Loader Class Initialized
INFO - 2016-12-20 01:27:22 --> Database Driver Class Initialized
INFO - 2016-12-20 01:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 01:27:22 --> Controller Class Initialized
INFO - 2016-12-20 01:27:22 --> Helper loaded: date_helper
DEBUG - 2016-12-20 01:27:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 01:27:22 --> Helper loaded: url_helper
INFO - 2016-12-20 01:27:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 01:27:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-20 01:27:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-20 01:27:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-20 01:27:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 01:27:22 --> Final output sent to browser
DEBUG - 2016-12-20 01:27:22 --> Total execution time: 0.3498
INFO - 2016-12-20 01:27:23 --> Config Class Initialized
INFO - 2016-12-20 01:27:23 --> Hooks Class Initialized
DEBUG - 2016-12-20 01:27:23 --> UTF-8 Support Enabled
INFO - 2016-12-20 01:27:23 --> Utf8 Class Initialized
INFO - 2016-12-20 01:27:23 --> URI Class Initialized
INFO - 2016-12-20 01:27:23 --> Router Class Initialized
INFO - 2016-12-20 01:27:23 --> Output Class Initialized
INFO - 2016-12-20 01:27:23 --> Security Class Initialized
DEBUG - 2016-12-20 01:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 01:27:23 --> Input Class Initialized
INFO - 2016-12-20 01:27:23 --> Language Class Initialized
INFO - 2016-12-20 01:27:23 --> Loader Class Initialized
INFO - 2016-12-20 01:27:23 --> Database Driver Class Initialized
INFO - 2016-12-20 01:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 01:27:23 --> Controller Class Initialized
INFO - 2016-12-20 01:27:23 --> Helper loaded: url_helper
DEBUG - 2016-12-20 01:27:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 01:27:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 01:27:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-20 01:27:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-20 01:27:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 01:27:23 --> Final output sent to browser
DEBUG - 2016-12-20 01:27:23 --> Total execution time: 0.0129
INFO - 2016-12-20 01:27:42 --> Config Class Initialized
INFO - 2016-12-20 01:27:42 --> Hooks Class Initialized
DEBUG - 2016-12-20 01:27:42 --> UTF-8 Support Enabled
INFO - 2016-12-20 01:27:42 --> Utf8 Class Initialized
INFO - 2016-12-20 01:27:42 --> URI Class Initialized
INFO - 2016-12-20 01:27:42 --> Router Class Initialized
INFO - 2016-12-20 01:27:42 --> Output Class Initialized
INFO - 2016-12-20 01:27:42 --> Security Class Initialized
DEBUG - 2016-12-20 01:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 01:27:42 --> Input Class Initialized
INFO - 2016-12-20 01:27:42 --> Language Class Initialized
INFO - 2016-12-20 01:27:42 --> Loader Class Initialized
INFO - 2016-12-20 01:27:42 --> Database Driver Class Initialized
INFO - 2016-12-20 01:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 01:27:42 --> Controller Class Initialized
INFO - 2016-12-20 01:27:42 --> Helper loaded: date_helper
DEBUG - 2016-12-20 01:27:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 01:27:42 --> Helper loaded: url_helper
INFO - 2016-12-20 01:27:42 --> Helper loaded: download_helper
INFO - 2016-12-20 01:27:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 01:27:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-20 01:27:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-20 01:27:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-20 01:27:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 01:27:42 --> Final output sent to browser
DEBUG - 2016-12-20 01:27:42 --> Total execution time: 0.1112
INFO - 2016-12-20 01:27:43 --> Config Class Initialized
INFO - 2016-12-20 01:27:43 --> Hooks Class Initialized
DEBUG - 2016-12-20 01:27:43 --> UTF-8 Support Enabled
INFO - 2016-12-20 01:27:43 --> Utf8 Class Initialized
INFO - 2016-12-20 01:27:43 --> URI Class Initialized
INFO - 2016-12-20 01:27:43 --> Router Class Initialized
INFO - 2016-12-20 01:27:43 --> Output Class Initialized
INFO - 2016-12-20 01:27:43 --> Security Class Initialized
DEBUG - 2016-12-20 01:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 01:27:43 --> Input Class Initialized
INFO - 2016-12-20 01:27:43 --> Language Class Initialized
INFO - 2016-12-20 01:27:43 --> Loader Class Initialized
INFO - 2016-12-20 01:27:43 --> Database Driver Class Initialized
INFO - 2016-12-20 01:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 01:27:43 --> Controller Class Initialized
INFO - 2016-12-20 01:27:43 --> Helper loaded: url_helper
DEBUG - 2016-12-20 01:27:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 01:27:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 01:27:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-20 01:27:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-20 01:27:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 01:27:43 --> Final output sent to browser
DEBUG - 2016-12-20 01:27:43 --> Total execution time: 0.0134
INFO - 2016-12-20 01:28:11 --> Config Class Initialized
INFO - 2016-12-20 01:28:11 --> Hooks Class Initialized
DEBUG - 2016-12-20 01:28:11 --> UTF-8 Support Enabled
INFO - 2016-12-20 01:28:11 --> Utf8 Class Initialized
INFO - 2016-12-20 01:28:11 --> URI Class Initialized
INFO - 2016-12-20 01:28:11 --> Router Class Initialized
INFO - 2016-12-20 01:28:11 --> Output Class Initialized
INFO - 2016-12-20 01:28:11 --> Security Class Initialized
DEBUG - 2016-12-20 01:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 01:28:11 --> Input Class Initialized
INFO - 2016-12-20 01:28:11 --> Language Class Initialized
INFO - 2016-12-20 01:28:11 --> Loader Class Initialized
INFO - 2016-12-20 01:28:11 --> Database Driver Class Initialized
INFO - 2016-12-20 01:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 01:28:11 --> Controller Class Initialized
INFO - 2016-12-20 01:28:11 --> Helper loaded: date_helper
DEBUG - 2016-12-20 01:28:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 01:28:11 --> Helper loaded: url_helper
INFO - 2016-12-20 01:28:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 01:28:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-20 01:28:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-20 01:28:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-20 01:28:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-20 01:28:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 01:28:11 --> Final output sent to browser
DEBUG - 2016-12-20 01:28:11 --> Total execution time: 0.1283
INFO - 2016-12-20 01:28:12 --> Config Class Initialized
INFO - 2016-12-20 01:28:12 --> Hooks Class Initialized
DEBUG - 2016-12-20 01:28:12 --> UTF-8 Support Enabled
INFO - 2016-12-20 01:28:12 --> Utf8 Class Initialized
INFO - 2016-12-20 01:28:12 --> URI Class Initialized
INFO - 2016-12-20 01:28:12 --> Router Class Initialized
INFO - 2016-12-20 01:28:12 --> Output Class Initialized
INFO - 2016-12-20 01:28:12 --> Security Class Initialized
DEBUG - 2016-12-20 01:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 01:28:12 --> Input Class Initialized
INFO - 2016-12-20 01:28:12 --> Language Class Initialized
INFO - 2016-12-20 01:28:12 --> Loader Class Initialized
INFO - 2016-12-20 01:28:12 --> Database Driver Class Initialized
INFO - 2016-12-20 01:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 01:28:12 --> Controller Class Initialized
INFO - 2016-12-20 01:28:12 --> Helper loaded: url_helper
DEBUG - 2016-12-20 01:28:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 01:28:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 01:28:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-20 01:28:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-20 01:28:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 01:28:12 --> Final output sent to browser
DEBUG - 2016-12-20 01:28:12 --> Total execution time: 0.0137
INFO - 2016-12-20 01:28:16 --> Config Class Initialized
INFO - 2016-12-20 01:28:16 --> Hooks Class Initialized
DEBUG - 2016-12-20 01:28:16 --> UTF-8 Support Enabled
INFO - 2016-12-20 01:28:16 --> Utf8 Class Initialized
INFO - 2016-12-20 01:28:16 --> URI Class Initialized
INFO - 2016-12-20 01:28:16 --> Router Class Initialized
INFO - 2016-12-20 01:28:16 --> Output Class Initialized
INFO - 2016-12-20 01:28:16 --> Security Class Initialized
DEBUG - 2016-12-20 01:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 01:28:16 --> Input Class Initialized
INFO - 2016-12-20 01:28:16 --> Language Class Initialized
INFO - 2016-12-20 01:28:16 --> Loader Class Initialized
INFO - 2016-12-20 01:28:16 --> Database Driver Class Initialized
INFO - 2016-12-20 01:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 01:28:16 --> Controller Class Initialized
INFO - 2016-12-20 01:28:16 --> Upload Class Initialized
INFO - 2016-12-20 01:28:16 --> Helper loaded: date_helper
DEBUG - 2016-12-20 01:28:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 01:28:16 --> Helper loaded: url_helper
INFO - 2016-12-20 01:28:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 01:28:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-20 01:28:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-20 01:28:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-20 01:28:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-20 01:28:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 01:28:16 --> Final output sent to browser
DEBUG - 2016-12-20 01:28:16 --> Total execution time: 0.1225
INFO - 2016-12-20 01:28:16 --> Config Class Initialized
INFO - 2016-12-20 01:28:16 --> Hooks Class Initialized
DEBUG - 2016-12-20 01:28:16 --> UTF-8 Support Enabled
INFO - 2016-12-20 01:28:16 --> Utf8 Class Initialized
INFO - 2016-12-20 01:28:16 --> URI Class Initialized
INFO - 2016-12-20 01:28:16 --> Router Class Initialized
INFO - 2016-12-20 01:28:16 --> Output Class Initialized
INFO - 2016-12-20 01:28:16 --> Security Class Initialized
DEBUG - 2016-12-20 01:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 01:28:16 --> Input Class Initialized
INFO - 2016-12-20 01:28:16 --> Language Class Initialized
INFO - 2016-12-20 01:28:16 --> Loader Class Initialized
INFO - 2016-12-20 01:28:16 --> Database Driver Class Initialized
INFO - 2016-12-20 01:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 01:28:16 --> Controller Class Initialized
INFO - 2016-12-20 01:28:16 --> Helper loaded: url_helper
DEBUG - 2016-12-20 01:28:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 01:28:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 01:28:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-20 01:28:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-20 01:28:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 01:28:16 --> Final output sent to browser
DEBUG - 2016-12-20 01:28:16 --> Total execution time: 0.0138
INFO - 2016-12-20 02:40:56 --> Config Class Initialized
INFO - 2016-12-20 02:40:56 --> Hooks Class Initialized
DEBUG - 2016-12-20 02:40:56 --> UTF-8 Support Enabled
INFO - 2016-12-20 02:40:56 --> Utf8 Class Initialized
INFO - 2016-12-20 02:40:56 --> URI Class Initialized
DEBUG - 2016-12-20 02:40:56 --> No URI present. Default controller set.
INFO - 2016-12-20 02:40:56 --> Router Class Initialized
INFO - 2016-12-20 02:40:56 --> Output Class Initialized
INFO - 2016-12-20 02:40:56 --> Security Class Initialized
DEBUG - 2016-12-20 02:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 02:40:56 --> Input Class Initialized
INFO - 2016-12-20 02:40:56 --> Language Class Initialized
INFO - 2016-12-20 02:40:56 --> Loader Class Initialized
INFO - 2016-12-20 02:40:57 --> Database Driver Class Initialized
INFO - 2016-12-20 02:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 02:40:57 --> Controller Class Initialized
INFO - 2016-12-20 02:40:57 --> Helper loaded: url_helper
DEBUG - 2016-12-20 02:40:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 02:40:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 02:40:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-20 02:40:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-20 02:40:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 02:40:57 --> Final output sent to browser
DEBUG - 2016-12-20 02:40:57 --> Total execution time: 1.7145
INFO - 2016-12-20 03:36:33 --> Config Class Initialized
INFO - 2016-12-20 03:36:33 --> Hooks Class Initialized
DEBUG - 2016-12-20 03:36:33 --> UTF-8 Support Enabled
INFO - 2016-12-20 03:36:33 --> Utf8 Class Initialized
INFO - 2016-12-20 03:36:33 --> URI Class Initialized
DEBUG - 2016-12-20 03:36:33 --> No URI present. Default controller set.
INFO - 2016-12-20 03:36:33 --> Router Class Initialized
INFO - 2016-12-20 03:36:33 --> Output Class Initialized
INFO - 2016-12-20 03:36:33 --> Security Class Initialized
DEBUG - 2016-12-20 03:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 03:36:33 --> Input Class Initialized
INFO - 2016-12-20 03:36:33 --> Language Class Initialized
INFO - 2016-12-20 03:36:34 --> Loader Class Initialized
INFO - 2016-12-20 03:36:34 --> Database Driver Class Initialized
INFO - 2016-12-20 03:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 03:36:34 --> Controller Class Initialized
INFO - 2016-12-20 03:36:34 --> Helper loaded: url_helper
DEBUG - 2016-12-20 03:36:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 03:36:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 03:36:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-20 03:36:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-20 03:36:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 03:36:35 --> Final output sent to browser
DEBUG - 2016-12-20 03:36:35 --> Total execution time: 1.7178
INFO - 2016-12-20 12:28:31 --> Config Class Initialized
INFO - 2016-12-20 12:28:31 --> Hooks Class Initialized
DEBUG - 2016-12-20 12:28:31 --> UTF-8 Support Enabled
INFO - 2016-12-20 12:28:31 --> Utf8 Class Initialized
INFO - 2016-12-20 12:28:31 --> URI Class Initialized
INFO - 2016-12-20 12:28:31 --> Router Class Initialized
INFO - 2016-12-20 12:28:31 --> Output Class Initialized
INFO - 2016-12-20 12:28:31 --> Security Class Initialized
DEBUG - 2016-12-20 12:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 12:28:31 --> Input Class Initialized
INFO - 2016-12-20 12:28:31 --> Language Class Initialized
INFO - 2016-12-20 12:28:31 --> Loader Class Initialized
INFO - 2016-12-20 12:28:31 --> Database Driver Class Initialized
INFO - 2016-12-20 12:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 12:28:32 --> Controller Class Initialized
INFO - 2016-12-20 12:28:32 --> Helper loaded: url_helper
DEBUG - 2016-12-20 12:28:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 12:28:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 12:28:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-20 12:28:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-20 12:28:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 12:28:32 --> Final output sent to browser
DEBUG - 2016-12-20 12:28:32 --> Total execution time: 1.7543
INFO - 2016-12-20 12:28:33 --> Config Class Initialized
INFO - 2016-12-20 12:28:33 --> Hooks Class Initialized
DEBUG - 2016-12-20 12:28:33 --> UTF-8 Support Enabled
INFO - 2016-12-20 12:28:33 --> Utf8 Class Initialized
INFO - 2016-12-20 12:28:33 --> URI Class Initialized
DEBUG - 2016-12-20 12:28:33 --> No URI present. Default controller set.
INFO - 2016-12-20 12:28:33 --> Router Class Initialized
INFO - 2016-12-20 12:28:33 --> Output Class Initialized
INFO - 2016-12-20 12:28:33 --> Security Class Initialized
DEBUG - 2016-12-20 12:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 12:28:33 --> Input Class Initialized
INFO - 2016-12-20 12:28:33 --> Language Class Initialized
INFO - 2016-12-20 12:28:33 --> Loader Class Initialized
INFO - 2016-12-20 12:28:33 --> Database Driver Class Initialized
INFO - 2016-12-20 12:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 12:28:33 --> Controller Class Initialized
INFO - 2016-12-20 12:28:33 --> Helper loaded: url_helper
DEBUG - 2016-12-20 12:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 12:28:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 12:28:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-20 12:28:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-20 12:28:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 12:28:33 --> Final output sent to browser
DEBUG - 2016-12-20 12:28:33 --> Total execution time: 0.0134
INFO - 2016-12-20 21:03:08 --> Config Class Initialized
INFO - 2016-12-20 21:03:08 --> Hooks Class Initialized
DEBUG - 2016-12-20 21:03:08 --> UTF-8 Support Enabled
INFO - 2016-12-20 21:03:08 --> Utf8 Class Initialized
INFO - 2016-12-20 21:03:08 --> URI Class Initialized
DEBUG - 2016-12-20 21:03:08 --> No URI present. Default controller set.
INFO - 2016-12-20 21:03:08 --> Router Class Initialized
INFO - 2016-12-20 21:03:08 --> Output Class Initialized
INFO - 2016-12-20 21:03:08 --> Security Class Initialized
DEBUG - 2016-12-20 21:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 21:03:08 --> Input Class Initialized
INFO - 2016-12-20 21:03:08 --> Language Class Initialized
INFO - 2016-12-20 21:03:08 --> Loader Class Initialized
INFO - 2016-12-20 21:03:09 --> Database Driver Class Initialized
INFO - 2016-12-20 21:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 21:03:09 --> Controller Class Initialized
INFO - 2016-12-20 21:03:09 --> Helper loaded: url_helper
DEBUG - 2016-12-20 21:03:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 21:03:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 21:03:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-20 21:03:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-20 21:03:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 21:03:10 --> Final output sent to browser
DEBUG - 2016-12-20 21:03:10 --> Total execution time: 2.2257
INFO - 2016-12-20 21:03:30 --> Config Class Initialized
INFO - 2016-12-20 21:03:30 --> Hooks Class Initialized
DEBUG - 2016-12-20 21:03:30 --> UTF-8 Support Enabled
INFO - 2016-12-20 21:03:30 --> Utf8 Class Initialized
INFO - 2016-12-20 21:03:30 --> URI Class Initialized
INFO - 2016-12-20 21:03:30 --> Router Class Initialized
INFO - 2016-12-20 21:03:30 --> Output Class Initialized
INFO - 2016-12-20 21:03:30 --> Security Class Initialized
DEBUG - 2016-12-20 21:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 21:03:30 --> Input Class Initialized
INFO - 2016-12-20 21:03:30 --> Language Class Initialized
INFO - 2016-12-20 21:03:30 --> Loader Class Initialized
INFO - 2016-12-20 21:03:30 --> Database Driver Class Initialized
INFO - 2016-12-20 21:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 21:03:30 --> Controller Class Initialized
INFO - 2016-12-20 21:03:30 --> Helper loaded: url_helper
DEBUG - 2016-12-20 21:03:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 21:03:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 21:03:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-20 21:03:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-20 21:03:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 21:03:30 --> Final output sent to browser
DEBUG - 2016-12-20 21:03:30 --> Total execution time: 0.4090
INFO - 2016-12-20 21:04:31 --> Config Class Initialized
INFO - 2016-12-20 21:04:31 --> Hooks Class Initialized
DEBUG - 2016-12-20 21:04:31 --> UTF-8 Support Enabled
INFO - 2016-12-20 21:04:31 --> Utf8 Class Initialized
INFO - 2016-12-20 21:04:31 --> URI Class Initialized
INFO - 2016-12-20 21:04:31 --> Router Class Initialized
INFO - 2016-12-20 21:04:31 --> Output Class Initialized
INFO - 2016-12-20 21:04:31 --> Security Class Initialized
DEBUG - 2016-12-20 21:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 21:04:31 --> Input Class Initialized
INFO - 2016-12-20 21:04:31 --> Language Class Initialized
INFO - 2016-12-20 21:04:31 --> Loader Class Initialized
INFO - 2016-12-20 21:04:32 --> Database Driver Class Initialized
INFO - 2016-12-20 21:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 21:04:32 --> Controller Class Initialized
INFO - 2016-12-20 21:04:32 --> Helper loaded: url_helper
DEBUG - 2016-12-20 21:04:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 21:04:33 --> Config Class Initialized
INFO - 2016-12-20 21:04:33 --> Hooks Class Initialized
DEBUG - 2016-12-20 21:04:33 --> UTF-8 Support Enabled
INFO - 2016-12-20 21:04:33 --> Utf8 Class Initialized
INFO - 2016-12-20 21:04:33 --> URI Class Initialized
INFO - 2016-12-20 21:04:33 --> Router Class Initialized
INFO - 2016-12-20 21:04:33 --> Output Class Initialized
INFO - 2016-12-20 21:04:33 --> Security Class Initialized
DEBUG - 2016-12-20 21:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 21:04:33 --> Input Class Initialized
INFO - 2016-12-20 21:04:33 --> Language Class Initialized
INFO - 2016-12-20 21:04:33 --> Loader Class Initialized
INFO - 2016-12-20 21:04:33 --> Database Driver Class Initialized
INFO - 2016-12-20 21:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 21:04:33 --> Controller Class Initialized
INFO - 2016-12-20 21:04:33 --> Helper loaded: date_helper
DEBUG - 2016-12-20 21:04:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 21:04:33 --> Helper loaded: url_helper
INFO - 2016-12-20 21:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 21:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2016-12-20 21:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2016-12-20 21:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-20 21:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 21:04:33 --> Final output sent to browser
DEBUG - 2016-12-20 21:04:33 --> Total execution time: 0.4397
INFO - 2016-12-20 21:04:35 --> Config Class Initialized
INFO - 2016-12-20 21:04:35 --> Hooks Class Initialized
DEBUG - 2016-12-20 21:04:35 --> UTF-8 Support Enabled
INFO - 2016-12-20 21:04:35 --> Utf8 Class Initialized
INFO - 2016-12-20 21:04:35 --> URI Class Initialized
INFO - 2016-12-20 21:04:35 --> Router Class Initialized
INFO - 2016-12-20 21:04:35 --> Output Class Initialized
INFO - 2016-12-20 21:04:35 --> Security Class Initialized
DEBUG - 2016-12-20 21:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 21:04:35 --> Input Class Initialized
INFO - 2016-12-20 21:04:35 --> Language Class Initialized
INFO - 2016-12-20 21:04:35 --> Loader Class Initialized
INFO - 2016-12-20 21:04:35 --> Database Driver Class Initialized
INFO - 2016-12-20 21:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 21:04:35 --> Controller Class Initialized
INFO - 2016-12-20 21:04:35 --> Helper loaded: url_helper
DEBUG - 2016-12-20 21:04:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 21:04:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 21:04:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-20 21:04:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-20 21:04:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 21:04:35 --> Final output sent to browser
DEBUG - 2016-12-20 21:04:35 --> Total execution time: 0.0336
INFO - 2016-12-20 21:04:45 --> Config Class Initialized
INFO - 2016-12-20 21:04:45 --> Hooks Class Initialized
DEBUG - 2016-12-20 21:04:45 --> UTF-8 Support Enabled
INFO - 2016-12-20 21:04:45 --> Utf8 Class Initialized
INFO - 2016-12-20 21:04:45 --> URI Class Initialized
DEBUG - 2016-12-20 21:04:45 --> No URI present. Default controller set.
INFO - 2016-12-20 21:04:45 --> Router Class Initialized
INFO - 2016-12-20 21:04:45 --> Output Class Initialized
INFO - 2016-12-20 21:04:45 --> Security Class Initialized
DEBUG - 2016-12-20 21:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 21:04:45 --> Input Class Initialized
INFO - 2016-12-20 21:04:45 --> Language Class Initialized
INFO - 2016-12-20 21:04:45 --> Loader Class Initialized
INFO - 2016-12-20 21:04:45 --> Database Driver Class Initialized
INFO - 2016-12-20 21:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 21:04:45 --> Controller Class Initialized
INFO - 2016-12-20 21:04:45 --> Helper loaded: url_helper
DEBUG - 2016-12-20 21:04:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 21:04:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 21:04:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-20 21:04:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-20 21:04:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 21:04:45 --> Final output sent to browser
DEBUG - 2016-12-20 21:04:45 --> Total execution time: 0.0131
INFO - 2016-12-20 21:04:46 --> Config Class Initialized
INFO - 2016-12-20 21:04:46 --> Hooks Class Initialized
DEBUG - 2016-12-20 21:04:46 --> UTF-8 Support Enabled
INFO - 2016-12-20 21:04:46 --> Utf8 Class Initialized
INFO - 2016-12-20 21:04:46 --> URI Class Initialized
INFO - 2016-12-20 21:04:46 --> Router Class Initialized
INFO - 2016-12-20 21:04:46 --> Output Class Initialized
INFO - 2016-12-20 21:04:46 --> Security Class Initialized
DEBUG - 2016-12-20 21:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 21:04:46 --> Input Class Initialized
INFO - 2016-12-20 21:04:46 --> Language Class Initialized
INFO - 2016-12-20 21:04:46 --> Loader Class Initialized
INFO - 2016-12-20 21:04:46 --> Database Driver Class Initialized
INFO - 2016-12-20 21:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 21:04:46 --> Controller Class Initialized
INFO - 2016-12-20 21:04:46 --> Helper loaded: url_helper
DEBUG - 2016-12-20 21:04:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 21:04:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 21:04:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-20 21:04:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-20 21:04:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 21:04:46 --> Final output sent to browser
DEBUG - 2016-12-20 21:04:46 --> Total execution time: 0.0131
INFO - 2016-12-20 22:07:08 --> Config Class Initialized
INFO - 2016-12-20 22:07:08 --> Hooks Class Initialized
DEBUG - 2016-12-20 22:07:08 --> UTF-8 Support Enabled
INFO - 2016-12-20 22:07:08 --> Utf8 Class Initialized
INFO - 2016-12-20 22:07:08 --> URI Class Initialized
DEBUG - 2016-12-20 22:07:09 --> No URI present. Default controller set.
INFO - 2016-12-20 22:07:09 --> Router Class Initialized
INFO - 2016-12-20 22:07:09 --> Output Class Initialized
INFO - 2016-12-20 22:07:09 --> Security Class Initialized
DEBUG - 2016-12-20 22:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 22:07:09 --> Input Class Initialized
INFO - 2016-12-20 22:07:09 --> Language Class Initialized
INFO - 2016-12-20 22:07:09 --> Loader Class Initialized
INFO - 2016-12-20 22:07:09 --> Database Driver Class Initialized
INFO - 2016-12-20 22:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 22:07:09 --> Controller Class Initialized
INFO - 2016-12-20 22:07:09 --> Helper loaded: url_helper
DEBUG - 2016-12-20 22:07:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 22:07:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 22:07:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-20 22:07:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-20 22:07:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 22:07:10 --> Final output sent to browser
DEBUG - 2016-12-20 22:07:10 --> Total execution time: 1.4366
INFO - 2016-12-20 22:07:10 --> Config Class Initialized
INFO - 2016-12-20 22:07:10 --> Hooks Class Initialized
DEBUG - 2016-12-20 22:07:10 --> UTF-8 Support Enabled
INFO - 2016-12-20 22:07:10 --> Utf8 Class Initialized
INFO - 2016-12-20 22:07:10 --> URI Class Initialized
INFO - 2016-12-20 22:07:10 --> Router Class Initialized
INFO - 2016-12-20 22:07:10 --> Output Class Initialized
INFO - 2016-12-20 22:07:10 --> Security Class Initialized
DEBUG - 2016-12-20 22:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-20 22:07:10 --> Input Class Initialized
INFO - 2016-12-20 22:07:10 --> Language Class Initialized
INFO - 2016-12-20 22:07:10 --> Loader Class Initialized
INFO - 2016-12-20 22:07:10 --> Database Driver Class Initialized
INFO - 2016-12-20 22:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-20 22:07:10 --> Controller Class Initialized
INFO - 2016-12-20 22:07:10 --> Helper loaded: url_helper
DEBUG - 2016-12-20 22:07:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-20 22:07:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-20 22:07:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-20 22:07:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-20 22:07:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-20 22:07:10 --> Final output sent to browser
DEBUG - 2016-12-20 22:07:10 --> Total execution time: 0.0134

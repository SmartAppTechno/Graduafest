<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-11 00:10:09 --> Config Class Initialized
INFO - 2017-01-11 00:10:09 --> Hooks Class Initialized
DEBUG - 2017-01-11 00:10:09 --> UTF-8 Support Enabled
INFO - 2017-01-11 00:10:09 --> Utf8 Class Initialized
INFO - 2017-01-11 00:10:09 --> URI Class Initialized
DEBUG - 2017-01-11 00:10:09 --> No URI present. Default controller set.
INFO - 2017-01-11 00:10:09 --> Router Class Initialized
INFO - 2017-01-11 00:10:09 --> Output Class Initialized
INFO - 2017-01-11 00:10:09 --> Security Class Initialized
DEBUG - 2017-01-11 00:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 00:10:09 --> Input Class Initialized
INFO - 2017-01-11 00:10:09 --> Language Class Initialized
INFO - 2017-01-11 00:10:09 --> Loader Class Initialized
INFO - 2017-01-11 00:10:10 --> Database Driver Class Initialized
INFO - 2017-01-11 00:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 00:10:10 --> Controller Class Initialized
INFO - 2017-01-11 00:10:10 --> Helper loaded: url_helper
DEBUG - 2017-01-11 00:10:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 00:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-11 00:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-11 00:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-11 00:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-11 00:10:10 --> Final output sent to browser
DEBUG - 2017-01-11 00:10:10 --> Total execution time: 1.6564
INFO - 2017-01-11 00:10:13 --> Config Class Initialized
INFO - 2017-01-11 00:10:13 --> Hooks Class Initialized
DEBUG - 2017-01-11 00:10:13 --> UTF-8 Support Enabled
INFO - 2017-01-11 00:10:13 --> Utf8 Class Initialized
INFO - 2017-01-11 00:10:13 --> URI Class Initialized
INFO - 2017-01-11 00:10:13 --> Router Class Initialized
INFO - 2017-01-11 00:10:13 --> Output Class Initialized
INFO - 2017-01-11 00:10:13 --> Security Class Initialized
DEBUG - 2017-01-11 00:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 00:10:13 --> Input Class Initialized
INFO - 2017-01-11 00:10:13 --> Language Class Initialized
INFO - 2017-01-11 00:10:13 --> Loader Class Initialized
INFO - 2017-01-11 00:10:13 --> Database Driver Class Initialized
INFO - 2017-01-11 00:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 00:10:13 --> Controller Class Initialized
INFO - 2017-01-11 00:10:13 --> Helper loaded: url_helper
DEBUG - 2017-01-11 00:10:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 00:10:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-11 00:10:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-11 00:10:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-11 00:10:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-11 00:10:13 --> Final output sent to browser
DEBUG - 2017-01-11 00:10:13 --> Total execution time: 0.0140
INFO - 2017-01-11 00:10:25 --> Config Class Initialized
INFO - 2017-01-11 00:10:25 --> Hooks Class Initialized
DEBUG - 2017-01-11 00:10:25 --> UTF-8 Support Enabled
INFO - 2017-01-11 00:10:25 --> Utf8 Class Initialized
INFO - 2017-01-11 00:10:25 --> URI Class Initialized
INFO - 2017-01-11 00:10:25 --> Router Class Initialized
INFO - 2017-01-11 00:10:25 --> Output Class Initialized
INFO - 2017-01-11 00:10:25 --> Security Class Initialized
DEBUG - 2017-01-11 00:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 00:10:25 --> Input Class Initialized
INFO - 2017-01-11 00:10:25 --> Language Class Initialized
INFO - 2017-01-11 00:10:25 --> Loader Class Initialized
INFO - 2017-01-11 00:10:25 --> Database Driver Class Initialized
INFO - 2017-01-11 00:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 00:10:25 --> Controller Class Initialized
INFO - 2017-01-11 00:10:25 --> Helper loaded: url_helper
DEBUG - 2017-01-11 00:10:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 00:10:25 --> Helper loaded: form_helper
INFO - 2017-01-11 00:10:26 --> Form Validation Class Initialized
INFO - 2017-01-11 00:10:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-11 00:10:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-11 00:10:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-11 00:10:26 --> Final output sent to browser
DEBUG - 2017-01-11 00:10:26 --> Total execution time: 0.1838
INFO - 2017-01-11 00:10:26 --> Config Class Initialized
INFO - 2017-01-11 00:10:26 --> Hooks Class Initialized
DEBUG - 2017-01-11 00:10:26 --> UTF-8 Support Enabled
INFO - 2017-01-11 00:10:26 --> Utf8 Class Initialized
INFO - 2017-01-11 00:10:26 --> URI Class Initialized
INFO - 2017-01-11 00:10:26 --> Router Class Initialized
INFO - 2017-01-11 00:10:26 --> Output Class Initialized
INFO - 2017-01-11 00:10:26 --> Security Class Initialized
DEBUG - 2017-01-11 00:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 00:10:26 --> Input Class Initialized
INFO - 2017-01-11 00:10:26 --> Language Class Initialized
INFO - 2017-01-11 00:10:26 --> Loader Class Initialized
INFO - 2017-01-11 00:10:26 --> Database Driver Class Initialized
INFO - 2017-01-11 00:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 00:10:26 --> Controller Class Initialized
INFO - 2017-01-11 00:10:26 --> Helper loaded: url_helper
DEBUG - 2017-01-11 00:10:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 00:10:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-11 00:10:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-11 00:10:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-11 00:10:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-11 00:10:26 --> Final output sent to browser
DEBUG - 2017-01-11 00:10:26 --> Total execution time: 0.0133
INFO - 2017-01-11 00:10:27 --> Config Class Initialized
INFO - 2017-01-11 00:10:27 --> Hooks Class Initialized
DEBUG - 2017-01-11 00:10:27 --> UTF-8 Support Enabled
INFO - 2017-01-11 00:10:27 --> Utf8 Class Initialized
INFO - 2017-01-11 00:10:27 --> URI Class Initialized
INFO - 2017-01-11 00:10:27 --> Router Class Initialized
INFO - 2017-01-11 00:10:27 --> Output Class Initialized
INFO - 2017-01-11 00:10:27 --> Security Class Initialized
DEBUG - 2017-01-11 00:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 00:10:27 --> Input Class Initialized
INFO - 2017-01-11 00:10:27 --> Language Class Initialized
INFO - 2017-01-11 00:10:27 --> Loader Class Initialized
INFO - 2017-01-11 00:10:27 --> Database Driver Class Initialized
INFO - 2017-01-11 00:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 00:10:27 --> Controller Class Initialized
INFO - 2017-01-11 00:10:27 --> Helper loaded: url_helper
DEBUG - 2017-01-11 00:10:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 00:10:27 --> Helper loaded: form_helper
INFO - 2017-01-11 00:10:27 --> Form Validation Class Initialized
INFO - 2017-01-11 00:10:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-11 00:10:28 --> Config Class Initialized
INFO - 2017-01-11 00:10:28 --> Hooks Class Initialized
DEBUG - 2017-01-11 00:10:28 --> UTF-8 Support Enabled
INFO - 2017-01-11 00:10:28 --> Utf8 Class Initialized
INFO - 2017-01-11 00:10:28 --> URI Class Initialized
INFO - 2017-01-11 00:10:28 --> Router Class Initialized
INFO - 2017-01-11 00:10:28 --> Output Class Initialized
INFO - 2017-01-11 00:10:28 --> Security Class Initialized
DEBUG - 2017-01-11 00:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 00:10:28 --> Input Class Initialized
INFO - 2017-01-11 00:10:28 --> Language Class Initialized
INFO - 2017-01-11 00:10:28 --> Loader Class Initialized
INFO - 2017-01-11 00:10:28 --> Database Driver Class Initialized
INFO - 2017-01-11 00:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 00:10:28 --> Controller Class Initialized
INFO - 2017-01-11 00:10:28 --> Helper loaded: date_helper
INFO - 2017-01-11 00:10:28 --> Helper loaded: url_helper
DEBUG - 2017-01-11 00:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 00:10:28 --> Helper loaded: form_helper
INFO - 2017-01-11 00:10:28 --> Form Validation Class Initialized
INFO - 2017-01-11 00:10:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-11 00:10:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-11 00:10:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-11 00:10:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-11 00:10:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-11 00:10:28 --> Final output sent to browser
DEBUG - 2017-01-11 00:10:28 --> Total execution time: 0.4053
INFO - 2017-01-11 00:10:29 --> Config Class Initialized
INFO - 2017-01-11 00:10:29 --> Hooks Class Initialized
DEBUG - 2017-01-11 00:10:29 --> UTF-8 Support Enabled
INFO - 2017-01-11 00:10:29 --> Utf8 Class Initialized
INFO - 2017-01-11 00:10:29 --> URI Class Initialized
INFO - 2017-01-11 00:10:29 --> Router Class Initialized
INFO - 2017-01-11 00:10:29 --> Output Class Initialized
INFO - 2017-01-11 00:10:29 --> Security Class Initialized
DEBUG - 2017-01-11 00:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 00:10:29 --> Input Class Initialized
INFO - 2017-01-11 00:10:29 --> Language Class Initialized
INFO - 2017-01-11 00:10:29 --> Loader Class Initialized
INFO - 2017-01-11 00:10:29 --> Database Driver Class Initialized
INFO - 2017-01-11 00:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 00:10:29 --> Controller Class Initialized
INFO - 2017-01-11 00:10:29 --> Helper loaded: date_helper
INFO - 2017-01-11 00:10:29 --> Helper loaded: url_helper
DEBUG - 2017-01-11 00:10:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 00:10:29 --> Helper loaded: form_helper
INFO - 2017-01-11 00:10:29 --> Form Validation Class Initialized
INFO - 2017-01-11 00:10:29 --> Config Class Initialized
INFO - 2017-01-11 00:10:29 --> Hooks Class Initialized
DEBUG - 2017-01-11 00:10:29 --> UTF-8 Support Enabled
INFO - 2017-01-11 00:10:29 --> Utf8 Class Initialized
INFO - 2017-01-11 00:10:29 --> URI Class Initialized
INFO - 2017-01-11 00:10:29 --> Router Class Initialized
INFO - 2017-01-11 00:10:29 --> Output Class Initialized
INFO - 2017-01-11 00:10:29 --> Security Class Initialized
DEBUG - 2017-01-11 00:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 00:10:29 --> Input Class Initialized
INFO - 2017-01-11 00:10:29 --> Language Class Initialized
INFO - 2017-01-11 00:10:29 --> Loader Class Initialized
INFO - 2017-01-11 00:10:29 --> Database Driver Class Initialized
INFO - 2017-01-11 00:10:29 --> Final output sent to browser
DEBUG - 2017-01-11 00:10:29 --> Total execution time: 0.0429
INFO - 2017-01-11 00:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 00:10:29 --> Controller Class Initialized
INFO - 2017-01-11 00:10:29 --> Helper loaded: url_helper
DEBUG - 2017-01-11 00:10:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 00:10:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-11 00:10:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-11 00:10:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-11 00:10:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-11 00:10:29 --> Final output sent to browser
DEBUG - 2017-01-11 00:10:29 --> Total execution time: 0.0334
INFO - 2017-01-11 00:10:34 --> Config Class Initialized
INFO - 2017-01-11 00:10:34 --> Hooks Class Initialized
DEBUG - 2017-01-11 00:10:34 --> UTF-8 Support Enabled
INFO - 2017-01-11 00:10:34 --> Utf8 Class Initialized
INFO - 2017-01-11 00:10:34 --> URI Class Initialized
INFO - 2017-01-11 00:10:34 --> Router Class Initialized
INFO - 2017-01-11 00:10:34 --> Output Class Initialized
INFO - 2017-01-11 00:10:34 --> Security Class Initialized
DEBUG - 2017-01-11 00:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 00:10:34 --> Input Class Initialized
INFO - 2017-01-11 00:10:34 --> Language Class Initialized
INFO - 2017-01-11 00:10:34 --> Loader Class Initialized
INFO - 2017-01-11 00:10:34 --> Database Driver Class Initialized
INFO - 2017-01-11 00:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 00:10:34 --> Controller Class Initialized
INFO - 2017-01-11 00:10:34 --> Upload Class Initialized
INFO - 2017-01-11 00:10:35 --> Helper loaded: url_helper
DEBUG - 2017-01-11 00:10:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 00:10:35 --> Helper loaded: form_helper
INFO - 2017-01-11 00:10:35 --> Form Validation Class Initialized
INFO - 2017-01-11 00:10:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-11 00:10:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-11 00:10:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-11 00:10:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-11 00:10:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-11 00:10:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-11 00:10:35 --> Final output sent to browser
DEBUG - 2017-01-11 00:10:35 --> Total execution time: 0.1548
INFO - 2017-01-11 00:10:35 --> Config Class Initialized
INFO - 2017-01-11 00:10:35 --> Hooks Class Initialized
DEBUG - 2017-01-11 00:10:35 --> UTF-8 Support Enabled
INFO - 2017-01-11 00:10:35 --> Utf8 Class Initialized
INFO - 2017-01-11 00:10:35 --> URI Class Initialized
INFO - 2017-01-11 00:10:35 --> Router Class Initialized
INFO - 2017-01-11 00:10:35 --> Output Class Initialized
INFO - 2017-01-11 00:10:35 --> Security Class Initialized
DEBUG - 2017-01-11 00:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 00:10:35 --> Input Class Initialized
INFO - 2017-01-11 00:10:35 --> Language Class Initialized
INFO - 2017-01-11 00:10:35 --> Loader Class Initialized
INFO - 2017-01-11 00:10:35 --> Database Driver Class Initialized
INFO - 2017-01-11 00:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 00:10:35 --> Controller Class Initialized
INFO - 2017-01-11 00:10:35 --> Helper loaded: url_helper
DEBUG - 2017-01-11 00:10:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 00:10:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-11 00:10:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-11 00:10:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-11 00:10:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-11 00:10:35 --> Final output sent to browser
DEBUG - 2017-01-11 00:10:35 --> Total execution time: 0.0132
INFO - 2017-01-11 00:10:50 --> Config Class Initialized
INFO - 2017-01-11 00:10:50 --> Hooks Class Initialized
DEBUG - 2017-01-11 00:10:50 --> UTF-8 Support Enabled
INFO - 2017-01-11 00:10:50 --> Utf8 Class Initialized
INFO - 2017-01-11 00:10:50 --> URI Class Initialized
INFO - 2017-01-11 00:10:50 --> Router Class Initialized
INFO - 2017-01-11 00:10:50 --> Output Class Initialized
INFO - 2017-01-11 00:10:50 --> Security Class Initialized
DEBUG - 2017-01-11 00:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 00:10:50 --> Input Class Initialized
INFO - 2017-01-11 00:10:50 --> Language Class Initialized
INFO - 2017-01-11 00:10:51 --> Loader Class Initialized
INFO - 2017-01-11 00:10:51 --> Database Driver Class Initialized
INFO - 2017-01-11 00:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 00:10:51 --> Controller Class Initialized
INFO - 2017-01-11 00:10:51 --> Helper loaded: date_helper
INFO - 2017-01-11 00:10:51 --> Helper loaded: url_helper
DEBUG - 2017-01-11 00:10:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 00:10:51 --> Helper loaded: form_helper
INFO - 2017-01-11 00:10:51 --> Form Validation Class Initialized
INFO - 2017-01-11 00:10:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-11 00:10:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-11 00:10:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-11 00:10:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-11 00:10:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-11 00:10:51 --> Final output sent to browser
DEBUG - 2017-01-11 00:10:51 --> Total execution time: 0.1018
INFO - 2017-01-11 00:10:51 --> Config Class Initialized
INFO - 2017-01-11 00:10:51 --> Hooks Class Initialized
DEBUG - 2017-01-11 00:10:51 --> UTF-8 Support Enabled
INFO - 2017-01-11 00:10:51 --> Utf8 Class Initialized
INFO - 2017-01-11 00:10:51 --> URI Class Initialized
INFO - 2017-01-11 00:10:51 --> Router Class Initialized
INFO - 2017-01-11 00:10:51 --> Output Class Initialized
INFO - 2017-01-11 00:10:51 --> Security Class Initialized
DEBUG - 2017-01-11 00:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 00:10:51 --> Input Class Initialized
INFO - 2017-01-11 00:10:51 --> Language Class Initialized
INFO - 2017-01-11 00:10:51 --> Loader Class Initialized
INFO - 2017-01-11 00:10:51 --> Database Driver Class Initialized
INFO - 2017-01-11 00:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 00:10:51 --> Controller Class Initialized
INFO - 2017-01-11 00:10:51 --> Helper loaded: date_helper
INFO - 2017-01-11 00:10:51 --> Helper loaded: url_helper
DEBUG - 2017-01-11 00:10:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 00:10:51 --> Helper loaded: form_helper
INFO - 2017-01-11 00:10:51 --> Form Validation Class Initialized
INFO - 2017-01-11 00:10:51 --> Final output sent to browser
DEBUG - 2017-01-11 00:10:51 --> Total execution time: 0.0227
INFO - 2017-01-11 00:10:51 --> Config Class Initialized
INFO - 2017-01-11 00:10:51 --> Hooks Class Initialized
DEBUG - 2017-01-11 00:10:51 --> UTF-8 Support Enabled
INFO - 2017-01-11 00:10:51 --> Utf8 Class Initialized
INFO - 2017-01-11 00:10:51 --> URI Class Initialized
INFO - 2017-01-11 00:10:51 --> Router Class Initialized
INFO - 2017-01-11 00:10:51 --> Output Class Initialized
INFO - 2017-01-11 00:10:51 --> Security Class Initialized
DEBUG - 2017-01-11 00:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 00:10:51 --> Input Class Initialized
INFO - 2017-01-11 00:10:51 --> Language Class Initialized
INFO - 2017-01-11 00:10:51 --> Loader Class Initialized
INFO - 2017-01-11 00:10:51 --> Database Driver Class Initialized
INFO - 2017-01-11 00:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 00:10:51 --> Controller Class Initialized
INFO - 2017-01-11 00:10:51 --> Helper loaded: url_helper
DEBUG - 2017-01-11 00:10:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 00:10:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-11 00:10:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-11 00:10:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-11 00:10:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-11 00:10:51 --> Final output sent to browser
DEBUG - 2017-01-11 00:10:51 --> Total execution time: 0.0134
INFO - 2017-01-11 00:10:55 --> Config Class Initialized
INFO - 2017-01-11 00:10:55 --> Hooks Class Initialized
DEBUG - 2017-01-11 00:10:55 --> UTF-8 Support Enabled
INFO - 2017-01-11 00:10:55 --> Utf8 Class Initialized
INFO - 2017-01-11 00:10:55 --> URI Class Initialized
INFO - 2017-01-11 00:10:55 --> Router Class Initialized
INFO - 2017-01-11 00:10:55 --> Output Class Initialized
INFO - 2017-01-11 00:10:55 --> Security Class Initialized
DEBUG - 2017-01-11 00:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 00:10:55 --> Input Class Initialized
INFO - 2017-01-11 00:10:55 --> Language Class Initialized
INFO - 2017-01-11 00:10:55 --> Loader Class Initialized
INFO - 2017-01-11 00:10:55 --> Database Driver Class Initialized
INFO - 2017-01-11 00:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 00:10:55 --> Controller Class Initialized
INFO - 2017-01-11 00:10:55 --> Helper loaded: date_helper
INFO - 2017-01-11 00:10:55 --> Helper loaded: url_helper
DEBUG - 2017-01-11 00:10:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 00:10:55 --> Helper loaded: form_helper
INFO - 2017-01-11 00:10:55 --> Form Validation Class Initialized
INFO - 2017-01-11 00:10:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-11 00:10:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-11 00:10:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-11 00:10:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-11 00:10:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-11 00:10:55 --> Final output sent to browser
DEBUG - 2017-01-11 00:10:55 --> Total execution time: 0.0446
INFO - 2017-01-11 00:10:55 --> Config Class Initialized
INFO - 2017-01-11 00:10:55 --> Hooks Class Initialized
DEBUG - 2017-01-11 00:10:55 --> UTF-8 Support Enabled
INFO - 2017-01-11 00:10:55 --> Utf8 Class Initialized
INFO - 2017-01-11 00:10:55 --> URI Class Initialized
INFO - 2017-01-11 00:10:55 --> Router Class Initialized
INFO - 2017-01-11 00:10:55 --> Output Class Initialized
INFO - 2017-01-11 00:10:55 --> Security Class Initialized
DEBUG - 2017-01-11 00:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 00:10:55 --> Input Class Initialized
INFO - 2017-01-11 00:10:55 --> Language Class Initialized
INFO - 2017-01-11 00:10:55 --> Loader Class Initialized
INFO - 2017-01-11 00:10:55 --> Database Driver Class Initialized
INFO - 2017-01-11 00:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 00:10:55 --> Controller Class Initialized
INFO - 2017-01-11 00:10:55 --> Helper loaded: date_helper
INFO - 2017-01-11 00:10:55 --> Helper loaded: url_helper
DEBUG - 2017-01-11 00:10:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 00:10:55 --> Helper loaded: form_helper
INFO - 2017-01-11 00:10:55 --> Form Validation Class Initialized
INFO - 2017-01-11 00:10:55 --> Final output sent to browser
DEBUG - 2017-01-11 00:10:55 --> Total execution time: 0.0142
INFO - 2017-01-11 00:10:55 --> Config Class Initialized
INFO - 2017-01-11 00:10:55 --> Hooks Class Initialized
DEBUG - 2017-01-11 00:10:55 --> UTF-8 Support Enabled
INFO - 2017-01-11 00:10:55 --> Utf8 Class Initialized
INFO - 2017-01-11 00:10:55 --> URI Class Initialized
INFO - 2017-01-11 00:10:55 --> Router Class Initialized
INFO - 2017-01-11 00:10:55 --> Output Class Initialized
INFO - 2017-01-11 00:10:55 --> Security Class Initialized
DEBUG - 2017-01-11 00:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 00:10:55 --> Input Class Initialized
INFO - 2017-01-11 00:10:55 --> Language Class Initialized
INFO - 2017-01-11 00:10:55 --> Loader Class Initialized
INFO - 2017-01-11 00:10:55 --> Database Driver Class Initialized
INFO - 2017-01-11 00:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 00:10:55 --> Controller Class Initialized
INFO - 2017-01-11 00:10:55 --> Helper loaded: url_helper
DEBUG - 2017-01-11 00:10:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 00:10:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-11 00:10:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-11 00:10:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-11 00:10:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-11 00:10:55 --> Final output sent to browser
DEBUG - 2017-01-11 00:10:55 --> Total execution time: 0.0134
INFO - 2017-01-11 00:10:58 --> Config Class Initialized
INFO - 2017-01-11 00:10:58 --> Hooks Class Initialized
DEBUG - 2017-01-11 00:10:58 --> UTF-8 Support Enabled
INFO - 2017-01-11 00:10:58 --> Utf8 Class Initialized
INFO - 2017-01-11 00:10:58 --> URI Class Initialized
INFO - 2017-01-11 00:10:58 --> Router Class Initialized
INFO - 2017-01-11 00:10:58 --> Output Class Initialized
INFO - 2017-01-11 00:10:58 --> Security Class Initialized
DEBUG - 2017-01-11 00:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 00:10:58 --> Input Class Initialized
INFO - 2017-01-11 00:10:58 --> Language Class Initialized
INFO - 2017-01-11 00:10:58 --> Loader Class Initialized
INFO - 2017-01-11 00:10:58 --> Database Driver Class Initialized
INFO - 2017-01-11 00:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 00:10:58 --> Controller Class Initialized
INFO - 2017-01-11 00:10:58 --> Helper loaded: date_helper
INFO - 2017-01-11 00:10:58 --> Helper loaded: url_helper
DEBUG - 2017-01-11 00:10:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 00:10:58 --> Helper loaded: form_helper
INFO - 2017-01-11 00:10:58 --> Form Validation Class Initialized
INFO - 2017-01-11 00:10:58 --> Final output sent to browser
DEBUG - 2017-01-11 00:10:58 --> Total execution time: 0.0140
INFO - 2017-01-11 00:11:00 --> Config Class Initialized
INFO - 2017-01-11 00:11:00 --> Hooks Class Initialized
DEBUG - 2017-01-11 00:11:00 --> UTF-8 Support Enabled
INFO - 2017-01-11 00:11:00 --> Utf8 Class Initialized
INFO - 2017-01-11 00:11:00 --> URI Class Initialized
INFO - 2017-01-11 00:11:00 --> Router Class Initialized
INFO - 2017-01-11 00:11:00 --> Output Class Initialized
INFO - 2017-01-11 00:11:00 --> Security Class Initialized
DEBUG - 2017-01-11 00:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 00:11:00 --> Input Class Initialized
INFO - 2017-01-11 00:11:00 --> Language Class Initialized
INFO - 2017-01-11 00:11:00 --> Loader Class Initialized
INFO - 2017-01-11 00:11:00 --> Database Driver Class Initialized
INFO - 2017-01-11 00:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 00:11:00 --> Controller Class Initialized
INFO - 2017-01-11 00:11:00 --> Helper loaded: date_helper
INFO - 2017-01-11 00:11:00 --> Helper loaded: url_helper
DEBUG - 2017-01-11 00:11:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 00:11:00 --> Helper loaded: form_helper
INFO - 2017-01-11 00:11:00 --> Form Validation Class Initialized
INFO - 2017-01-11 00:11:00 --> Final output sent to browser
DEBUG - 2017-01-11 00:11:00 --> Total execution time: 0.0144
INFO - 2017-01-11 00:11:05 --> Config Class Initialized
INFO - 2017-01-11 00:11:05 --> Hooks Class Initialized
DEBUG - 2017-01-11 00:11:05 --> UTF-8 Support Enabled
INFO - 2017-01-11 00:11:05 --> Utf8 Class Initialized
INFO - 2017-01-11 00:11:05 --> URI Class Initialized
INFO - 2017-01-11 00:11:05 --> Router Class Initialized
INFO - 2017-01-11 00:11:05 --> Output Class Initialized
INFO - 2017-01-11 00:11:05 --> Security Class Initialized
DEBUG - 2017-01-11 00:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 00:11:05 --> Input Class Initialized
INFO - 2017-01-11 00:11:05 --> Language Class Initialized
INFO - 2017-01-11 00:11:05 --> Loader Class Initialized
INFO - 2017-01-11 00:11:05 --> Database Driver Class Initialized
INFO - 2017-01-11 00:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 00:11:05 --> Controller Class Initialized
INFO - 2017-01-11 00:11:05 --> Helper loaded: date_helper
INFO - 2017-01-11 00:11:05 --> Helper loaded: url_helper
DEBUG - 2017-01-11 00:11:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 00:11:05 --> Helper loaded: form_helper
INFO - 2017-01-11 00:11:05 --> Form Validation Class Initialized
INFO - 2017-01-11 00:11:05 --> Final output sent to browser
DEBUG - 2017-01-11 00:11:05 --> Total execution time: 0.0145
INFO - 2017-01-11 03:08:21 --> Config Class Initialized
INFO - 2017-01-11 03:08:21 --> Hooks Class Initialized
DEBUG - 2017-01-11 03:08:21 --> UTF-8 Support Enabled
INFO - 2017-01-11 03:08:21 --> Utf8 Class Initialized
INFO - 2017-01-11 03:08:21 --> URI Class Initialized
DEBUG - 2017-01-11 03:08:21 --> No URI present. Default controller set.
INFO - 2017-01-11 03:08:21 --> Router Class Initialized
INFO - 2017-01-11 03:08:21 --> Output Class Initialized
INFO - 2017-01-11 03:08:21 --> Security Class Initialized
DEBUG - 2017-01-11 03:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 03:08:21 --> Input Class Initialized
INFO - 2017-01-11 03:08:21 --> Language Class Initialized
INFO - 2017-01-11 03:08:21 --> Loader Class Initialized
INFO - 2017-01-11 03:08:21 --> Database Driver Class Initialized
INFO - 2017-01-11 03:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 03:08:22 --> Controller Class Initialized
INFO - 2017-01-11 03:08:22 --> Helper loaded: url_helper
DEBUG - 2017-01-11 03:08:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 03:08:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-11 03:08:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-11 03:08:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-11 03:08:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-11 03:08:22 --> Final output sent to browser
DEBUG - 2017-01-11 03:08:22 --> Total execution time: 1.7031
INFO - 2017-01-11 06:06:29 --> Config Class Initialized
INFO - 2017-01-11 06:06:29 --> Hooks Class Initialized
DEBUG - 2017-01-11 06:06:29 --> UTF-8 Support Enabled
INFO - 2017-01-11 06:06:29 --> Utf8 Class Initialized
INFO - 2017-01-11 06:06:29 --> URI Class Initialized
INFO - 2017-01-11 06:06:30 --> Router Class Initialized
INFO - 2017-01-11 06:06:30 --> Output Class Initialized
INFO - 2017-01-11 06:06:30 --> Security Class Initialized
DEBUG - 2017-01-11 06:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 06:06:30 --> Input Class Initialized
INFO - 2017-01-11 06:06:30 --> Language Class Initialized
INFO - 2017-01-11 06:06:30 --> Loader Class Initialized
INFO - 2017-01-11 06:06:30 --> Database Driver Class Initialized
INFO - 2017-01-11 06:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 06:06:30 --> Controller Class Initialized
INFO - 2017-01-11 06:06:30 --> Helper loaded: url_helper
DEBUG - 2017-01-11 06:06:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 06:06:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-11 06:06:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-11 06:06:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-11 06:06:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-11 06:06:31 --> Final output sent to browser
DEBUG - 2017-01-11 06:06:31 --> Total execution time: 1.4021
INFO - 2017-01-11 15:52:29 --> Config Class Initialized
INFO - 2017-01-11 15:52:29 --> Hooks Class Initialized
DEBUG - 2017-01-11 15:52:29 --> UTF-8 Support Enabled
INFO - 2017-01-11 15:52:30 --> Utf8 Class Initialized
INFO - 2017-01-11 15:52:30 --> URI Class Initialized
DEBUG - 2017-01-11 15:52:30 --> No URI present. Default controller set.
INFO - 2017-01-11 15:52:30 --> Router Class Initialized
INFO - 2017-01-11 15:52:30 --> Output Class Initialized
INFO - 2017-01-11 15:52:30 --> Security Class Initialized
DEBUG - 2017-01-11 15:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 15:52:30 --> Input Class Initialized
INFO - 2017-01-11 15:52:30 --> Language Class Initialized
INFO - 2017-01-11 15:52:30 --> Loader Class Initialized
INFO - 2017-01-11 15:52:30 --> Database Driver Class Initialized
INFO - 2017-01-11 15:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 15:52:31 --> Controller Class Initialized
INFO - 2017-01-11 15:52:31 --> Helper loaded: url_helper
DEBUG - 2017-01-11 15:52:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 15:52:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-11 15:52:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-11 15:52:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-11 15:52:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-11 15:52:31 --> Final output sent to browser
DEBUG - 2017-01-11 15:52:31 --> Total execution time: 1.9334
INFO - 2017-01-11 20:13:46 --> Config Class Initialized
INFO - 2017-01-11 20:13:46 --> Hooks Class Initialized
DEBUG - 2017-01-11 20:13:46 --> UTF-8 Support Enabled
INFO - 2017-01-11 20:13:46 --> Utf8 Class Initialized
INFO - 2017-01-11 20:13:46 --> URI Class Initialized
INFO - 2017-01-11 20:13:46 --> Router Class Initialized
INFO - 2017-01-11 20:13:46 --> Output Class Initialized
INFO - 2017-01-11 20:13:46 --> Security Class Initialized
DEBUG - 2017-01-11 20:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 20:13:46 --> Input Class Initialized
INFO - 2017-01-11 20:13:46 --> Language Class Initialized
INFO - 2017-01-11 20:13:47 --> Loader Class Initialized
INFO - 2017-01-11 20:13:47 --> Database Driver Class Initialized
INFO - 2017-01-11 20:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 20:13:47 --> Controller Class Initialized
INFO - 2017-01-11 20:13:47 --> Helper loaded: url_helper
DEBUG - 2017-01-11 20:13:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 20:13:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-11 20:13:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-11 20:13:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-11 20:13:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-11 20:13:48 --> Final output sent to browser
DEBUG - 2017-01-11 20:13:48 --> Total execution time: 1.7343
INFO - 2017-01-11 20:13:48 --> Config Class Initialized
INFO - 2017-01-11 20:13:48 --> Hooks Class Initialized
DEBUG - 2017-01-11 20:13:48 --> UTF-8 Support Enabled
INFO - 2017-01-11 20:13:48 --> Utf8 Class Initialized
INFO - 2017-01-11 20:13:48 --> URI Class Initialized
DEBUG - 2017-01-11 20:13:48 --> No URI present. Default controller set.
INFO - 2017-01-11 20:13:48 --> Router Class Initialized
INFO - 2017-01-11 20:13:48 --> Output Class Initialized
INFO - 2017-01-11 20:13:48 --> Security Class Initialized
DEBUG - 2017-01-11 20:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-11 20:13:48 --> Input Class Initialized
INFO - 2017-01-11 20:13:48 --> Language Class Initialized
INFO - 2017-01-11 20:13:48 --> Loader Class Initialized
INFO - 2017-01-11 20:13:48 --> Database Driver Class Initialized
INFO - 2017-01-11 20:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-11 20:13:48 --> Controller Class Initialized
INFO - 2017-01-11 20:13:48 --> Helper loaded: url_helper
DEBUG - 2017-01-11 20:13:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-11 20:13:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-11 20:13:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-11 20:13:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-11 20:13:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-11 20:13:48 --> Final output sent to browser
DEBUG - 2017-01-11 20:13:48 --> Total execution time: 0.0131

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-22 03:59:08 --> Config Class Initialized
INFO - 2017-02-22 03:59:08 --> Hooks Class Initialized
DEBUG - 2017-02-22 03:59:08 --> UTF-8 Support Enabled
INFO - 2017-02-22 03:59:08 --> Utf8 Class Initialized
INFO - 2017-02-22 03:59:08 --> URI Class Initialized
INFO - 2017-02-22 03:59:08 --> Router Class Initialized
INFO - 2017-02-22 03:59:08 --> Output Class Initialized
INFO - 2017-02-22 03:59:08 --> Security Class Initialized
DEBUG - 2017-02-22 03:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 03:59:08 --> Input Class Initialized
INFO - 2017-02-22 03:59:08 --> Language Class Initialized
INFO - 2017-02-22 03:59:08 --> Loader Class Initialized
INFO - 2017-02-22 03:59:09 --> Database Driver Class Initialized
INFO - 2017-02-22 03:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 03:59:09 --> Controller Class Initialized
INFO - 2017-02-22 03:59:09 --> Helper loaded: url_helper
DEBUG - 2017-02-22 03:59:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 03:59:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 03:59:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 03:59:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 03:59:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 03:59:09 --> Final output sent to browser
DEBUG - 2017-02-22 03:59:09 --> Total execution time: 2.1123
INFO - 2017-02-22 05:05:26 --> Config Class Initialized
INFO - 2017-02-22 05:05:26 --> Hooks Class Initialized
DEBUG - 2017-02-22 05:05:27 --> UTF-8 Support Enabled
INFO - 2017-02-22 05:05:27 --> Utf8 Class Initialized
INFO - 2017-02-22 05:05:27 --> URI Class Initialized
INFO - 2017-02-22 05:05:27 --> Router Class Initialized
INFO - 2017-02-22 05:05:27 --> Output Class Initialized
INFO - 2017-02-22 05:05:27 --> Security Class Initialized
DEBUG - 2017-02-22 05:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 05:05:27 --> Input Class Initialized
INFO - 2017-02-22 05:05:27 --> Language Class Initialized
INFO - 2017-02-22 05:05:27 --> Loader Class Initialized
INFO - 2017-02-22 05:05:27 --> Database Driver Class Initialized
INFO - 2017-02-22 05:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 05:05:28 --> Controller Class Initialized
INFO - 2017-02-22 05:05:28 --> Helper loaded: url_helper
DEBUG - 2017-02-22 05:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 05:05:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 05:05:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 05:05:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 05:05:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 05:05:28 --> Final output sent to browser
DEBUG - 2017-02-22 05:05:28 --> Total execution time: 1.7761
INFO - 2017-02-22 06:06:36 --> Config Class Initialized
INFO - 2017-02-22 06:06:36 --> Hooks Class Initialized
DEBUG - 2017-02-22 06:06:37 --> UTF-8 Support Enabled
INFO - 2017-02-22 06:06:37 --> Utf8 Class Initialized
INFO - 2017-02-22 06:06:37 --> URI Class Initialized
INFO - 2017-02-22 06:06:37 --> Router Class Initialized
INFO - 2017-02-22 06:06:37 --> Output Class Initialized
INFO - 2017-02-22 06:06:37 --> Security Class Initialized
DEBUG - 2017-02-22 06:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 06:06:37 --> Input Class Initialized
INFO - 2017-02-22 06:06:37 --> Language Class Initialized
INFO - 2017-02-22 06:06:37 --> Loader Class Initialized
INFO - 2017-02-22 06:06:37 --> Database Driver Class Initialized
INFO - 2017-02-22 06:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 06:06:38 --> Controller Class Initialized
INFO - 2017-02-22 06:06:38 --> Helper loaded: url_helper
DEBUG - 2017-02-22 06:06:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 06:06:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 06:06:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 06:06:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 06:06:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 06:06:38 --> Final output sent to browser
DEBUG - 2017-02-22 06:06:38 --> Total execution time: 2.1263
INFO - 2017-02-22 08:21:02 --> Config Class Initialized
INFO - 2017-02-22 08:21:02 --> Hooks Class Initialized
DEBUG - 2017-02-22 08:21:03 --> UTF-8 Support Enabled
INFO - 2017-02-22 08:21:03 --> Utf8 Class Initialized
INFO - 2017-02-22 08:21:03 --> URI Class Initialized
INFO - 2017-02-22 08:21:03 --> Router Class Initialized
INFO - 2017-02-22 08:21:03 --> Output Class Initialized
INFO - 2017-02-22 08:21:03 --> Security Class Initialized
DEBUG - 2017-02-22 08:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 08:21:03 --> Input Class Initialized
INFO - 2017-02-22 08:21:03 --> Language Class Initialized
INFO - 2017-02-22 08:21:03 --> Loader Class Initialized
INFO - 2017-02-22 08:21:03 --> Database Driver Class Initialized
INFO - 2017-02-22 08:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 08:21:04 --> Controller Class Initialized
INFO - 2017-02-22 08:21:04 --> Helper loaded: url_helper
DEBUG - 2017-02-22 08:21:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 08:21:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 08:21:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 08:21:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 08:21:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 08:21:04 --> Final output sent to browser
DEBUG - 2017-02-22 08:21:04 --> Total execution time: 1.7871
INFO - 2017-02-22 08:21:12 --> Config Class Initialized
INFO - 2017-02-22 08:21:12 --> Hooks Class Initialized
DEBUG - 2017-02-22 08:21:12 --> UTF-8 Support Enabled
INFO - 2017-02-22 08:21:12 --> Utf8 Class Initialized
INFO - 2017-02-22 08:21:12 --> URI Class Initialized
DEBUG - 2017-02-22 08:21:12 --> No URI present. Default controller set.
INFO - 2017-02-22 08:21:12 --> Router Class Initialized
INFO - 2017-02-22 08:21:12 --> Output Class Initialized
INFO - 2017-02-22 08:21:12 --> Security Class Initialized
DEBUG - 2017-02-22 08:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 08:21:12 --> Input Class Initialized
INFO - 2017-02-22 08:21:12 --> Language Class Initialized
INFO - 2017-02-22 08:21:12 --> Loader Class Initialized
INFO - 2017-02-22 08:21:12 --> Database Driver Class Initialized
INFO - 2017-02-22 08:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 08:21:12 --> Controller Class Initialized
INFO - 2017-02-22 08:21:12 --> Helper loaded: url_helper
DEBUG - 2017-02-22 08:21:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 08:21:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 08:21:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 08:21:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 08:21:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 08:21:12 --> Final output sent to browser
DEBUG - 2017-02-22 08:21:12 --> Total execution time: 0.0139
INFO - 2017-02-22 10:14:08 --> Config Class Initialized
INFO - 2017-02-22 10:14:08 --> Hooks Class Initialized
DEBUG - 2017-02-22 10:14:08 --> UTF-8 Support Enabled
INFO - 2017-02-22 10:14:08 --> Utf8 Class Initialized
INFO - 2017-02-22 10:14:09 --> URI Class Initialized
INFO - 2017-02-22 10:14:09 --> Router Class Initialized
INFO - 2017-02-22 10:14:09 --> Output Class Initialized
INFO - 2017-02-22 10:14:09 --> Security Class Initialized
DEBUG - 2017-02-22 10:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 10:14:09 --> Input Class Initialized
INFO - 2017-02-22 10:14:09 --> Language Class Initialized
INFO - 2017-02-22 10:14:09 --> Loader Class Initialized
INFO - 2017-02-22 10:14:09 --> Database Driver Class Initialized
INFO - 2017-02-22 10:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 10:14:09 --> Controller Class Initialized
INFO - 2017-02-22 10:14:09 --> Helper loaded: url_helper
DEBUG - 2017-02-22 10:14:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 10:14:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 10:14:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 10:14:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 10:14:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 10:14:10 --> Final output sent to browser
DEBUG - 2017-02-22 10:14:10 --> Total execution time: 1.5027
INFO - 2017-02-22 10:14:25 --> Config Class Initialized
INFO - 2017-02-22 10:14:25 --> Hooks Class Initialized
DEBUG - 2017-02-22 10:14:25 --> UTF-8 Support Enabled
INFO - 2017-02-22 10:14:25 --> Utf8 Class Initialized
INFO - 2017-02-22 10:14:25 --> URI Class Initialized
DEBUG - 2017-02-22 10:14:25 --> No URI present. Default controller set.
INFO - 2017-02-22 10:14:25 --> Router Class Initialized
INFO - 2017-02-22 10:14:25 --> Output Class Initialized
INFO - 2017-02-22 10:14:25 --> Security Class Initialized
DEBUG - 2017-02-22 10:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 10:14:25 --> Input Class Initialized
INFO - 2017-02-22 10:14:25 --> Language Class Initialized
INFO - 2017-02-22 10:14:25 --> Loader Class Initialized
INFO - 2017-02-22 10:14:25 --> Database Driver Class Initialized
INFO - 2017-02-22 10:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 10:14:25 --> Controller Class Initialized
INFO - 2017-02-22 10:14:25 --> Helper loaded: url_helper
DEBUG - 2017-02-22 10:14:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 10:14:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 10:14:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 10:14:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 10:14:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 10:14:25 --> Final output sent to browser
DEBUG - 2017-02-22 10:14:25 --> Total execution time: 0.0327
INFO - 2017-02-22 11:21:12 --> Config Class Initialized
INFO - 2017-02-22 11:21:12 --> Hooks Class Initialized
DEBUG - 2017-02-22 11:21:12 --> UTF-8 Support Enabled
INFO - 2017-02-22 11:21:13 --> Utf8 Class Initialized
INFO - 2017-02-22 11:21:13 --> URI Class Initialized
INFO - 2017-02-22 11:21:13 --> Router Class Initialized
INFO - 2017-02-22 11:21:13 --> Output Class Initialized
INFO - 2017-02-22 11:21:13 --> Security Class Initialized
DEBUG - 2017-02-22 11:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 11:21:13 --> Input Class Initialized
INFO - 2017-02-22 11:21:13 --> Language Class Initialized
INFO - 2017-02-22 11:21:13 --> Loader Class Initialized
INFO - 2017-02-22 11:21:13 --> Database Driver Class Initialized
INFO - 2017-02-22 11:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 11:21:14 --> Controller Class Initialized
INFO - 2017-02-22 11:21:14 --> Helper loaded: url_helper
DEBUG - 2017-02-22 11:21:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 11:21:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 11:21:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 11:21:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 11:21:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 11:21:14 --> Final output sent to browser
DEBUG - 2017-02-22 11:21:14 --> Total execution time: 1.4926
INFO - 2017-02-22 13:34:08 --> Config Class Initialized
INFO - 2017-02-22 13:34:08 --> Hooks Class Initialized
DEBUG - 2017-02-22 13:34:08 --> UTF-8 Support Enabled
INFO - 2017-02-22 13:34:08 --> Utf8 Class Initialized
INFO - 2017-02-22 13:34:08 --> URI Class Initialized
INFO - 2017-02-22 13:34:08 --> Router Class Initialized
INFO - 2017-02-22 13:34:08 --> Output Class Initialized
INFO - 2017-02-22 13:34:08 --> Security Class Initialized
DEBUG - 2017-02-22 13:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 13:34:08 --> Input Class Initialized
INFO - 2017-02-22 13:34:08 --> Language Class Initialized
INFO - 2017-02-22 13:34:08 --> Loader Class Initialized
INFO - 2017-02-22 13:34:09 --> Database Driver Class Initialized
INFO - 2017-02-22 13:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 13:34:09 --> Controller Class Initialized
INFO - 2017-02-22 13:34:09 --> Helper loaded: url_helper
DEBUG - 2017-02-22 13:34:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 13:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 13:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 13:34:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 13:34:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 13:34:10 --> Final output sent to browser
DEBUG - 2017-02-22 13:34:10 --> Total execution time: 1.4844
INFO - 2017-02-22 14:07:26 --> Config Class Initialized
INFO - 2017-02-22 14:07:26 --> Hooks Class Initialized
DEBUG - 2017-02-22 14:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-22 14:07:27 --> Utf8 Class Initialized
INFO - 2017-02-22 14:07:27 --> URI Class Initialized
DEBUG - 2017-02-22 14:07:27 --> No URI present. Default controller set.
INFO - 2017-02-22 14:07:27 --> Router Class Initialized
INFO - 2017-02-22 14:07:27 --> Output Class Initialized
INFO - 2017-02-22 14:07:27 --> Security Class Initialized
DEBUG - 2017-02-22 14:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 14:07:27 --> Input Class Initialized
INFO - 2017-02-22 14:07:27 --> Language Class Initialized
INFO - 2017-02-22 14:07:27 --> Loader Class Initialized
INFO - 2017-02-22 14:07:27 --> Database Driver Class Initialized
INFO - 2017-02-22 14:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 14:07:27 --> Controller Class Initialized
INFO - 2017-02-22 14:07:27 --> Helper loaded: url_helper
DEBUG - 2017-02-22 14:07:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 14:07:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 14:07:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 14:07:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 14:07:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 14:07:28 --> Final output sent to browser
DEBUG - 2017-02-22 14:07:28 --> Total execution time: 1.4761
INFO - 2017-02-22 14:40:08 --> Config Class Initialized
INFO - 2017-02-22 14:40:08 --> Hooks Class Initialized
DEBUG - 2017-02-22 14:40:08 --> UTF-8 Support Enabled
INFO - 2017-02-22 14:40:08 --> Utf8 Class Initialized
INFO - 2017-02-22 14:40:08 --> URI Class Initialized
INFO - 2017-02-22 14:40:08 --> Router Class Initialized
INFO - 2017-02-22 14:40:08 --> Output Class Initialized
INFO - 2017-02-22 14:40:08 --> Security Class Initialized
DEBUG - 2017-02-22 14:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 14:40:09 --> Input Class Initialized
INFO - 2017-02-22 14:40:09 --> Language Class Initialized
INFO - 2017-02-22 14:40:09 --> Loader Class Initialized
INFO - 2017-02-22 14:40:09 --> Database Driver Class Initialized
INFO - 2017-02-22 14:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 14:40:09 --> Controller Class Initialized
INFO - 2017-02-22 14:40:09 --> Helper loaded: url_helper
DEBUG - 2017-02-22 14:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 14:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 14:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 14:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 14:40:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 14:40:09 --> Final output sent to browser
DEBUG - 2017-02-22 14:40:09 --> Total execution time: 1.4677
INFO - 2017-02-22 16:49:29 --> Config Class Initialized
INFO - 2017-02-22 16:49:29 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:49:29 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:49:29 --> Utf8 Class Initialized
INFO - 2017-02-22 16:49:29 --> URI Class Initialized
DEBUG - 2017-02-22 16:49:29 --> No URI present. Default controller set.
INFO - 2017-02-22 16:49:29 --> Router Class Initialized
INFO - 2017-02-22 16:49:29 --> Output Class Initialized
INFO - 2017-02-22 16:49:29 --> Security Class Initialized
DEBUG - 2017-02-22 16:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:49:30 --> Input Class Initialized
INFO - 2017-02-22 16:49:30 --> Language Class Initialized
INFO - 2017-02-22 16:49:30 --> Loader Class Initialized
INFO - 2017-02-22 16:49:30 --> Database Driver Class Initialized
INFO - 2017-02-22 16:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:49:30 --> Controller Class Initialized
INFO - 2017-02-22 16:49:30 --> Helper loaded: url_helper
DEBUG - 2017-02-22 16:49:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 16:49:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 16:49:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 16:49:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 16:49:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 16:49:31 --> Final output sent to browser
DEBUG - 2017-02-22 16:49:31 --> Total execution time: 2.1798
INFO - 2017-02-22 17:56:15 --> Config Class Initialized
INFO - 2017-02-22 17:56:15 --> Hooks Class Initialized
DEBUG - 2017-02-22 17:56:16 --> UTF-8 Support Enabled
INFO - 2017-02-22 17:56:16 --> Utf8 Class Initialized
INFO - 2017-02-22 17:56:16 --> URI Class Initialized
INFO - 2017-02-22 17:56:16 --> Router Class Initialized
INFO - 2017-02-22 17:56:16 --> Output Class Initialized
INFO - 2017-02-22 17:56:16 --> Security Class Initialized
DEBUG - 2017-02-22 17:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 17:56:16 --> Input Class Initialized
INFO - 2017-02-22 17:56:16 --> Language Class Initialized
INFO - 2017-02-22 17:56:16 --> Loader Class Initialized
INFO - 2017-02-22 17:56:16 --> Database Driver Class Initialized
INFO - 2017-02-22 17:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 17:56:17 --> Controller Class Initialized
INFO - 2017-02-22 17:56:17 --> Helper loaded: url_helper
DEBUG - 2017-02-22 17:56:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 17:56:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 17:56:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 17:56:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 17:56:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 17:56:17 --> Final output sent to browser
DEBUG - 2017-02-22 17:56:17 --> Total execution time: 2.0265
INFO - 2017-02-22 20:55:12 --> Config Class Initialized
INFO - 2017-02-22 20:55:12 --> Hooks Class Initialized
DEBUG - 2017-02-22 20:55:13 --> UTF-8 Support Enabled
INFO - 2017-02-22 20:55:13 --> Utf8 Class Initialized
INFO - 2017-02-22 20:55:13 --> URI Class Initialized
INFO - 2017-02-22 20:55:13 --> Router Class Initialized
INFO - 2017-02-22 20:55:13 --> Output Class Initialized
INFO - 2017-02-22 20:55:13 --> Security Class Initialized
DEBUG - 2017-02-22 20:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 20:55:13 --> Input Class Initialized
INFO - 2017-02-22 20:55:13 --> Language Class Initialized
INFO - 2017-02-22 20:55:13 --> Loader Class Initialized
INFO - 2017-02-22 20:55:13 --> Database Driver Class Initialized
INFO - 2017-02-22 20:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 20:55:14 --> Controller Class Initialized
INFO - 2017-02-22 20:55:14 --> Helper loaded: url_helper
DEBUG - 2017-02-22 20:55:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 20:55:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 20:55:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 20:55:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 20:55:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 20:55:14 --> Final output sent to browser
DEBUG - 2017-02-22 20:55:14 --> Total execution time: 1.8210
INFO - 2017-02-22 21:42:03 --> Config Class Initialized
INFO - 2017-02-22 21:42:03 --> Hooks Class Initialized
DEBUG - 2017-02-22 21:42:03 --> UTF-8 Support Enabled
INFO - 2017-02-22 21:42:03 --> Utf8 Class Initialized
INFO - 2017-02-22 21:42:03 --> URI Class Initialized
INFO - 2017-02-22 21:42:03 --> Router Class Initialized
INFO - 2017-02-22 21:42:03 --> Output Class Initialized
INFO - 2017-02-22 21:42:03 --> Security Class Initialized
DEBUG - 2017-02-22 21:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 21:42:03 --> Input Class Initialized
INFO - 2017-02-22 21:42:03 --> Language Class Initialized
INFO - 2017-02-22 21:42:03 --> Loader Class Initialized
INFO - 2017-02-22 21:42:04 --> Database Driver Class Initialized
INFO - 2017-02-22 21:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 21:42:04 --> Controller Class Initialized
INFO - 2017-02-22 21:42:04 --> Helper loaded: url_helper
DEBUG - 2017-02-22 21:42:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 21:42:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 21:42:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 21:42:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 21:42:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 21:42:05 --> Final output sent to browser
DEBUG - 2017-02-22 21:42:05 --> Total execution time: 2.0421
INFO - 2017-02-22 21:42:46 --> Config Class Initialized
INFO - 2017-02-22 21:42:46 --> Hooks Class Initialized
DEBUG - 2017-02-22 21:42:46 --> UTF-8 Support Enabled
INFO - 2017-02-22 21:42:46 --> Utf8 Class Initialized
INFO - 2017-02-22 21:42:46 --> URI Class Initialized
DEBUG - 2017-02-22 21:42:46 --> No URI present. Default controller set.
INFO - 2017-02-22 21:42:46 --> Router Class Initialized
INFO - 2017-02-22 21:42:46 --> Output Class Initialized
INFO - 2017-02-22 21:42:46 --> Security Class Initialized
DEBUG - 2017-02-22 21:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 21:42:46 --> Input Class Initialized
INFO - 2017-02-22 21:42:46 --> Language Class Initialized
INFO - 2017-02-22 21:42:46 --> Loader Class Initialized
INFO - 2017-02-22 21:42:46 --> Database Driver Class Initialized
INFO - 2017-02-22 21:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 21:42:47 --> Controller Class Initialized
INFO - 2017-02-22 21:42:47 --> Helper loaded: url_helper
DEBUG - 2017-02-22 21:42:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 21:42:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 21:42:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 21:42:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 21:42:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 21:42:47 --> Final output sent to browser
DEBUG - 2017-02-22 21:42:47 --> Total execution time: 0.0402
INFO - 2017-02-22 22:09:43 --> Config Class Initialized
INFO - 2017-02-22 22:09:43 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:09:43 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:09:43 --> Utf8 Class Initialized
INFO - 2017-02-22 22:09:43 --> URI Class Initialized
DEBUG - 2017-02-22 22:09:43 --> No URI present. Default controller set.
INFO - 2017-02-22 22:09:43 --> Router Class Initialized
INFO - 2017-02-22 22:09:43 --> Output Class Initialized
INFO - 2017-02-22 22:09:43 --> Security Class Initialized
DEBUG - 2017-02-22 22:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:09:43 --> Input Class Initialized
INFO - 2017-02-22 22:09:43 --> Language Class Initialized
INFO - 2017-02-22 22:09:43 --> Loader Class Initialized
INFO - 2017-02-22 22:09:44 --> Database Driver Class Initialized
INFO - 2017-02-22 22:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:09:44 --> Controller Class Initialized
INFO - 2017-02-22 22:09:44 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:09:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:09:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:09:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:09:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:09:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:09:45 --> Final output sent to browser
DEBUG - 2017-02-22 22:09:45 --> Total execution time: 2.0376
INFO - 2017-02-22 22:09:47 --> Config Class Initialized
INFO - 2017-02-22 22:09:47 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:09:47 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:09:47 --> Utf8 Class Initialized
INFO - 2017-02-22 22:09:47 --> URI Class Initialized
INFO - 2017-02-22 22:09:47 --> Router Class Initialized
INFO - 2017-02-22 22:09:47 --> Output Class Initialized
INFO - 2017-02-22 22:09:47 --> Security Class Initialized
DEBUG - 2017-02-22 22:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:09:47 --> Input Class Initialized
INFO - 2017-02-22 22:09:47 --> Language Class Initialized
INFO - 2017-02-22 22:09:47 --> Loader Class Initialized
INFO - 2017-02-22 22:09:47 --> Database Driver Class Initialized
INFO - 2017-02-22 22:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:09:47 --> Controller Class Initialized
INFO - 2017-02-22 22:09:47 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:09:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:09:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:09:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:09:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:09:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:09:47 --> Final output sent to browser
DEBUG - 2017-02-22 22:09:47 --> Total execution time: 0.0164
INFO - 2017-02-22 22:10:14 --> Config Class Initialized
INFO - 2017-02-22 22:10:14 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:10:14 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:10:14 --> Utf8 Class Initialized
INFO - 2017-02-22 22:10:14 --> URI Class Initialized
INFO - 2017-02-22 22:10:14 --> Router Class Initialized
INFO - 2017-02-22 22:10:14 --> Output Class Initialized
INFO - 2017-02-22 22:10:14 --> Security Class Initialized
DEBUG - 2017-02-22 22:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:10:14 --> Input Class Initialized
INFO - 2017-02-22 22:10:14 --> Language Class Initialized
INFO - 2017-02-22 22:10:14 --> Loader Class Initialized
INFO - 2017-02-22 22:10:14 --> Database Driver Class Initialized
INFO - 2017-02-22 22:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:10:14 --> Controller Class Initialized
INFO - 2017-02-22 22:10:14 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:10:17 --> Config Class Initialized
INFO - 2017-02-22 22:10:17 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:10:17 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:10:17 --> Utf8 Class Initialized
INFO - 2017-02-22 22:10:17 --> URI Class Initialized
INFO - 2017-02-22 22:10:17 --> Router Class Initialized
INFO - 2017-02-22 22:10:17 --> Output Class Initialized
INFO - 2017-02-22 22:10:17 --> Security Class Initialized
DEBUG - 2017-02-22 22:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:10:17 --> Input Class Initialized
INFO - 2017-02-22 22:10:17 --> Language Class Initialized
INFO - 2017-02-22 22:10:17 --> Loader Class Initialized
INFO - 2017-02-22 22:10:17 --> Database Driver Class Initialized
INFO - 2017-02-22 22:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:10:17 --> Controller Class Initialized
INFO - 2017-02-22 22:10:17 --> Helper loaded: date_helper
DEBUG - 2017-02-22 22:10:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:10:17 --> Helper loaded: url_helper
INFO - 2017-02-22 22:10:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:10:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-22 22:10:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-22 22:10:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-22 22:10:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:10:17 --> Final output sent to browser
DEBUG - 2017-02-22 22:10:17 --> Total execution time: 0.1689
INFO - 2017-02-22 22:10:18 --> Config Class Initialized
INFO - 2017-02-22 22:10:18 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:10:18 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:10:18 --> Utf8 Class Initialized
INFO - 2017-02-22 22:10:18 --> URI Class Initialized
INFO - 2017-02-22 22:10:18 --> Router Class Initialized
INFO - 2017-02-22 22:10:18 --> Output Class Initialized
INFO - 2017-02-22 22:10:18 --> Security Class Initialized
DEBUG - 2017-02-22 22:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:10:18 --> Input Class Initialized
INFO - 2017-02-22 22:10:18 --> Language Class Initialized
INFO - 2017-02-22 22:10:18 --> Loader Class Initialized
INFO - 2017-02-22 22:10:18 --> Database Driver Class Initialized
INFO - 2017-02-22 22:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:10:18 --> Controller Class Initialized
INFO - 2017-02-22 22:10:18 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:10:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:10:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:10:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:10:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:10:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:10:18 --> Final output sent to browser
DEBUG - 2017-02-22 22:10:18 --> Total execution time: 0.0143
INFO - 2017-02-22 22:10:32 --> Config Class Initialized
INFO - 2017-02-22 22:10:32 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:10:32 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:10:32 --> Utf8 Class Initialized
INFO - 2017-02-22 22:10:32 --> URI Class Initialized
DEBUG - 2017-02-22 22:10:32 --> No URI present. Default controller set.
INFO - 2017-02-22 22:10:32 --> Router Class Initialized
INFO - 2017-02-22 22:10:32 --> Output Class Initialized
INFO - 2017-02-22 22:10:32 --> Security Class Initialized
DEBUG - 2017-02-22 22:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:10:32 --> Input Class Initialized
INFO - 2017-02-22 22:10:32 --> Language Class Initialized
INFO - 2017-02-22 22:10:32 --> Loader Class Initialized
INFO - 2017-02-22 22:10:32 --> Database Driver Class Initialized
INFO - 2017-02-22 22:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:10:32 --> Controller Class Initialized
INFO - 2017-02-22 22:10:32 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:10:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:10:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:10:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:10:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:10:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:10:32 --> Final output sent to browser
DEBUG - 2017-02-22 22:10:32 --> Total execution time: 0.0142
INFO - 2017-02-22 22:10:33 --> Config Class Initialized
INFO - 2017-02-22 22:10:33 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:10:33 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:10:33 --> Utf8 Class Initialized
INFO - 2017-02-22 22:10:33 --> URI Class Initialized
INFO - 2017-02-22 22:10:33 --> Router Class Initialized
INFO - 2017-02-22 22:10:33 --> Output Class Initialized
INFO - 2017-02-22 22:10:33 --> Security Class Initialized
DEBUG - 2017-02-22 22:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:10:33 --> Input Class Initialized
INFO - 2017-02-22 22:10:33 --> Language Class Initialized
INFO - 2017-02-22 22:10:33 --> Loader Class Initialized
INFO - 2017-02-22 22:10:33 --> Database Driver Class Initialized
INFO - 2017-02-22 22:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:10:33 --> Controller Class Initialized
INFO - 2017-02-22 22:10:33 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:10:33 --> Final output sent to browser
DEBUG - 2017-02-22 22:10:33 --> Total execution time: 0.0205
INFO - 2017-02-22 22:16:45 --> Config Class Initialized
INFO - 2017-02-22 22:16:45 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:16:45 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:16:45 --> Utf8 Class Initialized
INFO - 2017-02-22 22:16:45 --> URI Class Initialized
DEBUG - 2017-02-22 22:16:45 --> No URI present. Default controller set.
INFO - 2017-02-22 22:16:45 --> Router Class Initialized
INFO - 2017-02-22 22:16:45 --> Output Class Initialized
INFO - 2017-02-22 22:16:45 --> Security Class Initialized
DEBUG - 2017-02-22 22:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:16:45 --> Input Class Initialized
INFO - 2017-02-22 22:16:45 --> Language Class Initialized
INFO - 2017-02-22 22:16:45 --> Loader Class Initialized
INFO - 2017-02-22 22:16:46 --> Database Driver Class Initialized
INFO - 2017-02-22 22:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:16:46 --> Controller Class Initialized
INFO - 2017-02-22 22:16:46 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:16:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:16:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:16:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:16:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:16:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:16:47 --> Final output sent to browser
DEBUG - 2017-02-22 22:16:47 --> Total execution time: 1.9738
INFO - 2017-02-22 22:16:53 --> Config Class Initialized
INFO - 2017-02-22 22:16:53 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:16:53 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:16:53 --> Utf8 Class Initialized
INFO - 2017-02-22 22:16:53 --> URI Class Initialized
INFO - 2017-02-22 22:16:53 --> Router Class Initialized
INFO - 2017-02-22 22:16:53 --> Output Class Initialized
INFO - 2017-02-22 22:16:53 --> Security Class Initialized
DEBUG - 2017-02-22 22:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:16:53 --> Input Class Initialized
INFO - 2017-02-22 22:16:53 --> Language Class Initialized
INFO - 2017-02-22 22:16:53 --> Loader Class Initialized
INFO - 2017-02-22 22:16:53 --> Database Driver Class Initialized
INFO - 2017-02-22 22:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:16:53 --> Controller Class Initialized
INFO - 2017-02-22 22:16:53 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:16:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:16:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:16:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:16:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:16:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:16:53 --> Final output sent to browser
DEBUG - 2017-02-22 22:16:53 --> Total execution time: 0.0145
INFO - 2017-02-22 22:17:53 --> Config Class Initialized
INFO - 2017-02-22 22:17:53 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:17:53 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:17:53 --> Utf8 Class Initialized
INFO - 2017-02-22 22:17:53 --> URI Class Initialized
INFO - 2017-02-22 22:17:53 --> Router Class Initialized
INFO - 2017-02-22 22:17:53 --> Output Class Initialized
INFO - 2017-02-22 22:17:53 --> Security Class Initialized
DEBUG - 2017-02-22 22:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:17:53 --> Input Class Initialized
INFO - 2017-02-22 22:17:53 --> Language Class Initialized
INFO - 2017-02-22 22:17:53 --> Loader Class Initialized
INFO - 2017-02-22 22:17:53 --> Database Driver Class Initialized
INFO - 2017-02-22 22:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:17:53 --> Controller Class Initialized
INFO - 2017-02-22 22:17:53 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:17:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:17:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:17:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:17:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:17:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:17:53 --> Final output sent to browser
DEBUG - 2017-02-22 22:17:53 --> Total execution time: 0.0521
INFO - 2017-02-22 22:17:54 --> Config Class Initialized
INFO - 2017-02-22 22:17:54 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:17:54 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:17:54 --> Utf8 Class Initialized
INFO - 2017-02-22 22:17:54 --> URI Class Initialized
INFO - 2017-02-22 22:17:54 --> Router Class Initialized
INFO - 2017-02-22 22:17:54 --> Output Class Initialized
INFO - 2017-02-22 22:17:54 --> Security Class Initialized
DEBUG - 2017-02-22 22:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:17:54 --> Input Class Initialized
INFO - 2017-02-22 22:17:54 --> Language Class Initialized
INFO - 2017-02-22 22:17:54 --> Loader Class Initialized
INFO - 2017-02-22 22:17:54 --> Database Driver Class Initialized
INFO - 2017-02-22 22:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:17:54 --> Controller Class Initialized
INFO - 2017-02-22 22:17:54 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:17:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:17:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:17:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:17:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:17:54 --> Final output sent to browser
DEBUG - 2017-02-22 22:17:54 --> Total execution time: 0.0380
INFO - 2017-02-22 22:18:21 --> Config Class Initialized
INFO - 2017-02-22 22:18:21 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:18:21 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:18:21 --> Utf8 Class Initialized
INFO - 2017-02-22 22:18:21 --> URI Class Initialized
INFO - 2017-02-22 22:18:21 --> Router Class Initialized
INFO - 2017-02-22 22:18:21 --> Output Class Initialized
INFO - 2017-02-22 22:18:21 --> Security Class Initialized
DEBUG - 2017-02-22 22:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:18:21 --> Input Class Initialized
INFO - 2017-02-22 22:18:21 --> Language Class Initialized
INFO - 2017-02-22 22:18:21 --> Loader Class Initialized
INFO - 2017-02-22 22:18:21 --> Database Driver Class Initialized
INFO - 2017-02-22 22:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:18:21 --> Controller Class Initialized
INFO - 2017-02-22 22:18:21 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:18:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:18:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:18:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:18:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:18:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:18:21 --> Final output sent to browser
DEBUG - 2017-02-22 22:18:21 --> Total execution time: 0.0159
INFO - 2017-02-22 22:18:22 --> Config Class Initialized
INFO - 2017-02-22 22:18:22 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:18:22 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:18:22 --> Utf8 Class Initialized
INFO - 2017-02-22 22:18:22 --> URI Class Initialized
INFO - 2017-02-22 22:18:22 --> Router Class Initialized
INFO - 2017-02-22 22:18:22 --> Output Class Initialized
INFO - 2017-02-22 22:18:22 --> Security Class Initialized
DEBUG - 2017-02-22 22:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:18:22 --> Input Class Initialized
INFO - 2017-02-22 22:18:22 --> Language Class Initialized
INFO - 2017-02-22 22:18:22 --> Loader Class Initialized
INFO - 2017-02-22 22:18:22 --> Database Driver Class Initialized
INFO - 2017-02-22 22:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:18:22 --> Controller Class Initialized
INFO - 2017-02-22 22:18:22 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:18:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:18:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:18:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:18:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:18:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:18:22 --> Final output sent to browser
DEBUG - 2017-02-22 22:18:22 --> Total execution time: 0.0453
INFO - 2017-02-22 22:18:27 --> Config Class Initialized
INFO - 2017-02-22 22:18:27 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:18:27 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:18:27 --> Utf8 Class Initialized
INFO - 2017-02-22 22:18:27 --> URI Class Initialized
INFO - 2017-02-22 22:18:27 --> Router Class Initialized
INFO - 2017-02-22 22:18:27 --> Output Class Initialized
INFO - 2017-02-22 22:18:27 --> Security Class Initialized
DEBUG - 2017-02-22 22:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:18:27 --> Input Class Initialized
INFO - 2017-02-22 22:18:27 --> Language Class Initialized
INFO - 2017-02-22 22:18:27 --> Loader Class Initialized
INFO - 2017-02-22 22:18:27 --> Database Driver Class Initialized
INFO - 2017-02-22 22:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:18:27 --> Controller Class Initialized
INFO - 2017-02-22 22:18:27 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:18:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:18:29 --> Config Class Initialized
INFO - 2017-02-22 22:18:29 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:18:29 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:18:29 --> Utf8 Class Initialized
INFO - 2017-02-22 22:18:29 --> URI Class Initialized
INFO - 2017-02-22 22:18:29 --> Router Class Initialized
INFO - 2017-02-22 22:18:29 --> Output Class Initialized
INFO - 2017-02-22 22:18:29 --> Security Class Initialized
DEBUG - 2017-02-22 22:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:18:29 --> Input Class Initialized
INFO - 2017-02-22 22:18:29 --> Language Class Initialized
INFO - 2017-02-22 22:18:29 --> Loader Class Initialized
INFO - 2017-02-22 22:18:29 --> Database Driver Class Initialized
INFO - 2017-02-22 22:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:18:29 --> Controller Class Initialized
INFO - 2017-02-22 22:18:29 --> Helper loaded: date_helper
DEBUG - 2017-02-22 22:18:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:18:29 --> Helper loaded: url_helper
INFO - 2017-02-22 22:18:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:18:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-22 22:18:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-22 22:18:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-22 22:18:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:18:29 --> Final output sent to browser
DEBUG - 2017-02-22 22:18:29 --> Total execution time: 0.1170
INFO - 2017-02-22 22:18:30 --> Config Class Initialized
INFO - 2017-02-22 22:18:30 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:18:30 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:18:30 --> Utf8 Class Initialized
INFO - 2017-02-22 22:18:30 --> URI Class Initialized
INFO - 2017-02-22 22:18:30 --> Router Class Initialized
INFO - 2017-02-22 22:18:30 --> Output Class Initialized
INFO - 2017-02-22 22:18:30 --> Security Class Initialized
DEBUG - 2017-02-22 22:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:18:30 --> Input Class Initialized
INFO - 2017-02-22 22:18:30 --> Language Class Initialized
INFO - 2017-02-22 22:18:30 --> Loader Class Initialized
INFO - 2017-02-22 22:18:30 --> Database Driver Class Initialized
INFO - 2017-02-22 22:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:18:30 --> Controller Class Initialized
INFO - 2017-02-22 22:18:30 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:18:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:18:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:18:30 --> Final output sent to browser
DEBUG - 2017-02-22 22:18:30 --> Total execution time: 0.0151
INFO - 2017-02-22 22:18:37 --> Config Class Initialized
INFO - 2017-02-22 22:18:37 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:18:37 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:18:37 --> Utf8 Class Initialized
INFO - 2017-02-22 22:18:37 --> URI Class Initialized
DEBUG - 2017-02-22 22:18:37 --> No URI present. Default controller set.
INFO - 2017-02-22 22:18:37 --> Router Class Initialized
INFO - 2017-02-22 22:18:37 --> Output Class Initialized
INFO - 2017-02-22 22:18:37 --> Security Class Initialized
DEBUG - 2017-02-22 22:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:18:37 --> Input Class Initialized
INFO - 2017-02-22 22:18:37 --> Language Class Initialized
INFO - 2017-02-22 22:18:37 --> Loader Class Initialized
INFO - 2017-02-22 22:18:37 --> Database Driver Class Initialized
INFO - 2017-02-22 22:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:18:37 --> Controller Class Initialized
INFO - 2017-02-22 22:18:37 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:18:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:18:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:18:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:18:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:18:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:18:37 --> Final output sent to browser
DEBUG - 2017-02-22 22:18:37 --> Total execution time: 0.3366
INFO - 2017-02-22 22:18:38 --> Config Class Initialized
INFO - 2017-02-22 22:18:38 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:18:38 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:18:38 --> Utf8 Class Initialized
INFO - 2017-02-22 22:18:38 --> URI Class Initialized
INFO - 2017-02-22 22:18:38 --> Router Class Initialized
INFO - 2017-02-22 22:18:38 --> Output Class Initialized
INFO - 2017-02-22 22:18:38 --> Security Class Initialized
DEBUG - 2017-02-22 22:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:18:38 --> Input Class Initialized
INFO - 2017-02-22 22:18:38 --> Language Class Initialized
INFO - 2017-02-22 22:18:38 --> Loader Class Initialized
INFO - 2017-02-22 22:18:38 --> Database Driver Class Initialized
INFO - 2017-02-22 22:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:18:38 --> Controller Class Initialized
INFO - 2017-02-22 22:18:38 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:18:38 --> Final output sent to browser
DEBUG - 2017-02-22 22:18:38 --> Total execution time: 0.0221
INFO - 2017-02-22 22:19:11 --> Config Class Initialized
INFO - 2017-02-22 22:19:11 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:19:11 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:19:11 --> Utf8 Class Initialized
INFO - 2017-02-22 22:19:11 --> URI Class Initialized
INFO - 2017-02-22 22:19:11 --> Router Class Initialized
INFO - 2017-02-22 22:19:11 --> Output Class Initialized
INFO - 2017-02-22 22:19:11 --> Security Class Initialized
DEBUG - 2017-02-22 22:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:19:11 --> Input Class Initialized
INFO - 2017-02-22 22:19:11 --> Language Class Initialized
INFO - 2017-02-22 22:19:11 --> Loader Class Initialized
INFO - 2017-02-22 22:19:11 --> Database Driver Class Initialized
INFO - 2017-02-22 22:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:19:12 --> Controller Class Initialized
INFO - 2017-02-22 22:19:12 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:19:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:19:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:19:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:19:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:19:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:19:12 --> Final output sent to browser
DEBUG - 2017-02-22 22:19:12 --> Total execution time: 0.5079
INFO - 2017-02-22 22:19:13 --> Config Class Initialized
INFO - 2017-02-22 22:19:13 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:19:13 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:19:13 --> Utf8 Class Initialized
INFO - 2017-02-22 22:19:13 --> URI Class Initialized
INFO - 2017-02-22 22:19:13 --> Router Class Initialized
INFO - 2017-02-22 22:19:13 --> Output Class Initialized
INFO - 2017-02-22 22:19:13 --> Security Class Initialized
DEBUG - 2017-02-22 22:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:19:13 --> Input Class Initialized
INFO - 2017-02-22 22:19:13 --> Language Class Initialized
INFO - 2017-02-22 22:19:13 --> Loader Class Initialized
INFO - 2017-02-22 22:19:13 --> Database Driver Class Initialized
INFO - 2017-02-22 22:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:19:13 --> Controller Class Initialized
INFO - 2017-02-22 22:19:13 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:19:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:19:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:19:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:19:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:19:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:19:13 --> Final output sent to browser
DEBUG - 2017-02-22 22:19:13 --> Total execution time: 0.0142
INFO - 2017-02-22 22:19:18 --> Config Class Initialized
INFO - 2017-02-22 22:19:18 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:19:18 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:19:18 --> Utf8 Class Initialized
INFO - 2017-02-22 22:19:18 --> URI Class Initialized
DEBUG - 2017-02-22 22:19:18 --> No URI present. Default controller set.
INFO - 2017-02-22 22:19:18 --> Router Class Initialized
INFO - 2017-02-22 22:19:18 --> Output Class Initialized
INFO - 2017-02-22 22:19:18 --> Security Class Initialized
DEBUG - 2017-02-22 22:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:19:18 --> Input Class Initialized
INFO - 2017-02-22 22:19:18 --> Language Class Initialized
INFO - 2017-02-22 22:19:18 --> Loader Class Initialized
INFO - 2017-02-22 22:19:18 --> Database Driver Class Initialized
INFO - 2017-02-22 22:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:19:18 --> Controller Class Initialized
INFO - 2017-02-22 22:19:18 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:19:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:19:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:19:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:19:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:19:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:19:18 --> Final output sent to browser
DEBUG - 2017-02-22 22:19:18 --> Total execution time: 0.0156
INFO - 2017-02-22 22:19:19 --> Config Class Initialized
INFO - 2017-02-22 22:19:19 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:19:19 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:19:19 --> Utf8 Class Initialized
INFO - 2017-02-22 22:19:19 --> URI Class Initialized
INFO - 2017-02-22 22:19:19 --> Router Class Initialized
INFO - 2017-02-22 22:19:19 --> Output Class Initialized
INFO - 2017-02-22 22:19:19 --> Security Class Initialized
DEBUG - 2017-02-22 22:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:19:19 --> Input Class Initialized
INFO - 2017-02-22 22:19:19 --> Language Class Initialized
INFO - 2017-02-22 22:19:19 --> Loader Class Initialized
INFO - 2017-02-22 22:19:19 --> Database Driver Class Initialized
INFO - 2017-02-22 22:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:19:19 --> Controller Class Initialized
INFO - 2017-02-22 22:19:19 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:19:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:19:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:19:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:19:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:19:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:19:19 --> Final output sent to browser
DEBUG - 2017-02-22 22:19:19 --> Total execution time: 0.0152
INFO - 2017-02-22 22:19:19 --> Config Class Initialized
INFO - 2017-02-22 22:19:19 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:19:19 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:19:19 --> Utf8 Class Initialized
INFO - 2017-02-22 22:19:19 --> URI Class Initialized
INFO - 2017-02-22 22:19:19 --> Router Class Initialized
INFO - 2017-02-22 22:19:19 --> Output Class Initialized
INFO - 2017-02-22 22:19:19 --> Security Class Initialized
DEBUG - 2017-02-22 22:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:19:19 --> Input Class Initialized
INFO - 2017-02-22 22:19:19 --> Language Class Initialized
INFO - 2017-02-22 22:19:19 --> Loader Class Initialized
INFO - 2017-02-22 22:19:19 --> Database Driver Class Initialized
INFO - 2017-02-22 22:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:19:19 --> Controller Class Initialized
INFO - 2017-02-22 22:19:19 --> Helper loaded: date_helper
DEBUG - 2017-02-22 22:19:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:19:19 --> Helper loaded: url_helper
INFO - 2017-02-22 22:19:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:19:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-22 22:19:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-22 22:19:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-22 22:19:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:19:19 --> Final output sent to browser
DEBUG - 2017-02-22 22:19:19 --> Total execution time: 0.0138
INFO - 2017-02-22 22:19:19 --> Config Class Initialized
INFO - 2017-02-22 22:19:19 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:19:19 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:19:19 --> Utf8 Class Initialized
INFO - 2017-02-22 22:19:19 --> URI Class Initialized
INFO - 2017-02-22 22:19:19 --> Router Class Initialized
INFO - 2017-02-22 22:19:19 --> Output Class Initialized
INFO - 2017-02-22 22:19:19 --> Security Class Initialized
DEBUG - 2017-02-22 22:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:19:19 --> Input Class Initialized
INFO - 2017-02-22 22:19:19 --> Language Class Initialized
INFO - 2017-02-22 22:19:19 --> Loader Class Initialized
INFO - 2017-02-22 22:19:19 --> Database Driver Class Initialized
INFO - 2017-02-22 22:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:19:19 --> Controller Class Initialized
INFO - 2017-02-22 22:19:19 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:19:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:19:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:19:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:19:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:19:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:19:19 --> Final output sent to browser
DEBUG - 2017-02-22 22:19:19 --> Total execution time: 0.0159
INFO - 2017-02-22 22:21:07 --> Config Class Initialized
INFO - 2017-02-22 22:21:07 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:21:07 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:21:07 --> Utf8 Class Initialized
INFO - 2017-02-22 22:21:07 --> URI Class Initialized
DEBUG - 2017-02-22 22:21:07 --> No URI present. Default controller set.
INFO - 2017-02-22 22:21:07 --> Router Class Initialized
INFO - 2017-02-22 22:21:07 --> Output Class Initialized
INFO - 2017-02-22 22:21:07 --> Security Class Initialized
DEBUG - 2017-02-22 22:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:21:08 --> Input Class Initialized
INFO - 2017-02-22 22:21:08 --> Language Class Initialized
INFO - 2017-02-22 22:21:08 --> Loader Class Initialized
INFO - 2017-02-22 22:21:08 --> Database Driver Class Initialized
INFO - 2017-02-22 22:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:21:09 --> Controller Class Initialized
INFO - 2017-02-22 22:21:09 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:21:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:21:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:21:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:21:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:21:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:21:09 --> Final output sent to browser
DEBUG - 2017-02-22 22:21:09 --> Total execution time: 1.8044
INFO - 2017-02-22 22:21:14 --> Config Class Initialized
INFO - 2017-02-22 22:21:14 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:21:14 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:21:14 --> Utf8 Class Initialized
INFO - 2017-02-22 22:21:14 --> URI Class Initialized
DEBUG - 2017-02-22 22:21:14 --> No URI present. Default controller set.
INFO - 2017-02-22 22:21:14 --> Router Class Initialized
INFO - 2017-02-22 22:21:15 --> Output Class Initialized
INFO - 2017-02-22 22:21:15 --> Security Class Initialized
DEBUG - 2017-02-22 22:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:21:15 --> Input Class Initialized
INFO - 2017-02-22 22:21:15 --> Language Class Initialized
INFO - 2017-02-22 22:21:15 --> Loader Class Initialized
INFO - 2017-02-22 22:21:15 --> Database Driver Class Initialized
INFO - 2017-02-22 22:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:21:15 --> Controller Class Initialized
INFO - 2017-02-22 22:21:15 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:21:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:21:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:21:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:21:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:21:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:21:16 --> Final output sent to browser
DEBUG - 2017-02-22 22:21:16 --> Total execution time: 1.2297
INFO - 2017-02-22 22:21:26 --> Config Class Initialized
INFO - 2017-02-22 22:21:26 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:21:26 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:21:26 --> Utf8 Class Initialized
INFO - 2017-02-22 22:21:26 --> URI Class Initialized
INFO - 2017-02-22 22:21:26 --> Router Class Initialized
INFO - 2017-02-22 22:21:26 --> Output Class Initialized
INFO - 2017-02-22 22:21:26 --> Security Class Initialized
DEBUG - 2017-02-22 22:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:21:26 --> Input Class Initialized
INFO - 2017-02-22 22:21:26 --> Language Class Initialized
INFO - 2017-02-22 22:21:26 --> Loader Class Initialized
INFO - 2017-02-22 22:21:27 --> Database Driver Class Initialized
INFO - 2017-02-22 22:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:21:27 --> Controller Class Initialized
INFO - 2017-02-22 22:21:27 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:21:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:21:27 --> Final output sent to browser
DEBUG - 2017-02-22 22:21:27 --> Total execution time: 1.2228
INFO - 2017-02-22 22:22:04 --> Config Class Initialized
INFO - 2017-02-22 22:22:04 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:22:05 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:22:05 --> Utf8 Class Initialized
INFO - 2017-02-22 22:22:05 --> URI Class Initialized
DEBUG - 2017-02-22 22:22:05 --> No URI present. Default controller set.
INFO - 2017-02-22 22:22:05 --> Router Class Initialized
INFO - 2017-02-22 22:22:05 --> Output Class Initialized
INFO - 2017-02-22 22:22:05 --> Security Class Initialized
DEBUG - 2017-02-22 22:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:22:05 --> Input Class Initialized
INFO - 2017-02-22 22:22:05 --> Language Class Initialized
INFO - 2017-02-22 22:22:05 --> Loader Class Initialized
INFO - 2017-02-22 22:22:05 --> Database Driver Class Initialized
INFO - 2017-02-22 22:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:22:06 --> Controller Class Initialized
INFO - 2017-02-22 22:22:06 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:22:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:22:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:22:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:22:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:22:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:22:06 --> Final output sent to browser
DEBUG - 2017-02-22 22:22:06 --> Total execution time: 1.4876
INFO - 2017-02-22 22:22:10 --> Config Class Initialized
INFO - 2017-02-22 22:22:10 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:22:11 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:22:11 --> Utf8 Class Initialized
INFO - 2017-02-22 22:22:11 --> URI Class Initialized
INFO - 2017-02-22 22:22:11 --> Router Class Initialized
INFO - 2017-02-22 22:22:11 --> Output Class Initialized
INFO - 2017-02-22 22:22:11 --> Security Class Initialized
DEBUG - 2017-02-22 22:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:22:11 --> Input Class Initialized
INFO - 2017-02-22 22:22:11 --> Language Class Initialized
INFO - 2017-02-22 22:22:11 --> Loader Class Initialized
INFO - 2017-02-22 22:22:11 --> Database Driver Class Initialized
INFO - 2017-02-22 22:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:22:11 --> Controller Class Initialized
INFO - 2017-02-22 22:22:11 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:22:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:22:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:22:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:22:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:22:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:22:11 --> Final output sent to browser
DEBUG - 2017-02-22 22:22:11 --> Total execution time: 0.3323
INFO - 2017-02-22 22:23:18 --> Config Class Initialized
INFO - 2017-02-22 22:23:18 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:23:19 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:23:19 --> Utf8 Class Initialized
INFO - 2017-02-22 22:23:19 --> URI Class Initialized
INFO - 2017-02-22 22:23:19 --> Router Class Initialized
INFO - 2017-02-22 22:23:19 --> Output Class Initialized
INFO - 2017-02-22 22:23:19 --> Security Class Initialized
DEBUG - 2017-02-22 22:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:23:19 --> Input Class Initialized
INFO - 2017-02-22 22:23:19 --> Language Class Initialized
INFO - 2017-02-22 22:23:19 --> Loader Class Initialized
INFO - 2017-02-22 22:23:19 --> Database Driver Class Initialized
INFO - 2017-02-22 22:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:23:20 --> Controller Class Initialized
INFO - 2017-02-22 22:23:20 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:23:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:23:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:23:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:23:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:23:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:23:20 --> Final output sent to browser
DEBUG - 2017-02-22 22:23:20 --> Total execution time: 2.0318
INFO - 2017-02-22 22:23:23 --> Config Class Initialized
INFO - 2017-02-22 22:23:23 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:23:23 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:23:23 --> Utf8 Class Initialized
INFO - 2017-02-22 22:23:23 --> URI Class Initialized
INFO - 2017-02-22 22:23:23 --> Router Class Initialized
INFO - 2017-02-22 22:23:23 --> Output Class Initialized
INFO - 2017-02-22 22:23:23 --> Security Class Initialized
DEBUG - 2017-02-22 22:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:23:23 --> Input Class Initialized
INFO - 2017-02-22 22:23:23 --> Language Class Initialized
INFO - 2017-02-22 22:23:23 --> Loader Class Initialized
INFO - 2017-02-22 22:23:23 --> Database Driver Class Initialized
INFO - 2017-02-22 22:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:23:23 --> Controller Class Initialized
INFO - 2017-02-22 22:23:23 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:23:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:23:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:23:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:23:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:23:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:23:23 --> Final output sent to browser
DEBUG - 2017-02-22 22:23:23 --> Total execution time: 0.0647
INFO - 2017-02-22 22:24:30 --> Config Class Initialized
INFO - 2017-02-22 22:24:30 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:24:30 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:24:30 --> Utf8 Class Initialized
INFO - 2017-02-22 22:24:30 --> URI Class Initialized
INFO - 2017-02-22 22:24:31 --> Router Class Initialized
INFO - 2017-02-22 22:24:31 --> Output Class Initialized
INFO - 2017-02-22 22:24:31 --> Security Class Initialized
DEBUG - 2017-02-22 22:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:24:31 --> Input Class Initialized
INFO - 2017-02-22 22:24:31 --> Language Class Initialized
INFO - 2017-02-22 22:24:31 --> Loader Class Initialized
INFO - 2017-02-22 22:24:31 --> Database Driver Class Initialized
INFO - 2017-02-22 22:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:24:31 --> Controller Class Initialized
INFO - 2017-02-22 22:24:31 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:24:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:24:33 --> Config Class Initialized
INFO - 2017-02-22 22:24:33 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:24:33 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:24:33 --> Utf8 Class Initialized
INFO - 2017-02-22 22:24:33 --> URI Class Initialized
INFO - 2017-02-22 22:24:33 --> Router Class Initialized
INFO - 2017-02-22 22:24:33 --> Output Class Initialized
INFO - 2017-02-22 22:24:33 --> Security Class Initialized
DEBUG - 2017-02-22 22:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:24:33 --> Input Class Initialized
INFO - 2017-02-22 22:24:33 --> Language Class Initialized
INFO - 2017-02-22 22:24:33 --> Loader Class Initialized
INFO - 2017-02-22 22:24:33 --> Database Driver Class Initialized
INFO - 2017-02-22 22:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:24:33 --> Controller Class Initialized
INFO - 2017-02-22 22:24:33 --> Helper loaded: date_helper
DEBUG - 2017-02-22 22:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:24:34 --> Helper loaded: url_helper
INFO - 2017-02-22 22:24:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:24:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-22 22:24:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-22 22:24:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-22 22:24:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:24:34 --> Final output sent to browser
DEBUG - 2017-02-22 22:24:34 --> Total execution time: 0.1990
INFO - 2017-02-22 22:24:36 --> Config Class Initialized
INFO - 2017-02-22 22:24:36 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:24:36 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:24:36 --> Utf8 Class Initialized
INFO - 2017-02-22 22:24:36 --> URI Class Initialized
INFO - 2017-02-22 22:24:36 --> Router Class Initialized
INFO - 2017-02-22 22:24:36 --> Output Class Initialized
INFO - 2017-02-22 22:24:36 --> Security Class Initialized
DEBUG - 2017-02-22 22:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:24:36 --> Input Class Initialized
INFO - 2017-02-22 22:24:36 --> Language Class Initialized
INFO - 2017-02-22 22:24:36 --> Loader Class Initialized
INFO - 2017-02-22 22:24:36 --> Database Driver Class Initialized
INFO - 2017-02-22 22:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:24:36 --> Controller Class Initialized
INFO - 2017-02-22 22:24:36 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:24:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:24:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:24:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:24:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:24:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:24:37 --> Final output sent to browser
DEBUG - 2017-02-22 22:24:37 --> Total execution time: 0.1634
INFO - 2017-02-22 22:26:44 --> Config Class Initialized
INFO - 2017-02-22 22:26:44 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:26:44 --> Utf8 Class Initialized
INFO - 2017-02-22 22:26:44 --> URI Class Initialized
DEBUG - 2017-02-22 22:26:45 --> No URI present. Default controller set.
INFO - 2017-02-22 22:26:45 --> Router Class Initialized
INFO - 2017-02-22 22:26:45 --> Output Class Initialized
INFO - 2017-02-22 22:26:45 --> Security Class Initialized
DEBUG - 2017-02-22 22:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:26:45 --> Input Class Initialized
INFO - 2017-02-22 22:26:45 --> Language Class Initialized
INFO - 2017-02-22 22:26:45 --> Loader Class Initialized
INFO - 2017-02-22 22:26:45 --> Database Driver Class Initialized
INFO - 2017-02-22 22:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:26:46 --> Controller Class Initialized
INFO - 2017-02-22 22:26:46 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:26:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:26:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:26:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:26:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:26:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:26:46 --> Final output sent to browser
DEBUG - 2017-02-22 22:26:46 --> Total execution time: 1.7715
INFO - 2017-02-22 22:27:08 --> Config Class Initialized
INFO - 2017-02-22 22:27:08 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:27:08 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:27:08 --> Utf8 Class Initialized
INFO - 2017-02-22 22:27:08 --> URI Class Initialized
INFO - 2017-02-22 22:27:08 --> Router Class Initialized
INFO - 2017-02-22 22:27:08 --> Output Class Initialized
INFO - 2017-02-22 22:27:08 --> Security Class Initialized
DEBUG - 2017-02-22 22:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:27:08 --> Input Class Initialized
INFO - 2017-02-22 22:27:08 --> Language Class Initialized
INFO - 2017-02-22 22:27:08 --> Loader Class Initialized
INFO - 2017-02-22 22:27:09 --> Database Driver Class Initialized
INFO - 2017-02-22 22:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:27:09 --> Controller Class Initialized
INFO - 2017-02-22 22:27:09 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:27:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:27:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:27:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:27:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:27:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:27:09 --> Final output sent to browser
DEBUG - 2017-02-22 22:27:09 --> Total execution time: 1.2045
INFO - 2017-02-22 22:28:40 --> Config Class Initialized
INFO - 2017-02-22 22:28:40 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:28:41 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:28:41 --> Utf8 Class Initialized
INFO - 2017-02-22 22:28:41 --> URI Class Initialized
INFO - 2017-02-22 22:28:41 --> Router Class Initialized
INFO - 2017-02-22 22:28:41 --> Output Class Initialized
INFO - 2017-02-22 22:28:41 --> Security Class Initialized
DEBUG - 2017-02-22 22:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:28:41 --> Input Class Initialized
INFO - 2017-02-22 22:28:41 --> Language Class Initialized
INFO - 2017-02-22 22:28:41 --> Loader Class Initialized
INFO - 2017-02-22 22:28:41 --> Database Driver Class Initialized
INFO - 2017-02-22 22:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:28:41 --> Controller Class Initialized
INFO - 2017-02-22 22:28:41 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:28:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:28:44 --> Config Class Initialized
INFO - 2017-02-22 22:28:44 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:28:44 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:28:44 --> Utf8 Class Initialized
INFO - 2017-02-22 22:28:44 --> URI Class Initialized
INFO - 2017-02-22 22:28:44 --> Router Class Initialized
INFO - 2017-02-22 22:28:44 --> Output Class Initialized
INFO - 2017-02-22 22:28:44 --> Security Class Initialized
DEBUG - 2017-02-22 22:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:28:44 --> Input Class Initialized
INFO - 2017-02-22 22:28:44 --> Language Class Initialized
INFO - 2017-02-22 22:28:44 --> Loader Class Initialized
INFO - 2017-02-22 22:28:44 --> Database Driver Class Initialized
INFO - 2017-02-22 22:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:28:44 --> Controller Class Initialized
INFO - 2017-02-22 22:28:44 --> Helper loaded: date_helper
DEBUG - 2017-02-22 22:28:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:28:44 --> Helper loaded: url_helper
INFO - 2017-02-22 22:28:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:28:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-22 22:28:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-22 22:28:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-22 22:28:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:28:44 --> Final output sent to browser
DEBUG - 2017-02-22 22:28:44 --> Total execution time: 0.1412
INFO - 2017-02-22 22:28:48 --> Config Class Initialized
INFO - 2017-02-22 22:28:48 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:28:48 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:28:48 --> Utf8 Class Initialized
INFO - 2017-02-22 22:28:48 --> URI Class Initialized
INFO - 2017-02-22 22:28:48 --> Router Class Initialized
INFO - 2017-02-22 22:28:48 --> Output Class Initialized
INFO - 2017-02-22 22:28:48 --> Security Class Initialized
DEBUG - 2017-02-22 22:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:28:48 --> Input Class Initialized
INFO - 2017-02-22 22:28:48 --> Language Class Initialized
INFO - 2017-02-22 22:28:48 --> Loader Class Initialized
INFO - 2017-02-22 22:28:48 --> Database Driver Class Initialized
INFO - 2017-02-22 22:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:28:48 --> Controller Class Initialized
INFO - 2017-02-22 22:28:48 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:28:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:28:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:28:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:28:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:28:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:28:48 --> Final output sent to browser
DEBUG - 2017-02-22 22:28:48 --> Total execution time: 0.0359
INFO - 2017-02-22 22:35:57 --> Config Class Initialized
INFO - 2017-02-22 22:35:57 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:35:57 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:35:57 --> Utf8 Class Initialized
INFO - 2017-02-22 22:35:57 --> URI Class Initialized
DEBUG - 2017-02-22 22:35:57 --> No URI present. Default controller set.
INFO - 2017-02-22 22:35:57 --> Router Class Initialized
INFO - 2017-02-22 22:35:57 --> Output Class Initialized
INFO - 2017-02-22 22:35:57 --> Security Class Initialized
DEBUG - 2017-02-22 22:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:35:57 --> Input Class Initialized
INFO - 2017-02-22 22:35:57 --> Language Class Initialized
INFO - 2017-02-22 22:35:57 --> Loader Class Initialized
INFO - 2017-02-22 22:35:58 --> Database Driver Class Initialized
INFO - 2017-02-22 22:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:35:58 --> Controller Class Initialized
INFO - 2017-02-22 22:35:58 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:35:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:35:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:35:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:35:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:35:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:35:59 --> Final output sent to browser
DEBUG - 2017-02-22 22:35:59 --> Total execution time: 4.0314
INFO - 2017-02-22 22:36:13 --> Config Class Initialized
INFO - 2017-02-22 22:36:13 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:36:13 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:36:13 --> Utf8 Class Initialized
INFO - 2017-02-22 22:36:13 --> URI Class Initialized
INFO - 2017-02-22 22:36:13 --> Router Class Initialized
INFO - 2017-02-22 22:36:13 --> Output Class Initialized
INFO - 2017-02-22 22:36:13 --> Security Class Initialized
DEBUG - 2017-02-22 22:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:36:13 --> Input Class Initialized
INFO - 2017-02-22 22:36:13 --> Language Class Initialized
INFO - 2017-02-22 22:36:13 --> Loader Class Initialized
INFO - 2017-02-22 22:36:14 --> Database Driver Class Initialized
INFO - 2017-02-22 22:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:36:14 --> Controller Class Initialized
INFO - 2017-02-22 22:36:14 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:36:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:36:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:36:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:36:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:36:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:36:14 --> Final output sent to browser
DEBUG - 2017-02-22 22:36:14 --> Total execution time: 1.2298
INFO - 2017-02-22 22:37:36 --> Config Class Initialized
INFO - 2017-02-22 22:37:36 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:37:36 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:37:36 --> Utf8 Class Initialized
INFO - 2017-02-22 22:37:36 --> URI Class Initialized
INFO - 2017-02-22 22:37:36 --> Router Class Initialized
INFO - 2017-02-22 22:37:36 --> Output Class Initialized
INFO - 2017-02-22 22:37:36 --> Security Class Initialized
DEBUG - 2017-02-22 22:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:37:36 --> Input Class Initialized
INFO - 2017-02-22 22:37:36 --> Language Class Initialized
INFO - 2017-02-22 22:37:36 --> Loader Class Initialized
INFO - 2017-02-22 22:37:36 --> Database Driver Class Initialized
INFO - 2017-02-22 22:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:37:36 --> Controller Class Initialized
INFO - 2017-02-22 22:37:36 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:37:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:37:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:37:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:37:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:37:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:37:36 --> Final output sent to browser
DEBUG - 2017-02-22 22:37:36 --> Total execution time: 0.0417
INFO - 2017-02-22 22:37:37 --> Config Class Initialized
INFO - 2017-02-22 22:37:37 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:37:37 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:37:37 --> Utf8 Class Initialized
INFO - 2017-02-22 22:37:37 --> URI Class Initialized
INFO - 2017-02-22 22:37:37 --> Router Class Initialized
INFO - 2017-02-22 22:37:37 --> Output Class Initialized
INFO - 2017-02-22 22:37:37 --> Security Class Initialized
DEBUG - 2017-02-22 22:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:37:37 --> Input Class Initialized
INFO - 2017-02-22 22:37:37 --> Language Class Initialized
INFO - 2017-02-22 22:37:37 --> Loader Class Initialized
INFO - 2017-02-22 22:37:37 --> Database Driver Class Initialized
INFO - 2017-02-22 22:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:37:37 --> Controller Class Initialized
INFO - 2017-02-22 22:37:37 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:37:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:37:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:37:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:37:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:37:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:37:38 --> Final output sent to browser
DEBUG - 2017-02-22 22:37:38 --> Total execution time: 0.0424
INFO - 2017-02-22 22:37:53 --> Config Class Initialized
INFO - 2017-02-22 22:37:53 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:37:53 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:37:53 --> Utf8 Class Initialized
INFO - 2017-02-22 22:37:53 --> URI Class Initialized
INFO - 2017-02-22 22:37:53 --> Router Class Initialized
INFO - 2017-02-22 22:37:53 --> Output Class Initialized
INFO - 2017-02-22 22:37:53 --> Security Class Initialized
DEBUG - 2017-02-22 22:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:37:53 --> Input Class Initialized
INFO - 2017-02-22 22:37:53 --> Language Class Initialized
INFO - 2017-02-22 22:37:53 --> Loader Class Initialized
INFO - 2017-02-22 22:37:53 --> Database Driver Class Initialized
INFO - 2017-02-22 22:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:37:53 --> Controller Class Initialized
INFO - 2017-02-22 22:37:53 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:37:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:37:55 --> Config Class Initialized
INFO - 2017-02-22 22:37:55 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:37:55 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:37:55 --> Utf8 Class Initialized
INFO - 2017-02-22 22:37:55 --> URI Class Initialized
INFO - 2017-02-22 22:37:55 --> Router Class Initialized
INFO - 2017-02-22 22:37:55 --> Output Class Initialized
INFO - 2017-02-22 22:37:55 --> Security Class Initialized
DEBUG - 2017-02-22 22:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:37:55 --> Input Class Initialized
INFO - 2017-02-22 22:37:55 --> Language Class Initialized
INFO - 2017-02-22 22:37:55 --> Loader Class Initialized
INFO - 2017-02-22 22:37:55 --> Database Driver Class Initialized
INFO - 2017-02-22 22:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:37:55 --> Controller Class Initialized
INFO - 2017-02-22 22:37:55 --> Helper loaded: date_helper
DEBUG - 2017-02-22 22:37:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:37:55 --> Helper loaded: url_helper
INFO - 2017-02-22 22:37:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:37:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-22 22:37:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-22 22:37:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-22 22:37:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:37:55 --> Final output sent to browser
DEBUG - 2017-02-22 22:37:55 --> Total execution time: 0.0924
INFO - 2017-02-22 22:37:56 --> Config Class Initialized
INFO - 2017-02-22 22:37:56 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:37:56 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:37:56 --> Utf8 Class Initialized
INFO - 2017-02-22 22:37:56 --> URI Class Initialized
INFO - 2017-02-22 22:37:56 --> Router Class Initialized
INFO - 2017-02-22 22:37:56 --> Output Class Initialized
INFO - 2017-02-22 22:37:56 --> Security Class Initialized
DEBUG - 2017-02-22 22:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:37:56 --> Input Class Initialized
INFO - 2017-02-22 22:37:56 --> Language Class Initialized
INFO - 2017-02-22 22:37:56 --> Loader Class Initialized
INFO - 2017-02-22 22:37:56 --> Database Driver Class Initialized
INFO - 2017-02-22 22:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:37:56 --> Controller Class Initialized
INFO - 2017-02-22 22:37:56 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:37:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:37:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:37:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:37:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:37:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:37:56 --> Final output sent to browser
DEBUG - 2017-02-22 22:37:56 --> Total execution time: 0.0150
INFO - 2017-02-22 22:38:46 --> Config Class Initialized
INFO - 2017-02-22 22:38:46 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:38:46 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:38:46 --> Utf8 Class Initialized
INFO - 2017-02-22 22:38:46 --> URI Class Initialized
DEBUG - 2017-02-22 22:38:46 --> No URI present. Default controller set.
INFO - 2017-02-22 22:38:46 --> Router Class Initialized
INFO - 2017-02-22 22:38:46 --> Output Class Initialized
INFO - 2017-02-22 22:38:46 --> Security Class Initialized
DEBUG - 2017-02-22 22:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:38:46 --> Input Class Initialized
INFO - 2017-02-22 22:38:46 --> Language Class Initialized
INFO - 2017-02-22 22:38:46 --> Loader Class Initialized
INFO - 2017-02-22 22:38:46 --> Database Driver Class Initialized
INFO - 2017-02-22 22:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:38:46 --> Controller Class Initialized
INFO - 2017-02-22 22:38:46 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:38:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:38:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:38:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:38:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:38:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:38:46 --> Final output sent to browser
DEBUG - 2017-02-22 22:38:46 --> Total execution time: 0.0372
INFO - 2017-02-22 22:38:48 --> Config Class Initialized
INFO - 2017-02-22 22:38:48 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:38:48 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:38:48 --> Utf8 Class Initialized
INFO - 2017-02-22 22:38:48 --> URI Class Initialized
INFO - 2017-02-22 22:38:48 --> Router Class Initialized
INFO - 2017-02-22 22:38:48 --> Output Class Initialized
INFO - 2017-02-22 22:38:48 --> Security Class Initialized
DEBUG - 2017-02-22 22:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:38:48 --> Input Class Initialized
INFO - 2017-02-22 22:38:48 --> Language Class Initialized
INFO - 2017-02-22 22:38:48 --> Loader Class Initialized
INFO - 2017-02-22 22:38:48 --> Database Driver Class Initialized
INFO - 2017-02-22 22:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:38:48 --> Controller Class Initialized
INFO - 2017-02-22 22:38:48 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:38:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:38:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:38:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:38:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:38:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:38:48 --> Final output sent to browser
DEBUG - 2017-02-22 22:38:48 --> Total execution time: 0.0151
INFO - 2017-02-22 22:39:58 --> Config Class Initialized
INFO - 2017-02-22 22:39:58 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:39:58 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:39:58 --> Utf8 Class Initialized
INFO - 2017-02-22 22:39:58 --> URI Class Initialized
DEBUG - 2017-02-22 22:39:58 --> No URI present. Default controller set.
INFO - 2017-02-22 22:39:58 --> Router Class Initialized
INFO - 2017-02-22 22:39:58 --> Output Class Initialized
INFO - 2017-02-22 22:39:58 --> Security Class Initialized
DEBUG - 2017-02-22 22:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:39:58 --> Input Class Initialized
INFO - 2017-02-22 22:39:58 --> Language Class Initialized
INFO - 2017-02-22 22:39:58 --> Loader Class Initialized
INFO - 2017-02-22 22:39:58 --> Database Driver Class Initialized
INFO - 2017-02-22 22:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:39:59 --> Controller Class Initialized
INFO - 2017-02-22 22:39:59 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:39:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:39:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:39:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:39:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:39:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:39:59 --> Final output sent to browser
DEBUG - 2017-02-22 22:39:59 --> Total execution time: 0.5104
INFO - 2017-02-22 22:40:04 --> Config Class Initialized
INFO - 2017-02-22 22:40:04 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:40:04 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:40:04 --> Utf8 Class Initialized
INFO - 2017-02-22 22:40:04 --> URI Class Initialized
INFO - 2017-02-22 22:40:04 --> Router Class Initialized
INFO - 2017-02-22 22:40:04 --> Output Class Initialized
INFO - 2017-02-22 22:40:04 --> Security Class Initialized
DEBUG - 2017-02-22 22:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:40:04 --> Input Class Initialized
INFO - 2017-02-22 22:40:04 --> Language Class Initialized
INFO - 2017-02-22 22:40:04 --> Loader Class Initialized
INFO - 2017-02-22 22:40:04 --> Database Driver Class Initialized
INFO - 2017-02-22 22:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:40:04 --> Controller Class Initialized
INFO - 2017-02-22 22:40:04 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:40:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:40:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:40:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:40:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:40:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:40:04 --> Final output sent to browser
DEBUG - 2017-02-22 22:40:04 --> Total execution time: 0.0145
INFO - 2017-02-22 22:40:28 --> Config Class Initialized
INFO - 2017-02-22 22:40:28 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:40:28 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:40:28 --> Utf8 Class Initialized
INFO - 2017-02-22 22:40:28 --> URI Class Initialized
INFO - 2017-02-22 22:40:28 --> Router Class Initialized
INFO - 2017-02-22 22:40:28 --> Output Class Initialized
INFO - 2017-02-22 22:40:28 --> Security Class Initialized
DEBUG - 2017-02-22 22:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:40:28 --> Input Class Initialized
INFO - 2017-02-22 22:40:28 --> Language Class Initialized
INFO - 2017-02-22 22:40:28 --> Loader Class Initialized
INFO - 2017-02-22 22:40:28 --> Database Driver Class Initialized
INFO - 2017-02-22 22:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:40:28 --> Controller Class Initialized
INFO - 2017-02-22 22:40:28 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:40:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:40:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:40:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:40:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:40:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:40:28 --> Final output sent to browser
DEBUG - 2017-02-22 22:40:28 --> Total execution time: 0.0148
INFO - 2017-02-22 22:40:31 --> Config Class Initialized
INFO - 2017-02-22 22:40:31 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:40:31 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:40:31 --> Utf8 Class Initialized
INFO - 2017-02-22 22:40:31 --> URI Class Initialized
INFO - 2017-02-22 22:40:31 --> Router Class Initialized
INFO - 2017-02-22 22:40:31 --> Output Class Initialized
INFO - 2017-02-22 22:40:31 --> Security Class Initialized
DEBUG - 2017-02-22 22:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:40:31 --> Input Class Initialized
INFO - 2017-02-22 22:40:31 --> Language Class Initialized
INFO - 2017-02-22 22:40:31 --> Loader Class Initialized
INFO - 2017-02-22 22:40:31 --> Database Driver Class Initialized
INFO - 2017-02-22 22:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:40:31 --> Controller Class Initialized
INFO - 2017-02-22 22:40:31 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:40:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:40:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:40:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:40:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:40:31 --> Final output sent to browser
DEBUG - 2017-02-22 22:40:31 --> Total execution time: 0.0146
INFO - 2017-02-22 22:40:47 --> Config Class Initialized
INFO - 2017-02-22 22:40:47 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:40:47 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:40:47 --> Utf8 Class Initialized
INFO - 2017-02-22 22:40:47 --> URI Class Initialized
INFO - 2017-02-22 22:40:47 --> Router Class Initialized
INFO - 2017-02-22 22:40:47 --> Output Class Initialized
INFO - 2017-02-22 22:40:47 --> Security Class Initialized
DEBUG - 2017-02-22 22:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:40:47 --> Input Class Initialized
INFO - 2017-02-22 22:40:47 --> Language Class Initialized
INFO - 2017-02-22 22:40:47 --> Loader Class Initialized
INFO - 2017-02-22 22:40:47 --> Database Driver Class Initialized
INFO - 2017-02-22 22:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:40:47 --> Controller Class Initialized
INFO - 2017-02-22 22:40:47 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:40:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:40:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:40:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:40:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:40:47 --> Final output sent to browser
DEBUG - 2017-02-22 22:40:47 --> Total execution time: 0.0629
INFO - 2017-02-22 22:40:50 --> Config Class Initialized
INFO - 2017-02-22 22:40:50 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:40:50 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:40:50 --> Utf8 Class Initialized
INFO - 2017-02-22 22:40:50 --> URI Class Initialized
INFO - 2017-02-22 22:40:50 --> Router Class Initialized
INFO - 2017-02-22 22:40:50 --> Output Class Initialized
INFO - 2017-02-22 22:40:50 --> Security Class Initialized
DEBUG - 2017-02-22 22:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:40:50 --> Input Class Initialized
INFO - 2017-02-22 22:40:50 --> Language Class Initialized
INFO - 2017-02-22 22:40:50 --> Loader Class Initialized
INFO - 2017-02-22 22:40:50 --> Database Driver Class Initialized
INFO - 2017-02-22 22:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:40:50 --> Controller Class Initialized
INFO - 2017-02-22 22:40:50 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:40:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:40:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:40:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:40:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:40:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:40:50 --> Final output sent to browser
DEBUG - 2017-02-22 22:40:50 --> Total execution time: 0.0146
INFO - 2017-02-22 22:41:33 --> Config Class Initialized
INFO - 2017-02-22 22:41:33 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:41:33 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:41:33 --> Utf8 Class Initialized
INFO - 2017-02-22 22:41:33 --> URI Class Initialized
INFO - 2017-02-22 22:41:33 --> Router Class Initialized
INFO - 2017-02-22 22:41:33 --> Output Class Initialized
INFO - 2017-02-22 22:41:33 --> Security Class Initialized
DEBUG - 2017-02-22 22:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:41:33 --> Input Class Initialized
INFO - 2017-02-22 22:41:33 --> Language Class Initialized
INFO - 2017-02-22 22:41:33 --> Loader Class Initialized
INFO - 2017-02-22 22:41:33 --> Database Driver Class Initialized
INFO - 2017-02-22 22:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:41:33 --> Controller Class Initialized
INFO - 2017-02-22 22:41:33 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:41:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:41:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:41:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:41:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:41:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:41:33 --> Final output sent to browser
DEBUG - 2017-02-22 22:41:33 --> Total execution time: 0.0355
INFO - 2017-02-22 22:41:36 --> Config Class Initialized
INFO - 2017-02-22 22:41:36 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:41:36 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:41:36 --> Utf8 Class Initialized
INFO - 2017-02-22 22:41:36 --> URI Class Initialized
INFO - 2017-02-22 22:41:36 --> Router Class Initialized
INFO - 2017-02-22 22:41:36 --> Output Class Initialized
INFO - 2017-02-22 22:41:36 --> Security Class Initialized
DEBUG - 2017-02-22 22:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:41:36 --> Input Class Initialized
INFO - 2017-02-22 22:41:36 --> Language Class Initialized
INFO - 2017-02-22 22:41:36 --> Loader Class Initialized
INFO - 2017-02-22 22:41:36 --> Database Driver Class Initialized
INFO - 2017-02-22 22:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:41:36 --> Controller Class Initialized
INFO - 2017-02-22 22:41:36 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:41:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:41:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:41:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:41:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:41:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:41:36 --> Final output sent to browser
DEBUG - 2017-02-22 22:41:36 --> Total execution time: 0.0138
INFO - 2017-02-22 22:42:16 --> Config Class Initialized
INFO - 2017-02-22 22:42:16 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:42:16 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:42:16 --> Utf8 Class Initialized
INFO - 2017-02-22 22:42:16 --> URI Class Initialized
INFO - 2017-02-22 22:42:16 --> Router Class Initialized
INFO - 2017-02-22 22:42:16 --> Output Class Initialized
INFO - 2017-02-22 22:42:16 --> Security Class Initialized
DEBUG - 2017-02-22 22:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:42:16 --> Input Class Initialized
INFO - 2017-02-22 22:42:16 --> Language Class Initialized
INFO - 2017-02-22 22:42:16 --> Loader Class Initialized
INFO - 2017-02-22 22:42:16 --> Database Driver Class Initialized
INFO - 2017-02-22 22:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:42:16 --> Controller Class Initialized
INFO - 2017-02-22 22:42:16 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:42:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:42:17 --> Config Class Initialized
INFO - 2017-02-22 22:42:17 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:42:17 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:42:17 --> Utf8 Class Initialized
INFO - 2017-02-22 22:42:17 --> URI Class Initialized
INFO - 2017-02-22 22:42:17 --> Router Class Initialized
INFO - 2017-02-22 22:42:17 --> Output Class Initialized
INFO - 2017-02-22 22:42:17 --> Security Class Initialized
DEBUG - 2017-02-22 22:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:42:17 --> Input Class Initialized
INFO - 2017-02-22 22:42:17 --> Language Class Initialized
INFO - 2017-02-22 22:42:17 --> Loader Class Initialized
INFO - 2017-02-22 22:42:17 --> Database Driver Class Initialized
INFO - 2017-02-22 22:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:42:17 --> Controller Class Initialized
INFO - 2017-02-22 22:42:17 --> Helper loaded: date_helper
DEBUG - 2017-02-22 22:42:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:42:17 --> Helper loaded: url_helper
INFO - 2017-02-22 22:42:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:42:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-22 22:42:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-22 22:42:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-22 22:42:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:42:17 --> Final output sent to browser
DEBUG - 2017-02-22 22:42:17 --> Total execution time: 0.0142
INFO - 2017-02-22 22:42:19 --> Config Class Initialized
INFO - 2017-02-22 22:42:19 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:42:19 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:42:19 --> Utf8 Class Initialized
INFO - 2017-02-22 22:42:19 --> URI Class Initialized
INFO - 2017-02-22 22:42:19 --> Router Class Initialized
INFO - 2017-02-22 22:42:19 --> Output Class Initialized
INFO - 2017-02-22 22:42:19 --> Security Class Initialized
DEBUG - 2017-02-22 22:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:42:19 --> Input Class Initialized
INFO - 2017-02-22 22:42:19 --> Language Class Initialized
INFO - 2017-02-22 22:42:19 --> Loader Class Initialized
INFO - 2017-02-22 22:42:19 --> Database Driver Class Initialized
INFO - 2017-02-22 22:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:42:19 --> Controller Class Initialized
INFO - 2017-02-22 22:42:19 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:42:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:42:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:42:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:42:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:42:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:42:19 --> Final output sent to browser
DEBUG - 2017-02-22 22:42:19 --> Total execution time: 0.0141
INFO - 2017-02-22 22:42:53 --> Config Class Initialized
INFO - 2017-02-22 22:42:53 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:42:53 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:42:53 --> Utf8 Class Initialized
INFO - 2017-02-22 22:42:53 --> URI Class Initialized
INFO - 2017-02-22 22:42:54 --> Router Class Initialized
INFO - 2017-02-22 22:42:54 --> Output Class Initialized
INFO - 2017-02-22 22:42:54 --> Security Class Initialized
DEBUG - 2017-02-22 22:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:42:54 --> Input Class Initialized
INFO - 2017-02-22 22:42:54 --> Language Class Initialized
INFO - 2017-02-22 22:42:54 --> Loader Class Initialized
INFO - 2017-02-22 22:42:54 --> Database Driver Class Initialized
INFO - 2017-02-22 22:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:42:54 --> Controller Class Initialized
INFO - 2017-02-22 22:42:54 --> Helper loaded: date_helper
DEBUG - 2017-02-22 22:42:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:42:54 --> Helper loaded: url_helper
INFO - 2017-02-22 22:42:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:42:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-22 22:42:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-22 22:42:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-22 22:42:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:42:54 --> Final output sent to browser
DEBUG - 2017-02-22 22:42:54 --> Total execution time: 1.1095
INFO - 2017-02-22 22:42:56 --> Config Class Initialized
INFO - 2017-02-22 22:42:56 --> Hooks Class Initialized
DEBUG - 2017-02-22 22:42:56 --> UTF-8 Support Enabled
INFO - 2017-02-22 22:42:56 --> Utf8 Class Initialized
INFO - 2017-02-22 22:42:56 --> URI Class Initialized
INFO - 2017-02-22 22:42:56 --> Router Class Initialized
INFO - 2017-02-22 22:42:56 --> Output Class Initialized
INFO - 2017-02-22 22:42:56 --> Security Class Initialized
DEBUG - 2017-02-22 22:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 22:42:56 --> Input Class Initialized
INFO - 2017-02-22 22:42:56 --> Language Class Initialized
INFO - 2017-02-22 22:42:56 --> Loader Class Initialized
INFO - 2017-02-22 22:42:56 --> Database Driver Class Initialized
INFO - 2017-02-22 22:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 22:42:56 --> Controller Class Initialized
INFO - 2017-02-22 22:42:56 --> Helper loaded: url_helper
DEBUG - 2017-02-22 22:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 22:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 22:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 22:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 22:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 22:42:56 --> Final output sent to browser
DEBUG - 2017-02-22 22:42:56 --> Total execution time: 0.2575
INFO - 2017-02-22 23:02:38 --> Config Class Initialized
INFO - 2017-02-22 23:02:38 --> Hooks Class Initialized
DEBUG - 2017-02-22 23:02:38 --> UTF-8 Support Enabled
INFO - 2017-02-22 23:02:38 --> Utf8 Class Initialized
INFO - 2017-02-22 23:02:38 --> URI Class Initialized
DEBUG - 2017-02-22 23:02:38 --> No URI present. Default controller set.
INFO - 2017-02-22 23:02:38 --> Router Class Initialized
INFO - 2017-02-22 23:02:38 --> Output Class Initialized
INFO - 2017-02-22 23:02:38 --> Security Class Initialized
DEBUG - 2017-02-22 23:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 23:02:39 --> Input Class Initialized
INFO - 2017-02-22 23:02:39 --> Language Class Initialized
INFO - 2017-02-22 23:02:39 --> Loader Class Initialized
INFO - 2017-02-22 23:02:39 --> Database Driver Class Initialized
INFO - 2017-02-22 23:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 23:02:40 --> Controller Class Initialized
INFO - 2017-02-22 23:02:40 --> Helper loaded: url_helper
DEBUG - 2017-02-22 23:02:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 23:02:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 23:02:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 23:02:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 23:02:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 23:02:40 --> Final output sent to browser
DEBUG - 2017-02-22 23:02:40 --> Total execution time: 1.8463
INFO - 2017-02-22 23:17:05 --> Config Class Initialized
INFO - 2017-02-22 23:17:05 --> Hooks Class Initialized
DEBUG - 2017-02-22 23:17:05 --> UTF-8 Support Enabled
INFO - 2017-02-22 23:17:05 --> Utf8 Class Initialized
INFO - 2017-02-22 23:17:05 --> URI Class Initialized
DEBUG - 2017-02-22 23:17:05 --> No URI present. Default controller set.
INFO - 2017-02-22 23:17:05 --> Router Class Initialized
INFO - 2017-02-22 23:17:05 --> Output Class Initialized
INFO - 2017-02-22 23:17:05 --> Security Class Initialized
DEBUG - 2017-02-22 23:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 23:17:05 --> Input Class Initialized
INFO - 2017-02-22 23:17:05 --> Language Class Initialized
INFO - 2017-02-22 23:17:05 --> Loader Class Initialized
INFO - 2017-02-22 23:17:06 --> Database Driver Class Initialized
INFO - 2017-02-22 23:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 23:17:06 --> Controller Class Initialized
INFO - 2017-02-22 23:17:06 --> Helper loaded: url_helper
DEBUG - 2017-02-22 23:17:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 23:17:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 23:17:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 23:17:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 23:17:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 23:17:07 --> Final output sent to browser
DEBUG - 2017-02-22 23:17:07 --> Total execution time: 1.8509
INFO - 2017-02-22 23:18:14 --> Config Class Initialized
INFO - 2017-02-22 23:18:14 --> Hooks Class Initialized
DEBUG - 2017-02-22 23:18:14 --> UTF-8 Support Enabled
INFO - 2017-02-22 23:18:14 --> Utf8 Class Initialized
INFO - 2017-02-22 23:18:14 --> URI Class Initialized
DEBUG - 2017-02-22 23:18:14 --> No URI present. Default controller set.
INFO - 2017-02-22 23:18:14 --> Router Class Initialized
INFO - 2017-02-22 23:18:14 --> Output Class Initialized
INFO - 2017-02-22 23:18:14 --> Security Class Initialized
DEBUG - 2017-02-22 23:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 23:18:14 --> Input Class Initialized
INFO - 2017-02-22 23:18:14 --> Language Class Initialized
INFO - 2017-02-22 23:18:14 --> Loader Class Initialized
INFO - 2017-02-22 23:18:14 --> Database Driver Class Initialized
INFO - 2017-02-22 23:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 23:18:14 --> Controller Class Initialized
INFO - 2017-02-22 23:18:14 --> Helper loaded: url_helper
DEBUG - 2017-02-22 23:18:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 23:18:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 23:18:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 23:18:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 23:18:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 23:18:14 --> Final output sent to browser
DEBUG - 2017-02-22 23:18:14 --> Total execution time: 0.0498
INFO - 2017-02-22 23:18:42 --> Config Class Initialized
INFO - 2017-02-22 23:18:42 --> Hooks Class Initialized
DEBUG - 2017-02-22 23:18:42 --> UTF-8 Support Enabled
INFO - 2017-02-22 23:18:42 --> Utf8 Class Initialized
INFO - 2017-02-22 23:18:42 --> URI Class Initialized
INFO - 2017-02-22 23:18:42 --> Router Class Initialized
INFO - 2017-02-22 23:18:42 --> Output Class Initialized
INFO - 2017-02-22 23:18:42 --> Security Class Initialized
DEBUG - 2017-02-22 23:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 23:18:42 --> Input Class Initialized
INFO - 2017-02-22 23:18:42 --> Language Class Initialized
INFO - 2017-02-22 23:18:42 --> Loader Class Initialized
INFO - 2017-02-22 23:18:42 --> Database Driver Class Initialized
INFO - 2017-02-22 23:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 23:18:42 --> Controller Class Initialized
INFO - 2017-02-22 23:18:42 --> Helper loaded: url_helper
DEBUG - 2017-02-22 23:18:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 23:18:44 --> Config Class Initialized
INFO - 2017-02-22 23:18:44 --> Hooks Class Initialized
DEBUG - 2017-02-22 23:18:44 --> UTF-8 Support Enabled
INFO - 2017-02-22 23:18:44 --> Utf8 Class Initialized
INFO - 2017-02-22 23:18:44 --> URI Class Initialized
INFO - 2017-02-22 23:18:44 --> Router Class Initialized
INFO - 2017-02-22 23:18:44 --> Output Class Initialized
INFO - 2017-02-22 23:18:44 --> Security Class Initialized
DEBUG - 2017-02-22 23:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 23:18:44 --> Input Class Initialized
INFO - 2017-02-22 23:18:44 --> Language Class Initialized
INFO - 2017-02-22 23:18:44 --> Loader Class Initialized
INFO - 2017-02-22 23:18:44 --> Database Driver Class Initialized
INFO - 2017-02-22 23:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 23:18:44 --> Controller Class Initialized
INFO - 2017-02-22 23:18:44 --> Helper loaded: date_helper
DEBUG - 2017-02-22 23:18:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 23:18:44 --> Helper loaded: url_helper
INFO - 2017-02-22 23:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 23:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-22 23:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-22 23:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-22 23:18:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 23:18:44 --> Final output sent to browser
DEBUG - 2017-02-22 23:18:44 --> Total execution time: 0.0942
INFO - 2017-02-22 23:18:47 --> Config Class Initialized
INFO - 2017-02-22 23:18:47 --> Hooks Class Initialized
DEBUG - 2017-02-22 23:18:47 --> UTF-8 Support Enabled
INFO - 2017-02-22 23:18:47 --> Utf8 Class Initialized
INFO - 2017-02-22 23:18:47 --> URI Class Initialized
INFO - 2017-02-22 23:18:47 --> Router Class Initialized
INFO - 2017-02-22 23:18:47 --> Output Class Initialized
INFO - 2017-02-22 23:18:47 --> Security Class Initialized
DEBUG - 2017-02-22 23:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 23:18:47 --> Input Class Initialized
INFO - 2017-02-22 23:18:47 --> Language Class Initialized
INFO - 2017-02-22 23:18:47 --> Loader Class Initialized
INFO - 2017-02-22 23:18:47 --> Database Driver Class Initialized
INFO - 2017-02-22 23:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 23:18:47 --> Controller Class Initialized
INFO - 2017-02-22 23:18:47 --> Helper loaded: url_helper
DEBUG - 2017-02-22 23:18:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 23:18:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 23:18:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 23:18:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 23:18:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 23:18:47 --> Final output sent to browser
DEBUG - 2017-02-22 23:18:47 --> Total execution time: 0.0141
INFO - 2017-02-22 23:18:52 --> Config Class Initialized
INFO - 2017-02-22 23:18:52 --> Hooks Class Initialized
DEBUG - 2017-02-22 23:18:52 --> UTF-8 Support Enabled
INFO - 2017-02-22 23:18:52 --> Utf8 Class Initialized
INFO - 2017-02-22 23:18:52 --> URI Class Initialized
DEBUG - 2017-02-22 23:18:52 --> No URI present. Default controller set.
INFO - 2017-02-22 23:18:52 --> Router Class Initialized
INFO - 2017-02-22 23:18:52 --> Output Class Initialized
INFO - 2017-02-22 23:18:52 --> Security Class Initialized
DEBUG - 2017-02-22 23:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 23:18:52 --> Input Class Initialized
INFO - 2017-02-22 23:18:52 --> Language Class Initialized
INFO - 2017-02-22 23:18:52 --> Loader Class Initialized
INFO - 2017-02-22 23:18:52 --> Database Driver Class Initialized
INFO - 2017-02-22 23:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 23:18:52 --> Controller Class Initialized
INFO - 2017-02-22 23:18:52 --> Helper loaded: url_helper
DEBUG - 2017-02-22 23:18:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 23:18:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 23:18:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 23:18:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 23:18:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 23:18:52 --> Final output sent to browser
DEBUG - 2017-02-22 23:18:52 --> Total execution time: 0.0139
INFO - 2017-02-22 23:18:56 --> Config Class Initialized
INFO - 2017-02-22 23:18:56 --> Hooks Class Initialized
DEBUG - 2017-02-22 23:18:56 --> UTF-8 Support Enabled
INFO - 2017-02-22 23:18:56 --> Utf8 Class Initialized
INFO - 2017-02-22 23:18:56 --> URI Class Initialized
INFO - 2017-02-22 23:18:56 --> Router Class Initialized
INFO - 2017-02-22 23:18:56 --> Output Class Initialized
INFO - 2017-02-22 23:18:56 --> Security Class Initialized
DEBUG - 2017-02-22 23:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 23:18:56 --> Input Class Initialized
INFO - 2017-02-22 23:18:56 --> Language Class Initialized
INFO - 2017-02-22 23:18:56 --> Loader Class Initialized
INFO - 2017-02-22 23:18:56 --> Database Driver Class Initialized
INFO - 2017-02-22 23:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 23:18:56 --> Controller Class Initialized
INFO - 2017-02-22 23:18:56 --> Helper loaded: url_helper
DEBUG - 2017-02-22 23:18:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 23:18:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 23:18:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 23:18:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 23:18:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 23:18:56 --> Final output sent to browser
DEBUG - 2017-02-22 23:18:56 --> Total execution time: 0.0145
INFO - 2017-02-22 23:42:57 --> Config Class Initialized
INFO - 2017-02-22 23:42:57 --> Hooks Class Initialized
DEBUG - 2017-02-22 23:42:57 --> UTF-8 Support Enabled
INFO - 2017-02-22 23:42:57 --> Utf8 Class Initialized
INFO - 2017-02-22 23:42:57 --> URI Class Initialized
DEBUG - 2017-02-22 23:42:57 --> No URI present. Default controller set.
INFO - 2017-02-22 23:42:57 --> Router Class Initialized
INFO - 2017-02-22 23:42:57 --> Output Class Initialized
INFO - 2017-02-22 23:42:57 --> Security Class Initialized
DEBUG - 2017-02-22 23:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 23:42:58 --> Input Class Initialized
INFO - 2017-02-22 23:42:58 --> Language Class Initialized
INFO - 2017-02-22 23:42:58 --> Loader Class Initialized
INFO - 2017-02-22 23:42:58 --> Database Driver Class Initialized
INFO - 2017-02-22 23:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 23:42:59 --> Controller Class Initialized
INFO - 2017-02-22 23:42:59 --> Helper loaded: url_helper
DEBUG - 2017-02-22 23:42:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 23:42:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 23:42:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 23:42:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 23:42:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 23:42:59 --> Final output sent to browser
DEBUG - 2017-02-22 23:42:59 --> Total execution time: 1.7626
INFO - 2017-02-22 23:43:09 --> Config Class Initialized
INFO - 2017-02-22 23:43:09 --> Hooks Class Initialized
DEBUG - 2017-02-22 23:43:09 --> UTF-8 Support Enabled
INFO - 2017-02-22 23:43:09 --> Utf8 Class Initialized
INFO - 2017-02-22 23:43:09 --> URI Class Initialized
INFO - 2017-02-22 23:43:09 --> Router Class Initialized
INFO - 2017-02-22 23:43:09 --> Output Class Initialized
INFO - 2017-02-22 23:43:09 --> Security Class Initialized
DEBUG - 2017-02-22 23:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 23:43:09 --> Input Class Initialized
INFO - 2017-02-22 23:43:09 --> Language Class Initialized
INFO - 2017-02-22 23:43:09 --> Loader Class Initialized
INFO - 2017-02-22 23:43:09 --> Database Driver Class Initialized
INFO - 2017-02-22 23:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 23:43:10 --> Controller Class Initialized
INFO - 2017-02-22 23:43:10 --> Helper loaded: url_helper
DEBUG - 2017-02-22 23:43:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 23:43:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 23:43:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 23:43:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 23:43:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 23:43:10 --> Final output sent to browser
DEBUG - 2017-02-22 23:43:10 --> Total execution time: 1.2007
INFO - 2017-02-22 23:45:32 --> Config Class Initialized
INFO - 2017-02-22 23:45:33 --> Hooks Class Initialized
DEBUG - 2017-02-22 23:45:33 --> UTF-8 Support Enabled
INFO - 2017-02-22 23:45:33 --> Utf8 Class Initialized
INFO - 2017-02-22 23:45:33 --> URI Class Initialized
INFO - 2017-02-22 23:45:33 --> Router Class Initialized
INFO - 2017-02-22 23:45:33 --> Output Class Initialized
INFO - 2017-02-22 23:45:33 --> Security Class Initialized
DEBUG - 2017-02-22 23:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 23:45:33 --> Input Class Initialized
INFO - 2017-02-22 23:45:33 --> Language Class Initialized
INFO - 2017-02-22 23:45:33 --> Loader Class Initialized
INFO - 2017-02-22 23:45:33 --> Database Driver Class Initialized
INFO - 2017-02-22 23:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 23:45:34 --> Controller Class Initialized
INFO - 2017-02-22 23:45:34 --> Helper loaded: url_helper
DEBUG - 2017-02-22 23:45:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 23:45:34 --> Config Class Initialized
INFO - 2017-02-22 23:45:34 --> Hooks Class Initialized
DEBUG - 2017-02-22 23:45:34 --> UTF-8 Support Enabled
INFO - 2017-02-22 23:45:34 --> Utf8 Class Initialized
INFO - 2017-02-22 23:45:34 --> URI Class Initialized
INFO - 2017-02-22 23:45:34 --> Router Class Initialized
INFO - 2017-02-22 23:45:34 --> Output Class Initialized
INFO - 2017-02-22 23:45:34 --> Security Class Initialized
DEBUG - 2017-02-22 23:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 23:45:34 --> Input Class Initialized
INFO - 2017-02-22 23:45:34 --> Language Class Initialized
INFO - 2017-02-22 23:45:34 --> Loader Class Initialized
INFO - 2017-02-22 23:45:34 --> Database Driver Class Initialized
INFO - 2017-02-22 23:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 23:45:34 --> Controller Class Initialized
INFO - 2017-02-22 23:45:34 --> Helper loaded: date_helper
DEBUG - 2017-02-22 23:45:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 23:45:34 --> Helper loaded: url_helper
INFO - 2017-02-22 23:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 23:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-22 23:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-22 23:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-22 23:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 23:45:34 --> Final output sent to browser
DEBUG - 2017-02-22 23:45:34 --> Total execution time: 0.1596
INFO - 2017-02-22 23:45:37 --> Config Class Initialized
INFO - 2017-02-22 23:45:37 --> Hooks Class Initialized
DEBUG - 2017-02-22 23:45:37 --> UTF-8 Support Enabled
INFO - 2017-02-22 23:45:37 --> Utf8 Class Initialized
INFO - 2017-02-22 23:45:37 --> URI Class Initialized
INFO - 2017-02-22 23:45:37 --> Router Class Initialized
INFO - 2017-02-22 23:45:37 --> Output Class Initialized
INFO - 2017-02-22 23:45:37 --> Security Class Initialized
DEBUG - 2017-02-22 23:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 23:45:37 --> Input Class Initialized
INFO - 2017-02-22 23:45:37 --> Language Class Initialized
INFO - 2017-02-22 23:45:37 --> Loader Class Initialized
INFO - 2017-02-22 23:45:37 --> Database Driver Class Initialized
INFO - 2017-02-22 23:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 23:45:37 --> Controller Class Initialized
INFO - 2017-02-22 23:45:37 --> Helper loaded: url_helper
DEBUG - 2017-02-22 23:45:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 23:45:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 23:45:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 23:45:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 23:45:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 23:45:37 --> Final output sent to browser
DEBUG - 2017-02-22 23:45:37 --> Total execution time: 0.0291
INFO - 2017-02-22 23:45:46 --> Config Class Initialized
INFO - 2017-02-22 23:45:46 --> Hooks Class Initialized
DEBUG - 2017-02-22 23:45:46 --> UTF-8 Support Enabled
INFO - 2017-02-22 23:45:46 --> Utf8 Class Initialized
INFO - 2017-02-22 23:45:46 --> URI Class Initialized
DEBUG - 2017-02-22 23:45:46 --> No URI present. Default controller set.
INFO - 2017-02-22 23:45:46 --> Router Class Initialized
INFO - 2017-02-22 23:45:46 --> Output Class Initialized
INFO - 2017-02-22 23:45:46 --> Security Class Initialized
DEBUG - 2017-02-22 23:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 23:45:46 --> Input Class Initialized
INFO - 2017-02-22 23:45:46 --> Language Class Initialized
INFO - 2017-02-22 23:45:46 --> Loader Class Initialized
INFO - 2017-02-22 23:45:46 --> Database Driver Class Initialized
INFO - 2017-02-22 23:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 23:45:46 --> Controller Class Initialized
INFO - 2017-02-22 23:45:46 --> Helper loaded: url_helper
DEBUG - 2017-02-22 23:45:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 23:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 23:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 23:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 23:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 23:45:46 --> Final output sent to browser
DEBUG - 2017-02-22 23:45:46 --> Total execution time: 0.0149
INFO - 2017-02-22 23:45:50 --> Config Class Initialized
INFO - 2017-02-22 23:45:50 --> Hooks Class Initialized
DEBUG - 2017-02-22 23:45:51 --> UTF-8 Support Enabled
INFO - 2017-02-22 23:45:51 --> Utf8 Class Initialized
INFO - 2017-02-22 23:45:51 --> URI Class Initialized
INFO - 2017-02-22 23:45:51 --> Router Class Initialized
INFO - 2017-02-22 23:45:51 --> Output Class Initialized
INFO - 2017-02-22 23:45:51 --> Security Class Initialized
DEBUG - 2017-02-22 23:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 23:45:51 --> Input Class Initialized
INFO - 2017-02-22 23:45:51 --> Language Class Initialized
INFO - 2017-02-22 23:45:51 --> Loader Class Initialized
INFO - 2017-02-22 23:45:51 --> Database Driver Class Initialized
INFO - 2017-02-22 23:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 23:45:51 --> Controller Class Initialized
INFO - 2017-02-22 23:45:51 --> Helper loaded: url_helper
DEBUG - 2017-02-22 23:45:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 23:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 23:45:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 23:45:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 23:45:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 23:45:52 --> Final output sent to browser
DEBUG - 2017-02-22 23:45:52 --> Total execution time: 1.2508
INFO - 2017-02-22 23:50:29 --> Config Class Initialized
INFO - 2017-02-22 23:50:29 --> Hooks Class Initialized
DEBUG - 2017-02-22 23:50:29 --> UTF-8 Support Enabled
INFO - 2017-02-22 23:50:29 --> Utf8 Class Initialized
INFO - 2017-02-22 23:50:29 --> URI Class Initialized
DEBUG - 2017-02-22 23:50:29 --> No URI present. Default controller set.
INFO - 2017-02-22 23:50:29 --> Router Class Initialized
INFO - 2017-02-22 23:50:29 --> Output Class Initialized
INFO - 2017-02-22 23:50:29 --> Security Class Initialized
DEBUG - 2017-02-22 23:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 23:50:29 --> Input Class Initialized
INFO - 2017-02-22 23:50:29 --> Language Class Initialized
INFO - 2017-02-22 23:50:29 --> Loader Class Initialized
INFO - 2017-02-22 23:50:30 --> Database Driver Class Initialized
INFO - 2017-02-22 23:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 23:50:30 --> Controller Class Initialized
INFO - 2017-02-22 23:50:30 --> Helper loaded: url_helper
DEBUG - 2017-02-22 23:50:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 23:50:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 23:50:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 23:50:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 23:50:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 23:50:31 --> Final output sent to browser
DEBUG - 2017-02-22 23:50:31 --> Total execution time: 1.9788
INFO - 2017-02-22 23:51:51 --> Config Class Initialized
INFO - 2017-02-22 23:51:51 --> Hooks Class Initialized
DEBUG - 2017-02-22 23:51:51 --> UTF-8 Support Enabled
INFO - 2017-02-22 23:51:51 --> Utf8 Class Initialized
INFO - 2017-02-22 23:51:51 --> URI Class Initialized
INFO - 2017-02-22 23:51:51 --> Router Class Initialized
INFO - 2017-02-22 23:51:51 --> Output Class Initialized
INFO - 2017-02-22 23:51:51 --> Security Class Initialized
DEBUG - 2017-02-22 23:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 23:51:51 --> Input Class Initialized
INFO - 2017-02-22 23:51:51 --> Language Class Initialized
INFO - 2017-02-22 23:51:51 --> Loader Class Initialized
INFO - 2017-02-22 23:51:51 --> Database Driver Class Initialized
INFO - 2017-02-22 23:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 23:51:51 --> Controller Class Initialized
INFO - 2017-02-22 23:51:51 --> Helper loaded: url_helper
DEBUG - 2017-02-22 23:51:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 23:51:51 --> Config Class Initialized
INFO - 2017-02-22 23:51:51 --> Hooks Class Initialized
DEBUG - 2017-02-22 23:51:51 --> UTF-8 Support Enabled
INFO - 2017-02-22 23:51:51 --> Utf8 Class Initialized
INFO - 2017-02-22 23:51:51 --> URI Class Initialized
INFO - 2017-02-22 23:51:51 --> Router Class Initialized
INFO - 2017-02-22 23:51:51 --> Output Class Initialized
INFO - 2017-02-22 23:51:51 --> Security Class Initialized
DEBUG - 2017-02-22 23:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 23:51:51 --> Input Class Initialized
INFO - 2017-02-22 23:51:51 --> Language Class Initialized
INFO - 2017-02-22 23:51:51 --> Loader Class Initialized
INFO - 2017-02-22 23:51:51 --> Database Driver Class Initialized
INFO - 2017-02-22 23:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 23:51:51 --> Controller Class Initialized
INFO - 2017-02-22 23:51:51 --> Helper loaded: date_helper
DEBUG - 2017-02-22 23:51:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 23:51:51 --> Helper loaded: url_helper
INFO - 2017-02-22 23:51:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 23:51:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-22 23:51:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-22 23:51:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-22 23:51:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 23:51:51 --> Final output sent to browser
DEBUG - 2017-02-22 23:51:51 --> Total execution time: 0.0980
INFO - 2017-02-22 23:51:52 --> Config Class Initialized
INFO - 2017-02-22 23:51:52 --> Hooks Class Initialized
DEBUG - 2017-02-22 23:51:52 --> UTF-8 Support Enabled
INFO - 2017-02-22 23:51:52 --> Utf8 Class Initialized
INFO - 2017-02-22 23:51:52 --> URI Class Initialized
INFO - 2017-02-22 23:51:52 --> Router Class Initialized
INFO - 2017-02-22 23:51:52 --> Output Class Initialized
INFO - 2017-02-22 23:51:52 --> Security Class Initialized
DEBUG - 2017-02-22 23:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 23:51:52 --> Input Class Initialized
INFO - 2017-02-22 23:51:52 --> Language Class Initialized
INFO - 2017-02-22 23:51:52 --> Loader Class Initialized
INFO - 2017-02-22 23:51:52 --> Database Driver Class Initialized
INFO - 2017-02-22 23:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 23:51:52 --> Controller Class Initialized
INFO - 2017-02-22 23:51:52 --> Helper loaded: url_helper
DEBUG - 2017-02-22 23:51:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 23:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 23:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 23:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 23:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 23:51:52 --> Final output sent to browser
DEBUG - 2017-02-22 23:51:52 --> Total execution time: 0.0154
INFO - 2017-02-22 23:51:52 --> Config Class Initialized
INFO - 2017-02-22 23:51:52 --> Hooks Class Initialized
DEBUG - 2017-02-22 23:51:52 --> UTF-8 Support Enabled
INFO - 2017-02-22 23:51:52 --> Utf8 Class Initialized
INFO - 2017-02-22 23:51:52 --> URI Class Initialized
INFO - 2017-02-22 23:51:52 --> Router Class Initialized
INFO - 2017-02-22 23:51:52 --> Output Class Initialized
INFO - 2017-02-22 23:51:52 --> Security Class Initialized
DEBUG - 2017-02-22 23:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 23:51:52 --> Input Class Initialized
INFO - 2017-02-22 23:51:52 --> Language Class Initialized
INFO - 2017-02-22 23:51:52 --> Loader Class Initialized
INFO - 2017-02-22 23:51:52 --> Database Driver Class Initialized
INFO - 2017-02-22 23:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 23:51:52 --> Controller Class Initialized
INFO - 2017-02-22 23:51:52 --> Helper loaded: url_helper
DEBUG - 2017-02-22 23:51:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 23:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 23:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 23:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 23:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 23:51:52 --> Final output sent to browser
DEBUG - 2017-02-22 23:51:52 --> Total execution time: 0.0160
INFO - 2017-02-22 23:53:02 --> Config Class Initialized
INFO - 2017-02-22 23:53:02 --> Hooks Class Initialized
DEBUG - 2017-02-22 23:53:02 --> UTF-8 Support Enabled
INFO - 2017-02-22 23:53:02 --> Utf8 Class Initialized
INFO - 2017-02-22 23:53:02 --> URI Class Initialized
DEBUG - 2017-02-22 23:53:02 --> No URI present. Default controller set.
INFO - 2017-02-22 23:53:02 --> Router Class Initialized
INFO - 2017-02-22 23:53:02 --> Output Class Initialized
INFO - 2017-02-22 23:53:02 --> Security Class Initialized
DEBUG - 2017-02-22 23:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 23:53:02 --> Input Class Initialized
INFO - 2017-02-22 23:53:02 --> Language Class Initialized
INFO - 2017-02-22 23:53:02 --> Loader Class Initialized
INFO - 2017-02-22 23:53:03 --> Database Driver Class Initialized
INFO - 2017-02-22 23:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 23:53:03 --> Controller Class Initialized
INFO - 2017-02-22 23:53:03 --> Helper loaded: url_helper
DEBUG - 2017-02-22 23:53:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 23:53:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 23:53:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-22 23:53:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-22 23:53:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 23:53:03 --> Final output sent to browser
DEBUG - 2017-02-22 23:53:03 --> Total execution time: 1.7209
INFO - 2017-02-22 23:53:49 --> Config Class Initialized
INFO - 2017-02-22 23:53:49 --> Hooks Class Initialized
DEBUG - 2017-02-22 23:53:50 --> UTF-8 Support Enabled
INFO - 2017-02-22 23:53:50 --> Utf8 Class Initialized
INFO - 2017-02-22 23:53:50 --> URI Class Initialized
INFO - 2017-02-22 23:53:50 --> Router Class Initialized
INFO - 2017-02-22 23:53:50 --> Output Class Initialized
INFO - 2017-02-22 23:53:50 --> Security Class Initialized
DEBUG - 2017-02-22 23:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 23:53:50 --> Input Class Initialized
INFO - 2017-02-22 23:53:50 --> Language Class Initialized
INFO - 2017-02-22 23:53:50 --> Loader Class Initialized
INFO - 2017-02-22 23:53:50 --> Database Driver Class Initialized
INFO - 2017-02-22 23:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 23:53:51 --> Controller Class Initialized
INFO - 2017-02-22 23:53:51 --> Helper loaded: url_helper
DEBUG - 2017-02-22 23:53:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 23:53:51 --> Config Class Initialized
INFO - 2017-02-22 23:53:51 --> Hooks Class Initialized
DEBUG - 2017-02-22 23:53:51 --> UTF-8 Support Enabled
INFO - 2017-02-22 23:53:51 --> Utf8 Class Initialized
INFO - 2017-02-22 23:53:51 --> URI Class Initialized
INFO - 2017-02-22 23:53:51 --> Router Class Initialized
INFO - 2017-02-22 23:53:51 --> Output Class Initialized
INFO - 2017-02-22 23:53:51 --> Security Class Initialized
DEBUG - 2017-02-22 23:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 23:53:51 --> Input Class Initialized
INFO - 2017-02-22 23:53:51 --> Language Class Initialized
INFO - 2017-02-22 23:53:51 --> Loader Class Initialized
INFO - 2017-02-22 23:53:51 --> Database Driver Class Initialized
INFO - 2017-02-22 23:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 23:53:51 --> Controller Class Initialized
INFO - 2017-02-22 23:53:51 --> Helper loaded: date_helper
DEBUG - 2017-02-22 23:53:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-22 23:53:51 --> Helper loaded: url_helper
INFO - 2017-02-22 23:53:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-22 23:53:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-22 23:53:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-22 23:53:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-22 23:53:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-22 23:53:52 --> Final output sent to browser
DEBUG - 2017-02-22 23:53:52 --> Total execution time: 0.1458

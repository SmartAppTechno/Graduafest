<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-12 00:24:06 --> Config Class Initialized
INFO - 2017-03-12 00:24:06 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:24:06 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:24:06 --> Utf8 Class Initialized
INFO - 2017-03-12 00:24:06 --> URI Class Initialized
DEBUG - 2017-03-12 00:24:06 --> No URI present. Default controller set.
INFO - 2017-03-12 00:24:06 --> Router Class Initialized
INFO - 2017-03-12 00:24:06 --> Output Class Initialized
INFO - 2017-03-12 00:24:06 --> Security Class Initialized
DEBUG - 2017-03-12 00:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:24:06 --> Input Class Initialized
INFO - 2017-03-12 00:24:06 --> Language Class Initialized
INFO - 2017-03-12 00:24:06 --> Loader Class Initialized
INFO - 2017-03-12 00:24:07 --> Database Driver Class Initialized
INFO - 2017-03-12 00:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:24:07 --> Controller Class Initialized
INFO - 2017-03-12 00:24:07 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:24:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:24:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:24:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:24:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:24:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:24:07 --> Final output sent to browser
DEBUG - 2017-03-12 00:24:07 --> Total execution time: 2.0592
INFO - 2017-03-12 00:24:20 --> Config Class Initialized
INFO - 2017-03-12 00:24:20 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:24:21 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:24:21 --> Utf8 Class Initialized
INFO - 2017-03-12 00:24:21 --> URI Class Initialized
INFO - 2017-03-12 00:24:21 --> Router Class Initialized
INFO - 2017-03-12 00:24:21 --> Output Class Initialized
INFO - 2017-03-12 00:24:21 --> Security Class Initialized
DEBUG - 2017-03-12 00:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:24:21 --> Input Class Initialized
INFO - 2017-03-12 00:24:21 --> Language Class Initialized
INFO - 2017-03-12 00:24:21 --> Loader Class Initialized
INFO - 2017-03-12 00:24:21 --> Database Driver Class Initialized
INFO - 2017-03-12 00:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:24:22 --> Controller Class Initialized
INFO - 2017-03-12 00:24:22 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:24:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:24:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:24:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:24:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:24:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:24:22 --> Final output sent to browser
DEBUG - 2017-03-12 00:24:22 --> Total execution time: 1.5570
INFO - 2017-03-12 00:24:29 --> Config Class Initialized
INFO - 2017-03-12 00:24:29 --> Hooks Class Initialized
INFO - 2017-03-12 00:24:29 --> Config Class Initialized
INFO - 2017-03-12 00:24:30 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:24:30 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:24:30 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:24:30 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:24:30 --> Utf8 Class Initialized
INFO - 2017-03-12 00:24:30 --> URI Class Initialized
INFO - 2017-03-12 00:24:30 --> URI Class Initialized
INFO - 2017-03-12 00:24:30 --> Router Class Initialized
INFO - 2017-03-12 00:24:30 --> Router Class Initialized
INFO - 2017-03-12 00:24:30 --> Output Class Initialized
INFO - 2017-03-12 00:24:30 --> Output Class Initialized
INFO - 2017-03-12 00:24:30 --> Security Class Initialized
INFO - 2017-03-12 00:24:30 --> Security Class Initialized
DEBUG - 2017-03-12 00:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:24:30 --> Input Class Initialized
DEBUG - 2017-03-12 00:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:24:30 --> Input Class Initialized
INFO - 2017-03-12 00:24:30 --> Language Class Initialized
INFO - 2017-03-12 00:24:30 --> Language Class Initialized
INFO - 2017-03-12 00:24:30 --> Loader Class Initialized
INFO - 2017-03-12 00:24:30 --> Loader Class Initialized
INFO - 2017-03-12 00:24:30 --> Database Driver Class Initialized
INFO - 2017-03-12 00:24:30 --> Database Driver Class Initialized
INFO - 2017-03-12 00:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:24:30 --> Controller Class Initialized
INFO - 2017-03-12 00:24:30 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:24:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:24:49 --> Controller Class Initialized
INFO - 2017-03-12 00:24:49 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:24:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:24:54 --> Config Class Initialized
INFO - 2017-03-12 00:24:54 --> Config Class Initialized
INFO - 2017-03-12 00:24:54 --> Hooks Class Initialized
INFO - 2017-03-12 00:24:54 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:24:56 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:24:56 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:24:56 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:24:56 --> Utf8 Class Initialized
INFO - 2017-03-12 00:24:56 --> URI Class Initialized
INFO - 2017-03-12 00:24:56 --> URI Class Initialized
INFO - 2017-03-12 00:24:57 --> Router Class Initialized
DEBUG - 2017-03-12 00:24:57 --> No URI present. Default controller set.
INFO - 2017-03-12 00:24:57 --> Router Class Initialized
INFO - 2017-03-12 00:24:57 --> Output Class Initialized
INFO - 2017-03-12 00:24:57 --> Output Class Initialized
INFO - 2017-03-12 00:24:57 --> Security Class Initialized
INFO - 2017-03-12 00:24:57 --> Security Class Initialized
DEBUG - 2017-03-12 00:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-03-12 00:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:24:57 --> Input Class Initialized
INFO - 2017-03-12 00:24:57 --> Input Class Initialized
INFO - 2017-03-12 00:24:57 --> Language Class Initialized
INFO - 2017-03-12 00:24:57 --> Language Class Initialized
INFO - 2017-03-12 00:24:58 --> Loader Class Initialized
INFO - 2017-03-12 00:24:58 --> Loader Class Initialized
INFO - 2017-03-12 00:24:58 --> Database Driver Class Initialized
INFO - 2017-03-12 00:24:58 --> Database Driver Class Initialized
INFO - 2017-03-12 00:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:24:59 --> Controller Class Initialized
INFO - 2017-03-12 00:24:59 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:24:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:24:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:24:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:25:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:25:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:25:00 --> Final output sent to browser
DEBUG - 2017-03-12 00:25:00 --> Total execution time: 11.6099
INFO - 2017-03-12 00:25:01 --> Config Class Initialized
INFO - 2017-03-12 00:25:01 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:25:01 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:25:01 --> Utf8 Class Initialized
INFO - 2017-03-12 00:25:01 --> URI Class Initialized
DEBUG - 2017-03-12 00:25:01 --> No URI present. Default controller set.
INFO - 2017-03-12 00:25:02 --> Router Class Initialized
INFO - 2017-03-12 00:25:02 --> Output Class Initialized
INFO - 2017-03-12 00:25:02 --> Security Class Initialized
DEBUG - 2017-03-12 00:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:25:02 --> Input Class Initialized
INFO - 2017-03-12 00:25:03 --> Language Class Initialized
INFO - 2017-03-12 00:25:03 --> Loader Class Initialized
INFO - 2017-03-12 00:25:05 --> Database Driver Class Initialized
INFO - 2017-03-12 00:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:25:07 --> Controller Class Initialized
INFO - 2017-03-12 00:25:07 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:25:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:25:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:25:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:25:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:25:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:25:08 --> Final output sent to browser
DEBUG - 2017-03-12 00:25:08 --> Total execution time: 7.4100
ERROR - 2017-03-12 00:25:10 --> Severity: error --> Exception: timed out before SSL handshake /home/graduafe/public_html/application/libraries/facebook-api-php-codexworld/base_facebook.php 972
INFO - 2017-03-12 00:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:25:11 --> Controller Class Initialized
INFO - 2017-03-12 00:25:11 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:25:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:25:18 --> Config Class Initialized
INFO - 2017-03-12 00:25:18 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:25:18 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:25:18 --> Utf8 Class Initialized
INFO - 2017-03-12 00:25:18 --> URI Class Initialized
INFO - 2017-03-12 00:25:18 --> Router Class Initialized
INFO - 2017-03-12 00:25:18 --> Output Class Initialized
INFO - 2017-03-12 00:25:18 --> Security Class Initialized
DEBUG - 2017-03-12 00:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:25:18 --> Input Class Initialized
INFO - 2017-03-12 00:25:18 --> Language Class Initialized
INFO - 2017-03-12 00:25:18 --> Loader Class Initialized
INFO - 2017-03-12 00:25:19 --> Database Driver Class Initialized
INFO - 2017-03-12 00:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:25:19 --> Controller Class Initialized
INFO - 2017-03-12 00:25:19 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:25:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:25:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:25:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:25:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:25:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:25:20 --> Final output sent to browser
DEBUG - 2017-03-12 00:25:20 --> Total execution time: 2.4055
INFO - 2017-03-12 00:25:23 --> Config Class Initialized
INFO - 2017-03-12 00:25:23 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:25:23 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:25:23 --> Utf8 Class Initialized
INFO - 2017-03-12 00:25:23 --> URI Class Initialized
INFO - 2017-03-12 00:25:23 --> Router Class Initialized
INFO - 2017-03-12 00:25:23 --> Output Class Initialized
INFO - 2017-03-12 00:25:23 --> Security Class Initialized
INFO - 2017-03-12 00:25:23 --> Config Class Initialized
INFO - 2017-03-12 00:25:23 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:25:23 --> Input Class Initialized
DEBUG - 2017-03-12 00:25:23 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:25:23 --> Language Class Initialized
INFO - 2017-03-12 00:25:23 --> Utf8 Class Initialized
INFO - 2017-03-12 00:25:23 --> URI Class Initialized
INFO - 2017-03-12 00:25:23 --> Router Class Initialized
INFO - 2017-03-12 00:25:23 --> Config Class Initialized
INFO - 2017-03-12 00:25:23 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:25:23 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:25:23 --> Utf8 Class Initialized
INFO - 2017-03-12 00:25:23 --> URI Class Initialized
INFO - 2017-03-12 00:25:23 --> Router Class Initialized
INFO - 2017-03-12 00:25:23 --> Output Class Initialized
INFO - 2017-03-12 00:25:23 --> Security Class Initialized
DEBUG - 2017-03-12 00:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:25:23 --> Input Class Initialized
INFO - 2017-03-12 00:25:23 --> Language Class Initialized
INFO - 2017-03-12 00:25:23 --> Loader Class Initialized
INFO - 2017-03-12 00:25:23 --> Loader Class Initialized
INFO - 2017-03-12 00:25:23 --> Output Class Initialized
INFO - 2017-03-12 00:25:23 --> Security Class Initialized
DEBUG - 2017-03-12 00:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:25:23 --> Input Class Initialized
INFO - 2017-03-12 00:25:23 --> Language Class Initialized
INFO - 2017-03-12 00:25:23 --> Loader Class Initialized
INFO - 2017-03-12 00:25:23 --> Config Class Initialized
INFO - 2017-03-12 00:25:23 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:25:23 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:25:23 --> Utf8 Class Initialized
INFO - 2017-03-12 00:25:23 --> URI Class Initialized
INFO - 2017-03-12 00:25:23 --> Router Class Initialized
INFO - 2017-03-12 00:25:23 --> Database Driver Class Initialized
INFO - 2017-03-12 00:25:23 --> Database Driver Class Initialized
INFO - 2017-03-12 00:25:23 --> Output Class Initialized
INFO - 2017-03-12 00:25:23 --> Security Class Initialized
DEBUG - 2017-03-12 00:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:25:23 --> Input Class Initialized
INFO - 2017-03-12 00:25:23 --> Language Class Initialized
INFO - 2017-03-12 00:25:23 --> Loader Class Initialized
INFO - 2017-03-12 00:25:23 --> Database Driver Class Initialized
INFO - 2017-03-12 00:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:25:23 --> Controller Class Initialized
INFO - 2017-03-12 00:25:23 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:25:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:25:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:25:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:25:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:25:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:25:23 --> Controller Class Initialized
INFO - 2017-03-12 00:25:23 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:25:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:25:23 --> Final output sent to browser
DEBUG - 2017-03-12 00:25:24 --> Total execution time: 0.1173
INFO - 2017-03-12 00:25:24 --> Database Driver Class Initialized
INFO - 2017-03-12 00:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:25:24 --> Controller Class Initialized
INFO - 2017-03-12 00:25:24 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:25:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:25:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 00:25:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:25:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:25:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:25:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:25:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:25:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:25:25 --> Final output sent to browser
DEBUG - 2017-03-12 00:25:25 --> Total execution time: 1.3568
INFO - 2017-03-12 00:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:25:28 --> Controller Class Initialized
INFO - 2017-03-12 00:25:28 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:25:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:25:29 --> Helper loaded: url_helper
INFO - 2017-03-12 00:25:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:25:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:25:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-12 00:25:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 00:25:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:25:32 --> Final output sent to browser
DEBUG - 2017-03-12 00:25:32 --> Total execution time: 8.9849
INFO - 2017-03-12 00:25:38 --> Config Class Initialized
INFO - 2017-03-12 00:25:38 --> Hooks Class Initialized
INFO - 2017-03-12 00:25:38 --> Config Class Initialized
INFO - 2017-03-12 00:25:38 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:25:38 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:25:38 --> Utf8 Class Initialized
INFO - 2017-03-12 00:25:38 --> URI Class Initialized
DEBUG - 2017-03-12 00:25:38 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:25:38 --> Utf8 Class Initialized
INFO - 2017-03-12 00:25:38 --> Router Class Initialized
INFO - 2017-03-12 00:25:38 --> Config Class Initialized
INFO - 2017-03-12 00:25:38 --> Hooks Class Initialized
INFO - 2017-03-12 00:25:38 --> Output Class Initialized
INFO - 2017-03-12 00:25:38 --> URI Class Initialized
INFO - 2017-03-12 00:25:38 --> Security Class Initialized
DEBUG - 2017-03-12 00:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:25:38 --> Input Class Initialized
DEBUG - 2017-03-12 00:25:38 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:25:38 --> Utf8 Class Initialized
INFO - 2017-03-12 00:25:38 --> URI Class Initialized
INFO - 2017-03-12 00:25:38 --> Router Class Initialized
INFO - 2017-03-12 00:25:38 --> Output Class Initialized
INFO - 2017-03-12 00:25:38 --> Security Class Initialized
INFO - 2017-03-12 00:25:38 --> Language Class Initialized
INFO - 2017-03-12 00:25:38 --> Router Class Initialized
INFO - 2017-03-12 00:25:38 --> Output Class Initialized
INFO - 2017-03-12 00:25:38 --> Security Class Initialized
DEBUG - 2017-03-12 00:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:25:38 --> Input Class Initialized
INFO - 2017-03-12 00:25:38 --> Language Class Initialized
DEBUG - 2017-03-12 00:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:25:38 --> Input Class Initialized
INFO - 2017-03-12 00:25:38 --> Language Class Initialized
INFO - 2017-03-12 00:25:38 --> Loader Class Initialized
INFO - 2017-03-12 00:25:38 --> Loader Class Initialized
INFO - 2017-03-12 00:25:38 --> Loader Class Initialized
INFO - 2017-03-12 00:25:38 --> Config Class Initialized
INFO - 2017-03-12 00:25:38 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:25:38 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:25:38 --> Utf8 Class Initialized
INFO - 2017-03-12 00:25:38 --> URI Class Initialized
INFO - 2017-03-12 00:25:38 --> Router Class Initialized
INFO - 2017-03-12 00:25:38 --> Output Class Initialized
INFO - 2017-03-12 00:25:38 --> Security Class Initialized
DEBUG - 2017-03-12 00:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:25:38 --> Input Class Initialized
INFO - 2017-03-12 00:25:38 --> Language Class Initialized
INFO - 2017-03-12 00:25:38 --> Loader Class Initialized
INFO - 2017-03-12 00:25:39 --> Database Driver Class Initialized
INFO - 2017-03-12 00:25:39 --> Database Driver Class Initialized
INFO - 2017-03-12 00:25:39 --> Database Driver Class Initialized
INFO - 2017-03-12 00:25:39 --> Database Driver Class Initialized
INFO - 2017-03-12 00:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:25:39 --> Controller Class Initialized
INFO - 2017-03-12 00:25:39 --> Controller Class Initialized
INFO - 2017-03-12 00:25:39 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:25:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:25:39 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:25:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:25:39 --> Helper loaded: url_helper
INFO - 2017-03-12 00:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-12 00:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 00:25:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:25:39 --> Final output sent to browser
DEBUG - 2017-03-12 00:25:39 --> Total execution time: 1.8990
INFO - 2017-03-12 00:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:25:39 --> Controller Class Initialized
INFO - 2017-03-12 00:25:39 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:25:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:25:39 --> Final output sent to browser
DEBUG - 2017-03-12 00:25:40 --> Total execution time: 1.8952
INFO - 2017-03-12 00:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:25:40 --> Controller Class Initialized
INFO - 2017-03-12 00:25:40 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:25:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:25:40 --> Final output sent to browser
DEBUG - 2017-03-12 00:25:40 --> Total execution time: 2.3805
INFO - 2017-03-12 00:25:50 --> Config Class Initialized
INFO - 2017-03-12 00:25:50 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:25:50 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:25:50 --> Utf8 Class Initialized
INFO - 2017-03-12 00:25:50 --> URI Class Initialized
INFO - 2017-03-12 00:25:50 --> Router Class Initialized
INFO - 2017-03-12 00:25:50 --> Output Class Initialized
INFO - 2017-03-12 00:25:50 --> Security Class Initialized
DEBUG - 2017-03-12 00:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:25:51 --> Input Class Initialized
INFO - 2017-03-12 00:25:51 --> Language Class Initialized
INFO - 2017-03-12 00:25:51 --> Loader Class Initialized
INFO - 2017-03-12 00:25:51 --> Database Driver Class Initialized
INFO - 2017-03-12 00:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:25:51 --> Controller Class Initialized
INFO - 2017-03-12 00:25:51 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:25:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:25:51 --> Helper loaded: url_helper
INFO - 2017-03-12 00:25:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:25:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:25:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-12 00:25:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 00:25:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:25:51 --> Final output sent to browser
DEBUG - 2017-03-12 00:25:51 --> Total execution time: 1.1427
INFO - 2017-03-12 00:26:06 --> Config Class Initialized
INFO - 2017-03-12 00:26:06 --> Config Class Initialized
INFO - 2017-03-12 00:26:06 --> Hooks Class Initialized
INFO - 2017-03-12 00:26:06 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:26:06 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:26:06 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:26:06 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:26:06 --> URI Class Initialized
INFO - 2017-03-12 00:26:06 --> Utf8 Class Initialized
INFO - 2017-03-12 00:26:06 --> URI Class Initialized
DEBUG - 2017-03-12 00:26:06 --> No URI present. Default controller set.
DEBUG - 2017-03-12 00:26:06 --> No URI present. Default controller set.
INFO - 2017-03-12 00:26:06 --> Router Class Initialized
INFO - 2017-03-12 00:26:06 --> Router Class Initialized
INFO - 2017-03-12 00:26:06 --> Output Class Initialized
INFO - 2017-03-12 00:26:06 --> Output Class Initialized
INFO - 2017-03-12 00:26:06 --> Security Class Initialized
INFO - 2017-03-12 00:26:06 --> Security Class Initialized
DEBUG - 2017-03-12 00:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:26:06 --> Input Class Initialized
INFO - 2017-03-12 00:26:06 --> Language Class Initialized
DEBUG - 2017-03-12 00:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:26:06 --> Input Class Initialized
INFO - 2017-03-12 00:26:06 --> Language Class Initialized
INFO - 2017-03-12 00:26:06 --> Loader Class Initialized
INFO - 2017-03-12 00:26:07 --> Loader Class Initialized
INFO - 2017-03-12 00:26:07 --> Database Driver Class Initialized
INFO - 2017-03-12 00:26:07 --> Database Driver Class Initialized
INFO - 2017-03-12 00:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:26:07 --> Controller Class Initialized
INFO - 2017-03-12 00:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:26:07 --> Controller Class Initialized
INFO - 2017-03-12 00:26:07 --> Helper loaded: url_helper
INFO - 2017-03-12 00:26:07 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:26:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:26:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:26:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:26:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:26:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:26:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:26:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:26:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:26:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:26:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:26:08 --> Final output sent to browser
DEBUG - 2017-03-12 00:26:08 --> Total execution time: 1.8679
INFO - 2017-03-12 00:26:08 --> Final output sent to browser
DEBUG - 2017-03-12 00:26:08 --> Total execution time: 1.8676
INFO - 2017-03-12 00:26:13 --> Config Class Initialized
INFO - 2017-03-12 00:26:13 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:26:13 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:26:13 --> Utf8 Class Initialized
INFO - 2017-03-12 00:26:13 --> URI Class Initialized
INFO - 2017-03-12 00:26:13 --> Config Class Initialized
INFO - 2017-03-12 00:26:13 --> Router Class Initialized
INFO - 2017-03-12 00:26:13 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:26:13 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:26:13 --> Utf8 Class Initialized
INFO - 2017-03-12 00:26:13 --> Output Class Initialized
INFO - 2017-03-12 00:26:13 --> URI Class Initialized
INFO - 2017-03-12 00:26:13 --> Security Class Initialized
INFO - 2017-03-12 00:26:13 --> Router Class Initialized
DEBUG - 2017-03-12 00:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:26:13 --> Input Class Initialized
INFO - 2017-03-12 00:26:13 --> Language Class Initialized
INFO - 2017-03-12 00:26:13 --> Output Class Initialized
INFO - 2017-03-12 00:26:13 --> Security Class Initialized
DEBUG - 2017-03-12 00:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:26:13 --> Input Class Initialized
INFO - 2017-03-12 00:26:13 --> Language Class Initialized
INFO - 2017-03-12 00:26:13 --> Loader Class Initialized
INFO - 2017-03-12 00:26:13 --> Loader Class Initialized
INFO - 2017-03-12 00:26:13 --> Database Driver Class Initialized
INFO - 2017-03-12 00:26:13 --> Database Driver Class Initialized
INFO - 2017-03-12 00:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:26:13 --> Controller Class Initialized
INFO - 2017-03-12 00:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:26:13 --> Controller Class Initialized
INFO - 2017-03-12 00:26:13 --> Helper loaded: url_helper
INFO - 2017-03-12 00:26:13 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:26:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:26:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:26:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:26:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:26:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:26:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:26:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:26:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:26:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:26:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:26:14 --> Final output sent to browser
DEBUG - 2017-03-12 00:26:14 --> Total execution time: 1.2428
INFO - 2017-03-12 00:26:14 --> Final output sent to browser
DEBUG - 2017-03-12 00:26:14 --> Total execution time: 1.2429
INFO - 2017-03-12 00:26:31 --> Config Class Initialized
INFO - 2017-03-12 00:26:31 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:26:32 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:26:32 --> Utf8 Class Initialized
INFO - 2017-03-12 00:26:32 --> URI Class Initialized
INFO - 2017-03-12 00:26:32 --> Router Class Initialized
INFO - 2017-03-12 00:26:32 --> Output Class Initialized
INFO - 2017-03-12 00:26:32 --> Security Class Initialized
DEBUG - 2017-03-12 00:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:26:32 --> Input Class Initialized
INFO - 2017-03-12 00:26:32 --> Language Class Initialized
INFO - 2017-03-12 00:26:32 --> Loader Class Initialized
INFO - 2017-03-12 00:26:33 --> Database Driver Class Initialized
INFO - 2017-03-12 00:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:26:33 --> Controller Class Initialized
INFO - 2017-03-12 00:26:33 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:26:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:26:39 --> Config Class Initialized
INFO - 2017-03-12 00:26:40 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:26:40 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:26:41 --> Utf8 Class Initialized
INFO - 2017-03-12 00:26:41 --> URI Class Initialized
INFO - 2017-03-12 00:26:42 --> Router Class Initialized
INFO - 2017-03-12 00:26:42 --> Output Class Initialized
INFO - 2017-03-12 00:26:42 --> Security Class Initialized
DEBUG - 2017-03-12 00:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:26:42 --> Input Class Initialized
INFO - 2017-03-12 00:26:43 --> Language Class Initialized
INFO - 2017-03-12 00:26:43 --> Loader Class Initialized
INFO - 2017-03-12 00:26:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 00:26:43 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:26:44 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
INFO - 2017-03-12 00:26:44 --> Database Driver Class Initialized
ERROR - 2017-03-12 00:26:44 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:26:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:26:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:26:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:26:44 --> Final output sent to browser
DEBUG - 2017-03-12 00:26:44 --> Total execution time: 12.7689
INFO - 2017-03-12 00:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:26:44 --> Controller Class Initialized
INFO - 2017-03-12 00:26:44 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:26:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:26:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 00:26:45 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:26:45 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:26:45 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:26:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:26:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:26:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:26:45 --> Final output sent to browser
DEBUG - 2017-03-12 00:26:45 --> Total execution time: 12.5889
INFO - 2017-03-12 00:27:01 --> Config Class Initialized
INFO - 2017-03-12 00:27:01 --> Hooks Class Initialized
INFO - 2017-03-12 00:27:01 --> Config Class Initialized
INFO - 2017-03-12 00:27:01 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:27:02 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:27:02 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:27:02 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:27:02 --> Utf8 Class Initialized
INFO - 2017-03-12 00:27:02 --> URI Class Initialized
INFO - 2017-03-12 00:27:02 --> URI Class Initialized
INFO - 2017-03-12 00:27:02 --> Router Class Initialized
INFO - 2017-03-12 00:27:02 --> Router Class Initialized
INFO - 2017-03-12 00:27:02 --> Output Class Initialized
INFO - 2017-03-12 00:27:02 --> Output Class Initialized
INFO - 2017-03-12 00:27:02 --> Security Class Initialized
INFO - 2017-03-12 00:27:02 --> Security Class Initialized
DEBUG - 2017-03-12 00:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:27:02 --> Input Class Initialized
INFO - 2017-03-12 00:27:02 --> Language Class Initialized
DEBUG - 2017-03-12 00:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:27:02 --> Input Class Initialized
INFO - 2017-03-12 00:27:02 --> Language Class Initialized
INFO - 2017-03-12 00:27:02 --> Loader Class Initialized
INFO - 2017-03-12 00:27:02 --> Loader Class Initialized
INFO - 2017-03-12 00:27:02 --> Database Driver Class Initialized
INFO - 2017-03-12 00:27:02 --> Database Driver Class Initialized
INFO - 2017-03-12 00:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:27:02 --> Controller Class Initialized
INFO - 2017-03-12 00:27:02 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:27:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:27:02 --> Config Class Initialized
INFO - 2017-03-12 00:27:02 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:27:02 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:27:02 --> Utf8 Class Initialized
INFO - 2017-03-12 00:27:02 --> URI Class Initialized
INFO - 2017-03-12 00:27:02 --> Router Class Initialized
INFO - 2017-03-12 00:27:02 --> Output Class Initialized
INFO - 2017-03-12 00:27:02 --> Security Class Initialized
DEBUG - 2017-03-12 00:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:27:02 --> Input Class Initialized
INFO - 2017-03-12 00:27:02 --> Language Class Initialized
INFO - 2017-03-12 00:27:03 --> Loader Class Initialized
INFO - 2017-03-12 00:27:03 --> Database Driver Class Initialized
INFO - 2017-03-12 00:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:27:03 --> Controller Class Initialized
INFO - 2017-03-12 00:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:27:03 --> Helper loaded: date_helper
INFO - 2017-03-12 00:27:03 --> Final output sent to browser
DEBUG - 2017-03-12 00:27:03 --> Total execution time: 1.4803
INFO - 2017-03-12 00:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:27:03 --> Controller Class Initialized
INFO - 2017-03-12 00:27:03 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
DEBUG - 2017-03-12 00:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:27:03 --> Final output sent to browser
DEBUG - 2017-03-12 00:27:03 --> Total execution time: 1.5303
INFO - 2017-03-12 00:27:03 --> Helper loaded: url_helper
INFO - 2017-03-12 00:27:03 --> Helper loaded: download_helper
INFO - 2017-03-12 00:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-12 00:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-12 00:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:27:03 --> Final output sent to browser
DEBUG - 2017-03-12 00:27:03 --> Total execution time: 1.3142
INFO - 2017-03-12 00:27:16 --> Config Class Initialized
INFO - 2017-03-12 00:27:16 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:27:16 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:27:16 --> Utf8 Class Initialized
INFO - 2017-03-12 00:27:16 --> URI Class Initialized
INFO - 2017-03-12 00:27:16 --> Router Class Initialized
INFO - 2017-03-12 00:27:16 --> Output Class Initialized
INFO - 2017-03-12 00:27:16 --> Security Class Initialized
DEBUG - 2017-03-12 00:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:27:16 --> Input Class Initialized
INFO - 2017-03-12 00:27:16 --> Language Class Initialized
INFO - 2017-03-12 00:27:17 --> Loader Class Initialized
INFO - 2017-03-12 00:27:17 --> Database Driver Class Initialized
INFO - 2017-03-12 00:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:27:17 --> Controller Class Initialized
INFO - 2017-03-12 00:27:17 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:27:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:27:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:27:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:27:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:27:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:27:17 --> Final output sent to browser
DEBUG - 2017-03-12 00:27:17 --> Total execution time: 1.8926
INFO - 2017-03-12 00:27:30 --> Config Class Initialized
INFO - 2017-03-12 00:27:30 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:27:31 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:27:32 --> Utf8 Class Initialized
INFO - 2017-03-12 00:27:32 --> URI Class Initialized
INFO - 2017-03-12 00:27:33 --> Router Class Initialized
INFO - 2017-03-12 00:27:33 --> Output Class Initialized
INFO - 2017-03-12 00:27:34 --> Security Class Initialized
DEBUG - 2017-03-12 00:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:27:34 --> Input Class Initialized
INFO - 2017-03-12 00:27:34 --> Language Class Initialized
INFO - 2017-03-12 00:27:34 --> Loader Class Initialized
INFO - 2017-03-12 00:27:35 --> Database Driver Class Initialized
INFO - 2017-03-12 00:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:27:35 --> Controller Class Initialized
INFO - 2017-03-12 00:27:35 --> Helper loaded: date_helper
INFO - 2017-03-12 00:27:36 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:27:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:27:36 --> Helper loaded: form_helper
INFO - 2017-03-12 00:27:36 --> Form Validation Class Initialized
INFO - 2017-03-12 00:27:36 --> Final output sent to browser
DEBUG - 2017-03-12 00:27:36 --> Total execution time: 6.3987
INFO - 2017-03-12 00:27:41 --> Config Class Initialized
INFO - 2017-03-12 00:27:41 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:27:41 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:27:41 --> Utf8 Class Initialized
INFO - 2017-03-12 00:27:41 --> URI Class Initialized
INFO - 2017-03-12 00:27:41 --> Router Class Initialized
INFO - 2017-03-12 00:27:41 --> Output Class Initialized
INFO - 2017-03-12 00:27:41 --> Security Class Initialized
DEBUG - 2017-03-12 00:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:27:41 --> Input Class Initialized
INFO - 2017-03-12 00:27:41 --> Language Class Initialized
INFO - 2017-03-12 00:27:41 --> Loader Class Initialized
INFO - 2017-03-12 00:27:41 --> Database Driver Class Initialized
INFO - 2017-03-12 00:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:27:41 --> Controller Class Initialized
INFO - 2017-03-12 00:27:42 --> Helper loaded: date_helper
INFO - 2017-03-12 00:27:42 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:27:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:27:42 --> Helper loaded: form_helper
INFO - 2017-03-12 00:27:42 --> Form Validation Class Initialized
INFO - 2017-03-12 00:27:42 --> Final output sent to browser
DEBUG - 2017-03-12 00:27:42 --> Total execution time: 1.2845
INFO - 2017-03-12 00:28:03 --> Config Class Initialized
INFO - 2017-03-12 00:28:03 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:28:03 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:28:03 --> Utf8 Class Initialized
INFO - 2017-03-12 00:28:03 --> URI Class Initialized
INFO - 2017-03-12 00:28:03 --> Router Class Initialized
INFO - 2017-03-12 00:28:03 --> Output Class Initialized
INFO - 2017-03-12 00:28:03 --> Security Class Initialized
DEBUG - 2017-03-12 00:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:28:03 --> Input Class Initialized
INFO - 2017-03-12 00:28:03 --> Language Class Initialized
INFO - 2017-03-12 00:28:03 --> Loader Class Initialized
INFO - 2017-03-12 00:28:04 --> Database Driver Class Initialized
INFO - 2017-03-12 00:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:28:05 --> Controller Class Initialized
INFO - 2017-03-12 00:28:05 --> Helper loaded: date_helper
INFO - 2017-03-12 00:28:05 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:28:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:28:05 --> Helper loaded: form_helper
INFO - 2017-03-12 00:28:05 --> Form Validation Class Initialized
INFO - 2017-03-12 00:28:06 --> Final output sent to browser
DEBUG - 2017-03-12 00:28:06 --> Total execution time: 3.8298
INFO - 2017-03-12 00:28:10 --> Config Class Initialized
INFO - 2017-03-12 00:28:10 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:28:10 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:28:10 --> Utf8 Class Initialized
INFO - 2017-03-12 00:28:10 --> URI Class Initialized
INFO - 2017-03-12 00:28:11 --> Router Class Initialized
INFO - 2017-03-12 00:28:11 --> Output Class Initialized
INFO - 2017-03-12 00:28:11 --> Security Class Initialized
DEBUG - 2017-03-12 00:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:28:11 --> Input Class Initialized
INFO - 2017-03-12 00:28:11 --> Language Class Initialized
INFO - 2017-03-12 00:28:11 --> Loader Class Initialized
INFO - 2017-03-12 00:28:11 --> Database Driver Class Initialized
INFO - 2017-03-12 00:28:12 --> Config Class Initialized
INFO - 2017-03-12 00:28:12 --> Hooks Class Initialized
INFO - 2017-03-12 00:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:28:12 --> Controller Class Initialized
DEBUG - 2017-03-12 00:28:12 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:28:12 --> Utf8 Class Initialized
INFO - 2017-03-12 00:28:12 --> URI Class Initialized
INFO - 2017-03-12 00:28:12 --> Router Class Initialized
INFO - 2017-03-12 00:28:13 --> Helper loaded: date_helper
INFO - 2017-03-12 00:28:13 --> Output Class Initialized
INFO - 2017-03-12 00:28:13 --> Security Class Initialized
DEBUG - 2017-03-12 00:28:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:28:13 --> Helper loaded: url_helper
INFO - 2017-03-12 00:28:13 --> Input Class Initialized
INFO - 2017-03-12 00:28:13 --> Helper loaded: download_helper
INFO - 2017-03-12 00:28:13 --> Language Class Initialized
INFO - 2017-03-12 00:28:13 --> Final output sent to browser
DEBUG - 2017-03-12 00:28:14 --> Total execution time: 3.6800
INFO - 2017-03-12 00:28:15 --> Loader Class Initialized
INFO - 2017-03-12 00:28:17 --> Database Driver Class Initialized
INFO - 2017-03-12 00:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:28:18 --> Controller Class Initialized
INFO - 2017-03-12 00:28:18 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:28:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:28:18 --> Helper loaded: url_helper
INFO - 2017-03-12 00:28:18 --> Helper loaded: download_helper
INFO - 2017-03-12 00:28:18 --> Final output sent to browser
DEBUG - 2017-03-12 00:28:18 --> Total execution time: 7.5385
INFO - 2017-03-12 00:28:38 --> Config Class Initialized
INFO - 2017-03-12 00:28:38 --> Hooks Class Initialized
INFO - 2017-03-12 00:28:39 --> Config Class Initialized
INFO - 2017-03-12 00:28:39 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:28:39 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:28:39 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:28:39 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:28:39 --> Utf8 Class Initialized
INFO - 2017-03-12 00:28:39 --> URI Class Initialized
INFO - 2017-03-12 00:28:39 --> URI Class Initialized
INFO - 2017-03-12 00:28:39 --> Router Class Initialized
INFO - 2017-03-12 00:28:39 --> Router Class Initialized
INFO - 2017-03-12 00:28:39 --> Output Class Initialized
INFO - 2017-03-12 00:28:39 --> Output Class Initialized
INFO - 2017-03-12 00:28:39 --> Security Class Initialized
INFO - 2017-03-12 00:28:39 --> Security Class Initialized
DEBUG - 2017-03-12 00:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:28:39 --> Input Class Initialized
DEBUG - 2017-03-12 00:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:28:39 --> Input Class Initialized
INFO - 2017-03-12 00:28:39 --> Language Class Initialized
INFO - 2017-03-12 00:28:39 --> Language Class Initialized
INFO - 2017-03-12 00:28:40 --> Loader Class Initialized
INFO - 2017-03-12 00:28:40 --> Loader Class Initialized
INFO - 2017-03-12 00:28:41 --> Database Driver Class Initialized
INFO - 2017-03-12 00:28:42 --> Database Driver Class Initialized
INFO - 2017-03-12 00:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:28:43 --> Controller Class Initialized
INFO - 2017-03-12 00:28:44 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:28:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:28:45 --> Helper loaded: url_helper
INFO - 2017-03-12 00:28:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:28:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-03-12 00:28:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:28:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-03-12 00:28:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-03-12 00:28:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:28:50 --> Final output sent to browser
DEBUG - 2017-03-12 00:28:51 --> Total execution time: 12.1557
INFO - 2017-03-12 00:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:28:53 --> Controller Class Initialized
INFO - 2017-03-12 00:28:58 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:29:00 --> Helper loaded: url_helper
INFO - 2017-03-12 00:29:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:29:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-03-12 00:29:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:29:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-03-12 00:29:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-03-12 00:29:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:29:08 --> Final output sent to browser
DEBUG - 2017-03-12 00:29:09 --> Total execution time: 30.2807
INFO - 2017-03-12 00:29:22 --> Config Class Initialized
INFO - 2017-03-12 00:29:22 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:29:25 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:29:25 --> Utf8 Class Initialized
INFO - 2017-03-12 00:29:27 --> URI Class Initialized
INFO - 2017-03-12 00:29:29 --> Router Class Initialized
INFO - 2017-03-12 00:29:31 --> Output Class Initialized
INFO - 2017-03-12 00:29:32 --> Security Class Initialized
DEBUG - 2017-03-12 00:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:29:33 --> Input Class Initialized
INFO - 2017-03-12 00:29:34 --> Language Class Initialized
INFO - 2017-03-12 00:29:36 --> Loader Class Initialized
INFO - 2017-03-12 00:29:41 --> Database Driver Class Initialized
INFO - 2017-03-12 00:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:29:47 --> Controller Class Initialized
INFO - 2017-03-12 00:29:49 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:29:51 --> Helper loaded: url_helper
INFO - 2017-03-12 00:29:52 --> Helper loaded: download_helper
INFO - 2017-03-12 00:29:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:29:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:29:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-12 00:29:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-12 00:29:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:29:59 --> Final output sent to browser
DEBUG - 2017-03-12 00:30:00 --> Total execution time: 53.2571
INFO - 2017-03-12 00:30:14 --> Config Class Initialized
INFO - 2017-03-12 00:30:14 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:30:14 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:30:14 --> Utf8 Class Initialized
INFO - 2017-03-12 00:30:14 --> URI Class Initialized
INFO - 2017-03-12 00:30:14 --> Router Class Initialized
INFO - 2017-03-12 00:30:14 --> Output Class Initialized
INFO - 2017-03-12 00:30:14 --> Security Class Initialized
DEBUG - 2017-03-12 00:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:30:15 --> Input Class Initialized
INFO - 2017-03-12 00:30:15 --> Language Class Initialized
INFO - 2017-03-12 00:30:15 --> Loader Class Initialized
INFO - 2017-03-12 00:30:17 --> Database Driver Class Initialized
INFO - 2017-03-12 00:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:30:17 --> Controller Class Initialized
INFO - 2017-03-12 00:30:17 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:30:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:30:19 --> Config Class Initialized
INFO - 2017-03-12 00:30:19 --> Hooks Class Initialized
INFO - 2017-03-12 00:30:19 --> Config Class Initialized
INFO - 2017-03-12 00:30:19 --> Hooks Class Initialized
INFO - 2017-03-12 00:30:19 --> Config Class Initialized
INFO - 2017-03-12 00:30:19 --> Hooks Class Initialized
INFO - 2017-03-12 00:30:19 --> Config Class Initialized
INFO - 2017-03-12 00:30:19 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:30:20 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:30:20 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:30:20 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:30:20 --> Config Class Initialized
INFO - 2017-03-12 00:30:20 --> Config Class Initialized
INFO - 2017-03-12 00:30:20 --> Hooks Class Initialized
INFO - 2017-03-12 00:30:20 --> Hooks Class Initialized
INFO - 2017-03-12 00:30:20 --> Config Class Initialized
INFO - 2017-03-12 00:30:20 --> Hooks Class Initialized
INFO - 2017-03-12 00:30:20 --> Config Class Initialized
INFO - 2017-03-12 00:30:20 --> Hooks Class Initialized
INFO - 2017-03-12 00:30:20 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:30:20 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:30:20 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:30:20 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:30:20 --> URI Class Initialized
INFO - 2017-03-12 00:30:20 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:30:20 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:30:20 --> Utf8 Class Initialized
INFO - 2017-03-12 00:30:20 --> Utf8 Class Initialized
INFO - 2017-03-12 00:30:20 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:30:20 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:30:20 --> URI Class Initialized
INFO - 2017-03-12 00:30:20 --> Utf8 Class Initialized
INFO - 2017-03-12 00:30:20 --> URI Class Initialized
DEBUG - 2017-03-12 00:30:20 --> No URI present. Default controller set.
INFO - 2017-03-12 00:30:20 --> Router Class Initialized
INFO - 2017-03-12 00:30:20 --> URI Class Initialized
DEBUG - 2017-03-12 00:30:20 --> No URI present. Default controller set.
INFO - 2017-03-12 00:30:20 --> Config Class Initialized
INFO - 2017-03-12 00:30:20 --> Router Class Initialized
INFO - 2017-03-12 00:30:20 --> Output Class Initialized
INFO - 2017-03-12 00:30:20 --> Output Class Initialized
INFO - 2017-03-12 00:30:20 --> Hooks Class Initialized
INFO - 2017-03-12 00:30:20 --> URI Class Initialized
INFO - 2017-03-12 00:30:20 --> Security Class Initialized
DEBUG - 2017-03-12 00:30:20 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:30:20 --> Security Class Initialized
DEBUG - 2017-03-12 00:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:30:20 --> URI Class Initialized
INFO - 2017-03-12 00:30:20 --> Utf8 Class Initialized
INFO - 2017-03-12 00:30:20 --> Input Class Initialized
INFO - 2017-03-12 00:30:20 --> Config Class Initialized
INFO - 2017-03-12 00:30:20 --> URI Class Initialized
INFO - 2017-03-12 00:30:20 --> URI Class Initialized
INFO - 2017-03-12 00:30:20 --> Router Class Initialized
INFO - 2017-03-12 00:30:20 --> Router Class Initialized
INFO - 2017-03-12 00:30:20 --> Router Class Initialized
INFO - 2017-03-12 00:30:20 --> Output Class Initialized
INFO - 2017-03-12 00:30:20 --> Security Class Initialized
DEBUG - 2017-03-12 00:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:30:20 --> Input Class Initialized
INFO - 2017-03-12 00:30:20 --> Language Class Initialized
DEBUG - 2017-03-12 00:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:30:20 --> Input Class Initialized
INFO - 2017-03-12 00:30:20 --> Language Class Initialized
INFO - 2017-03-12 00:30:20 --> Router Class Initialized
INFO - 2017-03-12 00:30:20 --> Loader Class Initialized
INFO - 2017-03-12 00:30:20 --> Router Class Initialized
INFO - 2017-03-12 00:30:20 --> Language Class Initialized
INFO - 2017-03-12 00:30:20 --> Router Class Initialized
INFO - 2017-03-12 00:30:20 --> Output Class Initialized
INFO - 2017-03-12 00:30:20 --> Loader Class Initialized
INFO - 2017-03-12 00:30:20 --> Output Class Initialized
INFO - 2017-03-12 00:30:20 --> Security Class Initialized
INFO - 2017-03-12 00:30:20 --> Security Class Initialized
DEBUG - 2017-03-12 00:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:30:20 --> Input Class Initialized
INFO - 2017-03-12 00:30:20 --> Language Class Initialized
DEBUG - 2017-03-12 00:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:30:20 --> Input Class Initialized
INFO - 2017-03-12 00:30:20 --> Language Class Initialized
INFO - 2017-03-12 00:30:20 --> Loader Class Initialized
DEBUG - 2017-03-12 00:30:20 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:30:20 --> Utf8 Class Initialized
INFO - 2017-03-12 00:30:20 --> Loader Class Initialized
INFO - 2017-03-12 00:30:20 --> Output Class Initialized
INFO - 2017-03-12 00:30:20 --> URI Class Initialized
INFO - 2017-03-12 00:30:20 --> Database Driver Class Initialized
INFO - 2017-03-12 00:30:20 --> Output Class Initialized
INFO - 2017-03-12 00:30:20 --> Router Class Initialized
INFO - 2017-03-12 00:30:20 --> Security Class Initialized
DEBUG - 2017-03-12 00:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:30:20 --> Input Class Initialized
INFO - 2017-03-12 00:30:20 --> Output Class Initialized
INFO - 2017-03-12 00:30:20 --> Language Class Initialized
INFO - 2017-03-12 00:30:20 --> Security Class Initialized
DEBUG - 2017-03-12 00:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:30:20 --> Input Class Initialized
INFO - 2017-03-12 00:30:20 --> Loader Class Initialized
INFO - 2017-03-12 00:30:20 --> Language Class Initialized
INFO - 2017-03-12 00:30:20 --> Security Class Initialized
INFO - 2017-03-12 00:30:20 --> Loader Class Initialized
DEBUG - 2017-03-12 00:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:30:20 --> Input Class Initialized
INFO - 2017-03-12 00:30:20 --> Language Class Initialized
INFO - 2017-03-12 00:30:20 --> Output Class Initialized
INFO - 2017-03-12 00:30:20 --> Security Class Initialized
DEBUG - 2017-03-12 00:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:30:20 --> Input Class Initialized
INFO - 2017-03-12 00:30:20 --> Language Class Initialized
INFO - 2017-03-12 00:30:20 --> Loader Class Initialized
INFO - 2017-03-12 00:30:20 --> Loader Class Initialized
INFO - 2017-03-12 00:30:20 --> Loader Class Initialized
INFO - 2017-03-12 00:30:20 --> Database Driver Class Initialized
INFO - 2017-03-12 00:30:20 --> Database Driver Class Initialized
INFO - 2017-03-12 00:30:20 --> Database Driver Class Initialized
INFO - 2017-03-12 00:30:20 --> Database Driver Class Initialized
INFO - 2017-03-12 00:30:20 --> Database Driver Class Initialized
INFO - 2017-03-12 00:30:20 --> Database Driver Class Initialized
INFO - 2017-03-12 00:30:20 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:30:21 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:30:21 --> Utf8 Class Initialized
INFO - 2017-03-12 00:30:21 --> URI Class Initialized
INFO - 2017-03-12 00:30:21 --> Router Class Initialized
INFO - 2017-03-12 00:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:30:21 --> Controller Class Initialized
INFO - 2017-03-12 00:30:21 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:30:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:30:21 --> Database Driver Class Initialized
INFO - 2017-03-12 00:30:21 --> Database Driver Class Initialized
INFO - 2017-03-12 00:30:21 --> Output Class Initialized
INFO - 2017-03-12 00:30:21 --> Security Class Initialized
DEBUG - 2017-03-12 00:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:30:21 --> Input Class Initialized
INFO - 2017-03-12 00:30:21 --> Language Class Initialized
INFO - 2017-03-12 00:30:21 --> Loader Class Initialized
INFO - 2017-03-12 00:30:21 --> Database Driver Class Initialized
INFO - 2017-03-12 00:30:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:30:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:30:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:30:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:30:21 --> Final output sent to browser
DEBUG - 2017-03-12 00:30:21 --> Total execution time: 4.0761
INFO - 2017-03-12 00:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:30:21 --> Controller Class Initialized
INFO - 2017-03-12 00:30:21 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:30:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:30:21 --> Helper loaded: url_helper
INFO - 2017-03-12 00:30:21 --> Helper loaded: download_helper
INFO - 2017-03-12 00:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:30:21 --> Controller Class Initialized
INFO - 2017-03-12 00:30:21 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:30:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:30:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:30:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:30:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:30:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:30:21 --> Final output sent to browser
DEBUG - 2017-03-12 00:30:21 --> Total execution time: 4.3217
INFO - 2017-03-12 00:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:30:22 --> Controller Class Initialized
INFO - 2017-03-12 00:30:23 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:30:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:30:23 --> Config Class Initialized
INFO - 2017-03-12 00:30:23 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:30:23 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:30:23 --> Utf8 Class Initialized
INFO - 2017-03-12 00:30:23 --> URI Class Initialized
DEBUG - 2017-03-12 00:30:23 --> No URI present. Default controller set.
INFO - 2017-03-12 00:30:23 --> Router Class Initialized
INFO - 2017-03-12 00:30:23 --> Output Class Initialized
INFO - 2017-03-12 00:30:23 --> Security Class Initialized
DEBUG - 2017-03-12 00:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:30:23 --> Input Class Initialized
INFO - 2017-03-12 00:30:23 --> Language Class Initialized
INFO - 2017-03-12 00:30:23 --> Loader Class Initialized
INFO - 2017-03-12 00:30:23 --> Database Driver Class Initialized
INFO - 2017-03-12 00:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:30:23 --> Controller Class Initialized
INFO - 2017-03-12 00:30:23 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:30:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:30:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:30:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:30:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:30:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:30:23 --> Final output sent to browser
DEBUG - 2017-03-12 00:30:23 --> Total execution time: 0.8096
INFO - 2017-03-12 00:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:30:23 --> Controller Class Initialized
INFO - 2017-03-12 00:30:23 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:30:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:30:23 --> Config Class Initialized
INFO - 2017-03-12 00:30:23 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:30:23 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:30:23 --> Utf8 Class Initialized
INFO - 2017-03-12 00:30:23 --> URI Class Initialized
INFO - 2017-03-12 00:30:23 --> Router Class Initialized
INFO - 2017-03-12 00:30:23 --> Output Class Initialized
INFO - 2017-03-12 00:30:23 --> Security Class Initialized
DEBUG - 2017-03-12 00:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:30:23 --> Input Class Initialized
INFO - 2017-03-12 00:30:23 --> Language Class Initialized
INFO - 2017-03-12 00:30:23 --> Loader Class Initialized
INFO - 2017-03-12 00:30:23 --> Database Driver Class Initialized
INFO - 2017-03-12 00:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:30:23 --> Controller Class Initialized
INFO - 2017-03-12 00:30:23 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:30:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:30:24 --> Controller Class Initialized
INFO - 2017-03-12 00:30:24 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:30:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:30:24 --> Controller Class Initialized
INFO - 2017-03-12 00:30:24 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:30:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:30:24 --> Controller Class Initialized
INFO - 2017-03-12 00:30:24 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:30:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:30:24 --> Controller Class Initialized
INFO - 2017-03-12 00:30:24 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:30:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:30:24 --> Controller Class Initialized
INFO - 2017-03-12 00:30:24 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:30:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-12 00:30:38 --> Severity: error --> Exception: timed out before SSL handshake /home/graduafe/public_html/application/libraries/facebook-api-php-codexworld/base_facebook.php 972
INFO - 2017-03-12 00:30:39 --> Config Class Initialized
INFO - 2017-03-12 00:30:39 --> Hooks Class Initialized
INFO - 2017-03-12 00:30:39 --> Config Class Initialized
INFO - 2017-03-12 00:30:39 --> Hooks Class Initialized
INFO - 2017-03-12 00:30:39 --> Config Class Initialized
INFO - 2017-03-12 00:30:39 --> Hooks Class Initialized
INFO - 2017-03-12 00:30:39 --> Config Class Initialized
INFO - 2017-03-12 00:30:39 --> Hooks Class Initialized
INFO - 2017-03-12 00:30:39 --> Config Class Initialized
INFO - 2017-03-12 00:30:39 --> Hooks Class Initialized
INFO - 2017-03-12 00:30:39 --> Config Class Initialized
INFO - 2017-03-12 00:30:39 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:30:39 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:30:39 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:30:39 --> Utf8 Class Initialized
INFO - 2017-03-12 00:30:39 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:30:39 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:30:39 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:30:39 --> Utf8 Class Initialized
INFO - 2017-03-12 00:30:39 --> Utf8 Class Initialized
INFO - 2017-03-12 00:30:39 --> URI Class Initialized
INFO - 2017-03-12 00:30:39 --> URI Class Initialized
INFO - 2017-03-12 00:30:39 --> URI Class Initialized
DEBUG - 2017-03-12 00:30:39 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:30:39 --> Utf8 Class Initialized
INFO - 2017-03-12 00:30:39 --> Router Class Initialized
INFO - 2017-03-12 00:30:39 --> URI Class Initialized
INFO - 2017-03-12 00:30:39 --> Router Class Initialized
INFO - 2017-03-12 00:30:39 --> Output Class Initialized
INFO - 2017-03-12 00:30:39 --> Security Class Initialized
INFO - 2017-03-12 00:30:39 --> URI Class Initialized
INFO - 2017-03-12 00:30:39 --> Router Class Initialized
INFO - 2017-03-12 00:30:39 --> Router Class Initialized
INFO - 2017-03-12 00:30:39 --> Output Class Initialized
INFO - 2017-03-12 00:30:39 --> Output Class Initialized
INFO - 2017-03-12 00:30:39 --> Security Class Initialized
DEBUG - 2017-03-12 00:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:30:39 --> Input Class Initialized
DEBUG - 2017-03-12 00:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:30:39 --> Language Class Initialized
INFO - 2017-03-12 00:30:39 --> Input Class Initialized
INFO - 2017-03-12 00:30:39 --> Config Class Initialized
INFO - 2017-03-12 00:30:39 --> Language Class Initialized
INFO - 2017-03-12 00:30:39 --> Hooks Class Initialized
INFO - 2017-03-12 00:30:39 --> Output Class Initialized
INFO - 2017-03-12 00:30:39 --> Loader Class Initialized
INFO - 2017-03-12 00:30:39 --> Loader Class Initialized
DEBUG - 2017-03-12 00:30:39 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:30:39 --> Security Class Initialized
INFO - 2017-03-12 00:30:39 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:30:39 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:30:39 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:30:39 --> Input Class Initialized
INFO - 2017-03-12 00:30:39 --> URI Class Initialized
INFO - 2017-03-12 00:30:39 --> Language Class Initialized
INFO - 2017-03-12 00:30:39 --> URI Class Initialized
INFO - 2017-03-12 00:30:39 --> Router Class Initialized
INFO - 2017-03-12 00:30:39 --> Router Class Initialized
INFO - 2017-03-12 00:30:39 --> Loader Class Initialized
INFO - 2017-03-12 00:30:39 --> Output Class Initialized
INFO - 2017-03-12 00:30:39 --> Output Class Initialized
INFO - 2017-03-12 00:30:39 --> Security Class Initialized
INFO - 2017-03-12 00:30:39 --> Security Class Initialized
DEBUG - 2017-03-12 00:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:30:39 --> Input Class Initialized
INFO - 2017-03-12 00:30:39 --> Language Class Initialized
INFO - 2017-03-12 00:30:39 --> Router Class Initialized
DEBUG - 2017-03-12 00:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:30:39 --> Output Class Initialized
INFO - 2017-03-12 00:30:39 --> Input Class Initialized
INFO - 2017-03-12 00:30:39 --> Language Class Initialized
INFO - 2017-03-12 00:30:39 --> Security Class Initialized
INFO - 2017-03-12 00:30:40 --> Loader Class Initialized
INFO - 2017-03-12 00:30:40 --> Security Class Initialized
INFO - 2017-03-12 00:30:40 --> Loader Class Initialized
DEBUG - 2017-03-12 00:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:30:40 --> Input Class Initialized
INFO - 2017-03-12 00:30:40 --> Language Class Initialized
INFO - 2017-03-12 00:30:40 --> Loader Class Initialized
INFO - 2017-03-12 00:30:40 --> Database Driver Class Initialized
DEBUG - 2017-03-12 00:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:30:40 --> Input Class Initialized
INFO - 2017-03-12 00:30:40 --> Language Class Initialized
INFO - 2017-03-12 00:30:40 --> Loader Class Initialized
INFO - 2017-03-12 00:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:30:40 --> Database Driver Class Initialized
INFO - 2017-03-12 00:30:40 --> Controller Class Initialized
INFO - 2017-03-12 00:30:40 --> Database Driver Class Initialized
INFO - 2017-03-12 00:30:40 --> Database Driver Class Initialized
INFO - 2017-03-12 00:30:40 --> Database Driver Class Initialized
INFO - 2017-03-12 00:30:40 --> Helper loaded: url_helper
INFO - 2017-03-12 00:30:40 --> Database Driver Class Initialized
INFO - 2017-03-12 00:30:40 --> Database Driver Class Initialized
INFO - 2017-03-12 00:30:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-03-12 00:30:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:30:40 --> Controller Class Initialized
INFO - 2017-03-12 00:30:40 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:30:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:30:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:30:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:30:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:30:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:30:40 --> Final output sent to browser
DEBUG - 2017-03-12 00:30:40 --> Total execution time: 1.4930
INFO - 2017-03-12 00:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:30:41 --> Controller Class Initialized
INFO - 2017-03-12 00:30:41 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:30:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:30:41 --> Controller Class Initialized
INFO - 2017-03-12 00:30:41 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:30:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:30:41 --> Controller Class Initialized
INFO - 2017-03-12 00:30:41 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:30:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:30:41 --> Helper loaded: url_helper
INFO - 2017-03-12 00:30:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:30:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:30:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-12 00:30:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 00:30:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:30:41 --> Final output sent to browser
DEBUG - 2017-03-12 00:30:41 --> Total execution time: 2.6868
INFO - 2017-03-12 00:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:30:41 --> Controller Class Initialized
INFO - 2017-03-12 00:30:41 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:30:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:30:42 --> Controller Class Initialized
INFO - 2017-03-12 00:30:42 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:30:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:30:43 --> Config Class Initialized
INFO - 2017-03-12 00:30:43 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:30:43 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:30:43 --> Utf8 Class Initialized
INFO - 2017-03-12 00:30:43 --> URI Class Initialized
INFO - 2017-03-12 00:30:43 --> Router Class Initialized
INFO - 2017-03-12 00:30:43 --> Output Class Initialized
INFO - 2017-03-12 00:30:43 --> Security Class Initialized
DEBUG - 2017-03-12 00:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:30:43 --> Input Class Initialized
INFO - 2017-03-12 00:30:43 --> Language Class Initialized
INFO - 2017-03-12 00:30:43 --> Loader Class Initialized
INFO - 2017-03-12 00:30:43 --> Database Driver Class Initialized
INFO - 2017-03-12 00:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:30:43 --> Controller Class Initialized
INFO - 2017-03-12 00:30:43 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:30:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:30:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:30:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:30:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:30:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:30:43 --> Final output sent to browser
DEBUG - 2017-03-12 00:30:43 --> Total execution time: 0.0164
INFO - 2017-03-12 00:33:31 --> Config Class Initialized
INFO - 2017-03-12 00:33:31 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:33:31 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:33:31 --> Utf8 Class Initialized
INFO - 2017-03-12 00:33:31 --> URI Class Initialized
INFO - 2017-03-12 00:33:32 --> Router Class Initialized
INFO - 2017-03-12 00:33:32 --> Output Class Initialized
INFO - 2017-03-12 00:33:32 --> Security Class Initialized
DEBUG - 2017-03-12 00:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:33:32 --> Input Class Initialized
INFO - 2017-03-12 00:33:32 --> Language Class Initialized
INFO - 2017-03-12 00:33:32 --> Loader Class Initialized
INFO - 2017-03-12 00:33:32 --> Database Driver Class Initialized
INFO - 2017-03-12 00:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:33:33 --> Controller Class Initialized
INFO - 2017-03-12 00:33:33 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:33:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:33:33 --> Helper loaded: url_helper
INFO - 2017-03-12 00:33:33 --> Helper loaded: download_helper
INFO - 2017-03-12 00:33:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:33:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:33:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-12 00:33:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-12 00:33:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:33:33 --> Final output sent to browser
DEBUG - 2017-03-12 00:33:33 --> Total execution time: 1.8926
INFO - 2017-03-12 00:33:41 --> Config Class Initialized
INFO - 2017-03-12 00:33:41 --> Hooks Class Initialized
INFO - 2017-03-12 00:33:41 --> Config Class Initialized
INFO - 2017-03-12 00:33:41 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:33:41 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:33:41 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:33:41 --> Utf8 Class Initialized
INFO - 2017-03-12 00:33:41 --> Utf8 Class Initialized
INFO - 2017-03-12 00:33:41 --> URI Class Initialized
INFO - 2017-03-12 00:33:41 --> URI Class Initialized
INFO - 2017-03-12 00:33:41 --> Router Class Initialized
INFO - 2017-03-12 00:33:41 --> Router Class Initialized
INFO - 2017-03-12 00:33:41 --> Output Class Initialized
INFO - 2017-03-12 00:33:41 --> Output Class Initialized
INFO - 2017-03-12 00:33:41 --> Security Class Initialized
DEBUG - 2017-03-12 00:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:33:41 --> Security Class Initialized
INFO - 2017-03-12 00:33:41 --> Input Class Initialized
INFO - 2017-03-12 00:33:41 --> Language Class Initialized
DEBUG - 2017-03-12 00:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:33:41 --> Input Class Initialized
INFO - 2017-03-12 00:33:41 --> Language Class Initialized
INFO - 2017-03-12 00:33:41 --> Loader Class Initialized
INFO - 2017-03-12 00:33:41 --> Loader Class Initialized
INFO - 2017-03-12 00:33:41 --> Database Driver Class Initialized
INFO - 2017-03-12 00:33:41 --> Database Driver Class Initialized
INFO - 2017-03-12 00:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:33:42 --> Controller Class Initialized
INFO - 2017-03-12 00:33:42 --> Helper loaded: url_helper
INFO - 2017-03-12 00:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:33:42 --> Controller Class Initialized
INFO - 2017-03-12 00:33:42 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:33:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:33:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:33:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:33:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:33:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
ERROR - 2017-03-12 00:33:42 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
INFO - 2017-03-12 00:33:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
ERROR - 2017-03-12 00:33:42 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:33:42 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:33:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:33:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:33:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:33:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:33:42 --> Final output sent to browser
DEBUG - 2017-03-12 00:33:42 --> Total execution time: 1.4763
INFO - 2017-03-12 00:33:42 --> Final output sent to browser
DEBUG - 2017-03-12 00:33:42 --> Total execution time: 1.4760
INFO - 2017-03-12 00:33:48 --> Config Class Initialized
INFO - 2017-03-12 00:33:48 --> Hooks Class Initialized
INFO - 2017-03-12 00:33:48 --> Config Class Initialized
INFO - 2017-03-12 00:33:48 --> Hooks Class Initialized
INFO - 2017-03-12 00:33:48 --> Config Class Initialized
INFO - 2017-03-12 00:33:48 --> Hooks Class Initialized
INFO - 2017-03-12 00:33:48 --> Config Class Initialized
INFO - 2017-03-12 00:33:48 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:33:48 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:33:48 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:33:48 --> Utf8 Class Initialized
INFO - 2017-03-12 00:33:48 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:33:48 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:33:48 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:33:48 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:33:48 --> Utf8 Class Initialized
INFO - 2017-03-12 00:33:48 --> URI Class Initialized
INFO - 2017-03-12 00:33:48 --> URI Class Initialized
INFO - 2017-03-12 00:33:48 --> URI Class Initialized
INFO - 2017-03-12 00:33:48 --> Router Class Initialized
INFO - 2017-03-12 00:33:48 --> Router Class Initialized
INFO - 2017-03-12 00:33:48 --> URI Class Initialized
INFO - 2017-03-12 00:33:49 --> Router Class Initialized
INFO - 2017-03-12 00:33:49 --> Output Class Initialized
INFO - 2017-03-12 00:33:49 --> Router Class Initialized
INFO - 2017-03-12 00:33:49 --> Output Class Initialized
INFO - 2017-03-12 00:33:49 --> Output Class Initialized
INFO - 2017-03-12 00:33:49 --> Security Class Initialized
INFO - 2017-03-12 00:33:49 --> Security Class Initialized
INFO - 2017-03-12 00:33:49 --> Security Class Initialized
DEBUG - 2017-03-12 00:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:33:49 --> Output Class Initialized
INFO - 2017-03-12 00:33:49 --> Input Class Initialized
INFO - 2017-03-12 00:33:49 --> Language Class Initialized
DEBUG - 2017-03-12 00:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:33:49 --> Input Class Initialized
INFO - 2017-03-12 00:33:49 --> Language Class Initialized
INFO - 2017-03-12 00:33:49 --> Security Class Initialized
DEBUG - 2017-03-12 00:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:33:49 --> Loader Class Initialized
INFO - 2017-03-12 00:33:49 --> Loader Class Initialized
DEBUG - 2017-03-12 00:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:33:49 --> Input Class Initialized
INFO - 2017-03-12 00:33:49 --> Input Class Initialized
INFO - 2017-03-12 00:33:49 --> Language Class Initialized
INFO - 2017-03-12 00:33:49 --> Language Class Initialized
INFO - 2017-03-12 00:33:50 --> Database Driver Class Initialized
INFO - 2017-03-12 00:33:50 --> Database Driver Class Initialized
INFO - 2017-03-12 00:33:50 --> Loader Class Initialized
INFO - 2017-03-12 00:33:50 --> Loader Class Initialized
INFO - 2017-03-12 00:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:33:50 --> Controller Class Initialized
INFO - 2017-03-12 00:33:50 --> Upload Class Initialized
INFO - 2017-03-12 00:33:51 --> Database Driver Class Initialized
INFO - 2017-03-12 00:33:51 --> Database Driver Class Initialized
INFO - 2017-03-12 00:33:51 --> Helper loaded: date_helper
INFO - 2017-03-12 00:33:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-03-12 00:33:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:33:51 --> Controller Class Initialized
INFO - 2017-03-12 00:33:51 --> Helper loaded: url_helper
INFO - 2017-03-12 00:33:51 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:33:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:33:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:33:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-03-12 00:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-03-12 00:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:33:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-12 00:33:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:33:52 --> Final output sent to browser
DEBUG - 2017-03-12 00:33:52 --> Total execution time: 3.4957
INFO - 2017-03-12 00:33:52 --> Final output sent to browser
DEBUG - 2017-03-12 00:33:52 --> Total execution time: 3.5059
INFO - 2017-03-12 00:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:33:53 --> Controller Class Initialized
INFO - 2017-03-12 00:33:53 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:33:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:33:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:33:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:33:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:33:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:33:54 --> Final output sent to browser
DEBUG - 2017-03-12 00:33:54 --> Total execution time: 6.0718
INFO - 2017-03-12 00:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:33:54 --> Controller Class Initialized
INFO - 2017-03-12 00:33:55 --> Upload Class Initialized
INFO - 2017-03-12 00:33:55 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:33:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:33:56 --> Helper loaded: url_helper
INFO - 2017-03-12 00:33:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:33:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:33:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-03-12 00:33:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-03-12 00:33:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-12 00:33:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:33:56 --> Final output sent to browser
DEBUG - 2017-03-12 00:33:56 --> Total execution time: 8.0481
INFO - 2017-03-12 00:34:05 --> Config Class Initialized
INFO - 2017-03-12 00:34:05 --> Config Class Initialized
INFO - 2017-03-12 00:34:05 --> Hooks Class Initialized
INFO - 2017-03-12 00:34:05 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:34:05 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:34:05 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:34:05 --> Utf8 Class Initialized
INFO - 2017-03-12 00:34:05 --> Utf8 Class Initialized
INFO - 2017-03-12 00:34:05 --> URI Class Initialized
INFO - 2017-03-12 00:34:06 --> URI Class Initialized
INFO - 2017-03-12 00:34:06 --> Router Class Initialized
INFO - 2017-03-12 00:34:06 --> Router Class Initialized
INFO - 2017-03-12 00:34:06 --> Config Class Initialized
INFO - 2017-03-12 00:34:06 --> Output Class Initialized
INFO - 2017-03-12 00:34:06 --> Output Class Initialized
INFO - 2017-03-12 00:34:06 --> Hooks Class Initialized
INFO - 2017-03-12 00:34:06 --> Security Class Initialized
INFO - 2017-03-12 00:34:06 --> Security Class Initialized
DEBUG - 2017-03-12 00:34:06 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:34:06 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:34:06 --> Input Class Initialized
INFO - 2017-03-12 00:34:06 --> Input Class Initialized
INFO - 2017-03-12 00:34:06 --> URI Class Initialized
INFO - 2017-03-12 00:34:06 --> Language Class Initialized
INFO - 2017-03-12 00:34:06 --> Language Class Initialized
INFO - 2017-03-12 00:34:06 --> Router Class Initialized
INFO - 2017-03-12 00:34:06 --> Loader Class Initialized
INFO - 2017-03-12 00:34:06 --> Loader Class Initialized
INFO - 2017-03-12 00:34:06 --> Output Class Initialized
INFO - 2017-03-12 00:34:06 --> Security Class Initialized
DEBUG - 2017-03-12 00:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:34:07 --> Input Class Initialized
INFO - 2017-03-12 00:34:07 --> Database Driver Class Initialized
INFO - 2017-03-12 00:34:07 --> Database Driver Class Initialized
INFO - 2017-03-12 00:34:07 --> Language Class Initialized
INFO - 2017-03-12 00:34:08 --> Loader Class Initialized
INFO - 2017-03-12 00:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:34:08 --> Controller Class Initialized
INFO - 2017-03-12 00:34:08 --> Upload Class Initialized
INFO - 2017-03-12 00:34:08 --> Database Driver Class Initialized
INFO - 2017-03-12 00:34:09 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:34:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:34:09 --> Helper loaded: url_helper
INFO - 2017-03-12 00:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-03-12 00:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-03-12 00:34:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-12 00:34:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:34:09 --> Final output sent to browser
DEBUG - 2017-03-12 00:34:09 --> Total execution time: 4.7432
INFO - 2017-03-12 00:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:34:09 --> Controller Class Initialized
INFO - 2017-03-12 00:34:09 --> Upload Class Initialized
INFO - 2017-03-12 00:34:09 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:34:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:34:10 --> Helper loaded: url_helper
INFO - 2017-03-12 00:34:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:34:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:34:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-03-12 00:34:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-03-12 00:34:10 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-12 00:34:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:34:10 --> Final output sent to browser
DEBUG - 2017-03-12 00:34:10 --> Total execution time: 5.3602
INFO - 2017-03-12 00:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:34:10 --> Controller Class Initialized
INFO - 2017-03-12 00:34:10 --> Upload Class Initialized
INFO - 2017-03-12 00:34:10 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:34:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:34:10 --> Helper loaded: url_helper
INFO - 2017-03-12 00:34:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:34:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:34:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-03-12 00:34:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-03-12 00:34:11 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-12 00:34:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:34:11 --> Final output sent to browser
DEBUG - 2017-03-12 00:34:11 --> Total execution time: 6.1298
INFO - 2017-03-12 00:34:14 --> Config Class Initialized
INFO - 2017-03-12 00:34:14 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:34:15 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:34:15 --> Utf8 Class Initialized
INFO - 2017-03-12 00:34:15 --> URI Class Initialized
INFO - 2017-03-12 00:34:15 --> Router Class Initialized
INFO - 2017-03-12 00:34:15 --> Output Class Initialized
INFO - 2017-03-12 00:34:15 --> Security Class Initialized
DEBUG - 2017-03-12 00:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:34:16 --> Input Class Initialized
INFO - 2017-03-12 00:34:16 --> Language Class Initialized
INFO - 2017-03-12 00:34:16 --> Loader Class Initialized
INFO - 2017-03-12 00:34:17 --> Database Driver Class Initialized
INFO - 2017-03-12 00:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:34:17 --> Controller Class Initialized
INFO - 2017-03-12 00:34:17 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:34:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:34:22 --> Config Class Initialized
INFO - 2017-03-12 00:34:22 --> Hooks Class Initialized
INFO - 2017-03-12 00:34:23 --> Config Class Initialized
INFO - 2017-03-12 00:34:23 --> Hooks Class Initialized
INFO - 2017-03-12 00:34:23 --> Config Class Initialized
INFO - 2017-03-12 00:34:24 --> Hooks Class Initialized
INFO - 2017-03-12 00:34:24 --> Config Class Initialized
INFO - 2017-03-12 00:34:24 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:34:24 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:34:24 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:34:24 --> Utf8 Class Initialized
INFO - 2017-03-12 00:34:25 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:34:25 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:34:25 --> Utf8 Class Initialized
INFO - 2017-03-12 00:34:25 --> URI Class Initialized
INFO - 2017-03-12 00:34:26 --> URI Class Initialized
DEBUG - 2017-03-12 00:34:26 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:34:26 --> Utf8 Class Initialized
INFO - 2017-03-12 00:34:26 --> Router Class Initialized
INFO - 2017-03-12 00:34:26 --> URI Class Initialized
INFO - 2017-03-12 00:34:26 --> Router Class Initialized
INFO - 2017-03-12 00:34:27 --> Output Class Initialized
INFO - 2017-03-12 00:34:27 --> Output Class Initialized
INFO - 2017-03-12 00:34:27 --> URI Class Initialized
INFO - 2017-03-12 00:34:27 --> Security Class Initialized
INFO - 2017-03-12 00:34:27 --> Security Class Initialized
INFO - 2017-03-12 00:34:27 --> Router Class Initialized
DEBUG - 2017-03-12 00:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-03-12 00:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:34:27 --> Input Class Initialized
INFO - 2017-03-12 00:34:27 --> Router Class Initialized
INFO - 2017-03-12 00:34:27 --> Language Class Initialized
INFO - 2017-03-12 00:34:28 --> Input Class Initialized
INFO - 2017-03-12 00:34:28 --> Output Class Initialized
INFO - 2017-03-12 00:34:28 --> Security Class Initialized
INFO - 2017-03-12 00:34:28 --> Output Class Initialized
INFO - 2017-03-12 00:34:28 --> Loader Class Initialized
DEBUG - 2017-03-12 00:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:34:28 --> Language Class Initialized
INFO - 2017-03-12 00:34:28 --> Input Class Initialized
INFO - 2017-03-12 00:34:28 --> Security Class Initialized
INFO - 2017-03-12 00:34:28 --> Language Class Initialized
DEBUG - 2017-03-12 00:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:34:28 --> Loader Class Initialized
INFO - 2017-03-12 00:34:28 --> Loader Class Initialized
INFO - 2017-03-12 00:34:28 --> Database Driver Class Initialized
INFO - 2017-03-12 00:34:28 --> Input Class Initialized
INFO - 2017-03-12 00:34:28 --> Language Class Initialized
INFO - 2017-03-12 00:34:28 --> Database Driver Class Initialized
INFO - 2017-03-12 00:34:28 --> Database Driver Class Initialized
INFO - 2017-03-12 00:34:29 --> Loader Class Initialized
INFO - 2017-03-12 00:34:29 --> Database Driver Class Initialized
INFO - 2017-03-12 00:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:34:29 --> Controller Class Initialized
INFO - 2017-03-12 00:34:29 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:34:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:34:29 --> Helper loaded: url_helper
INFO - 2017-03-12 00:34:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:34:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-03-12 00:34:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:34:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-03-12 00:34:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-03-12 00:34:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:34:30 --> Final output sent to browser
DEBUG - 2017-03-12 00:34:30 --> Total execution time: 10.1867
INFO - 2017-03-12 00:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:34:30 --> Controller Class Initialized
INFO - 2017-03-12 00:34:30 --> Helper loaded: date_helper
INFO - 2017-03-12 00:34:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
DEBUG - 2017-03-12 00:34:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:34:30 --> Helper loaded: url_helper
INFO - 2017-03-12 00:34:30 --> Helper loaded: download_helper
ERROR - 2017-03-12 00:34:30 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
INFO - 2017-03-12 00:34:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:34:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2017-03-12 00:34:30 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:34:30 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:34:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:34:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-12 00:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-12 00:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:34:31 --> Final output sent to browser
DEBUG - 2017-03-12 00:34:31 --> Total execution time: 10.8637
INFO - 2017-03-12 00:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:34:31 --> Controller Class Initialized
INFO - 2017-03-12 00:34:31 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:34:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:34:31 --> Helper loaded: url_helper
INFO - 2017-03-12 00:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-03-12 00:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-03-12 00:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-03-12 00:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:34:31 --> Final output sent to browser
DEBUG - 2017-03-12 00:34:31 --> Total execution time: 10.8895
INFO - 2017-03-12 00:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:34:31 --> Controller Class Initialized
INFO - 2017-03-12 00:34:31 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:34:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:34:31 --> Helper loaded: url_helper
INFO - 2017-03-12 00:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-03-12 00:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-03-12 00:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-03-12 00:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:34:31 --> Final output sent to browser
DEBUG - 2017-03-12 00:34:31 --> Total execution time: 10.8983
INFO - 2017-03-12 00:34:31 --> Final output sent to browser
DEBUG - 2017-03-12 00:34:31 --> Total execution time: 16.2822
INFO - 2017-03-12 00:34:34 --> Config Class Initialized
INFO - 2017-03-12 00:34:34 --> Hooks Class Initialized
INFO - 2017-03-12 00:34:34 --> Config Class Initialized
INFO - 2017-03-12 00:34:34 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:34:34 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:34:34 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:34:34 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:34:34 --> Utf8 Class Initialized
INFO - 2017-03-12 00:34:34 --> URI Class Initialized
INFO - 2017-03-12 00:34:34 --> URI Class Initialized
INFO - 2017-03-12 00:34:34 --> Config Class Initialized
INFO - 2017-03-12 00:34:34 --> Router Class Initialized
INFO - 2017-03-12 00:34:34 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:34:34 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:34:34 --> Router Class Initialized
INFO - 2017-03-12 00:34:34 --> Output Class Initialized
INFO - 2017-03-12 00:34:34 --> Config Class Initialized
INFO - 2017-03-12 00:34:34 --> Output Class Initialized
INFO - 2017-03-12 00:34:34 --> Hooks Class Initialized
INFO - 2017-03-12 00:34:34 --> Security Class Initialized
INFO - 2017-03-12 00:34:34 --> Security Class Initialized
DEBUG - 2017-03-12 00:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:34:35 --> Utf8 Class Initialized
INFO - 2017-03-12 00:34:35 --> Input Class Initialized
INFO - 2017-03-12 00:34:35 --> Language Class Initialized
DEBUG - 2017-03-12 00:34:35 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:34:35 --> Utf8 Class Initialized
INFO - 2017-03-12 00:34:35 --> Input Class Initialized
INFO - 2017-03-12 00:34:35 --> URI Class Initialized
INFO - 2017-03-12 00:34:35 --> Language Class Initialized
INFO - 2017-03-12 00:34:35 --> Router Class Initialized
INFO - 2017-03-12 00:34:35 --> Output Class Initialized
INFO - 2017-03-12 00:34:35 --> Security Class Initialized
DEBUG - 2017-03-12 00:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:34:35 --> Input Class Initialized
INFO - 2017-03-12 00:34:35 --> Language Class Initialized
INFO - 2017-03-12 00:34:35 --> Loader Class Initialized
INFO - 2017-03-12 00:34:35 --> Loader Class Initialized
INFO - 2017-03-12 00:34:35 --> URI Class Initialized
INFO - 2017-03-12 00:34:35 --> Router Class Initialized
INFO - 2017-03-12 00:34:35 --> Output Class Initialized
INFO - 2017-03-12 00:34:35 --> Security Class Initialized
DEBUG - 2017-03-12 00:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:34:35 --> Input Class Initialized
INFO - 2017-03-12 00:34:35 --> Language Class Initialized
INFO - 2017-03-12 00:34:35 --> Loader Class Initialized
INFO - 2017-03-12 00:34:35 --> Loader Class Initialized
INFO - 2017-03-12 00:34:35 --> Database Driver Class Initialized
INFO - 2017-03-12 00:34:35 --> Database Driver Class Initialized
INFO - 2017-03-12 00:34:35 --> Database Driver Class Initialized
INFO - 2017-03-12 00:34:35 --> Database Driver Class Initialized
INFO - 2017-03-12 00:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:34:35 --> Controller Class Initialized
INFO - 2017-03-12 00:34:35 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:34:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:34:35 --> Helper loaded: url_helper
INFO - 2017-03-12 00:34:35 --> Helper loaded: download_helper
INFO - 2017-03-12 00:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-12 00:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-12 00:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:34:36 --> Final output sent to browser
DEBUG - 2017-03-12 00:34:36 --> Total execution time: 2.3629
INFO - 2017-03-12 00:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:34:36 --> Controller Class Initialized
INFO - 2017-03-12 00:34:36 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:34:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:34:36 --> Helper loaded: url_helper
INFO - 2017-03-12 00:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-03-12 00:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-03-12 00:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-03-12 00:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:34:36 --> Final output sent to browser
DEBUG - 2017-03-12 00:34:36 --> Total execution time: 2.7217
INFO - 2017-03-12 00:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:34:36 --> Controller Class Initialized
INFO - 2017-03-12 00:34:36 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:34:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:34:36 --> Helper loaded: url_helper
INFO - 2017-03-12 00:34:36 --> Helper loaded: download_helper
INFO - 2017-03-12 00:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-12 00:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-12 00:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:34:36 --> Final output sent to browser
DEBUG - 2017-03-12 00:34:36 --> Total execution time: 3.1569
INFO - 2017-03-12 00:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:34:37 --> Controller Class Initialized
INFO - 2017-03-12 00:34:37 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:34:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:34:37 --> Helper loaded: url_helper
INFO - 2017-03-12 00:34:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:34:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-03-12 00:34:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:34:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-03-12 00:34:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-03-12 00:34:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:34:37 --> Final output sent to browser
DEBUG - 2017-03-12 00:34:37 --> Total execution time: 3.7948
INFO - 2017-03-12 00:34:37 --> Config Class Initialized
INFO - 2017-03-12 00:34:37 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:34:37 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:34:37 --> Utf8 Class Initialized
INFO - 2017-03-12 00:34:37 --> URI Class Initialized
INFO - 2017-03-12 00:34:37 --> Router Class Initialized
INFO - 2017-03-12 00:34:38 --> Output Class Initialized
INFO - 2017-03-12 00:34:38 --> Security Class Initialized
DEBUG - 2017-03-12 00:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:34:38 --> Input Class Initialized
INFO - 2017-03-12 00:34:38 --> Language Class Initialized
INFO - 2017-03-12 00:34:38 --> Loader Class Initialized
INFO - 2017-03-12 00:34:38 --> Database Driver Class Initialized
INFO - 2017-03-12 00:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:34:38 --> Controller Class Initialized
INFO - 2017-03-12 00:34:38 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:34:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:34:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:34:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:34:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:34:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:34:39 --> Final output sent to browser
DEBUG - 2017-03-12 00:34:39 --> Total execution time: 3.6862
INFO - 2017-03-12 00:34:56 --> Config Class Initialized
INFO - 2017-03-12 00:34:56 --> Config Class Initialized
INFO - 2017-03-12 00:34:56 --> Hooks Class Initialized
INFO - 2017-03-12 00:34:56 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:34:56 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:34:56 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:34:56 --> Utf8 Class Initialized
INFO - 2017-03-12 00:34:56 --> Utf8 Class Initialized
INFO - 2017-03-12 00:34:56 --> URI Class Initialized
INFO - 2017-03-12 00:34:56 --> URI Class Initialized
INFO - 2017-03-12 00:34:56 --> Router Class Initialized
INFO - 2017-03-12 00:34:56 --> Router Class Initialized
INFO - 2017-03-12 00:34:56 --> Output Class Initialized
INFO - 2017-03-12 00:34:56 --> Output Class Initialized
INFO - 2017-03-12 00:34:56 --> Security Class Initialized
INFO - 2017-03-12 00:34:56 --> Security Class Initialized
DEBUG - 2017-03-12 00:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:34:56 --> Input Class Initialized
INFO - 2017-03-12 00:34:56 --> Language Class Initialized
DEBUG - 2017-03-12 00:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:34:56 --> Input Class Initialized
INFO - 2017-03-12 00:34:56 --> Language Class Initialized
INFO - 2017-03-12 00:34:56 --> Loader Class Initialized
INFO - 2017-03-12 00:34:56 --> Loader Class Initialized
INFO - 2017-03-12 00:34:57 --> Database Driver Class Initialized
INFO - 2017-03-12 00:34:57 --> Database Driver Class Initialized
INFO - 2017-03-12 00:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:34:57 --> Controller Class Initialized
INFO - 2017-03-12 00:34:57 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:34:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:34:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:34:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:34:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:34:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:34:57 --> Final output sent to browser
DEBUG - 2017-03-12 00:34:57 --> Total execution time: 1.5140
INFO - 2017-03-12 00:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:34:58 --> Controller Class Initialized
INFO - 2017-03-12 00:34:58 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:34:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:34:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:34:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:34:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:34:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:34:59 --> Final output sent to browser
DEBUG - 2017-03-12 00:34:59 --> Total execution time: 3.2967
INFO - 2017-03-12 00:35:41 --> Config Class Initialized
INFO - 2017-03-12 00:35:41 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:35:41 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:35:41 --> Utf8 Class Initialized
INFO - 2017-03-12 00:35:41 --> URI Class Initialized
INFO - 2017-03-12 00:35:41 --> Router Class Initialized
INFO - 2017-03-12 00:35:41 --> Output Class Initialized
INFO - 2017-03-12 00:35:41 --> Security Class Initialized
DEBUG - 2017-03-12 00:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:35:42 --> Input Class Initialized
INFO - 2017-03-12 00:35:42 --> Language Class Initialized
INFO - 2017-03-12 00:35:42 --> Loader Class Initialized
INFO - 2017-03-12 00:35:42 --> Database Driver Class Initialized
INFO - 2017-03-12 00:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:35:42 --> Controller Class Initialized
INFO - 2017-03-12 00:35:42 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:35:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:35:42 --> Helper loaded: url_helper
INFO - 2017-03-12 00:35:42 --> Helper loaded: download_helper
INFO - 2017-03-12 00:35:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:35:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:35:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-12 00:35:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-12 00:35:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:35:42 --> Final output sent to browser
DEBUG - 2017-03-12 00:35:42 --> Total execution time: 1.5663
INFO - 2017-03-12 00:35:57 --> Config Class Initialized
INFO - 2017-03-12 00:35:57 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:35:57 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:35:57 --> Utf8 Class Initialized
INFO - 2017-03-12 00:35:57 --> URI Class Initialized
INFO - 2017-03-12 00:35:57 --> Router Class Initialized
INFO - 2017-03-12 00:35:58 --> Output Class Initialized
INFO - 2017-03-12 00:35:58 --> Security Class Initialized
DEBUG - 2017-03-12 00:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:35:58 --> Input Class Initialized
INFO - 2017-03-12 00:35:58 --> Language Class Initialized
INFO - 2017-03-12 00:35:58 --> Loader Class Initialized
INFO - 2017-03-12 00:35:58 --> Database Driver Class Initialized
INFO - 2017-03-12 00:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:35:59 --> Controller Class Initialized
INFO - 2017-03-12 00:35:59 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:35:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:35:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:35:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:35:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:35:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:35:59 --> Final output sent to browser
DEBUG - 2017-03-12 00:35:59 --> Total execution time: 2.4673
INFO - 2017-03-12 00:36:05 --> Config Class Initialized
INFO - 2017-03-12 00:36:05 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:36:05 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:36:05 --> Utf8 Class Initialized
INFO - 2017-03-12 00:36:05 --> URI Class Initialized
INFO - 2017-03-12 00:36:05 --> Router Class Initialized
INFO - 2017-03-12 00:36:05 --> Output Class Initialized
INFO - 2017-03-12 00:36:05 --> Security Class Initialized
DEBUG - 2017-03-12 00:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:36:05 --> Input Class Initialized
INFO - 2017-03-12 00:36:05 --> Language Class Initialized
INFO - 2017-03-12 00:36:05 --> Loader Class Initialized
INFO - 2017-03-12 00:36:05 --> Database Driver Class Initialized
INFO - 2017-03-12 00:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:36:05 --> Controller Class Initialized
INFO - 2017-03-12 00:36:05 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:36:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:36:06 --> Final output sent to browser
DEBUG - 2017-03-12 00:36:06 --> Total execution time: 1.3162
INFO - 2017-03-12 00:36:31 --> Config Class Initialized
INFO - 2017-03-12 00:36:31 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:36:31 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:36:31 --> Utf8 Class Initialized
INFO - 2017-03-12 00:36:31 --> URI Class Initialized
INFO - 2017-03-12 00:36:31 --> Router Class Initialized
INFO - 2017-03-12 00:36:31 --> Output Class Initialized
INFO - 2017-03-12 00:36:32 --> Security Class Initialized
DEBUG - 2017-03-12 00:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:36:32 --> Input Class Initialized
INFO - 2017-03-12 00:36:32 --> Language Class Initialized
INFO - 2017-03-12 00:36:32 --> Loader Class Initialized
INFO - 2017-03-12 00:36:32 --> Database Driver Class Initialized
INFO - 2017-03-12 00:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:36:32 --> Controller Class Initialized
INFO - 2017-03-12 00:36:32 --> Helper loaded: date_helper
INFO - 2017-03-12 00:36:32 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:36:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:36:32 --> Helper loaded: form_helper
INFO - 2017-03-12 00:36:32 --> Form Validation Class Initialized
INFO - 2017-03-12 00:36:32 --> Final output sent to browser
DEBUG - 2017-03-12 00:36:32 --> Total execution time: 1.5618
INFO - 2017-03-12 00:37:16 --> Config Class Initialized
INFO - 2017-03-12 00:37:16 --> Config Class Initialized
INFO - 2017-03-12 00:37:16 --> Hooks Class Initialized
INFO - 2017-03-12 00:37:16 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:37:16 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:37:16 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:37:16 --> Utf8 Class Initialized
INFO - 2017-03-12 00:37:16 --> Utf8 Class Initialized
INFO - 2017-03-12 00:37:16 --> URI Class Initialized
INFO - 2017-03-12 00:37:16 --> URI Class Initialized
INFO - 2017-03-12 00:37:16 --> Config Class Initialized
INFO - 2017-03-12 00:37:16 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:37:16 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:37:16 --> Utf8 Class Initialized
INFO - 2017-03-12 00:37:16 --> URI Class Initialized
INFO - 2017-03-12 00:37:16 --> Router Class Initialized
INFO - 2017-03-12 00:37:16 --> Router Class Initialized
INFO - 2017-03-12 00:37:16 --> Router Class Initialized
INFO - 2017-03-12 00:37:16 --> Output Class Initialized
INFO - 2017-03-12 00:37:16 --> Output Class Initialized
INFO - 2017-03-12 00:37:16 --> Output Class Initialized
INFO - 2017-03-12 00:37:16 --> Security Class Initialized
INFO - 2017-03-12 00:37:16 --> Security Class Initialized
DEBUG - 2017-03-12 00:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:37:16 --> Input Class Initialized
INFO - 2017-03-12 00:37:16 --> Language Class Initialized
INFO - 2017-03-12 00:37:16 --> Security Class Initialized
DEBUG - 2017-03-12 00:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:37:16 --> Input Class Initialized
INFO - 2017-03-12 00:37:16 --> Language Class Initialized
DEBUG - 2017-03-12 00:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:37:16 --> Input Class Initialized
INFO - 2017-03-12 00:37:16 --> Language Class Initialized
INFO - 2017-03-12 00:37:16 --> Loader Class Initialized
INFO - 2017-03-12 00:37:16 --> Loader Class Initialized
INFO - 2017-03-12 00:37:16 --> Loader Class Initialized
INFO - 2017-03-12 00:37:17 --> Database Driver Class Initialized
INFO - 2017-03-12 00:37:17 --> Database Driver Class Initialized
INFO - 2017-03-12 00:37:17 --> Database Driver Class Initialized
INFO - 2017-03-12 00:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:37:17 --> Controller Class Initialized
INFO - 2017-03-12 00:37:17 --> Upload Class Initialized
INFO - 2017-03-12 00:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:37:17 --> Controller Class Initialized
INFO - 2017-03-12 00:37:17 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:37:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:37:17 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:37:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:37:17 --> Helper loaded: url_helper
INFO - 2017-03-12 00:37:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:37:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:37:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-03-12 00:37:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-03-12 00:37:18 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-12 00:37:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:37:18 --> Final output sent to browser
DEBUG - 2017-03-12 00:37:18 --> Total execution time: 2.2636
INFO - 2017-03-12 00:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:37:18 --> Controller Class Initialized
INFO - 2017-03-12 00:37:18 --> Upload Class Initialized
INFO - 2017-03-12 00:37:19 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:37:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:37:19 --> Helper loaded: url_helper
INFO - 2017-03-12 00:37:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:37:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:37:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-03-12 00:37:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-03-12 00:37:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-12 00:37:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:37:23 --> Final output sent to browser
DEBUG - 2017-03-12 00:37:23 --> Total execution time: 6.9900
INFO - 2017-03-12 00:37:49 --> Config Class Initialized
INFO - 2017-03-12 00:37:49 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:37:49 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:37:49 --> Utf8 Class Initialized
INFO - 2017-03-12 00:37:50 --> URI Class Initialized
INFO - 2017-03-12 00:37:50 --> Config Class Initialized
INFO - 2017-03-12 00:37:50 --> Router Class Initialized
INFO - 2017-03-12 00:37:50 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:37:50 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:37:50 --> Utf8 Class Initialized
INFO - 2017-03-12 00:37:50 --> Output Class Initialized
INFO - 2017-03-12 00:37:50 --> URI Class Initialized
INFO - 2017-03-12 00:37:50 --> Security Class Initialized
INFO - 2017-03-12 00:37:50 --> Router Class Initialized
DEBUG - 2017-03-12 00:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:37:50 --> Output Class Initialized
INFO - 2017-03-12 00:37:50 --> Input Class Initialized
INFO - 2017-03-12 00:37:50 --> Security Class Initialized
INFO - 2017-03-12 00:37:50 --> Language Class Initialized
DEBUG - 2017-03-12 00:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:37:50 --> Input Class Initialized
INFO - 2017-03-12 00:37:50 --> Language Class Initialized
INFO - 2017-03-12 00:37:50 --> Loader Class Initialized
INFO - 2017-03-12 00:37:50 --> Loader Class Initialized
INFO - 2017-03-12 00:37:50 --> Database Driver Class Initialized
INFO - 2017-03-12 00:37:50 --> Database Driver Class Initialized
INFO - 2017-03-12 00:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:37:51 --> Controller Class Initialized
INFO - 2017-03-12 00:37:51 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:37:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:37:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:37:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:37:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:37:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:37:51 --> Final output sent to browser
DEBUG - 2017-03-12 00:37:51 --> Total execution time: 2.9273
INFO - 2017-03-12 00:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:37:52 --> Controller Class Initialized
INFO - 2017-03-12 00:37:52 --> Helper loaded: url_helper
INFO - 2017-03-12 00:37:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
DEBUG - 2017-03-12 00:37:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-12 00:37:52 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:37:52 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
INFO - 2017-03-12 00:37:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 00:37:52 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:37:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:37:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:37:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:37:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:37:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:37:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:37:52 --> Final output sent to browser
DEBUG - 2017-03-12 00:37:52 --> Total execution time: 36.8159
INFO - 2017-03-12 00:37:52 --> Final output sent to browser
DEBUG - 2017-03-12 00:37:53 --> Total execution time: 4.2706
INFO - 2017-03-12 00:37:57 --> Config Class Initialized
INFO - 2017-03-12 00:37:57 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:37:57 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:37:57 --> Utf8 Class Initialized
INFO - 2017-03-12 00:37:57 --> URI Class Initialized
INFO - 2017-03-12 00:37:57 --> Router Class Initialized
INFO - 2017-03-12 00:37:57 --> Output Class Initialized
INFO - 2017-03-12 00:37:57 --> Security Class Initialized
DEBUG - 2017-03-12 00:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:37:58 --> Input Class Initialized
INFO - 2017-03-12 00:37:58 --> Language Class Initialized
INFO - 2017-03-12 00:37:58 --> Loader Class Initialized
INFO - 2017-03-12 00:37:58 --> Database Driver Class Initialized
INFO - 2017-03-12 00:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:37:58 --> Controller Class Initialized
INFO - 2017-03-12 00:37:58 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:37:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:37:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:37:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:37:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:37:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:37:58 --> Final output sent to browser
DEBUG - 2017-03-12 00:37:58 --> Total execution time: 1.2439
INFO - 2017-03-12 00:38:12 --> Config Class Initialized
INFO - 2017-03-12 00:38:12 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:38:12 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:38:12 --> Utf8 Class Initialized
INFO - 2017-03-12 00:38:12 --> URI Class Initialized
DEBUG - 2017-03-12 00:38:12 --> No URI present. Default controller set.
INFO - 2017-03-12 00:38:12 --> Router Class Initialized
INFO - 2017-03-12 00:38:12 --> Output Class Initialized
INFO - 2017-03-12 00:38:12 --> Security Class Initialized
DEBUG - 2017-03-12 00:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:38:12 --> Input Class Initialized
INFO - 2017-03-12 00:38:12 --> Language Class Initialized
INFO - 2017-03-12 00:38:12 --> Loader Class Initialized
INFO - 2017-03-12 00:38:13 --> Database Driver Class Initialized
INFO - 2017-03-12 00:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:38:13 --> Controller Class Initialized
INFO - 2017-03-12 00:38:13 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:38:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:38:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:38:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:38:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:38:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:38:14 --> Final output sent to browser
DEBUG - 2017-03-12 00:38:14 --> Total execution time: 2.0093
INFO - 2017-03-12 00:38:42 --> Config Class Initialized
INFO - 2017-03-12 00:38:42 --> Config Class Initialized
INFO - 2017-03-12 00:38:43 --> Hooks Class Initialized
INFO - 2017-03-12 00:38:43 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:38:43 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:38:43 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:38:43 --> Utf8 Class Initialized
INFO - 2017-03-12 00:38:43 --> Utf8 Class Initialized
INFO - 2017-03-12 00:38:43 --> Config Class Initialized
INFO - 2017-03-12 00:38:43 --> Hooks Class Initialized
INFO - 2017-03-12 00:38:43 --> URI Class Initialized
INFO - 2017-03-12 00:38:43 --> URI Class Initialized
DEBUG - 2017-03-12 00:38:43 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:38:43 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:38:43 --> No URI present. Default controller set.
INFO - 2017-03-12 00:38:43 --> URI Class Initialized
INFO - 2017-03-12 00:38:43 --> Router Class Initialized
DEBUG - 2017-03-12 00:38:43 --> No URI present. Default controller set.
INFO - 2017-03-12 00:38:43 --> Router Class Initialized
INFO - 2017-03-12 00:38:43 --> Router Class Initialized
INFO - 2017-03-12 00:38:43 --> Output Class Initialized
INFO - 2017-03-12 00:38:43 --> Output Class Initialized
INFO - 2017-03-12 00:38:43 --> Output Class Initialized
INFO - 2017-03-12 00:38:43 --> Security Class Initialized
INFO - 2017-03-12 00:38:43 --> Security Class Initialized
INFO - 2017-03-12 00:38:43 --> Security Class Initialized
INFO - 2017-03-12 00:38:43 --> Config Class Initialized
DEBUG - 2017-03-12 00:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:38:43 --> Hooks Class Initialized
INFO - 2017-03-12 00:38:43 --> Input Class Initialized
DEBUG - 2017-03-12 00:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-03-12 00:38:43 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:38:43 --> Input Class Initialized
INFO - 2017-03-12 00:38:43 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:38:43 --> Input Class Initialized
INFO - 2017-03-12 00:38:43 --> Language Class Initialized
INFO - 2017-03-12 00:38:43 --> Language Class Initialized
INFO - 2017-03-12 00:38:43 --> URI Class Initialized
INFO - 2017-03-12 00:38:43 --> Loader Class Initialized
INFO - 2017-03-12 00:38:43 --> Router Class Initialized
INFO - 2017-03-12 00:38:43 --> Language Class Initialized
INFO - 2017-03-12 00:38:43 --> Output Class Initialized
INFO - 2017-03-12 00:38:43 --> Security Class Initialized
DEBUG - 2017-03-12 00:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:38:43 --> Input Class Initialized
INFO - 2017-03-12 00:38:43 --> Loader Class Initialized
INFO - 2017-03-12 00:38:43 --> Loader Class Initialized
INFO - 2017-03-12 00:38:43 --> Language Class Initialized
INFO - 2017-03-12 00:38:43 --> Loader Class Initialized
INFO - 2017-03-12 00:38:44 --> Database Driver Class Initialized
INFO - 2017-03-12 00:38:44 --> Database Driver Class Initialized
INFO - 2017-03-12 00:38:44 --> Database Driver Class Initialized
INFO - 2017-03-12 00:38:44 --> Database Driver Class Initialized
INFO - 2017-03-12 00:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:38:44 --> Controller Class Initialized
INFO - 2017-03-12 00:38:44 --> Helper loaded: url_helper
INFO - 2017-03-12 00:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:38:44 --> Controller Class Initialized
INFO - 2017-03-12 00:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:38:44 --> Controller Class Initialized
INFO - 2017-03-12 00:38:44 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:38:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:38:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:38:44 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:38:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:38:45 --> Final output sent to browser
INFO - 2017-03-12 00:38:45 --> Final output sent to browser
DEBUG - 2017-03-12 00:38:45 --> Total execution time: 2.8569
DEBUG - 2017-03-12 00:38:45 --> Total execution time: 2.8570
INFO - 2017-03-12 00:38:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 00:38:58 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:38:58 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:38:58 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:38:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:38:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:38:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:38:59 --> Final output sent to browser
DEBUG - 2017-03-12 00:38:59 --> Total execution time: 16.2470
INFO - 2017-03-12 00:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:38:59 --> Controller Class Initialized
INFO - 2017-03-12 00:39:00 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:39:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:39:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 00:39:03 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:39:03 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:39:03 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:39:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:39:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:39:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:39:03 --> Final output sent to browser
DEBUG - 2017-03-12 00:39:03 --> Total execution time: 19.9934
INFO - 2017-03-12 00:39:29 --> Config Class Initialized
INFO - 2017-03-12 00:39:29 --> Config Class Initialized
INFO - 2017-03-12 00:39:30 --> Hooks Class Initialized
INFO - 2017-03-12 00:39:30 --> Hooks Class Initialized
INFO - 2017-03-12 00:39:30 --> Config Class Initialized
INFO - 2017-03-12 00:39:30 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:39:30 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:39:30 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:39:30 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:39:30 --> Utf8 Class Initialized
INFO - 2017-03-12 00:39:30 --> Utf8 Class Initialized
INFO - 2017-03-12 00:39:30 --> URI Class Initialized
INFO - 2017-03-12 00:39:30 --> Utf8 Class Initialized
INFO - 2017-03-12 00:39:30 --> URI Class Initialized
INFO - 2017-03-12 00:39:30 --> URI Class Initialized
INFO - 2017-03-12 00:39:30 --> Router Class Initialized
INFO - 2017-03-12 00:39:30 --> Router Class Initialized
INFO - 2017-03-12 00:39:31 --> Router Class Initialized
INFO - 2017-03-12 00:39:31 --> Output Class Initialized
INFO - 2017-03-12 00:39:31 --> Output Class Initialized
INFO - 2017-03-12 00:39:31 --> Output Class Initialized
INFO - 2017-03-12 00:39:31 --> Security Class Initialized
INFO - 2017-03-12 00:39:31 --> Security Class Initialized
DEBUG - 2017-03-12 00:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:39:31 --> Input Class Initialized
INFO - 2017-03-12 00:39:31 --> Security Class Initialized
DEBUG - 2017-03-12 00:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:39:31 --> Language Class Initialized
DEBUG - 2017-03-12 00:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:39:31 --> Input Class Initialized
INFO - 2017-03-12 00:39:31 --> Input Class Initialized
ERROR - 2017-03-12 00:39:31 --> 404 Page Not Found: Phone/index.html
INFO - 2017-03-12 00:39:31 --> Language Class Initialized
INFO - 2017-03-12 00:39:31 --> Language Class Initialized
INFO - 2017-03-12 00:39:31 --> Loader Class Initialized
INFO - 2017-03-12 00:39:32 --> Loader Class Initialized
INFO - 2017-03-12 00:39:32 --> Database Driver Class Initialized
INFO - 2017-03-12 00:39:32 --> Database Driver Class Initialized
INFO - 2017-03-12 00:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:39:33 --> Controller Class Initialized
INFO - 2017-03-12 00:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:39:33 --> Controller Class Initialized
INFO - 2017-03-12 00:39:33 --> Helper loaded: url_helper
INFO - 2017-03-12 00:39:33 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:39:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:39:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:39:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:39:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:39:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
ERROR - 2017-03-12 00:39:36 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
INFO - 2017-03-12 00:39:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
ERROR - 2017-03-12 00:39:36 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:39:36 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:39:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:39:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:39:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:39:36 --> Config Class Initialized
INFO - 2017-03-12 00:39:36 --> Hooks Class Initialized
INFO - 2017-03-12 00:39:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:39:37 --> Config Class Initialized
INFO - 2017-03-12 00:39:37 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:39:37 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:39:37 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:39:37 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:39:37 --> Utf8 Class Initialized
INFO - 2017-03-12 00:39:37 --> Config Class Initialized
INFO - 2017-03-12 00:39:37 --> Hooks Class Initialized
INFO - 2017-03-12 00:39:37 --> URI Class Initialized
INFO - 2017-03-12 00:39:37 --> URI Class Initialized
INFO - 2017-03-12 00:39:37 --> Final output sent to browser
DEBUG - 2017-03-12 00:39:37 --> No URI present. Default controller set.
INFO - 2017-03-12 00:39:37 --> Router Class Initialized
DEBUG - 2017-03-12 00:39:37 --> No URI present. Default controller set.
INFO - 2017-03-12 00:39:37 --> Router Class Initialized
INFO - 2017-03-12 00:39:37 --> Final output sent to browser
DEBUG - 2017-03-12 00:39:37 --> Total execution time: 8.8149
DEBUG - 2017-03-12 00:39:37 --> Total execution time: 8.7119
DEBUG - 2017-03-12 00:39:37 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:39:37 --> Utf8 Class Initialized
INFO - 2017-03-12 00:39:37 --> Output Class Initialized
INFO - 2017-03-12 00:39:37 --> Output Class Initialized
INFO - 2017-03-12 00:39:38 --> URI Class Initialized
INFO - 2017-03-12 00:39:38 --> Security Class Initialized
INFO - 2017-03-12 00:39:38 --> Security Class Initialized
INFO - 2017-03-12 00:39:38 --> Router Class Initialized
DEBUG - 2017-03-12 00:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:39:38 --> Input Class Initialized
DEBUG - 2017-03-12 00:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:39:38 --> Output Class Initialized
INFO - 2017-03-12 00:39:38 --> Input Class Initialized
INFO - 2017-03-12 00:39:38 --> Language Class Initialized
INFO - 2017-03-12 00:39:38 --> Language Class Initialized
INFO - 2017-03-12 00:39:38 --> Security Class Initialized
DEBUG - 2017-03-12 00:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:39:38 --> Input Class Initialized
INFO - 2017-03-12 00:39:38 --> Language Class Initialized
INFO - 2017-03-12 00:39:38 --> Loader Class Initialized
INFO - 2017-03-12 00:39:38 --> Loader Class Initialized
INFO - 2017-03-12 00:39:38 --> Loader Class Initialized
INFO - 2017-03-12 00:39:38 --> Database Driver Class Initialized
INFO - 2017-03-12 00:39:38 --> Database Driver Class Initialized
INFO - 2017-03-12 00:39:38 --> Database Driver Class Initialized
INFO - 2017-03-12 00:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:39:39 --> Controller Class Initialized
INFO - 2017-03-12 00:39:39 --> Helper loaded: url_helper
INFO - 2017-03-12 00:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:39:39 --> Controller Class Initialized
INFO - 2017-03-12 00:39:39 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:39:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:39:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:39:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:39:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:39:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:39:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:39:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:39:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:39:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:39:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:39:40 --> Final output sent to browser
DEBUG - 2017-03-12 00:39:40 --> Total execution time: 3.1368
INFO - 2017-03-12 00:39:40 --> Final output sent to browser
DEBUG - 2017-03-12 00:39:40 --> Total execution time: 3.1283
INFO - 2017-03-12 00:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:39:41 --> Controller Class Initialized
INFO - 2017-03-12 00:39:41 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:39:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:39:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 00:39:42 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:39:42 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:39:42 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:39:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:39:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:39:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:39:42 --> Final output sent to browser
DEBUG - 2017-03-12 00:39:42 --> Total execution time: 5.5637
INFO - 2017-03-12 00:39:51 --> Config Class Initialized
INFO - 2017-03-12 00:39:51 --> Config Class Initialized
INFO - 2017-03-12 00:39:51 --> Hooks Class Initialized
INFO - 2017-03-12 00:39:51 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:39:51 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:39:51 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:39:51 --> Utf8 Class Initialized
INFO - 2017-03-12 00:39:51 --> Utf8 Class Initialized
INFO - 2017-03-12 00:39:51 --> URI Class Initialized
INFO - 2017-03-12 00:39:51 --> URI Class Initialized
INFO - 2017-03-12 00:39:51 --> Router Class Initialized
INFO - 2017-03-12 00:39:51 --> Router Class Initialized
INFO - 2017-03-12 00:39:51 --> Output Class Initialized
INFO - 2017-03-12 00:39:51 --> Output Class Initialized
INFO - 2017-03-12 00:39:51 --> Security Class Initialized
INFO - 2017-03-12 00:39:51 --> Security Class Initialized
DEBUG - 2017-03-12 00:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:39:51 --> Input Class Initialized
INFO - 2017-03-12 00:39:51 --> Language Class Initialized
DEBUG - 2017-03-12 00:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:39:51 --> Input Class Initialized
INFO - 2017-03-12 00:39:51 --> Language Class Initialized
INFO - 2017-03-12 00:39:51 --> Loader Class Initialized
INFO - 2017-03-12 00:39:51 --> Loader Class Initialized
INFO - 2017-03-12 00:39:51 --> Database Driver Class Initialized
INFO - 2017-03-12 00:39:51 --> Database Driver Class Initialized
INFO - 2017-03-12 00:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:39:51 --> Controller Class Initialized
INFO - 2017-03-12 00:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:39:51 --> Helper loaded: url_helper
INFO - 2017-03-12 00:39:51 --> Controller Class Initialized
INFO - 2017-03-12 00:39:51 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:39:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:39:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:39:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:39:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:39:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:39:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:39:52 --> Final output sent to browser
DEBUG - 2017-03-12 00:39:52 --> Total execution time: 1.4182
INFO - 2017-03-12 00:40:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 00:40:04 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:40:04 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:40:04 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:40:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:40:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:40:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:40:05 --> Final output sent to browser
DEBUG - 2017-03-12 00:40:05 --> Total execution time: 13.7201
INFO - 2017-03-12 00:40:09 --> Config Class Initialized
INFO - 2017-03-12 00:40:09 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:40:09 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:40:09 --> Utf8 Class Initialized
INFO - 2017-03-12 00:40:09 --> URI Class Initialized
INFO - 2017-03-12 00:40:09 --> Router Class Initialized
INFO - 2017-03-12 00:40:09 --> Output Class Initialized
INFO - 2017-03-12 00:40:09 --> Security Class Initialized
DEBUG - 2017-03-12 00:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:40:09 --> Input Class Initialized
INFO - 2017-03-12 00:40:09 --> Language Class Initialized
INFO - 2017-03-12 00:40:09 --> Loader Class Initialized
INFO - 2017-03-12 00:40:10 --> Database Driver Class Initialized
INFO - 2017-03-12 00:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:40:10 --> Controller Class Initialized
INFO - 2017-03-12 00:40:10 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:40:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:40:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 00:40:11 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:40:11 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:40:11 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:40:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:40:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:40:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:40:11 --> Final output sent to browser
DEBUG - 2017-03-12 00:40:11 --> Total execution time: 1.7592
INFO - 2017-03-12 00:40:26 --> Config Class Initialized
INFO - 2017-03-12 00:40:26 --> Config Class Initialized
INFO - 2017-03-12 00:40:26 --> Hooks Class Initialized
INFO - 2017-03-12 00:40:26 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:40:26 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:40:26 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:40:26 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:40:26 --> URI Class Initialized
INFO - 2017-03-12 00:40:26 --> Utf8 Class Initialized
INFO - 2017-03-12 00:40:26 --> URI Class Initialized
INFO - 2017-03-12 00:40:26 --> Router Class Initialized
INFO - 2017-03-12 00:40:26 --> Router Class Initialized
INFO - 2017-03-12 00:40:26 --> Output Class Initialized
INFO - 2017-03-12 00:40:26 --> Output Class Initialized
INFO - 2017-03-12 00:40:26 --> Security Class Initialized
INFO - 2017-03-12 00:40:26 --> Security Class Initialized
DEBUG - 2017-03-12 00:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:40:26 --> Input Class Initialized
INFO - 2017-03-12 00:40:26 --> Language Class Initialized
DEBUG - 2017-03-12 00:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:40:26 --> Input Class Initialized
INFO - 2017-03-12 00:40:26 --> Language Class Initialized
INFO - 2017-03-12 00:40:27 --> Loader Class Initialized
INFO - 2017-03-12 00:40:27 --> Loader Class Initialized
INFO - 2017-03-12 00:40:27 --> Database Driver Class Initialized
INFO - 2017-03-12 00:40:27 --> Database Driver Class Initialized
INFO - 2017-03-12 00:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:40:27 --> Controller Class Initialized
INFO - 2017-03-12 00:40:27 --> Controller Class Initialized
INFO - 2017-03-12 00:40:27 --> Helper loaded: url_helper
INFO - 2017-03-12 00:40:27 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:40:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:40:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:40:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:40:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:40:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:40:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:40:28 --> Final output sent to browser
DEBUG - 2017-03-12 00:40:28 --> Total execution time: 2.3542
INFO - 2017-03-12 00:40:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 00:40:42 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:40:42 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:40:42 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:40:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:40:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:40:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:40:43 --> Final output sent to browser
DEBUG - 2017-03-12 00:40:43 --> Total execution time: 16.3232
INFO - 2017-03-12 00:40:50 --> Config Class Initialized
INFO - 2017-03-12 00:40:50 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:40:51 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:40:51 --> Utf8 Class Initialized
INFO - 2017-03-12 00:40:51 --> URI Class Initialized
DEBUG - 2017-03-12 00:40:51 --> No URI present. Default controller set.
INFO - 2017-03-12 00:40:51 --> Router Class Initialized
INFO - 2017-03-12 00:40:51 --> Output Class Initialized
INFO - 2017-03-12 00:40:51 --> Security Class Initialized
DEBUG - 2017-03-12 00:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:40:51 --> Input Class Initialized
INFO - 2017-03-12 00:40:51 --> Language Class Initialized
INFO - 2017-03-12 00:40:51 --> Loader Class Initialized
INFO - 2017-03-12 00:40:52 --> Database Driver Class Initialized
INFO - 2017-03-12 00:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:40:53 --> Controller Class Initialized
INFO - 2017-03-12 00:40:53 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:40:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:40:53 --> Config Class Initialized
INFO - 2017-03-12 00:40:53 --> Hooks Class Initialized
INFO - 2017-03-12 00:40:53 --> Config Class Initialized
INFO - 2017-03-12 00:40:53 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:40:53 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:40:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:40:53 --> Utf8 Class Initialized
INFO - 2017-03-12 00:40:53 --> URI Class Initialized
DEBUG - 2017-03-12 00:40:54 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:40:54 --> Utf8 Class Initialized
INFO - 2017-03-12 00:40:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:40:54 --> URI Class Initialized
DEBUG - 2017-03-12 00:40:54 --> No URI present. Default controller set.
INFO - 2017-03-12 00:40:54 --> Router Class Initialized
INFO - 2017-03-12 00:40:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:40:54 --> Router Class Initialized
INFO - 2017-03-12 00:40:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:40:55 --> Output Class Initialized
INFO - 2017-03-12 00:40:55 --> Output Class Initialized
INFO - 2017-03-12 00:40:55 --> Security Class Initialized
INFO - 2017-03-12 00:40:55 --> Final output sent to browser
DEBUG - 2017-03-12 00:40:55 --> Total execution time: 5.4070
DEBUG - 2017-03-12 00:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:40:55 --> Input Class Initialized
INFO - 2017-03-12 00:40:55 --> Security Class Initialized
INFO - 2017-03-12 00:40:55 --> Language Class Initialized
DEBUG - 2017-03-12 00:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:40:55 --> Input Class Initialized
INFO - 2017-03-12 00:40:55 --> Language Class Initialized
INFO - 2017-03-12 00:40:58 --> Loader Class Initialized
INFO - 2017-03-12 00:40:58 --> Loader Class Initialized
INFO - 2017-03-12 00:40:58 --> Database Driver Class Initialized
INFO - 2017-03-12 00:40:58 --> Database Driver Class Initialized
INFO - 2017-03-12 00:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:40:58 --> Controller Class Initialized
INFO - 2017-03-12 00:40:58 --> Controller Class Initialized
INFO - 2017-03-12 00:40:58 --> Helper loaded: url_helper
INFO - 2017-03-12 00:40:58 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:40:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:40:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:40:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:40:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:40:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:40:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:40:59 --> Final output sent to browser
DEBUG - 2017-03-12 00:40:59 --> Total execution time: 6.4012
INFO - 2017-03-12 00:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 00:41:15 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:41:15 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:41:15 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:41:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:41:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:41:16 --> Final output sent to browser
DEBUG - 2017-03-12 00:41:16 --> Total execution time: 23.4089
INFO - 2017-03-12 00:41:21 --> Config Class Initialized
INFO - 2017-03-12 00:41:21 --> Hooks Class Initialized
INFO - 2017-03-12 00:41:21 --> Config Class Initialized
INFO - 2017-03-12 00:41:21 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:41:21 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:41:21 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:41:22 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:41:22 --> Utf8 Class Initialized
INFO - 2017-03-12 00:41:22 --> URI Class Initialized
INFO - 2017-03-12 00:41:22 --> URI Class Initialized
INFO - 2017-03-12 00:41:22 --> Router Class Initialized
INFO - 2017-03-12 00:41:22 --> Router Class Initialized
INFO - 2017-03-12 00:41:22 --> Output Class Initialized
INFO - 2017-03-12 00:41:22 --> Output Class Initialized
INFO - 2017-03-12 00:41:23 --> Security Class Initialized
INFO - 2017-03-12 00:41:23 --> Security Class Initialized
DEBUG - 2017-03-12 00:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-03-12 00:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:41:23 --> Input Class Initialized
INFO - 2017-03-12 00:41:23 --> Input Class Initialized
INFO - 2017-03-12 00:41:23 --> Language Class Initialized
INFO - 2017-03-12 00:41:23 --> Language Class Initialized
INFO - 2017-03-12 00:41:24 --> Loader Class Initialized
INFO - 2017-03-12 00:41:24 --> Loader Class Initialized
INFO - 2017-03-12 00:41:25 --> Database Driver Class Initialized
INFO - 2017-03-12 00:41:26 --> Database Driver Class Initialized
INFO - 2017-03-12 00:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:41:26 --> Controller Class Initialized
INFO - 2017-03-12 00:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:41:27 --> Controller Class Initialized
INFO - 2017-03-12 00:41:27 --> Helper loaded: url_helper
INFO - 2017-03-12 00:41:27 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:41:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:41:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:41:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:41:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:41:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:41:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:41:29 --> Final output sent to browser
DEBUG - 2017-03-12 00:41:29 --> Total execution time: 7.7765
INFO - 2017-03-12 00:41:33 --> Config Class Initialized
INFO - 2017-03-12 00:41:33 --> Config Class Initialized
INFO - 2017-03-12 00:41:33 --> Hooks Class Initialized
INFO - 2017-03-12 00:41:33 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:41:33 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:41:33 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:41:33 --> Utf8 Class Initialized
INFO - 2017-03-12 00:41:33 --> Utf8 Class Initialized
INFO - 2017-03-12 00:41:33 --> URI Class Initialized
INFO - 2017-03-12 00:41:33 --> URI Class Initialized
INFO - 2017-03-12 00:41:33 --> Router Class Initialized
INFO - 2017-03-12 00:41:33 --> Router Class Initialized
INFO - 2017-03-12 00:41:33 --> Output Class Initialized
INFO - 2017-03-12 00:41:33 --> Output Class Initialized
INFO - 2017-03-12 00:41:33 --> Security Class Initialized
INFO - 2017-03-12 00:41:33 --> Security Class Initialized
DEBUG - 2017-03-12 00:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:41:34 --> Input Class Initialized
INFO - 2017-03-12 00:41:34 --> Language Class Initialized
DEBUG - 2017-03-12 00:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:41:34 --> Input Class Initialized
INFO - 2017-03-12 00:41:34 --> Language Class Initialized
INFO - 2017-03-12 00:41:34 --> Loader Class Initialized
INFO - 2017-03-12 00:41:34 --> Loader Class Initialized
INFO - 2017-03-12 00:41:34 --> Config Class Initialized
INFO - 2017-03-12 00:41:34 --> Hooks Class Initialized
INFO - 2017-03-12 00:41:34 --> Config Class Initialized
INFO - 2017-03-12 00:41:34 --> Config Class Initialized
DEBUG - 2017-03-12 00:41:34 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:41:34 --> Hooks Class Initialized
INFO - 2017-03-12 00:41:34 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:41:34 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:41:34 --> Database Driver Class Initialized
INFO - 2017-03-12 00:41:34 --> Utf8 Class Initialized
INFO - 2017-03-12 00:41:34 --> URI Class Initialized
INFO - 2017-03-12 00:41:34 --> URI Class Initialized
INFO - 2017-03-12 00:41:34 --> Router Class Initialized
INFO - 2017-03-12 00:41:34 --> Router Class Initialized
INFO - 2017-03-12 00:41:34 --> Output Class Initialized
INFO - 2017-03-12 00:41:34 --> Output Class Initialized
INFO - 2017-03-12 00:41:34 --> Security Class Initialized
INFO - 2017-03-12 00:41:34 --> Security Class Initialized
DEBUG - 2017-03-12 00:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:41:34 --> Input Class Initialized
INFO - 2017-03-12 00:41:34 --> Language Class Initialized
DEBUG - 2017-03-12 00:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:41:34 --> Input Class Initialized
INFO - 2017-03-12 00:41:34 --> Language Class Initialized
INFO - 2017-03-12 00:41:34 --> Loader Class Initialized
INFO - 2017-03-12 00:41:34 --> Loader Class Initialized
INFO - 2017-03-12 00:41:34 --> Database Driver Class Initialized
INFO - 2017-03-12 00:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:41:34 --> Hooks Class Initialized
INFO - 2017-03-12 00:41:34 --> Database Driver Class Initialized
DEBUG - 2017-03-12 00:41:34 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:41:35 --> Utf8 Class Initialized
INFO - 2017-03-12 00:41:35 --> Database Driver Class Initialized
INFO - 2017-03-12 00:41:35 --> URI Class Initialized
INFO - 2017-03-12 00:41:35 --> Controller Class Initialized
INFO - 2017-03-12 00:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:41:35 --> Router Class Initialized
INFO - 2017-03-12 00:41:35 --> Helper loaded: url_helper
INFO - 2017-03-12 00:41:35 --> Controller Class Initialized
INFO - 2017-03-12 00:41:35 --> Output Class Initialized
INFO - 2017-03-12 00:41:35 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:41:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:41:35 --> Security Class Initialized
DEBUG - 2017-03-12 00:41:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:41:35 --> Input Class Initialized
INFO - 2017-03-12 00:41:36 --> Language Class Initialized
INFO - 2017-03-12 00:41:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:41:36 --> Loader Class Initialized
ERROR - 2017-03-12 00:41:36 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:41:36 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:41:37 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:41:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:41:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:41:37 --> Database Driver Class Initialized
INFO - 2017-03-12 00:41:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:41:37 --> Final output sent to browser
DEBUG - 2017-03-12 00:41:37 --> Total execution time: 5.1167
INFO - 2017-03-12 00:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:41:38 --> Controller Class Initialized
INFO - 2017-03-12 00:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:41:38 --> Controller Class Initialized
INFO - 2017-03-12 00:41:38 --> Helper loaded: url_helper
INFO - 2017-03-12 00:41:39 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:41:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:41:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:41:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 00:41:39 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:41:40 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:41:40 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:41:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:41:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:41:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:41:40 --> Final output sent to browser
DEBUG - 2017-03-12 00:41:41 --> Total execution time: 8.0304
INFO - 2017-03-12 00:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:41:41 --> Controller Class Initialized
INFO - 2017-03-12 00:41:41 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:41:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:41:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 00:41:42 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:41:43 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:41:43 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:41:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:41:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:41:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:41:44 --> Final output sent to browser
DEBUG - 2017-03-12 00:41:44 --> Total execution time: 11.3034
INFO - 2017-03-12 00:41:45 --> Config Class Initialized
INFO - 2017-03-12 00:41:45 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:41:45 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:41:45 --> Utf8 Class Initialized
INFO - 2017-03-12 00:41:46 --> URI Class Initialized
INFO - 2017-03-12 00:41:46 --> Router Class Initialized
INFO - 2017-03-12 00:41:46 --> Output Class Initialized
INFO - 2017-03-12 00:41:47 --> Security Class Initialized
DEBUG - 2017-03-12 00:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:41:47 --> Input Class Initialized
INFO - 2017-03-12 00:41:47 --> Language Class Initialized
INFO - 2017-03-12 00:41:47 --> Loader Class Initialized
INFO - 2017-03-12 00:41:47 --> Database Driver Class Initialized
INFO - 2017-03-12 00:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:41:48 --> Controller Class Initialized
INFO - 2017-03-12 00:41:48 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:41:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:41:49 --> Helper loaded: url_helper
INFO - 2017-03-12 00:41:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:41:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 00:41:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 00:41:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 00:41:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:41:53 --> Final output sent to browser
DEBUG - 2017-03-12 00:41:53 --> Total execution time: 10.9158
ERROR - 2017-03-12 00:41:59 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-12 00:42:01 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Scarlett Osborn')
INFO - 2017-03-12 00:42:01 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-12 00:42:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-12 00:42:11 --> Config Class Initialized
INFO - 2017-03-12 00:42:11 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:42:11 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:42:11 --> Utf8 Class Initialized
INFO - 2017-03-12 00:42:11 --> URI Class Initialized
INFO - 2017-03-12 00:42:12 --> Router Class Initialized
INFO - 2017-03-12 00:42:12 --> Output Class Initialized
INFO - 2017-03-12 00:42:12 --> Security Class Initialized
INFO - 2017-03-12 00:42:12 --> Config Class Initialized
DEBUG - 2017-03-12 00:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:42:12 --> Hooks Class Initialized
INFO - 2017-03-12 00:42:12 --> Input Class Initialized
INFO - 2017-03-12 00:42:12 --> Language Class Initialized
INFO - 2017-03-12 00:42:12 --> Loader Class Initialized
INFO - 2017-03-12 00:42:12 --> Config Class Initialized
INFO - 2017-03-12 00:42:12 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:42:12 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:42:12 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:42:12 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:42:12 --> URI Class Initialized
INFO - 2017-03-12 00:42:12 --> Utf8 Class Initialized
INFO - 2017-03-12 00:42:12 --> URI Class Initialized
INFO - 2017-03-12 00:42:12 --> Config Class Initialized
INFO - 2017-03-12 00:42:12 --> Router Class Initialized
INFO - 2017-03-12 00:42:12 --> Hooks Class Initialized
INFO - 2017-03-12 00:42:12 --> Router Class Initialized
DEBUG - 2017-03-12 00:42:12 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:42:12 --> Output Class Initialized
INFO - 2017-03-12 00:42:12 --> Utf8 Class Initialized
INFO - 2017-03-12 00:42:12 --> Output Class Initialized
INFO - 2017-03-12 00:42:12 --> URI Class Initialized
INFO - 2017-03-12 00:42:12 --> Security Class Initialized
INFO - 2017-03-12 00:42:12 --> Security Class Initialized
INFO - 2017-03-12 00:42:12 --> Database Driver Class Initialized
INFO - 2017-03-12 00:42:12 --> Config Class Initialized
DEBUG - 2017-03-12 00:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-03-12 00:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:42:12 --> Hooks Class Initialized
INFO - 2017-03-12 00:42:13 --> Input Class Initialized
INFO - 2017-03-12 00:42:13 --> Input Class Initialized
INFO - 2017-03-12 00:42:13 --> Language Class Initialized
DEBUG - 2017-03-12 00:42:13 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:42:13 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:42:13 --> No URI present. Default controller set.
INFO - 2017-03-12 00:42:13 --> URI Class Initialized
INFO - 2017-03-12 00:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:42:13 --> Router Class Initialized
INFO - 2017-03-12 00:42:13 --> Language Class Initialized
INFO - 2017-03-12 00:42:13 --> Router Class Initialized
INFO - 2017-03-12 00:42:13 --> Controller Class Initialized
INFO - 2017-03-12 00:42:13 --> Output Class Initialized
INFO - 2017-03-12 00:42:13 --> Output Class Initialized
INFO - 2017-03-12 00:42:13 --> Loader Class Initialized
INFO - 2017-03-12 00:42:13 --> Security Class Initialized
INFO - 2017-03-12 00:42:13 --> Loader Class Initialized
INFO - 2017-03-12 00:42:13 --> Helper loaded: url_helper
INFO - 2017-03-12 00:42:13 --> Security Class Initialized
DEBUG - 2017-03-12 00:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-03-12 00:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:42:13 --> Input Class Initialized
DEBUG - 2017-03-12 00:42:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:42:13 --> Database Driver Class Initialized
INFO - 2017-03-12 00:42:13 --> Input Class Initialized
INFO - 2017-03-12 00:42:13 --> Database Driver Class Initialized
INFO - 2017-03-12 00:42:13 --> Language Class Initialized
INFO - 2017-03-12 00:42:13 --> Language Class Initialized
INFO - 2017-03-12 00:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:42:14 --> Loader Class Initialized
INFO - 2017-03-12 00:42:14 --> Controller Class Initialized
INFO - 2017-03-12 00:42:14 --> Database Driver Class Initialized
INFO - 2017-03-12 00:42:14 --> Loader Class Initialized
INFO - 2017-03-12 00:42:14 --> Database Driver Class Initialized
INFO - 2017-03-12 00:42:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:42:14 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:42:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:42:15 --> Controller Class Initialized
INFO - 2017-03-12 00:42:15 --> Helper loaded: url_helper
INFO - 2017-03-12 00:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:42:15 --> Helper loaded: url_helper
INFO - 2017-03-12 00:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:42:15 --> Controller Class Initialized
DEBUG - 2017-03-12 00:42:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:42:15 --> Helper loaded: url_helper
INFO - 2017-03-12 00:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
DEBUG - 2017-03-12 00:42:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-12 00:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 00:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:42:15 --> Final output sent to browser
DEBUG - 2017-03-12 00:42:15 --> Total execution time: 3.5083
INFO - 2017-03-12 00:42:15 --> Final output sent to browser
INFO - 2017-03-12 00:42:15 --> Final output sent to browser
DEBUG - 2017-03-12 00:42:15 --> Total execution time: 3.5075
INFO - 2017-03-12 00:42:15 --> Final output sent to browser
DEBUG - 2017-03-12 00:42:15 --> Total execution time: 3.5321
INFO - 2017-03-12 00:42:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-03-12 00:42:15 --> Total execution time: 3.5317
INFO - 2017-03-12 00:42:15 --> Controller Class Initialized
INFO - 2017-03-12 00:42:16 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:42:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:42:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:42:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:42:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:42:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:42:17 --> Final output sent to browser
DEBUG - 2017-03-12 00:42:17 --> Total execution time: 5.8765
INFO - 2017-03-12 00:42:21 --> Config Class Initialized
INFO - 2017-03-12 00:42:21 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:42:21 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:42:21 --> Utf8 Class Initialized
INFO - 2017-03-12 00:42:21 --> URI Class Initialized
INFO - 2017-03-12 00:42:22 --> Router Class Initialized
INFO - 2017-03-12 00:42:22 --> Output Class Initialized
INFO - 2017-03-12 00:42:22 --> Security Class Initialized
DEBUG - 2017-03-12 00:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:42:22 --> Input Class Initialized
INFO - 2017-03-12 00:42:22 --> Language Class Initialized
INFO - 2017-03-12 00:42:22 --> Loader Class Initialized
INFO - 2017-03-12 00:42:22 --> Database Driver Class Initialized
INFO - 2017-03-12 00:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:42:23 --> Controller Class Initialized
INFO - 2017-03-12 00:42:23 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:42:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:42:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:42:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:42:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:42:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:42:25 --> Final output sent to browser
DEBUG - 2017-03-12 00:42:25 --> Total execution time: 3.4459
INFO - 2017-03-12 00:42:34 --> Config Class Initialized
INFO - 2017-03-12 00:42:34 --> Hooks Class Initialized
INFO - 2017-03-12 00:42:34 --> Config Class Initialized
INFO - 2017-03-12 00:42:34 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:42:34 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:42:34 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:42:34 --> Utf8 Class Initialized
INFO - 2017-03-12 00:42:34 --> Utf8 Class Initialized
INFO - 2017-03-12 00:42:34 --> URI Class Initialized
INFO - 2017-03-12 00:42:34 --> URI Class Initialized
INFO - 2017-03-12 00:42:34 --> Config Class Initialized
INFO - 2017-03-12 00:42:34 --> Router Class Initialized
INFO - 2017-03-12 00:42:34 --> Hooks Class Initialized
INFO - 2017-03-12 00:42:34 --> Router Class Initialized
DEBUG - 2017-03-12 00:42:34 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:42:34 --> Output Class Initialized
INFO - 2017-03-12 00:42:34 --> Utf8 Class Initialized
INFO - 2017-03-12 00:42:34 --> Output Class Initialized
INFO - 2017-03-12 00:42:34 --> URI Class Initialized
INFO - 2017-03-12 00:42:34 --> Security Class Initialized
INFO - 2017-03-12 00:42:34 --> Security Class Initialized
INFO - 2017-03-12 00:42:34 --> Router Class Initialized
DEBUG - 2017-03-12 00:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:42:34 --> Input Class Initialized
INFO - 2017-03-12 00:42:34 --> Language Class Initialized
DEBUG - 2017-03-12 00:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:42:35 --> Output Class Initialized
INFO - 2017-03-12 00:42:35 --> Input Class Initialized
INFO - 2017-03-12 00:42:35 --> Security Class Initialized
INFO - 2017-03-12 00:42:35 --> Language Class Initialized
INFO - 2017-03-12 00:42:35 --> Loader Class Initialized
DEBUG - 2017-03-12 00:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:42:35 --> Loader Class Initialized
INFO - 2017-03-12 00:42:35 --> Input Class Initialized
INFO - 2017-03-12 00:42:35 --> Language Class Initialized
INFO - 2017-03-12 00:42:35 --> Loader Class Initialized
INFO - 2017-03-12 00:42:35 --> Database Driver Class Initialized
INFO - 2017-03-12 00:42:35 --> Database Driver Class Initialized
INFO - 2017-03-12 00:42:35 --> Database Driver Class Initialized
INFO - 2017-03-12 00:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:42:35 --> Controller Class Initialized
INFO - 2017-03-12 00:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:42:36 --> Controller Class Initialized
INFO - 2017-03-12 00:42:36 --> Helper loaded: url_helper
INFO - 2017-03-12 00:42:36 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:42:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:42:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:42:48 --> Controller Class Initialized
INFO - 2017-03-12 00:42:50 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:42:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:42:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:42:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:42:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:42:57 --> Final output sent to browser
DEBUG - 2017-03-12 00:42:58 --> Total execution time: 23.3272
INFO - 2017-03-12 00:43:06 --> Config Class Initialized
INFO - 2017-03-12 00:43:06 --> Hooks Class Initialized
INFO - 2017-03-12 00:43:07 --> Config Class Initialized
INFO - 2017-03-12 00:43:07 --> Hooks Class Initialized
INFO - 2017-03-12 00:43:07 --> Config Class Initialized
INFO - 2017-03-12 00:43:07 --> Hooks Class Initialized
INFO - 2017-03-12 00:43:07 --> Config Class Initialized
INFO - 2017-03-12 00:43:07 --> Hooks Class Initialized
INFO - 2017-03-12 00:43:07 --> Config Class Initialized
INFO - 2017-03-12 00:43:07 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:43:07 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:43:07 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:43:07 --> Config Class Initialized
INFO - 2017-03-12 00:43:07 --> Utf8 Class Initialized
INFO - 2017-03-12 00:43:07 --> Utf8 Class Initialized
INFO - 2017-03-12 00:43:07 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:43:07 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:43:07 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:43:07 --> URI Class Initialized
INFO - 2017-03-12 00:43:07 --> Utf8 Class Initialized
INFO - 2017-03-12 00:43:07 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:43:07 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:43:07 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:43:07 --> URI Class Initialized
INFO - 2017-03-12 00:43:07 --> URI Class Initialized
INFO - 2017-03-12 00:43:07 --> Utf8 Class Initialized
INFO - 2017-03-12 00:43:07 --> Utf8 Class Initialized
INFO - 2017-03-12 00:43:07 --> URI Class Initialized
INFO - 2017-03-12 00:43:07 --> URI Class Initialized
INFO - 2017-03-12 00:43:07 --> Router Class Initialized
INFO - 2017-03-12 00:43:07 --> Router Class Initialized
INFO - 2017-03-12 00:43:07 --> Router Class Initialized
INFO - 2017-03-12 00:43:07 --> Router Class Initialized
INFO - 2017-03-12 00:43:07 --> Output Class Initialized
INFO - 2017-03-12 00:43:07 --> Router Class Initialized
INFO - 2017-03-12 00:43:07 --> Output Class Initialized
INFO - 2017-03-12 00:43:07 --> Output Class Initialized
INFO - 2017-03-12 00:43:07 --> URI Class Initialized
INFO - 2017-03-12 00:43:07 --> Security Class Initialized
INFO - 2017-03-12 00:43:07 --> Security Class Initialized
INFO - 2017-03-12 00:43:07 --> Router Class Initialized
DEBUG - 2017-03-12 00:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:43:07 --> Security Class Initialized
INFO - 2017-03-12 00:43:07 --> Input Class Initialized
INFO - 2017-03-12 00:43:07 --> Language Class Initialized
INFO - 2017-03-12 00:43:07 --> Output Class Initialized
DEBUG - 2017-03-12 00:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:43:07 --> Security Class Initialized
DEBUG - 2017-03-12 00:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:43:07 --> Input Class Initialized
INFO - 2017-03-12 00:43:07 --> Input Class Initialized
INFO - 2017-03-12 00:43:07 --> Language Class Initialized
INFO - 2017-03-12 00:43:07 --> Language Class Initialized
DEBUG - 2017-03-12 00:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:43:07 --> Input Class Initialized
INFO - 2017-03-12 00:43:07 --> Language Class Initialized
INFO - 2017-03-12 00:43:07 --> Output Class Initialized
INFO - 2017-03-12 00:43:07 --> Security Class Initialized
DEBUG - 2017-03-12 00:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:43:07 --> Input Class Initialized
INFO - 2017-03-12 00:43:07 --> Language Class Initialized
INFO - 2017-03-12 00:43:07 --> Output Class Initialized
INFO - 2017-03-12 00:43:07 --> Security Class Initialized
DEBUG - 2017-03-12 00:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:43:07 --> Input Class Initialized
INFO - 2017-03-12 00:43:07 --> Language Class Initialized
INFO - 2017-03-12 00:43:07 --> Loader Class Initialized
INFO - 2017-03-12 00:43:07 --> Loader Class Initialized
INFO - 2017-03-12 00:43:07 --> Loader Class Initialized
INFO - 2017-03-12 00:43:07 --> Loader Class Initialized
INFO - 2017-03-12 00:43:07 --> Loader Class Initialized
INFO - 2017-03-12 00:43:07 --> Loader Class Initialized
INFO - 2017-03-12 00:43:08 --> Database Driver Class Initialized
INFO - 2017-03-12 00:43:08 --> Database Driver Class Initialized
INFO - 2017-03-12 00:43:08 --> Database Driver Class Initialized
INFO - 2017-03-12 00:43:08 --> Database Driver Class Initialized
INFO - 2017-03-12 00:43:08 --> Database Driver Class Initialized
INFO - 2017-03-12 00:43:08 --> Database Driver Class Initialized
INFO - 2017-03-12 00:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:43:08 --> Controller Class Initialized
INFO - 2017-03-12 00:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:43:08 --> Controller Class Initialized
INFO - 2017-03-12 00:43:08 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:43:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:43:08 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:43:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:43:09 --> Controller Class Initialized
INFO - 2017-03-12 00:43:09 --> Helper loaded: url_helper
INFO - 2017-03-12 00:43:09 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:43:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:43:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:43:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 00:43:09 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
INFO - 2017-03-12 00:43:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
ERROR - 2017-03-12 00:43:09 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:43:09 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:43:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 00:43:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:43:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 00:43:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:43:09 --> Final output sent to browser
INFO - 2017-03-12 00:43:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
DEBUG - 2017-03-12 00:43:09 --> Total execution time: 5.2037
INFO - 2017-03-12 00:43:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:43:09 --> Final output sent to browser
DEBUG - 2017-03-12 00:43:10 --> Total execution time: 5.3289
ERROR - 2017-03-12 00:43:20 --> Severity: error --> Exception: timed out before SSL handshake /home/graduafe/public_html/application/libraries/facebook-api-php-codexworld/base_facebook.php 972
INFO - 2017-03-12 00:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:43:22 --> Controller Class Initialized
INFO - 2017-03-12 00:43:22 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:43:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-12 00:43:41 --> Severity: error --> Exception: Operation timed out after 16580 milliseconds with 0 out of 0 bytes received /home/graduafe/public_html/application/libraries/facebook-api-php-codexworld/base_facebook.php 972
INFO - 2017-03-12 00:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:43:42 --> Controller Class Initialized
INFO - 2017-03-12 00:43:43 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:43:48 --> Config Class Initialized
INFO - 2017-03-12 00:43:48 --> Hooks Class Initialized
INFO - 2017-03-12 00:43:48 --> Config Class Initialized
INFO - 2017-03-12 00:43:48 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:43:48 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:43:48 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:43:48 --> Utf8 Class Initialized
INFO - 2017-03-12 00:43:48 --> Utf8 Class Initialized
INFO - 2017-03-12 00:43:48 --> URI Class Initialized
INFO - 2017-03-12 00:43:48 --> URI Class Initialized
INFO - 2017-03-12 00:43:48 --> Router Class Initialized
INFO - 2017-03-12 00:43:48 --> Router Class Initialized
INFO - 2017-03-12 00:43:48 --> Output Class Initialized
INFO - 2017-03-12 00:43:48 --> Output Class Initialized
INFO - 2017-03-12 00:43:48 --> Security Class Initialized
INFO - 2017-03-12 00:43:48 --> Security Class Initialized
DEBUG - 2017-03-12 00:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:43:48 --> Input Class Initialized
DEBUG - 2017-03-12 00:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:43:48 --> Input Class Initialized
INFO - 2017-03-12 00:43:48 --> Language Class Initialized
INFO - 2017-03-12 00:43:48 --> Language Class Initialized
INFO - 2017-03-12 00:43:48 --> Loader Class Initialized
INFO - 2017-03-12 00:43:48 --> Loader Class Initialized
INFO - 2017-03-12 00:43:49 --> Database Driver Class Initialized
INFO - 2017-03-12 00:43:49 --> Database Driver Class Initialized
INFO - 2017-03-12 00:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:43:49 --> Controller Class Initialized
INFO - 2017-03-12 00:43:49 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:43:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:43:49 --> Final output sent to browser
DEBUG - 2017-03-12 00:43:50 --> Total execution time: 5.3329
ERROR - 2017-03-12 00:43:51 --> Severity: Warning --> Error while sending QUERY packet. PID=662338 /home/graduafe/public_html/system/database/drivers/mysqli/mysqli_driver.php 306
ERROR - 2017-03-12 00:43:51 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_persona`
WHERE `correo` = 'gaby221195@hotmail.com'
INFO - 2017-03-12 00:43:51 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-12 00:43:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-12 00:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:43:51 --> Controller Class Initialized
INFO - 2017-03-12 00:43:51 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:43:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-12 00:43:57 --> Severity: Warning --> Error while sending QUERY packet. PID=662341 /home/graduafe/public_html/system/database/drivers/mysqli/mysqli_driver.php 306
ERROR - 2017-03-12 00:43:57 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_persona`
WHERE `correo` = 'gaby221195@hotmail.com'
INFO - 2017-03-12 00:43:57 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-12 00:43:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-12 00:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:43:57 --> Controller Class Initialized
INFO - 2017-03-12 00:43:57 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:43:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:44:25 --> Config Class Initialized
INFO - 2017-03-12 00:44:25 --> Hooks Class Initialized
INFO - 2017-03-12 00:44:25 --> Config Class Initialized
INFO - 2017-03-12 00:44:25 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:44:25 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:44:25 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:44:25 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:44:25 --> Utf8 Class Initialized
INFO - 2017-03-12 00:44:25 --> URI Class Initialized
INFO - 2017-03-12 00:44:25 --> URI Class Initialized
INFO - 2017-03-12 00:44:26 --> Router Class Initialized
INFO - 2017-03-12 00:44:26 --> Router Class Initialized
INFO - 2017-03-12 00:44:26 --> Output Class Initialized
INFO - 2017-03-12 00:44:26 --> Output Class Initialized
INFO - 2017-03-12 00:44:26 --> Security Class Initialized
INFO - 2017-03-12 00:44:26 --> Security Class Initialized
DEBUG - 2017-03-12 00:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:44:26 --> Input Class Initialized
INFO - 2017-03-12 00:44:26 --> Language Class Initialized
DEBUG - 2017-03-12 00:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:44:26 --> Input Class Initialized
INFO - 2017-03-12 00:44:26 --> Language Class Initialized
INFO - 2017-03-12 00:44:26 --> Loader Class Initialized
INFO - 2017-03-12 00:44:26 --> Loader Class Initialized
INFO - 2017-03-12 00:44:26 --> Database Driver Class Initialized
INFO - 2017-03-12 00:44:26 --> Database Driver Class Initialized
INFO - 2017-03-12 00:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:44:28 --> Controller Class Initialized
INFO - 2017-03-12 00:44:28 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:44:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:44:28 --> Helper loaded: url_helper
INFO - 2017-03-12 00:44:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:44:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 00:44:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 00:44:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 00:44:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:44:29 --> Final output sent to browser
DEBUG - 2017-03-12 00:44:29 --> Total execution time: 3.8301
INFO - 2017-03-12 00:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:44:29 --> Controller Class Initialized
INFO - 2017-03-12 00:44:29 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:44:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:44:40 --> Config Class Initialized
INFO - 2017-03-12 00:44:40 --> Hooks Class Initialized
INFO - 2017-03-12 00:44:40 --> Config Class Initialized
INFO - 2017-03-12 00:44:40 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:44:40 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:44:40 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:44:40 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:44:40 --> URI Class Initialized
INFO - 2017-03-12 00:44:40 --> Utf8 Class Initialized
INFO - 2017-03-12 00:44:40 --> URI Class Initialized
INFO - 2017-03-12 00:44:40 --> Router Class Initialized
INFO - 2017-03-12 00:44:40 --> Router Class Initialized
INFO - 2017-03-12 00:44:40 --> Output Class Initialized
INFO - 2017-03-12 00:44:40 --> Output Class Initialized
INFO - 2017-03-12 00:44:40 --> Security Class Initialized
INFO - 2017-03-12 00:44:40 --> Security Class Initialized
DEBUG - 2017-03-12 00:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:44:41 --> Input Class Initialized
INFO - 2017-03-12 00:44:41 --> Language Class Initialized
DEBUG - 2017-03-12 00:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:44:41 --> Input Class Initialized
INFO - 2017-03-12 00:44:41 --> Language Class Initialized
INFO - 2017-03-12 00:44:41 --> Loader Class Initialized
INFO - 2017-03-12 00:44:41 --> Loader Class Initialized
INFO - 2017-03-12 00:44:41 --> Database Driver Class Initialized
INFO - 2017-03-12 00:44:41 --> Database Driver Class Initialized
INFO - 2017-03-12 00:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:44:41 --> Controller Class Initialized
INFO - 2017-03-12 00:44:41 --> Helper loaded: url_helper
INFO - 2017-03-12 00:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:44:41 --> Controller Class Initialized
INFO - 2017-03-12 00:44:41 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:44:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:44:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:44:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:44:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:44:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 00:44:42 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
INFO - 2017-03-12 00:44:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
ERROR - 2017-03-12 00:44:42 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:44:42 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:44:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:44:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:44:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:44:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:44:42 --> Final output sent to browser
DEBUG - 2017-03-12 00:44:42 --> Total execution time: 1.8800
INFO - 2017-03-12 00:44:42 --> Final output sent to browser
DEBUG - 2017-03-12 00:44:42 --> Total execution time: 1.8800
INFO - 2017-03-12 00:44:53 --> Config Class Initialized
INFO - 2017-03-12 00:44:53 --> Hooks Class Initialized
INFO - 2017-03-12 00:44:53 --> Config Class Initialized
INFO - 2017-03-12 00:44:53 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:44:53 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:44:53 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:44:53 --> Utf8 Class Initialized
INFO - 2017-03-12 00:44:54 --> URI Class Initialized
INFO - 2017-03-12 00:44:54 --> Utf8 Class Initialized
INFO - 2017-03-12 00:44:54 --> URI Class Initialized
INFO - 2017-03-12 00:44:54 --> Router Class Initialized
DEBUG - 2017-03-12 00:44:54 --> No URI present. Default controller set.
INFO - 2017-03-12 00:44:54 --> Router Class Initialized
INFO - 2017-03-12 00:44:54 --> Output Class Initialized
INFO - 2017-03-12 00:44:54 --> Output Class Initialized
INFO - 2017-03-12 00:44:54 --> Security Class Initialized
INFO - 2017-03-12 00:44:54 --> Security Class Initialized
DEBUG - 2017-03-12 00:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:44:54 --> Input Class Initialized
DEBUG - 2017-03-12 00:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:44:54 --> Language Class Initialized
INFO - 2017-03-12 00:44:54 --> Input Class Initialized
INFO - 2017-03-12 00:44:54 --> Language Class Initialized
INFO - 2017-03-12 00:44:55 --> Loader Class Initialized
INFO - 2017-03-12 00:44:55 --> Loader Class Initialized
INFO - 2017-03-12 00:44:55 --> Database Driver Class Initialized
INFO - 2017-03-12 00:44:55 --> Database Driver Class Initialized
INFO - 2017-03-12 00:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:44:56 --> Controller Class Initialized
INFO - 2017-03-12 00:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:44:56 --> Controller Class Initialized
INFO - 2017-03-12 00:44:56 --> Helper loaded: url_helper
INFO - 2017-03-12 00:44:57 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:44:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:44:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:44:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:44:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:44:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:44:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:44:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:44:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:44:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:44:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:44:58 --> Final output sent to browser
DEBUG - 2017-03-12 00:44:58 --> Total execution time: 4.4810
INFO - 2017-03-12 00:44:58 --> Final output sent to browser
DEBUG - 2017-03-12 00:44:58 --> Total execution time: 4.4810
INFO - 2017-03-12 00:45:00 --> Config Class Initialized
INFO - 2017-03-12 00:45:00 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:45:01 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:45:01 --> Utf8 Class Initialized
INFO - 2017-03-12 00:45:01 --> URI Class Initialized
INFO - 2017-03-12 00:45:02 --> Router Class Initialized
INFO - 2017-03-12 00:45:02 --> Output Class Initialized
INFO - 2017-03-12 00:45:02 --> Security Class Initialized
DEBUG - 2017-03-12 00:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:45:03 --> Input Class Initialized
INFO - 2017-03-12 00:45:04 --> Language Class Initialized
INFO - 2017-03-12 00:45:04 --> Loader Class Initialized
INFO - 2017-03-12 00:45:05 --> Database Driver Class Initialized
INFO - 2017-03-12 00:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:45:05 --> Controller Class Initialized
INFO - 2017-03-12 00:45:05 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:45:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:45:16 --> Config Class Initialized
INFO - 2017-03-12 00:45:16 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:45:17 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:45:17 --> Utf8 Class Initialized
INFO - 2017-03-12 00:45:17 --> URI Class Initialized
INFO - 2017-03-12 00:45:17 --> Router Class Initialized
INFO - 2017-03-12 00:45:17 --> Output Class Initialized
INFO - 2017-03-12 00:45:18 --> Security Class Initialized
DEBUG - 2017-03-12 00:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:45:19 --> Input Class Initialized
INFO - 2017-03-12 00:45:19 --> Language Class Initialized
INFO - 2017-03-12 00:45:21 --> Loader Class Initialized
INFO - 2017-03-12 00:45:23 --> Database Driver Class Initialized
INFO - 2017-03-12 00:45:27 --> Config Class Initialized
INFO - 2017-03-12 00:45:28 --> Hooks Class Initialized
INFO - 2017-03-12 00:45:28 --> Config Class Initialized
INFO - 2017-03-12 00:45:28 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:45:29 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:45:29 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:45:29 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:45:29 --> Utf8 Class Initialized
INFO - 2017-03-12 00:45:29 --> URI Class Initialized
INFO - 2017-03-12 00:45:29 --> URI Class Initialized
INFO - 2017-03-12 00:45:29 --> Config Class Initialized
INFO - 2017-03-12 00:45:30 --> Router Class Initialized
INFO - 2017-03-12 00:45:30 --> Router Class Initialized
INFO - 2017-03-12 00:45:30 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:45:30 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:45:31 --> Output Class Initialized
INFO - 2017-03-12 00:45:31 --> Output Class Initialized
INFO - 2017-03-12 00:45:31 --> Utf8 Class Initialized
INFO - 2017-03-12 00:45:31 --> Security Class Initialized
INFO - 2017-03-12 00:45:31 --> Security Class Initialized
INFO - 2017-03-12 00:45:31 --> URI Class Initialized
DEBUG - 2017-03-12 00:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:45:31 --> Input Class Initialized
DEBUG - 2017-03-12 00:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:45:31 --> Input Class Initialized
INFO - 2017-03-12 00:45:31 --> Language Class Initialized
INFO - 2017-03-12 00:45:31 --> Language Class Initialized
INFO - 2017-03-12 00:45:31 --> Router Class Initialized
INFO - 2017-03-12 00:45:31 --> Output Class Initialized
INFO - 2017-03-12 00:45:31 --> Security Class Initialized
DEBUG - 2017-03-12 00:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:45:31 --> Input Class Initialized
INFO - 2017-03-12 00:45:31 --> Language Class Initialized
INFO - 2017-03-12 00:45:31 --> Loader Class Initialized
INFO - 2017-03-12 00:45:31 --> Loader Class Initialized
INFO - 2017-03-12 00:45:31 --> Loader Class Initialized
INFO - 2017-03-12 00:45:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:45:32 --> Database Driver Class Initialized
INFO - 2017-03-12 00:45:33 --> Database Driver Class Initialized
INFO - 2017-03-12 00:45:33 --> Database Driver Class Initialized
ERROR - 2017-03-12 00:45:33 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
INFO - 2017-03-12 00:45:33 --> Config Class Initialized
INFO - 2017-03-12 00:45:33 --> Hooks Class Initialized
INFO - 2017-03-12 00:45:33 --> Config Class Initialized
INFO - 2017-03-12 00:45:33 --> Hooks Class Initialized
ERROR - 2017-03-12 00:45:33 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
INFO - 2017-03-12 00:45:33 --> Config Class Initialized
ERROR - 2017-03-12 00:45:33 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:45:33 --> Config Class Initialized
DEBUG - 2017-03-12 00:45:33 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:45:34 --> Hooks Class Initialized
INFO - 2017-03-12 00:45:34 --> Config Class Initialized
INFO - 2017-03-12 00:45:34 --> Utf8 Class Initialized
INFO - 2017-03-12 00:45:34 --> Hooks Class Initialized
INFO - 2017-03-12 00:45:34 --> Hooks Class Initialized
INFO - 2017-03-12 00:45:34 --> URI Class Initialized
DEBUG - 2017-03-12 00:45:34 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:45:34 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:45:34 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:45:34 --> Utf8 Class Initialized
INFO - 2017-03-12 00:45:34 --> Router Class Initialized
INFO - 2017-03-12 00:45:34 --> Config Class Initialized
INFO - 2017-03-12 00:45:34 --> Hooks Class Initialized
INFO - 2017-03-12 00:45:35 --> Config Class Initialized
INFO - 2017-03-12 00:45:35 --> Hooks Class Initialized
INFO - 2017-03-12 00:45:35 --> Config Class Initialized
DEBUG - 2017-03-12 00:45:35 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:45:35 --> Hooks Class Initialized
INFO - 2017-03-12 00:45:35 --> URI Class Initialized
INFO - 2017-03-12 00:45:35 --> Config Class Initialized
INFO - 2017-03-12 00:45:35 --> Hooks Class Initialized
INFO - 2017-03-12 00:45:35 --> Router Class Initialized
DEBUG - 2017-03-12 00:45:35 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:45:35 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:45:35 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:45:35 --> Utf8 Class Initialized
INFO - 2017-03-12 00:45:35 --> Utf8 Class Initialized
INFO - 2017-03-12 00:45:35 --> URI Class Initialized
DEBUG - 2017-03-12 00:45:35 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:45:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
DEBUG - 2017-03-12 00:45:35 --> No URI present. Default controller set.
INFO - 2017-03-12 00:45:35 --> Config Class Initialized
INFO - 2017-03-12 00:45:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:45:35 --> Utf8 Class Initialized
INFO - 2017-03-12 00:45:35 --> URI Class Initialized
INFO - 2017-03-12 00:45:35 --> Router Class Initialized
INFO - 2017-03-12 00:45:35 --> Output Class Initialized
INFO - 2017-03-12 00:45:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:45:35 --> Security Class Initialized
INFO - 2017-03-12 00:45:35 --> URI Class Initialized
INFO - 2017-03-12 00:45:35 --> Router Class Initialized
INFO - 2017-03-12 00:45:35 --> Router Class Initialized
INFO - 2017-03-12 00:45:35 --> Final output sent to browser
DEBUG - 2017-03-12 00:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:45:35 --> Input Class Initialized
INFO - 2017-03-12 00:45:35 --> URI Class Initialized
INFO - 2017-03-12 00:45:35 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:45:35 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:45:35 --> Utf8 Class Initialized
INFO - 2017-03-12 00:45:35 --> Output Class Initialized
INFO - 2017-03-12 00:45:35 --> Security Class Initialized
DEBUG - 2017-03-12 00:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:45:35 --> Input Class Initialized
INFO - 2017-03-12 00:45:35 --> Language Class Initialized
DEBUG - 2017-03-12 00:45:35 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:45:36 --> URI Class Initialized
INFO - 2017-03-12 00:45:36 --> Utf8 Class Initialized
INFO - 2017-03-12 00:45:36 --> Router Class Initialized
INFO - 2017-03-12 00:45:36 --> URI Class Initialized
INFO - 2017-03-12 00:45:36 --> Language Class Initialized
INFO - 2017-03-12 00:45:36 --> Loader Class Initialized
DEBUG - 2017-03-12 00:45:36 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:45:36 --> Router Class Initialized
INFO - 2017-03-12 00:45:36 --> Utf8 Class Initialized
INFO - 2017-03-12 00:45:36 --> URI Class Initialized
DEBUG - 2017-03-12 00:45:36 --> Total execution time: 35.1215
INFO - 2017-03-12 00:45:36 --> URI Class Initialized
INFO - 2017-03-12 00:45:36 --> Output Class Initialized
INFO - 2017-03-12 00:45:37 --> Router Class Initialized
INFO - 2017-03-12 00:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:45:37 --> Output Class Initialized
INFO - 2017-03-12 00:45:37 --> Controller Class Initialized
INFO - 2017-03-12 00:45:37 --> Security Class Initialized
INFO - 2017-03-12 00:45:37 --> Helper loaded: url_helper
INFO - 2017-03-12 00:45:37 --> Output Class Initialized
DEBUG - 2017-03-12 00:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-03-12 00:45:38 --> No URI present. Default controller set.
INFO - 2017-03-12 00:45:38 --> Input Class Initialized
INFO - 2017-03-12 00:45:38 --> Database Driver Class Initialized
INFO - 2017-03-12 00:45:38 --> Output Class Initialized
DEBUG - 2017-03-12 00:45:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:45:39 --> Language Class Initialized
INFO - 2017-03-12 00:45:39 --> Security Class Initialized
INFO - 2017-03-12 00:45:39 --> Router Class Initialized
INFO - 2017-03-12 00:45:39 --> Loader Class Initialized
INFO - 2017-03-12 00:45:39 --> Output Class Initialized
INFO - 2017-03-12 00:45:39 --> Loader Class Initialized
INFO - 2017-03-12 00:45:39 --> Security Class Initialized
INFO - 2017-03-12 00:45:39 --> Output Class Initialized
INFO - 2017-03-12 00:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:45:40 --> Output Class Initialized
INFO - 2017-03-12 00:45:40 --> Controller Class Initialized
INFO - 2017-03-12 00:45:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:45:41 --> Security Class Initialized
DEBUG - 2017-03-12 00:45:41 --> No URI present. Default controller set.
INFO - 2017-03-12 00:45:41 --> Helper loaded: url_helper
ERROR - 2017-03-12 00:45:42 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
DEBUG - 2017-03-12 00:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:45:42 --> Input Class Initialized
INFO - 2017-03-12 00:45:42 --> Router Class Initialized
DEBUG - 2017-03-12 00:45:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:45:42 --> Language Class Initialized
INFO - 2017-03-12 00:45:42 --> Database Driver Class Initialized
INFO - 2017-03-12 00:45:42 --> Security Class Initialized
DEBUG - 2017-03-12 00:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:45:42 --> Input Class Initialized
INFO - 2017-03-12 00:45:42 --> Language Class Initialized
INFO - 2017-03-12 00:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:45:42 --> Loader Class Initialized
INFO - 2017-03-12 00:45:42 --> Security Class Initialized
INFO - 2017-03-12 00:45:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
DEBUG - 2017-03-12 00:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:45:43 --> Input Class Initialized
INFO - 2017-03-12 00:45:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-03-12 00:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:45:43 --> Input Class Initialized
INFO - 2017-03-12 00:45:43 --> Language Class Initialized
INFO - 2017-03-12 00:45:43 --> Output Class Initialized
DEBUG - 2017-03-12 00:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:45:43 --> Input Class Initialized
INFO - 2017-03-12 00:45:43 --> Database Driver Class Initialized
INFO - 2017-03-12 00:45:43 --> Security Class Initialized
INFO - 2017-03-12 00:45:43 --> Loader Class Initialized
INFO - 2017-03-12 00:45:43 --> Loader Class Initialized
INFO - 2017-03-12 00:45:43 --> Language Class Initialized
DEBUG - 2017-03-12 00:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:45:43 --> Input Class Initialized
INFO - 2017-03-12 00:45:44 --> Language Class Initialized
INFO - 2017-03-12 00:45:44 --> Language Class Initialized
INFO - 2017-03-12 00:45:44 --> Security Class Initialized
INFO - 2017-03-12 00:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:45:44 --> Controller Class Initialized
INFO - 2017-03-12 00:45:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
ERROR - 2017-03-12 00:45:44 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
INFO - 2017-03-12 00:45:44 --> Controller Class Initialized
INFO - 2017-03-12 00:45:44 --> Database Driver Class Initialized
DEBUG - 2017-03-12 00:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:45:44 --> Database Driver Class Initialized
ERROR - 2017-03-12 00:45:44 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:45:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:45:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:45:44 --> Input Class Initialized
INFO - 2017-03-12 00:45:44 --> Loader Class Initialized
INFO - 2017-03-12 00:45:44 --> Loader Class Initialized
INFO - 2017-03-12 00:45:44 --> Loader Class Initialized
INFO - 2017-03-12 00:45:44 --> Helper loaded: date_helper
INFO - 2017-03-12 00:45:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:45:45 --> Language Class Initialized
INFO - 2017-03-12 00:45:45 --> Helper loaded: date_helper
INFO - 2017-03-12 00:45:45 --> Final output sent to browser
INFO - 2017-03-12 00:45:45 --> Database Driver Class Initialized
DEBUG - 2017-03-12 00:45:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:45:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:45:46 --> Controller Class Initialized
INFO - 2017-03-12 00:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:45:46 --> Helper loaded: url_helper
INFO - 2017-03-12 00:45:46 --> Database Driver Class Initialized
INFO - 2017-03-12 00:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:45:46 --> Helper loaded: download_helper
INFO - 2017-03-12 00:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:45:47 --> Controller Class Initialized
DEBUG - 2017-03-12 00:45:47 --> Total execution time: 12.8080
INFO - 2017-03-12 00:45:47 --> Helper loaded: date_helper
INFO - 2017-03-12 00:45:48 --> Loader Class Initialized
INFO - 2017-03-12 00:45:48 --> Controller Class Initialized
INFO - 2017-03-12 00:45:48 --> Final output sent to browser
DEBUG - 2017-03-12 00:45:48 --> Total execution time: 36.4345
INFO - 2017-03-12 00:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:45:49 --> Helper loaded: url_helper
INFO - 2017-03-12 00:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:45:49 --> Helper loaded: url_helper
INFO - 2017-03-12 00:45:50 --> Database Driver Class Initialized
INFO - 2017-03-12 00:45:50 --> Controller Class Initialized
INFO - 2017-03-12 00:45:50 --> Helper loaded: download_helper
INFO - 2017-03-12 00:45:50 --> Config Class Initialized
INFO - 2017-03-12 00:45:51 --> Helper loaded: url_helper
INFO - 2017-03-12 00:45:51 --> Hooks Class Initialized
INFO - 2017-03-12 00:45:51 --> Config Class Initialized
INFO - 2017-03-12 00:45:51 --> Config Class Initialized
INFO - 2017-03-12 00:45:51 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:45:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:45:52 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:45:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:45:52 --> Database Driver Class Initialized
INFO - 2017-03-12 00:45:52 --> Database Driver Class Initialized
DEBUG - 2017-03-12 00:45:52 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:45:53 --> Helper loaded: date_helper
INFO - 2017-03-12 00:45:53 --> Controller Class Initialized
INFO - 2017-03-12 00:45:53 --> Utf8 Class Initialized
INFO - 2017-03-12 00:45:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
DEBUG - 2017-03-12 00:45:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:45:53 --> URI Class Initialized
DEBUG - 2017-03-12 00:45:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:45:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:45:54 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:45:54 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:45:54 --> Utf8 Class Initialized
INFO - 2017-03-12 00:45:54 --> Helper loaded: download_helper
DEBUG - 2017-03-12 00:45:54 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:45:54 --> Controller Class Initialized
INFO - 2017-03-12 00:45:54 --> Helper loaded: url_helper
INFO - 2017-03-12 00:45:55 --> Helper loaded: url_helper
INFO - 2017-03-12 00:45:55 --> Utf8 Class Initialized
INFO - 2017-03-12 00:45:55 --> Helper loaded: date_helper
INFO - 2017-03-12 00:45:55 --> URI Class Initialized
INFO - 2017-03-12 00:45:55 --> Router Class Initialized
INFO - 2017-03-12 00:45:55 --> Helper loaded: download_helper
INFO - 2017-03-12 00:45:55 --> URI Class Initialized
DEBUG - 2017-03-12 00:45:55 --> No URI present. Default controller set.
DEBUG - 2017-03-12 00:45:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:45:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
ERROR - 2017-03-12 00:45:56 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
DEBUG - 2017-03-12 00:45:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:45:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:45:56 --> Router Class Initialized
ERROR - 2017-03-12 00:45:56 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
INFO - 2017-03-12 00:45:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:45:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
ERROR - 2017-03-12 00:45:57 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:45:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
DEBUG - 2017-03-12 00:45:57 --> No URI present. Default controller set.
INFO - 2017-03-12 00:45:57 --> Router Class Initialized
INFO - 2017-03-12 00:45:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:45:57 --> Output Class Initialized
INFO - 2017-03-12 00:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:45:58 --> Output Class Initialized
INFO - 2017-03-12 00:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:45:58 --> Output Class Initialized
INFO - 2017-03-12 00:45:58 --> Security Class Initialized
INFO - 2017-03-12 00:45:58 --> Security Class Initialized
INFO - 2017-03-12 00:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:45:59 --> Helper loaded: url_helper
INFO - 2017-03-12 00:45:59 --> Final output sent to browser
INFO - 2017-03-12 00:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
DEBUG - 2017-03-12 00:45:59 --> Total execution time: 25.5194
DEBUG - 2017-03-12 00:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:45:59 --> Input Class Initialized
INFO - 2017-03-12 00:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-12 00:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:45:59 --> Final output sent to browser
INFO - 2017-03-12 00:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-12 00:46:00 --> Helper loaded: download_helper
INFO - 2017-03-12 00:46:00 --> Final output sent to browser
DEBUG - 2017-03-12 00:46:00 --> Total execution time: 36.9497
INFO - 2017-03-12 00:46:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
DEBUG - 2017-03-12 00:46:02 --> Total execution time: 26.7852
INFO - 2017-03-12 00:46:02 --> Final output sent to browser
DEBUG - 2017-03-12 00:46:02 --> Total execution time: 30.3559
DEBUG - 2017-03-12 00:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:46:02 --> Input Class Initialized
INFO - 2017-03-12 00:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:46:02 --> Controller Class Initialized
INFO - 2017-03-12 00:46:02 --> Language Class Initialized
INFO - 2017-03-12 00:46:02 --> Security Class Initialized
DEBUG - 2017-03-12 00:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:46:02 --> Input Class Initialized
INFO - 2017-03-12 00:46:02 --> Language Class Initialized
INFO - 2017-03-12 00:46:02 --> Language Class Initialized
INFO - 2017-03-12 00:46:02 --> Loader Class Initialized
INFO - 2017-03-12 00:46:02 --> Helper loaded: url_helper
INFO - 2017-03-12 00:46:02 --> Config Class Initialized
INFO - 2017-03-12 00:46:02 --> Config Class Initialized
INFO - 2017-03-12 00:46:06 --> Hooks Class Initialized
INFO - 2017-03-12 00:46:06 --> Config Class Initialized
INFO - 2017-03-12 00:46:06 --> Hooks Class Initialized
INFO - 2017-03-12 00:46:06 --> Loader Class Initialized
INFO - 2017-03-12 00:46:06 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:46:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:46:07 --> Loader Class Initialized
INFO - 2017-03-12 00:46:07 --> Database Driver Class Initialized
DEBUG - 2017-03-12 00:46:07 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:46:07 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:46:07 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:46:08 --> Utf8 Class Initialized
INFO - 2017-03-12 00:46:08 --> Database Driver Class Initialized
INFO - 2017-03-12 00:46:08 --> URI Class Initialized
DEBUG - 2017-03-12 00:46:09 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:46:09 --> URI Class Initialized
INFO - 2017-03-12 00:46:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:46:09 --> Utf8 Class Initialized
INFO - 2017-03-12 00:46:09 --> Database Driver Class Initialized
INFO - 2017-03-12 00:46:10 --> Router Class Initialized
INFO - 2017-03-12 00:46:10 --> URI Class Initialized
DEBUG - 2017-03-12 00:46:11 --> No URI present. Default controller set.
INFO - 2017-03-12 00:46:11 --> Router Class Initialized
INFO - 2017-03-12 00:46:11 --> Output Class Initialized
INFO - 2017-03-12 00:46:11 --> Session: Class initialized using 'files' driver.
ERROR - 2017-03-12 00:46:12 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
INFO - 2017-03-12 00:46:12 --> Controller Class Initialized
INFO - 2017-03-12 00:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:46:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-03-12 00:46:12 --> No URI present. Default controller set.
INFO - 2017-03-12 00:46:12 --> Controller Class Initialized
ERROR - 2017-03-12 00:46:12 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
INFO - 2017-03-12 00:46:12 --> Router Class Initialized
INFO - 2017-03-12 00:46:12 --> Security Class Initialized
INFO - 2017-03-12 00:46:12 --> Output Class Initialized
INFO - 2017-03-12 00:46:12 --> Controller Class Initialized
DEBUG - 2017-03-12 00:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:46:13 --> Helper loaded: url_helper
INFO - 2017-03-12 00:46:13 --> Helper loaded: url_helper
INFO - 2017-03-12 00:46:13 --> Output Class Initialized
INFO - 2017-03-12 00:46:13 --> Security Class Initialized
DEBUG - 2017-03-12 00:46:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:46:13 --> Security Class Initialized
ERROR - 2017-03-12 00:46:13 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
DEBUG - 2017-03-12 00:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-03-12 00:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:46:13 --> Input Class Initialized
INFO - 2017-03-12 00:46:13 --> Input Class Initialized
DEBUG - 2017-03-12 00:46:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:46:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:46:13 --> Input Class Initialized
INFO - 2017-03-12 00:46:13 --> Language Class Initialized
INFO - 2017-03-12 00:46:13 --> Helper loaded: date_helper
INFO - 2017-03-12 00:46:13 --> Language Class Initialized
INFO - 2017-03-12 00:46:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:46:13 --> Language Class Initialized
INFO - 2017-03-12 00:46:13 --> Loader Class Initialized
INFO - 2017-03-12 00:46:13 --> Loader Class Initialized
INFO - 2017-03-12 00:46:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
DEBUG - 2017-03-12 00:46:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:46:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:46:14 --> Loader Class Initialized
INFO - 2017-03-12 00:46:14 --> Helper loaded: url_helper
INFO - 2017-03-12 00:46:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:46:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:46:14 --> Helper loaded: download_helper
INFO - 2017-03-12 00:46:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:46:14 --> Database Driver Class Initialized
INFO - 2017-03-12 00:46:16 --> Database Driver Class Initialized
INFO - 2017-03-12 00:46:16 --> Database Driver Class Initialized
INFO - 2017-03-12 00:46:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:46:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:46:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:46:18 --> Final output sent to browser
INFO - 2017-03-12 00:46:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:46:18 --> Controller Class Initialized
INFO - 2017-03-12 00:46:18 --> Final output sent to browser
DEBUG - 2017-03-12 00:46:18 --> Total execution time: 33.2777
DEBUG - 2017-03-12 00:46:18 --> Total execution time: 51.5957
INFO - 2017-03-12 00:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:46:19 --> Controller Class Initialized
INFO - 2017-03-12 00:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:46:19 --> Controller Class Initialized
INFO - 2017-03-12 00:46:19 --> Helper loaded: url_helper
INFO - 2017-03-12 00:46:19 --> Controller Class Initialized
INFO - 2017-03-12 00:46:19 --> Helper loaded: url_helper
INFO - 2017-03-12 00:46:19 --> Helper loaded: url_helper
INFO - 2017-03-12 00:46:20 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:46:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:46:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:46:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:46:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:46:20 --> Final output sent to browser
INFO - 2017-03-12 00:46:20 --> Helper loaded: url_helper
INFO - 2017-03-12 00:46:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:46:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:46:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:46:20 --> Helper loaded: download_helper
INFO - 2017-03-12 00:46:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:46:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
ERROR - 2017-03-12 00:46:20 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
INFO - 2017-03-12 00:46:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:46:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:46:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
ERROR - 2017-03-12 00:46:21 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:46:21 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:46:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:46:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:46:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
DEBUG - 2017-03-12 00:46:21 --> Total execution time: 32.8393
INFO - 2017-03-12 00:46:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:46:21 --> Final output sent to browser
DEBUG - 2017-03-12 00:46:21 --> Total execution time: 22.6218
INFO - 2017-03-12 00:46:21 --> Final output sent to browser
INFO - 2017-03-12 00:46:22 --> Final output sent to browser
DEBUG - 2017-03-12 00:46:22 --> Total execution time: 58.6192
DEBUG - 2017-03-12 00:46:22 --> Total execution time: 23.0353
INFO - 2017-03-12 00:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:46:22 --> Controller Class Initialized
INFO - 2017-03-12 00:46:23 --> Helper loaded: url_helper
INFO - 2017-03-12 00:46:23 --> Config Class Initialized
INFO - 2017-03-12 00:46:24 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:46:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:46:24 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:46:24 --> Utf8 Class Initialized
INFO - 2017-03-12 00:46:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:46:25 --> URI Class Initialized
ERROR - 2017-03-12 00:46:25 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
DEBUG - 2017-03-12 00:46:25 --> No URI present. Default controller set.
INFO - 2017-03-12 00:46:26 --> Router Class Initialized
ERROR - 2017-03-12 00:46:26 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:46:26 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:46:26 --> Output Class Initialized
INFO - 2017-03-12 00:46:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:46:26 --> Security Class Initialized
DEBUG - 2017-03-12 00:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:46:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:46:26 --> Input Class Initialized
INFO - 2017-03-12 00:46:26 --> Language Class Initialized
INFO - 2017-03-12 00:46:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:46:26 --> Final output sent to browser
DEBUG - 2017-03-12 00:46:26 --> Total execution time: 54.5094
INFO - 2017-03-12 00:46:26 --> Loader Class Initialized
INFO - 2017-03-12 00:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:46:26 --> Controller Class Initialized
INFO - 2017-03-12 00:46:26 --> Helper loaded: url_helper
INFO - 2017-03-12 00:46:27 --> Config Class Initialized
INFO - 2017-03-12 00:46:27 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:46:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:46:27 --> Database Driver Class Initialized
DEBUG - 2017-03-12 00:46:27 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:46:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:46:27 --> Utf8 Class Initialized
INFO - 2017-03-12 00:46:27 --> URI Class Initialized
ERROR - 2017-03-12 00:46:27 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
DEBUG - 2017-03-12 00:46:27 --> No URI present. Default controller set.
ERROR - 2017-03-12 00:46:27 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
INFO - 2017-03-12 00:46:27 --> Config Class Initialized
INFO - 2017-03-12 00:46:27 --> Hooks Class Initialized
ERROR - 2017-03-12 00:46:27 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:46:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:46:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:46:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:46:27 --> Config Class Initialized
INFO - 2017-03-12 00:46:27 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:46:27 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:46:27 --> Utf8 Class Initialized
INFO - 2017-03-12 00:46:27 --> URI Class Initialized
INFO - 2017-03-12 00:46:27 --> Config Class Initialized
INFO - 2017-03-12 00:46:27 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:46:27 --> No URI present. Default controller set.
INFO - 2017-03-12 00:46:27 --> Router Class Initialized
INFO - 2017-03-12 00:46:27 --> Output Class Initialized
DEBUG - 2017-03-12 00:46:27 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:46:27 --> Utf8 Class Initialized
INFO - 2017-03-12 00:46:27 --> Security Class Initialized
INFO - 2017-03-12 00:46:27 --> URI Class Initialized
DEBUG - 2017-03-12 00:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:46:27 --> Input Class Initialized
DEBUG - 2017-03-12 00:46:27 --> No URI present. Default controller set.
INFO - 2017-03-12 00:46:27 --> Router Class Initialized
INFO - 2017-03-12 00:46:27 --> Language Class Initialized
INFO - 2017-03-12 00:46:27 --> Output Class Initialized
INFO - 2017-03-12 00:46:27 --> Loader Class Initialized
INFO - 2017-03-12 00:46:27 --> Security Class Initialized
DEBUG - 2017-03-12 00:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:46:27 --> Input Class Initialized
INFO - 2017-03-12 00:46:27 --> Language Class Initialized
DEBUG - 2017-03-12 00:46:27 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:46:27 --> Utf8 Class Initialized
INFO - 2017-03-12 00:46:27 --> URI Class Initialized
INFO - 2017-03-12 00:46:27 --> Router Class Initialized
INFO - 2017-03-12 00:46:28 --> Output Class Initialized
INFO - 2017-03-12 00:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:46:28 --> Router Class Initialized
INFO - 2017-03-12 00:46:28 --> Controller Class Initialized
INFO - 2017-03-12 00:46:28 --> Helper loaded: url_helper
INFO - 2017-03-12 00:46:28 --> Loader Class Initialized
DEBUG - 2017-03-12 00:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:46:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:46:28 --> Output Class Initialized
INFO - 2017-03-12 00:46:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:46:28 --> Security Class Initialized
DEBUG - 2017-03-12 00:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:46:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:46:29 --> Database Driver Class Initialized
INFO - 2017-03-12 00:46:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:46:29 --> Input Class Initialized
INFO - 2017-03-12 00:46:29 --> Language Class Initialized
INFO - 2017-03-12 00:46:29 --> Loader Class Initialized
INFO - 2017-03-12 00:46:29 --> Database Driver Class Initialized
INFO - 2017-03-12 00:46:29 --> Security Class Initialized
DEBUG - 2017-03-12 00:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:46:29 --> Input Class Initialized
INFO - 2017-03-12 00:46:29 --> Language Class Initialized
INFO - 2017-03-12 00:46:29 --> Database Driver Class Initialized
INFO - 2017-03-12 00:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:46:29 --> Controller Class Initialized
INFO - 2017-03-12 00:46:29 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:46:29 --> Final output sent to browser
DEBUG - 2017-03-12 00:46:29 --> Total execution time: 55.9862
INFO - 2017-03-12 00:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:46:30 --> Controller Class Initialized
INFO - 2017-03-12 00:46:30 --> Loader Class Initialized
INFO - 2017-03-12 00:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:46:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:46:30 --> Controller Class Initialized
INFO - 2017-03-12 00:46:30 --> Database Driver Class Initialized
INFO - 2017-03-12 00:46:30 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:46:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:46:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:46:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:46:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:46:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:46:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:46:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:46:31 --> Controller Class Initialized
INFO - 2017-03-12 00:46:31 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:46:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:46:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:46:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:46:31 --> Final output sent to browser
INFO - 2017-03-12 00:46:31 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:46:31 --> Total execution time: 10.2220
ERROR - 2017-03-12 00:46:31 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
DEBUG - 2017-03-12 00:46:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:46:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 00:46:31 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
INFO - 2017-03-12 00:46:31 --> Final output sent to browser
ERROR - 2017-03-12 00:46:31 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:46:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:46:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:46:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
DEBUG - 2017-03-12 00:46:31 --> Total execution time: 5.7900
INFO - 2017-03-12 00:46:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:46:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:46:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:46:31 --> Final output sent to browser
DEBUG - 2017-03-12 00:46:31 --> Total execution time: 5.2699
INFO - 2017-03-12 00:46:31 --> Final output sent to browser
DEBUG - 2017-03-12 00:46:31 --> Total execution time: 6.1420
INFO - 2017-03-12 00:46:32 --> Final output sent to browser
DEBUG - 2017-03-12 00:46:32 --> Total execution time: 6.1503
INFO - 2017-03-12 00:47:12 --> Config Class Initialized
INFO - 2017-03-12 00:47:13 --> Config Class Initialized
INFO - 2017-03-12 00:47:13 --> Hooks Class Initialized
INFO - 2017-03-12 00:47:13 --> Hooks Class Initialized
INFO - 2017-03-12 00:47:13 --> Config Class Initialized
INFO - 2017-03-12 00:47:13 --> Hooks Class Initialized
INFO - 2017-03-12 00:47:13 --> Config Class Initialized
INFO - 2017-03-12 00:47:13 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:47:14 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:47:14 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:47:14 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:47:14 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:47:14 --> Utf8 Class Initialized
INFO - 2017-03-12 00:47:14 --> URI Class Initialized
DEBUG - 2017-03-12 00:47:15 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:47:15 --> Utf8 Class Initialized
INFO - 2017-03-12 00:47:15 --> URI Class Initialized
INFO - 2017-03-12 00:47:15 --> Router Class Initialized
INFO - 2017-03-12 00:47:15 --> Router Class Initialized
INFO - 2017-03-12 00:47:15 --> Utf8 Class Initialized
INFO - 2017-03-12 00:47:15 --> URI Class Initialized
INFO - 2017-03-12 00:47:15 --> Output Class Initialized
INFO - 2017-03-12 00:47:15 --> Output Class Initialized
INFO - 2017-03-12 00:47:15 --> Security Class Initialized
INFO - 2017-03-12 00:47:15 --> Security Class Initialized
DEBUG - 2017-03-12 00:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-03-12 00:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:47:15 --> Input Class Initialized
INFO - 2017-03-12 00:47:15 --> Input Class Initialized
INFO - 2017-03-12 00:47:15 --> Language Class Initialized
INFO - 2017-03-12 00:47:15 --> Language Class Initialized
INFO - 2017-03-12 00:47:15 --> URI Class Initialized
DEBUG - 2017-03-12 00:47:15 --> No URI present. Default controller set.
INFO - 2017-03-12 00:47:15 --> Router Class Initialized
INFO - 2017-03-12 00:47:16 --> Router Class Initialized
INFO - 2017-03-12 00:47:16 --> Loader Class Initialized
INFO - 2017-03-12 00:47:16 --> Output Class Initialized
INFO - 2017-03-12 00:47:16 --> Loader Class Initialized
INFO - 2017-03-12 00:47:16 --> Security Class Initialized
INFO - 2017-03-12 00:47:16 --> Output Class Initialized
DEBUG - 2017-03-12 00:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:47:16 --> Security Class Initialized
DEBUG - 2017-03-12 00:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:47:16 --> Database Driver Class Initialized
INFO - 2017-03-12 00:47:16 --> Input Class Initialized
INFO - 2017-03-12 00:47:16 --> Language Class Initialized
INFO - 2017-03-12 00:47:16 --> Loader Class Initialized
INFO - 2017-03-12 00:47:17 --> Database Driver Class Initialized
INFO - 2017-03-12 00:47:17 --> Database Driver Class Initialized
INFO - 2017-03-12 00:47:17 --> Input Class Initialized
INFO - 2017-03-12 00:47:17 --> Language Class Initialized
INFO - 2017-03-12 00:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:47:18 --> Controller Class Initialized
INFO - 2017-03-12 00:47:18 --> Helper loaded: url_helper
INFO - 2017-03-12 00:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:47:18 --> Controller Class Initialized
INFO - 2017-03-12 00:47:18 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:47:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:47:18 --> Loader Class Initialized
DEBUG - 2017-03-12 00:47:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:47:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:47:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:47:19 --> Database Driver Class Initialized
INFO - 2017-03-12 00:47:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
ERROR - 2017-03-12 00:47:19 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
INFO - 2017-03-12 00:47:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
ERROR - 2017-03-12 00:47:19 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:47:19 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:47:19 --> Config Class Initialized
INFO - 2017-03-12 00:47:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:47:19 --> Hooks Class Initialized
INFO - 2017-03-12 00:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:47:19 --> Config Class Initialized
INFO - 2017-03-12 00:47:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:47:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:47:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:47:19 --> Controller Class Initialized
INFO - 2017-03-12 00:47:19 --> Helper loaded: url_helper
INFO - 2017-03-12 00:47:20 --> Hooks Class Initialized
INFO - 2017-03-12 00:47:20 --> Config Class Initialized
INFO - 2017-03-12 00:47:20 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:47:20 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:47:20 --> Utf8 Class Initialized
INFO - 2017-03-12 00:47:20 --> Config Class Initialized
INFO - 2017-03-12 00:47:20 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:47:20 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:47:20 --> Utf8 Class Initialized
INFO - 2017-03-12 00:47:20 --> URI Class Initialized
DEBUG - 2017-03-12 00:47:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:47:20 --> Final output sent to browser
DEBUG - 2017-03-12 00:47:20 --> Total execution time: 8.1648
INFO - 2017-03-12 00:47:20 --> URI Class Initialized
INFO - 2017-03-12 00:47:20 --> Final output sent to browser
DEBUG - 2017-03-12 00:47:20 --> Total execution time: 10.0002
INFO - 2017-03-12 00:47:20 --> Router Class Initialized
DEBUG - 2017-03-12 00:47:20 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:47:20 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:47:21 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:47:21 --> Utf8 Class Initialized
INFO - 2017-03-12 00:47:21 --> Router Class Initialized
INFO - 2017-03-12 00:47:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:47:21 --> URI Class Initialized
INFO - 2017-03-12 00:47:21 --> URI Class Initialized
INFO - 2017-03-12 00:47:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:47:21 --> Output Class Initialized
INFO - 2017-03-12 00:47:21 --> Output Class Initialized
INFO - 2017-03-12 00:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:47:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:47:21 --> Router Class Initialized
INFO - 2017-03-12 00:47:21 --> Output Class Initialized
INFO - 2017-03-12 00:47:21 --> Security Class Initialized
INFO - 2017-03-12 00:47:21 --> Router Class Initialized
INFO - 2017-03-12 00:47:21 --> Output Class Initialized
INFO - 2017-03-12 00:47:21 --> Security Class Initialized
DEBUG - 2017-03-12 00:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:47:21 --> Input Class Initialized
INFO - 2017-03-12 00:47:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:47:21 --> Security Class Initialized
DEBUG - 2017-03-12 00:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:47:21 --> Input Class Initialized
INFO - 2017-03-12 00:47:21 --> Language Class Initialized
INFO - 2017-03-12 00:47:21 --> Security Class Initialized
DEBUG - 2017-03-12 00:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:47:21 --> Input Class Initialized
INFO - 2017-03-12 00:47:21 --> Language Class Initialized
DEBUG - 2017-03-12 00:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:47:21 --> Input Class Initialized
INFO - 2017-03-12 00:47:21 --> Language Class Initialized
INFO - 2017-03-12 00:47:21 --> Loader Class Initialized
INFO - 2017-03-12 00:47:21 --> Language Class Initialized
INFO - 2017-03-12 00:47:21 --> Loader Class Initialized
INFO - 2017-03-12 00:47:21 --> Loader Class Initialized
INFO - 2017-03-12 00:47:21 --> Loader Class Initialized
INFO - 2017-03-12 00:47:21 --> Controller Class Initialized
INFO - 2017-03-12 00:47:21 --> Helper loaded: url_helper
INFO - 2017-03-12 00:47:22 --> Database Driver Class Initialized
INFO - 2017-03-12 00:47:22 --> Final output sent to browser
DEBUG - 2017-03-12 00:47:22 --> Total execution time: 11.6739
INFO - 2017-03-12 00:47:22 --> Database Driver Class Initialized
INFO - 2017-03-12 00:47:22 --> Database Driver Class Initialized
INFO - 2017-03-12 00:47:22 --> Database Driver Class Initialized
DEBUG - 2017-03-12 00:47:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:47:23 --> Controller Class Initialized
INFO - 2017-03-12 00:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:47:23 --> Controller Class Initialized
INFO - 2017-03-12 00:47:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:47:23 --> Helper loaded: url_helper
INFO - 2017-03-12 00:47:23 --> Helper loaded: url_helper
ERROR - 2017-03-12 00:47:23 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
DEBUG - 2017-03-12 00:47:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:47:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-12 00:47:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:47:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:47:24 --> Final output sent to browser
DEBUG - 2017-03-12 00:47:24 --> Total execution time: 14.9358
INFO - 2017-03-12 00:47:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:47:25 --> Controller Class Initialized
INFO - 2017-03-12 00:47:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:47:25 --> Final output sent to browser
DEBUG - 2017-03-12 00:47:26 --> Total execution time: 7.8188
INFO - 2017-03-12 00:47:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:47:26 --> Helper loaded: url_helper
INFO - 2017-03-12 00:47:26 --> Final output sent to browser
INFO - 2017-03-12 00:47:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-03-12 00:47:26 --> Total execution time: 9.4167
INFO - 2017-03-12 00:47:26 --> Controller Class Initialized
INFO - 2017-03-12 00:47:26 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:47:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:47:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:47:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:47:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:47:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
ERROR - 2017-03-12 00:47:27 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
INFO - 2017-03-12 00:47:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
ERROR - 2017-03-12 00:47:27 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:47:27 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:47:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:47:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:47:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:47:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:47:27 --> Final output sent to browser
DEBUG - 2017-03-12 00:47:27 --> Total execution time: 10.4867
INFO - 2017-03-12 00:47:27 --> Final output sent to browser
DEBUG - 2017-03-12 00:47:27 --> Total execution time: 10.5095
INFO - 2017-03-12 00:47:35 --> Config Class Initialized
INFO - 2017-03-12 00:47:35 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:47:35 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:47:35 --> Utf8 Class Initialized
INFO - 2017-03-12 00:47:35 --> URI Class Initialized
INFO - 2017-03-12 00:47:35 --> Router Class Initialized
INFO - 2017-03-12 00:47:35 --> Output Class Initialized
INFO - 2017-03-12 00:47:36 --> Security Class Initialized
DEBUG - 2017-03-12 00:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:47:36 --> Input Class Initialized
INFO - 2017-03-12 00:47:36 --> Language Class Initialized
INFO - 2017-03-12 00:47:36 --> Loader Class Initialized
INFO - 2017-03-12 00:47:37 --> Database Driver Class Initialized
INFO - 2017-03-12 00:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:47:38 --> Controller Class Initialized
INFO - 2017-03-12 00:47:38 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:47:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:48:02 --> Config Class Initialized
INFO - 2017-03-12 00:48:02 --> Config Class Initialized
INFO - 2017-03-12 00:48:03 --> Hooks Class Initialized
INFO - 2017-03-12 00:48:03 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:48:03 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:48:04 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:48:04 --> Utf8 Class Initialized
INFO - 2017-03-12 00:48:04 --> Utf8 Class Initialized
INFO - 2017-03-12 00:48:04 --> URI Class Initialized
INFO - 2017-03-12 00:48:04 --> URI Class Initialized
INFO - 2017-03-12 00:48:04 --> Router Class Initialized
INFO - 2017-03-12 00:48:04 --> Router Class Initialized
INFO - 2017-03-12 00:48:04 --> Output Class Initialized
INFO - 2017-03-12 00:48:04 --> Output Class Initialized
INFO - 2017-03-12 00:48:04 --> Security Class Initialized
INFO - 2017-03-12 00:48:04 --> Security Class Initialized
DEBUG - 2017-03-12 00:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-03-12 00:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:48:04 --> Input Class Initialized
INFO - 2017-03-12 00:48:04 --> Input Class Initialized
INFO - 2017-03-12 00:48:04 --> Language Class Initialized
INFO - 2017-03-12 00:48:04 --> Language Class Initialized
INFO - 2017-03-12 00:48:06 --> Loader Class Initialized
INFO - 2017-03-12 00:48:06 --> Loader Class Initialized
INFO - 2017-03-12 00:48:06 --> Database Driver Class Initialized
INFO - 2017-03-12 00:48:06 --> Database Driver Class Initialized
INFO - 2017-03-12 00:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:48:07 --> Controller Class Initialized
INFO - 2017-03-12 00:48:08 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:48:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:48:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:48:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:48:09 --> Config Class Initialized
INFO - 2017-03-12 00:48:09 --> Hooks Class Initialized
INFO - 2017-03-12 00:48:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:48:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:48:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:48:10 --> Final output sent to browser
DEBUG - 2017-03-12 00:48:10 --> Total execution time: 11.6316
DEBUG - 2017-03-12 00:48:10 --> UTF-8 Support Enabled
ERROR - 2017-03-12 00:48:10 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
INFO - 2017-03-12 00:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:48:10 --> Controller Class Initialized
ERROR - 2017-03-12 00:48:10 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:48:10 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:48:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:48:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:48:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:48:10 --> Helper loaded: url_helper
INFO - 2017-03-12 00:48:10 --> Utf8 Class Initialized
INFO - 2017-03-12 00:48:10 --> URI Class Initialized
DEBUG - 2017-03-12 00:48:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:48:10 --> Final output sent to browser
DEBUG - 2017-03-12 00:48:10 --> Total execution time: 44.9404
INFO - 2017-03-12 00:48:10 --> Router Class Initialized
INFO - 2017-03-12 00:48:11 --> Output Class Initialized
INFO - 2017-03-12 00:48:11 --> Security Class Initialized
INFO - 2017-03-12 00:48:11 --> Config Class Initialized
INFO - 2017-03-12 00:48:11 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:48:12 --> Input Class Initialized
INFO - 2017-03-12 00:48:12 --> Config Class Initialized
INFO - 2017-03-12 00:48:12 --> Config Class Initialized
INFO - 2017-03-12 00:48:12 --> Language Class Initialized
INFO - 2017-03-12 00:48:13 --> Config Class Initialized
INFO - 2017-03-12 00:48:13 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:48:13 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:48:13 --> Utf8 Class Initialized
INFO - 2017-03-12 00:48:13 --> Loader Class Initialized
INFO - 2017-03-12 00:48:14 --> Hooks Class Initialized
INFO - 2017-03-12 00:48:14 --> Config Class Initialized
INFO - 2017-03-12 00:48:14 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:48:14 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:48:15 --> URI Class Initialized
INFO - 2017-03-12 00:48:15 --> Utf8 Class Initialized
INFO - 2017-03-12 00:48:15 --> Config Class Initialized
INFO - 2017-03-12 00:48:15 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:48:16 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:48:16 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:48:16 --> URI Class Initialized
INFO - 2017-03-12 00:48:16 --> Utf8 Class Initialized
INFO - 2017-03-12 00:48:16 --> Utf8 Class Initialized
INFO - 2017-03-12 00:48:16 --> URI Class Initialized
INFO - 2017-03-12 00:48:16 --> URI Class Initialized
INFO - 2017-03-12 00:48:16 --> Router Class Initialized
INFO - 2017-03-12 00:48:16 --> Hooks Class Initialized
INFO - 2017-03-12 00:48:16 --> Database Driver Class Initialized
INFO - 2017-03-12 00:48:16 --> Router Class Initialized
INFO - 2017-03-12 00:48:16 --> Output Class Initialized
INFO - 2017-03-12 00:48:17 --> Router Class Initialized
INFO - 2017-03-12 00:48:17 --> Output Class Initialized
INFO - 2017-03-12 00:48:17 --> Security Class Initialized
INFO - 2017-03-12 00:48:17 --> Router Class Initialized
INFO - 2017-03-12 00:48:17 --> Output Class Initialized
INFO - 2017-03-12 00:48:17 --> Security Class Initialized
DEBUG - 2017-03-12 00:48:17 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:48:17 --> Utf8 Class Initialized
INFO - 2017-03-12 00:48:17 --> URI Class Initialized
INFO - 2017-03-12 00:48:17 --> Router Class Initialized
DEBUG - 2017-03-12 00:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:48:17 --> Input Class Initialized
INFO - 2017-03-12 00:48:17 --> Security Class Initialized
INFO - 2017-03-12 00:48:18 --> Output Class Initialized
DEBUG - 2017-03-12 00:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-03-12 00:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:48:18 --> Language Class Initialized
INFO - 2017-03-12 00:48:19 --> Security Class Initialized
INFO - 2017-03-12 00:48:19 --> Input Class Initialized
INFO - 2017-03-12 00:48:19 --> Input Class Initialized
INFO - 2017-03-12 00:48:19 --> Output Class Initialized
INFO - 2017-03-12 00:48:19 --> Security Class Initialized
DEBUG - 2017-03-12 00:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:48:19 --> Input Class Initialized
INFO - 2017-03-12 00:48:19 --> Language Class Initialized
INFO - 2017-03-12 00:48:19 --> Loader Class Initialized
INFO - 2017-03-12 00:48:19 --> Language Class Initialized
INFO - 2017-03-12 00:48:19 --> Loader Class Initialized
INFO - 2017-03-12 00:48:19 --> Language Class Initialized
INFO - 2017-03-12 00:48:19 --> Loader Class Initialized
DEBUG - 2017-03-12 00:48:19 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:48:19 --> Utf8 Class Initialized
INFO - 2017-03-12 00:48:19 --> Loader Class Initialized
INFO - 2017-03-12 00:48:19 --> URI Class Initialized
DEBUG - 2017-03-12 00:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:48:19 --> Input Class Initialized
INFO - 2017-03-12 00:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:48:20 --> Router Class Initialized
INFO - 2017-03-12 00:48:20 --> Language Class Initialized
INFO - 2017-03-12 00:48:20 --> Database Driver Class Initialized
INFO - 2017-03-12 00:48:21 --> Database Driver Class Initialized
INFO - 2017-03-12 00:48:21 --> Output Class Initialized
INFO - 2017-03-12 00:48:21 --> Database Driver Class Initialized
INFO - 2017-03-12 00:48:21 --> Database Driver Class Initialized
INFO - 2017-03-12 00:48:21 --> Controller Class Initialized
INFO - 2017-03-12 00:48:21 --> Security Class Initialized
INFO - 2017-03-12 00:48:21 --> Loader Class Initialized
DEBUG - 2017-03-12 00:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:48:22 --> Input Class Initialized
INFO - 2017-03-12 00:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:48:22 --> Config Class Initialized
INFO - 2017-03-12 00:48:22 --> Language Class Initialized
INFO - 2017-03-12 00:48:22 --> Hooks Class Initialized
INFO - 2017-03-12 00:48:22 --> Database Driver Class Initialized
INFO - 2017-03-12 00:48:22 --> Controller Class Initialized
INFO - 2017-03-12 00:48:22 --> Helper loaded: url_helper
ERROR - 2017-03-12 00:48:23 --> Severity: Warning --> unlink(/tmp/ci_session1f459284d205536a752a69225c3f285ac8f27161): No such file or directory /home/graduafe/public_html/system/libraries/Session/drivers/Session_files_driver.php 311
INFO - 2017-03-12 00:48:23 --> Session: Class initialized using 'files' driver.
ERROR - 2017-03-12 00:48:23 --> Severity: Warning --> session_regenerate_id(): Session object destruction failed /home/graduafe/public_html/system/libraries/Session/Session.php 644
INFO - 2017-03-12 00:48:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-03-12 00:48:23 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:48:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:48:23 --> Utf8 Class Initialized
INFO - 2017-03-12 00:48:23 --> Controller Class Initialized
INFO - 2017-03-12 00:48:23 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:48:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:48:23 --> URI Class Initialized
INFO - 2017-03-12 00:48:23 --> Controller Class Initialized
INFO - 2017-03-12 00:48:23 --> Helper loaded: url_helper
INFO - 2017-03-12 00:48:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:48:23 --> Router Class Initialized
INFO - 2017-03-12 00:48:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:48:23 --> Loader Class Initialized
ERROR - 2017-03-12 00:48:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:48:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:48:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:48:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:48:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
DEBUG - 2017-03-12 00:48:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-12 00:48:24 --> Severity: Warning --> unlink(/tmp/ci_session1f459284d205536a752a69225c3f285ac8f27161): No such file or directory /home/graduafe/public_html/system/libraries/Session/drivers/Session_files_driver.php 311
INFO - 2017-03-12 00:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
ERROR - 2017-03-12 00:48:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
ERROR - 2017-03-12 00:48:24 --> Severity: Warning --> session_regenerate_id(): Session object destruction failed /home/graduafe/public_html/system/libraries/Session/Session.php 644
INFO - 2017-03-12 00:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:48:24 --> Controller Class Initialized
INFO - 2017-03-12 00:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:48:24 --> Output Class Initialized
INFO - 2017-03-12 00:48:24 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:48:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:48:24 --> Database Driver Class Initialized
INFO - 2017-03-12 00:48:24 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:48:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 00:48:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:48:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:48:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:48:24 --> Config Class Initialized
INFO - 2017-03-12 00:48:24 --> Hooks Class Initialized
ERROR - 2017-03-12 00:48:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:48:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
INFO - 2017-03-12 00:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 00:48:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
DEBUG - 2017-03-12 00:48:24 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:48:24 --> Security Class Initialized
ERROR - 2017-03-12 00:48:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:48:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
DEBUG - 2017-03-12 00:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:48:24 --> Utf8 Class Initialized
INFO - 2017-03-12 00:48:24 --> URI Class Initialized
INFO - 2017-03-12 00:48:24 --> Router Class Initialized
INFO - 2017-03-12 00:48:24 --> Output Class Initialized
INFO - 2017-03-12 00:48:24 --> Security Class Initialized
DEBUG - 2017-03-12 00:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:48:24 --> Input Class Initialized
INFO - 2017-03-12 00:48:24 --> Input Class Initialized
ERROR - 2017-03-12 00:48:24 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:48:24 --> Language Class Initialized
INFO - 2017-03-12 00:48:24 --> Language Class Initialized
INFO - 2017-03-12 00:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:48:24 --> Loader Class Initialized
INFO - 2017-03-12 00:48:24 --> Final output sent to browser
DEBUG - 2017-03-12 00:48:24 --> Total execution time: 15.5528
INFO - 2017-03-12 00:48:24 --> Loader Class Initialized
INFO - 2017-03-12 00:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:48:24 --> Final output sent to browser
INFO - 2017-03-12 00:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:48:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
DEBUG - 2017-03-12 00:48:25 --> Total execution time: 16.1167
INFO - 2017-03-12 00:48:25 --> Final output sent to browser
INFO - 2017-03-12 00:48:25 --> Database Driver Class Initialized
INFO - 2017-03-12 00:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:48:25 --> Controller Class Initialized
DEBUG - 2017-03-12 00:48:26 --> Total execution time: 18.7499
INFO - 2017-03-12 00:48:26 --> Database Driver Class Initialized
INFO - 2017-03-12 00:48:26 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:48:27 --> Controller Class Initialized
INFO - 2017-03-12 00:48:28 --> Helper loaded: url_helper
INFO - 2017-03-12 00:48:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:48:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
DEBUG - 2017-03-12 00:48:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-12 00:48:28 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:48:28 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:48:28 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:48:28 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
ERROR - 2017-03-12 00:48:28 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
INFO - 2017-03-12 00:48:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
ERROR - 2017-03-12 00:48:28 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:48:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:48:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:48:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:48:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:48:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:48:28 --> Final output sent to browser
DEBUG - 2017-03-12 00:48:28 --> Total execution time: 19.8809
INFO - 2017-03-12 00:48:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:48:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:48:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:48:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:48:28 --> Final output sent to browser
DEBUG - 2017-03-12 00:48:28 --> Total execution time: 29.3034
INFO - 2017-03-12 00:48:28 --> Final output sent to browser
INFO - 2017-03-12 00:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:48:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-03-12 00:48:29 --> Total execution time: 5.0935
INFO - 2017-03-12 00:48:31 --> Controller Class Initialized
INFO - 2017-03-12 00:48:31 --> Controller Class Initialized
INFO - 2017-03-12 00:48:31 --> Helper loaded: url_helper
INFO - 2017-03-12 00:48:31 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:48:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:48:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:48:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:48:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:48:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:48:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
ERROR - 2017-03-12 00:48:35 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:48:35 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
INFO - 2017-03-12 00:48:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
ERROR - 2017-03-12 00:48:35 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:48:35 --> Final output sent to browser
INFO - 2017-03-12 00:48:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
DEBUG - 2017-03-12 00:48:35 --> Total execution time: 17.2876
INFO - 2017-03-12 00:48:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:48:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:48:37 --> Final output sent to browser
DEBUG - 2017-03-12 00:48:37 --> Total execution time: 28.2926
INFO - 2017-03-12 00:48:43 --> Config Class Initialized
INFO - 2017-03-12 00:48:43 --> Hooks Class Initialized
INFO - 2017-03-12 00:48:43 --> Config Class Initialized
INFO - 2017-03-12 00:48:43 --> Hooks Class Initialized
INFO - 2017-03-12 00:48:43 --> Config Class Initialized
INFO - 2017-03-12 00:48:43 --> Hooks Class Initialized
INFO - 2017-03-12 00:48:43 --> Config Class Initialized
INFO - 2017-03-12 00:48:43 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:48:43 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:48:43 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:48:43 --> Utf8 Class Initialized
INFO - 2017-03-12 00:48:43 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:48:43 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:48:43 --> Utf8 Class Initialized
INFO - 2017-03-12 00:48:43 --> URI Class Initialized
DEBUG - 2017-03-12 00:48:43 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:48:43 --> URI Class Initialized
INFO - 2017-03-12 00:48:43 --> Utf8 Class Initialized
INFO - 2017-03-12 00:48:43 --> URI Class Initialized
INFO - 2017-03-12 00:48:43 --> URI Class Initialized
INFO - 2017-03-12 00:48:43 --> Router Class Initialized
INFO - 2017-03-12 00:48:43 --> Router Class Initialized
INFO - 2017-03-12 00:48:43 --> Router Class Initialized
INFO - 2017-03-12 00:48:43 --> Output Class Initialized
DEBUG - 2017-03-12 00:48:44 --> No URI present. Default controller set.
INFO - 2017-03-12 00:48:44 --> Router Class Initialized
INFO - 2017-03-12 00:48:44 --> Security Class Initialized
INFO - 2017-03-12 00:48:44 --> Output Class Initialized
INFO - 2017-03-12 00:48:44 --> Output Class Initialized
INFO - 2017-03-12 00:48:44 --> Security Class Initialized
INFO - 2017-03-12 00:48:44 --> Security Class Initialized
DEBUG - 2017-03-12 00:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:48:44 --> Input Class Initialized
DEBUG - 2017-03-12 00:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:48:44 --> Language Class Initialized
INFO - 2017-03-12 00:48:44 --> Input Class Initialized
INFO - 2017-03-12 00:48:44 --> Language Class Initialized
INFO - 2017-03-12 00:48:44 --> Output Class Initialized
INFO - 2017-03-12 00:48:44 --> Security Class Initialized
INFO - 2017-03-12 00:48:44 --> Loader Class Initialized
DEBUG - 2017-03-12 00:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:48:44 --> Input Class Initialized
INFO - 2017-03-12 00:48:44 --> Language Class Initialized
INFO - 2017-03-12 00:48:44 --> Loader Class Initialized
DEBUG - 2017-03-12 00:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:48:44 --> Input Class Initialized
INFO - 2017-03-12 00:48:44 --> Language Class Initialized
INFO - 2017-03-12 00:48:44 --> Loader Class Initialized
INFO - 2017-03-12 00:48:44 --> Loader Class Initialized
INFO - 2017-03-12 00:48:44 --> Database Driver Class Initialized
INFO - 2017-03-12 00:48:44 --> Database Driver Class Initialized
INFO - 2017-03-12 00:48:44 --> Database Driver Class Initialized
INFO - 2017-03-12 00:48:44 --> Database Driver Class Initialized
INFO - 2017-03-12 00:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:48:45 --> Controller Class Initialized
INFO - 2017-03-12 00:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:48:45 --> Controller Class Initialized
INFO - 2017-03-12 00:48:45 --> Controller Class Initialized
INFO - 2017-03-12 00:48:45 --> Helper loaded: url_helper
INFO - 2017-03-12 00:48:45 --> Helper loaded: url_helper
INFO - 2017-03-12 00:48:45 --> Controller Class Initialized
DEBUG - 2017-03-12 00:48:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:48:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:48:45 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:48:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:48:45 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:48:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:48:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:48:46 --> Final output sent to browser
DEBUG - 2017-03-12 00:48:46 --> Total execution time: 2.5261
INFO - 2017-03-12 00:48:46 --> Final output sent to browser
DEBUG - 2017-03-12 00:48:46 --> Total execution time: 2.5264
INFO - 2017-03-12 00:48:46 --> Final output sent to browser
DEBUG - 2017-03-12 00:48:46 --> Total execution time: 2.5260
INFO - 2017-03-12 00:48:46 --> Final output sent to browser
DEBUG - 2017-03-12 00:48:46 --> Total execution time: 2.5260
INFO - 2017-03-12 00:49:17 --> Config Class Initialized
INFO - 2017-03-12 00:49:17 --> Hooks Class Initialized
INFO - 2017-03-12 00:49:18 --> Config Class Initialized
INFO - 2017-03-12 00:49:18 --> Hooks Class Initialized
INFO - 2017-03-12 00:49:18 --> Config Class Initialized
INFO - 2017-03-12 00:49:18 --> Hooks Class Initialized
INFO - 2017-03-12 00:49:18 --> Config Class Initialized
DEBUG - 2017-03-12 00:49:18 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:49:18 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:49:18 --> Hooks Class Initialized
INFO - 2017-03-12 00:49:18 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:49:18 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:49:18 --> Utf8 Class Initialized
INFO - 2017-03-12 00:49:18 --> URI Class Initialized
DEBUG - 2017-03-12 00:49:18 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:49:18 --> Utf8 Class Initialized
INFO - 2017-03-12 00:49:18 --> URI Class Initialized
INFO - 2017-03-12 00:49:18 --> Utf8 Class Initialized
INFO - 2017-03-12 00:49:18 --> Router Class Initialized
INFO - 2017-03-12 00:49:18 --> URI Class Initialized
INFO - 2017-03-12 00:49:18 --> Router Class Initialized
INFO - 2017-03-12 00:49:18 --> URI Class Initialized
INFO - 2017-03-12 00:49:18 --> Output Class Initialized
INFO - 2017-03-12 00:49:18 --> Router Class Initialized
INFO - 2017-03-12 00:49:18 --> Router Class Initialized
INFO - 2017-03-12 00:49:18 --> Security Class Initialized
INFO - 2017-03-12 00:49:18 --> Output Class Initialized
INFO - 2017-03-12 00:49:19 --> Output Class Initialized
DEBUG - 2017-03-12 00:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:49:19 --> Security Class Initialized
INFO - 2017-03-12 00:49:19 --> Input Class Initialized
INFO - 2017-03-12 00:49:19 --> Security Class Initialized
DEBUG - 2017-03-12 00:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:49:19 --> Input Class Initialized
INFO - 2017-03-12 00:49:19 --> Output Class Initialized
INFO - 2017-03-12 00:49:19 --> Config Class Initialized
INFO - 2017-03-12 00:49:19 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:49:19 --> Input Class Initialized
INFO - 2017-03-12 00:49:19 --> Language Class Initialized
INFO - 2017-03-12 00:49:19 --> Language Class Initialized
INFO - 2017-03-12 00:49:19 --> Language Class Initialized
INFO - 2017-03-12 00:49:19 --> Security Class Initialized
DEBUG - 2017-03-12 00:49:20 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:49:20 --> Loader Class Initialized
DEBUG - 2017-03-12 00:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:49:20 --> Utf8 Class Initialized
INFO - 2017-03-12 00:49:20 --> Config Class Initialized
INFO - 2017-03-12 00:49:20 --> URI Class Initialized
INFO - 2017-03-12 00:49:20 --> Hooks Class Initialized
INFO - 2017-03-12 00:49:20 --> Loader Class Initialized
INFO - 2017-03-12 00:49:20 --> Router Class Initialized
INFO - 2017-03-12 00:49:20 --> Input Class Initialized
INFO - 2017-03-12 00:49:21 --> Loader Class Initialized
INFO - 2017-03-12 00:49:21 --> Language Class Initialized
INFO - 2017-03-12 00:49:21 --> Output Class Initialized
INFO - 2017-03-12 00:49:22 --> Database Driver Class Initialized
DEBUG - 2017-03-12 00:49:22 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:49:22 --> Config Class Initialized
INFO - 2017-03-12 00:49:22 --> Utf8 Class Initialized
INFO - 2017-03-12 00:49:22 --> Security Class Initialized
INFO - 2017-03-12 00:49:22 --> Database Driver Class Initialized
INFO - 2017-03-12 00:49:23 --> Loader Class Initialized
INFO - 2017-03-12 00:49:23 --> URI Class Initialized
INFO - 2017-03-12 00:49:23 --> Database Driver Class Initialized
DEBUG - 2017-03-12 00:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:49:24 --> Input Class Initialized
INFO - 2017-03-12 00:49:24 --> Router Class Initialized
INFO - 2017-03-12 00:49:25 --> Hooks Class Initialized
INFO - 2017-03-12 00:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:49:25 --> Database Driver Class Initialized
INFO - 2017-03-12 00:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:49:25 --> Language Class Initialized
INFO - 2017-03-12 00:49:25 --> Output Class Initialized
INFO - 2017-03-12 00:49:25 --> Controller Class Initialized
INFO - 2017-03-12 00:49:25 --> Controller Class Initialized
INFO - 2017-03-12 00:49:25 --> Security Class Initialized
DEBUG - 2017-03-12 00:49:26 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:49:26 --> Controller Class Initialized
INFO - 2017-03-12 00:49:26 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:49:26 --> Helper loaded: url_helper
INFO - 2017-03-12 00:49:26 --> Input Class Initialized
INFO - 2017-03-12 00:49:26 --> URI Class Initialized
INFO - 2017-03-12 00:49:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-03-12 00:49:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:49:26 --> Helper loaded: url_helper
INFO - 2017-03-12 00:49:26 --> Language Class Initialized
INFO - 2017-03-12 00:49:26 --> Helper loaded: url_helper
INFO - 2017-03-12 00:49:26 --> Router Class Initialized
DEBUG - 2017-03-12 00:49:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:49:26 --> Controller Class Initialized
INFO - 2017-03-12 00:49:26 --> Output Class Initialized
DEBUG - 2017-03-12 00:49:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:49:26 --> Loader Class Initialized
INFO - 2017-03-12 00:49:26 --> Loader Class Initialized
INFO - 2017-03-12 00:49:26 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:49:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:49:26 --> Security Class Initialized
DEBUG - 2017-03-12 00:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:49:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:49:27 --> Input Class Initialized
INFO - 2017-03-12 00:49:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:49:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:49:27 --> Language Class Initialized
INFO - 2017-03-12 00:49:27 --> Database Driver Class Initialized
INFO - 2017-03-12 00:49:27 --> Loader Class Initialized
INFO - 2017-03-12 00:49:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:49:27 --> Database Driver Class Initialized
INFO - 2017-03-12 00:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:49:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:49:27 --> Controller Class Initialized
INFO - 2017-03-12 00:49:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:49:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:49:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:49:27 --> Database Driver Class Initialized
INFO - 2017-03-12 00:49:27 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:49:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:49:27 --> Final output sent to browser
DEBUG - 2017-03-12 00:49:27 --> Total execution time: 11.3779
INFO - 2017-03-12 00:49:27 --> Final output sent to browser
DEBUG - 2017-03-12 00:49:28 --> Total execution time: 11.3629
INFO - 2017-03-12 00:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:49:34 --> Controller Class Initialized
INFO - 2017-03-12 00:49:34 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:49:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:49:37 --> Config Class Initialized
INFO - 2017-03-12 00:49:37 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:49:38 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:49:38 --> Utf8 Class Initialized
INFO - 2017-03-12 00:49:38 --> Config Class Initialized
INFO - 2017-03-12 00:49:38 --> Hooks Class Initialized
INFO - 2017-03-12 00:49:38 --> URI Class Initialized
DEBUG - 2017-03-12 00:49:39 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:49:39 --> Utf8 Class Initialized
INFO - 2017-03-12 00:49:39 --> URI Class Initialized
INFO - 2017-03-12 00:49:39 --> Router Class Initialized
INFO - 2017-03-12 00:49:39 --> Router Class Initialized
INFO - 2017-03-12 00:49:39 --> Output Class Initialized
INFO - 2017-03-12 00:49:39 --> Output Class Initialized
INFO - 2017-03-12 00:49:39 --> Security Class Initialized
INFO - 2017-03-12 00:49:39 --> Security Class Initialized
DEBUG - 2017-03-12 00:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:49:40 --> Input Class Initialized
DEBUG - 2017-03-12 00:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:49:40 --> Language Class Initialized
INFO - 2017-03-12 00:49:40 --> Input Class Initialized
INFO - 2017-03-12 00:49:40 --> Language Class Initialized
INFO - 2017-03-12 00:49:40 --> Loader Class Initialized
INFO - 2017-03-12 00:49:40 --> Loader Class Initialized
INFO - 2017-03-12 00:49:41 --> Database Driver Class Initialized
INFO - 2017-03-12 00:49:41 --> Database Driver Class Initialized
INFO - 2017-03-12 00:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:49:41 --> Controller Class Initialized
INFO - 2017-03-12 00:49:41 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:49:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:49:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:49:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:49:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:49:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:49:42 --> Final output sent to browser
DEBUG - 2017-03-12 00:49:42 --> Total execution time: 8.2096
INFO - 2017-03-12 00:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:49:44 --> Controller Class Initialized
INFO - 2017-03-12 00:49:44 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:49:45 --> Config Class Initialized
INFO - 2017-03-12 00:49:45 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:49:45 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:49:45 --> Utf8 Class Initialized
INFO - 2017-03-12 00:49:45 --> Config Class Initialized
INFO - 2017-03-12 00:49:45 --> URI Class Initialized
INFO - 2017-03-12 00:49:45 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:49:45 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:49:45 --> Utf8 Class Initialized
INFO - 2017-03-12 00:49:45 --> Router Class Initialized
INFO - 2017-03-12 00:49:45 --> URI Class Initialized
INFO - 2017-03-12 00:49:45 --> Router Class Initialized
INFO - 2017-03-12 00:49:45 --> Output Class Initialized
INFO - 2017-03-12 00:49:45 --> Output Class Initialized
INFO - 2017-03-12 00:49:45 --> Security Class Initialized
INFO - 2017-03-12 00:49:45 --> Security Class Initialized
DEBUG - 2017-03-12 00:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-03-12 00:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:49:45 --> Input Class Initialized
INFO - 2017-03-12 00:49:46 --> Input Class Initialized
INFO - 2017-03-12 00:49:46 --> Language Class Initialized
INFO - 2017-03-12 00:49:46 --> Language Class Initialized
INFO - 2017-03-12 00:49:46 --> Loader Class Initialized
INFO - 2017-03-12 00:49:46 --> Loader Class Initialized
INFO - 2017-03-12 00:49:47 --> Database Driver Class Initialized
INFO - 2017-03-12 00:49:47 --> Database Driver Class Initialized
INFO - 2017-03-12 00:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:49:47 --> Controller Class Initialized
INFO - 2017-03-12 00:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:49:47 --> Controller Class Initialized
INFO - 2017-03-12 00:49:47 --> Helper loaded: date_helper
INFO - 2017-03-12 00:49:47 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:49:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:49:47 --> Helper loaded: url_helper
INFO - 2017-03-12 00:49:47 --> Helper loaded: url_helper
INFO - 2017-03-12 00:49:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:49:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:49:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 00:49:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 00:49:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 00:49:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 00:49:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 00:49:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 00:49:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:49:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:49:49 --> Final output sent to browser
DEBUG - 2017-03-12 00:49:49 --> Total execution time: 3.6102
INFO - 2017-03-12 00:49:49 --> Final output sent to browser
DEBUG - 2017-03-12 00:49:49 --> Total execution time: 3.8199
INFO - 2017-03-12 00:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:49:50 --> Controller Class Initialized
INFO - 2017-03-12 00:49:50 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:49:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:49:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:49:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:49:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:49:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:49:51 --> Final output sent to browser
DEBUG - 2017-03-12 00:49:51 --> Total execution time: 17.6917
INFO - 2017-03-12 00:49:52 --> Config Class Initialized
INFO - 2017-03-12 00:49:52 --> Hooks Class Initialized
INFO - 2017-03-12 00:49:52 --> Config Class Initialized
INFO - 2017-03-12 00:49:52 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:49:52 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:49:52 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:49:52 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:49:52 --> Utf8 Class Initialized
INFO - 2017-03-12 00:49:52 --> URI Class Initialized
INFO - 2017-03-12 00:49:52 --> URI Class Initialized
INFO - 2017-03-12 00:49:52 --> Router Class Initialized
INFO - 2017-03-12 00:49:52 --> Router Class Initialized
INFO - 2017-03-12 00:49:52 --> Output Class Initialized
INFO - 2017-03-12 00:49:52 --> Output Class Initialized
INFO - 2017-03-12 00:49:52 --> Security Class Initialized
INFO - 2017-03-12 00:49:52 --> Security Class Initialized
DEBUG - 2017-03-12 00:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:49:52 --> Input Class Initialized
INFO - 2017-03-12 00:49:52 --> Language Class Initialized
DEBUG - 2017-03-12 00:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:49:52 --> Input Class Initialized
INFO - 2017-03-12 00:49:52 --> Language Class Initialized
INFO - 2017-03-12 00:49:52 --> Loader Class Initialized
INFO - 2017-03-12 00:49:52 --> Loader Class Initialized
INFO - 2017-03-12 00:49:53 --> Database Driver Class Initialized
INFO - 2017-03-12 00:49:53 --> Database Driver Class Initialized
INFO - 2017-03-12 00:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:49:53 --> Controller Class Initialized
INFO - 2017-03-12 00:49:53 --> Controller Class Initialized
INFO - 2017-03-12 00:49:53 --> Helper loaded: url_helper
INFO - 2017-03-12 00:49:53 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:49:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:49:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:49:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:49:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:49:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:49:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:49:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:49:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:49:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:49:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:49:53 --> Final output sent to browser
DEBUG - 2017-03-12 00:49:53 --> Total execution time: 2.3401
INFO - 2017-03-12 00:49:53 --> Final output sent to browser
DEBUG - 2017-03-12 00:49:53 --> Total execution time: 2.3405
INFO - 2017-03-12 00:49:58 --> Config Class Initialized
INFO - 2017-03-12 00:49:58 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:49:59 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:49:59 --> Utf8 Class Initialized
INFO - 2017-03-12 00:49:59 --> URI Class Initialized
INFO - 2017-03-12 00:49:59 --> Router Class Initialized
INFO - 2017-03-12 00:49:59 --> Output Class Initialized
INFO - 2017-03-12 00:49:59 --> Security Class Initialized
DEBUG - 2017-03-12 00:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:49:59 --> Input Class Initialized
INFO - 2017-03-12 00:49:59 --> Language Class Initialized
INFO - 2017-03-12 00:49:59 --> Loader Class Initialized
INFO - 2017-03-12 00:49:59 --> Database Driver Class Initialized
INFO - 2017-03-12 00:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:49:59 --> Controller Class Initialized
INFO - 2017-03-12 00:49:59 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:49:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:49:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:50:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:50:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:50:00 --> Final output sent to browser
DEBUG - 2017-03-12 00:50:00 --> Total execution time: 1.2626
INFO - 2017-03-12 00:50:38 --> Config Class Initialized
INFO - 2017-03-12 00:50:38 --> Config Class Initialized
INFO - 2017-03-12 00:50:39 --> Hooks Class Initialized
INFO - 2017-03-12 00:50:39 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:50:39 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:50:39 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:50:39 --> Utf8 Class Initialized
INFO - 2017-03-12 00:50:39 --> Utf8 Class Initialized
INFO - 2017-03-12 00:50:39 --> URI Class Initialized
INFO - 2017-03-12 00:50:39 --> URI Class Initialized
INFO - 2017-03-12 00:50:39 --> Router Class Initialized
DEBUG - 2017-03-12 00:50:39 --> No URI present. Default controller set.
INFO - 2017-03-12 00:50:39 --> Router Class Initialized
INFO - 2017-03-12 00:50:39 --> Output Class Initialized
INFO - 2017-03-12 00:50:39 --> Output Class Initialized
INFO - 2017-03-12 00:50:39 --> Security Class Initialized
INFO - 2017-03-12 00:50:39 --> Security Class Initialized
DEBUG - 2017-03-12 00:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:50:39 --> Input Class Initialized
DEBUG - 2017-03-12 00:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:50:39 --> Language Class Initialized
INFO - 2017-03-12 00:50:39 --> Input Class Initialized
INFO - 2017-03-12 00:50:39 --> Language Class Initialized
INFO - 2017-03-12 00:50:39 --> Loader Class Initialized
INFO - 2017-03-12 00:50:39 --> Loader Class Initialized
INFO - 2017-03-12 00:50:39 --> Database Driver Class Initialized
INFO - 2017-03-12 00:50:39 --> Database Driver Class Initialized
INFO - 2017-03-12 00:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:50:40 --> Controller Class Initialized
INFO - 2017-03-12 00:50:40 --> Helper loaded: url_helper
INFO - 2017-03-12 00:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:50:40 --> Controller Class Initialized
INFO - 2017-03-12 00:50:40 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:50:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:50:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:50:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:50:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:50:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:50:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:50:40 --> Final output sent to browser
DEBUG - 2017-03-12 00:50:40 --> Total execution time: 1.7010
INFO - 2017-03-12 00:50:50 --> Config Class Initialized
INFO - 2017-03-12 00:50:50 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:50:50 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:50:50 --> Utf8 Class Initialized
INFO - 2017-03-12 00:50:50 --> URI Class Initialized
INFO - 2017-03-12 00:50:50 --> Router Class Initialized
INFO - 2017-03-12 00:50:50 --> Output Class Initialized
INFO - 2017-03-12 00:50:50 --> Security Class Initialized
DEBUG - 2017-03-12 00:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:50:50 --> Input Class Initialized
INFO - 2017-03-12 00:50:50 --> Language Class Initialized
INFO - 2017-03-12 00:50:50 --> Loader Class Initialized
INFO - 2017-03-12 00:50:51 --> Database Driver Class Initialized
INFO - 2017-03-12 00:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:50:51 --> Controller Class Initialized
INFO - 2017-03-12 00:50:51 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:50:51 --> Helper loaded: url_helper
INFO - 2017-03-12 00:50:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:50:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 00:50:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 00:50:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 00:50:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:50:51 --> Final output sent to browser
DEBUG - 2017-03-12 00:50:51 --> Total execution time: 1.4261
INFO - 2017-03-12 00:50:55 --> Config Class Initialized
INFO - 2017-03-12 00:50:55 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:50:55 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:50:55 --> Utf8 Class Initialized
INFO - 2017-03-12 00:50:55 --> URI Class Initialized
INFO - 2017-03-12 00:50:55 --> Router Class Initialized
INFO - 2017-03-12 00:50:55 --> Output Class Initialized
INFO - 2017-03-12 00:50:55 --> Security Class Initialized
DEBUG - 2017-03-12 00:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:50:55 --> Input Class Initialized
INFO - 2017-03-12 00:50:55 --> Language Class Initialized
INFO - 2017-03-12 00:50:55 --> Loader Class Initialized
INFO - 2017-03-12 00:50:55 --> Database Driver Class Initialized
INFO - 2017-03-12 00:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:50:55 --> Controller Class Initialized
INFO - 2017-03-12 00:50:55 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:50:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:50:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:50:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:50:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:50:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:50:56 --> Final output sent to browser
DEBUG - 2017-03-12 00:50:56 --> Total execution time: 0.3179
INFO - 2017-03-12 00:51:18 --> Config Class Initialized
INFO - 2017-03-12 00:51:18 --> Hooks Class Initialized
INFO - 2017-03-12 00:51:18 --> Config Class Initialized
INFO - 2017-03-12 00:51:18 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:51:18 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:51:18 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:51:18 --> Utf8 Class Initialized
INFO - 2017-03-12 00:51:18 --> Utf8 Class Initialized
INFO - 2017-03-12 00:51:18 --> URI Class Initialized
INFO - 2017-03-12 00:51:18 --> URI Class Initialized
INFO - 2017-03-12 00:51:18 --> Router Class Initialized
INFO - 2017-03-12 00:51:18 --> Output Class Initialized
DEBUG - 2017-03-12 00:51:18 --> No URI present. Default controller set.
INFO - 2017-03-12 00:51:18 --> Router Class Initialized
INFO - 2017-03-12 00:51:18 --> Security Class Initialized
INFO - 2017-03-12 00:51:18 --> Output Class Initialized
INFO - 2017-03-12 00:51:18 --> Security Class Initialized
DEBUG - 2017-03-12 00:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:51:19 --> Input Class Initialized
INFO - 2017-03-12 00:51:19 --> Language Class Initialized
DEBUG - 2017-03-12 00:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:51:19 --> Input Class Initialized
INFO - 2017-03-12 00:51:19 --> Language Class Initialized
INFO - 2017-03-12 00:51:19 --> Loader Class Initialized
INFO - 2017-03-12 00:51:19 --> Loader Class Initialized
INFO - 2017-03-12 00:51:19 --> Database Driver Class Initialized
INFO - 2017-03-12 00:51:19 --> Database Driver Class Initialized
INFO - 2017-03-12 00:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:51:19 --> Controller Class Initialized
INFO - 2017-03-12 00:51:19 --> Helper loaded: url_helper
INFO - 2017-03-12 00:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:51:20 --> Controller Class Initialized
DEBUG - 2017-03-12 00:51:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:51:20 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:51:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:51:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:51:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:51:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:51:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:51:20 --> Final output sent to browser
DEBUG - 2017-03-12 00:51:20 --> Total execution time: 2.4624
INFO - 2017-03-12 00:51:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 00:51:30 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:51:30 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:51:30 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:51:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:51:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:51:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:51:31 --> Final output sent to browser
DEBUG - 2017-03-12 00:51:31 --> Total execution time: 13.2181
INFO - 2017-03-12 00:51:34 --> Config Class Initialized
INFO - 2017-03-12 00:51:34 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:51:34 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:51:34 --> Utf8 Class Initialized
INFO - 2017-03-12 00:51:34 --> URI Class Initialized
INFO - 2017-03-12 00:51:34 --> Router Class Initialized
INFO - 2017-03-12 00:51:34 --> Output Class Initialized
INFO - 2017-03-12 00:51:34 --> Security Class Initialized
DEBUG - 2017-03-12 00:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:51:34 --> Input Class Initialized
INFO - 2017-03-12 00:51:34 --> Language Class Initialized
INFO - 2017-03-12 00:51:35 --> Loader Class Initialized
INFO - 2017-03-12 00:51:35 --> Database Driver Class Initialized
INFO - 2017-03-12 00:51:35 --> Config Class Initialized
INFO - 2017-03-12 00:51:35 --> Hooks Class Initialized
INFO - 2017-03-12 00:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:51:36 --> Controller Class Initialized
INFO - 2017-03-12 00:51:36 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:51:36 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:51:36 --> Utf8 Class Initialized
INFO - 2017-03-12 00:51:36 --> URI Class Initialized
DEBUG - 2017-03-12 00:51:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:51:36 --> Router Class Initialized
INFO - 2017-03-12 00:51:36 --> Output Class Initialized
INFO - 2017-03-12 00:51:36 --> Security Class Initialized
INFO - 2017-03-12 00:51:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
DEBUG - 2017-03-12 00:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:51:37 --> Input Class Initialized
INFO - 2017-03-12 00:51:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:51:37 --> Language Class Initialized
INFO - 2017-03-12 00:51:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:51:37 --> Loader Class Initialized
INFO - 2017-03-12 00:51:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:51:37 --> Final output sent to browser
DEBUG - 2017-03-12 00:51:37 --> Total execution time: 4.3588
INFO - 2017-03-12 00:51:37 --> Database Driver Class Initialized
INFO - 2017-03-12 00:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:51:38 --> Controller Class Initialized
INFO - 2017-03-12 00:51:38 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:51:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:51:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:51:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:51:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:51:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:51:40 --> Final output sent to browser
DEBUG - 2017-03-12 00:51:40 --> Total execution time: 7.3358
INFO - 2017-03-12 00:51:54 --> Config Class Initialized
INFO - 2017-03-12 00:51:54 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:51:54 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:51:54 --> Utf8 Class Initialized
INFO - 2017-03-12 00:51:54 --> URI Class Initialized
INFO - 2017-03-12 00:51:54 --> Router Class Initialized
INFO - 2017-03-12 00:51:54 --> Output Class Initialized
INFO - 2017-03-12 00:51:55 --> Security Class Initialized
DEBUG - 2017-03-12 00:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:51:55 --> Input Class Initialized
INFO - 2017-03-12 00:51:55 --> Language Class Initialized
INFO - 2017-03-12 00:51:55 --> Loader Class Initialized
INFO - 2017-03-12 00:51:56 --> Database Driver Class Initialized
INFO - 2017-03-12 00:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:51:58 --> Controller Class Initialized
INFO - 2017-03-12 00:51:58 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:51:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:51:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:51:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:51:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:51:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:51:59 --> Final output sent to browser
DEBUG - 2017-03-12 00:51:59 --> Total execution time: 7.5078
INFO - 2017-03-12 00:52:05 --> Config Class Initialized
INFO - 2017-03-12 00:52:05 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:52:05 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:52:05 --> Utf8 Class Initialized
INFO - 2017-03-12 00:52:06 --> URI Class Initialized
INFO - 2017-03-12 00:52:06 --> Router Class Initialized
INFO - 2017-03-12 00:52:06 --> Output Class Initialized
INFO - 2017-03-12 00:52:06 --> Security Class Initialized
DEBUG - 2017-03-12 00:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:52:06 --> Input Class Initialized
INFO - 2017-03-12 00:52:06 --> Language Class Initialized
INFO - 2017-03-12 00:52:06 --> Loader Class Initialized
INFO - 2017-03-12 00:52:07 --> Database Driver Class Initialized
INFO - 2017-03-12 00:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:52:07 --> Controller Class Initialized
INFO - 2017-03-12 00:52:07 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:52:08 --> Final output sent to browser
DEBUG - 2017-03-12 00:52:08 --> Total execution time: 4.6682
INFO - 2017-03-12 00:52:10 --> Config Class Initialized
INFO - 2017-03-12 00:52:10 --> Hooks Class Initialized
INFO - 2017-03-12 00:52:10 --> Config Class Initialized
INFO - 2017-03-12 00:52:10 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:52:11 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:52:11 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:52:11 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:52:11 --> Utf8 Class Initialized
INFO - 2017-03-12 00:52:11 --> URI Class Initialized
INFO - 2017-03-12 00:52:11 --> URI Class Initialized
INFO - 2017-03-12 00:52:11 --> Router Class Initialized
INFO - 2017-03-12 00:52:11 --> Router Class Initialized
INFO - 2017-03-12 00:52:11 --> Output Class Initialized
INFO - 2017-03-12 00:52:11 --> Output Class Initialized
INFO - 2017-03-12 00:52:11 --> Security Class Initialized
INFO - 2017-03-12 00:52:11 --> Security Class Initialized
DEBUG - 2017-03-12 00:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:52:11 --> Input Class Initialized
INFO - 2017-03-12 00:52:11 --> Language Class Initialized
DEBUG - 2017-03-12 00:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:52:11 --> Input Class Initialized
INFO - 2017-03-12 00:52:11 --> Language Class Initialized
INFO - 2017-03-12 00:52:11 --> Loader Class Initialized
INFO - 2017-03-12 00:52:11 --> Loader Class Initialized
INFO - 2017-03-12 00:52:11 --> Database Driver Class Initialized
INFO - 2017-03-12 00:52:11 --> Database Driver Class Initialized
INFO - 2017-03-12 00:52:12 --> Session: Class initialized using 'files' driver.
ERROR - 2017-03-12 00:52:12 --> Severity: Warning --> unlink(/tmp/ci_session471a01508b4ed2234a268883dea705fb1311a8bf): No such file or directory /home/graduafe/public_html/system/libraries/Session/drivers/Session_files_driver.php 311
INFO - 2017-03-12 00:52:12 --> Controller Class Initialized
ERROR - 2017-03-12 00:52:12 --> Severity: Warning --> session_regenerate_id(): Session object destruction failed /home/graduafe/public_html/system/libraries/Session/Session.php 644
INFO - 2017-03-12 00:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:52:12 --> Controller Class Initialized
INFO - 2017-03-12 00:52:12 --> Helper loaded: url_helper
INFO - 2017-03-12 00:52:12 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:52:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:52:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-12 00:52:49 --> Severity: error --> Exception: Operation timed out after 10464 milliseconds with 0 out of 0 bytes received /home/graduafe/public_html/application/libraries/facebook-api-php-codexworld/base_facebook.php 972
ERROR - 2017-03-12 00:52:49 --> Severity: error --> Exception: Operation timed out after 10299 milliseconds with 0 out of 0 bytes received /home/graduafe/public_html/application/libraries/facebook-api-php-codexworld/base_facebook.php 972
ERROR - 2017-03-12 00:52:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-12 00:52:53 --> Config Class Initialized
INFO - 2017-03-12 00:52:53 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:52:53 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:52:53 --> Utf8 Class Initialized
INFO - 2017-03-12 00:52:53 --> URI Class Initialized
DEBUG - 2017-03-12 00:52:53 --> No URI present. Default controller set.
INFO - 2017-03-12 00:52:53 --> Router Class Initialized
INFO - 2017-03-12 00:52:53 --> Output Class Initialized
INFO - 2017-03-12 00:52:53 --> Security Class Initialized
DEBUG - 2017-03-12 00:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:52:53 --> Input Class Initialized
INFO - 2017-03-12 00:52:53 --> Language Class Initialized
INFO - 2017-03-12 00:52:53 --> Loader Class Initialized
INFO - 2017-03-12 00:52:54 --> Database Driver Class Initialized
INFO - 2017-03-12 00:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:52:54 --> Controller Class Initialized
INFO - 2017-03-12 00:52:54 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:52:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:52:54 --> Final output sent to browser
DEBUG - 2017-03-12 00:52:54 --> Total execution time: 1.9959
INFO - 2017-03-12 00:52:58 --> Config Class Initialized
INFO - 2017-03-12 00:52:58 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:52:59 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:52:59 --> Utf8 Class Initialized
INFO - 2017-03-12 00:52:59 --> URI Class Initialized
INFO - 2017-03-12 00:52:59 --> Router Class Initialized
INFO - 2017-03-12 00:52:59 --> Output Class Initialized
INFO - 2017-03-12 00:52:59 --> Security Class Initialized
DEBUG - 2017-03-12 00:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:52:59 --> Input Class Initialized
INFO - 2017-03-12 00:52:59 --> Language Class Initialized
INFO - 2017-03-12 00:52:59 --> Loader Class Initialized
INFO - 2017-03-12 00:52:59 --> Database Driver Class Initialized
INFO - 2017-03-12 00:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:52:59 --> Controller Class Initialized
INFO - 2017-03-12 00:52:59 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:53:00 --> Final output sent to browser
DEBUG - 2017-03-12 00:53:00 --> Total execution time: 1.5149
INFO - 2017-03-12 00:53:10 --> Config Class Initialized
INFO - 2017-03-12 00:53:10 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:53:10 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:53:10 --> Utf8 Class Initialized
INFO - 2017-03-12 00:53:10 --> URI Class Initialized
INFO - 2017-03-12 00:53:10 --> Router Class Initialized
INFO - 2017-03-12 00:53:11 --> Output Class Initialized
INFO - 2017-03-12 00:53:11 --> Security Class Initialized
DEBUG - 2017-03-12 00:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:53:11 --> Input Class Initialized
INFO - 2017-03-12 00:53:11 --> Language Class Initialized
INFO - 2017-03-12 00:53:11 --> Loader Class Initialized
INFO - 2017-03-12 00:53:11 --> Database Driver Class Initialized
INFO - 2017-03-12 00:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:53:12 --> Controller Class Initialized
INFO - 2017-03-12 00:53:12 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:53:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:53:13 --> Config Class Initialized
INFO - 2017-03-12 00:53:13 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:53:14 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:53:14 --> Utf8 Class Initialized
INFO - 2017-03-12 00:53:14 --> URI Class Initialized
DEBUG - 2017-03-12 00:53:15 --> No URI present. Default controller set.
INFO - 2017-03-12 00:53:15 --> Router Class Initialized
INFO - 2017-03-12 00:53:15 --> Output Class Initialized
INFO - 2017-03-12 00:53:16 --> Security Class Initialized
DEBUG - 2017-03-12 00:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:53:16 --> Input Class Initialized
INFO - 2017-03-12 00:53:16 --> Language Class Initialized
INFO - 2017-03-12 00:53:17 --> Loader Class Initialized
INFO - 2017-03-12 00:53:17 --> Database Driver Class Initialized
INFO - 2017-03-12 00:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:53:19 --> Controller Class Initialized
INFO - 2017-03-12 00:53:19 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:53:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:53:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:53:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:53:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:53:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:53:23 --> Final output sent to browser
DEBUG - 2017-03-12 00:53:23 --> Total execution time: 12.5169
INFO - 2017-03-12 00:53:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 00:53:30 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:53:30 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:53:30 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:53:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:53:30 --> Config Class Initialized
INFO - 2017-03-12 00:53:30 --> Config Class Initialized
INFO - 2017-03-12 00:53:30 --> Hooks Class Initialized
INFO - 2017-03-12 00:53:30 --> Hooks Class Initialized
INFO - 2017-03-12 00:53:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:53:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:53:30 --> Final output sent to browser
DEBUG - 2017-03-12 00:53:30 --> Total execution time: 20.3337
DEBUG - 2017-03-12 00:53:30 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:53:31 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:53:31 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:53:31 --> Utf8 Class Initialized
INFO - 2017-03-12 00:53:31 --> URI Class Initialized
INFO - 2017-03-12 00:53:31 --> URI Class Initialized
INFO - 2017-03-12 00:53:31 --> Router Class Initialized
INFO - 2017-03-12 00:53:32 --> Router Class Initialized
INFO - 2017-03-12 00:53:32 --> Output Class Initialized
INFO - 2017-03-12 00:53:32 --> Output Class Initialized
INFO - 2017-03-12 00:53:32 --> Security Class Initialized
INFO - 2017-03-12 00:53:32 --> Security Class Initialized
DEBUG - 2017-03-12 00:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-03-12 00:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:53:33 --> Input Class Initialized
INFO - 2017-03-12 00:53:33 --> Input Class Initialized
INFO - 2017-03-12 00:53:33 --> Language Class Initialized
INFO - 2017-03-12 00:53:33 --> Language Class Initialized
INFO - 2017-03-12 00:53:34 --> Loader Class Initialized
INFO - 2017-03-12 00:53:34 --> Loader Class Initialized
INFO - 2017-03-12 00:53:36 --> Database Driver Class Initialized
INFO - 2017-03-12 00:53:36 --> Database Driver Class Initialized
INFO - 2017-03-12 00:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:53:38 --> Controller Class Initialized
INFO - 2017-03-12 00:53:38 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:53:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:53:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:53:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:53:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:53:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:53:40 --> Final output sent to browser
DEBUG - 2017-03-12 00:53:40 --> Total execution time: 9.8639
INFO - 2017-03-12 00:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:53:41 --> Controller Class Initialized
INFO - 2017-03-12 00:53:43 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:53:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:53:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:53:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:53:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:53:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:53:45 --> Final output sent to browser
DEBUG - 2017-03-12 00:53:45 --> Total execution time: 14.9028
INFO - 2017-03-12 00:53:51 --> Config Class Initialized
INFO - 2017-03-12 00:53:51 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:53:52 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:53:52 --> Utf8 Class Initialized
INFO - 2017-03-12 00:53:52 --> URI Class Initialized
INFO - 2017-03-12 00:53:52 --> Router Class Initialized
INFO - 2017-03-12 00:53:52 --> Output Class Initialized
INFO - 2017-03-12 00:53:52 --> Security Class Initialized
DEBUG - 2017-03-12 00:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:53:52 --> Input Class Initialized
INFO - 2017-03-12 00:53:52 --> Language Class Initialized
INFO - 2017-03-12 00:53:52 --> Loader Class Initialized
INFO - 2017-03-12 00:53:53 --> Database Driver Class Initialized
INFO - 2017-03-12 00:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:53:54 --> Controller Class Initialized
INFO - 2017-03-12 00:53:54 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:53:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:53:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:53:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:53:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:53:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:53:55 --> Final output sent to browser
DEBUG - 2017-03-12 00:53:55 --> Total execution time: 5.4321
INFO - 2017-03-12 00:54:05 --> Config Class Initialized
INFO - 2017-03-12 00:54:05 --> Hooks Class Initialized
INFO - 2017-03-12 00:54:05 --> Config Class Initialized
INFO - 2017-03-12 00:54:05 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:54:05 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:54:05 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:54:05 --> Utf8 Class Initialized
INFO - 2017-03-12 00:54:05 --> Utf8 Class Initialized
INFO - 2017-03-12 00:54:05 --> URI Class Initialized
INFO - 2017-03-12 00:54:05 --> URI Class Initialized
INFO - 2017-03-12 00:54:06 --> Router Class Initialized
DEBUG - 2017-03-12 00:54:06 --> No URI present. Default controller set.
INFO - 2017-03-12 00:54:06 --> Router Class Initialized
INFO - 2017-03-12 00:54:06 --> Output Class Initialized
INFO - 2017-03-12 00:54:06 --> Output Class Initialized
INFO - 2017-03-12 00:54:06 --> Security Class Initialized
INFO - 2017-03-12 00:54:06 --> Security Class Initialized
DEBUG - 2017-03-12 00:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-03-12 00:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:54:06 --> Input Class Initialized
INFO - 2017-03-12 00:54:06 --> Input Class Initialized
INFO - 2017-03-12 00:54:06 --> Language Class Initialized
INFO - 2017-03-12 00:54:06 --> Language Class Initialized
INFO - 2017-03-12 00:54:06 --> Loader Class Initialized
INFO - 2017-03-12 00:54:06 --> Loader Class Initialized
INFO - 2017-03-12 00:54:06 --> Database Driver Class Initialized
INFO - 2017-03-12 00:54:06 --> Database Driver Class Initialized
INFO - 2017-03-12 00:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:54:07 --> Controller Class Initialized
INFO - 2017-03-12 00:54:07 --> Helper loaded: url_helper
INFO - 2017-03-12 00:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:54:07 --> Controller Class Initialized
INFO - 2017-03-12 00:54:07 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:54:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:54:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:54:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:54:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:54:08 --> Final output sent to browser
DEBUG - 2017-03-12 00:54:08 --> Total execution time: 2.9767
INFO - 2017-03-12 00:54:08 --> Final output sent to browser
DEBUG - 2017-03-12 00:54:08 --> Total execution time: 2.9688
INFO - 2017-03-12 00:54:15 --> Config Class Initialized
INFO - 2017-03-12 00:54:15 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:54:15 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:54:15 --> Utf8 Class Initialized
INFO - 2017-03-12 00:54:15 --> URI Class Initialized
INFO - 2017-03-12 00:54:16 --> Router Class Initialized
INFO - 2017-03-12 00:54:16 --> Output Class Initialized
INFO - 2017-03-12 00:54:16 --> Security Class Initialized
DEBUG - 2017-03-12 00:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:54:16 --> Input Class Initialized
INFO - 2017-03-12 00:54:16 --> Language Class Initialized
INFO - 2017-03-12 00:54:17 --> Loader Class Initialized
INFO - 2017-03-12 00:54:18 --> Database Driver Class Initialized
INFO - 2017-03-12 00:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:54:19 --> Controller Class Initialized
INFO - 2017-03-12 00:54:19 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:54:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:54:25 --> Config Class Initialized
INFO - 2017-03-12 00:54:25 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:54:25 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:54:25 --> Utf8 Class Initialized
INFO - 2017-03-12 00:54:25 --> URI Class Initialized
INFO - 2017-03-12 00:54:25 --> Router Class Initialized
INFO - 2017-03-12 00:54:25 --> Config Class Initialized
INFO - 2017-03-12 00:54:25 --> Output Class Initialized
INFO - 2017-03-12 00:54:25 --> Hooks Class Initialized
INFO - 2017-03-12 00:54:25 --> Security Class Initialized
DEBUG - 2017-03-12 00:54:25 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:54:25 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:54:25 --> URI Class Initialized
INFO - 2017-03-12 00:54:25 --> Input Class Initialized
INFO - 2017-03-12 00:54:25 --> Language Class Initialized
INFO - 2017-03-12 00:54:25 --> Router Class Initialized
INFO - 2017-03-12 00:54:25 --> Output Class Initialized
INFO - 2017-03-12 00:54:25 --> Security Class Initialized
DEBUG - 2017-03-12 00:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:54:25 --> Loader Class Initialized
INFO - 2017-03-12 00:54:25 --> Input Class Initialized
INFO - 2017-03-12 00:54:25 --> Language Class Initialized
INFO - 2017-03-12 00:54:26 --> Config Class Initialized
INFO - 2017-03-12 00:54:26 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:54:26 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:54:26 --> Utf8 Class Initialized
INFO - 2017-03-12 00:54:26 --> Config Class Initialized
INFO - 2017-03-12 00:54:26 --> Hooks Class Initialized
INFO - 2017-03-12 00:54:26 --> Database Driver Class Initialized
INFO - 2017-03-12 00:54:26 --> URI Class Initialized
INFO - 2017-03-12 00:54:26 --> Loader Class Initialized
INFO - 2017-03-12 00:54:26 --> Router Class Initialized
DEBUG - 2017-03-12 00:54:26 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:54:26 --> Utf8 Class Initialized
INFO - 2017-03-12 00:54:27 --> Output Class Initialized
INFO - 2017-03-12 00:54:27 --> Database Driver Class Initialized
INFO - 2017-03-12 00:54:27 --> URI Class Initialized
INFO - 2017-03-12 00:54:27 --> Security Class Initialized
INFO - 2017-03-12 00:54:27 --> Router Class Initialized
DEBUG - 2017-03-12 00:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:54:27 --> Input Class Initialized
INFO - 2017-03-12 00:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:54:27 --> Output Class Initialized
INFO - 2017-03-12 00:54:28 --> Controller Class Initialized
INFO - 2017-03-12 00:54:28 --> Language Class Initialized
INFO - 2017-03-12 00:54:28 --> Security Class Initialized
INFO - 2017-03-12 00:54:28 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:54:28 --> Input Class Initialized
INFO - 2017-03-12 00:54:28 --> Loader Class Initialized
DEBUG - 2017-03-12 00:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:54:28 --> Language Class Initialized
INFO - 2017-03-12 00:54:28 --> Loader Class Initialized
INFO - 2017-03-12 00:54:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:54:28 --> Database Driver Class Initialized
INFO - 2017-03-12 00:54:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:54:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:54:29 --> Database Driver Class Initialized
INFO - 2017-03-12 00:54:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:54:30 --> Final output sent to browser
DEBUG - 2017-03-12 00:54:30 --> Total execution time: 5.4989
INFO - 2017-03-12 00:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:54:31 --> Controller Class Initialized
INFO - 2017-03-12 00:54:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:54:31 --> Helper loaded: url_helper
INFO - 2017-03-12 00:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:54:31 --> Controller Class Initialized
ERROR - 2017-03-12 00:54:32 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
INFO - 2017-03-12 00:54:32 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:54:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-12 00:54:32 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
DEBUG - 2017-03-12 00:54:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-12 00:54:32 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:54:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:54:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:54:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:54:32 --> Final output sent to browser
DEBUG - 2017-03-12 00:54:32 --> Total execution time: 18.2873
INFO - 2017-03-12 00:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:54:32 --> Controller Class Initialized
INFO - 2017-03-12 00:54:32 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:54:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:54:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 00:54:35 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 00:54:35 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 00:54:35 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 00:54:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:54:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:54:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:54:36 --> Final output sent to browser
DEBUG - 2017-03-12 00:54:36 --> Total execution time: 11.4859
INFO - 2017-03-12 00:54:42 --> Config Class Initialized
INFO - 2017-03-12 00:54:42 --> Hooks Class Initialized
INFO - 2017-03-12 00:54:42 --> Config Class Initialized
INFO - 2017-03-12 00:54:42 --> Config Class Initialized
INFO - 2017-03-12 00:54:42 --> Hooks Class Initialized
INFO - 2017-03-12 00:54:42 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:54:42 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:54:42 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:54:42 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:54:42 --> Utf8 Class Initialized
INFO - 2017-03-12 00:54:42 --> URI Class Initialized
DEBUG - 2017-03-12 00:54:42 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:54:42 --> Utf8 Class Initialized
INFO - 2017-03-12 00:54:42 --> URI Class Initialized
INFO - 2017-03-12 00:54:42 --> Router Class Initialized
INFO - 2017-03-12 00:54:42 --> Router Class Initialized
INFO - 2017-03-12 00:54:42 --> URI Class Initialized
INFO - 2017-03-12 00:54:42 --> Router Class Initialized
INFO - 2017-03-12 00:54:42 --> Output Class Initialized
INFO - 2017-03-12 00:54:42 --> Output Class Initialized
INFO - 2017-03-12 00:54:42 --> Security Class Initialized
INFO - 2017-03-12 00:54:42 --> Security Class Initialized
DEBUG - 2017-03-12 00:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:54:42 --> Input Class Initialized
INFO - 2017-03-12 00:54:42 --> Output Class Initialized
INFO - 2017-03-12 00:54:42 --> Security Class Initialized
DEBUG - 2017-03-12 00:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:54:42 --> Input Class Initialized
INFO - 2017-03-12 00:54:42 --> Language Class Initialized
DEBUG - 2017-03-12 00:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:54:42 --> Input Class Initialized
INFO - 2017-03-12 00:54:42 --> Language Class Initialized
INFO - 2017-03-12 00:54:42 --> Language Class Initialized
INFO - 2017-03-12 00:54:42 --> Loader Class Initialized
INFO - 2017-03-12 00:54:42 --> Loader Class Initialized
INFO - 2017-03-12 00:54:42 --> Loader Class Initialized
INFO - 2017-03-12 00:54:43 --> Config Class Initialized
INFO - 2017-03-12 00:54:43 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:54:43 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:54:43 --> Utf8 Class Initialized
INFO - 2017-03-12 00:54:43 --> Database Driver Class Initialized
INFO - 2017-03-12 00:54:43 --> Database Driver Class Initialized
INFO - 2017-03-12 00:54:43 --> Database Driver Class Initialized
INFO - 2017-03-12 00:54:43 --> URI Class Initialized
INFO - 2017-03-12 00:54:43 --> Router Class Initialized
INFO - 2017-03-12 00:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:54:43 --> Controller Class Initialized
INFO - 2017-03-12 00:54:43 --> Output Class Initialized
INFO - 2017-03-12 00:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:54:43 --> Controller Class Initialized
INFO - 2017-03-12 00:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:54:43 --> Controller Class Initialized
INFO - 2017-03-12 00:54:43 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:54:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:54:43 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:54:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:54:43 --> Security Class Initialized
DEBUG - 2017-03-12 00:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:54:43 --> Input Class Initialized
INFO - 2017-03-12 00:54:43 --> Language Class Initialized
INFO - 2017-03-12 00:54:43 --> Loader Class Initialized
INFO - 2017-03-12 00:54:43 --> Database Driver Class Initialized
INFO - 2017-03-12 00:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:54:43 --> Controller Class Initialized
INFO - 2017-03-12 00:54:43 --> Helper loaded: date_helper
INFO - 2017-03-12 00:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
DEBUG - 2017-03-12 00:54:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:54:43 --> Helper loaded: url_helper
ERROR - 2017-03-12 00:54:43 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
INFO - 2017-03-12 00:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 00:54:43 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
INFO - 2017-03-12 00:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:54:43 --> Helper loaded: date_helper
ERROR - 2017-03-12 00:54:43 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
DEBUG - 2017-03-12 00:54:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:54:43 --> Helper loaded: url_helper
INFO - 2017-03-12 00:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 00:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 00:54:43 --> Final output sent to browser
DEBUG - 2017-03-12 00:54:43 --> Total execution time: 1.3398
INFO - 2017-03-12 00:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 00:54:43 --> Final output sent to browser
INFO - 2017-03-12 00:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
DEBUG - 2017-03-12 00:54:43 --> Total execution time: 1.3475
INFO - 2017-03-12 00:54:43 --> Final output sent to browser
DEBUG - 2017-03-12 00:54:43 --> Total execution time: 1.4786
INFO - 2017-03-12 00:54:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 00:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 00:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 00:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:54:44 --> Final output sent to browser
DEBUG - 2017-03-12 00:54:44 --> Total execution time: 1.4655
INFO - 2017-03-12 00:54:50 --> Config Class Initialized
INFO - 2017-03-12 00:54:50 --> Hooks Class Initialized
INFO - 2017-03-12 00:54:51 --> Config Class Initialized
INFO - 2017-03-12 00:54:51 --> Hooks Class Initialized
INFO - 2017-03-12 00:54:51 --> Config Class Initialized
INFO - 2017-03-12 00:54:51 --> Hooks Class Initialized
INFO - 2017-03-12 00:54:51 --> Config Class Initialized
INFO - 2017-03-12 00:54:51 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:54:51 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 00:54:51 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:54:51 --> Utf8 Class Initialized
DEBUG - 2017-03-12 00:54:51 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:54:51 --> Utf8 Class Initialized
INFO - 2017-03-12 00:54:51 --> Utf8 Class Initialized
INFO - 2017-03-12 00:54:51 --> URI Class Initialized
INFO - 2017-03-12 00:54:51 --> URI Class Initialized
DEBUG - 2017-03-12 00:54:51 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:54:51 --> Router Class Initialized
INFO - 2017-03-12 00:54:51 --> Utf8 Class Initialized
INFO - 2017-03-12 00:54:51 --> URI Class Initialized
INFO - 2017-03-12 00:54:51 --> Router Class Initialized
INFO - 2017-03-12 00:54:51 --> Output Class Initialized
INFO - 2017-03-12 00:54:51 --> Output Class Initialized
INFO - 2017-03-12 00:54:51 --> Security Class Initialized
INFO - 2017-03-12 00:54:51 --> Security Class Initialized
DEBUG - 2017-03-12 00:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:54:51 --> Input Class Initialized
INFO - 2017-03-12 00:54:51 --> Language Class Initialized
INFO - 2017-03-12 00:54:51 --> URI Class Initialized
INFO - 2017-03-12 00:54:51 --> Router Class Initialized
INFO - 2017-03-12 00:54:51 --> Router Class Initialized
INFO - 2017-03-12 00:54:51 --> Output Class Initialized
INFO - 2017-03-12 00:54:51 --> Loader Class Initialized
INFO - 2017-03-12 00:54:51 --> Security Class Initialized
DEBUG - 2017-03-12 00:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:54:51 --> Input Class Initialized
INFO - 2017-03-12 00:54:51 --> Language Class Initialized
INFO - 2017-03-12 00:54:51 --> Loader Class Initialized
INFO - 2017-03-12 00:54:51 --> Output Class Initialized
INFO - 2017-03-12 00:54:51 --> Security Class Initialized
DEBUG - 2017-03-12 00:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:54:51 --> Input Class Initialized
INFO - 2017-03-12 00:54:51 --> Language Class Initialized
DEBUG - 2017-03-12 00:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:54:51 --> Input Class Initialized
INFO - 2017-03-12 00:54:51 --> Language Class Initialized
INFO - 2017-03-12 00:54:51 --> Loader Class Initialized
INFO - 2017-03-12 00:54:51 --> Loader Class Initialized
INFO - 2017-03-12 00:54:51 --> Database Driver Class Initialized
INFO - 2017-03-12 00:54:51 --> Database Driver Class Initialized
INFO - 2017-03-12 00:54:51 --> Database Driver Class Initialized
INFO - 2017-03-12 00:54:51 --> Database Driver Class Initialized
INFO - 2017-03-12 00:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:54:52 --> Controller Class Initialized
INFO - 2017-03-12 00:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:54:52 --> Helper loaded: url_helper
INFO - 2017-03-12 00:54:52 --> Controller Class Initialized
INFO - 2017-03-12 00:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:54:52 --> Helper loaded: url_helper
INFO - 2017-03-12 00:54:52 --> Controller Class Initialized
INFO - 2017-03-12 00:54:52 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:54:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:54:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 00:54:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:54:52 --> Final output sent to browser
DEBUG - 2017-03-12 00:54:52 --> Total execution time: 1.5424
INFO - 2017-03-12 00:54:52 --> Final output sent to browser
INFO - 2017-03-12 00:54:52 --> Final output sent to browser
DEBUG - 2017-03-12 00:54:52 --> Total execution time: 1.5427
INFO - 2017-03-12 00:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:54:52 --> Controller Class Initialized
INFO - 2017-03-12 00:54:52 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:54:52 --> Total execution time: 1.5427
DEBUG - 2017-03-12 00:54:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:54:52 --> Final output sent to browser
DEBUG - 2017-03-12 00:54:52 --> Total execution time: 1.7374
INFO - 2017-03-12 00:55:02 --> Config Class Initialized
INFO - 2017-03-12 00:55:02 --> Config Class Initialized
INFO - 2017-03-12 00:55:02 --> Hooks Class Initialized
INFO - 2017-03-12 00:55:02 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:55:02 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:55:02 --> Utf8 Class Initialized
INFO - 2017-03-12 00:55:02 --> URI Class Initialized
DEBUG - 2017-03-12 00:55:02 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:55:02 --> Utf8 Class Initialized
INFO - 2017-03-12 00:55:02 --> Router Class Initialized
INFO - 2017-03-12 00:55:02 --> URI Class Initialized
INFO - 2017-03-12 00:55:02 --> Router Class Initialized
INFO - 2017-03-12 00:55:02 --> Output Class Initialized
INFO - 2017-03-12 00:55:02 --> Output Class Initialized
INFO - 2017-03-12 00:55:03 --> Security Class Initialized
INFO - 2017-03-12 00:55:03 --> Security Class Initialized
DEBUG - 2017-03-12 00:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-03-12 00:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:55:04 --> Input Class Initialized
INFO - 2017-03-12 00:55:04 --> Input Class Initialized
INFO - 2017-03-12 00:55:04 --> Language Class Initialized
INFO - 2017-03-12 00:55:04 --> Language Class Initialized
INFO - 2017-03-12 00:55:04 --> Loader Class Initialized
INFO - 2017-03-12 00:55:04 --> Loader Class Initialized
INFO - 2017-03-12 00:55:04 --> Database Driver Class Initialized
INFO - 2017-03-12 00:55:04 --> Database Driver Class Initialized
INFO - 2017-03-12 00:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:55:05 --> Controller Class Initialized
INFO - 2017-03-12 00:55:05 --> Helper loaded: url_helper
INFO - 2017-03-12 00:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:55:06 --> Controller Class Initialized
DEBUG - 2017-03-12 00:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:55:06 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:55:06 --> Helper loaded: url_helper
INFO - 2017-03-12 00:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-12 00:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 00:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:55:06 --> Final output sent to browser
DEBUG - 2017-03-12 00:55:06 --> Total execution time: 4.7021
INFO - 2017-03-12 00:55:07 --> Final output sent to browser
DEBUG - 2017-03-12 00:55:07 --> Total execution time: 4.7491
INFO - 2017-03-12 00:55:10 --> Config Class Initialized
INFO - 2017-03-12 00:55:10 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:55:10 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:55:10 --> Utf8 Class Initialized
INFO - 2017-03-12 00:55:10 --> URI Class Initialized
DEBUG - 2017-03-12 00:55:10 --> No URI present. Default controller set.
INFO - 2017-03-12 00:55:11 --> Router Class Initialized
INFO - 2017-03-12 00:55:11 --> Output Class Initialized
INFO - 2017-03-12 00:55:11 --> Security Class Initialized
DEBUG - 2017-03-12 00:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:55:11 --> Input Class Initialized
INFO - 2017-03-12 00:55:11 --> Language Class Initialized
INFO - 2017-03-12 00:55:11 --> Loader Class Initialized
INFO - 2017-03-12 00:55:11 --> Database Driver Class Initialized
INFO - 2017-03-12 00:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:55:12 --> Controller Class Initialized
INFO - 2017-03-12 00:55:12 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:55:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:55:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:55:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:55:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:55:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:55:12 --> Final output sent to browser
DEBUG - 2017-03-12 00:55:12 --> Total execution time: 1.8120
INFO - 2017-03-12 00:55:18 --> Config Class Initialized
INFO - 2017-03-12 00:55:18 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:55:18 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:55:18 --> Utf8 Class Initialized
INFO - 2017-03-12 00:55:18 --> URI Class Initialized
INFO - 2017-03-12 00:55:18 --> Router Class Initialized
INFO - 2017-03-12 00:55:18 --> Output Class Initialized
INFO - 2017-03-12 00:55:18 --> Security Class Initialized
DEBUG - 2017-03-12 00:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:55:19 --> Input Class Initialized
INFO - 2017-03-12 00:55:19 --> Language Class Initialized
INFO - 2017-03-12 00:55:19 --> Loader Class Initialized
INFO - 2017-03-12 00:55:19 --> Database Driver Class Initialized
INFO - 2017-03-12 00:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:55:19 --> Controller Class Initialized
INFO - 2017-03-12 00:55:19 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:55:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:55:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:55:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:55:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:55:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:55:19 --> Final output sent to browser
DEBUG - 2017-03-12 00:55:19 --> Total execution time: 1.3293
INFO - 2017-03-12 00:55:30 --> Config Class Initialized
INFO - 2017-03-12 00:55:30 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:55:30 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:55:30 --> Utf8 Class Initialized
INFO - 2017-03-12 00:55:30 --> URI Class Initialized
INFO - 2017-03-12 00:55:30 --> Router Class Initialized
INFO - 2017-03-12 00:55:30 --> Output Class Initialized
INFO - 2017-03-12 00:55:30 --> Security Class Initialized
DEBUG - 2017-03-12 00:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:55:31 --> Input Class Initialized
INFO - 2017-03-12 00:55:31 --> Language Class Initialized
INFO - 2017-03-12 00:55:31 --> Loader Class Initialized
INFO - 2017-03-12 00:55:31 --> Database Driver Class Initialized
INFO - 2017-03-12 00:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:55:31 --> Controller Class Initialized
INFO - 2017-03-12 00:55:31 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:55:37 --> Config Class Initialized
INFO - 2017-03-12 00:55:37 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:55:37 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:55:37 --> Utf8 Class Initialized
INFO - 2017-03-12 00:55:37 --> URI Class Initialized
INFO - 2017-03-12 00:55:37 --> Router Class Initialized
INFO - 2017-03-12 00:55:37 --> Output Class Initialized
INFO - 2017-03-12 00:55:37 --> Security Class Initialized
DEBUG - 2017-03-12 00:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:55:37 --> Input Class Initialized
INFO - 2017-03-12 00:55:37 --> Language Class Initialized
INFO - 2017-03-12 00:55:37 --> Loader Class Initialized
INFO - 2017-03-12 00:55:37 --> Database Driver Class Initialized
INFO - 2017-03-12 00:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:55:38 --> Controller Class Initialized
INFO - 2017-03-12 00:55:38 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:55:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:55:38 --> Helper loaded: url_helper
INFO - 2017-03-12 00:55:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:55:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 00:55:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 00:55:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 00:55:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:55:38 --> Final output sent to browser
DEBUG - 2017-03-12 00:55:38 --> Total execution time: 1.1512
INFO - 2017-03-12 00:55:53 --> Config Class Initialized
INFO - 2017-03-12 00:55:54 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:55:54 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:55:54 --> Utf8 Class Initialized
INFO - 2017-03-12 00:55:54 --> URI Class Initialized
INFO - 2017-03-12 00:55:54 --> Router Class Initialized
INFO - 2017-03-12 00:55:54 --> Output Class Initialized
INFO - 2017-03-12 00:55:54 --> Security Class Initialized
DEBUG - 2017-03-12 00:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:55:54 --> Input Class Initialized
INFO - 2017-03-12 00:55:54 --> Language Class Initialized
INFO - 2017-03-12 00:55:54 --> Loader Class Initialized
INFO - 2017-03-12 00:55:55 --> Database Driver Class Initialized
INFO - 2017-03-12 00:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:55:55 --> Controller Class Initialized
INFO - 2017-03-12 00:55:55 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:55:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:55:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:55:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:55:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:55:56 --> Final output sent to browser
DEBUG - 2017-03-12 00:55:56 --> Total execution time: 4.2413
INFO - 2017-03-12 00:56:01 --> Config Class Initialized
INFO - 2017-03-12 00:56:01 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:56:02 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:56:02 --> Utf8 Class Initialized
INFO - 2017-03-12 00:56:02 --> URI Class Initialized
INFO - 2017-03-12 00:56:02 --> Router Class Initialized
INFO - 2017-03-12 00:56:02 --> Output Class Initialized
INFO - 2017-03-12 00:56:02 --> Security Class Initialized
DEBUG - 2017-03-12 00:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:56:02 --> Input Class Initialized
INFO - 2017-03-12 00:56:02 --> Language Class Initialized
INFO - 2017-03-12 00:56:02 --> Loader Class Initialized
INFO - 2017-03-12 00:56:02 --> Database Driver Class Initialized
INFO - 2017-03-12 00:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:56:03 --> Controller Class Initialized
INFO - 2017-03-12 00:56:03 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:56:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:56:03 --> Helper loaded: url_helper
INFO - 2017-03-12 00:56:03 --> Helper loaded: download_helper
INFO - 2017-03-12 00:56:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:56:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:56:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-12 00:56:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-12 00:56:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:56:03 --> Final output sent to browser
DEBUG - 2017-03-12 00:56:03 --> Total execution time: 1.4844
INFO - 2017-03-12 00:56:12 --> Config Class Initialized
INFO - 2017-03-12 00:56:12 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:56:12 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:56:12 --> Utf8 Class Initialized
INFO - 2017-03-12 00:56:12 --> URI Class Initialized
INFO - 2017-03-12 00:56:12 --> Router Class Initialized
INFO - 2017-03-12 00:56:12 --> Output Class Initialized
INFO - 2017-03-12 00:56:12 --> Security Class Initialized
DEBUG - 2017-03-12 00:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:56:12 --> Input Class Initialized
INFO - 2017-03-12 00:56:12 --> Language Class Initialized
INFO - 2017-03-12 00:56:12 --> Loader Class Initialized
INFO - 2017-03-12 00:56:13 --> Database Driver Class Initialized
INFO - 2017-03-12 00:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:56:13 --> Controller Class Initialized
INFO - 2017-03-12 00:56:13 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:56:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:56:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:56:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:56:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:56:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:56:13 --> Final output sent to browser
DEBUG - 2017-03-12 00:56:13 --> Total execution time: 1.3628
INFO - 2017-03-12 00:56:52 --> Config Class Initialized
INFO - 2017-03-12 00:56:52 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:56:53 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:56:53 --> Utf8 Class Initialized
INFO - 2017-03-12 00:56:53 --> URI Class Initialized
INFO - 2017-03-12 00:56:53 --> Router Class Initialized
INFO - 2017-03-12 00:56:53 --> Output Class Initialized
INFO - 2017-03-12 00:56:53 --> Security Class Initialized
DEBUG - 2017-03-12 00:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:56:53 --> Input Class Initialized
INFO - 2017-03-12 00:56:53 --> Language Class Initialized
INFO - 2017-03-12 00:56:53 --> Loader Class Initialized
INFO - 2017-03-12 00:56:53 --> Database Driver Class Initialized
INFO - 2017-03-12 00:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:56:54 --> Controller Class Initialized
INFO - 2017-03-12 00:56:54 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:56:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:56:54 --> Helper loaded: url_helper
INFO - 2017-03-12 00:56:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:56:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-03-12 00:56:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:56:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-03-12 00:56:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-03-12 00:56:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:56:54 --> Final output sent to browser
DEBUG - 2017-03-12 00:56:54 --> Total execution time: 1.8127
INFO - 2017-03-12 00:57:08 --> Config Class Initialized
INFO - 2017-03-12 00:57:08 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:57:08 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:57:08 --> Utf8 Class Initialized
INFO - 2017-03-12 00:57:08 --> URI Class Initialized
INFO - 2017-03-12 00:57:08 --> Router Class Initialized
INFO - 2017-03-12 00:57:08 --> Output Class Initialized
INFO - 2017-03-12 00:57:08 --> Security Class Initialized
DEBUG - 2017-03-12 00:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:57:08 --> Input Class Initialized
INFO - 2017-03-12 00:57:08 --> Language Class Initialized
INFO - 2017-03-12 00:57:08 --> Loader Class Initialized
INFO - 2017-03-12 00:57:08 --> Database Driver Class Initialized
INFO - 2017-03-12 00:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:57:09 --> Controller Class Initialized
INFO - 2017-03-12 00:57:09 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:57:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:57:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:57:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:57:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:57:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:57:09 --> Final output sent to browser
DEBUG - 2017-03-12 00:57:09 --> Total execution time: 1.3012
INFO - 2017-03-12 00:57:19 --> Config Class Initialized
INFO - 2017-03-12 00:57:19 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:57:19 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:57:19 --> Utf8 Class Initialized
INFO - 2017-03-12 00:57:20 --> URI Class Initialized
INFO - 2017-03-12 00:57:20 --> Router Class Initialized
INFO - 2017-03-12 00:57:20 --> Output Class Initialized
INFO - 2017-03-12 00:57:20 --> Security Class Initialized
DEBUG - 2017-03-12 00:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:57:20 --> Input Class Initialized
INFO - 2017-03-12 00:57:20 --> Language Class Initialized
INFO - 2017-03-12 00:57:20 --> Loader Class Initialized
INFO - 2017-03-12 00:57:21 --> Database Driver Class Initialized
INFO - 2017-03-12 00:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:57:25 --> Controller Class Initialized
INFO - 2017-03-12 00:57:25 --> Upload Class Initialized
INFO - 2017-03-12 00:57:25 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:57:25 --> Helper loaded: url_helper
INFO - 2017-03-12 00:57:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:57:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:57:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-03-12 00:57:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-03-12 00:57:25 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-12 00:57:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:57:25 --> Final output sent to browser
DEBUG - 2017-03-12 00:57:25 --> Total execution time: 7.4944
INFO - 2017-03-12 00:57:28 --> Config Class Initialized
INFO - 2017-03-12 00:57:28 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:57:28 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:57:28 --> Utf8 Class Initialized
INFO - 2017-03-12 00:57:28 --> URI Class Initialized
INFO - 2017-03-12 00:57:28 --> Router Class Initialized
INFO - 2017-03-12 00:57:28 --> Output Class Initialized
INFO - 2017-03-12 00:57:28 --> Security Class Initialized
DEBUG - 2017-03-12 00:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:57:28 --> Input Class Initialized
INFO - 2017-03-12 00:57:28 --> Language Class Initialized
INFO - 2017-03-12 00:57:28 --> Loader Class Initialized
INFO - 2017-03-12 00:57:29 --> Database Driver Class Initialized
INFO - 2017-03-12 00:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:57:29 --> Controller Class Initialized
INFO - 2017-03-12 00:57:29 --> Upload Class Initialized
INFO - 2017-03-12 00:57:29 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:57:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:57:29 --> Helper loaded: url_helper
INFO - 2017-03-12 00:57:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:57:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 00:57:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-03-12 00:57:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-03-12 00:57:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-12 00:57:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:57:29 --> Final output sent to browser
DEBUG - 2017-03-12 00:57:29 --> Total execution time: 1.2130
INFO - 2017-03-12 00:57:39 --> Config Class Initialized
INFO - 2017-03-12 00:57:39 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:57:39 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:57:39 --> Utf8 Class Initialized
INFO - 2017-03-12 00:57:39 --> URI Class Initialized
INFO - 2017-03-12 00:57:39 --> Router Class Initialized
INFO - 2017-03-12 00:57:39 --> Output Class Initialized
INFO - 2017-03-12 00:57:39 --> Security Class Initialized
DEBUG - 2017-03-12 00:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:57:39 --> Input Class Initialized
INFO - 2017-03-12 00:57:39 --> Language Class Initialized
INFO - 2017-03-12 00:57:39 --> Loader Class Initialized
INFO - 2017-03-12 00:57:40 --> Database Driver Class Initialized
INFO - 2017-03-12 00:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:57:40 --> Controller Class Initialized
INFO - 2017-03-12 00:57:40 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:57:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:57:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:57:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:57:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:57:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:57:40 --> Final output sent to browser
DEBUG - 2017-03-12 00:57:40 --> Total execution time: 1.4576
INFO - 2017-03-12 00:58:54 --> Config Class Initialized
INFO - 2017-03-12 00:58:54 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:58:54 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:58:54 --> Utf8 Class Initialized
INFO - 2017-03-12 00:58:54 --> URI Class Initialized
INFO - 2017-03-12 00:58:54 --> Router Class Initialized
INFO - 2017-03-12 00:58:54 --> Output Class Initialized
INFO - 2017-03-12 00:58:54 --> Security Class Initialized
DEBUG - 2017-03-12 00:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:58:54 --> Input Class Initialized
INFO - 2017-03-12 00:58:54 --> Language Class Initialized
INFO - 2017-03-12 00:58:54 --> Loader Class Initialized
INFO - 2017-03-12 00:58:55 --> Database Driver Class Initialized
INFO - 2017-03-12 00:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:58:55 --> Controller Class Initialized
INFO - 2017-03-12 00:58:55 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:58:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:59:08 --> Config Class Initialized
INFO - 2017-03-12 00:59:08 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:59:08 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:59:08 --> Utf8 Class Initialized
INFO - 2017-03-12 00:59:08 --> URI Class Initialized
INFO - 2017-03-12 00:59:08 --> Router Class Initialized
INFO - 2017-03-12 00:59:08 --> Output Class Initialized
INFO - 2017-03-12 00:59:09 --> Security Class Initialized
DEBUG - 2017-03-12 00:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:59:09 --> Input Class Initialized
INFO - 2017-03-12 00:59:09 --> Language Class Initialized
INFO - 2017-03-12 00:59:09 --> Loader Class Initialized
INFO - 2017-03-12 00:59:09 --> Database Driver Class Initialized
INFO - 2017-03-12 00:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:59:09 --> Controller Class Initialized
INFO - 2017-03-12 00:59:09 --> Helper loaded: date_helper
DEBUG - 2017-03-12 00:59:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:59:09 --> Helper loaded: url_helper
INFO - 2017-03-12 00:59:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:59:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 00:59:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 00:59:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 00:59:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:59:10 --> Final output sent to browser
DEBUG - 2017-03-12 00:59:10 --> Total execution time: 1.6259
INFO - 2017-03-12 00:59:11 --> Config Class Initialized
INFO - 2017-03-12 00:59:11 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:59:11 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:59:11 --> Utf8 Class Initialized
INFO - 2017-03-12 00:59:11 --> URI Class Initialized
INFO - 2017-03-12 00:59:11 --> Router Class Initialized
INFO - 2017-03-12 00:59:11 --> Output Class Initialized
INFO - 2017-03-12 00:59:11 --> Security Class Initialized
DEBUG - 2017-03-12 00:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:59:11 --> Input Class Initialized
INFO - 2017-03-12 00:59:11 --> Language Class Initialized
INFO - 2017-03-12 00:59:11 --> Loader Class Initialized
INFO - 2017-03-12 00:59:11 --> Database Driver Class Initialized
INFO - 2017-03-12 00:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:59:11 --> Controller Class Initialized
INFO - 2017-03-12 00:59:11 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:59:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:59:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:59:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:59:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:59:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:59:11 --> Final output sent to browser
DEBUG - 2017-03-12 00:59:11 --> Total execution time: 0.4058
INFO - 2017-03-12 00:59:24 --> Config Class Initialized
INFO - 2017-03-12 00:59:24 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:59:24 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:59:24 --> Utf8 Class Initialized
INFO - 2017-03-12 00:59:24 --> URI Class Initialized
INFO - 2017-03-12 00:59:24 --> Router Class Initialized
INFO - 2017-03-12 00:59:25 --> Output Class Initialized
INFO - 2017-03-12 00:59:25 --> Security Class Initialized
DEBUG - 2017-03-12 00:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:59:25 --> Input Class Initialized
INFO - 2017-03-12 00:59:25 --> Language Class Initialized
INFO - 2017-03-12 00:59:25 --> Loader Class Initialized
INFO - 2017-03-12 00:59:25 --> Database Driver Class Initialized
INFO - 2017-03-12 00:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:59:25 --> Controller Class Initialized
INFO - 2017-03-12 00:59:25 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:59:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:59:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:59:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:59:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:59:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:59:26 --> Final output sent to browser
DEBUG - 2017-03-12 00:59:26 --> Total execution time: 1.5230
INFO - 2017-03-12 00:59:30 --> Config Class Initialized
INFO - 2017-03-12 00:59:30 --> Hooks Class Initialized
DEBUG - 2017-03-12 00:59:30 --> UTF-8 Support Enabled
INFO - 2017-03-12 00:59:30 --> Utf8 Class Initialized
INFO - 2017-03-12 00:59:30 --> URI Class Initialized
INFO - 2017-03-12 00:59:31 --> Router Class Initialized
INFO - 2017-03-12 00:59:31 --> Output Class Initialized
INFO - 2017-03-12 00:59:31 --> Security Class Initialized
DEBUG - 2017-03-12 00:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 00:59:31 --> Input Class Initialized
INFO - 2017-03-12 00:59:31 --> Language Class Initialized
INFO - 2017-03-12 00:59:31 --> Loader Class Initialized
INFO - 2017-03-12 00:59:31 --> Database Driver Class Initialized
INFO - 2017-03-12 00:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 00:59:31 --> Controller Class Initialized
INFO - 2017-03-12 00:59:31 --> Helper loaded: url_helper
DEBUG - 2017-03-12 00:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 00:59:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 00:59:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 00:59:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 00:59:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 00:59:32 --> Final output sent to browser
DEBUG - 2017-03-12 00:59:32 --> Total execution time: 1.3677
INFO - 2017-03-12 01:00:29 --> Config Class Initialized
INFO - 2017-03-12 01:00:29 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:00:29 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:00:29 --> Utf8 Class Initialized
INFO - 2017-03-12 01:00:29 --> URI Class Initialized
INFO - 2017-03-12 01:00:29 --> Router Class Initialized
INFO - 2017-03-12 01:00:29 --> Output Class Initialized
INFO - 2017-03-12 01:00:29 --> Security Class Initialized
DEBUG - 2017-03-12 01:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:00:29 --> Input Class Initialized
INFO - 2017-03-12 01:00:29 --> Language Class Initialized
INFO - 2017-03-12 01:00:29 --> Loader Class Initialized
INFO - 2017-03-12 01:00:30 --> Database Driver Class Initialized
INFO - 2017-03-12 01:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:00:30 --> Controller Class Initialized
INFO - 2017-03-12 01:00:30 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:00:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:00:39 --> Config Class Initialized
INFO - 2017-03-12 01:00:39 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:00:39 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:00:39 --> Utf8 Class Initialized
INFO - 2017-03-12 01:00:39 --> URI Class Initialized
INFO - 2017-03-12 01:00:39 --> Router Class Initialized
INFO - 2017-03-12 01:00:39 --> Output Class Initialized
INFO - 2017-03-12 01:00:39 --> Security Class Initialized
DEBUG - 2017-03-12 01:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:00:39 --> Input Class Initialized
INFO - 2017-03-12 01:00:39 --> Language Class Initialized
INFO - 2017-03-12 01:00:39 --> Loader Class Initialized
INFO - 2017-03-12 01:00:40 --> Database Driver Class Initialized
INFO - 2017-03-12 01:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:00:40 --> Controller Class Initialized
INFO - 2017-03-12 01:00:40 --> Helper loaded: date_helper
DEBUG - 2017-03-12 01:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:00:40 --> Helper loaded: url_helper
INFO - 2017-03-12 01:00:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:00:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 01:00:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 01:00:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 01:00:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:00:40 --> Final output sent to browser
DEBUG - 2017-03-12 01:00:40 --> Total execution time: 1.1303
INFO - 2017-03-12 01:00:41 --> Config Class Initialized
INFO - 2017-03-12 01:00:41 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:00:41 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:00:41 --> Utf8 Class Initialized
INFO - 2017-03-12 01:00:41 --> URI Class Initialized
INFO - 2017-03-12 01:00:41 --> Router Class Initialized
INFO - 2017-03-12 01:00:41 --> Output Class Initialized
INFO - 2017-03-12 01:00:41 --> Security Class Initialized
DEBUG - 2017-03-12 01:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:00:41 --> Input Class Initialized
INFO - 2017-03-12 01:00:41 --> Language Class Initialized
INFO - 2017-03-12 01:00:41 --> Loader Class Initialized
INFO - 2017-03-12 01:00:41 --> Database Driver Class Initialized
INFO - 2017-03-12 01:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:00:41 --> Controller Class Initialized
INFO - 2017-03-12 01:00:41 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:00:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:00:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:00:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:00:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:00:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:00:42 --> Final output sent to browser
DEBUG - 2017-03-12 01:00:42 --> Total execution time: 0.2833
INFO - 2017-03-12 01:00:49 --> Config Class Initialized
INFO - 2017-03-12 01:00:49 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:00:49 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:00:49 --> Utf8 Class Initialized
INFO - 2017-03-12 01:00:49 --> URI Class Initialized
INFO - 2017-03-12 01:00:49 --> Router Class Initialized
INFO - 2017-03-12 01:00:49 --> Output Class Initialized
INFO - 2017-03-12 01:00:49 --> Security Class Initialized
DEBUG - 2017-03-12 01:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:00:49 --> Input Class Initialized
INFO - 2017-03-12 01:00:49 --> Language Class Initialized
INFO - 2017-03-12 01:00:49 --> Loader Class Initialized
INFO - 2017-03-12 01:00:49 --> Database Driver Class Initialized
INFO - 2017-03-12 01:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:00:49 --> Controller Class Initialized
INFO - 2017-03-12 01:00:49 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:00:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:00:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:00:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:00:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:00:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:00:49 --> Final output sent to browser
DEBUG - 2017-03-12 01:00:49 --> Total execution time: 0.0988
INFO - 2017-03-12 01:00:52 --> Config Class Initialized
INFO - 2017-03-12 01:00:52 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:00:52 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:00:52 --> Utf8 Class Initialized
INFO - 2017-03-12 01:00:52 --> URI Class Initialized
INFO - 2017-03-12 01:00:53 --> Router Class Initialized
INFO - 2017-03-12 01:00:53 --> Output Class Initialized
INFO - 2017-03-12 01:00:53 --> Security Class Initialized
DEBUG - 2017-03-12 01:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:00:53 --> Input Class Initialized
INFO - 2017-03-12 01:00:53 --> Language Class Initialized
INFO - 2017-03-12 01:00:53 --> Loader Class Initialized
INFO - 2017-03-12 01:00:53 --> Database Driver Class Initialized
INFO - 2017-03-12 01:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:00:53 --> Controller Class Initialized
INFO - 2017-03-12 01:00:53 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:00:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:00:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:00:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:00:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:00:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:00:54 --> Final output sent to browser
DEBUG - 2017-03-12 01:00:54 --> Total execution time: 0.8477
INFO - 2017-03-12 01:01:31 --> Config Class Initialized
INFO - 2017-03-12 01:01:31 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:01:31 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:01:31 --> Utf8 Class Initialized
INFO - 2017-03-12 01:01:31 --> URI Class Initialized
DEBUG - 2017-03-12 01:01:31 --> No URI present. Default controller set.
INFO - 2017-03-12 01:01:31 --> Router Class Initialized
INFO - 2017-03-12 01:01:31 --> Output Class Initialized
INFO - 2017-03-12 01:01:31 --> Security Class Initialized
DEBUG - 2017-03-12 01:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:01:32 --> Input Class Initialized
INFO - 2017-03-12 01:01:32 --> Language Class Initialized
INFO - 2017-03-12 01:01:32 --> Loader Class Initialized
INFO - 2017-03-12 01:01:32 --> Database Driver Class Initialized
INFO - 2017-03-12 01:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:01:32 --> Controller Class Initialized
INFO - 2017-03-12 01:01:32 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:01:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:01:33 --> Final output sent to browser
DEBUG - 2017-03-12 01:01:33 --> Total execution time: 1.7626
INFO - 2017-03-12 01:01:42 --> Config Class Initialized
INFO - 2017-03-12 01:01:42 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:01:42 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:01:42 --> Utf8 Class Initialized
INFO - 2017-03-12 01:01:42 --> Config Class Initialized
INFO - 2017-03-12 01:01:42 --> URI Class Initialized
INFO - 2017-03-12 01:01:42 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:01:42 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:01:42 --> Utf8 Class Initialized
INFO - 2017-03-12 01:01:42 --> Router Class Initialized
INFO - 2017-03-12 01:01:42 --> URI Class Initialized
INFO - 2017-03-12 01:01:42 --> Output Class Initialized
INFO - 2017-03-12 01:01:42 --> Router Class Initialized
INFO - 2017-03-12 01:01:42 --> Security Class Initialized
INFO - 2017-03-12 01:01:42 --> Output Class Initialized
INFO - 2017-03-12 01:01:42 --> Security Class Initialized
DEBUG - 2017-03-12 01:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:01:42 --> Input Class Initialized
INFO - 2017-03-12 01:01:42 --> Language Class Initialized
DEBUG - 2017-03-12 01:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:01:42 --> Input Class Initialized
INFO - 2017-03-12 01:01:42 --> Language Class Initialized
INFO - 2017-03-12 01:01:42 --> Loader Class Initialized
INFO - 2017-03-12 01:01:42 --> Loader Class Initialized
INFO - 2017-03-12 01:01:43 --> Database Driver Class Initialized
INFO - 2017-03-12 01:01:43 --> Database Driver Class Initialized
INFO - 2017-03-12 01:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:01:43 --> Controller Class Initialized
INFO - 2017-03-12 01:01:43 --> Controller Class Initialized
INFO - 2017-03-12 01:01:43 --> Helper loaded: url_helper
INFO - 2017-03-12 01:01:43 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:01:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 01:01:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:01:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:01:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:01:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:01:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:01:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:01:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:01:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:01:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:01:43 --> Final output sent to browser
DEBUG - 2017-03-12 01:01:43 --> Total execution time: 1.8152
INFO - 2017-03-12 01:01:44 --> Final output sent to browser
DEBUG - 2017-03-12 01:01:44 --> Total execution time: 1.8152
INFO - 2017-03-12 01:01:49 --> Config Class Initialized
INFO - 2017-03-12 01:01:49 --> Config Class Initialized
INFO - 2017-03-12 01:01:50 --> Hooks Class Initialized
INFO - 2017-03-12 01:01:50 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:01:53 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 01:01:53 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:01:53 --> Utf8 Class Initialized
INFO - 2017-03-12 01:01:53 --> Utf8 Class Initialized
INFO - 2017-03-12 01:01:53 --> URI Class Initialized
INFO - 2017-03-12 01:01:53 --> URI Class Initialized
INFO - 2017-03-12 01:01:53 --> Router Class Initialized
INFO - 2017-03-12 01:01:53 --> Router Class Initialized
INFO - 2017-03-12 01:01:53 --> Output Class Initialized
INFO - 2017-03-12 01:01:53 --> Output Class Initialized
INFO - 2017-03-12 01:01:53 --> Security Class Initialized
INFO - 2017-03-12 01:01:53 --> Security Class Initialized
DEBUG - 2017-03-12 01:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:01:53 --> Input Class Initialized
INFO - 2017-03-12 01:01:53 --> Language Class Initialized
DEBUG - 2017-03-12 01:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:01:53 --> Input Class Initialized
INFO - 2017-03-12 01:01:53 --> Language Class Initialized
INFO - 2017-03-12 01:01:53 --> Loader Class Initialized
INFO - 2017-03-12 01:01:53 --> Loader Class Initialized
INFO - 2017-03-12 01:01:53 --> Database Driver Class Initialized
INFO - 2017-03-12 01:01:53 --> Database Driver Class Initialized
INFO - 2017-03-12 01:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:01:54 --> Controller Class Initialized
INFO - 2017-03-12 01:01:54 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:01:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:01:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:01:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:01:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:01:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:01:54 --> Final output sent to browser
DEBUG - 2017-03-12 01:01:54 --> Total execution time: 4.6331
INFO - 2017-03-12 01:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:01:54 --> Controller Class Initialized
INFO - 2017-03-12 01:01:54 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:01:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:01:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:01:56 --> Config Class Initialized
INFO - 2017-03-12 01:01:56 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:01:57 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:01:57 --> Utf8 Class Initialized
INFO - 2017-03-12 01:01:57 --> URI Class Initialized
DEBUG - 2017-03-12 01:01:57 --> No URI present. Default controller set.
INFO - 2017-03-12 01:01:57 --> Router Class Initialized
INFO - 2017-03-12 01:01:57 --> Output Class Initialized
INFO - 2017-03-12 01:01:57 --> Security Class Initialized
DEBUG - 2017-03-12 01:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:01:57 --> Input Class Initialized
INFO - 2017-03-12 01:01:57 --> Language Class Initialized
INFO - 2017-03-12 01:01:57 --> Loader Class Initialized
INFO - 2017-03-12 01:01:58 --> Database Driver Class Initialized
INFO - 2017-03-12 01:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:01:58 --> Controller Class Initialized
INFO - 2017-03-12 01:01:58 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:01:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:01:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:01:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:01:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:01:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:01:59 --> Final output sent to browser
DEBUG - 2017-03-12 01:01:59 --> Total execution time: 2.6639
INFO - 2017-03-12 01:02:03 --> Config Class Initialized
INFO - 2017-03-12 01:02:03 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:02:03 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:02:03 --> Utf8 Class Initialized
INFO - 2017-03-12 01:02:03 --> URI Class Initialized
INFO - 2017-03-12 01:02:03 --> Router Class Initialized
INFO - 2017-03-12 01:02:03 --> Output Class Initialized
INFO - 2017-03-12 01:02:03 --> Security Class Initialized
DEBUG - 2017-03-12 01:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:02:03 --> Input Class Initialized
INFO - 2017-03-12 01:02:03 --> Language Class Initialized
INFO - 2017-03-12 01:02:03 --> Loader Class Initialized
INFO - 2017-03-12 01:02:04 --> Database Driver Class Initialized
INFO - 2017-03-12 01:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:02:04 --> Controller Class Initialized
INFO - 2017-03-12 01:02:04 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:02:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:02:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:02:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:02:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:02:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:02:04 --> Final output sent to browser
DEBUG - 2017-03-12 01:02:04 --> Total execution time: 1.6778
INFO - 2017-03-12 01:02:19 --> Config Class Initialized
INFO - 2017-03-12 01:02:19 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:02:19 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:02:19 --> Utf8 Class Initialized
INFO - 2017-03-12 01:02:19 --> URI Class Initialized
INFO - 2017-03-12 01:02:19 --> Router Class Initialized
INFO - 2017-03-12 01:02:20 --> Output Class Initialized
INFO - 2017-03-12 01:02:20 --> Security Class Initialized
DEBUG - 2017-03-12 01:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:02:20 --> Input Class Initialized
INFO - 2017-03-12 01:02:20 --> Language Class Initialized
INFO - 2017-03-12 01:02:20 --> Loader Class Initialized
INFO - 2017-03-12 01:02:20 --> Database Driver Class Initialized
INFO - 2017-03-12 01:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:02:21 --> Controller Class Initialized
INFO - 2017-03-12 01:02:21 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:02:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:02:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:02:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:02:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:02:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:06:14 --> Config Class Initialized
INFO - 2017-03-12 01:06:15 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:06:15 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:06:15 --> Utf8 Class Initialized
INFO - 2017-03-12 01:06:15 --> URI Class Initialized
INFO - 2017-03-12 01:06:15 --> Router Class Initialized
INFO - 2017-03-12 01:06:15 --> Output Class Initialized
INFO - 2017-03-12 01:06:15 --> Security Class Initialized
DEBUG - 2017-03-12 01:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:06:15 --> Input Class Initialized
INFO - 2017-03-12 01:06:15 --> Language Class Initialized
INFO - 2017-03-12 01:06:15 --> Loader Class Initialized
INFO - 2017-03-12 01:06:15 --> Database Driver Class Initialized
INFO - 2017-03-12 01:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:06:16 --> Controller Class Initialized
INFO - 2017-03-12 01:06:16 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:06:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:06:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:06:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:06:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:06:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:06:16 --> Final output sent to browser
DEBUG - 2017-03-12 01:06:16 --> Total execution time: 1.5089
INFO - 2017-03-12 01:07:47 --> Config Class Initialized
INFO - 2017-03-12 01:07:47 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:07:48 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:07:48 --> Utf8 Class Initialized
INFO - 2017-03-12 01:07:48 --> URI Class Initialized
INFO - 2017-03-12 01:07:48 --> Router Class Initialized
INFO - 2017-03-12 01:07:48 --> Output Class Initialized
INFO - 2017-03-12 01:07:48 --> Security Class Initialized
DEBUG - 2017-03-12 01:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:07:48 --> Input Class Initialized
INFO - 2017-03-12 01:07:48 --> Language Class Initialized
INFO - 2017-03-12 01:07:48 --> Loader Class Initialized
INFO - 2017-03-12 01:07:48 --> Database Driver Class Initialized
INFO - 2017-03-12 01:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:07:49 --> Controller Class Initialized
INFO - 2017-03-12 01:07:49 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:07:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:07:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:07:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:07:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:07:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:07:49 --> Final output sent to browser
DEBUG - 2017-03-12 01:07:49 --> Total execution time: 2.1710
INFO - 2017-03-12 01:07:54 --> Config Class Initialized
INFO - 2017-03-12 01:07:54 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:07:54 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:07:54 --> Utf8 Class Initialized
INFO - 2017-03-12 01:07:54 --> URI Class Initialized
INFO - 2017-03-12 01:07:54 --> Router Class Initialized
INFO - 2017-03-12 01:07:54 --> Output Class Initialized
INFO - 2017-03-12 01:07:54 --> Security Class Initialized
DEBUG - 2017-03-12 01:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:07:54 --> Input Class Initialized
INFO - 2017-03-12 01:07:54 --> Language Class Initialized
INFO - 2017-03-12 01:07:54 --> Loader Class Initialized
INFO - 2017-03-12 01:07:55 --> Database Driver Class Initialized
INFO - 2017-03-12 01:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:07:55 --> Controller Class Initialized
INFO - 2017-03-12 01:07:55 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:07:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:07:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:07:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:07:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:07:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:07:55 --> Final output sent to browser
DEBUG - 2017-03-12 01:07:55 --> Total execution time: 1.5305
INFO - 2017-03-12 01:08:28 --> Config Class Initialized
INFO - 2017-03-12 01:08:28 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:08:28 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:08:28 --> Utf8 Class Initialized
INFO - 2017-03-12 01:08:28 --> URI Class Initialized
INFO - 2017-03-12 01:08:28 --> Router Class Initialized
INFO - 2017-03-12 01:08:28 --> Output Class Initialized
INFO - 2017-03-12 01:08:28 --> Security Class Initialized
DEBUG - 2017-03-12 01:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:08:28 --> Input Class Initialized
INFO - 2017-03-12 01:08:28 --> Language Class Initialized
INFO - 2017-03-12 01:08:28 --> Loader Class Initialized
INFO - 2017-03-12 01:08:29 --> Database Driver Class Initialized
INFO - 2017-03-12 01:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:08:29 --> Controller Class Initialized
INFO - 2017-03-12 01:08:29 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:08:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:08:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:08:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:08:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:08:29 --> Final output sent to browser
DEBUG - 2017-03-12 01:08:29 --> Total execution time: 1.7710
INFO - 2017-03-12 01:11:07 --> Config Class Initialized
INFO - 2017-03-12 01:11:07 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:11:07 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:11:07 --> Utf8 Class Initialized
INFO - 2017-03-12 01:11:07 --> URI Class Initialized
INFO - 2017-03-12 01:11:07 --> Router Class Initialized
INFO - 2017-03-12 01:11:07 --> Output Class Initialized
INFO - 2017-03-12 01:11:07 --> Security Class Initialized
DEBUG - 2017-03-12 01:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:11:07 --> Input Class Initialized
INFO - 2017-03-12 01:11:07 --> Language Class Initialized
INFO - 2017-03-12 01:11:07 --> Loader Class Initialized
INFO - 2017-03-12 01:11:08 --> Database Driver Class Initialized
INFO - 2017-03-12 01:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:11:08 --> Controller Class Initialized
INFO - 2017-03-12 01:11:08 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:11:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:11:21 --> Config Class Initialized
INFO - 2017-03-12 01:11:21 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:11:22 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:11:22 --> Utf8 Class Initialized
INFO - 2017-03-12 01:11:22 --> URI Class Initialized
INFO - 2017-03-12 01:11:22 --> Router Class Initialized
INFO - 2017-03-12 01:11:22 --> Output Class Initialized
INFO - 2017-03-12 01:11:22 --> Security Class Initialized
DEBUG - 2017-03-12 01:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:11:22 --> Input Class Initialized
INFO - 2017-03-12 01:11:22 --> Language Class Initialized
INFO - 2017-03-12 01:11:22 --> Loader Class Initialized
INFO - 2017-03-12 01:11:22 --> Database Driver Class Initialized
INFO - 2017-03-12 01:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:11:22 --> Controller Class Initialized
INFO - 2017-03-12 01:11:23 --> Helper loaded: date_helper
DEBUG - 2017-03-12 01:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:11:23 --> Helper loaded: url_helper
INFO - 2017-03-12 01:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 01:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 01:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 01:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:11:23 --> Final output sent to browser
DEBUG - 2017-03-12 01:11:23 --> Total execution time: 1.8862
INFO - 2017-03-12 01:11:33 --> Config Class Initialized
INFO - 2017-03-12 01:11:33 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:11:34 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:11:34 --> Utf8 Class Initialized
INFO - 2017-03-12 01:11:34 --> URI Class Initialized
INFO - 2017-03-12 01:11:34 --> Router Class Initialized
INFO - 2017-03-12 01:11:34 --> Output Class Initialized
INFO - 2017-03-12 01:11:34 --> Security Class Initialized
DEBUG - 2017-03-12 01:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:11:34 --> Input Class Initialized
INFO - 2017-03-12 01:11:34 --> Language Class Initialized
INFO - 2017-03-12 01:11:34 --> Loader Class Initialized
INFO - 2017-03-12 01:11:34 --> Database Driver Class Initialized
INFO - 2017-03-12 01:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:11:34 --> Controller Class Initialized
INFO - 2017-03-12 01:11:34 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:11:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:11:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:11:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:11:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:11:35 --> Final output sent to browser
DEBUG - 2017-03-12 01:11:35 --> Total execution time: 1.5239
INFO - 2017-03-12 01:13:10 --> Config Class Initialized
INFO - 2017-03-12 01:13:10 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:13:10 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:13:10 --> Utf8 Class Initialized
INFO - 2017-03-12 01:13:10 --> URI Class Initialized
DEBUG - 2017-03-12 01:13:10 --> No URI present. Default controller set.
INFO - 2017-03-12 01:13:10 --> Router Class Initialized
INFO - 2017-03-12 01:13:10 --> Output Class Initialized
INFO - 2017-03-12 01:13:10 --> Security Class Initialized
DEBUG - 2017-03-12 01:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:13:10 --> Input Class Initialized
INFO - 2017-03-12 01:13:10 --> Language Class Initialized
INFO - 2017-03-12 01:13:10 --> Loader Class Initialized
INFO - 2017-03-12 01:13:10 --> Database Driver Class Initialized
INFO - 2017-03-12 01:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:13:10 --> Controller Class Initialized
INFO - 2017-03-12 01:13:10 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:13:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:13:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:13:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:13:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:13:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:13:10 --> Final output sent to browser
DEBUG - 2017-03-12 01:13:10 --> Total execution time: 0.4544
INFO - 2017-03-12 01:13:19 --> Config Class Initialized
INFO - 2017-03-12 01:13:19 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:13:19 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:13:19 --> Utf8 Class Initialized
INFO - 2017-03-12 01:13:19 --> URI Class Initialized
INFO - 2017-03-12 01:13:19 --> Router Class Initialized
INFO - 2017-03-12 01:13:19 --> Output Class Initialized
INFO - 2017-03-12 01:13:19 --> Security Class Initialized
DEBUG - 2017-03-12 01:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:13:19 --> Input Class Initialized
INFO - 2017-03-12 01:13:19 --> Language Class Initialized
INFO - 2017-03-12 01:13:20 --> Loader Class Initialized
INFO - 2017-03-12 01:13:20 --> Database Driver Class Initialized
INFO - 2017-03-12 01:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:13:20 --> Controller Class Initialized
INFO - 2017-03-12 01:13:20 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:13:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:13:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:13:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:13:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:13:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:13:21 --> Final output sent to browser
DEBUG - 2017-03-12 01:13:21 --> Total execution time: 1.5286
INFO - 2017-03-12 01:13:40 --> Config Class Initialized
INFO - 2017-03-12 01:13:40 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:13:40 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:13:40 --> Utf8 Class Initialized
INFO - 2017-03-12 01:13:40 --> URI Class Initialized
INFO - 2017-03-12 01:13:40 --> Router Class Initialized
INFO - 2017-03-12 01:13:40 --> Output Class Initialized
INFO - 2017-03-12 01:13:40 --> Security Class Initialized
DEBUG - 2017-03-12 01:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:13:40 --> Input Class Initialized
INFO - 2017-03-12 01:13:40 --> Language Class Initialized
INFO - 2017-03-12 01:13:40 --> Loader Class Initialized
INFO - 2017-03-12 01:13:40 --> Database Driver Class Initialized
INFO - 2017-03-12 01:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:13:41 --> Controller Class Initialized
INFO - 2017-03-12 01:13:41 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:13:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:13:48 --> Config Class Initialized
INFO - 2017-03-12 01:13:48 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:13:48 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:13:48 --> Utf8 Class Initialized
INFO - 2017-03-12 01:13:48 --> URI Class Initialized
INFO - 2017-03-12 01:13:48 --> Router Class Initialized
INFO - 2017-03-12 01:13:48 --> Output Class Initialized
INFO - 2017-03-12 01:13:48 --> Security Class Initialized
DEBUG - 2017-03-12 01:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:13:48 --> Input Class Initialized
INFO - 2017-03-12 01:13:48 --> Language Class Initialized
INFO - 2017-03-12 01:13:48 --> Loader Class Initialized
INFO - 2017-03-12 01:13:48 --> Database Driver Class Initialized
INFO - 2017-03-12 01:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:13:49 --> Controller Class Initialized
INFO - 2017-03-12 01:13:49 --> Helper loaded: date_helper
DEBUG - 2017-03-12 01:13:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:13:49 --> Helper loaded: url_helper
INFO - 2017-03-12 01:13:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:13:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 01:13:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 01:13:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 01:13:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:13:49 --> Final output sent to browser
DEBUG - 2017-03-12 01:13:49 --> Total execution time: 1.1314
INFO - 2017-03-12 01:13:53 --> Config Class Initialized
INFO - 2017-03-12 01:13:53 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:13:53 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:13:53 --> Utf8 Class Initialized
INFO - 2017-03-12 01:13:53 --> URI Class Initialized
INFO - 2017-03-12 01:13:53 --> Router Class Initialized
INFO - 2017-03-12 01:13:54 --> Output Class Initialized
INFO - 2017-03-12 01:13:54 --> Security Class Initialized
DEBUG - 2017-03-12 01:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:13:54 --> Input Class Initialized
INFO - 2017-03-12 01:13:54 --> Language Class Initialized
INFO - 2017-03-12 01:13:54 --> Loader Class Initialized
INFO - 2017-03-12 01:13:54 --> Database Driver Class Initialized
INFO - 2017-03-12 01:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:13:55 --> Controller Class Initialized
INFO - 2017-03-12 01:13:55 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:13:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:13:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:13:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:13:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:13:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:13:55 --> Final output sent to browser
DEBUG - 2017-03-12 01:13:55 --> Total execution time: 1.6467
INFO - 2017-03-12 01:51:26 --> Config Class Initialized
INFO - 2017-03-12 01:51:26 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:51:26 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:51:26 --> Utf8 Class Initialized
INFO - 2017-03-12 01:51:26 --> URI Class Initialized
DEBUG - 2017-03-12 01:51:27 --> No URI present. Default controller set.
INFO - 2017-03-12 01:51:27 --> Router Class Initialized
INFO - 2017-03-12 01:51:27 --> Output Class Initialized
INFO - 2017-03-12 01:51:27 --> Security Class Initialized
DEBUG - 2017-03-12 01:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:51:27 --> Input Class Initialized
INFO - 2017-03-12 01:51:27 --> Language Class Initialized
INFO - 2017-03-12 01:51:27 --> Loader Class Initialized
INFO - 2017-03-12 01:51:27 --> Database Driver Class Initialized
INFO - 2017-03-12 01:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:51:28 --> Controller Class Initialized
INFO - 2017-03-12 01:51:28 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:51:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:51:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:51:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:51:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:51:28 --> Final output sent to browser
DEBUG - 2017-03-12 01:51:28 --> Total execution time: 1.9343
INFO - 2017-03-12 01:53:36 --> Config Class Initialized
INFO - 2017-03-12 01:53:36 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:53:36 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:53:36 --> Utf8 Class Initialized
INFO - 2017-03-12 01:53:36 --> URI Class Initialized
INFO - 2017-03-12 01:53:36 --> Router Class Initialized
INFO - 2017-03-12 01:53:36 --> Output Class Initialized
INFO - 2017-03-12 01:53:36 --> Security Class Initialized
DEBUG - 2017-03-12 01:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:53:37 --> Input Class Initialized
INFO - 2017-03-12 01:53:37 --> Language Class Initialized
INFO - 2017-03-12 01:53:37 --> Loader Class Initialized
INFO - 2017-03-12 01:53:37 --> Database Driver Class Initialized
INFO - 2017-03-12 01:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:53:37 --> Controller Class Initialized
INFO - 2017-03-12 01:53:37 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:53:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:53:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:53:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:53:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:53:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:53:38 --> Final output sent to browser
DEBUG - 2017-03-12 01:53:38 --> Total execution time: 1.6627
INFO - 2017-03-12 01:53:56 --> Config Class Initialized
INFO - 2017-03-12 01:53:56 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:53:56 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:53:56 --> Utf8 Class Initialized
INFO - 2017-03-12 01:53:56 --> URI Class Initialized
INFO - 2017-03-12 01:53:56 --> Router Class Initialized
INFO - 2017-03-12 01:53:56 --> Output Class Initialized
INFO - 2017-03-12 01:53:56 --> Security Class Initialized
DEBUG - 2017-03-12 01:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:53:56 --> Input Class Initialized
INFO - 2017-03-12 01:53:56 --> Language Class Initialized
INFO - 2017-03-12 01:53:56 --> Loader Class Initialized
INFO - 2017-03-12 01:53:57 --> Database Driver Class Initialized
INFO - 2017-03-12 01:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:53:57 --> Controller Class Initialized
INFO - 2017-03-12 01:53:57 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:53:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:53:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:53:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:53:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:53:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:53:57 --> Final output sent to browser
DEBUG - 2017-03-12 01:53:57 --> Total execution time: 1.6963
INFO - 2017-03-12 01:54:21 --> Config Class Initialized
INFO - 2017-03-12 01:54:21 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:54:21 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:54:21 --> Utf8 Class Initialized
INFO - 2017-03-12 01:54:21 --> URI Class Initialized
INFO - 2017-03-12 01:54:21 --> Router Class Initialized
INFO - 2017-03-12 01:54:21 --> Output Class Initialized
INFO - 2017-03-12 01:54:21 --> Security Class Initialized
DEBUG - 2017-03-12 01:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:54:21 --> Input Class Initialized
INFO - 2017-03-12 01:54:21 --> Language Class Initialized
INFO - 2017-03-12 01:54:21 --> Loader Class Initialized
INFO - 2017-03-12 01:54:22 --> Database Driver Class Initialized
INFO - 2017-03-12 01:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:54:22 --> Controller Class Initialized
INFO - 2017-03-12 01:54:22 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:54:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:54:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:54:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:54:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:54:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:54:22 --> Final output sent to browser
DEBUG - 2017-03-12 01:54:22 --> Total execution time: 1.7181
INFO - 2017-03-12 01:54:28 --> Config Class Initialized
INFO - 2017-03-12 01:54:28 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:54:28 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:54:28 --> Utf8 Class Initialized
INFO - 2017-03-12 01:54:28 --> URI Class Initialized
INFO - 2017-03-12 01:54:28 --> Router Class Initialized
INFO - 2017-03-12 01:54:29 --> Output Class Initialized
INFO - 2017-03-12 01:54:29 --> Security Class Initialized
DEBUG - 2017-03-12 01:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:54:29 --> Input Class Initialized
INFO - 2017-03-12 01:54:29 --> Language Class Initialized
INFO - 2017-03-12 01:54:29 --> Loader Class Initialized
INFO - 2017-03-12 01:54:29 --> Database Driver Class Initialized
INFO - 2017-03-12 01:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:54:29 --> Controller Class Initialized
INFO - 2017-03-12 01:54:29 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:54:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:54:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:54:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:54:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:54:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:54:30 --> Final output sent to browser
DEBUG - 2017-03-12 01:54:30 --> Total execution time: 1.4786
INFO - 2017-03-12 01:54:48 --> Config Class Initialized
INFO - 2017-03-12 01:54:48 --> Hooks Class Initialized
DEBUG - 2017-03-12 01:54:48 --> UTF-8 Support Enabled
INFO - 2017-03-12 01:54:48 --> Utf8 Class Initialized
INFO - 2017-03-12 01:54:48 --> URI Class Initialized
INFO - 2017-03-12 01:54:48 --> Router Class Initialized
INFO - 2017-03-12 01:54:48 --> Output Class Initialized
INFO - 2017-03-12 01:54:48 --> Security Class Initialized
DEBUG - 2017-03-12 01:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 01:54:48 --> Input Class Initialized
INFO - 2017-03-12 01:54:48 --> Language Class Initialized
INFO - 2017-03-12 01:54:48 --> Loader Class Initialized
INFO - 2017-03-12 01:54:49 --> Database Driver Class Initialized
INFO - 2017-03-12 01:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 01:54:49 --> Controller Class Initialized
INFO - 2017-03-12 01:54:49 --> Helper loaded: url_helper
DEBUG - 2017-03-12 01:54:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 01:54:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 01:54:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 01:54:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 01:54:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 01:54:49 --> Final output sent to browser
DEBUG - 2017-03-12 01:54:49 --> Total execution time: 1.6584
INFO - 2017-03-12 02:48:29 --> Config Class Initialized
INFO - 2017-03-12 02:48:29 --> Hooks Class Initialized
DEBUG - 2017-03-12 02:48:30 --> UTF-8 Support Enabled
INFO - 2017-03-12 02:48:30 --> Utf8 Class Initialized
INFO - 2017-03-12 02:48:30 --> URI Class Initialized
DEBUG - 2017-03-12 02:48:30 --> No URI present. Default controller set.
INFO - 2017-03-12 02:48:30 --> Router Class Initialized
INFO - 2017-03-12 02:48:30 --> Output Class Initialized
INFO - 2017-03-12 02:48:30 --> Security Class Initialized
DEBUG - 2017-03-12 02:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 02:48:30 --> Input Class Initialized
INFO - 2017-03-12 02:48:30 --> Language Class Initialized
INFO - 2017-03-12 02:48:30 --> Loader Class Initialized
INFO - 2017-03-12 02:48:30 --> Database Driver Class Initialized
INFO - 2017-03-12 02:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 02:48:31 --> Controller Class Initialized
INFO - 2017-03-12 02:48:31 --> Helper loaded: url_helper
DEBUG - 2017-03-12 02:48:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 02:48:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 02:48:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 02:48:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 02:48:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 02:48:31 --> Final output sent to browser
DEBUG - 2017-03-12 02:48:31 --> Total execution time: 1.9368
INFO - 2017-03-12 03:11:14 --> Config Class Initialized
INFO - 2017-03-12 03:11:14 --> Hooks Class Initialized
DEBUG - 2017-03-12 03:11:14 --> UTF-8 Support Enabled
INFO - 2017-03-12 03:11:14 --> Utf8 Class Initialized
INFO - 2017-03-12 03:11:14 --> URI Class Initialized
INFO - 2017-03-12 03:11:14 --> Router Class Initialized
INFO - 2017-03-12 03:11:14 --> Output Class Initialized
INFO - 2017-03-12 03:11:15 --> Security Class Initialized
DEBUG - 2017-03-12 03:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 03:11:15 --> Input Class Initialized
INFO - 2017-03-12 03:11:15 --> Language Class Initialized
INFO - 2017-03-12 03:11:15 --> Loader Class Initialized
INFO - 2017-03-12 03:11:15 --> Database Driver Class Initialized
INFO - 2017-03-12 03:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 03:11:15 --> Controller Class Initialized
INFO - 2017-03-12 03:11:16 --> Helper loaded: date_helper
DEBUG - 2017-03-12 03:11:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 03:11:16 --> Helper loaded: url_helper
INFO - 2017-03-12 03:11:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 03:11:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 03:11:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 03:11:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 03:11:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 03:11:16 --> Final output sent to browser
DEBUG - 2017-03-12 03:11:16 --> Total execution time: 2.2218
INFO - 2017-03-12 03:11:24 --> Config Class Initialized
INFO - 2017-03-12 03:11:24 --> Hooks Class Initialized
DEBUG - 2017-03-12 03:11:24 --> UTF-8 Support Enabled
INFO - 2017-03-12 03:11:24 --> Utf8 Class Initialized
INFO - 2017-03-12 03:11:24 --> URI Class Initialized
INFO - 2017-03-12 03:11:24 --> Router Class Initialized
INFO - 2017-03-12 03:11:24 --> Output Class Initialized
INFO - 2017-03-12 03:11:24 --> Security Class Initialized
DEBUG - 2017-03-12 03:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 03:11:24 --> Input Class Initialized
INFO - 2017-03-12 03:11:24 --> Language Class Initialized
INFO - 2017-03-12 03:11:24 --> Loader Class Initialized
INFO - 2017-03-12 03:11:25 --> Database Driver Class Initialized
INFO - 2017-03-12 03:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 03:11:25 --> Controller Class Initialized
INFO - 2017-03-12 03:11:25 --> Helper loaded: url_helper
DEBUG - 2017-03-12 03:11:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 03:11:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 03:11:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 03:11:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 03:11:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 03:11:25 --> Final output sent to browser
DEBUG - 2017-03-12 03:11:25 --> Total execution time: 1.2810
INFO - 2017-03-12 03:22:23 --> Config Class Initialized
INFO - 2017-03-12 03:22:23 --> Hooks Class Initialized
DEBUG - 2017-03-12 03:22:24 --> UTF-8 Support Enabled
INFO - 2017-03-12 03:22:24 --> Utf8 Class Initialized
INFO - 2017-03-12 03:22:24 --> URI Class Initialized
INFO - 2017-03-12 03:22:24 --> Router Class Initialized
INFO - 2017-03-12 03:22:24 --> Output Class Initialized
INFO - 2017-03-12 03:22:24 --> Security Class Initialized
DEBUG - 2017-03-12 03:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 03:22:24 --> Input Class Initialized
INFO - 2017-03-12 03:22:24 --> Language Class Initialized
INFO - 2017-03-12 03:22:24 --> Loader Class Initialized
INFO - 2017-03-12 03:22:24 --> Database Driver Class Initialized
INFO - 2017-03-12 03:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 03:22:25 --> Controller Class Initialized
INFO - 2017-03-12 03:22:25 --> Helper loaded: date_helper
DEBUG - 2017-03-12 03:22:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 03:22:25 --> Helper loaded: url_helper
INFO - 2017-03-12 03:22:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 03:22:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 03:22:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 03:22:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 03:22:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 03:22:25 --> Final output sent to browser
DEBUG - 2017-03-12 03:22:25 --> Total execution time: 1.9292
INFO - 2017-03-12 03:36:08 --> Config Class Initialized
INFO - 2017-03-12 03:36:08 --> Hooks Class Initialized
DEBUG - 2017-03-12 03:36:08 --> UTF-8 Support Enabled
INFO - 2017-03-12 03:36:08 --> Utf8 Class Initialized
INFO - 2017-03-12 03:36:08 --> URI Class Initialized
INFO - 2017-03-12 03:36:08 --> Router Class Initialized
INFO - 2017-03-12 03:36:09 --> Output Class Initialized
INFO - 2017-03-12 03:36:09 --> Security Class Initialized
DEBUG - 2017-03-12 03:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 03:36:09 --> Input Class Initialized
INFO - 2017-03-12 03:36:09 --> Language Class Initialized
INFO - 2017-03-12 03:36:09 --> Loader Class Initialized
INFO - 2017-03-12 03:36:09 --> Database Driver Class Initialized
INFO - 2017-03-12 03:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 03:36:09 --> Controller Class Initialized
INFO - 2017-03-12 03:36:10 --> Helper loaded: url_helper
DEBUG - 2017-03-12 03:36:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 03:36:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 03:36:10 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 03:36:10 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 03:36:10 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 03:36:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 03:36:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 03:36:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 03:36:10 --> Final output sent to browser
DEBUG - 2017-03-12 03:36:10 --> Total execution time: 2.1364
INFO - 2017-03-12 04:19:51 --> Config Class Initialized
INFO - 2017-03-12 04:19:51 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:19:51 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:19:51 --> Utf8 Class Initialized
INFO - 2017-03-12 04:19:51 --> URI Class Initialized
DEBUG - 2017-03-12 04:19:51 --> No URI present. Default controller set.
INFO - 2017-03-12 04:19:51 --> Router Class Initialized
INFO - 2017-03-12 04:19:51 --> Output Class Initialized
INFO - 2017-03-12 04:19:51 --> Security Class Initialized
DEBUG - 2017-03-12 04:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:19:52 --> Input Class Initialized
INFO - 2017-03-12 04:19:52 --> Language Class Initialized
INFO - 2017-03-12 04:19:52 --> Loader Class Initialized
INFO - 2017-03-12 04:19:52 --> Database Driver Class Initialized
INFO - 2017-03-12 04:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:19:52 --> Controller Class Initialized
INFO - 2017-03-12 04:19:52 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:19:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:19:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:19:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:19:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:19:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:19:53 --> Final output sent to browser
DEBUG - 2017-03-12 04:19:53 --> Total execution time: 1.8994
INFO - 2017-03-12 04:43:12 --> Config Class Initialized
INFO - 2017-03-12 04:43:12 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:43:13 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:43:13 --> Utf8 Class Initialized
INFO - 2017-03-12 04:43:13 --> URI Class Initialized
DEBUG - 2017-03-12 04:43:13 --> No URI present. Default controller set.
INFO - 2017-03-12 04:43:13 --> Router Class Initialized
INFO - 2017-03-12 04:43:13 --> Output Class Initialized
INFO - 2017-03-12 04:43:13 --> Security Class Initialized
DEBUG - 2017-03-12 04:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:43:13 --> Input Class Initialized
INFO - 2017-03-12 04:43:13 --> Language Class Initialized
INFO - 2017-03-12 04:43:13 --> Loader Class Initialized
INFO - 2017-03-12 04:43:14 --> Database Driver Class Initialized
INFO - 2017-03-12 04:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:43:16 --> Controller Class Initialized
INFO - 2017-03-12 04:43:16 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:43:16 --> Final output sent to browser
DEBUG - 2017-03-12 04:43:16 --> Total execution time: 4.0290
INFO - 2017-03-12 04:43:35 --> Config Class Initialized
INFO - 2017-03-12 04:43:36 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:43:36 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:43:36 --> Utf8 Class Initialized
INFO - 2017-03-12 04:43:36 --> URI Class Initialized
INFO - 2017-03-12 04:43:36 --> Router Class Initialized
INFO - 2017-03-12 04:43:36 --> Output Class Initialized
INFO - 2017-03-12 04:43:36 --> Security Class Initialized
DEBUG - 2017-03-12 04:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:43:36 --> Input Class Initialized
INFO - 2017-03-12 04:43:36 --> Language Class Initialized
INFO - 2017-03-12 04:43:37 --> Loader Class Initialized
INFO - 2017-03-12 04:43:37 --> Database Driver Class Initialized
INFO - 2017-03-12 04:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:43:37 --> Controller Class Initialized
INFO - 2017-03-12 04:43:38 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:43:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:43:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:43:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:43:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:43:40 --> Final output sent to browser
DEBUG - 2017-03-12 04:43:40 --> Total execution time: 4.1667
INFO - 2017-03-12 04:43:47 --> Config Class Initialized
INFO - 2017-03-12 04:43:47 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:43:48 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:43:48 --> Utf8 Class Initialized
INFO - 2017-03-12 04:43:48 --> URI Class Initialized
INFO - 2017-03-12 04:43:48 --> Router Class Initialized
INFO - 2017-03-12 04:43:49 --> Output Class Initialized
INFO - 2017-03-12 04:43:49 --> Security Class Initialized
DEBUG - 2017-03-12 04:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:43:49 --> Input Class Initialized
INFO - 2017-03-12 04:43:49 --> Language Class Initialized
INFO - 2017-03-12 04:43:49 --> Loader Class Initialized
INFO - 2017-03-12 04:43:49 --> Database Driver Class Initialized
INFO - 2017-03-12 04:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:43:50 --> Controller Class Initialized
INFO - 2017-03-12 04:43:50 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:43:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:43:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:43:51 --> Final output sent to browser
DEBUG - 2017-03-12 04:43:51 --> Total execution time: 3.2687
INFO - 2017-03-12 04:43:53 --> Config Class Initialized
INFO - 2017-03-12 04:43:53 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:43:53 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:43:53 --> Utf8 Class Initialized
INFO - 2017-03-12 04:43:53 --> URI Class Initialized
INFO - 2017-03-12 04:43:54 --> Router Class Initialized
INFO - 2017-03-12 04:43:54 --> Output Class Initialized
INFO - 2017-03-12 04:43:54 --> Security Class Initialized
DEBUG - 2017-03-12 04:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:43:54 --> Input Class Initialized
INFO - 2017-03-12 04:43:54 --> Language Class Initialized
INFO - 2017-03-12 04:43:54 --> Loader Class Initialized
INFO - 2017-03-12 04:43:54 --> Database Driver Class Initialized
INFO - 2017-03-12 04:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:43:55 --> Controller Class Initialized
INFO - 2017-03-12 04:43:55 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:43:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:43:55 --> Final output sent to browser
DEBUG - 2017-03-12 04:43:55 --> Total execution time: 1.7067
INFO - 2017-03-12 04:44:10 --> Config Class Initialized
INFO - 2017-03-12 04:44:10 --> Hooks Class Initialized
INFO - 2017-03-12 04:44:10 --> Config Class Initialized
INFO - 2017-03-12 04:44:10 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:44:11 --> UTF-8 Support Enabled
DEBUG - 2017-03-12 04:44:11 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:44:11 --> Utf8 Class Initialized
INFO - 2017-03-12 04:44:11 --> Utf8 Class Initialized
INFO - 2017-03-12 04:44:11 --> URI Class Initialized
INFO - 2017-03-12 04:44:11 --> URI Class Initialized
INFO - 2017-03-12 04:44:11 --> Router Class Initialized
INFO - 2017-03-12 04:44:11 --> Router Class Initialized
INFO - 2017-03-12 04:44:11 --> Output Class Initialized
INFO - 2017-03-12 04:44:11 --> Output Class Initialized
INFO - 2017-03-12 04:44:11 --> Security Class Initialized
INFO - 2017-03-12 04:44:11 --> Security Class Initialized
DEBUG - 2017-03-12 04:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:44:11 --> Input Class Initialized
INFO - 2017-03-12 04:44:11 --> Language Class Initialized
DEBUG - 2017-03-12 04:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:44:11 --> Input Class Initialized
INFO - 2017-03-12 04:44:11 --> Language Class Initialized
INFO - 2017-03-12 04:44:11 --> Loader Class Initialized
INFO - 2017-03-12 04:44:12 --> Loader Class Initialized
INFO - 2017-03-12 04:44:12 --> Database Driver Class Initialized
INFO - 2017-03-12 04:44:12 --> Database Driver Class Initialized
INFO - 2017-03-12 04:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:44:12 --> Controller Class Initialized
INFO - 2017-03-12 04:44:12 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:44:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:44:13 --> Final output sent to browser
DEBUG - 2017-03-12 04:44:13 --> Total execution time: 5.2670
INFO - 2017-03-12 04:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:44:13 --> Controller Class Initialized
INFO - 2017-03-12 04:44:13 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:44:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:44:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:44:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:44:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:44:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:44:14 --> Final output sent to browser
DEBUG - 2017-03-12 04:44:14 --> Total execution time: 6.3905
INFO - 2017-03-12 04:44:22 --> Config Class Initialized
INFO - 2017-03-12 04:44:22 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:44:23 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:44:23 --> Utf8 Class Initialized
INFO - 2017-03-12 04:44:23 --> URI Class Initialized
INFO - 2017-03-12 04:44:23 --> Router Class Initialized
INFO - 2017-03-12 04:44:23 --> Output Class Initialized
INFO - 2017-03-12 04:44:23 --> Security Class Initialized
DEBUG - 2017-03-12 04:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:44:23 --> Input Class Initialized
INFO - 2017-03-12 04:44:23 --> Language Class Initialized
INFO - 2017-03-12 04:44:23 --> Loader Class Initialized
INFO - 2017-03-12 04:44:23 --> Database Driver Class Initialized
INFO - 2017-03-12 04:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:44:23 --> Controller Class Initialized
INFO - 2017-03-12 04:44:23 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:44:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:44:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:44:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:44:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:44:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:44:24 --> Final output sent to browser
DEBUG - 2017-03-12 04:44:24 --> Total execution time: 1.6213
INFO - 2017-03-12 04:45:47 --> Config Class Initialized
INFO - 2017-03-12 04:45:47 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:45:47 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:45:47 --> Utf8 Class Initialized
INFO - 2017-03-12 04:45:47 --> URI Class Initialized
INFO - 2017-03-12 04:45:48 --> Router Class Initialized
INFO - 2017-03-12 04:45:48 --> Output Class Initialized
INFO - 2017-03-12 04:45:48 --> Security Class Initialized
DEBUG - 2017-03-12 04:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:45:48 --> Input Class Initialized
INFO - 2017-03-12 04:45:48 --> Language Class Initialized
INFO - 2017-03-12 04:45:48 --> Loader Class Initialized
INFO - 2017-03-12 04:45:48 --> Database Driver Class Initialized
INFO - 2017-03-12 04:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:45:49 --> Controller Class Initialized
INFO - 2017-03-12 04:45:49 --> Helper loaded: date_helper
DEBUG - 2017-03-12 04:45:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:45:49 --> Helper loaded: url_helper
INFO - 2017-03-12 04:45:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:45:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 04:45:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 04:45:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 04:45:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:45:49 --> Final output sent to browser
DEBUG - 2017-03-12 04:45:49 --> Total execution time: 2.9340
INFO - 2017-03-12 04:46:00 --> Config Class Initialized
INFO - 2017-03-12 04:46:00 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:46:01 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:46:01 --> Utf8 Class Initialized
INFO - 2017-03-12 04:46:01 --> URI Class Initialized
DEBUG - 2017-03-12 04:46:01 --> No URI present. Default controller set.
INFO - 2017-03-12 04:46:01 --> Router Class Initialized
INFO - 2017-03-12 04:46:01 --> Output Class Initialized
INFO - 2017-03-12 04:46:01 --> Security Class Initialized
DEBUG - 2017-03-12 04:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:46:01 --> Input Class Initialized
INFO - 2017-03-12 04:46:01 --> Language Class Initialized
INFO - 2017-03-12 04:46:01 --> Loader Class Initialized
INFO - 2017-03-12 04:46:02 --> Database Driver Class Initialized
INFO - 2017-03-12 04:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:46:02 --> Controller Class Initialized
INFO - 2017-03-12 04:46:02 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:46:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:46:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:46:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:46:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:46:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:46:03 --> Final output sent to browser
DEBUG - 2017-03-12 04:46:03 --> Total execution time: 2.0093
INFO - 2017-03-12 04:46:17 --> Config Class Initialized
INFO - 2017-03-12 04:46:17 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:46:18 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:46:18 --> Utf8 Class Initialized
INFO - 2017-03-12 04:46:18 --> URI Class Initialized
INFO - 2017-03-12 04:46:18 --> Router Class Initialized
INFO - 2017-03-12 04:46:18 --> Output Class Initialized
INFO - 2017-03-12 04:46:18 --> Security Class Initialized
DEBUG - 2017-03-12 04:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:46:18 --> Input Class Initialized
INFO - 2017-03-12 04:46:18 --> Language Class Initialized
INFO - 2017-03-12 04:46:18 --> Loader Class Initialized
INFO - 2017-03-12 04:46:18 --> Database Driver Class Initialized
INFO - 2017-03-12 04:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:46:19 --> Controller Class Initialized
INFO - 2017-03-12 04:46:19 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:46:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:46:29 --> Config Class Initialized
INFO - 2017-03-12 04:46:29 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:46:29 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:46:29 --> Utf8 Class Initialized
INFO - 2017-03-12 04:46:29 --> URI Class Initialized
INFO - 2017-03-12 04:46:29 --> Router Class Initialized
INFO - 2017-03-12 04:46:29 --> Output Class Initialized
INFO - 2017-03-12 04:46:29 --> Security Class Initialized
DEBUG - 2017-03-12 04:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:46:30 --> Input Class Initialized
INFO - 2017-03-12 04:46:30 --> Language Class Initialized
INFO - 2017-03-12 04:46:30 --> Loader Class Initialized
INFO - 2017-03-12 04:46:30 --> Database Driver Class Initialized
INFO - 2017-03-12 04:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:46:30 --> Controller Class Initialized
INFO - 2017-03-12 04:46:30 --> Helper loaded: date_helper
DEBUG - 2017-03-12 04:46:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:46:30 --> Helper loaded: url_helper
INFO - 2017-03-12 04:46:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:46:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 04:46:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 04:46:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 04:46:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:46:30 --> Final output sent to browser
DEBUG - 2017-03-12 04:46:30 --> Total execution time: 1.4936
INFO - 2017-03-12 04:46:43 --> Config Class Initialized
INFO - 2017-03-12 04:46:43 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:46:43 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:46:43 --> Utf8 Class Initialized
INFO - 2017-03-12 04:46:43 --> URI Class Initialized
DEBUG - 2017-03-12 04:46:44 --> No URI present. Default controller set.
INFO - 2017-03-12 04:46:44 --> Router Class Initialized
INFO - 2017-03-12 04:46:44 --> Output Class Initialized
INFO - 2017-03-12 04:46:44 --> Security Class Initialized
DEBUG - 2017-03-12 04:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:46:44 --> Input Class Initialized
INFO - 2017-03-12 04:46:44 --> Language Class Initialized
INFO - 2017-03-12 04:46:44 --> Loader Class Initialized
INFO - 2017-03-12 04:46:44 --> Database Driver Class Initialized
INFO - 2017-03-12 04:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:46:44 --> Controller Class Initialized
INFO - 2017-03-12 04:46:44 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:46:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:46:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:46:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:46:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:46:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:46:45 --> Final output sent to browser
DEBUG - 2017-03-12 04:46:45 --> Total execution time: 2.8337
INFO - 2017-03-12 04:46:58 --> Config Class Initialized
INFO - 2017-03-12 04:46:58 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:46:59 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:46:59 --> Utf8 Class Initialized
INFO - 2017-03-12 04:46:59 --> URI Class Initialized
INFO - 2017-03-12 04:46:59 --> Router Class Initialized
INFO - 2017-03-12 04:46:59 --> Output Class Initialized
INFO - 2017-03-12 04:46:59 --> Security Class Initialized
DEBUG - 2017-03-12 04:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:46:59 --> Input Class Initialized
INFO - 2017-03-12 04:46:59 --> Language Class Initialized
INFO - 2017-03-12 04:46:59 --> Loader Class Initialized
INFO - 2017-03-12 04:46:59 --> Database Driver Class Initialized
INFO - 2017-03-12 04:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:47:00 --> Controller Class Initialized
INFO - 2017-03-12 04:47:00 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:47:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:47:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:47:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:47:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:47:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:47:00 --> Final output sent to browser
DEBUG - 2017-03-12 04:47:00 --> Total execution time: 1.8511
INFO - 2017-03-12 04:47:17 --> Config Class Initialized
INFO - 2017-03-12 04:47:17 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:47:17 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:47:17 --> Utf8 Class Initialized
INFO - 2017-03-12 04:47:17 --> URI Class Initialized
INFO - 2017-03-12 04:47:17 --> Router Class Initialized
INFO - 2017-03-12 04:47:17 --> Output Class Initialized
INFO - 2017-03-12 04:47:18 --> Security Class Initialized
DEBUG - 2017-03-12 04:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:47:18 --> Input Class Initialized
INFO - 2017-03-12 04:47:18 --> Language Class Initialized
INFO - 2017-03-12 04:47:18 --> Loader Class Initialized
INFO - 2017-03-12 04:47:18 --> Database Driver Class Initialized
INFO - 2017-03-12 04:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:47:18 --> Controller Class Initialized
INFO - 2017-03-12 04:47:18 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:47:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:47:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:47:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:47:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:47:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:47:19 --> Final output sent to browser
DEBUG - 2017-03-12 04:47:19 --> Total execution time: 1.9642
INFO - 2017-03-12 04:47:42 --> Config Class Initialized
INFO - 2017-03-12 04:47:42 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:47:43 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:47:43 --> Utf8 Class Initialized
INFO - 2017-03-12 04:47:43 --> URI Class Initialized
INFO - 2017-03-12 04:47:43 --> Router Class Initialized
INFO - 2017-03-12 04:47:43 --> Output Class Initialized
INFO - 2017-03-12 04:47:43 --> Security Class Initialized
DEBUG - 2017-03-12 04:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:47:43 --> Input Class Initialized
INFO - 2017-03-12 04:47:43 --> Language Class Initialized
INFO - 2017-03-12 04:47:43 --> Loader Class Initialized
INFO - 2017-03-12 04:47:43 --> Database Driver Class Initialized
INFO - 2017-03-12 04:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:47:44 --> Controller Class Initialized
INFO - 2017-03-12 04:47:44 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:47:44 --> Final output sent to browser
DEBUG - 2017-03-12 04:47:44 --> Total execution time: 1.9572
INFO - 2017-03-12 04:49:10 --> Config Class Initialized
INFO - 2017-03-12 04:49:10 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:49:10 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:49:10 --> Utf8 Class Initialized
INFO - 2017-03-12 04:49:10 --> URI Class Initialized
DEBUG - 2017-03-12 04:49:10 --> No URI present. Default controller set.
INFO - 2017-03-12 04:49:10 --> Router Class Initialized
INFO - 2017-03-12 04:49:10 --> Output Class Initialized
INFO - 2017-03-12 04:49:10 --> Security Class Initialized
DEBUG - 2017-03-12 04:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:49:10 --> Input Class Initialized
INFO - 2017-03-12 04:49:10 --> Language Class Initialized
INFO - 2017-03-12 04:49:10 --> Loader Class Initialized
INFO - 2017-03-12 04:49:11 --> Database Driver Class Initialized
INFO - 2017-03-12 04:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:49:11 --> Controller Class Initialized
INFO - 2017-03-12 04:49:11 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:49:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:49:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:49:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:49:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:49:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:49:12 --> Final output sent to browser
DEBUG - 2017-03-12 04:49:12 --> Total execution time: 5.8667
INFO - 2017-03-12 04:49:39 --> Config Class Initialized
INFO - 2017-03-12 04:49:39 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:49:39 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:49:39 --> Utf8 Class Initialized
INFO - 2017-03-12 04:49:39 --> URI Class Initialized
INFO - 2017-03-12 04:49:39 --> Router Class Initialized
INFO - 2017-03-12 04:49:39 --> Output Class Initialized
INFO - 2017-03-12 04:49:39 --> Security Class Initialized
DEBUG - 2017-03-12 04:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:49:40 --> Input Class Initialized
INFO - 2017-03-12 04:49:40 --> Language Class Initialized
INFO - 2017-03-12 04:49:40 --> Loader Class Initialized
INFO - 2017-03-12 04:49:40 --> Database Driver Class Initialized
INFO - 2017-03-12 04:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:49:40 --> Controller Class Initialized
INFO - 2017-03-12 04:49:40 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:49:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:49:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:49:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:49:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:49:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:49:41 --> Final output sent to browser
DEBUG - 2017-03-12 04:49:41 --> Total execution time: 2.2793
INFO - 2017-03-12 04:49:50 --> Config Class Initialized
INFO - 2017-03-12 04:49:50 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:49:50 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:49:50 --> Utf8 Class Initialized
INFO - 2017-03-12 04:49:50 --> URI Class Initialized
INFO - 2017-03-12 04:49:50 --> Router Class Initialized
INFO - 2017-03-12 04:49:51 --> Output Class Initialized
INFO - 2017-03-12 04:49:51 --> Security Class Initialized
DEBUG - 2017-03-12 04:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:49:51 --> Input Class Initialized
INFO - 2017-03-12 04:49:51 --> Language Class Initialized
INFO - 2017-03-12 04:49:51 --> Loader Class Initialized
INFO - 2017-03-12 04:49:51 --> Database Driver Class Initialized
INFO - 2017-03-12 04:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:49:52 --> Controller Class Initialized
INFO - 2017-03-12 04:49:53 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:49:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:49:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:49:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:49:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:49:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:49:54 --> Final output sent to browser
DEBUG - 2017-03-12 04:49:54 --> Total execution time: 4.9872
INFO - 2017-03-12 04:50:01 --> Config Class Initialized
INFO - 2017-03-12 04:50:01 --> Config Class Initialized
INFO - 2017-03-12 04:50:02 --> Hooks Class Initialized
INFO - 2017-03-12 04:50:02 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:50:02 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:50:02 --> Utf8 Class Initialized
DEBUG - 2017-03-12 04:50:02 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:50:02 --> URI Class Initialized
INFO - 2017-03-12 04:50:02 --> Utf8 Class Initialized
INFO - 2017-03-12 04:50:02 --> URI Class Initialized
INFO - 2017-03-12 04:50:02 --> Router Class Initialized
INFO - 2017-03-12 04:50:02 --> Router Class Initialized
INFO - 2017-03-12 04:50:02 --> Output Class Initialized
INFO - 2017-03-12 04:50:02 --> Output Class Initialized
INFO - 2017-03-12 04:50:02 --> Security Class Initialized
INFO - 2017-03-12 04:50:02 --> Security Class Initialized
DEBUG - 2017-03-12 04:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:50:02 --> Input Class Initialized
DEBUG - 2017-03-12 04:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:50:02 --> Input Class Initialized
INFO - 2017-03-12 04:50:02 --> Language Class Initialized
INFO - 2017-03-12 04:50:02 --> Language Class Initialized
INFO - 2017-03-12 04:50:02 --> Loader Class Initialized
INFO - 2017-03-12 04:50:02 --> Loader Class Initialized
INFO - 2017-03-12 04:50:03 --> Database Driver Class Initialized
INFO - 2017-03-12 04:50:03 --> Database Driver Class Initialized
INFO - 2017-03-12 04:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:50:03 --> Controller Class Initialized
INFO - 2017-03-12 04:50:03 --> Helper loaded: url_helper
INFO - 2017-03-12 04:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:50:03 --> Controller Class Initialized
INFO - 2017-03-12 04:50:03 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:50:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 04:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:50:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:50:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:50:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:50:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:50:04 --> Final output sent to browser
DEBUG - 2017-03-12 04:50:04 --> Total execution time: 2.1703
INFO - 2017-03-12 04:50:04 --> Config Class Initialized
INFO - 2017-03-12 04:50:04 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:50:05 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:50:05 --> Utf8 Class Initialized
INFO - 2017-03-12 04:50:05 --> URI Class Initialized
INFO - 2017-03-12 04:50:05 --> Router Class Initialized
INFO - 2017-03-12 04:50:05 --> Output Class Initialized
INFO - 2017-03-12 04:50:05 --> Security Class Initialized
DEBUG - 2017-03-12 04:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:50:05 --> Input Class Initialized
INFO - 2017-03-12 04:50:05 --> Language Class Initialized
INFO - 2017-03-12 04:50:05 --> Loader Class Initialized
INFO - 2017-03-12 04:50:06 --> Database Driver Class Initialized
INFO - 2017-03-12 04:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:50:10 --> Controller Class Initialized
INFO - 2017-03-12 04:50:10 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:50:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:50:21 --> Config Class Initialized
INFO - 2017-03-12 04:50:21 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:50:22 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:50:22 --> Utf8 Class Initialized
INFO - 2017-03-12 04:50:22 --> URI Class Initialized
INFO - 2017-03-12 04:50:22 --> Router Class Initialized
INFO - 2017-03-12 04:50:22 --> Output Class Initialized
INFO - 2017-03-12 04:50:22 --> Security Class Initialized
DEBUG - 2017-03-12 04:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:50:22 --> Input Class Initialized
INFO - 2017-03-12 04:50:22 --> Language Class Initialized
INFO - 2017-03-12 04:50:22 --> Loader Class Initialized
INFO - 2017-03-12 04:50:23 --> Database Driver Class Initialized
INFO - 2017-03-12 04:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:50:24 --> Controller Class Initialized
INFO - 2017-03-12 04:50:24 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:50:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:50:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:50:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:50:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:50:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:50:25 --> Final output sent to browser
DEBUG - 2017-03-12 04:50:25 --> Total execution time: 3.7529
INFO - 2017-03-12 04:50:29 --> Config Class Initialized
INFO - 2017-03-12 04:50:29 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:50:29 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:50:29 --> Utf8 Class Initialized
INFO - 2017-03-12 04:50:29 --> URI Class Initialized
INFO - 2017-03-12 04:50:30 --> Router Class Initialized
INFO - 2017-03-12 04:50:30 --> Output Class Initialized
INFO - 2017-03-12 04:50:30 --> Security Class Initialized
DEBUG - 2017-03-12 04:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:50:30 --> Input Class Initialized
INFO - 2017-03-12 04:50:30 --> Language Class Initialized
INFO - 2017-03-12 04:50:30 --> Loader Class Initialized
INFO - 2017-03-12 04:50:30 --> Database Driver Class Initialized
INFO - 2017-03-12 04:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:50:30 --> Controller Class Initialized
INFO - 2017-03-12 04:50:30 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:50:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:50:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:50:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:50:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:50:31 --> Final output sent to browser
DEBUG - 2017-03-12 04:50:31 --> Total execution time: 2.2244
INFO - 2017-03-12 04:50:33 --> Config Class Initialized
INFO - 2017-03-12 04:50:33 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:50:33 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:50:33 --> Utf8 Class Initialized
INFO - 2017-03-12 04:50:33 --> URI Class Initialized
INFO - 2017-03-12 04:50:33 --> Router Class Initialized
INFO - 2017-03-12 04:50:33 --> Output Class Initialized
INFO - 2017-03-12 04:50:34 --> Security Class Initialized
DEBUG - 2017-03-12 04:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:50:34 --> Input Class Initialized
INFO - 2017-03-12 04:50:34 --> Language Class Initialized
INFO - 2017-03-12 04:50:34 --> Loader Class Initialized
INFO - 2017-03-12 04:50:34 --> Database Driver Class Initialized
INFO - 2017-03-12 04:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:50:34 --> Controller Class Initialized
INFO - 2017-03-12 04:50:34 --> Helper loaded: date_helper
DEBUG - 2017-03-12 04:50:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:50:35 --> Helper loaded: url_helper
INFO - 2017-03-12 04:50:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:50:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 04:50:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 04:50:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 04:50:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:50:35 --> Final output sent to browser
DEBUG - 2017-03-12 04:50:35 --> Total execution time: 1.6778
INFO - 2017-03-12 04:50:38 --> Config Class Initialized
INFO - 2017-03-12 04:50:38 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:50:38 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:50:38 --> Utf8 Class Initialized
INFO - 2017-03-12 04:50:38 --> URI Class Initialized
INFO - 2017-03-12 04:50:39 --> Router Class Initialized
INFO - 2017-03-12 04:50:39 --> Output Class Initialized
INFO - 2017-03-12 04:50:39 --> Security Class Initialized
DEBUG - 2017-03-12 04:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:50:39 --> Input Class Initialized
INFO - 2017-03-12 04:50:39 --> Language Class Initialized
INFO - 2017-03-12 04:50:39 --> Loader Class Initialized
INFO - 2017-03-12 04:50:39 --> Database Driver Class Initialized
INFO - 2017-03-12 04:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:50:40 --> Controller Class Initialized
INFO - 2017-03-12 04:50:40 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:50:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:50:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:50:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:50:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:50:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:50:41 --> Final output sent to browser
DEBUG - 2017-03-12 04:50:41 --> Total execution time: 2.9174
INFO - 2017-03-12 04:51:05 --> Config Class Initialized
INFO - 2017-03-12 04:51:05 --> Config Class Initialized
INFO - 2017-03-12 04:51:05 --> Hooks Class Initialized
INFO - 2017-03-12 04:51:05 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:51:05 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:51:05 --> Utf8 Class Initialized
INFO - 2017-03-12 04:51:05 --> URI Class Initialized
DEBUG - 2017-03-12 04:51:05 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:51:05 --> Utf8 Class Initialized
INFO - 2017-03-12 04:51:05 --> Router Class Initialized
INFO - 2017-03-12 04:51:05 --> URI Class Initialized
INFO - 2017-03-12 04:51:05 --> Router Class Initialized
INFO - 2017-03-12 04:51:05 --> Output Class Initialized
INFO - 2017-03-12 04:51:05 --> Output Class Initialized
INFO - 2017-03-12 04:51:06 --> Security Class Initialized
INFO - 2017-03-12 04:51:06 --> Security Class Initialized
DEBUG - 2017-03-12 04:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:51:06 --> Input Class Initialized
DEBUG - 2017-03-12 04:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:51:06 --> Language Class Initialized
INFO - 2017-03-12 04:51:06 --> Input Class Initialized
INFO - 2017-03-12 04:51:06 --> Language Class Initialized
INFO - 2017-03-12 04:51:06 --> Loader Class Initialized
INFO - 2017-03-12 04:51:06 --> Loader Class Initialized
INFO - 2017-03-12 04:51:06 --> Database Driver Class Initialized
INFO - 2017-03-12 04:51:06 --> Database Driver Class Initialized
INFO - 2017-03-12 04:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:51:07 --> Controller Class Initialized
INFO - 2017-03-12 04:51:07 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:51:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:51:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:51:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:51:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:51:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:51:08 --> Final output sent to browser
DEBUG - 2017-03-12 04:51:08 --> Total execution time: 2.5458
INFO - 2017-03-12 04:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:51:08 --> Controller Class Initialized
INFO - 2017-03-12 04:51:09 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:51:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:51:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:51:11 --> Final output sent to browser
DEBUG - 2017-03-12 04:51:11 --> Total execution time: 5.6352
INFO - 2017-03-12 04:51:21 --> Config Class Initialized
INFO - 2017-03-12 04:51:21 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:51:21 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:51:21 --> Utf8 Class Initialized
INFO - 2017-03-12 04:51:21 --> URI Class Initialized
INFO - 2017-03-12 04:51:21 --> Router Class Initialized
INFO - 2017-03-12 04:51:21 --> Output Class Initialized
INFO - 2017-03-12 04:51:21 --> Security Class Initialized
DEBUG - 2017-03-12 04:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:51:21 --> Input Class Initialized
INFO - 2017-03-12 04:51:21 --> Language Class Initialized
INFO - 2017-03-12 04:51:21 --> Loader Class Initialized
INFO - 2017-03-12 04:51:22 --> Database Driver Class Initialized
INFO - 2017-03-12 04:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:51:22 --> Controller Class Initialized
INFO - 2017-03-12 04:51:22 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:51:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:51:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:51:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:51:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:51:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:51:22 --> Final output sent to browser
DEBUG - 2017-03-12 04:51:22 --> Total execution time: 1.5177
INFO - 2017-03-12 04:52:02 --> Config Class Initialized
INFO - 2017-03-12 04:52:03 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:52:03 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:52:03 --> Utf8 Class Initialized
INFO - 2017-03-12 04:52:03 --> URI Class Initialized
INFO - 2017-03-12 04:52:03 --> Router Class Initialized
INFO - 2017-03-12 04:52:03 --> Output Class Initialized
INFO - 2017-03-12 04:52:03 --> Security Class Initialized
DEBUG - 2017-03-12 04:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:52:03 --> Input Class Initialized
INFO - 2017-03-12 04:52:03 --> Language Class Initialized
INFO - 2017-03-12 04:52:03 --> Loader Class Initialized
INFO - 2017-03-12 04:52:04 --> Database Driver Class Initialized
INFO - 2017-03-12 04:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:52:04 --> Controller Class Initialized
INFO - 2017-03-12 04:52:04 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:52:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:52:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:52:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:52:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:52:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:52:05 --> Final output sent to browser
DEBUG - 2017-03-12 04:52:05 --> Total execution time: 2.1375
INFO - 2017-03-12 04:52:09 --> Config Class Initialized
INFO - 2017-03-12 04:52:09 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:52:09 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:52:09 --> Utf8 Class Initialized
INFO - 2017-03-12 04:52:09 --> URI Class Initialized
INFO - 2017-03-12 04:52:09 --> Router Class Initialized
INFO - 2017-03-12 04:52:09 --> Output Class Initialized
INFO - 2017-03-12 04:52:09 --> Security Class Initialized
DEBUG - 2017-03-12 04:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:52:09 --> Input Class Initialized
INFO - 2017-03-12 04:52:09 --> Language Class Initialized
INFO - 2017-03-12 04:52:09 --> Loader Class Initialized
INFO - 2017-03-12 04:52:10 --> Database Driver Class Initialized
INFO - 2017-03-12 04:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:52:10 --> Controller Class Initialized
INFO - 2017-03-12 04:52:10 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:52:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:52:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:52:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:52:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:52:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:52:10 --> Final output sent to browser
DEBUG - 2017-03-12 04:52:10 --> Total execution time: 1.6807
INFO - 2017-03-12 04:52:46 --> Config Class Initialized
INFO - 2017-03-12 04:52:46 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:52:46 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:52:46 --> Utf8 Class Initialized
INFO - 2017-03-12 04:52:46 --> URI Class Initialized
INFO - 2017-03-12 04:52:46 --> Router Class Initialized
INFO - 2017-03-12 04:52:46 --> Output Class Initialized
INFO - 2017-03-12 04:52:46 --> Security Class Initialized
DEBUG - 2017-03-12 04:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:52:46 --> Input Class Initialized
INFO - 2017-03-12 04:52:46 --> Language Class Initialized
INFO - 2017-03-12 04:52:47 --> Loader Class Initialized
INFO - 2017-03-12 04:52:47 --> Database Driver Class Initialized
INFO - 2017-03-12 04:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:52:47 --> Controller Class Initialized
INFO - 2017-03-12 04:52:47 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:52:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:52:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:52:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:52:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:52:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:52:48 --> Final output sent to browser
DEBUG - 2017-03-12 04:52:48 --> Total execution time: 1.6235
INFO - 2017-03-12 04:52:59 --> Config Class Initialized
INFO - 2017-03-12 04:52:59 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:52:59 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:52:59 --> Utf8 Class Initialized
INFO - 2017-03-12 04:52:59 --> URI Class Initialized
INFO - 2017-03-12 04:52:59 --> Router Class Initialized
INFO - 2017-03-12 04:52:59 --> Output Class Initialized
INFO - 2017-03-12 04:52:59 --> Security Class Initialized
DEBUG - 2017-03-12 04:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:52:59 --> Input Class Initialized
INFO - 2017-03-12 04:52:59 --> Language Class Initialized
INFO - 2017-03-12 04:53:00 --> Loader Class Initialized
INFO - 2017-03-12 04:53:00 --> Database Driver Class Initialized
INFO - 2017-03-12 04:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:53:00 --> Controller Class Initialized
INFO - 2017-03-12 04:53:00 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:53:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:53:00 --> Final output sent to browser
DEBUG - 2017-03-12 04:53:00 --> Total execution time: 1.4792
INFO - 2017-03-12 04:53:42 --> Config Class Initialized
INFO - 2017-03-12 04:53:42 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:53:42 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:53:42 --> Utf8 Class Initialized
INFO - 2017-03-12 04:53:42 --> URI Class Initialized
INFO - 2017-03-12 04:53:42 --> Router Class Initialized
INFO - 2017-03-12 04:53:42 --> Output Class Initialized
INFO - 2017-03-12 04:53:42 --> Security Class Initialized
DEBUG - 2017-03-12 04:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:53:42 --> Input Class Initialized
INFO - 2017-03-12 04:53:42 --> Language Class Initialized
INFO - 2017-03-12 04:53:42 --> Loader Class Initialized
INFO - 2017-03-12 04:53:43 --> Database Driver Class Initialized
INFO - 2017-03-12 04:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:53:43 --> Controller Class Initialized
INFO - 2017-03-12 04:53:43 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:53:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:53:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:53:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:53:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:53:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:53:43 --> Final output sent to browser
DEBUG - 2017-03-12 04:53:43 --> Total execution time: 1.5247
INFO - 2017-03-12 04:53:48 --> Config Class Initialized
INFO - 2017-03-12 04:53:48 --> Hooks Class Initialized
DEBUG - 2017-03-12 04:53:49 --> UTF-8 Support Enabled
INFO - 2017-03-12 04:53:49 --> Utf8 Class Initialized
INFO - 2017-03-12 04:53:49 --> URI Class Initialized
INFO - 2017-03-12 04:53:49 --> Router Class Initialized
INFO - 2017-03-12 04:53:49 --> Output Class Initialized
INFO - 2017-03-12 04:53:49 --> Security Class Initialized
DEBUG - 2017-03-12 04:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 04:53:49 --> Input Class Initialized
INFO - 2017-03-12 04:53:49 --> Language Class Initialized
INFO - 2017-03-12 04:53:49 --> Loader Class Initialized
INFO - 2017-03-12 04:53:49 --> Database Driver Class Initialized
INFO - 2017-03-12 04:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 04:53:50 --> Controller Class Initialized
INFO - 2017-03-12 04:53:50 --> Helper loaded: url_helper
DEBUG - 2017-03-12 04:53:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 04:53:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 04:53:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 04:53:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 04:53:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 04:53:50 --> Final output sent to browser
DEBUG - 2017-03-12 04:53:50 --> Total execution time: 1.4502
INFO - 2017-03-12 05:02:34 --> Config Class Initialized
INFO - 2017-03-12 05:02:34 --> Hooks Class Initialized
DEBUG - 2017-03-12 05:02:34 --> UTF-8 Support Enabled
INFO - 2017-03-12 05:02:34 --> Utf8 Class Initialized
INFO - 2017-03-12 05:02:34 --> URI Class Initialized
INFO - 2017-03-12 05:02:34 --> Router Class Initialized
INFO - 2017-03-12 05:02:34 --> Output Class Initialized
INFO - 2017-03-12 05:02:34 --> Security Class Initialized
DEBUG - 2017-03-12 05:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 05:02:35 --> Input Class Initialized
INFO - 2017-03-12 05:02:35 --> Language Class Initialized
INFO - 2017-03-12 05:02:35 --> Loader Class Initialized
INFO - 2017-03-12 05:02:35 --> Database Driver Class Initialized
INFO - 2017-03-12 05:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 05:02:35 --> Controller Class Initialized
INFO - 2017-03-12 05:02:35 --> Helper loaded: url_helper
DEBUG - 2017-03-12 05:02:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 05:02:35 --> Config Class Initialized
INFO - 2017-03-12 05:02:35 --> Hooks Class Initialized
DEBUG - 2017-03-12 05:02:35 --> UTF-8 Support Enabled
INFO - 2017-03-12 05:02:35 --> Utf8 Class Initialized
INFO - 2017-03-12 05:02:35 --> URI Class Initialized
INFO - 2017-03-12 05:02:35 --> Router Class Initialized
INFO - 2017-03-12 05:02:35 --> Output Class Initialized
INFO - 2017-03-12 05:02:35 --> Security Class Initialized
DEBUG - 2017-03-12 05:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 05:02:35 --> Input Class Initialized
INFO - 2017-03-12 05:02:35 --> Language Class Initialized
INFO - 2017-03-12 05:02:36 --> Loader Class Initialized
INFO - 2017-03-12 05:02:36 --> Database Driver Class Initialized
INFO - 2017-03-12 05:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 05:02:36 --> Controller Class Initialized
INFO - 2017-03-12 05:02:36 --> Helper loaded: date_helper
DEBUG - 2017-03-12 05:02:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 05:02:36 --> Helper loaded: url_helper
INFO - 2017-03-12 05:02:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 05:02:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 05:02:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-12 05:02:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 05:02:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 05:02:36 --> Final output sent to browser
DEBUG - 2017-03-12 05:02:36 --> Total execution time: 0.3669
INFO - 2017-03-12 05:02:38 --> Config Class Initialized
INFO - 2017-03-12 05:02:38 --> Hooks Class Initialized
DEBUG - 2017-03-12 05:02:38 --> UTF-8 Support Enabled
INFO - 2017-03-12 05:02:38 --> Utf8 Class Initialized
INFO - 2017-03-12 05:02:38 --> URI Class Initialized
INFO - 2017-03-12 05:02:38 --> Router Class Initialized
INFO - 2017-03-12 05:02:38 --> Output Class Initialized
INFO - 2017-03-12 05:02:38 --> Security Class Initialized
DEBUG - 2017-03-12 05:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 05:02:38 --> Input Class Initialized
INFO - 2017-03-12 05:02:38 --> Language Class Initialized
INFO - 2017-03-12 05:02:38 --> Loader Class Initialized
INFO - 2017-03-12 05:02:38 --> Database Driver Class Initialized
INFO - 2017-03-12 05:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 05:02:38 --> Controller Class Initialized
INFO - 2017-03-12 05:02:38 --> Helper loaded: url_helper
DEBUG - 2017-03-12 05:02:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 05:02:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 05:02:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 05:02:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 05:02:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 05:02:38 --> Final output sent to browser
DEBUG - 2017-03-12 05:02:38 --> Total execution time: 0.0448
INFO - 2017-03-12 05:04:55 --> Config Class Initialized
INFO - 2017-03-12 05:04:55 --> Config Class Initialized
INFO - 2017-03-12 05:04:55 --> Hooks Class Initialized
INFO - 2017-03-12 05:04:55 --> Hooks Class Initialized
DEBUG - 2017-03-12 05:04:55 --> UTF-8 Support Enabled
INFO - 2017-03-12 05:04:55 --> Utf8 Class Initialized
DEBUG - 2017-03-12 05:04:55 --> UTF-8 Support Enabled
INFO - 2017-03-12 05:04:55 --> URI Class Initialized
INFO - 2017-03-12 05:04:55 --> Utf8 Class Initialized
INFO - 2017-03-12 05:04:55 --> URI Class Initialized
INFO - 2017-03-12 05:04:55 --> Router Class Initialized
INFO - 2017-03-12 05:04:55 --> Router Class Initialized
INFO - 2017-03-12 05:04:56 --> Output Class Initialized
INFO - 2017-03-12 05:04:56 --> Output Class Initialized
INFO - 2017-03-12 05:04:56 --> Security Class Initialized
INFO - 2017-03-12 05:04:56 --> Security Class Initialized
DEBUG - 2017-03-12 05:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 05:04:56 --> Input Class Initialized
INFO - 2017-03-12 05:04:56 --> Language Class Initialized
DEBUG - 2017-03-12 05:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 05:04:56 --> Input Class Initialized
INFO - 2017-03-12 05:04:56 --> Language Class Initialized
INFO - 2017-03-12 05:04:56 --> Loader Class Initialized
INFO - 2017-03-12 05:04:56 --> Loader Class Initialized
INFO - 2017-03-12 05:04:56 --> Database Driver Class Initialized
INFO - 2017-03-12 05:04:56 --> Database Driver Class Initialized
INFO - 2017-03-12 05:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 05:04:56 --> Controller Class Initialized
ERROR - 2017-03-12 05:04:56 --> Severity: Warning --> unlink(/tmp/ci_session12373a965618a03e33575978a6a169f0e22a03b8): No such file or directory /home/graduafe/public_html/system/libraries/Session/drivers/Session_files_driver.php 311
INFO - 2017-03-12 05:04:56 --> Helper loaded: url_helper
ERROR - 2017-03-12 05:04:56 --> Severity: Warning --> session_regenerate_id(): Session object destruction failed /home/graduafe/public_html/system/libraries/Session/Session.php 644
INFO - 2017-03-12 05:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 05:04:56 --> Controller Class Initialized
INFO - 2017-03-12 05:04:56 --> Helper loaded: url_helper
DEBUG - 2017-03-12 05:04:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-12 05:04:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 05:04:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 05:04:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 05:04:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 05:04:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 05:04:57 --> Final output sent to browser
DEBUG - 2017-03-12 05:04:57 --> Total execution time: 1.5935
INFO - 2017-03-12 05:05:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 05:05:07 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 05:05:07 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 05:05:07 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 05:05:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 05:05:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 05:05:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 05:05:07 --> Final output sent to browser
DEBUG - 2017-03-12 05:05:07 --> Total execution time: 12.0840
INFO - 2017-03-12 05:05:13 --> Config Class Initialized
INFO - 2017-03-12 05:05:13 --> Hooks Class Initialized
DEBUG - 2017-03-12 05:05:13 --> UTF-8 Support Enabled
INFO - 2017-03-12 05:05:13 --> Utf8 Class Initialized
INFO - 2017-03-12 05:05:13 --> URI Class Initialized
INFO - 2017-03-12 05:05:13 --> Router Class Initialized
INFO - 2017-03-12 05:05:13 --> Output Class Initialized
INFO - 2017-03-12 05:05:13 --> Security Class Initialized
DEBUG - 2017-03-12 05:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 05:05:13 --> Input Class Initialized
INFO - 2017-03-12 05:05:13 --> Language Class Initialized
INFO - 2017-03-12 05:05:13 --> Loader Class Initialized
INFO - 2017-03-12 05:05:14 --> Database Driver Class Initialized
INFO - 2017-03-12 05:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 05:05:14 --> Controller Class Initialized
INFO - 2017-03-12 05:05:14 --> Helper loaded: url_helper
DEBUG - 2017-03-12 05:05:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-12 05:05:14 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`, `contraseña`) VALUES (NULL, NULL, NULL)
INFO - 2017-03-12 05:05:14 --> Language file loaded: language/english/db_lang.php
INFO - 2017-03-12 05:05:47 --> Config Class Initialized
INFO - 2017-03-12 05:05:47 --> Hooks Class Initialized
DEBUG - 2017-03-12 05:05:47 --> UTF-8 Support Enabled
INFO - 2017-03-12 05:05:47 --> Utf8 Class Initialized
INFO - 2017-03-12 05:05:47 --> URI Class Initialized
INFO - 2017-03-12 05:05:47 --> Router Class Initialized
INFO - 2017-03-12 05:05:47 --> Output Class Initialized
INFO - 2017-03-12 05:05:47 --> Security Class Initialized
DEBUG - 2017-03-12 05:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 05:05:47 --> Input Class Initialized
INFO - 2017-03-12 05:05:47 --> Language Class Initialized
INFO - 2017-03-12 05:05:48 --> Loader Class Initialized
INFO - 2017-03-12 05:05:48 --> Database Driver Class Initialized
INFO - 2017-03-12 05:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 05:05:48 --> Controller Class Initialized
INFO - 2017-03-12 05:05:48 --> Helper loaded: url_helper
DEBUG - 2017-03-12 05:05:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 05:05:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 05:05:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 05:05:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 05:05:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 05:05:49 --> Final output sent to browser
DEBUG - 2017-03-12 05:05:49 --> Total execution time: 2.0294
INFO - 2017-03-12 05:05:50 --> Config Class Initialized
INFO - 2017-03-12 05:05:50 --> Hooks Class Initialized
DEBUG - 2017-03-12 05:05:50 --> UTF-8 Support Enabled
INFO - 2017-03-12 05:05:50 --> Utf8 Class Initialized
INFO - 2017-03-12 05:05:50 --> URI Class Initialized
INFO - 2017-03-12 05:05:50 --> Router Class Initialized
INFO - 2017-03-12 05:05:50 --> Output Class Initialized
INFO - 2017-03-12 05:05:50 --> Security Class Initialized
DEBUG - 2017-03-12 05:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 05:05:50 --> Input Class Initialized
INFO - 2017-03-12 05:05:50 --> Language Class Initialized
INFO - 2017-03-12 05:05:50 --> Loader Class Initialized
INFO - 2017-03-12 05:05:50 --> Database Driver Class Initialized
INFO - 2017-03-12 05:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 05:05:51 --> Controller Class Initialized
INFO - 2017-03-12 05:05:51 --> Helper loaded: date_helper
DEBUG - 2017-03-12 05:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 05:05:51 --> Helper loaded: url_helper
INFO - 2017-03-12 05:05:51 --> Helper loaded: download_helper
INFO - 2017-03-12 05:05:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 05:05:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 05:05:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-03-12 05:05:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-03-12 05:05:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 05:05:51 --> Final output sent to browser
DEBUG - 2017-03-12 05:05:51 --> Total execution time: 1.3589
INFO - 2017-03-12 05:06:03 --> Config Class Initialized
INFO - 2017-03-12 05:06:03 --> Hooks Class Initialized
DEBUG - 2017-03-12 05:06:03 --> UTF-8 Support Enabled
INFO - 2017-03-12 05:06:03 --> Utf8 Class Initialized
INFO - 2017-03-12 05:06:03 --> URI Class Initialized
INFO - 2017-03-12 05:06:03 --> Router Class Initialized
INFO - 2017-03-12 05:06:03 --> Output Class Initialized
INFO - 2017-03-12 05:06:03 --> Security Class Initialized
DEBUG - 2017-03-12 05:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 05:06:04 --> Input Class Initialized
INFO - 2017-03-12 05:06:04 --> Language Class Initialized
INFO - 2017-03-12 05:06:04 --> Loader Class Initialized
INFO - 2017-03-12 05:06:04 --> Database Driver Class Initialized
INFO - 2017-03-12 05:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 05:06:04 --> Controller Class Initialized
INFO - 2017-03-12 05:06:04 --> Helper loaded: url_helper
DEBUG - 2017-03-12 05:06:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 05:06:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 05:06:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 05:06:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 05:06:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 05:06:05 --> Final output sent to browser
DEBUG - 2017-03-12 05:06:05 --> Total execution time: 1.4245
INFO - 2017-03-12 05:09:17 --> Config Class Initialized
INFO - 2017-03-12 05:09:17 --> Hooks Class Initialized
DEBUG - 2017-03-12 05:09:17 --> UTF-8 Support Enabled
INFO - 2017-03-12 05:09:17 --> Utf8 Class Initialized
INFO - 2017-03-12 05:09:17 --> URI Class Initialized
INFO - 2017-03-12 05:09:17 --> Router Class Initialized
INFO - 2017-03-12 05:09:17 --> Output Class Initialized
INFO - 2017-03-12 05:09:17 --> Security Class Initialized
DEBUG - 2017-03-12 05:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 05:09:17 --> Input Class Initialized
INFO - 2017-03-12 05:09:17 --> Language Class Initialized
INFO - 2017-03-12 05:09:17 --> Loader Class Initialized
INFO - 2017-03-12 05:09:18 --> Database Driver Class Initialized
INFO - 2017-03-12 05:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 05:09:18 --> Controller Class Initialized
INFO - 2017-03-12 05:09:18 --> Helper loaded: date_helper
INFO - 2017-03-12 05:09:18 --> Helper loaded: url_helper
DEBUG - 2017-03-12 05:09:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 05:09:18 --> Helper loaded: form_helper
INFO - 2017-03-12 05:09:18 --> Form Validation Class Initialized
INFO - 2017-03-12 05:09:18 --> Final output sent to browser
DEBUG - 2017-03-12 05:09:18 --> Total execution time: 1.2953
INFO - 2017-03-12 05:09:47 --> Config Class Initialized
INFO - 2017-03-12 05:09:47 --> Hooks Class Initialized
DEBUG - 2017-03-12 05:09:47 --> UTF-8 Support Enabled
INFO - 2017-03-12 05:09:47 --> Utf8 Class Initialized
INFO - 2017-03-12 05:09:47 --> URI Class Initialized
INFO - 2017-03-12 05:09:47 --> Router Class Initialized
INFO - 2017-03-12 05:09:47 --> Output Class Initialized
INFO - 2017-03-12 05:09:47 --> Security Class Initialized
DEBUG - 2017-03-12 05:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 05:09:47 --> Input Class Initialized
INFO - 2017-03-12 05:09:47 --> Language Class Initialized
INFO - 2017-03-12 05:09:47 --> Loader Class Initialized
INFO - 2017-03-12 05:09:48 --> Database Driver Class Initialized
INFO - 2017-03-12 05:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 05:09:48 --> Controller Class Initialized
INFO - 2017-03-12 05:09:48 --> Helper loaded: date_helper
DEBUG - 2017-03-12 05:09:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 05:09:48 --> Helper loaded: url_helper
INFO - 2017-03-12 05:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 05:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-03-12 05:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 05:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-03-12 05:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-03-12 05:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 05:09:48 --> Final output sent to browser
DEBUG - 2017-03-12 05:09:48 --> Total execution time: 1.2761
INFO - 2017-03-12 05:09:57 --> Config Class Initialized
INFO - 2017-03-12 05:09:57 --> Hooks Class Initialized
DEBUG - 2017-03-12 05:09:58 --> UTF-8 Support Enabled
INFO - 2017-03-12 05:09:58 --> Utf8 Class Initialized
INFO - 2017-03-12 05:09:58 --> URI Class Initialized
INFO - 2017-03-12 05:09:58 --> Router Class Initialized
INFO - 2017-03-12 05:09:58 --> Output Class Initialized
INFO - 2017-03-12 05:09:58 --> Security Class Initialized
DEBUG - 2017-03-12 05:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 05:09:58 --> Input Class Initialized
INFO - 2017-03-12 05:09:58 --> Language Class Initialized
INFO - 2017-03-12 05:09:58 --> Loader Class Initialized
INFO - 2017-03-12 05:09:58 --> Database Driver Class Initialized
INFO - 2017-03-12 05:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 05:09:58 --> Controller Class Initialized
INFO - 2017-03-12 05:09:58 --> Helper loaded: url_helper
DEBUG - 2017-03-12 05:09:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 05:09:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 05:09:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 05:09:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 05:09:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 05:09:59 --> Final output sent to browser
DEBUG - 2017-03-12 05:09:59 --> Total execution time: 1.4211
INFO - 2017-03-12 05:10:17 --> Config Class Initialized
INFO - 2017-03-12 05:10:17 --> Hooks Class Initialized
DEBUG - 2017-03-12 05:10:17 --> UTF-8 Support Enabled
INFO - 2017-03-12 05:10:17 --> Utf8 Class Initialized
INFO - 2017-03-12 05:10:17 --> URI Class Initialized
INFO - 2017-03-12 05:10:17 --> Router Class Initialized
INFO - 2017-03-12 05:10:18 --> Output Class Initialized
INFO - 2017-03-12 05:10:18 --> Security Class Initialized
DEBUG - 2017-03-12 05:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 05:10:18 --> Input Class Initialized
INFO - 2017-03-12 05:10:18 --> Language Class Initialized
INFO - 2017-03-12 05:10:18 --> Loader Class Initialized
INFO - 2017-03-12 05:10:18 --> Database Driver Class Initialized
INFO - 2017-03-12 05:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 05:10:18 --> Controller Class Initialized
INFO - 2017-03-12 05:10:18 --> Upload Class Initialized
INFO - 2017-03-12 05:10:19 --> Helper loaded: date_helper
DEBUG - 2017-03-12 05:10:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 05:10:19 --> Helper loaded: url_helper
INFO - 2017-03-12 05:10:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 05:10:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 05:10:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-03-12 05:10:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-03-12 05:10:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-03-12 05:10:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 05:10:19 --> Final output sent to browser
DEBUG - 2017-03-12 05:10:19 --> Total execution time: 1.7375
INFO - 2017-03-12 05:10:26 --> Config Class Initialized
INFO - 2017-03-12 05:10:26 --> Hooks Class Initialized
DEBUG - 2017-03-12 05:10:26 --> UTF-8 Support Enabled
INFO - 2017-03-12 05:10:26 --> Utf8 Class Initialized
INFO - 2017-03-12 05:10:26 --> URI Class Initialized
INFO - 2017-03-12 05:10:26 --> Router Class Initialized
INFO - 2017-03-12 05:10:26 --> Output Class Initialized
INFO - 2017-03-12 05:10:27 --> Security Class Initialized
DEBUG - 2017-03-12 05:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 05:10:27 --> Input Class Initialized
INFO - 2017-03-12 05:10:27 --> Language Class Initialized
INFO - 2017-03-12 05:10:27 --> Loader Class Initialized
INFO - 2017-03-12 05:10:27 --> Database Driver Class Initialized
INFO - 2017-03-12 05:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 05:10:27 --> Controller Class Initialized
INFO - 2017-03-12 05:10:27 --> Helper loaded: url_helper
DEBUG - 2017-03-12 05:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 05:10:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 05:10:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 05:10:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 05:10:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 05:10:28 --> Final output sent to browser
DEBUG - 2017-03-12 05:10:28 --> Total execution time: 3.6868
INFO - 2017-03-12 05:59:51 --> Config Class Initialized
INFO - 2017-03-12 05:59:51 --> Hooks Class Initialized
DEBUG - 2017-03-12 05:59:52 --> UTF-8 Support Enabled
INFO - 2017-03-12 05:59:52 --> Utf8 Class Initialized
INFO - 2017-03-12 05:59:52 --> URI Class Initialized
DEBUG - 2017-03-12 05:59:52 --> No URI present. Default controller set.
INFO - 2017-03-12 05:59:52 --> Router Class Initialized
INFO - 2017-03-12 05:59:52 --> Output Class Initialized
INFO - 2017-03-12 05:59:52 --> Security Class Initialized
DEBUG - 2017-03-12 05:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 05:59:52 --> Input Class Initialized
INFO - 2017-03-12 05:59:52 --> Language Class Initialized
INFO - 2017-03-12 05:59:52 --> Loader Class Initialized
INFO - 2017-03-12 05:59:52 --> Database Driver Class Initialized
INFO - 2017-03-12 05:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 05:59:53 --> Controller Class Initialized
INFO - 2017-03-12 05:59:53 --> Helper loaded: url_helper
DEBUG - 2017-03-12 05:59:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 05:59:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 05:59:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 05:59:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 05:59:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 05:59:53 --> Final output sent to browser
DEBUG - 2017-03-12 05:59:53 --> Total execution time: 2.2292
INFO - 2017-03-12 15:20:01 --> Config Class Initialized
INFO - 2017-03-12 15:20:01 --> Hooks Class Initialized
DEBUG - 2017-03-12 15:20:01 --> UTF-8 Support Enabled
INFO - 2017-03-12 15:20:01 --> Utf8 Class Initialized
INFO - 2017-03-12 15:20:01 --> URI Class Initialized
INFO - 2017-03-12 15:20:01 --> Router Class Initialized
INFO - 2017-03-12 15:20:01 --> Output Class Initialized
INFO - 2017-03-12 15:20:01 --> Security Class Initialized
DEBUG - 2017-03-12 15:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 15:20:02 --> Input Class Initialized
INFO - 2017-03-12 15:20:02 --> Language Class Initialized
INFO - 2017-03-12 15:20:02 --> Loader Class Initialized
INFO - 2017-03-12 15:20:02 --> Database Driver Class Initialized
INFO - 2017-03-12 15:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 15:20:02 --> Controller Class Initialized
INFO - 2017-03-12 15:20:02 --> Helper loaded: url_helper
DEBUG - 2017-03-12 15:20:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 15:20:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 15:20:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 15:20:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 15:20:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 15:20:07 --> Final output sent to browser
DEBUG - 2017-03-12 15:20:07 --> Total execution time: 5.8401
INFO - 2017-03-12 15:20:12 --> Config Class Initialized
INFO - 2017-03-12 15:20:12 --> Hooks Class Initialized
DEBUG - 2017-03-12 15:20:12 --> UTF-8 Support Enabled
INFO - 2017-03-12 15:20:12 --> Utf8 Class Initialized
INFO - 2017-03-12 15:20:12 --> URI Class Initialized
DEBUG - 2017-03-12 15:20:12 --> No URI present. Default controller set.
INFO - 2017-03-12 15:20:12 --> Router Class Initialized
INFO - 2017-03-12 15:20:12 --> Output Class Initialized
INFO - 2017-03-12 15:20:12 --> Security Class Initialized
DEBUG - 2017-03-12 15:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 15:20:12 --> Input Class Initialized
INFO - 2017-03-12 15:20:12 --> Language Class Initialized
INFO - 2017-03-12 15:20:12 --> Loader Class Initialized
INFO - 2017-03-12 15:20:12 --> Database Driver Class Initialized
INFO - 2017-03-12 15:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 15:20:12 --> Controller Class Initialized
INFO - 2017-03-12 15:20:12 --> Helper loaded: url_helper
DEBUG - 2017-03-12 15:20:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 15:20:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 15:20:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 15:20:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 15:20:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 15:20:12 --> Final output sent to browser
DEBUG - 2017-03-12 15:20:12 --> Total execution time: 0.0425
INFO - 2017-03-12 16:15:42 --> Config Class Initialized
INFO - 2017-03-12 16:15:42 --> Hooks Class Initialized
DEBUG - 2017-03-12 16:15:42 --> UTF-8 Support Enabled
INFO - 2017-03-12 16:15:42 --> Utf8 Class Initialized
INFO - 2017-03-12 16:15:42 --> URI Class Initialized
DEBUG - 2017-03-12 16:15:42 --> No URI present. Default controller set.
INFO - 2017-03-12 16:15:42 --> Router Class Initialized
INFO - 2017-03-12 16:15:42 --> Output Class Initialized
INFO - 2017-03-12 16:15:42 --> Security Class Initialized
DEBUG - 2017-03-12 16:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 16:15:42 --> Input Class Initialized
INFO - 2017-03-12 16:15:42 --> Language Class Initialized
INFO - 2017-03-12 16:15:42 --> Loader Class Initialized
INFO - 2017-03-12 16:15:42 --> Database Driver Class Initialized
INFO - 2017-03-12 16:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 16:15:42 --> Controller Class Initialized
INFO - 2017-03-12 16:15:42 --> Helper loaded: url_helper
DEBUG - 2017-03-12 16:15:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 16:15:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 16:15:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 16:15:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 16:15:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 16:15:42 --> Final output sent to browser
DEBUG - 2017-03-12 16:15:42 --> Total execution time: 0.3463
INFO - 2017-03-12 16:15:51 --> Config Class Initialized
INFO - 2017-03-12 16:15:51 --> Hooks Class Initialized
DEBUG - 2017-03-12 16:15:51 --> UTF-8 Support Enabled
INFO - 2017-03-12 16:15:51 --> Utf8 Class Initialized
INFO - 2017-03-12 16:15:51 --> URI Class Initialized
INFO - 2017-03-12 16:15:51 --> Router Class Initialized
INFO - 2017-03-12 16:15:51 --> Output Class Initialized
INFO - 2017-03-12 16:15:51 --> Security Class Initialized
DEBUG - 2017-03-12 16:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 16:15:51 --> Input Class Initialized
INFO - 2017-03-12 16:15:51 --> Language Class Initialized
INFO - 2017-03-12 16:15:51 --> Loader Class Initialized
INFO - 2017-03-12 16:15:51 --> Database Driver Class Initialized
INFO - 2017-03-12 16:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 16:15:51 --> Controller Class Initialized
INFO - 2017-03-12 16:15:51 --> Helper loaded: url_helper
DEBUG - 2017-03-12 16:15:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 16:15:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 16:15:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 16:15:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 16:15:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 16:15:51 --> Final output sent to browser
DEBUG - 2017-03-12 16:15:51 --> Total execution time: 0.0170
INFO - 2017-03-12 16:15:59 --> Config Class Initialized
INFO - 2017-03-12 16:15:59 --> Hooks Class Initialized
DEBUG - 2017-03-12 16:15:59 --> UTF-8 Support Enabled
INFO - 2017-03-12 16:15:59 --> Utf8 Class Initialized
INFO - 2017-03-12 16:15:59 --> URI Class Initialized
INFO - 2017-03-12 16:15:59 --> Router Class Initialized
INFO - 2017-03-12 16:15:59 --> Output Class Initialized
INFO - 2017-03-12 16:15:59 --> Security Class Initialized
DEBUG - 2017-03-12 16:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 16:15:59 --> Input Class Initialized
INFO - 2017-03-12 16:15:59 --> Language Class Initialized
INFO - 2017-03-12 16:15:59 --> Loader Class Initialized
INFO - 2017-03-12 16:15:59 --> Database Driver Class Initialized
INFO - 2017-03-12 16:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 16:15:59 --> Controller Class Initialized
INFO - 2017-03-12 16:15:59 --> Helper loaded: url_helper
DEBUG - 2017-03-12 16:15:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 16:16:00 --> Config Class Initialized
INFO - 2017-03-12 16:16:00 --> Hooks Class Initialized
DEBUG - 2017-03-12 16:16:00 --> UTF-8 Support Enabled
INFO - 2017-03-12 16:16:00 --> Utf8 Class Initialized
INFO - 2017-03-12 16:16:00 --> URI Class Initialized
INFO - 2017-03-12 16:16:00 --> Router Class Initialized
INFO - 2017-03-12 16:16:00 --> Output Class Initialized
INFO - 2017-03-12 16:16:00 --> Security Class Initialized
DEBUG - 2017-03-12 16:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 16:16:00 --> Input Class Initialized
INFO - 2017-03-12 16:16:00 --> Language Class Initialized
INFO - 2017-03-12 16:16:00 --> Loader Class Initialized
INFO - 2017-03-12 16:16:00 --> Database Driver Class Initialized
INFO - 2017-03-12 16:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 16:16:00 --> Controller Class Initialized
INFO - 2017-03-12 16:16:00 --> Helper loaded: date_helper
DEBUG - 2017-03-12 16:16:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 16:16:00 --> Helper loaded: url_helper
INFO - 2017-03-12 16:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 16:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 16:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 16:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 16:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 16:16:00 --> Final output sent to browser
DEBUG - 2017-03-12 16:16:00 --> Total execution time: 0.1565
INFO - 2017-03-12 16:16:01 --> Config Class Initialized
INFO - 2017-03-12 16:16:01 --> Hooks Class Initialized
DEBUG - 2017-03-12 16:16:01 --> UTF-8 Support Enabled
INFO - 2017-03-12 16:16:01 --> Utf8 Class Initialized
INFO - 2017-03-12 16:16:01 --> URI Class Initialized
INFO - 2017-03-12 16:16:01 --> Router Class Initialized
INFO - 2017-03-12 16:16:01 --> Output Class Initialized
INFO - 2017-03-12 16:16:01 --> Security Class Initialized
DEBUG - 2017-03-12 16:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 16:16:01 --> Input Class Initialized
INFO - 2017-03-12 16:16:01 --> Language Class Initialized
INFO - 2017-03-12 16:16:01 --> Loader Class Initialized
INFO - 2017-03-12 16:16:01 --> Database Driver Class Initialized
INFO - 2017-03-12 16:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 16:16:01 --> Controller Class Initialized
INFO - 2017-03-12 16:16:01 --> Helper loaded: url_helper
DEBUG - 2017-03-12 16:16:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 16:16:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 16:16:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 16:16:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 16:16:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 16:16:01 --> Final output sent to browser
DEBUG - 2017-03-12 16:16:01 --> Total execution time: 0.0159
INFO - 2017-03-12 16:16:16 --> Config Class Initialized
INFO - 2017-03-12 16:16:16 --> Hooks Class Initialized
DEBUG - 2017-03-12 16:16:17 --> UTF-8 Support Enabled
INFO - 2017-03-12 16:16:17 --> Utf8 Class Initialized
INFO - 2017-03-12 16:16:17 --> URI Class Initialized
DEBUG - 2017-03-12 16:16:17 --> No URI present. Default controller set.
INFO - 2017-03-12 16:16:17 --> Router Class Initialized
INFO - 2017-03-12 16:16:17 --> Output Class Initialized
INFO - 2017-03-12 16:16:17 --> Security Class Initialized
DEBUG - 2017-03-12 16:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 16:16:17 --> Input Class Initialized
INFO - 2017-03-12 16:16:17 --> Language Class Initialized
INFO - 2017-03-12 16:16:17 --> Loader Class Initialized
INFO - 2017-03-12 16:16:17 --> Database Driver Class Initialized
INFO - 2017-03-12 16:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 16:16:17 --> Controller Class Initialized
INFO - 2017-03-12 16:16:17 --> Helper loaded: url_helper
DEBUG - 2017-03-12 16:16:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 16:16:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 16:16:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 16:16:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 16:16:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 16:16:18 --> Final output sent to browser
DEBUG - 2017-03-12 16:16:18 --> Total execution time: 1.2694
INFO - 2017-03-12 16:16:19 --> Config Class Initialized
INFO - 2017-03-12 16:16:19 --> Hooks Class Initialized
DEBUG - 2017-03-12 16:16:19 --> UTF-8 Support Enabled
INFO - 2017-03-12 16:16:19 --> Utf8 Class Initialized
INFO - 2017-03-12 16:16:19 --> URI Class Initialized
INFO - 2017-03-12 16:16:19 --> Router Class Initialized
INFO - 2017-03-12 16:16:19 --> Output Class Initialized
INFO - 2017-03-12 16:16:19 --> Security Class Initialized
DEBUG - 2017-03-12 16:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 16:16:19 --> Input Class Initialized
INFO - 2017-03-12 16:16:19 --> Language Class Initialized
INFO - 2017-03-12 16:16:20 --> Loader Class Initialized
INFO - 2017-03-12 16:16:20 --> Database Driver Class Initialized
INFO - 2017-03-12 16:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 16:16:21 --> Controller Class Initialized
INFO - 2017-03-12 16:16:21 --> Helper loaded: url_helper
DEBUG - 2017-03-12 16:16:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 16:16:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 16:16:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 16:16:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 16:16:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 16:16:21 --> Final output sent to browser
DEBUG - 2017-03-12 16:16:21 --> Total execution time: 1.9759
INFO - 2017-03-12 17:25:26 --> Config Class Initialized
INFO - 2017-03-12 17:25:26 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:25:26 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:25:26 --> Utf8 Class Initialized
INFO - 2017-03-12 17:25:26 --> URI Class Initialized
DEBUG - 2017-03-12 17:25:26 --> No URI present. Default controller set.
INFO - 2017-03-12 17:25:26 --> Router Class Initialized
INFO - 2017-03-12 17:25:27 --> Output Class Initialized
INFO - 2017-03-12 17:25:27 --> Security Class Initialized
DEBUG - 2017-03-12 17:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:25:27 --> Input Class Initialized
INFO - 2017-03-12 17:25:27 --> Language Class Initialized
INFO - 2017-03-12 17:25:27 --> Loader Class Initialized
INFO - 2017-03-12 17:25:27 --> Database Driver Class Initialized
INFO - 2017-03-12 17:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:25:28 --> Controller Class Initialized
INFO - 2017-03-12 17:25:28 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:25:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:25:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:25:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:25:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:25:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:25:28 --> Final output sent to browser
DEBUG - 2017-03-12 17:25:28 --> Total execution time: 1.7143
INFO - 2017-03-12 17:25:30 --> Config Class Initialized
INFO - 2017-03-12 17:25:30 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:25:30 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:25:30 --> Utf8 Class Initialized
INFO - 2017-03-12 17:25:30 --> URI Class Initialized
INFO - 2017-03-12 17:25:30 --> Router Class Initialized
INFO - 2017-03-12 17:25:30 --> Output Class Initialized
INFO - 2017-03-12 17:25:30 --> Security Class Initialized
DEBUG - 2017-03-12 17:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:25:30 --> Input Class Initialized
INFO - 2017-03-12 17:25:30 --> Language Class Initialized
INFO - 2017-03-12 17:25:30 --> Loader Class Initialized
INFO - 2017-03-12 17:25:30 --> Database Driver Class Initialized
INFO - 2017-03-12 17:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:25:30 --> Controller Class Initialized
INFO - 2017-03-12 17:25:30 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:25:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:25:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:25:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:25:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:25:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:25:30 --> Final output sent to browser
DEBUG - 2017-03-12 17:25:30 --> Total execution time: 0.0135
INFO - 2017-03-12 17:25:55 --> Config Class Initialized
INFO - 2017-03-12 17:25:55 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:25:55 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:25:55 --> Utf8 Class Initialized
INFO - 2017-03-12 17:25:55 --> URI Class Initialized
INFO - 2017-03-12 17:25:55 --> Router Class Initialized
INFO - 2017-03-12 17:25:55 --> Output Class Initialized
INFO - 2017-03-12 17:25:55 --> Security Class Initialized
DEBUG - 2017-03-12 17:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:25:55 --> Input Class Initialized
INFO - 2017-03-12 17:25:55 --> Language Class Initialized
INFO - 2017-03-12 17:25:55 --> Loader Class Initialized
INFO - 2017-03-12 17:25:55 --> Database Driver Class Initialized
INFO - 2017-03-12 17:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:25:55 --> Controller Class Initialized
INFO - 2017-03-12 17:25:55 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:25:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:25:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:25:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:25:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:25:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:25:55 --> Final output sent to browser
DEBUG - 2017-03-12 17:25:55 --> Total execution time: 0.0337
INFO - 2017-03-12 17:25:58 --> Config Class Initialized
INFO - 2017-03-12 17:25:58 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:25:58 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:25:58 --> Utf8 Class Initialized
INFO - 2017-03-12 17:25:58 --> URI Class Initialized
INFO - 2017-03-12 17:25:58 --> Router Class Initialized
INFO - 2017-03-12 17:25:58 --> Output Class Initialized
INFO - 2017-03-12 17:25:58 --> Security Class Initialized
DEBUG - 2017-03-12 17:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:25:58 --> Input Class Initialized
INFO - 2017-03-12 17:25:58 --> Language Class Initialized
INFO - 2017-03-12 17:25:58 --> Loader Class Initialized
INFO - 2017-03-12 17:25:58 --> Database Driver Class Initialized
INFO - 2017-03-12 17:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:25:58 --> Controller Class Initialized
INFO - 2017-03-12 17:25:58 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:25:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:25:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:25:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:25:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:25:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:25:58 --> Final output sent to browser
DEBUG - 2017-03-12 17:25:58 --> Total execution time: 0.0140
INFO - 2017-03-12 17:26:03 --> Config Class Initialized
INFO - 2017-03-12 17:26:03 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:26:03 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:26:03 --> Utf8 Class Initialized
INFO - 2017-03-12 17:26:03 --> URI Class Initialized
INFO - 2017-03-12 17:26:03 --> Router Class Initialized
INFO - 2017-03-12 17:26:03 --> Output Class Initialized
INFO - 2017-03-12 17:26:03 --> Security Class Initialized
DEBUG - 2017-03-12 17:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:26:03 --> Input Class Initialized
INFO - 2017-03-12 17:26:03 --> Language Class Initialized
INFO - 2017-03-12 17:26:03 --> Loader Class Initialized
INFO - 2017-03-12 17:26:03 --> Database Driver Class Initialized
INFO - 2017-03-12 17:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:26:03 --> Controller Class Initialized
INFO - 2017-03-12 17:26:03 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:26:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:26:03 --> Final output sent to browser
DEBUG - 2017-03-12 17:26:03 --> Total execution time: 0.0298
INFO - 2017-03-12 17:26:04 --> Config Class Initialized
INFO - 2017-03-12 17:26:04 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:26:04 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:26:04 --> Utf8 Class Initialized
INFO - 2017-03-12 17:26:04 --> URI Class Initialized
INFO - 2017-03-12 17:26:04 --> Router Class Initialized
INFO - 2017-03-12 17:26:04 --> Output Class Initialized
INFO - 2017-03-12 17:26:04 --> Security Class Initialized
DEBUG - 2017-03-12 17:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:26:04 --> Input Class Initialized
INFO - 2017-03-12 17:26:04 --> Language Class Initialized
INFO - 2017-03-12 17:26:04 --> Loader Class Initialized
INFO - 2017-03-12 17:26:04 --> Database Driver Class Initialized
INFO - 2017-03-12 17:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:26:04 --> Controller Class Initialized
INFO - 2017-03-12 17:26:04 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:26:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:26:04 --> Final output sent to browser
DEBUG - 2017-03-12 17:26:04 --> Total execution time: 0.0138
INFO - 2017-03-12 17:26:09 --> Config Class Initialized
INFO - 2017-03-12 17:26:09 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:26:09 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:26:09 --> Utf8 Class Initialized
INFO - 2017-03-12 17:26:09 --> URI Class Initialized
INFO - 2017-03-12 17:26:09 --> Router Class Initialized
INFO - 2017-03-12 17:26:09 --> Output Class Initialized
INFO - 2017-03-12 17:26:09 --> Security Class Initialized
DEBUG - 2017-03-12 17:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:26:09 --> Input Class Initialized
INFO - 2017-03-12 17:26:09 --> Language Class Initialized
INFO - 2017-03-12 17:26:09 --> Loader Class Initialized
INFO - 2017-03-12 17:26:09 --> Database Driver Class Initialized
INFO - 2017-03-12 17:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:26:09 --> Controller Class Initialized
INFO - 2017-03-12 17:26:09 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:26:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:26:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:26:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:26:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:26:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:26:09 --> Final output sent to browser
DEBUG - 2017-03-12 17:26:09 --> Total execution time: 0.0143
INFO - 2017-03-12 17:26:10 --> Config Class Initialized
INFO - 2017-03-12 17:26:10 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:26:10 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:26:10 --> Utf8 Class Initialized
INFO - 2017-03-12 17:26:10 --> URI Class Initialized
INFO - 2017-03-12 17:26:10 --> Router Class Initialized
INFO - 2017-03-12 17:26:10 --> Output Class Initialized
INFO - 2017-03-12 17:26:10 --> Security Class Initialized
DEBUG - 2017-03-12 17:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:26:10 --> Input Class Initialized
INFO - 2017-03-12 17:26:10 --> Language Class Initialized
INFO - 2017-03-12 17:26:10 --> Loader Class Initialized
INFO - 2017-03-12 17:26:10 --> Database Driver Class Initialized
INFO - 2017-03-12 17:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:26:10 --> Controller Class Initialized
INFO - 2017-03-12 17:26:10 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:26:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:26:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:26:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:26:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:26:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:26:10 --> Final output sent to browser
DEBUG - 2017-03-12 17:26:10 --> Total execution time: 0.0143
INFO - 2017-03-12 17:26:12 --> Config Class Initialized
INFO - 2017-03-12 17:26:12 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:26:12 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:26:12 --> Utf8 Class Initialized
INFO - 2017-03-12 17:26:12 --> URI Class Initialized
INFO - 2017-03-12 17:26:12 --> Router Class Initialized
INFO - 2017-03-12 17:26:12 --> Output Class Initialized
INFO - 2017-03-12 17:26:12 --> Security Class Initialized
DEBUG - 2017-03-12 17:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:26:12 --> Input Class Initialized
INFO - 2017-03-12 17:26:12 --> Language Class Initialized
INFO - 2017-03-12 17:26:12 --> Loader Class Initialized
INFO - 2017-03-12 17:26:12 --> Database Driver Class Initialized
INFO - 2017-03-12 17:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:26:12 --> Controller Class Initialized
INFO - 2017-03-12 17:26:12 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:26:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:26:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:26:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:26:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:26:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:26:12 --> Final output sent to browser
DEBUG - 2017-03-12 17:26:12 --> Total execution time: 0.0144
INFO - 2017-03-12 17:26:12 --> Config Class Initialized
INFO - 2017-03-12 17:26:12 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:26:12 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:26:12 --> Utf8 Class Initialized
INFO - 2017-03-12 17:26:12 --> URI Class Initialized
INFO - 2017-03-12 17:26:12 --> Router Class Initialized
INFO - 2017-03-12 17:26:12 --> Output Class Initialized
INFO - 2017-03-12 17:26:12 --> Security Class Initialized
DEBUG - 2017-03-12 17:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:26:12 --> Input Class Initialized
INFO - 2017-03-12 17:26:12 --> Language Class Initialized
INFO - 2017-03-12 17:26:12 --> Loader Class Initialized
INFO - 2017-03-12 17:26:12 --> Database Driver Class Initialized
INFO - 2017-03-12 17:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:26:12 --> Controller Class Initialized
INFO - 2017-03-12 17:26:12 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:26:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:26:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:26:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:26:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:26:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:26:12 --> Final output sent to browser
DEBUG - 2017-03-12 17:26:12 --> Total execution time: 0.0133
INFO - 2017-03-12 17:26:50 --> Config Class Initialized
INFO - 2017-03-12 17:26:50 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:26:50 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:26:50 --> Utf8 Class Initialized
INFO - 2017-03-12 17:26:50 --> URI Class Initialized
INFO - 2017-03-12 17:26:50 --> Router Class Initialized
INFO - 2017-03-12 17:26:50 --> Output Class Initialized
INFO - 2017-03-12 17:26:50 --> Security Class Initialized
DEBUG - 2017-03-12 17:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:26:50 --> Input Class Initialized
INFO - 2017-03-12 17:26:50 --> Language Class Initialized
INFO - 2017-03-12 17:26:50 --> Loader Class Initialized
INFO - 2017-03-12 17:26:50 --> Database Driver Class Initialized
INFO - 2017-03-12 17:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:26:50 --> Controller Class Initialized
INFO - 2017-03-12 17:26:50 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:26:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:26:50 --> Final output sent to browser
DEBUG - 2017-03-12 17:26:50 --> Total execution time: 0.2719
INFO - 2017-03-12 17:26:52 --> Config Class Initialized
INFO - 2017-03-12 17:26:52 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:26:52 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:26:52 --> Utf8 Class Initialized
INFO - 2017-03-12 17:26:52 --> URI Class Initialized
INFO - 2017-03-12 17:26:52 --> Router Class Initialized
INFO - 2017-03-12 17:26:52 --> Output Class Initialized
INFO - 2017-03-12 17:26:52 --> Security Class Initialized
DEBUG - 2017-03-12 17:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:26:52 --> Input Class Initialized
INFO - 2017-03-12 17:26:52 --> Language Class Initialized
INFO - 2017-03-12 17:26:52 --> Loader Class Initialized
INFO - 2017-03-12 17:26:52 --> Database Driver Class Initialized
INFO - 2017-03-12 17:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:26:52 --> Controller Class Initialized
INFO - 2017-03-12 17:26:52 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:26:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:26:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:26:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:26:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:26:52 --> Final output sent to browser
DEBUG - 2017-03-12 17:26:52 --> Total execution time: 0.0137
INFO - 2017-03-12 17:27:20 --> Config Class Initialized
INFO - 2017-03-12 17:27:20 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:27:20 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:27:20 --> Utf8 Class Initialized
INFO - 2017-03-12 17:27:20 --> URI Class Initialized
DEBUG - 2017-03-12 17:27:20 --> No URI present. Default controller set.
INFO - 2017-03-12 17:27:20 --> Router Class Initialized
INFO - 2017-03-12 17:27:20 --> Output Class Initialized
INFO - 2017-03-12 17:27:20 --> Security Class Initialized
DEBUG - 2017-03-12 17:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:27:20 --> Input Class Initialized
INFO - 2017-03-12 17:27:20 --> Language Class Initialized
INFO - 2017-03-12 17:27:20 --> Loader Class Initialized
INFO - 2017-03-12 17:27:20 --> Database Driver Class Initialized
INFO - 2017-03-12 17:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:27:20 --> Controller Class Initialized
INFO - 2017-03-12 17:27:20 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:27:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:27:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:27:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:27:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:27:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:27:20 --> Final output sent to browser
DEBUG - 2017-03-12 17:27:20 --> Total execution time: 0.0135
INFO - 2017-03-12 17:27:21 --> Config Class Initialized
INFO - 2017-03-12 17:27:21 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:27:21 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:27:21 --> Utf8 Class Initialized
INFO - 2017-03-12 17:27:21 --> URI Class Initialized
INFO - 2017-03-12 17:27:21 --> Router Class Initialized
INFO - 2017-03-12 17:27:21 --> Output Class Initialized
INFO - 2017-03-12 17:27:21 --> Security Class Initialized
DEBUG - 2017-03-12 17:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:27:21 --> Input Class Initialized
INFO - 2017-03-12 17:27:21 --> Language Class Initialized
INFO - 2017-03-12 17:27:21 --> Loader Class Initialized
INFO - 2017-03-12 17:27:21 --> Database Driver Class Initialized
INFO - 2017-03-12 17:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:27:21 --> Controller Class Initialized
INFO - 2017-03-12 17:27:21 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:27:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:27:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:27:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:27:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:27:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:27:21 --> Final output sent to browser
DEBUG - 2017-03-12 17:27:21 --> Total execution time: 0.0151
INFO - 2017-03-12 17:27:22 --> Config Class Initialized
INFO - 2017-03-12 17:27:22 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:27:22 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:27:22 --> Utf8 Class Initialized
INFO - 2017-03-12 17:27:22 --> URI Class Initialized
INFO - 2017-03-12 17:27:22 --> Router Class Initialized
INFO - 2017-03-12 17:27:22 --> Output Class Initialized
INFO - 2017-03-12 17:27:22 --> Security Class Initialized
DEBUG - 2017-03-12 17:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:27:22 --> Input Class Initialized
INFO - 2017-03-12 17:27:22 --> Language Class Initialized
INFO - 2017-03-12 17:27:22 --> Loader Class Initialized
INFO - 2017-03-12 17:27:22 --> Database Driver Class Initialized
INFO - 2017-03-12 17:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:27:22 --> Controller Class Initialized
INFO - 2017-03-12 17:27:22 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:27:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:27:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:27:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:27:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:27:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:27:22 --> Final output sent to browser
DEBUG - 2017-03-12 17:27:22 --> Total execution time: 0.0133
INFO - 2017-03-12 17:27:23 --> Config Class Initialized
INFO - 2017-03-12 17:27:23 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:27:23 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:27:23 --> Utf8 Class Initialized
INFO - 2017-03-12 17:27:23 --> URI Class Initialized
INFO - 2017-03-12 17:27:23 --> Router Class Initialized
INFO - 2017-03-12 17:27:23 --> Output Class Initialized
INFO - 2017-03-12 17:27:23 --> Security Class Initialized
DEBUG - 2017-03-12 17:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:27:23 --> Input Class Initialized
INFO - 2017-03-12 17:27:23 --> Language Class Initialized
INFO - 2017-03-12 17:27:23 --> Loader Class Initialized
INFO - 2017-03-12 17:27:23 --> Database Driver Class Initialized
INFO - 2017-03-12 17:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:27:23 --> Controller Class Initialized
INFO - 2017-03-12 17:27:23 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:27:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:27:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:27:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:27:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:27:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:27:23 --> Final output sent to browser
DEBUG - 2017-03-12 17:27:23 --> Total execution time: 0.0133
INFO - 2017-03-12 17:27:36 --> Config Class Initialized
INFO - 2017-03-12 17:27:36 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:27:36 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:27:36 --> Utf8 Class Initialized
INFO - 2017-03-12 17:27:36 --> URI Class Initialized
INFO - 2017-03-12 17:27:36 --> Router Class Initialized
INFO - 2017-03-12 17:27:36 --> Output Class Initialized
INFO - 2017-03-12 17:27:36 --> Security Class Initialized
DEBUG - 2017-03-12 17:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:27:36 --> Input Class Initialized
INFO - 2017-03-12 17:27:36 --> Language Class Initialized
INFO - 2017-03-12 17:27:36 --> Loader Class Initialized
INFO - 2017-03-12 17:27:36 --> Database Driver Class Initialized
INFO - 2017-03-12 17:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:27:36 --> Controller Class Initialized
INFO - 2017-03-12 17:27:36 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:27:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:27:36 --> Final output sent to browser
DEBUG - 2017-03-12 17:27:36 --> Total execution time: 0.0144
INFO - 2017-03-12 17:27:37 --> Config Class Initialized
INFO - 2017-03-12 17:27:37 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:27:37 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:27:37 --> Utf8 Class Initialized
INFO - 2017-03-12 17:27:37 --> URI Class Initialized
INFO - 2017-03-12 17:27:37 --> Router Class Initialized
INFO - 2017-03-12 17:27:37 --> Output Class Initialized
INFO - 2017-03-12 17:27:37 --> Security Class Initialized
DEBUG - 2017-03-12 17:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:27:37 --> Input Class Initialized
INFO - 2017-03-12 17:27:37 --> Language Class Initialized
INFO - 2017-03-12 17:27:37 --> Loader Class Initialized
INFO - 2017-03-12 17:27:37 --> Database Driver Class Initialized
INFO - 2017-03-12 17:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:27:37 --> Controller Class Initialized
INFO - 2017-03-12 17:27:37 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:27:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:27:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:27:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:27:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:27:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:27:37 --> Final output sent to browser
DEBUG - 2017-03-12 17:27:37 --> Total execution time: 0.0140
INFO - 2017-03-12 17:27:47 --> Config Class Initialized
INFO - 2017-03-12 17:27:47 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:27:47 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:27:47 --> Utf8 Class Initialized
INFO - 2017-03-12 17:27:47 --> URI Class Initialized
INFO - 2017-03-12 17:27:47 --> Router Class Initialized
INFO - 2017-03-12 17:27:47 --> Output Class Initialized
INFO - 2017-03-12 17:27:47 --> Security Class Initialized
DEBUG - 2017-03-12 17:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:27:47 --> Input Class Initialized
INFO - 2017-03-12 17:27:47 --> Language Class Initialized
INFO - 2017-03-12 17:27:47 --> Loader Class Initialized
INFO - 2017-03-12 17:27:47 --> Database Driver Class Initialized
INFO - 2017-03-12 17:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:27:47 --> Controller Class Initialized
INFO - 2017-03-12 17:27:47 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:27:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:27:48 --> Config Class Initialized
INFO - 2017-03-12 17:27:48 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:27:48 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:27:48 --> Utf8 Class Initialized
INFO - 2017-03-12 17:27:48 --> URI Class Initialized
INFO - 2017-03-12 17:27:48 --> Router Class Initialized
INFO - 2017-03-12 17:27:48 --> Output Class Initialized
INFO - 2017-03-12 17:27:48 --> Security Class Initialized
DEBUG - 2017-03-12 17:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:27:48 --> Input Class Initialized
INFO - 2017-03-12 17:27:48 --> Language Class Initialized
INFO - 2017-03-12 17:27:48 --> Loader Class Initialized
INFO - 2017-03-12 17:27:48 --> Database Driver Class Initialized
INFO - 2017-03-12 17:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:27:48 --> Controller Class Initialized
INFO - 2017-03-12 17:27:48 --> Helper loaded: date_helper
DEBUG - 2017-03-12 17:27:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:27:48 --> Helper loaded: url_helper
INFO - 2017-03-12 17:27:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:27:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 17:27:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 17:27:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 17:27:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:27:48 --> Final output sent to browser
DEBUG - 2017-03-12 17:27:48 --> Total execution time: 0.1024
INFO - 2017-03-12 17:27:49 --> Config Class Initialized
INFO - 2017-03-12 17:27:49 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:27:49 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:27:49 --> Utf8 Class Initialized
INFO - 2017-03-12 17:27:49 --> URI Class Initialized
INFO - 2017-03-12 17:27:49 --> Router Class Initialized
INFO - 2017-03-12 17:27:49 --> Output Class Initialized
INFO - 2017-03-12 17:27:49 --> Security Class Initialized
DEBUG - 2017-03-12 17:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:27:49 --> Input Class Initialized
INFO - 2017-03-12 17:27:49 --> Language Class Initialized
INFO - 2017-03-12 17:27:49 --> Loader Class Initialized
INFO - 2017-03-12 17:27:49 --> Database Driver Class Initialized
INFO - 2017-03-12 17:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:27:49 --> Controller Class Initialized
INFO - 2017-03-12 17:27:49 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:27:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:27:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:27:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:27:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:27:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:27:49 --> Final output sent to browser
DEBUG - 2017-03-12 17:27:49 --> Total execution time: 0.0153
INFO - 2017-03-12 17:27:59 --> Config Class Initialized
INFO - 2017-03-12 17:27:59 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:27:59 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:27:59 --> Utf8 Class Initialized
INFO - 2017-03-12 17:27:59 --> URI Class Initialized
INFO - 2017-03-12 17:27:59 --> Router Class Initialized
INFO - 2017-03-12 17:27:59 --> Output Class Initialized
INFO - 2017-03-12 17:27:59 --> Security Class Initialized
DEBUG - 2017-03-12 17:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:27:59 --> Input Class Initialized
INFO - 2017-03-12 17:27:59 --> Language Class Initialized
INFO - 2017-03-12 17:27:59 --> Loader Class Initialized
INFO - 2017-03-12 17:27:59 --> Database Driver Class Initialized
INFO - 2017-03-12 17:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:27:59 --> Controller Class Initialized
INFO - 2017-03-12 17:27:59 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:27:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:27:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:27:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:27:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:27:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:27:59 --> Final output sent to browser
DEBUG - 2017-03-12 17:27:59 --> Total execution time: 0.0136
INFO - 2017-03-12 17:27:59 --> Config Class Initialized
INFO - 2017-03-12 17:27:59 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:27:59 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:27:59 --> Utf8 Class Initialized
INFO - 2017-03-12 17:27:59 --> URI Class Initialized
INFO - 2017-03-12 17:27:59 --> Router Class Initialized
INFO - 2017-03-12 17:27:59 --> Output Class Initialized
INFO - 2017-03-12 17:27:59 --> Security Class Initialized
DEBUG - 2017-03-12 17:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:27:59 --> Input Class Initialized
INFO - 2017-03-12 17:27:59 --> Language Class Initialized
INFO - 2017-03-12 17:27:59 --> Loader Class Initialized
INFO - 2017-03-12 17:27:59 --> Database Driver Class Initialized
INFO - 2017-03-12 17:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:27:59 --> Controller Class Initialized
INFO - 2017-03-12 17:27:59 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:27:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:27:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:27:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:27:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:27:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:27:59 --> Final output sent to browser
DEBUG - 2017-03-12 17:27:59 --> Total execution time: 0.0144
INFO - 2017-03-12 17:28:36 --> Config Class Initialized
INFO - 2017-03-12 17:28:36 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:28:36 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:28:36 --> Utf8 Class Initialized
INFO - 2017-03-12 17:28:36 --> URI Class Initialized
INFO - 2017-03-12 17:28:37 --> Router Class Initialized
INFO - 2017-03-12 17:28:37 --> Output Class Initialized
INFO - 2017-03-12 17:28:37 --> Security Class Initialized
DEBUG - 2017-03-12 17:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:28:37 --> Input Class Initialized
INFO - 2017-03-12 17:28:37 --> Language Class Initialized
INFO - 2017-03-12 17:28:37 --> Loader Class Initialized
INFO - 2017-03-12 17:28:37 --> Database Driver Class Initialized
INFO - 2017-03-12 17:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:28:37 --> Controller Class Initialized
INFO - 2017-03-12 17:28:37 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:28:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:28:39 --> Config Class Initialized
INFO - 2017-03-12 17:28:39 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:28:39 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:28:39 --> Utf8 Class Initialized
INFO - 2017-03-12 17:28:39 --> URI Class Initialized
INFO - 2017-03-12 17:28:39 --> Router Class Initialized
INFO - 2017-03-12 17:28:39 --> Output Class Initialized
INFO - 2017-03-12 17:28:39 --> Security Class Initialized
DEBUG - 2017-03-12 17:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:28:39 --> Input Class Initialized
INFO - 2017-03-12 17:28:39 --> Language Class Initialized
INFO - 2017-03-12 17:28:39 --> Loader Class Initialized
INFO - 2017-03-12 17:28:39 --> Database Driver Class Initialized
INFO - 2017-03-12 17:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:28:39 --> Controller Class Initialized
INFO - 2017-03-12 17:28:39 --> Helper loaded: date_helper
DEBUG - 2017-03-12 17:28:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:28:40 --> Helper loaded: url_helper
INFO - 2017-03-12 17:28:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:28:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 17:28:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 17:28:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 17:28:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:28:40 --> Final output sent to browser
DEBUG - 2017-03-12 17:28:40 --> Total execution time: 0.1176
INFO - 2017-03-12 17:28:41 --> Config Class Initialized
INFO - 2017-03-12 17:28:41 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:28:41 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:28:41 --> Utf8 Class Initialized
INFO - 2017-03-12 17:28:41 --> URI Class Initialized
INFO - 2017-03-12 17:28:41 --> Router Class Initialized
INFO - 2017-03-12 17:28:41 --> Output Class Initialized
INFO - 2017-03-12 17:28:41 --> Security Class Initialized
DEBUG - 2017-03-12 17:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:28:41 --> Input Class Initialized
INFO - 2017-03-12 17:28:41 --> Language Class Initialized
INFO - 2017-03-12 17:28:41 --> Loader Class Initialized
INFO - 2017-03-12 17:28:41 --> Database Driver Class Initialized
INFO - 2017-03-12 17:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:28:41 --> Controller Class Initialized
INFO - 2017-03-12 17:28:41 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:28:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:28:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:28:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:28:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:28:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:28:41 --> Final output sent to browser
DEBUG - 2017-03-12 17:28:41 --> Total execution time: 0.0503
INFO - 2017-03-12 17:28:52 --> Config Class Initialized
INFO - 2017-03-12 17:28:52 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:28:52 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:28:52 --> Utf8 Class Initialized
INFO - 2017-03-12 17:28:52 --> URI Class Initialized
INFO - 2017-03-12 17:28:52 --> Router Class Initialized
INFO - 2017-03-12 17:28:52 --> Output Class Initialized
INFO - 2017-03-12 17:28:52 --> Security Class Initialized
DEBUG - 2017-03-12 17:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:28:52 --> Input Class Initialized
INFO - 2017-03-12 17:28:52 --> Language Class Initialized
INFO - 2017-03-12 17:28:52 --> Loader Class Initialized
INFO - 2017-03-12 17:28:52 --> Database Driver Class Initialized
INFO - 2017-03-12 17:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:28:52 --> Controller Class Initialized
INFO - 2017-03-12 17:28:52 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:28:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:28:53 --> Config Class Initialized
INFO - 2017-03-12 17:28:53 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:28:53 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:28:53 --> Utf8 Class Initialized
INFO - 2017-03-12 17:28:53 --> URI Class Initialized
INFO - 2017-03-12 17:28:53 --> Router Class Initialized
INFO - 2017-03-12 17:28:53 --> Output Class Initialized
INFO - 2017-03-12 17:28:53 --> Security Class Initialized
DEBUG - 2017-03-12 17:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:28:53 --> Input Class Initialized
INFO - 2017-03-12 17:28:53 --> Language Class Initialized
INFO - 2017-03-12 17:28:53 --> Loader Class Initialized
INFO - 2017-03-12 17:28:53 --> Database Driver Class Initialized
INFO - 2017-03-12 17:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:28:53 --> Controller Class Initialized
INFO - 2017-03-12 17:28:53 --> Helper loaded: date_helper
DEBUG - 2017-03-12 17:28:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:28:53 --> Helper loaded: url_helper
INFO - 2017-03-12 17:28:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:28:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 17:28:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 17:28:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 17:28:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:28:53 --> Final output sent to browser
DEBUG - 2017-03-12 17:28:53 --> Total execution time: 0.0145
INFO - 2017-03-12 17:28:54 --> Config Class Initialized
INFO - 2017-03-12 17:28:54 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:28:54 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:28:54 --> Utf8 Class Initialized
INFO - 2017-03-12 17:28:54 --> URI Class Initialized
INFO - 2017-03-12 17:28:54 --> Router Class Initialized
INFO - 2017-03-12 17:28:54 --> Output Class Initialized
INFO - 2017-03-12 17:28:54 --> Security Class Initialized
DEBUG - 2017-03-12 17:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:28:54 --> Input Class Initialized
INFO - 2017-03-12 17:28:54 --> Language Class Initialized
INFO - 2017-03-12 17:28:54 --> Loader Class Initialized
INFO - 2017-03-12 17:28:54 --> Database Driver Class Initialized
INFO - 2017-03-12 17:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:28:54 --> Controller Class Initialized
INFO - 2017-03-12 17:28:54 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:28:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:28:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:28:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:28:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:28:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:28:54 --> Final output sent to browser
DEBUG - 2017-03-12 17:28:54 --> Total execution time: 0.0136
INFO - 2017-03-12 17:29:47 --> Config Class Initialized
INFO - 2017-03-12 17:29:47 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:29:47 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:29:47 --> Utf8 Class Initialized
INFO - 2017-03-12 17:29:47 --> URI Class Initialized
DEBUG - 2017-03-12 17:29:47 --> No URI present. Default controller set.
INFO - 2017-03-12 17:29:47 --> Router Class Initialized
INFO - 2017-03-12 17:29:48 --> Output Class Initialized
INFO - 2017-03-12 17:29:48 --> Security Class Initialized
DEBUG - 2017-03-12 17:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:29:48 --> Input Class Initialized
INFO - 2017-03-12 17:29:48 --> Language Class Initialized
INFO - 2017-03-12 17:29:48 --> Loader Class Initialized
INFO - 2017-03-12 17:29:48 --> Database Driver Class Initialized
INFO - 2017-03-12 17:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:29:48 --> Controller Class Initialized
INFO - 2017-03-12 17:29:48 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:29:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:29:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:29:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:29:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:29:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:29:49 --> Final output sent to browser
DEBUG - 2017-03-12 17:29:49 --> Total execution time: 1.4390
INFO - 2017-03-12 17:29:50 --> Config Class Initialized
INFO - 2017-03-12 17:29:50 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:29:50 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:29:50 --> Utf8 Class Initialized
INFO - 2017-03-12 17:29:50 --> URI Class Initialized
INFO - 2017-03-12 17:29:50 --> Router Class Initialized
INFO - 2017-03-12 17:29:50 --> Output Class Initialized
INFO - 2017-03-12 17:29:50 --> Security Class Initialized
DEBUG - 2017-03-12 17:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:29:50 --> Input Class Initialized
INFO - 2017-03-12 17:29:50 --> Language Class Initialized
INFO - 2017-03-12 17:29:50 --> Loader Class Initialized
INFO - 2017-03-12 17:29:50 --> Database Driver Class Initialized
INFO - 2017-03-12 17:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:29:50 --> Controller Class Initialized
INFO - 2017-03-12 17:29:50 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:29:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:29:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:29:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:29:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:29:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:29:50 --> Final output sent to browser
DEBUG - 2017-03-12 17:29:50 --> Total execution time: 0.0137
INFO - 2017-03-12 17:29:56 --> Config Class Initialized
INFO - 2017-03-12 17:29:56 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:29:56 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:29:56 --> Utf8 Class Initialized
INFO - 2017-03-12 17:29:56 --> URI Class Initialized
INFO - 2017-03-12 17:29:56 --> Router Class Initialized
INFO - 2017-03-12 17:29:56 --> Output Class Initialized
INFO - 2017-03-12 17:29:56 --> Security Class Initialized
DEBUG - 2017-03-12 17:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:29:56 --> Input Class Initialized
INFO - 2017-03-12 17:29:56 --> Language Class Initialized
INFO - 2017-03-12 17:29:56 --> Loader Class Initialized
INFO - 2017-03-12 17:29:56 --> Database Driver Class Initialized
INFO - 2017-03-12 17:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:29:56 --> Controller Class Initialized
INFO - 2017-03-12 17:29:56 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:29:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:29:57 --> Config Class Initialized
INFO - 2017-03-12 17:29:57 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:29:57 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:29:57 --> Utf8 Class Initialized
INFO - 2017-03-12 17:29:57 --> URI Class Initialized
INFO - 2017-03-12 17:29:57 --> Router Class Initialized
INFO - 2017-03-12 17:29:57 --> Output Class Initialized
INFO - 2017-03-12 17:29:57 --> Security Class Initialized
DEBUG - 2017-03-12 17:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:29:57 --> Input Class Initialized
INFO - 2017-03-12 17:29:57 --> Language Class Initialized
INFO - 2017-03-12 17:29:57 --> Loader Class Initialized
INFO - 2017-03-12 17:29:57 --> Database Driver Class Initialized
INFO - 2017-03-12 17:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:29:57 --> Controller Class Initialized
INFO - 2017-03-12 17:29:57 --> Helper loaded: date_helper
DEBUG - 2017-03-12 17:29:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:29:57 --> Helper loaded: url_helper
INFO - 2017-03-12 17:29:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:29:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 17:29:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 17:29:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 17:29:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:29:57 --> Final output sent to browser
DEBUG - 2017-03-12 17:29:57 --> Total execution time: 0.1034
INFO - 2017-03-12 17:29:57 --> Config Class Initialized
INFO - 2017-03-12 17:29:57 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:29:57 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:29:57 --> Utf8 Class Initialized
INFO - 2017-03-12 17:29:57 --> URI Class Initialized
INFO - 2017-03-12 17:29:57 --> Router Class Initialized
INFO - 2017-03-12 17:29:57 --> Output Class Initialized
INFO - 2017-03-12 17:29:57 --> Security Class Initialized
DEBUG - 2017-03-12 17:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:29:57 --> Input Class Initialized
INFO - 2017-03-12 17:29:57 --> Language Class Initialized
INFO - 2017-03-12 17:29:57 --> Loader Class Initialized
INFO - 2017-03-12 17:29:57 --> Database Driver Class Initialized
INFO - 2017-03-12 17:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:29:57 --> Controller Class Initialized
INFO - 2017-03-12 17:29:57 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:29:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:29:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:29:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:29:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:29:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:29:57 --> Final output sent to browser
DEBUG - 2017-03-12 17:29:57 --> Total execution time: 0.0135
INFO - 2017-03-12 17:30:08 --> Config Class Initialized
INFO - 2017-03-12 17:30:08 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:30:08 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:30:08 --> Utf8 Class Initialized
INFO - 2017-03-12 17:30:08 --> URI Class Initialized
DEBUG - 2017-03-12 17:30:08 --> No URI present. Default controller set.
INFO - 2017-03-12 17:30:08 --> Router Class Initialized
INFO - 2017-03-12 17:30:08 --> Output Class Initialized
INFO - 2017-03-12 17:30:08 --> Security Class Initialized
DEBUG - 2017-03-12 17:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:30:08 --> Input Class Initialized
INFO - 2017-03-12 17:30:08 --> Language Class Initialized
INFO - 2017-03-12 17:30:08 --> Loader Class Initialized
INFO - 2017-03-12 17:30:08 --> Database Driver Class Initialized
INFO - 2017-03-12 17:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:30:08 --> Controller Class Initialized
INFO - 2017-03-12 17:30:08 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:30:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:30:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:30:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:30:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:30:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:30:08 --> Final output sent to browser
DEBUG - 2017-03-12 17:30:08 --> Total execution time: 0.0142
INFO - 2017-03-12 17:30:09 --> Config Class Initialized
INFO - 2017-03-12 17:30:09 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:30:09 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:30:09 --> Utf8 Class Initialized
INFO - 2017-03-12 17:30:09 --> URI Class Initialized
INFO - 2017-03-12 17:30:09 --> Router Class Initialized
INFO - 2017-03-12 17:30:09 --> Output Class Initialized
INFO - 2017-03-12 17:30:09 --> Security Class Initialized
DEBUG - 2017-03-12 17:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:30:09 --> Input Class Initialized
INFO - 2017-03-12 17:30:09 --> Language Class Initialized
INFO - 2017-03-12 17:30:09 --> Loader Class Initialized
INFO - 2017-03-12 17:30:09 --> Database Driver Class Initialized
INFO - 2017-03-12 17:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:30:09 --> Controller Class Initialized
INFO - 2017-03-12 17:30:09 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:30:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:30:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:30:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:30:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:30:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:30:09 --> Final output sent to browser
DEBUG - 2017-03-12 17:30:09 --> Total execution time: 0.0140
INFO - 2017-03-12 17:30:25 --> Config Class Initialized
INFO - 2017-03-12 17:30:25 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:30:25 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:30:25 --> Utf8 Class Initialized
INFO - 2017-03-12 17:30:25 --> URI Class Initialized
INFO - 2017-03-12 17:30:25 --> Router Class Initialized
INFO - 2017-03-12 17:30:25 --> Output Class Initialized
INFO - 2017-03-12 17:30:25 --> Security Class Initialized
DEBUG - 2017-03-12 17:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:30:25 --> Input Class Initialized
INFO - 2017-03-12 17:30:25 --> Language Class Initialized
INFO - 2017-03-12 17:30:25 --> Loader Class Initialized
INFO - 2017-03-12 17:30:25 --> Database Driver Class Initialized
INFO - 2017-03-12 17:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:30:25 --> Controller Class Initialized
INFO - 2017-03-12 17:30:25 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:30:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:30:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 17:30:26 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 17:30:26 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 17:30:26 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 17:30:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:30:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:30:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:30:26 --> Final output sent to browser
DEBUG - 2017-03-12 17:30:26 --> Total execution time: 0.5370
INFO - 2017-03-12 17:30:29 --> Config Class Initialized
INFO - 2017-03-12 17:30:29 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:30:29 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:30:29 --> Utf8 Class Initialized
INFO - 2017-03-12 17:30:29 --> URI Class Initialized
INFO - 2017-03-12 17:30:29 --> Router Class Initialized
INFO - 2017-03-12 17:30:29 --> Output Class Initialized
INFO - 2017-03-12 17:30:29 --> Security Class Initialized
DEBUG - 2017-03-12 17:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:30:29 --> Input Class Initialized
INFO - 2017-03-12 17:30:29 --> Language Class Initialized
INFO - 2017-03-12 17:30:29 --> Loader Class Initialized
INFO - 2017-03-12 17:30:29 --> Database Driver Class Initialized
INFO - 2017-03-12 17:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:30:29 --> Controller Class Initialized
INFO - 2017-03-12 17:30:29 --> Helper loaded: date_helper
DEBUG - 2017-03-12 17:30:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:30:29 --> Helper loaded: url_helper
INFO - 2017-03-12 17:30:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:30:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 17:30:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 17:30:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 17:30:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:30:29 --> Final output sent to browser
DEBUG - 2017-03-12 17:30:29 --> Total execution time: 0.0139
INFO - 2017-03-12 17:30:32 --> Config Class Initialized
INFO - 2017-03-12 17:30:32 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:30:32 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:30:32 --> Utf8 Class Initialized
INFO - 2017-03-12 17:30:32 --> URI Class Initialized
INFO - 2017-03-12 17:30:32 --> Router Class Initialized
INFO - 2017-03-12 17:30:32 --> Output Class Initialized
INFO - 2017-03-12 17:30:32 --> Security Class Initialized
DEBUG - 2017-03-12 17:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:30:32 --> Input Class Initialized
INFO - 2017-03-12 17:30:32 --> Language Class Initialized
INFO - 2017-03-12 17:30:32 --> Loader Class Initialized
INFO - 2017-03-12 17:30:32 --> Database Driver Class Initialized
INFO - 2017-03-12 17:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:30:32 --> Controller Class Initialized
INFO - 2017-03-12 17:30:32 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:30:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:30:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:30:32 --> Final output sent to browser
DEBUG - 2017-03-12 17:30:32 --> Total execution time: 0.0135
INFO - 2017-03-12 17:30:37 --> Config Class Initialized
INFO - 2017-03-12 17:30:37 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:30:37 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:30:37 --> Utf8 Class Initialized
INFO - 2017-03-12 17:30:37 --> URI Class Initialized
INFO - 2017-03-12 17:30:37 --> Router Class Initialized
INFO - 2017-03-12 17:30:37 --> Output Class Initialized
INFO - 2017-03-12 17:30:37 --> Security Class Initialized
DEBUG - 2017-03-12 17:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:30:37 --> Input Class Initialized
INFO - 2017-03-12 17:30:37 --> Language Class Initialized
INFO - 2017-03-12 17:30:37 --> Loader Class Initialized
INFO - 2017-03-12 17:30:37 --> Database Driver Class Initialized
INFO - 2017-03-12 17:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:30:37 --> Controller Class Initialized
INFO - 2017-03-12 17:30:37 --> Helper loaded: date_helper
DEBUG - 2017-03-12 17:30:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:30:37 --> Helper loaded: url_helper
INFO - 2017-03-12 17:30:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:30:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 17:30:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 17:30:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 17:30:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:30:37 --> Final output sent to browser
DEBUG - 2017-03-12 17:30:37 --> Total execution time: 0.0144
INFO - 2017-03-12 17:30:39 --> Config Class Initialized
INFO - 2017-03-12 17:30:39 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:30:39 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:30:39 --> Utf8 Class Initialized
INFO - 2017-03-12 17:30:39 --> URI Class Initialized
INFO - 2017-03-12 17:30:39 --> Router Class Initialized
INFO - 2017-03-12 17:30:39 --> Output Class Initialized
INFO - 2017-03-12 17:30:39 --> Security Class Initialized
DEBUG - 2017-03-12 17:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:30:40 --> Input Class Initialized
INFO - 2017-03-12 17:30:40 --> Language Class Initialized
INFO - 2017-03-12 17:30:40 --> Loader Class Initialized
INFO - 2017-03-12 17:30:40 --> Database Driver Class Initialized
INFO - 2017-03-12 17:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:30:40 --> Controller Class Initialized
INFO - 2017-03-12 17:30:40 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:30:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:30:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:30:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:30:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:30:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:30:40 --> Final output sent to browser
DEBUG - 2017-03-12 17:30:40 --> Total execution time: 1.2244
INFO - 2017-03-12 17:30:43 --> Config Class Initialized
INFO - 2017-03-12 17:30:43 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:30:43 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:30:43 --> Utf8 Class Initialized
INFO - 2017-03-12 17:30:43 --> URI Class Initialized
DEBUG - 2017-03-12 17:30:43 --> No URI present. Default controller set.
INFO - 2017-03-12 17:30:43 --> Router Class Initialized
INFO - 2017-03-12 17:30:43 --> Output Class Initialized
INFO - 2017-03-12 17:30:43 --> Security Class Initialized
DEBUG - 2017-03-12 17:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:30:43 --> Input Class Initialized
INFO - 2017-03-12 17:30:43 --> Language Class Initialized
INFO - 2017-03-12 17:30:43 --> Loader Class Initialized
INFO - 2017-03-12 17:30:43 --> Database Driver Class Initialized
INFO - 2017-03-12 17:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:30:43 --> Controller Class Initialized
INFO - 2017-03-12 17:30:43 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:30:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:30:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:30:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:30:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:30:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:30:43 --> Final output sent to browser
DEBUG - 2017-03-12 17:30:43 --> Total execution time: 0.0239
INFO - 2017-03-12 17:30:48 --> Config Class Initialized
INFO - 2017-03-12 17:30:48 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:30:48 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:30:48 --> Utf8 Class Initialized
INFO - 2017-03-12 17:30:48 --> URI Class Initialized
INFO - 2017-03-12 17:30:48 --> Router Class Initialized
INFO - 2017-03-12 17:30:48 --> Output Class Initialized
INFO - 2017-03-12 17:30:48 --> Security Class Initialized
DEBUG - 2017-03-12 17:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:30:48 --> Input Class Initialized
INFO - 2017-03-12 17:30:48 --> Language Class Initialized
INFO - 2017-03-12 17:30:48 --> Loader Class Initialized
INFO - 2017-03-12 17:30:48 --> Database Driver Class Initialized
INFO - 2017-03-12 17:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:30:48 --> Controller Class Initialized
INFO - 2017-03-12 17:30:48 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:30:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:30:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:30:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:30:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:30:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:30:48 --> Final output sent to browser
DEBUG - 2017-03-12 17:30:48 --> Total execution time: 0.0139
INFO - 2017-03-12 17:30:49 --> Config Class Initialized
INFO - 2017-03-12 17:30:49 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:30:49 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:30:49 --> Utf8 Class Initialized
INFO - 2017-03-12 17:30:49 --> URI Class Initialized
INFO - 2017-03-12 17:30:49 --> Router Class Initialized
INFO - 2017-03-12 17:30:49 --> Output Class Initialized
INFO - 2017-03-12 17:30:49 --> Security Class Initialized
DEBUG - 2017-03-12 17:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:30:49 --> Input Class Initialized
INFO - 2017-03-12 17:30:49 --> Language Class Initialized
INFO - 2017-03-12 17:30:49 --> Loader Class Initialized
INFO - 2017-03-12 17:30:49 --> Database Driver Class Initialized
INFO - 2017-03-12 17:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:30:50 --> Controller Class Initialized
INFO - 2017-03-12 17:30:50 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:30:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-12 17:30:51 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-12 17:30:51 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Scarlett Osborn')
INFO - 2017-03-12 17:30:51 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-12 17:30:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-12 17:30:52 --> Config Class Initialized
INFO - 2017-03-12 17:30:52 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:30:52 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:30:52 --> Utf8 Class Initialized
INFO - 2017-03-12 17:30:52 --> URI Class Initialized
INFO - 2017-03-12 17:30:52 --> Router Class Initialized
INFO - 2017-03-12 17:30:52 --> Output Class Initialized
INFO - 2017-03-12 17:30:52 --> Security Class Initialized
DEBUG - 2017-03-12 17:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:30:52 --> Input Class Initialized
INFO - 2017-03-12 17:30:52 --> Language Class Initialized
INFO - 2017-03-12 17:30:52 --> Loader Class Initialized
INFO - 2017-03-12 17:30:52 --> Database Driver Class Initialized
INFO - 2017-03-12 17:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:30:52 --> Controller Class Initialized
INFO - 2017-03-12 17:30:52 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:30:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:30:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:30:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:30:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:30:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:30:52 --> Final output sent to browser
DEBUG - 2017-03-12 17:30:52 --> Total execution time: 0.0133
INFO - 2017-03-12 17:30:59 --> Config Class Initialized
INFO - 2017-03-12 17:30:59 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:30:59 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:30:59 --> Utf8 Class Initialized
INFO - 2017-03-12 17:30:59 --> URI Class Initialized
INFO - 2017-03-12 17:30:59 --> Router Class Initialized
INFO - 2017-03-12 17:30:59 --> Output Class Initialized
INFO - 2017-03-12 17:30:59 --> Security Class Initialized
DEBUG - 2017-03-12 17:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:30:59 --> Input Class Initialized
INFO - 2017-03-12 17:30:59 --> Language Class Initialized
INFO - 2017-03-12 17:30:59 --> Loader Class Initialized
INFO - 2017-03-12 17:30:59 --> Database Driver Class Initialized
INFO - 2017-03-12 17:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:30:59 --> Controller Class Initialized
INFO - 2017-03-12 17:30:59 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:30:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:31:00 --> Config Class Initialized
INFO - 2017-03-12 17:31:00 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:31:00 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:31:00 --> Utf8 Class Initialized
INFO - 2017-03-12 17:31:00 --> URI Class Initialized
INFO - 2017-03-12 17:31:00 --> Router Class Initialized
INFO - 2017-03-12 17:31:00 --> Output Class Initialized
INFO - 2017-03-12 17:31:00 --> Security Class Initialized
DEBUG - 2017-03-12 17:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:31:00 --> Input Class Initialized
INFO - 2017-03-12 17:31:00 --> Language Class Initialized
INFO - 2017-03-12 17:31:00 --> Loader Class Initialized
INFO - 2017-03-12 17:31:00 --> Database Driver Class Initialized
INFO - 2017-03-12 17:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:31:00 --> Controller Class Initialized
INFO - 2017-03-12 17:31:00 --> Helper loaded: date_helper
DEBUG - 2017-03-12 17:31:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:31:00 --> Helper loaded: url_helper
INFO - 2017-03-12 17:31:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:31:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 17:31:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 17:31:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 17:31:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:31:00 --> Final output sent to browser
DEBUG - 2017-03-12 17:31:00 --> Total execution time: 0.0434
INFO - 2017-03-12 17:31:01 --> Config Class Initialized
INFO - 2017-03-12 17:31:01 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:31:01 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:31:01 --> Utf8 Class Initialized
INFO - 2017-03-12 17:31:01 --> URI Class Initialized
INFO - 2017-03-12 17:31:01 --> Router Class Initialized
INFO - 2017-03-12 17:31:01 --> Output Class Initialized
INFO - 2017-03-12 17:31:01 --> Security Class Initialized
DEBUG - 2017-03-12 17:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:31:01 --> Input Class Initialized
INFO - 2017-03-12 17:31:01 --> Language Class Initialized
INFO - 2017-03-12 17:31:01 --> Loader Class Initialized
INFO - 2017-03-12 17:31:01 --> Database Driver Class Initialized
INFO - 2017-03-12 17:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:31:01 --> Controller Class Initialized
INFO - 2017-03-12 17:31:01 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:31:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:31:01 --> Final output sent to browser
DEBUG - 2017-03-12 17:31:01 --> Total execution time: 0.0144
INFO - 2017-03-12 17:33:29 --> Config Class Initialized
INFO - 2017-03-12 17:33:29 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:33:29 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:33:29 --> Utf8 Class Initialized
INFO - 2017-03-12 17:33:29 --> URI Class Initialized
DEBUG - 2017-03-12 17:33:29 --> No URI present. Default controller set.
INFO - 2017-03-12 17:33:29 --> Router Class Initialized
INFO - 2017-03-12 17:33:29 --> Output Class Initialized
INFO - 2017-03-12 17:33:29 --> Security Class Initialized
DEBUG - 2017-03-12 17:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:33:29 --> Input Class Initialized
INFO - 2017-03-12 17:33:29 --> Language Class Initialized
INFO - 2017-03-12 17:33:29 --> Loader Class Initialized
INFO - 2017-03-12 17:33:29 --> Database Driver Class Initialized
INFO - 2017-03-12 17:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:33:29 --> Controller Class Initialized
INFO - 2017-03-12 17:33:29 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:33:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:33:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:33:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:33:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:33:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:33:29 --> Final output sent to browser
DEBUG - 2017-03-12 17:33:29 --> Total execution time: 0.2463
INFO - 2017-03-12 17:33:31 --> Config Class Initialized
INFO - 2017-03-12 17:33:31 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:33:31 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:33:31 --> Utf8 Class Initialized
INFO - 2017-03-12 17:33:31 --> URI Class Initialized
INFO - 2017-03-12 17:33:31 --> Router Class Initialized
INFO - 2017-03-12 17:33:31 --> Output Class Initialized
INFO - 2017-03-12 17:33:31 --> Security Class Initialized
DEBUG - 2017-03-12 17:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:33:31 --> Input Class Initialized
INFO - 2017-03-12 17:33:31 --> Language Class Initialized
INFO - 2017-03-12 17:33:31 --> Loader Class Initialized
INFO - 2017-03-12 17:33:31 --> Database Driver Class Initialized
INFO - 2017-03-12 17:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:33:31 --> Controller Class Initialized
INFO - 2017-03-12 17:33:31 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:33:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:33:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:33:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:33:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:33:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:33:31 --> Final output sent to browser
DEBUG - 2017-03-12 17:33:31 --> Total execution time: 0.0135
INFO - 2017-03-12 17:33:55 --> Config Class Initialized
INFO - 2017-03-12 17:33:55 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:33:55 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:33:55 --> Utf8 Class Initialized
INFO - 2017-03-12 17:33:55 --> URI Class Initialized
INFO - 2017-03-12 17:33:55 --> Router Class Initialized
INFO - 2017-03-12 17:33:55 --> Output Class Initialized
INFO - 2017-03-12 17:33:55 --> Security Class Initialized
DEBUG - 2017-03-12 17:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:33:55 --> Input Class Initialized
INFO - 2017-03-12 17:33:55 --> Language Class Initialized
INFO - 2017-03-12 17:33:55 --> Loader Class Initialized
INFO - 2017-03-12 17:33:55 --> Database Driver Class Initialized
INFO - 2017-03-12 17:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:33:55 --> Controller Class Initialized
INFO - 2017-03-12 17:33:55 --> Helper loaded: date_helper
DEBUG - 2017-03-12 17:33:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:33:55 --> Helper loaded: url_helper
INFO - 2017-03-12 17:33:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:33:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 17:33:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 17:33:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 17:33:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:33:55 --> Final output sent to browser
DEBUG - 2017-03-12 17:33:55 --> Total execution time: 0.0867
INFO - 2017-03-12 17:33:55 --> Config Class Initialized
INFO - 2017-03-12 17:33:55 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:33:55 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:33:55 --> Utf8 Class Initialized
INFO - 2017-03-12 17:33:55 --> URI Class Initialized
INFO - 2017-03-12 17:33:55 --> Router Class Initialized
INFO - 2017-03-12 17:33:55 --> Output Class Initialized
INFO - 2017-03-12 17:33:55 --> Security Class Initialized
DEBUG - 2017-03-12 17:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:33:55 --> Input Class Initialized
INFO - 2017-03-12 17:33:55 --> Language Class Initialized
INFO - 2017-03-12 17:33:55 --> Loader Class Initialized
INFO - 2017-03-12 17:33:55 --> Database Driver Class Initialized
INFO - 2017-03-12 17:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:33:55 --> Controller Class Initialized
INFO - 2017-03-12 17:33:55 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:33:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:33:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:33:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:33:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:33:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:33:55 --> Final output sent to browser
DEBUG - 2017-03-12 17:33:55 --> Total execution time: 0.0137
INFO - 2017-03-12 17:44:50 --> Config Class Initialized
INFO - 2017-03-12 17:44:50 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:44:50 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:44:50 --> Utf8 Class Initialized
INFO - 2017-03-12 17:44:50 --> URI Class Initialized
INFO - 2017-03-12 17:44:50 --> Router Class Initialized
INFO - 2017-03-12 17:44:50 --> Output Class Initialized
INFO - 2017-03-12 17:44:50 --> Security Class Initialized
DEBUG - 2017-03-12 17:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:44:50 --> Input Class Initialized
INFO - 2017-03-12 17:44:50 --> Language Class Initialized
INFO - 2017-03-12 17:44:50 --> Loader Class Initialized
INFO - 2017-03-12 17:44:50 --> Database Driver Class Initialized
INFO - 2017-03-12 17:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:44:50 --> Controller Class Initialized
INFO - 2017-03-12 17:44:50 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:44:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:44:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:44:51 --> Final output sent to browser
DEBUG - 2017-03-12 17:44:51 --> Total execution time: 0.3175
INFO - 2017-03-12 17:44:52 --> Config Class Initialized
INFO - 2017-03-12 17:44:52 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:44:52 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:44:52 --> Utf8 Class Initialized
INFO - 2017-03-12 17:44:52 --> URI Class Initialized
DEBUG - 2017-03-12 17:44:52 --> No URI present. Default controller set.
INFO - 2017-03-12 17:44:52 --> Router Class Initialized
INFO - 2017-03-12 17:44:52 --> Output Class Initialized
INFO - 2017-03-12 17:44:52 --> Security Class Initialized
DEBUG - 2017-03-12 17:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:44:52 --> Input Class Initialized
INFO - 2017-03-12 17:44:52 --> Language Class Initialized
INFO - 2017-03-12 17:44:52 --> Loader Class Initialized
INFO - 2017-03-12 17:44:52 --> Database Driver Class Initialized
INFO - 2017-03-12 17:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:44:52 --> Controller Class Initialized
INFO - 2017-03-12 17:44:52 --> Helper loaded: url_helper
DEBUG - 2017-03-12 17:44:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:44:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:44:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 17:44:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 17:44:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:44:52 --> Final output sent to browser
DEBUG - 2017-03-12 17:44:52 --> Total execution time: 0.2255
INFO - 2017-03-12 17:58:03 --> Config Class Initialized
INFO - 2017-03-12 17:58:03 --> Hooks Class Initialized
DEBUG - 2017-03-12 17:58:04 --> UTF-8 Support Enabled
INFO - 2017-03-12 17:58:04 --> Utf8 Class Initialized
INFO - 2017-03-12 17:58:04 --> URI Class Initialized
INFO - 2017-03-12 17:58:04 --> Router Class Initialized
INFO - 2017-03-12 17:58:04 --> Output Class Initialized
INFO - 2017-03-12 17:58:04 --> Security Class Initialized
DEBUG - 2017-03-12 17:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 17:58:04 --> Input Class Initialized
INFO - 2017-03-12 17:58:04 --> Language Class Initialized
INFO - 2017-03-12 17:58:04 --> Loader Class Initialized
INFO - 2017-03-12 17:58:04 --> Database Driver Class Initialized
INFO - 2017-03-12 17:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 17:58:05 --> Controller Class Initialized
INFO - 2017-03-12 17:58:05 --> Helper loaded: date_helper
DEBUG - 2017-03-12 17:58:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 17:58:05 --> Helper loaded: url_helper
INFO - 2017-03-12 17:58:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 17:58:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 17:58:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 17:58:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 17:58:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 17:58:05 --> Final output sent to browser
DEBUG - 2017-03-12 17:58:05 --> Total execution time: 1.3427
INFO - 2017-03-12 18:12:08 --> Config Class Initialized
INFO - 2017-03-12 18:12:08 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:12:08 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:12:08 --> Utf8 Class Initialized
INFO - 2017-03-12 18:12:08 --> URI Class Initialized
DEBUG - 2017-03-12 18:12:08 --> No URI present. Default controller set.
INFO - 2017-03-12 18:12:08 --> Router Class Initialized
INFO - 2017-03-12 18:12:08 --> Output Class Initialized
INFO - 2017-03-12 18:12:08 --> Security Class Initialized
DEBUG - 2017-03-12 18:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:12:08 --> Input Class Initialized
INFO - 2017-03-12 18:12:08 --> Language Class Initialized
INFO - 2017-03-12 18:12:08 --> Loader Class Initialized
INFO - 2017-03-12 18:12:09 --> Database Driver Class Initialized
INFO - 2017-03-12 18:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:12:09 --> Controller Class Initialized
INFO - 2017-03-12 18:12:09 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:12:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:12:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:12:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:12:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:12:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:12:09 --> Final output sent to browser
DEBUG - 2017-03-12 18:12:09 --> Total execution time: 1.5010
INFO - 2017-03-12 18:12:12 --> Config Class Initialized
INFO - 2017-03-12 18:12:12 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:12:12 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:12:12 --> Utf8 Class Initialized
INFO - 2017-03-12 18:12:12 --> URI Class Initialized
INFO - 2017-03-12 18:12:12 --> Router Class Initialized
INFO - 2017-03-12 18:12:12 --> Output Class Initialized
INFO - 2017-03-12 18:12:12 --> Security Class Initialized
DEBUG - 2017-03-12 18:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:12:12 --> Input Class Initialized
INFO - 2017-03-12 18:12:12 --> Language Class Initialized
INFO - 2017-03-12 18:12:12 --> Loader Class Initialized
INFO - 2017-03-12 18:12:12 --> Database Driver Class Initialized
INFO - 2017-03-12 18:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:12:12 --> Controller Class Initialized
INFO - 2017-03-12 18:12:12 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:12:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:12:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:12:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:12:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:12:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:12:12 --> Final output sent to browser
DEBUG - 2017-03-12 18:12:12 --> Total execution time: 0.1157
INFO - 2017-03-12 18:12:15 --> Config Class Initialized
INFO - 2017-03-12 18:12:15 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:12:15 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:12:15 --> Utf8 Class Initialized
INFO - 2017-03-12 18:12:15 --> URI Class Initialized
INFO - 2017-03-12 18:12:15 --> Router Class Initialized
INFO - 2017-03-12 18:12:15 --> Output Class Initialized
INFO - 2017-03-12 18:12:15 --> Security Class Initialized
DEBUG - 2017-03-12 18:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:12:15 --> Input Class Initialized
INFO - 2017-03-12 18:12:15 --> Language Class Initialized
INFO - 2017-03-12 18:12:15 --> Loader Class Initialized
INFO - 2017-03-12 18:12:15 --> Database Driver Class Initialized
INFO - 2017-03-12 18:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:12:15 --> Controller Class Initialized
INFO - 2017-03-12 18:12:15 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:12:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:12:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 18:12:16 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 18:12:16 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 18:12:16 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 18:12:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:12:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:12:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:12:16 --> Final output sent to browser
DEBUG - 2017-03-12 18:12:16 --> Total execution time: 0.5440
INFO - 2017-03-12 18:12:16 --> Config Class Initialized
INFO - 2017-03-12 18:12:16 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:12:16 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:12:16 --> Utf8 Class Initialized
INFO - 2017-03-12 18:12:16 --> URI Class Initialized
INFO - 2017-03-12 18:12:16 --> Router Class Initialized
INFO - 2017-03-12 18:12:16 --> Output Class Initialized
INFO - 2017-03-12 18:12:16 --> Security Class Initialized
DEBUG - 2017-03-12 18:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:12:16 --> Input Class Initialized
INFO - 2017-03-12 18:12:16 --> Language Class Initialized
INFO - 2017-03-12 18:12:16 --> Loader Class Initialized
INFO - 2017-03-12 18:12:16 --> Database Driver Class Initialized
INFO - 2017-03-12 18:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:12:16 --> Controller Class Initialized
INFO - 2017-03-12 18:12:16 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:12:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:12:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:12:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:12:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:12:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:12:16 --> Final output sent to browser
DEBUG - 2017-03-12 18:12:16 --> Total execution time: 0.0161
INFO - 2017-03-12 18:12:28 --> Config Class Initialized
INFO - 2017-03-12 18:12:28 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:12:28 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:12:28 --> Utf8 Class Initialized
INFO - 2017-03-12 18:12:28 --> URI Class Initialized
DEBUG - 2017-03-12 18:12:28 --> No URI present. Default controller set.
INFO - 2017-03-12 18:12:28 --> Router Class Initialized
INFO - 2017-03-12 18:12:28 --> Output Class Initialized
INFO - 2017-03-12 18:12:28 --> Security Class Initialized
DEBUG - 2017-03-12 18:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:12:28 --> Input Class Initialized
INFO - 2017-03-12 18:12:28 --> Language Class Initialized
INFO - 2017-03-12 18:12:28 --> Loader Class Initialized
INFO - 2017-03-12 18:12:28 --> Database Driver Class Initialized
INFO - 2017-03-12 18:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:12:28 --> Controller Class Initialized
INFO - 2017-03-12 18:12:28 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:12:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:12:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:12:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:12:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:12:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:12:28 --> Final output sent to browser
DEBUG - 2017-03-12 18:12:28 --> Total execution time: 0.0143
INFO - 2017-03-12 18:12:34 --> Config Class Initialized
INFO - 2017-03-12 18:12:34 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:12:34 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:12:34 --> Utf8 Class Initialized
INFO - 2017-03-12 18:12:34 --> URI Class Initialized
INFO - 2017-03-12 18:12:34 --> Router Class Initialized
INFO - 2017-03-12 18:12:34 --> Output Class Initialized
INFO - 2017-03-12 18:12:34 --> Security Class Initialized
DEBUG - 2017-03-12 18:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:12:34 --> Input Class Initialized
INFO - 2017-03-12 18:12:34 --> Language Class Initialized
INFO - 2017-03-12 18:12:34 --> Loader Class Initialized
INFO - 2017-03-12 18:12:34 --> Database Driver Class Initialized
INFO - 2017-03-12 18:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:12:34 --> Controller Class Initialized
INFO - 2017-03-12 18:12:34 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:12:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:12:36 --> Config Class Initialized
INFO - 2017-03-12 18:12:36 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:12:36 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:12:36 --> Utf8 Class Initialized
INFO - 2017-03-12 18:12:36 --> URI Class Initialized
INFO - 2017-03-12 18:12:36 --> Router Class Initialized
INFO - 2017-03-12 18:12:36 --> Output Class Initialized
INFO - 2017-03-12 18:12:36 --> Security Class Initialized
DEBUG - 2017-03-12 18:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:12:36 --> Input Class Initialized
INFO - 2017-03-12 18:12:36 --> Language Class Initialized
INFO - 2017-03-12 18:12:36 --> Loader Class Initialized
INFO - 2017-03-12 18:12:36 --> Database Driver Class Initialized
INFO - 2017-03-12 18:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:12:36 --> Controller Class Initialized
INFO - 2017-03-12 18:12:36 --> Helper loaded: date_helper
DEBUG - 2017-03-12 18:12:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:12:36 --> Helper loaded: url_helper
INFO - 2017-03-12 18:12:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:12:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 18:12:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 18:12:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 18:12:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:12:36 --> Final output sent to browser
DEBUG - 2017-03-12 18:12:36 --> Total execution time: 0.0950
INFO - 2017-03-12 18:12:36 --> Config Class Initialized
INFO - 2017-03-12 18:12:36 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:12:36 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:12:36 --> Utf8 Class Initialized
INFO - 2017-03-12 18:12:36 --> URI Class Initialized
INFO - 2017-03-12 18:12:36 --> Router Class Initialized
INFO - 2017-03-12 18:12:36 --> Output Class Initialized
INFO - 2017-03-12 18:12:36 --> Security Class Initialized
DEBUG - 2017-03-12 18:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:12:36 --> Input Class Initialized
INFO - 2017-03-12 18:12:36 --> Language Class Initialized
INFO - 2017-03-12 18:12:36 --> Loader Class Initialized
INFO - 2017-03-12 18:12:36 --> Database Driver Class Initialized
INFO - 2017-03-12 18:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:12:36 --> Controller Class Initialized
INFO - 2017-03-12 18:12:36 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:12:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:12:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:12:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:12:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:12:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:12:36 --> Final output sent to browser
DEBUG - 2017-03-12 18:12:36 --> Total execution time: 0.0134
INFO - 2017-03-12 18:12:37 --> Config Class Initialized
INFO - 2017-03-12 18:12:37 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:12:37 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:12:37 --> Utf8 Class Initialized
INFO - 2017-03-12 18:12:37 --> URI Class Initialized
INFO - 2017-03-12 18:12:37 --> Router Class Initialized
INFO - 2017-03-12 18:12:37 --> Output Class Initialized
INFO - 2017-03-12 18:12:37 --> Security Class Initialized
DEBUG - 2017-03-12 18:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:12:37 --> Input Class Initialized
INFO - 2017-03-12 18:12:37 --> Language Class Initialized
INFO - 2017-03-12 18:12:37 --> Loader Class Initialized
INFO - 2017-03-12 18:12:37 --> Database Driver Class Initialized
INFO - 2017-03-12 18:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:12:37 --> Controller Class Initialized
INFO - 2017-03-12 18:12:37 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:12:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:12:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:12:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:12:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:12:37 --> Final output sent to browser
DEBUG - 2017-03-12 18:12:37 --> Total execution time: 0.0138
INFO - 2017-03-12 18:12:41 --> Config Class Initialized
INFO - 2017-03-12 18:12:41 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:12:41 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:12:41 --> Utf8 Class Initialized
INFO - 2017-03-12 18:12:41 --> URI Class Initialized
INFO - 2017-03-12 18:12:41 --> Router Class Initialized
INFO - 2017-03-12 18:12:41 --> Output Class Initialized
INFO - 2017-03-12 18:12:41 --> Security Class Initialized
DEBUG - 2017-03-12 18:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:12:41 --> Input Class Initialized
INFO - 2017-03-12 18:12:41 --> Language Class Initialized
INFO - 2017-03-12 18:12:41 --> Loader Class Initialized
INFO - 2017-03-12 18:12:41 --> Database Driver Class Initialized
INFO - 2017-03-12 18:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:12:41 --> Controller Class Initialized
INFO - 2017-03-12 18:12:41 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:12:41 --> Config Class Initialized
INFO - 2017-03-12 18:12:41 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:12:41 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:12:41 --> Utf8 Class Initialized
INFO - 2017-03-12 18:12:41 --> URI Class Initialized
INFO - 2017-03-12 18:12:41 --> Router Class Initialized
INFO - 2017-03-12 18:12:41 --> Output Class Initialized
INFO - 2017-03-12 18:12:41 --> Security Class Initialized
DEBUG - 2017-03-12 18:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:12:41 --> Input Class Initialized
INFO - 2017-03-12 18:12:41 --> Language Class Initialized
INFO - 2017-03-12 18:12:41 --> Loader Class Initialized
INFO - 2017-03-12 18:12:41 --> Database Driver Class Initialized
INFO - 2017-03-12 18:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:12:41 --> Controller Class Initialized
INFO - 2017-03-12 18:12:41 --> Helper loaded: date_helper
DEBUG - 2017-03-12 18:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:12:41 --> Helper loaded: url_helper
INFO - 2017-03-12 18:12:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:12:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 18:12:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 18:12:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 18:12:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:12:41 --> Final output sent to browser
DEBUG - 2017-03-12 18:12:41 --> Total execution time: 0.0140
INFO - 2017-03-12 18:12:42 --> Config Class Initialized
INFO - 2017-03-12 18:12:42 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:12:42 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:12:42 --> Utf8 Class Initialized
INFO - 2017-03-12 18:12:42 --> URI Class Initialized
INFO - 2017-03-12 18:12:42 --> Router Class Initialized
INFO - 2017-03-12 18:12:42 --> Output Class Initialized
INFO - 2017-03-12 18:12:42 --> Security Class Initialized
DEBUG - 2017-03-12 18:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:12:42 --> Input Class Initialized
INFO - 2017-03-12 18:12:42 --> Language Class Initialized
INFO - 2017-03-12 18:12:42 --> Loader Class Initialized
INFO - 2017-03-12 18:12:42 --> Database Driver Class Initialized
INFO - 2017-03-12 18:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:12:42 --> Controller Class Initialized
INFO - 2017-03-12 18:12:42 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:12:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:12:42 --> Config Class Initialized
INFO - 2017-03-12 18:12:42 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:12:42 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:12:42 --> Utf8 Class Initialized
INFO - 2017-03-12 18:12:42 --> URI Class Initialized
INFO - 2017-03-12 18:12:42 --> Router Class Initialized
INFO - 2017-03-12 18:12:42 --> Output Class Initialized
INFO - 2017-03-12 18:12:42 --> Security Class Initialized
DEBUG - 2017-03-12 18:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:12:42 --> Input Class Initialized
INFO - 2017-03-12 18:12:42 --> Language Class Initialized
INFO - 2017-03-12 18:12:42 --> Loader Class Initialized
INFO - 2017-03-12 18:12:42 --> Database Driver Class Initialized
INFO - 2017-03-12 18:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:12:42 --> Controller Class Initialized
INFO - 2017-03-12 18:12:42 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:12:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:12:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:12:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:12:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:12:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:12:42 --> Final output sent to browser
DEBUG - 2017-03-12 18:12:42 --> Total execution time: 0.1006
ERROR - 2017-03-12 18:12:42 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-12 18:12:42 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Pa Padilla')
INFO - 2017-03-12 18:12:42 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-12 18:12:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-12 18:12:43 --> Config Class Initialized
INFO - 2017-03-12 18:12:43 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:12:43 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:12:43 --> Utf8 Class Initialized
INFO - 2017-03-12 18:12:43 --> URI Class Initialized
INFO - 2017-03-12 18:12:43 --> Router Class Initialized
INFO - 2017-03-12 18:12:43 --> Output Class Initialized
INFO - 2017-03-12 18:12:43 --> Security Class Initialized
DEBUG - 2017-03-12 18:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:12:43 --> Input Class Initialized
INFO - 2017-03-12 18:12:43 --> Language Class Initialized
INFO - 2017-03-12 18:12:43 --> Loader Class Initialized
INFO - 2017-03-12 18:12:43 --> Database Driver Class Initialized
INFO - 2017-03-12 18:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:12:43 --> Controller Class Initialized
INFO - 2017-03-12 18:12:43 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:12:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:12:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:12:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:12:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:12:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:12:43 --> Final output sent to browser
DEBUG - 2017-03-12 18:12:43 --> Total execution time: 0.0155
INFO - 2017-03-12 18:12:47 --> Config Class Initialized
INFO - 2017-03-12 18:12:47 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:12:47 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:12:47 --> Utf8 Class Initialized
INFO - 2017-03-12 18:12:47 --> URI Class Initialized
DEBUG - 2017-03-12 18:12:47 --> No URI present. Default controller set.
INFO - 2017-03-12 18:12:47 --> Router Class Initialized
INFO - 2017-03-12 18:12:47 --> Output Class Initialized
INFO - 2017-03-12 18:12:47 --> Security Class Initialized
DEBUG - 2017-03-12 18:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:12:47 --> Input Class Initialized
INFO - 2017-03-12 18:12:47 --> Language Class Initialized
INFO - 2017-03-12 18:12:47 --> Loader Class Initialized
INFO - 2017-03-12 18:12:47 --> Database Driver Class Initialized
INFO - 2017-03-12 18:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:12:47 --> Controller Class Initialized
INFO - 2017-03-12 18:12:47 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:12:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:12:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:12:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:12:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:12:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:12:47 --> Final output sent to browser
DEBUG - 2017-03-12 18:12:47 --> Total execution time: 0.0131
INFO - 2017-03-12 18:12:49 --> Config Class Initialized
INFO - 2017-03-12 18:12:49 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:12:49 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:12:49 --> Utf8 Class Initialized
INFO - 2017-03-12 18:12:49 --> URI Class Initialized
INFO - 2017-03-12 18:12:49 --> Router Class Initialized
INFO - 2017-03-12 18:12:49 --> Output Class Initialized
INFO - 2017-03-12 18:12:49 --> Security Class Initialized
DEBUG - 2017-03-12 18:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:12:49 --> Input Class Initialized
INFO - 2017-03-12 18:12:49 --> Language Class Initialized
INFO - 2017-03-12 18:12:49 --> Loader Class Initialized
INFO - 2017-03-12 18:12:49 --> Database Driver Class Initialized
INFO - 2017-03-12 18:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:12:49 --> Controller Class Initialized
INFO - 2017-03-12 18:12:49 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:12:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:12:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:12:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:12:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:12:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:12:49 --> Final output sent to browser
DEBUG - 2017-03-12 18:12:49 --> Total execution time: 0.0140
INFO - 2017-03-12 18:12:51 --> Config Class Initialized
INFO - 2017-03-12 18:12:51 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:12:51 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:12:51 --> Utf8 Class Initialized
INFO - 2017-03-12 18:12:51 --> URI Class Initialized
INFO - 2017-03-12 18:12:51 --> Router Class Initialized
INFO - 2017-03-12 18:12:51 --> Output Class Initialized
INFO - 2017-03-12 18:12:51 --> Security Class Initialized
DEBUG - 2017-03-12 18:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:12:51 --> Input Class Initialized
INFO - 2017-03-12 18:12:51 --> Language Class Initialized
INFO - 2017-03-12 18:12:51 --> Loader Class Initialized
INFO - 2017-03-12 18:12:51 --> Database Driver Class Initialized
INFO - 2017-03-12 18:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:12:51 --> Controller Class Initialized
INFO - 2017-03-12 18:12:51 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:12:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-12 18:12:52 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-12 18:12:52 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Pa Padilla')
INFO - 2017-03-12 18:12:52 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-12 18:12:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-12 18:12:52 --> Config Class Initialized
INFO - 2017-03-12 18:12:52 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:12:52 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:12:52 --> Utf8 Class Initialized
INFO - 2017-03-12 18:12:52 --> URI Class Initialized
INFO - 2017-03-12 18:12:52 --> Router Class Initialized
INFO - 2017-03-12 18:12:52 --> Output Class Initialized
INFO - 2017-03-12 18:12:52 --> Security Class Initialized
DEBUG - 2017-03-12 18:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:12:52 --> Input Class Initialized
INFO - 2017-03-12 18:12:52 --> Language Class Initialized
INFO - 2017-03-12 18:12:52 --> Loader Class Initialized
INFO - 2017-03-12 18:12:52 --> Database Driver Class Initialized
INFO - 2017-03-12 18:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:12:52 --> Controller Class Initialized
INFO - 2017-03-12 18:12:52 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:12:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:12:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:12:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:12:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:12:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:12:52 --> Final output sent to browser
DEBUG - 2017-03-12 18:12:52 --> Total execution time: 0.0460
INFO - 2017-03-12 18:13:04 --> Config Class Initialized
INFO - 2017-03-12 18:13:04 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:13:05 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:13:05 --> Utf8 Class Initialized
INFO - 2017-03-12 18:13:05 --> URI Class Initialized
INFO - 2017-03-12 18:13:05 --> Router Class Initialized
INFO - 2017-03-12 18:13:05 --> Output Class Initialized
INFO - 2017-03-12 18:13:05 --> Security Class Initialized
DEBUG - 2017-03-12 18:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:13:05 --> Input Class Initialized
INFO - 2017-03-12 18:13:05 --> Language Class Initialized
INFO - 2017-03-12 18:13:05 --> Loader Class Initialized
INFO - 2017-03-12 18:13:05 --> Database Driver Class Initialized
INFO - 2017-03-12 18:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:13:06 --> Controller Class Initialized
INFO - 2017-03-12 18:13:06 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:13:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-12 18:13:07 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-12 18:13:07 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Pa Padilla')
INFO - 2017-03-12 18:13:07 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-12 18:13:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-12 18:13:07 --> Config Class Initialized
INFO - 2017-03-12 18:13:07 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:13:07 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:13:07 --> Utf8 Class Initialized
INFO - 2017-03-12 18:13:07 --> URI Class Initialized
INFO - 2017-03-12 18:13:07 --> Router Class Initialized
INFO - 2017-03-12 18:13:07 --> Output Class Initialized
INFO - 2017-03-12 18:13:07 --> Security Class Initialized
DEBUG - 2017-03-12 18:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:13:07 --> Input Class Initialized
INFO - 2017-03-12 18:13:07 --> Language Class Initialized
INFO - 2017-03-12 18:13:07 --> Loader Class Initialized
INFO - 2017-03-12 18:13:07 --> Database Driver Class Initialized
INFO - 2017-03-12 18:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:13:07 --> Controller Class Initialized
INFO - 2017-03-12 18:13:07 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:13:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:13:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:13:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:13:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:13:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:13:07 --> Final output sent to browser
DEBUG - 2017-03-12 18:13:07 --> Total execution time: 0.0562
INFO - 2017-03-12 18:13:10 --> Config Class Initialized
INFO - 2017-03-12 18:13:10 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:13:10 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:13:10 --> Utf8 Class Initialized
INFO - 2017-03-12 18:13:10 --> URI Class Initialized
INFO - 2017-03-12 18:13:10 --> Router Class Initialized
INFO - 2017-03-12 18:13:10 --> Output Class Initialized
INFO - 2017-03-12 18:13:10 --> Security Class Initialized
DEBUG - 2017-03-12 18:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:13:10 --> Input Class Initialized
INFO - 2017-03-12 18:13:10 --> Language Class Initialized
INFO - 2017-03-12 18:13:10 --> Loader Class Initialized
INFO - 2017-03-12 18:13:10 --> Database Driver Class Initialized
INFO - 2017-03-12 18:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:13:10 --> Controller Class Initialized
INFO - 2017-03-12 18:13:10 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:13:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:13:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:13:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:13:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:13:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:13:10 --> Final output sent to browser
DEBUG - 2017-03-12 18:13:10 --> Total execution time: 0.0146
INFO - 2017-03-12 18:13:11 --> Config Class Initialized
INFO - 2017-03-12 18:13:11 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:13:11 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:13:11 --> Utf8 Class Initialized
INFO - 2017-03-12 18:13:11 --> URI Class Initialized
INFO - 2017-03-12 18:13:11 --> Router Class Initialized
INFO - 2017-03-12 18:13:11 --> Output Class Initialized
INFO - 2017-03-12 18:13:11 --> Security Class Initialized
DEBUG - 2017-03-12 18:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:13:11 --> Input Class Initialized
INFO - 2017-03-12 18:13:11 --> Language Class Initialized
INFO - 2017-03-12 18:13:11 --> Loader Class Initialized
INFO - 2017-03-12 18:13:11 --> Database Driver Class Initialized
INFO - 2017-03-12 18:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:13:11 --> Controller Class Initialized
INFO - 2017-03-12 18:13:11 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:13:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:13:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:13:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:13:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:13:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:13:12 --> Final output sent to browser
DEBUG - 2017-03-12 18:13:12 --> Total execution time: 1.2378
INFO - 2017-03-12 18:13:27 --> Config Class Initialized
INFO - 2017-03-12 18:13:27 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:13:27 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:13:27 --> Utf8 Class Initialized
INFO - 2017-03-12 18:13:27 --> URI Class Initialized
INFO - 2017-03-12 18:13:28 --> Router Class Initialized
INFO - 2017-03-12 18:13:28 --> Output Class Initialized
INFO - 2017-03-12 18:13:28 --> Security Class Initialized
DEBUG - 2017-03-12 18:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:13:28 --> Input Class Initialized
INFO - 2017-03-12 18:13:28 --> Language Class Initialized
INFO - 2017-03-12 18:13:28 --> Loader Class Initialized
INFO - 2017-03-12 18:13:28 --> Database Driver Class Initialized
INFO - 2017-03-12 18:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:13:28 --> Controller Class Initialized
INFO - 2017-03-12 18:13:28 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:13:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:13:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:13:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:13:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:13:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:13:28 --> Final output sent to browser
DEBUG - 2017-03-12 18:13:28 --> Total execution time: 0.4787
INFO - 2017-03-12 18:13:29 --> Config Class Initialized
INFO - 2017-03-12 18:13:29 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:13:29 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:13:29 --> Utf8 Class Initialized
INFO - 2017-03-12 18:13:29 --> URI Class Initialized
INFO - 2017-03-12 18:13:29 --> Router Class Initialized
INFO - 2017-03-12 18:13:29 --> Output Class Initialized
INFO - 2017-03-12 18:13:29 --> Security Class Initialized
DEBUG - 2017-03-12 18:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:13:29 --> Input Class Initialized
INFO - 2017-03-12 18:13:29 --> Language Class Initialized
INFO - 2017-03-12 18:13:29 --> Loader Class Initialized
INFO - 2017-03-12 18:13:29 --> Database Driver Class Initialized
INFO - 2017-03-12 18:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:13:29 --> Controller Class Initialized
INFO - 2017-03-12 18:13:29 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:13:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:13:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:13:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:13:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:13:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:13:29 --> Final output sent to browser
DEBUG - 2017-03-12 18:13:29 --> Total execution time: 0.0159
INFO - 2017-03-12 18:13:45 --> Config Class Initialized
INFO - 2017-03-12 18:13:45 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:13:45 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:13:45 --> Utf8 Class Initialized
INFO - 2017-03-12 18:13:45 --> URI Class Initialized
INFO - 2017-03-12 18:13:45 --> Router Class Initialized
INFO - 2017-03-12 18:13:45 --> Output Class Initialized
INFO - 2017-03-12 18:13:45 --> Security Class Initialized
DEBUG - 2017-03-12 18:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:13:45 --> Input Class Initialized
INFO - 2017-03-12 18:13:45 --> Language Class Initialized
INFO - 2017-03-12 18:13:45 --> Loader Class Initialized
INFO - 2017-03-12 18:13:46 --> Database Driver Class Initialized
INFO - 2017-03-12 18:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:13:46 --> Controller Class Initialized
INFO - 2017-03-12 18:13:46 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:13:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:13:47 --> Config Class Initialized
INFO - 2017-03-12 18:13:47 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:13:47 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:13:47 --> Utf8 Class Initialized
INFO - 2017-03-12 18:13:47 --> URI Class Initialized
INFO - 2017-03-12 18:13:47 --> Router Class Initialized
INFO - 2017-03-12 18:13:47 --> Output Class Initialized
INFO - 2017-03-12 18:13:47 --> Security Class Initialized
DEBUG - 2017-03-12 18:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:13:47 --> Input Class Initialized
INFO - 2017-03-12 18:13:47 --> Language Class Initialized
INFO - 2017-03-12 18:13:47 --> Loader Class Initialized
INFO - 2017-03-12 18:13:47 --> Database Driver Class Initialized
INFO - 2017-03-12 18:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:13:47 --> Controller Class Initialized
INFO - 2017-03-12 18:13:47 --> Helper loaded: date_helper
DEBUG - 2017-03-12 18:13:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:13:47 --> Helper loaded: url_helper
INFO - 2017-03-12 18:13:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:13:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 18:13:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 18:13:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 18:13:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:13:47 --> Final output sent to browser
DEBUG - 2017-03-12 18:13:47 --> Total execution time: 0.1148
INFO - 2017-03-12 18:13:48 --> Config Class Initialized
INFO - 2017-03-12 18:13:48 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:13:48 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:13:48 --> Utf8 Class Initialized
INFO - 2017-03-12 18:13:48 --> URI Class Initialized
INFO - 2017-03-12 18:13:48 --> Router Class Initialized
INFO - 2017-03-12 18:13:48 --> Output Class Initialized
INFO - 2017-03-12 18:13:48 --> Security Class Initialized
DEBUG - 2017-03-12 18:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:13:48 --> Input Class Initialized
INFO - 2017-03-12 18:13:48 --> Language Class Initialized
INFO - 2017-03-12 18:13:48 --> Loader Class Initialized
INFO - 2017-03-12 18:13:48 --> Database Driver Class Initialized
INFO - 2017-03-12 18:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:13:48 --> Controller Class Initialized
INFO - 2017-03-12 18:13:48 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:13:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:13:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:13:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:13:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:13:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:13:48 --> Final output sent to browser
DEBUG - 2017-03-12 18:13:48 --> Total execution time: 0.0352
INFO - 2017-03-12 18:13:50 --> Config Class Initialized
INFO - 2017-03-12 18:13:50 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:13:50 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:13:50 --> Utf8 Class Initialized
INFO - 2017-03-12 18:13:50 --> URI Class Initialized
DEBUG - 2017-03-12 18:13:50 --> No URI present. Default controller set.
INFO - 2017-03-12 18:13:50 --> Router Class Initialized
INFO - 2017-03-12 18:13:50 --> Output Class Initialized
INFO - 2017-03-12 18:13:50 --> Security Class Initialized
DEBUG - 2017-03-12 18:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:13:50 --> Input Class Initialized
INFO - 2017-03-12 18:13:50 --> Language Class Initialized
INFO - 2017-03-12 18:13:50 --> Loader Class Initialized
INFO - 2017-03-12 18:13:50 --> Database Driver Class Initialized
INFO - 2017-03-12 18:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:13:50 --> Controller Class Initialized
INFO - 2017-03-12 18:13:50 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:13:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:13:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:13:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:13:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:13:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:13:50 --> Final output sent to browser
DEBUG - 2017-03-12 18:13:50 --> Total execution time: 0.0431
INFO - 2017-03-12 18:13:50 --> Config Class Initialized
INFO - 2017-03-12 18:13:50 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:13:50 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:13:50 --> Utf8 Class Initialized
INFO - 2017-03-12 18:13:50 --> URI Class Initialized
INFO - 2017-03-12 18:13:50 --> Router Class Initialized
INFO - 2017-03-12 18:13:50 --> Output Class Initialized
INFO - 2017-03-12 18:13:50 --> Security Class Initialized
DEBUG - 2017-03-12 18:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:13:50 --> Input Class Initialized
INFO - 2017-03-12 18:13:50 --> Language Class Initialized
INFO - 2017-03-12 18:13:50 --> Loader Class Initialized
INFO - 2017-03-12 18:13:50 --> Database Driver Class Initialized
INFO - 2017-03-12 18:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:13:50 --> Controller Class Initialized
INFO - 2017-03-12 18:13:50 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:13:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:13:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:13:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:13:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:13:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:13:50 --> Final output sent to browser
DEBUG - 2017-03-12 18:13:50 --> Total execution time: 0.0142
INFO - 2017-03-12 18:21:00 --> Config Class Initialized
INFO - 2017-03-12 18:21:00 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:21:00 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:21:00 --> Utf8 Class Initialized
INFO - 2017-03-12 18:21:00 --> URI Class Initialized
DEBUG - 2017-03-12 18:21:00 --> No URI present. Default controller set.
INFO - 2017-03-12 18:21:00 --> Router Class Initialized
INFO - 2017-03-12 18:21:00 --> Output Class Initialized
INFO - 2017-03-12 18:21:00 --> Security Class Initialized
DEBUG - 2017-03-12 18:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:21:00 --> Input Class Initialized
INFO - 2017-03-12 18:21:00 --> Language Class Initialized
INFO - 2017-03-12 18:21:01 --> Loader Class Initialized
INFO - 2017-03-12 18:21:01 --> Database Driver Class Initialized
INFO - 2017-03-12 18:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:21:01 --> Controller Class Initialized
INFO - 2017-03-12 18:21:01 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:21:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:21:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:21:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:21:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:21:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:21:02 --> Final output sent to browser
DEBUG - 2017-03-12 18:21:02 --> Total execution time: 1.5761
INFO - 2017-03-12 18:21:07 --> Config Class Initialized
INFO - 2017-03-12 18:21:07 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:21:07 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:21:07 --> Utf8 Class Initialized
INFO - 2017-03-12 18:21:07 --> URI Class Initialized
INFO - 2017-03-12 18:21:07 --> Router Class Initialized
INFO - 2017-03-12 18:21:07 --> Output Class Initialized
INFO - 2017-03-12 18:21:07 --> Security Class Initialized
DEBUG - 2017-03-12 18:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:21:07 --> Input Class Initialized
INFO - 2017-03-12 18:21:07 --> Language Class Initialized
INFO - 2017-03-12 18:21:07 --> Loader Class Initialized
INFO - 2017-03-12 18:21:07 --> Database Driver Class Initialized
INFO - 2017-03-12 18:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:21:07 --> Controller Class Initialized
INFO - 2017-03-12 18:21:07 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:21:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:21:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:21:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:21:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:21:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:21:07 --> Final output sent to browser
DEBUG - 2017-03-12 18:21:07 --> Total execution time: 0.0138
INFO - 2017-03-12 18:21:47 --> Config Class Initialized
INFO - 2017-03-12 18:21:47 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:21:47 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:21:48 --> Utf8 Class Initialized
INFO - 2017-03-12 18:21:48 --> URI Class Initialized
INFO - 2017-03-12 18:21:48 --> Router Class Initialized
INFO - 2017-03-12 18:21:48 --> Output Class Initialized
INFO - 2017-03-12 18:21:48 --> Security Class Initialized
DEBUG - 2017-03-12 18:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:21:48 --> Input Class Initialized
INFO - 2017-03-12 18:21:48 --> Language Class Initialized
INFO - 2017-03-12 18:21:48 --> Loader Class Initialized
INFO - 2017-03-12 18:21:48 --> Database Driver Class Initialized
INFO - 2017-03-12 18:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:21:49 --> Controller Class Initialized
INFO - 2017-03-12 18:21:49 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:21:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:21:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 18:21:49 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 18:21:49 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 18:21:49 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 18:21:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:21:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:21:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:21:49 --> Final output sent to browser
DEBUG - 2017-03-12 18:21:49 --> Total execution time: 1.8741
INFO - 2017-03-12 18:21:52 --> Config Class Initialized
INFO - 2017-03-12 18:21:52 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:21:52 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:21:52 --> Utf8 Class Initialized
INFO - 2017-03-12 18:21:52 --> URI Class Initialized
INFO - 2017-03-12 18:21:52 --> Router Class Initialized
INFO - 2017-03-12 18:21:52 --> Output Class Initialized
INFO - 2017-03-12 18:21:52 --> Security Class Initialized
DEBUG - 2017-03-12 18:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:21:52 --> Input Class Initialized
INFO - 2017-03-12 18:21:52 --> Language Class Initialized
INFO - 2017-03-12 18:21:52 --> Loader Class Initialized
INFO - 2017-03-12 18:21:52 --> Database Driver Class Initialized
INFO - 2017-03-12 18:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:21:52 --> Controller Class Initialized
INFO - 2017-03-12 18:21:52 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:21:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:21:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:21:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:21:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:21:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:21:52 --> Final output sent to browser
DEBUG - 2017-03-12 18:21:52 --> Total execution time: 0.0141
INFO - 2017-03-12 18:22:16 --> Config Class Initialized
INFO - 2017-03-12 18:22:16 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:22:16 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:22:16 --> Utf8 Class Initialized
INFO - 2017-03-12 18:22:16 --> URI Class Initialized
INFO - 2017-03-12 18:22:16 --> Router Class Initialized
INFO - 2017-03-12 18:22:16 --> Output Class Initialized
INFO - 2017-03-12 18:22:16 --> Security Class Initialized
DEBUG - 2017-03-12 18:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:22:16 --> Input Class Initialized
INFO - 2017-03-12 18:22:16 --> Language Class Initialized
INFO - 2017-03-12 18:22:16 --> Loader Class Initialized
INFO - 2017-03-12 18:22:16 --> Database Driver Class Initialized
INFO - 2017-03-12 18:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:22:16 --> Controller Class Initialized
INFO - 2017-03-12 18:22:16 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:22:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:22:19 --> Config Class Initialized
INFO - 2017-03-12 18:22:19 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:22:19 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:22:19 --> Utf8 Class Initialized
INFO - 2017-03-12 18:22:19 --> URI Class Initialized
INFO - 2017-03-12 18:22:19 --> Router Class Initialized
INFO - 2017-03-12 18:22:19 --> Output Class Initialized
INFO - 2017-03-12 18:22:19 --> Security Class Initialized
DEBUG - 2017-03-12 18:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:22:19 --> Input Class Initialized
INFO - 2017-03-12 18:22:19 --> Language Class Initialized
INFO - 2017-03-12 18:22:19 --> Loader Class Initialized
INFO - 2017-03-12 18:22:19 --> Database Driver Class Initialized
INFO - 2017-03-12 18:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:22:19 --> Controller Class Initialized
INFO - 2017-03-12 18:22:19 --> Helper loaded: date_helper
DEBUG - 2017-03-12 18:22:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:22:19 --> Helper loaded: url_helper
INFO - 2017-03-12 18:22:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:22:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 18:22:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 18:22:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 18:22:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:22:19 --> Final output sent to browser
DEBUG - 2017-03-12 18:22:19 --> Total execution time: 0.1001
INFO - 2017-03-12 18:22:20 --> Config Class Initialized
INFO - 2017-03-12 18:22:20 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:22:20 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:22:20 --> Utf8 Class Initialized
INFO - 2017-03-12 18:22:20 --> URI Class Initialized
INFO - 2017-03-12 18:22:20 --> Router Class Initialized
INFO - 2017-03-12 18:22:20 --> Output Class Initialized
INFO - 2017-03-12 18:22:20 --> Security Class Initialized
DEBUG - 2017-03-12 18:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:22:20 --> Input Class Initialized
INFO - 2017-03-12 18:22:20 --> Language Class Initialized
INFO - 2017-03-12 18:22:20 --> Loader Class Initialized
INFO - 2017-03-12 18:22:20 --> Database Driver Class Initialized
INFO - 2017-03-12 18:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:22:20 --> Controller Class Initialized
INFO - 2017-03-12 18:22:20 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:22:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:22:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:22:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:22:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:22:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:22:20 --> Final output sent to browser
DEBUG - 2017-03-12 18:22:20 --> Total execution time: 0.0158
INFO - 2017-03-12 18:27:44 --> Config Class Initialized
INFO - 2017-03-12 18:27:44 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:27:44 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:27:44 --> Utf8 Class Initialized
INFO - 2017-03-12 18:27:44 --> URI Class Initialized
INFO - 2017-03-12 18:27:44 --> Router Class Initialized
INFO - 2017-03-12 18:27:44 --> Output Class Initialized
INFO - 2017-03-12 18:27:44 --> Security Class Initialized
DEBUG - 2017-03-12 18:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:27:44 --> Input Class Initialized
INFO - 2017-03-12 18:27:44 --> Language Class Initialized
INFO - 2017-03-12 18:27:44 --> Loader Class Initialized
INFO - 2017-03-12 18:27:44 --> Database Driver Class Initialized
INFO - 2017-03-12 18:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:27:45 --> Controller Class Initialized
INFO - 2017-03-12 18:27:45 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:27:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-12 18:27:46 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-12 18:27:46 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Scarlett Osborn')
INFO - 2017-03-12 18:27:46 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-12 18:27:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-12 18:27:47 --> Config Class Initialized
INFO - 2017-03-12 18:27:47 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:27:47 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:27:47 --> Utf8 Class Initialized
INFO - 2017-03-12 18:27:47 --> URI Class Initialized
INFO - 2017-03-12 18:27:47 --> Router Class Initialized
INFO - 2017-03-12 18:27:47 --> Output Class Initialized
INFO - 2017-03-12 18:27:47 --> Security Class Initialized
DEBUG - 2017-03-12 18:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:27:47 --> Input Class Initialized
INFO - 2017-03-12 18:27:47 --> Language Class Initialized
INFO - 2017-03-12 18:27:47 --> Loader Class Initialized
INFO - 2017-03-12 18:27:47 --> Database Driver Class Initialized
INFO - 2017-03-12 18:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:27:47 --> Controller Class Initialized
INFO - 2017-03-12 18:27:47 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:27:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:27:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:27:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:27:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:27:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:27:47 --> Final output sent to browser
DEBUG - 2017-03-12 18:27:47 --> Total execution time: 0.4063
INFO - 2017-03-12 18:27:53 --> Config Class Initialized
INFO - 2017-03-12 18:27:53 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:27:53 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:27:53 --> Utf8 Class Initialized
INFO - 2017-03-12 18:27:53 --> URI Class Initialized
INFO - 2017-03-12 18:27:53 --> Router Class Initialized
INFO - 2017-03-12 18:27:53 --> Output Class Initialized
INFO - 2017-03-12 18:27:53 --> Security Class Initialized
DEBUG - 2017-03-12 18:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:27:53 --> Input Class Initialized
INFO - 2017-03-12 18:27:53 --> Language Class Initialized
INFO - 2017-03-12 18:27:53 --> Loader Class Initialized
INFO - 2017-03-12 18:27:53 --> Database Driver Class Initialized
INFO - 2017-03-12 18:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:27:53 --> Controller Class Initialized
INFO - 2017-03-12 18:27:53 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:27:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-12 18:27:54 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-12 18:27:54 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Scarlett Osborn')
INFO - 2017-03-12 18:27:54 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-12 18:27:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-12 18:27:54 --> Config Class Initialized
INFO - 2017-03-12 18:27:54 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:27:54 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:27:54 --> Utf8 Class Initialized
INFO - 2017-03-12 18:27:54 --> URI Class Initialized
INFO - 2017-03-12 18:27:54 --> Router Class Initialized
INFO - 2017-03-12 18:27:54 --> Output Class Initialized
INFO - 2017-03-12 18:27:54 --> Security Class Initialized
DEBUG - 2017-03-12 18:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:27:54 --> Input Class Initialized
INFO - 2017-03-12 18:27:54 --> Language Class Initialized
INFO - 2017-03-12 18:27:54 --> Loader Class Initialized
INFO - 2017-03-12 18:27:54 --> Database Driver Class Initialized
INFO - 2017-03-12 18:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:27:54 --> Controller Class Initialized
INFO - 2017-03-12 18:27:54 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:27:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:27:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:27:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:27:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:27:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:27:54 --> Final output sent to browser
DEBUG - 2017-03-12 18:27:54 --> Total execution time: 0.0140
INFO - 2017-03-12 18:27:56 --> Config Class Initialized
INFO - 2017-03-12 18:27:56 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:27:56 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:27:56 --> Utf8 Class Initialized
INFO - 2017-03-12 18:27:56 --> URI Class Initialized
INFO - 2017-03-12 18:27:56 --> Router Class Initialized
INFO - 2017-03-12 18:27:56 --> Output Class Initialized
INFO - 2017-03-12 18:27:56 --> Security Class Initialized
DEBUG - 2017-03-12 18:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:27:56 --> Input Class Initialized
INFO - 2017-03-12 18:27:56 --> Language Class Initialized
INFO - 2017-03-12 18:27:56 --> Loader Class Initialized
INFO - 2017-03-12 18:27:56 --> Database Driver Class Initialized
INFO - 2017-03-12 18:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:27:56 --> Controller Class Initialized
INFO - 2017-03-12 18:27:56 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:27:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-12 18:27:56 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-12 18:27:56 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Scarlett Osborn')
INFO - 2017-03-12 18:27:56 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-12 18:27:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-12 18:27:57 --> Config Class Initialized
INFO - 2017-03-12 18:27:57 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:27:57 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:27:57 --> Utf8 Class Initialized
INFO - 2017-03-12 18:27:57 --> URI Class Initialized
INFO - 2017-03-12 18:27:57 --> Router Class Initialized
INFO - 2017-03-12 18:27:57 --> Output Class Initialized
INFO - 2017-03-12 18:27:57 --> Security Class Initialized
DEBUG - 2017-03-12 18:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:27:57 --> Input Class Initialized
INFO - 2017-03-12 18:27:57 --> Language Class Initialized
INFO - 2017-03-12 18:27:57 --> Loader Class Initialized
INFO - 2017-03-12 18:27:57 --> Database Driver Class Initialized
INFO - 2017-03-12 18:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:27:57 --> Controller Class Initialized
INFO - 2017-03-12 18:27:57 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:27:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:27:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:27:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:27:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:27:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:27:57 --> Final output sent to browser
DEBUG - 2017-03-12 18:27:57 --> Total execution time: 0.0138
INFO - 2017-03-12 18:27:58 --> Config Class Initialized
INFO - 2017-03-12 18:27:58 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:27:58 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:27:58 --> Utf8 Class Initialized
INFO - 2017-03-12 18:27:58 --> URI Class Initialized
DEBUG - 2017-03-12 18:27:58 --> No URI present. Default controller set.
INFO - 2017-03-12 18:27:58 --> Router Class Initialized
INFO - 2017-03-12 18:27:58 --> Output Class Initialized
INFO - 2017-03-12 18:27:58 --> Security Class Initialized
DEBUG - 2017-03-12 18:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:27:58 --> Input Class Initialized
INFO - 2017-03-12 18:27:58 --> Language Class Initialized
INFO - 2017-03-12 18:27:58 --> Loader Class Initialized
INFO - 2017-03-12 18:27:58 --> Database Driver Class Initialized
INFO - 2017-03-12 18:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:27:58 --> Controller Class Initialized
INFO - 2017-03-12 18:27:58 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:27:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:27:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:27:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:27:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:27:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:27:58 --> Final output sent to browser
DEBUG - 2017-03-12 18:27:58 --> Total execution time: 0.0131
INFO - 2017-03-12 18:28:32 --> Config Class Initialized
INFO - 2017-03-12 18:28:32 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:28:32 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:28:32 --> Utf8 Class Initialized
INFO - 2017-03-12 18:28:33 --> URI Class Initialized
INFO - 2017-03-12 18:28:33 --> Router Class Initialized
INFO - 2017-03-12 18:28:33 --> Output Class Initialized
INFO - 2017-03-12 18:28:33 --> Security Class Initialized
DEBUG - 2017-03-12 18:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:28:33 --> Input Class Initialized
INFO - 2017-03-12 18:28:33 --> Language Class Initialized
INFO - 2017-03-12 18:28:33 --> Loader Class Initialized
INFO - 2017-03-12 18:28:33 --> Database Driver Class Initialized
INFO - 2017-03-12 18:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:28:33 --> Controller Class Initialized
INFO - 2017-03-12 18:28:33 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:28:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:28:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:28:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:28:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:28:33 --> Final output sent to browser
DEBUG - 2017-03-12 18:28:33 --> Total execution time: 0.0607
INFO - 2017-03-12 18:28:54 --> Config Class Initialized
INFO - 2017-03-12 18:28:54 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:28:54 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:28:54 --> Utf8 Class Initialized
INFO - 2017-03-12 18:28:54 --> URI Class Initialized
INFO - 2017-03-12 18:28:54 --> Router Class Initialized
INFO - 2017-03-12 18:28:54 --> Output Class Initialized
INFO - 2017-03-12 18:28:54 --> Security Class Initialized
DEBUG - 2017-03-12 18:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:28:54 --> Input Class Initialized
INFO - 2017-03-12 18:28:54 --> Language Class Initialized
INFO - 2017-03-12 18:28:54 --> Loader Class Initialized
INFO - 2017-03-12 18:28:54 --> Database Driver Class Initialized
INFO - 2017-03-12 18:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:28:54 --> Controller Class Initialized
INFO - 2017-03-12 18:28:54 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:28:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:28:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:28:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:28:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:28:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:28:54 --> Final output sent to browser
DEBUG - 2017-03-12 18:28:54 --> Total execution time: 0.0145
INFO - 2017-03-12 18:29:08 --> Config Class Initialized
INFO - 2017-03-12 18:29:08 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:29:08 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:29:08 --> Utf8 Class Initialized
INFO - 2017-03-12 18:29:08 --> URI Class Initialized
INFO - 2017-03-12 18:29:08 --> Router Class Initialized
INFO - 2017-03-12 18:29:08 --> Output Class Initialized
INFO - 2017-03-12 18:29:08 --> Security Class Initialized
DEBUG - 2017-03-12 18:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:29:08 --> Input Class Initialized
INFO - 2017-03-12 18:29:08 --> Language Class Initialized
INFO - 2017-03-12 18:29:08 --> Loader Class Initialized
INFO - 2017-03-12 18:29:08 --> Database Driver Class Initialized
INFO - 2017-03-12 18:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:29:08 --> Controller Class Initialized
INFO - 2017-03-12 18:29:08 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:29:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:29:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:29:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:29:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:29:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:29:08 --> Final output sent to browser
DEBUG - 2017-03-12 18:29:08 --> Total execution time: 0.0134
INFO - 2017-03-12 18:29:12 --> Config Class Initialized
INFO - 2017-03-12 18:29:12 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:29:12 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:29:12 --> Utf8 Class Initialized
INFO - 2017-03-12 18:29:12 --> URI Class Initialized
INFO - 2017-03-12 18:29:12 --> Router Class Initialized
INFO - 2017-03-12 18:29:12 --> Output Class Initialized
INFO - 2017-03-12 18:29:12 --> Security Class Initialized
DEBUG - 2017-03-12 18:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:29:12 --> Input Class Initialized
INFO - 2017-03-12 18:29:12 --> Language Class Initialized
INFO - 2017-03-12 18:29:12 --> Loader Class Initialized
INFO - 2017-03-12 18:29:12 --> Database Driver Class Initialized
INFO - 2017-03-12 18:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:29:12 --> Controller Class Initialized
INFO - 2017-03-12 18:29:12 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:29:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:29:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:29:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:29:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:29:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:29:12 --> Final output sent to browser
DEBUG - 2017-03-12 18:29:12 --> Total execution time: 0.0140
INFO - 2017-03-12 18:29:14 --> Config Class Initialized
INFO - 2017-03-12 18:29:14 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:29:14 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:29:14 --> Utf8 Class Initialized
INFO - 2017-03-12 18:29:14 --> URI Class Initialized
INFO - 2017-03-12 18:29:14 --> Router Class Initialized
INFO - 2017-03-12 18:29:14 --> Output Class Initialized
INFO - 2017-03-12 18:29:14 --> Security Class Initialized
DEBUG - 2017-03-12 18:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:29:14 --> Input Class Initialized
INFO - 2017-03-12 18:29:14 --> Language Class Initialized
INFO - 2017-03-12 18:29:14 --> Loader Class Initialized
INFO - 2017-03-12 18:29:14 --> Database Driver Class Initialized
INFO - 2017-03-12 18:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:29:14 --> Controller Class Initialized
INFO - 2017-03-12 18:29:14 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:29:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:29:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:29:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:29:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:29:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:29:14 --> Final output sent to browser
DEBUG - 2017-03-12 18:29:14 --> Total execution time: 0.0138
INFO - 2017-03-12 18:32:28 --> Config Class Initialized
INFO - 2017-03-12 18:32:28 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:32:28 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:32:28 --> Utf8 Class Initialized
INFO - 2017-03-12 18:32:28 --> URI Class Initialized
INFO - 2017-03-12 18:32:28 --> Router Class Initialized
INFO - 2017-03-12 18:32:28 --> Output Class Initialized
INFO - 2017-03-12 18:32:28 --> Security Class Initialized
DEBUG - 2017-03-12 18:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:32:29 --> Input Class Initialized
INFO - 2017-03-12 18:32:29 --> Language Class Initialized
INFO - 2017-03-12 18:32:29 --> Loader Class Initialized
INFO - 2017-03-12 18:32:29 --> Database Driver Class Initialized
INFO - 2017-03-12 18:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:32:30 --> Controller Class Initialized
INFO - 2017-03-12 18:32:30 --> Helper loaded: date_helper
DEBUG - 2017-03-12 18:32:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:32:30 --> Helper loaded: url_helper
INFO - 2017-03-12 18:32:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:32:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 18:32:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 18:32:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 18:32:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:32:30 --> Final output sent to browser
DEBUG - 2017-03-12 18:32:30 --> Total execution time: 1.7014
INFO - 2017-03-12 18:32:32 --> Config Class Initialized
INFO - 2017-03-12 18:32:32 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:32:32 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:32:32 --> Utf8 Class Initialized
INFO - 2017-03-12 18:32:32 --> URI Class Initialized
INFO - 2017-03-12 18:32:32 --> Router Class Initialized
INFO - 2017-03-12 18:32:32 --> Output Class Initialized
INFO - 2017-03-12 18:32:32 --> Security Class Initialized
DEBUG - 2017-03-12 18:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:32:32 --> Input Class Initialized
INFO - 2017-03-12 18:32:32 --> Language Class Initialized
INFO - 2017-03-12 18:32:32 --> Loader Class Initialized
INFO - 2017-03-12 18:32:32 --> Database Driver Class Initialized
INFO - 2017-03-12 18:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:32:33 --> Controller Class Initialized
INFO - 2017-03-12 18:32:33 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:32:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:32:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:32:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:32:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:32:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:32:33 --> Final output sent to browser
DEBUG - 2017-03-12 18:32:33 --> Total execution time: 1.5408
INFO - 2017-03-12 18:42:54 --> Config Class Initialized
INFO - 2017-03-12 18:42:54 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:42:54 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:42:54 --> Utf8 Class Initialized
INFO - 2017-03-12 18:42:54 --> URI Class Initialized
DEBUG - 2017-03-12 18:42:54 --> No URI present. Default controller set.
INFO - 2017-03-12 18:42:54 --> Router Class Initialized
INFO - 2017-03-12 18:42:54 --> Output Class Initialized
INFO - 2017-03-12 18:42:54 --> Security Class Initialized
DEBUG - 2017-03-12 18:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:42:54 --> Input Class Initialized
INFO - 2017-03-12 18:42:54 --> Language Class Initialized
INFO - 2017-03-12 18:42:54 --> Loader Class Initialized
INFO - 2017-03-12 18:42:55 --> Database Driver Class Initialized
INFO - 2017-03-12 18:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:42:55 --> Controller Class Initialized
INFO - 2017-03-12 18:42:55 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:42:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:42:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:42:56 --> Final output sent to browser
DEBUG - 2017-03-12 18:42:56 --> Total execution time: 1.4977
INFO - 2017-03-12 18:43:15 --> Config Class Initialized
INFO - 2017-03-12 18:43:15 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:43:15 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:43:15 --> Utf8 Class Initialized
INFO - 2017-03-12 18:43:15 --> URI Class Initialized
INFO - 2017-03-12 18:43:15 --> Router Class Initialized
INFO - 2017-03-12 18:43:15 --> Output Class Initialized
INFO - 2017-03-12 18:43:15 --> Security Class Initialized
DEBUG - 2017-03-12 18:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:43:15 --> Input Class Initialized
INFO - 2017-03-12 18:43:15 --> Language Class Initialized
INFO - 2017-03-12 18:43:15 --> Loader Class Initialized
INFO - 2017-03-12 18:43:15 --> Database Driver Class Initialized
INFO - 2017-03-12 18:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:43:15 --> Controller Class Initialized
INFO - 2017-03-12 18:43:15 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:43:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:43:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:43:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:43:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:43:15 --> Final output sent to browser
DEBUG - 2017-03-12 18:43:15 --> Total execution time: 0.0138
INFO - 2017-03-12 18:43:49 --> Config Class Initialized
INFO - 2017-03-12 18:43:49 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:43:49 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:43:49 --> Utf8 Class Initialized
INFO - 2017-03-12 18:43:49 --> URI Class Initialized
DEBUG - 2017-03-12 18:43:49 --> No URI present. Default controller set.
INFO - 2017-03-12 18:43:49 --> Router Class Initialized
INFO - 2017-03-12 18:43:49 --> Output Class Initialized
INFO - 2017-03-12 18:43:49 --> Security Class Initialized
DEBUG - 2017-03-12 18:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:43:49 --> Input Class Initialized
INFO - 2017-03-12 18:43:49 --> Language Class Initialized
INFO - 2017-03-12 18:43:49 --> Loader Class Initialized
INFO - 2017-03-12 18:43:49 --> Database Driver Class Initialized
INFO - 2017-03-12 18:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:43:50 --> Controller Class Initialized
INFO - 2017-03-12 18:43:50 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:43:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:43:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:43:50 --> Final output sent to browser
DEBUG - 2017-03-12 18:43:50 --> Total execution time: 1.3278
INFO - 2017-03-12 18:43:55 --> Config Class Initialized
INFO - 2017-03-12 18:43:55 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:43:55 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:43:55 --> Utf8 Class Initialized
INFO - 2017-03-12 18:43:55 --> URI Class Initialized
INFO - 2017-03-12 18:43:55 --> Router Class Initialized
INFO - 2017-03-12 18:43:55 --> Output Class Initialized
INFO - 2017-03-12 18:43:55 --> Security Class Initialized
DEBUG - 2017-03-12 18:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:43:55 --> Input Class Initialized
INFO - 2017-03-12 18:43:55 --> Language Class Initialized
INFO - 2017-03-12 18:43:55 --> Loader Class Initialized
INFO - 2017-03-12 18:43:55 --> Database Driver Class Initialized
INFO - 2017-03-12 18:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:43:55 --> Controller Class Initialized
INFO - 2017-03-12 18:43:55 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:43:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:43:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:43:55 --> Final output sent to browser
DEBUG - 2017-03-12 18:43:55 --> Total execution time: 0.1442
INFO - 2017-03-12 18:44:40 --> Config Class Initialized
INFO - 2017-03-12 18:44:40 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:44:40 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:44:40 --> Utf8 Class Initialized
INFO - 2017-03-12 18:44:40 --> URI Class Initialized
INFO - 2017-03-12 18:44:40 --> Router Class Initialized
INFO - 2017-03-12 18:44:40 --> Output Class Initialized
INFO - 2017-03-12 18:44:40 --> Security Class Initialized
DEBUG - 2017-03-12 18:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:44:40 --> Input Class Initialized
INFO - 2017-03-12 18:44:40 --> Language Class Initialized
INFO - 2017-03-12 18:44:40 --> Loader Class Initialized
INFO - 2017-03-12 18:44:40 --> Database Driver Class Initialized
INFO - 2017-03-12 18:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:44:41 --> Controller Class Initialized
INFO - 2017-03-12 18:44:41 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:44:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:44:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 18:44:41 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 18:44:41 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 18:44:41 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 18:44:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:44:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:44:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:44:41 --> Final output sent to browser
DEBUG - 2017-03-12 18:44:41 --> Total execution time: 1.0156
INFO - 2017-03-12 18:44:48 --> Config Class Initialized
INFO - 2017-03-12 18:44:48 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:44:48 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:44:48 --> Utf8 Class Initialized
INFO - 2017-03-12 18:44:48 --> URI Class Initialized
INFO - 2017-03-12 18:44:48 --> Router Class Initialized
INFO - 2017-03-12 18:44:48 --> Output Class Initialized
INFO - 2017-03-12 18:44:48 --> Security Class Initialized
DEBUG - 2017-03-12 18:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:44:48 --> Input Class Initialized
INFO - 2017-03-12 18:44:48 --> Language Class Initialized
INFO - 2017-03-12 18:44:48 --> Loader Class Initialized
INFO - 2017-03-12 18:44:48 --> Database Driver Class Initialized
INFO - 2017-03-12 18:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:44:48 --> Controller Class Initialized
INFO - 2017-03-12 18:44:48 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:44:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:44:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:44:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:44:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:44:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:44:48 --> Final output sent to browser
DEBUG - 2017-03-12 18:44:48 --> Total execution time: 0.0139
INFO - 2017-03-12 18:49:33 --> Config Class Initialized
INFO - 2017-03-12 18:49:33 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:49:33 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:49:33 --> Utf8 Class Initialized
INFO - 2017-03-12 18:49:33 --> URI Class Initialized
DEBUG - 2017-03-12 18:49:33 --> No URI present. Default controller set.
INFO - 2017-03-12 18:49:33 --> Router Class Initialized
INFO - 2017-03-12 18:49:33 --> Output Class Initialized
INFO - 2017-03-12 18:49:33 --> Security Class Initialized
DEBUG - 2017-03-12 18:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:49:34 --> Input Class Initialized
INFO - 2017-03-12 18:49:34 --> Language Class Initialized
INFO - 2017-03-12 18:49:34 --> Loader Class Initialized
INFO - 2017-03-12 18:49:34 --> Database Driver Class Initialized
INFO - 2017-03-12 18:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:49:34 --> Controller Class Initialized
INFO - 2017-03-12 18:49:34 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:49:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:49:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:49:35 --> Final output sent to browser
DEBUG - 2017-03-12 18:49:35 --> Total execution time: 1.5571
INFO - 2017-03-12 18:49:46 --> Config Class Initialized
INFO - 2017-03-12 18:49:46 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:49:46 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:49:46 --> Utf8 Class Initialized
INFO - 2017-03-12 18:49:46 --> URI Class Initialized
INFO - 2017-03-12 18:49:46 --> Router Class Initialized
INFO - 2017-03-12 18:49:46 --> Output Class Initialized
INFO - 2017-03-12 18:49:46 --> Security Class Initialized
DEBUG - 2017-03-12 18:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:49:46 --> Input Class Initialized
INFO - 2017-03-12 18:49:46 --> Language Class Initialized
INFO - 2017-03-12 18:49:46 --> Loader Class Initialized
INFO - 2017-03-12 18:49:46 --> Database Driver Class Initialized
INFO - 2017-03-12 18:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:49:46 --> Controller Class Initialized
INFO - 2017-03-12 18:49:46 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:49:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:49:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:49:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:49:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:49:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:49:46 --> Final output sent to browser
DEBUG - 2017-03-12 18:49:46 --> Total execution time: 0.0135
INFO - 2017-03-12 18:50:40 --> Config Class Initialized
INFO - 2017-03-12 18:50:40 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:50:40 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:50:40 --> Utf8 Class Initialized
INFO - 2017-03-12 18:50:40 --> URI Class Initialized
INFO - 2017-03-12 18:50:40 --> Router Class Initialized
INFO - 2017-03-12 18:50:40 --> Output Class Initialized
INFO - 2017-03-12 18:50:40 --> Security Class Initialized
DEBUG - 2017-03-12 18:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:50:40 --> Input Class Initialized
INFO - 2017-03-12 18:50:40 --> Language Class Initialized
INFO - 2017-03-12 18:50:40 --> Loader Class Initialized
INFO - 2017-03-12 18:50:40 --> Database Driver Class Initialized
INFO - 2017-03-12 18:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:50:40 --> Controller Class Initialized
INFO - 2017-03-12 18:50:40 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:50:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:50:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 18:50:40 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 18:50:40 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 18:50:40 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 18:50:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:50:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:50:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:50:40 --> Final output sent to browser
DEBUG - 2017-03-12 18:50:40 --> Total execution time: 0.0223
INFO - 2017-03-12 18:50:46 --> Config Class Initialized
INFO - 2017-03-12 18:50:46 --> Hooks Class Initialized
DEBUG - 2017-03-12 18:50:46 --> UTF-8 Support Enabled
INFO - 2017-03-12 18:50:46 --> Utf8 Class Initialized
INFO - 2017-03-12 18:50:46 --> URI Class Initialized
INFO - 2017-03-12 18:50:46 --> Router Class Initialized
INFO - 2017-03-12 18:50:46 --> Output Class Initialized
INFO - 2017-03-12 18:50:46 --> Security Class Initialized
DEBUG - 2017-03-12 18:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 18:50:46 --> Input Class Initialized
INFO - 2017-03-12 18:50:46 --> Language Class Initialized
INFO - 2017-03-12 18:50:46 --> Loader Class Initialized
INFO - 2017-03-12 18:50:46 --> Database Driver Class Initialized
INFO - 2017-03-12 18:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 18:50:46 --> Controller Class Initialized
INFO - 2017-03-12 18:50:46 --> Helper loaded: url_helper
DEBUG - 2017-03-12 18:50:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 18:50:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 18:50:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 18:50:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 18:50:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 18:50:46 --> Final output sent to browser
DEBUG - 2017-03-12 18:50:46 --> Total execution time: 0.0134
INFO - 2017-03-12 19:03:28 --> Config Class Initialized
INFO - 2017-03-12 19:03:28 --> Hooks Class Initialized
DEBUG - 2017-03-12 19:03:28 --> UTF-8 Support Enabled
INFO - 2017-03-12 19:03:28 --> Utf8 Class Initialized
INFO - 2017-03-12 19:03:28 --> URI Class Initialized
INFO - 2017-03-12 19:03:28 --> Router Class Initialized
INFO - 2017-03-12 19:03:28 --> Output Class Initialized
INFO - 2017-03-12 19:03:28 --> Security Class Initialized
DEBUG - 2017-03-12 19:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 19:03:28 --> Input Class Initialized
INFO - 2017-03-12 19:03:28 --> Language Class Initialized
INFO - 2017-03-12 19:03:28 --> Loader Class Initialized
INFO - 2017-03-12 19:03:28 --> Database Driver Class Initialized
INFO - 2017-03-12 19:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 19:03:29 --> Controller Class Initialized
INFO - 2017-03-12 19:03:29 --> Helper loaded: url_helper
DEBUG - 2017-03-12 19:03:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 19:03:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 19:03:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 19:03:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 19:03:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 19:03:29 --> Final output sent to browser
DEBUG - 2017-03-12 19:03:29 --> Total execution time: 1.5390
INFO - 2017-03-12 21:47:14 --> Config Class Initialized
INFO - 2017-03-12 21:47:14 --> Hooks Class Initialized
DEBUG - 2017-03-12 21:47:14 --> UTF-8 Support Enabled
INFO - 2017-03-12 21:47:14 --> Utf8 Class Initialized
INFO - 2017-03-12 21:47:14 --> URI Class Initialized
INFO - 2017-03-12 21:47:14 --> Router Class Initialized
INFO - 2017-03-12 21:47:14 --> Output Class Initialized
INFO - 2017-03-12 21:47:14 --> Security Class Initialized
DEBUG - 2017-03-12 21:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 21:47:14 --> Input Class Initialized
INFO - 2017-03-12 21:47:14 --> Language Class Initialized
INFO - 2017-03-12 21:47:14 --> Loader Class Initialized
INFO - 2017-03-12 21:47:14 --> Database Driver Class Initialized
INFO - 2017-03-12 21:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 21:47:15 --> Controller Class Initialized
INFO - 2017-03-12 21:47:15 --> Helper loaded: url_helper
DEBUG - 2017-03-12 21:47:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 21:47:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-03-12 21:47:15 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-03-12 21:47:15 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-03-12 21:47:15 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-03-12 21:47:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 21:47:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 21:47:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 21:47:15 --> Final output sent to browser
DEBUG - 2017-03-12 21:47:15 --> Total execution time: 1.7293
INFO - 2017-03-12 21:47:18 --> Config Class Initialized
INFO - 2017-03-12 21:47:18 --> Hooks Class Initialized
DEBUG - 2017-03-12 21:47:18 --> UTF-8 Support Enabled
INFO - 2017-03-12 21:47:18 --> Utf8 Class Initialized
INFO - 2017-03-12 21:47:18 --> URI Class Initialized
INFO - 2017-03-12 21:47:18 --> Router Class Initialized
INFO - 2017-03-12 21:47:18 --> Output Class Initialized
INFO - 2017-03-12 21:47:18 --> Security Class Initialized
DEBUG - 2017-03-12 21:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 21:47:18 --> Input Class Initialized
INFO - 2017-03-12 21:47:18 --> Language Class Initialized
INFO - 2017-03-12 21:47:18 --> Loader Class Initialized
INFO - 2017-03-12 21:47:18 --> Database Driver Class Initialized
INFO - 2017-03-12 21:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 21:47:18 --> Controller Class Initialized
INFO - 2017-03-12 21:47:18 --> Helper loaded: url_helper
DEBUG - 2017-03-12 21:47:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 21:47:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 21:47:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 21:47:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 21:47:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 21:47:18 --> Final output sent to browser
DEBUG - 2017-03-12 21:47:18 --> Total execution time: 0.0139
INFO - 2017-03-12 21:47:26 --> Config Class Initialized
INFO - 2017-03-12 21:47:26 --> Hooks Class Initialized
DEBUG - 2017-03-12 21:47:26 --> UTF-8 Support Enabled
INFO - 2017-03-12 21:47:26 --> Utf8 Class Initialized
INFO - 2017-03-12 21:47:26 --> URI Class Initialized
INFO - 2017-03-12 21:47:26 --> Router Class Initialized
INFO - 2017-03-12 21:47:26 --> Output Class Initialized
INFO - 2017-03-12 21:47:26 --> Security Class Initialized
DEBUG - 2017-03-12 21:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 21:47:26 --> Input Class Initialized
INFO - 2017-03-12 21:47:26 --> Language Class Initialized
INFO - 2017-03-12 21:47:26 --> Loader Class Initialized
INFO - 2017-03-12 21:47:26 --> Database Driver Class Initialized
INFO - 2017-03-12 21:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 21:47:26 --> Controller Class Initialized
INFO - 2017-03-12 21:47:26 --> Helper loaded: url_helper
DEBUG - 2017-03-12 21:47:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-12 21:47:27 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-12 21:47:27 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Pa Padilla')
INFO - 2017-03-12 21:47:27 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-12 21:47:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-12 21:47:29 --> Config Class Initialized
INFO - 2017-03-12 21:47:29 --> Hooks Class Initialized
DEBUG - 2017-03-12 21:47:29 --> UTF-8 Support Enabled
INFO - 2017-03-12 21:47:29 --> Utf8 Class Initialized
INFO - 2017-03-12 21:47:29 --> URI Class Initialized
INFO - 2017-03-12 21:47:29 --> Router Class Initialized
INFO - 2017-03-12 21:47:29 --> Output Class Initialized
INFO - 2017-03-12 21:47:29 --> Security Class Initialized
DEBUG - 2017-03-12 21:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 21:47:29 --> Input Class Initialized
INFO - 2017-03-12 21:47:29 --> Language Class Initialized
INFO - 2017-03-12 21:47:29 --> Loader Class Initialized
INFO - 2017-03-12 21:47:29 --> Database Driver Class Initialized
INFO - 2017-03-12 21:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 21:47:29 --> Controller Class Initialized
INFO - 2017-03-12 21:47:29 --> Helper loaded: url_helper
DEBUG - 2017-03-12 21:47:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 21:47:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 21:47:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 21:47:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 21:47:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 21:47:29 --> Final output sent to browser
DEBUG - 2017-03-12 21:47:29 --> Total execution time: 0.0140
INFO - 2017-03-12 21:47:34 --> Config Class Initialized
INFO - 2017-03-12 21:47:34 --> Hooks Class Initialized
DEBUG - 2017-03-12 21:47:34 --> UTF-8 Support Enabled
INFO - 2017-03-12 21:47:34 --> Utf8 Class Initialized
INFO - 2017-03-12 21:47:34 --> URI Class Initialized
INFO - 2017-03-12 21:47:34 --> Router Class Initialized
INFO - 2017-03-12 21:47:34 --> Output Class Initialized
INFO - 2017-03-12 21:47:34 --> Security Class Initialized
DEBUG - 2017-03-12 21:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 21:47:34 --> Input Class Initialized
INFO - 2017-03-12 21:47:34 --> Language Class Initialized
INFO - 2017-03-12 21:47:34 --> Loader Class Initialized
INFO - 2017-03-12 21:47:34 --> Database Driver Class Initialized
INFO - 2017-03-12 21:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 21:47:34 --> Controller Class Initialized
INFO - 2017-03-12 21:47:34 --> Helper loaded: url_helper
DEBUG - 2017-03-12 21:47:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-12 21:47:34 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-12 21:47:34 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Pa Padilla')
INFO - 2017-03-12 21:47:34 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-12 21:47:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-12 21:47:34 --> Config Class Initialized
INFO - 2017-03-12 21:47:34 --> Hooks Class Initialized
DEBUG - 2017-03-12 21:47:34 --> UTF-8 Support Enabled
INFO - 2017-03-12 21:47:34 --> Utf8 Class Initialized
INFO - 2017-03-12 21:47:34 --> URI Class Initialized
INFO - 2017-03-12 21:47:34 --> Router Class Initialized
INFO - 2017-03-12 21:47:34 --> Output Class Initialized
INFO - 2017-03-12 21:47:34 --> Security Class Initialized
DEBUG - 2017-03-12 21:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 21:47:34 --> Input Class Initialized
INFO - 2017-03-12 21:47:34 --> Language Class Initialized
INFO - 2017-03-12 21:47:34 --> Loader Class Initialized
INFO - 2017-03-12 21:47:34 --> Database Driver Class Initialized
INFO - 2017-03-12 21:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 21:47:34 --> Controller Class Initialized
INFO - 2017-03-12 21:47:34 --> Helper loaded: url_helper
DEBUG - 2017-03-12 21:47:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 21:47:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 21:47:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 21:47:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 21:47:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 21:47:34 --> Final output sent to browser
DEBUG - 2017-03-12 21:47:34 --> Total execution time: 0.0137
INFO - 2017-03-12 21:47:35 --> Config Class Initialized
INFO - 2017-03-12 21:47:35 --> Hooks Class Initialized
DEBUG - 2017-03-12 21:47:35 --> UTF-8 Support Enabled
INFO - 2017-03-12 21:47:35 --> Utf8 Class Initialized
INFO - 2017-03-12 21:47:35 --> URI Class Initialized
DEBUG - 2017-03-12 21:47:35 --> No URI present. Default controller set.
INFO - 2017-03-12 21:47:35 --> Router Class Initialized
INFO - 2017-03-12 21:47:35 --> Output Class Initialized
INFO - 2017-03-12 21:47:35 --> Security Class Initialized
DEBUG - 2017-03-12 21:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 21:47:35 --> Input Class Initialized
INFO - 2017-03-12 21:47:35 --> Language Class Initialized
INFO - 2017-03-12 21:47:35 --> Loader Class Initialized
INFO - 2017-03-12 21:47:35 --> Database Driver Class Initialized
INFO - 2017-03-12 21:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 21:47:35 --> Controller Class Initialized
INFO - 2017-03-12 21:47:35 --> Helper loaded: url_helper
DEBUG - 2017-03-12 21:47:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 21:47:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 21:47:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 21:47:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 21:47:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 21:47:35 --> Final output sent to browser
DEBUG - 2017-03-12 21:47:35 --> Total execution time: 0.0461
INFO - 2017-03-12 21:47:37 --> Config Class Initialized
INFO - 2017-03-12 21:47:37 --> Hooks Class Initialized
DEBUG - 2017-03-12 21:47:37 --> UTF-8 Support Enabled
INFO - 2017-03-12 21:47:37 --> Utf8 Class Initialized
INFO - 2017-03-12 21:47:37 --> URI Class Initialized
INFO - 2017-03-12 21:47:37 --> Router Class Initialized
INFO - 2017-03-12 21:47:37 --> Output Class Initialized
INFO - 2017-03-12 21:47:37 --> Security Class Initialized
DEBUG - 2017-03-12 21:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 21:47:37 --> Input Class Initialized
INFO - 2017-03-12 21:47:37 --> Language Class Initialized
INFO - 2017-03-12 21:47:37 --> Loader Class Initialized
INFO - 2017-03-12 21:47:37 --> Database Driver Class Initialized
INFO - 2017-03-12 21:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 21:47:37 --> Controller Class Initialized
INFO - 2017-03-12 21:47:37 --> Helper loaded: url_helper
DEBUG - 2017-03-12 21:47:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 21:47:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 21:47:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 21:47:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 21:47:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 21:47:37 --> Final output sent to browser
DEBUG - 2017-03-12 21:47:37 --> Total execution time: 0.0133
INFO - 2017-03-12 21:48:45 --> Config Class Initialized
INFO - 2017-03-12 21:48:45 --> Hooks Class Initialized
DEBUG - 2017-03-12 21:48:45 --> UTF-8 Support Enabled
INFO - 2017-03-12 21:48:45 --> Utf8 Class Initialized
INFO - 2017-03-12 21:48:45 --> URI Class Initialized
INFO - 2017-03-12 21:48:45 --> Router Class Initialized
INFO - 2017-03-12 21:48:45 --> Output Class Initialized
INFO - 2017-03-12 21:48:45 --> Security Class Initialized
DEBUG - 2017-03-12 21:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 21:48:45 --> Input Class Initialized
INFO - 2017-03-12 21:48:45 --> Language Class Initialized
INFO - 2017-03-12 21:48:45 --> Loader Class Initialized
INFO - 2017-03-12 21:48:46 --> Database Driver Class Initialized
INFO - 2017-03-12 21:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 21:48:46 --> Controller Class Initialized
INFO - 2017-03-12 21:48:46 --> Helper loaded: url_helper
DEBUG - 2017-03-12 21:48:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-12 21:48:47 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-12 21:48:47 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Pa Padilla')
INFO - 2017-03-12 21:48:47 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-12 21:48:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-12 21:48:48 --> Config Class Initialized
INFO - 2017-03-12 21:48:48 --> Hooks Class Initialized
DEBUG - 2017-03-12 21:48:48 --> UTF-8 Support Enabled
INFO - 2017-03-12 21:48:48 --> Utf8 Class Initialized
INFO - 2017-03-12 21:48:48 --> URI Class Initialized
INFO - 2017-03-12 21:48:48 --> Router Class Initialized
INFO - 2017-03-12 21:48:48 --> Output Class Initialized
INFO - 2017-03-12 21:48:48 --> Security Class Initialized
DEBUG - 2017-03-12 21:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 21:48:48 --> Input Class Initialized
INFO - 2017-03-12 21:48:48 --> Language Class Initialized
INFO - 2017-03-12 21:48:48 --> Loader Class Initialized
INFO - 2017-03-12 21:48:48 --> Database Driver Class Initialized
INFO - 2017-03-12 21:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 21:48:48 --> Controller Class Initialized
INFO - 2017-03-12 21:48:48 --> Helper loaded: url_helper
DEBUG - 2017-03-12 21:48:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 21:48:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 21:48:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 21:48:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 21:48:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 21:48:48 --> Final output sent to browser
DEBUG - 2017-03-12 21:48:48 --> Total execution time: 0.2437
INFO - 2017-03-12 21:48:50 --> Config Class Initialized
INFO - 2017-03-12 21:48:50 --> Hooks Class Initialized
DEBUG - 2017-03-12 21:48:50 --> UTF-8 Support Enabled
INFO - 2017-03-12 21:48:50 --> Utf8 Class Initialized
INFO - 2017-03-12 21:48:50 --> URI Class Initialized
INFO - 2017-03-12 21:48:50 --> Router Class Initialized
INFO - 2017-03-12 21:48:50 --> Output Class Initialized
INFO - 2017-03-12 21:48:50 --> Security Class Initialized
DEBUG - 2017-03-12 21:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 21:48:50 --> Input Class Initialized
INFO - 2017-03-12 21:48:50 --> Language Class Initialized
INFO - 2017-03-12 21:48:50 --> Loader Class Initialized
INFO - 2017-03-12 21:48:50 --> Database Driver Class Initialized
INFO - 2017-03-12 21:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 21:48:50 --> Controller Class Initialized
INFO - 2017-03-12 21:48:50 --> Helper loaded: url_helper
DEBUG - 2017-03-12 21:48:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-12 21:48:50 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-12 21:48:50 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Pa Padilla')
INFO - 2017-03-12 21:48:50 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-12 21:48:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-12 21:48:51 --> Config Class Initialized
INFO - 2017-03-12 21:48:51 --> Hooks Class Initialized
DEBUG - 2017-03-12 21:48:51 --> UTF-8 Support Enabled
INFO - 2017-03-12 21:48:51 --> Utf8 Class Initialized
INFO - 2017-03-12 21:48:51 --> URI Class Initialized
INFO - 2017-03-12 21:48:51 --> Router Class Initialized
INFO - 2017-03-12 21:48:51 --> Output Class Initialized
INFO - 2017-03-12 21:48:51 --> Security Class Initialized
DEBUG - 2017-03-12 21:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 21:48:51 --> Input Class Initialized
INFO - 2017-03-12 21:48:51 --> Language Class Initialized
INFO - 2017-03-12 21:48:51 --> Loader Class Initialized
INFO - 2017-03-12 21:48:51 --> Database Driver Class Initialized
INFO - 2017-03-12 21:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 21:48:51 --> Controller Class Initialized
INFO - 2017-03-12 21:48:51 --> Helper loaded: url_helper
DEBUG - 2017-03-12 21:48:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 21:48:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 21:48:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 21:48:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 21:48:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 21:48:51 --> Final output sent to browser
DEBUG - 2017-03-12 21:48:51 --> Total execution time: 0.0138
INFO - 2017-03-12 22:41:54 --> Config Class Initialized
INFO - 2017-03-12 22:41:54 --> Hooks Class Initialized
DEBUG - 2017-03-12 22:41:54 --> UTF-8 Support Enabled
INFO - 2017-03-12 22:41:54 --> Utf8 Class Initialized
INFO - 2017-03-12 22:41:54 --> URI Class Initialized
DEBUG - 2017-03-12 22:41:54 --> No URI present. Default controller set.
INFO - 2017-03-12 22:41:54 --> Router Class Initialized
INFO - 2017-03-12 22:41:54 --> Output Class Initialized
INFO - 2017-03-12 22:41:54 --> Security Class Initialized
DEBUG - 2017-03-12 22:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 22:41:54 --> Input Class Initialized
INFO - 2017-03-12 22:41:54 --> Language Class Initialized
INFO - 2017-03-12 22:41:54 --> Loader Class Initialized
INFO - 2017-03-12 22:41:54 --> Database Driver Class Initialized
INFO - 2017-03-12 22:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 22:41:55 --> Controller Class Initialized
INFO - 2017-03-12 22:41:55 --> Helper loaded: url_helper
DEBUG - 2017-03-12 22:41:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 22:41:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 22:41:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 22:41:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 22:41:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 22:41:55 --> Final output sent to browser
DEBUG - 2017-03-12 22:41:55 --> Total execution time: 1.5177
INFO - 2017-03-12 22:42:01 --> Config Class Initialized
INFO - 2017-03-12 22:42:01 --> Hooks Class Initialized
DEBUG - 2017-03-12 22:42:01 --> UTF-8 Support Enabled
INFO - 2017-03-12 22:42:01 --> Utf8 Class Initialized
INFO - 2017-03-12 22:42:01 --> URI Class Initialized
INFO - 2017-03-12 22:42:01 --> Router Class Initialized
INFO - 2017-03-12 22:42:01 --> Output Class Initialized
INFO - 2017-03-12 22:42:01 --> Security Class Initialized
DEBUG - 2017-03-12 22:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 22:42:01 --> Input Class Initialized
INFO - 2017-03-12 22:42:01 --> Language Class Initialized
INFO - 2017-03-12 22:42:01 --> Loader Class Initialized
INFO - 2017-03-12 22:42:01 --> Database Driver Class Initialized
INFO - 2017-03-12 22:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 22:42:01 --> Controller Class Initialized
INFO - 2017-03-12 22:42:01 --> Helper loaded: url_helper
DEBUG - 2017-03-12 22:42:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 22:42:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 22:42:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 22:42:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 22:42:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 22:42:01 --> Final output sent to browser
DEBUG - 2017-03-12 22:42:01 --> Total execution time: 0.0163
INFO - 2017-03-12 22:59:06 --> Config Class Initialized
INFO - 2017-03-12 22:59:06 --> Hooks Class Initialized
DEBUG - 2017-03-12 22:59:06 --> UTF-8 Support Enabled
INFO - 2017-03-12 22:59:06 --> Utf8 Class Initialized
INFO - 2017-03-12 22:59:06 --> URI Class Initialized
DEBUG - 2017-03-12 22:59:07 --> No URI present. Default controller set.
INFO - 2017-03-12 22:59:07 --> Router Class Initialized
INFO - 2017-03-12 22:59:07 --> Output Class Initialized
INFO - 2017-03-12 22:59:07 --> Security Class Initialized
DEBUG - 2017-03-12 22:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 22:59:07 --> Input Class Initialized
INFO - 2017-03-12 22:59:07 --> Language Class Initialized
INFO - 2017-03-12 22:59:07 --> Loader Class Initialized
INFO - 2017-03-12 22:59:07 --> Database Driver Class Initialized
INFO - 2017-03-12 22:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 22:59:07 --> Controller Class Initialized
INFO - 2017-03-12 22:59:07 --> Helper loaded: url_helper
DEBUG - 2017-03-12 22:59:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 22:59:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 22:59:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 22:59:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 22:59:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 22:59:08 --> Final output sent to browser
DEBUG - 2017-03-12 22:59:08 --> Total execution time: 1.4711
INFO - 2017-03-12 22:59:13 --> Config Class Initialized
INFO - 2017-03-12 22:59:13 --> Hooks Class Initialized
DEBUG - 2017-03-12 22:59:13 --> UTF-8 Support Enabled
INFO - 2017-03-12 22:59:13 --> Utf8 Class Initialized
INFO - 2017-03-12 22:59:13 --> URI Class Initialized
INFO - 2017-03-12 22:59:13 --> Router Class Initialized
INFO - 2017-03-12 22:59:13 --> Output Class Initialized
INFO - 2017-03-12 22:59:13 --> Security Class Initialized
DEBUG - 2017-03-12 22:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 22:59:13 --> Input Class Initialized
INFO - 2017-03-12 22:59:13 --> Language Class Initialized
INFO - 2017-03-12 22:59:13 --> Loader Class Initialized
INFO - 2017-03-12 22:59:14 --> Database Driver Class Initialized
INFO - 2017-03-12 22:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 22:59:14 --> Controller Class Initialized
INFO - 2017-03-12 22:59:14 --> Helper loaded: url_helper
DEBUG - 2017-03-12 22:59:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 22:59:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 22:59:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 22:59:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 22:59:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 22:59:14 --> Final output sent to browser
DEBUG - 2017-03-12 22:59:14 --> Total execution time: 1.2222
INFO - 2017-03-12 22:59:28 --> Config Class Initialized
INFO - 2017-03-12 22:59:28 --> Hooks Class Initialized
DEBUG - 2017-03-12 22:59:28 --> UTF-8 Support Enabled
INFO - 2017-03-12 22:59:28 --> Utf8 Class Initialized
INFO - 2017-03-12 22:59:28 --> URI Class Initialized
INFO - 2017-03-12 22:59:28 --> Router Class Initialized
INFO - 2017-03-12 22:59:28 --> Output Class Initialized
INFO - 2017-03-12 22:59:28 --> Security Class Initialized
DEBUG - 2017-03-12 22:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 22:59:28 --> Input Class Initialized
INFO - 2017-03-12 22:59:28 --> Language Class Initialized
INFO - 2017-03-12 22:59:28 --> Loader Class Initialized
INFO - 2017-03-12 22:59:28 --> Database Driver Class Initialized
INFO - 2017-03-12 22:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 22:59:28 --> Controller Class Initialized
INFO - 2017-03-12 22:59:28 --> Helper loaded: url_helper
DEBUG - 2017-03-12 22:59:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 22:59:29 --> Config Class Initialized
INFO - 2017-03-12 22:59:29 --> Hooks Class Initialized
DEBUG - 2017-03-12 22:59:29 --> UTF-8 Support Enabled
INFO - 2017-03-12 22:59:29 --> Utf8 Class Initialized
INFO - 2017-03-12 22:59:29 --> URI Class Initialized
INFO - 2017-03-12 22:59:29 --> Router Class Initialized
INFO - 2017-03-12 22:59:29 --> Output Class Initialized
INFO - 2017-03-12 22:59:29 --> Security Class Initialized
DEBUG - 2017-03-12 22:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 22:59:29 --> Input Class Initialized
INFO - 2017-03-12 22:59:29 --> Language Class Initialized
INFO - 2017-03-12 22:59:29 --> Loader Class Initialized
INFO - 2017-03-12 22:59:29 --> Database Driver Class Initialized
INFO - 2017-03-12 22:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 22:59:29 --> Controller Class Initialized
INFO - 2017-03-12 22:59:29 --> Helper loaded: date_helper
DEBUG - 2017-03-12 22:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 22:59:29 --> Helper loaded: url_helper
INFO - 2017-03-12 22:59:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 22:59:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-03-12 22:59:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-03-12 22:59:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 22:59:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 22:59:30 --> Final output sent to browser
DEBUG - 2017-03-12 22:59:30 --> Total execution time: 0.3483
INFO - 2017-03-12 22:59:32 --> Config Class Initialized
INFO - 2017-03-12 22:59:32 --> Hooks Class Initialized
DEBUG - 2017-03-12 22:59:32 --> UTF-8 Support Enabled
INFO - 2017-03-12 22:59:32 --> Utf8 Class Initialized
INFO - 2017-03-12 22:59:32 --> URI Class Initialized
INFO - 2017-03-12 22:59:32 --> Router Class Initialized
INFO - 2017-03-12 22:59:32 --> Output Class Initialized
INFO - 2017-03-12 22:59:32 --> Security Class Initialized
DEBUG - 2017-03-12 22:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 22:59:32 --> Input Class Initialized
INFO - 2017-03-12 22:59:32 --> Language Class Initialized
INFO - 2017-03-12 22:59:32 --> Loader Class Initialized
INFO - 2017-03-12 22:59:32 --> Database Driver Class Initialized
INFO - 2017-03-12 22:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 22:59:32 --> Controller Class Initialized
INFO - 2017-03-12 22:59:32 --> Helper loaded: url_helper
DEBUG - 2017-03-12 22:59:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 22:59:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 22:59:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 22:59:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 22:59:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 22:59:32 --> Final output sent to browser
DEBUG - 2017-03-12 22:59:32 --> Total execution time: 0.0134
INFO - 2017-03-12 23:01:52 --> Config Class Initialized
INFO - 2017-03-12 23:01:52 --> Hooks Class Initialized
DEBUG - 2017-03-12 23:01:52 --> UTF-8 Support Enabled
INFO - 2017-03-12 23:01:52 --> Utf8 Class Initialized
INFO - 2017-03-12 23:01:52 --> URI Class Initialized
DEBUG - 2017-03-12 23:01:53 --> No URI present. Default controller set.
INFO - 2017-03-12 23:01:53 --> Router Class Initialized
INFO - 2017-03-12 23:01:53 --> Output Class Initialized
INFO - 2017-03-12 23:01:53 --> Security Class Initialized
DEBUG - 2017-03-12 23:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 23:01:53 --> Input Class Initialized
INFO - 2017-03-12 23:01:53 --> Language Class Initialized
INFO - 2017-03-12 23:01:53 --> Loader Class Initialized
INFO - 2017-03-12 23:01:53 --> Database Driver Class Initialized
INFO - 2017-03-12 23:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 23:01:53 --> Controller Class Initialized
INFO - 2017-03-12 23:01:53 --> Helper loaded: url_helper
DEBUG - 2017-03-12 23:01:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 23:01:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 23:01:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 23:01:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 23:01:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 23:01:54 --> Final output sent to browser
DEBUG - 2017-03-12 23:01:54 --> Total execution time: 1.2344
INFO - 2017-03-12 23:01:55 --> Config Class Initialized
INFO - 2017-03-12 23:01:55 --> Hooks Class Initialized
DEBUG - 2017-03-12 23:01:55 --> UTF-8 Support Enabled
INFO - 2017-03-12 23:01:55 --> Utf8 Class Initialized
INFO - 2017-03-12 23:01:55 --> URI Class Initialized
INFO - 2017-03-12 23:01:55 --> Router Class Initialized
INFO - 2017-03-12 23:01:55 --> Output Class Initialized
INFO - 2017-03-12 23:01:55 --> Security Class Initialized
DEBUG - 2017-03-12 23:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 23:01:55 --> Input Class Initialized
INFO - 2017-03-12 23:01:55 --> Language Class Initialized
INFO - 2017-03-12 23:01:55 --> Loader Class Initialized
INFO - 2017-03-12 23:01:55 --> Database Driver Class Initialized
INFO - 2017-03-12 23:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 23:01:55 --> Controller Class Initialized
INFO - 2017-03-12 23:01:55 --> Helper loaded: url_helper
DEBUG - 2017-03-12 23:01:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 23:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 23:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 23:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 23:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 23:01:55 --> Final output sent to browser
DEBUG - 2017-03-12 23:01:55 --> Total execution time: 0.0137
INFO - 2017-03-12 23:17:04 --> Config Class Initialized
INFO - 2017-03-12 23:17:04 --> Hooks Class Initialized
DEBUG - 2017-03-12 23:17:04 --> UTF-8 Support Enabled
INFO - 2017-03-12 23:17:05 --> Utf8 Class Initialized
INFO - 2017-03-12 23:17:05 --> URI Class Initialized
INFO - 2017-03-12 23:17:05 --> Router Class Initialized
INFO - 2017-03-12 23:17:05 --> Output Class Initialized
INFO - 2017-03-12 23:17:05 --> Security Class Initialized
DEBUG - 2017-03-12 23:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 23:17:05 --> Input Class Initialized
INFO - 2017-03-12 23:17:05 --> Language Class Initialized
INFO - 2017-03-12 23:17:05 --> Loader Class Initialized
INFO - 2017-03-12 23:17:05 --> Database Driver Class Initialized
INFO - 2017-03-12 23:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 23:17:06 --> Controller Class Initialized
INFO - 2017-03-12 23:17:06 --> Helper loaded: url_helper
DEBUG - 2017-03-12 23:17:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-03-12 23:17:07 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-03-12 23:17:07 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Pa Padilla')
INFO - 2017-03-12 23:17:07 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-03-12 23:17:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-03-12 23:17:08 --> Config Class Initialized
INFO - 2017-03-12 23:17:08 --> Hooks Class Initialized
DEBUG - 2017-03-12 23:17:08 --> UTF-8 Support Enabled
INFO - 2017-03-12 23:17:08 --> Utf8 Class Initialized
INFO - 2017-03-12 23:17:08 --> URI Class Initialized
INFO - 2017-03-12 23:17:08 --> Router Class Initialized
INFO - 2017-03-12 23:17:08 --> Output Class Initialized
INFO - 2017-03-12 23:17:08 --> Security Class Initialized
DEBUG - 2017-03-12 23:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 23:17:08 --> Input Class Initialized
INFO - 2017-03-12 23:17:08 --> Language Class Initialized
INFO - 2017-03-12 23:17:08 --> Loader Class Initialized
INFO - 2017-03-12 23:17:08 --> Database Driver Class Initialized
INFO - 2017-03-12 23:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 23:17:08 --> Controller Class Initialized
INFO - 2017-03-12 23:17:08 --> Helper loaded: url_helper
DEBUG - 2017-03-12 23:17:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 23:17:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 23:17:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 23:17:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 23:17:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 23:17:08 --> Final output sent to browser
DEBUG - 2017-03-12 23:17:08 --> Total execution time: 0.1702
INFO - 2017-03-12 23:44:00 --> Config Class Initialized
INFO - 2017-03-12 23:44:00 --> Hooks Class Initialized
DEBUG - 2017-03-12 23:44:00 --> UTF-8 Support Enabled
INFO - 2017-03-12 23:44:00 --> Utf8 Class Initialized
INFO - 2017-03-12 23:44:00 --> URI Class Initialized
DEBUG - 2017-03-12 23:44:00 --> No URI present. Default controller set.
INFO - 2017-03-12 23:44:00 --> Router Class Initialized
INFO - 2017-03-12 23:44:00 --> Output Class Initialized
INFO - 2017-03-12 23:44:00 --> Security Class Initialized
DEBUG - 2017-03-12 23:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 23:44:00 --> Input Class Initialized
INFO - 2017-03-12 23:44:00 --> Language Class Initialized
INFO - 2017-03-12 23:44:00 --> Loader Class Initialized
INFO - 2017-03-12 23:44:00 --> Database Driver Class Initialized
INFO - 2017-03-12 23:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 23:44:01 --> Controller Class Initialized
INFO - 2017-03-12 23:44:01 --> Helper loaded: url_helper
DEBUG - 2017-03-12 23:44:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 23:44:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 23:44:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 23:44:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 23:44:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 23:44:01 --> Final output sent to browser
DEBUG - 2017-03-12 23:44:01 --> Total execution time: 1.4870
INFO - 2017-03-12 23:44:05 --> Config Class Initialized
INFO - 2017-03-12 23:44:05 --> Hooks Class Initialized
DEBUG - 2017-03-12 23:44:05 --> UTF-8 Support Enabled
INFO - 2017-03-12 23:44:05 --> Utf8 Class Initialized
INFO - 2017-03-12 23:44:05 --> URI Class Initialized
INFO - 2017-03-12 23:44:05 --> Router Class Initialized
INFO - 2017-03-12 23:44:05 --> Output Class Initialized
INFO - 2017-03-12 23:44:05 --> Security Class Initialized
DEBUG - 2017-03-12 23:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 23:44:05 --> Input Class Initialized
INFO - 2017-03-12 23:44:05 --> Language Class Initialized
INFO - 2017-03-12 23:44:05 --> Loader Class Initialized
INFO - 2017-03-12 23:44:05 --> Database Driver Class Initialized
INFO - 2017-03-12 23:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 23:44:05 --> Controller Class Initialized
INFO - 2017-03-12 23:44:05 --> Helper loaded: url_helper
DEBUG - 2017-03-12 23:44:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 23:44:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 23:44:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 23:44:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 23:44:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 23:44:05 --> Final output sent to browser
DEBUG - 2017-03-12 23:44:05 --> Total execution time: 0.0141
INFO - 2017-03-12 23:45:38 --> Config Class Initialized
INFO - 2017-03-12 23:45:38 --> Hooks Class Initialized
DEBUG - 2017-03-12 23:45:38 --> UTF-8 Support Enabled
INFO - 2017-03-12 23:45:38 --> Utf8 Class Initialized
INFO - 2017-03-12 23:45:38 --> URI Class Initialized
DEBUG - 2017-03-12 23:45:38 --> No URI present. Default controller set.
INFO - 2017-03-12 23:45:38 --> Router Class Initialized
INFO - 2017-03-12 23:45:38 --> Output Class Initialized
INFO - 2017-03-12 23:45:38 --> Security Class Initialized
DEBUG - 2017-03-12 23:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 23:45:38 --> Input Class Initialized
INFO - 2017-03-12 23:45:38 --> Language Class Initialized
INFO - 2017-03-12 23:45:38 --> Loader Class Initialized
INFO - 2017-03-12 23:45:38 --> Database Driver Class Initialized
INFO - 2017-03-12 23:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 23:45:38 --> Controller Class Initialized
INFO - 2017-03-12 23:45:38 --> Helper loaded: url_helper
DEBUG - 2017-03-12 23:45:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 23:45:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 23:45:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 23:45:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 23:45:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 23:45:38 --> Final output sent to browser
DEBUG - 2017-03-12 23:45:38 --> Total execution time: 0.3455
INFO - 2017-03-12 23:46:51 --> Config Class Initialized
INFO - 2017-03-12 23:46:51 --> Hooks Class Initialized
DEBUG - 2017-03-12 23:46:51 --> UTF-8 Support Enabled
INFO - 2017-03-12 23:46:51 --> Utf8 Class Initialized
INFO - 2017-03-12 23:46:51 --> URI Class Initialized
INFO - 2017-03-12 23:46:51 --> Router Class Initialized
INFO - 2017-03-12 23:46:52 --> Output Class Initialized
INFO - 2017-03-12 23:46:52 --> Security Class Initialized
DEBUG - 2017-03-12 23:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 23:46:52 --> Input Class Initialized
INFO - 2017-03-12 23:46:52 --> Language Class Initialized
INFO - 2017-03-12 23:46:52 --> Loader Class Initialized
INFO - 2017-03-12 23:46:52 --> Database Driver Class Initialized
INFO - 2017-03-12 23:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 23:46:52 --> Controller Class Initialized
INFO - 2017-03-12 23:46:52 --> Helper loaded: url_helper
DEBUG - 2017-03-12 23:46:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 23:46:54 --> Config Class Initialized
INFO - 2017-03-12 23:46:54 --> Hooks Class Initialized
DEBUG - 2017-03-12 23:46:54 --> UTF-8 Support Enabled
INFO - 2017-03-12 23:46:54 --> Utf8 Class Initialized
INFO - 2017-03-12 23:46:54 --> URI Class Initialized
INFO - 2017-03-12 23:46:54 --> Router Class Initialized
INFO - 2017-03-12 23:46:54 --> Output Class Initialized
INFO - 2017-03-12 23:46:54 --> Security Class Initialized
DEBUG - 2017-03-12 23:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 23:46:54 --> Input Class Initialized
INFO - 2017-03-12 23:46:54 --> Language Class Initialized
INFO - 2017-03-12 23:46:54 --> Loader Class Initialized
INFO - 2017-03-12 23:46:54 --> Database Driver Class Initialized
INFO - 2017-03-12 23:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 23:46:54 --> Controller Class Initialized
INFO - 2017-03-12 23:46:54 --> Helper loaded: date_helper
DEBUG - 2017-03-12 23:46:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 23:46:54 --> Helper loaded: url_helper
INFO - 2017-03-12 23:46:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 23:46:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-03-12 23:46:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-03-12 23:46:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-03-12 23:46:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 23:46:54 --> Final output sent to browser
DEBUG - 2017-03-12 23:46:54 --> Total execution time: 0.1156
INFO - 2017-03-12 23:47:03 --> Config Class Initialized
INFO - 2017-03-12 23:47:03 --> Hooks Class Initialized
DEBUG - 2017-03-12 23:47:03 --> UTF-8 Support Enabled
INFO - 2017-03-12 23:47:03 --> Utf8 Class Initialized
INFO - 2017-03-12 23:47:03 --> URI Class Initialized
DEBUG - 2017-03-12 23:47:03 --> No URI present. Default controller set.
INFO - 2017-03-12 23:47:03 --> Router Class Initialized
INFO - 2017-03-12 23:47:03 --> Output Class Initialized
INFO - 2017-03-12 23:47:03 --> Security Class Initialized
DEBUG - 2017-03-12 23:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-12 23:47:03 --> Input Class Initialized
INFO - 2017-03-12 23:47:03 --> Language Class Initialized
INFO - 2017-03-12 23:47:03 --> Loader Class Initialized
INFO - 2017-03-12 23:47:03 --> Database Driver Class Initialized
INFO - 2017-03-12 23:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-12 23:47:03 --> Controller Class Initialized
INFO - 2017-03-12 23:47:03 --> Helper loaded: url_helper
DEBUG - 2017-03-12 23:47:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-12 23:47:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-03-12 23:47:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-03-12 23:47:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-03-12 23:47:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-03-12 23:47:04 --> Final output sent to browser
DEBUG - 2017-03-12 23:47:04 --> Total execution time: 0.1476

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-18 00:00:39 --> Config Class Initialized
INFO - 2017-01-18 00:00:39 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:00:39 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:00:39 --> Utf8 Class Initialized
INFO - 2017-01-18 00:00:39 --> URI Class Initialized
INFO - 2017-01-18 00:00:39 --> Router Class Initialized
INFO - 2017-01-18 00:00:39 --> Output Class Initialized
INFO - 2017-01-18 00:00:39 --> Security Class Initialized
DEBUG - 2017-01-18 00:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:00:39 --> Input Class Initialized
INFO - 2017-01-18 00:00:39 --> Language Class Initialized
INFO - 2017-01-18 00:00:39 --> Loader Class Initialized
INFO - 2017-01-18 00:00:39 --> Database Driver Class Initialized
INFO - 2017-01-18 00:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:00:39 --> Controller Class Initialized
INFO - 2017-01-18 00:00:39 --> Upload Class Initialized
INFO - 2017-01-18 00:00:39 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:00:39 --> Helper loaded: form_helper
INFO - 2017-01-18 00:00:39 --> Form Validation Class Initialized
INFO - 2017-01-18 00:00:39 --> Final output sent to browser
DEBUG - 2017-01-18 00:00:39 --> Total execution time: 0.0204
INFO - 2017-01-18 00:00:39 --> Config Class Initialized
INFO - 2017-01-18 00:00:39 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:00:39 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:00:39 --> Utf8 Class Initialized
INFO - 2017-01-18 00:00:39 --> URI Class Initialized
INFO - 2017-01-18 00:00:39 --> Router Class Initialized
INFO - 2017-01-18 00:00:39 --> Output Class Initialized
INFO - 2017-01-18 00:00:39 --> Security Class Initialized
DEBUG - 2017-01-18 00:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:00:39 --> Input Class Initialized
INFO - 2017-01-18 00:00:39 --> Language Class Initialized
INFO - 2017-01-18 00:00:39 --> Loader Class Initialized
INFO - 2017-01-18 00:00:39 --> Database Driver Class Initialized
INFO - 2017-01-18 00:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:00:39 --> Controller Class Initialized
INFO - 2017-01-18 00:00:39 --> Upload Class Initialized
INFO - 2017-01-18 00:00:39 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:00:39 --> Helper loaded: form_helper
INFO - 2017-01-18 00:00:39 --> Form Validation Class Initialized
INFO - 2017-01-18 00:00:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-18 00:00:39 --> Final output sent to browser
DEBUG - 2017-01-18 00:00:39 --> Total execution time: 0.0153
INFO - 2017-01-18 00:07:35 --> Config Class Initialized
INFO - 2017-01-18 00:07:35 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:07:35 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:07:35 --> Utf8 Class Initialized
INFO - 2017-01-18 00:07:35 --> URI Class Initialized
INFO - 2017-01-18 00:07:35 --> Router Class Initialized
INFO - 2017-01-18 00:07:35 --> Output Class Initialized
INFO - 2017-01-18 00:07:35 --> Security Class Initialized
DEBUG - 2017-01-18 00:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:07:35 --> Input Class Initialized
INFO - 2017-01-18 00:07:35 --> Language Class Initialized
INFO - 2017-01-18 00:07:35 --> Loader Class Initialized
INFO - 2017-01-18 00:07:35 --> Database Driver Class Initialized
INFO - 2017-01-18 00:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:07:35 --> Controller Class Initialized
INFO - 2017-01-18 00:07:35 --> Upload Class Initialized
INFO - 2017-01-18 00:07:35 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:07:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:07:35 --> Helper loaded: form_helper
INFO - 2017-01-18 00:07:35 --> Form Validation Class Initialized
INFO - 2017-01-18 00:07:35 --> Final output sent to browser
DEBUG - 2017-01-18 00:07:35 --> Total execution time: 0.0274
INFO - 2017-01-18 00:07:35 --> Config Class Initialized
INFO - 2017-01-18 00:07:35 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:07:35 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:07:35 --> Utf8 Class Initialized
INFO - 2017-01-18 00:07:35 --> URI Class Initialized
INFO - 2017-01-18 00:07:35 --> Router Class Initialized
INFO - 2017-01-18 00:07:35 --> Output Class Initialized
INFO - 2017-01-18 00:07:35 --> Security Class Initialized
DEBUG - 2017-01-18 00:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:07:35 --> Input Class Initialized
INFO - 2017-01-18 00:07:35 --> Language Class Initialized
INFO - 2017-01-18 00:07:35 --> Loader Class Initialized
INFO - 2017-01-18 00:07:35 --> Database Driver Class Initialized
INFO - 2017-01-18 00:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:07:35 --> Controller Class Initialized
INFO - 2017-01-18 00:07:35 --> Upload Class Initialized
INFO - 2017-01-18 00:07:35 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:07:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:07:35 --> Helper loaded: form_helper
INFO - 2017-01-18 00:07:35 --> Form Validation Class Initialized
INFO - 2017-01-18 00:07:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-18 00:07:35 --> Final output sent to browser
DEBUG - 2017-01-18 00:07:35 --> Total execution time: 0.0151
INFO - 2017-01-18 00:10:02 --> Config Class Initialized
INFO - 2017-01-18 00:10:02 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:10:02 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:10:02 --> Utf8 Class Initialized
INFO - 2017-01-18 00:10:02 --> URI Class Initialized
INFO - 2017-01-18 00:10:02 --> Router Class Initialized
INFO - 2017-01-18 00:10:02 --> Output Class Initialized
INFO - 2017-01-18 00:10:02 --> Security Class Initialized
DEBUG - 2017-01-18 00:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:10:02 --> Input Class Initialized
INFO - 2017-01-18 00:10:02 --> Language Class Initialized
INFO - 2017-01-18 00:10:02 --> Loader Class Initialized
INFO - 2017-01-18 00:10:02 --> Database Driver Class Initialized
INFO - 2017-01-18 00:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:10:02 --> Controller Class Initialized
INFO - 2017-01-18 00:10:02 --> Helper loaded: date_helper
DEBUG - 2017-01-18 00:10:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:10:02 --> Helper loaded: url_helper
INFO - 2017-01-18 00:10:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 00:10:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-18 00:10:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-18 00:10:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-18 00:10:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 00:10:02 --> Final output sent to browser
DEBUG - 2017-01-18 00:10:02 --> Total execution time: 0.0152
INFO - 2017-01-18 00:10:50 --> Config Class Initialized
INFO - 2017-01-18 00:10:50 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:10:50 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:10:50 --> Utf8 Class Initialized
INFO - 2017-01-18 00:10:50 --> URI Class Initialized
INFO - 2017-01-18 00:10:50 --> Router Class Initialized
INFO - 2017-01-18 00:10:50 --> Output Class Initialized
INFO - 2017-01-18 00:10:50 --> Security Class Initialized
DEBUG - 2017-01-18 00:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:10:50 --> Input Class Initialized
INFO - 2017-01-18 00:10:50 --> Language Class Initialized
INFO - 2017-01-18 00:10:50 --> Loader Class Initialized
INFO - 2017-01-18 00:10:50 --> Database Driver Class Initialized
INFO - 2017-01-18 00:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:10:50 --> Controller Class Initialized
INFO - 2017-01-18 00:10:50 --> Upload Class Initialized
INFO - 2017-01-18 00:10:50 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:10:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:10:50 --> Helper loaded: form_helper
INFO - 2017-01-18 00:10:50 --> Form Validation Class Initialized
INFO - 2017-01-18 00:10:50 --> Final output sent to browser
DEBUG - 2017-01-18 00:10:50 --> Total execution time: 0.0248
INFO - 2017-01-18 00:11:25 --> Config Class Initialized
INFO - 2017-01-18 00:11:25 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:11:25 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:11:25 --> Utf8 Class Initialized
INFO - 2017-01-18 00:11:25 --> URI Class Initialized
INFO - 2017-01-18 00:11:25 --> Router Class Initialized
INFO - 2017-01-18 00:11:25 --> Output Class Initialized
INFO - 2017-01-18 00:11:25 --> Security Class Initialized
DEBUG - 2017-01-18 00:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:11:25 --> Input Class Initialized
INFO - 2017-01-18 00:11:25 --> Language Class Initialized
INFO - 2017-01-18 00:11:25 --> Loader Class Initialized
INFO - 2017-01-18 00:11:25 --> Database Driver Class Initialized
INFO - 2017-01-18 00:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:11:25 --> Controller Class Initialized
INFO - 2017-01-18 00:11:25 --> Upload Class Initialized
INFO - 2017-01-18 00:11:25 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:11:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:11:25 --> Helper loaded: form_helper
INFO - 2017-01-18 00:11:25 --> Form Validation Class Initialized
INFO - 2017-01-18 00:11:25 --> Final output sent to browser
DEBUG - 2017-01-18 00:11:25 --> Total execution time: 0.0174
INFO - 2017-01-18 00:11:26 --> Config Class Initialized
INFO - 2017-01-18 00:11:26 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:11:26 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:11:26 --> Utf8 Class Initialized
INFO - 2017-01-18 00:11:26 --> URI Class Initialized
INFO - 2017-01-18 00:11:26 --> Router Class Initialized
INFO - 2017-01-18 00:11:26 --> Output Class Initialized
INFO - 2017-01-18 00:11:26 --> Security Class Initialized
DEBUG - 2017-01-18 00:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:11:26 --> Input Class Initialized
INFO - 2017-01-18 00:11:26 --> Language Class Initialized
INFO - 2017-01-18 00:11:26 --> Loader Class Initialized
INFO - 2017-01-18 00:11:26 --> Database Driver Class Initialized
INFO - 2017-01-18 00:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:11:26 --> Controller Class Initialized
INFO - 2017-01-18 00:11:26 --> Upload Class Initialized
INFO - 2017-01-18 00:11:26 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:11:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:11:26 --> Helper loaded: form_helper
INFO - 2017-01-18 00:11:26 --> Form Validation Class Initialized
INFO - 2017-01-18 00:11:26 --> Final output sent to browser
DEBUG - 2017-01-18 00:11:26 --> Total execution time: 0.0154
INFO - 2017-01-18 00:11:47 --> Config Class Initialized
INFO - 2017-01-18 00:11:47 --> Hooks Class Initialized
INFO - 2017-01-18 00:11:47 --> Config Class Initialized
INFO - 2017-01-18 00:11:47 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:11:47 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:11:47 --> Utf8 Class Initialized
INFO - 2017-01-18 00:11:47 --> URI Class Initialized
INFO - 2017-01-18 00:11:47 --> Router Class Initialized
INFO - 2017-01-18 00:11:47 --> Output Class Initialized
INFO - 2017-01-18 00:11:47 --> Security Class Initialized
DEBUG - 2017-01-18 00:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:11:47 --> Input Class Initialized
INFO - 2017-01-18 00:11:47 --> Language Class Initialized
INFO - 2017-01-18 00:11:47 --> Loader Class Initialized
INFO - 2017-01-18 00:11:47 --> Database Driver Class Initialized
DEBUG - 2017-01-18 00:11:47 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:11:47 --> Utf8 Class Initialized
INFO - 2017-01-18 00:11:47 --> URI Class Initialized
INFO - 2017-01-18 00:11:47 --> Router Class Initialized
INFO - 2017-01-18 00:11:47 --> Output Class Initialized
INFO - 2017-01-18 00:11:47 --> Security Class Initialized
DEBUG - 2017-01-18 00:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:11:47 --> Input Class Initialized
INFO - 2017-01-18 00:11:47 --> Language Class Initialized
INFO - 2017-01-18 00:11:47 --> Loader Class Initialized
INFO - 2017-01-18 00:11:47 --> Database Driver Class Initialized
INFO - 2017-01-18 00:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:11:47 --> Controller Class Initialized
INFO - 2017-01-18 00:11:47 --> Upload Class Initialized
INFO - 2017-01-18 00:11:47 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:11:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:11:47 --> Helper loaded: form_helper
INFO - 2017-01-18 00:11:47 --> Form Validation Class Initialized
INFO - 2017-01-18 00:11:47 --> Final output sent to browser
DEBUG - 2017-01-18 00:11:47 --> Total execution time: 0.0288
INFO - 2017-01-18 00:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:11:47 --> Controller Class Initialized
INFO - 2017-01-18 00:11:47 --> Upload Class Initialized
INFO - 2017-01-18 00:11:47 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:11:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:11:47 --> Helper loaded: form_helper
INFO - 2017-01-18 00:11:47 --> Form Validation Class Initialized
INFO - 2017-01-18 00:11:47 --> Final output sent to browser
DEBUG - 2017-01-18 00:11:47 --> Total execution time: 0.1126
INFO - 2017-01-18 00:12:05 --> Config Class Initialized
INFO - 2017-01-18 00:12:05 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:12:05 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:12:05 --> Utf8 Class Initialized
INFO - 2017-01-18 00:12:05 --> URI Class Initialized
INFO - 2017-01-18 00:12:05 --> Router Class Initialized
INFO - 2017-01-18 00:12:05 --> Output Class Initialized
INFO - 2017-01-18 00:12:05 --> Security Class Initialized
DEBUG - 2017-01-18 00:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:12:05 --> Input Class Initialized
INFO - 2017-01-18 00:12:05 --> Language Class Initialized
INFO - 2017-01-18 00:12:05 --> Loader Class Initialized
INFO - 2017-01-18 00:12:05 --> Database Driver Class Initialized
INFO - 2017-01-18 00:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:12:05 --> Controller Class Initialized
INFO - 2017-01-18 00:12:05 --> Upload Class Initialized
INFO - 2017-01-18 00:12:05 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:12:05 --> Helper loaded: form_helper
INFO - 2017-01-18 00:12:05 --> Form Validation Class Initialized
INFO - 2017-01-18 00:12:05 --> Final output sent to browser
DEBUG - 2017-01-18 00:12:05 --> Total execution time: 0.0153
INFO - 2017-01-18 00:12:05 --> Config Class Initialized
INFO - 2017-01-18 00:12:05 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:12:05 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:12:05 --> Utf8 Class Initialized
INFO - 2017-01-18 00:12:05 --> URI Class Initialized
INFO - 2017-01-18 00:12:05 --> Router Class Initialized
INFO - 2017-01-18 00:12:05 --> Output Class Initialized
INFO - 2017-01-18 00:12:05 --> Security Class Initialized
DEBUG - 2017-01-18 00:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:12:05 --> Input Class Initialized
INFO - 2017-01-18 00:12:05 --> Language Class Initialized
INFO - 2017-01-18 00:12:05 --> Loader Class Initialized
INFO - 2017-01-18 00:12:05 --> Database Driver Class Initialized
INFO - 2017-01-18 00:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:12:05 --> Controller Class Initialized
INFO - 2017-01-18 00:12:05 --> Upload Class Initialized
INFO - 2017-01-18 00:12:05 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:12:05 --> Helper loaded: form_helper
INFO - 2017-01-18 00:12:05 --> Form Validation Class Initialized
INFO - 2017-01-18 00:12:05 --> Final output sent to browser
DEBUG - 2017-01-18 00:12:05 --> Total execution time: 0.0367
INFO - 2017-01-18 00:12:15 --> Config Class Initialized
INFO - 2017-01-18 00:12:15 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:12:15 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:12:15 --> Utf8 Class Initialized
INFO - 2017-01-18 00:12:15 --> URI Class Initialized
INFO - 2017-01-18 00:12:15 --> Router Class Initialized
INFO - 2017-01-18 00:12:15 --> Output Class Initialized
INFO - 2017-01-18 00:12:15 --> Security Class Initialized
DEBUG - 2017-01-18 00:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:12:15 --> Input Class Initialized
INFO - 2017-01-18 00:12:15 --> Language Class Initialized
INFO - 2017-01-18 00:12:15 --> Loader Class Initialized
INFO - 2017-01-18 00:12:15 --> Database Driver Class Initialized
INFO - 2017-01-18 00:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:12:15 --> Controller Class Initialized
INFO - 2017-01-18 00:12:15 --> Helper loaded: date_helper
DEBUG - 2017-01-18 00:12:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:12:15 --> Helper loaded: url_helper
INFO - 2017-01-18 00:12:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 00:12:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-18 00:12:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-18 00:12:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-18 00:12:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 00:12:15 --> Final output sent to browser
DEBUG - 2017-01-18 00:12:15 --> Total execution time: 0.0144
INFO - 2017-01-18 00:12:46 --> Config Class Initialized
INFO - 2017-01-18 00:12:46 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:12:46 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:12:46 --> Utf8 Class Initialized
INFO - 2017-01-18 00:12:46 --> URI Class Initialized
DEBUG - 2017-01-18 00:12:46 --> No URI present. Default controller set.
INFO - 2017-01-18 00:12:46 --> Router Class Initialized
INFO - 2017-01-18 00:12:46 --> Output Class Initialized
INFO - 2017-01-18 00:12:46 --> Security Class Initialized
DEBUG - 2017-01-18 00:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:12:46 --> Input Class Initialized
INFO - 2017-01-18 00:12:46 --> Language Class Initialized
INFO - 2017-01-18 00:12:46 --> Loader Class Initialized
INFO - 2017-01-18 00:12:46 --> Database Driver Class Initialized
INFO - 2017-01-18 00:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:12:46 --> Controller Class Initialized
INFO - 2017-01-18 00:12:46 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:12:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:12:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 00:12:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 00:12:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 00:12:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 00:12:46 --> Final output sent to browser
DEBUG - 2017-01-18 00:12:46 --> Total execution time: 0.0301
INFO - 2017-01-18 00:14:27 --> Config Class Initialized
INFO - 2017-01-18 00:14:27 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:14:27 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:14:27 --> Utf8 Class Initialized
INFO - 2017-01-18 00:14:27 --> URI Class Initialized
INFO - 2017-01-18 00:14:27 --> Router Class Initialized
INFO - 2017-01-18 00:14:27 --> Output Class Initialized
INFO - 2017-01-18 00:14:27 --> Security Class Initialized
DEBUG - 2017-01-18 00:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:14:27 --> Input Class Initialized
INFO - 2017-01-18 00:14:27 --> Language Class Initialized
INFO - 2017-01-18 00:14:27 --> Loader Class Initialized
INFO - 2017-01-18 00:14:27 --> Database Driver Class Initialized
INFO - 2017-01-18 00:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:14:27 --> Controller Class Initialized
INFO - 2017-01-18 00:14:27 --> Helper loaded: date_helper
DEBUG - 2017-01-18 00:14:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:14:27 --> Helper loaded: url_helper
INFO - 2017-01-18 00:14:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 00:14:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-18 00:14:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-18 00:14:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-18 00:14:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 00:14:27 --> Final output sent to browser
DEBUG - 2017-01-18 00:14:27 --> Total execution time: 0.0150
INFO - 2017-01-18 00:19:00 --> Config Class Initialized
INFO - 2017-01-18 00:19:00 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:19:00 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:19:00 --> Utf8 Class Initialized
INFO - 2017-01-18 00:19:00 --> URI Class Initialized
INFO - 2017-01-18 00:19:00 --> Router Class Initialized
INFO - 2017-01-18 00:19:00 --> Output Class Initialized
INFO - 2017-01-18 00:19:00 --> Security Class Initialized
DEBUG - 2017-01-18 00:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:19:00 --> Input Class Initialized
INFO - 2017-01-18 00:19:00 --> Language Class Initialized
INFO - 2017-01-18 00:19:00 --> Loader Class Initialized
INFO - 2017-01-18 00:19:00 --> Database Driver Class Initialized
INFO - 2017-01-18 00:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:19:00 --> Controller Class Initialized
INFO - 2017-01-18 00:19:00 --> Upload Class Initialized
INFO - 2017-01-18 00:19:00 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:19:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:19:00 --> Helper loaded: form_helper
INFO - 2017-01-18 00:19:00 --> Form Validation Class Initialized
INFO - 2017-01-18 00:19:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-18 00:19:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-18 00:19:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-18 00:19:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-18 00:19:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-18 00:19:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-18 00:19:00 --> Final output sent to browser
DEBUG - 2017-01-18 00:19:00 --> Total execution time: 0.0306
INFO - 2017-01-18 00:19:01 --> Config Class Initialized
INFO - 2017-01-18 00:19:01 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:19:01 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:19:01 --> Utf8 Class Initialized
INFO - 2017-01-18 00:19:01 --> URI Class Initialized
INFO - 2017-01-18 00:19:01 --> Router Class Initialized
INFO - 2017-01-18 00:19:01 --> Output Class Initialized
INFO - 2017-01-18 00:19:01 --> Security Class Initialized
DEBUG - 2017-01-18 00:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:19:01 --> Input Class Initialized
INFO - 2017-01-18 00:19:01 --> Language Class Initialized
INFO - 2017-01-18 00:19:01 --> Loader Class Initialized
INFO - 2017-01-18 00:19:01 --> Database Driver Class Initialized
INFO - 2017-01-18 00:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:19:01 --> Controller Class Initialized
INFO - 2017-01-18 00:19:01 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:19:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:19:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 00:19:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 00:19:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 00:19:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 00:19:01 --> Final output sent to browser
DEBUG - 2017-01-18 00:19:01 --> Total execution time: 0.0158
INFO - 2017-01-18 00:19:07 --> Config Class Initialized
INFO - 2017-01-18 00:19:07 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:19:07 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:19:07 --> Utf8 Class Initialized
INFO - 2017-01-18 00:19:07 --> URI Class Initialized
INFO - 2017-01-18 00:19:07 --> Router Class Initialized
INFO - 2017-01-18 00:19:07 --> Output Class Initialized
INFO - 2017-01-18 00:19:07 --> Security Class Initialized
DEBUG - 2017-01-18 00:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:19:07 --> Input Class Initialized
INFO - 2017-01-18 00:19:07 --> Language Class Initialized
INFO - 2017-01-18 00:19:07 --> Loader Class Initialized
INFO - 2017-01-18 00:19:07 --> Database Driver Class Initialized
INFO - 2017-01-18 00:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:19:07 --> Controller Class Initialized
INFO - 2017-01-18 00:19:07 --> Helper loaded: date_helper
INFO - 2017-01-18 00:19:07 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:19:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:19:07 --> Helper loaded: form_helper
INFO - 2017-01-18 00:19:07 --> Form Validation Class Initialized
INFO - 2017-01-18 00:19:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-18 00:19:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-18 00:19:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-18 00:19:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-18 00:19:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-18 00:19:07 --> Final output sent to browser
DEBUG - 2017-01-18 00:19:07 --> Total execution time: 0.0153
INFO - 2017-01-18 00:19:08 --> Config Class Initialized
INFO - 2017-01-18 00:19:08 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:19:08 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:19:08 --> Utf8 Class Initialized
INFO - 2017-01-18 00:19:08 --> URI Class Initialized
INFO - 2017-01-18 00:19:08 --> Router Class Initialized
INFO - 2017-01-18 00:19:08 --> Output Class Initialized
INFO - 2017-01-18 00:19:08 --> Security Class Initialized
DEBUG - 2017-01-18 00:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:19:08 --> Input Class Initialized
INFO - 2017-01-18 00:19:08 --> Language Class Initialized
INFO - 2017-01-18 00:19:08 --> Loader Class Initialized
INFO - 2017-01-18 00:19:08 --> Database Driver Class Initialized
INFO - 2017-01-18 00:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:19:08 --> Controller Class Initialized
INFO - 2017-01-18 00:19:08 --> Helper loaded: date_helper
INFO - 2017-01-18 00:19:08 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:19:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:19:08 --> Helper loaded: form_helper
INFO - 2017-01-18 00:19:08 --> Form Validation Class Initialized
INFO - 2017-01-18 00:19:08 --> Final output sent to browser
DEBUG - 2017-01-18 00:19:08 --> Total execution time: 0.0139
INFO - 2017-01-18 00:19:08 --> Config Class Initialized
INFO - 2017-01-18 00:19:08 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:19:08 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:19:08 --> Utf8 Class Initialized
INFO - 2017-01-18 00:19:08 --> URI Class Initialized
INFO - 2017-01-18 00:19:08 --> Router Class Initialized
INFO - 2017-01-18 00:19:08 --> Output Class Initialized
INFO - 2017-01-18 00:19:08 --> Security Class Initialized
DEBUG - 2017-01-18 00:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:19:08 --> Input Class Initialized
INFO - 2017-01-18 00:19:08 --> Language Class Initialized
INFO - 2017-01-18 00:19:08 --> Loader Class Initialized
INFO - 2017-01-18 00:19:08 --> Database Driver Class Initialized
INFO - 2017-01-18 00:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:19:08 --> Controller Class Initialized
INFO - 2017-01-18 00:19:08 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:19:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:19:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 00:19:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 00:19:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 00:19:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 00:19:08 --> Final output sent to browser
DEBUG - 2017-01-18 00:19:08 --> Total execution time: 0.0138
INFO - 2017-01-18 00:19:10 --> Config Class Initialized
INFO - 2017-01-18 00:19:10 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:19:10 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:19:10 --> Utf8 Class Initialized
INFO - 2017-01-18 00:19:10 --> URI Class Initialized
INFO - 2017-01-18 00:19:10 --> Router Class Initialized
INFO - 2017-01-18 00:19:10 --> Output Class Initialized
INFO - 2017-01-18 00:19:10 --> Security Class Initialized
DEBUG - 2017-01-18 00:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:19:10 --> Input Class Initialized
INFO - 2017-01-18 00:19:10 --> Language Class Initialized
INFO - 2017-01-18 00:19:10 --> Loader Class Initialized
INFO - 2017-01-18 00:19:10 --> Database Driver Class Initialized
INFO - 2017-01-18 00:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:19:10 --> Controller Class Initialized
INFO - 2017-01-18 00:19:10 --> Helper loaded: date_helper
INFO - 2017-01-18 00:19:10 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:19:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:19:10 --> Helper loaded: form_helper
INFO - 2017-01-18 00:19:10 --> Form Validation Class Initialized
INFO - 2017-01-18 00:19:10 --> Final output sent to browser
DEBUG - 2017-01-18 00:19:10 --> Total execution time: 0.0144
INFO - 2017-01-18 00:19:19 --> Config Class Initialized
INFO - 2017-01-18 00:19:19 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:19:19 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:19:19 --> Utf8 Class Initialized
INFO - 2017-01-18 00:19:19 --> URI Class Initialized
INFO - 2017-01-18 00:19:19 --> Router Class Initialized
INFO - 2017-01-18 00:19:19 --> Output Class Initialized
INFO - 2017-01-18 00:19:19 --> Security Class Initialized
DEBUG - 2017-01-18 00:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:19:19 --> Input Class Initialized
INFO - 2017-01-18 00:19:19 --> Language Class Initialized
INFO - 2017-01-18 00:19:19 --> Loader Class Initialized
INFO - 2017-01-18 00:19:19 --> Database Driver Class Initialized
INFO - 2017-01-18 00:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:19:19 --> Controller Class Initialized
INFO - 2017-01-18 00:19:19 --> Helper loaded: date_helper
INFO - 2017-01-18 00:19:19 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:19:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:19:19 --> Helper loaded: form_helper
INFO - 2017-01-18 00:19:19 --> Form Validation Class Initialized
INFO - 2017-01-18 00:19:19 --> Final output sent to browser
DEBUG - 2017-01-18 00:19:19 --> Total execution time: 0.0140
INFO - 2017-01-18 00:19:19 --> Config Class Initialized
INFO - 2017-01-18 00:19:19 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:19:19 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:19:19 --> Utf8 Class Initialized
INFO - 2017-01-18 00:19:19 --> URI Class Initialized
INFO - 2017-01-18 00:19:19 --> Router Class Initialized
INFO - 2017-01-18 00:19:19 --> Output Class Initialized
INFO - 2017-01-18 00:19:19 --> Security Class Initialized
DEBUG - 2017-01-18 00:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:19:19 --> Input Class Initialized
INFO - 2017-01-18 00:19:19 --> Language Class Initialized
INFO - 2017-01-18 00:19:19 --> Loader Class Initialized
INFO - 2017-01-18 00:19:19 --> Database Driver Class Initialized
INFO - 2017-01-18 00:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:19:19 --> Controller Class Initialized
INFO - 2017-01-18 00:19:19 --> Helper loaded: date_helper
INFO - 2017-01-18 00:19:19 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:19:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:19:19 --> Helper loaded: form_helper
INFO - 2017-01-18 00:19:19 --> Form Validation Class Initialized
INFO - 2017-01-18 00:19:19 --> Final output sent to browser
DEBUG - 2017-01-18 00:19:19 --> Total execution time: 0.0148
INFO - 2017-01-18 00:19:28 --> Config Class Initialized
INFO - 2017-01-18 00:19:28 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:19:28 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:19:28 --> Utf8 Class Initialized
INFO - 2017-01-18 00:19:28 --> URI Class Initialized
INFO - 2017-01-18 00:19:28 --> Router Class Initialized
INFO - 2017-01-18 00:19:28 --> Output Class Initialized
INFO - 2017-01-18 00:19:28 --> Security Class Initialized
DEBUG - 2017-01-18 00:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:19:28 --> Input Class Initialized
INFO - 2017-01-18 00:19:28 --> Language Class Initialized
INFO - 2017-01-18 00:19:28 --> Loader Class Initialized
INFO - 2017-01-18 00:19:28 --> Database Driver Class Initialized
INFO - 2017-01-18 00:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:19:28 --> Controller Class Initialized
INFO - 2017-01-18 00:19:28 --> Helper loaded: date_helper
INFO - 2017-01-18 00:19:28 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:19:28 --> Helper loaded: form_helper
INFO - 2017-01-18 00:19:28 --> Form Validation Class Initialized
INFO - 2017-01-18 00:19:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-18 00:19:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-18 00:19:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-18 00:19:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-18 00:19:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-18 00:19:28 --> Final output sent to browser
DEBUG - 2017-01-18 00:19:28 --> Total execution time: 0.0488
INFO - 2017-01-18 00:19:29 --> Config Class Initialized
INFO - 2017-01-18 00:19:29 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:19:29 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:19:29 --> Utf8 Class Initialized
INFO - 2017-01-18 00:19:29 --> URI Class Initialized
INFO - 2017-01-18 00:19:29 --> Router Class Initialized
INFO - 2017-01-18 00:19:29 --> Output Class Initialized
INFO - 2017-01-18 00:19:29 --> Security Class Initialized
DEBUG - 2017-01-18 00:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:19:29 --> Input Class Initialized
INFO - 2017-01-18 00:19:29 --> Language Class Initialized
INFO - 2017-01-18 00:19:29 --> Loader Class Initialized
INFO - 2017-01-18 00:19:29 --> Database Driver Class Initialized
INFO - 2017-01-18 00:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:19:29 --> Controller Class Initialized
INFO - 2017-01-18 00:19:29 --> Helper loaded: date_helper
INFO - 2017-01-18 00:19:29 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:19:29 --> Helper loaded: form_helper
INFO - 2017-01-18 00:19:29 --> Form Validation Class Initialized
INFO - 2017-01-18 00:19:29 --> Final output sent to browser
DEBUG - 2017-01-18 00:19:29 --> Total execution time: 0.0278
INFO - 2017-01-18 00:19:29 --> Config Class Initialized
INFO - 2017-01-18 00:19:29 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:19:29 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:19:29 --> Utf8 Class Initialized
INFO - 2017-01-18 00:19:29 --> URI Class Initialized
INFO - 2017-01-18 00:19:29 --> Router Class Initialized
INFO - 2017-01-18 00:19:29 --> Output Class Initialized
INFO - 2017-01-18 00:19:29 --> Security Class Initialized
DEBUG - 2017-01-18 00:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:19:29 --> Input Class Initialized
INFO - 2017-01-18 00:19:29 --> Language Class Initialized
INFO - 2017-01-18 00:19:29 --> Loader Class Initialized
INFO - 2017-01-18 00:19:29 --> Database Driver Class Initialized
INFO - 2017-01-18 00:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:19:29 --> Controller Class Initialized
INFO - 2017-01-18 00:19:29 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:19:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 00:19:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 00:19:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 00:19:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 00:19:29 --> Final output sent to browser
DEBUG - 2017-01-18 00:19:29 --> Total execution time: 0.0135
INFO - 2017-01-18 00:19:30 --> Config Class Initialized
INFO - 2017-01-18 00:19:30 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:19:30 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:19:30 --> Utf8 Class Initialized
INFO - 2017-01-18 00:19:30 --> URI Class Initialized
INFO - 2017-01-18 00:19:30 --> Router Class Initialized
INFO - 2017-01-18 00:19:30 --> Output Class Initialized
INFO - 2017-01-18 00:19:30 --> Security Class Initialized
DEBUG - 2017-01-18 00:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:19:30 --> Input Class Initialized
INFO - 2017-01-18 00:19:30 --> Language Class Initialized
INFO - 2017-01-18 00:19:30 --> Loader Class Initialized
INFO - 2017-01-18 00:19:30 --> Database Driver Class Initialized
INFO - 2017-01-18 00:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:19:30 --> Controller Class Initialized
INFO - 2017-01-18 00:19:30 --> Upload Class Initialized
INFO - 2017-01-18 00:19:30 --> Helper loaded: date_helper
INFO - 2017-01-18 00:19:30 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:19:30 --> Helper loaded: form_helper
INFO - 2017-01-18 00:19:30 --> Form Validation Class Initialized
INFO - 2017-01-18 00:19:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-18 00:19:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-18 00:19:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-18 00:19:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-18 00:19:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-18 00:19:30 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-18 00:19:30 --> Final output sent to browser
DEBUG - 2017-01-18 00:19:30 --> Total execution time: 0.0167
INFO - 2017-01-18 00:19:31 --> Config Class Initialized
INFO - 2017-01-18 00:19:31 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:19:31 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:19:31 --> Utf8 Class Initialized
INFO - 2017-01-18 00:19:31 --> URI Class Initialized
INFO - 2017-01-18 00:19:31 --> Router Class Initialized
INFO - 2017-01-18 00:19:31 --> Output Class Initialized
INFO - 2017-01-18 00:19:31 --> Security Class Initialized
DEBUG - 2017-01-18 00:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:19:31 --> Input Class Initialized
INFO - 2017-01-18 00:19:31 --> Language Class Initialized
INFO - 2017-01-18 00:19:31 --> Loader Class Initialized
INFO - 2017-01-18 00:19:31 --> Database Driver Class Initialized
INFO - 2017-01-18 00:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:19:31 --> Controller Class Initialized
INFO - 2017-01-18 00:19:31 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:19:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:19:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 00:19:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 00:19:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 00:19:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 00:19:31 --> Final output sent to browser
DEBUG - 2017-01-18 00:19:31 --> Total execution time: 0.0137
INFO - 2017-01-18 00:19:32 --> Config Class Initialized
INFO - 2017-01-18 00:19:32 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:19:32 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:19:32 --> Utf8 Class Initialized
INFO - 2017-01-18 00:19:32 --> URI Class Initialized
INFO - 2017-01-18 00:19:32 --> Router Class Initialized
INFO - 2017-01-18 00:19:32 --> Output Class Initialized
INFO - 2017-01-18 00:19:32 --> Security Class Initialized
DEBUG - 2017-01-18 00:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:19:32 --> Input Class Initialized
INFO - 2017-01-18 00:19:32 --> Language Class Initialized
INFO - 2017-01-18 00:19:32 --> Loader Class Initialized
INFO - 2017-01-18 00:19:32 --> Database Driver Class Initialized
INFO - 2017-01-18 00:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:19:32 --> Controller Class Initialized
INFO - 2017-01-18 00:19:32 --> Helper loaded: date_helper
INFO - 2017-01-18 00:19:32 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:19:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:19:32 --> Helper loaded: form_helper
INFO - 2017-01-18 00:19:32 --> Form Validation Class Initialized
INFO - 2017-01-18 00:19:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-18 00:19:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-18 00:19:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-18 00:19:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-18 00:19:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-18 00:19:32 --> Final output sent to browser
DEBUG - 2017-01-18 00:19:32 --> Total execution time: 0.0158
INFO - 2017-01-18 00:19:32 --> Config Class Initialized
INFO - 2017-01-18 00:19:32 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:19:32 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:19:32 --> Utf8 Class Initialized
INFO - 2017-01-18 00:19:32 --> URI Class Initialized
INFO - 2017-01-18 00:19:32 --> Router Class Initialized
INFO - 2017-01-18 00:19:32 --> Output Class Initialized
INFO - 2017-01-18 00:19:32 --> Security Class Initialized
DEBUG - 2017-01-18 00:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:19:32 --> Input Class Initialized
INFO - 2017-01-18 00:19:32 --> Language Class Initialized
INFO - 2017-01-18 00:19:32 --> Loader Class Initialized
INFO - 2017-01-18 00:19:32 --> Database Driver Class Initialized
INFO - 2017-01-18 00:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:19:32 --> Controller Class Initialized
INFO - 2017-01-18 00:19:32 --> Helper loaded: date_helper
INFO - 2017-01-18 00:19:32 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:19:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:19:32 --> Helper loaded: form_helper
INFO - 2017-01-18 00:19:32 --> Form Validation Class Initialized
INFO - 2017-01-18 00:19:32 --> Final output sent to browser
DEBUG - 2017-01-18 00:19:32 --> Total execution time: 0.0141
INFO - 2017-01-18 00:19:32 --> Config Class Initialized
INFO - 2017-01-18 00:19:32 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:19:32 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:19:32 --> Utf8 Class Initialized
INFO - 2017-01-18 00:19:32 --> URI Class Initialized
INFO - 2017-01-18 00:19:32 --> Router Class Initialized
INFO - 2017-01-18 00:19:32 --> Output Class Initialized
INFO - 2017-01-18 00:19:32 --> Security Class Initialized
DEBUG - 2017-01-18 00:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:19:32 --> Input Class Initialized
INFO - 2017-01-18 00:19:32 --> Language Class Initialized
INFO - 2017-01-18 00:19:32 --> Loader Class Initialized
INFO - 2017-01-18 00:19:32 --> Database Driver Class Initialized
INFO - 2017-01-18 00:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:19:32 --> Controller Class Initialized
INFO - 2017-01-18 00:19:32 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:19:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:19:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 00:19:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 00:19:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 00:19:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 00:19:32 --> Final output sent to browser
DEBUG - 2017-01-18 00:19:32 --> Total execution time: 0.0134
INFO - 2017-01-18 00:19:36 --> Config Class Initialized
INFO - 2017-01-18 00:19:36 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:19:36 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:19:36 --> Utf8 Class Initialized
INFO - 2017-01-18 00:19:36 --> URI Class Initialized
INFO - 2017-01-18 00:19:36 --> Router Class Initialized
INFO - 2017-01-18 00:19:36 --> Output Class Initialized
INFO - 2017-01-18 00:19:36 --> Security Class Initialized
DEBUG - 2017-01-18 00:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:19:36 --> Input Class Initialized
INFO - 2017-01-18 00:19:36 --> Language Class Initialized
INFO - 2017-01-18 00:19:36 --> Loader Class Initialized
INFO - 2017-01-18 00:19:36 --> Database Driver Class Initialized
INFO - 2017-01-18 00:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:19:36 --> Controller Class Initialized
INFO - 2017-01-18 00:19:36 --> Helper loaded: date_helper
INFO - 2017-01-18 00:19:36 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:19:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:19:36 --> Helper loaded: form_helper
INFO - 2017-01-18 00:19:36 --> Form Validation Class Initialized
INFO - 2017-01-18 00:19:36 --> Final output sent to browser
DEBUG - 2017-01-18 00:19:36 --> Total execution time: 0.0141
INFO - 2017-01-18 00:20:52 --> Config Class Initialized
INFO - 2017-01-18 00:20:52 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:20:52 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:20:52 --> Utf8 Class Initialized
INFO - 2017-01-18 00:20:52 --> URI Class Initialized
INFO - 2017-01-18 00:20:52 --> Router Class Initialized
INFO - 2017-01-18 00:20:52 --> Output Class Initialized
INFO - 2017-01-18 00:20:52 --> Security Class Initialized
DEBUG - 2017-01-18 00:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:20:52 --> Input Class Initialized
INFO - 2017-01-18 00:20:52 --> Language Class Initialized
INFO - 2017-01-18 00:20:52 --> Loader Class Initialized
INFO - 2017-01-18 00:20:52 --> Database Driver Class Initialized
INFO - 2017-01-18 00:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:20:52 --> Controller Class Initialized
INFO - 2017-01-18 00:20:52 --> Helper loaded: date_helper
INFO - 2017-01-18 00:20:52 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:20:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:20:52 --> Helper loaded: form_helper
INFO - 2017-01-18 00:20:52 --> Form Validation Class Initialized
INFO - 2017-01-18 00:20:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-18 00:20:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-18 00:20:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pagos.php
INFO - 2017-01-18 00:20:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pagos.php
INFO - 2017-01-18 00:20:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-18 00:20:53 --> Final output sent to browser
DEBUG - 2017-01-18 00:20:53 --> Total execution time: 0.1447
INFO - 2017-01-18 00:20:53 --> Config Class Initialized
INFO - 2017-01-18 00:20:53 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:20:53 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:20:53 --> Utf8 Class Initialized
INFO - 2017-01-18 00:20:53 --> URI Class Initialized
INFO - 2017-01-18 00:20:53 --> Router Class Initialized
INFO - 2017-01-18 00:20:53 --> Output Class Initialized
INFO - 2017-01-18 00:20:53 --> Security Class Initialized
DEBUG - 2017-01-18 00:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:20:53 --> Input Class Initialized
INFO - 2017-01-18 00:20:53 --> Language Class Initialized
INFO - 2017-01-18 00:20:53 --> Loader Class Initialized
INFO - 2017-01-18 00:20:53 --> Database Driver Class Initialized
INFO - 2017-01-18 00:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:20:53 --> Controller Class Initialized
INFO - 2017-01-18 00:20:53 --> Helper loaded: date_helper
INFO - 2017-01-18 00:20:53 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:20:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:20:53 --> Helper loaded: form_helper
INFO - 2017-01-18 00:20:53 --> Form Validation Class Initialized
INFO - 2017-01-18 00:20:53 --> Final output sent to browser
DEBUG - 2017-01-18 00:20:53 --> Total execution time: 0.0147
INFO - 2017-01-18 00:20:53 --> Config Class Initialized
INFO - 2017-01-18 00:20:53 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:20:53 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:20:53 --> Utf8 Class Initialized
INFO - 2017-01-18 00:20:53 --> URI Class Initialized
INFO - 2017-01-18 00:20:53 --> Router Class Initialized
INFO - 2017-01-18 00:20:53 --> Output Class Initialized
INFO - 2017-01-18 00:20:53 --> Security Class Initialized
DEBUG - 2017-01-18 00:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:20:53 --> Input Class Initialized
INFO - 2017-01-18 00:20:53 --> Language Class Initialized
INFO - 2017-01-18 00:20:53 --> Loader Class Initialized
INFO - 2017-01-18 00:20:53 --> Database Driver Class Initialized
INFO - 2017-01-18 00:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:20:53 --> Controller Class Initialized
INFO - 2017-01-18 00:20:53 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:20:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:20:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 00:20:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 00:20:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 00:20:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 00:20:53 --> Final output sent to browser
DEBUG - 2017-01-18 00:20:53 --> Total execution time: 0.0174
INFO - 2017-01-18 00:25:16 --> Config Class Initialized
INFO - 2017-01-18 00:25:16 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:25:16 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:25:16 --> Utf8 Class Initialized
INFO - 2017-01-18 00:25:16 --> URI Class Initialized
INFO - 2017-01-18 00:25:16 --> Router Class Initialized
INFO - 2017-01-18 00:25:16 --> Output Class Initialized
INFO - 2017-01-18 00:25:16 --> Security Class Initialized
DEBUG - 2017-01-18 00:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:25:16 --> Input Class Initialized
INFO - 2017-01-18 00:25:16 --> Language Class Initialized
INFO - 2017-01-18 00:25:16 --> Loader Class Initialized
INFO - 2017-01-18 00:25:16 --> Database Driver Class Initialized
INFO - 2017-01-18 00:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:25:16 --> Controller Class Initialized
INFO - 2017-01-18 00:25:16 --> Upload Class Initialized
INFO - 2017-01-18 00:25:16 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:25:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:25:16 --> Helper loaded: form_helper
INFO - 2017-01-18 00:25:16 --> Form Validation Class Initialized
INFO - 2017-01-18 00:25:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-18 00:25:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-18 00:25:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-18 00:25:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-18 00:25:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-18 00:25:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-18 00:25:16 --> Final output sent to browser
DEBUG - 2017-01-18 00:25:16 --> Total execution time: 0.0168
INFO - 2017-01-18 00:25:16 --> Config Class Initialized
INFO - 2017-01-18 00:25:16 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:25:16 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:25:16 --> Utf8 Class Initialized
INFO - 2017-01-18 00:25:16 --> URI Class Initialized
INFO - 2017-01-18 00:25:16 --> Router Class Initialized
INFO - 2017-01-18 00:25:16 --> Output Class Initialized
INFO - 2017-01-18 00:25:16 --> Security Class Initialized
DEBUG - 2017-01-18 00:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:25:16 --> Input Class Initialized
INFO - 2017-01-18 00:25:16 --> Language Class Initialized
INFO - 2017-01-18 00:25:16 --> Loader Class Initialized
INFO - 2017-01-18 00:25:16 --> Database Driver Class Initialized
INFO - 2017-01-18 00:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:25:16 --> Controller Class Initialized
INFO - 2017-01-18 00:25:16 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:25:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:25:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 00:25:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 00:25:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 00:25:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 00:25:16 --> Final output sent to browser
DEBUG - 2017-01-18 00:25:16 --> Total execution time: 0.0140
INFO - 2017-01-18 00:26:42 --> Config Class Initialized
INFO - 2017-01-18 00:26:42 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:26:42 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:26:42 --> Utf8 Class Initialized
INFO - 2017-01-18 00:26:42 --> URI Class Initialized
INFO - 2017-01-18 00:26:42 --> Router Class Initialized
INFO - 2017-01-18 00:26:42 --> Output Class Initialized
INFO - 2017-01-18 00:26:42 --> Security Class Initialized
DEBUG - 2017-01-18 00:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:26:42 --> Input Class Initialized
INFO - 2017-01-18 00:26:42 --> Language Class Initialized
INFO - 2017-01-18 00:26:42 --> Loader Class Initialized
INFO - 2017-01-18 00:26:42 --> Database Driver Class Initialized
INFO - 2017-01-18 00:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:26:42 --> Controller Class Initialized
INFO - 2017-01-18 00:26:42 --> Upload Class Initialized
INFO - 2017-01-18 00:26:42 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:26:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:26:42 --> Helper loaded: form_helper
INFO - 2017-01-18 00:26:42 --> Form Validation Class Initialized
INFO - 2017-01-18 00:26:42 --> Final output sent to browser
DEBUG - 2017-01-18 00:26:42 --> Total execution time: 0.0150
INFO - 2017-01-18 00:26:42 --> Config Class Initialized
INFO - 2017-01-18 00:26:42 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:26:42 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:26:42 --> Utf8 Class Initialized
INFO - 2017-01-18 00:26:42 --> URI Class Initialized
INFO - 2017-01-18 00:26:42 --> Router Class Initialized
INFO - 2017-01-18 00:26:42 --> Output Class Initialized
INFO - 2017-01-18 00:26:42 --> Security Class Initialized
DEBUG - 2017-01-18 00:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:26:42 --> Input Class Initialized
INFO - 2017-01-18 00:26:42 --> Language Class Initialized
INFO - 2017-01-18 00:26:42 --> Loader Class Initialized
INFO - 2017-01-18 00:26:42 --> Database Driver Class Initialized
INFO - 2017-01-18 00:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:26:42 --> Controller Class Initialized
INFO - 2017-01-18 00:26:42 --> Upload Class Initialized
INFO - 2017-01-18 00:26:42 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:26:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:26:42 --> Helper loaded: form_helper
INFO - 2017-01-18 00:26:42 --> Form Validation Class Initialized
INFO - 2017-01-18 00:26:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-18 00:26:42 --> Final output sent to browser
DEBUG - 2017-01-18 00:26:42 --> Total execution time: 0.0165
INFO - 2017-01-18 00:26:53 --> Config Class Initialized
INFO - 2017-01-18 00:26:53 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:26:53 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:26:53 --> Utf8 Class Initialized
INFO - 2017-01-18 00:26:53 --> URI Class Initialized
INFO - 2017-01-18 00:26:53 --> Router Class Initialized
INFO - 2017-01-18 00:26:53 --> Output Class Initialized
INFO - 2017-01-18 00:26:53 --> Security Class Initialized
DEBUG - 2017-01-18 00:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:26:53 --> Input Class Initialized
INFO - 2017-01-18 00:26:53 --> Language Class Initialized
INFO - 2017-01-18 00:26:53 --> Loader Class Initialized
INFO - 2017-01-18 00:26:53 --> Database Driver Class Initialized
INFO - 2017-01-18 00:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:26:53 --> Controller Class Initialized
INFO - 2017-01-18 00:26:53 --> Helper loaded: date_helper
DEBUG - 2017-01-18 00:26:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:26:53 --> Helper loaded: url_helper
INFO - 2017-01-18 00:26:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 00:26:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-18 00:26:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-18 00:26:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-18 00:26:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 00:26:53 --> Final output sent to browser
DEBUG - 2017-01-18 00:26:53 --> Total execution time: 0.0146
INFO - 2017-01-18 00:49:33 --> Config Class Initialized
INFO - 2017-01-18 00:49:33 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:49:33 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:49:33 --> Utf8 Class Initialized
INFO - 2017-01-18 00:49:33 --> URI Class Initialized
INFO - 2017-01-18 00:49:33 --> Router Class Initialized
INFO - 2017-01-18 00:49:33 --> Output Class Initialized
INFO - 2017-01-18 00:49:33 --> Security Class Initialized
DEBUG - 2017-01-18 00:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:49:33 --> Input Class Initialized
INFO - 2017-01-18 00:49:33 --> Language Class Initialized
INFO - 2017-01-18 00:49:33 --> Loader Class Initialized
INFO - 2017-01-18 00:49:33 --> Database Driver Class Initialized
INFO - 2017-01-18 00:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:49:33 --> Controller Class Initialized
INFO - 2017-01-18 00:49:33 --> Upload Class Initialized
INFO - 2017-01-18 00:49:33 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:49:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:49:33 --> Helper loaded: form_helper
INFO - 2017-01-18 00:49:33 --> Form Validation Class Initialized
INFO - 2017-01-18 00:49:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-18 00:49:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-18 00:49:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-18 00:49:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-18 00:49:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-18 00:49:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-18 00:49:33 --> Final output sent to browser
DEBUG - 2017-01-18 00:49:33 --> Total execution time: 0.0203
INFO - 2017-01-18 00:49:34 --> Config Class Initialized
INFO - 2017-01-18 00:49:34 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:49:34 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:49:34 --> Utf8 Class Initialized
INFO - 2017-01-18 00:49:34 --> URI Class Initialized
INFO - 2017-01-18 00:49:34 --> Router Class Initialized
INFO - 2017-01-18 00:49:34 --> Output Class Initialized
INFO - 2017-01-18 00:49:34 --> Security Class Initialized
DEBUG - 2017-01-18 00:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:49:34 --> Input Class Initialized
INFO - 2017-01-18 00:49:34 --> Language Class Initialized
INFO - 2017-01-18 00:49:34 --> Loader Class Initialized
INFO - 2017-01-18 00:49:34 --> Database Driver Class Initialized
INFO - 2017-01-18 00:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:49:34 --> Controller Class Initialized
INFO - 2017-01-18 00:49:34 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:49:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:49:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 00:49:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 00:49:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 00:49:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 00:49:34 --> Final output sent to browser
DEBUG - 2017-01-18 00:49:34 --> Total execution time: 0.0135
INFO - 2017-01-18 00:54:07 --> Config Class Initialized
INFO - 2017-01-18 00:54:07 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:54:07 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:54:07 --> Utf8 Class Initialized
INFO - 2017-01-18 00:54:07 --> URI Class Initialized
INFO - 2017-01-18 00:54:07 --> Router Class Initialized
INFO - 2017-01-18 00:54:07 --> Output Class Initialized
INFO - 2017-01-18 00:54:07 --> Security Class Initialized
DEBUG - 2017-01-18 00:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:54:07 --> Input Class Initialized
INFO - 2017-01-18 00:54:07 --> Language Class Initialized
INFO - 2017-01-18 00:54:07 --> Loader Class Initialized
INFO - 2017-01-18 00:54:07 --> Database Driver Class Initialized
INFO - 2017-01-18 00:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:54:07 --> Controller Class Initialized
INFO - 2017-01-18 00:54:07 --> Upload Class Initialized
INFO - 2017-01-18 00:54:07 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:54:07 --> Helper loaded: form_helper
INFO - 2017-01-18 00:54:07 --> Form Validation Class Initialized
INFO - 2017-01-18 00:54:07 --> Final output sent to browser
DEBUG - 2017-01-18 00:54:07 --> Total execution time: 0.0151
INFO - 2017-01-18 00:54:07 --> Config Class Initialized
INFO - 2017-01-18 00:54:07 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:54:07 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:54:07 --> Utf8 Class Initialized
INFO - 2017-01-18 00:54:07 --> URI Class Initialized
INFO - 2017-01-18 00:54:07 --> Router Class Initialized
INFO - 2017-01-18 00:54:07 --> Output Class Initialized
INFO - 2017-01-18 00:54:07 --> Security Class Initialized
DEBUG - 2017-01-18 00:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:54:07 --> Input Class Initialized
INFO - 2017-01-18 00:54:07 --> Language Class Initialized
INFO - 2017-01-18 00:54:07 --> Loader Class Initialized
INFO - 2017-01-18 00:54:07 --> Database Driver Class Initialized
INFO - 2017-01-18 00:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:54:07 --> Controller Class Initialized
INFO - 2017-01-18 00:54:07 --> Upload Class Initialized
INFO - 2017-01-18 00:54:07 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:54:07 --> Helper loaded: form_helper
INFO - 2017-01-18 00:54:07 --> Form Validation Class Initialized
INFO - 2017-01-18 00:54:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-18 00:54:07 --> Final output sent to browser
DEBUG - 2017-01-18 00:54:07 --> Total execution time: 0.0157
INFO - 2017-01-18 00:54:26 --> Config Class Initialized
INFO - 2017-01-18 00:54:26 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:54:26 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:54:26 --> Utf8 Class Initialized
INFO - 2017-01-18 00:54:26 --> URI Class Initialized
INFO - 2017-01-18 00:54:26 --> Router Class Initialized
INFO - 2017-01-18 00:54:26 --> Output Class Initialized
INFO - 2017-01-18 00:54:26 --> Security Class Initialized
DEBUG - 2017-01-18 00:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:54:26 --> Input Class Initialized
INFO - 2017-01-18 00:54:26 --> Language Class Initialized
INFO - 2017-01-18 00:54:26 --> Loader Class Initialized
INFO - 2017-01-18 00:54:26 --> Database Driver Class Initialized
INFO - 2017-01-18 00:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:54:26 --> Controller Class Initialized
INFO - 2017-01-18 00:54:26 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:54:26 --> Config Class Initialized
INFO - 2017-01-18 00:54:26 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:54:26 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:54:26 --> Utf8 Class Initialized
INFO - 2017-01-18 00:54:26 --> URI Class Initialized
INFO - 2017-01-18 00:54:26 --> Router Class Initialized
INFO - 2017-01-18 00:54:26 --> Output Class Initialized
INFO - 2017-01-18 00:54:26 --> Security Class Initialized
DEBUG - 2017-01-18 00:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:54:26 --> Input Class Initialized
INFO - 2017-01-18 00:54:26 --> Language Class Initialized
INFO - 2017-01-18 00:54:26 --> Loader Class Initialized
INFO - 2017-01-18 00:54:26 --> Database Driver Class Initialized
INFO - 2017-01-18 00:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:54:26 --> Controller Class Initialized
INFO - 2017-01-18 00:54:26 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:54:26 --> Helper loaded: form_helper
INFO - 2017-01-18 00:54:26 --> Form Validation Class Initialized
INFO - 2017-01-18 00:54:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-18 00:54:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-18 00:54:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-18 00:54:26 --> Final output sent to browser
DEBUG - 2017-01-18 00:54:26 --> Total execution time: 0.0143
INFO - 2017-01-18 00:54:26 --> Config Class Initialized
INFO - 2017-01-18 00:54:26 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:54:26 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:54:26 --> Utf8 Class Initialized
INFO - 2017-01-18 00:54:26 --> URI Class Initialized
INFO - 2017-01-18 00:54:26 --> Router Class Initialized
INFO - 2017-01-18 00:54:26 --> Output Class Initialized
INFO - 2017-01-18 00:54:26 --> Security Class Initialized
DEBUG - 2017-01-18 00:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:54:26 --> Input Class Initialized
INFO - 2017-01-18 00:54:26 --> Language Class Initialized
INFO - 2017-01-18 00:54:26 --> Loader Class Initialized
INFO - 2017-01-18 00:54:26 --> Database Driver Class Initialized
INFO - 2017-01-18 00:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:54:26 --> Controller Class Initialized
INFO - 2017-01-18 00:54:26 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:54:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 00:54:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 00:54:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 00:54:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 00:54:26 --> Final output sent to browser
DEBUG - 2017-01-18 00:54:26 --> Total execution time: 0.0689
INFO - 2017-01-18 00:54:26 --> Config Class Initialized
INFO - 2017-01-18 00:54:26 --> Hooks Class Initialized
DEBUG - 2017-01-18 00:54:26 --> UTF-8 Support Enabled
INFO - 2017-01-18 00:54:26 --> Utf8 Class Initialized
INFO - 2017-01-18 00:54:26 --> URI Class Initialized
INFO - 2017-01-18 00:54:26 --> Router Class Initialized
INFO - 2017-01-18 00:54:26 --> Output Class Initialized
INFO - 2017-01-18 00:54:26 --> Security Class Initialized
DEBUG - 2017-01-18 00:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 00:54:26 --> Input Class Initialized
INFO - 2017-01-18 00:54:26 --> Language Class Initialized
INFO - 2017-01-18 00:54:26 --> Loader Class Initialized
INFO - 2017-01-18 00:54:26 --> Database Driver Class Initialized
INFO - 2017-01-18 00:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 00:54:26 --> Controller Class Initialized
INFO - 2017-01-18 00:54:26 --> Helper loaded: url_helper
DEBUG - 2017-01-18 00:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 00:54:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 00:54:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 00:54:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 00:54:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 00:54:26 --> Final output sent to browser
DEBUG - 2017-01-18 00:54:26 --> Total execution time: 0.0140
INFO - 2017-01-18 01:00:03 --> Config Class Initialized
INFO - 2017-01-18 01:00:03 --> Hooks Class Initialized
DEBUG - 2017-01-18 01:00:03 --> UTF-8 Support Enabled
INFO - 2017-01-18 01:00:03 --> Utf8 Class Initialized
INFO - 2017-01-18 01:00:03 --> URI Class Initialized
DEBUG - 2017-01-18 01:00:03 --> No URI present. Default controller set.
INFO - 2017-01-18 01:00:03 --> Router Class Initialized
INFO - 2017-01-18 01:00:03 --> Output Class Initialized
INFO - 2017-01-18 01:00:03 --> Security Class Initialized
DEBUG - 2017-01-18 01:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 01:00:03 --> Input Class Initialized
INFO - 2017-01-18 01:00:03 --> Language Class Initialized
INFO - 2017-01-18 01:00:03 --> Loader Class Initialized
INFO - 2017-01-18 01:00:03 --> Database Driver Class Initialized
INFO - 2017-01-18 01:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 01:00:03 --> Controller Class Initialized
INFO - 2017-01-18 01:00:03 --> Helper loaded: url_helper
DEBUG - 2017-01-18 01:00:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 01:00:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 01:00:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 01:00:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 01:00:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 01:00:03 --> Final output sent to browser
DEBUG - 2017-01-18 01:00:03 --> Total execution time: 0.0135
INFO - 2017-01-18 01:44:30 --> Config Class Initialized
INFO - 2017-01-18 01:44:30 --> Hooks Class Initialized
DEBUG - 2017-01-18 01:44:30 --> UTF-8 Support Enabled
INFO - 2017-01-18 01:44:30 --> Utf8 Class Initialized
INFO - 2017-01-18 01:44:30 --> URI Class Initialized
DEBUG - 2017-01-18 01:44:30 --> No URI present. Default controller set.
INFO - 2017-01-18 01:44:30 --> Router Class Initialized
INFO - 2017-01-18 01:44:30 --> Output Class Initialized
INFO - 2017-01-18 01:44:30 --> Security Class Initialized
DEBUG - 2017-01-18 01:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 01:44:30 --> Input Class Initialized
INFO - 2017-01-18 01:44:30 --> Language Class Initialized
INFO - 2017-01-18 01:44:30 --> Loader Class Initialized
INFO - 2017-01-18 01:44:30 --> Database Driver Class Initialized
INFO - 2017-01-18 01:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 01:44:30 --> Controller Class Initialized
INFO - 2017-01-18 01:44:30 --> Helper loaded: url_helper
DEBUG - 2017-01-18 01:44:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 01:44:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 01:44:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 01:44:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 01:44:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 01:44:30 --> Final output sent to browser
DEBUG - 2017-01-18 01:44:30 --> Total execution time: 0.0556
INFO - 2017-01-18 01:44:44 --> Config Class Initialized
INFO - 2017-01-18 01:44:44 --> Hooks Class Initialized
DEBUG - 2017-01-18 01:44:44 --> UTF-8 Support Enabled
INFO - 2017-01-18 01:44:44 --> Utf8 Class Initialized
INFO - 2017-01-18 01:44:44 --> URI Class Initialized
INFO - 2017-01-18 01:44:44 --> Router Class Initialized
INFO - 2017-01-18 01:44:44 --> Output Class Initialized
INFO - 2017-01-18 01:44:44 --> Security Class Initialized
DEBUG - 2017-01-18 01:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 01:44:44 --> Input Class Initialized
INFO - 2017-01-18 01:44:44 --> Language Class Initialized
INFO - 2017-01-18 01:44:44 --> Loader Class Initialized
INFO - 2017-01-18 01:44:44 --> Database Driver Class Initialized
INFO - 2017-01-18 01:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 01:44:44 --> Controller Class Initialized
INFO - 2017-01-18 01:44:44 --> Helper loaded: url_helper
DEBUG - 2017-01-18 01:44:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 01:44:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 01:44:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 01:44:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 01:44:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 01:44:44 --> Final output sent to browser
DEBUG - 2017-01-18 01:44:44 --> Total execution time: 0.0177
INFO - 2017-01-18 01:45:58 --> Config Class Initialized
INFO - 2017-01-18 01:45:58 --> Hooks Class Initialized
DEBUG - 2017-01-18 01:45:58 --> UTF-8 Support Enabled
INFO - 2017-01-18 01:45:58 --> Utf8 Class Initialized
INFO - 2017-01-18 01:45:58 --> URI Class Initialized
INFO - 2017-01-18 01:45:58 --> Router Class Initialized
INFO - 2017-01-18 01:45:58 --> Output Class Initialized
INFO - 2017-01-18 01:45:58 --> Security Class Initialized
DEBUG - 2017-01-18 01:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 01:45:58 --> Input Class Initialized
INFO - 2017-01-18 01:45:58 --> Language Class Initialized
INFO - 2017-01-18 01:45:58 --> Loader Class Initialized
INFO - 2017-01-18 01:45:58 --> Database Driver Class Initialized
INFO - 2017-01-18 01:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 01:45:58 --> Controller Class Initialized
INFO - 2017-01-18 01:45:58 --> Helper loaded: url_helper
DEBUG - 2017-01-18 01:45:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 01:45:59 --> Config Class Initialized
INFO - 2017-01-18 01:45:59 --> Hooks Class Initialized
DEBUG - 2017-01-18 01:45:59 --> UTF-8 Support Enabled
INFO - 2017-01-18 01:45:59 --> Utf8 Class Initialized
INFO - 2017-01-18 01:45:59 --> URI Class Initialized
INFO - 2017-01-18 01:45:59 --> Router Class Initialized
INFO - 2017-01-18 01:45:59 --> Output Class Initialized
INFO - 2017-01-18 01:45:59 --> Security Class Initialized
DEBUG - 2017-01-18 01:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 01:45:59 --> Input Class Initialized
INFO - 2017-01-18 01:45:59 --> Language Class Initialized
INFO - 2017-01-18 01:45:59 --> Loader Class Initialized
INFO - 2017-01-18 01:45:59 --> Database Driver Class Initialized
INFO - 2017-01-18 01:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 01:45:59 --> Controller Class Initialized
INFO - 2017-01-18 01:45:59 --> Helper loaded: date_helper
DEBUG - 2017-01-18 01:45:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 01:45:59 --> Helper loaded: url_helper
INFO - 2017-01-18 01:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 01:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-18 01:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-18 01:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-18 01:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 01:45:59 --> Final output sent to browser
DEBUG - 2017-01-18 01:45:59 --> Total execution time: 0.0151
INFO - 2017-01-18 01:46:00 --> Config Class Initialized
INFO - 2017-01-18 01:46:00 --> Hooks Class Initialized
DEBUG - 2017-01-18 01:46:00 --> UTF-8 Support Enabled
INFO - 2017-01-18 01:46:00 --> Utf8 Class Initialized
INFO - 2017-01-18 01:46:00 --> URI Class Initialized
INFO - 2017-01-18 01:46:00 --> Router Class Initialized
INFO - 2017-01-18 01:46:00 --> Output Class Initialized
INFO - 2017-01-18 01:46:00 --> Security Class Initialized
DEBUG - 2017-01-18 01:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 01:46:00 --> Input Class Initialized
INFO - 2017-01-18 01:46:00 --> Language Class Initialized
INFO - 2017-01-18 01:46:00 --> Loader Class Initialized
INFO - 2017-01-18 01:46:00 --> Database Driver Class Initialized
INFO - 2017-01-18 01:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 01:46:00 --> Controller Class Initialized
INFO - 2017-01-18 01:46:00 --> Helper loaded: url_helper
DEBUG - 2017-01-18 01:46:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 01:46:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 01:46:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 01:46:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 01:46:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 01:46:00 --> Final output sent to browser
DEBUG - 2017-01-18 01:46:00 --> Total execution time: 0.0210
INFO - 2017-01-18 01:46:10 --> Config Class Initialized
INFO - 2017-01-18 01:46:10 --> Hooks Class Initialized
DEBUG - 2017-01-18 01:46:10 --> UTF-8 Support Enabled
INFO - 2017-01-18 01:46:10 --> Utf8 Class Initialized
INFO - 2017-01-18 01:46:10 --> URI Class Initialized
DEBUG - 2017-01-18 01:46:10 --> No URI present. Default controller set.
INFO - 2017-01-18 01:46:10 --> Router Class Initialized
INFO - 2017-01-18 01:46:10 --> Output Class Initialized
INFO - 2017-01-18 01:46:10 --> Security Class Initialized
DEBUG - 2017-01-18 01:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 01:46:10 --> Input Class Initialized
INFO - 2017-01-18 01:46:10 --> Language Class Initialized
INFO - 2017-01-18 01:46:10 --> Loader Class Initialized
INFO - 2017-01-18 01:46:10 --> Database Driver Class Initialized
INFO - 2017-01-18 01:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 01:46:10 --> Controller Class Initialized
INFO - 2017-01-18 01:46:10 --> Helper loaded: url_helper
DEBUG - 2017-01-18 01:46:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 01:46:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 01:46:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 01:46:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 01:46:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 01:46:10 --> Final output sent to browser
DEBUG - 2017-01-18 01:46:10 --> Total execution time: 0.0134
INFO - 2017-01-18 01:46:12 --> Config Class Initialized
INFO - 2017-01-18 01:46:12 --> Hooks Class Initialized
DEBUG - 2017-01-18 01:46:12 --> UTF-8 Support Enabled
INFO - 2017-01-18 01:46:12 --> Utf8 Class Initialized
INFO - 2017-01-18 01:46:12 --> URI Class Initialized
INFO - 2017-01-18 01:46:12 --> Router Class Initialized
INFO - 2017-01-18 01:46:12 --> Output Class Initialized
INFO - 2017-01-18 01:46:12 --> Security Class Initialized
DEBUG - 2017-01-18 01:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 01:46:12 --> Input Class Initialized
INFO - 2017-01-18 01:46:12 --> Language Class Initialized
INFO - 2017-01-18 01:46:12 --> Loader Class Initialized
INFO - 2017-01-18 01:46:12 --> Database Driver Class Initialized
INFO - 2017-01-18 01:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 01:46:12 --> Controller Class Initialized
INFO - 2017-01-18 01:46:12 --> Helper loaded: url_helper
DEBUG - 2017-01-18 01:46:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 01:46:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 01:46:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 01:46:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 01:46:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 01:46:12 --> Final output sent to browser
DEBUG - 2017-01-18 01:46:12 --> Total execution time: 0.0138
INFO - 2017-01-18 01:47:29 --> Config Class Initialized
INFO - 2017-01-18 01:47:29 --> Hooks Class Initialized
DEBUG - 2017-01-18 01:47:29 --> UTF-8 Support Enabled
INFO - 2017-01-18 01:47:29 --> Utf8 Class Initialized
INFO - 2017-01-18 01:47:29 --> URI Class Initialized
INFO - 2017-01-18 01:47:29 --> Router Class Initialized
INFO - 2017-01-18 01:47:29 --> Output Class Initialized
INFO - 2017-01-18 01:47:29 --> Security Class Initialized
DEBUG - 2017-01-18 01:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 01:47:29 --> Input Class Initialized
INFO - 2017-01-18 01:47:29 --> Language Class Initialized
INFO - 2017-01-18 01:47:29 --> Loader Class Initialized
INFO - 2017-01-18 01:47:29 --> Database Driver Class Initialized
INFO - 2017-01-18 01:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 01:47:29 --> Controller Class Initialized
INFO - 2017-01-18 01:47:29 --> Helper loaded: url_helper
DEBUG - 2017-01-18 01:47:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 01:47:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 01:47:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 01:47:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 01:47:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 01:47:29 --> Final output sent to browser
DEBUG - 2017-01-18 01:47:29 --> Total execution time: 0.0146
INFO - 2017-01-18 01:47:31 --> Config Class Initialized
INFO - 2017-01-18 01:47:31 --> Hooks Class Initialized
DEBUG - 2017-01-18 01:47:31 --> UTF-8 Support Enabled
INFO - 2017-01-18 01:47:31 --> Utf8 Class Initialized
INFO - 2017-01-18 01:47:31 --> URI Class Initialized
INFO - 2017-01-18 01:47:31 --> Router Class Initialized
INFO - 2017-01-18 01:47:31 --> Output Class Initialized
INFO - 2017-01-18 01:47:31 --> Security Class Initialized
DEBUG - 2017-01-18 01:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 01:47:31 --> Input Class Initialized
INFO - 2017-01-18 01:47:31 --> Language Class Initialized
INFO - 2017-01-18 01:47:31 --> Loader Class Initialized
INFO - 2017-01-18 01:47:31 --> Database Driver Class Initialized
INFO - 2017-01-18 01:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 01:47:31 --> Controller Class Initialized
INFO - 2017-01-18 01:47:31 --> Helper loaded: url_helper
DEBUG - 2017-01-18 01:47:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 01:47:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 01:47:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 01:47:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 01:47:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 01:47:31 --> Final output sent to browser
DEBUG - 2017-01-18 01:47:31 --> Total execution time: 0.0138
INFO - 2017-01-18 01:47:43 --> Config Class Initialized
INFO - 2017-01-18 01:47:43 --> Hooks Class Initialized
DEBUG - 2017-01-18 01:47:43 --> UTF-8 Support Enabled
INFO - 2017-01-18 01:47:43 --> Utf8 Class Initialized
INFO - 2017-01-18 01:47:43 --> URI Class Initialized
INFO - 2017-01-18 01:47:43 --> Router Class Initialized
INFO - 2017-01-18 01:47:43 --> Output Class Initialized
INFO - 2017-01-18 01:47:43 --> Security Class Initialized
DEBUG - 2017-01-18 01:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 01:47:43 --> Input Class Initialized
INFO - 2017-01-18 01:47:43 --> Language Class Initialized
INFO - 2017-01-18 01:47:43 --> Loader Class Initialized
INFO - 2017-01-18 01:47:43 --> Database Driver Class Initialized
INFO - 2017-01-18 01:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 01:47:43 --> Controller Class Initialized
INFO - 2017-01-18 01:47:43 --> Helper loaded: url_helper
DEBUG - 2017-01-18 01:47:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 01:47:44 --> Config Class Initialized
INFO - 2017-01-18 01:47:44 --> Hooks Class Initialized
DEBUG - 2017-01-18 01:47:44 --> UTF-8 Support Enabled
INFO - 2017-01-18 01:47:44 --> Utf8 Class Initialized
INFO - 2017-01-18 01:47:44 --> URI Class Initialized
INFO - 2017-01-18 01:47:44 --> Router Class Initialized
INFO - 2017-01-18 01:47:44 --> Output Class Initialized
INFO - 2017-01-18 01:47:44 --> Security Class Initialized
DEBUG - 2017-01-18 01:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 01:47:44 --> Input Class Initialized
INFO - 2017-01-18 01:47:44 --> Language Class Initialized
INFO - 2017-01-18 01:47:44 --> Loader Class Initialized
INFO - 2017-01-18 01:47:44 --> Database Driver Class Initialized
INFO - 2017-01-18 01:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 01:47:44 --> Controller Class Initialized
INFO - 2017-01-18 01:47:44 --> Helper loaded: date_helper
DEBUG - 2017-01-18 01:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 01:47:44 --> Helper loaded: url_helper
INFO - 2017-01-18 01:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 01:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-18 01:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-18 01:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-18 01:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 01:47:44 --> Final output sent to browser
DEBUG - 2017-01-18 01:47:44 --> Total execution time: 0.0646
INFO - 2017-01-18 01:47:45 --> Config Class Initialized
INFO - 2017-01-18 01:47:45 --> Hooks Class Initialized
DEBUG - 2017-01-18 01:47:45 --> UTF-8 Support Enabled
INFO - 2017-01-18 01:47:45 --> Utf8 Class Initialized
INFO - 2017-01-18 01:47:45 --> URI Class Initialized
INFO - 2017-01-18 01:47:45 --> Router Class Initialized
INFO - 2017-01-18 01:47:45 --> Output Class Initialized
INFO - 2017-01-18 01:47:45 --> Security Class Initialized
DEBUG - 2017-01-18 01:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 01:47:45 --> Input Class Initialized
INFO - 2017-01-18 01:47:45 --> Language Class Initialized
INFO - 2017-01-18 01:47:45 --> Loader Class Initialized
INFO - 2017-01-18 01:47:45 --> Database Driver Class Initialized
INFO - 2017-01-18 01:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 01:47:45 --> Controller Class Initialized
INFO - 2017-01-18 01:47:45 --> Helper loaded: url_helper
DEBUG - 2017-01-18 01:47:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 01:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 01:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 01:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 01:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 01:47:45 --> Final output sent to browser
DEBUG - 2017-01-18 01:47:45 --> Total execution time: 0.0136
INFO - 2017-01-18 01:47:49 --> Config Class Initialized
INFO - 2017-01-18 01:47:49 --> Hooks Class Initialized
DEBUG - 2017-01-18 01:47:49 --> UTF-8 Support Enabled
INFO - 2017-01-18 01:47:49 --> Utf8 Class Initialized
INFO - 2017-01-18 01:47:49 --> URI Class Initialized
DEBUG - 2017-01-18 01:47:49 --> No URI present. Default controller set.
INFO - 2017-01-18 01:47:49 --> Router Class Initialized
INFO - 2017-01-18 01:47:49 --> Output Class Initialized
INFO - 2017-01-18 01:47:49 --> Security Class Initialized
DEBUG - 2017-01-18 01:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 01:47:49 --> Input Class Initialized
INFO - 2017-01-18 01:47:49 --> Language Class Initialized
INFO - 2017-01-18 01:47:49 --> Loader Class Initialized
INFO - 2017-01-18 01:47:49 --> Database Driver Class Initialized
INFO - 2017-01-18 01:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 01:47:49 --> Controller Class Initialized
INFO - 2017-01-18 01:47:49 --> Helper loaded: url_helper
DEBUG - 2017-01-18 01:47:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 01:47:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 01:47:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 01:47:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 01:47:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 01:47:49 --> Final output sent to browser
DEBUG - 2017-01-18 01:47:49 --> Total execution time: 0.0137
INFO - 2017-01-18 01:47:50 --> Config Class Initialized
INFO - 2017-01-18 01:47:50 --> Hooks Class Initialized
DEBUG - 2017-01-18 01:47:50 --> UTF-8 Support Enabled
INFO - 2017-01-18 01:47:50 --> Utf8 Class Initialized
INFO - 2017-01-18 01:47:50 --> URI Class Initialized
INFO - 2017-01-18 01:47:50 --> Router Class Initialized
INFO - 2017-01-18 01:47:50 --> Output Class Initialized
INFO - 2017-01-18 01:47:50 --> Security Class Initialized
DEBUG - 2017-01-18 01:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 01:47:50 --> Input Class Initialized
INFO - 2017-01-18 01:47:50 --> Language Class Initialized
INFO - 2017-01-18 01:47:50 --> Loader Class Initialized
INFO - 2017-01-18 01:47:50 --> Database Driver Class Initialized
INFO - 2017-01-18 01:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 01:47:50 --> Controller Class Initialized
INFO - 2017-01-18 01:47:50 --> Helper loaded: url_helper
DEBUG - 2017-01-18 01:47:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 01:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 01:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 01:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 01:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 01:47:50 --> Final output sent to browser
DEBUG - 2017-01-18 01:47:50 --> Total execution time: 0.0137
INFO - 2017-01-18 01:48:05 --> Config Class Initialized
INFO - 2017-01-18 01:48:05 --> Hooks Class Initialized
DEBUG - 2017-01-18 01:48:05 --> UTF-8 Support Enabled
INFO - 2017-01-18 01:48:05 --> Utf8 Class Initialized
INFO - 2017-01-18 01:48:05 --> URI Class Initialized
INFO - 2017-01-18 01:48:05 --> Router Class Initialized
INFO - 2017-01-18 01:48:05 --> Output Class Initialized
INFO - 2017-01-18 01:48:05 --> Security Class Initialized
DEBUG - 2017-01-18 01:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 01:48:05 --> Input Class Initialized
INFO - 2017-01-18 01:48:05 --> Language Class Initialized
INFO - 2017-01-18 01:48:05 --> Loader Class Initialized
INFO - 2017-01-18 01:48:05 --> Database Driver Class Initialized
INFO - 2017-01-18 01:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 01:48:05 --> Controller Class Initialized
INFO - 2017-01-18 01:48:05 --> Helper loaded: url_helper
DEBUG - 2017-01-18 01:48:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 01:48:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 01:48:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 01:48:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 01:48:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 01:48:05 --> Final output sent to browser
DEBUG - 2017-01-18 01:48:05 --> Total execution time: 0.0144
INFO - 2017-01-18 01:48:06 --> Config Class Initialized
INFO - 2017-01-18 01:48:06 --> Hooks Class Initialized
DEBUG - 2017-01-18 01:48:06 --> UTF-8 Support Enabled
INFO - 2017-01-18 01:48:06 --> Utf8 Class Initialized
INFO - 2017-01-18 01:48:06 --> URI Class Initialized
INFO - 2017-01-18 01:48:06 --> Router Class Initialized
INFO - 2017-01-18 01:48:06 --> Output Class Initialized
INFO - 2017-01-18 01:48:06 --> Security Class Initialized
DEBUG - 2017-01-18 01:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 01:48:06 --> Input Class Initialized
INFO - 2017-01-18 01:48:06 --> Language Class Initialized
INFO - 2017-01-18 01:48:06 --> Loader Class Initialized
INFO - 2017-01-18 01:48:06 --> Database Driver Class Initialized
INFO - 2017-01-18 01:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 01:48:06 --> Controller Class Initialized
INFO - 2017-01-18 01:48:06 --> Helper loaded: url_helper
DEBUG - 2017-01-18 01:48:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 01:48:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 01:48:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 01:48:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 01:48:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 01:48:06 --> Final output sent to browser
DEBUG - 2017-01-18 01:48:06 --> Total execution time: 0.0135
INFO - 2017-01-18 01:48:34 --> Config Class Initialized
INFO - 2017-01-18 01:48:34 --> Hooks Class Initialized
DEBUG - 2017-01-18 01:48:34 --> UTF-8 Support Enabled
INFO - 2017-01-18 01:48:34 --> Utf8 Class Initialized
INFO - 2017-01-18 01:48:34 --> URI Class Initialized
INFO - 2017-01-18 01:48:34 --> Router Class Initialized
INFO - 2017-01-18 01:48:34 --> Output Class Initialized
INFO - 2017-01-18 01:48:34 --> Security Class Initialized
DEBUG - 2017-01-18 01:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 01:48:34 --> Input Class Initialized
INFO - 2017-01-18 01:48:34 --> Language Class Initialized
INFO - 2017-01-18 01:48:34 --> Loader Class Initialized
INFO - 2017-01-18 01:48:34 --> Database Driver Class Initialized
INFO - 2017-01-18 01:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 01:48:34 --> Controller Class Initialized
INFO - 2017-01-18 01:48:34 --> Helper loaded: url_helper
DEBUG - 2017-01-18 01:48:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 01:48:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 01:48:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 01:48:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 01:48:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 01:48:34 --> Final output sent to browser
DEBUG - 2017-01-18 01:48:34 --> Total execution time: 0.0152
INFO - 2017-01-18 01:48:35 --> Config Class Initialized
INFO - 2017-01-18 01:48:35 --> Hooks Class Initialized
DEBUG - 2017-01-18 01:48:35 --> UTF-8 Support Enabled
INFO - 2017-01-18 01:48:35 --> Utf8 Class Initialized
INFO - 2017-01-18 01:48:35 --> URI Class Initialized
INFO - 2017-01-18 01:48:35 --> Router Class Initialized
INFO - 2017-01-18 01:48:35 --> Output Class Initialized
INFO - 2017-01-18 01:48:35 --> Security Class Initialized
DEBUG - 2017-01-18 01:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 01:48:35 --> Input Class Initialized
INFO - 2017-01-18 01:48:35 --> Language Class Initialized
INFO - 2017-01-18 01:48:35 --> Loader Class Initialized
INFO - 2017-01-18 01:48:35 --> Database Driver Class Initialized
INFO - 2017-01-18 01:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 01:48:35 --> Controller Class Initialized
INFO - 2017-01-18 01:48:35 --> Helper loaded: url_helper
DEBUG - 2017-01-18 01:48:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 01:48:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 01:48:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 01:48:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 01:48:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 01:48:35 --> Final output sent to browser
DEBUG - 2017-01-18 01:48:35 --> Total execution time: 0.0250
INFO - 2017-01-18 01:48:50 --> Config Class Initialized
INFO - 2017-01-18 01:48:50 --> Hooks Class Initialized
DEBUG - 2017-01-18 01:48:50 --> UTF-8 Support Enabled
INFO - 2017-01-18 01:48:50 --> Utf8 Class Initialized
INFO - 2017-01-18 01:48:50 --> URI Class Initialized
INFO - 2017-01-18 01:48:50 --> Router Class Initialized
INFO - 2017-01-18 01:48:50 --> Output Class Initialized
INFO - 2017-01-18 01:48:50 --> Security Class Initialized
DEBUG - 2017-01-18 01:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 01:48:50 --> Input Class Initialized
INFO - 2017-01-18 01:48:50 --> Language Class Initialized
INFO - 2017-01-18 01:48:50 --> Loader Class Initialized
INFO - 2017-01-18 01:48:50 --> Database Driver Class Initialized
INFO - 2017-01-18 01:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 01:48:50 --> Controller Class Initialized
INFO - 2017-01-18 01:48:50 --> Helper loaded: url_helper
DEBUG - 2017-01-18 01:48:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 01:48:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 01:48:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 01:48:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 01:48:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 01:48:50 --> Final output sent to browser
DEBUG - 2017-01-18 01:48:50 --> Total execution time: 0.0267
INFO - 2017-01-18 01:48:51 --> Config Class Initialized
INFO - 2017-01-18 01:48:51 --> Hooks Class Initialized
DEBUG - 2017-01-18 01:48:51 --> UTF-8 Support Enabled
INFO - 2017-01-18 01:48:51 --> Utf8 Class Initialized
INFO - 2017-01-18 01:48:51 --> URI Class Initialized
INFO - 2017-01-18 01:48:51 --> Router Class Initialized
INFO - 2017-01-18 01:48:51 --> Output Class Initialized
INFO - 2017-01-18 01:48:51 --> Security Class Initialized
DEBUG - 2017-01-18 01:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 01:48:51 --> Input Class Initialized
INFO - 2017-01-18 01:48:51 --> Language Class Initialized
INFO - 2017-01-18 01:48:51 --> Loader Class Initialized
INFO - 2017-01-18 01:48:51 --> Database Driver Class Initialized
INFO - 2017-01-18 01:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 01:48:51 --> Controller Class Initialized
INFO - 2017-01-18 01:48:51 --> Helper loaded: url_helper
DEBUG - 2017-01-18 01:48:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 01:48:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 01:48:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 01:48:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 01:48:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 01:48:51 --> Final output sent to browser
DEBUG - 2017-01-18 01:48:51 --> Total execution time: 0.0163
INFO - 2017-01-18 03:46:40 --> Config Class Initialized
INFO - 2017-01-18 03:46:40 --> Hooks Class Initialized
DEBUG - 2017-01-18 03:46:40 --> UTF-8 Support Enabled
INFO - 2017-01-18 03:46:40 --> Utf8 Class Initialized
INFO - 2017-01-18 03:46:40 --> URI Class Initialized
DEBUG - 2017-01-18 03:46:40 --> No URI present. Default controller set.
INFO - 2017-01-18 03:46:40 --> Router Class Initialized
INFO - 2017-01-18 03:46:40 --> Output Class Initialized
INFO - 2017-01-18 03:46:40 --> Security Class Initialized
DEBUG - 2017-01-18 03:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 03:46:40 --> Input Class Initialized
INFO - 2017-01-18 03:46:40 --> Language Class Initialized
INFO - 2017-01-18 03:46:40 --> Loader Class Initialized
INFO - 2017-01-18 03:46:40 --> Database Driver Class Initialized
INFO - 2017-01-18 03:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 03:46:40 --> Controller Class Initialized
INFO - 2017-01-18 03:46:40 --> Helper loaded: url_helper
DEBUG - 2017-01-18 03:46:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 03:46:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 03:46:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 03:46:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 03:46:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 03:46:40 --> Final output sent to browser
DEBUG - 2017-01-18 03:46:40 --> Total execution time: 0.0131
INFO - 2017-01-18 03:47:03 --> Config Class Initialized
INFO - 2017-01-18 03:47:03 --> Hooks Class Initialized
DEBUG - 2017-01-18 03:47:03 --> UTF-8 Support Enabled
INFO - 2017-01-18 03:47:03 --> Utf8 Class Initialized
INFO - 2017-01-18 03:47:03 --> URI Class Initialized
INFO - 2017-01-18 03:47:03 --> Router Class Initialized
INFO - 2017-01-18 03:47:03 --> Output Class Initialized
INFO - 2017-01-18 03:47:03 --> Security Class Initialized
DEBUG - 2017-01-18 03:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 03:47:03 --> Input Class Initialized
INFO - 2017-01-18 03:47:03 --> Language Class Initialized
INFO - 2017-01-18 03:47:03 --> Loader Class Initialized
INFO - 2017-01-18 03:47:03 --> Database Driver Class Initialized
INFO - 2017-01-18 03:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 03:47:03 --> Controller Class Initialized
INFO - 2017-01-18 03:47:03 --> Helper loaded: url_helper
DEBUG - 2017-01-18 03:47:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 03:47:03 --> Config Class Initialized
INFO - 2017-01-18 03:47:03 --> Hooks Class Initialized
DEBUG - 2017-01-18 03:47:03 --> UTF-8 Support Enabled
INFO - 2017-01-18 03:47:03 --> Utf8 Class Initialized
INFO - 2017-01-18 03:47:03 --> URI Class Initialized
INFO - 2017-01-18 03:47:03 --> Router Class Initialized
INFO - 2017-01-18 03:47:03 --> Output Class Initialized
INFO - 2017-01-18 03:47:03 --> Security Class Initialized
DEBUG - 2017-01-18 03:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 03:47:03 --> Input Class Initialized
INFO - 2017-01-18 03:47:03 --> Language Class Initialized
INFO - 2017-01-18 03:47:03 --> Loader Class Initialized
INFO - 2017-01-18 03:47:03 --> Database Driver Class Initialized
INFO - 2017-01-18 03:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 03:47:03 --> Controller Class Initialized
INFO - 2017-01-18 03:47:03 --> Helper loaded: date_helper
DEBUG - 2017-01-18 03:47:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 03:47:03 --> Helper loaded: url_helper
INFO - 2017-01-18 03:47:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 03:47:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-18 03:47:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-18 03:47:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-18 03:47:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 03:47:03 --> Final output sent to browser
DEBUG - 2017-01-18 03:47:03 --> Total execution time: 0.0152
INFO - 2017-01-18 03:51:00 --> Config Class Initialized
INFO - 2017-01-18 03:51:00 --> Hooks Class Initialized
DEBUG - 2017-01-18 03:51:00 --> UTF-8 Support Enabled
INFO - 2017-01-18 03:51:00 --> Utf8 Class Initialized
INFO - 2017-01-18 03:51:00 --> URI Class Initialized
INFO - 2017-01-18 03:51:00 --> Router Class Initialized
INFO - 2017-01-18 03:51:00 --> Output Class Initialized
INFO - 2017-01-18 03:51:00 --> Security Class Initialized
DEBUG - 2017-01-18 03:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 03:51:00 --> Input Class Initialized
INFO - 2017-01-18 03:51:00 --> Language Class Initialized
INFO - 2017-01-18 03:51:00 --> Loader Class Initialized
INFO - 2017-01-18 03:51:00 --> Database Driver Class Initialized
INFO - 2017-01-18 03:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 03:51:00 --> Controller Class Initialized
INFO - 2017-01-18 03:51:00 --> Helper loaded: date_helper
DEBUG - 2017-01-18 03:51:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 03:51:00 --> Helper loaded: url_helper
INFO - 2017-01-18 03:51:00 --> Helper loaded: download_helper
INFO - 2017-01-18 03:51:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 03:51:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-18 03:51:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-18 03:51:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-18 03:51:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 03:51:00 --> Final output sent to browser
DEBUG - 2017-01-18 03:51:00 --> Total execution time: 0.0191
INFO - 2017-01-18 03:51:22 --> Config Class Initialized
INFO - 2017-01-18 03:51:22 --> Hooks Class Initialized
DEBUG - 2017-01-18 03:51:22 --> UTF-8 Support Enabled
INFO - 2017-01-18 03:51:22 --> Utf8 Class Initialized
INFO - 2017-01-18 03:51:22 --> URI Class Initialized
DEBUG - 2017-01-18 03:51:22 --> No URI present. Default controller set.
INFO - 2017-01-18 03:51:22 --> Router Class Initialized
INFO - 2017-01-18 03:51:22 --> Output Class Initialized
INFO - 2017-01-18 03:51:22 --> Security Class Initialized
DEBUG - 2017-01-18 03:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 03:51:22 --> Input Class Initialized
INFO - 2017-01-18 03:51:22 --> Language Class Initialized
INFO - 2017-01-18 03:51:22 --> Loader Class Initialized
INFO - 2017-01-18 03:51:22 --> Database Driver Class Initialized
INFO - 2017-01-18 03:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 03:51:22 --> Controller Class Initialized
INFO - 2017-01-18 03:51:22 --> Helper loaded: url_helper
DEBUG - 2017-01-18 03:51:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 03:51:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 03:51:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 03:51:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 03:51:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 03:51:22 --> Final output sent to browser
DEBUG - 2017-01-18 03:51:22 --> Total execution time: 0.0132
INFO - 2017-01-18 03:51:32 --> Config Class Initialized
INFO - 2017-01-18 03:51:32 --> Hooks Class Initialized
DEBUG - 2017-01-18 03:51:32 --> UTF-8 Support Enabled
INFO - 2017-01-18 03:51:32 --> Utf8 Class Initialized
INFO - 2017-01-18 03:51:32 --> URI Class Initialized
INFO - 2017-01-18 03:51:32 --> Router Class Initialized
INFO - 2017-01-18 03:51:32 --> Output Class Initialized
INFO - 2017-01-18 03:51:32 --> Security Class Initialized
DEBUG - 2017-01-18 03:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 03:51:32 --> Input Class Initialized
INFO - 2017-01-18 03:51:32 --> Language Class Initialized
INFO - 2017-01-18 03:51:32 --> Loader Class Initialized
INFO - 2017-01-18 03:51:32 --> Database Driver Class Initialized
INFO - 2017-01-18 03:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 03:51:32 --> Controller Class Initialized
INFO - 2017-01-18 03:51:32 --> Helper loaded: url_helper
DEBUG - 2017-01-18 03:51:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 03:51:32 --> Helper loaded: form_helper
INFO - 2017-01-18 03:51:32 --> Form Validation Class Initialized
INFO - 2017-01-18 03:51:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-18 03:51:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-18 03:51:32 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-18 03:51:32 --> Final output sent to browser
DEBUG - 2017-01-18 03:51:32 --> Total execution time: 0.0188
INFO - 2017-01-18 03:52:09 --> Config Class Initialized
INFO - 2017-01-18 03:52:09 --> Hooks Class Initialized
DEBUG - 2017-01-18 03:52:09 --> UTF-8 Support Enabled
INFO - 2017-01-18 03:52:09 --> Utf8 Class Initialized
INFO - 2017-01-18 03:52:09 --> URI Class Initialized
INFO - 2017-01-18 03:52:09 --> Router Class Initialized
INFO - 2017-01-18 03:52:09 --> Output Class Initialized
INFO - 2017-01-18 03:52:09 --> Security Class Initialized
DEBUG - 2017-01-18 03:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 03:52:09 --> Input Class Initialized
INFO - 2017-01-18 03:52:09 --> Language Class Initialized
INFO - 2017-01-18 03:52:09 --> Loader Class Initialized
INFO - 2017-01-18 03:52:09 --> Database Driver Class Initialized
INFO - 2017-01-18 03:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 03:52:09 --> Controller Class Initialized
INFO - 2017-01-18 03:52:09 --> Helper loaded: url_helper
DEBUG - 2017-01-18 03:52:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 03:52:09 --> Helper loaded: form_helper
INFO - 2017-01-18 03:52:09 --> Form Validation Class Initialized
INFO - 2017-01-18 03:52:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-18 03:52:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-18 03:52:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-18 03:52:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-18 03:52:09 --> Final output sent to browser
DEBUG - 2017-01-18 03:52:09 --> Total execution time: 0.0145
INFO - 2017-01-18 03:52:48 --> Config Class Initialized
INFO - 2017-01-18 03:52:48 --> Hooks Class Initialized
DEBUG - 2017-01-18 03:52:48 --> UTF-8 Support Enabled
INFO - 2017-01-18 03:52:48 --> Utf8 Class Initialized
INFO - 2017-01-18 03:52:48 --> URI Class Initialized
INFO - 2017-01-18 03:52:48 --> Router Class Initialized
INFO - 2017-01-18 03:52:48 --> Output Class Initialized
INFO - 2017-01-18 03:52:48 --> Security Class Initialized
DEBUG - 2017-01-18 03:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 03:52:48 --> Input Class Initialized
INFO - 2017-01-18 03:52:48 --> Language Class Initialized
INFO - 2017-01-18 03:52:48 --> Loader Class Initialized
INFO - 2017-01-18 03:52:48 --> Database Driver Class Initialized
INFO - 2017-01-18 03:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 03:52:48 --> Controller Class Initialized
INFO - 2017-01-18 03:52:48 --> Helper loaded: url_helper
DEBUG - 2017-01-18 03:52:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 03:52:48 --> Helper loaded: form_helper
INFO - 2017-01-18 03:52:48 --> Form Validation Class Initialized
INFO - 2017-01-18 03:52:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-18 03:52:48 --> Config Class Initialized
INFO - 2017-01-18 03:52:48 --> Hooks Class Initialized
DEBUG - 2017-01-18 03:52:48 --> UTF-8 Support Enabled
INFO - 2017-01-18 03:52:48 --> Utf8 Class Initialized
INFO - 2017-01-18 03:52:48 --> URI Class Initialized
INFO - 2017-01-18 03:52:48 --> Router Class Initialized
INFO - 2017-01-18 03:52:48 --> Output Class Initialized
INFO - 2017-01-18 03:52:48 --> Security Class Initialized
DEBUG - 2017-01-18 03:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 03:52:48 --> Input Class Initialized
INFO - 2017-01-18 03:52:48 --> Language Class Initialized
INFO - 2017-01-18 03:52:48 --> Loader Class Initialized
INFO - 2017-01-18 03:52:48 --> Database Driver Class Initialized
INFO - 2017-01-18 03:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 03:52:48 --> Controller Class Initialized
INFO - 2017-01-18 03:52:48 --> Helper loaded: date_helper
INFO - 2017-01-18 03:52:48 --> Helper loaded: url_helper
DEBUG - 2017-01-18 03:52:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 03:52:48 --> Helper loaded: form_helper
INFO - 2017-01-18 03:52:48 --> Form Validation Class Initialized
INFO - 2017-01-18 03:52:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-18 03:52:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-18 03:52:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-18 03:52:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-18 03:52:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-18 03:52:48 --> Final output sent to browser
DEBUG - 2017-01-18 03:52:48 --> Total execution time: 0.0145
INFO - 2017-01-18 03:52:49 --> Config Class Initialized
INFO - 2017-01-18 03:52:49 --> Hooks Class Initialized
DEBUG - 2017-01-18 03:52:49 --> UTF-8 Support Enabled
INFO - 2017-01-18 03:52:49 --> Utf8 Class Initialized
INFO - 2017-01-18 03:52:49 --> URI Class Initialized
INFO - 2017-01-18 03:52:49 --> Router Class Initialized
INFO - 2017-01-18 03:52:49 --> Output Class Initialized
INFO - 2017-01-18 03:52:49 --> Security Class Initialized
DEBUG - 2017-01-18 03:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 03:52:49 --> Input Class Initialized
INFO - 2017-01-18 03:52:49 --> Language Class Initialized
INFO - 2017-01-18 03:52:49 --> Loader Class Initialized
INFO - 2017-01-18 03:52:49 --> Database Driver Class Initialized
INFO - 2017-01-18 03:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 03:52:49 --> Controller Class Initialized
INFO - 2017-01-18 03:52:49 --> Helper loaded: date_helper
INFO - 2017-01-18 03:52:49 --> Helper loaded: url_helper
DEBUG - 2017-01-18 03:52:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 03:52:49 --> Helper loaded: form_helper
INFO - 2017-01-18 03:52:49 --> Form Validation Class Initialized
INFO - 2017-01-18 03:52:49 --> Final output sent to browser
DEBUG - 2017-01-18 03:52:49 --> Total execution time: 0.0146
INFO - 2017-01-18 03:53:00 --> Config Class Initialized
INFO - 2017-01-18 03:53:00 --> Hooks Class Initialized
DEBUG - 2017-01-18 03:53:00 --> UTF-8 Support Enabled
INFO - 2017-01-18 03:53:00 --> Utf8 Class Initialized
INFO - 2017-01-18 03:53:00 --> URI Class Initialized
INFO - 2017-01-18 03:53:00 --> Router Class Initialized
INFO - 2017-01-18 03:53:00 --> Output Class Initialized
INFO - 2017-01-18 03:53:00 --> Security Class Initialized
DEBUG - 2017-01-18 03:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 03:53:00 --> Input Class Initialized
INFO - 2017-01-18 03:53:00 --> Language Class Initialized
INFO - 2017-01-18 03:53:00 --> Loader Class Initialized
INFO - 2017-01-18 03:53:00 --> Database Driver Class Initialized
INFO - 2017-01-18 03:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 03:53:00 --> Controller Class Initialized
INFO - 2017-01-18 03:53:00 --> Upload Class Initialized
INFO - 2017-01-18 03:53:00 --> Helper loaded: url_helper
DEBUG - 2017-01-18 03:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 03:53:00 --> Helper loaded: form_helper
INFO - 2017-01-18 03:53:00 --> Form Validation Class Initialized
INFO - 2017-01-18 03:53:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-18 03:53:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-18 03:53:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-18 03:53:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-18 03:53:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-18 03:53:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-18 03:53:00 --> Final output sent to browser
DEBUG - 2017-01-18 03:53:00 --> Total execution time: 0.0191
INFO - 2017-01-18 03:54:06 --> Config Class Initialized
INFO - 2017-01-18 03:54:06 --> Hooks Class Initialized
DEBUG - 2017-01-18 03:54:06 --> UTF-8 Support Enabled
INFO - 2017-01-18 03:54:06 --> Utf8 Class Initialized
INFO - 2017-01-18 03:54:06 --> URI Class Initialized
INFO - 2017-01-18 03:54:06 --> Router Class Initialized
INFO - 2017-01-18 03:54:06 --> Output Class Initialized
INFO - 2017-01-18 03:54:06 --> Security Class Initialized
DEBUG - 2017-01-18 03:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 03:54:06 --> Input Class Initialized
INFO - 2017-01-18 03:54:06 --> Language Class Initialized
INFO - 2017-01-18 03:54:06 --> Loader Class Initialized
INFO - 2017-01-18 03:54:06 --> Database Driver Class Initialized
INFO - 2017-01-18 03:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 03:54:06 --> Controller Class Initialized
INFO - 2017-01-18 03:54:06 --> Helper loaded: url_helper
DEBUG - 2017-01-18 03:54:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 03:54:07 --> Config Class Initialized
INFO - 2017-01-18 03:54:07 --> Hooks Class Initialized
DEBUG - 2017-01-18 03:54:07 --> UTF-8 Support Enabled
INFO - 2017-01-18 03:54:07 --> Utf8 Class Initialized
INFO - 2017-01-18 03:54:07 --> URI Class Initialized
INFO - 2017-01-18 03:54:07 --> Router Class Initialized
INFO - 2017-01-18 03:54:07 --> Output Class Initialized
INFO - 2017-01-18 03:54:07 --> Security Class Initialized
DEBUG - 2017-01-18 03:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 03:54:07 --> Input Class Initialized
INFO - 2017-01-18 03:54:07 --> Language Class Initialized
INFO - 2017-01-18 03:54:07 --> Loader Class Initialized
INFO - 2017-01-18 03:54:07 --> Database Driver Class Initialized
INFO - 2017-01-18 03:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 03:54:07 --> Controller Class Initialized
INFO - 2017-01-18 03:54:07 --> Helper loaded: url_helper
DEBUG - 2017-01-18 03:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 03:54:07 --> Helper loaded: form_helper
INFO - 2017-01-18 03:54:07 --> Form Validation Class Initialized
INFO - 2017-01-18 03:54:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-18 03:54:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-18 03:54:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-18 03:54:07 --> Final output sent to browser
DEBUG - 2017-01-18 03:54:07 --> Total execution time: 0.0132
INFO - 2017-01-18 05:34:10 --> Config Class Initialized
INFO - 2017-01-18 05:34:10 --> Hooks Class Initialized
DEBUG - 2017-01-18 05:34:10 --> UTF-8 Support Enabled
INFO - 2017-01-18 05:34:10 --> Utf8 Class Initialized
INFO - 2017-01-18 05:34:10 --> URI Class Initialized
DEBUG - 2017-01-18 05:34:10 --> No URI present. Default controller set.
INFO - 2017-01-18 05:34:10 --> Router Class Initialized
INFO - 2017-01-18 05:34:10 --> Output Class Initialized
INFO - 2017-01-18 05:34:10 --> Security Class Initialized
DEBUG - 2017-01-18 05:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 05:34:10 --> Input Class Initialized
INFO - 2017-01-18 05:34:10 --> Language Class Initialized
INFO - 2017-01-18 05:34:10 --> Loader Class Initialized
INFO - 2017-01-18 05:34:10 --> Database Driver Class Initialized
INFO - 2017-01-18 05:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 05:34:10 --> Controller Class Initialized
INFO - 2017-01-18 05:34:10 --> Helper loaded: url_helper
DEBUG - 2017-01-18 05:34:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 05:34:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 05:34:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 05:34:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 05:34:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 05:34:10 --> Final output sent to browser
DEBUG - 2017-01-18 05:34:10 --> Total execution time: 0.0135
INFO - 2017-01-18 05:34:14 --> Config Class Initialized
INFO - 2017-01-18 05:34:14 --> Hooks Class Initialized
DEBUG - 2017-01-18 05:34:14 --> UTF-8 Support Enabled
INFO - 2017-01-18 05:34:14 --> Utf8 Class Initialized
INFO - 2017-01-18 05:34:14 --> URI Class Initialized
INFO - 2017-01-18 05:34:14 --> Router Class Initialized
INFO - 2017-01-18 05:34:14 --> Output Class Initialized
INFO - 2017-01-18 05:34:14 --> Security Class Initialized
DEBUG - 2017-01-18 05:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 05:34:14 --> Input Class Initialized
INFO - 2017-01-18 05:34:14 --> Language Class Initialized
INFO - 2017-01-18 05:34:14 --> Loader Class Initialized
INFO - 2017-01-18 05:34:14 --> Database Driver Class Initialized
INFO - 2017-01-18 05:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 05:34:14 --> Controller Class Initialized
INFO - 2017-01-18 05:34:14 --> Helper loaded: url_helper
DEBUG - 2017-01-18 05:34:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 05:34:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 05:34:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 05:34:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 05:34:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 05:34:14 --> Final output sent to browser
DEBUG - 2017-01-18 05:34:14 --> Total execution time: 0.0137
INFO - 2017-01-18 05:47:44 --> Config Class Initialized
INFO - 2017-01-18 05:47:44 --> Hooks Class Initialized
DEBUG - 2017-01-18 05:47:44 --> UTF-8 Support Enabled
INFO - 2017-01-18 05:47:44 --> Utf8 Class Initialized
INFO - 2017-01-18 05:47:44 --> URI Class Initialized
DEBUG - 2017-01-18 05:47:44 --> No URI present. Default controller set.
INFO - 2017-01-18 05:47:44 --> Router Class Initialized
INFO - 2017-01-18 05:47:44 --> Output Class Initialized
INFO - 2017-01-18 05:47:44 --> Security Class Initialized
DEBUG - 2017-01-18 05:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 05:47:44 --> Input Class Initialized
INFO - 2017-01-18 05:47:44 --> Language Class Initialized
INFO - 2017-01-18 05:47:44 --> Loader Class Initialized
INFO - 2017-01-18 05:47:44 --> Database Driver Class Initialized
INFO - 2017-01-18 05:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 05:47:44 --> Controller Class Initialized
INFO - 2017-01-18 05:47:44 --> Helper loaded: url_helper
DEBUG - 2017-01-18 05:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 05:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 05:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 05:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 05:47:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 05:47:44 --> Final output sent to browser
DEBUG - 2017-01-18 05:47:44 --> Total execution time: 0.0142
INFO - 2017-01-18 05:47:52 --> Config Class Initialized
INFO - 2017-01-18 05:47:52 --> Hooks Class Initialized
DEBUG - 2017-01-18 05:47:52 --> UTF-8 Support Enabled
INFO - 2017-01-18 05:47:52 --> Utf8 Class Initialized
INFO - 2017-01-18 05:47:52 --> URI Class Initialized
INFO - 2017-01-18 05:47:52 --> Router Class Initialized
INFO - 2017-01-18 05:47:52 --> Output Class Initialized
INFO - 2017-01-18 05:47:52 --> Security Class Initialized
DEBUG - 2017-01-18 05:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 05:47:52 --> Input Class Initialized
INFO - 2017-01-18 05:47:52 --> Language Class Initialized
INFO - 2017-01-18 05:47:52 --> Loader Class Initialized
INFO - 2017-01-18 05:47:52 --> Database Driver Class Initialized
INFO - 2017-01-18 05:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 05:47:52 --> Controller Class Initialized
INFO - 2017-01-18 05:47:52 --> Helper loaded: url_helper
DEBUG - 2017-01-18 05:47:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 05:47:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 05:47:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 05:47:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 05:47:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 05:47:52 --> Final output sent to browser
DEBUG - 2017-01-18 05:47:52 --> Total execution time: 0.0137
INFO - 2017-01-18 05:48:37 --> Config Class Initialized
INFO - 2017-01-18 05:48:37 --> Hooks Class Initialized
DEBUG - 2017-01-18 05:48:37 --> UTF-8 Support Enabled
INFO - 2017-01-18 05:48:37 --> Utf8 Class Initialized
INFO - 2017-01-18 05:48:37 --> URI Class Initialized
INFO - 2017-01-18 05:48:37 --> Router Class Initialized
INFO - 2017-01-18 05:48:37 --> Output Class Initialized
INFO - 2017-01-18 05:48:37 --> Security Class Initialized
DEBUG - 2017-01-18 05:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 05:48:37 --> Input Class Initialized
INFO - 2017-01-18 05:48:37 --> Language Class Initialized
INFO - 2017-01-18 05:48:37 --> Loader Class Initialized
INFO - 2017-01-18 05:48:37 --> Database Driver Class Initialized
INFO - 2017-01-18 05:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 05:48:37 --> Controller Class Initialized
INFO - 2017-01-18 05:48:37 --> Helper loaded: url_helper
DEBUG - 2017-01-18 05:48:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 05:48:39 --> Config Class Initialized
INFO - 2017-01-18 05:48:39 --> Hooks Class Initialized
DEBUG - 2017-01-18 05:48:39 --> UTF-8 Support Enabled
INFO - 2017-01-18 05:48:39 --> Utf8 Class Initialized
INFO - 2017-01-18 05:48:39 --> URI Class Initialized
INFO - 2017-01-18 05:48:39 --> Router Class Initialized
INFO - 2017-01-18 05:48:39 --> Output Class Initialized
INFO - 2017-01-18 05:48:39 --> Security Class Initialized
DEBUG - 2017-01-18 05:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 05:48:39 --> Input Class Initialized
INFO - 2017-01-18 05:48:39 --> Language Class Initialized
INFO - 2017-01-18 05:48:39 --> Loader Class Initialized
INFO - 2017-01-18 05:48:39 --> Database Driver Class Initialized
INFO - 2017-01-18 05:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 05:48:39 --> Controller Class Initialized
INFO - 2017-01-18 05:48:39 --> Helper loaded: date_helper
DEBUG - 2017-01-18 05:48:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 05:48:39 --> Helper loaded: url_helper
INFO - 2017-01-18 05:48:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 05:48:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-18 05:48:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-18 05:48:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-18 05:48:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 05:48:39 --> Final output sent to browser
DEBUG - 2017-01-18 05:48:39 --> Total execution time: 0.0136
INFO - 2017-01-18 05:48:40 --> Config Class Initialized
INFO - 2017-01-18 05:48:40 --> Hooks Class Initialized
DEBUG - 2017-01-18 05:48:40 --> UTF-8 Support Enabled
INFO - 2017-01-18 05:48:40 --> Utf8 Class Initialized
INFO - 2017-01-18 05:48:40 --> URI Class Initialized
INFO - 2017-01-18 05:48:40 --> Router Class Initialized
INFO - 2017-01-18 05:48:40 --> Output Class Initialized
INFO - 2017-01-18 05:48:40 --> Security Class Initialized
DEBUG - 2017-01-18 05:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 05:48:40 --> Input Class Initialized
INFO - 2017-01-18 05:48:40 --> Language Class Initialized
INFO - 2017-01-18 05:48:40 --> Loader Class Initialized
INFO - 2017-01-18 05:48:40 --> Database Driver Class Initialized
INFO - 2017-01-18 05:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 05:48:40 --> Controller Class Initialized
INFO - 2017-01-18 05:48:40 --> Helper loaded: url_helper
DEBUG - 2017-01-18 05:48:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 05:48:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 05:48:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 05:48:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 05:48:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 05:48:40 --> Final output sent to browser
DEBUG - 2017-01-18 05:48:40 --> Total execution time: 0.0142
INFO - 2017-01-18 05:48:45 --> Config Class Initialized
INFO - 2017-01-18 05:48:45 --> Hooks Class Initialized
DEBUG - 2017-01-18 05:48:45 --> UTF-8 Support Enabled
INFO - 2017-01-18 05:48:45 --> Utf8 Class Initialized
INFO - 2017-01-18 05:48:45 --> URI Class Initialized
INFO - 2017-01-18 05:48:45 --> Router Class Initialized
INFO - 2017-01-18 05:48:45 --> Output Class Initialized
INFO - 2017-01-18 05:48:45 --> Security Class Initialized
DEBUG - 2017-01-18 05:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 05:48:45 --> Input Class Initialized
INFO - 2017-01-18 05:48:45 --> Language Class Initialized
INFO - 2017-01-18 05:48:45 --> Loader Class Initialized
INFO - 2017-01-18 05:48:45 --> Database Driver Class Initialized
INFO - 2017-01-18 05:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 05:48:45 --> Controller Class Initialized
INFO - 2017-01-18 05:48:45 --> Helper loaded: url_helper
DEBUG - 2017-01-18 05:48:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 05:48:45 --> Config Class Initialized
INFO - 2017-01-18 05:48:45 --> Hooks Class Initialized
DEBUG - 2017-01-18 05:48:45 --> UTF-8 Support Enabled
INFO - 2017-01-18 05:48:45 --> Utf8 Class Initialized
INFO - 2017-01-18 05:48:45 --> URI Class Initialized
INFO - 2017-01-18 05:48:45 --> Router Class Initialized
INFO - 2017-01-18 05:48:45 --> Output Class Initialized
INFO - 2017-01-18 05:48:45 --> Security Class Initialized
DEBUG - 2017-01-18 05:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 05:48:45 --> Input Class Initialized
INFO - 2017-01-18 05:48:45 --> Language Class Initialized
INFO - 2017-01-18 05:48:45 --> Loader Class Initialized
INFO - 2017-01-18 05:48:45 --> Database Driver Class Initialized
INFO - 2017-01-18 05:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 05:48:45 --> Controller Class Initialized
INFO - 2017-01-18 05:48:46 --> Helper loaded: date_helper
DEBUG - 2017-01-18 05:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 05:48:46 --> Helper loaded: url_helper
INFO - 2017-01-18 05:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 05:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-18 05:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-18 05:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-18 05:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 05:48:46 --> Final output sent to browser
DEBUG - 2017-01-18 05:48:46 --> Total execution time: 0.0141
INFO - 2017-01-18 05:48:46 --> Config Class Initialized
INFO - 2017-01-18 05:48:46 --> Hooks Class Initialized
DEBUG - 2017-01-18 05:48:46 --> UTF-8 Support Enabled
INFO - 2017-01-18 05:48:46 --> Utf8 Class Initialized
INFO - 2017-01-18 05:48:46 --> URI Class Initialized
INFO - 2017-01-18 05:48:46 --> Router Class Initialized
INFO - 2017-01-18 05:48:46 --> Output Class Initialized
INFO - 2017-01-18 05:48:46 --> Security Class Initialized
DEBUG - 2017-01-18 05:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 05:48:46 --> Input Class Initialized
INFO - 2017-01-18 05:48:46 --> Language Class Initialized
INFO - 2017-01-18 05:48:46 --> Loader Class Initialized
INFO - 2017-01-18 05:48:46 --> Database Driver Class Initialized
INFO - 2017-01-18 05:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 05:48:46 --> Controller Class Initialized
INFO - 2017-01-18 05:48:46 --> Helper loaded: url_helper
DEBUG - 2017-01-18 05:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 05:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 05:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 05:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 05:48:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 05:48:46 --> Final output sent to browser
DEBUG - 2017-01-18 05:48:46 --> Total execution time: 0.0135
INFO - 2017-01-18 05:48:50 --> Config Class Initialized
INFO - 2017-01-18 05:48:50 --> Hooks Class Initialized
DEBUG - 2017-01-18 05:48:50 --> UTF-8 Support Enabled
INFO - 2017-01-18 05:48:50 --> Utf8 Class Initialized
INFO - 2017-01-18 05:48:50 --> URI Class Initialized
DEBUG - 2017-01-18 05:48:50 --> No URI present. Default controller set.
INFO - 2017-01-18 05:48:50 --> Router Class Initialized
INFO - 2017-01-18 05:48:50 --> Output Class Initialized
INFO - 2017-01-18 05:48:50 --> Security Class Initialized
DEBUG - 2017-01-18 05:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 05:48:50 --> Input Class Initialized
INFO - 2017-01-18 05:48:50 --> Language Class Initialized
INFO - 2017-01-18 05:48:50 --> Loader Class Initialized
INFO - 2017-01-18 05:48:50 --> Database Driver Class Initialized
INFO - 2017-01-18 05:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 05:48:50 --> Controller Class Initialized
INFO - 2017-01-18 05:48:50 --> Helper loaded: url_helper
DEBUG - 2017-01-18 05:48:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 05:48:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 05:48:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 05:48:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 05:48:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 05:48:50 --> Final output sent to browser
DEBUG - 2017-01-18 05:48:50 --> Total execution time: 0.0213
INFO - 2017-01-18 05:48:55 --> Config Class Initialized
INFO - 2017-01-18 05:48:55 --> Hooks Class Initialized
DEBUG - 2017-01-18 05:48:55 --> UTF-8 Support Enabled
INFO - 2017-01-18 05:48:55 --> Utf8 Class Initialized
INFO - 2017-01-18 05:48:55 --> URI Class Initialized
INFO - 2017-01-18 05:48:55 --> Router Class Initialized
INFO - 2017-01-18 05:48:55 --> Output Class Initialized
INFO - 2017-01-18 05:48:55 --> Security Class Initialized
DEBUG - 2017-01-18 05:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 05:48:55 --> Input Class Initialized
INFO - 2017-01-18 05:48:55 --> Language Class Initialized
INFO - 2017-01-18 05:48:55 --> Loader Class Initialized
INFO - 2017-01-18 05:48:55 --> Database Driver Class Initialized
INFO - 2017-01-18 05:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 05:48:55 --> Controller Class Initialized
INFO - 2017-01-18 05:48:55 --> Helper loaded: url_helper
DEBUG - 2017-01-18 05:48:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 05:48:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 05:48:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 05:48:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 05:48:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 05:48:55 --> Final output sent to browser
DEBUG - 2017-01-18 05:48:55 --> Total execution time: 0.0145
INFO - 2017-01-18 05:50:13 --> Config Class Initialized
INFO - 2017-01-18 05:50:13 --> Hooks Class Initialized
DEBUG - 2017-01-18 05:50:13 --> UTF-8 Support Enabled
INFO - 2017-01-18 05:50:13 --> Utf8 Class Initialized
INFO - 2017-01-18 05:50:13 --> URI Class Initialized
DEBUG - 2017-01-18 05:50:13 --> No URI present. Default controller set.
INFO - 2017-01-18 05:50:13 --> Router Class Initialized
INFO - 2017-01-18 05:50:13 --> Output Class Initialized
INFO - 2017-01-18 05:50:13 --> Security Class Initialized
DEBUG - 2017-01-18 05:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 05:50:13 --> Input Class Initialized
INFO - 2017-01-18 05:50:13 --> Language Class Initialized
INFO - 2017-01-18 05:50:13 --> Loader Class Initialized
INFO - 2017-01-18 05:50:13 --> Database Driver Class Initialized
INFO - 2017-01-18 05:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 05:50:13 --> Controller Class Initialized
INFO - 2017-01-18 05:50:13 --> Helper loaded: url_helper
DEBUG - 2017-01-18 05:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 05:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 05:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 05:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 05:50:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 05:50:13 --> Final output sent to browser
DEBUG - 2017-01-18 05:50:13 --> Total execution time: 0.0139
INFO - 2017-01-18 05:50:17 --> Config Class Initialized
INFO - 2017-01-18 05:50:17 --> Hooks Class Initialized
DEBUG - 2017-01-18 05:50:17 --> UTF-8 Support Enabled
INFO - 2017-01-18 05:50:17 --> Utf8 Class Initialized
INFO - 2017-01-18 05:50:17 --> URI Class Initialized
INFO - 2017-01-18 05:50:17 --> Router Class Initialized
INFO - 2017-01-18 05:50:17 --> Output Class Initialized
INFO - 2017-01-18 05:50:17 --> Security Class Initialized
DEBUG - 2017-01-18 05:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 05:50:17 --> Input Class Initialized
INFO - 2017-01-18 05:50:17 --> Language Class Initialized
INFO - 2017-01-18 05:50:17 --> Loader Class Initialized
INFO - 2017-01-18 05:50:17 --> Database Driver Class Initialized
INFO - 2017-01-18 05:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 05:50:17 --> Controller Class Initialized
INFO - 2017-01-18 05:50:17 --> Helper loaded: url_helper
DEBUG - 2017-01-18 05:50:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 05:50:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 05:50:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 05:50:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 05:50:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 05:50:17 --> Final output sent to browser
DEBUG - 2017-01-18 05:50:17 --> Total execution time: 0.0136
INFO - 2017-01-18 05:50:27 --> Config Class Initialized
INFO - 2017-01-18 05:50:27 --> Hooks Class Initialized
DEBUG - 2017-01-18 05:50:27 --> UTF-8 Support Enabled
INFO - 2017-01-18 05:50:27 --> Utf8 Class Initialized
INFO - 2017-01-18 05:50:27 --> URI Class Initialized
INFO - 2017-01-18 05:50:27 --> Router Class Initialized
INFO - 2017-01-18 05:50:27 --> Output Class Initialized
INFO - 2017-01-18 05:50:27 --> Security Class Initialized
DEBUG - 2017-01-18 05:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 05:50:27 --> Input Class Initialized
INFO - 2017-01-18 05:50:27 --> Language Class Initialized
INFO - 2017-01-18 05:50:27 --> Loader Class Initialized
INFO - 2017-01-18 05:50:27 --> Database Driver Class Initialized
INFO - 2017-01-18 05:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 05:50:27 --> Controller Class Initialized
INFO - 2017-01-18 05:50:27 --> Helper loaded: url_helper
DEBUG - 2017-01-18 05:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 05:50:29 --> Config Class Initialized
INFO - 2017-01-18 05:50:29 --> Hooks Class Initialized
DEBUG - 2017-01-18 05:50:29 --> UTF-8 Support Enabled
INFO - 2017-01-18 05:50:29 --> Utf8 Class Initialized
INFO - 2017-01-18 05:50:29 --> URI Class Initialized
INFO - 2017-01-18 05:50:29 --> Router Class Initialized
INFO - 2017-01-18 05:50:29 --> Output Class Initialized
INFO - 2017-01-18 05:50:29 --> Security Class Initialized
DEBUG - 2017-01-18 05:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 05:50:29 --> Input Class Initialized
INFO - 2017-01-18 05:50:29 --> Language Class Initialized
INFO - 2017-01-18 05:50:29 --> Loader Class Initialized
INFO - 2017-01-18 05:50:29 --> Database Driver Class Initialized
INFO - 2017-01-18 05:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 05:50:29 --> Controller Class Initialized
INFO - 2017-01-18 05:50:29 --> Helper loaded: date_helper
DEBUG - 2017-01-18 05:50:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 05:50:29 --> Helper loaded: url_helper
INFO - 2017-01-18 05:50:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 05:50:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-18 05:50:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-18 05:50:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-18 05:50:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 05:50:29 --> Final output sent to browser
DEBUG - 2017-01-18 05:50:29 --> Total execution time: 0.0148
INFO - 2017-01-18 05:50:30 --> Config Class Initialized
INFO - 2017-01-18 05:50:30 --> Hooks Class Initialized
DEBUG - 2017-01-18 05:50:30 --> UTF-8 Support Enabled
INFO - 2017-01-18 05:50:30 --> Utf8 Class Initialized
INFO - 2017-01-18 05:50:30 --> URI Class Initialized
INFO - 2017-01-18 05:50:30 --> Router Class Initialized
INFO - 2017-01-18 05:50:30 --> Output Class Initialized
INFO - 2017-01-18 05:50:30 --> Security Class Initialized
DEBUG - 2017-01-18 05:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 05:50:30 --> Input Class Initialized
INFO - 2017-01-18 05:50:30 --> Language Class Initialized
INFO - 2017-01-18 05:50:30 --> Loader Class Initialized
INFO - 2017-01-18 05:50:30 --> Database Driver Class Initialized
INFO - 2017-01-18 05:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 05:50:30 --> Controller Class Initialized
INFO - 2017-01-18 05:50:30 --> Helper loaded: url_helper
DEBUG - 2017-01-18 05:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 05:50:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 05:50:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 05:50:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 05:50:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 05:50:30 --> Final output sent to browser
DEBUG - 2017-01-18 05:50:30 --> Total execution time: 0.0145
INFO - 2017-01-18 05:50:38 --> Config Class Initialized
INFO - 2017-01-18 05:50:38 --> Hooks Class Initialized
DEBUG - 2017-01-18 05:50:38 --> UTF-8 Support Enabled
INFO - 2017-01-18 05:50:38 --> Utf8 Class Initialized
INFO - 2017-01-18 05:50:38 --> URI Class Initialized
DEBUG - 2017-01-18 05:50:38 --> No URI present. Default controller set.
INFO - 2017-01-18 05:50:38 --> Router Class Initialized
INFO - 2017-01-18 05:50:38 --> Output Class Initialized
INFO - 2017-01-18 05:50:38 --> Security Class Initialized
DEBUG - 2017-01-18 05:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 05:50:38 --> Input Class Initialized
INFO - 2017-01-18 05:50:38 --> Language Class Initialized
INFO - 2017-01-18 05:50:38 --> Loader Class Initialized
INFO - 2017-01-18 05:50:38 --> Database Driver Class Initialized
INFO - 2017-01-18 05:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 05:50:38 --> Controller Class Initialized
INFO - 2017-01-18 05:50:38 --> Helper loaded: url_helper
DEBUG - 2017-01-18 05:50:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 05:50:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 05:50:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 05:50:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 05:50:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 05:50:38 --> Final output sent to browser
DEBUG - 2017-01-18 05:50:38 --> Total execution time: 0.0132
INFO - 2017-01-18 05:50:41 --> Config Class Initialized
INFO - 2017-01-18 05:50:41 --> Hooks Class Initialized
DEBUG - 2017-01-18 05:50:41 --> UTF-8 Support Enabled
INFO - 2017-01-18 05:50:41 --> Utf8 Class Initialized
INFO - 2017-01-18 05:50:41 --> URI Class Initialized
INFO - 2017-01-18 05:50:41 --> Router Class Initialized
INFO - 2017-01-18 05:50:41 --> Output Class Initialized
INFO - 2017-01-18 05:50:41 --> Security Class Initialized
DEBUG - 2017-01-18 05:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 05:50:41 --> Input Class Initialized
INFO - 2017-01-18 05:50:41 --> Language Class Initialized
INFO - 2017-01-18 05:50:41 --> Loader Class Initialized
INFO - 2017-01-18 05:50:41 --> Database Driver Class Initialized
INFO - 2017-01-18 05:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 05:50:41 --> Controller Class Initialized
INFO - 2017-01-18 05:50:41 --> Helper loaded: url_helper
DEBUG - 2017-01-18 05:50:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 05:50:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 05:50:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 05:50:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 05:50:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 05:50:41 --> Final output sent to browser
DEBUG - 2017-01-18 05:50:41 --> Total execution time: 0.0134
INFO - 2017-01-18 16:07:22 --> Config Class Initialized
INFO - 2017-01-18 16:07:22 --> Hooks Class Initialized
DEBUG - 2017-01-18 16:07:22 --> UTF-8 Support Enabled
INFO - 2017-01-18 16:07:22 --> Utf8 Class Initialized
INFO - 2017-01-18 16:07:22 --> URI Class Initialized
INFO - 2017-01-18 16:07:22 --> Router Class Initialized
INFO - 2017-01-18 16:07:22 --> Output Class Initialized
INFO - 2017-01-18 16:07:22 --> Security Class Initialized
DEBUG - 2017-01-18 16:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 16:07:22 --> Input Class Initialized
INFO - 2017-01-18 16:07:22 --> Language Class Initialized
INFO - 2017-01-18 16:07:22 --> Loader Class Initialized
INFO - 2017-01-18 16:07:22 --> Database Driver Class Initialized
INFO - 2017-01-18 16:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 16:07:22 --> Controller Class Initialized
INFO - 2017-01-18 16:07:22 --> Helper loaded: url_helper
DEBUG - 2017-01-18 16:07:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 16:07:22 --> Helper loaded: form_helper
INFO - 2017-01-18 16:07:22 --> Form Validation Class Initialized
INFO - 2017-01-18 16:07:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-18 16:07:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-18 16:07:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-18 16:07:22 --> Final output sent to browser
DEBUG - 2017-01-18 16:07:22 --> Total execution time: 0.0946
INFO - 2017-01-18 16:59:03 --> Config Class Initialized
INFO - 2017-01-18 16:59:03 --> Hooks Class Initialized
DEBUG - 2017-01-18 16:59:03 --> UTF-8 Support Enabled
INFO - 2017-01-18 16:59:03 --> Utf8 Class Initialized
INFO - 2017-01-18 16:59:03 --> URI Class Initialized
DEBUG - 2017-01-18 16:59:03 --> No URI present. Default controller set.
INFO - 2017-01-18 16:59:03 --> Router Class Initialized
INFO - 2017-01-18 16:59:03 --> Output Class Initialized
INFO - 2017-01-18 16:59:03 --> Security Class Initialized
DEBUG - 2017-01-18 16:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 16:59:03 --> Input Class Initialized
INFO - 2017-01-18 16:59:03 --> Language Class Initialized
INFO - 2017-01-18 16:59:03 --> Loader Class Initialized
INFO - 2017-01-18 16:59:03 --> Database Driver Class Initialized
INFO - 2017-01-18 16:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 16:59:03 --> Controller Class Initialized
INFO - 2017-01-18 16:59:03 --> Helper loaded: url_helper
DEBUG - 2017-01-18 16:59:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 16:59:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 16:59:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 16:59:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 16:59:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 16:59:03 --> Final output sent to browser
DEBUG - 2017-01-18 16:59:03 --> Total execution time: 0.0333
INFO - 2017-01-18 16:59:07 --> Config Class Initialized
INFO - 2017-01-18 16:59:07 --> Hooks Class Initialized
DEBUG - 2017-01-18 16:59:07 --> UTF-8 Support Enabled
INFO - 2017-01-18 16:59:07 --> Utf8 Class Initialized
INFO - 2017-01-18 16:59:07 --> URI Class Initialized
INFO - 2017-01-18 16:59:07 --> Router Class Initialized
INFO - 2017-01-18 16:59:07 --> Output Class Initialized
INFO - 2017-01-18 16:59:07 --> Security Class Initialized
DEBUG - 2017-01-18 16:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 16:59:07 --> Input Class Initialized
INFO - 2017-01-18 16:59:07 --> Language Class Initialized
INFO - 2017-01-18 16:59:07 --> Loader Class Initialized
INFO - 2017-01-18 16:59:07 --> Database Driver Class Initialized
INFO - 2017-01-18 16:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 16:59:07 --> Controller Class Initialized
INFO - 2017-01-18 16:59:07 --> Helper loaded: url_helper
DEBUG - 2017-01-18 16:59:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 16:59:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 16:59:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 16:59:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 16:59:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 16:59:07 --> Final output sent to browser
DEBUG - 2017-01-18 16:59:07 --> Total execution time: 0.0360
INFO - 2017-01-18 16:59:32 --> Config Class Initialized
INFO - 2017-01-18 16:59:32 --> Hooks Class Initialized
DEBUG - 2017-01-18 16:59:32 --> UTF-8 Support Enabled
INFO - 2017-01-18 16:59:32 --> Utf8 Class Initialized
INFO - 2017-01-18 16:59:32 --> URI Class Initialized
INFO - 2017-01-18 16:59:32 --> Router Class Initialized
INFO - 2017-01-18 16:59:32 --> Output Class Initialized
INFO - 2017-01-18 16:59:32 --> Security Class Initialized
DEBUG - 2017-01-18 16:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 16:59:32 --> Input Class Initialized
INFO - 2017-01-18 16:59:32 --> Language Class Initialized
INFO - 2017-01-18 16:59:32 --> Loader Class Initialized
INFO - 2017-01-18 16:59:32 --> Database Driver Class Initialized
INFO - 2017-01-18 16:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 16:59:32 --> Controller Class Initialized
INFO - 2017-01-18 16:59:32 --> Helper loaded: url_helper
DEBUG - 2017-01-18 16:59:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 16:59:33 --> Config Class Initialized
INFO - 2017-01-18 16:59:33 --> Hooks Class Initialized
DEBUG - 2017-01-18 16:59:33 --> UTF-8 Support Enabled
INFO - 2017-01-18 16:59:33 --> Utf8 Class Initialized
INFO - 2017-01-18 16:59:33 --> URI Class Initialized
INFO - 2017-01-18 16:59:33 --> Router Class Initialized
INFO - 2017-01-18 16:59:33 --> Output Class Initialized
INFO - 2017-01-18 16:59:33 --> Security Class Initialized
DEBUG - 2017-01-18 16:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 16:59:33 --> Input Class Initialized
INFO - 2017-01-18 16:59:33 --> Language Class Initialized
INFO - 2017-01-18 16:59:33 --> Loader Class Initialized
INFO - 2017-01-18 16:59:33 --> Database Driver Class Initialized
INFO - 2017-01-18 16:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 16:59:33 --> Controller Class Initialized
INFO - 2017-01-18 16:59:33 --> Helper loaded: date_helper
DEBUG - 2017-01-18 16:59:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 16:59:33 --> Helper loaded: url_helper
INFO - 2017-01-18 16:59:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 16:59:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-18 16:59:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-18 16:59:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-18 16:59:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 16:59:33 --> Final output sent to browser
DEBUG - 2017-01-18 16:59:33 --> Total execution time: 0.0375
INFO - 2017-01-18 16:59:34 --> Config Class Initialized
INFO - 2017-01-18 16:59:34 --> Hooks Class Initialized
DEBUG - 2017-01-18 16:59:34 --> UTF-8 Support Enabled
INFO - 2017-01-18 16:59:34 --> Utf8 Class Initialized
INFO - 2017-01-18 16:59:34 --> URI Class Initialized
INFO - 2017-01-18 16:59:34 --> Router Class Initialized
INFO - 2017-01-18 16:59:34 --> Output Class Initialized
INFO - 2017-01-18 16:59:34 --> Security Class Initialized
DEBUG - 2017-01-18 16:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 16:59:34 --> Input Class Initialized
INFO - 2017-01-18 16:59:34 --> Language Class Initialized
INFO - 2017-01-18 16:59:34 --> Loader Class Initialized
INFO - 2017-01-18 16:59:34 --> Database Driver Class Initialized
INFO - 2017-01-18 16:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 16:59:34 --> Controller Class Initialized
INFO - 2017-01-18 16:59:34 --> Helper loaded: url_helper
DEBUG - 2017-01-18 16:59:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 16:59:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 16:59:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 16:59:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 16:59:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 16:59:34 --> Final output sent to browser
DEBUG - 2017-01-18 16:59:34 --> Total execution time: 0.0144
INFO - 2017-01-18 16:59:45 --> Config Class Initialized
INFO - 2017-01-18 16:59:45 --> Hooks Class Initialized
DEBUG - 2017-01-18 16:59:45 --> UTF-8 Support Enabled
INFO - 2017-01-18 16:59:45 --> Utf8 Class Initialized
INFO - 2017-01-18 16:59:45 --> URI Class Initialized
INFO - 2017-01-18 16:59:45 --> Router Class Initialized
INFO - 2017-01-18 16:59:45 --> Output Class Initialized
INFO - 2017-01-18 16:59:45 --> Security Class Initialized
DEBUG - 2017-01-18 16:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 16:59:45 --> Input Class Initialized
INFO - 2017-01-18 16:59:45 --> Language Class Initialized
INFO - 2017-01-18 16:59:45 --> Loader Class Initialized
INFO - 2017-01-18 16:59:45 --> Database Driver Class Initialized
INFO - 2017-01-18 16:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 16:59:45 --> Controller Class Initialized
INFO - 2017-01-18 16:59:45 --> Helper loaded: url_helper
DEBUG - 2017-01-18 16:59:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 16:59:46 --> Config Class Initialized
INFO - 2017-01-18 16:59:46 --> Hooks Class Initialized
DEBUG - 2017-01-18 16:59:46 --> UTF-8 Support Enabled
INFO - 2017-01-18 16:59:46 --> Utf8 Class Initialized
INFO - 2017-01-18 16:59:46 --> URI Class Initialized
INFO - 2017-01-18 16:59:46 --> Router Class Initialized
INFO - 2017-01-18 16:59:46 --> Output Class Initialized
INFO - 2017-01-18 16:59:46 --> Security Class Initialized
DEBUG - 2017-01-18 16:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 16:59:46 --> Input Class Initialized
INFO - 2017-01-18 16:59:46 --> Language Class Initialized
INFO - 2017-01-18 16:59:46 --> Loader Class Initialized
INFO - 2017-01-18 16:59:46 --> Database Driver Class Initialized
INFO - 2017-01-18 16:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 16:59:46 --> Controller Class Initialized
INFO - 2017-01-18 16:59:46 --> Helper loaded: date_helper
DEBUG - 2017-01-18 16:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 16:59:46 --> Helper loaded: url_helper
INFO - 2017-01-18 16:59:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 16:59:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-18 16:59:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-18 16:59:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-18 16:59:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 16:59:46 --> Final output sent to browser
DEBUG - 2017-01-18 16:59:46 --> Total execution time: 0.0145
INFO - 2017-01-18 16:59:46 --> Config Class Initialized
INFO - 2017-01-18 16:59:46 --> Hooks Class Initialized
DEBUG - 2017-01-18 16:59:46 --> UTF-8 Support Enabled
INFO - 2017-01-18 16:59:46 --> Utf8 Class Initialized
INFO - 2017-01-18 16:59:46 --> URI Class Initialized
INFO - 2017-01-18 16:59:46 --> Router Class Initialized
INFO - 2017-01-18 16:59:46 --> Output Class Initialized
INFO - 2017-01-18 16:59:46 --> Security Class Initialized
DEBUG - 2017-01-18 16:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 16:59:46 --> Input Class Initialized
INFO - 2017-01-18 16:59:46 --> Language Class Initialized
INFO - 2017-01-18 16:59:46 --> Loader Class Initialized
INFO - 2017-01-18 16:59:46 --> Database Driver Class Initialized
INFO - 2017-01-18 16:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 16:59:46 --> Controller Class Initialized
INFO - 2017-01-18 16:59:46 --> Helper loaded: url_helper
DEBUG - 2017-01-18 16:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 16:59:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 16:59:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 16:59:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 16:59:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 16:59:46 --> Final output sent to browser
DEBUG - 2017-01-18 16:59:46 --> Total execution time: 0.0200
INFO - 2017-01-18 18:16:29 --> Config Class Initialized
INFO - 2017-01-18 18:16:29 --> Hooks Class Initialized
DEBUG - 2017-01-18 18:16:29 --> UTF-8 Support Enabled
INFO - 2017-01-18 18:16:29 --> Utf8 Class Initialized
INFO - 2017-01-18 18:16:29 --> URI Class Initialized
DEBUG - 2017-01-18 18:16:29 --> No URI present. Default controller set.
INFO - 2017-01-18 18:16:29 --> Router Class Initialized
INFO - 2017-01-18 18:16:29 --> Output Class Initialized
INFO - 2017-01-18 18:16:29 --> Security Class Initialized
DEBUG - 2017-01-18 18:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 18:16:29 --> Input Class Initialized
INFO - 2017-01-18 18:16:29 --> Language Class Initialized
INFO - 2017-01-18 18:16:29 --> Loader Class Initialized
INFO - 2017-01-18 18:16:29 --> Database Driver Class Initialized
INFO - 2017-01-18 18:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 18:16:29 --> Controller Class Initialized
INFO - 2017-01-18 18:16:29 --> Helper loaded: url_helper
DEBUG - 2017-01-18 18:16:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 18:16:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 18:16:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 18:16:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 18:16:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 18:16:29 --> Final output sent to browser
DEBUG - 2017-01-18 18:16:29 --> Total execution time: 0.0130
INFO - 2017-01-18 18:16:31 --> Config Class Initialized
INFO - 2017-01-18 18:16:31 --> Hooks Class Initialized
DEBUG - 2017-01-18 18:16:31 --> UTF-8 Support Enabled
INFO - 2017-01-18 18:16:31 --> Utf8 Class Initialized
INFO - 2017-01-18 18:16:31 --> URI Class Initialized
INFO - 2017-01-18 18:16:31 --> Router Class Initialized
INFO - 2017-01-18 18:16:31 --> Output Class Initialized
INFO - 2017-01-18 18:16:31 --> Security Class Initialized
DEBUG - 2017-01-18 18:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 18:16:31 --> Input Class Initialized
INFO - 2017-01-18 18:16:31 --> Language Class Initialized
INFO - 2017-01-18 18:16:31 --> Loader Class Initialized
INFO - 2017-01-18 18:16:31 --> Database Driver Class Initialized
INFO - 2017-01-18 18:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 18:16:31 --> Controller Class Initialized
INFO - 2017-01-18 18:16:31 --> Helper loaded: url_helper
DEBUG - 2017-01-18 18:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 18:16:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 18:16:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 18:16:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 18:16:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 18:16:31 --> Final output sent to browser
DEBUG - 2017-01-18 18:16:31 --> Total execution time: 0.0191
INFO - 2017-01-18 18:20:20 --> Config Class Initialized
INFO - 2017-01-18 18:20:20 --> Hooks Class Initialized
DEBUG - 2017-01-18 18:20:20 --> UTF-8 Support Enabled
INFO - 2017-01-18 18:20:20 --> Utf8 Class Initialized
INFO - 2017-01-18 18:20:20 --> URI Class Initialized
DEBUG - 2017-01-18 18:20:20 --> No URI present. Default controller set.
INFO - 2017-01-18 18:20:20 --> Router Class Initialized
INFO - 2017-01-18 18:20:20 --> Output Class Initialized
INFO - 2017-01-18 18:20:20 --> Security Class Initialized
DEBUG - 2017-01-18 18:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 18:20:20 --> Input Class Initialized
INFO - 2017-01-18 18:20:20 --> Language Class Initialized
INFO - 2017-01-18 18:20:20 --> Loader Class Initialized
INFO - 2017-01-18 18:20:20 --> Database Driver Class Initialized
INFO - 2017-01-18 18:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 18:20:20 --> Controller Class Initialized
INFO - 2017-01-18 18:20:20 --> Helper loaded: url_helper
DEBUG - 2017-01-18 18:20:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 18:20:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 18:20:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 18:20:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 18:20:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 18:20:20 --> Final output sent to browser
DEBUG - 2017-01-18 18:20:20 --> Total execution time: 0.0139
INFO - 2017-01-18 18:21:14 --> Config Class Initialized
INFO - 2017-01-18 18:21:14 --> Hooks Class Initialized
DEBUG - 2017-01-18 18:21:14 --> UTF-8 Support Enabled
INFO - 2017-01-18 18:21:14 --> Utf8 Class Initialized
INFO - 2017-01-18 18:21:14 --> URI Class Initialized
DEBUG - 2017-01-18 18:21:14 --> No URI present. Default controller set.
INFO - 2017-01-18 18:21:14 --> Router Class Initialized
INFO - 2017-01-18 18:21:14 --> Output Class Initialized
INFO - 2017-01-18 18:21:14 --> Security Class Initialized
DEBUG - 2017-01-18 18:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 18:21:14 --> Input Class Initialized
INFO - 2017-01-18 18:21:14 --> Language Class Initialized
INFO - 2017-01-18 18:21:14 --> Loader Class Initialized
INFO - 2017-01-18 18:21:14 --> Database Driver Class Initialized
INFO - 2017-01-18 18:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 18:21:14 --> Controller Class Initialized
INFO - 2017-01-18 18:21:14 --> Helper loaded: url_helper
DEBUG - 2017-01-18 18:21:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 18:21:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 18:21:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 18:21:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 18:21:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 18:21:14 --> Final output sent to browser
DEBUG - 2017-01-18 18:21:14 --> Total execution time: 0.0626
INFO - 2017-01-18 18:21:27 --> Config Class Initialized
INFO - 2017-01-18 18:21:27 --> Hooks Class Initialized
DEBUG - 2017-01-18 18:21:27 --> UTF-8 Support Enabled
INFO - 2017-01-18 18:21:27 --> Utf8 Class Initialized
INFO - 2017-01-18 18:21:27 --> URI Class Initialized
INFO - 2017-01-18 18:21:27 --> Router Class Initialized
INFO - 2017-01-18 18:21:27 --> Output Class Initialized
INFO - 2017-01-18 18:21:27 --> Security Class Initialized
DEBUG - 2017-01-18 18:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 18:21:27 --> Input Class Initialized
INFO - 2017-01-18 18:21:27 --> Language Class Initialized
INFO - 2017-01-18 18:21:27 --> Loader Class Initialized
INFO - 2017-01-18 18:21:27 --> Database Driver Class Initialized
INFO - 2017-01-18 18:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 18:21:27 --> Controller Class Initialized
INFO - 2017-01-18 18:21:27 --> Helper loaded: url_helper
DEBUG - 2017-01-18 18:21:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 18:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 18:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 18:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 18:21:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 18:21:27 --> Final output sent to browser
DEBUG - 2017-01-18 18:21:27 --> Total execution time: 0.0145
INFO - 2017-01-18 22:53:33 --> Config Class Initialized
INFO - 2017-01-18 22:53:33 --> Hooks Class Initialized
DEBUG - 2017-01-18 22:53:33 --> UTF-8 Support Enabled
INFO - 2017-01-18 22:53:33 --> Utf8 Class Initialized
INFO - 2017-01-18 22:53:33 --> URI Class Initialized
DEBUG - 2017-01-18 22:53:33 --> No URI present. Default controller set.
INFO - 2017-01-18 22:53:33 --> Router Class Initialized
INFO - 2017-01-18 22:53:33 --> Output Class Initialized
INFO - 2017-01-18 22:53:33 --> Security Class Initialized
DEBUG - 2017-01-18 22:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 22:53:33 --> Input Class Initialized
INFO - 2017-01-18 22:53:33 --> Language Class Initialized
INFO - 2017-01-18 22:53:33 --> Loader Class Initialized
INFO - 2017-01-18 22:53:33 --> Database Driver Class Initialized
INFO - 2017-01-18 22:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 22:53:33 --> Controller Class Initialized
INFO - 2017-01-18 22:53:33 --> Helper loaded: url_helper
DEBUG - 2017-01-18 22:53:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 22:53:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 22:53:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 22:53:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 22:53:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 22:53:33 --> Final output sent to browser
DEBUG - 2017-01-18 22:53:33 --> Total execution time: 0.3684
INFO - 2017-01-18 23:12:23 --> Config Class Initialized
INFO - 2017-01-18 23:12:23 --> Hooks Class Initialized
DEBUG - 2017-01-18 23:12:23 --> UTF-8 Support Enabled
INFO - 2017-01-18 23:12:23 --> Utf8 Class Initialized
INFO - 2017-01-18 23:12:23 --> URI Class Initialized
INFO - 2017-01-18 23:12:23 --> Router Class Initialized
INFO - 2017-01-18 23:12:23 --> Output Class Initialized
INFO - 2017-01-18 23:12:23 --> Security Class Initialized
DEBUG - 2017-01-18 23:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 23:12:23 --> Input Class Initialized
INFO - 2017-01-18 23:12:23 --> Language Class Initialized
INFO - 2017-01-18 23:12:23 --> Loader Class Initialized
INFO - 2017-01-18 23:12:23 --> Database Driver Class Initialized
INFO - 2017-01-18 23:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 23:12:23 --> Controller Class Initialized
INFO - 2017-01-18 23:12:23 --> Helper loaded: url_helper
DEBUG - 2017-01-18 23:12:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 23:12:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 23:12:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 23:12:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 23:12:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 23:12:23 --> Final output sent to browser
DEBUG - 2017-01-18 23:12:23 --> Total execution time: 0.0146
INFO - 2017-01-18 23:12:24 --> Config Class Initialized
INFO - 2017-01-18 23:12:24 --> Hooks Class Initialized
DEBUG - 2017-01-18 23:12:24 --> UTF-8 Support Enabled
INFO - 2017-01-18 23:12:24 --> Utf8 Class Initialized
INFO - 2017-01-18 23:12:24 --> URI Class Initialized
DEBUG - 2017-01-18 23:12:24 --> No URI present. Default controller set.
INFO - 2017-01-18 23:12:24 --> Router Class Initialized
INFO - 2017-01-18 23:12:24 --> Output Class Initialized
INFO - 2017-01-18 23:12:24 --> Security Class Initialized
DEBUG - 2017-01-18 23:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 23:12:24 --> Input Class Initialized
INFO - 2017-01-18 23:12:24 --> Language Class Initialized
INFO - 2017-01-18 23:12:24 --> Loader Class Initialized
INFO - 2017-01-18 23:12:24 --> Database Driver Class Initialized
INFO - 2017-01-18 23:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 23:12:24 --> Controller Class Initialized
INFO - 2017-01-18 23:12:24 --> Helper loaded: url_helper
DEBUG - 2017-01-18 23:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 23:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 23:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 23:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 23:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 23:12:24 --> Final output sent to browser
DEBUG - 2017-01-18 23:12:24 --> Total execution time: 0.0133
INFO - 2017-01-18 23:45:00 --> Config Class Initialized
INFO - 2017-01-18 23:45:00 --> Hooks Class Initialized
DEBUG - 2017-01-18 23:45:00 --> UTF-8 Support Enabled
INFO - 2017-01-18 23:45:00 --> Utf8 Class Initialized
INFO - 2017-01-18 23:45:00 --> URI Class Initialized
DEBUG - 2017-01-18 23:45:00 --> No URI present. Default controller set.
INFO - 2017-01-18 23:45:00 --> Router Class Initialized
INFO - 2017-01-18 23:45:00 --> Output Class Initialized
INFO - 2017-01-18 23:45:00 --> Security Class Initialized
DEBUG - 2017-01-18 23:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 23:45:00 --> Input Class Initialized
INFO - 2017-01-18 23:45:00 --> Language Class Initialized
INFO - 2017-01-18 23:45:00 --> Loader Class Initialized
INFO - 2017-01-18 23:45:00 --> Database Driver Class Initialized
INFO - 2017-01-18 23:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 23:45:00 --> Controller Class Initialized
INFO - 2017-01-18 23:45:00 --> Helper loaded: url_helper
DEBUG - 2017-01-18 23:45:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 23:45:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 23:45:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 23:45:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 23:45:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 23:45:00 --> Final output sent to browser
DEBUG - 2017-01-18 23:45:00 --> Total execution time: 0.0141
INFO - 2017-01-18 23:45:15 --> Config Class Initialized
INFO - 2017-01-18 23:45:15 --> Hooks Class Initialized
DEBUG - 2017-01-18 23:45:15 --> UTF-8 Support Enabled
INFO - 2017-01-18 23:45:15 --> Utf8 Class Initialized
INFO - 2017-01-18 23:45:15 --> URI Class Initialized
INFO - 2017-01-18 23:45:15 --> Router Class Initialized
INFO - 2017-01-18 23:45:15 --> Output Class Initialized
INFO - 2017-01-18 23:45:15 --> Security Class Initialized
DEBUG - 2017-01-18 23:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 23:45:15 --> Input Class Initialized
INFO - 2017-01-18 23:45:15 --> Language Class Initialized
INFO - 2017-01-18 23:45:15 --> Loader Class Initialized
INFO - 2017-01-18 23:45:15 --> Database Driver Class Initialized
INFO - 2017-01-18 23:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 23:45:15 --> Controller Class Initialized
INFO - 2017-01-18 23:45:15 --> Helper loaded: url_helper
DEBUG - 2017-01-18 23:45:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 23:45:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 23:45:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 23:45:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 23:45:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 23:45:15 --> Final output sent to browser
DEBUG - 2017-01-18 23:45:15 --> Total execution time: 0.0146
INFO - 2017-01-18 23:54:49 --> Config Class Initialized
INFO - 2017-01-18 23:54:49 --> Hooks Class Initialized
DEBUG - 2017-01-18 23:54:49 --> UTF-8 Support Enabled
INFO - 2017-01-18 23:54:49 --> Utf8 Class Initialized
INFO - 2017-01-18 23:54:49 --> URI Class Initialized
INFO - 2017-01-18 23:54:49 --> Router Class Initialized
INFO - 2017-01-18 23:54:49 --> Output Class Initialized
INFO - 2017-01-18 23:54:49 --> Security Class Initialized
DEBUG - 2017-01-18 23:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 23:54:49 --> Input Class Initialized
INFO - 2017-01-18 23:54:49 --> Language Class Initialized
INFO - 2017-01-18 23:54:49 --> Loader Class Initialized
INFO - 2017-01-18 23:54:49 --> Database Driver Class Initialized
INFO - 2017-01-18 23:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 23:54:49 --> Controller Class Initialized
INFO - 2017-01-18 23:54:49 --> Helper loaded: url_helper
DEBUG - 2017-01-18 23:54:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 23:54:50 --> Config Class Initialized
INFO - 2017-01-18 23:54:50 --> Hooks Class Initialized
DEBUG - 2017-01-18 23:54:50 --> UTF-8 Support Enabled
INFO - 2017-01-18 23:54:50 --> Utf8 Class Initialized
INFO - 2017-01-18 23:54:50 --> URI Class Initialized
INFO - 2017-01-18 23:54:50 --> Router Class Initialized
INFO - 2017-01-18 23:54:50 --> Output Class Initialized
INFO - 2017-01-18 23:54:50 --> Security Class Initialized
DEBUG - 2017-01-18 23:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 23:54:50 --> Input Class Initialized
INFO - 2017-01-18 23:54:50 --> Language Class Initialized
INFO - 2017-01-18 23:54:50 --> Loader Class Initialized
INFO - 2017-01-18 23:54:50 --> Database Driver Class Initialized
INFO - 2017-01-18 23:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 23:54:50 --> Controller Class Initialized
INFO - 2017-01-18 23:54:50 --> Helper loaded: date_helper
DEBUG - 2017-01-18 23:54:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 23:54:50 --> Helper loaded: url_helper
INFO - 2017-01-18 23:54:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 23:54:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-18 23:54:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-18 23:54:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-18 23:54:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 23:54:50 --> Final output sent to browser
DEBUG - 2017-01-18 23:54:50 --> Total execution time: 0.0276
INFO - 2017-01-18 23:54:51 --> Config Class Initialized
INFO - 2017-01-18 23:54:51 --> Hooks Class Initialized
DEBUG - 2017-01-18 23:54:51 --> UTF-8 Support Enabled
INFO - 2017-01-18 23:54:51 --> Utf8 Class Initialized
INFO - 2017-01-18 23:54:51 --> URI Class Initialized
INFO - 2017-01-18 23:54:51 --> Router Class Initialized
INFO - 2017-01-18 23:54:51 --> Output Class Initialized
INFO - 2017-01-18 23:54:51 --> Security Class Initialized
DEBUG - 2017-01-18 23:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 23:54:51 --> Input Class Initialized
INFO - 2017-01-18 23:54:51 --> Language Class Initialized
INFO - 2017-01-18 23:54:51 --> Loader Class Initialized
INFO - 2017-01-18 23:54:51 --> Database Driver Class Initialized
INFO - 2017-01-18 23:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 23:54:51 --> Controller Class Initialized
INFO - 2017-01-18 23:54:51 --> Helper loaded: url_helper
DEBUG - 2017-01-18 23:54:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 23:54:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 23:54:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 23:54:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 23:54:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 23:54:51 --> Final output sent to browser
DEBUG - 2017-01-18 23:54:51 --> Total execution time: 0.0132
INFO - 2017-01-18 23:54:56 --> Config Class Initialized
INFO - 2017-01-18 23:54:56 --> Hooks Class Initialized
DEBUG - 2017-01-18 23:54:56 --> UTF-8 Support Enabled
INFO - 2017-01-18 23:54:56 --> Utf8 Class Initialized
INFO - 2017-01-18 23:54:56 --> URI Class Initialized
DEBUG - 2017-01-18 23:54:56 --> No URI present. Default controller set.
INFO - 2017-01-18 23:54:56 --> Router Class Initialized
INFO - 2017-01-18 23:54:56 --> Output Class Initialized
INFO - 2017-01-18 23:54:56 --> Security Class Initialized
DEBUG - 2017-01-18 23:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 23:54:56 --> Input Class Initialized
INFO - 2017-01-18 23:54:56 --> Language Class Initialized
INFO - 2017-01-18 23:54:56 --> Loader Class Initialized
INFO - 2017-01-18 23:54:56 --> Database Driver Class Initialized
INFO - 2017-01-18 23:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 23:54:56 --> Controller Class Initialized
INFO - 2017-01-18 23:54:56 --> Helper loaded: url_helper
DEBUG - 2017-01-18 23:54:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 23:54:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 23:54:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 23:54:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 23:54:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 23:54:56 --> Final output sent to browser
DEBUG - 2017-01-18 23:54:56 --> Total execution time: 0.0150
INFO - 2017-01-18 23:54:58 --> Config Class Initialized
INFO - 2017-01-18 23:54:58 --> Hooks Class Initialized
DEBUG - 2017-01-18 23:54:58 --> UTF-8 Support Enabled
INFO - 2017-01-18 23:54:58 --> Utf8 Class Initialized
INFO - 2017-01-18 23:54:58 --> URI Class Initialized
INFO - 2017-01-18 23:54:58 --> Router Class Initialized
INFO - 2017-01-18 23:54:58 --> Output Class Initialized
INFO - 2017-01-18 23:54:58 --> Security Class Initialized
DEBUG - 2017-01-18 23:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-18 23:54:58 --> Input Class Initialized
INFO - 2017-01-18 23:54:58 --> Language Class Initialized
INFO - 2017-01-18 23:54:58 --> Loader Class Initialized
INFO - 2017-01-18 23:54:58 --> Database Driver Class Initialized
INFO - 2017-01-18 23:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-18 23:54:58 --> Controller Class Initialized
INFO - 2017-01-18 23:54:58 --> Helper loaded: url_helper
DEBUG - 2017-01-18 23:54:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-18 23:54:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-18 23:54:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-18 23:54:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-18 23:54:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-18 23:54:58 --> Final output sent to browser
DEBUG - 2017-01-18 23:54:58 --> Total execution time: 0.0135

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-16 00:13:51 --> Config Class Initialized
INFO - 2016-12-16 00:13:51 --> Hooks Class Initialized
DEBUG - 2016-12-16 00:13:51 --> UTF-8 Support Enabled
INFO - 2016-12-16 00:13:51 --> Utf8 Class Initialized
INFO - 2016-12-16 00:13:51 --> URI Class Initialized
DEBUG - 2016-12-16 00:13:51 --> No URI present. Default controller set.
INFO - 2016-12-16 00:13:51 --> Router Class Initialized
INFO - 2016-12-16 00:13:51 --> Output Class Initialized
INFO - 2016-12-16 00:13:51 --> Security Class Initialized
DEBUG - 2016-12-16 00:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 00:13:51 --> Input Class Initialized
INFO - 2016-12-16 00:13:51 --> Language Class Initialized
INFO - 2016-12-16 00:13:51 --> Loader Class Initialized
INFO - 2016-12-16 00:13:51 --> Database Driver Class Initialized
INFO - 2016-12-16 00:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 00:13:51 --> Controller Class Initialized
INFO - 2016-12-16 00:13:51 --> Helper loaded: url_helper
DEBUG - 2016-12-16 00:13:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 00:13:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 00:13:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 00:13:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 00:13:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 00:13:51 --> Final output sent to browser
DEBUG - 2016-12-16 00:13:51 --> Total execution time: 0.0130
INFO - 2016-12-16 00:13:53 --> Config Class Initialized
INFO - 2016-12-16 00:13:53 --> Hooks Class Initialized
DEBUG - 2016-12-16 00:13:53 --> UTF-8 Support Enabled
INFO - 2016-12-16 00:13:53 --> Utf8 Class Initialized
INFO - 2016-12-16 00:13:53 --> URI Class Initialized
INFO - 2016-12-16 00:13:53 --> Router Class Initialized
INFO - 2016-12-16 00:13:53 --> Output Class Initialized
INFO - 2016-12-16 00:13:53 --> Security Class Initialized
DEBUG - 2016-12-16 00:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 00:13:53 --> Input Class Initialized
INFO - 2016-12-16 00:13:53 --> Language Class Initialized
INFO - 2016-12-16 00:13:53 --> Loader Class Initialized
INFO - 2016-12-16 00:13:53 --> Database Driver Class Initialized
INFO - 2016-12-16 00:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 00:13:53 --> Controller Class Initialized
INFO - 2016-12-16 00:13:53 --> Helper loaded: url_helper
DEBUG - 2016-12-16 00:13:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 00:13:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 00:13:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 00:13:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 00:13:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 00:13:53 --> Final output sent to browser
DEBUG - 2016-12-16 00:13:53 --> Total execution time: 0.0132
INFO - 2016-12-16 08:21:18 --> Config Class Initialized
INFO - 2016-12-16 08:21:18 --> Hooks Class Initialized
DEBUG - 2016-12-16 08:21:18 --> UTF-8 Support Enabled
INFO - 2016-12-16 08:21:18 --> Utf8 Class Initialized
INFO - 2016-12-16 08:21:18 --> URI Class Initialized
DEBUG - 2016-12-16 08:21:18 --> No URI present. Default controller set.
INFO - 2016-12-16 08:21:18 --> Router Class Initialized
INFO - 2016-12-16 08:21:18 --> Output Class Initialized
INFO - 2016-12-16 08:21:18 --> Security Class Initialized
DEBUG - 2016-12-16 08:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 08:21:18 --> Input Class Initialized
INFO - 2016-12-16 08:21:18 --> Language Class Initialized
INFO - 2016-12-16 08:21:18 --> Loader Class Initialized
INFO - 2016-12-16 08:21:19 --> Database Driver Class Initialized
INFO - 2016-12-16 08:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 08:21:19 --> Controller Class Initialized
INFO - 2016-12-16 08:21:19 --> Helper loaded: url_helper
DEBUG - 2016-12-16 08:21:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 08:21:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 08:21:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 08:21:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 08:21:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 08:21:19 --> Final output sent to browser
DEBUG - 2016-12-16 08:21:19 --> Total execution time: 1.6744
INFO - 2016-12-16 08:21:22 --> Config Class Initialized
INFO - 2016-12-16 08:21:22 --> Hooks Class Initialized
DEBUG - 2016-12-16 08:21:22 --> UTF-8 Support Enabled
INFO - 2016-12-16 08:21:22 --> Utf8 Class Initialized
INFO - 2016-12-16 08:21:22 --> URI Class Initialized
INFO - 2016-12-16 08:21:22 --> Router Class Initialized
INFO - 2016-12-16 08:21:22 --> Output Class Initialized
INFO - 2016-12-16 08:21:22 --> Security Class Initialized
DEBUG - 2016-12-16 08:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 08:21:22 --> Input Class Initialized
INFO - 2016-12-16 08:21:22 --> Language Class Initialized
INFO - 2016-12-16 08:21:22 --> Loader Class Initialized
INFO - 2016-12-16 08:21:22 --> Database Driver Class Initialized
INFO - 2016-12-16 08:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 08:21:22 --> Controller Class Initialized
INFO - 2016-12-16 08:21:22 --> Helper loaded: url_helper
DEBUG - 2016-12-16 08:21:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 08:21:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 08:21:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 08:21:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 08:21:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 08:21:22 --> Final output sent to browser
DEBUG - 2016-12-16 08:21:22 --> Total execution time: 0.0146
INFO - 2016-12-16 08:21:37 --> Config Class Initialized
INFO - 2016-12-16 08:21:37 --> Hooks Class Initialized
DEBUG - 2016-12-16 08:21:37 --> UTF-8 Support Enabled
INFO - 2016-12-16 08:21:37 --> Utf8 Class Initialized
INFO - 2016-12-16 08:21:37 --> URI Class Initialized
INFO - 2016-12-16 08:21:37 --> Router Class Initialized
INFO - 2016-12-16 08:21:37 --> Output Class Initialized
INFO - 2016-12-16 08:21:37 --> Security Class Initialized
DEBUG - 2016-12-16 08:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 08:21:37 --> Input Class Initialized
INFO - 2016-12-16 08:21:37 --> Language Class Initialized
INFO - 2016-12-16 08:21:37 --> Loader Class Initialized
INFO - 2016-12-16 08:21:37 --> Database Driver Class Initialized
INFO - 2016-12-16 08:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 08:21:37 --> Controller Class Initialized
INFO - 2016-12-16 08:21:37 --> Helper loaded: url_helper
DEBUG - 2016-12-16 08:21:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 08:21:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 08:21:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 08:21:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 08:21:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 08:21:37 --> Final output sent to browser
DEBUG - 2016-12-16 08:21:37 --> Total execution time: 0.2857
INFO - 2016-12-16 08:21:40 --> Config Class Initialized
INFO - 2016-12-16 08:21:40 --> Hooks Class Initialized
DEBUG - 2016-12-16 08:21:40 --> UTF-8 Support Enabled
INFO - 2016-12-16 08:21:40 --> Utf8 Class Initialized
INFO - 2016-12-16 08:21:40 --> URI Class Initialized
INFO - 2016-12-16 08:21:40 --> Router Class Initialized
INFO - 2016-12-16 08:21:40 --> Output Class Initialized
INFO - 2016-12-16 08:21:40 --> Security Class Initialized
DEBUG - 2016-12-16 08:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 08:21:40 --> Input Class Initialized
INFO - 2016-12-16 08:21:40 --> Language Class Initialized
INFO - 2016-12-16 08:21:40 --> Loader Class Initialized
INFO - 2016-12-16 08:21:40 --> Database Driver Class Initialized
INFO - 2016-12-16 08:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 08:21:40 --> Controller Class Initialized
INFO - 2016-12-16 08:21:40 --> Helper loaded: url_helper
DEBUG - 2016-12-16 08:21:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 08:21:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 08:21:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 08:21:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 08:21:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 08:21:40 --> Final output sent to browser
DEBUG - 2016-12-16 08:21:40 --> Total execution time: 0.0138
INFO - 2016-12-16 08:21:44 --> Config Class Initialized
INFO - 2016-12-16 08:21:44 --> Hooks Class Initialized
DEBUG - 2016-12-16 08:21:44 --> UTF-8 Support Enabled
INFO - 2016-12-16 08:21:44 --> Utf8 Class Initialized
INFO - 2016-12-16 08:21:44 --> URI Class Initialized
INFO - 2016-12-16 08:21:44 --> Router Class Initialized
INFO - 2016-12-16 08:21:44 --> Output Class Initialized
INFO - 2016-12-16 08:21:44 --> Security Class Initialized
DEBUG - 2016-12-16 08:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 08:21:44 --> Input Class Initialized
INFO - 2016-12-16 08:21:44 --> Language Class Initialized
INFO - 2016-12-16 08:21:44 --> Loader Class Initialized
INFO - 2016-12-16 08:21:44 --> Database Driver Class Initialized
INFO - 2016-12-16 08:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 08:21:44 --> Controller Class Initialized
INFO - 2016-12-16 08:21:44 --> Helper loaded: url_helper
DEBUG - 2016-12-16 08:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 08:21:46 --> Config Class Initialized
INFO - 2016-12-16 08:21:46 --> Hooks Class Initialized
DEBUG - 2016-12-16 08:21:46 --> UTF-8 Support Enabled
INFO - 2016-12-16 08:21:46 --> Utf8 Class Initialized
INFO - 2016-12-16 08:21:46 --> URI Class Initialized
INFO - 2016-12-16 08:21:46 --> Router Class Initialized
INFO - 2016-12-16 08:21:46 --> Output Class Initialized
INFO - 2016-12-16 08:21:46 --> Security Class Initialized
DEBUG - 2016-12-16 08:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 08:21:46 --> Input Class Initialized
INFO - 2016-12-16 08:21:46 --> Language Class Initialized
INFO - 2016-12-16 08:21:46 --> Loader Class Initialized
INFO - 2016-12-16 08:21:46 --> Database Driver Class Initialized
INFO - 2016-12-16 08:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 08:21:46 --> Controller Class Initialized
DEBUG - 2016-12-16 08:21:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 08:21:46 --> Helper loaded: url_helper
INFO - 2016-12-16 08:21:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 08:21:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 08:21:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-16 08:21:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-16 08:21:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 08:21:46 --> Final output sent to browser
DEBUG - 2016-12-16 08:21:46 --> Total execution time: 0.0850
INFO - 2016-12-16 08:21:47 --> Config Class Initialized
INFO - 2016-12-16 08:21:47 --> Hooks Class Initialized
DEBUG - 2016-12-16 08:21:47 --> UTF-8 Support Enabled
INFO - 2016-12-16 08:21:47 --> Utf8 Class Initialized
INFO - 2016-12-16 08:21:47 --> URI Class Initialized
INFO - 2016-12-16 08:21:47 --> Router Class Initialized
INFO - 2016-12-16 08:21:47 --> Output Class Initialized
INFO - 2016-12-16 08:21:47 --> Security Class Initialized
DEBUG - 2016-12-16 08:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 08:21:47 --> Input Class Initialized
INFO - 2016-12-16 08:21:47 --> Language Class Initialized
INFO - 2016-12-16 08:21:47 --> Loader Class Initialized
INFO - 2016-12-16 08:21:47 --> Database Driver Class Initialized
INFO - 2016-12-16 08:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 08:21:47 --> Controller Class Initialized
INFO - 2016-12-16 08:21:47 --> Helper loaded: url_helper
DEBUG - 2016-12-16 08:21:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 08:21:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 08:21:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 08:21:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 08:21:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 08:21:47 --> Final output sent to browser
DEBUG - 2016-12-16 08:21:47 --> Total execution time: 0.0135
INFO - 2016-12-16 08:21:54 --> Config Class Initialized
INFO - 2016-12-16 08:21:54 --> Hooks Class Initialized
DEBUG - 2016-12-16 08:21:54 --> UTF-8 Support Enabled
INFO - 2016-12-16 08:21:54 --> Utf8 Class Initialized
INFO - 2016-12-16 08:21:54 --> URI Class Initialized
INFO - 2016-12-16 08:21:54 --> Router Class Initialized
INFO - 2016-12-16 08:21:54 --> Output Class Initialized
INFO - 2016-12-16 08:21:54 --> Security Class Initialized
DEBUG - 2016-12-16 08:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 08:21:54 --> Input Class Initialized
INFO - 2016-12-16 08:21:54 --> Language Class Initialized
INFO - 2016-12-16 08:21:54 --> Loader Class Initialized
INFO - 2016-12-16 08:21:54 --> Database Driver Class Initialized
INFO - 2016-12-16 08:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 08:21:54 --> Controller Class Initialized
INFO - 2016-12-16 08:21:54 --> Helper loaded: date_helper
DEBUG - 2016-12-16 08:21:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 08:21:54 --> Helper loaded: url_helper
INFO - 2016-12-16 08:21:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 08:21:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 08:21:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-16 08:21:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-16 08:21:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 08:21:54 --> Final output sent to browser
DEBUG - 2016-12-16 08:21:54 --> Total execution time: 0.1448
INFO - 2016-12-16 08:21:56 --> Config Class Initialized
INFO - 2016-12-16 08:21:56 --> Hooks Class Initialized
DEBUG - 2016-12-16 08:21:56 --> UTF-8 Support Enabled
INFO - 2016-12-16 08:21:56 --> Utf8 Class Initialized
INFO - 2016-12-16 08:21:56 --> URI Class Initialized
INFO - 2016-12-16 08:21:56 --> Router Class Initialized
INFO - 2016-12-16 08:21:56 --> Output Class Initialized
INFO - 2016-12-16 08:21:56 --> Security Class Initialized
DEBUG - 2016-12-16 08:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 08:21:56 --> Input Class Initialized
INFO - 2016-12-16 08:21:56 --> Language Class Initialized
INFO - 2016-12-16 08:21:56 --> Loader Class Initialized
INFO - 2016-12-16 08:21:56 --> Database Driver Class Initialized
INFO - 2016-12-16 08:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 08:21:56 --> Controller Class Initialized
INFO - 2016-12-16 08:21:56 --> Helper loaded: url_helper
DEBUG - 2016-12-16 08:21:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 08:21:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 08:21:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 08:21:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 08:21:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 08:21:56 --> Final output sent to browser
DEBUG - 2016-12-16 08:21:56 --> Total execution time: 0.0130
INFO - 2016-12-16 08:22:01 --> Config Class Initialized
INFO - 2016-12-16 08:22:01 --> Hooks Class Initialized
DEBUG - 2016-12-16 08:22:01 --> UTF-8 Support Enabled
INFO - 2016-12-16 08:22:01 --> Utf8 Class Initialized
INFO - 2016-12-16 08:22:01 --> URI Class Initialized
INFO - 2016-12-16 08:22:01 --> Router Class Initialized
INFO - 2016-12-16 08:22:01 --> Output Class Initialized
INFO - 2016-12-16 08:22:01 --> Security Class Initialized
DEBUG - 2016-12-16 08:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 08:22:01 --> Input Class Initialized
INFO - 2016-12-16 08:22:01 --> Language Class Initialized
INFO - 2016-12-16 08:22:01 --> Loader Class Initialized
INFO - 2016-12-16 08:22:01 --> Database Driver Class Initialized
INFO - 2016-12-16 08:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 08:22:01 --> Controller Class Initialized
DEBUG - 2016-12-16 08:22:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 08:22:01 --> Helper loaded: url_helper
INFO - 2016-12-16 08:22:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 08:22:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 08:22:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 08:22:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 08:22:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 08:22:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 08:22:01 --> Final output sent to browser
DEBUG - 2016-12-16 08:22:01 --> Total execution time: 0.3490
INFO - 2016-12-16 08:22:02 --> Config Class Initialized
INFO - 2016-12-16 08:22:02 --> Hooks Class Initialized
DEBUG - 2016-12-16 08:22:02 --> UTF-8 Support Enabled
INFO - 2016-12-16 08:22:02 --> Utf8 Class Initialized
INFO - 2016-12-16 08:22:02 --> URI Class Initialized
INFO - 2016-12-16 08:22:02 --> Router Class Initialized
INFO - 2016-12-16 08:22:02 --> Output Class Initialized
INFO - 2016-12-16 08:22:02 --> Security Class Initialized
DEBUG - 2016-12-16 08:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 08:22:02 --> Input Class Initialized
INFO - 2016-12-16 08:22:02 --> Language Class Initialized
INFO - 2016-12-16 08:22:02 --> Loader Class Initialized
INFO - 2016-12-16 08:22:02 --> Database Driver Class Initialized
INFO - 2016-12-16 08:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 08:22:02 --> Controller Class Initialized
INFO - 2016-12-16 08:22:02 --> Helper loaded: url_helper
DEBUG - 2016-12-16 08:22:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 08:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 08:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 08:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 08:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 08:22:02 --> Final output sent to browser
DEBUG - 2016-12-16 08:22:02 --> Total execution time: 0.0129
INFO - 2016-12-16 14:17:11 --> Config Class Initialized
INFO - 2016-12-16 14:17:11 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:17:11 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:17:11 --> Utf8 Class Initialized
INFO - 2016-12-16 14:17:11 --> URI Class Initialized
INFO - 2016-12-16 14:17:11 --> Router Class Initialized
INFO - 2016-12-16 14:17:11 --> Output Class Initialized
INFO - 2016-12-16 14:17:11 --> Security Class Initialized
DEBUG - 2016-12-16 14:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:17:11 --> Input Class Initialized
INFO - 2016-12-16 14:17:11 --> Language Class Initialized
INFO - 2016-12-16 14:17:11 --> Loader Class Initialized
INFO - 2016-12-16 14:17:12 --> Database Driver Class Initialized
INFO - 2016-12-16 14:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:17:12 --> Controller Class Initialized
DEBUG - 2016-12-16 14:17:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:17:12 --> Helper loaded: url_helper
INFO - 2016-12-16 14:17:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:17:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 14:17:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 14:17:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 14:17:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 14:17:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:17:12 --> Final output sent to browser
DEBUG - 2016-12-16 14:17:12 --> Total execution time: 1.5157
INFO - 2016-12-16 14:17:13 --> Config Class Initialized
INFO - 2016-12-16 14:17:13 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:17:13 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:17:13 --> Utf8 Class Initialized
INFO - 2016-12-16 14:17:13 --> URI Class Initialized
INFO - 2016-12-16 14:17:13 --> Router Class Initialized
INFO - 2016-12-16 14:17:13 --> Output Class Initialized
INFO - 2016-12-16 14:17:13 --> Security Class Initialized
DEBUG - 2016-12-16 14:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:17:13 --> Input Class Initialized
INFO - 2016-12-16 14:17:13 --> Language Class Initialized
INFO - 2016-12-16 14:17:13 --> Loader Class Initialized
INFO - 2016-12-16 14:17:13 --> Database Driver Class Initialized
INFO - 2016-12-16 14:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:17:13 --> Controller Class Initialized
INFO - 2016-12-16 14:17:13 --> Helper loaded: url_helper
DEBUG - 2016-12-16 14:17:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:17:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:17:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 14:17:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 14:17:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:17:14 --> Final output sent to browser
DEBUG - 2016-12-16 14:17:14 --> Total execution time: 0.2214
INFO - 2016-12-16 14:17:20 --> Config Class Initialized
INFO - 2016-12-16 14:17:20 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:17:20 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:17:20 --> Utf8 Class Initialized
INFO - 2016-12-16 14:17:20 --> URI Class Initialized
INFO - 2016-12-16 14:17:20 --> Router Class Initialized
INFO - 2016-12-16 14:17:20 --> Output Class Initialized
INFO - 2016-12-16 14:17:20 --> Security Class Initialized
DEBUG - 2016-12-16 14:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:17:20 --> Input Class Initialized
INFO - 2016-12-16 14:17:20 --> Language Class Initialized
INFO - 2016-12-16 14:17:20 --> Loader Class Initialized
INFO - 2016-12-16 14:17:20 --> Database Driver Class Initialized
INFO - 2016-12-16 14:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:17:20 --> Controller Class Initialized
INFO - 2016-12-16 14:17:21 --> Helper loaded: date_helper
DEBUG - 2016-12-16 14:17:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:17:21 --> Helper loaded: url_helper
INFO - 2016-12-16 14:17:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:17:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-16 14:17:21 --> Severity: Notice --> Undefined variable: layout_name /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php 10
INFO - 2016-12-16 14:17:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
ERROR - 2016-12-16 14:17:21 --> Severity: Notice --> Undefined variable: numero_lugares /home/graduafe/public_html/application/controllers/User_mi_graduacion_controller.php 51
INFO - 2016-12-16 14:17:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-16 14:17:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:17:21 --> Final output sent to browser
DEBUG - 2016-12-16 14:17:21 --> Total execution time: 0.5067
INFO - 2016-12-16 14:17:21 --> Config Class Initialized
INFO - 2016-12-16 14:17:21 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:17:21 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:17:21 --> Utf8 Class Initialized
INFO - 2016-12-16 14:17:22 --> Config Class Initialized
INFO - 2016-12-16 14:17:22 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:17:22 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:17:22 --> Utf8 Class Initialized
INFO - 2016-12-16 14:17:22 --> Config Class Initialized
INFO - 2016-12-16 14:17:22 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:17:22 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:17:22 --> Utf8 Class Initialized
INFO - 2016-12-16 14:17:22 --> URI Class Initialized
INFO - 2016-12-16 14:17:22 --> Router Class Initialized
INFO - 2016-12-16 14:17:22 --> Output Class Initialized
INFO - 2016-12-16 14:17:22 --> Security Class Initialized
DEBUG - 2016-12-16 14:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:17:22 --> Input Class Initialized
INFO - 2016-12-16 14:17:22 --> Language Class Initialized
INFO - 2016-12-16 14:17:22 --> Loader Class Initialized
INFO - 2016-12-16 14:17:22 --> Database Driver Class Initialized
INFO - 2016-12-16 14:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:17:22 --> Controller Class Initialized
INFO - 2016-12-16 14:17:22 --> Helper loaded: url_helper
DEBUG - 2016-12-16 14:17:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:17:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:17:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 14:17:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 14:17:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:17:22 --> Final output sent to browser
DEBUG - 2016-12-16 14:17:22 --> Total execution time: 0.0132
INFO - 2016-12-16 14:17:25 --> Config Class Initialized
INFO - 2016-12-16 14:17:25 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:17:25 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:17:25 --> Utf8 Class Initialized
INFO - 2016-12-16 14:17:25 --> URI Class Initialized
INFO - 2016-12-16 14:17:25 --> Router Class Initialized
INFO - 2016-12-16 14:17:25 --> Output Class Initialized
INFO - 2016-12-16 14:17:25 --> Security Class Initialized
DEBUG - 2016-12-16 14:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:17:25 --> Input Class Initialized
INFO - 2016-12-16 14:17:25 --> Language Class Initialized
INFO - 2016-12-16 14:17:25 --> Loader Class Initialized
INFO - 2016-12-16 14:17:25 --> Database Driver Class Initialized
INFO - 2016-12-16 14:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:17:25 --> Controller Class Initialized
INFO - 2016-12-16 14:17:25 --> Helper loaded: date_helper
DEBUG - 2016-12-16 14:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:17:25 --> Helper loaded: url_helper
INFO - 2016-12-16 14:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-16 14:17:25 --> Severity: Notice --> Undefined variable: layout_name /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php 10
INFO - 2016-12-16 14:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
ERROR - 2016-12-16 14:17:25 --> Severity: Notice --> Undefined variable: numero_lugares /home/graduafe/public_html/application/controllers/User_mi_graduacion_controller.php 51
INFO - 2016-12-16 14:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-16 14:17:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:17:25 --> Final output sent to browser
DEBUG - 2016-12-16 14:17:25 --> Total execution time: 0.0758
INFO - 2016-12-16 14:17:26 --> Config Class Initialized
INFO - 2016-12-16 14:17:26 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:17:26 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:17:26 --> Utf8 Class Initialized
INFO - 2016-12-16 14:17:26 --> Config Class Initialized
INFO - 2016-12-16 14:17:26 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:17:26 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:17:26 --> Utf8 Class Initialized
INFO - 2016-12-16 14:17:26 --> URI Class Initialized
INFO - 2016-12-16 14:17:26 --> Router Class Initialized
INFO - 2016-12-16 14:17:26 --> Output Class Initialized
INFO - 2016-12-16 14:17:26 --> Security Class Initialized
DEBUG - 2016-12-16 14:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:17:26 --> Input Class Initialized
INFO - 2016-12-16 14:17:26 --> Language Class Initialized
INFO - 2016-12-16 14:17:26 --> Loader Class Initialized
INFO - 2016-12-16 14:17:26 --> Database Driver Class Initialized
INFO - 2016-12-16 14:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:17:26 --> Controller Class Initialized
INFO - 2016-12-16 14:17:26 --> Helper loaded: url_helper
DEBUG - 2016-12-16 14:17:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:17:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:17:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 14:17:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 14:17:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:17:26 --> Final output sent to browser
DEBUG - 2016-12-16 14:17:26 --> Total execution time: 0.0142
INFO - 2016-12-16 14:17:37 --> Config Class Initialized
INFO - 2016-12-16 14:17:37 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:17:37 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:17:37 --> Utf8 Class Initialized
INFO - 2016-12-16 14:17:37 --> URI Class Initialized
INFO - 2016-12-16 14:17:37 --> Router Class Initialized
INFO - 2016-12-16 14:17:37 --> Output Class Initialized
INFO - 2016-12-16 14:17:37 --> Security Class Initialized
DEBUG - 2016-12-16 14:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:17:37 --> Input Class Initialized
INFO - 2016-12-16 14:17:37 --> Language Class Initialized
INFO - 2016-12-16 14:17:37 --> Loader Class Initialized
INFO - 2016-12-16 14:17:37 --> Database Driver Class Initialized
INFO - 2016-12-16 14:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:17:37 --> Controller Class Initialized
DEBUG - 2016-12-16 14:17:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:17:37 --> Helper loaded: url_helper
INFO - 2016-12-16 14:17:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:17:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 14:17:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 14:17:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 14:17:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 14:17:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:17:37 --> Final output sent to browser
DEBUG - 2016-12-16 14:17:37 --> Total execution time: 0.0124
INFO - 2016-12-16 14:17:37 --> Config Class Initialized
INFO - 2016-12-16 14:17:37 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:17:37 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:17:37 --> Utf8 Class Initialized
INFO - 2016-12-16 14:17:37 --> URI Class Initialized
INFO - 2016-12-16 14:17:37 --> Router Class Initialized
INFO - 2016-12-16 14:17:37 --> Output Class Initialized
INFO - 2016-12-16 14:17:37 --> Security Class Initialized
DEBUG - 2016-12-16 14:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:17:37 --> Input Class Initialized
INFO - 2016-12-16 14:17:37 --> Language Class Initialized
INFO - 2016-12-16 14:17:37 --> Loader Class Initialized
INFO - 2016-12-16 14:17:37 --> Database Driver Class Initialized
INFO - 2016-12-16 14:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:17:37 --> Controller Class Initialized
INFO - 2016-12-16 14:17:37 --> Helper loaded: url_helper
DEBUG - 2016-12-16 14:17:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:17:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:17:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 14:17:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 14:17:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:17:37 --> Final output sent to browser
DEBUG - 2016-12-16 14:17:37 --> Total execution time: 0.0133
INFO - 2016-12-16 14:17:42 --> Config Class Initialized
INFO - 2016-12-16 14:17:42 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:17:42 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:17:42 --> Utf8 Class Initialized
INFO - 2016-12-16 14:17:42 --> URI Class Initialized
INFO - 2016-12-16 14:17:42 --> Router Class Initialized
INFO - 2016-12-16 14:17:42 --> Output Class Initialized
INFO - 2016-12-16 14:17:42 --> Security Class Initialized
DEBUG - 2016-12-16 14:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:17:42 --> Input Class Initialized
INFO - 2016-12-16 14:17:42 --> Language Class Initialized
INFO - 2016-12-16 14:17:42 --> Loader Class Initialized
INFO - 2016-12-16 14:17:42 --> Database Driver Class Initialized
INFO - 2016-12-16 14:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:17:42 --> Controller Class Initialized
DEBUG - 2016-12-16 14:17:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:17:42 --> Helper loaded: url_helper
INFO - 2016-12-16 14:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2016-12-16 14:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-16 14:17:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:17:42 --> Final output sent to browser
DEBUG - 2016-12-16 14:17:42 --> Total execution time: 0.0508
INFO - 2016-12-16 14:17:43 --> Config Class Initialized
INFO - 2016-12-16 14:17:43 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:17:43 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:17:43 --> Utf8 Class Initialized
INFO - 2016-12-16 14:17:43 --> URI Class Initialized
INFO - 2016-12-16 14:17:43 --> Router Class Initialized
INFO - 2016-12-16 14:17:43 --> Output Class Initialized
INFO - 2016-12-16 14:17:43 --> Security Class Initialized
DEBUG - 2016-12-16 14:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:17:43 --> Input Class Initialized
INFO - 2016-12-16 14:17:43 --> Language Class Initialized
INFO - 2016-12-16 14:17:43 --> Loader Class Initialized
INFO - 2016-12-16 14:17:43 --> Database Driver Class Initialized
INFO - 2016-12-16 14:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:17:43 --> Controller Class Initialized
INFO - 2016-12-16 14:17:43 --> Helper loaded: url_helper
DEBUG - 2016-12-16 14:17:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 14:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 14:17:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:17:43 --> Final output sent to browser
DEBUG - 2016-12-16 14:17:43 --> Total execution time: 0.0760
INFO - 2016-12-16 14:17:54 --> Config Class Initialized
INFO - 2016-12-16 14:17:54 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:17:54 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:17:54 --> Utf8 Class Initialized
INFO - 2016-12-16 14:17:54 --> URI Class Initialized
DEBUG - 2016-12-16 14:17:54 --> No URI present. Default controller set.
INFO - 2016-12-16 14:17:54 --> Router Class Initialized
INFO - 2016-12-16 14:17:54 --> Output Class Initialized
INFO - 2016-12-16 14:17:54 --> Security Class Initialized
DEBUG - 2016-12-16 14:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:17:54 --> Input Class Initialized
INFO - 2016-12-16 14:17:54 --> Language Class Initialized
INFO - 2016-12-16 14:17:54 --> Loader Class Initialized
INFO - 2016-12-16 14:17:54 --> Database Driver Class Initialized
INFO - 2016-12-16 14:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:17:54 --> Controller Class Initialized
INFO - 2016-12-16 14:17:54 --> Helper loaded: url_helper
DEBUG - 2016-12-16 14:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:17:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:17:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 14:17:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 14:17:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:17:54 --> Final output sent to browser
DEBUG - 2016-12-16 14:17:54 --> Total execution time: 0.0337
INFO - 2016-12-16 14:17:55 --> Config Class Initialized
INFO - 2016-12-16 14:17:55 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:17:55 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:17:55 --> Utf8 Class Initialized
INFO - 2016-12-16 14:17:55 --> URI Class Initialized
INFO - 2016-12-16 14:17:55 --> Router Class Initialized
INFO - 2016-12-16 14:17:55 --> Output Class Initialized
INFO - 2016-12-16 14:17:55 --> Security Class Initialized
DEBUG - 2016-12-16 14:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:17:55 --> Input Class Initialized
INFO - 2016-12-16 14:17:55 --> Language Class Initialized
INFO - 2016-12-16 14:17:55 --> Loader Class Initialized
INFO - 2016-12-16 14:17:55 --> Database Driver Class Initialized
INFO - 2016-12-16 14:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:17:55 --> Controller Class Initialized
INFO - 2016-12-16 14:17:55 --> Helper loaded: url_helper
DEBUG - 2016-12-16 14:17:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:17:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:17:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 14:17:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 14:17:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:17:55 --> Final output sent to browser
DEBUG - 2016-12-16 14:17:55 --> Total execution time: 0.0136
INFO - 2016-12-16 14:17:59 --> Config Class Initialized
INFO - 2016-12-16 14:17:59 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:17:59 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:17:59 --> Utf8 Class Initialized
INFO - 2016-12-16 14:17:59 --> URI Class Initialized
INFO - 2016-12-16 14:17:59 --> Router Class Initialized
INFO - 2016-12-16 14:17:59 --> Output Class Initialized
INFO - 2016-12-16 14:17:59 --> Security Class Initialized
DEBUG - 2016-12-16 14:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:17:59 --> Input Class Initialized
INFO - 2016-12-16 14:17:59 --> Language Class Initialized
INFO - 2016-12-16 14:17:59 --> Loader Class Initialized
INFO - 2016-12-16 14:17:59 --> Database Driver Class Initialized
INFO - 2016-12-16 14:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:17:59 --> Controller Class Initialized
INFO - 2016-12-16 14:17:59 --> Helper loaded: url_helper
DEBUG - 2016-12-16 14:17:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:18:01 --> Config Class Initialized
INFO - 2016-12-16 14:18:01 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:18:01 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:18:01 --> Utf8 Class Initialized
INFO - 2016-12-16 14:18:01 --> URI Class Initialized
INFO - 2016-12-16 14:18:01 --> Router Class Initialized
INFO - 2016-12-16 14:18:01 --> Output Class Initialized
INFO - 2016-12-16 14:18:01 --> Security Class Initialized
DEBUG - 2016-12-16 14:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:18:01 --> Input Class Initialized
INFO - 2016-12-16 14:18:01 --> Language Class Initialized
INFO - 2016-12-16 14:18:01 --> Loader Class Initialized
INFO - 2016-12-16 14:18:01 --> Database Driver Class Initialized
INFO - 2016-12-16 14:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:18:01 --> Controller Class Initialized
DEBUG - 2016-12-16 14:18:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:18:01 --> Helper loaded: url_helper
INFO - 2016-12-16 14:18:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:18:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 14:18:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-16 14:18:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-16 14:18:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:18:01 --> Final output sent to browser
DEBUG - 2016-12-16 14:18:01 --> Total execution time: 0.0307
INFO - 2016-12-16 14:18:02 --> Config Class Initialized
INFO - 2016-12-16 14:18:02 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:18:02 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:18:02 --> Utf8 Class Initialized
INFO - 2016-12-16 14:18:02 --> URI Class Initialized
INFO - 2016-12-16 14:18:02 --> Router Class Initialized
INFO - 2016-12-16 14:18:02 --> Output Class Initialized
INFO - 2016-12-16 14:18:02 --> Security Class Initialized
DEBUG - 2016-12-16 14:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:18:02 --> Input Class Initialized
INFO - 2016-12-16 14:18:02 --> Language Class Initialized
INFO - 2016-12-16 14:18:02 --> Loader Class Initialized
INFO - 2016-12-16 14:18:02 --> Database Driver Class Initialized
INFO - 2016-12-16 14:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:18:02 --> Controller Class Initialized
INFO - 2016-12-16 14:18:02 --> Helper loaded: url_helper
DEBUG - 2016-12-16 14:18:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:18:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:18:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 14:18:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 14:18:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:18:02 --> Final output sent to browser
DEBUG - 2016-12-16 14:18:02 --> Total execution time: 0.0134
INFO - 2016-12-16 14:18:08 --> Config Class Initialized
INFO - 2016-12-16 14:18:08 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:18:08 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:18:08 --> Utf8 Class Initialized
INFO - 2016-12-16 14:18:08 --> URI Class Initialized
INFO - 2016-12-16 14:18:08 --> Router Class Initialized
INFO - 2016-12-16 14:18:08 --> Output Class Initialized
INFO - 2016-12-16 14:18:08 --> Security Class Initialized
DEBUG - 2016-12-16 14:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:18:08 --> Input Class Initialized
INFO - 2016-12-16 14:18:08 --> Language Class Initialized
INFO - 2016-12-16 14:18:08 --> Loader Class Initialized
INFO - 2016-12-16 14:18:08 --> Database Driver Class Initialized
INFO - 2016-12-16 14:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:18:08 --> Controller Class Initialized
DEBUG - 2016-12-16 14:18:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:18:08 --> Helper loaded: url_helper
INFO - 2016-12-16 14:18:08 --> Final output sent to browser
DEBUG - 2016-12-16 14:18:08 --> Total execution time: 0.0113
INFO - 2016-12-16 14:35:56 --> Config Class Initialized
INFO - 2016-12-16 14:35:56 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:35:56 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:35:56 --> Utf8 Class Initialized
INFO - 2016-12-16 14:35:56 --> URI Class Initialized
INFO - 2016-12-16 14:35:56 --> Router Class Initialized
INFO - 2016-12-16 14:35:56 --> Output Class Initialized
INFO - 2016-12-16 14:35:56 --> Security Class Initialized
DEBUG - 2016-12-16 14:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:35:56 --> Input Class Initialized
INFO - 2016-12-16 14:35:56 --> Language Class Initialized
INFO - 2016-12-16 14:35:56 --> Loader Class Initialized
INFO - 2016-12-16 14:35:56 --> Database Driver Class Initialized
INFO - 2016-12-16 14:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:35:56 --> Controller Class Initialized
INFO - 2016-12-16 14:35:56 --> Helper loaded: date_helper
INFO - 2016-12-16 14:35:56 --> Helper loaded: url_helper
DEBUG - 2016-12-16 14:35:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:35:56 --> Helper loaded: form_helper
INFO - 2016-12-16 14:35:56 --> Form Validation Class Initialized
INFO - 2016-12-16 14:35:56 --> Config Class Initialized
INFO - 2016-12-16 14:35:56 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:35:56 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:35:56 --> Utf8 Class Initialized
INFO - 2016-12-16 14:35:56 --> URI Class Initialized
INFO - 2016-12-16 14:35:56 --> Router Class Initialized
INFO - 2016-12-16 14:35:56 --> Output Class Initialized
INFO - 2016-12-16 14:35:56 --> Security Class Initialized
DEBUG - 2016-12-16 14:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:35:56 --> Input Class Initialized
INFO - 2016-12-16 14:35:56 --> Language Class Initialized
INFO - 2016-12-16 14:35:56 --> Loader Class Initialized
INFO - 2016-12-16 14:35:56 --> Database Driver Class Initialized
INFO - 2016-12-16 14:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:35:56 --> Controller Class Initialized
INFO - 2016-12-16 14:35:56 --> Helper loaded: url_helper
DEBUG - 2016-12-16 14:35:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:35:56 --> Helper loaded: form_helper
INFO - 2016-12-16 14:35:56 --> Form Validation Class Initialized
INFO - 2016-12-16 14:35:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-16 14:35:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2016-12-16 14:35:56 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-16 14:35:56 --> Final output sent to browser
DEBUG - 2016-12-16 14:35:56 --> Total execution time: 0.0669
INFO - 2016-12-16 14:35:57 --> Config Class Initialized
INFO - 2016-12-16 14:35:57 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:35:57 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:35:57 --> Utf8 Class Initialized
INFO - 2016-12-16 14:35:57 --> URI Class Initialized
INFO - 2016-12-16 14:35:57 --> Router Class Initialized
INFO - 2016-12-16 14:35:57 --> Output Class Initialized
INFO - 2016-12-16 14:35:57 --> Security Class Initialized
DEBUG - 2016-12-16 14:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:35:57 --> Input Class Initialized
INFO - 2016-12-16 14:35:57 --> Language Class Initialized
INFO - 2016-12-16 14:35:57 --> Loader Class Initialized
INFO - 2016-12-16 14:35:57 --> Database Driver Class Initialized
INFO - 2016-12-16 14:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:35:57 --> Controller Class Initialized
INFO - 2016-12-16 14:35:57 --> Helper loaded: url_helper
DEBUG - 2016-12-16 14:35:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:35:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:35:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 14:35:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 14:35:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:35:57 --> Final output sent to browser
DEBUG - 2016-12-16 14:35:57 --> Total execution time: 0.0148
INFO - 2016-12-16 14:36:00 --> Config Class Initialized
INFO - 2016-12-16 14:36:00 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:36:00 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:36:00 --> Utf8 Class Initialized
INFO - 2016-12-16 14:36:00 --> URI Class Initialized
DEBUG - 2016-12-16 14:36:00 --> No URI present. Default controller set.
INFO - 2016-12-16 14:36:00 --> Router Class Initialized
INFO - 2016-12-16 14:36:00 --> Output Class Initialized
INFO - 2016-12-16 14:36:00 --> Security Class Initialized
DEBUG - 2016-12-16 14:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:36:00 --> Input Class Initialized
INFO - 2016-12-16 14:36:00 --> Language Class Initialized
INFO - 2016-12-16 14:36:00 --> Loader Class Initialized
INFO - 2016-12-16 14:36:00 --> Database Driver Class Initialized
INFO - 2016-12-16 14:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:36:00 --> Controller Class Initialized
INFO - 2016-12-16 14:36:00 --> Helper loaded: url_helper
DEBUG - 2016-12-16 14:36:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:36:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:36:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 14:36:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 14:36:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:36:00 --> Final output sent to browser
DEBUG - 2016-12-16 14:36:00 --> Total execution time: 0.0134
INFO - 2016-12-16 14:36:01 --> Config Class Initialized
INFO - 2016-12-16 14:36:01 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:36:01 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:36:01 --> Utf8 Class Initialized
INFO - 2016-12-16 14:36:01 --> URI Class Initialized
INFO - 2016-12-16 14:36:01 --> Router Class Initialized
INFO - 2016-12-16 14:36:01 --> Output Class Initialized
INFO - 2016-12-16 14:36:01 --> Security Class Initialized
DEBUG - 2016-12-16 14:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:36:01 --> Input Class Initialized
INFO - 2016-12-16 14:36:01 --> Language Class Initialized
INFO - 2016-12-16 14:36:01 --> Loader Class Initialized
INFO - 2016-12-16 14:36:01 --> Database Driver Class Initialized
INFO - 2016-12-16 14:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:36:01 --> Controller Class Initialized
INFO - 2016-12-16 14:36:01 --> Helper loaded: url_helper
DEBUG - 2016-12-16 14:36:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:36:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:36:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 14:36:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 14:36:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:36:01 --> Final output sent to browser
DEBUG - 2016-12-16 14:36:01 --> Total execution time: 0.0137
INFO - 2016-12-16 14:36:05 --> Config Class Initialized
INFO - 2016-12-16 14:36:05 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:36:05 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:36:05 --> Utf8 Class Initialized
INFO - 2016-12-16 14:36:05 --> URI Class Initialized
INFO - 2016-12-16 14:36:05 --> Router Class Initialized
INFO - 2016-12-16 14:36:05 --> Output Class Initialized
INFO - 2016-12-16 14:36:05 --> Security Class Initialized
DEBUG - 2016-12-16 14:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:36:05 --> Input Class Initialized
INFO - 2016-12-16 14:36:05 --> Language Class Initialized
INFO - 2016-12-16 14:36:05 --> Loader Class Initialized
INFO - 2016-12-16 14:36:05 --> Database Driver Class Initialized
INFO - 2016-12-16 14:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:36:05 --> Controller Class Initialized
INFO - 2016-12-16 14:36:05 --> Helper loaded: url_helper
DEBUG - 2016-12-16 14:36:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:36:06 --> Config Class Initialized
INFO - 2016-12-16 14:36:06 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:36:06 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:36:06 --> Utf8 Class Initialized
INFO - 2016-12-16 14:36:06 --> URI Class Initialized
INFO - 2016-12-16 14:36:06 --> Router Class Initialized
INFO - 2016-12-16 14:36:06 --> Output Class Initialized
INFO - 2016-12-16 14:36:06 --> Security Class Initialized
DEBUG - 2016-12-16 14:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:36:06 --> Input Class Initialized
INFO - 2016-12-16 14:36:06 --> Language Class Initialized
INFO - 2016-12-16 14:36:06 --> Loader Class Initialized
INFO - 2016-12-16 14:36:06 --> Database Driver Class Initialized
INFO - 2016-12-16 14:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:36:06 --> Controller Class Initialized
DEBUG - 2016-12-16 14:36:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:36:06 --> Helper loaded: url_helper
INFO - 2016-12-16 14:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 14:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-16 14:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-16 14:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:36:06 --> Final output sent to browser
DEBUG - 2016-12-16 14:36:06 --> Total execution time: 0.0153
INFO - 2016-12-16 14:36:06 --> Config Class Initialized
INFO - 2016-12-16 14:36:06 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:36:06 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:36:06 --> Utf8 Class Initialized
INFO - 2016-12-16 14:36:06 --> URI Class Initialized
INFO - 2016-12-16 14:36:06 --> Router Class Initialized
INFO - 2016-12-16 14:36:06 --> Output Class Initialized
INFO - 2016-12-16 14:36:06 --> Security Class Initialized
DEBUG - 2016-12-16 14:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:36:06 --> Input Class Initialized
INFO - 2016-12-16 14:36:06 --> Language Class Initialized
INFO - 2016-12-16 14:36:06 --> Loader Class Initialized
INFO - 2016-12-16 14:36:06 --> Database Driver Class Initialized
INFO - 2016-12-16 14:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:36:06 --> Controller Class Initialized
INFO - 2016-12-16 14:36:06 --> Helper loaded: url_helper
DEBUG - 2016-12-16 14:36:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 14:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 14:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:36:06 --> Final output sent to browser
DEBUG - 2016-12-16 14:36:06 --> Total execution time: 0.0140
INFO - 2016-12-16 14:36:47 --> Config Class Initialized
INFO - 2016-12-16 14:36:47 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:36:47 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:36:47 --> Utf8 Class Initialized
INFO - 2016-12-16 14:36:47 --> URI Class Initialized
INFO - 2016-12-16 14:36:47 --> Router Class Initialized
INFO - 2016-12-16 14:36:47 --> Output Class Initialized
INFO - 2016-12-16 14:36:47 --> Security Class Initialized
DEBUG - 2016-12-16 14:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:36:47 --> Input Class Initialized
INFO - 2016-12-16 14:36:47 --> Language Class Initialized
INFO - 2016-12-16 14:36:47 --> Loader Class Initialized
INFO - 2016-12-16 14:36:47 --> Database Driver Class Initialized
INFO - 2016-12-16 14:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:36:47 --> Controller Class Initialized
INFO - 2016-12-16 14:36:47 --> Helper loaded: date_helper
DEBUG - 2016-12-16 14:36:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:36:47 --> Helper loaded: url_helper
INFO - 2016-12-16 14:36:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:36:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 14:36:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-16 14:36:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-16 14:36:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:36:47 --> Final output sent to browser
DEBUG - 2016-12-16 14:36:47 --> Total execution time: 0.0167
INFO - 2016-12-16 14:36:48 --> Config Class Initialized
INFO - 2016-12-16 14:36:48 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:36:48 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:36:48 --> Utf8 Class Initialized
INFO - 2016-12-16 14:36:48 --> URI Class Initialized
INFO - 2016-12-16 14:36:48 --> Router Class Initialized
INFO - 2016-12-16 14:36:48 --> Output Class Initialized
INFO - 2016-12-16 14:36:48 --> Security Class Initialized
DEBUG - 2016-12-16 14:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:36:48 --> Input Class Initialized
INFO - 2016-12-16 14:36:48 --> Language Class Initialized
INFO - 2016-12-16 14:36:48 --> Loader Class Initialized
INFO - 2016-12-16 14:36:48 --> Database Driver Class Initialized
INFO - 2016-12-16 14:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:36:48 --> Controller Class Initialized
INFO - 2016-12-16 14:36:48 --> Helper loaded: url_helper
DEBUG - 2016-12-16 14:36:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:36:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:36:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 14:36:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 14:36:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:36:48 --> Final output sent to browser
DEBUG - 2016-12-16 14:36:48 --> Total execution time: 0.0130
INFO - 2016-12-16 14:36:57 --> Config Class Initialized
INFO - 2016-12-16 14:36:57 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:36:57 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:36:57 --> Utf8 Class Initialized
INFO - 2016-12-16 14:36:57 --> URI Class Initialized
INFO - 2016-12-16 14:36:57 --> Router Class Initialized
INFO - 2016-12-16 14:36:57 --> Output Class Initialized
INFO - 2016-12-16 14:36:57 --> Security Class Initialized
DEBUG - 2016-12-16 14:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:36:57 --> Input Class Initialized
INFO - 2016-12-16 14:36:57 --> Language Class Initialized
ERROR - 2016-12-16 14:36:57 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 14:49:12 --> Config Class Initialized
INFO - 2016-12-16 14:49:12 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:49:12 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:49:12 --> Utf8 Class Initialized
INFO - 2016-12-16 14:49:12 --> URI Class Initialized
DEBUG - 2016-12-16 14:49:12 --> No URI present. Default controller set.
INFO - 2016-12-16 14:49:12 --> Router Class Initialized
INFO - 2016-12-16 14:49:12 --> Output Class Initialized
INFO - 2016-12-16 14:49:12 --> Security Class Initialized
DEBUG - 2016-12-16 14:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:49:12 --> Input Class Initialized
INFO - 2016-12-16 14:49:12 --> Language Class Initialized
INFO - 2016-12-16 14:49:12 --> Loader Class Initialized
INFO - 2016-12-16 14:49:12 --> Database Driver Class Initialized
INFO - 2016-12-16 14:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:49:12 --> Controller Class Initialized
INFO - 2016-12-16 14:49:13 --> Helper loaded: url_helper
DEBUG - 2016-12-16 14:49:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:49:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:49:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 14:49:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 14:49:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:49:13 --> Final output sent to browser
DEBUG - 2016-12-16 14:49:13 --> Total execution time: 0.4126
INFO - 2016-12-16 14:49:13 --> Config Class Initialized
INFO - 2016-12-16 14:49:13 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:49:13 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:49:13 --> Utf8 Class Initialized
INFO - 2016-12-16 14:49:13 --> URI Class Initialized
INFO - 2016-12-16 14:49:13 --> Router Class Initialized
INFO - 2016-12-16 14:49:13 --> Output Class Initialized
INFO - 2016-12-16 14:49:13 --> Security Class Initialized
DEBUG - 2016-12-16 14:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:49:13 --> Input Class Initialized
INFO - 2016-12-16 14:49:13 --> Language Class Initialized
INFO - 2016-12-16 14:49:13 --> Loader Class Initialized
INFO - 2016-12-16 14:49:13 --> Database Driver Class Initialized
INFO - 2016-12-16 14:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:49:13 --> Controller Class Initialized
INFO - 2016-12-16 14:49:13 --> Helper loaded: url_helper
DEBUG - 2016-12-16 14:49:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:49:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:49:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 14:49:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 14:49:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:49:13 --> Final output sent to browser
DEBUG - 2016-12-16 14:49:13 --> Total execution time: 0.0129
INFO - 2016-12-16 14:49:17 --> Config Class Initialized
INFO - 2016-12-16 14:49:17 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:49:17 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:49:17 --> Utf8 Class Initialized
INFO - 2016-12-16 14:49:17 --> URI Class Initialized
INFO - 2016-12-16 14:49:17 --> Router Class Initialized
INFO - 2016-12-16 14:49:17 --> Output Class Initialized
INFO - 2016-12-16 14:49:17 --> Security Class Initialized
DEBUG - 2016-12-16 14:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:49:17 --> Input Class Initialized
INFO - 2016-12-16 14:49:17 --> Language Class Initialized
INFO - 2016-12-16 14:49:17 --> Loader Class Initialized
INFO - 2016-12-16 14:49:17 --> Database Driver Class Initialized
INFO - 2016-12-16 14:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:49:17 --> Controller Class Initialized
INFO - 2016-12-16 14:49:17 --> Helper loaded: url_helper
DEBUG - 2016-12-16 14:49:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:49:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:49:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 14:49:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 14:49:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:49:17 --> Final output sent to browser
DEBUG - 2016-12-16 14:49:17 --> Total execution time: 0.0136
INFO - 2016-12-16 14:51:52 --> Config Class Initialized
INFO - 2016-12-16 14:51:52 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:51:52 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:51:52 --> Utf8 Class Initialized
INFO - 2016-12-16 14:51:52 --> URI Class Initialized
INFO - 2016-12-16 14:51:52 --> Router Class Initialized
INFO - 2016-12-16 14:51:52 --> Output Class Initialized
INFO - 2016-12-16 14:51:52 --> Security Class Initialized
DEBUG - 2016-12-16 14:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:51:52 --> Input Class Initialized
INFO - 2016-12-16 14:51:52 --> Language Class Initialized
INFO - 2016-12-16 14:51:52 --> Loader Class Initialized
INFO - 2016-12-16 14:51:52 --> Database Driver Class Initialized
INFO - 2016-12-16 14:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:51:52 --> Controller Class Initialized
INFO - 2016-12-16 14:51:52 --> Helper loaded: date_helper
DEBUG - 2016-12-16 14:51:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:51:52 --> Helper loaded: url_helper
INFO - 2016-12-16 14:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 14:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-16 14:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-16 14:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:51:52 --> Final output sent to browser
DEBUG - 2016-12-16 14:51:52 --> Total execution time: 0.1576
INFO - 2016-12-16 14:51:53 --> Config Class Initialized
INFO - 2016-12-16 14:51:53 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:51:53 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:51:53 --> Utf8 Class Initialized
INFO - 2016-12-16 14:51:53 --> URI Class Initialized
INFO - 2016-12-16 14:51:53 --> Router Class Initialized
INFO - 2016-12-16 14:51:53 --> Output Class Initialized
INFO - 2016-12-16 14:51:53 --> Security Class Initialized
DEBUG - 2016-12-16 14:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:51:53 --> Input Class Initialized
INFO - 2016-12-16 14:51:53 --> Language Class Initialized
ERROR - 2016-12-16 14:51:53 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 14:51:53 --> Config Class Initialized
INFO - 2016-12-16 14:51:53 --> Hooks Class Initialized
DEBUG - 2016-12-16 14:51:53 --> UTF-8 Support Enabled
INFO - 2016-12-16 14:51:53 --> Utf8 Class Initialized
INFO - 2016-12-16 14:51:53 --> URI Class Initialized
INFO - 2016-12-16 14:51:53 --> Router Class Initialized
INFO - 2016-12-16 14:51:53 --> Output Class Initialized
INFO - 2016-12-16 14:51:53 --> Security Class Initialized
DEBUG - 2016-12-16 14:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 14:51:53 --> Input Class Initialized
INFO - 2016-12-16 14:51:53 --> Language Class Initialized
INFO - 2016-12-16 14:51:53 --> Loader Class Initialized
INFO - 2016-12-16 14:51:53 --> Database Driver Class Initialized
INFO - 2016-12-16 14:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 14:51:53 --> Controller Class Initialized
INFO - 2016-12-16 14:51:53 --> Helper loaded: url_helper
DEBUG - 2016-12-16 14:51:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 14:51:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 14:51:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 14:51:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 14:51:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 14:51:53 --> Final output sent to browser
DEBUG - 2016-12-16 14:51:53 --> Total execution time: 0.0133
INFO - 2016-12-16 15:03:49 --> Config Class Initialized
INFO - 2016-12-16 15:03:49 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:03:49 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:03:49 --> Utf8 Class Initialized
INFO - 2016-12-16 15:03:49 --> URI Class Initialized
INFO - 2016-12-16 15:03:49 --> Router Class Initialized
INFO - 2016-12-16 15:03:49 --> Output Class Initialized
INFO - 2016-12-16 15:03:49 --> Security Class Initialized
DEBUG - 2016-12-16 15:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:03:49 --> Input Class Initialized
INFO - 2016-12-16 15:03:49 --> Language Class Initialized
INFO - 2016-12-16 15:03:49 --> Loader Class Initialized
INFO - 2016-12-16 15:03:49 --> Database Driver Class Initialized
INFO - 2016-12-16 15:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:03:49 --> Controller Class Initialized
INFO - 2016-12-16 15:03:49 --> Helper loaded: date_helper
DEBUG - 2016-12-16 15:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:03:49 --> Helper loaded: url_helper
INFO - 2016-12-16 15:03:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:03:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:03:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-16 15:03:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-16 15:03:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:03:49 --> Final output sent to browser
DEBUG - 2016-12-16 15:03:49 --> Total execution time: 0.0190
INFO - 2016-12-16 15:03:50 --> Config Class Initialized
INFO - 2016-12-16 15:03:50 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:03:50 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:03:50 --> Utf8 Class Initialized
INFO - 2016-12-16 15:03:50 --> URI Class Initialized
INFO - 2016-12-16 15:03:50 --> Router Class Initialized
INFO - 2016-12-16 15:03:50 --> Output Class Initialized
INFO - 2016-12-16 15:03:50 --> Security Class Initialized
DEBUG - 2016-12-16 15:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:03:50 --> Input Class Initialized
INFO - 2016-12-16 15:03:50 --> Language Class Initialized
ERROR - 2016-12-16 15:03:50 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:03:50 --> Config Class Initialized
INFO - 2016-12-16 15:03:50 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:03:50 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:03:50 --> Utf8 Class Initialized
INFO - 2016-12-16 15:03:50 --> URI Class Initialized
INFO - 2016-12-16 15:03:50 --> Router Class Initialized
INFO - 2016-12-16 15:03:50 --> Output Class Initialized
INFO - 2016-12-16 15:03:50 --> Security Class Initialized
DEBUG - 2016-12-16 15:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:03:50 --> Input Class Initialized
INFO - 2016-12-16 15:03:50 --> Language Class Initialized
INFO - 2016-12-16 15:03:50 --> Loader Class Initialized
INFO - 2016-12-16 15:03:50 --> Database Driver Class Initialized
INFO - 2016-12-16 15:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:03:50 --> Controller Class Initialized
INFO - 2016-12-16 15:03:50 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:03:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:03:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:03:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:03:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:03:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:03:50 --> Final output sent to browser
DEBUG - 2016-12-16 15:03:50 --> Total execution time: 0.0135
INFO - 2016-12-16 15:03:53 --> Config Class Initialized
INFO - 2016-12-16 15:03:53 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:03:53 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:03:53 --> Utf8 Class Initialized
INFO - 2016-12-16 15:03:53 --> URI Class Initialized
INFO - 2016-12-16 15:03:53 --> Router Class Initialized
INFO - 2016-12-16 15:03:53 --> Output Class Initialized
INFO - 2016-12-16 15:03:53 --> Security Class Initialized
DEBUG - 2016-12-16 15:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:03:53 --> Input Class Initialized
INFO - 2016-12-16 15:03:53 --> Language Class Initialized
INFO - 2016-12-16 15:03:54 --> Loader Class Initialized
INFO - 2016-12-16 15:03:54 --> Database Driver Class Initialized
INFO - 2016-12-16 15:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:03:54 --> Controller Class Initialized
DEBUG - 2016-12-16 15:03:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:03:54 --> Helper loaded: url_helper
INFO - 2016-12-16 15:03:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:03:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:03:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-16 15:03:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-16 15:03:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:03:54 --> Final output sent to browser
DEBUG - 2016-12-16 15:03:54 --> Total execution time: 0.2913
INFO - 2016-12-16 15:03:54 --> Config Class Initialized
INFO - 2016-12-16 15:03:54 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:03:54 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:03:54 --> Utf8 Class Initialized
INFO - 2016-12-16 15:03:54 --> URI Class Initialized
INFO - 2016-12-16 15:03:54 --> Router Class Initialized
INFO - 2016-12-16 15:03:54 --> Output Class Initialized
INFO - 2016-12-16 15:03:54 --> Security Class Initialized
DEBUG - 2016-12-16 15:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:03:54 --> Input Class Initialized
INFO - 2016-12-16 15:03:54 --> Language Class Initialized
ERROR - 2016-12-16 15:03:54 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:03:54 --> Config Class Initialized
INFO - 2016-12-16 15:03:54 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:03:54 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:03:54 --> Utf8 Class Initialized
INFO - 2016-12-16 15:03:54 --> URI Class Initialized
INFO - 2016-12-16 15:03:54 --> Router Class Initialized
INFO - 2016-12-16 15:03:54 --> Output Class Initialized
INFO - 2016-12-16 15:03:54 --> Security Class Initialized
DEBUG - 2016-12-16 15:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:03:54 --> Input Class Initialized
INFO - 2016-12-16 15:03:54 --> Language Class Initialized
INFO - 2016-12-16 15:03:54 --> Loader Class Initialized
INFO - 2016-12-16 15:03:54 --> Database Driver Class Initialized
INFO - 2016-12-16 15:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:03:54 --> Controller Class Initialized
INFO - 2016-12-16 15:03:54 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:03:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:03:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:03:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:03:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:03:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:03:54 --> Final output sent to browser
DEBUG - 2016-12-16 15:03:54 --> Total execution time: 0.0134
INFO - 2016-12-16 15:03:57 --> Config Class Initialized
INFO - 2016-12-16 15:03:57 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:03:57 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:03:57 --> Utf8 Class Initialized
INFO - 2016-12-16 15:03:57 --> URI Class Initialized
INFO - 2016-12-16 15:03:57 --> Router Class Initialized
INFO - 2016-12-16 15:03:57 --> Output Class Initialized
INFO - 2016-12-16 15:03:57 --> Security Class Initialized
DEBUG - 2016-12-16 15:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:03:57 --> Input Class Initialized
INFO - 2016-12-16 15:03:57 --> Language Class Initialized
INFO - 2016-12-16 15:03:57 --> Loader Class Initialized
INFO - 2016-12-16 15:03:57 --> Database Driver Class Initialized
INFO - 2016-12-16 15:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:03:57 --> Controller Class Initialized
DEBUG - 2016-12-16 15:03:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:03:57 --> Helper loaded: url_helper
INFO - 2016-12-16 15:03:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:03:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:03:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:03:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:03:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:03:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:03:57 --> Final output sent to browser
DEBUG - 2016-12-16 15:03:57 --> Total execution time: 0.1074
INFO - 2016-12-16 15:03:57 --> Config Class Initialized
INFO - 2016-12-16 15:03:57 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:03:57 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:03:57 --> Utf8 Class Initialized
INFO - 2016-12-16 15:03:57 --> URI Class Initialized
INFO - 2016-12-16 15:03:57 --> Router Class Initialized
INFO - 2016-12-16 15:03:57 --> Output Class Initialized
INFO - 2016-12-16 15:03:57 --> Security Class Initialized
DEBUG - 2016-12-16 15:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:03:57 --> Input Class Initialized
INFO - 2016-12-16 15:03:57 --> Language Class Initialized
ERROR - 2016-12-16 15:03:57 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:03:57 --> Config Class Initialized
INFO - 2016-12-16 15:03:57 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:03:57 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:03:57 --> Utf8 Class Initialized
INFO - 2016-12-16 15:03:57 --> URI Class Initialized
INFO - 2016-12-16 15:03:57 --> Router Class Initialized
INFO - 2016-12-16 15:03:57 --> Output Class Initialized
INFO - 2016-12-16 15:03:57 --> Security Class Initialized
DEBUG - 2016-12-16 15:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:03:57 --> Input Class Initialized
INFO - 2016-12-16 15:03:57 --> Language Class Initialized
INFO - 2016-12-16 15:03:57 --> Loader Class Initialized
INFO - 2016-12-16 15:03:57 --> Database Driver Class Initialized
INFO - 2016-12-16 15:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:03:57 --> Controller Class Initialized
INFO - 2016-12-16 15:03:57 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:03:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:03:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:03:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:03:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:03:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:03:57 --> Final output sent to browser
DEBUG - 2016-12-16 15:03:57 --> Total execution time: 0.0132
INFO - 2016-12-16 15:04:10 --> Config Class Initialized
INFO - 2016-12-16 15:04:10 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:04:10 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:04:10 --> Utf8 Class Initialized
INFO - 2016-12-16 15:04:10 --> URI Class Initialized
INFO - 2016-12-16 15:04:10 --> Router Class Initialized
INFO - 2016-12-16 15:04:10 --> Output Class Initialized
INFO - 2016-12-16 15:04:10 --> Security Class Initialized
DEBUG - 2016-12-16 15:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:04:10 --> Input Class Initialized
INFO - 2016-12-16 15:04:10 --> Language Class Initialized
INFO - 2016-12-16 15:04:10 --> Loader Class Initialized
INFO - 2016-12-16 15:04:11 --> Database Driver Class Initialized
INFO - 2016-12-16 15:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:04:11 --> Controller Class Initialized
INFO - 2016-12-16 15:04:11 --> Upload Class Initialized
DEBUG - 2016-12-16 15:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:04:11 --> Helper loaded: url_helper
INFO - 2016-12-16 15:04:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:04:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:04:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-16 15:04:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-16 15:04:11 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-16 15:04:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:04:11 --> Final output sent to browser
DEBUG - 2016-12-16 15:04:11 --> Total execution time: 0.4390
INFO - 2016-12-16 15:04:11 --> Config Class Initialized
INFO - 2016-12-16 15:04:11 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:04:11 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:04:11 --> Utf8 Class Initialized
INFO - 2016-12-16 15:04:11 --> URI Class Initialized
INFO - 2016-12-16 15:04:11 --> Router Class Initialized
INFO - 2016-12-16 15:04:11 --> Output Class Initialized
INFO - 2016-12-16 15:04:11 --> Security Class Initialized
DEBUG - 2016-12-16 15:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:04:11 --> Input Class Initialized
INFO - 2016-12-16 15:04:11 --> Language Class Initialized
ERROR - 2016-12-16 15:04:11 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:04:11 --> Config Class Initialized
INFO - 2016-12-16 15:04:11 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:04:11 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:04:11 --> Utf8 Class Initialized
INFO - 2016-12-16 15:04:11 --> URI Class Initialized
INFO - 2016-12-16 15:04:11 --> Router Class Initialized
INFO - 2016-12-16 15:04:11 --> Output Class Initialized
INFO - 2016-12-16 15:04:11 --> Security Class Initialized
DEBUG - 2016-12-16 15:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:04:11 --> Input Class Initialized
INFO - 2016-12-16 15:04:11 --> Language Class Initialized
INFO - 2016-12-16 15:04:11 --> Loader Class Initialized
INFO - 2016-12-16 15:04:11 --> Database Driver Class Initialized
INFO - 2016-12-16 15:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:04:11 --> Controller Class Initialized
INFO - 2016-12-16 15:04:11 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:04:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:04:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:04:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:04:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:04:11 --> Final output sent to browser
DEBUG - 2016-12-16 15:04:11 --> Total execution time: 0.0137
INFO - 2016-12-16 15:04:16 --> Config Class Initialized
INFO - 2016-12-16 15:04:16 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:04:16 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:04:16 --> Utf8 Class Initialized
INFO - 2016-12-16 15:04:16 --> URI Class Initialized
INFO - 2016-12-16 15:04:16 --> Router Class Initialized
INFO - 2016-12-16 15:04:16 --> Output Class Initialized
INFO - 2016-12-16 15:04:16 --> Security Class Initialized
DEBUG - 2016-12-16 15:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:04:16 --> Input Class Initialized
INFO - 2016-12-16 15:04:16 --> Language Class Initialized
INFO - 2016-12-16 15:04:16 --> Loader Class Initialized
INFO - 2016-12-16 15:04:16 --> Database Driver Class Initialized
INFO - 2016-12-16 15:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:04:16 --> Controller Class Initialized
DEBUG - 2016-12-16 15:04:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:04:16 --> Helper loaded: url_helper
INFO - 2016-12-16 15:04:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:04:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:04:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:04:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:04:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:04:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:04:16 --> Final output sent to browser
DEBUG - 2016-12-16 15:04:16 --> Total execution time: 0.0120
INFO - 2016-12-16 15:04:16 --> Config Class Initialized
INFO - 2016-12-16 15:04:16 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:04:16 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:04:16 --> Utf8 Class Initialized
INFO - 2016-12-16 15:04:16 --> URI Class Initialized
INFO - 2016-12-16 15:04:16 --> Router Class Initialized
INFO - 2016-12-16 15:04:16 --> Output Class Initialized
INFO - 2016-12-16 15:04:16 --> Security Class Initialized
DEBUG - 2016-12-16 15:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:04:16 --> Input Class Initialized
INFO - 2016-12-16 15:04:16 --> Language Class Initialized
ERROR - 2016-12-16 15:04:16 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:04:16 --> Config Class Initialized
INFO - 2016-12-16 15:04:16 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:04:16 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:04:16 --> Utf8 Class Initialized
INFO - 2016-12-16 15:04:16 --> URI Class Initialized
INFO - 2016-12-16 15:04:16 --> Router Class Initialized
INFO - 2016-12-16 15:04:16 --> Output Class Initialized
INFO - 2016-12-16 15:04:16 --> Security Class Initialized
DEBUG - 2016-12-16 15:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:04:16 --> Input Class Initialized
INFO - 2016-12-16 15:04:16 --> Language Class Initialized
INFO - 2016-12-16 15:04:16 --> Loader Class Initialized
INFO - 2016-12-16 15:04:16 --> Database Driver Class Initialized
INFO - 2016-12-16 15:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:04:16 --> Controller Class Initialized
INFO - 2016-12-16 15:04:16 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:04:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:04:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:04:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:04:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:04:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:04:16 --> Final output sent to browser
DEBUG - 2016-12-16 15:04:16 --> Total execution time: 0.0132
INFO - 2016-12-16 15:04:33 --> Config Class Initialized
INFO - 2016-12-16 15:04:33 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:04:33 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:04:33 --> Utf8 Class Initialized
INFO - 2016-12-16 15:04:33 --> URI Class Initialized
INFO - 2016-12-16 15:04:33 --> Router Class Initialized
INFO - 2016-12-16 15:04:33 --> Output Class Initialized
INFO - 2016-12-16 15:04:33 --> Security Class Initialized
DEBUG - 2016-12-16 15:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:04:33 --> Input Class Initialized
INFO - 2016-12-16 15:04:33 --> Language Class Initialized
INFO - 2016-12-16 15:04:33 --> Loader Class Initialized
INFO - 2016-12-16 15:04:33 --> Database Driver Class Initialized
INFO - 2016-12-16 15:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:04:33 --> Controller Class Initialized
INFO - 2016-12-16 15:04:33 --> Upload Class Initialized
DEBUG - 2016-12-16 15:04:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:04:33 --> Helper loaded: url_helper
INFO - 2016-12-16 15:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-16 15:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-16 15:04:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-16 15:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:04:33 --> Final output sent to browser
DEBUG - 2016-12-16 15:04:33 --> Total execution time: 0.0145
INFO - 2016-12-16 15:04:33 --> Config Class Initialized
INFO - 2016-12-16 15:04:33 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:04:33 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:04:33 --> Utf8 Class Initialized
INFO - 2016-12-16 15:04:33 --> URI Class Initialized
INFO - 2016-12-16 15:04:33 --> Router Class Initialized
INFO - 2016-12-16 15:04:33 --> Output Class Initialized
INFO - 2016-12-16 15:04:33 --> Security Class Initialized
DEBUG - 2016-12-16 15:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:04:33 --> Input Class Initialized
INFO - 2016-12-16 15:04:33 --> Language Class Initialized
ERROR - 2016-12-16 15:04:33 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:04:34 --> Config Class Initialized
INFO - 2016-12-16 15:04:34 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:04:34 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:04:34 --> Utf8 Class Initialized
INFO - 2016-12-16 15:04:34 --> URI Class Initialized
INFO - 2016-12-16 15:04:34 --> Router Class Initialized
INFO - 2016-12-16 15:04:34 --> Output Class Initialized
INFO - 2016-12-16 15:04:34 --> Security Class Initialized
DEBUG - 2016-12-16 15:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:04:34 --> Input Class Initialized
INFO - 2016-12-16 15:04:34 --> Language Class Initialized
INFO - 2016-12-16 15:04:34 --> Loader Class Initialized
INFO - 2016-12-16 15:04:34 --> Database Driver Class Initialized
INFO - 2016-12-16 15:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:04:34 --> Controller Class Initialized
INFO - 2016-12-16 15:04:34 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:04:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:04:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:04:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:04:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:04:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:04:34 --> Final output sent to browser
DEBUG - 2016-12-16 15:04:34 --> Total execution time: 0.0133
INFO - 2016-12-16 15:04:38 --> Config Class Initialized
INFO - 2016-12-16 15:04:38 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:04:38 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:04:38 --> Utf8 Class Initialized
INFO - 2016-12-16 15:04:38 --> URI Class Initialized
INFO - 2016-12-16 15:04:38 --> Router Class Initialized
INFO - 2016-12-16 15:04:38 --> Output Class Initialized
INFO - 2016-12-16 15:04:38 --> Security Class Initialized
DEBUG - 2016-12-16 15:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:04:38 --> Input Class Initialized
INFO - 2016-12-16 15:04:38 --> Language Class Initialized
INFO - 2016-12-16 15:04:38 --> Loader Class Initialized
INFO - 2016-12-16 15:04:38 --> Database Driver Class Initialized
INFO - 2016-12-16 15:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:04:38 --> Controller Class Initialized
INFO - 2016-12-16 15:04:38 --> Helper loaded: date_helper
DEBUG - 2016-12-16 15:04:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:04:38 --> Helper loaded: url_helper
INFO - 2016-12-16 15:04:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:04:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:04:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-16 15:04:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-16 15:04:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:04:38 --> Final output sent to browser
DEBUG - 2016-12-16 15:04:38 --> Total execution time: 0.0175
INFO - 2016-12-16 15:04:38 --> Config Class Initialized
INFO - 2016-12-16 15:04:38 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:04:38 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:04:38 --> Utf8 Class Initialized
INFO - 2016-12-16 15:04:38 --> URI Class Initialized
INFO - 2016-12-16 15:04:38 --> Router Class Initialized
INFO - 2016-12-16 15:04:38 --> Output Class Initialized
INFO - 2016-12-16 15:04:38 --> Security Class Initialized
DEBUG - 2016-12-16 15:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:04:38 --> Input Class Initialized
INFO - 2016-12-16 15:04:38 --> Language Class Initialized
ERROR - 2016-12-16 15:04:38 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:04:38 --> Config Class Initialized
INFO - 2016-12-16 15:04:38 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:04:38 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:04:38 --> Utf8 Class Initialized
INFO - 2016-12-16 15:04:38 --> URI Class Initialized
INFO - 2016-12-16 15:04:38 --> Router Class Initialized
INFO - 2016-12-16 15:04:38 --> Output Class Initialized
INFO - 2016-12-16 15:04:38 --> Security Class Initialized
DEBUG - 2016-12-16 15:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:04:38 --> Input Class Initialized
INFO - 2016-12-16 15:04:38 --> Language Class Initialized
INFO - 2016-12-16 15:04:38 --> Loader Class Initialized
INFO - 2016-12-16 15:04:38 --> Database Driver Class Initialized
INFO - 2016-12-16 15:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:04:38 --> Controller Class Initialized
INFO - 2016-12-16 15:04:38 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:04:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:04:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:04:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:04:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:04:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:04:38 --> Final output sent to browser
DEBUG - 2016-12-16 15:04:38 --> Total execution time: 0.0502
INFO - 2016-12-16 15:05:12 --> Config Class Initialized
INFO - 2016-12-16 15:05:12 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:05:12 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:05:12 --> Utf8 Class Initialized
INFO - 2016-12-16 15:05:12 --> URI Class Initialized
INFO - 2016-12-16 15:05:12 --> Router Class Initialized
INFO - 2016-12-16 15:05:12 --> Output Class Initialized
INFO - 2016-12-16 15:05:12 --> Security Class Initialized
DEBUG - 2016-12-16 15:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:05:12 --> Input Class Initialized
INFO - 2016-12-16 15:05:12 --> Language Class Initialized
INFO - 2016-12-16 15:05:12 --> Loader Class Initialized
INFO - 2016-12-16 15:05:12 --> Database Driver Class Initialized
INFO - 2016-12-16 15:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:05:12 --> Controller Class Initialized
DEBUG - 2016-12-16 15:05:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:05:12 --> Helper loaded: url_helper
INFO - 2016-12-16 15:05:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:05:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:05:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-16 15:05:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-16 15:05:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:05:12 --> Final output sent to browser
DEBUG - 2016-12-16 15:05:12 --> Total execution time: 0.0128
INFO - 2016-12-16 15:05:13 --> Config Class Initialized
INFO - 2016-12-16 15:05:13 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:05:13 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:05:13 --> Utf8 Class Initialized
INFO - 2016-12-16 15:05:13 --> URI Class Initialized
INFO - 2016-12-16 15:05:13 --> Router Class Initialized
INFO - 2016-12-16 15:05:13 --> Output Class Initialized
INFO - 2016-12-16 15:05:13 --> Security Class Initialized
DEBUG - 2016-12-16 15:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:05:13 --> Input Class Initialized
INFO - 2016-12-16 15:05:13 --> Language Class Initialized
ERROR - 2016-12-16 15:05:13 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:05:13 --> Config Class Initialized
INFO - 2016-12-16 15:05:13 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:05:13 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:05:13 --> Utf8 Class Initialized
INFO - 2016-12-16 15:05:13 --> URI Class Initialized
INFO - 2016-12-16 15:05:13 --> Router Class Initialized
INFO - 2016-12-16 15:05:13 --> Output Class Initialized
INFO - 2016-12-16 15:05:13 --> Security Class Initialized
DEBUG - 2016-12-16 15:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:05:13 --> Input Class Initialized
INFO - 2016-12-16 15:05:13 --> Language Class Initialized
INFO - 2016-12-16 15:05:13 --> Loader Class Initialized
INFO - 2016-12-16 15:05:13 --> Database Driver Class Initialized
INFO - 2016-12-16 15:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:05:13 --> Controller Class Initialized
INFO - 2016-12-16 15:05:13 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:05:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:05:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:05:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:05:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:05:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:05:13 --> Final output sent to browser
DEBUG - 2016-12-16 15:05:13 --> Total execution time: 0.0127
INFO - 2016-12-16 15:05:16 --> Config Class Initialized
INFO - 2016-12-16 15:05:16 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:05:16 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:05:16 --> Utf8 Class Initialized
INFO - 2016-12-16 15:05:16 --> URI Class Initialized
INFO - 2016-12-16 15:05:16 --> Router Class Initialized
INFO - 2016-12-16 15:05:16 --> Output Class Initialized
INFO - 2016-12-16 15:05:16 --> Security Class Initialized
DEBUG - 2016-12-16 15:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:05:16 --> Input Class Initialized
INFO - 2016-12-16 15:05:16 --> Language Class Initialized
INFO - 2016-12-16 15:05:16 --> Loader Class Initialized
INFO - 2016-12-16 15:05:16 --> Database Driver Class Initialized
INFO - 2016-12-16 15:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:05:16 --> Controller Class Initialized
DEBUG - 2016-12-16 15:05:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:05:16 --> Helper loaded: url_helper
INFO - 2016-12-16 15:05:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:05:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:05:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:05:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:05:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:05:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:05:16 --> Final output sent to browser
DEBUG - 2016-12-16 15:05:16 --> Total execution time: 0.0135
INFO - 2016-12-16 15:05:17 --> Config Class Initialized
INFO - 2016-12-16 15:05:17 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:05:17 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:05:17 --> Utf8 Class Initialized
INFO - 2016-12-16 15:05:17 --> URI Class Initialized
INFO - 2016-12-16 15:05:17 --> Router Class Initialized
INFO - 2016-12-16 15:05:17 --> Output Class Initialized
INFO - 2016-12-16 15:05:17 --> Security Class Initialized
DEBUG - 2016-12-16 15:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:05:17 --> Input Class Initialized
INFO - 2016-12-16 15:05:17 --> Language Class Initialized
ERROR - 2016-12-16 15:05:17 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:05:17 --> Config Class Initialized
INFO - 2016-12-16 15:05:17 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:05:17 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:05:17 --> Utf8 Class Initialized
INFO - 2016-12-16 15:05:17 --> URI Class Initialized
INFO - 2016-12-16 15:05:17 --> Router Class Initialized
INFO - 2016-12-16 15:05:17 --> Output Class Initialized
INFO - 2016-12-16 15:05:17 --> Security Class Initialized
DEBUG - 2016-12-16 15:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:05:17 --> Input Class Initialized
INFO - 2016-12-16 15:05:17 --> Language Class Initialized
INFO - 2016-12-16 15:05:17 --> Loader Class Initialized
INFO - 2016-12-16 15:05:17 --> Database Driver Class Initialized
INFO - 2016-12-16 15:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:05:17 --> Controller Class Initialized
INFO - 2016-12-16 15:05:17 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:05:17 --> Final output sent to browser
DEBUG - 2016-12-16 15:05:17 --> Total execution time: 0.0148
INFO - 2016-12-16 15:05:27 --> Config Class Initialized
INFO - 2016-12-16 15:05:27 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:05:27 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:05:27 --> Utf8 Class Initialized
INFO - 2016-12-16 15:05:27 --> URI Class Initialized
INFO - 2016-12-16 15:05:27 --> Router Class Initialized
INFO - 2016-12-16 15:05:27 --> Output Class Initialized
INFO - 2016-12-16 15:05:27 --> Security Class Initialized
DEBUG - 2016-12-16 15:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:05:27 --> Input Class Initialized
INFO - 2016-12-16 15:05:27 --> Language Class Initialized
INFO - 2016-12-16 15:05:27 --> Loader Class Initialized
INFO - 2016-12-16 15:05:27 --> Database Driver Class Initialized
INFO - 2016-12-16 15:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:05:27 --> Controller Class Initialized
DEBUG - 2016-12-16 15:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:05:27 --> Helper loaded: url_helper
INFO - 2016-12-16 15:05:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:05:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:05:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:05:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:05:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:05:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:05:27 --> Final output sent to browser
DEBUG - 2016-12-16 15:05:27 --> Total execution time: 0.0124
INFO - 2016-12-16 15:05:27 --> Config Class Initialized
INFO - 2016-12-16 15:05:27 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:05:27 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:05:27 --> Utf8 Class Initialized
INFO - 2016-12-16 15:05:27 --> URI Class Initialized
INFO - 2016-12-16 15:05:27 --> Router Class Initialized
INFO - 2016-12-16 15:05:27 --> Output Class Initialized
INFO - 2016-12-16 15:05:27 --> Security Class Initialized
DEBUG - 2016-12-16 15:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:05:27 --> Input Class Initialized
INFO - 2016-12-16 15:05:27 --> Language Class Initialized
ERROR - 2016-12-16 15:05:27 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:05:27 --> Config Class Initialized
INFO - 2016-12-16 15:05:27 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:05:27 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:05:27 --> Utf8 Class Initialized
INFO - 2016-12-16 15:05:27 --> URI Class Initialized
INFO - 2016-12-16 15:05:27 --> Router Class Initialized
INFO - 2016-12-16 15:05:27 --> Output Class Initialized
INFO - 2016-12-16 15:05:27 --> Security Class Initialized
DEBUG - 2016-12-16 15:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:05:27 --> Input Class Initialized
INFO - 2016-12-16 15:05:27 --> Language Class Initialized
INFO - 2016-12-16 15:05:27 --> Loader Class Initialized
INFO - 2016-12-16 15:05:27 --> Database Driver Class Initialized
INFO - 2016-12-16 15:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:05:27 --> Controller Class Initialized
INFO - 2016-12-16 15:05:27 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:05:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:05:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:05:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:05:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:05:27 --> Final output sent to browser
DEBUG - 2016-12-16 15:05:27 --> Total execution time: 0.0136
INFO - 2016-12-16 15:06:27 --> Config Class Initialized
INFO - 2016-12-16 15:06:27 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:06:27 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:06:27 --> Utf8 Class Initialized
INFO - 2016-12-16 15:06:27 --> URI Class Initialized
INFO - 2016-12-16 15:06:27 --> Router Class Initialized
INFO - 2016-12-16 15:06:27 --> Output Class Initialized
INFO - 2016-12-16 15:06:27 --> Security Class Initialized
DEBUG - 2016-12-16 15:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:06:27 --> Input Class Initialized
INFO - 2016-12-16 15:06:27 --> Language Class Initialized
INFO - 2016-12-16 15:06:27 --> Loader Class Initialized
INFO - 2016-12-16 15:06:27 --> Database Driver Class Initialized
INFO - 2016-12-16 15:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:06:27 --> Controller Class Initialized
DEBUG - 2016-12-16 15:06:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:06:27 --> Helper loaded: url_helper
INFO - 2016-12-16 15:06:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:06:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:06:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:06:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:06:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:06:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:06:27 --> Final output sent to browser
DEBUG - 2016-12-16 15:06:27 --> Total execution time: 0.0561
INFO - 2016-12-16 15:06:27 --> Config Class Initialized
INFO - 2016-12-16 15:06:27 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:06:27 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:06:27 --> Utf8 Class Initialized
INFO - 2016-12-16 15:06:27 --> URI Class Initialized
INFO - 2016-12-16 15:06:27 --> Router Class Initialized
INFO - 2016-12-16 15:06:27 --> Output Class Initialized
INFO - 2016-12-16 15:06:27 --> Security Class Initialized
DEBUG - 2016-12-16 15:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:06:27 --> Input Class Initialized
INFO - 2016-12-16 15:06:27 --> Language Class Initialized
ERROR - 2016-12-16 15:06:27 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:06:27 --> Config Class Initialized
INFO - 2016-12-16 15:06:27 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:06:27 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:06:27 --> Utf8 Class Initialized
INFO - 2016-12-16 15:06:27 --> URI Class Initialized
INFO - 2016-12-16 15:06:27 --> Router Class Initialized
INFO - 2016-12-16 15:06:27 --> Output Class Initialized
INFO - 2016-12-16 15:06:27 --> Security Class Initialized
DEBUG - 2016-12-16 15:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:06:27 --> Input Class Initialized
INFO - 2016-12-16 15:06:27 --> Language Class Initialized
INFO - 2016-12-16 15:06:27 --> Loader Class Initialized
INFO - 2016-12-16 15:06:27 --> Database Driver Class Initialized
INFO - 2016-12-16 15:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:06:27 --> Controller Class Initialized
INFO - 2016-12-16 15:06:27 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:06:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:06:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:06:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:06:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:06:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:06:27 --> Final output sent to browser
DEBUG - 2016-12-16 15:06:27 --> Total execution time: 0.0681
INFO - 2016-12-16 15:06:44 --> Config Class Initialized
INFO - 2016-12-16 15:06:44 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:06:44 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:06:44 --> Utf8 Class Initialized
INFO - 2016-12-16 15:06:44 --> URI Class Initialized
INFO - 2016-12-16 15:06:44 --> Router Class Initialized
INFO - 2016-12-16 15:06:44 --> Output Class Initialized
INFO - 2016-12-16 15:06:44 --> Security Class Initialized
DEBUG - 2016-12-16 15:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:06:44 --> Input Class Initialized
INFO - 2016-12-16 15:06:44 --> Language Class Initialized
INFO - 2016-12-16 15:06:44 --> Loader Class Initialized
INFO - 2016-12-16 15:06:44 --> Database Driver Class Initialized
INFO - 2016-12-16 15:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:06:44 --> Controller Class Initialized
DEBUG - 2016-12-16 15:06:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:06:44 --> Helper loaded: url_helper
INFO - 2016-12-16 15:06:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:06:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:06:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:06:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:06:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:06:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:06:44 --> Final output sent to browser
DEBUG - 2016-12-16 15:06:44 --> Total execution time: 0.0119
INFO - 2016-12-16 15:06:44 --> Config Class Initialized
INFO - 2016-12-16 15:06:44 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:06:44 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:06:44 --> Utf8 Class Initialized
INFO - 2016-12-16 15:06:44 --> URI Class Initialized
INFO - 2016-12-16 15:06:44 --> Router Class Initialized
INFO - 2016-12-16 15:06:44 --> Output Class Initialized
INFO - 2016-12-16 15:06:44 --> Security Class Initialized
DEBUG - 2016-12-16 15:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:06:44 --> Input Class Initialized
INFO - 2016-12-16 15:06:44 --> Language Class Initialized
ERROR - 2016-12-16 15:06:44 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:06:44 --> Config Class Initialized
INFO - 2016-12-16 15:06:44 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:06:44 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:06:44 --> Utf8 Class Initialized
INFO - 2016-12-16 15:06:44 --> URI Class Initialized
INFO - 2016-12-16 15:06:44 --> Router Class Initialized
INFO - 2016-12-16 15:06:44 --> Output Class Initialized
INFO - 2016-12-16 15:06:44 --> Security Class Initialized
DEBUG - 2016-12-16 15:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:06:44 --> Input Class Initialized
INFO - 2016-12-16 15:06:44 --> Language Class Initialized
INFO - 2016-12-16 15:06:44 --> Loader Class Initialized
INFO - 2016-12-16 15:06:44 --> Database Driver Class Initialized
INFO - 2016-12-16 15:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:06:44 --> Controller Class Initialized
INFO - 2016-12-16 15:06:44 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:06:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:06:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:06:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:06:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:06:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:06:44 --> Final output sent to browser
DEBUG - 2016-12-16 15:06:44 --> Total execution time: 0.0131
INFO - 2016-12-16 15:07:19 --> Config Class Initialized
INFO - 2016-12-16 15:07:19 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:07:19 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:07:19 --> Utf8 Class Initialized
INFO - 2016-12-16 15:07:19 --> URI Class Initialized
INFO - 2016-12-16 15:07:19 --> Router Class Initialized
INFO - 2016-12-16 15:07:19 --> Output Class Initialized
INFO - 2016-12-16 15:07:19 --> Security Class Initialized
DEBUG - 2016-12-16 15:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:07:19 --> Input Class Initialized
INFO - 2016-12-16 15:07:19 --> Language Class Initialized
INFO - 2016-12-16 15:07:19 --> Loader Class Initialized
INFO - 2016-12-16 15:07:19 --> Database Driver Class Initialized
INFO - 2016-12-16 15:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:07:19 --> Controller Class Initialized
DEBUG - 2016-12-16 15:07:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:07:19 --> Helper loaded: url_helper
INFO - 2016-12-16 15:07:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:07:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:07:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:07:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:07:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:07:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:07:19 --> Final output sent to browser
DEBUG - 2016-12-16 15:07:19 --> Total execution time: 0.0121
INFO - 2016-12-16 15:07:20 --> Config Class Initialized
INFO - 2016-12-16 15:07:20 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:07:20 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:07:20 --> Utf8 Class Initialized
INFO - 2016-12-16 15:07:20 --> URI Class Initialized
INFO - 2016-12-16 15:07:20 --> Router Class Initialized
INFO - 2016-12-16 15:07:20 --> Output Class Initialized
INFO - 2016-12-16 15:07:20 --> Security Class Initialized
DEBUG - 2016-12-16 15:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:07:20 --> Input Class Initialized
INFO - 2016-12-16 15:07:20 --> Language Class Initialized
ERROR - 2016-12-16 15:07:20 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:07:20 --> Config Class Initialized
INFO - 2016-12-16 15:07:20 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:07:20 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:07:20 --> Utf8 Class Initialized
INFO - 2016-12-16 15:07:20 --> URI Class Initialized
INFO - 2016-12-16 15:07:20 --> Router Class Initialized
INFO - 2016-12-16 15:07:20 --> Output Class Initialized
INFO - 2016-12-16 15:07:20 --> Security Class Initialized
DEBUG - 2016-12-16 15:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:07:20 --> Input Class Initialized
INFO - 2016-12-16 15:07:20 --> Language Class Initialized
INFO - 2016-12-16 15:07:20 --> Loader Class Initialized
INFO - 2016-12-16 15:07:20 --> Database Driver Class Initialized
INFO - 2016-12-16 15:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:07:20 --> Controller Class Initialized
INFO - 2016-12-16 15:07:20 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:07:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:07:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:07:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:07:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:07:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:07:20 --> Final output sent to browser
DEBUG - 2016-12-16 15:07:20 --> Total execution time: 0.0768
INFO - 2016-12-16 15:08:55 --> Config Class Initialized
INFO - 2016-12-16 15:08:55 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:08:55 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:08:55 --> Utf8 Class Initialized
INFO - 2016-12-16 15:08:55 --> URI Class Initialized
DEBUG - 2016-12-16 15:08:55 --> No URI present. Default controller set.
INFO - 2016-12-16 15:08:55 --> Router Class Initialized
INFO - 2016-12-16 15:08:55 --> Output Class Initialized
INFO - 2016-12-16 15:08:55 --> Security Class Initialized
DEBUG - 2016-12-16 15:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:08:55 --> Input Class Initialized
INFO - 2016-12-16 15:08:55 --> Language Class Initialized
INFO - 2016-12-16 15:08:55 --> Loader Class Initialized
INFO - 2016-12-16 15:08:55 --> Database Driver Class Initialized
INFO - 2016-12-16 15:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:08:55 --> Controller Class Initialized
INFO - 2016-12-16 15:08:55 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:08:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:08:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:08:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:08:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:08:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:08:55 --> Final output sent to browser
DEBUG - 2016-12-16 15:08:55 --> Total execution time: 0.0136
INFO - 2016-12-16 15:08:59 --> Config Class Initialized
INFO - 2016-12-16 15:08:59 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:08:59 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:08:59 --> Utf8 Class Initialized
INFO - 2016-12-16 15:08:59 --> URI Class Initialized
INFO - 2016-12-16 15:08:59 --> Router Class Initialized
INFO - 2016-12-16 15:08:59 --> Output Class Initialized
INFO - 2016-12-16 15:08:59 --> Security Class Initialized
DEBUG - 2016-12-16 15:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:08:59 --> Input Class Initialized
INFO - 2016-12-16 15:08:59 --> Language Class Initialized
INFO - 2016-12-16 15:08:59 --> Loader Class Initialized
INFO - 2016-12-16 15:08:59 --> Database Driver Class Initialized
INFO - 2016-12-16 15:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:08:59 --> Controller Class Initialized
INFO - 2016-12-16 15:08:59 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:08:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:08:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:08:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:08:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:08:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:08:59 --> Final output sent to browser
DEBUG - 2016-12-16 15:08:59 --> Total execution time: 0.0131
INFO - 2016-12-16 15:09:28 --> Config Class Initialized
INFO - 2016-12-16 15:09:28 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:09:28 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:09:28 --> Utf8 Class Initialized
INFO - 2016-12-16 15:09:28 --> URI Class Initialized
DEBUG - 2016-12-16 15:09:28 --> No URI present. Default controller set.
INFO - 2016-12-16 15:09:28 --> Router Class Initialized
INFO - 2016-12-16 15:09:28 --> Output Class Initialized
INFO - 2016-12-16 15:09:28 --> Security Class Initialized
DEBUG - 2016-12-16 15:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:09:28 --> Input Class Initialized
INFO - 2016-12-16 15:09:28 --> Language Class Initialized
INFO - 2016-12-16 15:09:28 --> Loader Class Initialized
INFO - 2016-12-16 15:09:28 --> Database Driver Class Initialized
INFO - 2016-12-16 15:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:09:28 --> Controller Class Initialized
INFO - 2016-12-16 15:09:28 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:09:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:09:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:09:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:09:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:09:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:09:28 --> Final output sent to browser
DEBUG - 2016-12-16 15:09:28 --> Total execution time: 0.0129
INFO - 2016-12-16 15:09:30 --> Config Class Initialized
INFO - 2016-12-16 15:09:30 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:09:30 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:09:30 --> Utf8 Class Initialized
INFO - 2016-12-16 15:09:30 --> URI Class Initialized
INFO - 2016-12-16 15:09:30 --> Router Class Initialized
INFO - 2016-12-16 15:09:30 --> Output Class Initialized
INFO - 2016-12-16 15:09:30 --> Security Class Initialized
DEBUG - 2016-12-16 15:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:09:30 --> Input Class Initialized
INFO - 2016-12-16 15:09:30 --> Language Class Initialized
INFO - 2016-12-16 15:09:30 --> Loader Class Initialized
INFO - 2016-12-16 15:09:30 --> Database Driver Class Initialized
INFO - 2016-12-16 15:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:09:30 --> Controller Class Initialized
INFO - 2016-12-16 15:09:30 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:09:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:09:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:09:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:09:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:09:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:09:30 --> Final output sent to browser
DEBUG - 2016-12-16 15:09:30 --> Total execution time: 0.0137
INFO - 2016-12-16 15:09:44 --> Config Class Initialized
INFO - 2016-12-16 15:09:44 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:09:44 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:09:44 --> Utf8 Class Initialized
INFO - 2016-12-16 15:09:44 --> URI Class Initialized
INFO - 2016-12-16 15:09:44 --> Router Class Initialized
INFO - 2016-12-16 15:09:44 --> Output Class Initialized
INFO - 2016-12-16 15:09:44 --> Security Class Initialized
DEBUG - 2016-12-16 15:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:09:44 --> Input Class Initialized
INFO - 2016-12-16 15:09:44 --> Language Class Initialized
INFO - 2016-12-16 15:09:44 --> Loader Class Initialized
INFO - 2016-12-16 15:09:44 --> Database Driver Class Initialized
INFO - 2016-12-16 15:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:09:44 --> Controller Class Initialized
INFO - 2016-12-16 15:09:44 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:09:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:09:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:09:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:09:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:09:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:09:44 --> Final output sent to browser
DEBUG - 2016-12-16 15:09:44 --> Total execution time: 0.0404
INFO - 2016-12-16 15:09:46 --> Config Class Initialized
INFO - 2016-12-16 15:09:46 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:09:46 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:09:46 --> Utf8 Class Initialized
INFO - 2016-12-16 15:09:46 --> URI Class Initialized
INFO - 2016-12-16 15:09:46 --> Router Class Initialized
INFO - 2016-12-16 15:09:46 --> Output Class Initialized
INFO - 2016-12-16 15:09:46 --> Security Class Initialized
DEBUG - 2016-12-16 15:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:09:46 --> Input Class Initialized
INFO - 2016-12-16 15:09:46 --> Language Class Initialized
INFO - 2016-12-16 15:09:46 --> Loader Class Initialized
INFO - 2016-12-16 15:09:46 --> Database Driver Class Initialized
INFO - 2016-12-16 15:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:09:46 --> Controller Class Initialized
INFO - 2016-12-16 15:09:46 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:09:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:09:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:09:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:09:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:09:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:09:46 --> Final output sent to browser
DEBUG - 2016-12-16 15:09:46 --> Total execution time: 0.0130
INFO - 2016-12-16 15:09:48 --> Config Class Initialized
INFO - 2016-12-16 15:09:48 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:09:48 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:09:48 --> Utf8 Class Initialized
INFO - 2016-12-16 15:09:48 --> URI Class Initialized
INFO - 2016-12-16 15:09:48 --> Router Class Initialized
INFO - 2016-12-16 15:09:48 --> Output Class Initialized
INFO - 2016-12-16 15:09:48 --> Security Class Initialized
DEBUG - 2016-12-16 15:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:09:48 --> Input Class Initialized
INFO - 2016-12-16 15:09:48 --> Language Class Initialized
INFO - 2016-12-16 15:09:48 --> Loader Class Initialized
INFO - 2016-12-16 15:09:48 --> Database Driver Class Initialized
INFO - 2016-12-16 15:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:09:48 --> Controller Class Initialized
INFO - 2016-12-16 15:09:48 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:09:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:09:49 --> Config Class Initialized
INFO - 2016-12-16 15:09:49 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:09:49 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:09:49 --> Utf8 Class Initialized
INFO - 2016-12-16 15:09:49 --> URI Class Initialized
INFO - 2016-12-16 15:09:49 --> Router Class Initialized
INFO - 2016-12-16 15:09:49 --> Output Class Initialized
INFO - 2016-12-16 15:09:49 --> Security Class Initialized
DEBUG - 2016-12-16 15:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:09:49 --> Input Class Initialized
INFO - 2016-12-16 15:09:49 --> Language Class Initialized
INFO - 2016-12-16 15:09:49 --> Loader Class Initialized
INFO - 2016-12-16 15:09:49 --> Database Driver Class Initialized
INFO - 2016-12-16 15:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:09:49 --> Controller Class Initialized
DEBUG - 2016-12-16 15:09:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:09:49 --> Helper loaded: url_helper
INFO - 2016-12-16 15:09:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:09:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:09:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-16 15:09:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-16 15:09:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:09:49 --> Final output sent to browser
DEBUG - 2016-12-16 15:09:49 --> Total execution time: 0.0140
INFO - 2016-12-16 15:09:51 --> Config Class Initialized
INFO - 2016-12-16 15:09:51 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:09:51 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:09:51 --> Utf8 Class Initialized
INFO - 2016-12-16 15:09:51 --> URI Class Initialized
INFO - 2016-12-16 15:09:51 --> Router Class Initialized
INFO - 2016-12-16 15:09:51 --> Output Class Initialized
INFO - 2016-12-16 15:09:51 --> Security Class Initialized
DEBUG - 2016-12-16 15:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:09:51 --> Input Class Initialized
INFO - 2016-12-16 15:09:51 --> Language Class Initialized
INFO - 2016-12-16 15:09:51 --> Loader Class Initialized
INFO - 2016-12-16 15:09:51 --> Database Driver Class Initialized
INFO - 2016-12-16 15:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:09:51 --> Controller Class Initialized
INFO - 2016-12-16 15:09:51 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:09:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:09:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:09:51 --> Final output sent to browser
DEBUG - 2016-12-16 15:09:51 --> Total execution time: 0.0151
INFO - 2016-12-16 15:10:10 --> Config Class Initialized
INFO - 2016-12-16 15:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:10:10 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:10:10 --> Utf8 Class Initialized
INFO - 2016-12-16 15:10:10 --> URI Class Initialized
INFO - 2016-12-16 15:10:10 --> Router Class Initialized
INFO - 2016-12-16 15:10:10 --> Output Class Initialized
INFO - 2016-12-16 15:10:10 --> Security Class Initialized
DEBUG - 2016-12-16 15:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:10:10 --> Input Class Initialized
INFO - 2016-12-16 15:10:10 --> Language Class Initialized
INFO - 2016-12-16 15:10:10 --> Loader Class Initialized
INFO - 2016-12-16 15:10:10 --> Database Driver Class Initialized
INFO - 2016-12-16 15:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:10:10 --> Controller Class Initialized
DEBUG - 2016-12-16 15:10:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:10:10 --> Helper loaded: url_helper
INFO - 2016-12-16 15:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:10:10 --> Final output sent to browser
DEBUG - 2016-12-16 15:10:10 --> Total execution time: 0.0121
INFO - 2016-12-16 15:10:10 --> Config Class Initialized
INFO - 2016-12-16 15:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:10:10 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:10:10 --> Utf8 Class Initialized
INFO - 2016-12-16 15:10:10 --> URI Class Initialized
INFO - 2016-12-16 15:10:10 --> Router Class Initialized
INFO - 2016-12-16 15:10:10 --> Output Class Initialized
INFO - 2016-12-16 15:10:10 --> Security Class Initialized
DEBUG - 2016-12-16 15:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:10:10 --> Input Class Initialized
INFO - 2016-12-16 15:10:10 --> Language Class Initialized
INFO - 2016-12-16 15:10:10 --> Loader Class Initialized
INFO - 2016-12-16 15:10:10 --> Database Driver Class Initialized
INFO - 2016-12-16 15:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:10:10 --> Controller Class Initialized
DEBUG - 2016-12-16 15:10:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:10:10 --> Helper loaded: url_helper
INFO - 2016-12-16 15:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:10:10 --> Final output sent to browser
DEBUG - 2016-12-16 15:10:10 --> Total execution time: 0.0423
INFO - 2016-12-16 15:10:12 --> Config Class Initialized
INFO - 2016-12-16 15:10:12 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:10:12 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:10:12 --> Utf8 Class Initialized
INFO - 2016-12-16 15:10:12 --> URI Class Initialized
INFO - 2016-12-16 15:10:12 --> Router Class Initialized
INFO - 2016-12-16 15:10:12 --> Output Class Initialized
INFO - 2016-12-16 15:10:12 --> Security Class Initialized
DEBUG - 2016-12-16 15:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:10:12 --> Input Class Initialized
INFO - 2016-12-16 15:10:12 --> Language Class Initialized
INFO - 2016-12-16 15:10:12 --> Loader Class Initialized
INFO - 2016-12-16 15:10:12 --> Database Driver Class Initialized
INFO - 2016-12-16 15:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:10:12 --> Controller Class Initialized
INFO - 2016-12-16 15:10:12 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:10:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:10:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:10:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:10:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:10:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:10:12 --> Final output sent to browser
DEBUG - 2016-12-16 15:10:12 --> Total execution time: 0.0141
INFO - 2016-12-16 15:10:51 --> Config Class Initialized
INFO - 2016-12-16 15:10:51 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:10:51 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:10:51 --> Utf8 Class Initialized
INFO - 2016-12-16 15:10:51 --> URI Class Initialized
INFO - 2016-12-16 15:10:51 --> Router Class Initialized
INFO - 2016-12-16 15:10:51 --> Output Class Initialized
INFO - 2016-12-16 15:10:51 --> Security Class Initialized
DEBUG - 2016-12-16 15:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:10:51 --> Input Class Initialized
INFO - 2016-12-16 15:10:51 --> Language Class Initialized
INFO - 2016-12-16 15:10:51 --> Loader Class Initialized
INFO - 2016-12-16 15:10:51 --> Database Driver Class Initialized
INFO - 2016-12-16 15:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:10:51 --> Controller Class Initialized
DEBUG - 2016-12-16 15:10:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:10:51 --> Helper loaded: url_helper
INFO - 2016-12-16 15:10:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:10:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:10:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-16 15:10:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-16 15:10:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:10:51 --> Final output sent to browser
DEBUG - 2016-12-16 15:10:51 --> Total execution time: 0.0142
INFO - 2016-12-16 15:10:51 --> Config Class Initialized
INFO - 2016-12-16 15:10:51 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:10:51 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:10:51 --> Utf8 Class Initialized
INFO - 2016-12-16 15:10:51 --> URI Class Initialized
INFO - 2016-12-16 15:10:51 --> Router Class Initialized
INFO - 2016-12-16 15:10:51 --> Output Class Initialized
INFO - 2016-12-16 15:10:51 --> Security Class Initialized
DEBUG - 2016-12-16 15:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:10:51 --> Input Class Initialized
INFO - 2016-12-16 15:10:51 --> Language Class Initialized
INFO - 2016-12-16 15:10:51 --> Loader Class Initialized
INFO - 2016-12-16 15:10:51 --> Database Driver Class Initialized
INFO - 2016-12-16 15:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:10:51 --> Controller Class Initialized
INFO - 2016-12-16 15:10:51 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:10:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:10:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:10:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:10:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:10:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:10:51 --> Final output sent to browser
DEBUG - 2016-12-16 15:10:51 --> Total execution time: 0.0139
INFO - 2016-12-16 15:10:53 --> Config Class Initialized
INFO - 2016-12-16 15:10:53 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:10:53 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:10:53 --> Utf8 Class Initialized
INFO - 2016-12-16 15:10:53 --> URI Class Initialized
INFO - 2016-12-16 15:10:53 --> Router Class Initialized
INFO - 2016-12-16 15:10:53 --> Output Class Initialized
INFO - 2016-12-16 15:10:53 --> Security Class Initialized
DEBUG - 2016-12-16 15:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:10:53 --> Input Class Initialized
INFO - 2016-12-16 15:10:53 --> Language Class Initialized
INFO - 2016-12-16 15:10:53 --> Loader Class Initialized
INFO - 2016-12-16 15:10:53 --> Database Driver Class Initialized
INFO - 2016-12-16 15:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:10:53 --> Controller Class Initialized
INFO - 2016-12-16 15:10:53 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:10:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:10:53 --> Config Class Initialized
INFO - 2016-12-16 15:10:53 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:10:53 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:10:53 --> Utf8 Class Initialized
INFO - 2016-12-16 15:10:53 --> URI Class Initialized
INFO - 2016-12-16 15:10:53 --> Router Class Initialized
INFO - 2016-12-16 15:10:53 --> Output Class Initialized
INFO - 2016-12-16 15:10:53 --> Security Class Initialized
DEBUG - 2016-12-16 15:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:10:53 --> Input Class Initialized
INFO - 2016-12-16 15:10:53 --> Language Class Initialized
INFO - 2016-12-16 15:10:53 --> Loader Class Initialized
INFO - 2016-12-16 15:10:53 --> Database Driver Class Initialized
INFO - 2016-12-16 15:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:10:53 --> Controller Class Initialized
DEBUG - 2016-12-16 15:10:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:10:53 --> Helper loaded: url_helper
INFO - 2016-12-16 15:10:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:10:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:10:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-16 15:10:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-16 15:10:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:10:53 --> Final output sent to browser
DEBUG - 2016-12-16 15:10:53 --> Total execution time: 0.0133
INFO - 2016-12-16 15:10:54 --> Config Class Initialized
INFO - 2016-12-16 15:10:54 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:10:54 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:10:54 --> Utf8 Class Initialized
INFO - 2016-12-16 15:10:54 --> URI Class Initialized
INFO - 2016-12-16 15:10:54 --> Router Class Initialized
INFO - 2016-12-16 15:10:54 --> Output Class Initialized
INFO - 2016-12-16 15:10:54 --> Security Class Initialized
DEBUG - 2016-12-16 15:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:10:54 --> Input Class Initialized
INFO - 2016-12-16 15:10:54 --> Language Class Initialized
INFO - 2016-12-16 15:10:54 --> Loader Class Initialized
INFO - 2016-12-16 15:10:54 --> Database Driver Class Initialized
INFO - 2016-12-16 15:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:10:54 --> Controller Class Initialized
INFO - 2016-12-16 15:10:54 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:10:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:10:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:10:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:10:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:10:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:10:54 --> Final output sent to browser
DEBUG - 2016-12-16 15:10:54 --> Total execution time: 0.0136
INFO - 2016-12-16 15:11:06 --> Config Class Initialized
INFO - 2016-12-16 15:11:06 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:11:06 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:11:06 --> Utf8 Class Initialized
INFO - 2016-12-16 15:11:06 --> URI Class Initialized
INFO - 2016-12-16 15:11:06 --> Router Class Initialized
INFO - 2016-12-16 15:11:07 --> Output Class Initialized
INFO - 2016-12-16 15:11:07 --> Security Class Initialized
DEBUG - 2016-12-16 15:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:11:07 --> Input Class Initialized
INFO - 2016-12-16 15:11:07 --> Language Class Initialized
INFO - 2016-12-16 15:11:07 --> Loader Class Initialized
INFO - 2016-12-16 15:11:07 --> Database Driver Class Initialized
INFO - 2016-12-16 15:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:11:07 --> Controller Class Initialized
INFO - 2016-12-16 15:11:07 --> Upload Class Initialized
DEBUG - 2016-12-16 15:11:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:11:07 --> Helper loaded: url_helper
INFO - 2016-12-16 15:11:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:11:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:11:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-16 15:11:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-16 15:11:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-16 15:11:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:11:07 --> Final output sent to browser
DEBUG - 2016-12-16 15:11:07 --> Total execution time: 0.0157
INFO - 2016-12-16 15:11:08 --> Config Class Initialized
INFO - 2016-12-16 15:11:08 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:11:08 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:11:08 --> Utf8 Class Initialized
INFO - 2016-12-16 15:11:08 --> URI Class Initialized
INFO - 2016-12-16 15:11:08 --> Router Class Initialized
INFO - 2016-12-16 15:11:08 --> Output Class Initialized
INFO - 2016-12-16 15:11:08 --> Security Class Initialized
DEBUG - 2016-12-16 15:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:11:08 --> Input Class Initialized
INFO - 2016-12-16 15:11:08 --> Language Class Initialized
INFO - 2016-12-16 15:11:08 --> Loader Class Initialized
INFO - 2016-12-16 15:11:08 --> Database Driver Class Initialized
INFO - 2016-12-16 15:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:11:08 --> Controller Class Initialized
INFO - 2016-12-16 15:11:08 --> Upload Class Initialized
DEBUG - 2016-12-16 15:11:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:11:08 --> Helper loaded: url_helper
INFO - 2016-12-16 15:11:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:11:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:11:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-16 15:11:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-16 15:11:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-16 15:11:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:11:08 --> Final output sent to browser
DEBUG - 2016-12-16 15:11:08 --> Total execution time: 0.0148
INFO - 2016-12-16 15:11:08 --> Config Class Initialized
INFO - 2016-12-16 15:11:08 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:11:08 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:11:08 --> Utf8 Class Initialized
INFO - 2016-12-16 15:11:08 --> URI Class Initialized
INFO - 2016-12-16 15:11:08 --> Router Class Initialized
INFO - 2016-12-16 15:11:08 --> Output Class Initialized
INFO - 2016-12-16 15:11:08 --> Security Class Initialized
DEBUG - 2016-12-16 15:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:11:08 --> Input Class Initialized
INFO - 2016-12-16 15:11:08 --> Language Class Initialized
INFO - 2016-12-16 15:11:08 --> Loader Class Initialized
INFO - 2016-12-16 15:11:08 --> Database Driver Class Initialized
INFO - 2016-12-16 15:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:11:08 --> Controller Class Initialized
INFO - 2016-12-16 15:11:08 --> Upload Class Initialized
DEBUG - 2016-12-16 15:11:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:11:08 --> Helper loaded: url_helper
INFO - 2016-12-16 15:11:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:11:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:11:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-16 15:11:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2016-12-16 15:11:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2016-12-16 15:11:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:11:08 --> Final output sent to browser
DEBUG - 2016-12-16 15:11:08 --> Total execution time: 0.0146
INFO - 2016-12-16 15:11:11 --> Config Class Initialized
INFO - 2016-12-16 15:11:11 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:11:11 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:11:11 --> Utf8 Class Initialized
INFO - 2016-12-16 15:11:11 --> URI Class Initialized
INFO - 2016-12-16 15:11:11 --> Router Class Initialized
INFO - 2016-12-16 15:11:11 --> Output Class Initialized
INFO - 2016-12-16 15:11:11 --> Security Class Initialized
DEBUG - 2016-12-16 15:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:11:11 --> Input Class Initialized
INFO - 2016-12-16 15:11:11 --> Language Class Initialized
INFO - 2016-12-16 15:11:11 --> Loader Class Initialized
INFO - 2016-12-16 15:11:11 --> Database Driver Class Initialized
INFO - 2016-12-16 15:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:11:11 --> Controller Class Initialized
INFO - 2016-12-16 15:11:11 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:11:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:11:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:11:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:11:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:11:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:11:11 --> Final output sent to browser
DEBUG - 2016-12-16 15:11:11 --> Total execution time: 0.0132
INFO - 2016-12-16 15:13:05 --> Config Class Initialized
INFO - 2016-12-16 15:13:05 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:13:05 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:13:05 --> Utf8 Class Initialized
INFO - 2016-12-16 15:13:05 --> URI Class Initialized
INFO - 2016-12-16 15:13:05 --> Router Class Initialized
INFO - 2016-12-16 15:13:05 --> Output Class Initialized
INFO - 2016-12-16 15:13:05 --> Security Class Initialized
DEBUG - 2016-12-16 15:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:13:05 --> Input Class Initialized
INFO - 2016-12-16 15:13:05 --> Language Class Initialized
INFO - 2016-12-16 15:13:05 --> Loader Class Initialized
INFO - 2016-12-16 15:13:05 --> Database Driver Class Initialized
INFO - 2016-12-16 15:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:13:05 --> Controller Class Initialized
DEBUG - 2016-12-16 15:13:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:13:05 --> Helper loaded: url_helper
INFO - 2016-12-16 15:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:13:05 --> Final output sent to browser
DEBUG - 2016-12-16 15:13:05 --> Total execution time: 0.0130
INFO - 2016-12-16 15:13:06 --> Config Class Initialized
INFO - 2016-12-16 15:13:06 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:13:06 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:13:06 --> Utf8 Class Initialized
INFO - 2016-12-16 15:13:06 --> URI Class Initialized
INFO - 2016-12-16 15:13:06 --> Router Class Initialized
INFO - 2016-12-16 15:13:06 --> Output Class Initialized
INFO - 2016-12-16 15:13:06 --> Security Class Initialized
DEBUG - 2016-12-16 15:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:13:06 --> Input Class Initialized
INFO - 2016-12-16 15:13:06 --> Language Class Initialized
INFO - 2016-12-16 15:13:06 --> Loader Class Initialized
INFO - 2016-12-16 15:13:06 --> Database Driver Class Initialized
INFO - 2016-12-16 15:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:13:06 --> Controller Class Initialized
INFO - 2016-12-16 15:13:06 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:13:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:13:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:13:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:13:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:13:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:13:06 --> Final output sent to browser
DEBUG - 2016-12-16 15:13:06 --> Total execution time: 0.0141
INFO - 2016-12-16 15:13:08 --> Config Class Initialized
INFO - 2016-12-16 15:13:08 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:13:08 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:13:08 --> Utf8 Class Initialized
INFO - 2016-12-16 15:13:08 --> URI Class Initialized
INFO - 2016-12-16 15:13:08 --> Router Class Initialized
INFO - 2016-12-16 15:13:08 --> Output Class Initialized
INFO - 2016-12-16 15:13:08 --> Security Class Initialized
DEBUG - 2016-12-16 15:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:13:08 --> Input Class Initialized
INFO - 2016-12-16 15:13:08 --> Language Class Initialized
INFO - 2016-12-16 15:13:08 --> Loader Class Initialized
INFO - 2016-12-16 15:13:08 --> Database Driver Class Initialized
INFO - 2016-12-16 15:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:13:08 --> Controller Class Initialized
DEBUG - 2016-12-16 15:13:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:13:08 --> Helper loaded: url_helper
INFO - 2016-12-16 15:13:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:13:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:13:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:13:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:13:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:13:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:13:08 --> Final output sent to browser
DEBUG - 2016-12-16 15:13:08 --> Total execution time: 0.0125
INFO - 2016-12-16 15:13:08 --> Config Class Initialized
INFO - 2016-12-16 15:13:08 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:13:08 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:13:08 --> Utf8 Class Initialized
INFO - 2016-12-16 15:13:08 --> URI Class Initialized
INFO - 2016-12-16 15:13:08 --> Router Class Initialized
INFO - 2016-12-16 15:13:08 --> Output Class Initialized
INFO - 2016-12-16 15:13:08 --> Security Class Initialized
DEBUG - 2016-12-16 15:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:13:08 --> Input Class Initialized
INFO - 2016-12-16 15:13:08 --> Language Class Initialized
INFO - 2016-12-16 15:13:08 --> Loader Class Initialized
INFO - 2016-12-16 15:13:08 --> Database Driver Class Initialized
INFO - 2016-12-16 15:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:13:08 --> Controller Class Initialized
INFO - 2016-12-16 15:13:08 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:13:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:13:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:13:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:13:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:13:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:13:08 --> Final output sent to browser
DEBUG - 2016-12-16 15:13:08 --> Total execution time: 0.0133
INFO - 2016-12-16 15:14:34 --> Config Class Initialized
INFO - 2016-12-16 15:14:34 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:14:34 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:14:34 --> Utf8 Class Initialized
INFO - 2016-12-16 15:14:34 --> URI Class Initialized
INFO - 2016-12-16 15:14:34 --> Router Class Initialized
INFO - 2016-12-16 15:14:34 --> Output Class Initialized
INFO - 2016-12-16 15:14:34 --> Security Class Initialized
DEBUG - 2016-12-16 15:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:14:34 --> Input Class Initialized
INFO - 2016-12-16 15:14:34 --> Language Class Initialized
INFO - 2016-12-16 15:14:34 --> Loader Class Initialized
INFO - 2016-12-16 15:14:34 --> Database Driver Class Initialized
INFO - 2016-12-16 15:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:14:34 --> Controller Class Initialized
DEBUG - 2016-12-16 15:14:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:14:34 --> Helper loaded: url_helper
INFO - 2016-12-16 15:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:14:34 --> Final output sent to browser
DEBUG - 2016-12-16 15:14:34 --> Total execution time: 0.0122
INFO - 2016-12-16 15:14:34 --> Config Class Initialized
INFO - 2016-12-16 15:14:34 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:14:34 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:14:34 --> Utf8 Class Initialized
INFO - 2016-12-16 15:14:34 --> URI Class Initialized
INFO - 2016-12-16 15:14:34 --> Router Class Initialized
INFO - 2016-12-16 15:14:34 --> Output Class Initialized
INFO - 2016-12-16 15:14:34 --> Security Class Initialized
DEBUG - 2016-12-16 15:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:14:34 --> Input Class Initialized
INFO - 2016-12-16 15:14:34 --> Language Class Initialized
INFO - 2016-12-16 15:14:34 --> Loader Class Initialized
INFO - 2016-12-16 15:14:34 --> Database Driver Class Initialized
INFO - 2016-12-16 15:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:14:34 --> Controller Class Initialized
INFO - 2016-12-16 15:14:34 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:14:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:14:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:14:34 --> Final output sent to browser
DEBUG - 2016-12-16 15:14:34 --> Total execution time: 0.0855
INFO - 2016-12-16 15:14:37 --> Config Class Initialized
INFO - 2016-12-16 15:14:37 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:14:37 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:14:37 --> Utf8 Class Initialized
INFO - 2016-12-16 15:14:37 --> URI Class Initialized
INFO - 2016-12-16 15:14:37 --> Router Class Initialized
INFO - 2016-12-16 15:14:37 --> Output Class Initialized
INFO - 2016-12-16 15:14:37 --> Security Class Initialized
DEBUG - 2016-12-16 15:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:14:37 --> Input Class Initialized
INFO - 2016-12-16 15:14:37 --> Language Class Initialized
INFO - 2016-12-16 15:14:37 --> Loader Class Initialized
INFO - 2016-12-16 15:14:37 --> Database Driver Class Initialized
INFO - 2016-12-16 15:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:14:37 --> Controller Class Initialized
DEBUG - 2016-12-16 15:14:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:14:37 --> Helper loaded: url_helper
INFO - 2016-12-16 15:14:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:14:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:14:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:14:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:14:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:14:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:14:37 --> Final output sent to browser
DEBUG - 2016-12-16 15:14:37 --> Total execution time: 0.0126
INFO - 2016-12-16 15:14:37 --> Config Class Initialized
INFO - 2016-12-16 15:14:37 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:14:37 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:14:37 --> Utf8 Class Initialized
INFO - 2016-12-16 15:14:37 --> URI Class Initialized
INFO - 2016-12-16 15:14:37 --> Router Class Initialized
INFO - 2016-12-16 15:14:37 --> Output Class Initialized
INFO - 2016-12-16 15:14:37 --> Security Class Initialized
DEBUG - 2016-12-16 15:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:14:37 --> Input Class Initialized
INFO - 2016-12-16 15:14:37 --> Language Class Initialized
INFO - 2016-12-16 15:14:37 --> Loader Class Initialized
INFO - 2016-12-16 15:14:37 --> Database Driver Class Initialized
INFO - 2016-12-16 15:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:14:37 --> Controller Class Initialized
INFO - 2016-12-16 15:14:37 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:14:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:14:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:14:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:14:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:14:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:14:37 --> Final output sent to browser
DEBUG - 2016-12-16 15:14:37 --> Total execution time: 0.0781
INFO - 2016-12-16 15:14:38 --> Config Class Initialized
INFO - 2016-12-16 15:14:38 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:14:38 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:14:38 --> Utf8 Class Initialized
INFO - 2016-12-16 15:14:38 --> URI Class Initialized
INFO - 2016-12-16 15:14:38 --> Router Class Initialized
INFO - 2016-12-16 15:14:38 --> Output Class Initialized
INFO - 2016-12-16 15:14:38 --> Security Class Initialized
DEBUG - 2016-12-16 15:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:14:38 --> Input Class Initialized
INFO - 2016-12-16 15:14:38 --> Language Class Initialized
INFO - 2016-12-16 15:14:38 --> Loader Class Initialized
INFO - 2016-12-16 15:14:38 --> Database Driver Class Initialized
INFO - 2016-12-16 15:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:14:38 --> Controller Class Initialized
DEBUG - 2016-12-16 15:14:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:14:38 --> Helper loaded: url_helper
INFO - 2016-12-16 15:14:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:14:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:14:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:14:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:14:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:14:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:14:38 --> Final output sent to browser
DEBUG - 2016-12-16 15:14:38 --> Total execution time: 0.0117
INFO - 2016-12-16 15:14:38 --> Config Class Initialized
INFO - 2016-12-16 15:14:38 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:14:38 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:14:38 --> Utf8 Class Initialized
INFO - 2016-12-16 15:14:38 --> URI Class Initialized
INFO - 2016-12-16 15:14:38 --> Router Class Initialized
INFO - 2016-12-16 15:14:38 --> Output Class Initialized
INFO - 2016-12-16 15:14:38 --> Security Class Initialized
DEBUG - 2016-12-16 15:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:14:38 --> Input Class Initialized
INFO - 2016-12-16 15:14:38 --> Language Class Initialized
INFO - 2016-12-16 15:14:38 --> Loader Class Initialized
INFO - 2016-12-16 15:14:38 --> Database Driver Class Initialized
INFO - 2016-12-16 15:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:14:38 --> Controller Class Initialized
INFO - 2016-12-16 15:14:38 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:14:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:14:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:14:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:14:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:14:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:14:38 --> Final output sent to browser
DEBUG - 2016-12-16 15:14:38 --> Total execution time: 0.0141
INFO - 2016-12-16 15:14:39 --> Config Class Initialized
INFO - 2016-12-16 15:14:39 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:14:39 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:14:39 --> Utf8 Class Initialized
INFO - 2016-12-16 15:14:39 --> URI Class Initialized
INFO - 2016-12-16 15:14:39 --> Router Class Initialized
INFO - 2016-12-16 15:14:39 --> Output Class Initialized
INFO - 2016-12-16 15:14:39 --> Security Class Initialized
DEBUG - 2016-12-16 15:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:14:39 --> Input Class Initialized
INFO - 2016-12-16 15:14:39 --> Language Class Initialized
INFO - 2016-12-16 15:14:39 --> Loader Class Initialized
INFO - 2016-12-16 15:14:39 --> Database Driver Class Initialized
INFO - 2016-12-16 15:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:14:39 --> Controller Class Initialized
DEBUG - 2016-12-16 15:14:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:14:39 --> Helper loaded: url_helper
INFO - 2016-12-16 15:14:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:14:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:14:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:14:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:14:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:14:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:14:39 --> Final output sent to browser
DEBUG - 2016-12-16 15:14:39 --> Total execution time: 0.0127
INFO - 2016-12-16 15:14:39 --> Config Class Initialized
INFO - 2016-12-16 15:14:39 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:14:39 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:14:39 --> Utf8 Class Initialized
INFO - 2016-12-16 15:14:39 --> URI Class Initialized
INFO - 2016-12-16 15:14:39 --> Router Class Initialized
INFO - 2016-12-16 15:14:39 --> Output Class Initialized
INFO - 2016-12-16 15:14:39 --> Security Class Initialized
DEBUG - 2016-12-16 15:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:14:39 --> Input Class Initialized
INFO - 2016-12-16 15:14:39 --> Language Class Initialized
INFO - 2016-12-16 15:14:39 --> Loader Class Initialized
INFO - 2016-12-16 15:14:39 --> Database Driver Class Initialized
INFO - 2016-12-16 15:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:14:39 --> Controller Class Initialized
INFO - 2016-12-16 15:14:39 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:14:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:14:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:14:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:14:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:14:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:14:39 --> Final output sent to browser
DEBUG - 2016-12-16 15:14:39 --> Total execution time: 0.0137
INFO - 2016-12-16 15:14:40 --> Config Class Initialized
INFO - 2016-12-16 15:14:40 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:14:40 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:14:40 --> Utf8 Class Initialized
INFO - 2016-12-16 15:14:40 --> URI Class Initialized
INFO - 2016-12-16 15:14:40 --> Router Class Initialized
INFO - 2016-12-16 15:14:40 --> Output Class Initialized
INFO - 2016-12-16 15:14:40 --> Security Class Initialized
DEBUG - 2016-12-16 15:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:14:40 --> Input Class Initialized
INFO - 2016-12-16 15:14:40 --> Language Class Initialized
INFO - 2016-12-16 15:14:40 --> Loader Class Initialized
INFO - 2016-12-16 15:14:40 --> Database Driver Class Initialized
INFO - 2016-12-16 15:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:14:40 --> Controller Class Initialized
DEBUG - 2016-12-16 15:14:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:14:40 --> Helper loaded: url_helper
INFO - 2016-12-16 15:14:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:14:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:14:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:14:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:14:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:14:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:14:40 --> Final output sent to browser
DEBUG - 2016-12-16 15:14:40 --> Total execution time: 0.0125
INFO - 2016-12-16 15:14:40 --> Config Class Initialized
INFO - 2016-12-16 15:14:40 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:14:40 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:14:40 --> Utf8 Class Initialized
INFO - 2016-12-16 15:14:40 --> URI Class Initialized
INFO - 2016-12-16 15:14:40 --> Router Class Initialized
INFO - 2016-12-16 15:14:40 --> Output Class Initialized
INFO - 2016-12-16 15:14:40 --> Security Class Initialized
DEBUG - 2016-12-16 15:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:14:40 --> Input Class Initialized
INFO - 2016-12-16 15:14:40 --> Language Class Initialized
INFO - 2016-12-16 15:14:40 --> Loader Class Initialized
INFO - 2016-12-16 15:14:40 --> Database Driver Class Initialized
INFO - 2016-12-16 15:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:14:40 --> Controller Class Initialized
INFO - 2016-12-16 15:14:40 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:14:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:14:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:14:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:14:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:14:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:14:40 --> Final output sent to browser
DEBUG - 2016-12-16 15:14:40 --> Total execution time: 0.0141
INFO - 2016-12-16 15:14:49 --> Config Class Initialized
INFO - 2016-12-16 15:14:49 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:14:49 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:14:49 --> Utf8 Class Initialized
INFO - 2016-12-16 15:14:49 --> URI Class Initialized
INFO - 2016-12-16 15:14:49 --> Router Class Initialized
INFO - 2016-12-16 15:14:49 --> Output Class Initialized
INFO - 2016-12-16 15:14:49 --> Security Class Initialized
DEBUG - 2016-12-16 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:14:49 --> Input Class Initialized
INFO - 2016-12-16 15:14:49 --> Language Class Initialized
ERROR - 2016-12-16 15:14:49 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:15:52 --> Config Class Initialized
INFO - 2016-12-16 15:15:52 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:15:52 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:15:52 --> Utf8 Class Initialized
INFO - 2016-12-16 15:15:52 --> URI Class Initialized
INFO - 2016-12-16 15:15:52 --> Router Class Initialized
INFO - 2016-12-16 15:15:52 --> Output Class Initialized
INFO - 2016-12-16 15:15:52 --> Security Class Initialized
DEBUG - 2016-12-16 15:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:15:52 --> Input Class Initialized
INFO - 2016-12-16 15:15:52 --> Language Class Initialized
INFO - 2016-12-16 15:15:52 --> Loader Class Initialized
INFO - 2016-12-16 15:15:52 --> Database Driver Class Initialized
INFO - 2016-12-16 15:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:15:52 --> Controller Class Initialized
DEBUG - 2016-12-16 15:15:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:15:52 --> Helper loaded: url_helper
INFO - 2016-12-16 15:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-16 15:15:52 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php 46
INFO - 2016-12-16 15:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:15:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:15:52 --> Final output sent to browser
DEBUG - 2016-12-16 15:15:52 --> Total execution time: 0.0252
INFO - 2016-12-16 15:15:53 --> Config Class Initialized
INFO - 2016-12-16 15:15:53 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:15:53 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:15:53 --> Utf8 Class Initialized
INFO - 2016-12-16 15:15:53 --> URI Class Initialized
INFO - 2016-12-16 15:15:53 --> Router Class Initialized
INFO - 2016-12-16 15:15:53 --> Output Class Initialized
INFO - 2016-12-16 15:15:53 --> Security Class Initialized
DEBUG - 2016-12-16 15:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:15:53 --> Input Class Initialized
INFO - 2016-12-16 15:15:53 --> Language Class Initialized
ERROR - 2016-12-16 15:15:53 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:15:53 --> Config Class Initialized
INFO - 2016-12-16 15:15:53 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:15:53 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:15:53 --> Utf8 Class Initialized
INFO - 2016-12-16 15:15:53 --> URI Class Initialized
INFO - 2016-12-16 15:15:53 --> Router Class Initialized
INFO - 2016-12-16 15:15:53 --> Output Class Initialized
INFO - 2016-12-16 15:15:53 --> Security Class Initialized
DEBUG - 2016-12-16 15:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:15:53 --> Input Class Initialized
INFO - 2016-12-16 15:15:53 --> Language Class Initialized
INFO - 2016-12-16 15:15:53 --> Loader Class Initialized
INFO - 2016-12-16 15:15:53 --> Database Driver Class Initialized
INFO - 2016-12-16 15:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:15:53 --> Controller Class Initialized
INFO - 2016-12-16 15:15:53 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:15:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:15:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:15:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:15:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:15:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:15:53 --> Final output sent to browser
DEBUG - 2016-12-16 15:15:53 --> Total execution time: 0.0142
INFO - 2016-12-16 15:17:02 --> Config Class Initialized
INFO - 2016-12-16 15:17:02 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:17:02 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:17:02 --> Utf8 Class Initialized
INFO - 2016-12-16 15:17:02 --> URI Class Initialized
INFO - 2016-12-16 15:17:02 --> Router Class Initialized
INFO - 2016-12-16 15:17:02 --> Output Class Initialized
INFO - 2016-12-16 15:17:02 --> Security Class Initialized
DEBUG - 2016-12-16 15:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:17:02 --> Input Class Initialized
INFO - 2016-12-16 15:17:02 --> Language Class Initialized
INFO - 2016-12-16 15:17:02 --> Loader Class Initialized
INFO - 2016-12-16 15:17:02 --> Database Driver Class Initialized
INFO - 2016-12-16 15:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:17:02 --> Controller Class Initialized
DEBUG - 2016-12-16 15:17:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:17:02 --> Helper loaded: url_helper
INFO - 2016-12-16 15:17:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:17:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:17:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:17:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:17:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:17:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:17:02 --> Final output sent to browser
DEBUG - 2016-12-16 15:17:02 --> Total execution time: 0.0121
INFO - 2016-12-16 15:17:03 --> Config Class Initialized
INFO - 2016-12-16 15:17:03 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:17:03 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:17:03 --> Utf8 Class Initialized
INFO - 2016-12-16 15:17:03 --> URI Class Initialized
INFO - 2016-12-16 15:17:03 --> Router Class Initialized
INFO - 2016-12-16 15:17:03 --> Output Class Initialized
INFO - 2016-12-16 15:17:03 --> Security Class Initialized
DEBUG - 2016-12-16 15:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:17:03 --> Input Class Initialized
INFO - 2016-12-16 15:17:03 --> Language Class Initialized
ERROR - 2016-12-16 15:17:03 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:17:03 --> Config Class Initialized
INFO - 2016-12-16 15:17:03 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:17:03 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:17:03 --> Utf8 Class Initialized
INFO - 2016-12-16 15:17:03 --> URI Class Initialized
INFO - 2016-12-16 15:17:03 --> Router Class Initialized
INFO - 2016-12-16 15:17:03 --> Output Class Initialized
INFO - 2016-12-16 15:17:03 --> Security Class Initialized
DEBUG - 2016-12-16 15:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:17:03 --> Input Class Initialized
INFO - 2016-12-16 15:17:03 --> Language Class Initialized
INFO - 2016-12-16 15:17:03 --> Loader Class Initialized
INFO - 2016-12-16 15:17:03 --> Database Driver Class Initialized
INFO - 2016-12-16 15:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:17:03 --> Controller Class Initialized
INFO - 2016-12-16 15:17:03 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:17:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:17:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:17:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:17:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:17:03 --> Final output sent to browser
DEBUG - 2016-12-16 15:17:03 --> Total execution time: 0.0132
INFO - 2016-12-16 15:17:56 --> Config Class Initialized
INFO - 2016-12-16 15:17:56 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:17:56 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:17:56 --> Utf8 Class Initialized
INFO - 2016-12-16 15:17:56 --> URI Class Initialized
INFO - 2016-12-16 15:17:56 --> Router Class Initialized
INFO - 2016-12-16 15:17:56 --> Output Class Initialized
INFO - 2016-12-16 15:17:56 --> Security Class Initialized
DEBUG - 2016-12-16 15:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:17:56 --> Input Class Initialized
INFO - 2016-12-16 15:17:56 --> Language Class Initialized
INFO - 2016-12-16 15:17:56 --> Loader Class Initialized
INFO - 2016-12-16 15:17:56 --> Database Driver Class Initialized
INFO - 2016-12-16 15:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:17:56 --> Controller Class Initialized
DEBUG - 2016-12-16 15:17:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:17:56 --> Helper loaded: url_helper
INFO - 2016-12-16 15:17:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:17:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:17:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:17:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:17:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:17:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:17:56 --> Final output sent to browser
DEBUG - 2016-12-16 15:17:56 --> Total execution time: 0.0128
INFO - 2016-12-16 15:17:56 --> Config Class Initialized
INFO - 2016-12-16 15:17:56 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:17:56 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:17:56 --> Utf8 Class Initialized
INFO - 2016-12-16 15:17:56 --> URI Class Initialized
INFO - 2016-12-16 15:17:56 --> Router Class Initialized
INFO - 2016-12-16 15:17:56 --> Output Class Initialized
INFO - 2016-12-16 15:17:56 --> Security Class Initialized
DEBUG - 2016-12-16 15:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:17:56 --> Input Class Initialized
INFO - 2016-12-16 15:17:56 --> Language Class Initialized
ERROR - 2016-12-16 15:17:56 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:17:56 --> Config Class Initialized
INFO - 2016-12-16 15:17:56 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:17:56 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:17:56 --> Utf8 Class Initialized
INFO - 2016-12-16 15:17:56 --> URI Class Initialized
INFO - 2016-12-16 15:17:56 --> Router Class Initialized
INFO - 2016-12-16 15:17:56 --> Output Class Initialized
INFO - 2016-12-16 15:17:56 --> Security Class Initialized
DEBUG - 2016-12-16 15:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:17:56 --> Input Class Initialized
INFO - 2016-12-16 15:17:56 --> Language Class Initialized
INFO - 2016-12-16 15:17:56 --> Loader Class Initialized
INFO - 2016-12-16 15:17:56 --> Database Driver Class Initialized
INFO - 2016-12-16 15:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:17:56 --> Controller Class Initialized
INFO - 2016-12-16 15:17:56 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:17:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:17:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:17:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:17:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:17:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:17:56 --> Final output sent to browser
DEBUG - 2016-12-16 15:17:56 --> Total execution time: 0.0136
INFO - 2016-12-16 15:18:17 --> Config Class Initialized
INFO - 2016-12-16 15:18:17 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:18:17 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:18:17 --> Utf8 Class Initialized
INFO - 2016-12-16 15:18:17 --> URI Class Initialized
INFO - 2016-12-16 15:18:17 --> Router Class Initialized
INFO - 2016-12-16 15:18:17 --> Output Class Initialized
INFO - 2016-12-16 15:18:17 --> Security Class Initialized
DEBUG - 2016-12-16 15:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:18:17 --> Input Class Initialized
INFO - 2016-12-16 15:18:17 --> Language Class Initialized
INFO - 2016-12-16 15:18:17 --> Loader Class Initialized
INFO - 2016-12-16 15:18:17 --> Database Driver Class Initialized
INFO - 2016-12-16 15:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:18:17 --> Controller Class Initialized
DEBUG - 2016-12-16 15:18:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:18:17 --> Helper loaded: url_helper
INFO - 2016-12-16 15:18:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:18:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:18:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:18:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:18:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:18:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:18:17 --> Final output sent to browser
DEBUG - 2016-12-16 15:18:17 --> Total execution time: 0.0171
INFO - 2016-12-16 15:18:17 --> Config Class Initialized
INFO - 2016-12-16 15:18:17 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:18:17 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:18:17 --> Utf8 Class Initialized
INFO - 2016-12-16 15:18:17 --> URI Class Initialized
INFO - 2016-12-16 15:18:17 --> Router Class Initialized
INFO - 2016-12-16 15:18:17 --> Output Class Initialized
INFO - 2016-12-16 15:18:17 --> Security Class Initialized
DEBUG - 2016-12-16 15:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:18:17 --> Input Class Initialized
INFO - 2016-12-16 15:18:17 --> Language Class Initialized
ERROR - 2016-12-16 15:18:17 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:18:17 --> Config Class Initialized
INFO - 2016-12-16 15:18:17 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:18:17 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:18:17 --> Utf8 Class Initialized
INFO - 2016-12-16 15:18:17 --> URI Class Initialized
INFO - 2016-12-16 15:18:17 --> Router Class Initialized
INFO - 2016-12-16 15:18:17 --> Output Class Initialized
INFO - 2016-12-16 15:18:17 --> Security Class Initialized
DEBUG - 2016-12-16 15:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:18:17 --> Input Class Initialized
INFO - 2016-12-16 15:18:17 --> Language Class Initialized
INFO - 2016-12-16 15:18:17 --> Loader Class Initialized
INFO - 2016-12-16 15:18:17 --> Database Driver Class Initialized
INFO - 2016-12-16 15:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:18:17 --> Controller Class Initialized
INFO - 2016-12-16 15:18:17 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:18:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:18:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:18:18 --> Final output sent to browser
DEBUG - 2016-12-16 15:18:18 --> Total execution time: 0.0135
INFO - 2016-12-16 15:19:00 --> Config Class Initialized
INFO - 2016-12-16 15:19:00 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:19:00 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:19:00 --> Utf8 Class Initialized
INFO - 2016-12-16 15:19:00 --> URI Class Initialized
INFO - 2016-12-16 15:19:00 --> Router Class Initialized
INFO - 2016-12-16 15:19:00 --> Output Class Initialized
INFO - 2016-12-16 15:19:00 --> Security Class Initialized
DEBUG - 2016-12-16 15:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:19:00 --> Input Class Initialized
INFO - 2016-12-16 15:19:00 --> Language Class Initialized
INFO - 2016-12-16 15:19:00 --> Loader Class Initialized
INFO - 2016-12-16 15:19:00 --> Database Driver Class Initialized
INFO - 2016-12-16 15:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:19:00 --> Controller Class Initialized
DEBUG - 2016-12-16 15:19:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:19:00 --> Helper loaded: url_helper
INFO - 2016-12-16 15:19:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:19:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:19:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:19:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:19:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:19:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:19:00 --> Final output sent to browser
DEBUG - 2016-12-16 15:19:00 --> Total execution time: 0.0120
INFO - 2016-12-16 15:19:01 --> Config Class Initialized
INFO - 2016-12-16 15:19:01 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:19:01 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:19:01 --> Utf8 Class Initialized
INFO - 2016-12-16 15:19:01 --> URI Class Initialized
INFO - 2016-12-16 15:19:01 --> Router Class Initialized
INFO - 2016-12-16 15:19:01 --> Output Class Initialized
INFO - 2016-12-16 15:19:01 --> Security Class Initialized
DEBUG - 2016-12-16 15:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:19:01 --> Input Class Initialized
INFO - 2016-12-16 15:19:01 --> Language Class Initialized
ERROR - 2016-12-16 15:19:01 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:19:01 --> Config Class Initialized
INFO - 2016-12-16 15:19:01 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:19:01 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:19:01 --> Utf8 Class Initialized
INFO - 2016-12-16 15:19:01 --> URI Class Initialized
INFO - 2016-12-16 15:19:01 --> Router Class Initialized
INFO - 2016-12-16 15:19:01 --> Output Class Initialized
INFO - 2016-12-16 15:19:01 --> Security Class Initialized
DEBUG - 2016-12-16 15:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:19:01 --> Input Class Initialized
INFO - 2016-12-16 15:19:01 --> Language Class Initialized
INFO - 2016-12-16 15:19:01 --> Loader Class Initialized
INFO - 2016-12-16 15:19:01 --> Database Driver Class Initialized
INFO - 2016-12-16 15:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:19:01 --> Controller Class Initialized
INFO - 2016-12-16 15:19:01 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:19:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:19:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:19:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:19:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:19:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:19:01 --> Final output sent to browser
DEBUG - 2016-12-16 15:19:01 --> Total execution time: 0.0138
INFO - 2016-12-16 15:19:02 --> Config Class Initialized
INFO - 2016-12-16 15:19:02 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:19:02 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:19:02 --> Utf8 Class Initialized
INFO - 2016-12-16 15:19:02 --> URI Class Initialized
INFO - 2016-12-16 15:19:02 --> Router Class Initialized
INFO - 2016-12-16 15:19:02 --> Output Class Initialized
INFO - 2016-12-16 15:19:02 --> Security Class Initialized
DEBUG - 2016-12-16 15:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:19:02 --> Input Class Initialized
INFO - 2016-12-16 15:19:02 --> Language Class Initialized
INFO - 2016-12-16 15:19:02 --> Loader Class Initialized
INFO - 2016-12-16 15:19:02 --> Database Driver Class Initialized
INFO - 2016-12-16 15:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:19:02 --> Controller Class Initialized
DEBUG - 2016-12-16 15:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:19:02 --> Helper loaded: url_helper
INFO - 2016-12-16 15:19:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:19:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:19:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:19:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:19:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:19:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:19:02 --> Final output sent to browser
DEBUG - 2016-12-16 15:19:02 --> Total execution time: 0.0120
INFO - 2016-12-16 15:19:02 --> Config Class Initialized
INFO - 2016-12-16 15:19:02 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:19:02 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:19:02 --> Utf8 Class Initialized
INFO - 2016-12-16 15:19:02 --> URI Class Initialized
INFO - 2016-12-16 15:19:02 --> Router Class Initialized
INFO - 2016-12-16 15:19:02 --> Output Class Initialized
INFO - 2016-12-16 15:19:02 --> Security Class Initialized
DEBUG - 2016-12-16 15:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:19:02 --> Input Class Initialized
INFO - 2016-12-16 15:19:02 --> Language Class Initialized
ERROR - 2016-12-16 15:19:02 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:19:02 --> Config Class Initialized
INFO - 2016-12-16 15:19:02 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:19:02 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:19:02 --> Utf8 Class Initialized
INFO - 2016-12-16 15:19:02 --> URI Class Initialized
INFO - 2016-12-16 15:19:02 --> Router Class Initialized
INFO - 2016-12-16 15:19:02 --> Output Class Initialized
INFO - 2016-12-16 15:19:02 --> Security Class Initialized
DEBUG - 2016-12-16 15:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:19:02 --> Input Class Initialized
INFO - 2016-12-16 15:19:02 --> Language Class Initialized
INFO - 2016-12-16 15:19:02 --> Loader Class Initialized
INFO - 2016-12-16 15:19:02 --> Database Driver Class Initialized
INFO - 2016-12-16 15:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:19:02 --> Controller Class Initialized
INFO - 2016-12-16 15:19:02 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:19:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:19:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:19:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:19:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:19:02 --> Final output sent to browser
DEBUG - 2016-12-16 15:19:02 --> Total execution time: 0.0132
INFO - 2016-12-16 15:19:03 --> Config Class Initialized
INFO - 2016-12-16 15:19:03 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:19:03 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:19:03 --> Utf8 Class Initialized
INFO - 2016-12-16 15:19:03 --> URI Class Initialized
INFO - 2016-12-16 15:19:03 --> Router Class Initialized
INFO - 2016-12-16 15:19:03 --> Output Class Initialized
INFO - 2016-12-16 15:19:03 --> Security Class Initialized
DEBUG - 2016-12-16 15:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:19:03 --> Input Class Initialized
INFO - 2016-12-16 15:19:03 --> Language Class Initialized
INFO - 2016-12-16 15:19:03 --> Loader Class Initialized
INFO - 2016-12-16 15:19:03 --> Database Driver Class Initialized
INFO - 2016-12-16 15:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:19:03 --> Controller Class Initialized
DEBUG - 2016-12-16 15:19:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:19:03 --> Helper loaded: url_helper
INFO - 2016-12-16 15:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:19:03 --> Final output sent to browser
DEBUG - 2016-12-16 15:19:03 --> Total execution time: 0.0119
INFO - 2016-12-16 15:19:03 --> Config Class Initialized
INFO - 2016-12-16 15:19:03 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:19:03 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:19:03 --> Utf8 Class Initialized
INFO - 2016-12-16 15:19:03 --> URI Class Initialized
INFO - 2016-12-16 15:19:03 --> Router Class Initialized
INFO - 2016-12-16 15:19:03 --> Output Class Initialized
INFO - 2016-12-16 15:19:03 --> Security Class Initialized
DEBUG - 2016-12-16 15:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:19:03 --> Input Class Initialized
INFO - 2016-12-16 15:19:03 --> Language Class Initialized
ERROR - 2016-12-16 15:19:03 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:19:03 --> Config Class Initialized
INFO - 2016-12-16 15:19:03 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:19:03 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:19:03 --> Utf8 Class Initialized
INFO - 2016-12-16 15:19:03 --> URI Class Initialized
INFO - 2016-12-16 15:19:03 --> Router Class Initialized
INFO - 2016-12-16 15:19:03 --> Output Class Initialized
INFO - 2016-12-16 15:19:03 --> Security Class Initialized
DEBUG - 2016-12-16 15:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:19:03 --> Input Class Initialized
INFO - 2016-12-16 15:19:03 --> Language Class Initialized
INFO - 2016-12-16 15:19:03 --> Loader Class Initialized
INFO - 2016-12-16 15:19:03 --> Database Driver Class Initialized
INFO - 2016-12-16 15:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:19:03 --> Controller Class Initialized
INFO - 2016-12-16 15:19:03 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:19:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:19:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:19:03 --> Final output sent to browser
DEBUG - 2016-12-16 15:19:03 --> Total execution time: 0.0125
INFO - 2016-12-16 15:19:07 --> Config Class Initialized
INFO - 2016-12-16 15:19:07 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:19:07 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:19:07 --> Utf8 Class Initialized
INFO - 2016-12-16 15:19:07 --> URI Class Initialized
INFO - 2016-12-16 15:19:07 --> Router Class Initialized
INFO - 2016-12-16 15:19:07 --> Output Class Initialized
INFO - 2016-12-16 15:19:07 --> Security Class Initialized
DEBUG - 2016-12-16 15:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:19:07 --> Input Class Initialized
INFO - 2016-12-16 15:19:07 --> Language Class Initialized
INFO - 2016-12-16 15:19:07 --> Loader Class Initialized
INFO - 2016-12-16 15:19:07 --> Database Driver Class Initialized
INFO - 2016-12-16 15:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:19:07 --> Controller Class Initialized
DEBUG - 2016-12-16 15:19:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:19:07 --> Helper loaded: url_helper
INFO - 2016-12-16 15:19:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:19:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:19:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:19:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:19:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:19:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:19:07 --> Final output sent to browser
DEBUG - 2016-12-16 15:19:07 --> Total execution time: 0.0117
INFO - 2016-12-16 15:19:07 --> Config Class Initialized
INFO - 2016-12-16 15:19:07 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:19:07 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:19:07 --> Utf8 Class Initialized
INFO - 2016-12-16 15:19:07 --> URI Class Initialized
INFO - 2016-12-16 15:19:07 --> Router Class Initialized
INFO - 2016-12-16 15:19:07 --> Output Class Initialized
INFO - 2016-12-16 15:19:07 --> Security Class Initialized
DEBUG - 2016-12-16 15:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:19:07 --> Input Class Initialized
INFO - 2016-12-16 15:19:07 --> Language Class Initialized
ERROR - 2016-12-16 15:19:07 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:19:07 --> Config Class Initialized
INFO - 2016-12-16 15:19:07 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:19:07 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:19:07 --> Utf8 Class Initialized
INFO - 2016-12-16 15:19:07 --> URI Class Initialized
INFO - 2016-12-16 15:19:07 --> Router Class Initialized
INFO - 2016-12-16 15:19:07 --> Output Class Initialized
INFO - 2016-12-16 15:19:07 --> Security Class Initialized
DEBUG - 2016-12-16 15:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:19:07 --> Input Class Initialized
INFO - 2016-12-16 15:19:07 --> Language Class Initialized
INFO - 2016-12-16 15:19:07 --> Loader Class Initialized
INFO - 2016-12-16 15:19:07 --> Database Driver Class Initialized
INFO - 2016-12-16 15:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:19:07 --> Controller Class Initialized
INFO - 2016-12-16 15:19:07 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:19:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:19:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:19:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:19:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:19:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:19:07 --> Final output sent to browser
DEBUG - 2016-12-16 15:19:07 --> Total execution time: 0.0134
INFO - 2016-12-16 15:26:56 --> Config Class Initialized
INFO - 2016-12-16 15:26:56 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:26:57 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:26:57 --> Utf8 Class Initialized
INFO - 2016-12-16 15:26:57 --> URI Class Initialized
INFO - 2016-12-16 15:26:57 --> Router Class Initialized
INFO - 2016-12-16 15:26:57 --> Output Class Initialized
INFO - 2016-12-16 15:26:57 --> Security Class Initialized
DEBUG - 2016-12-16 15:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:26:57 --> Input Class Initialized
INFO - 2016-12-16 15:26:57 --> Language Class Initialized
INFO - 2016-12-16 15:26:57 --> Loader Class Initialized
INFO - 2016-12-16 15:26:57 --> Database Driver Class Initialized
INFO - 2016-12-16 15:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:26:57 --> Controller Class Initialized
DEBUG - 2016-12-16 15:26:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:26:57 --> Helper loaded: url_helper
INFO - 2016-12-16 15:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:26:57 --> Final output sent to browser
DEBUG - 2016-12-16 15:26:57 --> Total execution time: 0.2911
INFO - 2016-12-16 15:26:57 --> Config Class Initialized
INFO - 2016-12-16 15:26:57 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:26:57 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:26:57 --> Utf8 Class Initialized
INFO - 2016-12-16 15:26:57 --> URI Class Initialized
INFO - 2016-12-16 15:26:57 --> Router Class Initialized
INFO - 2016-12-16 15:26:57 --> Output Class Initialized
INFO - 2016-12-16 15:26:57 --> Security Class Initialized
DEBUG - 2016-12-16 15:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:26:57 --> Input Class Initialized
INFO - 2016-12-16 15:26:57 --> Language Class Initialized
ERROR - 2016-12-16 15:26:57 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:26:57 --> Config Class Initialized
INFO - 2016-12-16 15:26:57 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:26:57 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:26:57 --> Utf8 Class Initialized
INFO - 2016-12-16 15:26:57 --> URI Class Initialized
INFO - 2016-12-16 15:26:57 --> Router Class Initialized
INFO - 2016-12-16 15:26:57 --> Output Class Initialized
INFO - 2016-12-16 15:26:57 --> Security Class Initialized
DEBUG - 2016-12-16 15:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:26:57 --> Input Class Initialized
INFO - 2016-12-16 15:26:57 --> Language Class Initialized
INFO - 2016-12-16 15:26:57 --> Loader Class Initialized
INFO - 2016-12-16 15:26:57 --> Database Driver Class Initialized
INFO - 2016-12-16 15:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:26:57 --> Controller Class Initialized
INFO - 2016-12-16 15:26:57 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:26:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:26:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:26:57 --> Final output sent to browser
DEBUG - 2016-12-16 15:26:57 --> Total execution time: 0.0134
INFO - 2016-12-16 15:27:04 --> Config Class Initialized
INFO - 2016-12-16 15:27:04 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:27:04 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:27:04 --> Utf8 Class Initialized
INFO - 2016-12-16 15:27:04 --> URI Class Initialized
INFO - 2016-12-16 15:27:04 --> Router Class Initialized
INFO - 2016-12-16 15:27:04 --> Output Class Initialized
INFO - 2016-12-16 15:27:04 --> Security Class Initialized
DEBUG - 2016-12-16 15:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:27:04 --> Input Class Initialized
INFO - 2016-12-16 15:27:04 --> Language Class Initialized
INFO - 2016-12-16 15:27:04 --> Loader Class Initialized
INFO - 2016-12-16 15:27:04 --> Database Driver Class Initialized
INFO - 2016-12-16 15:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:27:04 --> Controller Class Initialized
DEBUG - 2016-12-16 15:27:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:27:04 --> Helper loaded: url_helper
INFO - 2016-12-16 15:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:27:04 --> Final output sent to browser
DEBUG - 2016-12-16 15:27:04 --> Total execution time: 0.0122
INFO - 2016-12-16 15:27:04 --> Config Class Initialized
INFO - 2016-12-16 15:27:04 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:27:04 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:27:04 --> Utf8 Class Initialized
INFO - 2016-12-16 15:27:04 --> URI Class Initialized
INFO - 2016-12-16 15:27:04 --> Router Class Initialized
INFO - 2016-12-16 15:27:04 --> Output Class Initialized
INFO - 2016-12-16 15:27:04 --> Security Class Initialized
DEBUG - 2016-12-16 15:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:27:04 --> Input Class Initialized
INFO - 2016-12-16 15:27:04 --> Language Class Initialized
ERROR - 2016-12-16 15:27:04 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-16 15:27:05 --> Config Class Initialized
INFO - 2016-12-16 15:27:05 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:27:05 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:27:05 --> Utf8 Class Initialized
INFO - 2016-12-16 15:27:05 --> URI Class Initialized
INFO - 2016-12-16 15:27:05 --> Router Class Initialized
INFO - 2016-12-16 15:27:05 --> Output Class Initialized
INFO - 2016-12-16 15:27:05 --> Security Class Initialized
DEBUG - 2016-12-16 15:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:27:05 --> Input Class Initialized
INFO - 2016-12-16 15:27:05 --> Language Class Initialized
INFO - 2016-12-16 15:27:05 --> Loader Class Initialized
INFO - 2016-12-16 15:27:05 --> Database Driver Class Initialized
INFO - 2016-12-16 15:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:27:05 --> Controller Class Initialized
INFO - 2016-12-16 15:27:05 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:27:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:27:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:27:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:27:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:27:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:27:05 --> Final output sent to browser
DEBUG - 2016-12-16 15:27:05 --> Total execution time: 0.0320
INFO - 2016-12-16 15:27:10 --> Config Class Initialized
INFO - 2016-12-16 15:27:10 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:27:10 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:27:10 --> Utf8 Class Initialized
INFO - 2016-12-16 15:27:10 --> URI Class Initialized
INFO - 2016-12-16 15:27:10 --> Router Class Initialized
INFO - 2016-12-16 15:27:10 --> Output Class Initialized
INFO - 2016-12-16 15:27:10 --> Security Class Initialized
DEBUG - 2016-12-16 15:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:27:10 --> Input Class Initialized
INFO - 2016-12-16 15:27:10 --> Language Class Initialized
INFO - 2016-12-16 15:27:10 --> Loader Class Initialized
INFO - 2016-12-16 15:27:11 --> Database Driver Class Initialized
INFO - 2016-12-16 15:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:27:11 --> Controller Class Initialized
DEBUG - 2016-12-16 15:27:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:27:11 --> Helper loaded: url_helper
INFO - 2016-12-16 15:27:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:27:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 15:27:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 15:27:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 15:27:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 15:27:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:27:11 --> Final output sent to browser
DEBUG - 2016-12-16 15:27:11 --> Total execution time: 0.0126
INFO - 2016-12-16 15:27:11 --> Config Class Initialized
INFO - 2016-12-16 15:27:11 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:27:11 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:27:11 --> Utf8 Class Initialized
INFO - 2016-12-16 15:27:11 --> URI Class Initialized
INFO - 2016-12-16 15:27:11 --> Router Class Initialized
INFO - 2016-12-16 15:27:11 --> Output Class Initialized
INFO - 2016-12-16 15:27:11 --> Security Class Initialized
DEBUG - 2016-12-16 15:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:27:11 --> Input Class Initialized
INFO - 2016-12-16 15:27:11 --> Language Class Initialized
INFO - 2016-12-16 15:27:11 --> Loader Class Initialized
INFO - 2016-12-16 15:27:11 --> Database Driver Class Initialized
INFO - 2016-12-16 15:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:27:11 --> Controller Class Initialized
INFO - 2016-12-16 15:27:11 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:27:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:27:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:27:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:27:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:27:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:27:11 --> Final output sent to browser
DEBUG - 2016-12-16 15:27:11 --> Total execution time: 0.0141
INFO - 2016-12-16 15:31:16 --> Config Class Initialized
INFO - 2016-12-16 15:31:16 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:31:16 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:31:16 --> Utf8 Class Initialized
INFO - 2016-12-16 15:31:16 --> URI Class Initialized
DEBUG - 2016-12-16 15:31:16 --> No URI present. Default controller set.
INFO - 2016-12-16 15:31:16 --> Router Class Initialized
INFO - 2016-12-16 15:31:16 --> Output Class Initialized
INFO - 2016-12-16 15:31:16 --> Security Class Initialized
DEBUG - 2016-12-16 15:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:31:16 --> Input Class Initialized
INFO - 2016-12-16 15:31:16 --> Language Class Initialized
INFO - 2016-12-16 15:31:16 --> Loader Class Initialized
INFO - 2016-12-16 15:31:16 --> Database Driver Class Initialized
INFO - 2016-12-16 15:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:31:16 --> Controller Class Initialized
INFO - 2016-12-16 15:31:16 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:31:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:31:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:31:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:31:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:31:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:31:16 --> Final output sent to browser
DEBUG - 2016-12-16 15:31:16 --> Total execution time: 0.0461
INFO - 2016-12-16 15:31:17 --> Config Class Initialized
INFO - 2016-12-16 15:31:17 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:31:17 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:31:17 --> Utf8 Class Initialized
INFO - 2016-12-16 15:31:17 --> URI Class Initialized
INFO - 2016-12-16 15:31:17 --> Router Class Initialized
INFO - 2016-12-16 15:31:17 --> Output Class Initialized
INFO - 2016-12-16 15:31:17 --> Security Class Initialized
DEBUG - 2016-12-16 15:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:31:17 --> Input Class Initialized
INFO - 2016-12-16 15:31:17 --> Language Class Initialized
INFO - 2016-12-16 15:31:17 --> Loader Class Initialized
INFO - 2016-12-16 15:31:17 --> Database Driver Class Initialized
INFO - 2016-12-16 15:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:31:17 --> Controller Class Initialized
INFO - 2016-12-16 15:31:17 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:31:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:31:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:31:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:31:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:31:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:31:17 --> Final output sent to browser
DEBUG - 2016-12-16 15:31:17 --> Total execution time: 0.0426
INFO - 2016-12-16 15:31:20 --> Config Class Initialized
INFO - 2016-12-16 15:31:20 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:31:20 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:31:20 --> Utf8 Class Initialized
INFO - 2016-12-16 15:31:20 --> URI Class Initialized
INFO - 2016-12-16 15:31:20 --> Router Class Initialized
INFO - 2016-12-16 15:31:20 --> Output Class Initialized
INFO - 2016-12-16 15:31:20 --> Security Class Initialized
DEBUG - 2016-12-16 15:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:31:20 --> Input Class Initialized
INFO - 2016-12-16 15:31:20 --> Language Class Initialized
INFO - 2016-12-16 15:31:20 --> Loader Class Initialized
INFO - 2016-12-16 15:31:20 --> Database Driver Class Initialized
INFO - 2016-12-16 15:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:31:20 --> Controller Class Initialized
INFO - 2016-12-16 15:31:20 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:31:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:31:20 --> Helper loaded: form_helper
INFO - 2016-12-16 15:31:20 --> Form Validation Class Initialized
INFO - 2016-12-16 15:31:20 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-16 15:31:20 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2016-12-16 15:31:20 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-16 15:31:20 --> Final output sent to browser
DEBUG - 2016-12-16 15:31:20 --> Total execution time: 0.5981
INFO - 2016-12-16 15:31:20 --> Config Class Initialized
INFO - 2016-12-16 15:31:20 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:31:20 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:31:20 --> Utf8 Class Initialized
INFO - 2016-12-16 15:31:20 --> URI Class Initialized
INFO - 2016-12-16 15:31:20 --> Router Class Initialized
INFO - 2016-12-16 15:31:20 --> Output Class Initialized
INFO - 2016-12-16 15:31:20 --> Security Class Initialized
DEBUG - 2016-12-16 15:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:31:20 --> Input Class Initialized
INFO - 2016-12-16 15:31:20 --> Language Class Initialized
INFO - 2016-12-16 15:31:20 --> Loader Class Initialized
INFO - 2016-12-16 15:31:20 --> Database Driver Class Initialized
INFO - 2016-12-16 15:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:31:20 --> Controller Class Initialized
INFO - 2016-12-16 15:31:20 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:31:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:31:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:31:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:31:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:31:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:31:20 --> Final output sent to browser
DEBUG - 2016-12-16 15:31:20 --> Total execution time: 0.0142
INFO - 2016-12-16 15:31:26 --> Config Class Initialized
INFO - 2016-12-16 15:31:26 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:31:26 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:31:26 --> Utf8 Class Initialized
INFO - 2016-12-16 15:31:26 --> URI Class Initialized
INFO - 2016-12-16 15:31:26 --> Router Class Initialized
INFO - 2016-12-16 15:31:26 --> Output Class Initialized
INFO - 2016-12-16 15:31:26 --> Security Class Initialized
DEBUG - 2016-12-16 15:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:31:26 --> Input Class Initialized
INFO - 2016-12-16 15:31:26 --> Language Class Initialized
INFO - 2016-12-16 15:31:26 --> Loader Class Initialized
INFO - 2016-12-16 15:31:26 --> Database Driver Class Initialized
INFO - 2016-12-16 15:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:31:26 --> Controller Class Initialized
INFO - 2016-12-16 15:31:26 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:31:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:31:26 --> Helper loaded: form_helper
INFO - 2016-12-16 15:31:26 --> Form Validation Class Initialized
INFO - 2016-12-16 15:31:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-16 15:31:26 --> Config Class Initialized
INFO - 2016-12-16 15:31:26 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:31:26 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:31:26 --> Utf8 Class Initialized
INFO - 2016-12-16 15:31:26 --> URI Class Initialized
INFO - 2016-12-16 15:31:26 --> Router Class Initialized
INFO - 2016-12-16 15:31:26 --> Output Class Initialized
INFO - 2016-12-16 15:31:26 --> Security Class Initialized
DEBUG - 2016-12-16 15:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:31:26 --> Input Class Initialized
INFO - 2016-12-16 15:31:26 --> Language Class Initialized
INFO - 2016-12-16 15:31:26 --> Loader Class Initialized
INFO - 2016-12-16 15:31:26 --> Database Driver Class Initialized
INFO - 2016-12-16 15:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:31:26 --> Controller Class Initialized
INFO - 2016-12-16 15:31:26 --> Helper loaded: date_helper
INFO - 2016-12-16 15:31:26 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:31:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:31:26 --> Helper loaded: form_helper
INFO - 2016-12-16 15:31:26 --> Form Validation Class Initialized
INFO - 2016-12-16 15:31:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-16 15:31:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-16 15:31:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2016-12-16 15:31:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2016-12-16 15:31:26 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-16 15:31:26 --> Final output sent to browser
DEBUG - 2016-12-16 15:31:26 --> Total execution time: 0.0909
INFO - 2016-12-16 15:31:26 --> Config Class Initialized
INFO - 2016-12-16 15:31:26 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:31:26 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:31:26 --> Utf8 Class Initialized
INFO - 2016-12-16 15:31:26 --> URI Class Initialized
INFO - 2016-12-16 15:31:26 --> Router Class Initialized
INFO - 2016-12-16 15:31:26 --> Output Class Initialized
INFO - 2016-12-16 15:31:26 --> Security Class Initialized
DEBUG - 2016-12-16 15:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:31:26 --> Input Class Initialized
INFO - 2016-12-16 15:31:26 --> Language Class Initialized
INFO - 2016-12-16 15:31:26 --> Loader Class Initialized
INFO - 2016-12-16 15:31:27 --> Database Driver Class Initialized
INFO - 2016-12-16 15:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:31:27 --> Controller Class Initialized
INFO - 2016-12-16 15:31:27 --> Helper loaded: date_helper
INFO - 2016-12-16 15:31:27 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:31:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:31:27 --> Helper loaded: form_helper
INFO - 2016-12-16 15:31:27 --> Form Validation Class Initialized
INFO - 2016-12-16 15:31:27 --> Final output sent to browser
DEBUG - 2016-12-16 15:31:27 --> Total execution time: 0.0614
INFO - 2016-12-16 15:31:27 --> Config Class Initialized
INFO - 2016-12-16 15:31:27 --> Hooks Class Initialized
DEBUG - 2016-12-16 15:31:27 --> UTF-8 Support Enabled
INFO - 2016-12-16 15:31:27 --> Utf8 Class Initialized
INFO - 2016-12-16 15:31:27 --> URI Class Initialized
INFO - 2016-12-16 15:31:27 --> Router Class Initialized
INFO - 2016-12-16 15:31:27 --> Output Class Initialized
INFO - 2016-12-16 15:31:27 --> Security Class Initialized
DEBUG - 2016-12-16 15:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 15:31:27 --> Input Class Initialized
INFO - 2016-12-16 15:31:27 --> Language Class Initialized
INFO - 2016-12-16 15:31:27 --> Loader Class Initialized
INFO - 2016-12-16 15:31:27 --> Database Driver Class Initialized
INFO - 2016-12-16 15:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 15:31:27 --> Controller Class Initialized
INFO - 2016-12-16 15:31:27 --> Helper loaded: url_helper
DEBUG - 2016-12-16 15:31:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 15:31:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 15:31:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 15:31:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 15:31:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 15:31:27 --> Final output sent to browser
DEBUG - 2016-12-16 15:31:27 --> Total execution time: 0.0183
INFO - 2016-12-16 16:08:43 --> Config Class Initialized
INFO - 2016-12-16 16:08:43 --> Hooks Class Initialized
DEBUG - 2016-12-16 16:08:43 --> UTF-8 Support Enabled
INFO - 2016-12-16 16:08:43 --> Utf8 Class Initialized
INFO - 2016-12-16 16:08:43 --> URI Class Initialized
INFO - 2016-12-16 16:08:43 --> Router Class Initialized
INFO - 2016-12-16 16:08:43 --> Output Class Initialized
INFO - 2016-12-16 16:08:43 --> Security Class Initialized
DEBUG - 2016-12-16 16:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 16:08:43 --> Input Class Initialized
INFO - 2016-12-16 16:08:43 --> Language Class Initialized
INFO - 2016-12-16 16:08:43 --> Loader Class Initialized
INFO - 2016-12-16 16:08:43 --> Database Driver Class Initialized
INFO - 2016-12-16 16:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 16:08:44 --> Controller Class Initialized
DEBUG - 2016-12-16 16:08:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 16:08:44 --> Helper loaded: url_helper
INFO - 2016-12-16 16:08:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 16:08:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 16:08:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 16:08:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 16:08:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 16:08:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 16:08:44 --> Final output sent to browser
DEBUG - 2016-12-16 16:08:44 --> Total execution time: 1.0210
INFO - 2016-12-16 16:08:45 --> Config Class Initialized
INFO - 2016-12-16 16:08:45 --> Hooks Class Initialized
DEBUG - 2016-12-16 16:08:45 --> UTF-8 Support Enabled
INFO - 2016-12-16 16:08:45 --> Utf8 Class Initialized
INFO - 2016-12-16 16:08:45 --> URI Class Initialized
INFO - 2016-12-16 16:08:45 --> Router Class Initialized
INFO - 2016-12-16 16:08:45 --> Output Class Initialized
INFO - 2016-12-16 16:08:45 --> Security Class Initialized
DEBUG - 2016-12-16 16:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 16:08:45 --> Input Class Initialized
INFO - 2016-12-16 16:08:45 --> Language Class Initialized
INFO - 2016-12-16 16:08:45 --> Loader Class Initialized
INFO - 2016-12-16 16:08:45 --> Database Driver Class Initialized
INFO - 2016-12-16 16:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 16:08:45 --> Controller Class Initialized
INFO - 2016-12-16 16:08:45 --> Helper loaded: url_helper
DEBUG - 2016-12-16 16:08:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 16:08:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 16:08:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 16:08:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 16:08:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 16:08:45 --> Final output sent to browser
DEBUG - 2016-12-16 16:08:45 --> Total execution time: 0.0141
INFO - 2016-12-16 16:09:09 --> Config Class Initialized
INFO - 2016-12-16 16:09:09 --> Hooks Class Initialized
DEBUG - 2016-12-16 16:09:09 --> UTF-8 Support Enabled
INFO - 2016-12-16 16:09:09 --> Utf8 Class Initialized
INFO - 2016-12-16 16:09:09 --> URI Class Initialized
INFO - 2016-12-16 16:09:09 --> Router Class Initialized
INFO - 2016-12-16 16:09:09 --> Output Class Initialized
INFO - 2016-12-16 16:09:09 --> Security Class Initialized
DEBUG - 2016-12-16 16:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 16:09:09 --> Input Class Initialized
INFO - 2016-12-16 16:09:09 --> Language Class Initialized
INFO - 2016-12-16 16:09:09 --> Loader Class Initialized
INFO - 2016-12-16 16:09:09 --> Database Driver Class Initialized
INFO - 2016-12-16 16:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 16:09:09 --> Controller Class Initialized
DEBUG - 2016-12-16 16:09:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 16:09:09 --> Helper loaded: url_helper
INFO - 2016-12-16 16:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 16:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 16:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 16:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 16:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 16:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 16:09:09 --> Final output sent to browser
DEBUG - 2016-12-16 16:09:09 --> Total execution time: 0.0131
INFO - 2016-12-16 16:09:09 --> Config Class Initialized
INFO - 2016-12-16 16:09:09 --> Hooks Class Initialized
DEBUG - 2016-12-16 16:09:09 --> UTF-8 Support Enabled
INFO - 2016-12-16 16:09:09 --> Utf8 Class Initialized
INFO - 2016-12-16 16:09:09 --> URI Class Initialized
INFO - 2016-12-16 16:09:09 --> Router Class Initialized
INFO - 2016-12-16 16:09:09 --> Output Class Initialized
INFO - 2016-12-16 16:09:09 --> Security Class Initialized
DEBUG - 2016-12-16 16:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 16:09:09 --> Input Class Initialized
INFO - 2016-12-16 16:09:09 --> Language Class Initialized
INFO - 2016-12-16 16:09:09 --> Loader Class Initialized
INFO - 2016-12-16 16:09:09 --> Database Driver Class Initialized
INFO - 2016-12-16 16:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 16:09:09 --> Controller Class Initialized
INFO - 2016-12-16 16:09:09 --> Helper loaded: url_helper
DEBUG - 2016-12-16 16:09:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 16:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 16:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 16:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 16:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 16:09:09 --> Final output sent to browser
DEBUG - 2016-12-16 16:09:09 --> Total execution time: 0.0139
INFO - 2016-12-16 16:09:12 --> Config Class Initialized
INFO - 2016-12-16 16:09:12 --> Hooks Class Initialized
DEBUG - 2016-12-16 16:09:12 --> UTF-8 Support Enabled
INFO - 2016-12-16 16:09:12 --> Utf8 Class Initialized
INFO - 2016-12-16 16:09:12 --> URI Class Initialized
INFO - 2016-12-16 16:09:12 --> Router Class Initialized
INFO - 2016-12-16 16:09:12 --> Output Class Initialized
INFO - 2016-12-16 16:09:12 --> Security Class Initialized
DEBUG - 2016-12-16 16:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 16:09:12 --> Input Class Initialized
INFO - 2016-12-16 16:09:12 --> Language Class Initialized
INFO - 2016-12-16 16:09:12 --> Loader Class Initialized
INFO - 2016-12-16 16:09:12 --> Database Driver Class Initialized
INFO - 2016-12-16 16:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 16:09:12 --> Controller Class Initialized
DEBUG - 2016-12-16 16:09:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 16:09:12 --> Helper loaded: url_helper
INFO - 2016-12-16 16:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 16:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 16:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 16:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 16:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 16:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 16:09:12 --> Final output sent to browser
DEBUG - 2016-12-16 16:09:12 --> Total execution time: 0.0120
INFO - 2016-12-16 16:09:13 --> Config Class Initialized
INFO - 2016-12-16 16:09:13 --> Hooks Class Initialized
DEBUG - 2016-12-16 16:09:13 --> UTF-8 Support Enabled
INFO - 2016-12-16 16:09:13 --> Utf8 Class Initialized
INFO - 2016-12-16 16:09:13 --> URI Class Initialized
INFO - 2016-12-16 16:09:13 --> Router Class Initialized
INFO - 2016-12-16 16:09:13 --> Output Class Initialized
INFO - 2016-12-16 16:09:13 --> Security Class Initialized
DEBUG - 2016-12-16 16:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 16:09:13 --> Input Class Initialized
INFO - 2016-12-16 16:09:13 --> Language Class Initialized
INFO - 2016-12-16 16:09:13 --> Loader Class Initialized
INFO - 2016-12-16 16:09:13 --> Database Driver Class Initialized
INFO - 2016-12-16 16:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 16:09:13 --> Controller Class Initialized
INFO - 2016-12-16 16:09:13 --> Helper loaded: url_helper
DEBUG - 2016-12-16 16:09:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 16:09:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 16:09:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 16:09:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 16:09:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 16:09:13 --> Final output sent to browser
DEBUG - 2016-12-16 16:09:13 --> Total execution time: 0.0147
INFO - 2016-12-16 16:09:14 --> Config Class Initialized
INFO - 2016-12-16 16:09:14 --> Hooks Class Initialized
DEBUG - 2016-12-16 16:09:14 --> UTF-8 Support Enabled
INFO - 2016-12-16 16:09:14 --> Utf8 Class Initialized
INFO - 2016-12-16 16:09:14 --> URI Class Initialized
INFO - 2016-12-16 16:09:14 --> Router Class Initialized
INFO - 2016-12-16 16:09:14 --> Output Class Initialized
INFO - 2016-12-16 16:09:14 --> Security Class Initialized
DEBUG - 2016-12-16 16:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 16:09:14 --> Input Class Initialized
INFO - 2016-12-16 16:09:14 --> Language Class Initialized
INFO - 2016-12-16 16:09:14 --> Loader Class Initialized
INFO - 2016-12-16 16:09:14 --> Database Driver Class Initialized
INFO - 2016-12-16 16:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 16:09:14 --> Controller Class Initialized
DEBUG - 2016-12-16 16:09:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 16:09:14 --> Helper loaded: url_helper
INFO - 2016-12-16 16:09:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 16:09:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 16:09:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 16:09:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 16:09:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 16:09:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 16:09:14 --> Final output sent to browser
DEBUG - 2016-12-16 16:09:14 --> Total execution time: 0.0308
INFO - 2016-12-16 16:09:14 --> Config Class Initialized
INFO - 2016-12-16 16:09:14 --> Hooks Class Initialized
DEBUG - 2016-12-16 16:09:14 --> UTF-8 Support Enabled
INFO - 2016-12-16 16:09:14 --> Utf8 Class Initialized
INFO - 2016-12-16 16:09:14 --> URI Class Initialized
INFO - 2016-12-16 16:09:14 --> Router Class Initialized
INFO - 2016-12-16 16:09:14 --> Output Class Initialized
INFO - 2016-12-16 16:09:14 --> Security Class Initialized
DEBUG - 2016-12-16 16:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 16:09:14 --> Input Class Initialized
INFO - 2016-12-16 16:09:14 --> Language Class Initialized
INFO - 2016-12-16 16:09:14 --> Loader Class Initialized
INFO - 2016-12-16 16:09:14 --> Database Driver Class Initialized
INFO - 2016-12-16 16:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 16:09:14 --> Controller Class Initialized
INFO - 2016-12-16 16:09:14 --> Helper loaded: url_helper
DEBUG - 2016-12-16 16:09:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 16:09:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 16:09:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 16:09:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 16:09:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 16:09:14 --> Final output sent to browser
DEBUG - 2016-12-16 16:09:14 --> Total execution time: 0.0146
INFO - 2016-12-16 16:09:20 --> Config Class Initialized
INFO - 2016-12-16 16:09:20 --> Hooks Class Initialized
DEBUG - 2016-12-16 16:09:20 --> UTF-8 Support Enabled
INFO - 2016-12-16 16:09:20 --> Utf8 Class Initialized
INFO - 2016-12-16 16:09:20 --> URI Class Initialized
INFO - 2016-12-16 16:09:20 --> Router Class Initialized
INFO - 2016-12-16 16:09:20 --> Output Class Initialized
INFO - 2016-12-16 16:09:20 --> Security Class Initialized
DEBUG - 2016-12-16 16:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 16:09:20 --> Input Class Initialized
INFO - 2016-12-16 16:09:20 --> Language Class Initialized
INFO - 2016-12-16 16:09:20 --> Loader Class Initialized
INFO - 2016-12-16 16:09:20 --> Database Driver Class Initialized
INFO - 2016-12-16 16:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 16:09:20 --> Controller Class Initialized
DEBUG - 2016-12-16 16:09:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 16:09:20 --> Helper loaded: url_helper
INFO - 2016-12-16 16:09:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 16:09:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 16:09:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 16:09:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 16:09:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 16:09:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 16:09:20 --> Final output sent to browser
DEBUG - 2016-12-16 16:09:20 --> Total execution time: 0.0129
INFO - 2016-12-16 16:09:21 --> Config Class Initialized
INFO - 2016-12-16 16:09:21 --> Hooks Class Initialized
DEBUG - 2016-12-16 16:09:21 --> UTF-8 Support Enabled
INFO - 2016-12-16 16:09:21 --> Utf8 Class Initialized
INFO - 2016-12-16 16:09:21 --> URI Class Initialized
INFO - 2016-12-16 16:09:21 --> Router Class Initialized
INFO - 2016-12-16 16:09:21 --> Output Class Initialized
INFO - 2016-12-16 16:09:21 --> Security Class Initialized
DEBUG - 2016-12-16 16:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 16:09:21 --> Input Class Initialized
INFO - 2016-12-16 16:09:21 --> Language Class Initialized
INFO - 2016-12-16 16:09:21 --> Loader Class Initialized
INFO - 2016-12-16 16:09:21 --> Database Driver Class Initialized
INFO - 2016-12-16 16:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 16:09:21 --> Controller Class Initialized
INFO - 2016-12-16 16:09:21 --> Helper loaded: url_helper
DEBUG - 2016-12-16 16:09:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 16:09:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 16:09:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 16:09:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 16:09:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 16:09:21 --> Final output sent to browser
DEBUG - 2016-12-16 16:09:21 --> Total execution time: 0.0162
INFO - 2016-12-16 16:09:22 --> Config Class Initialized
INFO - 2016-12-16 16:09:22 --> Hooks Class Initialized
DEBUG - 2016-12-16 16:09:22 --> UTF-8 Support Enabled
INFO - 2016-12-16 16:09:22 --> Utf8 Class Initialized
INFO - 2016-12-16 16:09:22 --> URI Class Initialized
INFO - 2016-12-16 16:09:22 --> Router Class Initialized
INFO - 2016-12-16 16:09:22 --> Output Class Initialized
INFO - 2016-12-16 16:09:22 --> Security Class Initialized
DEBUG - 2016-12-16 16:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 16:09:22 --> Input Class Initialized
INFO - 2016-12-16 16:09:22 --> Language Class Initialized
INFO - 2016-12-16 16:09:22 --> Loader Class Initialized
INFO - 2016-12-16 16:09:22 --> Database Driver Class Initialized
INFO - 2016-12-16 16:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 16:09:22 --> Controller Class Initialized
DEBUG - 2016-12-16 16:09:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 16:09:22 --> Helper loaded: url_helper
INFO - 2016-12-16 16:09:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 16:09:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 16:09:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 16:09:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 16:09:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 16:09:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 16:09:22 --> Final output sent to browser
DEBUG - 2016-12-16 16:09:22 --> Total execution time: 0.0129
INFO - 2016-12-16 16:09:22 --> Config Class Initialized
INFO - 2016-12-16 16:09:22 --> Hooks Class Initialized
DEBUG - 2016-12-16 16:09:22 --> UTF-8 Support Enabled
INFO - 2016-12-16 16:09:22 --> Utf8 Class Initialized
INFO - 2016-12-16 16:09:22 --> URI Class Initialized
INFO - 2016-12-16 16:09:22 --> Router Class Initialized
INFO - 2016-12-16 16:09:22 --> Output Class Initialized
INFO - 2016-12-16 16:09:22 --> Security Class Initialized
DEBUG - 2016-12-16 16:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 16:09:22 --> Input Class Initialized
INFO - 2016-12-16 16:09:22 --> Language Class Initialized
INFO - 2016-12-16 16:09:22 --> Loader Class Initialized
INFO - 2016-12-16 16:09:22 --> Database Driver Class Initialized
INFO - 2016-12-16 16:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 16:09:22 --> Controller Class Initialized
INFO - 2016-12-16 16:09:22 --> Helper loaded: url_helper
DEBUG - 2016-12-16 16:09:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 16:09:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 16:09:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 16:09:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 16:09:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 16:09:22 --> Final output sent to browser
DEBUG - 2016-12-16 16:09:22 --> Total execution time: 0.0140
INFO - 2016-12-16 16:09:48 --> Config Class Initialized
INFO - 2016-12-16 16:09:48 --> Hooks Class Initialized
DEBUG - 2016-12-16 16:09:48 --> UTF-8 Support Enabled
INFO - 2016-12-16 16:09:48 --> Utf8 Class Initialized
INFO - 2016-12-16 16:09:48 --> URI Class Initialized
INFO - 2016-12-16 16:09:48 --> Router Class Initialized
INFO - 2016-12-16 16:09:48 --> Output Class Initialized
INFO - 2016-12-16 16:09:48 --> Security Class Initialized
DEBUG - 2016-12-16 16:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 16:09:48 --> Input Class Initialized
INFO - 2016-12-16 16:09:48 --> Language Class Initialized
INFO - 2016-12-16 16:09:48 --> Loader Class Initialized
INFO - 2016-12-16 16:09:48 --> Database Driver Class Initialized
INFO - 2016-12-16 16:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 16:09:48 --> Controller Class Initialized
DEBUG - 2016-12-16 16:09:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 16:09:48 --> Helper loaded: url_helper
INFO - 2016-12-16 16:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 16:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 16:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 16:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 16:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 16:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 16:09:48 --> Final output sent to browser
DEBUG - 2016-12-16 16:09:48 --> Total execution time: 0.0128
INFO - 2016-12-16 16:09:48 --> Config Class Initialized
INFO - 2016-12-16 16:09:48 --> Hooks Class Initialized
DEBUG - 2016-12-16 16:09:48 --> UTF-8 Support Enabled
INFO - 2016-12-16 16:09:48 --> Utf8 Class Initialized
INFO - 2016-12-16 16:09:48 --> URI Class Initialized
INFO - 2016-12-16 16:09:48 --> Router Class Initialized
INFO - 2016-12-16 16:09:48 --> Output Class Initialized
INFO - 2016-12-16 16:09:48 --> Security Class Initialized
DEBUG - 2016-12-16 16:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 16:09:48 --> Input Class Initialized
INFO - 2016-12-16 16:09:48 --> Language Class Initialized
INFO - 2016-12-16 16:09:48 --> Loader Class Initialized
INFO - 2016-12-16 16:09:48 --> Database Driver Class Initialized
INFO - 2016-12-16 16:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 16:09:48 --> Controller Class Initialized
INFO - 2016-12-16 16:09:48 --> Helper loaded: url_helper
DEBUG - 2016-12-16 16:09:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 16:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 16:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 16:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 16:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 16:09:48 --> Final output sent to browser
DEBUG - 2016-12-16 16:09:48 --> Total execution time: 0.0143
INFO - 2016-12-16 16:10:37 --> Config Class Initialized
INFO - 2016-12-16 16:10:37 --> Hooks Class Initialized
DEBUG - 2016-12-16 16:10:37 --> UTF-8 Support Enabled
INFO - 2016-12-16 16:10:37 --> Utf8 Class Initialized
INFO - 2016-12-16 16:10:37 --> URI Class Initialized
INFO - 2016-12-16 16:10:37 --> Router Class Initialized
INFO - 2016-12-16 16:10:37 --> Output Class Initialized
INFO - 2016-12-16 16:10:37 --> Security Class Initialized
DEBUG - 2016-12-16 16:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 16:10:37 --> Input Class Initialized
INFO - 2016-12-16 16:10:37 --> Language Class Initialized
INFO - 2016-12-16 16:10:37 --> Loader Class Initialized
INFO - 2016-12-16 16:10:37 --> Database Driver Class Initialized
INFO - 2016-12-16 16:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 16:10:37 --> Controller Class Initialized
DEBUG - 2016-12-16 16:10:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 16:10:37 --> Helper loaded: url_helper
INFO - 2016-12-16 16:10:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 16:10:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-16 16:10:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-16 16:10:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-16 16:10:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-16 16:10:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 16:10:37 --> Final output sent to browser
DEBUG - 2016-12-16 16:10:37 --> Total execution time: 0.0536
INFO - 2016-12-16 16:10:37 --> Config Class Initialized
INFO - 2016-12-16 16:10:37 --> Hooks Class Initialized
DEBUG - 2016-12-16 16:10:37 --> UTF-8 Support Enabled
INFO - 2016-12-16 16:10:37 --> Utf8 Class Initialized
INFO - 2016-12-16 16:10:37 --> URI Class Initialized
INFO - 2016-12-16 16:10:37 --> Router Class Initialized
INFO - 2016-12-16 16:10:37 --> Output Class Initialized
INFO - 2016-12-16 16:10:37 --> Security Class Initialized
DEBUG - 2016-12-16 16:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 16:10:37 --> Input Class Initialized
INFO - 2016-12-16 16:10:37 --> Language Class Initialized
INFO - 2016-12-16 16:10:37 --> Loader Class Initialized
INFO - 2016-12-16 16:10:37 --> Database Driver Class Initialized
INFO - 2016-12-16 16:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 16:10:37 --> Controller Class Initialized
INFO - 2016-12-16 16:10:37 --> Helper loaded: url_helper
DEBUG - 2016-12-16 16:10:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 16:10:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 16:10:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 16:10:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 16:10:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 16:10:37 --> Final output sent to browser
DEBUG - 2016-12-16 16:10:37 --> Total execution time: 0.0150
INFO - 2016-12-16 19:26:09 --> Config Class Initialized
INFO - 2016-12-16 19:26:09 --> Hooks Class Initialized
DEBUG - 2016-12-16 19:26:09 --> UTF-8 Support Enabled
INFO - 2016-12-16 19:26:09 --> Utf8 Class Initialized
INFO - 2016-12-16 19:26:09 --> URI Class Initialized
DEBUG - 2016-12-16 19:26:09 --> No URI present. Default controller set.
INFO - 2016-12-16 19:26:09 --> Router Class Initialized
INFO - 2016-12-16 19:26:09 --> Output Class Initialized
INFO - 2016-12-16 19:26:09 --> Security Class Initialized
DEBUG - 2016-12-16 19:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 19:26:09 --> Input Class Initialized
INFO - 2016-12-16 19:26:09 --> Language Class Initialized
INFO - 2016-12-16 19:26:09 --> Loader Class Initialized
INFO - 2016-12-16 19:26:10 --> Database Driver Class Initialized
INFO - 2016-12-16 19:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 19:26:10 --> Controller Class Initialized
INFO - 2016-12-16 19:26:10 --> Helper loaded: url_helper
DEBUG - 2016-12-16 19:26:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 19:26:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 19:26:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 19:26:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 19:26:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 19:26:10 --> Final output sent to browser
DEBUG - 2016-12-16 19:26:10 --> Total execution time: 1.5261
INFO - 2016-12-16 22:53:13 --> Config Class Initialized
INFO - 2016-12-16 22:53:13 --> Hooks Class Initialized
DEBUG - 2016-12-16 22:53:13 --> UTF-8 Support Enabled
INFO - 2016-12-16 22:53:13 --> Utf8 Class Initialized
INFO - 2016-12-16 22:53:13 --> URI Class Initialized
DEBUG - 2016-12-16 22:53:13 --> No URI present. Default controller set.
INFO - 2016-12-16 22:53:13 --> Router Class Initialized
INFO - 2016-12-16 22:53:13 --> Output Class Initialized
INFO - 2016-12-16 22:53:13 --> Security Class Initialized
DEBUG - 2016-12-16 22:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 22:53:13 --> Input Class Initialized
INFO - 2016-12-16 22:53:13 --> Language Class Initialized
INFO - 2016-12-16 22:53:13 --> Loader Class Initialized
INFO - 2016-12-16 22:53:13 --> Database Driver Class Initialized
INFO - 2016-12-16 22:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 22:53:13 --> Controller Class Initialized
INFO - 2016-12-16 22:53:13 --> Helper loaded: url_helper
DEBUG - 2016-12-16 22:53:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 22:53:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 22:53:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 22:53:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 22:53:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 22:53:13 --> Final output sent to browser
DEBUG - 2016-12-16 22:53:13 --> Total execution time: 0.1079
INFO - 2016-12-16 22:53:26 --> Config Class Initialized
INFO - 2016-12-16 22:53:26 --> Hooks Class Initialized
DEBUG - 2016-12-16 22:53:26 --> UTF-8 Support Enabled
INFO - 2016-12-16 22:53:26 --> Utf8 Class Initialized
INFO - 2016-12-16 22:53:26 --> URI Class Initialized
DEBUG - 2016-12-16 22:53:26 --> No URI present. Default controller set.
INFO - 2016-12-16 22:53:26 --> Router Class Initialized
INFO - 2016-12-16 22:53:26 --> Output Class Initialized
INFO - 2016-12-16 22:53:26 --> Security Class Initialized
DEBUG - 2016-12-16 22:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 22:53:26 --> Input Class Initialized
INFO - 2016-12-16 22:53:26 --> Language Class Initialized
INFO - 2016-12-16 22:53:26 --> Loader Class Initialized
INFO - 2016-12-16 22:53:26 --> Database Driver Class Initialized
INFO - 2016-12-16 22:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 22:53:26 --> Controller Class Initialized
INFO - 2016-12-16 22:53:26 --> Helper loaded: url_helper
DEBUG - 2016-12-16 22:53:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 22:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 22:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 22:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 22:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 22:53:26 --> Final output sent to browser
DEBUG - 2016-12-16 22:53:26 --> Total execution time: 0.0136
INFO - 2016-12-16 22:53:40 --> Config Class Initialized
INFO - 2016-12-16 22:53:40 --> Hooks Class Initialized
DEBUG - 2016-12-16 22:53:40 --> UTF-8 Support Enabled
INFO - 2016-12-16 22:53:40 --> Utf8 Class Initialized
INFO - 2016-12-16 22:53:40 --> URI Class Initialized
DEBUG - 2016-12-16 22:53:40 --> No URI present. Default controller set.
INFO - 2016-12-16 22:53:40 --> Router Class Initialized
INFO - 2016-12-16 22:53:40 --> Output Class Initialized
INFO - 2016-12-16 22:53:40 --> Security Class Initialized
DEBUG - 2016-12-16 22:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 22:53:40 --> Input Class Initialized
INFO - 2016-12-16 22:53:40 --> Language Class Initialized
INFO - 2016-12-16 22:53:40 --> Loader Class Initialized
INFO - 2016-12-16 22:53:40 --> Database Driver Class Initialized
INFO - 2016-12-16 22:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 22:53:40 --> Controller Class Initialized
INFO - 2016-12-16 22:53:40 --> Helper loaded: url_helper
DEBUG - 2016-12-16 22:53:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 22:53:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 22:53:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 22:53:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 22:53:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 22:53:40 --> Final output sent to browser
DEBUG - 2016-12-16 22:53:40 --> Total execution time: 0.0151
INFO - 2016-12-16 22:53:58 --> Config Class Initialized
INFO - 2016-12-16 22:53:58 --> Hooks Class Initialized
DEBUG - 2016-12-16 22:53:58 --> UTF-8 Support Enabled
INFO - 2016-12-16 22:53:58 --> Utf8 Class Initialized
INFO - 2016-12-16 22:53:58 --> URI Class Initialized
DEBUG - 2016-12-16 22:53:58 --> No URI present. Default controller set.
INFO - 2016-12-16 22:53:58 --> Router Class Initialized
INFO - 2016-12-16 22:53:58 --> Output Class Initialized
INFO - 2016-12-16 22:53:58 --> Security Class Initialized
DEBUG - 2016-12-16 22:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 22:53:58 --> Input Class Initialized
INFO - 2016-12-16 22:53:58 --> Language Class Initialized
INFO - 2016-12-16 22:53:58 --> Loader Class Initialized
INFO - 2016-12-16 22:53:58 --> Database Driver Class Initialized
INFO - 2016-12-16 22:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 22:53:58 --> Controller Class Initialized
INFO - 2016-12-16 22:53:58 --> Helper loaded: url_helper
DEBUG - 2016-12-16 22:53:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 22:53:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 22:53:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 22:53:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 22:53:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 22:53:58 --> Final output sent to browser
DEBUG - 2016-12-16 22:53:58 --> Total execution time: 0.0134
INFO - 2016-12-16 22:54:08 --> Config Class Initialized
INFO - 2016-12-16 22:54:08 --> Hooks Class Initialized
DEBUG - 2016-12-16 22:54:08 --> UTF-8 Support Enabled
INFO - 2016-12-16 22:54:08 --> Utf8 Class Initialized
INFO - 2016-12-16 22:54:08 --> URI Class Initialized
DEBUG - 2016-12-16 22:54:08 --> No URI present. Default controller set.
INFO - 2016-12-16 22:54:08 --> Router Class Initialized
INFO - 2016-12-16 22:54:08 --> Output Class Initialized
INFO - 2016-12-16 22:54:08 --> Security Class Initialized
DEBUG - 2016-12-16 22:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 22:54:08 --> Input Class Initialized
INFO - 2016-12-16 22:54:08 --> Language Class Initialized
INFO - 2016-12-16 22:54:08 --> Loader Class Initialized
INFO - 2016-12-16 22:54:08 --> Database Driver Class Initialized
INFO - 2016-12-16 22:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 22:54:08 --> Controller Class Initialized
INFO - 2016-12-16 22:54:08 --> Helper loaded: url_helper
DEBUG - 2016-12-16 22:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 22:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 22:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 22:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 22:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 22:54:08 --> Final output sent to browser
DEBUG - 2016-12-16 22:54:08 --> Total execution time: 0.0135
INFO - 2016-12-16 22:54:18 --> Config Class Initialized
INFO - 2016-12-16 22:54:18 --> Hooks Class Initialized
DEBUG - 2016-12-16 22:54:18 --> UTF-8 Support Enabled
INFO - 2016-12-16 22:54:18 --> Utf8 Class Initialized
INFO - 2016-12-16 22:54:18 --> URI Class Initialized
DEBUG - 2016-12-16 22:54:18 --> No URI present. Default controller set.
INFO - 2016-12-16 22:54:18 --> Router Class Initialized
INFO - 2016-12-16 22:54:18 --> Output Class Initialized
INFO - 2016-12-16 22:54:18 --> Security Class Initialized
DEBUG - 2016-12-16 22:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-16 22:54:18 --> Input Class Initialized
INFO - 2016-12-16 22:54:18 --> Language Class Initialized
INFO - 2016-12-16 22:54:18 --> Loader Class Initialized
INFO - 2016-12-16 22:54:18 --> Database Driver Class Initialized
INFO - 2016-12-16 22:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-16 22:54:18 --> Controller Class Initialized
INFO - 2016-12-16 22:54:18 --> Helper loaded: url_helper
DEBUG - 2016-12-16 22:54:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-16 22:54:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-16 22:54:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-16 22:54:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-16 22:54:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-16 22:54:18 --> Final output sent to browser
DEBUG - 2016-12-16 22:54:18 --> Total execution time: 0.0132

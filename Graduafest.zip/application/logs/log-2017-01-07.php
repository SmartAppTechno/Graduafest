<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-07 00:40:14 --> Config Class Initialized
INFO - 2017-01-07 00:40:14 --> Hooks Class Initialized
DEBUG - 2017-01-07 00:40:14 --> UTF-8 Support Enabled
INFO - 2017-01-07 00:40:14 --> Utf8 Class Initialized
INFO - 2017-01-07 00:40:14 --> URI Class Initialized
INFO - 2017-01-07 00:40:15 --> Router Class Initialized
INFO - 2017-01-07 00:40:15 --> Output Class Initialized
INFO - 2017-01-07 00:40:15 --> Security Class Initialized
DEBUG - 2017-01-07 00:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-07 00:40:15 --> Input Class Initialized
INFO - 2017-01-07 00:40:15 --> Language Class Initialized
INFO - 2017-01-07 00:40:15 --> Loader Class Initialized
INFO - 2017-01-07 00:40:15 --> Database Driver Class Initialized
INFO - 2017-01-07 00:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-07 00:40:15 --> Controller Class Initialized
INFO - 2017-01-07 00:40:15 --> Helper loaded: url_helper
DEBUG - 2017-01-07 00:40:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-07 00:40:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-07 00:40:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-07 00:40:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-07 00:40:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-07 00:40:16 --> Final output sent to browser
DEBUG - 2017-01-07 00:40:16 --> Total execution time: 1.7492
INFO - 2017-01-07 01:11:12 --> Config Class Initialized
INFO - 2017-01-07 01:11:12 --> Hooks Class Initialized
DEBUG - 2017-01-07 01:11:12 --> UTF-8 Support Enabled
INFO - 2017-01-07 01:11:12 --> Utf8 Class Initialized
INFO - 2017-01-07 01:11:12 --> URI Class Initialized
INFO - 2017-01-07 01:11:13 --> Router Class Initialized
INFO - 2017-01-07 01:11:13 --> Output Class Initialized
INFO - 2017-01-07 01:11:13 --> Security Class Initialized
DEBUG - 2017-01-07 01:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-07 01:11:13 --> Input Class Initialized
INFO - 2017-01-07 01:11:13 --> Language Class Initialized
INFO - 2017-01-07 01:11:13 --> Loader Class Initialized
INFO - 2017-01-07 01:11:13 --> Database Driver Class Initialized
INFO - 2017-01-07 01:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-07 01:11:13 --> Controller Class Initialized
INFO - 2017-01-07 01:11:13 --> Helper loaded: url_helper
DEBUG - 2017-01-07 01:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-07 01:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-07 01:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-07 01:11:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-07 01:11:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-07 01:11:14 --> Final output sent to browser
DEBUG - 2017-01-07 01:11:14 --> Total execution time: 1.5870
INFO - 2017-01-07 02:05:00 --> Config Class Initialized
INFO - 2017-01-07 02:05:00 --> Hooks Class Initialized
DEBUG - 2017-01-07 02:05:01 --> UTF-8 Support Enabled
INFO - 2017-01-07 02:05:01 --> Utf8 Class Initialized
INFO - 2017-01-07 02:05:01 --> URI Class Initialized
DEBUG - 2017-01-07 02:05:01 --> No URI present. Default controller set.
INFO - 2017-01-07 02:05:01 --> Router Class Initialized
INFO - 2017-01-07 02:05:01 --> Output Class Initialized
INFO - 2017-01-07 02:05:01 --> Security Class Initialized
DEBUG - 2017-01-07 02:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-07 02:05:01 --> Input Class Initialized
INFO - 2017-01-07 02:05:01 --> Language Class Initialized
INFO - 2017-01-07 02:05:01 --> Loader Class Initialized
INFO - 2017-01-07 02:05:01 --> Database Driver Class Initialized
INFO - 2017-01-07 02:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-07 02:05:01 --> Controller Class Initialized
INFO - 2017-01-07 02:05:01 --> Helper loaded: url_helper
DEBUG - 2017-01-07 02:05:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-07 02:05:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-07 02:05:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-07 02:05:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-07 02:05:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-07 02:05:02 --> Final output sent to browser
DEBUG - 2017-01-07 02:05:02 --> Total execution time: 1.3961
INFO - 2017-01-07 07:53:32 --> Config Class Initialized
INFO - 2017-01-07 07:53:32 --> Hooks Class Initialized
DEBUG - 2017-01-07 07:53:32 --> UTF-8 Support Enabled
INFO - 2017-01-07 07:53:32 --> Utf8 Class Initialized
INFO - 2017-01-07 07:53:32 --> URI Class Initialized
INFO - 2017-01-07 07:53:32 --> Router Class Initialized
INFO - 2017-01-07 07:53:32 --> Output Class Initialized
INFO - 2017-01-07 07:53:32 --> Security Class Initialized
DEBUG - 2017-01-07 07:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-07 07:53:32 --> Input Class Initialized
INFO - 2017-01-07 07:53:32 --> Language Class Initialized
INFO - 2017-01-07 07:53:32 --> Loader Class Initialized
INFO - 2017-01-07 07:53:33 --> Database Driver Class Initialized
INFO - 2017-01-07 07:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-07 07:53:33 --> Controller Class Initialized
INFO - 2017-01-07 07:53:33 --> Helper loaded: url_helper
DEBUG - 2017-01-07 07:53:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-07 07:53:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-07 07:53:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-07 07:53:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-07 07:53:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-07 07:53:34 --> Final output sent to browser
DEBUG - 2017-01-07 07:53:34 --> Total execution time: 1.9152
INFO - 2017-01-07 07:53:34 --> Config Class Initialized
INFO - 2017-01-07 07:53:34 --> Hooks Class Initialized
DEBUG - 2017-01-07 07:53:34 --> UTF-8 Support Enabled
INFO - 2017-01-07 07:53:34 --> Utf8 Class Initialized
INFO - 2017-01-07 07:53:34 --> URI Class Initialized
INFO - 2017-01-07 07:53:34 --> Router Class Initialized
INFO - 2017-01-07 07:53:34 --> Output Class Initialized
INFO - 2017-01-07 07:53:34 --> Security Class Initialized
DEBUG - 2017-01-07 07:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-07 07:53:34 --> Input Class Initialized
INFO - 2017-01-07 07:53:34 --> Language Class Initialized
ERROR - 2017-01-07 07:53:34 --> 404 Page Not Found: Well-known/assetlinks.json
INFO - 2017-01-07 11:38:03 --> Config Class Initialized
INFO - 2017-01-07 11:38:03 --> Hooks Class Initialized
DEBUG - 2017-01-07 11:38:03 --> UTF-8 Support Enabled
INFO - 2017-01-07 11:38:03 --> Utf8 Class Initialized
INFO - 2017-01-07 11:38:03 --> URI Class Initialized
INFO - 2017-01-07 11:38:03 --> Router Class Initialized
INFO - 2017-01-07 11:38:03 --> Output Class Initialized
INFO - 2017-01-07 11:38:03 --> Security Class Initialized
DEBUG - 2017-01-07 11:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-07 11:38:04 --> Input Class Initialized
INFO - 2017-01-07 11:38:04 --> Language Class Initialized
INFO - 2017-01-07 11:38:04 --> Loader Class Initialized
INFO - 2017-01-07 11:38:04 --> Database Driver Class Initialized
INFO - 2017-01-07 11:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-07 11:38:04 --> Controller Class Initialized
INFO - 2017-01-07 11:38:04 --> Helper loaded: url_helper
DEBUG - 2017-01-07 11:38:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-07 11:38:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-07 11:38:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-07 11:38:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-07 11:38:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-07 11:38:05 --> Final output sent to browser
DEBUG - 2017-01-07 11:38:05 --> Total execution time: 1.5911
INFO - 2017-01-07 11:38:05 --> Config Class Initialized
INFO - 2017-01-07 11:38:05 --> Hooks Class Initialized
DEBUG - 2017-01-07 11:38:05 --> UTF-8 Support Enabled
INFO - 2017-01-07 11:38:05 --> Utf8 Class Initialized
INFO - 2017-01-07 11:38:05 --> URI Class Initialized
DEBUG - 2017-01-07 11:38:05 --> No URI present. Default controller set.
INFO - 2017-01-07 11:38:05 --> Router Class Initialized
INFO - 2017-01-07 11:38:05 --> Output Class Initialized
INFO - 2017-01-07 11:38:05 --> Security Class Initialized
DEBUG - 2017-01-07 11:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-07 11:38:05 --> Input Class Initialized
INFO - 2017-01-07 11:38:05 --> Language Class Initialized
INFO - 2017-01-07 11:38:05 --> Loader Class Initialized
INFO - 2017-01-07 11:38:05 --> Database Driver Class Initialized
INFO - 2017-01-07 11:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-07 11:38:05 --> Controller Class Initialized
INFO - 2017-01-07 11:38:05 --> Helper loaded: url_helper
DEBUG - 2017-01-07 11:38:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-07 11:38:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-07 11:38:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-07 11:38:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-07 11:38:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-07 11:38:05 --> Final output sent to browser
DEBUG - 2017-01-07 11:38:05 --> Total execution time: 0.0143
INFO - 2017-01-07 14:17:06 --> Config Class Initialized
INFO - 2017-01-07 14:17:06 --> Hooks Class Initialized
DEBUG - 2017-01-07 14:17:06 --> UTF-8 Support Enabled
INFO - 2017-01-07 14:17:06 --> Utf8 Class Initialized
INFO - 2017-01-07 14:17:06 --> URI Class Initialized
DEBUG - 2017-01-07 14:17:06 --> No URI present. Default controller set.
INFO - 2017-01-07 14:17:06 --> Router Class Initialized
INFO - 2017-01-07 14:17:06 --> Output Class Initialized
INFO - 2017-01-07 14:17:06 --> Security Class Initialized
DEBUG - 2017-01-07 14:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-07 14:17:06 --> Input Class Initialized
INFO - 2017-01-07 14:17:06 --> Language Class Initialized
INFO - 2017-01-07 14:17:06 --> Loader Class Initialized
INFO - 2017-01-07 14:17:06 --> Database Driver Class Initialized
INFO - 2017-01-07 14:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-07 14:17:06 --> Controller Class Initialized
INFO - 2017-01-07 14:17:06 --> Helper loaded: url_helper
DEBUG - 2017-01-07 14:17:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-07 14:17:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-07 14:17:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-07 14:17:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-07 14:17:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-07 14:17:06 --> Final output sent to browser
DEBUG - 2017-01-07 14:17:06 --> Total execution time: 0.0297
INFO - 2017-01-07 14:17:07 --> Config Class Initialized
INFO - 2017-01-07 14:17:07 --> Hooks Class Initialized
DEBUG - 2017-01-07 14:17:07 --> UTF-8 Support Enabled
INFO - 2017-01-07 14:17:07 --> Utf8 Class Initialized
INFO - 2017-01-07 14:17:07 --> URI Class Initialized
DEBUG - 2017-01-07 14:17:07 --> No URI present. Default controller set.
INFO - 2017-01-07 14:17:07 --> Router Class Initialized
INFO - 2017-01-07 14:17:07 --> Output Class Initialized
INFO - 2017-01-07 14:17:07 --> Security Class Initialized
DEBUG - 2017-01-07 14:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-07 14:17:07 --> Input Class Initialized
INFO - 2017-01-07 14:17:07 --> Language Class Initialized
INFO - 2017-01-07 14:17:07 --> Loader Class Initialized
INFO - 2017-01-07 14:17:07 --> Database Driver Class Initialized
INFO - 2017-01-07 14:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-07 14:17:07 --> Controller Class Initialized
INFO - 2017-01-07 14:17:07 --> Helper loaded: url_helper
DEBUG - 2017-01-07 14:17:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-07 14:17:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-07 14:17:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-07 14:17:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-07 14:17:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-07 14:17:07 --> Final output sent to browser
DEBUG - 2017-01-07 14:17:07 --> Total execution time: 0.0191
INFO - 2017-01-07 14:46:35 --> Config Class Initialized
INFO - 2017-01-07 14:46:35 --> Hooks Class Initialized
DEBUG - 2017-01-07 14:46:35 --> UTF-8 Support Enabled
INFO - 2017-01-07 14:46:35 --> Utf8 Class Initialized
INFO - 2017-01-07 14:46:35 --> URI Class Initialized
DEBUG - 2017-01-07 14:46:35 --> No URI present. Default controller set.
INFO - 2017-01-07 14:46:35 --> Router Class Initialized
INFO - 2017-01-07 14:46:35 --> Output Class Initialized
INFO - 2017-01-07 14:46:35 --> Security Class Initialized
DEBUG - 2017-01-07 14:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-07 14:46:35 --> Input Class Initialized
INFO - 2017-01-07 14:46:35 --> Language Class Initialized
INFO - 2017-01-07 14:46:35 --> Loader Class Initialized
INFO - 2017-01-07 14:46:35 --> Database Driver Class Initialized
INFO - 2017-01-07 14:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-07 14:46:35 --> Controller Class Initialized
INFO - 2017-01-07 14:46:35 --> Helper loaded: url_helper
DEBUG - 2017-01-07 14:46:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-07 14:46:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-07 14:46:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-07 14:46:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-07 14:46:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-07 14:46:35 --> Final output sent to browser
DEBUG - 2017-01-07 14:46:35 --> Total execution time: 0.0133
INFO - 2017-01-07 23:51:31 --> Config Class Initialized
INFO - 2017-01-07 23:51:31 --> Hooks Class Initialized
DEBUG - 2017-01-07 23:51:31 --> UTF-8 Support Enabled
INFO - 2017-01-07 23:51:31 --> Utf8 Class Initialized
INFO - 2017-01-07 23:51:31 --> URI Class Initialized
DEBUG - 2017-01-07 23:51:31 --> No URI present. Default controller set.
INFO - 2017-01-07 23:51:31 --> Router Class Initialized
INFO - 2017-01-07 23:51:31 --> Output Class Initialized
INFO - 2017-01-07 23:51:31 --> Security Class Initialized
DEBUG - 2017-01-07 23:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-07 23:51:31 --> Input Class Initialized
INFO - 2017-01-07 23:51:31 --> Language Class Initialized
INFO - 2017-01-07 23:51:31 --> Loader Class Initialized
INFO - 2017-01-07 23:51:32 --> Database Driver Class Initialized
INFO - 2017-01-07 23:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-07 23:51:32 --> Controller Class Initialized
INFO - 2017-01-07 23:51:32 --> Helper loaded: url_helper
DEBUG - 2017-01-07 23:51:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-07 23:51:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-07 23:51:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-07 23:51:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-07 23:51:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-07 23:51:32 --> Final output sent to browser
DEBUG - 2017-01-07 23:51:32 --> Total execution time: 1.4587
INFO - 2017-01-07 23:52:22 --> Config Class Initialized
INFO - 2017-01-07 23:52:22 --> Hooks Class Initialized
DEBUG - 2017-01-07 23:52:22 --> UTF-8 Support Enabled
INFO - 2017-01-07 23:52:22 --> Utf8 Class Initialized
INFO - 2017-01-07 23:52:22 --> URI Class Initialized
INFO - 2017-01-07 23:52:22 --> Router Class Initialized
INFO - 2017-01-07 23:52:23 --> Output Class Initialized
INFO - 2017-01-07 23:52:23 --> Security Class Initialized
DEBUG - 2017-01-07 23:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-07 23:52:23 --> Input Class Initialized
INFO - 2017-01-07 23:52:23 --> Language Class Initialized
INFO - 2017-01-07 23:52:23 --> Loader Class Initialized
INFO - 2017-01-07 23:52:23 --> Database Driver Class Initialized
INFO - 2017-01-07 23:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-07 23:52:23 --> Controller Class Initialized
INFO - 2017-01-07 23:52:23 --> Helper loaded: url_helper
DEBUG - 2017-01-07 23:52:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-07 23:52:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-07 23:52:23 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-07 23:52:23 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-07 23:52:23 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-07 23:52:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-07 23:52:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-07 23:52:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-07 23:52:23 --> Final output sent to browser
DEBUG - 2017-01-07 23:52:23 --> Total execution time: 0.0612
INFO - 2017-01-07 23:52:26 --> Config Class Initialized
INFO - 2017-01-07 23:52:26 --> Hooks Class Initialized
DEBUG - 2017-01-07 23:52:26 --> UTF-8 Support Enabled
INFO - 2017-01-07 23:52:26 --> Utf8 Class Initialized
INFO - 2017-01-07 23:52:26 --> URI Class Initialized
INFO - 2017-01-07 23:52:26 --> Router Class Initialized
INFO - 2017-01-07 23:52:26 --> Output Class Initialized
INFO - 2017-01-07 23:52:26 --> Security Class Initialized
DEBUG - 2017-01-07 23:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-07 23:52:26 --> Input Class Initialized
INFO - 2017-01-07 23:52:26 --> Language Class Initialized
INFO - 2017-01-07 23:52:26 --> Loader Class Initialized
INFO - 2017-01-07 23:52:26 --> Database Driver Class Initialized
INFO - 2017-01-07 23:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-07 23:52:26 --> Controller Class Initialized
INFO - 2017-01-07 23:52:26 --> Helper loaded: url_helper
DEBUG - 2017-01-07 23:52:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-07 23:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-07 23:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-07 23:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-07 23:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-07 23:52:26 --> Final output sent to browser
DEBUG - 2017-01-07 23:52:26 --> Total execution time: 0.0137
INFO - 2017-01-07 23:52:31 --> Config Class Initialized
INFO - 2017-01-07 23:52:31 --> Hooks Class Initialized
DEBUG - 2017-01-07 23:52:31 --> UTF-8 Support Enabled
INFO - 2017-01-07 23:52:31 --> Utf8 Class Initialized
INFO - 2017-01-07 23:52:31 --> URI Class Initialized
DEBUG - 2017-01-07 23:52:31 --> No URI present. Default controller set.
INFO - 2017-01-07 23:52:31 --> Router Class Initialized
INFO - 2017-01-07 23:52:31 --> Output Class Initialized
INFO - 2017-01-07 23:52:31 --> Security Class Initialized
DEBUG - 2017-01-07 23:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-07 23:52:31 --> Input Class Initialized
INFO - 2017-01-07 23:52:31 --> Language Class Initialized
INFO - 2017-01-07 23:52:31 --> Loader Class Initialized
INFO - 2017-01-07 23:52:31 --> Database Driver Class Initialized
INFO - 2017-01-07 23:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-07 23:52:31 --> Controller Class Initialized
INFO - 2017-01-07 23:52:31 --> Helper loaded: url_helper
DEBUG - 2017-01-07 23:52:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-07 23:52:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-07 23:52:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-07 23:52:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-07 23:52:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-07 23:52:31 --> Final output sent to browser
DEBUG - 2017-01-07 23:52:31 --> Total execution time: 0.0246

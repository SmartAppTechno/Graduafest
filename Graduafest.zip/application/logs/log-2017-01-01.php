<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-01 00:25:21 --> Config Class Initialized
INFO - 2017-01-01 00:25:21 --> Hooks Class Initialized
DEBUG - 2017-01-01 00:25:21 --> UTF-8 Support Enabled
INFO - 2017-01-01 00:25:21 --> Utf8 Class Initialized
INFO - 2017-01-01 00:25:21 --> URI Class Initialized
DEBUG - 2017-01-01 00:25:21 --> No URI present. Default controller set.
INFO - 2017-01-01 00:25:21 --> Router Class Initialized
INFO - 2017-01-01 00:25:22 --> Output Class Initialized
INFO - 2017-01-01 00:25:22 --> Security Class Initialized
DEBUG - 2017-01-01 00:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-01 00:25:22 --> Input Class Initialized
INFO - 2017-01-01 00:25:22 --> Language Class Initialized
INFO - 2017-01-01 00:25:22 --> Loader Class Initialized
INFO - 2017-01-01 00:25:22 --> Database Driver Class Initialized
INFO - 2017-01-01 00:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-01 00:25:22 --> Controller Class Initialized
INFO - 2017-01-01 00:25:22 --> Helper loaded: url_helper
DEBUG - 2017-01-01 00:25:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-01 00:25:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-01 00:25:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-01 00:25:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-01 00:25:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-01 00:25:22 --> Final output sent to browser
DEBUG - 2017-01-01 00:25:22 --> Total execution time: 1.1711
INFO - 2017-01-01 03:42:21 --> Config Class Initialized
INFO - 2017-01-01 03:42:21 --> Hooks Class Initialized
DEBUG - 2017-01-01 03:42:22 --> UTF-8 Support Enabled
INFO - 2017-01-01 03:42:22 --> Utf8 Class Initialized
INFO - 2017-01-01 03:42:22 --> URI Class Initialized
DEBUG - 2017-01-01 03:42:22 --> No URI present. Default controller set.
INFO - 2017-01-01 03:42:22 --> Router Class Initialized
INFO - 2017-01-01 03:42:22 --> Output Class Initialized
INFO - 2017-01-01 03:42:22 --> Security Class Initialized
DEBUG - 2017-01-01 03:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-01 03:42:22 --> Input Class Initialized
INFO - 2017-01-01 03:42:22 --> Language Class Initialized
INFO - 2017-01-01 03:42:22 --> Loader Class Initialized
INFO - 2017-01-01 03:42:22 --> Database Driver Class Initialized
INFO - 2017-01-01 03:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-01 03:42:22 --> Controller Class Initialized
INFO - 2017-01-01 03:42:22 --> Helper loaded: url_helper
DEBUG - 2017-01-01 03:42:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-01 03:42:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-01 03:42:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-01 03:42:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-01 03:42:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-01 03:42:23 --> Final output sent to browser
DEBUG - 2017-01-01 03:42:23 --> Total execution time: 1.4130
INFO - 2017-01-01 03:45:44 --> Config Class Initialized
INFO - 2017-01-01 03:45:44 --> Hooks Class Initialized
DEBUG - 2017-01-01 03:45:44 --> UTF-8 Support Enabled
INFO - 2017-01-01 03:45:44 --> Utf8 Class Initialized
INFO - 2017-01-01 03:45:44 --> URI Class Initialized
DEBUG - 2017-01-01 03:45:44 --> No URI present. Default controller set.
INFO - 2017-01-01 03:45:44 --> Router Class Initialized
INFO - 2017-01-01 03:45:44 --> Output Class Initialized
INFO - 2017-01-01 03:45:44 --> Security Class Initialized
DEBUG - 2017-01-01 03:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-01 03:45:44 --> Input Class Initialized
INFO - 2017-01-01 03:45:44 --> Language Class Initialized
INFO - 2017-01-01 03:45:44 --> Loader Class Initialized
INFO - 2017-01-01 03:45:44 --> Database Driver Class Initialized
INFO - 2017-01-01 03:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-01 03:45:45 --> Controller Class Initialized
INFO - 2017-01-01 03:45:45 --> Helper loaded: url_helper
DEBUG - 2017-01-01 03:45:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-01 03:45:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-01 03:45:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-01 03:45:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-01 03:45:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-01 03:45:45 --> Final output sent to browser
DEBUG - 2017-01-01 03:45:45 --> Total execution time: 1.0867

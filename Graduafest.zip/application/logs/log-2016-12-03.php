<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-03 02:15:10 --> Config Class Initialized
INFO - 2016-12-03 02:15:10 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:15:10 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:15:10 --> Utf8 Class Initialized
INFO - 2016-12-03 02:15:10 --> URI Class Initialized
DEBUG - 2016-12-03 02:15:10 --> No URI present. Default controller set.
INFO - 2016-12-03 02:15:10 --> Router Class Initialized
INFO - 2016-12-03 02:15:10 --> Output Class Initialized
INFO - 2016-12-03 02:15:10 --> Security Class Initialized
DEBUG - 2016-12-03 02:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:15:10 --> Input Class Initialized
INFO - 2016-12-03 02:15:10 --> Language Class Initialized
INFO - 2016-12-03 02:15:10 --> Loader Class Initialized
INFO - 2016-12-03 02:15:11 --> Database Driver Class Initialized
INFO - 2016-12-03 02:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:15:11 --> Controller Class Initialized
INFO - 2016-12-03 02:15:11 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:15:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:15:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:15:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:15:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:15:11 --> Final output sent to browser
DEBUG - 2016-12-03 02:15:11 --> Total execution time: 1.7470
INFO - 2016-12-03 02:15:25 --> Config Class Initialized
INFO - 2016-12-03 02:15:25 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:15:25 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:15:25 --> Utf8 Class Initialized
INFO - 2016-12-03 02:15:25 --> URI Class Initialized
INFO - 2016-12-03 02:15:25 --> Router Class Initialized
INFO - 2016-12-03 02:15:25 --> Output Class Initialized
INFO - 2016-12-03 02:15:25 --> Security Class Initialized
DEBUG - 2016-12-03 02:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:15:25 --> Input Class Initialized
INFO - 2016-12-03 02:15:25 --> Language Class Initialized
INFO - 2016-12-03 02:15:25 --> Loader Class Initialized
INFO - 2016-12-03 02:15:25 --> Database Driver Class Initialized
INFO - 2016-12-03 02:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:15:25 --> Controller Class Initialized
INFO - 2016-12-03 02:15:25 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:15:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:15:25 --> Final output sent to browser
DEBUG - 2016-12-03 02:15:25 --> Total execution time: 0.0198
INFO - 2016-12-03 02:15:25 --> Config Class Initialized
INFO - 2016-12-03 02:15:25 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:15:25 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:15:25 --> Utf8 Class Initialized
INFO - 2016-12-03 02:15:25 --> URI Class Initialized
INFO - 2016-12-03 02:15:25 --> Router Class Initialized
INFO - 2016-12-03 02:15:25 --> Output Class Initialized
INFO - 2016-12-03 02:15:25 --> Security Class Initialized
DEBUG - 2016-12-03 02:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:15:25 --> Input Class Initialized
INFO - 2016-12-03 02:15:25 --> Language Class Initialized
INFO - 2016-12-03 02:15:25 --> Loader Class Initialized
INFO - 2016-12-03 02:15:25 --> Database Driver Class Initialized
INFO - 2016-12-03 02:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:15:25 --> Controller Class Initialized
INFO - 2016-12-03 02:15:25 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:15:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:15:25 --> Final output sent to browser
DEBUG - 2016-12-03 02:15:25 --> Total execution time: 0.0175
INFO - 2016-12-03 02:15:25 --> Config Class Initialized
INFO - 2016-12-03 02:15:25 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:15:25 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:15:25 --> Utf8 Class Initialized
INFO - 2016-12-03 02:15:25 --> URI Class Initialized
INFO - 2016-12-03 02:15:25 --> Router Class Initialized
INFO - 2016-12-03 02:15:25 --> Output Class Initialized
INFO - 2016-12-03 02:15:25 --> Security Class Initialized
DEBUG - 2016-12-03 02:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:15:25 --> Input Class Initialized
INFO - 2016-12-03 02:15:25 --> Language Class Initialized
INFO - 2016-12-03 02:15:25 --> Loader Class Initialized
INFO - 2016-12-03 02:15:25 --> Database Driver Class Initialized
INFO - 2016-12-03 02:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:15:25 --> Controller Class Initialized
INFO - 2016-12-03 02:15:25 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:15:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:15:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:15:25 --> Final output sent to browser
DEBUG - 2016-12-03 02:15:25 --> Total execution time: 0.0125
INFO - 2016-12-03 02:18:32 --> Config Class Initialized
INFO - 2016-12-03 02:18:32 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:18:32 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:18:32 --> Utf8 Class Initialized
INFO - 2016-12-03 02:18:32 --> URI Class Initialized
DEBUG - 2016-12-03 02:18:32 --> No URI present. Default controller set.
INFO - 2016-12-03 02:18:32 --> Router Class Initialized
INFO - 2016-12-03 02:18:32 --> Output Class Initialized
INFO - 2016-12-03 02:18:32 --> Security Class Initialized
DEBUG - 2016-12-03 02:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:18:32 --> Input Class Initialized
INFO - 2016-12-03 02:18:32 --> Language Class Initialized
INFO - 2016-12-03 02:18:32 --> Loader Class Initialized
INFO - 2016-12-03 02:18:32 --> Database Driver Class Initialized
INFO - 2016-12-03 02:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:18:32 --> Controller Class Initialized
INFO - 2016-12-03 02:18:32 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:18:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:18:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:18:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:18:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:18:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:18:32 --> Final output sent to browser
DEBUG - 2016-12-03 02:18:32 --> Total execution time: 0.0143
INFO - 2016-12-03 02:18:51 --> Config Class Initialized
INFO - 2016-12-03 02:18:51 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:18:51 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:18:51 --> Utf8 Class Initialized
INFO - 2016-12-03 02:18:51 --> URI Class Initialized
INFO - 2016-12-03 02:18:51 --> Router Class Initialized
INFO - 2016-12-03 02:18:51 --> Output Class Initialized
INFO - 2016-12-03 02:18:51 --> Security Class Initialized
DEBUG - 2016-12-03 02:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:18:51 --> Input Class Initialized
INFO - 2016-12-03 02:18:51 --> Language Class Initialized
INFO - 2016-12-03 02:18:51 --> Loader Class Initialized
INFO - 2016-12-03 02:18:51 --> Database Driver Class Initialized
INFO - 2016-12-03 02:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:18:51 --> Controller Class Initialized
INFO - 2016-12-03 02:18:51 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:18:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:18:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:18:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:18:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:18:51 --> Final output sent to browser
DEBUG - 2016-12-03 02:18:51 --> Total execution time: 0.0134
INFO - 2016-12-03 02:21:15 --> Config Class Initialized
INFO - 2016-12-03 02:21:15 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:21:15 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:21:15 --> Utf8 Class Initialized
INFO - 2016-12-03 02:21:15 --> URI Class Initialized
DEBUG - 2016-12-03 02:21:15 --> No URI present. Default controller set.
INFO - 2016-12-03 02:21:15 --> Router Class Initialized
INFO - 2016-12-03 02:21:15 --> Output Class Initialized
INFO - 2016-12-03 02:21:15 --> Security Class Initialized
DEBUG - 2016-12-03 02:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:21:15 --> Input Class Initialized
INFO - 2016-12-03 02:21:15 --> Language Class Initialized
INFO - 2016-12-03 02:21:15 --> Loader Class Initialized
INFO - 2016-12-03 02:21:15 --> Database Driver Class Initialized
INFO - 2016-12-03 02:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:21:15 --> Controller Class Initialized
INFO - 2016-12-03 02:21:15 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:21:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:21:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:21:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:21:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:21:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:21:15 --> Final output sent to browser
DEBUG - 2016-12-03 02:21:15 --> Total execution time: 0.0145
INFO - 2016-12-03 02:21:15 --> Config Class Initialized
INFO - 2016-12-03 02:21:15 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:21:15 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:21:15 --> Utf8 Class Initialized
INFO - 2016-12-03 02:21:15 --> URI Class Initialized
INFO - 2016-12-03 02:21:15 --> Router Class Initialized
INFO - 2016-12-03 02:21:15 --> Output Class Initialized
INFO - 2016-12-03 02:21:15 --> Security Class Initialized
DEBUG - 2016-12-03 02:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:21:15 --> Input Class Initialized
INFO - 2016-12-03 02:21:15 --> Language Class Initialized
INFO - 2016-12-03 02:21:15 --> Loader Class Initialized
INFO - 2016-12-03 02:21:15 --> Database Driver Class Initialized
INFO - 2016-12-03 02:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:21:15 --> Controller Class Initialized
INFO - 2016-12-03 02:21:15 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:21:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:21:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:21:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:21:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:21:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:21:15 --> Final output sent to browser
DEBUG - 2016-12-03 02:21:15 --> Total execution time: 0.0150
INFO - 2016-12-03 02:21:35 --> Config Class Initialized
INFO - 2016-12-03 02:21:35 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:21:35 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:21:35 --> Utf8 Class Initialized
INFO - 2016-12-03 02:21:35 --> URI Class Initialized
INFO - 2016-12-03 02:21:35 --> Router Class Initialized
INFO - 2016-12-03 02:21:35 --> Output Class Initialized
INFO - 2016-12-03 02:21:35 --> Security Class Initialized
DEBUG - 2016-12-03 02:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:21:35 --> Input Class Initialized
INFO - 2016-12-03 02:21:35 --> Language Class Initialized
INFO - 2016-12-03 02:21:35 --> Loader Class Initialized
INFO - 2016-12-03 02:21:35 --> Database Driver Class Initialized
INFO - 2016-12-03 02:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:21:35 --> Controller Class Initialized
INFO - 2016-12-03 02:21:35 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:21:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:21:38 --> Config Class Initialized
INFO - 2016-12-03 02:21:38 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:21:38 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:21:38 --> Utf8 Class Initialized
INFO - 2016-12-03 02:21:38 --> URI Class Initialized
INFO - 2016-12-03 02:21:38 --> Router Class Initialized
INFO - 2016-12-03 02:21:38 --> Output Class Initialized
INFO - 2016-12-03 02:21:38 --> Security Class Initialized
DEBUG - 2016-12-03 02:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:21:38 --> Input Class Initialized
INFO - 2016-12-03 02:21:38 --> Language Class Initialized
ERROR - 2016-12-03 02:21:39 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /home/graduafe/public_html/application/controllers/User_paquetes_personales_controller.php 28
INFO - 2016-12-03 02:21:39 --> Config Class Initialized
INFO - 2016-12-03 02:21:39 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:21:39 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:21:39 --> Utf8 Class Initialized
INFO - 2016-12-03 02:21:39 --> URI Class Initialized
INFO - 2016-12-03 02:21:39 --> Router Class Initialized
INFO - 2016-12-03 02:21:39 --> Output Class Initialized
INFO - 2016-12-03 02:21:39 --> Security Class Initialized
DEBUG - 2016-12-03 02:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:21:39 --> Input Class Initialized
INFO - 2016-12-03 02:21:39 --> Language Class Initialized
INFO - 2016-12-03 02:21:39 --> Loader Class Initialized
INFO - 2016-12-03 02:21:39 --> Database Driver Class Initialized
INFO - 2016-12-03 02:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:21:39 --> Controller Class Initialized
INFO - 2016-12-03 02:21:39 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:21:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:21:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:21:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:21:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:21:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:21:39 --> Final output sent to browser
DEBUG - 2016-12-03 02:21:39 --> Total execution time: 0.0138
INFO - 2016-12-03 02:22:43 --> Config Class Initialized
INFO - 2016-12-03 02:22:43 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:22:43 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:22:43 --> Utf8 Class Initialized
INFO - 2016-12-03 02:22:43 --> URI Class Initialized
INFO - 2016-12-03 02:22:43 --> Router Class Initialized
INFO - 2016-12-03 02:22:43 --> Output Class Initialized
INFO - 2016-12-03 02:22:43 --> Security Class Initialized
DEBUG - 2016-12-03 02:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:22:43 --> Input Class Initialized
INFO - 2016-12-03 02:22:43 --> Language Class Initialized
INFO - 2016-12-03 02:22:43 --> Loader Class Initialized
INFO - 2016-12-03 02:22:43 --> Database Driver Class Initialized
INFO - 2016-12-03 02:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:22:43 --> Controller Class Initialized
DEBUG - 2016-12-03 02:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:22:43 --> Helper loaded: url_helper
INFO - 2016-12-03 02:22:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:22:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 02:22:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-03 02:22:44 --> Config Class Initialized
INFO - 2016-12-03 02:22:44 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:22:44 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:22:44 --> Utf8 Class Initialized
INFO - 2016-12-03 02:22:44 --> URI Class Initialized
INFO - 2016-12-03 02:22:44 --> Router Class Initialized
INFO - 2016-12-03 02:22:44 --> Output Class Initialized
INFO - 2016-12-03 02:22:44 --> Security Class Initialized
DEBUG - 2016-12-03 02:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:22:44 --> Input Class Initialized
INFO - 2016-12-03 02:22:44 --> Language Class Initialized
INFO - 2016-12-03 02:22:44 --> Loader Class Initialized
INFO - 2016-12-03 02:22:44 --> Database Driver Class Initialized
INFO - 2016-12-03 02:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:22:44 --> Controller Class Initialized
INFO - 2016-12-03 02:22:44 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:22:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:22:44 --> Final output sent to browser
DEBUG - 2016-12-03 02:22:44 --> Total execution time: 0.0145
INFO - 2016-12-03 02:22:48 --> Config Class Initialized
INFO - 2016-12-03 02:22:48 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:22:48 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:22:48 --> Utf8 Class Initialized
INFO - 2016-12-03 02:22:48 --> URI Class Initialized
DEBUG - 2016-12-03 02:22:48 --> No URI present. Default controller set.
INFO - 2016-12-03 02:22:48 --> Router Class Initialized
INFO - 2016-12-03 02:22:48 --> Output Class Initialized
INFO - 2016-12-03 02:22:48 --> Security Class Initialized
DEBUG - 2016-12-03 02:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:22:48 --> Input Class Initialized
INFO - 2016-12-03 02:22:48 --> Language Class Initialized
INFO - 2016-12-03 02:22:48 --> Loader Class Initialized
INFO - 2016-12-03 02:22:48 --> Database Driver Class Initialized
INFO - 2016-12-03 02:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:22:48 --> Controller Class Initialized
INFO - 2016-12-03 02:22:48 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:22:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:22:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:22:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:22:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:22:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:22:48 --> Final output sent to browser
DEBUG - 2016-12-03 02:22:48 --> Total execution time: 0.0130
INFO - 2016-12-03 02:22:50 --> Config Class Initialized
INFO - 2016-12-03 02:22:50 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:22:50 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:22:50 --> Utf8 Class Initialized
INFO - 2016-12-03 02:22:50 --> URI Class Initialized
INFO - 2016-12-03 02:22:50 --> Router Class Initialized
INFO - 2016-12-03 02:22:50 --> Output Class Initialized
INFO - 2016-12-03 02:22:50 --> Security Class Initialized
DEBUG - 2016-12-03 02:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:22:50 --> Input Class Initialized
INFO - 2016-12-03 02:22:50 --> Language Class Initialized
INFO - 2016-12-03 02:22:50 --> Loader Class Initialized
INFO - 2016-12-03 02:22:50 --> Database Driver Class Initialized
INFO - 2016-12-03 02:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:22:50 --> Controller Class Initialized
INFO - 2016-12-03 02:22:50 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:22:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:22:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:22:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:22:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:22:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:22:50 --> Final output sent to browser
DEBUG - 2016-12-03 02:22:50 --> Total execution time: 0.0137
INFO - 2016-12-03 02:22:52 --> Config Class Initialized
INFO - 2016-12-03 02:22:52 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:22:52 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:22:52 --> Utf8 Class Initialized
INFO - 2016-12-03 02:22:52 --> URI Class Initialized
INFO - 2016-12-03 02:22:52 --> Router Class Initialized
INFO - 2016-12-03 02:22:52 --> Output Class Initialized
INFO - 2016-12-03 02:22:52 --> Security Class Initialized
DEBUG - 2016-12-03 02:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:22:52 --> Input Class Initialized
INFO - 2016-12-03 02:22:52 --> Language Class Initialized
INFO - 2016-12-03 02:22:52 --> Loader Class Initialized
INFO - 2016-12-03 02:22:52 --> Database Driver Class Initialized
INFO - 2016-12-03 02:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:22:52 --> Controller Class Initialized
INFO - 2016-12-03 02:22:52 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:22:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:22:52 --> Config Class Initialized
INFO - 2016-12-03 02:22:52 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:22:52 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:22:52 --> Utf8 Class Initialized
INFO - 2016-12-03 02:22:52 --> URI Class Initialized
INFO - 2016-12-03 02:22:52 --> Router Class Initialized
INFO - 2016-12-03 02:22:52 --> Output Class Initialized
INFO - 2016-12-03 02:22:52 --> Security Class Initialized
DEBUG - 2016-12-03 02:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:22:52 --> Input Class Initialized
INFO - 2016-12-03 02:22:52 --> Language Class Initialized
INFO - 2016-12-03 02:22:52 --> Loader Class Initialized
INFO - 2016-12-03 02:22:52 --> Database Driver Class Initialized
INFO - 2016-12-03 02:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:22:52 --> Controller Class Initialized
DEBUG - 2016-12-03 02:22:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:22:53 --> Helper loaded: url_helper
INFO - 2016-12-03 02:22:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:22:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 02:22:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-03 02:22:53 --> Config Class Initialized
INFO - 2016-12-03 02:22:53 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:22:53 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:22:53 --> Utf8 Class Initialized
INFO - 2016-12-03 02:22:53 --> URI Class Initialized
INFO - 2016-12-03 02:22:53 --> Router Class Initialized
INFO - 2016-12-03 02:22:53 --> Output Class Initialized
INFO - 2016-12-03 02:22:53 --> Security Class Initialized
DEBUG - 2016-12-03 02:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:22:53 --> Input Class Initialized
INFO - 2016-12-03 02:22:53 --> Language Class Initialized
INFO - 2016-12-03 02:22:53 --> Loader Class Initialized
INFO - 2016-12-03 02:22:53 --> Database Driver Class Initialized
INFO - 2016-12-03 02:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:22:53 --> Controller Class Initialized
INFO - 2016-12-03 02:22:53 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:22:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:22:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:22:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:22:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:22:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:22:53 --> Final output sent to browser
DEBUG - 2016-12-03 02:22:53 --> Total execution time: 0.0131
INFO - 2016-12-03 02:23:42 --> Config Class Initialized
INFO - 2016-12-03 02:23:42 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:23:42 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:23:42 --> Utf8 Class Initialized
INFO - 2016-12-03 02:23:42 --> URI Class Initialized
DEBUG - 2016-12-03 02:23:42 --> No URI present. Default controller set.
INFO - 2016-12-03 02:23:42 --> Router Class Initialized
INFO - 2016-12-03 02:23:42 --> Output Class Initialized
INFO - 2016-12-03 02:23:42 --> Security Class Initialized
DEBUG - 2016-12-03 02:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:23:42 --> Input Class Initialized
INFO - 2016-12-03 02:23:42 --> Language Class Initialized
INFO - 2016-12-03 02:23:42 --> Loader Class Initialized
INFO - 2016-12-03 02:23:42 --> Database Driver Class Initialized
INFO - 2016-12-03 02:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:23:42 --> Controller Class Initialized
INFO - 2016-12-03 02:23:42 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:23:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:23:42 --> Final output sent to browser
DEBUG - 2016-12-03 02:23:42 --> Total execution time: 0.0136
INFO - 2016-12-03 02:23:43 --> Config Class Initialized
INFO - 2016-12-03 02:23:43 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:23:43 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:23:43 --> Utf8 Class Initialized
INFO - 2016-12-03 02:23:43 --> URI Class Initialized
INFO - 2016-12-03 02:23:43 --> Router Class Initialized
INFO - 2016-12-03 02:23:43 --> Output Class Initialized
INFO - 2016-12-03 02:23:43 --> Security Class Initialized
DEBUG - 2016-12-03 02:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:23:43 --> Input Class Initialized
INFO - 2016-12-03 02:23:43 --> Language Class Initialized
INFO - 2016-12-03 02:23:43 --> Loader Class Initialized
INFO - 2016-12-03 02:23:43 --> Database Driver Class Initialized
INFO - 2016-12-03 02:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:23:43 --> Controller Class Initialized
INFO - 2016-12-03 02:23:43 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:23:43 --> Final output sent to browser
DEBUG - 2016-12-03 02:23:43 --> Total execution time: 0.0142
INFO - 2016-12-03 02:23:45 --> Config Class Initialized
INFO - 2016-12-03 02:23:45 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:23:45 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:23:45 --> Utf8 Class Initialized
INFO - 2016-12-03 02:23:45 --> URI Class Initialized
INFO - 2016-12-03 02:23:45 --> Router Class Initialized
INFO - 2016-12-03 02:23:45 --> Output Class Initialized
INFO - 2016-12-03 02:23:45 --> Security Class Initialized
DEBUG - 2016-12-03 02:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:23:45 --> Input Class Initialized
INFO - 2016-12-03 02:23:45 --> Language Class Initialized
INFO - 2016-12-03 02:23:45 --> Loader Class Initialized
INFO - 2016-12-03 02:23:45 --> Database Driver Class Initialized
INFO - 2016-12-03 02:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:23:45 --> Controller Class Initialized
INFO - 2016-12-03 02:23:45 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:23:46 --> Config Class Initialized
INFO - 2016-12-03 02:23:46 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:23:46 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:23:46 --> Utf8 Class Initialized
INFO - 2016-12-03 02:23:46 --> URI Class Initialized
INFO - 2016-12-03 02:23:46 --> Router Class Initialized
INFO - 2016-12-03 02:23:46 --> Output Class Initialized
INFO - 2016-12-03 02:23:46 --> Security Class Initialized
DEBUG - 2016-12-03 02:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:23:46 --> Input Class Initialized
INFO - 2016-12-03 02:23:46 --> Language Class Initialized
INFO - 2016-12-03 02:23:46 --> Loader Class Initialized
INFO - 2016-12-03 02:23:46 --> Database Driver Class Initialized
INFO - 2016-12-03 02:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:23:46 --> Controller Class Initialized
DEBUG - 2016-12-03 02:23:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:23:46 --> Helper loaded: url_helper
INFO - 2016-12-03 02:23:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:23:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 02:23:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-03 02:23:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-03 02:23:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:23:46 --> Final output sent to browser
DEBUG - 2016-12-03 02:23:46 --> Total execution time: 0.0231
INFO - 2016-12-03 02:23:47 --> Config Class Initialized
INFO - 2016-12-03 02:23:47 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:23:47 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:23:47 --> Utf8 Class Initialized
INFO - 2016-12-03 02:23:47 --> URI Class Initialized
INFO - 2016-12-03 02:23:47 --> Router Class Initialized
INFO - 2016-12-03 02:23:47 --> Output Class Initialized
INFO - 2016-12-03 02:23:47 --> Security Class Initialized
DEBUG - 2016-12-03 02:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:23:47 --> Input Class Initialized
INFO - 2016-12-03 02:23:47 --> Language Class Initialized
INFO - 2016-12-03 02:23:47 --> Loader Class Initialized
INFO - 2016-12-03 02:23:47 --> Database Driver Class Initialized
INFO - 2016-12-03 02:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:23:47 --> Controller Class Initialized
INFO - 2016-12-03 02:23:47 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:23:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:23:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:23:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:23:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:23:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:23:47 --> Final output sent to browser
DEBUG - 2016-12-03 02:23:47 --> Total execution time: 0.0134
INFO - 2016-12-03 02:29:12 --> Config Class Initialized
INFO - 2016-12-03 02:29:12 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:29:12 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:29:12 --> Utf8 Class Initialized
INFO - 2016-12-03 02:29:12 --> URI Class Initialized
INFO - 2016-12-03 02:29:12 --> Router Class Initialized
INFO - 2016-12-03 02:29:12 --> Output Class Initialized
INFO - 2016-12-03 02:29:12 --> Security Class Initialized
DEBUG - 2016-12-03 02:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:29:12 --> Input Class Initialized
INFO - 2016-12-03 02:29:12 --> Language Class Initialized
INFO - 2016-12-03 02:29:12 --> Loader Class Initialized
INFO - 2016-12-03 02:29:12 --> Database Driver Class Initialized
INFO - 2016-12-03 02:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:29:12 --> Controller Class Initialized
DEBUG - 2016-12-03 02:29:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:29:12 --> Helper loaded: url_helper
INFO - 2016-12-03 02:29:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:29:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 02:29:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-03 02:29:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-03 02:29:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:29:12 --> Final output sent to browser
DEBUG - 2016-12-03 02:29:12 --> Total execution time: 0.0136
INFO - 2016-12-03 02:29:12 --> Config Class Initialized
INFO - 2016-12-03 02:29:12 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:29:12 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:29:12 --> Utf8 Class Initialized
INFO - 2016-12-03 02:29:12 --> URI Class Initialized
INFO - 2016-12-03 02:29:12 --> Router Class Initialized
INFO - 2016-12-03 02:29:12 --> Output Class Initialized
INFO - 2016-12-03 02:29:12 --> Security Class Initialized
DEBUG - 2016-12-03 02:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:29:12 --> Input Class Initialized
INFO - 2016-12-03 02:29:12 --> Language Class Initialized
INFO - 2016-12-03 02:29:12 --> Loader Class Initialized
INFO - 2016-12-03 02:29:12 --> Database Driver Class Initialized
INFO - 2016-12-03 02:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:29:12 --> Controller Class Initialized
INFO - 2016-12-03 02:29:12 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:29:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:29:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:29:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:29:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:29:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:29:12 --> Final output sent to browser
DEBUG - 2016-12-03 02:29:12 --> Total execution time: 0.0145
INFO - 2016-12-03 02:29:14 --> Config Class Initialized
INFO - 2016-12-03 02:29:14 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:29:14 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:29:14 --> Utf8 Class Initialized
INFO - 2016-12-03 02:29:14 --> URI Class Initialized
INFO - 2016-12-03 02:29:14 --> Router Class Initialized
INFO - 2016-12-03 02:29:14 --> Output Class Initialized
INFO - 2016-12-03 02:29:14 --> Security Class Initialized
DEBUG - 2016-12-03 02:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:29:14 --> Input Class Initialized
INFO - 2016-12-03 02:29:14 --> Language Class Initialized
INFO - 2016-12-03 02:29:14 --> Loader Class Initialized
INFO - 2016-12-03 02:29:14 --> Database Driver Class Initialized
INFO - 2016-12-03 02:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:29:14 --> Controller Class Initialized
DEBUG - 2016-12-03 02:29:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:29:14 --> Helper loaded: url_helper
INFO - 2016-12-03 02:29:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:29:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 02:29:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-03 02:29:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-03 02:29:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:29:14 --> Final output sent to browser
DEBUG - 2016-12-03 02:29:14 --> Total execution time: 0.0135
INFO - 2016-12-03 02:29:14 --> Config Class Initialized
INFO - 2016-12-03 02:29:14 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:29:14 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:29:14 --> Utf8 Class Initialized
INFO - 2016-12-03 02:29:14 --> URI Class Initialized
INFO - 2016-12-03 02:29:14 --> Router Class Initialized
INFO - 2016-12-03 02:29:14 --> Output Class Initialized
INFO - 2016-12-03 02:29:14 --> Security Class Initialized
DEBUG - 2016-12-03 02:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:29:14 --> Input Class Initialized
INFO - 2016-12-03 02:29:14 --> Language Class Initialized
INFO - 2016-12-03 02:29:14 --> Loader Class Initialized
INFO - 2016-12-03 02:29:14 --> Database Driver Class Initialized
INFO - 2016-12-03 02:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:29:14 --> Controller Class Initialized
INFO - 2016-12-03 02:29:14 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:29:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:29:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:29:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:29:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:29:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:29:14 --> Final output sent to browser
DEBUG - 2016-12-03 02:29:14 --> Total execution time: 0.0135
INFO - 2016-12-03 02:29:17 --> Config Class Initialized
INFO - 2016-12-03 02:29:17 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:29:17 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:29:17 --> Utf8 Class Initialized
INFO - 2016-12-03 02:29:17 --> URI Class Initialized
INFO - 2016-12-03 02:29:17 --> Router Class Initialized
INFO - 2016-12-03 02:29:17 --> Output Class Initialized
INFO - 2016-12-03 02:29:17 --> Security Class Initialized
DEBUG - 2016-12-03 02:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:29:17 --> Input Class Initialized
INFO - 2016-12-03 02:29:17 --> Language Class Initialized
ERROR - 2016-12-03 02:29:17 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 02:30:16 --> Config Class Initialized
INFO - 2016-12-03 02:30:16 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:30:16 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:30:16 --> Utf8 Class Initialized
INFO - 2016-12-03 02:30:16 --> URI Class Initialized
INFO - 2016-12-03 02:30:16 --> Router Class Initialized
INFO - 2016-12-03 02:30:16 --> Output Class Initialized
INFO - 2016-12-03 02:30:16 --> Security Class Initialized
DEBUG - 2016-12-03 02:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:30:16 --> Input Class Initialized
INFO - 2016-12-03 02:30:16 --> Language Class Initialized
INFO - 2016-12-03 02:30:16 --> Loader Class Initialized
INFO - 2016-12-03 02:30:16 --> Database Driver Class Initialized
INFO - 2016-12-03 02:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:30:16 --> Controller Class Initialized
DEBUG - 2016-12-03 02:30:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:30:16 --> Helper loaded: url_helper
INFO - 2016-12-03 02:30:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:30:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 02:30:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-03 02:30:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-03 02:30:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:30:16 --> Final output sent to browser
DEBUG - 2016-12-03 02:30:16 --> Total execution time: 0.0399
INFO - 2016-12-03 02:30:17 --> Config Class Initialized
INFO - 2016-12-03 02:30:17 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:30:17 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:30:17 --> Utf8 Class Initialized
INFO - 2016-12-03 02:30:17 --> URI Class Initialized
INFO - 2016-12-03 02:30:17 --> Router Class Initialized
INFO - 2016-12-03 02:30:17 --> Output Class Initialized
INFO - 2016-12-03 02:30:17 --> Security Class Initialized
DEBUG - 2016-12-03 02:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:30:17 --> Input Class Initialized
INFO - 2016-12-03 02:30:17 --> Language Class Initialized
ERROR - 2016-12-03 02:30:17 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 02:30:17 --> Config Class Initialized
INFO - 2016-12-03 02:30:17 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:30:17 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:30:17 --> Utf8 Class Initialized
INFO - 2016-12-03 02:30:17 --> URI Class Initialized
INFO - 2016-12-03 02:30:17 --> Router Class Initialized
INFO - 2016-12-03 02:30:17 --> Output Class Initialized
INFO - 2016-12-03 02:30:17 --> Security Class Initialized
DEBUG - 2016-12-03 02:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:30:17 --> Input Class Initialized
INFO - 2016-12-03 02:30:17 --> Language Class Initialized
INFO - 2016-12-03 02:30:17 --> Loader Class Initialized
INFO - 2016-12-03 02:30:17 --> Database Driver Class Initialized
INFO - 2016-12-03 02:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:30:17 --> Controller Class Initialized
INFO - 2016-12-03 02:30:17 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:30:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:30:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:30:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:30:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:30:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:30:17 --> Final output sent to browser
DEBUG - 2016-12-03 02:30:17 --> Total execution time: 0.0152
INFO - 2016-12-03 02:31:30 --> Config Class Initialized
INFO - 2016-12-03 02:31:30 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:31:30 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:31:30 --> Utf8 Class Initialized
INFO - 2016-12-03 02:31:30 --> URI Class Initialized
INFO - 2016-12-03 02:31:30 --> Router Class Initialized
INFO - 2016-12-03 02:31:30 --> Output Class Initialized
INFO - 2016-12-03 02:31:30 --> Security Class Initialized
DEBUG - 2016-12-03 02:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:31:30 --> Input Class Initialized
INFO - 2016-12-03 02:31:30 --> Language Class Initialized
INFO - 2016-12-03 02:31:30 --> Loader Class Initialized
INFO - 2016-12-03 02:31:30 --> Database Driver Class Initialized
INFO - 2016-12-03 02:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:31:30 --> Controller Class Initialized
DEBUG - 2016-12-03 02:31:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:31:30 --> Helper loaded: url_helper
INFO - 2016-12-03 02:31:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:31:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 02:31:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 02:31:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 02:31:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:31:30 --> Final output sent to browser
DEBUG - 2016-12-03 02:31:30 --> Total execution time: 0.1993
INFO - 2016-12-03 02:31:31 --> Config Class Initialized
INFO - 2016-12-03 02:31:31 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:31:31 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:31:31 --> Utf8 Class Initialized
INFO - 2016-12-03 02:31:31 --> URI Class Initialized
INFO - 2016-12-03 02:31:31 --> Router Class Initialized
INFO - 2016-12-03 02:31:31 --> Output Class Initialized
INFO - 2016-12-03 02:31:31 --> Security Class Initialized
DEBUG - 2016-12-03 02:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:31:31 --> Input Class Initialized
INFO - 2016-12-03 02:31:31 --> Language Class Initialized
ERROR - 2016-12-03 02:31:31 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 02:31:31 --> Config Class Initialized
INFO - 2016-12-03 02:31:31 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:31:31 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:31:31 --> Utf8 Class Initialized
INFO - 2016-12-03 02:31:31 --> URI Class Initialized
INFO - 2016-12-03 02:31:31 --> Router Class Initialized
INFO - 2016-12-03 02:31:31 --> Output Class Initialized
INFO - 2016-12-03 02:31:31 --> Security Class Initialized
DEBUG - 2016-12-03 02:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:31:31 --> Input Class Initialized
INFO - 2016-12-03 02:31:31 --> Language Class Initialized
INFO - 2016-12-03 02:31:31 --> Loader Class Initialized
INFO - 2016-12-03 02:31:31 --> Database Driver Class Initialized
INFO - 2016-12-03 02:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:31:31 --> Controller Class Initialized
INFO - 2016-12-03 02:31:31 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:31:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:31:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:31:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:31:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:31:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:31:31 --> Final output sent to browser
DEBUG - 2016-12-03 02:31:31 --> Total execution time: 0.0132
INFO - 2016-12-03 02:32:42 --> Config Class Initialized
INFO - 2016-12-03 02:32:42 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:32:42 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:32:42 --> Utf8 Class Initialized
INFO - 2016-12-03 02:32:42 --> URI Class Initialized
INFO - 2016-12-03 02:32:42 --> Router Class Initialized
INFO - 2016-12-03 02:32:42 --> Output Class Initialized
INFO - 2016-12-03 02:32:42 --> Security Class Initialized
DEBUG - 2016-12-03 02:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:32:42 --> Input Class Initialized
INFO - 2016-12-03 02:32:42 --> Language Class Initialized
INFO - 2016-12-03 02:32:42 --> Loader Class Initialized
INFO - 2016-12-03 02:32:42 --> Database Driver Class Initialized
INFO - 2016-12-03 02:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:32:42 --> Controller Class Initialized
DEBUG - 2016-12-03 02:32:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:32:42 --> Helper loaded: url_helper
INFO - 2016-12-03 02:32:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:32:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 02:32:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 02:32:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 02:32:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:32:42 --> Final output sent to browser
DEBUG - 2016-12-03 02:32:42 --> Total execution time: 0.0434
INFO - 2016-12-03 02:32:42 --> Config Class Initialized
INFO - 2016-12-03 02:32:42 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:32:42 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:32:42 --> Utf8 Class Initialized
INFO - 2016-12-03 02:32:42 --> URI Class Initialized
INFO - 2016-12-03 02:32:42 --> Router Class Initialized
INFO - 2016-12-03 02:32:42 --> Output Class Initialized
INFO - 2016-12-03 02:32:42 --> Security Class Initialized
DEBUG - 2016-12-03 02:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:32:42 --> Input Class Initialized
INFO - 2016-12-03 02:32:42 --> Language Class Initialized
ERROR - 2016-12-03 02:32:42 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 02:32:42 --> Config Class Initialized
INFO - 2016-12-03 02:32:42 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:32:42 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:32:42 --> Utf8 Class Initialized
INFO - 2016-12-03 02:32:42 --> URI Class Initialized
INFO - 2016-12-03 02:32:42 --> Router Class Initialized
INFO - 2016-12-03 02:32:42 --> Output Class Initialized
INFO - 2016-12-03 02:32:42 --> Security Class Initialized
DEBUG - 2016-12-03 02:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:32:42 --> Input Class Initialized
INFO - 2016-12-03 02:32:42 --> Language Class Initialized
INFO - 2016-12-03 02:32:42 --> Loader Class Initialized
INFO - 2016-12-03 02:32:42 --> Database Driver Class Initialized
INFO - 2016-12-03 02:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:32:42 --> Controller Class Initialized
INFO - 2016-12-03 02:32:42 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:32:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:32:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:32:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:32:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:32:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:32:42 --> Final output sent to browser
DEBUG - 2016-12-03 02:32:42 --> Total execution time: 0.0131
INFO - 2016-12-03 02:36:04 --> Config Class Initialized
INFO - 2016-12-03 02:36:04 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:36:04 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:36:04 --> Utf8 Class Initialized
INFO - 2016-12-03 02:36:04 --> URI Class Initialized
INFO - 2016-12-03 02:36:04 --> Router Class Initialized
INFO - 2016-12-03 02:36:04 --> Output Class Initialized
INFO - 2016-12-03 02:36:04 --> Security Class Initialized
DEBUG - 2016-12-03 02:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:36:04 --> Input Class Initialized
INFO - 2016-12-03 02:36:04 --> Language Class Initialized
INFO - 2016-12-03 02:36:04 --> Loader Class Initialized
INFO - 2016-12-03 02:36:04 --> Database Driver Class Initialized
INFO - 2016-12-03 02:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:36:04 --> Controller Class Initialized
DEBUG - 2016-12-03 02:36:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:36:04 --> Helper loaded: url_helper
INFO - 2016-12-03 02:36:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:36:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 02:36:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 02:36:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 02:36:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:36:04 --> Final output sent to browser
DEBUG - 2016-12-03 02:36:04 --> Total execution time: 0.0152
INFO - 2016-12-03 02:36:05 --> Config Class Initialized
INFO - 2016-12-03 02:36:05 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:36:05 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:36:05 --> Utf8 Class Initialized
INFO - 2016-12-03 02:36:05 --> URI Class Initialized
INFO - 2016-12-03 02:36:05 --> Router Class Initialized
INFO - 2016-12-03 02:36:05 --> Output Class Initialized
INFO - 2016-12-03 02:36:05 --> Security Class Initialized
DEBUG - 2016-12-03 02:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:36:05 --> Input Class Initialized
INFO - 2016-12-03 02:36:05 --> Language Class Initialized
ERROR - 2016-12-03 02:36:05 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 02:36:05 --> Config Class Initialized
INFO - 2016-12-03 02:36:05 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:36:05 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:36:05 --> Utf8 Class Initialized
INFO - 2016-12-03 02:36:05 --> URI Class Initialized
INFO - 2016-12-03 02:36:05 --> Router Class Initialized
INFO - 2016-12-03 02:36:05 --> Output Class Initialized
INFO - 2016-12-03 02:36:05 --> Security Class Initialized
DEBUG - 2016-12-03 02:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:36:05 --> Input Class Initialized
INFO - 2016-12-03 02:36:05 --> Language Class Initialized
INFO - 2016-12-03 02:36:05 --> Loader Class Initialized
INFO - 2016-12-03 02:36:05 --> Database Driver Class Initialized
INFO - 2016-12-03 02:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:36:05 --> Controller Class Initialized
INFO - 2016-12-03 02:36:05 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:36:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:36:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:36:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:36:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:36:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:36:05 --> Final output sent to browser
DEBUG - 2016-12-03 02:36:05 --> Total execution time: 0.0135
INFO - 2016-12-03 02:39:59 --> Config Class Initialized
INFO - 2016-12-03 02:39:59 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:39:59 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:39:59 --> Utf8 Class Initialized
INFO - 2016-12-03 02:39:59 --> URI Class Initialized
INFO - 2016-12-03 02:39:59 --> Router Class Initialized
INFO - 2016-12-03 02:39:59 --> Output Class Initialized
INFO - 2016-12-03 02:39:59 --> Security Class Initialized
DEBUG - 2016-12-03 02:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:39:59 --> Input Class Initialized
INFO - 2016-12-03 02:39:59 --> Language Class Initialized
INFO - 2016-12-03 02:39:59 --> Loader Class Initialized
INFO - 2016-12-03 02:39:59 --> Database Driver Class Initialized
INFO - 2016-12-03 02:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:39:59 --> Controller Class Initialized
INFO - 2016-12-03 02:39:59 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:39:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:39:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:39:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:39:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:39:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:39:59 --> Final output sent to browser
DEBUG - 2016-12-03 02:39:59 --> Total execution time: 0.0133
INFO - 2016-12-03 02:40:52 --> Config Class Initialized
INFO - 2016-12-03 02:40:52 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:40:52 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:40:52 --> Utf8 Class Initialized
INFO - 2016-12-03 02:40:52 --> URI Class Initialized
INFO - 2016-12-03 02:40:52 --> Router Class Initialized
INFO - 2016-12-03 02:40:52 --> Output Class Initialized
INFO - 2016-12-03 02:40:52 --> Security Class Initialized
DEBUG - 2016-12-03 02:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:40:52 --> Input Class Initialized
INFO - 2016-12-03 02:40:52 --> Language Class Initialized
INFO - 2016-12-03 02:40:52 --> Loader Class Initialized
INFO - 2016-12-03 02:40:52 --> Database Driver Class Initialized
INFO - 2016-12-03 02:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:40:52 --> Controller Class Initialized
DEBUG - 2016-12-03 02:40:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:40:52 --> Helper loaded: url_helper
INFO - 2016-12-03 02:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 02:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 02:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 02:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:40:52 --> Final output sent to browser
DEBUG - 2016-12-03 02:40:52 --> Total execution time: 0.0149
INFO - 2016-12-03 02:40:52 --> Config Class Initialized
INFO - 2016-12-03 02:40:52 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:40:52 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:40:52 --> Utf8 Class Initialized
INFO - 2016-12-03 02:40:52 --> URI Class Initialized
INFO - 2016-12-03 02:40:52 --> Router Class Initialized
INFO - 2016-12-03 02:40:52 --> Output Class Initialized
INFO - 2016-12-03 02:40:52 --> Security Class Initialized
DEBUG - 2016-12-03 02:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:40:52 --> Input Class Initialized
INFO - 2016-12-03 02:40:52 --> Language Class Initialized
ERROR - 2016-12-03 02:40:52 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 02:40:52 --> Config Class Initialized
INFO - 2016-12-03 02:40:52 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:40:52 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:40:52 --> Utf8 Class Initialized
INFO - 2016-12-03 02:40:52 --> URI Class Initialized
INFO - 2016-12-03 02:40:52 --> Router Class Initialized
INFO - 2016-12-03 02:40:52 --> Output Class Initialized
INFO - 2016-12-03 02:40:52 --> Security Class Initialized
DEBUG - 2016-12-03 02:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:40:52 --> Input Class Initialized
INFO - 2016-12-03 02:40:52 --> Language Class Initialized
INFO - 2016-12-03 02:40:52 --> Loader Class Initialized
INFO - 2016-12-03 02:40:52 --> Database Driver Class Initialized
INFO - 2016-12-03 02:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:40:52 --> Controller Class Initialized
INFO - 2016-12-03 02:40:52 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:40:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:40:52 --> Final output sent to browser
DEBUG - 2016-12-03 02:40:52 --> Total execution time: 0.0130
INFO - 2016-12-03 02:41:24 --> Config Class Initialized
INFO - 2016-12-03 02:41:24 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:41:24 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:41:24 --> Utf8 Class Initialized
INFO - 2016-12-03 02:41:24 --> URI Class Initialized
INFO - 2016-12-03 02:41:24 --> Router Class Initialized
INFO - 2016-12-03 02:41:24 --> Output Class Initialized
INFO - 2016-12-03 02:41:24 --> Security Class Initialized
DEBUG - 2016-12-03 02:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:41:24 --> Input Class Initialized
INFO - 2016-12-03 02:41:24 --> Language Class Initialized
INFO - 2016-12-03 02:41:24 --> Loader Class Initialized
INFO - 2016-12-03 02:41:24 --> Database Driver Class Initialized
INFO - 2016-12-03 02:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:41:24 --> Controller Class Initialized
DEBUG - 2016-12-03 02:41:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:41:24 --> Helper loaded: url_helper
INFO - 2016-12-03 02:41:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:41:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 02:41:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 02:41:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 02:41:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:41:24 --> Final output sent to browser
DEBUG - 2016-12-03 02:41:24 --> Total execution time: 0.0153
INFO - 2016-12-03 02:41:24 --> Config Class Initialized
INFO - 2016-12-03 02:41:24 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:41:24 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:41:24 --> Utf8 Class Initialized
INFO - 2016-12-03 02:41:24 --> URI Class Initialized
INFO - 2016-12-03 02:41:24 --> Router Class Initialized
INFO - 2016-12-03 02:41:24 --> Output Class Initialized
INFO - 2016-12-03 02:41:24 --> Security Class Initialized
DEBUG - 2016-12-03 02:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:41:24 --> Input Class Initialized
INFO - 2016-12-03 02:41:24 --> Language Class Initialized
ERROR - 2016-12-03 02:41:24 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 02:41:24 --> Config Class Initialized
INFO - 2016-12-03 02:41:24 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:41:24 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:41:24 --> Utf8 Class Initialized
INFO - 2016-12-03 02:41:24 --> URI Class Initialized
INFO - 2016-12-03 02:41:24 --> Router Class Initialized
INFO - 2016-12-03 02:41:24 --> Output Class Initialized
INFO - 2016-12-03 02:41:24 --> Security Class Initialized
DEBUG - 2016-12-03 02:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:41:24 --> Input Class Initialized
INFO - 2016-12-03 02:41:24 --> Language Class Initialized
INFO - 2016-12-03 02:41:24 --> Loader Class Initialized
INFO - 2016-12-03 02:41:24 --> Database Driver Class Initialized
INFO - 2016-12-03 02:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:41:24 --> Controller Class Initialized
INFO - 2016-12-03 02:41:24 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:41:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:41:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:41:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:41:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:41:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:41:24 --> Final output sent to browser
DEBUG - 2016-12-03 02:41:24 --> Total execution time: 0.0137
INFO - 2016-12-03 02:41:39 --> Config Class Initialized
INFO - 2016-12-03 02:41:39 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:41:39 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:41:39 --> Utf8 Class Initialized
INFO - 2016-12-03 02:41:39 --> URI Class Initialized
INFO - 2016-12-03 02:41:39 --> Router Class Initialized
INFO - 2016-12-03 02:41:39 --> Output Class Initialized
INFO - 2016-12-03 02:41:39 --> Security Class Initialized
DEBUG - 2016-12-03 02:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:41:39 --> Input Class Initialized
INFO - 2016-12-03 02:41:39 --> Language Class Initialized
INFO - 2016-12-03 02:41:39 --> Loader Class Initialized
INFO - 2016-12-03 02:41:39 --> Database Driver Class Initialized
INFO - 2016-12-03 02:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:41:39 --> Controller Class Initialized
DEBUG - 2016-12-03 02:41:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:41:39 --> Helper loaded: url_helper
INFO - 2016-12-03 02:41:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:41:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 02:41:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 02:41:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 02:41:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:41:39 --> Final output sent to browser
DEBUG - 2016-12-03 02:41:39 --> Total execution time: 0.0224
INFO - 2016-12-03 02:41:39 --> Config Class Initialized
INFO - 2016-12-03 02:41:39 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:41:39 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:41:39 --> Utf8 Class Initialized
INFO - 2016-12-03 02:41:39 --> URI Class Initialized
INFO - 2016-12-03 02:41:39 --> Router Class Initialized
INFO - 2016-12-03 02:41:39 --> Output Class Initialized
INFO - 2016-12-03 02:41:39 --> Security Class Initialized
DEBUG - 2016-12-03 02:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:41:39 --> Input Class Initialized
INFO - 2016-12-03 02:41:39 --> Language Class Initialized
ERROR - 2016-12-03 02:41:39 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 02:41:39 --> Config Class Initialized
INFO - 2016-12-03 02:41:39 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:41:39 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:41:39 --> Utf8 Class Initialized
INFO - 2016-12-03 02:41:39 --> URI Class Initialized
INFO - 2016-12-03 02:41:39 --> Router Class Initialized
INFO - 2016-12-03 02:41:39 --> Output Class Initialized
INFO - 2016-12-03 02:41:39 --> Security Class Initialized
DEBUG - 2016-12-03 02:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:41:39 --> Input Class Initialized
INFO - 2016-12-03 02:41:39 --> Language Class Initialized
INFO - 2016-12-03 02:41:39 --> Loader Class Initialized
INFO - 2016-12-03 02:41:39 --> Database Driver Class Initialized
INFO - 2016-12-03 02:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:41:39 --> Controller Class Initialized
INFO - 2016-12-03 02:41:39 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:41:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:41:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:41:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:41:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:41:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:41:39 --> Final output sent to browser
DEBUG - 2016-12-03 02:41:39 --> Total execution time: 0.0139
INFO - 2016-12-03 02:46:04 --> Config Class Initialized
INFO - 2016-12-03 02:46:04 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:46:04 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:46:04 --> Utf8 Class Initialized
INFO - 2016-12-03 02:46:04 --> URI Class Initialized
INFO - 2016-12-03 02:46:04 --> Router Class Initialized
INFO - 2016-12-03 02:46:04 --> Output Class Initialized
INFO - 2016-12-03 02:46:04 --> Security Class Initialized
DEBUG - 2016-12-03 02:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:46:04 --> Input Class Initialized
INFO - 2016-12-03 02:46:04 --> Language Class Initialized
INFO - 2016-12-03 02:46:04 --> Loader Class Initialized
INFO - 2016-12-03 02:46:04 --> Database Driver Class Initialized
INFO - 2016-12-03 02:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:46:04 --> Controller Class Initialized
DEBUG - 2016-12-03 02:46:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:46:04 --> Helper loaded: url_helper
INFO - 2016-12-03 02:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 02:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 02:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 02:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:46:04 --> Final output sent to browser
DEBUG - 2016-12-03 02:46:04 --> Total execution time: 0.0152
INFO - 2016-12-03 02:46:04 --> Config Class Initialized
INFO - 2016-12-03 02:46:04 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:46:04 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:46:04 --> Utf8 Class Initialized
INFO - 2016-12-03 02:46:04 --> URI Class Initialized
INFO - 2016-12-03 02:46:04 --> Router Class Initialized
INFO - 2016-12-03 02:46:04 --> Output Class Initialized
INFO - 2016-12-03 02:46:04 --> Security Class Initialized
DEBUG - 2016-12-03 02:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:46:04 --> Input Class Initialized
INFO - 2016-12-03 02:46:04 --> Language Class Initialized
ERROR - 2016-12-03 02:46:04 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 02:46:04 --> Config Class Initialized
INFO - 2016-12-03 02:46:04 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:46:04 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:46:04 --> Utf8 Class Initialized
INFO - 2016-12-03 02:46:04 --> URI Class Initialized
INFO - 2016-12-03 02:46:04 --> Router Class Initialized
INFO - 2016-12-03 02:46:04 --> Output Class Initialized
INFO - 2016-12-03 02:46:04 --> Security Class Initialized
DEBUG - 2016-12-03 02:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:46:04 --> Input Class Initialized
INFO - 2016-12-03 02:46:04 --> Language Class Initialized
INFO - 2016-12-03 02:46:04 --> Loader Class Initialized
INFO - 2016-12-03 02:46:04 --> Database Driver Class Initialized
INFO - 2016-12-03 02:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:46:04 --> Controller Class Initialized
INFO - 2016-12-03 02:46:04 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:46:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:46:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:46:04 --> Final output sent to browser
DEBUG - 2016-12-03 02:46:04 --> Total execution time: 0.0158
INFO - 2016-12-03 02:51:26 --> Config Class Initialized
INFO - 2016-12-03 02:51:26 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:51:26 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:51:26 --> Utf8 Class Initialized
INFO - 2016-12-03 02:51:26 --> URI Class Initialized
INFO - 2016-12-03 02:51:26 --> Router Class Initialized
INFO - 2016-12-03 02:51:26 --> Output Class Initialized
INFO - 2016-12-03 02:51:26 --> Security Class Initialized
DEBUG - 2016-12-03 02:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:51:26 --> Input Class Initialized
INFO - 2016-12-03 02:51:26 --> Language Class Initialized
INFO - 2016-12-03 02:51:26 --> Loader Class Initialized
INFO - 2016-12-03 02:51:26 --> Database Driver Class Initialized
INFO - 2016-12-03 02:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:51:26 --> Controller Class Initialized
DEBUG - 2016-12-03 02:51:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:51:26 --> Helper loaded: url_helper
INFO - 2016-12-03 02:51:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:51:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 02:51:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 02:51:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 02:51:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:51:26 --> Final output sent to browser
DEBUG - 2016-12-03 02:51:26 --> Total execution time: 0.2416
INFO - 2016-12-03 02:51:27 --> Config Class Initialized
INFO - 2016-12-03 02:51:27 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:51:27 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:51:27 --> Utf8 Class Initialized
INFO - 2016-12-03 02:51:27 --> URI Class Initialized
INFO - 2016-12-03 02:51:27 --> Router Class Initialized
INFO - 2016-12-03 02:51:27 --> Output Class Initialized
INFO - 2016-12-03 02:51:27 --> Security Class Initialized
DEBUG - 2016-12-03 02:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:51:27 --> Input Class Initialized
INFO - 2016-12-03 02:51:27 --> Language Class Initialized
ERROR - 2016-12-03 02:51:27 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 02:51:27 --> Config Class Initialized
INFO - 2016-12-03 02:51:27 --> Hooks Class Initialized
DEBUG - 2016-12-03 02:51:27 --> UTF-8 Support Enabled
INFO - 2016-12-03 02:51:27 --> Utf8 Class Initialized
INFO - 2016-12-03 02:51:27 --> URI Class Initialized
INFO - 2016-12-03 02:51:27 --> Router Class Initialized
INFO - 2016-12-03 02:51:27 --> Output Class Initialized
INFO - 2016-12-03 02:51:27 --> Security Class Initialized
DEBUG - 2016-12-03 02:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 02:51:27 --> Input Class Initialized
INFO - 2016-12-03 02:51:27 --> Language Class Initialized
INFO - 2016-12-03 02:51:27 --> Loader Class Initialized
INFO - 2016-12-03 02:51:27 --> Database Driver Class Initialized
INFO - 2016-12-03 02:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 02:51:27 --> Controller Class Initialized
INFO - 2016-12-03 02:51:27 --> Helper loaded: url_helper
DEBUG - 2016-12-03 02:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 02:51:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 02:51:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 02:51:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 02:51:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 02:51:27 --> Final output sent to browser
DEBUG - 2016-12-03 02:51:27 --> Total execution time: 0.0132
INFO - 2016-12-03 03:22:40 --> Config Class Initialized
INFO - 2016-12-03 03:22:40 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:22:40 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:22:40 --> Utf8 Class Initialized
INFO - 2016-12-03 03:22:40 --> URI Class Initialized
INFO - 2016-12-03 03:22:40 --> Router Class Initialized
INFO - 2016-12-03 03:22:40 --> Output Class Initialized
INFO - 2016-12-03 03:22:40 --> Security Class Initialized
DEBUG - 2016-12-03 03:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:22:40 --> Input Class Initialized
INFO - 2016-12-03 03:22:40 --> Language Class Initialized
INFO - 2016-12-03 03:22:40 --> Loader Class Initialized
INFO - 2016-12-03 03:22:40 --> Database Driver Class Initialized
INFO - 2016-12-03 03:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:22:40 --> Controller Class Initialized
INFO - 2016-12-03 03:22:40 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:22:40 --> Helper loaded: form_helper
INFO - 2016-12-03 03:22:40 --> Form Validation Class Initialized
INFO - 2016-12-03 03:22:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-03 03:22:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2016-12-03 03:22:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-03 03:22:40 --> Final output sent to browser
DEBUG - 2016-12-03 03:22:40 --> Total execution time: 0.0599
INFO - 2016-12-03 03:22:40 --> Config Class Initialized
INFO - 2016-12-03 03:22:40 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:22:40 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:22:40 --> Utf8 Class Initialized
INFO - 2016-12-03 03:22:40 --> URI Class Initialized
INFO - 2016-12-03 03:22:40 --> Router Class Initialized
INFO - 2016-12-03 03:22:40 --> Output Class Initialized
INFO - 2016-12-03 03:22:40 --> Security Class Initialized
DEBUG - 2016-12-03 03:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:22:40 --> Input Class Initialized
INFO - 2016-12-03 03:22:40 --> Language Class Initialized
INFO - 2016-12-03 03:22:40 --> Loader Class Initialized
INFO - 2016-12-03 03:22:40 --> Database Driver Class Initialized
INFO - 2016-12-03 03:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:22:40 --> Controller Class Initialized
INFO - 2016-12-03 03:22:40 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:22:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:22:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 03:22:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 03:22:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:22:40 --> Final output sent to browser
DEBUG - 2016-12-03 03:22:40 --> Total execution time: 0.0160
INFO - 2016-12-03 03:22:45 --> Config Class Initialized
INFO - 2016-12-03 03:22:45 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:22:45 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:22:45 --> Utf8 Class Initialized
INFO - 2016-12-03 03:22:45 --> URI Class Initialized
INFO - 2016-12-03 03:22:45 --> Router Class Initialized
INFO - 2016-12-03 03:22:45 --> Output Class Initialized
INFO - 2016-12-03 03:22:45 --> Security Class Initialized
DEBUG - 2016-12-03 03:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:22:45 --> Input Class Initialized
INFO - 2016-12-03 03:22:45 --> Language Class Initialized
INFO - 2016-12-03 03:22:46 --> Loader Class Initialized
INFO - 2016-12-03 03:22:46 --> Database Driver Class Initialized
INFO - 2016-12-03 03:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:22:46 --> Controller Class Initialized
INFO - 2016-12-03 03:22:46 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:22:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:22:46 --> Helper loaded: form_helper
INFO - 2016-12-03 03:22:46 --> Form Validation Class Initialized
INFO - 2016-12-03 03:22:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-03 03:22:46 --> Config Class Initialized
INFO - 2016-12-03 03:22:46 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:22:46 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:22:46 --> Utf8 Class Initialized
INFO - 2016-12-03 03:22:46 --> URI Class Initialized
INFO - 2016-12-03 03:22:46 --> Router Class Initialized
INFO - 2016-12-03 03:22:46 --> Output Class Initialized
INFO - 2016-12-03 03:22:46 --> Security Class Initialized
DEBUG - 2016-12-03 03:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:22:46 --> Input Class Initialized
INFO - 2016-12-03 03:22:46 --> Language Class Initialized
INFO - 2016-12-03 03:22:46 --> Loader Class Initialized
INFO - 2016-12-03 03:22:46 --> Database Driver Class Initialized
INFO - 2016-12-03 03:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:22:46 --> Controller Class Initialized
ERROR - 2016-12-03 03:22:46 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /home/graduafe/public_html/application/models/Graduacion_modelo.php 53
INFO - 2016-12-03 03:22:46 --> Config Class Initialized
INFO - 2016-12-03 03:22:46 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:22:46 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:22:46 --> Utf8 Class Initialized
INFO - 2016-12-03 03:22:46 --> URI Class Initialized
INFO - 2016-12-03 03:22:46 --> Router Class Initialized
INFO - 2016-12-03 03:22:46 --> Output Class Initialized
INFO - 2016-12-03 03:22:46 --> Security Class Initialized
DEBUG - 2016-12-03 03:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:22:46 --> Input Class Initialized
INFO - 2016-12-03 03:22:46 --> Language Class Initialized
INFO - 2016-12-03 03:22:46 --> Loader Class Initialized
INFO - 2016-12-03 03:22:46 --> Database Driver Class Initialized
INFO - 2016-12-03 03:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:22:46 --> Controller Class Initialized
INFO - 2016-12-03 03:22:46 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:22:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:22:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:22:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 03:22:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 03:22:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:22:46 --> Final output sent to browser
DEBUG - 2016-12-03 03:22:46 --> Total execution time: 0.0137
INFO - 2016-12-03 03:23:58 --> Config Class Initialized
INFO - 2016-12-03 03:23:58 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:23:58 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:23:58 --> Utf8 Class Initialized
INFO - 2016-12-03 03:23:58 --> URI Class Initialized
INFO - 2016-12-03 03:23:58 --> Router Class Initialized
INFO - 2016-12-03 03:23:58 --> Output Class Initialized
INFO - 2016-12-03 03:23:58 --> Security Class Initialized
DEBUG - 2016-12-03 03:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:23:58 --> Input Class Initialized
INFO - 2016-12-03 03:23:58 --> Language Class Initialized
INFO - 2016-12-03 03:23:58 --> Loader Class Initialized
INFO - 2016-12-03 03:23:58 --> Database Driver Class Initialized
INFO - 2016-12-03 03:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:23:58 --> Controller Class Initialized
INFO - 2016-12-03 03:23:58 --> Helper loaded: date_helper
INFO - 2016-12-03 03:23:58 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:23:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:23:58 --> Helper loaded: form_helper
INFO - 2016-12-03 03:23:58 --> Form Validation Class Initialized
INFO - 2016-12-03 03:23:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-03 03:23:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-03 03:23:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2016-12-03 03:23:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2016-12-03 03:23:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-03 03:23:58 --> Final output sent to browser
DEBUG - 2016-12-03 03:23:58 --> Total execution time: 0.1245
INFO - 2016-12-03 03:23:59 --> Config Class Initialized
INFO - 2016-12-03 03:23:59 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:23:59 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:23:59 --> Utf8 Class Initialized
INFO - 2016-12-03 03:23:59 --> URI Class Initialized
INFO - 2016-12-03 03:23:59 --> Router Class Initialized
INFO - 2016-12-03 03:23:59 --> Output Class Initialized
INFO - 2016-12-03 03:23:59 --> Security Class Initialized
DEBUG - 2016-12-03 03:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:23:59 --> Input Class Initialized
INFO - 2016-12-03 03:23:59 --> Language Class Initialized
INFO - 2016-12-03 03:23:59 --> Loader Class Initialized
INFO - 2016-12-03 03:23:59 --> Database Driver Class Initialized
INFO - 2016-12-03 03:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:23:59 --> Controller Class Initialized
INFO - 2016-12-03 03:23:59 --> Helper loaded: date_helper
INFO - 2016-12-03 03:23:59 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:23:59 --> Helper loaded: form_helper
INFO - 2016-12-03 03:23:59 --> Form Validation Class Initialized
INFO - 2016-12-03 03:23:59 --> Final output sent to browser
DEBUG - 2016-12-03 03:23:59 --> Total execution time: 0.0261
INFO - 2016-12-03 03:23:59 --> Config Class Initialized
INFO - 2016-12-03 03:23:59 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:23:59 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:23:59 --> Utf8 Class Initialized
INFO - 2016-12-03 03:23:59 --> URI Class Initialized
INFO - 2016-12-03 03:23:59 --> Router Class Initialized
INFO - 2016-12-03 03:23:59 --> Output Class Initialized
INFO - 2016-12-03 03:23:59 --> Security Class Initialized
DEBUG - 2016-12-03 03:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:23:59 --> Input Class Initialized
INFO - 2016-12-03 03:23:59 --> Language Class Initialized
INFO - 2016-12-03 03:23:59 --> Loader Class Initialized
INFO - 2016-12-03 03:23:59 --> Database Driver Class Initialized
INFO - 2016-12-03 03:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:23:59 --> Controller Class Initialized
INFO - 2016-12-03 03:23:59 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:23:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:23:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 03:23:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 03:23:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:23:59 --> Final output sent to browser
DEBUG - 2016-12-03 03:23:59 --> Total execution time: 0.0127
INFO - 2016-12-03 03:26:21 --> Config Class Initialized
INFO - 2016-12-03 03:26:21 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:26:21 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:26:21 --> Utf8 Class Initialized
INFO - 2016-12-03 03:26:21 --> URI Class Initialized
INFO - 2016-12-03 03:26:21 --> Router Class Initialized
INFO - 2016-12-03 03:26:21 --> Output Class Initialized
INFO - 2016-12-03 03:26:21 --> Security Class Initialized
DEBUG - 2016-12-03 03:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:26:21 --> Input Class Initialized
INFO - 2016-12-03 03:26:21 --> Language Class Initialized
INFO - 2016-12-03 03:26:21 --> Loader Class Initialized
INFO - 2016-12-03 03:26:21 --> Database Driver Class Initialized
INFO - 2016-12-03 03:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:26:21 --> Controller Class Initialized
ERROR - 2016-12-03 03:26:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/models/Graduacion_modelo.php:60) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-03 03:26:21 --> Severity: Compile Error --> Cannot redeclare Graduacion_modelo::obtener_layout() /home/graduafe/public_html/application/models/Graduacion_modelo.php 60
INFO - 2016-12-03 03:26:21 --> Config Class Initialized
INFO - 2016-12-03 03:26:21 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:26:21 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:26:21 --> Utf8 Class Initialized
INFO - 2016-12-03 03:26:21 --> URI Class Initialized
INFO - 2016-12-03 03:26:21 --> Router Class Initialized
INFO - 2016-12-03 03:26:21 --> Output Class Initialized
INFO - 2016-12-03 03:26:21 --> Security Class Initialized
DEBUG - 2016-12-03 03:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:26:21 --> Input Class Initialized
INFO - 2016-12-03 03:26:21 --> Language Class Initialized
INFO - 2016-12-03 03:26:21 --> Loader Class Initialized
INFO - 2016-12-03 03:26:21 --> Database Driver Class Initialized
INFO - 2016-12-03 03:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:26:21 --> Controller Class Initialized
INFO - 2016-12-03 03:26:21 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:26:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 03:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 03:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:26:21 --> Final output sent to browser
DEBUG - 2016-12-03 03:26:21 --> Total execution time: 0.0412
INFO - 2016-12-03 03:26:35 --> Config Class Initialized
INFO - 2016-12-03 03:26:35 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:26:35 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:26:35 --> Utf8 Class Initialized
INFO - 2016-12-03 03:26:35 --> URI Class Initialized
INFO - 2016-12-03 03:26:35 --> Router Class Initialized
INFO - 2016-12-03 03:26:35 --> Output Class Initialized
INFO - 2016-12-03 03:26:35 --> Security Class Initialized
DEBUG - 2016-12-03 03:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:26:35 --> Input Class Initialized
INFO - 2016-12-03 03:26:35 --> Language Class Initialized
INFO - 2016-12-03 03:26:35 --> Loader Class Initialized
INFO - 2016-12-03 03:26:35 --> Database Driver Class Initialized
INFO - 2016-12-03 03:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:26:35 --> Controller Class Initialized
INFO - 2016-12-03 03:26:35 --> Helper loaded: date_helper
INFO - 2016-12-03 03:26:35 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:26:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:26:35 --> Helper loaded: form_helper
INFO - 2016-12-03 03:26:35 --> Form Validation Class Initialized
INFO - 2016-12-03 03:26:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-03 03:26:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-03 03:26:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2016-12-03 03:26:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2016-12-03 03:26:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-03 03:26:35 --> Final output sent to browser
DEBUG - 2016-12-03 03:26:35 --> Total execution time: 0.0168
INFO - 2016-12-03 03:26:36 --> Config Class Initialized
INFO - 2016-12-03 03:26:36 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:26:36 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:26:36 --> Utf8 Class Initialized
INFO - 2016-12-03 03:26:36 --> URI Class Initialized
INFO - 2016-12-03 03:26:36 --> Router Class Initialized
INFO - 2016-12-03 03:26:36 --> Output Class Initialized
INFO - 2016-12-03 03:26:36 --> Security Class Initialized
DEBUG - 2016-12-03 03:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:26:36 --> Input Class Initialized
INFO - 2016-12-03 03:26:36 --> Language Class Initialized
INFO - 2016-12-03 03:26:36 --> Loader Class Initialized
INFO - 2016-12-03 03:26:36 --> Database Driver Class Initialized
INFO - 2016-12-03 03:26:36 --> Config Class Initialized
INFO - 2016-12-03 03:26:36 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:26:36 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:26:36 --> Utf8 Class Initialized
INFO - 2016-12-03 03:26:36 --> URI Class Initialized
INFO - 2016-12-03 03:26:36 --> Router Class Initialized
INFO - 2016-12-03 03:26:36 --> Output Class Initialized
INFO - 2016-12-03 03:26:36 --> Security Class Initialized
DEBUG - 2016-12-03 03:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:26:36 --> Input Class Initialized
INFO - 2016-12-03 03:26:36 --> Language Class Initialized
INFO - 2016-12-03 03:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:26:36 --> Controller Class Initialized
INFO - 2016-12-03 03:26:36 --> Helper loaded: date_helper
INFO - 2016-12-03 03:26:36 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:26:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:26:36 --> Helper loaded: form_helper
INFO - 2016-12-03 03:26:36 --> Form Validation Class Initialized
INFO - 2016-12-03 03:26:36 --> Final output sent to browser
DEBUG - 2016-12-03 03:26:36 --> Total execution time: 0.0392
INFO - 2016-12-03 03:26:36 --> Loader Class Initialized
INFO - 2016-12-03 03:26:36 --> Database Driver Class Initialized
INFO - 2016-12-03 03:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:26:36 --> Controller Class Initialized
INFO - 2016-12-03 03:26:36 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:26:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:26:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:26:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 03:26:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 03:26:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:26:36 --> Final output sent to browser
DEBUG - 2016-12-03 03:26:36 --> Total execution time: 0.0733
INFO - 2016-12-03 03:33:00 --> Config Class Initialized
INFO - 2016-12-03 03:33:00 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:33:00 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:33:00 --> Utf8 Class Initialized
INFO - 2016-12-03 03:33:00 --> URI Class Initialized
INFO - 2016-12-03 03:33:00 --> Router Class Initialized
INFO - 2016-12-03 03:33:00 --> Output Class Initialized
INFO - 2016-12-03 03:33:00 --> Security Class Initialized
DEBUG - 2016-12-03 03:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:33:00 --> Input Class Initialized
INFO - 2016-12-03 03:33:00 --> Language Class Initialized
INFO - 2016-12-03 03:33:00 --> Loader Class Initialized
INFO - 2016-12-03 03:33:00 --> Database Driver Class Initialized
INFO - 2016-12-03 03:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:33:01 --> Controller Class Initialized
DEBUG - 2016-12-03 03:33:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:33:01 --> Helper loaded: url_helper
INFO - 2016-12-03 03:33:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:33:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-03 03:33:01 --> Severity: Notice --> Undefined property: User_mi_graduacion_controller::$graduaion_modelo /home/graduafe/public_html/application/controllers/User_mi_graduacion_controller.php 43
ERROR - 2016-12-03 03:33:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-03 03:33:01 --> Severity: Error --> Call to a member function obtener_layout_by_id() on a non-object /home/graduafe/public_html/application/controllers/User_mi_graduacion_controller.php 43
INFO - 2016-12-03 03:33:01 --> Config Class Initialized
INFO - 2016-12-03 03:33:01 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:33:01 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:33:01 --> Utf8 Class Initialized
INFO - 2016-12-03 03:33:01 --> URI Class Initialized
INFO - 2016-12-03 03:33:01 --> Router Class Initialized
INFO - 2016-12-03 03:33:01 --> Output Class Initialized
INFO - 2016-12-03 03:33:01 --> Security Class Initialized
DEBUG - 2016-12-03 03:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:33:01 --> Input Class Initialized
INFO - 2016-12-03 03:33:01 --> Language Class Initialized
INFO - 2016-12-03 03:33:01 --> Loader Class Initialized
INFO - 2016-12-03 03:33:01 --> Database Driver Class Initialized
INFO - 2016-12-03 03:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:33:01 --> Controller Class Initialized
INFO - 2016-12-03 03:33:01 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:33:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:33:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:33:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 03:33:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 03:33:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:33:02 --> Final output sent to browser
DEBUG - 2016-12-03 03:33:02 --> Total execution time: 0.0902
INFO - 2016-12-03 03:33:19 --> Config Class Initialized
INFO - 2016-12-03 03:33:19 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:33:19 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:33:19 --> Utf8 Class Initialized
INFO - 2016-12-03 03:33:19 --> URI Class Initialized
INFO - 2016-12-03 03:33:19 --> Router Class Initialized
INFO - 2016-12-03 03:33:19 --> Output Class Initialized
INFO - 2016-12-03 03:33:19 --> Security Class Initialized
DEBUG - 2016-12-03 03:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:33:19 --> Input Class Initialized
INFO - 2016-12-03 03:33:19 --> Language Class Initialized
INFO - 2016-12-03 03:33:19 --> Loader Class Initialized
INFO - 2016-12-03 03:33:19 --> Database Driver Class Initialized
INFO - 2016-12-03 03:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:33:19 --> Controller Class Initialized
INFO - 2016-12-03 03:33:19 --> Helper loaded: date_helper
DEBUG - 2016-12-03 03:33:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:33:19 --> Helper loaded: url_helper
INFO - 2016-12-03 03:33:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:33:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-03 03:33:19 --> Severity: Notice --> Undefined property: User_mi_graduacion_controller::$graduaion_modelo /home/graduafe/public_html/application/controllers/User_mi_graduacion_controller.php 44
ERROR - 2016-12-03 03:33:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-03 03:33:19 --> Severity: Error --> Call to a member function obtener_layout_by_id() on a non-object /home/graduafe/public_html/application/controllers/User_mi_graduacion_controller.php 44
INFO - 2016-12-03 03:33:20 --> Config Class Initialized
INFO - 2016-12-03 03:33:20 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:33:20 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:33:20 --> Utf8 Class Initialized
INFO - 2016-12-03 03:33:20 --> URI Class Initialized
INFO - 2016-12-03 03:33:20 --> Router Class Initialized
INFO - 2016-12-03 03:33:20 --> Output Class Initialized
INFO - 2016-12-03 03:33:20 --> Security Class Initialized
DEBUG - 2016-12-03 03:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:33:20 --> Input Class Initialized
INFO - 2016-12-03 03:33:20 --> Language Class Initialized
INFO - 2016-12-03 03:33:20 --> Loader Class Initialized
INFO - 2016-12-03 03:33:20 --> Database Driver Class Initialized
INFO - 2016-12-03 03:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:33:20 --> Controller Class Initialized
INFO - 2016-12-03 03:33:20 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:33:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:33:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:33:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 03:33:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 03:33:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:33:20 --> Final output sent to browser
DEBUG - 2016-12-03 03:33:20 --> Total execution time: 0.0544
INFO - 2016-12-03 03:33:21 --> Config Class Initialized
INFO - 2016-12-03 03:33:21 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:33:21 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:33:21 --> Utf8 Class Initialized
INFO - 2016-12-03 03:33:21 --> URI Class Initialized
INFO - 2016-12-03 03:33:21 --> Router Class Initialized
INFO - 2016-12-03 03:33:21 --> Output Class Initialized
INFO - 2016-12-03 03:33:21 --> Security Class Initialized
DEBUG - 2016-12-03 03:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:33:21 --> Input Class Initialized
INFO - 2016-12-03 03:33:21 --> Language Class Initialized
INFO - 2016-12-03 03:33:21 --> Loader Class Initialized
INFO - 2016-12-03 03:33:21 --> Database Driver Class Initialized
INFO - 2016-12-03 03:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:33:21 --> Controller Class Initialized
INFO - 2016-12-03 03:33:21 --> Helper loaded: date_helper
DEBUG - 2016-12-03 03:33:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:33:21 --> Helper loaded: url_helper
INFO - 2016-12-03 03:33:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:33:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-03 03:33:21 --> Severity: Notice --> Undefined property: User_mi_graduacion_controller::$graduaion_modelo /home/graduafe/public_html/application/controllers/User_mi_graduacion_controller.php 44
ERROR - 2016-12-03 03:33:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-03 03:33:21 --> Severity: Error --> Call to a member function obtener_layout_by_id() on a non-object /home/graduafe/public_html/application/controllers/User_mi_graduacion_controller.php 44
INFO - 2016-12-03 03:33:21 --> Config Class Initialized
INFO - 2016-12-03 03:33:21 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:33:21 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:33:21 --> Utf8 Class Initialized
INFO - 2016-12-03 03:33:21 --> URI Class Initialized
INFO - 2016-12-03 03:33:21 --> Router Class Initialized
INFO - 2016-12-03 03:33:21 --> Output Class Initialized
INFO - 2016-12-03 03:33:21 --> Security Class Initialized
DEBUG - 2016-12-03 03:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:33:21 --> Input Class Initialized
INFO - 2016-12-03 03:33:21 --> Language Class Initialized
INFO - 2016-12-03 03:33:21 --> Loader Class Initialized
INFO - 2016-12-03 03:33:21 --> Database Driver Class Initialized
INFO - 2016-12-03 03:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:33:21 --> Controller Class Initialized
INFO - 2016-12-03 03:33:21 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:33:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:33:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:33:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 03:33:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 03:33:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:33:21 --> Final output sent to browser
DEBUG - 2016-12-03 03:33:21 --> Total execution time: 0.0147
INFO - 2016-12-03 03:33:53 --> Config Class Initialized
INFO - 2016-12-03 03:33:53 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:33:53 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:33:53 --> Utf8 Class Initialized
INFO - 2016-12-03 03:33:53 --> URI Class Initialized
INFO - 2016-12-03 03:33:53 --> Router Class Initialized
INFO - 2016-12-03 03:33:53 --> Output Class Initialized
INFO - 2016-12-03 03:33:53 --> Security Class Initialized
DEBUG - 2016-12-03 03:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:33:53 --> Input Class Initialized
INFO - 2016-12-03 03:33:53 --> Language Class Initialized
INFO - 2016-12-03 03:33:53 --> Loader Class Initialized
INFO - 2016-12-03 03:33:53 --> Database Driver Class Initialized
INFO - 2016-12-03 03:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:33:53 --> Controller Class Initialized
INFO - 2016-12-03 03:33:53 --> Helper loaded: date_helper
DEBUG - 2016-12-03 03:33:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:33:53 --> Helper loaded: url_helper
INFO - 2016-12-03 03:33:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:33:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 03:33:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 03:33:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 03:33:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:33:53 --> Final output sent to browser
DEBUG - 2016-12-03 03:33:53 --> Total execution time: 0.0378
INFO - 2016-12-03 03:33:53 --> Config Class Initialized
INFO - 2016-12-03 03:33:53 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:33:53 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:33:53 --> Utf8 Class Initialized
INFO - 2016-12-03 03:33:53 --> URI Class Initialized
INFO - 2016-12-03 03:33:53 --> Router Class Initialized
INFO - 2016-12-03 03:33:53 --> Output Class Initialized
INFO - 2016-12-03 03:33:53 --> Security Class Initialized
DEBUG - 2016-12-03 03:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:33:53 --> Input Class Initialized
INFO - 2016-12-03 03:33:53 --> Language Class Initialized
ERROR - 2016-12-03 03:33:53 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 03:33:53 --> Config Class Initialized
INFO - 2016-12-03 03:33:53 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:33:53 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:33:53 --> Utf8 Class Initialized
INFO - 2016-12-03 03:33:53 --> URI Class Initialized
INFO - 2016-12-03 03:33:53 --> Router Class Initialized
INFO - 2016-12-03 03:33:53 --> Output Class Initialized
INFO - 2016-12-03 03:33:53 --> Security Class Initialized
DEBUG - 2016-12-03 03:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:33:53 --> Input Class Initialized
INFO - 2016-12-03 03:33:53 --> Language Class Initialized
INFO - 2016-12-03 03:33:53 --> Loader Class Initialized
INFO - 2016-12-03 03:33:53 --> Database Driver Class Initialized
INFO - 2016-12-03 03:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:33:53 --> Controller Class Initialized
INFO - 2016-12-03 03:33:53 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:33:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:33:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:33:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 03:33:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 03:33:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:33:53 --> Final output sent to browser
DEBUG - 2016-12-03 03:33:53 --> Total execution time: 0.0208
INFO - 2016-12-03 03:35:18 --> Config Class Initialized
INFO - 2016-12-03 03:35:18 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:35:18 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:35:18 --> Utf8 Class Initialized
INFO - 2016-12-03 03:35:18 --> URI Class Initialized
INFO - 2016-12-03 03:35:18 --> Router Class Initialized
INFO - 2016-12-03 03:35:18 --> Output Class Initialized
INFO - 2016-12-03 03:35:18 --> Security Class Initialized
DEBUG - 2016-12-03 03:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:35:18 --> Input Class Initialized
INFO - 2016-12-03 03:35:18 --> Language Class Initialized
INFO - 2016-12-03 03:35:18 --> Loader Class Initialized
INFO - 2016-12-03 03:35:18 --> Database Driver Class Initialized
INFO - 2016-12-03 03:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:35:18 --> Controller Class Initialized
INFO - 2016-12-03 03:35:18 --> Helper loaded: date_helper
DEBUG - 2016-12-03 03:35:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:35:18 --> Helper loaded: url_helper
INFO - 2016-12-03 03:35:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:35:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 03:35:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 03:35:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 03:35:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:35:18 --> Final output sent to browser
DEBUG - 2016-12-03 03:35:18 --> Total execution time: 0.0266
INFO - 2016-12-03 03:35:19 --> Config Class Initialized
INFO - 2016-12-03 03:35:19 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:35:19 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:35:19 --> Utf8 Class Initialized
INFO - 2016-12-03 03:35:19 --> URI Class Initialized
INFO - 2016-12-03 03:35:19 --> Router Class Initialized
INFO - 2016-12-03 03:35:19 --> Output Class Initialized
INFO - 2016-12-03 03:35:19 --> Security Class Initialized
DEBUG - 2016-12-03 03:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:35:19 --> Input Class Initialized
INFO - 2016-12-03 03:35:19 --> Language Class Initialized
ERROR - 2016-12-03 03:35:19 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 03:35:19 --> Config Class Initialized
INFO - 2016-12-03 03:35:19 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:35:19 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:35:19 --> Utf8 Class Initialized
INFO - 2016-12-03 03:35:19 --> URI Class Initialized
INFO - 2016-12-03 03:35:19 --> Router Class Initialized
INFO - 2016-12-03 03:35:19 --> Output Class Initialized
INFO - 2016-12-03 03:35:19 --> Security Class Initialized
DEBUG - 2016-12-03 03:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:35:19 --> Input Class Initialized
INFO - 2016-12-03 03:35:19 --> Language Class Initialized
INFO - 2016-12-03 03:35:19 --> Loader Class Initialized
INFO - 2016-12-03 03:35:19 --> Database Driver Class Initialized
INFO - 2016-12-03 03:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:35:19 --> Controller Class Initialized
INFO - 2016-12-03 03:35:19 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:35:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:35:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:35:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 03:35:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 03:35:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:35:19 --> Final output sent to browser
DEBUG - 2016-12-03 03:35:19 --> Total execution time: 0.0495
INFO - 2016-12-03 03:37:30 --> Config Class Initialized
INFO - 2016-12-03 03:37:30 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:37:30 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:37:30 --> Utf8 Class Initialized
INFO - 2016-12-03 03:37:30 --> URI Class Initialized
INFO - 2016-12-03 03:37:30 --> Router Class Initialized
INFO - 2016-12-03 03:37:30 --> Output Class Initialized
INFO - 2016-12-03 03:37:30 --> Security Class Initialized
DEBUG - 2016-12-03 03:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:37:30 --> Input Class Initialized
INFO - 2016-12-03 03:37:30 --> Language Class Initialized
INFO - 2016-12-03 03:37:30 --> Loader Class Initialized
INFO - 2016-12-03 03:37:30 --> Database Driver Class Initialized
INFO - 2016-12-03 03:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:37:30 --> Controller Class Initialized
INFO - 2016-12-03 03:37:30 --> Helper loaded: date_helper
DEBUG - 2016-12-03 03:37:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:37:30 --> Helper loaded: url_helper
INFO - 2016-12-03 03:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 03:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 03:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 03:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:37:30 --> Final output sent to browser
DEBUG - 2016-12-03 03:37:30 --> Total execution time: 0.0232
INFO - 2016-12-03 03:37:30 --> Config Class Initialized
INFO - 2016-12-03 03:37:30 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:37:30 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:37:30 --> Utf8 Class Initialized
INFO - 2016-12-03 03:37:30 --> URI Class Initialized
INFO - 2016-12-03 03:37:30 --> Router Class Initialized
INFO - 2016-12-03 03:37:30 --> Output Class Initialized
INFO - 2016-12-03 03:37:30 --> Security Class Initialized
DEBUG - 2016-12-03 03:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:37:30 --> Input Class Initialized
INFO - 2016-12-03 03:37:30 --> Language Class Initialized
ERROR - 2016-12-03 03:37:30 --> 404 Page Not Found: Imagenes_productos/NO_LAYOUT_AVILABLE.jpg
INFO - 2016-12-03 03:37:30 --> Config Class Initialized
INFO - 2016-12-03 03:37:30 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:37:30 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:37:30 --> Utf8 Class Initialized
INFO - 2016-12-03 03:37:30 --> URI Class Initialized
INFO - 2016-12-03 03:37:30 --> Router Class Initialized
INFO - 2016-12-03 03:37:30 --> Output Class Initialized
INFO - 2016-12-03 03:37:30 --> Security Class Initialized
DEBUG - 2016-12-03 03:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:37:30 --> Input Class Initialized
INFO - 2016-12-03 03:37:30 --> Language Class Initialized
ERROR - 2016-12-03 03:37:30 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 03:37:30 --> Config Class Initialized
INFO - 2016-12-03 03:37:30 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:37:30 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:37:30 --> Utf8 Class Initialized
INFO - 2016-12-03 03:37:30 --> URI Class Initialized
INFO - 2016-12-03 03:37:30 --> Router Class Initialized
INFO - 2016-12-03 03:37:30 --> Output Class Initialized
INFO - 2016-12-03 03:37:30 --> Security Class Initialized
DEBUG - 2016-12-03 03:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:37:30 --> Input Class Initialized
INFO - 2016-12-03 03:37:30 --> Language Class Initialized
INFO - 2016-12-03 03:37:30 --> Loader Class Initialized
INFO - 2016-12-03 03:37:30 --> Database Driver Class Initialized
INFO - 2016-12-03 03:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:37:30 --> Controller Class Initialized
INFO - 2016-12-03 03:37:30 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:37:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 03:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 03:37:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:37:30 --> Final output sent to browser
DEBUG - 2016-12-03 03:37:30 --> Total execution time: 0.0128
INFO - 2016-12-03 03:38:03 --> Config Class Initialized
INFO - 2016-12-03 03:38:03 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:38:03 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:38:03 --> Utf8 Class Initialized
INFO - 2016-12-03 03:38:03 --> URI Class Initialized
INFO - 2016-12-03 03:38:03 --> Router Class Initialized
INFO - 2016-12-03 03:38:03 --> Output Class Initialized
INFO - 2016-12-03 03:38:03 --> Security Class Initialized
DEBUG - 2016-12-03 03:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:38:03 --> Input Class Initialized
INFO - 2016-12-03 03:38:03 --> Language Class Initialized
INFO - 2016-12-03 03:38:03 --> Loader Class Initialized
INFO - 2016-12-03 03:38:03 --> Database Driver Class Initialized
INFO - 2016-12-03 03:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:38:03 --> Controller Class Initialized
INFO - 2016-12-03 03:38:03 --> Helper loaded: date_helper
DEBUG - 2016-12-03 03:38:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:38:03 --> Helper loaded: url_helper
INFO - 2016-12-03 03:38:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:38:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 03:38:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 03:38:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 03:38:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:38:03 --> Final output sent to browser
DEBUG - 2016-12-03 03:38:03 --> Total execution time: 0.0187
INFO - 2016-12-03 03:38:03 --> Config Class Initialized
INFO - 2016-12-03 03:38:03 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:38:03 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:38:03 --> Utf8 Class Initialized
INFO - 2016-12-03 03:38:03 --> URI Class Initialized
INFO - 2016-12-03 03:38:03 --> Router Class Initialized
INFO - 2016-12-03 03:38:03 --> Output Class Initialized
INFO - 2016-12-03 03:38:03 --> Security Class Initialized
DEBUG - 2016-12-03 03:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:38:03 --> Input Class Initialized
INFO - 2016-12-03 03:38:03 --> Language Class Initialized
ERROR - 2016-12-03 03:38:03 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 03:38:04 --> Config Class Initialized
INFO - 2016-12-03 03:38:04 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:38:04 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:38:04 --> Utf8 Class Initialized
INFO - 2016-12-03 03:38:04 --> URI Class Initialized
INFO - 2016-12-03 03:38:04 --> Router Class Initialized
INFO - 2016-12-03 03:38:04 --> Output Class Initialized
INFO - 2016-12-03 03:38:04 --> Security Class Initialized
DEBUG - 2016-12-03 03:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:38:04 --> Input Class Initialized
INFO - 2016-12-03 03:38:04 --> Language Class Initialized
INFO - 2016-12-03 03:38:04 --> Loader Class Initialized
INFO - 2016-12-03 03:38:04 --> Database Driver Class Initialized
INFO - 2016-12-03 03:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:38:04 --> Controller Class Initialized
INFO - 2016-12-03 03:38:04 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:38:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:38:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:38:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 03:38:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 03:38:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:38:04 --> Final output sent to browser
DEBUG - 2016-12-03 03:38:04 --> Total execution time: 0.0128
INFO - 2016-12-03 03:39:31 --> Config Class Initialized
INFO - 2016-12-03 03:39:31 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:39:31 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:39:31 --> Utf8 Class Initialized
INFO - 2016-12-03 03:39:31 --> URI Class Initialized
INFO - 2016-12-03 03:39:31 --> Router Class Initialized
INFO - 2016-12-03 03:39:31 --> Output Class Initialized
INFO - 2016-12-03 03:39:31 --> Security Class Initialized
DEBUG - 2016-12-03 03:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:39:31 --> Input Class Initialized
INFO - 2016-12-03 03:39:31 --> Language Class Initialized
INFO - 2016-12-03 03:39:31 --> Loader Class Initialized
INFO - 2016-12-03 03:39:31 --> Database Driver Class Initialized
INFO - 2016-12-03 03:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:39:32 --> Controller Class Initialized
INFO - 2016-12-03 03:39:32 --> Helper loaded: date_helper
DEBUG - 2016-12-03 03:39:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:39:32 --> Helper loaded: url_helper
INFO - 2016-12-03 03:39:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:39:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 03:39:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 03:39:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 03:39:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:39:32 --> Final output sent to browser
DEBUG - 2016-12-03 03:39:32 --> Total execution time: 0.4847
INFO - 2016-12-03 03:39:32 --> Config Class Initialized
INFO - 2016-12-03 03:39:32 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:39:32 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:39:32 --> Utf8 Class Initialized
INFO - 2016-12-03 03:39:32 --> URI Class Initialized
INFO - 2016-12-03 03:39:32 --> Router Class Initialized
INFO - 2016-12-03 03:39:32 --> Output Class Initialized
INFO - 2016-12-03 03:39:32 --> Security Class Initialized
DEBUG - 2016-12-03 03:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:39:32 --> Input Class Initialized
INFO - 2016-12-03 03:39:32 --> Language Class Initialized
ERROR - 2016-12-03 03:39:32 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 03:39:32 --> Config Class Initialized
INFO - 2016-12-03 03:39:32 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:39:32 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:39:32 --> Utf8 Class Initialized
INFO - 2016-12-03 03:39:32 --> URI Class Initialized
INFO - 2016-12-03 03:39:32 --> Router Class Initialized
INFO - 2016-12-03 03:39:32 --> Output Class Initialized
INFO - 2016-12-03 03:39:32 --> Security Class Initialized
DEBUG - 2016-12-03 03:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:39:32 --> Input Class Initialized
INFO - 2016-12-03 03:39:32 --> Language Class Initialized
INFO - 2016-12-03 03:39:32 --> Loader Class Initialized
INFO - 2016-12-03 03:39:32 --> Database Driver Class Initialized
INFO - 2016-12-03 03:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:39:32 --> Controller Class Initialized
INFO - 2016-12-03 03:39:32 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:39:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:39:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:39:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 03:39:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 03:39:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:39:32 --> Final output sent to browser
DEBUG - 2016-12-03 03:39:32 --> Total execution time: 0.0140
INFO - 2016-12-03 03:39:47 --> Config Class Initialized
INFO - 2016-12-03 03:39:47 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:39:47 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:39:47 --> Utf8 Class Initialized
INFO - 2016-12-03 03:39:47 --> URI Class Initialized
INFO - 2016-12-03 03:39:47 --> Router Class Initialized
INFO - 2016-12-03 03:39:47 --> Output Class Initialized
INFO - 2016-12-03 03:39:47 --> Security Class Initialized
DEBUG - 2016-12-03 03:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:39:47 --> Input Class Initialized
INFO - 2016-12-03 03:39:47 --> Language Class Initialized
INFO - 2016-12-03 03:39:47 --> Loader Class Initialized
INFO - 2016-12-03 03:39:47 --> Database Driver Class Initialized
INFO - 2016-12-03 03:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:39:47 --> Controller Class Initialized
INFO - 2016-12-03 03:39:47 --> Helper loaded: date_helper
DEBUG - 2016-12-03 03:39:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:39:47 --> Helper loaded: url_helper
INFO - 2016-12-03 03:39:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:39:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 03:39:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 03:39:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 03:39:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:39:47 --> Final output sent to browser
DEBUG - 2016-12-03 03:39:47 --> Total execution time: 0.0175
INFO - 2016-12-03 03:39:48 --> Config Class Initialized
INFO - 2016-12-03 03:39:48 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:39:48 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:39:48 --> Utf8 Class Initialized
INFO - 2016-12-03 03:39:48 --> URI Class Initialized
INFO - 2016-12-03 03:39:48 --> Router Class Initialized
INFO - 2016-12-03 03:39:48 --> Output Class Initialized
INFO - 2016-12-03 03:39:48 --> Security Class Initialized
DEBUG - 2016-12-03 03:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:39:48 --> Input Class Initialized
INFO - 2016-12-03 03:39:48 --> Language Class Initialized
ERROR - 2016-12-03 03:39:48 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 03:39:48 --> Config Class Initialized
INFO - 2016-12-03 03:39:48 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:39:48 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:39:48 --> Utf8 Class Initialized
INFO - 2016-12-03 03:39:48 --> URI Class Initialized
INFO - 2016-12-03 03:39:48 --> Router Class Initialized
INFO - 2016-12-03 03:39:48 --> Output Class Initialized
INFO - 2016-12-03 03:39:48 --> Security Class Initialized
DEBUG - 2016-12-03 03:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:39:48 --> Input Class Initialized
INFO - 2016-12-03 03:39:48 --> Language Class Initialized
INFO - 2016-12-03 03:39:48 --> Loader Class Initialized
INFO - 2016-12-03 03:39:48 --> Database Driver Class Initialized
INFO - 2016-12-03 03:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:39:48 --> Controller Class Initialized
INFO - 2016-12-03 03:39:48 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:39:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:39:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:39:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 03:39:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 03:39:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:39:48 --> Final output sent to browser
DEBUG - 2016-12-03 03:39:48 --> Total execution time: 0.0130
INFO - 2016-12-03 03:40:00 --> Config Class Initialized
INFO - 2016-12-03 03:40:00 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:40:00 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:40:00 --> Utf8 Class Initialized
INFO - 2016-12-03 03:40:00 --> URI Class Initialized
INFO - 2016-12-03 03:40:00 --> Router Class Initialized
INFO - 2016-12-03 03:40:00 --> Output Class Initialized
INFO - 2016-12-03 03:40:00 --> Security Class Initialized
DEBUG - 2016-12-03 03:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:40:00 --> Input Class Initialized
INFO - 2016-12-03 03:40:00 --> Language Class Initialized
INFO - 2016-12-03 03:40:00 --> Loader Class Initialized
INFO - 2016-12-03 03:40:00 --> Database Driver Class Initialized
INFO - 2016-12-03 03:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:40:00 --> Controller Class Initialized
DEBUG - 2016-12-03 03:40:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:40:00 --> Helper loaded: url_helper
INFO - 2016-12-03 03:40:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:40:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 03:40:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-03 03:40:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-03 03:40:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:40:00 --> Final output sent to browser
DEBUG - 2016-12-03 03:40:00 --> Total execution time: 0.0784
INFO - 2016-12-03 03:40:00 --> Config Class Initialized
INFO - 2016-12-03 03:40:00 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:40:00 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:40:00 --> Utf8 Class Initialized
INFO - 2016-12-03 03:40:00 --> URI Class Initialized
INFO - 2016-12-03 03:40:00 --> Router Class Initialized
INFO - 2016-12-03 03:40:00 --> Output Class Initialized
INFO - 2016-12-03 03:40:00 --> Security Class Initialized
DEBUG - 2016-12-03 03:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:40:00 --> Input Class Initialized
INFO - 2016-12-03 03:40:00 --> Language Class Initialized
ERROR - 2016-12-03 03:40:00 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 03:40:00 --> Config Class Initialized
INFO - 2016-12-03 03:40:00 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:40:00 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:40:00 --> Utf8 Class Initialized
INFO - 2016-12-03 03:40:00 --> URI Class Initialized
INFO - 2016-12-03 03:40:00 --> Router Class Initialized
INFO - 2016-12-03 03:40:00 --> Output Class Initialized
INFO - 2016-12-03 03:40:00 --> Security Class Initialized
DEBUG - 2016-12-03 03:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:40:00 --> Input Class Initialized
INFO - 2016-12-03 03:40:00 --> Language Class Initialized
INFO - 2016-12-03 03:40:00 --> Loader Class Initialized
INFO - 2016-12-03 03:40:00 --> Database Driver Class Initialized
INFO - 2016-12-03 03:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:40:00 --> Controller Class Initialized
INFO - 2016-12-03 03:40:00 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:40:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:40:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:40:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 03:40:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 03:40:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:40:00 --> Final output sent to browser
DEBUG - 2016-12-03 03:40:00 --> Total execution time: 0.0132
INFO - 2016-12-03 03:40:16 --> Config Class Initialized
INFO - 2016-12-03 03:40:16 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:40:16 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:40:16 --> Utf8 Class Initialized
INFO - 2016-12-03 03:40:16 --> URI Class Initialized
INFO - 2016-12-03 03:40:16 --> Router Class Initialized
INFO - 2016-12-03 03:40:16 --> Output Class Initialized
INFO - 2016-12-03 03:40:16 --> Security Class Initialized
DEBUG - 2016-12-03 03:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:40:16 --> Input Class Initialized
INFO - 2016-12-03 03:40:16 --> Language Class Initialized
INFO - 2016-12-03 03:40:16 --> Loader Class Initialized
INFO - 2016-12-03 03:40:16 --> Database Driver Class Initialized
INFO - 2016-12-03 03:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:40:16 --> Controller Class Initialized
DEBUG - 2016-12-03 03:40:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:40:16 --> Helper loaded: url_helper
INFO - 2016-12-03 03:40:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:40:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 03:40:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-03 03:40:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-03 03:40:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:40:16 --> Final output sent to browser
DEBUG - 2016-12-03 03:40:16 --> Total execution time: 0.0145
INFO - 2016-12-03 03:40:17 --> Config Class Initialized
INFO - 2016-12-03 03:40:17 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:40:17 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:40:17 --> Utf8 Class Initialized
INFO - 2016-12-03 03:40:17 --> URI Class Initialized
INFO - 2016-12-03 03:40:17 --> Router Class Initialized
INFO - 2016-12-03 03:40:17 --> Output Class Initialized
INFO - 2016-12-03 03:40:17 --> Security Class Initialized
DEBUG - 2016-12-03 03:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:40:17 --> Input Class Initialized
INFO - 2016-12-03 03:40:17 --> Language Class Initialized
ERROR - 2016-12-03 03:40:17 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 03:40:17 --> Config Class Initialized
INFO - 2016-12-03 03:40:17 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:40:17 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:40:17 --> Utf8 Class Initialized
INFO - 2016-12-03 03:40:17 --> URI Class Initialized
INFO - 2016-12-03 03:40:17 --> Router Class Initialized
INFO - 2016-12-03 03:40:17 --> Output Class Initialized
INFO - 2016-12-03 03:40:17 --> Security Class Initialized
DEBUG - 2016-12-03 03:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:40:17 --> Input Class Initialized
INFO - 2016-12-03 03:40:17 --> Language Class Initialized
INFO - 2016-12-03 03:40:17 --> Loader Class Initialized
INFO - 2016-12-03 03:40:17 --> Database Driver Class Initialized
INFO - 2016-12-03 03:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:40:17 --> Controller Class Initialized
INFO - 2016-12-03 03:40:17 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:40:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:40:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:40:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 03:40:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 03:40:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:40:17 --> Final output sent to browser
DEBUG - 2016-12-03 03:40:17 --> Total execution time: 0.0143
INFO - 2016-12-03 03:40:20 --> Config Class Initialized
INFO - 2016-12-03 03:40:20 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:40:20 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:40:20 --> Utf8 Class Initialized
INFO - 2016-12-03 03:40:20 --> URI Class Initialized
INFO - 2016-12-03 03:40:20 --> Router Class Initialized
INFO - 2016-12-03 03:40:20 --> Output Class Initialized
INFO - 2016-12-03 03:40:20 --> Security Class Initialized
DEBUG - 2016-12-03 03:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:40:20 --> Input Class Initialized
INFO - 2016-12-03 03:40:20 --> Language Class Initialized
INFO - 2016-12-03 03:40:20 --> Loader Class Initialized
INFO - 2016-12-03 03:40:20 --> Database Driver Class Initialized
INFO - 2016-12-03 03:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:40:20 --> Controller Class Initialized
INFO - 2016-12-03 03:40:20 --> Helper loaded: date_helper
DEBUG - 2016-12-03 03:40:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:40:20 --> Helper loaded: url_helper
INFO - 2016-12-03 03:40:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:40:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 03:40:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 03:40:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 03:40:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:40:20 --> Final output sent to browser
DEBUG - 2016-12-03 03:40:20 --> Total execution time: 0.0525
INFO - 2016-12-03 03:40:20 --> Config Class Initialized
INFO - 2016-12-03 03:40:20 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:40:20 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:40:20 --> Utf8 Class Initialized
INFO - 2016-12-03 03:40:20 --> URI Class Initialized
INFO - 2016-12-03 03:40:20 --> Router Class Initialized
INFO - 2016-12-03 03:40:20 --> Output Class Initialized
INFO - 2016-12-03 03:40:20 --> Security Class Initialized
DEBUG - 2016-12-03 03:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:40:20 --> Input Class Initialized
INFO - 2016-12-03 03:40:20 --> Language Class Initialized
ERROR - 2016-12-03 03:40:20 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 03:40:21 --> Config Class Initialized
INFO - 2016-12-03 03:40:21 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:40:21 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:40:21 --> Utf8 Class Initialized
INFO - 2016-12-03 03:40:21 --> URI Class Initialized
INFO - 2016-12-03 03:40:21 --> Router Class Initialized
INFO - 2016-12-03 03:40:21 --> Output Class Initialized
INFO - 2016-12-03 03:40:21 --> Security Class Initialized
DEBUG - 2016-12-03 03:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:40:21 --> Input Class Initialized
INFO - 2016-12-03 03:40:21 --> Language Class Initialized
INFO - 2016-12-03 03:40:21 --> Loader Class Initialized
INFO - 2016-12-03 03:40:21 --> Database Driver Class Initialized
INFO - 2016-12-03 03:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:40:21 --> Controller Class Initialized
INFO - 2016-12-03 03:40:21 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 03:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 03:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:40:21 --> Final output sent to browser
DEBUG - 2016-12-03 03:40:21 --> Total execution time: 0.0141
INFO - 2016-12-03 03:40:37 --> Config Class Initialized
INFO - 2016-12-03 03:40:37 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:40:37 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:40:37 --> Utf8 Class Initialized
INFO - 2016-12-03 03:40:37 --> URI Class Initialized
INFO - 2016-12-03 03:40:37 --> Router Class Initialized
INFO - 2016-12-03 03:40:37 --> Output Class Initialized
INFO - 2016-12-03 03:40:37 --> Security Class Initialized
DEBUG - 2016-12-03 03:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:40:37 --> Input Class Initialized
INFO - 2016-12-03 03:40:37 --> Language Class Initialized
INFO - 2016-12-03 03:40:37 --> Loader Class Initialized
INFO - 2016-12-03 03:40:37 --> Database Driver Class Initialized
INFO - 2016-12-03 03:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:40:37 --> Controller Class Initialized
INFO - 2016-12-03 03:40:37 --> Helper loaded: date_helper
DEBUG - 2016-12-03 03:40:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:40:37 --> Helper loaded: url_helper
INFO - 2016-12-03 03:40:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:40:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 03:40:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 03:40:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 03:40:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:40:37 --> Final output sent to browser
DEBUG - 2016-12-03 03:40:37 --> Total execution time: 0.0338
INFO - 2016-12-03 03:40:37 --> Config Class Initialized
INFO - 2016-12-03 03:40:37 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:40:37 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:40:37 --> Utf8 Class Initialized
INFO - 2016-12-03 03:40:37 --> URI Class Initialized
INFO - 2016-12-03 03:40:37 --> Router Class Initialized
INFO - 2016-12-03 03:40:37 --> Output Class Initialized
INFO - 2016-12-03 03:40:37 --> Security Class Initialized
DEBUG - 2016-12-03 03:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:40:37 --> Input Class Initialized
INFO - 2016-12-03 03:40:37 --> Language Class Initialized
ERROR - 2016-12-03 03:40:37 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 03:40:38 --> Config Class Initialized
INFO - 2016-12-03 03:40:38 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:40:38 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:40:38 --> Utf8 Class Initialized
INFO - 2016-12-03 03:40:38 --> URI Class Initialized
INFO - 2016-12-03 03:40:38 --> Router Class Initialized
INFO - 2016-12-03 03:40:38 --> Output Class Initialized
INFO - 2016-12-03 03:40:38 --> Security Class Initialized
DEBUG - 2016-12-03 03:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:40:38 --> Input Class Initialized
INFO - 2016-12-03 03:40:38 --> Language Class Initialized
INFO - 2016-12-03 03:40:38 --> Loader Class Initialized
INFO - 2016-12-03 03:40:38 --> Database Driver Class Initialized
INFO - 2016-12-03 03:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:40:38 --> Controller Class Initialized
INFO - 2016-12-03 03:40:38 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:40:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 03:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 03:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:40:38 --> Final output sent to browser
DEBUG - 2016-12-03 03:40:38 --> Total execution time: 0.0536
INFO - 2016-12-03 03:41:07 --> Config Class Initialized
INFO - 2016-12-03 03:41:07 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:41:07 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:41:07 --> Utf8 Class Initialized
INFO - 2016-12-03 03:41:07 --> URI Class Initialized
INFO - 2016-12-03 03:41:07 --> Router Class Initialized
INFO - 2016-12-03 03:41:07 --> Output Class Initialized
INFO - 2016-12-03 03:41:07 --> Security Class Initialized
DEBUG - 2016-12-03 03:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:41:07 --> Input Class Initialized
INFO - 2016-12-03 03:41:07 --> Language Class Initialized
INFO - 2016-12-03 03:41:07 --> Loader Class Initialized
INFO - 2016-12-03 03:41:07 --> Database Driver Class Initialized
INFO - 2016-12-03 03:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:41:07 --> Controller Class Initialized
INFO - 2016-12-03 03:41:07 --> Helper loaded: date_helper
DEBUG - 2016-12-03 03:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:41:07 --> Helper loaded: url_helper
INFO - 2016-12-03 03:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 03:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 03:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 03:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:41:07 --> Final output sent to browser
DEBUG - 2016-12-03 03:41:07 --> Total execution time: 0.0162
INFO - 2016-12-03 03:41:07 --> Config Class Initialized
INFO - 2016-12-03 03:41:07 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:41:07 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:41:07 --> Utf8 Class Initialized
INFO - 2016-12-03 03:41:07 --> URI Class Initialized
INFO - 2016-12-03 03:41:07 --> Router Class Initialized
INFO - 2016-12-03 03:41:07 --> Output Class Initialized
INFO - 2016-12-03 03:41:07 --> Security Class Initialized
DEBUG - 2016-12-03 03:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:41:07 --> Input Class Initialized
INFO - 2016-12-03 03:41:07 --> Language Class Initialized
ERROR - 2016-12-03 03:41:07 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 03:41:07 --> Config Class Initialized
INFO - 2016-12-03 03:41:07 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:41:07 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:41:07 --> Utf8 Class Initialized
INFO - 2016-12-03 03:41:07 --> URI Class Initialized
INFO - 2016-12-03 03:41:07 --> Router Class Initialized
INFO - 2016-12-03 03:41:07 --> Output Class Initialized
INFO - 2016-12-03 03:41:07 --> Security Class Initialized
DEBUG - 2016-12-03 03:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:41:07 --> Input Class Initialized
INFO - 2016-12-03 03:41:07 --> Language Class Initialized
INFO - 2016-12-03 03:41:07 --> Loader Class Initialized
INFO - 2016-12-03 03:41:07 --> Database Driver Class Initialized
INFO - 2016-12-03 03:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:41:07 --> Controller Class Initialized
INFO - 2016-12-03 03:41:07 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 03:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 03:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:41:07 --> Final output sent to browser
DEBUG - 2016-12-03 03:41:07 --> Total execution time: 0.0136
INFO - 2016-12-03 03:41:53 --> Config Class Initialized
INFO - 2016-12-03 03:41:53 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:41:53 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:41:53 --> Utf8 Class Initialized
INFO - 2016-12-03 03:41:53 --> URI Class Initialized
INFO - 2016-12-03 03:41:53 --> Router Class Initialized
INFO - 2016-12-03 03:41:53 --> Output Class Initialized
INFO - 2016-12-03 03:41:53 --> Security Class Initialized
DEBUG - 2016-12-03 03:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:41:53 --> Input Class Initialized
INFO - 2016-12-03 03:41:53 --> Language Class Initialized
INFO - 2016-12-03 03:41:53 --> Loader Class Initialized
INFO - 2016-12-03 03:41:53 --> Database Driver Class Initialized
INFO - 2016-12-03 03:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:41:53 --> Controller Class Initialized
INFO - 2016-12-03 03:41:53 --> Helper loaded: date_helper
INFO - 2016-12-03 03:41:53 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:41:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:41:53 --> Helper loaded: form_helper
INFO - 2016-12-03 03:41:53 --> Form Validation Class Initialized
INFO - 2016-12-03 03:41:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-03 03:41:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-03 03:41:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2016-12-03 03:41:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2016-12-03 03:41:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-03 03:41:53 --> Final output sent to browser
DEBUG - 2016-12-03 03:41:53 --> Total execution time: 0.0802
INFO - 2016-12-03 03:41:54 --> Config Class Initialized
INFO - 2016-12-03 03:41:54 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:41:54 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:41:54 --> Utf8 Class Initialized
INFO - 2016-12-03 03:41:54 --> URI Class Initialized
INFO - 2016-12-03 03:41:54 --> Router Class Initialized
INFO - 2016-12-03 03:41:54 --> Output Class Initialized
INFO - 2016-12-03 03:41:54 --> Security Class Initialized
DEBUG - 2016-12-03 03:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:41:54 --> Input Class Initialized
INFO - 2016-12-03 03:41:54 --> Language Class Initialized
INFO - 2016-12-03 03:41:54 --> Loader Class Initialized
INFO - 2016-12-03 03:41:54 --> Database Driver Class Initialized
INFO - 2016-12-03 03:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:41:54 --> Controller Class Initialized
INFO - 2016-12-03 03:41:54 --> Helper loaded: date_helper
INFO - 2016-12-03 03:41:54 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:41:54 --> Helper loaded: form_helper
INFO - 2016-12-03 03:41:54 --> Form Validation Class Initialized
INFO - 2016-12-03 03:41:54 --> Final output sent to browser
DEBUG - 2016-12-03 03:41:54 --> Total execution time: 0.0327
INFO - 2016-12-03 03:41:54 --> Config Class Initialized
INFO - 2016-12-03 03:41:54 --> Hooks Class Initialized
DEBUG - 2016-12-03 03:41:54 --> UTF-8 Support Enabled
INFO - 2016-12-03 03:41:54 --> Utf8 Class Initialized
INFO - 2016-12-03 03:41:54 --> URI Class Initialized
INFO - 2016-12-03 03:41:54 --> Router Class Initialized
INFO - 2016-12-03 03:41:54 --> Output Class Initialized
INFO - 2016-12-03 03:41:54 --> Security Class Initialized
DEBUG - 2016-12-03 03:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 03:41:54 --> Input Class Initialized
INFO - 2016-12-03 03:41:54 --> Language Class Initialized
INFO - 2016-12-03 03:41:54 --> Loader Class Initialized
INFO - 2016-12-03 03:41:54 --> Database Driver Class Initialized
INFO - 2016-12-03 03:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 03:41:54 --> Controller Class Initialized
INFO - 2016-12-03 03:41:54 --> Helper loaded: url_helper
DEBUG - 2016-12-03 03:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 03:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 03:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 03:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 03:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 03:41:54 --> Final output sent to browser
DEBUG - 2016-12-03 03:41:54 --> Total execution time: 0.0455
INFO - 2016-12-03 04:08:30 --> Config Class Initialized
INFO - 2016-12-03 04:08:30 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:08:30 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:08:30 --> Utf8 Class Initialized
INFO - 2016-12-03 04:08:30 --> URI Class Initialized
INFO - 2016-12-03 04:08:30 --> Router Class Initialized
INFO - 2016-12-03 04:08:30 --> Output Class Initialized
INFO - 2016-12-03 04:08:30 --> Security Class Initialized
DEBUG - 2016-12-03 04:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:08:30 --> Input Class Initialized
INFO - 2016-12-03 04:08:30 --> Language Class Initialized
INFO - 2016-12-03 04:08:30 --> Loader Class Initialized
INFO - 2016-12-03 04:08:30 --> Database Driver Class Initialized
INFO - 2016-12-03 04:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:08:30 --> Controller Class Initialized
INFO - 2016-12-03 04:08:30 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:08:30 --> Helper loaded: url_helper
INFO - 2016-12-03 04:08:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:08:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:08:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:08:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:08:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:08:30 --> Final output sent to browser
DEBUG - 2016-12-03 04:08:30 --> Total execution time: 0.0541
INFO - 2016-12-03 04:08:31 --> Config Class Initialized
INFO - 2016-12-03 04:08:31 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:08:31 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:08:31 --> Utf8 Class Initialized
INFO - 2016-12-03 04:08:31 --> URI Class Initialized
INFO - 2016-12-03 04:08:31 --> Router Class Initialized
INFO - 2016-12-03 04:08:31 --> Output Class Initialized
INFO - 2016-12-03 04:08:31 --> Security Class Initialized
DEBUG - 2016-12-03 04:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:08:31 --> Input Class Initialized
INFO - 2016-12-03 04:08:31 --> Language Class Initialized
ERROR - 2016-12-03 04:08:31 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:08:31 --> Config Class Initialized
INFO - 2016-12-03 04:08:31 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:08:31 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:08:31 --> Utf8 Class Initialized
INFO - 2016-12-03 04:08:31 --> URI Class Initialized
INFO - 2016-12-03 04:08:31 --> Router Class Initialized
INFO - 2016-12-03 04:08:31 --> Output Class Initialized
INFO - 2016-12-03 04:08:31 --> Security Class Initialized
DEBUG - 2016-12-03 04:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:08:31 --> Input Class Initialized
INFO - 2016-12-03 04:08:31 --> Language Class Initialized
INFO - 2016-12-03 04:08:31 --> Loader Class Initialized
INFO - 2016-12-03 04:08:31 --> Database Driver Class Initialized
INFO - 2016-12-03 04:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:08:31 --> Controller Class Initialized
INFO - 2016-12-03 04:08:31 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:08:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:08:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:08:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:08:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:08:31 --> Final output sent to browser
DEBUG - 2016-12-03 04:08:31 --> Total execution time: 0.0128
INFO - 2016-12-03 04:09:52 --> Config Class Initialized
INFO - 2016-12-03 04:09:52 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:09:52 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:09:52 --> Utf8 Class Initialized
INFO - 2016-12-03 04:09:52 --> URI Class Initialized
INFO - 2016-12-03 04:09:52 --> Router Class Initialized
INFO - 2016-12-03 04:09:52 --> Output Class Initialized
INFO - 2016-12-03 04:09:52 --> Security Class Initialized
DEBUG - 2016-12-03 04:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:09:52 --> Input Class Initialized
INFO - 2016-12-03 04:09:52 --> Language Class Initialized
INFO - 2016-12-03 04:09:52 --> Loader Class Initialized
INFO - 2016-12-03 04:09:52 --> Database Driver Class Initialized
INFO - 2016-12-03 04:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:09:52 --> Controller Class Initialized
INFO - 2016-12-03 04:09:52 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:09:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:09:52 --> Helper loaded: url_helper
INFO - 2016-12-03 04:09:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:09:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:09:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:09:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:09:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:09:52 --> Final output sent to browser
DEBUG - 2016-12-03 04:09:52 --> Total execution time: 0.0171
INFO - 2016-12-03 04:09:52 --> Config Class Initialized
INFO - 2016-12-03 04:09:52 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:09:52 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:09:52 --> Utf8 Class Initialized
INFO - 2016-12-03 04:09:52 --> URI Class Initialized
INFO - 2016-12-03 04:09:52 --> Router Class Initialized
INFO - 2016-12-03 04:09:52 --> Output Class Initialized
INFO - 2016-12-03 04:09:52 --> Security Class Initialized
DEBUG - 2016-12-03 04:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:09:52 --> Input Class Initialized
INFO - 2016-12-03 04:09:52 --> Language Class Initialized
ERROR - 2016-12-03 04:09:52 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:09:52 --> Config Class Initialized
INFO - 2016-12-03 04:09:52 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:09:52 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:09:52 --> Utf8 Class Initialized
INFO - 2016-12-03 04:09:52 --> URI Class Initialized
INFO - 2016-12-03 04:09:52 --> Router Class Initialized
INFO - 2016-12-03 04:09:52 --> Output Class Initialized
INFO - 2016-12-03 04:09:52 --> Security Class Initialized
DEBUG - 2016-12-03 04:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:09:52 --> Input Class Initialized
INFO - 2016-12-03 04:09:52 --> Language Class Initialized
INFO - 2016-12-03 04:09:52 --> Loader Class Initialized
INFO - 2016-12-03 04:09:52 --> Database Driver Class Initialized
INFO - 2016-12-03 04:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:09:52 --> Controller Class Initialized
INFO - 2016-12-03 04:09:52 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:09:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:09:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:09:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:09:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:09:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:09:52 --> Final output sent to browser
DEBUG - 2016-12-03 04:09:52 --> Total execution time: 0.0139
INFO - 2016-12-03 04:10:01 --> Config Class Initialized
INFO - 2016-12-03 04:10:01 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:10:01 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:10:01 --> Utf8 Class Initialized
INFO - 2016-12-03 04:10:01 --> URI Class Initialized
INFO - 2016-12-03 04:10:01 --> Router Class Initialized
INFO - 2016-12-03 04:10:01 --> Output Class Initialized
INFO - 2016-12-03 04:10:01 --> Security Class Initialized
DEBUG - 2016-12-03 04:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:10:01 --> Input Class Initialized
INFO - 2016-12-03 04:10:01 --> Language Class Initialized
INFO - 2016-12-03 04:10:01 --> Loader Class Initialized
INFO - 2016-12-03 04:10:01 --> Database Driver Class Initialized
INFO - 2016-12-03 04:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:10:01 --> Controller Class Initialized
INFO - 2016-12-03 04:10:01 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:10:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:10:01 --> Helper loaded: url_helper
INFO - 2016-12-03 04:10:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:10:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:10:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:10:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:10:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:10:01 --> Final output sent to browser
DEBUG - 2016-12-03 04:10:01 --> Total execution time: 0.0205
INFO - 2016-12-03 04:10:01 --> Config Class Initialized
INFO - 2016-12-03 04:10:01 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:10:01 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:10:01 --> Utf8 Class Initialized
INFO - 2016-12-03 04:10:01 --> URI Class Initialized
INFO - 2016-12-03 04:10:01 --> Router Class Initialized
INFO - 2016-12-03 04:10:01 --> Output Class Initialized
INFO - 2016-12-03 04:10:01 --> Security Class Initialized
DEBUG - 2016-12-03 04:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:10:01 --> Input Class Initialized
INFO - 2016-12-03 04:10:01 --> Language Class Initialized
ERROR - 2016-12-03 04:10:01 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:10:01 --> Config Class Initialized
INFO - 2016-12-03 04:10:01 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:10:01 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:10:01 --> Utf8 Class Initialized
INFO - 2016-12-03 04:10:01 --> URI Class Initialized
INFO - 2016-12-03 04:10:01 --> Router Class Initialized
INFO - 2016-12-03 04:10:01 --> Output Class Initialized
INFO - 2016-12-03 04:10:01 --> Security Class Initialized
DEBUG - 2016-12-03 04:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:10:01 --> Input Class Initialized
INFO - 2016-12-03 04:10:01 --> Language Class Initialized
INFO - 2016-12-03 04:10:01 --> Loader Class Initialized
INFO - 2016-12-03 04:10:01 --> Database Driver Class Initialized
INFO - 2016-12-03 04:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:10:01 --> Controller Class Initialized
INFO - 2016-12-03 04:10:01 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:10:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:10:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:10:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:10:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:10:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:10:01 --> Final output sent to browser
DEBUG - 2016-12-03 04:10:01 --> Total execution time: 0.0128
INFO - 2016-12-03 04:10:30 --> Config Class Initialized
INFO - 2016-12-03 04:10:30 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:10:30 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:10:30 --> Utf8 Class Initialized
INFO - 2016-12-03 04:10:30 --> URI Class Initialized
INFO - 2016-12-03 04:10:30 --> Router Class Initialized
INFO - 2016-12-03 04:10:30 --> Output Class Initialized
INFO - 2016-12-03 04:10:30 --> Security Class Initialized
DEBUG - 2016-12-03 04:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:10:30 --> Input Class Initialized
INFO - 2016-12-03 04:10:30 --> Language Class Initialized
INFO - 2016-12-03 04:10:30 --> Loader Class Initialized
INFO - 2016-12-03 04:10:30 --> Database Driver Class Initialized
INFO - 2016-12-03 04:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:10:30 --> Controller Class Initialized
INFO - 2016-12-03 04:10:30 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:10:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:10:30 --> Helper loaded: url_helper
INFO - 2016-12-03 04:10:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:10:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:10:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:10:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:10:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:10:30 --> Final output sent to browser
DEBUG - 2016-12-03 04:10:30 --> Total execution time: 0.0180
INFO - 2016-12-03 04:10:30 --> Config Class Initialized
INFO - 2016-12-03 04:10:30 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:10:30 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:10:30 --> Utf8 Class Initialized
INFO - 2016-12-03 04:10:30 --> URI Class Initialized
INFO - 2016-12-03 04:10:30 --> Router Class Initialized
INFO - 2016-12-03 04:10:30 --> Output Class Initialized
INFO - 2016-12-03 04:10:30 --> Security Class Initialized
DEBUG - 2016-12-03 04:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:10:30 --> Input Class Initialized
INFO - 2016-12-03 04:10:30 --> Language Class Initialized
ERROR - 2016-12-03 04:10:30 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:10:31 --> Config Class Initialized
INFO - 2016-12-03 04:10:31 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:10:31 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:10:31 --> Utf8 Class Initialized
INFO - 2016-12-03 04:10:31 --> URI Class Initialized
INFO - 2016-12-03 04:10:31 --> Router Class Initialized
INFO - 2016-12-03 04:10:31 --> Output Class Initialized
INFO - 2016-12-03 04:10:31 --> Security Class Initialized
DEBUG - 2016-12-03 04:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:10:31 --> Input Class Initialized
INFO - 2016-12-03 04:10:31 --> Language Class Initialized
INFO - 2016-12-03 04:10:31 --> Loader Class Initialized
INFO - 2016-12-03 04:10:31 --> Database Driver Class Initialized
INFO - 2016-12-03 04:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:10:31 --> Controller Class Initialized
INFO - 2016-12-03 04:10:31 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:10:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:10:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:10:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:10:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:10:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:10:31 --> Final output sent to browser
DEBUG - 2016-12-03 04:10:31 --> Total execution time: 0.0124
INFO - 2016-12-03 04:10:33 --> Config Class Initialized
INFO - 2016-12-03 04:10:33 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:10:33 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:10:33 --> Utf8 Class Initialized
INFO - 2016-12-03 04:10:33 --> URI Class Initialized
INFO - 2016-12-03 04:10:33 --> Router Class Initialized
INFO - 2016-12-03 04:10:33 --> Output Class Initialized
INFO - 2016-12-03 04:10:33 --> Security Class Initialized
DEBUG - 2016-12-03 04:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:10:33 --> Input Class Initialized
INFO - 2016-12-03 04:10:33 --> Language Class Initialized
INFO - 2016-12-03 04:10:33 --> Loader Class Initialized
INFO - 2016-12-03 04:10:33 --> Database Driver Class Initialized
INFO - 2016-12-03 04:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:10:33 --> Controller Class Initialized
INFO - 2016-12-03 04:10:33 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:10:33 --> Helper loaded: url_helper
INFO - 2016-12-03 04:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:10:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:10:33 --> Final output sent to browser
DEBUG - 2016-12-03 04:10:33 --> Total execution time: 0.0233
INFO - 2016-12-03 04:10:33 --> Config Class Initialized
INFO - 2016-12-03 04:10:33 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:10:33 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:10:33 --> Utf8 Class Initialized
INFO - 2016-12-03 04:10:33 --> URI Class Initialized
INFO - 2016-12-03 04:10:33 --> Router Class Initialized
INFO - 2016-12-03 04:10:33 --> Output Class Initialized
INFO - 2016-12-03 04:10:33 --> Security Class Initialized
DEBUG - 2016-12-03 04:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:10:33 --> Input Class Initialized
INFO - 2016-12-03 04:10:33 --> Language Class Initialized
ERROR - 2016-12-03 04:10:33 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:10:34 --> Config Class Initialized
INFO - 2016-12-03 04:10:34 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:10:34 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:10:34 --> Utf8 Class Initialized
INFO - 2016-12-03 04:10:34 --> URI Class Initialized
INFO - 2016-12-03 04:10:34 --> Router Class Initialized
INFO - 2016-12-03 04:10:34 --> Output Class Initialized
INFO - 2016-12-03 04:10:34 --> Security Class Initialized
DEBUG - 2016-12-03 04:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:10:34 --> Input Class Initialized
INFO - 2016-12-03 04:10:34 --> Language Class Initialized
INFO - 2016-12-03 04:10:34 --> Loader Class Initialized
INFO - 2016-12-03 04:10:34 --> Database Driver Class Initialized
INFO - 2016-12-03 04:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:10:34 --> Controller Class Initialized
INFO - 2016-12-03 04:10:34 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:10:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:10:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:10:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:10:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:10:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:10:34 --> Final output sent to browser
DEBUG - 2016-12-03 04:10:34 --> Total execution time: 0.0134
INFO - 2016-12-03 04:22:28 --> Config Class Initialized
INFO - 2016-12-03 04:22:28 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:22:28 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:22:28 --> Utf8 Class Initialized
INFO - 2016-12-03 04:22:28 --> URI Class Initialized
INFO - 2016-12-03 04:22:28 --> Router Class Initialized
INFO - 2016-12-03 04:22:28 --> Output Class Initialized
INFO - 2016-12-03 04:22:28 --> Security Class Initialized
DEBUG - 2016-12-03 04:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:22:28 --> Input Class Initialized
INFO - 2016-12-03 04:22:28 --> Language Class Initialized
INFO - 2016-12-03 04:22:28 --> Loader Class Initialized
INFO - 2016-12-03 04:22:28 --> Database Driver Class Initialized
INFO - 2016-12-03 04:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:22:28 --> Controller Class Initialized
INFO - 2016-12-03 04:22:28 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:22:28 --> Helper loaded: url_helper
INFO - 2016-12-03 04:22:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:22:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:22:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:22:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:22:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:22:28 --> Final output sent to browser
DEBUG - 2016-12-03 04:22:28 --> Total execution time: 0.0361
INFO - 2016-12-03 04:22:29 --> Config Class Initialized
INFO - 2016-12-03 04:22:29 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:22:29 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:22:29 --> Utf8 Class Initialized
INFO - 2016-12-03 04:22:29 --> URI Class Initialized
INFO - 2016-12-03 04:22:29 --> Router Class Initialized
INFO - 2016-12-03 04:22:29 --> Output Class Initialized
INFO - 2016-12-03 04:22:29 --> Security Class Initialized
DEBUG - 2016-12-03 04:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:22:29 --> Input Class Initialized
INFO - 2016-12-03 04:22:29 --> Language Class Initialized
ERROR - 2016-12-03 04:22:29 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:22:29 --> Config Class Initialized
INFO - 2016-12-03 04:22:29 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:22:29 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:22:29 --> Utf8 Class Initialized
INFO - 2016-12-03 04:22:29 --> URI Class Initialized
INFO - 2016-12-03 04:22:29 --> Router Class Initialized
INFO - 2016-12-03 04:22:29 --> Output Class Initialized
INFO - 2016-12-03 04:22:29 --> Security Class Initialized
DEBUG - 2016-12-03 04:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:22:29 --> Input Class Initialized
INFO - 2016-12-03 04:22:29 --> Language Class Initialized
INFO - 2016-12-03 04:22:29 --> Loader Class Initialized
INFO - 2016-12-03 04:22:29 --> Database Driver Class Initialized
INFO - 2016-12-03 04:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:22:29 --> Controller Class Initialized
INFO - 2016-12-03 04:22:29 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:22:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:22:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:22:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:22:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:22:29 --> Final output sent to browser
DEBUG - 2016-12-03 04:22:29 --> Total execution time: 0.0135
INFO - 2016-12-03 04:24:10 --> Config Class Initialized
INFO - 2016-12-03 04:24:10 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:24:10 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:24:10 --> Utf8 Class Initialized
INFO - 2016-12-03 04:24:10 --> URI Class Initialized
INFO - 2016-12-03 04:24:10 --> Router Class Initialized
INFO - 2016-12-03 04:24:10 --> Output Class Initialized
INFO - 2016-12-03 04:24:10 --> Security Class Initialized
DEBUG - 2016-12-03 04:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:24:10 --> Input Class Initialized
INFO - 2016-12-03 04:24:10 --> Language Class Initialized
INFO - 2016-12-03 04:24:10 --> Loader Class Initialized
INFO - 2016-12-03 04:24:10 --> Database Driver Class Initialized
INFO - 2016-12-03 04:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:24:10 --> Controller Class Initialized
INFO - 2016-12-03 04:24:10 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:24:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:24:10 --> Helper loaded: url_helper
INFO - 2016-12-03 04:24:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:24:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:24:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:24:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:24:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:24:10 --> Final output sent to browser
DEBUG - 2016-12-03 04:24:10 --> Total execution time: 0.0164
INFO - 2016-12-03 04:24:10 --> Config Class Initialized
INFO - 2016-12-03 04:24:10 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:24:10 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:24:10 --> Utf8 Class Initialized
INFO - 2016-12-03 04:24:10 --> URI Class Initialized
INFO - 2016-12-03 04:24:10 --> Router Class Initialized
INFO - 2016-12-03 04:24:10 --> Output Class Initialized
INFO - 2016-12-03 04:24:10 --> Security Class Initialized
DEBUG - 2016-12-03 04:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:24:10 --> Input Class Initialized
INFO - 2016-12-03 04:24:10 --> Language Class Initialized
ERROR - 2016-12-03 04:24:10 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:24:10 --> Config Class Initialized
INFO - 2016-12-03 04:24:10 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:24:10 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:24:10 --> Utf8 Class Initialized
INFO - 2016-12-03 04:24:10 --> URI Class Initialized
INFO - 2016-12-03 04:24:10 --> Router Class Initialized
INFO - 2016-12-03 04:24:10 --> Output Class Initialized
INFO - 2016-12-03 04:24:10 --> Security Class Initialized
DEBUG - 2016-12-03 04:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:24:10 --> Input Class Initialized
INFO - 2016-12-03 04:24:10 --> Language Class Initialized
INFO - 2016-12-03 04:24:10 --> Loader Class Initialized
INFO - 2016-12-03 04:24:10 --> Database Driver Class Initialized
INFO - 2016-12-03 04:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:24:10 --> Controller Class Initialized
INFO - 2016-12-03 04:24:10 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:24:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:24:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:24:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:24:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:24:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:24:10 --> Final output sent to browser
DEBUG - 2016-12-03 04:24:10 --> Total execution time: 0.0133
INFO - 2016-12-03 04:25:31 --> Config Class Initialized
INFO - 2016-12-03 04:25:31 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:25:31 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:25:31 --> Utf8 Class Initialized
INFO - 2016-12-03 04:25:31 --> URI Class Initialized
INFO - 2016-12-03 04:25:31 --> Router Class Initialized
INFO - 2016-12-03 04:25:31 --> Output Class Initialized
INFO - 2016-12-03 04:25:31 --> Security Class Initialized
DEBUG - 2016-12-03 04:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:25:31 --> Input Class Initialized
INFO - 2016-12-03 04:25:31 --> Language Class Initialized
INFO - 2016-12-03 04:25:31 --> Loader Class Initialized
INFO - 2016-12-03 04:25:31 --> Database Driver Class Initialized
INFO - 2016-12-03 04:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:25:31 --> Controller Class Initialized
INFO - 2016-12-03 04:25:31 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:25:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:25:31 --> Helper loaded: url_helper
INFO - 2016-12-03 04:25:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:25:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:25:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:25:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:25:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:25:31 --> Final output sent to browser
DEBUG - 2016-12-03 04:25:31 --> Total execution time: 0.0362
INFO - 2016-12-03 04:25:31 --> Config Class Initialized
INFO - 2016-12-03 04:25:31 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:25:31 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:25:31 --> Utf8 Class Initialized
INFO - 2016-12-03 04:25:31 --> URI Class Initialized
INFO - 2016-12-03 04:25:31 --> Router Class Initialized
INFO - 2016-12-03 04:25:31 --> Output Class Initialized
INFO - 2016-12-03 04:25:31 --> Security Class Initialized
DEBUG - 2016-12-03 04:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:25:31 --> Input Class Initialized
INFO - 2016-12-03 04:25:31 --> Language Class Initialized
ERROR - 2016-12-03 04:25:31 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:25:31 --> Config Class Initialized
INFO - 2016-12-03 04:25:31 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:25:31 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:25:31 --> Utf8 Class Initialized
INFO - 2016-12-03 04:25:31 --> URI Class Initialized
INFO - 2016-12-03 04:25:31 --> Router Class Initialized
INFO - 2016-12-03 04:25:31 --> Output Class Initialized
INFO - 2016-12-03 04:25:31 --> Security Class Initialized
DEBUG - 2016-12-03 04:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:25:31 --> Input Class Initialized
INFO - 2016-12-03 04:25:31 --> Language Class Initialized
INFO - 2016-12-03 04:25:31 --> Loader Class Initialized
INFO - 2016-12-03 04:25:31 --> Database Driver Class Initialized
INFO - 2016-12-03 04:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:25:31 --> Controller Class Initialized
INFO - 2016-12-03 04:25:31 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:25:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:25:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:25:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:25:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:25:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:25:31 --> Final output sent to browser
DEBUG - 2016-12-03 04:25:31 --> Total execution time: 0.0136
INFO - 2016-12-03 04:26:13 --> Config Class Initialized
INFO - 2016-12-03 04:26:13 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:26:13 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:26:13 --> Utf8 Class Initialized
INFO - 2016-12-03 04:26:13 --> URI Class Initialized
INFO - 2016-12-03 04:26:13 --> Router Class Initialized
INFO - 2016-12-03 04:26:13 --> Output Class Initialized
INFO - 2016-12-03 04:26:13 --> Security Class Initialized
DEBUG - 2016-12-03 04:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:26:13 --> Input Class Initialized
INFO - 2016-12-03 04:26:13 --> Language Class Initialized
INFO - 2016-12-03 04:26:13 --> Loader Class Initialized
INFO - 2016-12-03 04:26:13 --> Database Driver Class Initialized
INFO - 2016-12-03 04:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:26:13 --> Controller Class Initialized
INFO - 2016-12-03 04:26:13 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:26:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:26:13 --> Helper loaded: url_helper
INFO - 2016-12-03 04:26:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:26:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:26:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:26:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:26:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:26:13 --> Final output sent to browser
DEBUG - 2016-12-03 04:26:13 --> Total execution time: 0.0184
INFO - 2016-12-03 04:26:13 --> Config Class Initialized
INFO - 2016-12-03 04:26:13 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:26:13 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:26:13 --> Utf8 Class Initialized
INFO - 2016-12-03 04:26:13 --> URI Class Initialized
INFO - 2016-12-03 04:26:13 --> Router Class Initialized
INFO - 2016-12-03 04:26:13 --> Output Class Initialized
INFO - 2016-12-03 04:26:13 --> Security Class Initialized
DEBUG - 2016-12-03 04:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:26:13 --> Input Class Initialized
INFO - 2016-12-03 04:26:13 --> Language Class Initialized
ERROR - 2016-12-03 04:26:13 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:26:13 --> Config Class Initialized
INFO - 2016-12-03 04:26:13 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:26:13 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:26:13 --> Utf8 Class Initialized
INFO - 2016-12-03 04:26:13 --> URI Class Initialized
INFO - 2016-12-03 04:26:13 --> Router Class Initialized
INFO - 2016-12-03 04:26:13 --> Output Class Initialized
INFO - 2016-12-03 04:26:13 --> Security Class Initialized
DEBUG - 2016-12-03 04:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:26:13 --> Input Class Initialized
INFO - 2016-12-03 04:26:13 --> Language Class Initialized
INFO - 2016-12-03 04:26:13 --> Loader Class Initialized
INFO - 2016-12-03 04:26:13 --> Database Driver Class Initialized
INFO - 2016-12-03 04:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:26:13 --> Controller Class Initialized
INFO - 2016-12-03 04:26:13 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:26:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:26:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:26:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:26:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:26:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:26:13 --> Final output sent to browser
DEBUG - 2016-12-03 04:26:13 --> Total execution time: 0.0140
INFO - 2016-12-03 04:26:41 --> Config Class Initialized
INFO - 2016-12-03 04:26:41 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:26:41 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:26:41 --> Utf8 Class Initialized
INFO - 2016-12-03 04:26:41 --> URI Class Initialized
INFO - 2016-12-03 04:26:41 --> Router Class Initialized
INFO - 2016-12-03 04:26:41 --> Output Class Initialized
INFO - 2016-12-03 04:26:41 --> Security Class Initialized
DEBUG - 2016-12-03 04:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:26:41 --> Input Class Initialized
INFO - 2016-12-03 04:26:41 --> Language Class Initialized
INFO - 2016-12-03 04:26:41 --> Loader Class Initialized
INFO - 2016-12-03 04:26:41 --> Database Driver Class Initialized
INFO - 2016-12-03 04:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:26:41 --> Controller Class Initialized
INFO - 2016-12-03 04:26:41 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:26:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:26:41 --> Helper loaded: url_helper
INFO - 2016-12-03 04:26:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:26:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:26:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:26:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:26:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:26:41 --> Final output sent to browser
DEBUG - 2016-12-03 04:26:41 --> Total execution time: 0.0496
INFO - 2016-12-03 04:26:42 --> Config Class Initialized
INFO - 2016-12-03 04:26:42 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:26:42 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:26:42 --> Utf8 Class Initialized
INFO - 2016-12-03 04:26:42 --> URI Class Initialized
INFO - 2016-12-03 04:26:42 --> Router Class Initialized
INFO - 2016-12-03 04:26:42 --> Output Class Initialized
INFO - 2016-12-03 04:26:42 --> Security Class Initialized
DEBUG - 2016-12-03 04:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:26:42 --> Input Class Initialized
INFO - 2016-12-03 04:26:42 --> Language Class Initialized
ERROR - 2016-12-03 04:26:42 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:26:42 --> Config Class Initialized
INFO - 2016-12-03 04:26:42 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:26:42 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:26:42 --> Utf8 Class Initialized
INFO - 2016-12-03 04:26:42 --> URI Class Initialized
INFO - 2016-12-03 04:26:42 --> Router Class Initialized
INFO - 2016-12-03 04:26:42 --> Output Class Initialized
INFO - 2016-12-03 04:26:42 --> Security Class Initialized
DEBUG - 2016-12-03 04:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:26:42 --> Input Class Initialized
INFO - 2016-12-03 04:26:42 --> Language Class Initialized
INFO - 2016-12-03 04:26:42 --> Loader Class Initialized
INFO - 2016-12-03 04:26:42 --> Database Driver Class Initialized
INFO - 2016-12-03 04:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:26:42 --> Controller Class Initialized
INFO - 2016-12-03 04:26:42 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:26:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:26:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:26:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:26:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:26:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:26:42 --> Final output sent to browser
DEBUG - 2016-12-03 04:26:42 --> Total execution time: 0.0139
INFO - 2016-12-03 04:27:25 --> Config Class Initialized
INFO - 2016-12-03 04:27:25 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:27:25 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:27:25 --> Utf8 Class Initialized
INFO - 2016-12-03 04:27:25 --> URI Class Initialized
INFO - 2016-12-03 04:27:25 --> Router Class Initialized
INFO - 2016-12-03 04:27:25 --> Output Class Initialized
INFO - 2016-12-03 04:27:25 --> Security Class Initialized
DEBUG - 2016-12-03 04:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:27:25 --> Input Class Initialized
INFO - 2016-12-03 04:27:25 --> Language Class Initialized
INFO - 2016-12-03 04:27:25 --> Loader Class Initialized
INFO - 2016-12-03 04:27:25 --> Database Driver Class Initialized
INFO - 2016-12-03 04:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:27:25 --> Controller Class Initialized
INFO - 2016-12-03 04:27:25 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:27:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:27:25 --> Helper loaded: url_helper
INFO - 2016-12-03 04:27:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:27:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:27:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:27:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:27:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:27:25 --> Final output sent to browser
DEBUG - 2016-12-03 04:27:25 --> Total execution time: 0.0173
INFO - 2016-12-03 04:27:26 --> Config Class Initialized
INFO - 2016-12-03 04:27:26 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:27:26 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:27:26 --> Utf8 Class Initialized
INFO - 2016-12-03 04:27:26 --> URI Class Initialized
INFO - 2016-12-03 04:27:26 --> Router Class Initialized
INFO - 2016-12-03 04:27:26 --> Output Class Initialized
INFO - 2016-12-03 04:27:26 --> Security Class Initialized
DEBUG - 2016-12-03 04:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:27:26 --> Input Class Initialized
INFO - 2016-12-03 04:27:26 --> Language Class Initialized
ERROR - 2016-12-03 04:27:26 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:27:26 --> Config Class Initialized
INFO - 2016-12-03 04:27:26 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:27:26 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:27:26 --> Utf8 Class Initialized
INFO - 2016-12-03 04:27:26 --> URI Class Initialized
INFO - 2016-12-03 04:27:26 --> Router Class Initialized
INFO - 2016-12-03 04:27:26 --> Output Class Initialized
INFO - 2016-12-03 04:27:26 --> Security Class Initialized
DEBUG - 2016-12-03 04:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:27:26 --> Input Class Initialized
INFO - 2016-12-03 04:27:26 --> Language Class Initialized
INFO - 2016-12-03 04:27:26 --> Loader Class Initialized
INFO - 2016-12-03 04:27:26 --> Database Driver Class Initialized
INFO - 2016-12-03 04:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:27:26 --> Controller Class Initialized
INFO - 2016-12-03 04:27:26 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:27:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:27:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:27:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:27:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:27:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:27:26 --> Final output sent to browser
DEBUG - 2016-12-03 04:27:26 --> Total execution time: 0.0134
INFO - 2016-12-03 04:28:27 --> Config Class Initialized
INFO - 2016-12-03 04:28:27 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:28:27 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:28:27 --> Utf8 Class Initialized
INFO - 2016-12-03 04:28:27 --> URI Class Initialized
INFO - 2016-12-03 04:28:27 --> Router Class Initialized
INFO - 2016-12-03 04:28:27 --> Output Class Initialized
INFO - 2016-12-03 04:28:27 --> Security Class Initialized
DEBUG - 2016-12-03 04:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:28:27 --> Input Class Initialized
INFO - 2016-12-03 04:28:27 --> Language Class Initialized
INFO - 2016-12-03 04:28:27 --> Loader Class Initialized
INFO - 2016-12-03 04:28:27 --> Database Driver Class Initialized
INFO - 2016-12-03 04:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:28:27 --> Controller Class Initialized
INFO - 2016-12-03 04:28:27 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:28:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:28:27 --> Helper loaded: url_helper
INFO - 2016-12-03 04:28:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:28:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:28:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:28:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:28:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:28:27 --> Final output sent to browser
DEBUG - 2016-12-03 04:28:27 --> Total execution time: 0.0167
INFO - 2016-12-03 04:28:27 --> Config Class Initialized
INFO - 2016-12-03 04:28:27 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:28:27 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:28:27 --> Utf8 Class Initialized
INFO - 2016-12-03 04:28:27 --> URI Class Initialized
INFO - 2016-12-03 04:28:27 --> Router Class Initialized
INFO - 2016-12-03 04:28:27 --> Output Class Initialized
INFO - 2016-12-03 04:28:27 --> Security Class Initialized
DEBUG - 2016-12-03 04:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:28:27 --> Input Class Initialized
INFO - 2016-12-03 04:28:27 --> Language Class Initialized
ERROR - 2016-12-03 04:28:27 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:28:28 --> Config Class Initialized
INFO - 2016-12-03 04:28:28 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:28:28 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:28:28 --> Utf8 Class Initialized
INFO - 2016-12-03 04:28:28 --> URI Class Initialized
INFO - 2016-12-03 04:28:28 --> Router Class Initialized
INFO - 2016-12-03 04:28:28 --> Output Class Initialized
INFO - 2016-12-03 04:28:28 --> Security Class Initialized
DEBUG - 2016-12-03 04:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:28:28 --> Input Class Initialized
INFO - 2016-12-03 04:28:28 --> Language Class Initialized
INFO - 2016-12-03 04:28:28 --> Loader Class Initialized
INFO - 2016-12-03 04:28:28 --> Database Driver Class Initialized
INFO - 2016-12-03 04:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:28:28 --> Controller Class Initialized
INFO - 2016-12-03 04:28:28 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:28:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:28:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:28:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:28:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:28:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:28:28 --> Final output sent to browser
DEBUG - 2016-12-03 04:28:28 --> Total execution time: 0.0145
INFO - 2016-12-03 04:31:30 --> Config Class Initialized
INFO - 2016-12-03 04:31:30 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:31:30 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:31:30 --> Utf8 Class Initialized
INFO - 2016-12-03 04:31:30 --> URI Class Initialized
INFO - 2016-12-03 04:31:30 --> Router Class Initialized
INFO - 2016-12-03 04:31:30 --> Output Class Initialized
INFO - 2016-12-03 04:31:30 --> Security Class Initialized
DEBUG - 2016-12-03 04:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:31:30 --> Input Class Initialized
INFO - 2016-12-03 04:31:30 --> Language Class Initialized
INFO - 2016-12-03 04:31:30 --> Loader Class Initialized
INFO - 2016-12-03 04:31:30 --> Database Driver Class Initialized
INFO - 2016-12-03 04:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:31:30 --> Controller Class Initialized
INFO - 2016-12-03 04:31:30 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:31:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:31:30 --> Helper loaded: url_helper
INFO - 2016-12-03 04:31:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:31:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:31:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:31:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:31:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:31:30 --> Final output sent to browser
DEBUG - 2016-12-03 04:31:30 --> Total execution time: 0.0164
INFO - 2016-12-03 04:31:30 --> Config Class Initialized
INFO - 2016-12-03 04:31:30 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:31:30 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:31:30 --> Utf8 Class Initialized
INFO - 2016-12-03 04:31:30 --> URI Class Initialized
INFO - 2016-12-03 04:31:30 --> Router Class Initialized
INFO - 2016-12-03 04:31:30 --> Output Class Initialized
INFO - 2016-12-03 04:31:30 --> Security Class Initialized
DEBUG - 2016-12-03 04:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:31:30 --> Input Class Initialized
INFO - 2016-12-03 04:31:30 --> Language Class Initialized
ERROR - 2016-12-03 04:31:30 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:31:31 --> Config Class Initialized
INFO - 2016-12-03 04:31:31 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:31:31 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:31:31 --> Utf8 Class Initialized
INFO - 2016-12-03 04:31:31 --> URI Class Initialized
INFO - 2016-12-03 04:31:31 --> Router Class Initialized
INFO - 2016-12-03 04:31:31 --> Output Class Initialized
INFO - 2016-12-03 04:31:31 --> Security Class Initialized
DEBUG - 2016-12-03 04:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:31:31 --> Input Class Initialized
INFO - 2016-12-03 04:31:31 --> Language Class Initialized
INFO - 2016-12-03 04:31:31 --> Loader Class Initialized
INFO - 2016-12-03 04:31:31 --> Database Driver Class Initialized
INFO - 2016-12-03 04:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:31:31 --> Controller Class Initialized
INFO - 2016-12-03 04:31:31 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:31:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:31:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:31:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:31:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:31:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:31:31 --> Final output sent to browser
DEBUG - 2016-12-03 04:31:31 --> Total execution time: 0.0180
INFO - 2016-12-03 04:31:45 --> Config Class Initialized
INFO - 2016-12-03 04:31:45 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:31:45 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:31:45 --> Utf8 Class Initialized
INFO - 2016-12-03 04:31:45 --> URI Class Initialized
INFO - 2016-12-03 04:31:45 --> Router Class Initialized
INFO - 2016-12-03 04:31:45 --> Output Class Initialized
INFO - 2016-12-03 04:31:45 --> Security Class Initialized
DEBUG - 2016-12-03 04:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:31:45 --> Input Class Initialized
INFO - 2016-12-03 04:31:45 --> Language Class Initialized
INFO - 2016-12-03 04:31:45 --> Loader Class Initialized
INFO - 2016-12-03 04:31:45 --> Database Driver Class Initialized
INFO - 2016-12-03 04:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:31:45 --> Controller Class Initialized
INFO - 2016-12-03 04:31:45 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:31:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:31:45 --> Helper loaded: url_helper
INFO - 2016-12-03 04:31:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:31:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:31:46 --> Final output sent to browser
DEBUG - 2016-12-03 04:31:46 --> Total execution time: 0.0172
INFO - 2016-12-03 04:31:46 --> Config Class Initialized
INFO - 2016-12-03 04:31:46 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:31:46 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:31:46 --> Utf8 Class Initialized
INFO - 2016-12-03 04:31:46 --> URI Class Initialized
INFO - 2016-12-03 04:31:46 --> Router Class Initialized
INFO - 2016-12-03 04:31:46 --> Output Class Initialized
INFO - 2016-12-03 04:31:46 --> Security Class Initialized
DEBUG - 2016-12-03 04:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:31:46 --> Input Class Initialized
INFO - 2016-12-03 04:31:46 --> Language Class Initialized
ERROR - 2016-12-03 04:31:46 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:31:46 --> Config Class Initialized
INFO - 2016-12-03 04:31:46 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:31:46 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:31:46 --> Utf8 Class Initialized
INFO - 2016-12-03 04:31:46 --> URI Class Initialized
INFO - 2016-12-03 04:31:46 --> Router Class Initialized
INFO - 2016-12-03 04:31:46 --> Output Class Initialized
INFO - 2016-12-03 04:31:46 --> Security Class Initialized
DEBUG - 2016-12-03 04:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:31:46 --> Input Class Initialized
INFO - 2016-12-03 04:31:46 --> Language Class Initialized
INFO - 2016-12-03 04:31:46 --> Loader Class Initialized
INFO - 2016-12-03 04:31:46 --> Database Driver Class Initialized
INFO - 2016-12-03 04:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:31:46 --> Controller Class Initialized
INFO - 2016-12-03 04:31:46 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:31:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:31:46 --> Final output sent to browser
DEBUG - 2016-12-03 04:31:46 --> Total execution time: 0.0138
INFO - 2016-12-03 04:34:31 --> Config Class Initialized
INFO - 2016-12-03 04:34:31 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:34:31 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:34:31 --> Utf8 Class Initialized
INFO - 2016-12-03 04:34:31 --> URI Class Initialized
INFO - 2016-12-03 04:34:31 --> Router Class Initialized
INFO - 2016-12-03 04:34:31 --> Output Class Initialized
INFO - 2016-12-03 04:34:31 --> Security Class Initialized
DEBUG - 2016-12-03 04:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:34:31 --> Input Class Initialized
INFO - 2016-12-03 04:34:31 --> Language Class Initialized
INFO - 2016-12-03 04:34:31 --> Loader Class Initialized
INFO - 2016-12-03 04:34:31 --> Database Driver Class Initialized
INFO - 2016-12-03 04:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:34:31 --> Controller Class Initialized
INFO - 2016-12-03 04:34:31 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:34:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:34:31 --> Helper loaded: url_helper
INFO - 2016-12-03 04:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:34:31 --> Final output sent to browser
DEBUG - 2016-12-03 04:34:31 --> Total execution time: 0.0172
INFO - 2016-12-03 04:34:31 --> Config Class Initialized
INFO - 2016-12-03 04:34:31 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:34:31 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:34:31 --> Utf8 Class Initialized
INFO - 2016-12-03 04:34:31 --> URI Class Initialized
INFO - 2016-12-03 04:34:31 --> Router Class Initialized
INFO - 2016-12-03 04:34:31 --> Output Class Initialized
INFO - 2016-12-03 04:34:31 --> Security Class Initialized
DEBUG - 2016-12-03 04:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:34:31 --> Input Class Initialized
INFO - 2016-12-03 04:34:31 --> Language Class Initialized
ERROR - 2016-12-03 04:34:31 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:34:31 --> Config Class Initialized
INFO - 2016-12-03 04:34:31 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:34:31 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:34:31 --> Utf8 Class Initialized
INFO - 2016-12-03 04:34:31 --> URI Class Initialized
INFO - 2016-12-03 04:34:31 --> Router Class Initialized
INFO - 2016-12-03 04:34:31 --> Output Class Initialized
INFO - 2016-12-03 04:34:31 --> Security Class Initialized
DEBUG - 2016-12-03 04:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:34:31 --> Input Class Initialized
INFO - 2016-12-03 04:34:31 --> Language Class Initialized
INFO - 2016-12-03 04:34:31 --> Loader Class Initialized
INFO - 2016-12-03 04:34:31 --> Database Driver Class Initialized
INFO - 2016-12-03 04:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:34:31 --> Controller Class Initialized
INFO - 2016-12-03 04:34:31 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:34:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:34:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:34:31 --> Final output sent to browser
DEBUG - 2016-12-03 04:34:31 --> Total execution time: 0.0137
INFO - 2016-12-03 04:34:36 --> Config Class Initialized
INFO - 2016-12-03 04:34:36 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:34:36 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:34:36 --> Utf8 Class Initialized
INFO - 2016-12-03 04:34:36 --> URI Class Initialized
INFO - 2016-12-03 04:34:36 --> Router Class Initialized
INFO - 2016-12-03 04:34:36 --> Output Class Initialized
INFO - 2016-12-03 04:34:36 --> Security Class Initialized
DEBUG - 2016-12-03 04:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:34:36 --> Input Class Initialized
INFO - 2016-12-03 04:34:36 --> Language Class Initialized
INFO - 2016-12-03 04:34:36 --> Loader Class Initialized
INFO - 2016-12-03 04:34:36 --> Database Driver Class Initialized
INFO - 2016-12-03 04:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:34:36 --> Controller Class Initialized
INFO - 2016-12-03 04:34:36 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:34:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:34:36 --> Helper loaded: url_helper
INFO - 2016-12-03 04:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:34:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:34:36 --> Final output sent to browser
DEBUG - 2016-12-03 04:34:36 --> Total execution time: 0.0167
INFO - 2016-12-03 04:34:36 --> Config Class Initialized
INFO - 2016-12-03 04:34:36 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:34:36 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:34:36 --> Utf8 Class Initialized
INFO - 2016-12-03 04:34:36 --> URI Class Initialized
INFO - 2016-12-03 04:34:36 --> Router Class Initialized
INFO - 2016-12-03 04:34:36 --> Output Class Initialized
INFO - 2016-12-03 04:34:36 --> Security Class Initialized
DEBUG - 2016-12-03 04:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:34:36 --> Input Class Initialized
INFO - 2016-12-03 04:34:36 --> Language Class Initialized
ERROR - 2016-12-03 04:34:36 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:34:37 --> Config Class Initialized
INFO - 2016-12-03 04:34:37 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:34:37 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:34:37 --> Utf8 Class Initialized
INFO - 2016-12-03 04:34:37 --> URI Class Initialized
INFO - 2016-12-03 04:34:37 --> Router Class Initialized
INFO - 2016-12-03 04:34:37 --> Output Class Initialized
INFO - 2016-12-03 04:34:37 --> Security Class Initialized
DEBUG - 2016-12-03 04:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:34:37 --> Input Class Initialized
INFO - 2016-12-03 04:34:37 --> Language Class Initialized
INFO - 2016-12-03 04:34:37 --> Loader Class Initialized
INFO - 2016-12-03 04:34:37 --> Database Driver Class Initialized
INFO - 2016-12-03 04:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:34:37 --> Controller Class Initialized
INFO - 2016-12-03 04:34:37 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:34:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:34:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:34:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:34:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:34:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:34:37 --> Final output sent to browser
DEBUG - 2016-12-03 04:34:37 --> Total execution time: 0.0132
INFO - 2016-12-03 04:35:37 --> Config Class Initialized
INFO - 2016-12-03 04:35:37 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:35:37 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:35:37 --> Utf8 Class Initialized
INFO - 2016-12-03 04:35:37 --> URI Class Initialized
INFO - 2016-12-03 04:35:37 --> Router Class Initialized
INFO - 2016-12-03 04:35:37 --> Output Class Initialized
INFO - 2016-12-03 04:35:37 --> Security Class Initialized
DEBUG - 2016-12-03 04:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:35:37 --> Input Class Initialized
INFO - 2016-12-03 04:35:37 --> Language Class Initialized
INFO - 2016-12-03 04:35:37 --> Loader Class Initialized
INFO - 2016-12-03 04:35:37 --> Database Driver Class Initialized
INFO - 2016-12-03 04:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:35:37 --> Controller Class Initialized
INFO - 2016-12-03 04:35:37 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:35:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:35:37 --> Helper loaded: url_helper
INFO - 2016-12-03 04:35:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:35:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:35:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:35:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:35:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:35:37 --> Final output sent to browser
DEBUG - 2016-12-03 04:35:37 --> Total execution time: 0.0174
INFO - 2016-12-03 04:35:38 --> Config Class Initialized
INFO - 2016-12-03 04:35:38 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:35:38 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:35:38 --> Utf8 Class Initialized
INFO - 2016-12-03 04:35:38 --> URI Class Initialized
INFO - 2016-12-03 04:35:38 --> Router Class Initialized
INFO - 2016-12-03 04:35:38 --> Output Class Initialized
INFO - 2016-12-03 04:35:38 --> Security Class Initialized
DEBUG - 2016-12-03 04:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:35:38 --> Input Class Initialized
INFO - 2016-12-03 04:35:38 --> Language Class Initialized
ERROR - 2016-12-03 04:35:38 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:35:38 --> Config Class Initialized
INFO - 2016-12-03 04:35:38 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:35:38 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:35:38 --> Utf8 Class Initialized
INFO - 2016-12-03 04:35:38 --> URI Class Initialized
INFO - 2016-12-03 04:35:38 --> Router Class Initialized
INFO - 2016-12-03 04:35:38 --> Output Class Initialized
INFO - 2016-12-03 04:35:38 --> Security Class Initialized
DEBUG - 2016-12-03 04:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:35:38 --> Input Class Initialized
INFO - 2016-12-03 04:35:38 --> Language Class Initialized
INFO - 2016-12-03 04:35:38 --> Loader Class Initialized
INFO - 2016-12-03 04:35:38 --> Database Driver Class Initialized
INFO - 2016-12-03 04:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:35:38 --> Controller Class Initialized
INFO - 2016-12-03 04:35:38 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:35:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:35:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:35:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:35:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:35:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:35:38 --> Final output sent to browser
DEBUG - 2016-12-03 04:35:38 --> Total execution time: 0.0142
INFO - 2016-12-03 04:35:39 --> Config Class Initialized
INFO - 2016-12-03 04:35:39 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:35:39 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:35:39 --> Utf8 Class Initialized
INFO - 2016-12-03 04:35:39 --> URI Class Initialized
INFO - 2016-12-03 04:35:39 --> Router Class Initialized
INFO - 2016-12-03 04:35:39 --> Output Class Initialized
INFO - 2016-12-03 04:35:39 --> Security Class Initialized
DEBUG - 2016-12-03 04:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:35:39 --> Input Class Initialized
INFO - 2016-12-03 04:35:39 --> Language Class Initialized
INFO - 2016-12-03 04:35:39 --> Loader Class Initialized
INFO - 2016-12-03 04:35:39 --> Database Driver Class Initialized
INFO - 2016-12-03 04:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:35:39 --> Controller Class Initialized
INFO - 2016-12-03 04:35:39 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:35:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:35:39 --> Helper loaded: url_helper
INFO - 2016-12-03 04:35:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:35:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:35:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:35:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:35:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:35:39 --> Final output sent to browser
DEBUG - 2016-12-03 04:35:39 --> Total execution time: 0.0750
INFO - 2016-12-03 04:35:40 --> Config Class Initialized
INFO - 2016-12-03 04:35:40 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:35:40 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:35:40 --> Utf8 Class Initialized
INFO - 2016-12-03 04:35:40 --> URI Class Initialized
INFO - 2016-12-03 04:35:40 --> Router Class Initialized
INFO - 2016-12-03 04:35:40 --> Output Class Initialized
INFO - 2016-12-03 04:35:40 --> Security Class Initialized
DEBUG - 2016-12-03 04:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:35:40 --> Input Class Initialized
INFO - 2016-12-03 04:35:40 --> Language Class Initialized
ERROR - 2016-12-03 04:35:40 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:35:41 --> Config Class Initialized
INFO - 2016-12-03 04:35:41 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:35:41 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:35:41 --> Utf8 Class Initialized
INFO - 2016-12-03 04:35:41 --> URI Class Initialized
INFO - 2016-12-03 04:35:41 --> Router Class Initialized
INFO - 2016-12-03 04:35:41 --> Output Class Initialized
INFO - 2016-12-03 04:35:41 --> Security Class Initialized
DEBUG - 2016-12-03 04:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:35:41 --> Input Class Initialized
INFO - 2016-12-03 04:35:41 --> Language Class Initialized
INFO - 2016-12-03 04:35:41 --> Loader Class Initialized
INFO - 2016-12-03 04:35:41 --> Database Driver Class Initialized
INFO - 2016-12-03 04:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:35:41 --> Controller Class Initialized
INFO - 2016-12-03 04:35:41 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:35:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:35:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:35:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:35:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:35:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:35:41 --> Final output sent to browser
DEBUG - 2016-12-03 04:35:41 --> Total execution time: 0.0535
INFO - 2016-12-03 04:37:46 --> Config Class Initialized
INFO - 2016-12-03 04:37:46 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:37:46 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:37:46 --> Utf8 Class Initialized
INFO - 2016-12-03 04:37:46 --> URI Class Initialized
INFO - 2016-12-03 04:37:46 --> Router Class Initialized
INFO - 2016-12-03 04:37:46 --> Output Class Initialized
INFO - 2016-12-03 04:37:46 --> Security Class Initialized
DEBUG - 2016-12-03 04:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:37:46 --> Input Class Initialized
INFO - 2016-12-03 04:37:46 --> Language Class Initialized
INFO - 2016-12-03 04:37:46 --> Loader Class Initialized
INFO - 2016-12-03 04:37:46 --> Database Driver Class Initialized
INFO - 2016-12-03 04:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:37:46 --> Controller Class Initialized
INFO - 2016-12-03 04:37:46 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:37:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:37:46 --> Helper loaded: url_helper
INFO - 2016-12-03 04:37:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:37:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:37:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:37:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:37:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:37:46 --> Final output sent to browser
DEBUG - 2016-12-03 04:37:46 --> Total execution time: 0.0179
INFO - 2016-12-03 04:37:46 --> Config Class Initialized
INFO - 2016-12-03 04:37:46 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:37:46 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:37:46 --> Utf8 Class Initialized
INFO - 2016-12-03 04:37:46 --> URI Class Initialized
INFO - 2016-12-03 04:37:46 --> Router Class Initialized
INFO - 2016-12-03 04:37:46 --> Output Class Initialized
INFO - 2016-12-03 04:37:46 --> Security Class Initialized
DEBUG - 2016-12-03 04:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:37:46 --> Input Class Initialized
INFO - 2016-12-03 04:37:46 --> Language Class Initialized
ERROR - 2016-12-03 04:37:46 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:37:46 --> Config Class Initialized
INFO - 2016-12-03 04:37:46 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:37:46 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:37:46 --> Utf8 Class Initialized
INFO - 2016-12-03 04:37:46 --> URI Class Initialized
INFO - 2016-12-03 04:37:46 --> Router Class Initialized
INFO - 2016-12-03 04:37:46 --> Output Class Initialized
INFO - 2016-12-03 04:37:46 --> Security Class Initialized
DEBUG - 2016-12-03 04:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:37:46 --> Input Class Initialized
INFO - 2016-12-03 04:37:46 --> Language Class Initialized
INFO - 2016-12-03 04:37:46 --> Loader Class Initialized
INFO - 2016-12-03 04:37:46 --> Database Driver Class Initialized
INFO - 2016-12-03 04:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:37:46 --> Controller Class Initialized
INFO - 2016-12-03 04:37:46 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:37:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:37:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:37:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:37:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:37:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:37:46 --> Final output sent to browser
DEBUG - 2016-12-03 04:37:46 --> Total execution time: 0.0456
INFO - 2016-12-03 04:38:41 --> Config Class Initialized
INFO - 2016-12-03 04:38:41 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:38:41 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:38:41 --> Utf8 Class Initialized
INFO - 2016-12-03 04:38:41 --> URI Class Initialized
INFO - 2016-12-03 04:38:41 --> Router Class Initialized
INFO - 2016-12-03 04:38:41 --> Output Class Initialized
INFO - 2016-12-03 04:38:41 --> Security Class Initialized
DEBUG - 2016-12-03 04:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:38:41 --> Input Class Initialized
INFO - 2016-12-03 04:38:41 --> Language Class Initialized
INFO - 2016-12-03 04:38:41 --> Loader Class Initialized
INFO - 2016-12-03 04:38:41 --> Database Driver Class Initialized
INFO - 2016-12-03 04:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:38:41 --> Controller Class Initialized
INFO - 2016-12-03 04:38:41 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:38:41 --> Helper loaded: url_helper
INFO - 2016-12-03 04:38:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:38:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:38:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:38:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:38:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:38:41 --> Final output sent to browser
DEBUG - 2016-12-03 04:38:41 --> Total execution time: 0.0159
INFO - 2016-12-03 04:38:41 --> Config Class Initialized
INFO - 2016-12-03 04:38:41 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:38:41 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:38:41 --> Utf8 Class Initialized
INFO - 2016-12-03 04:38:41 --> URI Class Initialized
INFO - 2016-12-03 04:38:41 --> Router Class Initialized
INFO - 2016-12-03 04:38:41 --> Output Class Initialized
INFO - 2016-12-03 04:38:41 --> Security Class Initialized
DEBUG - 2016-12-03 04:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:38:41 --> Input Class Initialized
INFO - 2016-12-03 04:38:41 --> Language Class Initialized
ERROR - 2016-12-03 04:38:41 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:38:42 --> Config Class Initialized
INFO - 2016-12-03 04:38:42 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:38:42 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:38:42 --> Utf8 Class Initialized
INFO - 2016-12-03 04:38:42 --> URI Class Initialized
INFO - 2016-12-03 04:38:42 --> Router Class Initialized
INFO - 2016-12-03 04:38:42 --> Output Class Initialized
INFO - 2016-12-03 04:38:42 --> Security Class Initialized
DEBUG - 2016-12-03 04:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:38:42 --> Input Class Initialized
INFO - 2016-12-03 04:38:42 --> Language Class Initialized
INFO - 2016-12-03 04:38:42 --> Loader Class Initialized
INFO - 2016-12-03 04:38:42 --> Database Driver Class Initialized
INFO - 2016-12-03 04:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:38:42 --> Controller Class Initialized
INFO - 2016-12-03 04:38:42 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:38:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:38:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:38:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:38:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:38:42 --> Final output sent to browser
DEBUG - 2016-12-03 04:38:42 --> Total execution time: 0.0128
INFO - 2016-12-03 04:49:35 --> Config Class Initialized
INFO - 2016-12-03 04:49:35 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:49:35 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:49:35 --> Utf8 Class Initialized
INFO - 2016-12-03 04:49:35 --> URI Class Initialized
INFO - 2016-12-03 04:49:35 --> Router Class Initialized
INFO - 2016-12-03 04:49:35 --> Output Class Initialized
INFO - 2016-12-03 04:49:35 --> Security Class Initialized
DEBUG - 2016-12-03 04:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:49:35 --> Input Class Initialized
INFO - 2016-12-03 04:49:35 --> Language Class Initialized
INFO - 2016-12-03 04:49:35 --> Loader Class Initialized
INFO - 2016-12-03 04:49:35 --> Database Driver Class Initialized
INFO - 2016-12-03 04:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:49:35 --> Controller Class Initialized
INFO - 2016-12-03 04:49:35 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:49:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:49:35 --> Helper loaded: url_helper
INFO - 2016-12-03 04:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:49:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:49:35 --> Final output sent to browser
DEBUG - 2016-12-03 04:49:35 --> Total execution time: 0.0233
INFO - 2016-12-03 04:49:35 --> Config Class Initialized
INFO - 2016-12-03 04:49:35 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:49:35 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:49:35 --> Utf8 Class Initialized
INFO - 2016-12-03 04:49:35 --> URI Class Initialized
INFO - 2016-12-03 04:49:35 --> Router Class Initialized
INFO - 2016-12-03 04:49:35 --> Output Class Initialized
INFO - 2016-12-03 04:49:35 --> Security Class Initialized
DEBUG - 2016-12-03 04:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:49:35 --> Input Class Initialized
INFO - 2016-12-03 04:49:35 --> Language Class Initialized
ERROR - 2016-12-03 04:49:35 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:49:36 --> Config Class Initialized
INFO - 2016-12-03 04:49:36 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:49:36 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:49:36 --> Utf8 Class Initialized
INFO - 2016-12-03 04:49:36 --> URI Class Initialized
INFO - 2016-12-03 04:49:36 --> Router Class Initialized
INFO - 2016-12-03 04:49:36 --> Output Class Initialized
INFO - 2016-12-03 04:49:36 --> Security Class Initialized
DEBUG - 2016-12-03 04:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:49:36 --> Input Class Initialized
INFO - 2016-12-03 04:49:36 --> Language Class Initialized
INFO - 2016-12-03 04:49:36 --> Loader Class Initialized
INFO - 2016-12-03 04:49:36 --> Database Driver Class Initialized
INFO - 2016-12-03 04:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:49:36 --> Controller Class Initialized
INFO - 2016-12-03 04:49:36 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:49:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:49:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:49:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:49:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:49:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:49:36 --> Final output sent to browser
DEBUG - 2016-12-03 04:49:36 --> Total execution time: 0.0127
INFO - 2016-12-03 04:49:47 --> Config Class Initialized
INFO - 2016-12-03 04:49:47 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:49:47 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:49:47 --> Utf8 Class Initialized
INFO - 2016-12-03 04:49:47 --> URI Class Initialized
INFO - 2016-12-03 04:49:47 --> Router Class Initialized
INFO - 2016-12-03 04:49:47 --> Output Class Initialized
INFO - 2016-12-03 04:49:47 --> Security Class Initialized
DEBUG - 2016-12-03 04:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:49:47 --> Input Class Initialized
INFO - 2016-12-03 04:49:47 --> Language Class Initialized
INFO - 2016-12-03 04:49:47 --> Loader Class Initialized
INFO - 2016-12-03 04:49:47 --> Database Driver Class Initialized
INFO - 2016-12-03 04:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:49:47 --> Controller Class Initialized
INFO - 2016-12-03 04:49:47 --> Helper loaded: date_helper
INFO - 2016-12-03 04:49:47 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:49:47 --> Helper loaded: form_helper
INFO - 2016-12-03 04:49:47 --> Form Validation Class Initialized
INFO - 2016-12-03 04:49:47 --> Final output sent to browser
DEBUG - 2016-12-03 04:49:47 --> Total execution time: 0.0282
INFO - 2016-12-03 04:49:53 --> Config Class Initialized
INFO - 2016-12-03 04:49:53 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:49:53 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:49:53 --> Utf8 Class Initialized
INFO - 2016-12-03 04:49:53 --> URI Class Initialized
INFO - 2016-12-03 04:49:53 --> Router Class Initialized
INFO - 2016-12-03 04:49:53 --> Output Class Initialized
INFO - 2016-12-03 04:49:53 --> Security Class Initialized
DEBUG - 2016-12-03 04:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:49:53 --> Input Class Initialized
INFO - 2016-12-03 04:49:53 --> Language Class Initialized
INFO - 2016-12-03 04:49:53 --> Loader Class Initialized
INFO - 2016-12-03 04:49:53 --> Database Driver Class Initialized
INFO - 2016-12-03 04:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:49:53 --> Controller Class Initialized
INFO - 2016-12-03 04:49:53 --> Helper loaded: date_helper
INFO - 2016-12-03 04:49:53 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:49:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:49:53 --> Helper loaded: form_helper
INFO - 2016-12-03 04:49:53 --> Form Validation Class Initialized
INFO - 2016-12-03 04:49:53 --> Final output sent to browser
DEBUG - 2016-12-03 04:49:53 --> Total execution time: 0.0154
INFO - 2016-12-03 04:51:26 --> Config Class Initialized
INFO - 2016-12-03 04:51:26 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:51:26 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:51:26 --> Utf8 Class Initialized
INFO - 2016-12-03 04:51:26 --> URI Class Initialized
INFO - 2016-12-03 04:51:26 --> Router Class Initialized
INFO - 2016-12-03 04:51:26 --> Output Class Initialized
INFO - 2016-12-03 04:51:26 --> Security Class Initialized
DEBUG - 2016-12-03 04:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:51:26 --> Input Class Initialized
INFO - 2016-12-03 04:51:26 --> Language Class Initialized
INFO - 2016-12-03 04:51:26 --> Loader Class Initialized
INFO - 2016-12-03 04:51:26 --> Database Driver Class Initialized
INFO - 2016-12-03 04:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:51:26 --> Controller Class Initialized
INFO - 2016-12-03 04:51:26 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:51:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:51:26 --> Helper loaded: url_helper
INFO - 2016-12-03 04:51:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:51:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:51:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:51:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:51:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:51:26 --> Final output sent to browser
DEBUG - 2016-12-03 04:51:26 --> Total execution time: 0.0557
INFO - 2016-12-03 04:51:26 --> Config Class Initialized
INFO - 2016-12-03 04:51:26 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:51:26 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:51:26 --> Utf8 Class Initialized
INFO - 2016-12-03 04:51:26 --> URI Class Initialized
INFO - 2016-12-03 04:51:26 --> Router Class Initialized
INFO - 2016-12-03 04:51:26 --> Output Class Initialized
INFO - 2016-12-03 04:51:26 --> Security Class Initialized
DEBUG - 2016-12-03 04:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:51:26 --> Input Class Initialized
INFO - 2016-12-03 04:51:26 --> Language Class Initialized
ERROR - 2016-12-03 04:51:26 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:51:27 --> Config Class Initialized
INFO - 2016-12-03 04:51:27 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:51:27 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:51:27 --> Utf8 Class Initialized
INFO - 2016-12-03 04:51:27 --> URI Class Initialized
INFO - 2016-12-03 04:51:27 --> Router Class Initialized
INFO - 2016-12-03 04:51:27 --> Output Class Initialized
INFO - 2016-12-03 04:51:27 --> Security Class Initialized
DEBUG - 2016-12-03 04:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:51:27 --> Input Class Initialized
INFO - 2016-12-03 04:51:27 --> Language Class Initialized
INFO - 2016-12-03 04:51:27 --> Loader Class Initialized
INFO - 2016-12-03 04:51:27 --> Database Driver Class Initialized
INFO - 2016-12-03 04:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:51:27 --> Controller Class Initialized
INFO - 2016-12-03 04:51:27 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:51:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:51:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:51:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:51:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:51:27 --> Final output sent to browser
DEBUG - 2016-12-03 04:51:27 --> Total execution time: 0.0136
INFO - 2016-12-03 04:52:50 --> Config Class Initialized
INFO - 2016-12-03 04:52:50 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:52:50 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:52:50 --> Utf8 Class Initialized
INFO - 2016-12-03 04:52:50 --> URI Class Initialized
INFO - 2016-12-03 04:52:50 --> Router Class Initialized
INFO - 2016-12-03 04:52:50 --> Output Class Initialized
INFO - 2016-12-03 04:52:50 --> Security Class Initialized
DEBUG - 2016-12-03 04:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:52:50 --> Input Class Initialized
INFO - 2016-12-03 04:52:50 --> Language Class Initialized
INFO - 2016-12-03 04:52:50 --> Loader Class Initialized
INFO - 2016-12-03 04:52:50 --> Database Driver Class Initialized
INFO - 2016-12-03 04:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:52:50 --> Controller Class Initialized
INFO - 2016-12-03 04:52:50 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:52:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:52:50 --> Helper loaded: url_helper
INFO - 2016-12-03 04:52:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:52:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:52:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:52:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:52:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:52:50 --> Final output sent to browser
DEBUG - 2016-12-03 04:52:50 --> Total execution time: 0.0238
INFO - 2016-12-03 04:52:50 --> Config Class Initialized
INFO - 2016-12-03 04:52:50 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:52:50 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:52:50 --> Utf8 Class Initialized
INFO - 2016-12-03 04:52:50 --> URI Class Initialized
INFO - 2016-12-03 04:52:50 --> Router Class Initialized
INFO - 2016-12-03 04:52:50 --> Output Class Initialized
INFO - 2016-12-03 04:52:50 --> Security Class Initialized
DEBUG - 2016-12-03 04:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:52:50 --> Input Class Initialized
INFO - 2016-12-03 04:52:50 --> Language Class Initialized
ERROR - 2016-12-03 04:52:50 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:52:51 --> Config Class Initialized
INFO - 2016-12-03 04:52:51 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:52:51 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:52:51 --> Utf8 Class Initialized
INFO - 2016-12-03 04:52:51 --> URI Class Initialized
INFO - 2016-12-03 04:52:51 --> Router Class Initialized
INFO - 2016-12-03 04:52:51 --> Output Class Initialized
INFO - 2016-12-03 04:52:51 --> Security Class Initialized
DEBUG - 2016-12-03 04:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:52:51 --> Input Class Initialized
INFO - 2016-12-03 04:52:51 --> Language Class Initialized
INFO - 2016-12-03 04:52:51 --> Loader Class Initialized
INFO - 2016-12-03 04:52:51 --> Database Driver Class Initialized
INFO - 2016-12-03 04:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:52:51 --> Controller Class Initialized
INFO - 2016-12-03 04:52:51 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:52:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:52:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:52:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:52:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:52:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:52:51 --> Final output sent to browser
DEBUG - 2016-12-03 04:52:51 --> Total execution time: 0.0218
INFO - 2016-12-03 04:52:53 --> Config Class Initialized
INFO - 2016-12-03 04:52:53 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:52:53 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:52:53 --> Utf8 Class Initialized
INFO - 2016-12-03 04:52:53 --> URI Class Initialized
INFO - 2016-12-03 04:52:53 --> Router Class Initialized
INFO - 2016-12-03 04:52:53 --> Output Class Initialized
INFO - 2016-12-03 04:52:53 --> Security Class Initialized
DEBUG - 2016-12-03 04:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:52:53 --> Input Class Initialized
INFO - 2016-12-03 04:52:53 --> Language Class Initialized
INFO - 2016-12-03 04:52:53 --> Loader Class Initialized
INFO - 2016-12-03 04:52:53 --> Database Driver Class Initialized
INFO - 2016-12-03 04:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:52:53 --> Controller Class Initialized
INFO - 2016-12-03 04:52:53 --> Helper loaded: date_helper
DEBUG - 2016-12-03 04:52:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:52:53 --> Helper loaded: url_helper
INFO - 2016-12-03 04:52:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:52:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 04:52:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 04:52:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 04:52:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:52:53 --> Final output sent to browser
DEBUG - 2016-12-03 04:52:53 --> Total execution time: 0.0164
INFO - 2016-12-03 04:52:54 --> Config Class Initialized
INFO - 2016-12-03 04:52:54 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:52:54 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:52:54 --> Utf8 Class Initialized
INFO - 2016-12-03 04:52:54 --> URI Class Initialized
INFO - 2016-12-03 04:52:54 --> Router Class Initialized
INFO - 2016-12-03 04:52:54 --> Output Class Initialized
INFO - 2016-12-03 04:52:54 --> Security Class Initialized
DEBUG - 2016-12-03 04:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:52:54 --> Input Class Initialized
INFO - 2016-12-03 04:52:54 --> Language Class Initialized
ERROR - 2016-12-03 04:52:54 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 04:52:54 --> Config Class Initialized
INFO - 2016-12-03 04:52:54 --> Hooks Class Initialized
DEBUG - 2016-12-03 04:52:54 --> UTF-8 Support Enabled
INFO - 2016-12-03 04:52:54 --> Utf8 Class Initialized
INFO - 2016-12-03 04:52:54 --> URI Class Initialized
INFO - 2016-12-03 04:52:54 --> Router Class Initialized
INFO - 2016-12-03 04:52:54 --> Output Class Initialized
INFO - 2016-12-03 04:52:54 --> Security Class Initialized
DEBUG - 2016-12-03 04:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 04:52:54 --> Input Class Initialized
INFO - 2016-12-03 04:52:54 --> Language Class Initialized
INFO - 2016-12-03 04:52:54 --> Loader Class Initialized
INFO - 2016-12-03 04:52:54 --> Database Driver Class Initialized
INFO - 2016-12-03 04:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 04:52:54 --> Controller Class Initialized
INFO - 2016-12-03 04:52:54 --> Helper loaded: url_helper
DEBUG - 2016-12-03 04:52:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 04:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 04:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 04:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 04:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 04:52:54 --> Final output sent to browser
DEBUG - 2016-12-03 04:52:54 --> Total execution time: 0.0134
INFO - 2016-12-03 05:01:44 --> Config Class Initialized
INFO - 2016-12-03 05:01:44 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:01:44 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:01:44 --> Utf8 Class Initialized
INFO - 2016-12-03 05:01:44 --> URI Class Initialized
INFO - 2016-12-03 05:01:44 --> Router Class Initialized
INFO - 2016-12-03 05:01:44 --> Output Class Initialized
INFO - 2016-12-03 05:01:44 --> Security Class Initialized
DEBUG - 2016-12-03 05:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:01:44 --> Input Class Initialized
INFO - 2016-12-03 05:01:44 --> Language Class Initialized
INFO - 2016-12-03 05:01:44 --> Loader Class Initialized
INFO - 2016-12-03 05:01:44 --> Database Driver Class Initialized
INFO - 2016-12-03 05:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:01:44 --> Controller Class Initialized
INFO - 2016-12-03 05:01:44 --> Helper loaded: date_helper
DEBUG - 2016-12-03 05:01:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:01:44 --> Helper loaded: url_helper
INFO - 2016-12-03 05:01:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:01:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 05:01:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 05:01:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 05:01:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:01:44 --> Final output sent to browser
DEBUG - 2016-12-03 05:01:44 --> Total execution time: 0.0171
INFO - 2016-12-03 05:01:44 --> Config Class Initialized
INFO - 2016-12-03 05:01:44 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:01:44 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:01:44 --> Utf8 Class Initialized
INFO - 2016-12-03 05:01:44 --> URI Class Initialized
INFO - 2016-12-03 05:01:44 --> Router Class Initialized
INFO - 2016-12-03 05:01:44 --> Output Class Initialized
INFO - 2016-12-03 05:01:44 --> Security Class Initialized
DEBUG - 2016-12-03 05:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:01:44 --> Input Class Initialized
INFO - 2016-12-03 05:01:44 --> Language Class Initialized
ERROR - 2016-12-03 05:01:44 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 05:01:44 --> Config Class Initialized
INFO - 2016-12-03 05:01:44 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:01:44 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:01:44 --> Utf8 Class Initialized
INFO - 2016-12-03 05:01:44 --> URI Class Initialized
INFO - 2016-12-03 05:01:44 --> Router Class Initialized
INFO - 2016-12-03 05:01:44 --> Output Class Initialized
INFO - 2016-12-03 05:01:44 --> Security Class Initialized
DEBUG - 2016-12-03 05:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:01:44 --> Input Class Initialized
INFO - 2016-12-03 05:01:44 --> Language Class Initialized
INFO - 2016-12-03 05:01:44 --> Loader Class Initialized
INFO - 2016-12-03 05:01:44 --> Database Driver Class Initialized
INFO - 2016-12-03 05:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:01:44 --> Controller Class Initialized
INFO - 2016-12-03 05:01:44 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:01:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:01:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:01:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:01:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:01:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:01:44 --> Final output sent to browser
DEBUG - 2016-12-03 05:01:44 --> Total execution time: 0.0137
INFO - 2016-12-03 05:03:27 --> Config Class Initialized
INFO - 2016-12-03 05:03:27 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:03:27 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:03:27 --> Utf8 Class Initialized
INFO - 2016-12-03 05:03:27 --> URI Class Initialized
INFO - 2016-12-03 05:03:27 --> Router Class Initialized
INFO - 2016-12-03 05:03:27 --> Output Class Initialized
INFO - 2016-12-03 05:03:27 --> Security Class Initialized
DEBUG - 2016-12-03 05:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:03:27 --> Input Class Initialized
INFO - 2016-12-03 05:03:27 --> Language Class Initialized
INFO - 2016-12-03 05:03:27 --> Loader Class Initialized
INFO - 2016-12-03 05:03:27 --> Database Driver Class Initialized
INFO - 2016-12-03 05:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:03:27 --> Controller Class Initialized
INFO - 2016-12-03 05:03:27 --> Helper loaded: date_helper
INFO - 2016-12-03 05:03:27 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:03:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:03:27 --> Helper loaded: form_helper
INFO - 2016-12-03 05:03:27 --> Form Validation Class Initialized
INFO - 2016-12-03 05:03:27 --> Final output sent to browser
DEBUG - 2016-12-03 05:03:27 --> Total execution time: 0.0153
INFO - 2016-12-03 05:03:32 --> Config Class Initialized
INFO - 2016-12-03 05:03:32 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:03:32 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:03:32 --> Utf8 Class Initialized
INFO - 2016-12-03 05:03:32 --> URI Class Initialized
INFO - 2016-12-03 05:03:32 --> Router Class Initialized
INFO - 2016-12-03 05:03:32 --> Output Class Initialized
INFO - 2016-12-03 05:03:32 --> Security Class Initialized
DEBUG - 2016-12-03 05:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:03:32 --> Input Class Initialized
INFO - 2016-12-03 05:03:32 --> Language Class Initialized
INFO - 2016-12-03 05:03:32 --> Loader Class Initialized
INFO - 2016-12-03 05:03:32 --> Database Driver Class Initialized
INFO - 2016-12-03 05:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:03:32 --> Controller Class Initialized
INFO - 2016-12-03 05:03:32 --> Helper loaded: date_helper
INFO - 2016-12-03 05:03:32 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:03:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:03:32 --> Helper loaded: form_helper
INFO - 2016-12-03 05:03:32 --> Form Validation Class Initialized
INFO - 2016-12-03 05:03:32 --> Final output sent to browser
DEBUG - 2016-12-03 05:03:32 --> Total execution time: 0.0148
INFO - 2016-12-03 05:03:45 --> Config Class Initialized
INFO - 2016-12-03 05:03:45 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:03:45 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:03:45 --> Utf8 Class Initialized
INFO - 2016-12-03 05:03:45 --> URI Class Initialized
INFO - 2016-12-03 05:03:45 --> Router Class Initialized
INFO - 2016-12-03 05:03:45 --> Output Class Initialized
INFO - 2016-12-03 05:03:45 --> Security Class Initialized
DEBUG - 2016-12-03 05:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:03:45 --> Input Class Initialized
INFO - 2016-12-03 05:03:45 --> Language Class Initialized
INFO - 2016-12-03 05:03:45 --> Loader Class Initialized
INFO - 2016-12-03 05:03:45 --> Database Driver Class Initialized
INFO - 2016-12-03 05:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:03:45 --> Controller Class Initialized
INFO - 2016-12-03 05:03:45 --> Helper loaded: date_helper
INFO - 2016-12-03 05:03:45 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:03:45 --> Helper loaded: form_helper
INFO - 2016-12-03 05:03:45 --> Form Validation Class Initialized
INFO - 2016-12-03 05:03:45 --> Config Class Initialized
INFO - 2016-12-03 05:03:45 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:03:45 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:03:45 --> Utf8 Class Initialized
INFO - 2016-12-03 05:03:45 --> URI Class Initialized
INFO - 2016-12-03 05:03:45 --> Router Class Initialized
INFO - 2016-12-03 05:03:45 --> Output Class Initialized
INFO - 2016-12-03 05:03:45 --> Security Class Initialized
DEBUG - 2016-12-03 05:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:03:45 --> Input Class Initialized
INFO - 2016-12-03 05:03:45 --> Language Class Initialized
INFO - 2016-12-03 05:03:45 --> Loader Class Initialized
INFO - 2016-12-03 05:03:45 --> Database Driver Class Initialized
INFO - 2016-12-03 05:03:45 --> Final output sent to browser
DEBUG - 2016-12-03 05:03:45 --> Total execution time: 0.0719
INFO - 2016-12-03 05:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:03:45 --> Controller Class Initialized
INFO - 2016-12-03 05:03:45 --> Helper loaded: date_helper
INFO - 2016-12-03 05:03:45 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:03:45 --> Helper loaded: form_helper
INFO - 2016-12-03 05:03:45 --> Form Validation Class Initialized
INFO - 2016-12-03 05:03:45 --> Final output sent to browser
DEBUG - 2016-12-03 05:03:45 --> Total execution time: 0.0773
INFO - 2016-12-03 05:03:48 --> Config Class Initialized
INFO - 2016-12-03 05:03:48 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:03:48 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:03:48 --> Utf8 Class Initialized
INFO - 2016-12-03 05:03:48 --> URI Class Initialized
INFO - 2016-12-03 05:03:48 --> Router Class Initialized
INFO - 2016-12-03 05:03:48 --> Output Class Initialized
INFO - 2016-12-03 05:03:48 --> Security Class Initialized
DEBUG - 2016-12-03 05:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:03:48 --> Input Class Initialized
INFO - 2016-12-03 05:03:48 --> Language Class Initialized
INFO - 2016-12-03 05:03:48 --> Loader Class Initialized
INFO - 2016-12-03 05:03:48 --> Database Driver Class Initialized
INFO - 2016-12-03 05:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:03:48 --> Controller Class Initialized
INFO - 2016-12-03 05:03:48 --> Helper loaded: date_helper
INFO - 2016-12-03 05:03:48 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:03:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:03:48 --> Helper loaded: form_helper
INFO - 2016-12-03 05:03:48 --> Form Validation Class Initialized
INFO - 2016-12-03 05:03:48 --> Final output sent to browser
DEBUG - 2016-12-03 05:03:48 --> Total execution time: 0.0862
INFO - 2016-12-03 05:03:48 --> Config Class Initialized
INFO - 2016-12-03 05:03:48 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:03:48 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:03:48 --> Utf8 Class Initialized
INFO - 2016-12-03 05:03:48 --> URI Class Initialized
INFO - 2016-12-03 05:03:48 --> Router Class Initialized
INFO - 2016-12-03 05:03:48 --> Output Class Initialized
INFO - 2016-12-03 05:03:48 --> Security Class Initialized
DEBUG - 2016-12-03 05:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:03:48 --> Input Class Initialized
INFO - 2016-12-03 05:03:48 --> Language Class Initialized
INFO - 2016-12-03 05:03:48 --> Loader Class Initialized
INFO - 2016-12-03 05:03:48 --> Database Driver Class Initialized
INFO - 2016-12-03 05:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:03:48 --> Controller Class Initialized
INFO - 2016-12-03 05:03:48 --> Helper loaded: date_helper
INFO - 2016-12-03 05:03:48 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:03:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:03:48 --> Helper loaded: form_helper
INFO - 2016-12-03 05:03:48 --> Form Validation Class Initialized
INFO - 2016-12-03 05:03:48 --> Final output sent to browser
DEBUG - 2016-12-03 05:03:48 --> Total execution time: 0.0695
INFO - 2016-12-03 05:04:30 --> Config Class Initialized
INFO - 2016-12-03 05:04:30 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:04:30 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:04:30 --> Utf8 Class Initialized
INFO - 2016-12-03 05:04:30 --> URI Class Initialized
INFO - 2016-12-03 05:04:30 --> Router Class Initialized
INFO - 2016-12-03 05:04:30 --> Output Class Initialized
INFO - 2016-12-03 05:04:30 --> Security Class Initialized
DEBUG - 2016-12-03 05:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:04:30 --> Input Class Initialized
INFO - 2016-12-03 05:04:30 --> Language Class Initialized
INFO - 2016-12-03 05:04:30 --> Loader Class Initialized
INFO - 2016-12-03 05:04:30 --> Database Driver Class Initialized
INFO - 2016-12-03 05:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:04:30 --> Controller Class Initialized
INFO - 2016-12-03 05:04:30 --> Helper loaded: date_helper
DEBUG - 2016-12-03 05:04:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:04:30 --> Helper loaded: url_helper
INFO - 2016-12-03 05:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 05:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 05:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 05:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:04:30 --> Final output sent to browser
DEBUG - 2016-12-03 05:04:30 --> Total execution time: 0.0240
INFO - 2016-12-03 05:04:30 --> Config Class Initialized
INFO - 2016-12-03 05:04:30 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:04:30 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:04:30 --> Utf8 Class Initialized
INFO - 2016-12-03 05:04:30 --> URI Class Initialized
INFO - 2016-12-03 05:04:30 --> Router Class Initialized
INFO - 2016-12-03 05:04:30 --> Output Class Initialized
INFO - 2016-12-03 05:04:30 --> Security Class Initialized
DEBUG - 2016-12-03 05:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:04:30 --> Input Class Initialized
INFO - 2016-12-03 05:04:30 --> Language Class Initialized
ERROR - 2016-12-03 05:04:30 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 05:04:31 --> Config Class Initialized
INFO - 2016-12-03 05:04:31 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:04:31 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:04:31 --> Utf8 Class Initialized
INFO - 2016-12-03 05:04:31 --> URI Class Initialized
INFO - 2016-12-03 05:04:31 --> Router Class Initialized
INFO - 2016-12-03 05:04:31 --> Output Class Initialized
INFO - 2016-12-03 05:04:31 --> Security Class Initialized
DEBUG - 2016-12-03 05:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:04:31 --> Input Class Initialized
INFO - 2016-12-03 05:04:31 --> Language Class Initialized
INFO - 2016-12-03 05:04:31 --> Loader Class Initialized
INFO - 2016-12-03 05:04:31 --> Database Driver Class Initialized
INFO - 2016-12-03 05:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:04:31 --> Controller Class Initialized
INFO - 2016-12-03 05:04:31 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:04:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:04:31 --> Final output sent to browser
DEBUG - 2016-12-03 05:04:31 --> Total execution time: 0.0187
INFO - 2016-12-03 05:04:41 --> Config Class Initialized
INFO - 2016-12-03 05:04:41 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:04:41 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:04:41 --> Utf8 Class Initialized
INFO - 2016-12-03 05:04:41 --> URI Class Initialized
INFO - 2016-12-03 05:04:41 --> Router Class Initialized
INFO - 2016-12-03 05:04:41 --> Output Class Initialized
INFO - 2016-12-03 05:04:41 --> Security Class Initialized
DEBUG - 2016-12-03 05:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:04:41 --> Input Class Initialized
INFO - 2016-12-03 05:04:41 --> Language Class Initialized
INFO - 2016-12-03 05:04:41 --> Loader Class Initialized
INFO - 2016-12-03 05:04:41 --> Database Driver Class Initialized
INFO - 2016-12-03 05:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:04:41 --> Controller Class Initialized
INFO - 2016-12-03 05:04:41 --> Helper loaded: date_helper
INFO - 2016-12-03 05:04:41 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:04:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:04:41 --> Helper loaded: form_helper
INFO - 2016-12-03 05:04:41 --> Form Validation Class Initialized
INFO - 2016-12-03 05:04:41 --> Final output sent to browser
DEBUG - 2016-12-03 05:04:41 --> Total execution time: 0.0161
INFO - 2016-12-03 05:04:45 --> Config Class Initialized
INFO - 2016-12-03 05:04:45 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:04:45 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:04:45 --> Utf8 Class Initialized
INFO - 2016-12-03 05:04:45 --> URI Class Initialized
INFO - 2016-12-03 05:04:45 --> Router Class Initialized
INFO - 2016-12-03 05:04:45 --> Output Class Initialized
INFO - 2016-12-03 05:04:45 --> Security Class Initialized
DEBUG - 2016-12-03 05:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:04:45 --> Input Class Initialized
INFO - 2016-12-03 05:04:45 --> Language Class Initialized
INFO - 2016-12-03 05:04:45 --> Loader Class Initialized
INFO - 2016-12-03 05:04:45 --> Database Driver Class Initialized
INFO - 2016-12-03 05:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:04:45 --> Controller Class Initialized
INFO - 2016-12-03 05:04:45 --> Helper loaded: date_helper
INFO - 2016-12-03 05:04:45 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:04:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:04:45 --> Helper loaded: form_helper
INFO - 2016-12-03 05:04:45 --> Form Validation Class Initialized
INFO - 2016-12-03 05:04:45 --> Final output sent to browser
DEBUG - 2016-12-03 05:04:45 --> Total execution time: 0.0148
INFO - 2016-12-03 05:04:47 --> Config Class Initialized
INFO - 2016-12-03 05:04:47 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:04:47 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:04:47 --> Utf8 Class Initialized
INFO - 2016-12-03 05:04:47 --> URI Class Initialized
INFO - 2016-12-03 05:04:47 --> Router Class Initialized
INFO - 2016-12-03 05:04:47 --> Output Class Initialized
INFO - 2016-12-03 05:04:47 --> Security Class Initialized
DEBUG - 2016-12-03 05:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:04:47 --> Input Class Initialized
INFO - 2016-12-03 05:04:47 --> Language Class Initialized
INFO - 2016-12-03 05:04:47 --> Loader Class Initialized
INFO - 2016-12-03 05:04:47 --> Database Driver Class Initialized
INFO - 2016-12-03 05:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:04:47 --> Controller Class Initialized
INFO - 2016-12-03 05:04:47 --> Helper loaded: date_helper
INFO - 2016-12-03 05:04:47 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:04:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:04:47 --> Helper loaded: form_helper
INFO - 2016-12-03 05:04:47 --> Form Validation Class Initialized
INFO - 2016-12-03 05:04:47 --> Final output sent to browser
DEBUG - 2016-12-03 05:04:47 --> Total execution time: 0.0147
INFO - 2016-12-03 05:04:53 --> Config Class Initialized
INFO - 2016-12-03 05:04:53 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:04:53 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:04:53 --> Utf8 Class Initialized
INFO - 2016-12-03 05:04:53 --> URI Class Initialized
INFO - 2016-12-03 05:04:53 --> Router Class Initialized
INFO - 2016-12-03 05:04:53 --> Output Class Initialized
INFO - 2016-12-03 05:04:53 --> Security Class Initialized
DEBUG - 2016-12-03 05:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:04:53 --> Input Class Initialized
INFO - 2016-12-03 05:04:53 --> Language Class Initialized
INFO - 2016-12-03 05:04:53 --> Loader Class Initialized
INFO - 2016-12-03 05:04:53 --> Database Driver Class Initialized
INFO - 2016-12-03 05:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:04:53 --> Controller Class Initialized
INFO - 2016-12-03 05:04:53 --> Helper loaded: date_helper
INFO - 2016-12-03 05:04:53 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:04:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:04:53 --> Helper loaded: form_helper
INFO - 2016-12-03 05:04:53 --> Form Validation Class Initialized
INFO - 2016-12-03 05:04:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-03 05:04:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-03 05:04:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2016-12-03 05:04:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2016-12-03 05:04:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-03 05:04:53 --> Final output sent to browser
DEBUG - 2016-12-03 05:04:53 --> Total execution time: 0.0154
INFO - 2016-12-03 05:04:54 --> Config Class Initialized
INFO - 2016-12-03 05:04:54 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:04:54 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:04:54 --> Utf8 Class Initialized
INFO - 2016-12-03 05:04:54 --> URI Class Initialized
INFO - 2016-12-03 05:04:54 --> Router Class Initialized
INFO - 2016-12-03 05:04:54 --> Output Class Initialized
INFO - 2016-12-03 05:04:54 --> Security Class Initialized
DEBUG - 2016-12-03 05:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:04:54 --> Input Class Initialized
INFO - 2016-12-03 05:04:54 --> Language Class Initialized
INFO - 2016-12-03 05:04:54 --> Loader Class Initialized
INFO - 2016-12-03 05:04:54 --> Database Driver Class Initialized
INFO - 2016-12-03 05:04:54 --> Config Class Initialized
INFO - 2016-12-03 05:04:54 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:04:54 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:04:54 --> Utf8 Class Initialized
INFO - 2016-12-03 05:04:54 --> URI Class Initialized
INFO - 2016-12-03 05:04:54 --> Router Class Initialized
INFO - 2016-12-03 05:04:54 --> Output Class Initialized
INFO - 2016-12-03 05:04:54 --> Security Class Initialized
DEBUG - 2016-12-03 05:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:04:54 --> Input Class Initialized
INFO - 2016-12-03 05:04:54 --> Language Class Initialized
INFO - 2016-12-03 05:04:54 --> Loader Class Initialized
INFO - 2016-12-03 05:04:54 --> Database Driver Class Initialized
INFO - 2016-12-03 05:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:04:54 --> Controller Class Initialized
INFO - 2016-12-03 05:04:54 --> Helper loaded: date_helper
INFO - 2016-12-03 05:04:54 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:04:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:04:54 --> Helper loaded: form_helper
INFO - 2016-12-03 05:04:54 --> Form Validation Class Initialized
INFO - 2016-12-03 05:04:54 --> Final output sent to browser
DEBUG - 2016-12-03 05:04:54 --> Total execution time: 0.0907
INFO - 2016-12-03 05:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:04:54 --> Controller Class Initialized
INFO - 2016-12-03 05:04:54 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:04:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:04:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:04:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:04:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:04:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:04:54 --> Final output sent to browser
DEBUG - 2016-12-03 05:04:54 --> Total execution time: 0.0732
INFO - 2016-12-03 05:04:56 --> Config Class Initialized
INFO - 2016-12-03 05:04:56 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:04:56 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:04:56 --> Utf8 Class Initialized
INFO - 2016-12-03 05:04:56 --> URI Class Initialized
INFO - 2016-12-03 05:04:56 --> Router Class Initialized
INFO - 2016-12-03 05:04:56 --> Output Class Initialized
INFO - 2016-12-03 05:04:56 --> Security Class Initialized
DEBUG - 2016-12-03 05:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:04:56 --> Input Class Initialized
INFO - 2016-12-03 05:04:56 --> Language Class Initialized
INFO - 2016-12-03 05:04:56 --> Loader Class Initialized
INFO - 2016-12-03 05:04:56 --> Database Driver Class Initialized
INFO - 2016-12-03 05:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:04:56 --> Controller Class Initialized
INFO - 2016-12-03 05:04:56 --> Helper loaded: date_helper
INFO - 2016-12-03 05:04:56 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:04:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:04:56 --> Helper loaded: form_helper
INFO - 2016-12-03 05:04:56 --> Form Validation Class Initialized
INFO - 2016-12-03 05:04:56 --> Config Class Initialized
INFO - 2016-12-03 05:04:56 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:04:56 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:04:56 --> Utf8 Class Initialized
INFO - 2016-12-03 05:04:56 --> URI Class Initialized
INFO - 2016-12-03 05:04:56 --> Router Class Initialized
INFO - 2016-12-03 05:04:56 --> Output Class Initialized
INFO - 2016-12-03 05:04:56 --> Security Class Initialized
DEBUG - 2016-12-03 05:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:04:56 --> Input Class Initialized
INFO - 2016-12-03 05:04:56 --> Language Class Initialized
INFO - 2016-12-03 05:04:56 --> Loader Class Initialized
INFO - 2016-12-03 05:04:56 --> Final output sent to browser
DEBUG - 2016-12-03 05:04:56 --> Total execution time: 0.1142
INFO - 2016-12-03 05:04:56 --> Database Driver Class Initialized
INFO - 2016-12-03 05:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:04:56 --> Controller Class Initialized
INFO - 2016-12-03 05:04:56 --> Helper loaded: date_helper
INFO - 2016-12-03 05:04:56 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:04:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:04:56 --> Helper loaded: form_helper
INFO - 2016-12-03 05:04:56 --> Form Validation Class Initialized
INFO - 2016-12-03 05:04:56 --> Final output sent to browser
DEBUG - 2016-12-03 05:04:56 --> Total execution time: 0.0218
INFO - 2016-12-03 05:06:13 --> Config Class Initialized
INFO - 2016-12-03 05:06:13 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:06:13 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:06:13 --> Utf8 Class Initialized
INFO - 2016-12-03 05:06:13 --> URI Class Initialized
INFO - 2016-12-03 05:06:13 --> Router Class Initialized
INFO - 2016-12-03 05:06:13 --> Output Class Initialized
INFO - 2016-12-03 05:06:13 --> Security Class Initialized
DEBUG - 2016-12-03 05:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:06:13 --> Input Class Initialized
INFO - 2016-12-03 05:06:13 --> Language Class Initialized
INFO - 2016-12-03 05:06:13 --> Loader Class Initialized
INFO - 2016-12-03 05:06:13 --> Database Driver Class Initialized
INFO - 2016-12-03 05:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:06:13 --> Controller Class Initialized
INFO - 2016-12-03 05:06:13 --> Helper loaded: date_helper
INFO - 2016-12-03 05:06:13 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:06:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:06:13 --> Helper loaded: form_helper
INFO - 2016-12-03 05:06:13 --> Form Validation Class Initialized
INFO - 2016-12-03 05:06:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-03 05:06:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-03 05:06:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2016-12-03 05:06:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2016-12-03 05:06:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-03 05:06:13 --> Final output sent to browser
DEBUG - 2016-12-03 05:06:13 --> Total execution time: 0.0148
INFO - 2016-12-03 05:06:14 --> Config Class Initialized
INFO - 2016-12-03 05:06:14 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:06:14 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:06:14 --> Utf8 Class Initialized
INFO - 2016-12-03 05:06:14 --> URI Class Initialized
INFO - 2016-12-03 05:06:14 --> Router Class Initialized
INFO - 2016-12-03 05:06:14 --> Output Class Initialized
INFO - 2016-12-03 05:06:14 --> Security Class Initialized
DEBUG - 2016-12-03 05:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:06:14 --> Input Class Initialized
INFO - 2016-12-03 05:06:14 --> Language Class Initialized
INFO - 2016-12-03 05:06:14 --> Loader Class Initialized
INFO - 2016-12-03 05:06:14 --> Database Driver Class Initialized
INFO - 2016-12-03 05:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:06:14 --> Controller Class Initialized
INFO - 2016-12-03 05:06:14 --> Helper loaded: date_helper
INFO - 2016-12-03 05:06:14 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:06:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:06:14 --> Helper loaded: form_helper
INFO - 2016-12-03 05:06:14 --> Form Validation Class Initialized
INFO - 2016-12-03 05:06:14 --> Final output sent to browser
DEBUG - 2016-12-03 05:06:14 --> Total execution time: 0.0265
INFO - 2016-12-03 05:06:14 --> Config Class Initialized
INFO - 2016-12-03 05:06:14 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:06:14 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:06:14 --> Utf8 Class Initialized
INFO - 2016-12-03 05:06:14 --> URI Class Initialized
INFO - 2016-12-03 05:06:14 --> Router Class Initialized
INFO - 2016-12-03 05:06:14 --> Output Class Initialized
INFO - 2016-12-03 05:06:14 --> Security Class Initialized
DEBUG - 2016-12-03 05:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:06:14 --> Input Class Initialized
INFO - 2016-12-03 05:06:14 --> Language Class Initialized
INFO - 2016-12-03 05:06:14 --> Loader Class Initialized
INFO - 2016-12-03 05:06:14 --> Database Driver Class Initialized
INFO - 2016-12-03 05:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:06:14 --> Controller Class Initialized
INFO - 2016-12-03 05:06:14 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:06:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:06:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:06:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:06:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:06:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:06:14 --> Final output sent to browser
DEBUG - 2016-12-03 05:06:14 --> Total execution time: 0.0127
INFO - 2016-12-03 05:06:20 --> Config Class Initialized
INFO - 2016-12-03 05:06:20 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:06:20 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:06:20 --> Utf8 Class Initialized
INFO - 2016-12-03 05:06:20 --> URI Class Initialized
INFO - 2016-12-03 05:06:20 --> Router Class Initialized
INFO - 2016-12-03 05:06:20 --> Output Class Initialized
INFO - 2016-12-03 05:06:20 --> Security Class Initialized
DEBUG - 2016-12-03 05:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:06:20 --> Input Class Initialized
INFO - 2016-12-03 05:06:20 --> Language Class Initialized
INFO - 2016-12-03 05:06:20 --> Loader Class Initialized
INFO - 2016-12-03 05:06:20 --> Database Driver Class Initialized
INFO - 2016-12-03 05:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:06:20 --> Controller Class Initialized
INFO - 2016-12-03 05:06:20 --> Helper loaded: date_helper
INFO - 2016-12-03 05:06:20 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:06:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:06:20 --> Helper loaded: form_helper
INFO - 2016-12-03 05:06:20 --> Form Validation Class Initialized
INFO - 2016-12-03 05:06:20 --> Final output sent to browser
DEBUG - 2016-12-03 05:06:20 --> Total execution time: 0.0160
INFO - 2016-12-03 05:06:20 --> Config Class Initialized
INFO - 2016-12-03 05:06:20 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:06:20 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:06:20 --> Utf8 Class Initialized
INFO - 2016-12-03 05:06:20 --> URI Class Initialized
INFO - 2016-12-03 05:06:20 --> Router Class Initialized
INFO - 2016-12-03 05:06:20 --> Output Class Initialized
INFO - 2016-12-03 05:06:20 --> Security Class Initialized
DEBUG - 2016-12-03 05:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:06:20 --> Input Class Initialized
INFO - 2016-12-03 05:06:20 --> Language Class Initialized
INFO - 2016-12-03 05:06:20 --> Loader Class Initialized
INFO - 2016-12-03 05:06:20 --> Database Driver Class Initialized
INFO - 2016-12-03 05:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:06:20 --> Controller Class Initialized
INFO - 2016-12-03 05:06:20 --> Helper loaded: date_helper
INFO - 2016-12-03 05:06:20 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:06:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:06:20 --> Helper loaded: form_helper
INFO - 2016-12-03 05:06:20 --> Form Validation Class Initialized
INFO - 2016-12-03 05:06:20 --> Final output sent to browser
DEBUG - 2016-12-03 05:06:20 --> Total execution time: 0.0149
INFO - 2016-12-03 05:06:23 --> Config Class Initialized
INFO - 2016-12-03 05:06:23 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:06:23 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:06:23 --> Utf8 Class Initialized
INFO - 2016-12-03 05:06:23 --> URI Class Initialized
INFO - 2016-12-03 05:06:23 --> Router Class Initialized
INFO - 2016-12-03 05:06:23 --> Output Class Initialized
INFO - 2016-12-03 05:06:23 --> Security Class Initialized
DEBUG - 2016-12-03 05:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:06:23 --> Input Class Initialized
INFO - 2016-12-03 05:06:23 --> Language Class Initialized
INFO - 2016-12-03 05:06:23 --> Loader Class Initialized
INFO - 2016-12-03 05:06:23 --> Database Driver Class Initialized
INFO - 2016-12-03 05:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:06:23 --> Controller Class Initialized
INFO - 2016-12-03 05:06:23 --> Helper loaded: date_helper
INFO - 2016-12-03 05:06:23 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:06:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:06:23 --> Helper loaded: form_helper
INFO - 2016-12-03 05:06:23 --> Form Validation Class Initialized
INFO - 2016-12-03 05:06:23 --> Final output sent to browser
DEBUG - 2016-12-03 05:06:23 --> Total execution time: 0.0654
INFO - 2016-12-03 05:06:23 --> Config Class Initialized
INFO - 2016-12-03 05:06:23 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:06:23 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:06:23 --> Utf8 Class Initialized
INFO - 2016-12-03 05:06:23 --> URI Class Initialized
INFO - 2016-12-03 05:06:23 --> Router Class Initialized
INFO - 2016-12-03 05:06:23 --> Output Class Initialized
INFO - 2016-12-03 05:06:23 --> Security Class Initialized
DEBUG - 2016-12-03 05:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:06:23 --> Input Class Initialized
INFO - 2016-12-03 05:06:23 --> Language Class Initialized
INFO - 2016-12-03 05:06:23 --> Loader Class Initialized
INFO - 2016-12-03 05:06:23 --> Database Driver Class Initialized
INFO - 2016-12-03 05:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:06:23 --> Controller Class Initialized
INFO - 2016-12-03 05:06:23 --> Helper loaded: date_helper
INFO - 2016-12-03 05:06:23 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:06:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:06:23 --> Helper loaded: form_helper
INFO - 2016-12-03 05:06:23 --> Form Validation Class Initialized
INFO - 2016-12-03 05:06:23 --> Final output sent to browser
DEBUG - 2016-12-03 05:06:23 --> Total execution time: 0.0707
INFO - 2016-12-03 05:06:26 --> Config Class Initialized
INFO - 2016-12-03 05:06:26 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:06:26 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:06:26 --> Utf8 Class Initialized
INFO - 2016-12-03 05:06:26 --> URI Class Initialized
INFO - 2016-12-03 05:06:26 --> Router Class Initialized
INFO - 2016-12-03 05:06:26 --> Output Class Initialized
INFO - 2016-12-03 05:06:26 --> Security Class Initialized
DEBUG - 2016-12-03 05:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:06:26 --> Input Class Initialized
INFO - 2016-12-03 05:06:26 --> Language Class Initialized
INFO - 2016-12-03 05:06:26 --> Loader Class Initialized
INFO - 2016-12-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-12-03 05:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:06:26 --> Controller Class Initialized
INFO - 2016-12-03 05:06:26 --> Helper loaded: date_helper
INFO - 2016-12-03 05:06:26 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:06:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:06:26 --> Helper loaded: form_helper
INFO - 2016-12-03 05:06:26 --> Form Validation Class Initialized
INFO - 2016-12-03 05:06:26 --> Final output sent to browser
DEBUG - 2016-12-03 05:06:26 --> Total execution time: 0.0145
INFO - 2016-12-03 05:06:26 --> Config Class Initialized
INFO - 2016-12-03 05:06:26 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:06:26 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:06:26 --> Utf8 Class Initialized
INFO - 2016-12-03 05:06:26 --> URI Class Initialized
INFO - 2016-12-03 05:06:26 --> Router Class Initialized
INFO - 2016-12-03 05:06:26 --> Output Class Initialized
INFO - 2016-12-03 05:06:26 --> Security Class Initialized
DEBUG - 2016-12-03 05:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:06:26 --> Input Class Initialized
INFO - 2016-12-03 05:06:26 --> Language Class Initialized
INFO - 2016-12-03 05:06:26 --> Loader Class Initialized
INFO - 2016-12-03 05:06:26 --> Database Driver Class Initialized
INFO - 2016-12-03 05:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:06:26 --> Controller Class Initialized
INFO - 2016-12-03 05:06:26 --> Helper loaded: date_helper
INFO - 2016-12-03 05:06:26 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:06:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:06:26 --> Helper loaded: form_helper
INFO - 2016-12-03 05:06:26 --> Form Validation Class Initialized
INFO - 2016-12-03 05:06:26 --> Final output sent to browser
DEBUG - 2016-12-03 05:06:26 --> Total execution time: 0.0920
INFO - 2016-12-03 05:09:06 --> Config Class Initialized
INFO - 2016-12-03 05:09:06 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:09:06 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:09:06 --> Utf8 Class Initialized
INFO - 2016-12-03 05:09:06 --> URI Class Initialized
INFO - 2016-12-03 05:09:06 --> Router Class Initialized
INFO - 2016-12-03 05:09:06 --> Output Class Initialized
INFO - 2016-12-03 05:09:06 --> Security Class Initialized
DEBUG - 2016-12-03 05:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:09:06 --> Input Class Initialized
INFO - 2016-12-03 05:09:06 --> Language Class Initialized
INFO - 2016-12-03 05:09:06 --> Loader Class Initialized
INFO - 2016-12-03 05:09:06 --> Database Driver Class Initialized
INFO - 2016-12-03 05:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:09:06 --> Controller Class Initialized
DEBUG - 2016-12-03 05:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:09:06 --> Helper loaded: url_helper
INFO - 2016-12-03 05:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 05:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 05:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 05:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 05:09:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:09:06 --> Final output sent to browser
DEBUG - 2016-12-03 05:09:06 --> Total execution time: 0.0659
INFO - 2016-12-03 05:09:06 --> Config Class Initialized
INFO - 2016-12-03 05:09:06 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:09:06 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:09:06 --> Utf8 Class Initialized
INFO - 2016-12-03 05:09:06 --> URI Class Initialized
INFO - 2016-12-03 05:09:06 --> Router Class Initialized
INFO - 2016-12-03 05:09:06 --> Output Class Initialized
INFO - 2016-12-03 05:09:06 --> Security Class Initialized
DEBUG - 2016-12-03 05:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:09:06 --> Input Class Initialized
INFO - 2016-12-03 05:09:06 --> Language Class Initialized
ERROR - 2016-12-03 05:09:06 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 05:09:07 --> Config Class Initialized
INFO - 2016-12-03 05:09:07 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:09:07 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:09:07 --> Utf8 Class Initialized
INFO - 2016-12-03 05:09:07 --> URI Class Initialized
INFO - 2016-12-03 05:09:07 --> Router Class Initialized
INFO - 2016-12-03 05:09:07 --> Output Class Initialized
INFO - 2016-12-03 05:09:07 --> Security Class Initialized
DEBUG - 2016-12-03 05:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:09:07 --> Input Class Initialized
INFO - 2016-12-03 05:09:07 --> Language Class Initialized
INFO - 2016-12-03 05:09:07 --> Loader Class Initialized
INFO - 2016-12-03 05:09:07 --> Database Driver Class Initialized
INFO - 2016-12-03 05:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:09:07 --> Controller Class Initialized
INFO - 2016-12-03 05:09:07 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:09:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:09:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:09:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:09:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:09:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:09:07 --> Final output sent to browser
DEBUG - 2016-12-03 05:09:07 --> Total execution time: 0.0140
INFO - 2016-12-03 05:09:08 --> Config Class Initialized
INFO - 2016-12-03 05:09:08 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:09:08 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:09:08 --> Utf8 Class Initialized
INFO - 2016-12-03 05:09:08 --> URI Class Initialized
INFO - 2016-12-03 05:09:08 --> Router Class Initialized
INFO - 2016-12-03 05:09:08 --> Output Class Initialized
INFO - 2016-12-03 05:09:08 --> Security Class Initialized
DEBUG - 2016-12-03 05:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:09:08 --> Input Class Initialized
INFO - 2016-12-03 05:09:08 --> Language Class Initialized
INFO - 2016-12-03 05:09:08 --> Loader Class Initialized
INFO - 2016-12-03 05:09:08 --> Database Driver Class Initialized
INFO - 2016-12-03 05:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:09:08 --> Controller Class Initialized
INFO - 2016-12-03 05:09:08 --> Helper loaded: date_helper
DEBUG - 2016-12-03 05:09:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:09:08 --> Helper loaded: url_helper
INFO - 2016-12-03 05:09:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:09:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 05:09:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 05:09:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 05:09:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:09:08 --> Final output sent to browser
DEBUG - 2016-12-03 05:09:08 --> Total execution time: 0.0625
INFO - 2016-12-03 05:09:08 --> Config Class Initialized
INFO - 2016-12-03 05:09:08 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:09:08 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:09:08 --> Utf8 Class Initialized
INFO - 2016-12-03 05:09:08 --> URI Class Initialized
INFO - 2016-12-03 05:09:08 --> Router Class Initialized
INFO - 2016-12-03 05:09:08 --> Output Class Initialized
INFO - 2016-12-03 05:09:08 --> Security Class Initialized
DEBUG - 2016-12-03 05:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:09:08 --> Input Class Initialized
INFO - 2016-12-03 05:09:08 --> Language Class Initialized
ERROR - 2016-12-03 05:09:08 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 05:09:08 --> Config Class Initialized
INFO - 2016-12-03 05:09:08 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:09:08 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:09:08 --> Utf8 Class Initialized
INFO - 2016-12-03 05:09:08 --> URI Class Initialized
INFO - 2016-12-03 05:09:08 --> Router Class Initialized
INFO - 2016-12-03 05:09:08 --> Output Class Initialized
INFO - 2016-12-03 05:09:08 --> Security Class Initialized
DEBUG - 2016-12-03 05:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:09:08 --> Input Class Initialized
INFO - 2016-12-03 05:09:08 --> Language Class Initialized
INFO - 2016-12-03 05:09:08 --> Loader Class Initialized
INFO - 2016-12-03 05:09:08 --> Database Driver Class Initialized
INFO - 2016-12-03 05:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:09:08 --> Controller Class Initialized
INFO - 2016-12-03 05:09:08 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:09:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:09:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:09:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:09:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:09:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:09:08 --> Final output sent to browser
DEBUG - 2016-12-03 05:09:08 --> Total execution time: 0.0607
INFO - 2016-12-03 05:09:09 --> Config Class Initialized
INFO - 2016-12-03 05:09:09 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:09:09 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:09:09 --> Utf8 Class Initialized
INFO - 2016-12-03 05:09:09 --> URI Class Initialized
INFO - 2016-12-03 05:09:09 --> Router Class Initialized
INFO - 2016-12-03 05:09:09 --> Output Class Initialized
INFO - 2016-12-03 05:09:09 --> Security Class Initialized
DEBUG - 2016-12-03 05:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:09:09 --> Input Class Initialized
INFO - 2016-12-03 05:09:09 --> Language Class Initialized
INFO - 2016-12-03 05:09:09 --> Loader Class Initialized
INFO - 2016-12-03 05:09:09 --> Database Driver Class Initialized
INFO - 2016-12-03 05:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:09:09 --> Controller Class Initialized
DEBUG - 2016-12-03 05:09:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:09:09 --> Helper loaded: url_helper
INFO - 2016-12-03 05:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 05:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 05:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 05:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 05:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:09:09 --> Final output sent to browser
DEBUG - 2016-12-03 05:09:09 --> Total execution time: 0.0117
INFO - 2016-12-03 05:09:09 --> Config Class Initialized
INFO - 2016-12-03 05:09:09 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:09:09 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:09:09 --> Utf8 Class Initialized
INFO - 2016-12-03 05:09:09 --> URI Class Initialized
INFO - 2016-12-03 05:09:09 --> Router Class Initialized
INFO - 2016-12-03 05:09:09 --> Output Class Initialized
INFO - 2016-12-03 05:09:09 --> Security Class Initialized
DEBUG - 2016-12-03 05:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:09:09 --> Input Class Initialized
INFO - 2016-12-03 05:09:09 --> Language Class Initialized
ERROR - 2016-12-03 05:09:09 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 05:09:09 --> Config Class Initialized
INFO - 2016-12-03 05:09:09 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:09:09 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:09:09 --> Utf8 Class Initialized
INFO - 2016-12-03 05:09:09 --> URI Class Initialized
INFO - 2016-12-03 05:09:09 --> Router Class Initialized
INFO - 2016-12-03 05:09:09 --> Output Class Initialized
INFO - 2016-12-03 05:09:09 --> Security Class Initialized
DEBUG - 2016-12-03 05:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:09:09 --> Input Class Initialized
INFO - 2016-12-03 05:09:09 --> Language Class Initialized
INFO - 2016-12-03 05:09:09 --> Loader Class Initialized
INFO - 2016-12-03 05:09:09 --> Database Driver Class Initialized
INFO - 2016-12-03 05:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:09:09 --> Controller Class Initialized
INFO - 2016-12-03 05:09:09 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:09:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:09:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:09:09 --> Final output sent to browser
DEBUG - 2016-12-03 05:09:09 --> Total execution time: 0.0130
INFO - 2016-12-03 05:09:11 --> Config Class Initialized
INFO - 2016-12-03 05:09:11 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:09:11 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:09:11 --> Utf8 Class Initialized
INFO - 2016-12-03 05:09:11 --> URI Class Initialized
INFO - 2016-12-03 05:09:11 --> Router Class Initialized
INFO - 2016-12-03 05:09:11 --> Output Class Initialized
INFO - 2016-12-03 05:09:11 --> Security Class Initialized
DEBUG - 2016-12-03 05:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:09:11 --> Input Class Initialized
INFO - 2016-12-03 05:09:11 --> Language Class Initialized
INFO - 2016-12-03 05:09:11 --> Loader Class Initialized
INFO - 2016-12-03 05:09:11 --> Database Driver Class Initialized
INFO - 2016-12-03 05:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:09:11 --> Controller Class Initialized
INFO - 2016-12-03 05:09:11 --> Helper loaded: date_helper
DEBUG - 2016-12-03 05:09:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:09:11 --> Helper loaded: url_helper
INFO - 2016-12-03 05:09:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:09:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 05:09:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 05:09:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 05:09:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:09:11 --> Final output sent to browser
DEBUG - 2016-12-03 05:09:11 --> Total execution time: 0.0166
INFO - 2016-12-03 05:09:11 --> Config Class Initialized
INFO - 2016-12-03 05:09:11 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:09:11 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:09:11 --> Utf8 Class Initialized
INFO - 2016-12-03 05:09:11 --> URI Class Initialized
INFO - 2016-12-03 05:09:11 --> Router Class Initialized
INFO - 2016-12-03 05:09:11 --> Output Class Initialized
INFO - 2016-12-03 05:09:11 --> Security Class Initialized
DEBUG - 2016-12-03 05:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:09:11 --> Input Class Initialized
INFO - 2016-12-03 05:09:11 --> Language Class Initialized
ERROR - 2016-12-03 05:09:11 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 05:09:11 --> Config Class Initialized
INFO - 2016-12-03 05:09:11 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:09:11 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:09:11 --> Utf8 Class Initialized
INFO - 2016-12-03 05:09:11 --> URI Class Initialized
INFO - 2016-12-03 05:09:11 --> Router Class Initialized
INFO - 2016-12-03 05:09:11 --> Output Class Initialized
INFO - 2016-12-03 05:09:11 --> Security Class Initialized
DEBUG - 2016-12-03 05:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:09:11 --> Input Class Initialized
INFO - 2016-12-03 05:09:11 --> Language Class Initialized
INFO - 2016-12-03 05:09:11 --> Loader Class Initialized
INFO - 2016-12-03 05:09:11 --> Database Driver Class Initialized
INFO - 2016-12-03 05:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:09:11 --> Controller Class Initialized
INFO - 2016-12-03 05:09:11 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:09:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:09:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:09:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:09:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:09:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:09:11 --> Final output sent to browser
DEBUG - 2016-12-03 05:09:11 --> Total execution time: 0.0133
INFO - 2016-12-03 05:09:12 --> Config Class Initialized
INFO - 2016-12-03 05:09:12 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:09:12 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:09:12 --> Utf8 Class Initialized
INFO - 2016-12-03 05:09:12 --> URI Class Initialized
INFO - 2016-12-03 05:09:12 --> Router Class Initialized
INFO - 2016-12-03 05:09:12 --> Output Class Initialized
INFO - 2016-12-03 05:09:12 --> Security Class Initialized
DEBUG - 2016-12-03 05:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:09:12 --> Input Class Initialized
INFO - 2016-12-03 05:09:12 --> Language Class Initialized
INFO - 2016-12-03 05:09:12 --> Loader Class Initialized
INFO - 2016-12-03 05:09:12 --> Database Driver Class Initialized
INFO - 2016-12-03 05:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:09:12 --> Controller Class Initialized
DEBUG - 2016-12-03 05:09:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:09:12 --> Helper loaded: url_helper
INFO - 2016-12-03 05:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 05:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 05:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 05:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 05:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:09:12 --> Final output sent to browser
DEBUG - 2016-12-03 05:09:12 --> Total execution time: 0.0122
INFO - 2016-12-03 05:09:12 --> Config Class Initialized
INFO - 2016-12-03 05:09:12 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:09:12 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:09:12 --> Utf8 Class Initialized
INFO - 2016-12-03 05:09:12 --> URI Class Initialized
INFO - 2016-12-03 05:09:12 --> Router Class Initialized
INFO - 2016-12-03 05:09:12 --> Output Class Initialized
INFO - 2016-12-03 05:09:12 --> Security Class Initialized
DEBUG - 2016-12-03 05:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:09:12 --> Input Class Initialized
INFO - 2016-12-03 05:09:12 --> Language Class Initialized
ERROR - 2016-12-03 05:09:12 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 05:09:13 --> Config Class Initialized
INFO - 2016-12-03 05:09:13 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:09:13 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:09:13 --> Utf8 Class Initialized
INFO - 2016-12-03 05:09:13 --> URI Class Initialized
INFO - 2016-12-03 05:09:13 --> Router Class Initialized
INFO - 2016-12-03 05:09:13 --> Output Class Initialized
INFO - 2016-12-03 05:09:13 --> Security Class Initialized
DEBUG - 2016-12-03 05:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:09:13 --> Input Class Initialized
INFO - 2016-12-03 05:09:13 --> Language Class Initialized
INFO - 2016-12-03 05:09:13 --> Loader Class Initialized
INFO - 2016-12-03 05:09:13 --> Database Driver Class Initialized
INFO - 2016-12-03 05:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:09:13 --> Controller Class Initialized
INFO - 2016-12-03 05:09:13 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:09:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:09:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:09:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:09:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:09:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:09:13 --> Final output sent to browser
DEBUG - 2016-12-03 05:09:13 --> Total execution time: 0.0147
INFO - 2016-12-03 05:10:13 --> Config Class Initialized
INFO - 2016-12-03 05:10:13 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:10:13 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:10:13 --> Utf8 Class Initialized
INFO - 2016-12-03 05:10:13 --> URI Class Initialized
INFO - 2016-12-03 05:10:13 --> Router Class Initialized
INFO - 2016-12-03 05:10:13 --> Output Class Initialized
INFO - 2016-12-03 05:10:13 --> Security Class Initialized
DEBUG - 2016-12-03 05:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:10:13 --> Input Class Initialized
INFO - 2016-12-03 05:10:13 --> Language Class Initialized
INFO - 2016-12-03 05:10:13 --> Loader Class Initialized
INFO - 2016-12-03 05:10:13 --> Database Driver Class Initialized
INFO - 2016-12-03 05:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:10:13 --> Controller Class Initialized
DEBUG - 2016-12-03 05:10:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:10:13 --> Helper loaded: url_helper
INFO - 2016-12-03 05:10:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:10:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 05:10:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-03 05:10:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-03 05:10:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:10:13 --> Final output sent to browser
DEBUG - 2016-12-03 05:10:13 --> Total execution time: 0.0187
INFO - 2016-12-03 05:10:14 --> Config Class Initialized
INFO - 2016-12-03 05:10:14 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:10:14 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:10:14 --> Utf8 Class Initialized
INFO - 2016-12-03 05:10:14 --> URI Class Initialized
INFO - 2016-12-03 05:10:14 --> Router Class Initialized
INFO - 2016-12-03 05:10:14 --> Output Class Initialized
INFO - 2016-12-03 05:10:14 --> Security Class Initialized
DEBUG - 2016-12-03 05:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:10:14 --> Input Class Initialized
INFO - 2016-12-03 05:10:14 --> Language Class Initialized
ERROR - 2016-12-03 05:10:14 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 05:10:14 --> Config Class Initialized
INFO - 2016-12-03 05:10:14 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:10:14 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:10:14 --> Utf8 Class Initialized
INFO - 2016-12-03 05:10:14 --> URI Class Initialized
INFO - 2016-12-03 05:10:14 --> Router Class Initialized
INFO - 2016-12-03 05:10:14 --> Output Class Initialized
INFO - 2016-12-03 05:10:14 --> Security Class Initialized
DEBUG - 2016-12-03 05:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:10:14 --> Input Class Initialized
INFO - 2016-12-03 05:10:14 --> Language Class Initialized
INFO - 2016-12-03 05:10:14 --> Loader Class Initialized
INFO - 2016-12-03 05:10:14 --> Database Driver Class Initialized
INFO - 2016-12-03 05:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:10:14 --> Controller Class Initialized
INFO - 2016-12-03 05:10:14 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:10:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:10:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:10:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:10:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:10:14 --> Final output sent to browser
DEBUG - 2016-12-03 05:10:14 --> Total execution time: 0.0598
INFO - 2016-12-03 05:10:21 --> Config Class Initialized
INFO - 2016-12-03 05:10:21 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:10:21 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:10:21 --> Utf8 Class Initialized
INFO - 2016-12-03 05:10:21 --> URI Class Initialized
INFO - 2016-12-03 05:10:21 --> Router Class Initialized
INFO - 2016-12-03 05:10:21 --> Output Class Initialized
INFO - 2016-12-03 05:10:21 --> Security Class Initialized
DEBUG - 2016-12-03 05:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:10:21 --> Input Class Initialized
INFO - 2016-12-03 05:10:21 --> Language Class Initialized
INFO - 2016-12-03 05:10:21 --> Loader Class Initialized
INFO - 2016-12-03 05:10:21 --> Database Driver Class Initialized
INFO - 2016-12-03 05:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:10:21 --> Controller Class Initialized
DEBUG - 2016-12-03 05:10:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:10:21 --> Helper loaded: url_helper
INFO - 2016-12-03 05:10:21 --> Final output sent to browser
DEBUG - 2016-12-03 05:10:21 --> Total execution time: 0.0193
INFO - 2016-12-03 05:10:27 --> Config Class Initialized
INFO - 2016-12-03 05:10:27 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:10:27 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:10:27 --> Utf8 Class Initialized
INFO - 2016-12-03 05:10:27 --> URI Class Initialized
INFO - 2016-12-03 05:10:27 --> Router Class Initialized
INFO - 2016-12-03 05:10:27 --> Output Class Initialized
INFO - 2016-12-03 05:10:27 --> Security Class Initialized
DEBUG - 2016-12-03 05:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:10:27 --> Input Class Initialized
INFO - 2016-12-03 05:10:27 --> Language Class Initialized
INFO - 2016-12-03 05:10:27 --> Loader Class Initialized
INFO - 2016-12-03 05:10:27 --> Database Driver Class Initialized
INFO - 2016-12-03 05:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:10:27 --> Controller Class Initialized
DEBUG - 2016-12-03 05:10:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:10:27 --> Helper loaded: url_helper
INFO - 2016-12-03 05:10:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:10:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 05:10:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 05:10:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 05:10:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 05:10:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:10:27 --> Final output sent to browser
DEBUG - 2016-12-03 05:10:27 --> Total execution time: 0.0124
INFO - 2016-12-03 05:10:27 --> Config Class Initialized
INFO - 2016-12-03 05:10:27 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:10:27 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:10:27 --> Utf8 Class Initialized
INFO - 2016-12-03 05:10:27 --> URI Class Initialized
INFO - 2016-12-03 05:10:27 --> Router Class Initialized
INFO - 2016-12-03 05:10:27 --> Output Class Initialized
INFO - 2016-12-03 05:10:27 --> Security Class Initialized
DEBUG - 2016-12-03 05:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:10:27 --> Input Class Initialized
INFO - 2016-12-03 05:10:27 --> Language Class Initialized
ERROR - 2016-12-03 05:10:27 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 05:10:29 --> Config Class Initialized
INFO - 2016-12-03 05:10:29 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:10:29 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:10:29 --> Utf8 Class Initialized
INFO - 2016-12-03 05:10:29 --> URI Class Initialized
INFO - 2016-12-03 05:10:29 --> Router Class Initialized
INFO - 2016-12-03 05:10:29 --> Output Class Initialized
INFO - 2016-12-03 05:10:29 --> Security Class Initialized
DEBUG - 2016-12-03 05:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:10:29 --> Input Class Initialized
INFO - 2016-12-03 05:10:29 --> Language Class Initialized
INFO - 2016-12-03 05:10:29 --> Loader Class Initialized
INFO - 2016-12-03 05:10:29 --> Database Driver Class Initialized
INFO - 2016-12-03 05:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:10:29 --> Controller Class Initialized
INFO - 2016-12-03 05:10:29 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:10:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:10:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:10:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:10:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:10:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:10:29 --> Final output sent to browser
DEBUG - 2016-12-03 05:10:29 --> Total execution time: 0.0149
INFO - 2016-12-03 05:26:48 --> Config Class Initialized
INFO - 2016-12-03 05:26:48 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:26:48 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:26:48 --> Utf8 Class Initialized
INFO - 2016-12-03 05:26:48 --> URI Class Initialized
INFO - 2016-12-03 05:26:48 --> Router Class Initialized
INFO - 2016-12-03 05:26:48 --> Output Class Initialized
INFO - 2016-12-03 05:26:48 --> Security Class Initialized
DEBUG - 2016-12-03 05:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:26:48 --> Input Class Initialized
INFO - 2016-12-03 05:26:48 --> Language Class Initialized
INFO - 2016-12-03 05:26:48 --> Loader Class Initialized
INFO - 2016-12-03 05:26:48 --> Database Driver Class Initialized
INFO - 2016-12-03 05:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:26:48 --> Controller Class Initialized
DEBUG - 2016-12-03 05:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:26:48 --> Helper loaded: url_helper
INFO - 2016-12-03 05:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 05:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 05:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 05:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 05:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:26:48 --> Final output sent to browser
DEBUG - 2016-12-03 05:26:48 --> Total execution time: 0.0125
INFO - 2016-12-03 05:26:49 --> Config Class Initialized
INFO - 2016-12-03 05:26:49 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:26:49 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:26:49 --> Utf8 Class Initialized
INFO - 2016-12-03 05:26:49 --> URI Class Initialized
INFO - 2016-12-03 05:26:49 --> Router Class Initialized
INFO - 2016-12-03 05:26:49 --> Output Class Initialized
INFO - 2016-12-03 05:26:49 --> Security Class Initialized
DEBUG - 2016-12-03 05:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:26:49 --> Input Class Initialized
INFO - 2016-12-03 05:26:49 --> Language Class Initialized
ERROR - 2016-12-03 05:26:49 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 05:26:49 --> Config Class Initialized
INFO - 2016-12-03 05:26:49 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:26:49 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:26:49 --> Utf8 Class Initialized
INFO - 2016-12-03 05:26:49 --> URI Class Initialized
INFO - 2016-12-03 05:26:49 --> Router Class Initialized
INFO - 2016-12-03 05:26:49 --> Output Class Initialized
INFO - 2016-12-03 05:26:49 --> Security Class Initialized
DEBUG - 2016-12-03 05:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:26:49 --> Input Class Initialized
INFO - 2016-12-03 05:26:49 --> Language Class Initialized
INFO - 2016-12-03 05:26:49 --> Loader Class Initialized
INFO - 2016-12-03 05:26:49 --> Database Driver Class Initialized
INFO - 2016-12-03 05:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:26:49 --> Controller Class Initialized
INFO - 2016-12-03 05:26:49 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:26:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:26:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:26:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:26:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:26:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:26:49 --> Final output sent to browser
DEBUG - 2016-12-03 05:26:49 --> Total execution time: 0.0145
INFO - 2016-12-03 05:27:04 --> Config Class Initialized
INFO - 2016-12-03 05:27:04 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:27:04 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:27:04 --> Utf8 Class Initialized
INFO - 2016-12-03 05:27:04 --> URI Class Initialized
INFO - 2016-12-03 05:27:04 --> Router Class Initialized
INFO - 2016-12-03 05:27:04 --> Output Class Initialized
INFO - 2016-12-03 05:27:04 --> Security Class Initialized
DEBUG - 2016-12-03 05:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:27:04 --> Input Class Initialized
INFO - 2016-12-03 05:27:04 --> Language Class Initialized
INFO - 2016-12-03 05:27:04 --> Loader Class Initialized
INFO - 2016-12-03 05:27:04 --> Database Driver Class Initialized
INFO - 2016-12-03 05:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:27:04 --> Controller Class Initialized
DEBUG - 2016-12-03 05:27:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:27:04 --> Helper loaded: url_helper
INFO - 2016-12-03 05:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 05:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 05:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 05:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 05:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:27:04 --> Final output sent to browser
DEBUG - 2016-12-03 05:27:04 --> Total execution time: 0.0134
INFO - 2016-12-03 05:27:04 --> Config Class Initialized
INFO - 2016-12-03 05:27:04 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:27:04 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:27:04 --> Utf8 Class Initialized
INFO - 2016-12-03 05:27:04 --> URI Class Initialized
INFO - 2016-12-03 05:27:04 --> Router Class Initialized
INFO - 2016-12-03 05:27:04 --> Output Class Initialized
INFO - 2016-12-03 05:27:04 --> Security Class Initialized
DEBUG - 2016-12-03 05:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:27:04 --> Input Class Initialized
INFO - 2016-12-03 05:27:04 --> Language Class Initialized
ERROR - 2016-12-03 05:27:04 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 05:27:05 --> Config Class Initialized
INFO - 2016-12-03 05:27:05 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:27:05 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:27:05 --> Utf8 Class Initialized
INFO - 2016-12-03 05:27:05 --> URI Class Initialized
INFO - 2016-12-03 05:27:05 --> Router Class Initialized
INFO - 2016-12-03 05:27:05 --> Output Class Initialized
INFO - 2016-12-03 05:27:05 --> Security Class Initialized
DEBUG - 2016-12-03 05:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:27:05 --> Input Class Initialized
INFO - 2016-12-03 05:27:05 --> Language Class Initialized
INFO - 2016-12-03 05:27:05 --> Loader Class Initialized
INFO - 2016-12-03 05:27:05 --> Database Driver Class Initialized
INFO - 2016-12-03 05:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:27:05 --> Controller Class Initialized
INFO - 2016-12-03 05:27:05 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:27:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:27:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:27:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:27:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:27:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:27:05 --> Final output sent to browser
DEBUG - 2016-12-03 05:27:05 --> Total execution time: 0.0132
INFO - 2016-12-03 05:45:49 --> Config Class Initialized
INFO - 2016-12-03 05:45:49 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:45:49 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:45:49 --> Utf8 Class Initialized
INFO - 2016-12-03 05:45:49 --> URI Class Initialized
INFO - 2016-12-03 05:45:49 --> Router Class Initialized
INFO - 2016-12-03 05:45:49 --> Output Class Initialized
INFO - 2016-12-03 05:45:49 --> Security Class Initialized
DEBUG - 2016-12-03 05:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:45:49 --> Input Class Initialized
INFO - 2016-12-03 05:45:49 --> Language Class Initialized
INFO - 2016-12-03 05:45:49 --> Loader Class Initialized
INFO - 2016-12-03 05:45:49 --> Database Driver Class Initialized
INFO - 2016-12-03 05:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:45:49 --> Controller Class Initialized
ERROR - 2016-12-03 05:45:49 --> Severity: error --> Exception: Unable to locate the model you have specified: Persona_productos /home/graduafe/public_html/system/core/Loader.php 344
INFO - 2016-12-03 05:45:49 --> Config Class Initialized
INFO - 2016-12-03 05:45:49 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:45:49 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:45:49 --> Utf8 Class Initialized
INFO - 2016-12-03 05:45:49 --> URI Class Initialized
INFO - 2016-12-03 05:45:49 --> Router Class Initialized
INFO - 2016-12-03 05:45:49 --> Output Class Initialized
INFO - 2016-12-03 05:45:49 --> Security Class Initialized
DEBUG - 2016-12-03 05:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:45:49 --> Input Class Initialized
INFO - 2016-12-03 05:45:49 --> Language Class Initialized
INFO - 2016-12-03 05:45:49 --> Loader Class Initialized
INFO - 2016-12-03 05:45:49 --> Database Driver Class Initialized
INFO - 2016-12-03 05:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:45:49 --> Controller Class Initialized
INFO - 2016-12-03 05:45:49 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:45:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:45:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:45:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:45:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:45:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:45:49 --> Final output sent to browser
DEBUG - 2016-12-03 05:45:49 --> Total execution time: 0.0134
INFO - 2016-12-03 05:46:18 --> Config Class Initialized
INFO - 2016-12-03 05:46:18 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:46:18 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:46:18 --> Utf8 Class Initialized
INFO - 2016-12-03 05:46:18 --> URI Class Initialized
INFO - 2016-12-03 05:46:18 --> Router Class Initialized
INFO - 2016-12-03 05:46:18 --> Output Class Initialized
INFO - 2016-12-03 05:46:18 --> Security Class Initialized
DEBUG - 2016-12-03 05:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:46:18 --> Input Class Initialized
INFO - 2016-12-03 05:46:18 --> Language Class Initialized
INFO - 2016-12-03 05:46:18 --> Loader Class Initialized
INFO - 2016-12-03 05:46:18 --> Database Driver Class Initialized
INFO - 2016-12-03 05:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:46:18 --> Controller Class Initialized
DEBUG - 2016-12-03 05:46:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:46:18 --> Helper loaded: url_helper
INFO - 2016-12-03 05:46:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:46:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 05:46:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 05:46:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 05:46:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 05:46:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:46:18 --> Final output sent to browser
DEBUG - 2016-12-03 05:46:18 --> Total execution time: 0.0175
INFO - 2016-12-03 05:46:18 --> Config Class Initialized
INFO - 2016-12-03 05:46:18 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:46:18 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:46:18 --> Utf8 Class Initialized
INFO - 2016-12-03 05:46:18 --> URI Class Initialized
INFO - 2016-12-03 05:46:18 --> Router Class Initialized
INFO - 2016-12-03 05:46:18 --> Output Class Initialized
INFO - 2016-12-03 05:46:18 --> Security Class Initialized
DEBUG - 2016-12-03 05:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:46:18 --> Input Class Initialized
INFO - 2016-12-03 05:46:18 --> Language Class Initialized
ERROR - 2016-12-03 05:46:18 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 05:46:18 --> Config Class Initialized
INFO - 2016-12-03 05:46:18 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:46:18 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:46:18 --> Utf8 Class Initialized
INFO - 2016-12-03 05:46:18 --> URI Class Initialized
INFO - 2016-12-03 05:46:18 --> Router Class Initialized
INFO - 2016-12-03 05:46:18 --> Output Class Initialized
INFO - 2016-12-03 05:46:18 --> Security Class Initialized
DEBUG - 2016-12-03 05:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:46:18 --> Input Class Initialized
INFO - 2016-12-03 05:46:18 --> Language Class Initialized
INFO - 2016-12-03 05:46:18 --> Loader Class Initialized
INFO - 2016-12-03 05:46:18 --> Database Driver Class Initialized
INFO - 2016-12-03 05:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:46:18 --> Controller Class Initialized
INFO - 2016-12-03 05:46:18 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:46:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:46:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:46:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:46:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:46:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:46:18 --> Final output sent to browser
DEBUG - 2016-12-03 05:46:18 --> Total execution time: 0.0140
INFO - 2016-12-03 05:46:23 --> Config Class Initialized
INFO - 2016-12-03 05:46:23 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:46:23 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:46:23 --> Utf8 Class Initialized
INFO - 2016-12-03 05:46:23 --> URI Class Initialized
INFO - 2016-12-03 05:46:23 --> Router Class Initialized
INFO - 2016-12-03 05:46:23 --> Output Class Initialized
INFO - 2016-12-03 05:46:23 --> Security Class Initialized
DEBUG - 2016-12-03 05:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:46:23 --> Input Class Initialized
INFO - 2016-12-03 05:46:23 --> Language Class Initialized
INFO - 2016-12-03 05:46:23 --> Loader Class Initialized
INFO - 2016-12-03 05:46:23 --> Database Driver Class Initialized
INFO - 2016-12-03 05:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:46:23 --> Controller Class Initialized
DEBUG - 2016-12-03 05:46:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:46:23 --> Helper loaded: url_helper
INFO - 2016-12-03 05:46:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:46:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 05:46:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-03 05:46:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-03 05:46:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:46:24 --> Final output sent to browser
DEBUG - 2016-12-03 05:46:24 --> Total execution time: 0.0636
INFO - 2016-12-03 05:46:24 --> Config Class Initialized
INFO - 2016-12-03 05:46:24 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:46:24 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:46:24 --> Utf8 Class Initialized
INFO - 2016-12-03 05:46:24 --> URI Class Initialized
INFO - 2016-12-03 05:46:24 --> Router Class Initialized
INFO - 2016-12-03 05:46:24 --> Output Class Initialized
INFO - 2016-12-03 05:46:24 --> Security Class Initialized
DEBUG - 2016-12-03 05:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:46:24 --> Input Class Initialized
INFO - 2016-12-03 05:46:24 --> Language Class Initialized
ERROR - 2016-12-03 05:46:24 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 05:46:24 --> Config Class Initialized
INFO - 2016-12-03 05:46:24 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:46:24 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:46:24 --> Utf8 Class Initialized
INFO - 2016-12-03 05:46:24 --> URI Class Initialized
INFO - 2016-12-03 05:46:24 --> Router Class Initialized
INFO - 2016-12-03 05:46:24 --> Output Class Initialized
INFO - 2016-12-03 05:46:24 --> Security Class Initialized
DEBUG - 2016-12-03 05:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:46:24 --> Input Class Initialized
INFO - 2016-12-03 05:46:24 --> Language Class Initialized
INFO - 2016-12-03 05:46:24 --> Loader Class Initialized
INFO - 2016-12-03 05:46:24 --> Database Driver Class Initialized
INFO - 2016-12-03 05:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:46:24 --> Controller Class Initialized
INFO - 2016-12-03 05:46:24 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:46:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:46:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:46:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:46:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:46:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:46:24 --> Final output sent to browser
DEBUG - 2016-12-03 05:46:24 --> Total execution time: 0.0136
INFO - 2016-12-03 05:46:31 --> Config Class Initialized
INFO - 2016-12-03 05:46:31 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:46:31 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:46:31 --> Utf8 Class Initialized
INFO - 2016-12-03 05:46:31 --> URI Class Initialized
INFO - 2016-12-03 05:46:31 --> Router Class Initialized
INFO - 2016-12-03 05:46:31 --> Output Class Initialized
INFO - 2016-12-03 05:46:31 --> Security Class Initialized
DEBUG - 2016-12-03 05:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:46:31 --> Input Class Initialized
INFO - 2016-12-03 05:46:31 --> Language Class Initialized
INFO - 2016-12-03 05:46:31 --> Loader Class Initialized
INFO - 2016-12-03 05:46:31 --> Database Driver Class Initialized
INFO - 2016-12-03 05:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:46:31 --> Controller Class Initialized
DEBUG - 2016-12-03 05:46:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:46:31 --> Helper loaded: url_helper
INFO - 2016-12-03 05:46:31 --> Final output sent to browser
DEBUG - 2016-12-03 05:46:31 --> Total execution time: 0.0121
INFO - 2016-12-03 05:46:37 --> Config Class Initialized
INFO - 2016-12-03 05:46:37 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:46:37 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:46:37 --> Utf8 Class Initialized
INFO - 2016-12-03 05:46:37 --> URI Class Initialized
INFO - 2016-12-03 05:46:37 --> Router Class Initialized
INFO - 2016-12-03 05:46:37 --> Output Class Initialized
INFO - 2016-12-03 05:46:37 --> Security Class Initialized
DEBUG - 2016-12-03 05:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:46:37 --> Input Class Initialized
INFO - 2016-12-03 05:46:37 --> Language Class Initialized
INFO - 2016-12-03 05:46:37 --> Loader Class Initialized
INFO - 2016-12-03 05:46:37 --> Database Driver Class Initialized
INFO - 2016-12-03 05:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:46:37 --> Controller Class Initialized
DEBUG - 2016-12-03 05:46:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:46:37 --> Helper loaded: url_helper
INFO - 2016-12-03 05:46:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:46:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 05:46:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 05:46:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 05:46:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 05:46:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:46:37 --> Final output sent to browser
DEBUG - 2016-12-03 05:46:37 --> Total execution time: 0.0121
INFO - 2016-12-03 05:46:37 --> Config Class Initialized
INFO - 2016-12-03 05:46:37 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:46:37 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:46:37 --> Utf8 Class Initialized
INFO - 2016-12-03 05:46:37 --> URI Class Initialized
INFO - 2016-12-03 05:46:37 --> Router Class Initialized
INFO - 2016-12-03 05:46:37 --> Output Class Initialized
INFO - 2016-12-03 05:46:37 --> Security Class Initialized
DEBUG - 2016-12-03 05:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:46:37 --> Input Class Initialized
INFO - 2016-12-03 05:46:37 --> Language Class Initialized
ERROR - 2016-12-03 05:46:37 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 05:46:37 --> Config Class Initialized
INFO - 2016-12-03 05:46:37 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:46:37 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:46:37 --> Utf8 Class Initialized
INFO - 2016-12-03 05:46:37 --> URI Class Initialized
INFO - 2016-12-03 05:46:37 --> Router Class Initialized
INFO - 2016-12-03 05:46:37 --> Output Class Initialized
INFO - 2016-12-03 05:46:37 --> Security Class Initialized
DEBUG - 2016-12-03 05:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:46:37 --> Input Class Initialized
INFO - 2016-12-03 05:46:37 --> Language Class Initialized
INFO - 2016-12-03 05:46:37 --> Loader Class Initialized
INFO - 2016-12-03 05:46:37 --> Database Driver Class Initialized
INFO - 2016-12-03 05:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:46:37 --> Controller Class Initialized
INFO - 2016-12-03 05:46:37 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:46:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:46:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:46:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:46:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:46:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:46:37 --> Final output sent to browser
DEBUG - 2016-12-03 05:46:37 --> Total execution time: 0.0134
INFO - 2016-12-03 05:46:40 --> Config Class Initialized
INFO - 2016-12-03 05:46:40 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:46:40 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:46:40 --> Utf8 Class Initialized
INFO - 2016-12-03 05:46:40 --> URI Class Initialized
INFO - 2016-12-03 05:46:40 --> Router Class Initialized
INFO - 2016-12-03 05:46:40 --> Output Class Initialized
INFO - 2016-12-03 05:46:40 --> Security Class Initialized
DEBUG - 2016-12-03 05:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:46:40 --> Input Class Initialized
INFO - 2016-12-03 05:46:40 --> Language Class Initialized
INFO - 2016-12-03 05:46:40 --> Loader Class Initialized
INFO - 2016-12-03 05:46:40 --> Database Driver Class Initialized
INFO - 2016-12-03 05:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:46:40 --> Controller Class Initialized
DEBUG - 2016-12-03 05:46:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:46:40 --> Helper loaded: url_helper
ERROR - 2016-12-03 05:46:40 --> Severity: Notice --> Undefined property: User_carrito_compras_controller::$persona_productos /home/graduafe/public_html/application/controllers/User_carrito_compras_controller.php 32
ERROR - 2016-12-03 05:46:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-03 05:46:40 --> Severity: Error --> Call to a member function registrar_compra() on a non-object /home/graduafe/public_html/application/controllers/User_carrito_compras_controller.php 32
INFO - 2016-12-03 05:46:59 --> Config Class Initialized
INFO - 2016-12-03 05:46:59 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:46:59 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:46:59 --> Utf8 Class Initialized
INFO - 2016-12-03 05:46:59 --> URI Class Initialized
INFO - 2016-12-03 05:46:59 --> Router Class Initialized
INFO - 2016-12-03 05:46:59 --> Output Class Initialized
INFO - 2016-12-03 05:46:59 --> Security Class Initialized
DEBUG - 2016-12-03 05:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:46:59 --> Input Class Initialized
INFO - 2016-12-03 05:46:59 --> Language Class Initialized
INFO - 2016-12-03 05:46:59 --> Loader Class Initialized
INFO - 2016-12-03 05:46:59 --> Database Driver Class Initialized
INFO - 2016-12-03 05:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:46:59 --> Controller Class Initialized
INFO - 2016-12-03 05:46:59 --> Helper loaded: date_helper
INFO - 2016-12-03 05:46:59 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:46:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:46:59 --> Helper loaded: form_helper
INFO - 2016-12-03 05:46:59 --> Form Validation Class Initialized
INFO - 2016-12-03 05:46:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-03 05:46:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-03 05:46:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2016-12-03 05:46:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2016-12-03 05:46:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-03 05:46:59 --> Final output sent to browser
DEBUG - 2016-12-03 05:46:59 --> Total execution time: 0.1380
INFO - 2016-12-03 05:47:00 --> Config Class Initialized
INFO - 2016-12-03 05:47:00 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:47:00 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:47:00 --> Utf8 Class Initialized
INFO - 2016-12-03 05:47:00 --> URI Class Initialized
INFO - 2016-12-03 05:47:00 --> Router Class Initialized
INFO - 2016-12-03 05:47:00 --> Output Class Initialized
INFO - 2016-12-03 05:47:00 --> Security Class Initialized
DEBUG - 2016-12-03 05:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:47:00 --> Input Class Initialized
INFO - 2016-12-03 05:47:00 --> Language Class Initialized
INFO - 2016-12-03 05:47:00 --> Loader Class Initialized
INFO - 2016-12-03 05:47:00 --> Database Driver Class Initialized
INFO - 2016-12-03 05:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:47:00 --> Controller Class Initialized
INFO - 2016-12-03 05:47:00 --> Helper loaded: date_helper
INFO - 2016-12-03 05:47:00 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:47:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:47:00 --> Helper loaded: form_helper
INFO - 2016-12-03 05:47:00 --> Form Validation Class Initialized
INFO - 2016-12-03 05:47:00 --> Final output sent to browser
DEBUG - 2016-12-03 05:47:00 --> Total execution time: 0.0251
INFO - 2016-12-03 05:47:00 --> Config Class Initialized
INFO - 2016-12-03 05:47:00 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:47:00 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:47:00 --> Utf8 Class Initialized
INFO - 2016-12-03 05:47:00 --> URI Class Initialized
INFO - 2016-12-03 05:47:00 --> Router Class Initialized
INFO - 2016-12-03 05:47:00 --> Output Class Initialized
INFO - 2016-12-03 05:47:00 --> Security Class Initialized
DEBUG - 2016-12-03 05:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:47:00 --> Input Class Initialized
INFO - 2016-12-03 05:47:00 --> Language Class Initialized
INFO - 2016-12-03 05:47:00 --> Loader Class Initialized
INFO - 2016-12-03 05:47:00 --> Database Driver Class Initialized
INFO - 2016-12-03 05:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:47:00 --> Controller Class Initialized
INFO - 2016-12-03 05:47:00 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:47:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:47:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:47:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:47:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:47:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:47:00 --> Final output sent to browser
DEBUG - 2016-12-03 05:47:00 --> Total execution time: 0.0312
INFO - 2016-12-03 05:47:02 --> Config Class Initialized
INFO - 2016-12-03 05:47:02 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:47:02 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:47:02 --> Utf8 Class Initialized
INFO - 2016-12-03 05:47:02 --> URI Class Initialized
INFO - 2016-12-03 05:47:02 --> Router Class Initialized
INFO - 2016-12-03 05:47:02 --> Output Class Initialized
INFO - 2016-12-03 05:47:02 --> Security Class Initialized
DEBUG - 2016-12-03 05:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:47:02 --> Input Class Initialized
INFO - 2016-12-03 05:47:02 --> Language Class Initialized
INFO - 2016-12-03 05:47:02 --> Loader Class Initialized
INFO - 2016-12-03 05:47:02 --> Database Driver Class Initialized
INFO - 2016-12-03 05:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:47:02 --> Controller Class Initialized
INFO - 2016-12-03 05:47:02 --> Helper loaded: date_helper
INFO - 2016-12-03 05:47:02 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:47:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:47:02 --> Helper loaded: form_helper
INFO - 2016-12-03 05:47:02 --> Form Validation Class Initialized
INFO - 2016-12-03 05:47:02 --> Config Class Initialized
INFO - 2016-12-03 05:47:02 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:47:02 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:47:02 --> Utf8 Class Initialized
INFO - 2016-12-03 05:47:02 --> Final output sent to browser
DEBUG - 2016-12-03 05:47:02 --> Total execution time: 0.0497
INFO - 2016-12-03 05:47:02 --> URI Class Initialized
INFO - 2016-12-03 05:47:02 --> Router Class Initialized
INFO - 2016-12-03 05:47:02 --> Output Class Initialized
INFO - 2016-12-03 05:47:02 --> Security Class Initialized
DEBUG - 2016-12-03 05:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:47:02 --> Input Class Initialized
INFO - 2016-12-03 05:47:02 --> Language Class Initialized
INFO - 2016-12-03 05:47:02 --> Loader Class Initialized
INFO - 2016-12-03 05:47:02 --> Database Driver Class Initialized
INFO - 2016-12-03 05:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:47:02 --> Controller Class Initialized
INFO - 2016-12-03 05:47:02 --> Helper loaded: date_helper
INFO - 2016-12-03 05:47:02 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:47:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:47:02 --> Helper loaded: form_helper
INFO - 2016-12-03 05:47:02 --> Form Validation Class Initialized
INFO - 2016-12-03 05:47:02 --> Final output sent to browser
DEBUG - 2016-12-03 05:47:02 --> Total execution time: 0.0479
INFO - 2016-12-03 05:47:04 --> Config Class Initialized
INFO - 2016-12-03 05:47:04 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:47:04 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:47:04 --> Utf8 Class Initialized
INFO - 2016-12-03 05:47:04 --> URI Class Initialized
INFO - 2016-12-03 05:47:04 --> Router Class Initialized
INFO - 2016-12-03 05:47:04 --> Output Class Initialized
INFO - 2016-12-03 05:47:04 --> Security Class Initialized
DEBUG - 2016-12-03 05:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:47:04 --> Input Class Initialized
INFO - 2016-12-03 05:47:04 --> Language Class Initialized
INFO - 2016-12-03 05:47:04 --> Loader Class Initialized
INFO - 2016-12-03 05:47:04 --> Config Class Initialized
INFO - 2016-12-03 05:47:04 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:47:04 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:47:04 --> Utf8 Class Initialized
INFO - 2016-12-03 05:47:04 --> URI Class Initialized
INFO - 2016-12-03 05:47:04 --> Router Class Initialized
INFO - 2016-12-03 05:47:04 --> Output Class Initialized
INFO - 2016-12-03 05:47:04 --> Security Class Initialized
DEBUG - 2016-12-03 05:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:47:04 --> Input Class Initialized
INFO - 2016-12-03 05:47:04 --> Language Class Initialized
INFO - 2016-12-03 05:47:04 --> Loader Class Initialized
INFO - 2016-12-03 05:47:04 --> Database Driver Class Initialized
INFO - 2016-12-03 05:47:04 --> Database Driver Class Initialized
INFO - 2016-12-03 05:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:47:04 --> Controller Class Initialized
INFO - 2016-12-03 05:47:04 --> Helper loaded: date_helper
INFO - 2016-12-03 05:47:04 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:47:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:47:04 --> Helper loaded: form_helper
INFO - 2016-12-03 05:47:04 --> Form Validation Class Initialized
INFO - 2016-12-03 05:47:04 --> Final output sent to browser
DEBUG - 2016-12-03 05:47:04 --> Total execution time: 0.0267
INFO - 2016-12-03 05:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:47:04 --> Controller Class Initialized
INFO - 2016-12-03 05:47:04 --> Helper loaded: date_helper
INFO - 2016-12-03 05:47:04 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:47:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:47:04 --> Helper loaded: form_helper
INFO - 2016-12-03 05:47:04 --> Form Validation Class Initialized
INFO - 2016-12-03 05:47:04 --> Final output sent to browser
DEBUG - 2016-12-03 05:47:04 --> Total execution time: 0.0931
INFO - 2016-12-03 05:49:10 --> Config Class Initialized
INFO - 2016-12-03 05:49:10 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:49:10 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:49:10 --> Utf8 Class Initialized
INFO - 2016-12-03 05:49:10 --> URI Class Initialized
INFO - 2016-12-03 05:49:10 --> Router Class Initialized
INFO - 2016-12-03 05:49:10 --> Output Class Initialized
INFO - 2016-12-03 05:49:10 --> Security Class Initialized
DEBUG - 2016-12-03 05:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:49:10 --> Input Class Initialized
INFO - 2016-12-03 05:49:10 --> Language Class Initialized
INFO - 2016-12-03 05:49:10 --> Loader Class Initialized
INFO - 2016-12-03 05:49:10 --> Database Driver Class Initialized
INFO - 2016-12-03 05:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:49:10 --> Controller Class Initialized
DEBUG - 2016-12-03 05:49:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:49:10 --> Helper loaded: url_helper
INFO - 2016-12-03 05:49:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:49:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 05:49:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 05:49:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 05:49:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 05:49:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:49:10 --> Final output sent to browser
DEBUG - 2016-12-03 05:49:10 --> Total execution time: 0.0145
INFO - 2016-12-03 05:49:10 --> Config Class Initialized
INFO - 2016-12-03 05:49:10 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:49:10 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:49:10 --> Utf8 Class Initialized
INFO - 2016-12-03 05:49:10 --> URI Class Initialized
INFO - 2016-12-03 05:49:10 --> Router Class Initialized
INFO - 2016-12-03 05:49:10 --> Output Class Initialized
INFO - 2016-12-03 05:49:10 --> Security Class Initialized
DEBUG - 2016-12-03 05:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:49:10 --> Input Class Initialized
INFO - 2016-12-03 05:49:10 --> Language Class Initialized
INFO - 2016-12-03 05:49:10 --> Loader Class Initialized
INFO - 2016-12-03 05:49:10 --> Database Driver Class Initialized
INFO - 2016-12-03 05:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:49:10 --> Controller Class Initialized
INFO - 2016-12-03 05:49:10 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:49:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:49:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:49:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:49:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:49:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:49:10 --> Final output sent to browser
DEBUG - 2016-12-03 05:49:10 --> Total execution time: 0.0130
INFO - 2016-12-03 05:49:11 --> Config Class Initialized
INFO - 2016-12-03 05:49:11 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:49:11 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:49:11 --> Utf8 Class Initialized
INFO - 2016-12-03 05:49:11 --> URI Class Initialized
INFO - 2016-12-03 05:49:11 --> Router Class Initialized
INFO - 2016-12-03 05:49:11 --> Output Class Initialized
INFO - 2016-12-03 05:49:11 --> Security Class Initialized
DEBUG - 2016-12-03 05:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:49:11 --> Input Class Initialized
INFO - 2016-12-03 05:49:11 --> Language Class Initialized
ERROR - 2016-12-03 05:49:11 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 05:49:14 --> Config Class Initialized
INFO - 2016-12-03 05:49:14 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:49:14 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:49:14 --> Utf8 Class Initialized
INFO - 2016-12-03 05:49:14 --> URI Class Initialized
INFO - 2016-12-03 05:49:14 --> Router Class Initialized
INFO - 2016-12-03 05:49:14 --> Output Class Initialized
INFO - 2016-12-03 05:49:14 --> Security Class Initialized
DEBUG - 2016-12-03 05:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:49:14 --> Input Class Initialized
INFO - 2016-12-03 05:49:14 --> Language Class Initialized
INFO - 2016-12-03 05:49:14 --> Loader Class Initialized
INFO - 2016-12-03 05:49:14 --> Database Driver Class Initialized
INFO - 2016-12-03 05:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:49:14 --> Controller Class Initialized
DEBUG - 2016-12-03 05:49:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:49:14 --> Helper loaded: url_helper
ERROR - 2016-12-03 05:49:14 --> Severity: Notice --> Undefined property: User_carrito_compras_controller::$persona_productos /home/graduafe/public_html/application/controllers/User_carrito_compras_controller.php 32
ERROR - 2016-12-03 05:49:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
ERROR - 2016-12-03 05:49:14 --> Severity: Error --> Call to a member function registrar_compra() on a non-object /home/graduafe/public_html/application/controllers/User_carrito_compras_controller.php 32
INFO - 2016-12-03 05:49:57 --> Config Class Initialized
INFO - 2016-12-03 05:49:57 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:49:57 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:49:57 --> Utf8 Class Initialized
INFO - 2016-12-03 05:49:57 --> URI Class Initialized
INFO - 2016-12-03 05:49:57 --> Router Class Initialized
INFO - 2016-12-03 05:49:57 --> Output Class Initialized
INFO - 2016-12-03 05:49:57 --> Security Class Initialized
DEBUG - 2016-12-03 05:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:49:57 --> Input Class Initialized
INFO - 2016-12-03 05:49:57 --> Language Class Initialized
INFO - 2016-12-03 05:49:57 --> Loader Class Initialized
INFO - 2016-12-03 05:49:57 --> Database Driver Class Initialized
INFO - 2016-12-03 05:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:49:57 --> Controller Class Initialized
DEBUG - 2016-12-03 05:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:49:57 --> Helper loaded: url_helper
ERROR - 2016-12-03 05:49:57 --> Severity: Notice --> Undefined variable: canitdad /home/graduafe/public_html/application/models/Persona_productos_modelo.php 33
ERROR - 2016-12-03 05:49:57 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `tbl_persona_productos` (`id_persona`, `id_producto`, `id_graduacion`, `cantidad`) VALUES ('5', '24', '26', NULL)
INFO - 2016-12-03 05:49:57 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-12-03 05:49:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2016-12-03 05:54:26 --> Config Class Initialized
INFO - 2016-12-03 05:54:26 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:54:26 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:54:26 --> Utf8 Class Initialized
INFO - 2016-12-03 05:54:26 --> URI Class Initialized
INFO - 2016-12-03 05:54:26 --> Router Class Initialized
INFO - 2016-12-03 05:54:26 --> Output Class Initialized
INFO - 2016-12-03 05:54:26 --> Security Class Initialized
DEBUG - 2016-12-03 05:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:54:26 --> Input Class Initialized
INFO - 2016-12-03 05:54:26 --> Language Class Initialized
INFO - 2016-12-03 05:54:26 --> Loader Class Initialized
INFO - 2016-12-03 05:54:26 --> Database Driver Class Initialized
INFO - 2016-12-03 05:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:54:26 --> Controller Class Initialized
DEBUG - 2016-12-03 05:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:54:26 --> Helper loaded: url_helper
INFO - 2016-12-03 05:54:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:54:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 05:54:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 05:54:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 05:54:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 05:54:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:54:26 --> Final output sent to browser
DEBUG - 2016-12-03 05:54:26 --> Total execution time: 0.0119
INFO - 2016-12-03 05:54:26 --> Config Class Initialized
INFO - 2016-12-03 05:54:26 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:54:26 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:54:26 --> Utf8 Class Initialized
INFO - 2016-12-03 05:54:26 --> URI Class Initialized
INFO - 2016-12-03 05:54:26 --> Router Class Initialized
INFO - 2016-12-03 05:54:26 --> Output Class Initialized
INFO - 2016-12-03 05:54:26 --> Security Class Initialized
DEBUG - 2016-12-03 05:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:54:26 --> Input Class Initialized
INFO - 2016-12-03 05:54:26 --> Language Class Initialized
ERROR - 2016-12-03 05:54:26 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 05:54:26 --> Config Class Initialized
INFO - 2016-12-03 05:54:26 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:54:26 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:54:26 --> Utf8 Class Initialized
INFO - 2016-12-03 05:54:26 --> URI Class Initialized
INFO - 2016-12-03 05:54:26 --> Router Class Initialized
INFO - 2016-12-03 05:54:26 --> Output Class Initialized
INFO - 2016-12-03 05:54:26 --> Security Class Initialized
DEBUG - 2016-12-03 05:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:54:26 --> Input Class Initialized
INFO - 2016-12-03 05:54:26 --> Language Class Initialized
INFO - 2016-12-03 05:54:26 --> Loader Class Initialized
INFO - 2016-12-03 05:54:26 --> Database Driver Class Initialized
INFO - 2016-12-03 05:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:54:26 --> Controller Class Initialized
INFO - 2016-12-03 05:54:26 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:54:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:54:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:54:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:54:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:54:26 --> Final output sent to browser
DEBUG - 2016-12-03 05:54:26 --> Total execution time: 0.0150
INFO - 2016-12-03 05:54:27 --> Config Class Initialized
INFO - 2016-12-03 05:54:27 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:54:27 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:54:27 --> Utf8 Class Initialized
INFO - 2016-12-03 05:54:27 --> URI Class Initialized
INFO - 2016-12-03 05:54:27 --> Router Class Initialized
INFO - 2016-12-03 05:54:27 --> Output Class Initialized
INFO - 2016-12-03 05:54:27 --> Security Class Initialized
DEBUG - 2016-12-03 05:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:54:27 --> Input Class Initialized
INFO - 2016-12-03 05:54:27 --> Language Class Initialized
INFO - 2016-12-03 05:54:27 --> Loader Class Initialized
INFO - 2016-12-03 05:54:27 --> Database Driver Class Initialized
INFO - 2016-12-03 05:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:54:27 --> Controller Class Initialized
DEBUG - 2016-12-03 05:54:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:54:27 --> Helper loaded: url_helper
ERROR - 2016-12-03 05:54:27 --> Severity: Notice --> Undefined variable: canitdad /home/graduafe/public_html/application/models/Persona_productos_modelo.php 33
ERROR - 2016-12-03 05:54:27 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `tbl_persona_productos` (`id_persona`, `id_producto`, `id_graduacion`, `cantidad`) VALUES ('5', '24', '26', NULL)
INFO - 2016-12-03 05:54:27 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-12-03 05:54:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_carrito_compras_controller.php:32) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2016-12-03 05:55:02 --> Config Class Initialized
INFO - 2016-12-03 05:55:02 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:55:02 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:55:02 --> Utf8 Class Initialized
INFO - 2016-12-03 05:55:02 --> URI Class Initialized
INFO - 2016-12-03 05:55:02 --> Router Class Initialized
INFO - 2016-12-03 05:55:02 --> Output Class Initialized
INFO - 2016-12-03 05:55:02 --> Security Class Initialized
DEBUG - 2016-12-03 05:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:55:02 --> Input Class Initialized
INFO - 2016-12-03 05:55:02 --> Language Class Initialized
INFO - 2016-12-03 05:55:02 --> Loader Class Initialized
INFO - 2016-12-03 05:55:02 --> Database Driver Class Initialized
INFO - 2016-12-03 05:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:55:02 --> Controller Class Initialized
DEBUG - 2016-12-03 05:55:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:55:02 --> Helper loaded: url_helper
ERROR - 2016-12-03 05:55:02 --> Severity: Notice --> Undefined variable: canitdad /home/graduafe/public_html/application/models/Persona_productos_modelo.php 33
ERROR - 2016-12-03 05:55:02 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `tbl_persona_productos` (`id_persona`, `id_producto`, `id_graduacion`, `cantidad`) VALUES ('5', '24', '26', NULL)
INFO - 2016-12-03 05:55:02 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-12-03 05:55:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_carrito_compras_controller.php:32) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2016-12-03 05:55:10 --> Config Class Initialized
INFO - 2016-12-03 05:55:10 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:55:10 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:55:10 --> Utf8 Class Initialized
INFO - 2016-12-03 05:55:10 --> URI Class Initialized
INFO - 2016-12-03 05:55:10 --> Router Class Initialized
INFO - 2016-12-03 05:55:10 --> Output Class Initialized
INFO - 2016-12-03 05:55:10 --> Security Class Initialized
DEBUG - 2016-12-03 05:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:55:10 --> Input Class Initialized
INFO - 2016-12-03 05:55:10 --> Language Class Initialized
INFO - 2016-12-03 05:55:10 --> Loader Class Initialized
INFO - 2016-12-03 05:55:10 --> Database Driver Class Initialized
INFO - 2016-12-03 05:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:55:10 --> Controller Class Initialized
DEBUG - 2016-12-03 05:55:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:55:10 --> Helper loaded: url_helper
INFO - 2016-12-03 05:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 05:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 05:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 05:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 05:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:55:10 --> Final output sent to browser
DEBUG - 2016-12-03 05:55:10 --> Total execution time: 0.0388
INFO - 2016-12-03 05:55:12 --> Config Class Initialized
INFO - 2016-12-03 05:55:12 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:55:12 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:55:12 --> Utf8 Class Initialized
INFO - 2016-12-03 05:55:12 --> URI Class Initialized
INFO - 2016-12-03 05:55:12 --> Router Class Initialized
INFO - 2016-12-03 05:55:12 --> Output Class Initialized
INFO - 2016-12-03 05:55:12 --> Security Class Initialized
DEBUG - 2016-12-03 05:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:55:12 --> Input Class Initialized
INFO - 2016-12-03 05:55:12 --> Language Class Initialized
ERROR - 2016-12-03 05:55:12 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 05:55:12 --> Config Class Initialized
INFO - 2016-12-03 05:55:12 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:55:12 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:55:12 --> Utf8 Class Initialized
INFO - 2016-12-03 05:55:12 --> URI Class Initialized
INFO - 2016-12-03 05:55:12 --> Router Class Initialized
INFO - 2016-12-03 05:55:12 --> Output Class Initialized
INFO - 2016-12-03 05:55:12 --> Security Class Initialized
DEBUG - 2016-12-03 05:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:55:12 --> Input Class Initialized
INFO - 2016-12-03 05:55:12 --> Language Class Initialized
INFO - 2016-12-03 05:55:12 --> Loader Class Initialized
INFO - 2016-12-03 05:55:12 --> Database Driver Class Initialized
INFO - 2016-12-03 05:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:55:12 --> Controller Class Initialized
INFO - 2016-12-03 05:55:12 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:55:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:55:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:55:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:55:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:55:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:55:12 --> Final output sent to browser
DEBUG - 2016-12-03 05:55:12 --> Total execution time: 0.0262
INFO - 2016-12-03 05:55:12 --> Config Class Initialized
INFO - 2016-12-03 05:55:12 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:55:12 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:55:12 --> Utf8 Class Initialized
INFO - 2016-12-03 05:55:12 --> URI Class Initialized
INFO - 2016-12-03 05:55:12 --> Router Class Initialized
INFO - 2016-12-03 05:55:12 --> Output Class Initialized
INFO - 2016-12-03 05:55:12 --> Security Class Initialized
DEBUG - 2016-12-03 05:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:55:12 --> Input Class Initialized
INFO - 2016-12-03 05:55:12 --> Language Class Initialized
INFO - 2016-12-03 05:55:12 --> Loader Class Initialized
INFO - 2016-12-03 05:55:12 --> Database Driver Class Initialized
INFO - 2016-12-03 05:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:55:12 --> Controller Class Initialized
DEBUG - 2016-12-03 05:55:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:55:12 --> Helper loaded: url_helper
ERROR - 2016-12-03 05:55:12 --> Severity: Notice --> Undefined variable: canitdad /home/graduafe/public_html/application/models/Persona_productos_modelo.php 33
ERROR - 2016-12-03 05:55:12 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `tbl_persona_productos` (`id_persona`, `id_producto`, `id_graduacion`, `cantidad`) VALUES ('5', '24', '26', NULL)
INFO - 2016-12-03 05:55:12 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-12-03 05:55:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_carrito_compras_controller.php:32) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2016-12-03 05:55:54 --> Config Class Initialized
INFO - 2016-12-03 05:55:54 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:55:54 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:55:54 --> Utf8 Class Initialized
INFO - 2016-12-03 05:55:54 --> URI Class Initialized
INFO - 2016-12-03 05:55:54 --> Router Class Initialized
INFO - 2016-12-03 05:55:54 --> Output Class Initialized
INFO - 2016-12-03 05:55:54 --> Security Class Initialized
DEBUG - 2016-12-03 05:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:55:54 --> Input Class Initialized
INFO - 2016-12-03 05:55:54 --> Language Class Initialized
INFO - 2016-12-03 05:55:54 --> Loader Class Initialized
INFO - 2016-12-03 05:55:54 --> Database Driver Class Initialized
INFO - 2016-12-03 05:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:55:54 --> Controller Class Initialized
DEBUG - 2016-12-03 05:55:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:55:54 --> Helper loaded: url_helper
ERROR - 2016-12-03 05:55:54 --> Severity: Notice --> Undefined variable: canitdad /home/graduafe/public_html/application/models/Persona_productos_modelo.php 33
ERROR - 2016-12-03 05:55:54 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `tbl_persona_productos` (`id_persona`, `id_producto`, `id_graduacion`, `cantidad`) VALUES ('5', '24', '26', NULL)
INFO - 2016-12-03 05:55:54 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-12-03 05:55:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_carrito_compras_controller.php:32) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2016-12-03 05:57:26 --> Config Class Initialized
INFO - 2016-12-03 05:57:26 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:57:26 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:57:26 --> Utf8 Class Initialized
INFO - 2016-12-03 05:57:26 --> URI Class Initialized
INFO - 2016-12-03 05:57:26 --> Router Class Initialized
INFO - 2016-12-03 05:57:26 --> Output Class Initialized
INFO - 2016-12-03 05:57:26 --> Security Class Initialized
DEBUG - 2016-12-03 05:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:57:26 --> Input Class Initialized
INFO - 2016-12-03 05:57:26 --> Language Class Initialized
INFO - 2016-12-03 05:57:26 --> Loader Class Initialized
INFO - 2016-12-03 05:57:26 --> Database Driver Class Initialized
INFO - 2016-12-03 05:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:57:26 --> Controller Class Initialized
DEBUG - 2016-12-03 05:57:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:57:26 --> Helper loaded: url_helper
ERROR - 2016-12-03 05:57:26 --> Severity: Notice --> Undefined variable: canitdad /home/graduafe/public_html/application/models/Persona_productos_modelo.php 33
ERROR - 2016-12-03 05:57:26 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `tbl_persona_productos` (`id_persona`, `id_producto`, `id_graduacion`, `cantidad`) VALUES ('5', '24', '26', NULL)
INFO - 2016-12-03 05:57:26 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-12-03 05:57:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_carrito_compras_controller.php:32) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2016-12-03 05:58:12 --> Config Class Initialized
INFO - 2016-12-03 05:58:12 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:58:12 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:58:12 --> Utf8 Class Initialized
INFO - 2016-12-03 05:58:12 --> URI Class Initialized
INFO - 2016-12-03 05:58:12 --> Router Class Initialized
INFO - 2016-12-03 05:58:12 --> Output Class Initialized
INFO - 2016-12-03 05:58:12 --> Security Class Initialized
DEBUG - 2016-12-03 05:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:58:12 --> Input Class Initialized
INFO - 2016-12-03 05:58:12 --> Language Class Initialized
ERROR - 2016-12-03 05:58:12 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/graduafe/public_html/application/controllers/User_carrito_compras_controller.php 32
INFO - 2016-12-03 05:58:12 --> Config Class Initialized
INFO - 2016-12-03 05:58:12 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:58:12 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:58:12 --> Utf8 Class Initialized
INFO - 2016-12-03 05:58:12 --> URI Class Initialized
INFO - 2016-12-03 05:58:12 --> Router Class Initialized
INFO - 2016-12-03 05:58:12 --> Output Class Initialized
INFO - 2016-12-03 05:58:12 --> Security Class Initialized
DEBUG - 2016-12-03 05:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:58:12 --> Input Class Initialized
INFO - 2016-12-03 05:58:12 --> Language Class Initialized
INFO - 2016-12-03 05:58:12 --> Loader Class Initialized
INFO - 2016-12-03 05:58:12 --> Database Driver Class Initialized
INFO - 2016-12-03 05:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:58:12 --> Controller Class Initialized
INFO - 2016-12-03 05:58:12 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:58:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:58:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:58:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:58:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:58:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:58:12 --> Final output sent to browser
DEBUG - 2016-12-03 05:58:12 --> Total execution time: 0.0131
INFO - 2016-12-03 05:58:24 --> Config Class Initialized
INFO - 2016-12-03 05:58:24 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:58:24 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:58:24 --> Utf8 Class Initialized
INFO - 2016-12-03 05:58:24 --> URI Class Initialized
INFO - 2016-12-03 05:58:24 --> Router Class Initialized
INFO - 2016-12-03 05:58:24 --> Output Class Initialized
INFO - 2016-12-03 05:58:24 --> Security Class Initialized
DEBUG - 2016-12-03 05:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:58:24 --> Input Class Initialized
INFO - 2016-12-03 05:58:24 --> Language Class Initialized
INFO - 2016-12-03 05:58:24 --> Loader Class Initialized
INFO - 2016-12-03 05:58:24 --> Database Driver Class Initialized
INFO - 2016-12-03 05:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:58:24 --> Controller Class Initialized
DEBUG - 2016-12-03 05:58:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:58:24 --> Helper loaded: url_helper
INFO - 2016-12-03 05:58:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:58:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 05:58:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 05:58:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 05:58:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 05:58:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:58:24 --> Final output sent to browser
DEBUG - 2016-12-03 05:58:24 --> Total execution time: 0.0146
INFO - 2016-12-03 05:58:24 --> Config Class Initialized
INFO - 2016-12-03 05:58:24 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:58:24 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:58:24 --> Utf8 Class Initialized
INFO - 2016-12-03 05:58:24 --> URI Class Initialized
INFO - 2016-12-03 05:58:24 --> Router Class Initialized
INFO - 2016-12-03 05:58:24 --> Output Class Initialized
INFO - 2016-12-03 05:58:24 --> Security Class Initialized
DEBUG - 2016-12-03 05:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:58:24 --> Input Class Initialized
INFO - 2016-12-03 05:58:24 --> Language Class Initialized
ERROR - 2016-12-03 05:58:24 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 05:58:25 --> Config Class Initialized
INFO - 2016-12-03 05:58:25 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:58:25 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:58:25 --> Utf8 Class Initialized
INFO - 2016-12-03 05:58:25 --> URI Class Initialized
INFO - 2016-12-03 05:58:25 --> Router Class Initialized
INFO - 2016-12-03 05:58:25 --> Output Class Initialized
INFO - 2016-12-03 05:58:25 --> Security Class Initialized
DEBUG - 2016-12-03 05:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:58:25 --> Input Class Initialized
INFO - 2016-12-03 05:58:25 --> Language Class Initialized
INFO - 2016-12-03 05:58:25 --> Loader Class Initialized
INFO - 2016-12-03 05:58:25 --> Database Driver Class Initialized
INFO - 2016-12-03 05:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:58:25 --> Controller Class Initialized
INFO - 2016-12-03 05:58:25 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:58:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:58:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:58:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:58:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:58:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:58:25 --> Final output sent to browser
DEBUG - 2016-12-03 05:58:25 --> Total execution time: 0.0127
INFO - 2016-12-03 05:58:26 --> Config Class Initialized
INFO - 2016-12-03 05:58:26 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:58:26 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:58:26 --> Utf8 Class Initialized
INFO - 2016-12-03 05:58:26 --> URI Class Initialized
INFO - 2016-12-03 05:58:26 --> Router Class Initialized
INFO - 2016-12-03 05:58:26 --> Output Class Initialized
INFO - 2016-12-03 05:58:26 --> Security Class Initialized
DEBUG - 2016-12-03 05:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:58:26 --> Input Class Initialized
INFO - 2016-12-03 05:58:26 --> Language Class Initialized
INFO - 2016-12-03 05:58:26 --> Loader Class Initialized
INFO - 2016-12-03 05:58:26 --> Database Driver Class Initialized
INFO - 2016-12-03 05:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:58:26 --> Controller Class Initialized
DEBUG - 2016-12-03 05:58:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:58:26 --> Helper loaded: url_helper
ERROR - 2016-12-03 05:58:26 --> Severity: Notice --> Undefined variable: canitdad /home/graduafe/public_html/application/models/Persona_productos_modelo.php 33
ERROR - 2016-12-03 05:58:26 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `tbl_persona_productos` (`id_persona`, `id_producto`, `id_graduacion`, `cantidad`) VALUES ('5', '24', '26', NULL)
INFO - 2016-12-03 05:58:26 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-12-03 05:58:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/application/controllers/User_carrito_compras_controller.php:33) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2016-12-03 05:59:18 --> Config Class Initialized
INFO - 2016-12-03 05:59:18 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:59:18 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:59:18 --> Utf8 Class Initialized
INFO - 2016-12-03 05:59:18 --> URI Class Initialized
INFO - 2016-12-03 05:59:18 --> Router Class Initialized
INFO - 2016-12-03 05:59:18 --> Output Class Initialized
INFO - 2016-12-03 05:59:18 --> Security Class Initialized
DEBUG - 2016-12-03 05:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:59:18 --> Input Class Initialized
INFO - 2016-12-03 05:59:18 --> Language Class Initialized
INFO - 2016-12-03 05:59:18 --> Loader Class Initialized
INFO - 2016-12-03 05:59:18 --> Database Driver Class Initialized
INFO - 2016-12-03 05:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:59:18 --> Controller Class Initialized
DEBUG - 2016-12-03 05:59:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:59:18 --> Helper loaded: url_helper
INFO - 2016-12-03 05:59:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:59:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 05:59:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 05:59:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 05:59:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 05:59:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:59:18 --> Final output sent to browser
DEBUG - 2016-12-03 05:59:18 --> Total execution time: 0.0117
INFO - 2016-12-03 05:59:19 --> Config Class Initialized
INFO - 2016-12-03 05:59:19 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:59:19 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:59:19 --> Utf8 Class Initialized
INFO - 2016-12-03 05:59:19 --> URI Class Initialized
INFO - 2016-12-03 05:59:19 --> Router Class Initialized
INFO - 2016-12-03 05:59:19 --> Output Class Initialized
INFO - 2016-12-03 05:59:19 --> Security Class Initialized
DEBUG - 2016-12-03 05:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:59:19 --> Input Class Initialized
INFO - 2016-12-03 05:59:19 --> Language Class Initialized
ERROR - 2016-12-03 05:59:19 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 05:59:19 --> Config Class Initialized
INFO - 2016-12-03 05:59:19 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:59:19 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:59:19 --> Utf8 Class Initialized
INFO - 2016-12-03 05:59:19 --> URI Class Initialized
INFO - 2016-12-03 05:59:19 --> Router Class Initialized
INFO - 2016-12-03 05:59:19 --> Output Class Initialized
INFO - 2016-12-03 05:59:19 --> Security Class Initialized
DEBUG - 2016-12-03 05:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:59:19 --> Input Class Initialized
INFO - 2016-12-03 05:59:19 --> Language Class Initialized
INFO - 2016-12-03 05:59:19 --> Loader Class Initialized
INFO - 2016-12-03 05:59:19 --> Database Driver Class Initialized
INFO - 2016-12-03 05:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:59:19 --> Controller Class Initialized
INFO - 2016-12-03 05:59:19 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:59:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:59:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:59:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:59:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:59:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:59:19 --> Final output sent to browser
DEBUG - 2016-12-03 05:59:19 --> Total execution time: 0.0133
INFO - 2016-12-03 05:59:20 --> Config Class Initialized
INFO - 2016-12-03 05:59:20 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:59:20 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:59:20 --> Utf8 Class Initialized
INFO - 2016-12-03 05:59:20 --> URI Class Initialized
INFO - 2016-12-03 05:59:20 --> Router Class Initialized
INFO - 2016-12-03 05:59:20 --> Output Class Initialized
INFO - 2016-12-03 05:59:20 --> Security Class Initialized
DEBUG - 2016-12-03 05:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:59:20 --> Input Class Initialized
INFO - 2016-12-03 05:59:20 --> Language Class Initialized
INFO - 2016-12-03 05:59:20 --> Loader Class Initialized
INFO - 2016-12-03 05:59:20 --> Database Driver Class Initialized
INFO - 2016-12-03 05:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:59:20 --> Controller Class Initialized
DEBUG - 2016-12-03 05:59:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:59:20 --> Helper loaded: url_helper
ERROR - 2016-12-03 05:59:20 --> Severity: Notice --> Undefined variable: canitdad /home/graduafe/public_html/application/models/Persona_productos_modelo.php 33
ERROR - 2016-12-03 05:59:20 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `tbl_persona_productos` (`id_persona`, `id_producto`, `id_graduacion`, `cantidad`) VALUES ('5', '24', '26', NULL)
INFO - 2016-12-03 05:59:20 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-12-03 05:59:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2016-12-03 05:59:28 --> Config Class Initialized
INFO - 2016-12-03 05:59:28 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:59:28 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:59:28 --> Utf8 Class Initialized
INFO - 2016-12-03 05:59:28 --> URI Class Initialized
INFO - 2016-12-03 05:59:28 --> Router Class Initialized
INFO - 2016-12-03 05:59:28 --> Output Class Initialized
INFO - 2016-12-03 05:59:28 --> Security Class Initialized
DEBUG - 2016-12-03 05:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:59:28 --> Input Class Initialized
INFO - 2016-12-03 05:59:28 --> Language Class Initialized
INFO - 2016-12-03 05:59:28 --> Loader Class Initialized
INFO - 2016-12-03 05:59:28 --> Database Driver Class Initialized
INFO - 2016-12-03 05:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:59:28 --> Controller Class Initialized
DEBUG - 2016-12-03 05:59:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:59:28 --> Helper loaded: url_helper
ERROR - 2016-12-03 05:59:28 --> Severity: Notice --> Undefined variable: canitdad /home/graduafe/public_html/application/models/Persona_productos_modelo.php 33
ERROR - 2016-12-03 05:59:28 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `tbl_persona_productos` (`id_persona`, `id_producto`, `id_graduacion`, `cantidad`) VALUES ('5', '24', '26', NULL)
INFO - 2016-12-03 05:59:28 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-12-03 05:59:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2016-12-03 05:59:49 --> Config Class Initialized
INFO - 2016-12-03 05:59:49 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:59:49 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:59:49 --> Utf8 Class Initialized
INFO - 2016-12-03 05:59:49 --> URI Class Initialized
INFO - 2016-12-03 05:59:49 --> Router Class Initialized
INFO - 2016-12-03 05:59:49 --> Output Class Initialized
INFO - 2016-12-03 05:59:49 --> Security Class Initialized
DEBUG - 2016-12-03 05:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:59:49 --> Input Class Initialized
INFO - 2016-12-03 05:59:49 --> Language Class Initialized
INFO - 2016-12-03 05:59:49 --> Loader Class Initialized
INFO - 2016-12-03 05:59:49 --> Database Driver Class Initialized
INFO - 2016-12-03 05:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:59:49 --> Controller Class Initialized
DEBUG - 2016-12-03 05:59:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:59:49 --> Helper loaded: url_helper
INFO - 2016-12-03 05:59:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:59:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 05:59:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 05:59:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 05:59:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 05:59:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:59:49 --> Final output sent to browser
DEBUG - 2016-12-03 05:59:49 --> Total execution time: 0.0136
INFO - 2016-12-03 05:59:49 --> Config Class Initialized
INFO - 2016-12-03 05:59:49 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:59:49 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:59:49 --> Utf8 Class Initialized
INFO - 2016-12-03 05:59:49 --> URI Class Initialized
INFO - 2016-12-03 05:59:49 --> Router Class Initialized
INFO - 2016-12-03 05:59:49 --> Output Class Initialized
INFO - 2016-12-03 05:59:49 --> Security Class Initialized
DEBUG - 2016-12-03 05:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:59:49 --> Input Class Initialized
INFO - 2016-12-03 05:59:49 --> Language Class Initialized
ERROR - 2016-12-03 05:59:49 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 05:59:49 --> Config Class Initialized
INFO - 2016-12-03 05:59:49 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:59:49 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:59:49 --> Utf8 Class Initialized
INFO - 2016-12-03 05:59:49 --> URI Class Initialized
INFO - 2016-12-03 05:59:49 --> Router Class Initialized
INFO - 2016-12-03 05:59:49 --> Output Class Initialized
INFO - 2016-12-03 05:59:49 --> Security Class Initialized
DEBUG - 2016-12-03 05:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:59:49 --> Input Class Initialized
INFO - 2016-12-03 05:59:49 --> Language Class Initialized
INFO - 2016-12-03 05:59:49 --> Loader Class Initialized
INFO - 2016-12-03 05:59:49 --> Database Driver Class Initialized
INFO - 2016-12-03 05:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:59:49 --> Controller Class Initialized
INFO - 2016-12-03 05:59:49 --> Helper loaded: url_helper
DEBUG - 2016-12-03 05:59:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:59:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 05:59:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 05:59:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 05:59:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 05:59:49 --> Final output sent to browser
DEBUG - 2016-12-03 05:59:49 --> Total execution time: 0.0689
INFO - 2016-12-03 05:59:50 --> Config Class Initialized
INFO - 2016-12-03 05:59:50 --> Hooks Class Initialized
DEBUG - 2016-12-03 05:59:50 --> UTF-8 Support Enabled
INFO - 2016-12-03 05:59:50 --> Utf8 Class Initialized
INFO - 2016-12-03 05:59:50 --> URI Class Initialized
INFO - 2016-12-03 05:59:50 --> Router Class Initialized
INFO - 2016-12-03 05:59:50 --> Output Class Initialized
INFO - 2016-12-03 05:59:50 --> Security Class Initialized
DEBUG - 2016-12-03 05:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 05:59:50 --> Input Class Initialized
INFO - 2016-12-03 05:59:50 --> Language Class Initialized
INFO - 2016-12-03 05:59:50 --> Loader Class Initialized
INFO - 2016-12-03 05:59:50 --> Database Driver Class Initialized
INFO - 2016-12-03 05:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 05:59:50 --> Controller Class Initialized
DEBUG - 2016-12-03 05:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 05:59:50 --> Helper loaded: url_helper
INFO - 2016-12-03 05:59:50 --> Final output sent to browser
DEBUG - 2016-12-03 05:59:50 --> Total execution time: 0.0275
INFO - 2016-12-03 06:00:25 --> Config Class Initialized
INFO - 2016-12-03 06:00:25 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:00:25 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:00:25 --> Utf8 Class Initialized
INFO - 2016-12-03 06:00:25 --> URI Class Initialized
INFO - 2016-12-03 06:00:25 --> Router Class Initialized
INFO - 2016-12-03 06:00:25 --> Output Class Initialized
INFO - 2016-12-03 06:00:25 --> Security Class Initialized
DEBUG - 2016-12-03 06:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:00:25 --> Input Class Initialized
INFO - 2016-12-03 06:00:25 --> Language Class Initialized
INFO - 2016-12-03 06:00:25 --> Loader Class Initialized
INFO - 2016-12-03 06:00:25 --> Database Driver Class Initialized
INFO - 2016-12-03 06:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:00:25 --> Controller Class Initialized
INFO - 2016-12-03 06:00:25 --> Helper loaded: date_helper
INFO - 2016-12-03 06:00:25 --> Helper loaded: url_helper
DEBUG - 2016-12-03 06:00:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:00:25 --> Helper loaded: form_helper
INFO - 2016-12-03 06:00:25 --> Form Validation Class Initialized
INFO - 2016-12-03 06:00:25 --> Config Class Initialized
INFO - 2016-12-03 06:00:25 --> Hooks Class Initialized
INFO - 2016-12-03 06:00:25 --> Final output sent to browser
DEBUG - 2016-12-03 06:00:25 --> Total execution time: 0.0624
DEBUG - 2016-12-03 06:00:25 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:00:25 --> Utf8 Class Initialized
INFO - 2016-12-03 06:00:25 --> URI Class Initialized
INFO - 2016-12-03 06:00:25 --> Router Class Initialized
INFO - 2016-12-03 06:00:25 --> Output Class Initialized
INFO - 2016-12-03 06:00:25 --> Security Class Initialized
DEBUG - 2016-12-03 06:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:00:25 --> Input Class Initialized
INFO - 2016-12-03 06:00:25 --> Language Class Initialized
INFO - 2016-12-03 06:00:25 --> Loader Class Initialized
INFO - 2016-12-03 06:00:25 --> Database Driver Class Initialized
INFO - 2016-12-03 06:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:00:25 --> Controller Class Initialized
INFO - 2016-12-03 06:00:25 --> Helper loaded: date_helper
INFO - 2016-12-03 06:00:25 --> Helper loaded: url_helper
DEBUG - 2016-12-03 06:00:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:00:25 --> Helper loaded: form_helper
INFO - 2016-12-03 06:00:25 --> Form Validation Class Initialized
INFO - 2016-12-03 06:00:25 --> Final output sent to browser
DEBUG - 2016-12-03 06:00:25 --> Total execution time: 0.0892
INFO - 2016-12-03 06:11:14 --> Config Class Initialized
INFO - 2016-12-03 06:11:14 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:11:14 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:11:14 --> Utf8 Class Initialized
INFO - 2016-12-03 06:11:14 --> URI Class Initialized
INFO - 2016-12-03 06:11:14 --> Router Class Initialized
INFO - 2016-12-03 06:11:14 --> Output Class Initialized
INFO - 2016-12-03 06:11:14 --> Security Class Initialized
DEBUG - 2016-12-03 06:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:11:14 --> Input Class Initialized
INFO - 2016-12-03 06:11:14 --> Language Class Initialized
INFO - 2016-12-03 06:11:14 --> Loader Class Initialized
INFO - 2016-12-03 06:11:14 --> Database Driver Class Initialized
INFO - 2016-12-03 06:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:11:14 --> Controller Class Initialized
DEBUG - 2016-12-03 06:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:11:14 --> Helper loaded: url_helper
INFO - 2016-12-03 06:11:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:11:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 06:11:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 06:11:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 06:11:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 06:11:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:11:14 --> Final output sent to browser
DEBUG - 2016-12-03 06:11:14 --> Total execution time: 0.0373
INFO - 2016-12-03 06:11:15 --> Config Class Initialized
INFO - 2016-12-03 06:11:15 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:11:15 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:11:15 --> Utf8 Class Initialized
INFO - 2016-12-03 06:11:15 --> URI Class Initialized
INFO - 2016-12-03 06:11:15 --> Router Class Initialized
INFO - 2016-12-03 06:11:15 --> Output Class Initialized
INFO - 2016-12-03 06:11:15 --> Security Class Initialized
DEBUG - 2016-12-03 06:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:11:15 --> Input Class Initialized
INFO - 2016-12-03 06:11:15 --> Language Class Initialized
ERROR - 2016-12-03 06:11:15 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 06:11:15 --> Config Class Initialized
INFO - 2016-12-03 06:11:15 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:11:15 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:11:15 --> Utf8 Class Initialized
INFO - 2016-12-03 06:11:15 --> URI Class Initialized
INFO - 2016-12-03 06:11:15 --> Router Class Initialized
INFO - 2016-12-03 06:11:15 --> Output Class Initialized
INFO - 2016-12-03 06:11:15 --> Security Class Initialized
DEBUG - 2016-12-03 06:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:11:15 --> Input Class Initialized
INFO - 2016-12-03 06:11:15 --> Language Class Initialized
INFO - 2016-12-03 06:11:15 --> Loader Class Initialized
INFO - 2016-12-03 06:11:15 --> Database Driver Class Initialized
INFO - 2016-12-03 06:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:11:15 --> Controller Class Initialized
INFO - 2016-12-03 06:11:15 --> Helper loaded: url_helper
DEBUG - 2016-12-03 06:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:11:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:11:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 06:11:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 06:11:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:11:15 --> Final output sent to browser
DEBUG - 2016-12-03 06:11:15 --> Total execution time: 0.0219
INFO - 2016-12-03 06:11:16 --> Config Class Initialized
INFO - 2016-12-03 06:11:16 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:11:16 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:11:16 --> Utf8 Class Initialized
INFO - 2016-12-03 06:11:16 --> URI Class Initialized
INFO - 2016-12-03 06:11:16 --> Router Class Initialized
INFO - 2016-12-03 06:11:16 --> Output Class Initialized
INFO - 2016-12-03 06:11:16 --> Security Class Initialized
DEBUG - 2016-12-03 06:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:11:16 --> Input Class Initialized
INFO - 2016-12-03 06:11:16 --> Language Class Initialized
INFO - 2016-12-03 06:11:16 --> Loader Class Initialized
INFO - 2016-12-03 06:11:16 --> Database Driver Class Initialized
INFO - 2016-12-03 06:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:11:16 --> Controller Class Initialized
DEBUG - 2016-12-03 06:11:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:11:16 --> Helper loaded: url_helper
INFO - 2016-12-03 06:11:16 --> Final output sent to browser
DEBUG - 2016-12-03 06:11:16 --> Total execution time: 0.0281
INFO - 2016-12-03 06:11:17 --> Config Class Initialized
INFO - 2016-12-03 06:11:17 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:11:17 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:11:17 --> Utf8 Class Initialized
INFO - 2016-12-03 06:11:17 --> URI Class Initialized
INFO - 2016-12-03 06:11:17 --> Router Class Initialized
INFO - 2016-12-03 06:11:17 --> Output Class Initialized
INFO - 2016-12-03 06:11:17 --> Security Class Initialized
DEBUG - 2016-12-03 06:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:11:17 --> Input Class Initialized
INFO - 2016-12-03 06:11:17 --> Language Class Initialized
INFO - 2016-12-03 06:11:17 --> Loader Class Initialized
INFO - 2016-12-03 06:11:17 --> Database Driver Class Initialized
INFO - 2016-12-03 06:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:11:17 --> Controller Class Initialized
DEBUG - 2016-12-03 06:11:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:11:17 --> Helper loaded: url_helper
INFO - 2016-12-03 06:11:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:11:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 06:11:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 06:11:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 06:11:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 06:11:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:11:17 --> Final output sent to browser
DEBUG - 2016-12-03 06:11:17 --> Total execution time: 0.0126
INFO - 2016-12-03 06:11:19 --> Config Class Initialized
INFO - 2016-12-03 06:11:19 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:11:19 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:11:19 --> Utf8 Class Initialized
INFO - 2016-12-03 06:11:19 --> URI Class Initialized
INFO - 2016-12-03 06:11:19 --> Router Class Initialized
INFO - 2016-12-03 06:11:19 --> Output Class Initialized
INFO - 2016-12-03 06:11:19 --> Security Class Initialized
DEBUG - 2016-12-03 06:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:11:19 --> Input Class Initialized
INFO - 2016-12-03 06:11:19 --> Language Class Initialized
ERROR - 2016-12-03 06:11:19 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 06:11:19 --> Config Class Initialized
INFO - 2016-12-03 06:11:19 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:11:19 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:11:19 --> Utf8 Class Initialized
INFO - 2016-12-03 06:11:19 --> URI Class Initialized
INFO - 2016-12-03 06:11:19 --> Router Class Initialized
INFO - 2016-12-03 06:11:19 --> Output Class Initialized
INFO - 2016-12-03 06:11:19 --> Security Class Initialized
DEBUG - 2016-12-03 06:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:11:19 --> Input Class Initialized
INFO - 2016-12-03 06:11:19 --> Language Class Initialized
INFO - 2016-12-03 06:11:19 --> Loader Class Initialized
INFO - 2016-12-03 06:11:19 --> Database Driver Class Initialized
INFO - 2016-12-03 06:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:11:19 --> Controller Class Initialized
INFO - 2016-12-03 06:11:19 --> Helper loaded: url_helper
DEBUG - 2016-12-03 06:11:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:11:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:11:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 06:11:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 06:11:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:11:19 --> Final output sent to browser
DEBUG - 2016-12-03 06:11:19 --> Total execution time: 0.0129
INFO - 2016-12-03 06:15:59 --> Config Class Initialized
INFO - 2016-12-03 06:15:59 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:15:59 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:15:59 --> Utf8 Class Initialized
INFO - 2016-12-03 06:15:59 --> URI Class Initialized
INFO - 2016-12-03 06:15:59 --> Router Class Initialized
INFO - 2016-12-03 06:15:59 --> Output Class Initialized
INFO - 2016-12-03 06:15:59 --> Security Class Initialized
DEBUG - 2016-12-03 06:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:15:59 --> Input Class Initialized
INFO - 2016-12-03 06:15:59 --> Language Class Initialized
INFO - 2016-12-03 06:15:59 --> Loader Class Initialized
INFO - 2016-12-03 06:15:59 --> Database Driver Class Initialized
INFO - 2016-12-03 06:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:15:59 --> Controller Class Initialized
DEBUG - 2016-12-03 06:15:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:15:59 --> Helper loaded: url_helper
INFO - 2016-12-03 06:15:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:15:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 06:15:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 06:15:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 06:15:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 06:15:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:15:59 --> Final output sent to browser
DEBUG - 2016-12-03 06:15:59 --> Total execution time: 0.0123
INFO - 2016-12-03 06:15:59 --> Config Class Initialized
INFO - 2016-12-03 06:15:59 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:15:59 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:15:59 --> Utf8 Class Initialized
INFO - 2016-12-03 06:15:59 --> URI Class Initialized
INFO - 2016-12-03 06:15:59 --> Router Class Initialized
INFO - 2016-12-03 06:15:59 --> Output Class Initialized
INFO - 2016-12-03 06:15:59 --> Security Class Initialized
DEBUG - 2016-12-03 06:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:15:59 --> Input Class Initialized
INFO - 2016-12-03 06:15:59 --> Language Class Initialized
ERROR - 2016-12-03 06:15:59 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 06:15:59 --> Config Class Initialized
INFO - 2016-12-03 06:15:59 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:15:59 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:15:59 --> Utf8 Class Initialized
INFO - 2016-12-03 06:15:59 --> URI Class Initialized
INFO - 2016-12-03 06:15:59 --> Router Class Initialized
INFO - 2016-12-03 06:15:59 --> Output Class Initialized
INFO - 2016-12-03 06:15:59 --> Security Class Initialized
DEBUG - 2016-12-03 06:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:15:59 --> Input Class Initialized
INFO - 2016-12-03 06:15:59 --> Language Class Initialized
INFO - 2016-12-03 06:15:59 --> Loader Class Initialized
INFO - 2016-12-03 06:15:59 --> Database Driver Class Initialized
INFO - 2016-12-03 06:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:15:59 --> Controller Class Initialized
INFO - 2016-12-03 06:15:59 --> Helper loaded: url_helper
DEBUG - 2016-12-03 06:15:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:15:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:15:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 06:15:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 06:15:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:15:59 --> Final output sent to browser
DEBUG - 2016-12-03 06:15:59 --> Total execution time: 0.0137
INFO - 2016-12-03 06:16:00 --> Config Class Initialized
INFO - 2016-12-03 06:16:00 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:16:00 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:16:00 --> Utf8 Class Initialized
INFO - 2016-12-03 06:16:00 --> URI Class Initialized
INFO - 2016-12-03 06:16:00 --> Router Class Initialized
INFO - 2016-12-03 06:16:00 --> Output Class Initialized
INFO - 2016-12-03 06:16:00 --> Security Class Initialized
DEBUG - 2016-12-03 06:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:16:00 --> Input Class Initialized
INFO - 2016-12-03 06:16:00 --> Language Class Initialized
INFO - 2016-12-03 06:16:00 --> Loader Class Initialized
INFO - 2016-12-03 06:16:00 --> Database Driver Class Initialized
INFO - 2016-12-03 06:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:16:00 --> Controller Class Initialized
DEBUG - 2016-12-03 06:16:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:16:00 --> Helper loaded: url_helper
INFO - 2016-12-03 06:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 06:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-03 06:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-03 06:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:16:00 --> Final output sent to browser
DEBUG - 2016-12-03 06:16:00 --> Total execution time: 0.0132
INFO - 2016-12-03 06:16:00 --> Config Class Initialized
INFO - 2016-12-03 06:16:00 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:16:00 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:16:00 --> Utf8 Class Initialized
INFO - 2016-12-03 06:16:00 --> URI Class Initialized
INFO - 2016-12-03 06:16:00 --> Router Class Initialized
INFO - 2016-12-03 06:16:00 --> Output Class Initialized
INFO - 2016-12-03 06:16:00 --> Security Class Initialized
DEBUG - 2016-12-03 06:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:16:00 --> Input Class Initialized
INFO - 2016-12-03 06:16:00 --> Language Class Initialized
ERROR - 2016-12-03 06:16:00 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 06:16:00 --> Config Class Initialized
INFO - 2016-12-03 06:16:00 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:16:00 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:16:00 --> Utf8 Class Initialized
INFO - 2016-12-03 06:16:00 --> URI Class Initialized
INFO - 2016-12-03 06:16:00 --> Router Class Initialized
INFO - 2016-12-03 06:16:00 --> Output Class Initialized
INFO - 2016-12-03 06:16:00 --> Security Class Initialized
DEBUG - 2016-12-03 06:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:16:00 --> Input Class Initialized
INFO - 2016-12-03 06:16:00 --> Language Class Initialized
INFO - 2016-12-03 06:16:00 --> Loader Class Initialized
INFO - 2016-12-03 06:16:00 --> Database Driver Class Initialized
INFO - 2016-12-03 06:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:16:00 --> Controller Class Initialized
INFO - 2016-12-03 06:16:00 --> Helper loaded: url_helper
DEBUG - 2016-12-03 06:16:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 06:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 06:16:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:16:00 --> Final output sent to browser
DEBUG - 2016-12-03 06:16:00 --> Total execution time: 0.0144
INFO - 2016-12-03 06:16:02 --> Config Class Initialized
INFO - 2016-12-03 06:16:02 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:16:02 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:16:02 --> Utf8 Class Initialized
INFO - 2016-12-03 06:16:02 --> URI Class Initialized
INFO - 2016-12-03 06:16:02 --> Router Class Initialized
INFO - 2016-12-03 06:16:02 --> Output Class Initialized
INFO - 2016-12-03 06:16:02 --> Security Class Initialized
DEBUG - 2016-12-03 06:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:16:02 --> Input Class Initialized
INFO - 2016-12-03 06:16:02 --> Language Class Initialized
INFO - 2016-12-03 06:16:02 --> Loader Class Initialized
INFO - 2016-12-03 06:16:02 --> Database Driver Class Initialized
INFO - 2016-12-03 06:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:16:02 --> Controller Class Initialized
DEBUG - 2016-12-03 06:16:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:16:02 --> Helper loaded: url_helper
INFO - 2016-12-03 06:16:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:16:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 06:16:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 06:16:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 06:16:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 06:16:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:16:02 --> Final output sent to browser
DEBUG - 2016-12-03 06:16:02 --> Total execution time: 0.0121
INFO - 2016-12-03 06:16:02 --> Config Class Initialized
INFO - 2016-12-03 06:16:02 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:16:02 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:16:02 --> Utf8 Class Initialized
INFO - 2016-12-03 06:16:02 --> URI Class Initialized
INFO - 2016-12-03 06:16:02 --> Router Class Initialized
INFO - 2016-12-03 06:16:02 --> Output Class Initialized
INFO - 2016-12-03 06:16:02 --> Security Class Initialized
DEBUG - 2016-12-03 06:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:16:02 --> Input Class Initialized
INFO - 2016-12-03 06:16:02 --> Language Class Initialized
ERROR - 2016-12-03 06:16:02 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 06:16:02 --> Config Class Initialized
INFO - 2016-12-03 06:16:02 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:16:02 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:16:02 --> Utf8 Class Initialized
INFO - 2016-12-03 06:16:02 --> URI Class Initialized
INFO - 2016-12-03 06:16:02 --> Router Class Initialized
INFO - 2016-12-03 06:16:02 --> Output Class Initialized
INFO - 2016-12-03 06:16:02 --> Security Class Initialized
DEBUG - 2016-12-03 06:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:16:02 --> Input Class Initialized
INFO - 2016-12-03 06:16:02 --> Language Class Initialized
INFO - 2016-12-03 06:16:02 --> Loader Class Initialized
INFO - 2016-12-03 06:16:02 --> Database Driver Class Initialized
INFO - 2016-12-03 06:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:16:02 --> Controller Class Initialized
INFO - 2016-12-03 06:16:02 --> Helper loaded: url_helper
DEBUG - 2016-12-03 06:16:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:16:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:16:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 06:16:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 06:16:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:16:02 --> Final output sent to browser
DEBUG - 2016-12-03 06:16:02 --> Total execution time: 0.0135
INFO - 2016-12-03 06:16:16 --> Config Class Initialized
INFO - 2016-12-03 06:16:16 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:16:16 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:16:16 --> Utf8 Class Initialized
INFO - 2016-12-03 06:16:16 --> URI Class Initialized
INFO - 2016-12-03 06:16:16 --> Router Class Initialized
INFO - 2016-12-03 06:16:16 --> Output Class Initialized
INFO - 2016-12-03 06:16:16 --> Security Class Initialized
DEBUG - 2016-12-03 06:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:16:16 --> Input Class Initialized
INFO - 2016-12-03 06:16:16 --> Language Class Initialized
INFO - 2016-12-03 06:16:16 --> Loader Class Initialized
INFO - 2016-12-03 06:16:16 --> Database Driver Class Initialized
INFO - 2016-12-03 06:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:16:16 --> Controller Class Initialized
DEBUG - 2016-12-03 06:16:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:16:16 --> Helper loaded: url_helper
INFO - 2016-12-03 06:16:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:16:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 06:16:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 06:16:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 06:16:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 06:16:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:16:16 --> Final output sent to browser
DEBUG - 2016-12-03 06:16:16 --> Total execution time: 0.0125
INFO - 2016-12-03 06:16:16 --> Config Class Initialized
INFO - 2016-12-03 06:16:16 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:16:16 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:16:16 --> Utf8 Class Initialized
INFO - 2016-12-03 06:16:16 --> URI Class Initialized
INFO - 2016-12-03 06:16:16 --> Router Class Initialized
INFO - 2016-12-03 06:16:16 --> Output Class Initialized
INFO - 2016-12-03 06:16:16 --> Security Class Initialized
DEBUG - 2016-12-03 06:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:16:16 --> Input Class Initialized
INFO - 2016-12-03 06:16:16 --> Language Class Initialized
ERROR - 2016-12-03 06:16:16 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 06:16:16 --> Config Class Initialized
INFO - 2016-12-03 06:16:16 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:16:16 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:16:16 --> Utf8 Class Initialized
INFO - 2016-12-03 06:16:16 --> URI Class Initialized
INFO - 2016-12-03 06:16:16 --> Router Class Initialized
INFO - 2016-12-03 06:16:16 --> Output Class Initialized
INFO - 2016-12-03 06:16:16 --> Security Class Initialized
DEBUG - 2016-12-03 06:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:16:16 --> Input Class Initialized
INFO - 2016-12-03 06:16:16 --> Language Class Initialized
INFO - 2016-12-03 06:16:16 --> Loader Class Initialized
INFO - 2016-12-03 06:16:16 --> Database Driver Class Initialized
INFO - 2016-12-03 06:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:16:16 --> Controller Class Initialized
INFO - 2016-12-03 06:16:16 --> Helper loaded: url_helper
DEBUG - 2016-12-03 06:16:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:16:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:16:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 06:16:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 06:16:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:16:16 --> Final output sent to browser
DEBUG - 2016-12-03 06:16:16 --> Total execution time: 0.0143
INFO - 2016-12-03 06:16:18 --> Config Class Initialized
INFO - 2016-12-03 06:16:18 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:16:18 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:16:18 --> Utf8 Class Initialized
INFO - 2016-12-03 06:16:18 --> URI Class Initialized
INFO - 2016-12-03 06:16:18 --> Router Class Initialized
INFO - 2016-12-03 06:16:18 --> Output Class Initialized
INFO - 2016-12-03 06:16:18 --> Security Class Initialized
DEBUG - 2016-12-03 06:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:16:18 --> Input Class Initialized
INFO - 2016-12-03 06:16:18 --> Language Class Initialized
INFO - 2016-12-03 06:16:18 --> Loader Class Initialized
INFO - 2016-12-03 06:16:18 --> Database Driver Class Initialized
INFO - 2016-12-03 06:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:16:18 --> Controller Class Initialized
DEBUG - 2016-12-03 06:16:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:16:18 --> Helper loaded: url_helper
INFO - 2016-12-03 06:16:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:16:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 06:16:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-03 06:16:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-03 06:16:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:16:18 --> Final output sent to browser
DEBUG - 2016-12-03 06:16:18 --> Total execution time: 0.0138
INFO - 2016-12-03 06:16:18 --> Config Class Initialized
INFO - 2016-12-03 06:16:18 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:16:18 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:16:18 --> Utf8 Class Initialized
INFO - 2016-12-03 06:16:18 --> URI Class Initialized
INFO - 2016-12-03 06:16:18 --> Router Class Initialized
INFO - 2016-12-03 06:16:18 --> Output Class Initialized
INFO - 2016-12-03 06:16:18 --> Security Class Initialized
DEBUG - 2016-12-03 06:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:16:18 --> Input Class Initialized
INFO - 2016-12-03 06:16:18 --> Language Class Initialized
ERROR - 2016-12-03 06:16:18 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 06:16:19 --> Config Class Initialized
INFO - 2016-12-03 06:16:19 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:16:19 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:16:19 --> Utf8 Class Initialized
INFO - 2016-12-03 06:16:19 --> URI Class Initialized
INFO - 2016-12-03 06:16:19 --> Router Class Initialized
INFO - 2016-12-03 06:16:19 --> Output Class Initialized
INFO - 2016-12-03 06:16:19 --> Security Class Initialized
DEBUG - 2016-12-03 06:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:16:19 --> Input Class Initialized
INFO - 2016-12-03 06:16:19 --> Language Class Initialized
INFO - 2016-12-03 06:16:19 --> Loader Class Initialized
INFO - 2016-12-03 06:16:19 --> Database Driver Class Initialized
INFO - 2016-12-03 06:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:16:19 --> Controller Class Initialized
INFO - 2016-12-03 06:16:19 --> Helper loaded: url_helper
DEBUG - 2016-12-03 06:16:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:16:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:16:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 06:16:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 06:16:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:16:19 --> Final output sent to browser
DEBUG - 2016-12-03 06:16:19 --> Total execution time: 0.0138
INFO - 2016-12-03 06:16:20 --> Config Class Initialized
INFO - 2016-12-03 06:16:20 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:16:20 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:16:20 --> Utf8 Class Initialized
INFO - 2016-12-03 06:16:20 --> URI Class Initialized
INFO - 2016-12-03 06:16:20 --> Router Class Initialized
INFO - 2016-12-03 06:16:20 --> Output Class Initialized
INFO - 2016-12-03 06:16:20 --> Security Class Initialized
DEBUG - 2016-12-03 06:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:16:20 --> Input Class Initialized
INFO - 2016-12-03 06:16:20 --> Language Class Initialized
INFO - 2016-12-03 06:16:20 --> Loader Class Initialized
INFO - 2016-12-03 06:16:20 --> Database Driver Class Initialized
INFO - 2016-12-03 06:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:16:20 --> Controller Class Initialized
DEBUG - 2016-12-03 06:16:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:16:20 --> Helper loaded: url_helper
INFO - 2016-12-03 06:16:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:16:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 06:16:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 06:16:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 06:16:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 06:16:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:16:20 --> Final output sent to browser
DEBUG - 2016-12-03 06:16:20 --> Total execution time: 0.0118
INFO - 2016-12-03 06:16:20 --> Config Class Initialized
INFO - 2016-12-03 06:16:20 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:16:20 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:16:20 --> Utf8 Class Initialized
INFO - 2016-12-03 06:16:20 --> URI Class Initialized
INFO - 2016-12-03 06:16:20 --> Router Class Initialized
INFO - 2016-12-03 06:16:20 --> Output Class Initialized
INFO - 2016-12-03 06:16:20 --> Security Class Initialized
DEBUG - 2016-12-03 06:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:16:20 --> Input Class Initialized
INFO - 2016-12-03 06:16:20 --> Language Class Initialized
ERROR - 2016-12-03 06:16:20 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 06:16:21 --> Config Class Initialized
INFO - 2016-12-03 06:16:21 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:16:21 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:16:21 --> Utf8 Class Initialized
INFO - 2016-12-03 06:16:21 --> URI Class Initialized
INFO - 2016-12-03 06:16:21 --> Router Class Initialized
INFO - 2016-12-03 06:16:21 --> Output Class Initialized
INFO - 2016-12-03 06:16:21 --> Security Class Initialized
DEBUG - 2016-12-03 06:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:16:21 --> Input Class Initialized
INFO - 2016-12-03 06:16:21 --> Language Class Initialized
INFO - 2016-12-03 06:16:21 --> Loader Class Initialized
INFO - 2016-12-03 06:16:21 --> Database Driver Class Initialized
INFO - 2016-12-03 06:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:16:21 --> Controller Class Initialized
INFO - 2016-12-03 06:16:21 --> Helper loaded: url_helper
DEBUG - 2016-12-03 06:16:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:16:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:16:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 06:16:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 06:16:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:16:21 --> Final output sent to browser
DEBUG - 2016-12-03 06:16:21 --> Total execution time: 0.0137
INFO - 2016-12-03 06:16:23 --> Config Class Initialized
INFO - 2016-12-03 06:16:23 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:16:23 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:16:23 --> Utf8 Class Initialized
INFO - 2016-12-03 06:16:23 --> URI Class Initialized
INFO - 2016-12-03 06:16:23 --> Router Class Initialized
INFO - 2016-12-03 06:16:23 --> Output Class Initialized
INFO - 2016-12-03 06:16:23 --> Security Class Initialized
DEBUG - 2016-12-03 06:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:16:23 --> Input Class Initialized
INFO - 2016-12-03 06:16:23 --> Language Class Initialized
INFO - 2016-12-03 06:16:23 --> Loader Class Initialized
INFO - 2016-12-03 06:16:23 --> Database Driver Class Initialized
INFO - 2016-12-03 06:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:16:23 --> Controller Class Initialized
DEBUG - 2016-12-03 06:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:16:23 --> Helper loaded: url_helper
INFO - 2016-12-03 06:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 06:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-03 06:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-03 06:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:16:23 --> Final output sent to browser
DEBUG - 2016-12-03 06:16:23 --> Total execution time: 0.0137
INFO - 2016-12-03 06:16:23 --> Config Class Initialized
INFO - 2016-12-03 06:16:23 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:16:23 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:16:23 --> Utf8 Class Initialized
INFO - 2016-12-03 06:16:23 --> URI Class Initialized
INFO - 2016-12-03 06:16:23 --> Router Class Initialized
INFO - 2016-12-03 06:16:23 --> Output Class Initialized
INFO - 2016-12-03 06:16:23 --> Security Class Initialized
DEBUG - 2016-12-03 06:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:16:23 --> Input Class Initialized
INFO - 2016-12-03 06:16:23 --> Language Class Initialized
ERROR - 2016-12-03 06:16:23 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 06:16:24 --> Config Class Initialized
INFO - 2016-12-03 06:16:24 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:16:24 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:16:24 --> Utf8 Class Initialized
INFO - 2016-12-03 06:16:24 --> URI Class Initialized
INFO - 2016-12-03 06:16:24 --> Router Class Initialized
INFO - 2016-12-03 06:16:24 --> Output Class Initialized
INFO - 2016-12-03 06:16:24 --> Security Class Initialized
DEBUG - 2016-12-03 06:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:16:24 --> Input Class Initialized
INFO - 2016-12-03 06:16:24 --> Language Class Initialized
INFO - 2016-12-03 06:16:24 --> Loader Class Initialized
INFO - 2016-12-03 06:16:24 --> Database Driver Class Initialized
INFO - 2016-12-03 06:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:16:24 --> Controller Class Initialized
INFO - 2016-12-03 06:16:24 --> Helper loaded: url_helper
DEBUG - 2016-12-03 06:16:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 06:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 06:16:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:16:24 --> Final output sent to browser
DEBUG - 2016-12-03 06:16:24 --> Total execution time: 0.0129
INFO - 2016-12-03 06:16:30 --> Config Class Initialized
INFO - 2016-12-03 06:16:30 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:16:30 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:16:30 --> Utf8 Class Initialized
INFO - 2016-12-03 06:16:30 --> URI Class Initialized
INFO - 2016-12-03 06:16:30 --> Router Class Initialized
INFO - 2016-12-03 06:16:30 --> Output Class Initialized
INFO - 2016-12-03 06:16:30 --> Security Class Initialized
DEBUG - 2016-12-03 06:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:16:30 --> Input Class Initialized
INFO - 2016-12-03 06:16:30 --> Language Class Initialized
INFO - 2016-12-03 06:16:30 --> Loader Class Initialized
INFO - 2016-12-03 06:16:30 --> Database Driver Class Initialized
INFO - 2016-12-03 06:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:16:30 --> Controller Class Initialized
DEBUG - 2016-12-03 06:16:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:16:30 --> Helper loaded: url_helper
INFO - 2016-12-03 06:16:30 --> Final output sent to browser
DEBUG - 2016-12-03 06:16:30 --> Total execution time: 0.0119
INFO - 2016-12-03 06:16:33 --> Config Class Initialized
INFO - 2016-12-03 06:16:33 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:16:33 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:16:33 --> Utf8 Class Initialized
INFO - 2016-12-03 06:16:33 --> URI Class Initialized
INFO - 2016-12-03 06:16:33 --> Router Class Initialized
INFO - 2016-12-03 06:16:33 --> Output Class Initialized
INFO - 2016-12-03 06:16:33 --> Security Class Initialized
DEBUG - 2016-12-03 06:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:16:33 --> Input Class Initialized
INFO - 2016-12-03 06:16:33 --> Language Class Initialized
INFO - 2016-12-03 06:16:33 --> Loader Class Initialized
INFO - 2016-12-03 06:16:33 --> Database Driver Class Initialized
INFO - 2016-12-03 06:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:16:33 --> Controller Class Initialized
DEBUG - 2016-12-03 06:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:16:33 --> Helper loaded: url_helper
INFO - 2016-12-03 06:16:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:16:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 06:16:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-03 06:16:33 --> Severity: Notice --> Use of undefined constant id - assumed 'id' /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php 39
INFO - 2016-12-03 06:16:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 06:16:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 06:16:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:16:33 --> Final output sent to browser
DEBUG - 2016-12-03 06:16:33 --> Total execution time: 0.0125
INFO - 2016-12-03 06:16:34 --> Config Class Initialized
INFO - 2016-12-03 06:16:34 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:16:34 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:16:34 --> Utf8 Class Initialized
INFO - 2016-12-03 06:16:34 --> URI Class Initialized
INFO - 2016-12-03 06:16:34 --> Router Class Initialized
INFO - 2016-12-03 06:16:34 --> Output Class Initialized
INFO - 2016-12-03 06:16:34 --> Security Class Initialized
DEBUG - 2016-12-03 06:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:16:34 --> Input Class Initialized
INFO - 2016-12-03 06:16:34 --> Language Class Initialized
ERROR - 2016-12-03 06:16:34 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 06:16:34 --> Config Class Initialized
INFO - 2016-12-03 06:16:34 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:16:34 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:16:34 --> Utf8 Class Initialized
INFO - 2016-12-03 06:16:34 --> URI Class Initialized
INFO - 2016-12-03 06:16:34 --> Router Class Initialized
INFO - 2016-12-03 06:16:34 --> Output Class Initialized
INFO - 2016-12-03 06:16:34 --> Security Class Initialized
DEBUG - 2016-12-03 06:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:16:34 --> Input Class Initialized
INFO - 2016-12-03 06:16:34 --> Language Class Initialized
INFO - 2016-12-03 06:16:34 --> Loader Class Initialized
INFO - 2016-12-03 06:16:34 --> Database Driver Class Initialized
INFO - 2016-12-03 06:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:16:34 --> Controller Class Initialized
INFO - 2016-12-03 06:16:34 --> Helper loaded: url_helper
DEBUG - 2016-12-03 06:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:16:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:16:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 06:16:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 06:16:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:16:34 --> Final output sent to browser
DEBUG - 2016-12-03 06:16:34 --> Total execution time: 0.0136
INFO - 2016-12-03 06:17:13 --> Config Class Initialized
INFO - 2016-12-03 06:17:13 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:17:13 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:17:13 --> Utf8 Class Initialized
INFO - 2016-12-03 06:17:13 --> URI Class Initialized
INFO - 2016-12-03 06:17:13 --> Router Class Initialized
INFO - 2016-12-03 06:17:13 --> Output Class Initialized
INFO - 2016-12-03 06:17:13 --> Security Class Initialized
DEBUG - 2016-12-03 06:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:17:13 --> Input Class Initialized
INFO - 2016-12-03 06:17:13 --> Language Class Initialized
INFO - 2016-12-03 06:17:13 --> Loader Class Initialized
INFO - 2016-12-03 06:17:13 --> Database Driver Class Initialized
INFO - 2016-12-03 06:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:17:13 --> Controller Class Initialized
DEBUG - 2016-12-03 06:17:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:17:13 --> Helper loaded: url_helper
INFO - 2016-12-03 06:17:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:17:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 06:17:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 06:17:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 06:17:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 06:17:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:17:13 --> Final output sent to browser
DEBUG - 2016-12-03 06:17:13 --> Total execution time: 0.0126
INFO - 2016-12-03 06:17:13 --> Config Class Initialized
INFO - 2016-12-03 06:17:13 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:17:13 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:17:13 --> Utf8 Class Initialized
INFO - 2016-12-03 06:17:13 --> URI Class Initialized
INFO - 2016-12-03 06:17:13 --> Router Class Initialized
INFO - 2016-12-03 06:17:13 --> Output Class Initialized
INFO - 2016-12-03 06:17:13 --> Security Class Initialized
DEBUG - 2016-12-03 06:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:17:13 --> Input Class Initialized
INFO - 2016-12-03 06:17:13 --> Language Class Initialized
ERROR - 2016-12-03 06:17:13 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 06:17:13 --> Config Class Initialized
INFO - 2016-12-03 06:17:13 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:17:13 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:17:13 --> Utf8 Class Initialized
INFO - 2016-12-03 06:17:13 --> URI Class Initialized
INFO - 2016-12-03 06:17:13 --> Router Class Initialized
INFO - 2016-12-03 06:17:13 --> Output Class Initialized
INFO - 2016-12-03 06:17:13 --> Security Class Initialized
DEBUG - 2016-12-03 06:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:17:13 --> Input Class Initialized
INFO - 2016-12-03 06:17:13 --> Language Class Initialized
INFO - 2016-12-03 06:17:13 --> Loader Class Initialized
INFO - 2016-12-03 06:17:13 --> Database Driver Class Initialized
INFO - 2016-12-03 06:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:17:13 --> Controller Class Initialized
INFO - 2016-12-03 06:17:13 --> Helper loaded: url_helper
DEBUG - 2016-12-03 06:17:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:17:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:17:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 06:17:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 06:17:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:17:13 --> Final output sent to browser
DEBUG - 2016-12-03 06:17:13 --> Total execution time: 0.0141
INFO - 2016-12-03 06:17:19 --> Config Class Initialized
INFO - 2016-12-03 06:17:19 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:17:19 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:17:19 --> Utf8 Class Initialized
INFO - 2016-12-03 06:17:19 --> URI Class Initialized
INFO - 2016-12-03 06:17:19 --> Router Class Initialized
INFO - 2016-12-03 06:17:19 --> Output Class Initialized
INFO - 2016-12-03 06:17:19 --> Security Class Initialized
DEBUG - 2016-12-03 06:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:17:19 --> Input Class Initialized
INFO - 2016-12-03 06:17:19 --> Language Class Initialized
INFO - 2016-12-03 06:17:19 --> Loader Class Initialized
INFO - 2016-12-03 06:17:19 --> Database Driver Class Initialized
INFO - 2016-12-03 06:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:17:19 --> Controller Class Initialized
DEBUG - 2016-12-03 06:17:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:17:19 --> Helper loaded: url_helper
INFO - 2016-12-03 06:17:19 --> Final output sent to browser
DEBUG - 2016-12-03 06:17:19 --> Total execution time: 0.0122
INFO - 2016-12-03 06:20:22 --> Config Class Initialized
INFO - 2016-12-03 06:20:22 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:20:22 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:20:22 --> Utf8 Class Initialized
INFO - 2016-12-03 06:20:22 --> URI Class Initialized
INFO - 2016-12-03 06:20:22 --> Router Class Initialized
INFO - 2016-12-03 06:20:22 --> Output Class Initialized
INFO - 2016-12-03 06:20:22 --> Security Class Initialized
DEBUG - 2016-12-03 06:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:20:22 --> Input Class Initialized
INFO - 2016-12-03 06:20:22 --> Language Class Initialized
INFO - 2016-12-03 06:20:22 --> Loader Class Initialized
INFO - 2016-12-03 06:20:22 --> Database Driver Class Initialized
INFO - 2016-12-03 06:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:20:22 --> Controller Class Initialized
DEBUG - 2016-12-03 06:20:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:20:22 --> Helper loaded: url_helper
INFO - 2016-12-03 06:20:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:20:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 06:20:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 06:20:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 06:20:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 06:20:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:20:22 --> Final output sent to browser
DEBUG - 2016-12-03 06:20:22 --> Total execution time: 0.0202
INFO - 2016-12-03 06:20:22 --> Config Class Initialized
INFO - 2016-12-03 06:20:22 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:20:22 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:20:22 --> Utf8 Class Initialized
INFO - 2016-12-03 06:20:22 --> URI Class Initialized
INFO - 2016-12-03 06:20:22 --> Router Class Initialized
INFO - 2016-12-03 06:20:22 --> Output Class Initialized
INFO - 2016-12-03 06:20:22 --> Security Class Initialized
DEBUG - 2016-12-03 06:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:20:22 --> Input Class Initialized
INFO - 2016-12-03 06:20:22 --> Language Class Initialized
ERROR - 2016-12-03 06:20:22 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 06:20:22 --> Config Class Initialized
INFO - 2016-12-03 06:20:22 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:20:22 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:20:22 --> Utf8 Class Initialized
INFO - 2016-12-03 06:20:22 --> URI Class Initialized
INFO - 2016-12-03 06:20:22 --> Router Class Initialized
INFO - 2016-12-03 06:20:22 --> Output Class Initialized
INFO - 2016-12-03 06:20:22 --> Security Class Initialized
DEBUG - 2016-12-03 06:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:20:22 --> Input Class Initialized
INFO - 2016-12-03 06:20:22 --> Language Class Initialized
INFO - 2016-12-03 06:20:22 --> Loader Class Initialized
INFO - 2016-12-03 06:20:22 --> Database Driver Class Initialized
INFO - 2016-12-03 06:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:20:22 --> Controller Class Initialized
INFO - 2016-12-03 06:20:22 --> Helper loaded: url_helper
DEBUG - 2016-12-03 06:20:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:20:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:20:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 06:20:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 06:20:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:20:22 --> Final output sent to browser
DEBUG - 2016-12-03 06:20:22 --> Total execution time: 0.0138
INFO - 2016-12-03 06:20:23 --> Config Class Initialized
INFO - 2016-12-03 06:20:23 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:20:23 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:20:23 --> Utf8 Class Initialized
INFO - 2016-12-03 06:20:23 --> URI Class Initialized
INFO - 2016-12-03 06:20:23 --> Router Class Initialized
INFO - 2016-12-03 06:20:23 --> Output Class Initialized
INFO - 2016-12-03 06:20:23 --> Security Class Initialized
DEBUG - 2016-12-03 06:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:20:23 --> Input Class Initialized
INFO - 2016-12-03 06:20:23 --> Language Class Initialized
INFO - 2016-12-03 06:20:23 --> Loader Class Initialized
INFO - 2016-12-03 06:20:23 --> Database Driver Class Initialized
INFO - 2016-12-03 06:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:20:23 --> Controller Class Initialized
DEBUG - 2016-12-03 06:20:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:20:23 --> Helper loaded: url_helper
INFO - 2016-12-03 06:20:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:20:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 06:20:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-03 06:20:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-03 06:20:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:20:23 --> Final output sent to browser
DEBUG - 2016-12-03 06:20:23 --> Total execution time: 0.0296
INFO - 2016-12-03 06:20:24 --> Config Class Initialized
INFO - 2016-12-03 06:20:24 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:20:24 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:20:24 --> Utf8 Class Initialized
INFO - 2016-12-03 06:20:24 --> URI Class Initialized
INFO - 2016-12-03 06:20:24 --> Router Class Initialized
INFO - 2016-12-03 06:20:24 --> Output Class Initialized
INFO - 2016-12-03 06:20:24 --> Security Class Initialized
DEBUG - 2016-12-03 06:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:20:24 --> Input Class Initialized
INFO - 2016-12-03 06:20:24 --> Language Class Initialized
ERROR - 2016-12-03 06:20:24 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 06:20:25 --> Config Class Initialized
INFO - 2016-12-03 06:20:25 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:20:25 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:20:25 --> Utf8 Class Initialized
INFO - 2016-12-03 06:20:25 --> URI Class Initialized
INFO - 2016-12-03 06:20:25 --> Router Class Initialized
INFO - 2016-12-03 06:20:25 --> Output Class Initialized
INFO - 2016-12-03 06:20:25 --> Security Class Initialized
DEBUG - 2016-12-03 06:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:20:25 --> Input Class Initialized
INFO - 2016-12-03 06:20:25 --> Language Class Initialized
INFO - 2016-12-03 06:20:25 --> Loader Class Initialized
INFO - 2016-12-03 06:20:25 --> Database Driver Class Initialized
INFO - 2016-12-03 06:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:20:25 --> Controller Class Initialized
INFO - 2016-12-03 06:20:25 --> Helper loaded: url_helper
DEBUG - 2016-12-03 06:20:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:20:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:20:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 06:20:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 06:20:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:20:25 --> Final output sent to browser
DEBUG - 2016-12-03 06:20:25 --> Total execution time: 0.0137
INFO - 2016-12-03 06:20:31 --> Config Class Initialized
INFO - 2016-12-03 06:20:31 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:20:31 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:20:31 --> Utf8 Class Initialized
INFO - 2016-12-03 06:20:31 --> URI Class Initialized
INFO - 2016-12-03 06:20:31 --> Router Class Initialized
INFO - 2016-12-03 06:20:31 --> Output Class Initialized
INFO - 2016-12-03 06:20:31 --> Security Class Initialized
DEBUG - 2016-12-03 06:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:20:31 --> Input Class Initialized
INFO - 2016-12-03 06:20:31 --> Language Class Initialized
INFO - 2016-12-03 06:20:31 --> Loader Class Initialized
INFO - 2016-12-03 06:20:31 --> Database Driver Class Initialized
INFO - 2016-12-03 06:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:20:31 --> Controller Class Initialized
DEBUG - 2016-12-03 06:20:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:20:31 --> Helper loaded: url_helper
INFO - 2016-12-03 06:20:31 --> Final output sent to browser
DEBUG - 2016-12-03 06:20:31 --> Total execution time: 0.0143
INFO - 2016-12-03 06:20:33 --> Config Class Initialized
INFO - 2016-12-03 06:20:33 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:20:33 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:20:33 --> Utf8 Class Initialized
INFO - 2016-12-03 06:20:33 --> URI Class Initialized
INFO - 2016-12-03 06:20:33 --> Router Class Initialized
INFO - 2016-12-03 06:20:33 --> Output Class Initialized
INFO - 2016-12-03 06:20:33 --> Security Class Initialized
DEBUG - 2016-12-03 06:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:20:33 --> Input Class Initialized
INFO - 2016-12-03 06:20:33 --> Language Class Initialized
INFO - 2016-12-03 06:20:33 --> Loader Class Initialized
INFO - 2016-12-03 06:20:34 --> Database Driver Class Initialized
INFO - 2016-12-03 06:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:20:34 --> Controller Class Initialized
DEBUG - 2016-12-03 06:20:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:20:34 --> Helper loaded: url_helper
INFO - 2016-12-03 06:20:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:20:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 06:20:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 06:20:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 06:20:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 06:20:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:20:34 --> Final output sent to browser
DEBUG - 2016-12-03 06:20:34 --> Total execution time: 0.0526
INFO - 2016-12-03 06:20:34 --> Config Class Initialized
INFO - 2016-12-03 06:20:34 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:20:34 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:20:34 --> Utf8 Class Initialized
INFO - 2016-12-03 06:20:34 --> URI Class Initialized
INFO - 2016-12-03 06:20:34 --> Router Class Initialized
INFO - 2016-12-03 06:20:34 --> Output Class Initialized
INFO - 2016-12-03 06:20:34 --> Security Class Initialized
DEBUG - 2016-12-03 06:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:20:34 --> Input Class Initialized
INFO - 2016-12-03 06:20:34 --> Language Class Initialized
ERROR - 2016-12-03 06:20:34 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 06:20:34 --> Config Class Initialized
INFO - 2016-12-03 06:20:34 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:20:34 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:20:34 --> Utf8 Class Initialized
INFO - 2016-12-03 06:20:34 --> URI Class Initialized
INFO - 2016-12-03 06:20:34 --> Router Class Initialized
INFO - 2016-12-03 06:20:34 --> Output Class Initialized
INFO - 2016-12-03 06:20:34 --> Security Class Initialized
DEBUG - 2016-12-03 06:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:20:34 --> Input Class Initialized
INFO - 2016-12-03 06:20:34 --> Language Class Initialized
INFO - 2016-12-03 06:20:34 --> Loader Class Initialized
INFO - 2016-12-03 06:20:34 --> Database Driver Class Initialized
INFO - 2016-12-03 06:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:20:34 --> Controller Class Initialized
INFO - 2016-12-03 06:20:34 --> Helper loaded: url_helper
DEBUG - 2016-12-03 06:20:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:20:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:20:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 06:20:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 06:20:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:20:34 --> Final output sent to browser
DEBUG - 2016-12-03 06:20:34 --> Total execution time: 0.0134
INFO - 2016-12-03 06:20:39 --> Config Class Initialized
INFO - 2016-12-03 06:20:39 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:20:39 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:20:39 --> Utf8 Class Initialized
INFO - 2016-12-03 06:20:39 --> URI Class Initialized
INFO - 2016-12-03 06:20:39 --> Router Class Initialized
INFO - 2016-12-03 06:20:39 --> Output Class Initialized
INFO - 2016-12-03 06:20:39 --> Security Class Initialized
DEBUG - 2016-12-03 06:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:20:39 --> Input Class Initialized
INFO - 2016-12-03 06:20:39 --> Language Class Initialized
INFO - 2016-12-03 06:20:39 --> Loader Class Initialized
INFO - 2016-12-03 06:20:39 --> Database Driver Class Initialized
INFO - 2016-12-03 06:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:20:39 --> Controller Class Initialized
DEBUG - 2016-12-03 06:20:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:20:39 --> Helper loaded: url_helper
INFO - 2016-12-03 06:20:39 --> Final output sent to browser
DEBUG - 2016-12-03 06:20:39 --> Total execution time: 0.0119
INFO - 2016-12-03 06:20:40 --> Config Class Initialized
INFO - 2016-12-03 06:20:40 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:20:40 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:20:40 --> Utf8 Class Initialized
INFO - 2016-12-03 06:20:40 --> URI Class Initialized
INFO - 2016-12-03 06:20:40 --> Router Class Initialized
INFO - 2016-12-03 06:20:40 --> Output Class Initialized
INFO - 2016-12-03 06:20:40 --> Security Class Initialized
DEBUG - 2016-12-03 06:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:20:40 --> Input Class Initialized
INFO - 2016-12-03 06:20:40 --> Language Class Initialized
INFO - 2016-12-03 06:20:40 --> Loader Class Initialized
INFO - 2016-12-03 06:20:40 --> Database Driver Class Initialized
INFO - 2016-12-03 06:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:20:40 --> Controller Class Initialized
DEBUG - 2016-12-03 06:20:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:20:40 --> Helper loaded: url_helper
INFO - 2016-12-03 06:20:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:20:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 06:20:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 06:20:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 06:20:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 06:20:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:20:40 --> Final output sent to browser
DEBUG - 2016-12-03 06:20:40 --> Total execution time: 0.0471
INFO - 2016-12-03 06:20:41 --> Config Class Initialized
INFO - 2016-12-03 06:20:41 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:20:41 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:20:41 --> Utf8 Class Initialized
INFO - 2016-12-03 06:20:41 --> URI Class Initialized
INFO - 2016-12-03 06:20:41 --> Router Class Initialized
INFO - 2016-12-03 06:20:41 --> Output Class Initialized
INFO - 2016-12-03 06:20:41 --> Security Class Initialized
DEBUG - 2016-12-03 06:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:20:41 --> Input Class Initialized
INFO - 2016-12-03 06:20:41 --> Language Class Initialized
ERROR - 2016-12-03 06:20:41 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 06:20:41 --> Config Class Initialized
INFO - 2016-12-03 06:20:41 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:20:41 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:20:41 --> Utf8 Class Initialized
INFO - 2016-12-03 06:20:41 --> URI Class Initialized
INFO - 2016-12-03 06:20:41 --> Router Class Initialized
INFO - 2016-12-03 06:20:41 --> Output Class Initialized
INFO - 2016-12-03 06:20:41 --> Security Class Initialized
DEBUG - 2016-12-03 06:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:20:41 --> Input Class Initialized
INFO - 2016-12-03 06:20:41 --> Language Class Initialized
INFO - 2016-12-03 06:20:41 --> Loader Class Initialized
INFO - 2016-12-03 06:20:41 --> Database Driver Class Initialized
INFO - 2016-12-03 06:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:20:41 --> Controller Class Initialized
INFO - 2016-12-03 06:20:41 --> Helper loaded: url_helper
DEBUG - 2016-12-03 06:20:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:20:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:20:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 06:20:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 06:20:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:20:41 --> Final output sent to browser
DEBUG - 2016-12-03 06:20:41 --> Total execution time: 0.0141
INFO - 2016-12-03 06:20:44 --> Config Class Initialized
INFO - 2016-12-03 06:20:44 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:20:44 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:20:44 --> Utf8 Class Initialized
INFO - 2016-12-03 06:20:44 --> URI Class Initialized
INFO - 2016-12-03 06:20:44 --> Router Class Initialized
INFO - 2016-12-03 06:20:44 --> Output Class Initialized
INFO - 2016-12-03 06:20:44 --> Security Class Initialized
DEBUG - 2016-12-03 06:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:20:44 --> Input Class Initialized
INFO - 2016-12-03 06:20:44 --> Language Class Initialized
INFO - 2016-12-03 06:20:44 --> Loader Class Initialized
INFO - 2016-12-03 06:20:44 --> Database Driver Class Initialized
INFO - 2016-12-03 06:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:20:44 --> Controller Class Initialized
DEBUG - 2016-12-03 06:20:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:20:44 --> Helper loaded: url_helper
INFO - 2016-12-03 06:20:44 --> Final output sent to browser
DEBUG - 2016-12-03 06:20:44 --> Total execution time: 0.0144
INFO - 2016-12-03 06:20:47 --> Config Class Initialized
INFO - 2016-12-03 06:20:47 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:20:47 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:20:47 --> Utf8 Class Initialized
INFO - 2016-12-03 06:20:47 --> URI Class Initialized
INFO - 2016-12-03 06:20:47 --> Router Class Initialized
INFO - 2016-12-03 06:20:47 --> Output Class Initialized
INFO - 2016-12-03 06:20:47 --> Security Class Initialized
DEBUG - 2016-12-03 06:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:20:47 --> Input Class Initialized
INFO - 2016-12-03 06:20:47 --> Language Class Initialized
INFO - 2016-12-03 06:20:47 --> Loader Class Initialized
INFO - 2016-12-03 06:20:47 --> Database Driver Class Initialized
INFO - 2016-12-03 06:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:20:47 --> Controller Class Initialized
DEBUG - 2016-12-03 06:20:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:20:47 --> Helper loaded: url_helper
INFO - 2016-12-03 06:20:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:20:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 06:20:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 06:20:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 06:20:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 06:20:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:20:47 --> Final output sent to browser
DEBUG - 2016-12-03 06:20:47 --> Total execution time: 0.0130
INFO - 2016-12-03 06:20:48 --> Config Class Initialized
INFO - 2016-12-03 06:20:48 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:20:48 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:20:48 --> Utf8 Class Initialized
INFO - 2016-12-03 06:20:48 --> URI Class Initialized
INFO - 2016-12-03 06:20:48 --> Router Class Initialized
INFO - 2016-12-03 06:20:48 --> Output Class Initialized
INFO - 2016-12-03 06:20:48 --> Security Class Initialized
DEBUG - 2016-12-03 06:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:20:48 --> Input Class Initialized
INFO - 2016-12-03 06:20:48 --> Language Class Initialized
ERROR - 2016-12-03 06:20:48 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 06:20:48 --> Config Class Initialized
INFO - 2016-12-03 06:20:48 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:20:48 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:20:48 --> Utf8 Class Initialized
INFO - 2016-12-03 06:20:48 --> URI Class Initialized
INFO - 2016-12-03 06:20:48 --> Router Class Initialized
INFO - 2016-12-03 06:20:48 --> Output Class Initialized
INFO - 2016-12-03 06:20:48 --> Security Class Initialized
DEBUG - 2016-12-03 06:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:20:48 --> Input Class Initialized
INFO - 2016-12-03 06:20:48 --> Language Class Initialized
INFO - 2016-12-03 06:20:48 --> Loader Class Initialized
INFO - 2016-12-03 06:20:48 --> Database Driver Class Initialized
INFO - 2016-12-03 06:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:20:48 --> Controller Class Initialized
INFO - 2016-12-03 06:20:48 --> Helper loaded: url_helper
DEBUG - 2016-12-03 06:20:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:20:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 06:20:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 06:20:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 06:20:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 06:20:48 --> Final output sent to browser
DEBUG - 2016-12-03 06:20:48 --> Total execution time: 0.0134
INFO - 2016-12-03 06:20:52 --> Config Class Initialized
INFO - 2016-12-03 06:20:52 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:20:52 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:20:52 --> Utf8 Class Initialized
INFO - 2016-12-03 06:20:52 --> URI Class Initialized
INFO - 2016-12-03 06:20:52 --> Router Class Initialized
INFO - 2016-12-03 06:20:52 --> Output Class Initialized
INFO - 2016-12-03 06:20:52 --> Security Class Initialized
DEBUG - 2016-12-03 06:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:20:52 --> Input Class Initialized
INFO - 2016-12-03 06:20:52 --> Language Class Initialized
INFO - 2016-12-03 06:20:52 --> Loader Class Initialized
INFO - 2016-12-03 06:20:52 --> Database Driver Class Initialized
INFO - 2016-12-03 06:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:20:52 --> Controller Class Initialized
INFO - 2016-12-03 06:20:52 --> Helper loaded: date_helper
INFO - 2016-12-03 06:20:52 --> Helper loaded: url_helper
DEBUG - 2016-12-03 06:20:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:20:52 --> Helper loaded: form_helper
INFO - 2016-12-03 06:20:52 --> Form Validation Class Initialized
INFO - 2016-12-03 06:20:53 --> Final output sent to browser
DEBUG - 2016-12-03 06:20:53 --> Total execution time: 0.0874
INFO - 2016-12-03 06:20:53 --> Config Class Initialized
INFO - 2016-12-03 06:20:53 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:20:53 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:20:53 --> Utf8 Class Initialized
INFO - 2016-12-03 06:20:53 --> URI Class Initialized
INFO - 2016-12-03 06:20:53 --> Router Class Initialized
INFO - 2016-12-03 06:20:53 --> Output Class Initialized
INFO - 2016-12-03 06:20:53 --> Security Class Initialized
DEBUG - 2016-12-03 06:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:20:53 --> Input Class Initialized
INFO - 2016-12-03 06:20:53 --> Language Class Initialized
INFO - 2016-12-03 06:20:53 --> Loader Class Initialized
INFO - 2016-12-03 06:20:53 --> Database Driver Class Initialized
INFO - 2016-12-03 06:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:20:53 --> Controller Class Initialized
INFO - 2016-12-03 06:20:53 --> Helper loaded: date_helper
INFO - 2016-12-03 06:20:53 --> Helper loaded: url_helper
DEBUG - 2016-12-03 06:20:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:20:53 --> Helper loaded: form_helper
INFO - 2016-12-03 06:20:53 --> Form Validation Class Initialized
INFO - 2016-12-03 06:20:53 --> Final output sent to browser
DEBUG - 2016-12-03 06:20:53 --> Total execution time: 0.0289
INFO - 2016-12-03 06:20:54 --> Config Class Initialized
INFO - 2016-12-03 06:20:54 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:20:54 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:20:54 --> Utf8 Class Initialized
INFO - 2016-12-03 06:20:54 --> URI Class Initialized
INFO - 2016-12-03 06:20:54 --> Router Class Initialized
INFO - 2016-12-03 06:20:54 --> Output Class Initialized
INFO - 2016-12-03 06:20:54 --> Security Class Initialized
DEBUG - 2016-12-03 06:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:20:54 --> Input Class Initialized
INFO - 2016-12-03 06:20:54 --> Language Class Initialized
INFO - 2016-12-03 06:20:54 --> Loader Class Initialized
INFO - 2016-12-03 06:20:54 --> Database Driver Class Initialized
INFO - 2016-12-03 06:20:54 --> Config Class Initialized
INFO - 2016-12-03 06:20:54 --> Hooks Class Initialized
DEBUG - 2016-12-03 06:20:54 --> UTF-8 Support Enabled
INFO - 2016-12-03 06:20:54 --> Utf8 Class Initialized
INFO - 2016-12-03 06:20:54 --> URI Class Initialized
INFO - 2016-12-03 06:20:54 --> Router Class Initialized
INFO - 2016-12-03 06:20:54 --> Output Class Initialized
INFO - 2016-12-03 06:20:54 --> Security Class Initialized
INFO - 2016-12-03 06:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:20:54 --> Controller Class Initialized
INFO - 2016-12-03 06:20:54 --> Helper loaded: date_helper
INFO - 2016-12-03 06:20:54 --> Helper loaded: url_helper
DEBUG - 2016-12-03 06:20:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:20:54 --> Helper loaded: form_helper
INFO - 2016-12-03 06:20:54 --> Form Validation Class Initialized
DEBUG - 2016-12-03 06:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 06:20:54 --> Input Class Initialized
INFO - 2016-12-03 06:20:54 --> Language Class Initialized
INFO - 2016-12-03 06:20:54 --> Loader Class Initialized
INFO - 2016-12-03 06:20:54 --> Database Driver Class Initialized
INFO - 2016-12-03 06:20:54 --> Final output sent to browser
DEBUG - 2016-12-03 06:20:54 --> Total execution time: 0.0427
INFO - 2016-12-03 06:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 06:20:54 --> Controller Class Initialized
INFO - 2016-12-03 06:20:54 --> Helper loaded: date_helper
INFO - 2016-12-03 06:20:54 --> Helper loaded: url_helper
DEBUG - 2016-12-03 06:20:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 06:20:54 --> Helper loaded: form_helper
INFO - 2016-12-03 06:20:54 --> Form Validation Class Initialized
INFO - 2016-12-03 06:20:54 --> Final output sent to browser
DEBUG - 2016-12-03 06:20:54 --> Total execution time: 0.0803
INFO - 2016-12-03 15:58:38 --> Config Class Initialized
INFO - 2016-12-03 15:58:38 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:58:38 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:58:38 --> Utf8 Class Initialized
INFO - 2016-12-03 15:58:38 --> URI Class Initialized
INFO - 2016-12-03 15:58:38 --> Router Class Initialized
INFO - 2016-12-03 15:58:38 --> Output Class Initialized
INFO - 2016-12-03 15:58:39 --> Security Class Initialized
DEBUG - 2016-12-03 15:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:58:39 --> Input Class Initialized
INFO - 2016-12-03 15:58:39 --> Language Class Initialized
INFO - 2016-12-03 15:58:39 --> Loader Class Initialized
INFO - 2016-12-03 15:58:39 --> Database Driver Class Initialized
INFO - 2016-12-03 15:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:58:39 --> Controller Class Initialized
INFO - 2016-12-03 15:58:39 --> Helper loaded: date_helper
INFO - 2016-12-03 15:58:39 --> Helper loaded: url_helper
DEBUG - 2016-12-03 15:58:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 15:58:39 --> Helper loaded: form_helper
INFO - 2016-12-03 15:58:39 --> Form Validation Class Initialized
INFO - 2016-12-03 15:58:39 --> Config Class Initialized
INFO - 2016-12-03 15:58:39 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:58:39 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:58:39 --> Utf8 Class Initialized
INFO - 2016-12-03 15:58:39 --> URI Class Initialized
INFO - 2016-12-03 15:58:39 --> Router Class Initialized
INFO - 2016-12-03 15:58:39 --> Output Class Initialized
INFO - 2016-12-03 15:58:39 --> Security Class Initialized
DEBUG - 2016-12-03 15:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:58:39 --> Input Class Initialized
INFO - 2016-12-03 15:58:39 --> Language Class Initialized
INFO - 2016-12-03 15:58:39 --> Loader Class Initialized
INFO - 2016-12-03 15:58:39 --> Database Driver Class Initialized
INFO - 2016-12-03 15:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:58:39 --> Controller Class Initialized
INFO - 2016-12-03 15:58:39 --> Helper loaded: url_helper
DEBUG - 2016-12-03 15:58:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 15:58:39 --> Helper loaded: form_helper
INFO - 2016-12-03 15:58:39 --> Form Validation Class Initialized
INFO - 2016-12-03 15:58:39 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-03 15:58:39 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2016-12-03 15:58:39 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-03 15:58:39 --> Final output sent to browser
DEBUG - 2016-12-03 15:58:39 --> Total execution time: 0.0409
INFO - 2016-12-03 15:58:39 --> Config Class Initialized
INFO - 2016-12-03 15:58:39 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:58:39 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:58:39 --> Utf8 Class Initialized
INFO - 2016-12-03 15:58:39 --> URI Class Initialized
INFO - 2016-12-03 15:58:39 --> Router Class Initialized
INFO - 2016-12-03 15:58:39 --> Output Class Initialized
INFO - 2016-12-03 15:58:39 --> Security Class Initialized
DEBUG - 2016-12-03 15:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:58:39 --> Input Class Initialized
INFO - 2016-12-03 15:58:39 --> Language Class Initialized
INFO - 2016-12-03 15:58:39 --> Loader Class Initialized
INFO - 2016-12-03 15:58:39 --> Database Driver Class Initialized
INFO - 2016-12-03 15:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:58:39 --> Controller Class Initialized
INFO - 2016-12-03 15:58:39 --> Helper loaded: url_helper
DEBUG - 2016-12-03 15:58:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 15:58:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 15:58:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 15:58:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 15:58:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 15:58:39 --> Final output sent to browser
DEBUG - 2016-12-03 15:58:39 --> Total execution time: 0.0142
INFO - 2016-12-03 15:58:49 --> Config Class Initialized
INFO - 2016-12-03 15:58:49 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:58:49 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:58:49 --> Utf8 Class Initialized
INFO - 2016-12-03 15:58:49 --> URI Class Initialized
INFO - 2016-12-03 15:58:49 --> Router Class Initialized
INFO - 2016-12-03 15:58:49 --> Output Class Initialized
INFO - 2016-12-03 15:58:49 --> Security Class Initialized
DEBUG - 2016-12-03 15:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:58:49 --> Input Class Initialized
INFO - 2016-12-03 15:58:49 --> Language Class Initialized
INFO - 2016-12-03 15:58:49 --> Loader Class Initialized
INFO - 2016-12-03 15:58:49 --> Database Driver Class Initialized
INFO - 2016-12-03 15:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:58:49 --> Controller Class Initialized
INFO - 2016-12-03 15:58:49 --> Helper loaded: url_helper
DEBUG - 2016-12-03 15:58:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 15:58:49 --> Helper loaded: form_helper
INFO - 2016-12-03 15:58:49 --> Form Validation Class Initialized
INFO - 2016-12-03 15:58:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-12-03 15:58:49 --> Config Class Initialized
INFO - 2016-12-03 15:58:49 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:58:49 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:58:49 --> Utf8 Class Initialized
INFO - 2016-12-03 15:58:49 --> URI Class Initialized
INFO - 2016-12-03 15:58:49 --> Router Class Initialized
INFO - 2016-12-03 15:58:49 --> Output Class Initialized
INFO - 2016-12-03 15:58:49 --> Security Class Initialized
DEBUG - 2016-12-03 15:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:58:49 --> Input Class Initialized
INFO - 2016-12-03 15:58:49 --> Language Class Initialized
INFO - 2016-12-03 15:58:49 --> Loader Class Initialized
INFO - 2016-12-03 15:58:49 --> Database Driver Class Initialized
INFO - 2016-12-03 15:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:58:49 --> Controller Class Initialized
INFO - 2016-12-03 15:58:49 --> Helper loaded: date_helper
INFO - 2016-12-03 15:58:49 --> Helper loaded: url_helper
DEBUG - 2016-12-03 15:58:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 15:58:49 --> Helper loaded: form_helper
INFO - 2016-12-03 15:58:49 --> Form Validation Class Initialized
INFO - 2016-12-03 15:58:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-03 15:58:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-03 15:58:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2016-12-03 15:58:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2016-12-03 15:58:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-03 15:58:49 --> Final output sent to browser
DEBUG - 2016-12-03 15:58:49 --> Total execution time: 0.0479
INFO - 2016-12-03 15:58:49 --> Config Class Initialized
INFO - 2016-12-03 15:58:49 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:58:49 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:58:49 --> Utf8 Class Initialized
INFO - 2016-12-03 15:58:49 --> URI Class Initialized
INFO - 2016-12-03 15:58:49 --> Router Class Initialized
INFO - 2016-12-03 15:58:49 --> Output Class Initialized
INFO - 2016-12-03 15:58:49 --> Security Class Initialized
DEBUG - 2016-12-03 15:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:58:49 --> Input Class Initialized
INFO - 2016-12-03 15:58:49 --> Language Class Initialized
INFO - 2016-12-03 15:58:49 --> Loader Class Initialized
INFO - 2016-12-03 15:58:49 --> Database Driver Class Initialized
INFO - 2016-12-03 15:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:58:49 --> Controller Class Initialized
INFO - 2016-12-03 15:58:49 --> Helper loaded: date_helper
INFO - 2016-12-03 15:58:49 --> Helper loaded: url_helper
DEBUG - 2016-12-03 15:58:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 15:58:49 --> Helper loaded: form_helper
INFO - 2016-12-03 15:58:49 --> Form Validation Class Initialized
INFO - 2016-12-03 15:58:49 --> Final output sent to browser
DEBUG - 2016-12-03 15:58:49 --> Total execution time: 0.0397
INFO - 2016-12-03 15:58:49 --> Config Class Initialized
INFO - 2016-12-03 15:58:49 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:58:49 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:58:49 --> Utf8 Class Initialized
INFO - 2016-12-03 15:58:49 --> URI Class Initialized
INFO - 2016-12-03 15:58:49 --> Router Class Initialized
INFO - 2016-12-03 15:58:49 --> Output Class Initialized
INFO - 2016-12-03 15:58:49 --> Security Class Initialized
DEBUG - 2016-12-03 15:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:58:49 --> Input Class Initialized
INFO - 2016-12-03 15:58:49 --> Language Class Initialized
INFO - 2016-12-03 15:58:49 --> Loader Class Initialized
INFO - 2016-12-03 15:58:49 --> Database Driver Class Initialized
INFO - 2016-12-03 15:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:58:49 --> Controller Class Initialized
INFO - 2016-12-03 15:58:49 --> Helper loaded: url_helper
DEBUG - 2016-12-03 15:58:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 15:58:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 15:58:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 15:58:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 15:58:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 15:58:49 --> Final output sent to browser
DEBUG - 2016-12-03 15:58:49 --> Total execution time: 0.0145
INFO - 2016-12-03 15:58:54 --> Config Class Initialized
INFO - 2016-12-03 15:58:54 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:58:54 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:58:54 --> Utf8 Class Initialized
INFO - 2016-12-03 15:58:54 --> URI Class Initialized
INFO - 2016-12-03 15:58:54 --> Router Class Initialized
INFO - 2016-12-03 15:58:54 --> Output Class Initialized
INFO - 2016-12-03 15:58:54 --> Security Class Initialized
DEBUG - 2016-12-03 15:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:58:54 --> Input Class Initialized
INFO - 2016-12-03 15:58:54 --> Language Class Initialized
INFO - 2016-12-03 15:58:54 --> Loader Class Initialized
INFO - 2016-12-03 15:58:54 --> Database Driver Class Initialized
INFO - 2016-12-03 15:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:58:54 --> Controller Class Initialized
INFO - 2016-12-03 15:58:54 --> Helper loaded: date_helper
INFO - 2016-12-03 15:58:54 --> Helper loaded: url_helper
DEBUG - 2016-12-03 15:58:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 15:58:54 --> Helper loaded: form_helper
INFO - 2016-12-03 15:58:54 --> Form Validation Class Initialized
INFO - 2016-12-03 15:58:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-03 15:58:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2016-12-03 15:58:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pagos.php
INFO - 2016-12-03 15:58:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pagos.php
INFO - 2016-12-03 15:58:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-03 15:58:54 --> Final output sent to browser
DEBUG - 2016-12-03 15:58:54 --> Total execution time: 0.0514
INFO - 2016-12-03 15:58:54 --> Config Class Initialized
INFO - 2016-12-03 15:58:54 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:58:54 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:58:54 --> Utf8 Class Initialized
INFO - 2016-12-03 15:58:54 --> URI Class Initialized
INFO - 2016-12-03 15:58:54 --> Router Class Initialized
INFO - 2016-12-03 15:58:54 --> Output Class Initialized
INFO - 2016-12-03 15:58:54 --> Security Class Initialized
DEBUG - 2016-12-03 15:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:58:54 --> Input Class Initialized
INFO - 2016-12-03 15:58:54 --> Language Class Initialized
INFO - 2016-12-03 15:58:54 --> Loader Class Initialized
INFO - 2016-12-03 15:58:54 --> Database Driver Class Initialized
INFO - 2016-12-03 15:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:58:54 --> Controller Class Initialized
INFO - 2016-12-03 15:58:54 --> Helper loaded: date_helper
INFO - 2016-12-03 15:58:54 --> Helper loaded: url_helper
DEBUG - 2016-12-03 15:58:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 15:58:54 --> Helper loaded: form_helper
INFO - 2016-12-03 15:58:54 --> Form Validation Class Initialized
INFO - 2016-12-03 15:58:54 --> Final output sent to browser
DEBUG - 2016-12-03 15:58:54 --> Total execution time: 0.0151
INFO - 2016-12-03 15:58:54 --> Config Class Initialized
INFO - 2016-12-03 15:58:54 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:58:54 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:58:54 --> Utf8 Class Initialized
INFO - 2016-12-03 15:58:54 --> URI Class Initialized
INFO - 2016-12-03 15:58:54 --> Router Class Initialized
INFO - 2016-12-03 15:58:54 --> Output Class Initialized
INFO - 2016-12-03 15:58:54 --> Security Class Initialized
DEBUG - 2016-12-03 15:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:58:54 --> Input Class Initialized
INFO - 2016-12-03 15:58:54 --> Language Class Initialized
INFO - 2016-12-03 15:58:54 --> Loader Class Initialized
INFO - 2016-12-03 15:58:54 --> Database Driver Class Initialized
INFO - 2016-12-03 15:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:58:54 --> Controller Class Initialized
INFO - 2016-12-03 15:58:54 --> Helper loaded: url_helper
DEBUG - 2016-12-03 15:58:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 15:58:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 15:58:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 15:58:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 15:58:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 15:58:54 --> Final output sent to browser
DEBUG - 2016-12-03 15:58:54 --> Total execution time: 0.0131
INFO - 2016-12-03 15:59:04 --> Config Class Initialized
INFO - 2016-12-03 15:59:04 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:59:04 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:59:04 --> Utf8 Class Initialized
INFO - 2016-12-03 15:59:04 --> URI Class Initialized
INFO - 2016-12-03 15:59:04 --> Router Class Initialized
INFO - 2016-12-03 15:59:04 --> Output Class Initialized
INFO - 2016-12-03 15:59:04 --> Security Class Initialized
DEBUG - 2016-12-03 15:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:59:04 --> Input Class Initialized
INFO - 2016-12-03 15:59:04 --> Language Class Initialized
INFO - 2016-12-03 15:59:04 --> Loader Class Initialized
INFO - 2016-12-03 15:59:04 --> Database Driver Class Initialized
INFO - 2016-12-03 15:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:59:04 --> Controller Class Initialized
DEBUG - 2016-12-03 15:59:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 15:59:04 --> Helper loaded: url_helper
INFO - 2016-12-03 15:59:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 15:59:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 15:59:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-03 15:59:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 15:59:04 --> Final output sent to browser
DEBUG - 2016-12-03 15:59:04 --> Total execution time: 0.0196
INFO - 2016-12-03 15:59:05 --> Config Class Initialized
INFO - 2016-12-03 15:59:05 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:59:05 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:59:05 --> Utf8 Class Initialized
INFO - 2016-12-03 15:59:05 --> URI Class Initialized
INFO - 2016-12-03 15:59:05 --> Router Class Initialized
INFO - 2016-12-03 15:59:05 --> Output Class Initialized
INFO - 2016-12-03 15:59:05 --> Security Class Initialized
DEBUG - 2016-12-03 15:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:59:05 --> Input Class Initialized
INFO - 2016-12-03 15:59:05 --> Language Class Initialized
ERROR - 2016-12-03 15:59:05 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 15:59:05 --> Config Class Initialized
INFO - 2016-12-03 15:59:05 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:59:05 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:59:05 --> Utf8 Class Initialized
INFO - 2016-12-03 15:59:05 --> URI Class Initialized
INFO - 2016-12-03 15:59:05 --> Router Class Initialized
INFO - 2016-12-03 15:59:05 --> Output Class Initialized
INFO - 2016-12-03 15:59:05 --> Security Class Initialized
DEBUG - 2016-12-03 15:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:59:05 --> Input Class Initialized
INFO - 2016-12-03 15:59:05 --> Language Class Initialized
INFO - 2016-12-03 15:59:05 --> Loader Class Initialized
INFO - 2016-12-03 15:59:05 --> Database Driver Class Initialized
INFO - 2016-12-03 15:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:59:05 --> Controller Class Initialized
INFO - 2016-12-03 15:59:05 --> Helper loaded: url_helper
DEBUG - 2016-12-03 15:59:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 15:59:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 15:59:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 15:59:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 15:59:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 15:59:05 --> Final output sent to browser
DEBUG - 2016-12-03 15:59:05 --> Total execution time: 0.0133
INFO - 2016-12-03 15:59:06 --> Config Class Initialized
INFO - 2016-12-03 15:59:06 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:59:06 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:59:06 --> Utf8 Class Initialized
INFO - 2016-12-03 15:59:06 --> URI Class Initialized
INFO - 2016-12-03 15:59:06 --> Router Class Initialized
INFO - 2016-12-03 15:59:06 --> Output Class Initialized
INFO - 2016-12-03 15:59:06 --> Security Class Initialized
DEBUG - 2016-12-03 15:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:59:06 --> Input Class Initialized
INFO - 2016-12-03 15:59:06 --> Language Class Initialized
INFO - 2016-12-03 15:59:06 --> Loader Class Initialized
INFO - 2016-12-03 15:59:06 --> Database Driver Class Initialized
INFO - 2016-12-03 15:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:59:06 --> Controller Class Initialized
DEBUG - 2016-12-03 15:59:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 15:59:06 --> Helper loaded: url_helper
INFO - 2016-12-03 15:59:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 15:59:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 15:59:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 15:59:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 15:59:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 15:59:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 15:59:06 --> Final output sent to browser
DEBUG - 2016-12-03 15:59:06 --> Total execution time: 0.0278
INFO - 2016-12-03 15:59:06 --> Config Class Initialized
INFO - 2016-12-03 15:59:06 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:59:06 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:59:06 --> Utf8 Class Initialized
INFO - 2016-12-03 15:59:06 --> URI Class Initialized
INFO - 2016-12-03 15:59:06 --> Router Class Initialized
INFO - 2016-12-03 15:59:06 --> Output Class Initialized
INFO - 2016-12-03 15:59:06 --> Security Class Initialized
DEBUG - 2016-12-03 15:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:59:06 --> Input Class Initialized
INFO - 2016-12-03 15:59:06 --> Language Class Initialized
ERROR - 2016-12-03 15:59:06 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 15:59:06 --> Config Class Initialized
INFO - 2016-12-03 15:59:06 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:59:06 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:59:06 --> Utf8 Class Initialized
INFO - 2016-12-03 15:59:06 --> URI Class Initialized
INFO - 2016-12-03 15:59:06 --> Router Class Initialized
INFO - 2016-12-03 15:59:06 --> Output Class Initialized
INFO - 2016-12-03 15:59:06 --> Security Class Initialized
DEBUG - 2016-12-03 15:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:59:06 --> Input Class Initialized
INFO - 2016-12-03 15:59:06 --> Language Class Initialized
INFO - 2016-12-03 15:59:06 --> Loader Class Initialized
INFO - 2016-12-03 15:59:06 --> Database Driver Class Initialized
INFO - 2016-12-03 15:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:59:06 --> Controller Class Initialized
INFO - 2016-12-03 15:59:06 --> Helper loaded: url_helper
DEBUG - 2016-12-03 15:59:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 15:59:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 15:59:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 15:59:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 15:59:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 15:59:06 --> Final output sent to browser
DEBUG - 2016-12-03 15:59:06 --> Total execution time: 0.0139
INFO - 2016-12-03 15:59:08 --> Config Class Initialized
INFO - 2016-12-03 15:59:08 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:59:08 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:59:08 --> Utf8 Class Initialized
INFO - 2016-12-03 15:59:08 --> URI Class Initialized
INFO - 2016-12-03 15:59:08 --> Router Class Initialized
INFO - 2016-12-03 15:59:08 --> Output Class Initialized
INFO - 2016-12-03 15:59:08 --> Security Class Initialized
DEBUG - 2016-12-03 15:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:59:08 --> Input Class Initialized
INFO - 2016-12-03 15:59:08 --> Language Class Initialized
INFO - 2016-12-03 15:59:08 --> Loader Class Initialized
INFO - 2016-12-03 15:59:08 --> Database Driver Class Initialized
INFO - 2016-12-03 15:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:59:08 --> Controller Class Initialized
INFO - 2016-12-03 15:59:08 --> Helper loaded: date_helper
DEBUG - 2016-12-03 15:59:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 15:59:08 --> Helper loaded: url_helper
INFO - 2016-12-03 15:59:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 15:59:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2016-12-03 15:59:08 --> Severity: Notice --> Undefined variable: layout_name /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php 10
INFO - 2016-12-03 15:59:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
ERROR - 2016-12-03 15:59:08 --> Severity: Notice --> Undefined variable: numero_lugares /home/graduafe/public_html/application/controllers/User_mi_graduacion_controller.php 52
INFO - 2016-12-03 15:59:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 15:59:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 15:59:08 --> Final output sent to browser
DEBUG - 2016-12-03 15:59:08 --> Total execution time: 0.0814
INFO - 2016-12-03 15:59:08 --> Config Class Initialized
INFO - 2016-12-03 15:59:08 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:59:08 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:59:08 --> Utf8 Class Initialized
INFO - 2016-12-03 15:59:08 --> Config Class Initialized
INFO - 2016-12-03 15:59:08 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:59:08 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:59:08 --> Utf8 Class Initialized
INFO - 2016-12-03 15:59:08 --> URI Class Initialized
INFO - 2016-12-03 15:59:08 --> Router Class Initialized
INFO - 2016-12-03 15:59:08 --> Output Class Initialized
INFO - 2016-12-03 15:59:08 --> Security Class Initialized
DEBUG - 2016-12-03 15:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:59:08 --> Input Class Initialized
INFO - 2016-12-03 15:59:08 --> Language Class Initialized
ERROR - 2016-12-03 15:59:08 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 15:59:08 --> Config Class Initialized
INFO - 2016-12-03 15:59:08 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:59:08 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:59:08 --> Utf8 Class Initialized
INFO - 2016-12-03 15:59:08 --> URI Class Initialized
INFO - 2016-12-03 15:59:08 --> Router Class Initialized
INFO - 2016-12-03 15:59:08 --> Output Class Initialized
INFO - 2016-12-03 15:59:08 --> Security Class Initialized
DEBUG - 2016-12-03 15:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:59:08 --> Input Class Initialized
INFO - 2016-12-03 15:59:08 --> Language Class Initialized
INFO - 2016-12-03 15:59:08 --> Loader Class Initialized
INFO - 2016-12-03 15:59:08 --> Database Driver Class Initialized
INFO - 2016-12-03 15:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:59:08 --> Controller Class Initialized
INFO - 2016-12-03 15:59:08 --> Helper loaded: url_helper
DEBUG - 2016-12-03 15:59:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 15:59:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 15:59:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 15:59:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 15:59:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 15:59:08 --> Final output sent to browser
DEBUG - 2016-12-03 15:59:08 --> Total execution time: 0.0130
INFO - 2016-12-03 15:59:27 --> Config Class Initialized
INFO - 2016-12-03 15:59:27 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:59:27 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:59:27 --> Utf8 Class Initialized
INFO - 2016-12-03 15:59:27 --> URI Class Initialized
INFO - 2016-12-03 15:59:27 --> Router Class Initialized
INFO - 2016-12-03 15:59:27 --> Output Class Initialized
INFO - 2016-12-03 15:59:27 --> Security Class Initialized
DEBUG - 2016-12-03 15:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:59:27 --> Input Class Initialized
INFO - 2016-12-03 15:59:27 --> Language Class Initialized
INFO - 2016-12-03 15:59:27 --> Loader Class Initialized
INFO - 2016-12-03 15:59:27 --> Database Driver Class Initialized
INFO - 2016-12-03 15:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:59:27 --> Controller Class Initialized
DEBUG - 2016-12-03 15:59:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 15:59:27 --> Helper loaded: url_helper
INFO - 2016-12-03 15:59:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 15:59:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 15:59:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2016-12-03 15:59:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-03 15:59:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 15:59:27 --> Final output sent to browser
DEBUG - 2016-12-03 15:59:27 --> Total execution time: 0.0128
INFO - 2016-12-03 15:59:27 --> Config Class Initialized
INFO - 2016-12-03 15:59:27 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:59:27 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:59:27 --> Utf8 Class Initialized
INFO - 2016-12-03 15:59:27 --> URI Class Initialized
INFO - 2016-12-03 15:59:27 --> Router Class Initialized
INFO - 2016-12-03 15:59:27 --> Output Class Initialized
INFO - 2016-12-03 15:59:27 --> Security Class Initialized
DEBUG - 2016-12-03 15:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:59:27 --> Input Class Initialized
INFO - 2016-12-03 15:59:27 --> Language Class Initialized
ERROR - 2016-12-03 15:59:27 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-03 15:59:27 --> Config Class Initialized
INFO - 2016-12-03 15:59:27 --> Hooks Class Initialized
DEBUG - 2016-12-03 15:59:27 --> UTF-8 Support Enabled
INFO - 2016-12-03 15:59:27 --> Utf8 Class Initialized
INFO - 2016-12-03 15:59:27 --> URI Class Initialized
INFO - 2016-12-03 15:59:27 --> Router Class Initialized
INFO - 2016-12-03 15:59:27 --> Output Class Initialized
INFO - 2016-12-03 15:59:27 --> Security Class Initialized
DEBUG - 2016-12-03 15:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 15:59:27 --> Input Class Initialized
INFO - 2016-12-03 15:59:27 --> Language Class Initialized
INFO - 2016-12-03 15:59:27 --> Loader Class Initialized
INFO - 2016-12-03 15:59:27 --> Database Driver Class Initialized
INFO - 2016-12-03 15:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 15:59:27 --> Controller Class Initialized
INFO - 2016-12-03 15:59:27 --> Helper loaded: url_helper
DEBUG - 2016-12-03 15:59:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 15:59:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 15:59:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 15:59:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 15:59:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 15:59:27 --> Final output sent to browser
DEBUG - 2016-12-03 15:59:27 --> Total execution time: 0.0130
INFO - 2016-12-03 19:56:35 --> Config Class Initialized
INFO - 2016-12-03 19:56:35 --> Hooks Class Initialized
DEBUG - 2016-12-03 19:56:35 --> UTF-8 Support Enabled
INFO - 2016-12-03 19:56:35 --> Utf8 Class Initialized
INFO - 2016-12-03 19:56:35 --> URI Class Initialized
DEBUG - 2016-12-03 19:56:35 --> No URI present. Default controller set.
INFO - 2016-12-03 19:56:35 --> Router Class Initialized
INFO - 2016-12-03 19:56:35 --> Output Class Initialized
INFO - 2016-12-03 19:56:35 --> Security Class Initialized
DEBUG - 2016-12-03 19:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 19:56:35 --> Input Class Initialized
INFO - 2016-12-03 19:56:35 --> Language Class Initialized
INFO - 2016-12-03 19:56:35 --> Loader Class Initialized
INFO - 2016-12-03 19:56:35 --> Database Driver Class Initialized
INFO - 2016-12-03 19:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 19:56:35 --> Controller Class Initialized
INFO - 2016-12-03 19:56:35 --> Helper loaded: url_helper
DEBUG - 2016-12-03 19:56:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 19:56:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 19:56:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 19:56:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 19:56:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 19:56:35 --> Final output sent to browser
DEBUG - 2016-12-03 19:56:35 --> Total execution time: 0.4428
INFO - 2016-12-03 19:56:41 --> Config Class Initialized
INFO - 2016-12-03 19:56:41 --> Hooks Class Initialized
DEBUG - 2016-12-03 19:56:41 --> UTF-8 Support Enabled
INFO - 2016-12-03 19:56:41 --> Utf8 Class Initialized
INFO - 2016-12-03 19:56:41 --> URI Class Initialized
INFO - 2016-12-03 19:56:41 --> Router Class Initialized
INFO - 2016-12-03 19:56:41 --> Output Class Initialized
INFO - 2016-12-03 19:56:41 --> Security Class Initialized
DEBUG - 2016-12-03 19:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 19:56:41 --> Input Class Initialized
INFO - 2016-12-03 19:56:41 --> Language Class Initialized
INFO - 2016-12-03 19:56:41 --> Loader Class Initialized
INFO - 2016-12-03 19:56:41 --> Database Driver Class Initialized
INFO - 2016-12-03 19:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 19:56:41 --> Controller Class Initialized
INFO - 2016-12-03 19:56:41 --> Helper loaded: url_helper
DEBUG - 2016-12-03 19:56:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 19:56:43 --> Config Class Initialized
INFO - 2016-12-03 19:56:43 --> Hooks Class Initialized
DEBUG - 2016-12-03 19:56:43 --> UTF-8 Support Enabled
INFO - 2016-12-03 19:56:43 --> Utf8 Class Initialized
INFO - 2016-12-03 19:56:43 --> URI Class Initialized
INFO - 2016-12-03 19:56:43 --> Router Class Initialized
INFO - 2016-12-03 19:56:43 --> Output Class Initialized
INFO - 2016-12-03 19:56:43 --> Security Class Initialized
DEBUG - 2016-12-03 19:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 19:56:43 --> Input Class Initialized
INFO - 2016-12-03 19:56:43 --> Language Class Initialized
INFO - 2016-12-03 19:56:43 --> Loader Class Initialized
INFO - 2016-12-03 19:56:43 --> Database Driver Class Initialized
INFO - 2016-12-03 19:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 19:56:43 --> Controller Class Initialized
DEBUG - 2016-12-03 19:56:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 19:56:43 --> Helper loaded: url_helper
INFO - 2016-12-03 19:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 19:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 19:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-03 19:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-03 19:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 19:56:43 --> Final output sent to browser
DEBUG - 2016-12-03 19:56:43 --> Total execution time: 0.0264
INFO - 2016-12-03 19:56:44 --> Config Class Initialized
INFO - 2016-12-03 19:56:44 --> Hooks Class Initialized
DEBUG - 2016-12-03 19:56:44 --> UTF-8 Support Enabled
INFO - 2016-12-03 19:56:44 --> Utf8 Class Initialized
INFO - 2016-12-03 19:56:44 --> URI Class Initialized
INFO - 2016-12-03 19:56:44 --> Router Class Initialized
INFO - 2016-12-03 19:56:44 --> Output Class Initialized
INFO - 2016-12-03 19:56:44 --> Security Class Initialized
DEBUG - 2016-12-03 19:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 19:56:44 --> Input Class Initialized
INFO - 2016-12-03 19:56:44 --> Language Class Initialized
INFO - 2016-12-03 19:56:44 --> Loader Class Initialized
INFO - 2016-12-03 19:56:44 --> Database Driver Class Initialized
INFO - 2016-12-03 19:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 19:56:44 --> Controller Class Initialized
INFO - 2016-12-03 19:56:44 --> Helper loaded: url_helper
DEBUG - 2016-12-03 19:56:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 19:56:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 19:56:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 19:56:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 19:56:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 19:56:44 --> Final output sent to browser
DEBUG - 2016-12-03 19:56:44 --> Total execution time: 0.0185
INFO - 2016-12-03 19:56:47 --> Config Class Initialized
INFO - 2016-12-03 19:56:47 --> Hooks Class Initialized
DEBUG - 2016-12-03 19:56:47 --> UTF-8 Support Enabled
INFO - 2016-12-03 19:56:47 --> Utf8 Class Initialized
INFO - 2016-12-03 19:56:47 --> URI Class Initialized
INFO - 2016-12-03 19:56:47 --> Router Class Initialized
INFO - 2016-12-03 19:56:47 --> Output Class Initialized
INFO - 2016-12-03 19:56:47 --> Security Class Initialized
DEBUG - 2016-12-03 19:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 19:56:47 --> Input Class Initialized
INFO - 2016-12-03 19:56:47 --> Language Class Initialized
INFO - 2016-12-03 19:56:47 --> Loader Class Initialized
INFO - 2016-12-03 19:56:47 --> Database Driver Class Initialized
INFO - 2016-12-03 19:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 19:56:47 --> Controller Class Initialized
INFO - 2016-12-03 19:56:47 --> Helper loaded: date_helper
DEBUG - 2016-12-03 19:56:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 19:56:47 --> Helper loaded: url_helper
INFO - 2016-12-03 19:56:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 19:56:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 19:56:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 19:56:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 19:56:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 19:56:47 --> Final output sent to browser
DEBUG - 2016-12-03 19:56:47 --> Total execution time: 0.0527
INFO - 2016-12-03 19:56:48 --> Config Class Initialized
INFO - 2016-12-03 19:56:48 --> Hooks Class Initialized
DEBUG - 2016-12-03 19:56:48 --> UTF-8 Support Enabled
INFO - 2016-12-03 19:56:48 --> Utf8 Class Initialized
INFO - 2016-12-03 19:56:48 --> URI Class Initialized
INFO - 2016-12-03 19:56:48 --> Router Class Initialized
INFO - 2016-12-03 19:56:48 --> Output Class Initialized
INFO - 2016-12-03 19:56:48 --> Security Class Initialized
DEBUG - 2016-12-03 19:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 19:56:48 --> Input Class Initialized
INFO - 2016-12-03 19:56:48 --> Language Class Initialized
INFO - 2016-12-03 19:56:48 --> Loader Class Initialized
INFO - 2016-12-03 19:56:48 --> Database Driver Class Initialized
INFO - 2016-12-03 19:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 19:56:48 --> Controller Class Initialized
INFO - 2016-12-03 19:56:48 --> Helper loaded: url_helper
DEBUG - 2016-12-03 19:56:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 19:56:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 19:56:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 19:56:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 19:56:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 19:56:48 --> Final output sent to browser
DEBUG - 2016-12-03 19:56:48 --> Total execution time: 0.0133
INFO - 2016-12-03 19:57:01 --> Config Class Initialized
INFO - 2016-12-03 19:57:01 --> Hooks Class Initialized
DEBUG - 2016-12-03 19:57:01 --> UTF-8 Support Enabled
INFO - 2016-12-03 19:57:01 --> Utf8 Class Initialized
INFO - 2016-12-03 19:57:01 --> URI Class Initialized
INFO - 2016-12-03 19:57:01 --> Router Class Initialized
INFO - 2016-12-03 19:57:01 --> Output Class Initialized
INFO - 2016-12-03 19:57:01 --> Security Class Initialized
DEBUG - 2016-12-03 19:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 19:57:01 --> Input Class Initialized
INFO - 2016-12-03 19:57:01 --> Language Class Initialized
INFO - 2016-12-03 19:57:01 --> Loader Class Initialized
INFO - 2016-12-03 19:57:01 --> Database Driver Class Initialized
INFO - 2016-12-03 19:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 19:57:01 --> Controller Class Initialized
INFO - 2016-12-03 19:57:01 --> Helper loaded: date_helper
INFO - 2016-12-03 19:57:01 --> Helper loaded: url_helper
DEBUG - 2016-12-03 19:57:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 19:57:01 --> Helper loaded: form_helper
INFO - 2016-12-03 19:57:01 --> Form Validation Class Initialized
INFO - 2016-12-03 19:57:01 --> Final output sent to browser
DEBUG - 2016-12-03 19:57:01 --> Total execution time: 0.0314
INFO - 2016-12-03 19:57:07 --> Config Class Initialized
INFO - 2016-12-03 19:57:07 --> Hooks Class Initialized
DEBUG - 2016-12-03 19:57:07 --> UTF-8 Support Enabled
INFO - 2016-12-03 19:57:07 --> Utf8 Class Initialized
INFO - 2016-12-03 19:57:07 --> URI Class Initialized
INFO - 2016-12-03 19:57:07 --> Router Class Initialized
INFO - 2016-12-03 19:57:07 --> Output Class Initialized
INFO - 2016-12-03 19:57:07 --> Security Class Initialized
DEBUG - 2016-12-03 19:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 19:57:07 --> Input Class Initialized
INFO - 2016-12-03 19:57:07 --> Language Class Initialized
INFO - 2016-12-03 19:57:07 --> Loader Class Initialized
INFO - 2016-12-03 19:57:07 --> Database Driver Class Initialized
INFO - 2016-12-03 19:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 19:57:07 --> Controller Class Initialized
INFO - 2016-12-03 19:57:07 --> Helper loaded: date_helper
INFO - 2016-12-03 19:57:07 --> Helper loaded: url_helper
DEBUG - 2016-12-03 19:57:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 19:57:07 --> Helper loaded: form_helper
INFO - 2016-12-03 19:57:07 --> Form Validation Class Initialized
INFO - 2016-12-03 19:57:07 --> Final output sent to browser
DEBUG - 2016-12-03 19:57:07 --> Total execution time: 0.0157
INFO - 2016-12-03 19:57:16 --> Config Class Initialized
INFO - 2016-12-03 19:57:16 --> Hooks Class Initialized
DEBUG - 2016-12-03 19:57:16 --> UTF-8 Support Enabled
INFO - 2016-12-03 19:57:16 --> Utf8 Class Initialized
INFO - 2016-12-03 19:57:16 --> URI Class Initialized
INFO - 2016-12-03 19:57:16 --> Router Class Initialized
INFO - 2016-12-03 19:57:16 --> Output Class Initialized
INFO - 2016-12-03 19:57:16 --> Security Class Initialized
DEBUG - 2016-12-03 19:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 19:57:16 --> Input Class Initialized
INFO - 2016-12-03 19:57:16 --> Language Class Initialized
INFO - 2016-12-03 19:57:16 --> Loader Class Initialized
INFO - 2016-12-03 19:57:16 --> Database Driver Class Initialized
INFO - 2016-12-03 19:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 19:57:16 --> Controller Class Initialized
INFO - 2016-12-03 19:57:16 --> Helper loaded: date_helper
INFO - 2016-12-03 19:57:16 --> Helper loaded: url_helper
DEBUG - 2016-12-03 19:57:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 19:57:16 --> Helper loaded: form_helper
INFO - 2016-12-03 19:57:16 --> Form Validation Class Initialized
INFO - 2016-12-03 19:57:16 --> Final output sent to browser
DEBUG - 2016-12-03 19:57:16 --> Total execution time: 0.0147
INFO - 2016-12-03 19:57:24 --> Config Class Initialized
INFO - 2016-12-03 19:57:24 --> Hooks Class Initialized
DEBUG - 2016-12-03 19:57:24 --> UTF-8 Support Enabled
INFO - 2016-12-03 19:57:24 --> Utf8 Class Initialized
INFO - 2016-12-03 19:57:24 --> URI Class Initialized
INFO - 2016-12-03 19:57:24 --> Router Class Initialized
INFO - 2016-12-03 19:57:24 --> Output Class Initialized
INFO - 2016-12-03 19:57:24 --> Security Class Initialized
DEBUG - 2016-12-03 19:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 19:57:24 --> Input Class Initialized
INFO - 2016-12-03 19:57:24 --> Language Class Initialized
INFO - 2016-12-03 19:57:24 --> Loader Class Initialized
INFO - 2016-12-03 19:57:24 --> Database Driver Class Initialized
INFO - 2016-12-03 19:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 19:57:24 --> Controller Class Initialized
DEBUG - 2016-12-03 19:57:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 19:57:24 --> Helper loaded: url_helper
INFO - 2016-12-03 19:57:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 19:57:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-03 19:57:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 19:57:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-03 19:57:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-03 19:57:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 19:57:24 --> Final output sent to browser
DEBUG - 2016-12-03 19:57:24 --> Total execution time: 0.0125
INFO - 2016-12-03 19:57:24 --> Config Class Initialized
INFO - 2016-12-03 19:57:24 --> Hooks Class Initialized
DEBUG - 2016-12-03 19:57:24 --> UTF-8 Support Enabled
INFO - 2016-12-03 19:57:24 --> Utf8 Class Initialized
INFO - 2016-12-03 19:57:24 --> URI Class Initialized
INFO - 2016-12-03 19:57:24 --> Router Class Initialized
INFO - 2016-12-03 19:57:24 --> Output Class Initialized
INFO - 2016-12-03 19:57:24 --> Security Class Initialized
DEBUG - 2016-12-03 19:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 19:57:24 --> Input Class Initialized
INFO - 2016-12-03 19:57:24 --> Language Class Initialized
INFO - 2016-12-03 19:57:24 --> Loader Class Initialized
INFO - 2016-12-03 19:57:24 --> Database Driver Class Initialized
INFO - 2016-12-03 19:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 19:57:24 --> Controller Class Initialized
INFO - 2016-12-03 19:57:24 --> Helper loaded: url_helper
DEBUG - 2016-12-03 19:57:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 19:57:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 19:57:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 19:57:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 19:57:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 19:57:24 --> Final output sent to browser
DEBUG - 2016-12-03 19:57:24 --> Total execution time: 0.0134
INFO - 2016-12-03 19:57:33 --> Config Class Initialized
INFO - 2016-12-03 19:57:33 --> Hooks Class Initialized
DEBUG - 2016-12-03 19:57:33 --> UTF-8 Support Enabled
INFO - 2016-12-03 19:57:33 --> Utf8 Class Initialized
INFO - 2016-12-03 19:57:33 --> URI Class Initialized
INFO - 2016-12-03 19:57:33 --> Router Class Initialized
INFO - 2016-12-03 19:57:33 --> Output Class Initialized
INFO - 2016-12-03 19:57:33 --> Security Class Initialized
DEBUG - 2016-12-03 19:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 19:57:33 --> Input Class Initialized
INFO - 2016-12-03 19:57:33 --> Language Class Initialized
INFO - 2016-12-03 19:57:33 --> Loader Class Initialized
INFO - 2016-12-03 19:57:33 --> Database Driver Class Initialized
INFO - 2016-12-03 19:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 19:57:33 --> Controller Class Initialized
DEBUG - 2016-12-03 19:57:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 19:57:33 --> Helper loaded: url_helper
INFO - 2016-12-03 19:57:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 19:57:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 19:57:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-03 19:57:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 19:57:33 --> Final output sent to browser
DEBUG - 2016-12-03 19:57:33 --> Total execution time: 0.0121
INFO - 2016-12-03 19:57:33 --> Config Class Initialized
INFO - 2016-12-03 19:57:33 --> Hooks Class Initialized
DEBUG - 2016-12-03 19:57:33 --> UTF-8 Support Enabled
INFO - 2016-12-03 19:57:33 --> Utf8 Class Initialized
INFO - 2016-12-03 19:57:33 --> URI Class Initialized
INFO - 2016-12-03 19:57:33 --> Router Class Initialized
INFO - 2016-12-03 19:57:33 --> Output Class Initialized
INFO - 2016-12-03 19:57:33 --> Security Class Initialized
DEBUG - 2016-12-03 19:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 19:57:33 --> Input Class Initialized
INFO - 2016-12-03 19:57:33 --> Language Class Initialized
INFO - 2016-12-03 19:57:33 --> Loader Class Initialized
INFO - 2016-12-03 19:57:33 --> Database Driver Class Initialized
INFO - 2016-12-03 19:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 19:57:33 --> Controller Class Initialized
INFO - 2016-12-03 19:57:33 --> Helper loaded: url_helper
DEBUG - 2016-12-03 19:57:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 19:57:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 19:57:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 19:57:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 19:57:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 19:57:33 --> Final output sent to browser
DEBUG - 2016-12-03 19:57:33 --> Total execution time: 0.0131
INFO - 2016-12-03 19:57:34 --> Config Class Initialized
INFO - 2016-12-03 19:57:34 --> Hooks Class Initialized
DEBUG - 2016-12-03 19:57:34 --> UTF-8 Support Enabled
INFO - 2016-12-03 19:57:34 --> Utf8 Class Initialized
INFO - 2016-12-03 19:57:34 --> URI Class Initialized
INFO - 2016-12-03 19:57:34 --> Router Class Initialized
INFO - 2016-12-03 19:57:34 --> Output Class Initialized
INFO - 2016-12-03 19:57:34 --> Security Class Initialized
DEBUG - 2016-12-03 19:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 19:57:34 --> Input Class Initialized
INFO - 2016-12-03 19:57:34 --> Language Class Initialized
INFO - 2016-12-03 19:57:34 --> Loader Class Initialized
INFO - 2016-12-03 19:57:34 --> Database Driver Class Initialized
INFO - 2016-12-03 19:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 19:57:34 --> Controller Class Initialized
DEBUG - 2016-12-03 19:57:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 19:57:34 --> Helper loaded: url_helper
INFO - 2016-12-03 19:57:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 19:57:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 19:57:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-03 19:57:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-03 19:57:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 19:57:34 --> Final output sent to browser
DEBUG - 2016-12-03 19:57:34 --> Total execution time: 0.0143
INFO - 2016-12-03 19:57:34 --> Config Class Initialized
INFO - 2016-12-03 19:57:34 --> Hooks Class Initialized
DEBUG - 2016-12-03 19:57:34 --> UTF-8 Support Enabled
INFO - 2016-12-03 19:57:34 --> Utf8 Class Initialized
INFO - 2016-12-03 19:57:34 --> URI Class Initialized
INFO - 2016-12-03 19:57:34 --> Router Class Initialized
INFO - 2016-12-03 19:57:34 --> Output Class Initialized
INFO - 2016-12-03 19:57:34 --> Security Class Initialized
DEBUG - 2016-12-03 19:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 19:57:34 --> Input Class Initialized
INFO - 2016-12-03 19:57:34 --> Language Class Initialized
INFO - 2016-12-03 19:57:34 --> Loader Class Initialized
INFO - 2016-12-03 19:57:34 --> Database Driver Class Initialized
INFO - 2016-12-03 19:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 19:57:34 --> Controller Class Initialized
INFO - 2016-12-03 19:57:34 --> Helper loaded: url_helper
DEBUG - 2016-12-03 19:57:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 19:57:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 19:57:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 19:57:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 19:57:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 19:57:34 --> Final output sent to browser
DEBUG - 2016-12-03 19:57:34 --> Total execution time: 0.0131
INFO - 2016-12-03 19:57:35 --> Config Class Initialized
INFO - 2016-12-03 19:57:35 --> Hooks Class Initialized
DEBUG - 2016-12-03 19:57:35 --> UTF-8 Support Enabled
INFO - 2016-12-03 19:57:35 --> Utf8 Class Initialized
INFO - 2016-12-03 19:57:35 --> URI Class Initialized
INFO - 2016-12-03 19:57:35 --> Router Class Initialized
INFO - 2016-12-03 19:57:35 --> Output Class Initialized
INFO - 2016-12-03 19:57:35 --> Security Class Initialized
DEBUG - 2016-12-03 19:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 19:57:35 --> Input Class Initialized
INFO - 2016-12-03 19:57:35 --> Language Class Initialized
INFO - 2016-12-03 19:57:35 --> Loader Class Initialized
INFO - 2016-12-03 19:57:35 --> Database Driver Class Initialized
INFO - 2016-12-03 19:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 19:57:35 --> Controller Class Initialized
INFO - 2016-12-03 19:57:35 --> Helper loaded: date_helper
DEBUG - 2016-12-03 19:57:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 19:57:35 --> Helper loaded: url_helper
INFO - 2016-12-03 19:57:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 19:57:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-03 19:57:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-03 19:57:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-03 19:57:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 19:57:35 --> Final output sent to browser
DEBUG - 2016-12-03 19:57:35 --> Total execution time: 0.0167
INFO - 2016-12-03 19:57:35 --> Config Class Initialized
INFO - 2016-12-03 19:57:35 --> Hooks Class Initialized
DEBUG - 2016-12-03 19:57:35 --> UTF-8 Support Enabled
INFO - 2016-12-03 19:57:35 --> Utf8 Class Initialized
INFO - 2016-12-03 19:57:35 --> URI Class Initialized
INFO - 2016-12-03 19:57:35 --> Router Class Initialized
INFO - 2016-12-03 19:57:35 --> Output Class Initialized
INFO - 2016-12-03 19:57:35 --> Security Class Initialized
DEBUG - 2016-12-03 19:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-03 19:57:35 --> Input Class Initialized
INFO - 2016-12-03 19:57:35 --> Language Class Initialized
INFO - 2016-12-03 19:57:35 --> Loader Class Initialized
INFO - 2016-12-03 19:57:35 --> Database Driver Class Initialized
INFO - 2016-12-03 19:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-03 19:57:35 --> Controller Class Initialized
INFO - 2016-12-03 19:57:35 --> Helper loaded: url_helper
DEBUG - 2016-12-03 19:57:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-03 19:57:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-03 19:57:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-03 19:57:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-03 19:57:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-03 19:57:35 --> Final output sent to browser
DEBUG - 2016-12-03 19:57:35 --> Total execution time: 0.0131

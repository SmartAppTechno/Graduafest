<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-10 00:40:17 --> Config Class Initialized
INFO - 2017-01-10 00:40:17 --> Hooks Class Initialized
DEBUG - 2017-01-10 00:40:17 --> UTF-8 Support Enabled
INFO - 2017-01-10 00:40:17 --> Utf8 Class Initialized
INFO - 2017-01-10 00:40:17 --> URI Class Initialized
INFO - 2017-01-10 00:40:17 --> Router Class Initialized
INFO - 2017-01-10 00:40:17 --> Output Class Initialized
INFO - 2017-01-10 00:40:17 --> Security Class Initialized
DEBUG - 2017-01-10 00:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 00:40:17 --> Input Class Initialized
INFO - 2017-01-10 00:40:17 --> Language Class Initialized
INFO - 2017-01-10 00:40:17 --> Loader Class Initialized
INFO - 2017-01-10 00:40:17 --> Database Driver Class Initialized
INFO - 2017-01-10 00:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 00:40:18 --> Controller Class Initialized
INFO - 2017-01-10 00:40:18 --> Helper loaded: url_helper
DEBUG - 2017-01-10 00:40:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 00:40:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 00:40:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 00:40:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 00:40:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 00:40:18 --> Final output sent to browser
DEBUG - 2017-01-10 00:40:18 --> Total execution time: 1.7669
INFO - 2017-01-10 01:28:51 --> Config Class Initialized
INFO - 2017-01-10 01:28:51 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:28:51 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:28:51 --> Utf8 Class Initialized
INFO - 2017-01-10 01:28:51 --> URI Class Initialized
DEBUG - 2017-01-10 01:28:51 --> No URI present. Default controller set.
INFO - 2017-01-10 01:28:51 --> Router Class Initialized
INFO - 2017-01-10 01:28:51 --> Output Class Initialized
INFO - 2017-01-10 01:28:51 --> Security Class Initialized
DEBUG - 2017-01-10 01:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:28:52 --> Input Class Initialized
INFO - 2017-01-10 01:28:52 --> Language Class Initialized
INFO - 2017-01-10 01:28:52 --> Loader Class Initialized
INFO - 2017-01-10 01:28:52 --> Database Driver Class Initialized
INFO - 2017-01-10 01:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:28:52 --> Controller Class Initialized
INFO - 2017-01-10 01:28:52 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:28:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:28:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 01:28:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 01:28:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 01:28:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 01:28:52 --> Final output sent to browser
DEBUG - 2017-01-10 01:28:52 --> Total execution time: 1.2427
INFO - 2017-01-10 01:29:01 --> Config Class Initialized
INFO - 2017-01-10 01:29:01 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:29:01 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:29:01 --> Utf8 Class Initialized
INFO - 2017-01-10 01:29:01 --> URI Class Initialized
INFO - 2017-01-10 01:29:01 --> Router Class Initialized
INFO - 2017-01-10 01:29:02 --> Output Class Initialized
INFO - 2017-01-10 01:29:02 --> Security Class Initialized
DEBUG - 2017-01-10 01:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:29:02 --> Input Class Initialized
INFO - 2017-01-10 01:29:02 --> Language Class Initialized
INFO - 2017-01-10 01:29:02 --> Loader Class Initialized
INFO - 2017-01-10 01:29:02 --> Database Driver Class Initialized
INFO - 2017-01-10 01:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:29:02 --> Controller Class Initialized
INFO - 2017-01-10 01:29:02 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:29:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:29:02 --> Helper loaded: form_helper
INFO - 2017-01-10 01:29:02 --> Form Validation Class Initialized
INFO - 2017-01-10 01:29:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 01:29:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-10 01:29:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 01:29:02 --> Final output sent to browser
DEBUG - 2017-01-10 01:29:02 --> Total execution time: 0.4097
INFO - 2017-01-10 01:29:06 --> Config Class Initialized
INFO - 2017-01-10 01:29:06 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:29:06 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:29:06 --> Utf8 Class Initialized
INFO - 2017-01-10 01:29:06 --> URI Class Initialized
INFO - 2017-01-10 01:29:06 --> Router Class Initialized
INFO - 2017-01-10 01:29:06 --> Output Class Initialized
INFO - 2017-01-10 01:29:06 --> Security Class Initialized
DEBUG - 2017-01-10 01:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:29:06 --> Input Class Initialized
INFO - 2017-01-10 01:29:06 --> Language Class Initialized
INFO - 2017-01-10 01:29:06 --> Loader Class Initialized
INFO - 2017-01-10 01:29:06 --> Database Driver Class Initialized
INFO - 2017-01-10 01:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:29:06 --> Controller Class Initialized
INFO - 2017-01-10 01:29:06 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:29:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:29:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 01:29:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 01:29:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 01:29:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 01:29:06 --> Final output sent to browser
DEBUG - 2017-01-10 01:29:06 --> Total execution time: 0.0134
INFO - 2017-01-10 01:29:08 --> Config Class Initialized
INFO - 2017-01-10 01:29:08 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:29:08 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:29:08 --> Utf8 Class Initialized
INFO - 2017-01-10 01:29:08 --> URI Class Initialized
INFO - 2017-01-10 01:29:08 --> Router Class Initialized
INFO - 2017-01-10 01:29:08 --> Output Class Initialized
INFO - 2017-01-10 01:29:08 --> Security Class Initialized
DEBUG - 2017-01-10 01:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:29:08 --> Input Class Initialized
INFO - 2017-01-10 01:29:08 --> Language Class Initialized
INFO - 2017-01-10 01:29:08 --> Loader Class Initialized
INFO - 2017-01-10 01:29:08 --> Database Driver Class Initialized
INFO - 2017-01-10 01:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:29:08 --> Controller Class Initialized
INFO - 2017-01-10 01:29:08 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:29:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:29:08 --> Helper loaded: form_helper
INFO - 2017-01-10 01:29:08 --> Form Validation Class Initialized
INFO - 2017-01-10 01:29:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-10 01:29:08 --> Config Class Initialized
INFO - 2017-01-10 01:29:08 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:29:08 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:29:08 --> Utf8 Class Initialized
INFO - 2017-01-10 01:29:08 --> URI Class Initialized
INFO - 2017-01-10 01:29:08 --> Router Class Initialized
INFO - 2017-01-10 01:29:08 --> Output Class Initialized
INFO - 2017-01-10 01:29:08 --> Security Class Initialized
DEBUG - 2017-01-10 01:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:29:08 --> Input Class Initialized
INFO - 2017-01-10 01:29:08 --> Language Class Initialized
INFO - 2017-01-10 01:29:08 --> Loader Class Initialized
INFO - 2017-01-10 01:29:08 --> Database Driver Class Initialized
INFO - 2017-01-10 01:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:29:08 --> Controller Class Initialized
INFO - 2017-01-10 01:29:08 --> Helper loaded: date_helper
INFO - 2017-01-10 01:29:08 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:29:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:29:08 --> Helper loaded: form_helper
INFO - 2017-01-10 01:29:08 --> Form Validation Class Initialized
INFO - 2017-01-10 01:29:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 01:29:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 01:29:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-10 01:29:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-10 01:29:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 01:29:08 --> Final output sent to browser
DEBUG - 2017-01-10 01:29:08 --> Total execution time: 0.1422
INFO - 2017-01-10 01:29:09 --> Config Class Initialized
INFO - 2017-01-10 01:29:09 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:29:09 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:29:09 --> Utf8 Class Initialized
INFO - 2017-01-10 01:29:09 --> URI Class Initialized
INFO - 2017-01-10 01:29:09 --> Router Class Initialized
INFO - 2017-01-10 01:29:09 --> Output Class Initialized
INFO - 2017-01-10 01:29:09 --> Security Class Initialized
DEBUG - 2017-01-10 01:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:29:09 --> Input Class Initialized
INFO - 2017-01-10 01:29:09 --> Language Class Initialized
INFO - 2017-01-10 01:29:09 --> Loader Class Initialized
INFO - 2017-01-10 01:29:09 --> Database Driver Class Initialized
INFO - 2017-01-10 01:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:29:09 --> Controller Class Initialized
INFO - 2017-01-10 01:29:09 --> Helper loaded: date_helper
INFO - 2017-01-10 01:29:09 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:29:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:29:09 --> Helper loaded: form_helper
INFO - 2017-01-10 01:29:09 --> Form Validation Class Initialized
INFO - 2017-01-10 01:29:09 --> Final output sent to browser
DEBUG - 2017-01-10 01:29:09 --> Total execution time: 0.0153
INFO - 2017-01-10 01:29:13 --> Config Class Initialized
INFO - 2017-01-10 01:29:13 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:29:13 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:29:13 --> Utf8 Class Initialized
INFO - 2017-01-10 01:29:13 --> URI Class Initialized
INFO - 2017-01-10 01:29:13 --> Router Class Initialized
INFO - 2017-01-10 01:29:13 --> Output Class Initialized
INFO - 2017-01-10 01:29:13 --> Security Class Initialized
DEBUG - 2017-01-10 01:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:29:13 --> Input Class Initialized
INFO - 2017-01-10 01:29:13 --> Language Class Initialized
INFO - 2017-01-10 01:29:13 --> Loader Class Initialized
INFO - 2017-01-10 01:29:13 --> Database Driver Class Initialized
INFO - 2017-01-10 01:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:29:13 --> Controller Class Initialized
INFO - 2017-01-10 01:29:13 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:29:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:29:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 01:29:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 01:29:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 01:29:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 01:29:13 --> Final output sent to browser
DEBUG - 2017-01-10 01:29:13 --> Total execution time: 0.0135
INFO - 2017-01-10 01:29:19 --> Config Class Initialized
INFO - 2017-01-10 01:29:19 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:29:19 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:29:19 --> Utf8 Class Initialized
INFO - 2017-01-10 01:29:19 --> URI Class Initialized
INFO - 2017-01-10 01:29:19 --> Router Class Initialized
INFO - 2017-01-10 01:29:19 --> Output Class Initialized
INFO - 2017-01-10 01:29:19 --> Security Class Initialized
DEBUG - 2017-01-10 01:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:29:19 --> Input Class Initialized
INFO - 2017-01-10 01:29:19 --> Language Class Initialized
INFO - 2017-01-10 01:29:19 --> Loader Class Initialized
INFO - 2017-01-10 01:29:19 --> Database Driver Class Initialized
INFO - 2017-01-10 01:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:29:19 --> Controller Class Initialized
INFO - 2017-01-10 01:29:19 --> Upload Class Initialized
INFO - 2017-01-10 01:29:19 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:29:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:29:19 --> Helper loaded: form_helper
INFO - 2017-01-10 01:29:19 --> Form Validation Class Initialized
INFO - 2017-01-10 01:29:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 01:29:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 01:29:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-10 01:29:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-10 01:29:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-10 01:29:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 01:29:19 --> Final output sent to browser
DEBUG - 2017-01-10 01:29:19 --> Total execution time: 0.1544
INFO - 2017-01-10 01:29:21 --> Config Class Initialized
INFO - 2017-01-10 01:29:21 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:29:21 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:29:21 --> Utf8 Class Initialized
INFO - 2017-01-10 01:29:21 --> URI Class Initialized
INFO - 2017-01-10 01:29:21 --> Router Class Initialized
INFO - 2017-01-10 01:29:21 --> Output Class Initialized
INFO - 2017-01-10 01:29:21 --> Security Class Initialized
DEBUG - 2017-01-10 01:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:29:21 --> Input Class Initialized
INFO - 2017-01-10 01:29:21 --> Language Class Initialized
INFO - 2017-01-10 01:29:21 --> Loader Class Initialized
INFO - 2017-01-10 01:29:21 --> Database Driver Class Initialized
INFO - 2017-01-10 01:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:29:22 --> Controller Class Initialized
INFO - 2017-01-10 01:29:22 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:29:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:29:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 01:29:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 01:29:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 01:29:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 01:29:22 --> Final output sent to browser
DEBUG - 2017-01-10 01:29:22 --> Total execution time: 0.0139
INFO - 2017-01-10 01:29:40 --> Config Class Initialized
INFO - 2017-01-10 01:29:40 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:29:40 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:29:40 --> Utf8 Class Initialized
INFO - 2017-01-10 01:29:40 --> URI Class Initialized
INFO - 2017-01-10 01:29:40 --> Router Class Initialized
INFO - 2017-01-10 01:29:40 --> Output Class Initialized
INFO - 2017-01-10 01:29:40 --> Security Class Initialized
DEBUG - 2017-01-10 01:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:29:40 --> Input Class Initialized
INFO - 2017-01-10 01:29:40 --> Language Class Initialized
INFO - 2017-01-10 01:29:40 --> Loader Class Initialized
INFO - 2017-01-10 01:29:40 --> Database Driver Class Initialized
INFO - 2017-01-10 01:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:29:40 --> Controller Class Initialized
INFO - 2017-01-10 01:29:40 --> Upload Class Initialized
INFO - 2017-01-10 01:29:40 --> Helper loaded: date_helper
INFO - 2017-01-10 01:29:40 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:29:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:29:40 --> Helper loaded: form_helper
INFO - 2017-01-10 01:29:40 --> Form Validation Class Initialized
INFO - 2017-01-10 01:29:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 01:29:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 01:29:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-10 01:29:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-10 01:29:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-10 01:29:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 01:29:40 --> Final output sent to browser
DEBUG - 2017-01-10 01:29:40 --> Total execution time: 0.2084
INFO - 2017-01-10 01:29:40 --> Config Class Initialized
INFO - 2017-01-10 01:29:40 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:29:40 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:29:40 --> Utf8 Class Initialized
INFO - 2017-01-10 01:29:40 --> URI Class Initialized
INFO - 2017-01-10 01:29:40 --> Router Class Initialized
INFO - 2017-01-10 01:29:40 --> Output Class Initialized
INFO - 2017-01-10 01:29:40 --> Security Class Initialized
DEBUG - 2017-01-10 01:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:29:40 --> Input Class Initialized
INFO - 2017-01-10 01:29:40 --> Language Class Initialized
INFO - 2017-01-10 01:29:40 --> Loader Class Initialized
INFO - 2017-01-10 01:29:40 --> Database Driver Class Initialized
INFO - 2017-01-10 01:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:29:40 --> Controller Class Initialized
INFO - 2017-01-10 01:29:40 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:29:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:29:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 01:29:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 01:29:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 01:29:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 01:29:40 --> Final output sent to browser
DEBUG - 2017-01-10 01:29:40 --> Total execution time: 0.0141
INFO - 2017-01-10 01:30:01 --> Config Class Initialized
INFO - 2017-01-10 01:30:01 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:30:01 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:30:01 --> Utf8 Class Initialized
INFO - 2017-01-10 01:30:01 --> URI Class Initialized
INFO - 2017-01-10 01:30:01 --> Router Class Initialized
INFO - 2017-01-10 01:30:01 --> Output Class Initialized
INFO - 2017-01-10 01:30:01 --> Security Class Initialized
DEBUG - 2017-01-10 01:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:30:01 --> Input Class Initialized
INFO - 2017-01-10 01:30:01 --> Language Class Initialized
INFO - 2017-01-10 01:30:01 --> Loader Class Initialized
INFO - 2017-01-10 01:30:01 --> Database Driver Class Initialized
INFO - 2017-01-10 01:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:30:01 --> Controller Class Initialized
INFO - 2017-01-10 01:30:01 --> Helper loaded: date_helper
INFO - 2017-01-10 01:30:01 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:30:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:30:01 --> Helper loaded: form_helper
INFO - 2017-01-10 01:30:01 --> Form Validation Class Initialized
INFO - 2017-01-10 01:30:01 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 01:30:01 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 01:30:01 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-10 01:30:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-10 01:30:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 01:30:02 --> Final output sent to browser
DEBUG - 2017-01-10 01:30:02 --> Total execution time: 0.3672
INFO - 2017-01-10 01:30:02 --> Config Class Initialized
INFO - 2017-01-10 01:30:02 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:30:02 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:30:02 --> Utf8 Class Initialized
INFO - 2017-01-10 01:30:02 --> URI Class Initialized
INFO - 2017-01-10 01:30:02 --> Router Class Initialized
INFO - 2017-01-10 01:30:02 --> Output Class Initialized
INFO - 2017-01-10 01:30:02 --> Security Class Initialized
DEBUG - 2017-01-10 01:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:30:02 --> Input Class Initialized
INFO - 2017-01-10 01:30:02 --> Language Class Initialized
INFO - 2017-01-10 01:30:02 --> Loader Class Initialized
INFO - 2017-01-10 01:30:02 --> Database Driver Class Initialized
INFO - 2017-01-10 01:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:30:02 --> Controller Class Initialized
INFO - 2017-01-10 01:30:02 --> Helper loaded: date_helper
INFO - 2017-01-10 01:30:02 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:30:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:30:02 --> Helper loaded: form_helper
INFO - 2017-01-10 01:30:02 --> Form Validation Class Initialized
INFO - 2017-01-10 01:30:02 --> Final output sent to browser
DEBUG - 2017-01-10 01:30:02 --> Total execution time: 0.0146
INFO - 2017-01-10 01:30:02 --> Config Class Initialized
INFO - 2017-01-10 01:30:02 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:30:02 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:30:02 --> Utf8 Class Initialized
INFO - 2017-01-10 01:30:02 --> URI Class Initialized
INFO - 2017-01-10 01:30:02 --> Router Class Initialized
INFO - 2017-01-10 01:30:02 --> Output Class Initialized
INFO - 2017-01-10 01:30:02 --> Security Class Initialized
DEBUG - 2017-01-10 01:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:30:02 --> Input Class Initialized
INFO - 2017-01-10 01:30:02 --> Language Class Initialized
INFO - 2017-01-10 01:30:02 --> Loader Class Initialized
INFO - 2017-01-10 01:30:02 --> Database Driver Class Initialized
INFO - 2017-01-10 01:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:30:02 --> Controller Class Initialized
INFO - 2017-01-10 01:30:02 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:30:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:30:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 01:30:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 01:30:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 01:30:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 01:30:02 --> Final output sent to browser
DEBUG - 2017-01-10 01:30:02 --> Total execution time: 0.0132
INFO - 2017-01-10 01:30:07 --> Config Class Initialized
INFO - 2017-01-10 01:30:07 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:30:07 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:30:07 --> Utf8 Class Initialized
INFO - 2017-01-10 01:30:07 --> URI Class Initialized
INFO - 2017-01-10 01:30:07 --> Router Class Initialized
INFO - 2017-01-10 01:30:07 --> Output Class Initialized
INFO - 2017-01-10 01:30:07 --> Security Class Initialized
DEBUG - 2017-01-10 01:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:30:07 --> Input Class Initialized
INFO - 2017-01-10 01:30:07 --> Language Class Initialized
INFO - 2017-01-10 01:30:07 --> Loader Class Initialized
INFO - 2017-01-10 01:30:08 --> Database Driver Class Initialized
INFO - 2017-01-10 01:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:30:08 --> Controller Class Initialized
INFO - 2017-01-10 01:30:08 --> Helper loaded: date_helper
INFO - 2017-01-10 01:30:08 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:30:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:30:08 --> Helper loaded: form_helper
INFO - 2017-01-10 01:30:08 --> Form Validation Class Initialized
INFO - 2017-01-10 01:30:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 01:30:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 01:30:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pagos.php
INFO - 2017-01-10 01:30:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pagos.php
INFO - 2017-01-10 01:30:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 01:30:08 --> Final output sent to browser
DEBUG - 2017-01-10 01:30:08 --> Total execution time: 0.0556
INFO - 2017-01-10 01:30:08 --> Config Class Initialized
INFO - 2017-01-10 01:30:08 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:30:08 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:30:08 --> Utf8 Class Initialized
INFO - 2017-01-10 01:30:08 --> URI Class Initialized
INFO - 2017-01-10 01:30:08 --> Router Class Initialized
INFO - 2017-01-10 01:30:08 --> Output Class Initialized
INFO - 2017-01-10 01:30:08 --> Security Class Initialized
DEBUG - 2017-01-10 01:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:30:08 --> Input Class Initialized
INFO - 2017-01-10 01:30:08 --> Language Class Initialized
INFO - 2017-01-10 01:30:08 --> Loader Class Initialized
INFO - 2017-01-10 01:30:08 --> Database Driver Class Initialized
INFO - 2017-01-10 01:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:30:08 --> Controller Class Initialized
INFO - 2017-01-10 01:30:08 --> Helper loaded: date_helper
INFO - 2017-01-10 01:30:08 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:30:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:30:08 --> Helper loaded: form_helper
INFO - 2017-01-10 01:30:08 --> Form Validation Class Initialized
INFO - 2017-01-10 01:30:08 --> Final output sent to browser
DEBUG - 2017-01-10 01:30:08 --> Total execution time: 0.0425
INFO - 2017-01-10 01:30:08 --> Config Class Initialized
INFO - 2017-01-10 01:30:08 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:30:08 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:30:08 --> Utf8 Class Initialized
INFO - 2017-01-10 01:30:08 --> URI Class Initialized
INFO - 2017-01-10 01:30:08 --> Router Class Initialized
INFO - 2017-01-10 01:30:08 --> Output Class Initialized
INFO - 2017-01-10 01:30:08 --> Security Class Initialized
DEBUG - 2017-01-10 01:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:30:08 --> Input Class Initialized
INFO - 2017-01-10 01:30:08 --> Language Class Initialized
INFO - 2017-01-10 01:30:08 --> Loader Class Initialized
INFO - 2017-01-10 01:30:08 --> Database Driver Class Initialized
INFO - 2017-01-10 01:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:30:08 --> Controller Class Initialized
INFO - 2017-01-10 01:30:08 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:30:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:30:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 01:30:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 01:30:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 01:30:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 01:30:08 --> Final output sent to browser
DEBUG - 2017-01-10 01:30:08 --> Total execution time: 0.0408
INFO - 2017-01-10 01:30:44 --> Config Class Initialized
INFO - 2017-01-10 01:30:44 --> Config Class Initialized
INFO - 2017-01-10 01:30:44 --> Hooks Class Initialized
INFO - 2017-01-10 01:30:44 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:30:44 --> UTF-8 Support Enabled
DEBUG - 2017-01-10 01:30:44 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:30:44 --> Utf8 Class Initialized
INFO - 2017-01-10 01:30:44 --> Utf8 Class Initialized
INFO - 2017-01-10 01:30:44 --> URI Class Initialized
INFO - 2017-01-10 01:30:44 --> URI Class Initialized
INFO - 2017-01-10 01:30:44 --> Router Class Initialized
INFO - 2017-01-10 01:30:44 --> Router Class Initialized
INFO - 2017-01-10 01:30:44 --> Output Class Initialized
INFO - 2017-01-10 01:30:44 --> Output Class Initialized
INFO - 2017-01-10 01:30:44 --> Security Class Initialized
INFO - 2017-01-10 01:30:44 --> Security Class Initialized
DEBUG - 2017-01-10 01:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:30:44 --> Input Class Initialized
INFO - 2017-01-10 01:30:44 --> Language Class Initialized
DEBUG - 2017-01-10 01:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:30:44 --> Input Class Initialized
INFO - 2017-01-10 01:30:44 --> Language Class Initialized
INFO - 2017-01-10 01:30:44 --> Loader Class Initialized
INFO - 2017-01-10 01:30:44 --> Loader Class Initialized
INFO - 2017-01-10 01:30:44 --> Database Driver Class Initialized
INFO - 2017-01-10 01:30:44 --> Database Driver Class Initialized
INFO - 2017-01-10 01:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:30:44 --> Controller Class Initialized
INFO - 2017-01-10 01:30:44 --> Helper loaded: date_helper
INFO - 2017-01-10 01:30:45 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:30:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:30:45 --> Helper loaded: form_helper
INFO - 2017-01-10 01:30:45 --> Form Validation Class Initialized
INFO - 2017-01-10 01:30:45 --> Final output sent to browser
DEBUG - 2017-01-10 01:30:45 --> Total execution time: 1.1422
INFO - 2017-01-10 01:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:30:45 --> Controller Class Initialized
INFO - 2017-01-10 01:30:45 --> Helper loaded: date_helper
INFO - 2017-01-10 01:30:45 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:30:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:30:45 --> Helper loaded: form_helper
INFO - 2017-01-10 01:30:45 --> Form Validation Class Initialized
INFO - 2017-01-10 01:30:45 --> Final output sent to browser
DEBUG - 2017-01-10 01:30:45 --> Total execution time: 1.1534
INFO - 2017-01-10 01:30:49 --> Config Class Initialized
INFO - 2017-01-10 01:30:49 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:30:49 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:30:49 --> Utf8 Class Initialized
INFO - 2017-01-10 01:30:49 --> URI Class Initialized
INFO - 2017-01-10 01:30:49 --> Router Class Initialized
INFO - 2017-01-10 01:30:49 --> Output Class Initialized
INFO - 2017-01-10 01:30:49 --> Security Class Initialized
DEBUG - 2017-01-10 01:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:30:49 --> Input Class Initialized
INFO - 2017-01-10 01:30:49 --> Language Class Initialized
INFO - 2017-01-10 01:30:49 --> Loader Class Initialized
INFO - 2017-01-10 01:30:49 --> Database Driver Class Initialized
INFO - 2017-01-10 01:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:30:49 --> Controller Class Initialized
INFO - 2017-01-10 01:30:49 --> Upload Class Initialized
INFO - 2017-01-10 01:30:49 --> Helper loaded: date_helper
INFO - 2017-01-10 01:30:49 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:30:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:30:49 --> Helper loaded: form_helper
INFO - 2017-01-10 01:30:49 --> Form Validation Class Initialized
INFO - 2017-01-10 01:30:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 01:30:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 01:30:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/cupones.php
INFO - 2017-01-10 01:30:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/cupones.php
INFO - 2017-01-10 01:30:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-10 01:30:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 01:30:49 --> Final output sent to browser
DEBUG - 2017-01-10 01:30:49 --> Total execution time: 0.2438
INFO - 2017-01-10 01:30:50 --> Config Class Initialized
INFO - 2017-01-10 01:30:50 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:30:51 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:30:51 --> Utf8 Class Initialized
INFO - 2017-01-10 01:30:51 --> URI Class Initialized
INFO - 2017-01-10 01:30:51 --> Router Class Initialized
INFO - 2017-01-10 01:30:51 --> Output Class Initialized
INFO - 2017-01-10 01:30:51 --> Security Class Initialized
DEBUG - 2017-01-10 01:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:30:51 --> Input Class Initialized
INFO - 2017-01-10 01:30:51 --> Language Class Initialized
INFO - 2017-01-10 01:30:51 --> Loader Class Initialized
INFO - 2017-01-10 01:30:51 --> Database Driver Class Initialized
INFO - 2017-01-10 01:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:30:51 --> Controller Class Initialized
INFO - 2017-01-10 01:30:51 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:30:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:30:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 01:30:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 01:30:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 01:30:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 01:30:52 --> Final output sent to browser
DEBUG - 2017-01-10 01:30:52 --> Total execution time: 1.1741
INFO - 2017-01-10 01:30:56 --> Config Class Initialized
INFO - 2017-01-10 01:30:56 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:30:56 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:30:56 --> Utf8 Class Initialized
INFO - 2017-01-10 01:30:56 --> URI Class Initialized
INFO - 2017-01-10 01:30:56 --> Router Class Initialized
INFO - 2017-01-10 01:30:56 --> Output Class Initialized
INFO - 2017-01-10 01:30:56 --> Security Class Initialized
DEBUG - 2017-01-10 01:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:30:56 --> Input Class Initialized
INFO - 2017-01-10 01:30:56 --> Language Class Initialized
INFO - 2017-01-10 01:30:56 --> Loader Class Initialized
INFO - 2017-01-10 01:30:56 --> Database Driver Class Initialized
INFO - 2017-01-10 01:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:30:56 --> Controller Class Initialized
INFO - 2017-01-10 01:30:56 --> Upload Class Initialized
INFO - 2017-01-10 01:30:56 --> Helper loaded: date_helper
INFO - 2017-01-10 01:30:56 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:30:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:30:56 --> Helper loaded: form_helper
INFO - 2017-01-10 01:30:56 --> Form Validation Class Initialized
INFO - 2017-01-10 01:30:56 --> Final output sent to browser
DEBUG - 2017-01-10 01:30:56 --> Total execution time: 0.3116
INFO - 2017-01-10 01:31:15 --> Config Class Initialized
INFO - 2017-01-10 01:31:15 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:31:15 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:31:15 --> Utf8 Class Initialized
INFO - 2017-01-10 01:31:15 --> URI Class Initialized
INFO - 2017-01-10 01:31:15 --> Router Class Initialized
INFO - 2017-01-10 01:31:15 --> Output Class Initialized
INFO - 2017-01-10 01:31:15 --> Security Class Initialized
DEBUG - 2017-01-10 01:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:31:15 --> Input Class Initialized
INFO - 2017-01-10 01:31:15 --> Language Class Initialized
INFO - 2017-01-10 01:31:15 --> Loader Class Initialized
INFO - 2017-01-10 01:31:15 --> Database Driver Class Initialized
INFO - 2017-01-10 01:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:31:15 --> Controller Class Initialized
INFO - 2017-01-10 01:31:15 --> Upload Class Initialized
INFO - 2017-01-10 01:31:15 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:31:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:31:15 --> Helper loaded: form_helper
INFO - 2017-01-10 01:31:15 --> Form Validation Class Initialized
INFO - 2017-01-10 01:31:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 01:31:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 01:31:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-10 01:31:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-10 01:31:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-10 01:31:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 01:31:15 --> Final output sent to browser
DEBUG - 2017-01-10 01:31:15 --> Total execution time: 0.0784
INFO - 2017-01-10 01:31:16 --> Config Class Initialized
INFO - 2017-01-10 01:31:16 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:31:16 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:31:16 --> Utf8 Class Initialized
INFO - 2017-01-10 01:31:16 --> URI Class Initialized
INFO - 2017-01-10 01:31:16 --> Router Class Initialized
INFO - 2017-01-10 01:31:16 --> Output Class Initialized
INFO - 2017-01-10 01:31:16 --> Security Class Initialized
DEBUG - 2017-01-10 01:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:31:16 --> Input Class Initialized
INFO - 2017-01-10 01:31:16 --> Language Class Initialized
INFO - 2017-01-10 01:31:16 --> Loader Class Initialized
INFO - 2017-01-10 01:31:16 --> Database Driver Class Initialized
INFO - 2017-01-10 01:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:31:16 --> Controller Class Initialized
INFO - 2017-01-10 01:31:16 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:31:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:31:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 01:31:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 01:31:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 01:31:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 01:31:16 --> Final output sent to browser
DEBUG - 2017-01-10 01:31:16 --> Total execution time: 0.0139
INFO - 2017-01-10 01:33:40 --> Config Class Initialized
INFO - 2017-01-10 01:33:40 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:33:41 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:33:41 --> Utf8 Class Initialized
INFO - 2017-01-10 01:33:41 --> URI Class Initialized
INFO - 2017-01-10 01:33:41 --> Router Class Initialized
INFO - 2017-01-10 01:33:41 --> Output Class Initialized
INFO - 2017-01-10 01:33:41 --> Security Class Initialized
DEBUG - 2017-01-10 01:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:33:41 --> Input Class Initialized
INFO - 2017-01-10 01:33:41 --> Language Class Initialized
INFO - 2017-01-10 01:33:41 --> Loader Class Initialized
INFO - 2017-01-10 01:33:41 --> Database Driver Class Initialized
INFO - 2017-01-10 01:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:33:41 --> Controller Class Initialized
INFO - 2017-01-10 01:33:41 --> Upload Class Initialized
INFO - 2017-01-10 01:33:41 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:33:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:33:41 --> Helper loaded: form_helper
INFO - 2017-01-10 01:33:41 --> Form Validation Class Initialized
INFO - 2017-01-10 01:33:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 01:33:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 01:33:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-10 01:33:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-10 01:33:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-10 01:33:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 01:33:41 --> Final output sent to browser
DEBUG - 2017-01-10 01:33:41 --> Total execution time: 0.4061
INFO - 2017-01-10 01:33:42 --> Config Class Initialized
INFO - 2017-01-10 01:33:42 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:33:42 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:33:42 --> Utf8 Class Initialized
INFO - 2017-01-10 01:33:42 --> URI Class Initialized
INFO - 2017-01-10 01:33:42 --> Router Class Initialized
INFO - 2017-01-10 01:33:42 --> Output Class Initialized
INFO - 2017-01-10 01:33:42 --> Security Class Initialized
DEBUG - 2017-01-10 01:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:33:42 --> Input Class Initialized
INFO - 2017-01-10 01:33:42 --> Language Class Initialized
INFO - 2017-01-10 01:33:42 --> Loader Class Initialized
INFO - 2017-01-10 01:33:42 --> Database Driver Class Initialized
INFO - 2017-01-10 01:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:33:42 --> Controller Class Initialized
INFO - 2017-01-10 01:33:42 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:33:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:33:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 01:33:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 01:33:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 01:33:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 01:33:42 --> Final output sent to browser
DEBUG - 2017-01-10 01:33:42 --> Total execution time: 0.0136
INFO - 2017-01-10 01:35:05 --> Config Class Initialized
INFO - 2017-01-10 01:35:05 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:35:05 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:35:05 --> Utf8 Class Initialized
INFO - 2017-01-10 01:35:05 --> URI Class Initialized
INFO - 2017-01-10 01:35:05 --> Router Class Initialized
INFO - 2017-01-10 01:35:05 --> Output Class Initialized
INFO - 2017-01-10 01:35:05 --> Security Class Initialized
DEBUG - 2017-01-10 01:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:35:05 --> Input Class Initialized
INFO - 2017-01-10 01:35:05 --> Language Class Initialized
INFO - 2017-01-10 01:35:05 --> Loader Class Initialized
INFO - 2017-01-10 01:35:05 --> Database Driver Class Initialized
INFO - 2017-01-10 01:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:35:05 --> Controller Class Initialized
INFO - 2017-01-10 01:35:05 --> Upload Class Initialized
INFO - 2017-01-10 01:35:05 --> Helper loaded: date_helper
INFO - 2017-01-10 01:35:05 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:35:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:35:05 --> Helper loaded: form_helper
INFO - 2017-01-10 01:35:05 --> Form Validation Class Initialized
INFO - 2017-01-10 01:35:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 01:35:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 01:35:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-10 01:35:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-10 01:35:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-10 01:35:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 01:35:05 --> Final output sent to browser
DEBUG - 2017-01-10 01:35:05 --> Total execution time: 0.0704
INFO - 2017-01-10 01:35:06 --> Config Class Initialized
INFO - 2017-01-10 01:35:06 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:35:06 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:35:06 --> Utf8 Class Initialized
INFO - 2017-01-10 01:35:06 --> URI Class Initialized
INFO - 2017-01-10 01:35:06 --> Router Class Initialized
INFO - 2017-01-10 01:35:06 --> Output Class Initialized
INFO - 2017-01-10 01:35:06 --> Security Class Initialized
DEBUG - 2017-01-10 01:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:35:06 --> Input Class Initialized
INFO - 2017-01-10 01:35:06 --> Language Class Initialized
INFO - 2017-01-10 01:35:06 --> Loader Class Initialized
INFO - 2017-01-10 01:35:06 --> Database Driver Class Initialized
INFO - 2017-01-10 01:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:35:06 --> Controller Class Initialized
INFO - 2017-01-10 01:35:06 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:35:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:35:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 01:35:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 01:35:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 01:35:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 01:35:06 --> Final output sent to browser
DEBUG - 2017-01-10 01:35:06 --> Total execution time: 0.0132
INFO - 2017-01-10 01:35:08 --> Config Class Initialized
INFO - 2017-01-10 01:35:08 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:35:08 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:35:08 --> Utf8 Class Initialized
INFO - 2017-01-10 01:35:08 --> URI Class Initialized
INFO - 2017-01-10 01:35:08 --> Router Class Initialized
INFO - 2017-01-10 01:35:08 --> Output Class Initialized
INFO - 2017-01-10 01:35:08 --> Security Class Initialized
DEBUG - 2017-01-10 01:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:35:08 --> Input Class Initialized
INFO - 2017-01-10 01:35:08 --> Language Class Initialized
INFO - 2017-01-10 01:35:08 --> Loader Class Initialized
INFO - 2017-01-10 01:35:08 --> Database Driver Class Initialized
INFO - 2017-01-10 01:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:35:08 --> Controller Class Initialized
INFO - 2017-01-10 01:35:08 --> Helper loaded: date_helper
INFO - 2017-01-10 01:35:08 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:35:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:35:08 --> Helper loaded: form_helper
INFO - 2017-01-10 01:35:08 --> Form Validation Class Initialized
INFO - 2017-01-10 01:35:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 01:35:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 01:35:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-10 01:35:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-10 01:35:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 01:35:08 --> Final output sent to browser
DEBUG - 2017-01-10 01:35:08 --> Total execution time: 0.0836
INFO - 2017-01-10 01:35:08 --> Config Class Initialized
INFO - 2017-01-10 01:35:08 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:35:08 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:35:08 --> Utf8 Class Initialized
INFO - 2017-01-10 01:35:08 --> URI Class Initialized
INFO - 2017-01-10 01:35:08 --> Router Class Initialized
INFO - 2017-01-10 01:35:08 --> Output Class Initialized
INFO - 2017-01-10 01:35:08 --> Security Class Initialized
DEBUG - 2017-01-10 01:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:35:08 --> Input Class Initialized
INFO - 2017-01-10 01:35:08 --> Language Class Initialized
INFO - 2017-01-10 01:35:08 --> Loader Class Initialized
INFO - 2017-01-10 01:35:08 --> Database Driver Class Initialized
INFO - 2017-01-10 01:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:35:08 --> Controller Class Initialized
INFO - 2017-01-10 01:35:08 --> Helper loaded: date_helper
INFO - 2017-01-10 01:35:08 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:35:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:35:08 --> Helper loaded: form_helper
INFO - 2017-01-10 01:35:08 --> Form Validation Class Initialized
INFO - 2017-01-10 01:35:08 --> Final output sent to browser
DEBUG - 2017-01-10 01:35:08 --> Total execution time: 0.0140
INFO - 2017-01-10 01:35:08 --> Config Class Initialized
INFO - 2017-01-10 01:35:08 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:35:08 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:35:08 --> Utf8 Class Initialized
INFO - 2017-01-10 01:35:08 --> URI Class Initialized
INFO - 2017-01-10 01:35:08 --> Router Class Initialized
INFO - 2017-01-10 01:35:08 --> Output Class Initialized
INFO - 2017-01-10 01:35:08 --> Security Class Initialized
DEBUG - 2017-01-10 01:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:35:08 --> Input Class Initialized
INFO - 2017-01-10 01:35:08 --> Language Class Initialized
INFO - 2017-01-10 01:35:08 --> Loader Class Initialized
INFO - 2017-01-10 01:35:08 --> Database Driver Class Initialized
INFO - 2017-01-10 01:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:35:08 --> Controller Class Initialized
INFO - 2017-01-10 01:35:08 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:35:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:35:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 01:35:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 01:35:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 01:35:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 01:35:08 --> Final output sent to browser
DEBUG - 2017-01-10 01:35:08 --> Total execution time: 0.0134
INFO - 2017-01-10 01:35:14 --> Config Class Initialized
INFO - 2017-01-10 01:35:14 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:35:14 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:35:14 --> Utf8 Class Initialized
INFO - 2017-01-10 01:35:14 --> URI Class Initialized
INFO - 2017-01-10 01:35:14 --> Router Class Initialized
INFO - 2017-01-10 01:35:14 --> Output Class Initialized
INFO - 2017-01-10 01:35:14 --> Security Class Initialized
DEBUG - 2017-01-10 01:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:35:14 --> Input Class Initialized
INFO - 2017-01-10 01:35:14 --> Language Class Initialized
INFO - 2017-01-10 01:35:14 --> Loader Class Initialized
INFO - 2017-01-10 01:35:14 --> Database Driver Class Initialized
INFO - 2017-01-10 01:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:35:14 --> Controller Class Initialized
INFO - 2017-01-10 01:35:14 --> Helper loaded: date_helper
INFO - 2017-01-10 01:35:14 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:35:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:35:14 --> Helper loaded: form_helper
INFO - 2017-01-10 01:35:14 --> Form Validation Class Initialized
INFO - 2017-01-10 01:35:14 --> Final output sent to browser
DEBUG - 2017-01-10 01:35:14 --> Total execution time: 0.0163
INFO - 2017-01-10 01:35:14 --> Config Class Initialized
INFO - 2017-01-10 01:35:14 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:35:14 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:35:14 --> Utf8 Class Initialized
INFO - 2017-01-10 01:35:14 --> URI Class Initialized
INFO - 2017-01-10 01:35:14 --> Router Class Initialized
INFO - 2017-01-10 01:35:14 --> Output Class Initialized
INFO - 2017-01-10 01:35:14 --> Security Class Initialized
DEBUG - 2017-01-10 01:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:35:14 --> Input Class Initialized
INFO - 2017-01-10 01:35:14 --> Language Class Initialized
INFO - 2017-01-10 01:35:14 --> Loader Class Initialized
INFO - 2017-01-10 01:35:14 --> Database Driver Class Initialized
INFO - 2017-01-10 01:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:35:14 --> Controller Class Initialized
INFO - 2017-01-10 01:35:14 --> Helper loaded: date_helper
INFO - 2017-01-10 01:35:14 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:35:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:35:14 --> Helper loaded: form_helper
INFO - 2017-01-10 01:35:14 --> Form Validation Class Initialized
INFO - 2017-01-10 01:35:14 --> Final output sent to browser
DEBUG - 2017-01-10 01:35:14 --> Total execution time: 0.0146
INFO - 2017-01-10 01:35:33 --> Config Class Initialized
INFO - 2017-01-10 01:35:33 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:35:33 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:35:33 --> Utf8 Class Initialized
INFO - 2017-01-10 01:35:33 --> URI Class Initialized
INFO - 2017-01-10 01:35:33 --> Router Class Initialized
INFO - 2017-01-10 01:35:33 --> Output Class Initialized
INFO - 2017-01-10 01:35:33 --> Security Class Initialized
DEBUG - 2017-01-10 01:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:35:33 --> Input Class Initialized
INFO - 2017-01-10 01:35:33 --> Language Class Initialized
INFO - 2017-01-10 01:35:33 --> Loader Class Initialized
INFO - 2017-01-10 01:35:33 --> Database Driver Class Initialized
INFO - 2017-01-10 01:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:35:33 --> Controller Class Initialized
INFO - 2017-01-10 01:35:33 --> Upload Class Initialized
INFO - 2017-01-10 01:35:33 --> Helper loaded: date_helper
INFO - 2017-01-10 01:35:33 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:35:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:35:33 --> Helper loaded: form_helper
INFO - 2017-01-10 01:35:33 --> Form Validation Class Initialized
INFO - 2017-01-10 01:35:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 01:35:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 01:35:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-10 01:35:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-10 01:35:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-10 01:35:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 01:35:33 --> Final output sent to browser
DEBUG - 2017-01-10 01:35:33 --> Total execution time: 0.0161
INFO - 2017-01-10 01:35:34 --> Config Class Initialized
INFO - 2017-01-10 01:35:34 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:35:34 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:35:34 --> Utf8 Class Initialized
INFO - 2017-01-10 01:35:34 --> URI Class Initialized
INFO - 2017-01-10 01:35:34 --> Router Class Initialized
INFO - 2017-01-10 01:35:34 --> Output Class Initialized
INFO - 2017-01-10 01:35:34 --> Security Class Initialized
DEBUG - 2017-01-10 01:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:35:34 --> Input Class Initialized
INFO - 2017-01-10 01:35:34 --> Language Class Initialized
INFO - 2017-01-10 01:35:34 --> Loader Class Initialized
INFO - 2017-01-10 01:35:34 --> Database Driver Class Initialized
INFO - 2017-01-10 01:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:35:34 --> Controller Class Initialized
INFO - 2017-01-10 01:35:34 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:35:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:35:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 01:35:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 01:35:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 01:35:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 01:35:34 --> Final output sent to browser
DEBUG - 2017-01-10 01:35:34 --> Total execution time: 0.0145
INFO - 2017-01-10 01:35:40 --> Config Class Initialized
INFO - 2017-01-10 01:35:40 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:35:40 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:35:40 --> Utf8 Class Initialized
INFO - 2017-01-10 01:35:40 --> URI Class Initialized
INFO - 2017-01-10 01:35:40 --> Router Class Initialized
INFO - 2017-01-10 01:35:40 --> Output Class Initialized
INFO - 2017-01-10 01:35:40 --> Security Class Initialized
DEBUG - 2017-01-10 01:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:35:40 --> Input Class Initialized
INFO - 2017-01-10 01:35:40 --> Language Class Initialized
INFO - 2017-01-10 01:35:40 --> Loader Class Initialized
INFO - 2017-01-10 01:35:40 --> Database Driver Class Initialized
INFO - 2017-01-10 01:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:35:40 --> Controller Class Initialized
INFO - 2017-01-10 01:35:40 --> Upload Class Initialized
INFO - 2017-01-10 01:35:40 --> Helper loaded: date_helper
INFO - 2017-01-10 01:35:40 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:35:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:35:40 --> Helper loaded: form_helper
INFO - 2017-01-10 01:35:40 --> Form Validation Class Initialized
INFO - 2017-01-10 01:35:40 --> Final output sent to browser
DEBUG - 2017-01-10 01:35:40 --> Total execution time: 0.0152
INFO - 2017-01-10 01:36:04 --> Config Class Initialized
INFO - 2017-01-10 01:36:04 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:36:05 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:36:05 --> Utf8 Class Initialized
INFO - 2017-01-10 01:36:05 --> URI Class Initialized
INFO - 2017-01-10 01:36:05 --> Router Class Initialized
INFO - 2017-01-10 01:36:05 --> Output Class Initialized
INFO - 2017-01-10 01:36:05 --> Security Class Initialized
DEBUG - 2017-01-10 01:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:36:05 --> Input Class Initialized
INFO - 2017-01-10 01:36:05 --> Language Class Initialized
INFO - 2017-01-10 01:36:05 --> Loader Class Initialized
INFO - 2017-01-10 01:36:05 --> Database Driver Class Initialized
INFO - 2017-01-10 01:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:36:05 --> Controller Class Initialized
INFO - 2017-01-10 01:36:05 --> Upload Class Initialized
INFO - 2017-01-10 01:36:05 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:36:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:36:05 --> Helper loaded: form_helper
INFO - 2017-01-10 01:36:05 --> Form Validation Class Initialized
INFO - 2017-01-10 01:36:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 01:36:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 01:36:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-10 01:36:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-10 01:36:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-10 01:36:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 01:36:05 --> Final output sent to browser
DEBUG - 2017-01-10 01:36:05 --> Total execution time: 0.3174
INFO - 2017-01-10 01:36:05 --> Config Class Initialized
INFO - 2017-01-10 01:36:05 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:36:05 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:36:05 --> Utf8 Class Initialized
INFO - 2017-01-10 01:36:05 --> URI Class Initialized
INFO - 2017-01-10 01:36:05 --> Router Class Initialized
INFO - 2017-01-10 01:36:05 --> Output Class Initialized
INFO - 2017-01-10 01:36:05 --> Security Class Initialized
DEBUG - 2017-01-10 01:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:36:05 --> Input Class Initialized
INFO - 2017-01-10 01:36:05 --> Language Class Initialized
INFO - 2017-01-10 01:36:05 --> Loader Class Initialized
INFO - 2017-01-10 01:36:05 --> Database Driver Class Initialized
INFO - 2017-01-10 01:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:36:05 --> Controller Class Initialized
INFO - 2017-01-10 01:36:05 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:36:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:36:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 01:36:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 01:36:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 01:36:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 01:36:06 --> Final output sent to browser
DEBUG - 2017-01-10 01:36:06 --> Total execution time: 0.0738
INFO - 2017-01-10 01:41:42 --> Config Class Initialized
INFO - 2017-01-10 01:41:42 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:41:42 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:41:42 --> Utf8 Class Initialized
INFO - 2017-01-10 01:41:42 --> URI Class Initialized
INFO - 2017-01-10 01:41:42 --> Router Class Initialized
INFO - 2017-01-10 01:41:43 --> Output Class Initialized
INFO - 2017-01-10 01:41:43 --> Security Class Initialized
DEBUG - 2017-01-10 01:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:41:43 --> Input Class Initialized
INFO - 2017-01-10 01:41:43 --> Language Class Initialized
INFO - 2017-01-10 01:41:43 --> Loader Class Initialized
INFO - 2017-01-10 01:41:43 --> Database Driver Class Initialized
INFO - 2017-01-10 01:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:41:43 --> Controller Class Initialized
INFO - 2017-01-10 01:41:43 --> Upload Class Initialized
INFO - 2017-01-10 01:41:43 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:41:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:41:43 --> Helper loaded: form_helper
INFO - 2017-01-10 01:41:43 --> Form Validation Class Initialized
INFO - 2017-01-10 01:41:43 --> Final output sent to browser
DEBUG - 2017-01-10 01:41:43 --> Total execution time: 1.0668
INFO - 2017-01-10 01:46:09 --> Config Class Initialized
INFO - 2017-01-10 01:46:09 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:46:09 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:46:09 --> Utf8 Class Initialized
INFO - 2017-01-10 01:46:09 --> URI Class Initialized
INFO - 2017-01-10 01:46:09 --> Router Class Initialized
INFO - 2017-01-10 01:46:09 --> Output Class Initialized
INFO - 2017-01-10 01:46:09 --> Security Class Initialized
DEBUG - 2017-01-10 01:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:46:09 --> Input Class Initialized
INFO - 2017-01-10 01:46:09 --> Language Class Initialized
INFO - 2017-01-10 01:46:09 --> Loader Class Initialized
INFO - 2017-01-10 01:46:10 --> Database Driver Class Initialized
INFO - 2017-01-10 01:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:46:10 --> Controller Class Initialized
INFO - 2017-01-10 01:46:10 --> Upload Class Initialized
INFO - 2017-01-10 01:46:10 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:46:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:46:10 --> Helper loaded: form_helper
INFO - 2017-01-10 01:46:10 --> Form Validation Class Initialized
INFO - 2017-01-10 01:46:13 --> Final output sent to browser
DEBUG - 2017-01-10 01:46:13 --> Total execution time: 4.1470
INFO - 2017-01-10 01:46:14 --> Config Class Initialized
INFO - 2017-01-10 01:46:14 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:46:14 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:46:14 --> Utf8 Class Initialized
INFO - 2017-01-10 01:46:14 --> URI Class Initialized
INFO - 2017-01-10 01:46:14 --> Router Class Initialized
INFO - 2017-01-10 01:46:14 --> Output Class Initialized
INFO - 2017-01-10 01:46:14 --> Security Class Initialized
DEBUG - 2017-01-10 01:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:46:14 --> Input Class Initialized
INFO - 2017-01-10 01:46:14 --> Language Class Initialized
INFO - 2017-01-10 01:46:14 --> Loader Class Initialized
INFO - 2017-01-10 01:46:14 --> Database Driver Class Initialized
INFO - 2017-01-10 01:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:46:14 --> Controller Class Initialized
INFO - 2017-01-10 01:46:14 --> Upload Class Initialized
INFO - 2017-01-10 01:46:14 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:46:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:46:14 --> Helper loaded: form_helper
INFO - 2017-01-10 01:46:14 --> Form Validation Class Initialized
INFO - 2017-01-10 01:46:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-10 01:46:14 --> Final output sent to browser
DEBUG - 2017-01-10 01:46:14 --> Total execution time: 0.0226
INFO - 2017-01-10 01:46:15 --> Config Class Initialized
INFO - 2017-01-10 01:46:15 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:46:15 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:46:15 --> Utf8 Class Initialized
INFO - 2017-01-10 01:46:15 --> URI Class Initialized
INFO - 2017-01-10 01:46:15 --> Router Class Initialized
INFO - 2017-01-10 01:46:15 --> Output Class Initialized
INFO - 2017-01-10 01:46:15 --> Security Class Initialized
DEBUG - 2017-01-10 01:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:46:15 --> Input Class Initialized
INFO - 2017-01-10 01:46:15 --> Language Class Initialized
INFO - 2017-01-10 01:46:15 --> Loader Class Initialized
INFO - 2017-01-10 01:46:15 --> Database Driver Class Initialized
INFO - 2017-01-10 01:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:46:15 --> Controller Class Initialized
INFO - 2017-01-10 01:46:15 --> Upload Class Initialized
INFO - 2017-01-10 01:46:15 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:46:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:46:15 --> Helper loaded: form_helper
INFO - 2017-01-10 01:46:15 --> Form Validation Class Initialized
INFO - 2017-01-10 01:46:15 --> Final output sent to browser
DEBUG - 2017-01-10 01:46:15 --> Total execution time: 0.0144
INFO - 2017-01-10 01:46:15 --> Config Class Initialized
INFO - 2017-01-10 01:46:15 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:46:15 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:46:15 --> Utf8 Class Initialized
INFO - 2017-01-10 01:46:15 --> URI Class Initialized
INFO - 2017-01-10 01:46:15 --> Router Class Initialized
INFO - 2017-01-10 01:46:15 --> Output Class Initialized
INFO - 2017-01-10 01:46:15 --> Security Class Initialized
DEBUG - 2017-01-10 01:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:46:15 --> Input Class Initialized
INFO - 2017-01-10 01:46:15 --> Language Class Initialized
INFO - 2017-01-10 01:46:15 --> Loader Class Initialized
INFO - 2017-01-10 01:46:15 --> Database Driver Class Initialized
INFO - 2017-01-10 01:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:46:15 --> Controller Class Initialized
INFO - 2017-01-10 01:46:15 --> Upload Class Initialized
INFO - 2017-01-10 01:46:15 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:46:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:46:15 --> Helper loaded: form_helper
INFO - 2017-01-10 01:46:15 --> Form Validation Class Initialized
INFO - 2017-01-10 01:46:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-10 01:46:15 --> Final output sent to browser
DEBUG - 2017-01-10 01:46:15 --> Total execution time: 0.0138
INFO - 2017-01-10 01:55:17 --> Config Class Initialized
INFO - 2017-01-10 01:55:17 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:55:17 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:55:17 --> Utf8 Class Initialized
INFO - 2017-01-10 01:55:17 --> URI Class Initialized
INFO - 2017-01-10 01:55:17 --> Router Class Initialized
INFO - 2017-01-10 01:55:17 --> Output Class Initialized
INFO - 2017-01-10 01:55:17 --> Security Class Initialized
DEBUG - 2017-01-10 01:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:55:17 --> Input Class Initialized
INFO - 2017-01-10 01:55:17 --> Language Class Initialized
INFO - 2017-01-10 01:55:17 --> Loader Class Initialized
INFO - 2017-01-10 01:55:17 --> Database Driver Class Initialized
INFO - 2017-01-10 01:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:55:17 --> Controller Class Initialized
INFO - 2017-01-10 01:55:17 --> Upload Class Initialized
INFO - 2017-01-10 01:55:17 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:55:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:55:17 --> Helper loaded: form_helper
INFO - 2017-01-10 01:55:17 --> Form Validation Class Initialized
INFO - 2017-01-10 01:55:18 --> Final output sent to browser
DEBUG - 2017-01-10 01:55:18 --> Total execution time: 1.3243
INFO - 2017-01-10 01:55:18 --> Config Class Initialized
INFO - 2017-01-10 01:55:18 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:55:18 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:55:18 --> Utf8 Class Initialized
INFO - 2017-01-10 01:55:18 --> URI Class Initialized
INFO - 2017-01-10 01:55:18 --> Router Class Initialized
INFO - 2017-01-10 01:55:18 --> Output Class Initialized
INFO - 2017-01-10 01:55:18 --> Security Class Initialized
DEBUG - 2017-01-10 01:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:55:18 --> Input Class Initialized
INFO - 2017-01-10 01:55:18 --> Language Class Initialized
INFO - 2017-01-10 01:55:18 --> Loader Class Initialized
INFO - 2017-01-10 01:55:18 --> Database Driver Class Initialized
INFO - 2017-01-10 01:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:55:18 --> Controller Class Initialized
INFO - 2017-01-10 01:55:18 --> Upload Class Initialized
INFO - 2017-01-10 01:55:18 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:55:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:55:18 --> Helper loaded: form_helper
INFO - 2017-01-10 01:55:18 --> Form Validation Class Initialized
INFO - 2017-01-10 01:55:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-10 01:55:18 --> Final output sent to browser
DEBUG - 2017-01-10 01:55:18 --> Total execution time: 0.0159
INFO - 2017-01-10 01:55:23 --> Config Class Initialized
INFO - 2017-01-10 01:55:23 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:55:23 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:55:23 --> Utf8 Class Initialized
INFO - 2017-01-10 01:55:23 --> URI Class Initialized
INFO - 2017-01-10 01:55:23 --> Router Class Initialized
INFO - 2017-01-10 01:55:23 --> Output Class Initialized
INFO - 2017-01-10 01:55:23 --> Security Class Initialized
DEBUG - 2017-01-10 01:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:55:23 --> Input Class Initialized
INFO - 2017-01-10 01:55:23 --> Language Class Initialized
INFO - 2017-01-10 01:55:23 --> Loader Class Initialized
INFO - 2017-01-10 01:55:23 --> Database Driver Class Initialized
INFO - 2017-01-10 01:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:55:23 --> Controller Class Initialized
INFO - 2017-01-10 01:55:23 --> Upload Class Initialized
INFO - 2017-01-10 01:55:23 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:55:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:55:23 --> Helper loaded: form_helper
INFO - 2017-01-10 01:55:23 --> Form Validation Class Initialized
INFO - 2017-01-10 01:55:23 --> Final output sent to browser
DEBUG - 2017-01-10 01:55:23 --> Total execution time: 0.0143
INFO - 2017-01-10 01:55:23 --> Config Class Initialized
INFO - 2017-01-10 01:55:23 --> Hooks Class Initialized
DEBUG - 2017-01-10 01:55:23 --> UTF-8 Support Enabled
INFO - 2017-01-10 01:55:23 --> Utf8 Class Initialized
INFO - 2017-01-10 01:55:23 --> URI Class Initialized
INFO - 2017-01-10 01:55:23 --> Router Class Initialized
INFO - 2017-01-10 01:55:23 --> Output Class Initialized
INFO - 2017-01-10 01:55:23 --> Security Class Initialized
DEBUG - 2017-01-10 01:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 01:55:23 --> Input Class Initialized
INFO - 2017-01-10 01:55:23 --> Language Class Initialized
INFO - 2017-01-10 01:55:23 --> Loader Class Initialized
INFO - 2017-01-10 01:55:23 --> Database Driver Class Initialized
INFO - 2017-01-10 01:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 01:55:23 --> Controller Class Initialized
INFO - 2017-01-10 01:55:23 --> Upload Class Initialized
INFO - 2017-01-10 01:55:23 --> Helper loaded: url_helper
DEBUG - 2017-01-10 01:55:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 01:55:23 --> Helper loaded: form_helper
INFO - 2017-01-10 01:55:23 --> Form Validation Class Initialized
INFO - 2017-01-10 01:55:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-10 01:55:23 --> Final output sent to browser
DEBUG - 2017-01-10 01:55:23 --> Total execution time: 0.0157
INFO - 2017-01-10 02:02:18 --> Config Class Initialized
INFO - 2017-01-10 02:02:18 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:02:18 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:02:18 --> Utf8 Class Initialized
INFO - 2017-01-10 02:02:18 --> URI Class Initialized
INFO - 2017-01-10 02:02:18 --> Router Class Initialized
INFO - 2017-01-10 02:02:18 --> Output Class Initialized
INFO - 2017-01-10 02:02:18 --> Security Class Initialized
DEBUG - 2017-01-10 02:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:02:18 --> Input Class Initialized
INFO - 2017-01-10 02:02:18 --> Language Class Initialized
INFO - 2017-01-10 02:02:18 --> Loader Class Initialized
INFO - 2017-01-10 02:02:18 --> Database Driver Class Initialized
INFO - 2017-01-10 02:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:02:18 --> Controller Class Initialized
INFO - 2017-01-10 02:02:18 --> Upload Class Initialized
INFO - 2017-01-10 02:02:18 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:02:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:02:18 --> Helper loaded: form_helper
INFO - 2017-01-10 02:02:18 --> Form Validation Class Initialized
INFO - 2017-01-10 02:02:19 --> Final output sent to browser
DEBUG - 2017-01-10 02:02:19 --> Total execution time: 0.9882
INFO - 2017-01-10 02:02:20 --> Config Class Initialized
INFO - 2017-01-10 02:02:20 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:02:20 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:02:20 --> Utf8 Class Initialized
INFO - 2017-01-10 02:02:20 --> URI Class Initialized
INFO - 2017-01-10 02:02:20 --> Router Class Initialized
INFO - 2017-01-10 02:02:20 --> Output Class Initialized
INFO - 2017-01-10 02:02:20 --> Security Class Initialized
DEBUG - 2017-01-10 02:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:02:20 --> Input Class Initialized
INFO - 2017-01-10 02:02:20 --> Language Class Initialized
INFO - 2017-01-10 02:02:20 --> Loader Class Initialized
INFO - 2017-01-10 02:02:20 --> Database Driver Class Initialized
INFO - 2017-01-10 02:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:02:20 --> Controller Class Initialized
INFO - 2017-01-10 02:02:20 --> Upload Class Initialized
INFO - 2017-01-10 02:02:20 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:02:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:02:20 --> Helper loaded: form_helper
INFO - 2017-01-10 02:02:20 --> Form Validation Class Initialized
INFO - 2017-01-10 02:02:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-10 02:02:20 --> Final output sent to browser
DEBUG - 2017-01-10 02:02:20 --> Total execution time: 0.0156
INFO - 2017-01-10 02:02:50 --> Config Class Initialized
INFO - 2017-01-10 02:02:50 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:02:50 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:02:50 --> Utf8 Class Initialized
INFO - 2017-01-10 02:02:50 --> URI Class Initialized
DEBUG - 2017-01-10 02:02:50 --> No URI present. Default controller set.
INFO - 2017-01-10 02:02:50 --> Router Class Initialized
INFO - 2017-01-10 02:02:50 --> Output Class Initialized
INFO - 2017-01-10 02:02:50 --> Security Class Initialized
DEBUG - 2017-01-10 02:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:02:50 --> Input Class Initialized
INFO - 2017-01-10 02:02:50 --> Language Class Initialized
INFO - 2017-01-10 02:02:50 --> Loader Class Initialized
INFO - 2017-01-10 02:02:50 --> Database Driver Class Initialized
INFO - 2017-01-10 02:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:02:50 --> Controller Class Initialized
INFO - 2017-01-10 02:02:50 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:02:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:02:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:02:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:02:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:02:51 --> Config Class Initialized
INFO - 2017-01-10 02:02:51 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:02:51 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:02:51 --> Utf8 Class Initialized
INFO - 2017-01-10 02:02:51 --> URI Class Initialized
INFO - 2017-01-10 02:02:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:02:51 --> Final output sent to browser
DEBUG - 2017-01-10 02:02:51 --> Total execution time: 0.2807
INFO - 2017-01-10 02:02:51 --> Router Class Initialized
INFO - 2017-01-10 02:02:51 --> Output Class Initialized
INFO - 2017-01-10 02:02:51 --> Config Class Initialized
INFO - 2017-01-10 02:02:51 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:02:51 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:02:51 --> Utf8 Class Initialized
INFO - 2017-01-10 02:02:51 --> URI Class Initialized
INFO - 2017-01-10 02:02:51 --> Security Class Initialized
DEBUG - 2017-01-10 02:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:02:51 --> Input Class Initialized
INFO - 2017-01-10 02:02:51 --> Language Class Initialized
INFO - 2017-01-10 02:02:51 --> Router Class Initialized
INFO - 2017-01-10 02:02:51 --> Output Class Initialized
INFO - 2017-01-10 02:02:51 --> Security Class Initialized
DEBUG - 2017-01-10 02:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:02:51 --> Input Class Initialized
INFO - 2017-01-10 02:02:51 --> Language Class Initialized
ERROR - 2017-01-10 02:02:51 --> 404 Page Not Found: Imagenes_portada/Galeria5.jpg
ERROR - 2017-01-10 02:02:51 --> 404 Page Not Found: Imagenes_portada/Galeria2.jpg
INFO - 2017-01-10 02:02:51 --> Config Class Initialized
INFO - 2017-01-10 02:02:51 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:02:51 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:02:51 --> Utf8 Class Initialized
INFO - 2017-01-10 02:02:51 --> URI Class Initialized
INFO - 2017-01-10 02:02:51 --> Router Class Initialized
INFO - 2017-01-10 02:02:51 --> Output Class Initialized
INFO - 2017-01-10 02:02:51 --> Security Class Initialized
DEBUG - 2017-01-10 02:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:02:51 --> Input Class Initialized
INFO - 2017-01-10 02:02:51 --> Language Class Initialized
ERROR - 2017-01-10 02:02:51 --> 404 Page Not Found: Imagenes_portada/Galeria4.jpg
INFO - 2017-01-10 02:02:51 --> Config Class Initialized
INFO - 2017-01-10 02:02:51 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:02:51 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:02:51 --> Utf8 Class Initialized
INFO - 2017-01-10 02:02:51 --> URI Class Initialized
INFO - 2017-01-10 02:02:51 --> Router Class Initialized
INFO - 2017-01-10 02:02:51 --> Output Class Initialized
INFO - 2017-01-10 02:02:51 --> Security Class Initialized
DEBUG - 2017-01-10 02:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:02:51 --> Input Class Initialized
INFO - 2017-01-10 02:02:51 --> Language Class Initialized
ERROR - 2017-01-10 02:02:51 --> 404 Page Not Found: Imagenes_portada/Galeria3.jpg
INFO - 2017-01-10 02:02:51 --> Config Class Initialized
INFO - 2017-01-10 02:02:51 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:02:51 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:02:51 --> Utf8 Class Initialized
INFO - 2017-01-10 02:02:51 --> URI Class Initialized
INFO - 2017-01-10 02:02:51 --> Router Class Initialized
INFO - 2017-01-10 02:02:51 --> Output Class Initialized
INFO - 2017-01-10 02:02:51 --> Security Class Initialized
DEBUG - 2017-01-10 02:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:02:51 --> Input Class Initialized
INFO - 2017-01-10 02:02:51 --> Language Class Initialized
ERROR - 2017-01-10 02:02:51 --> 404 Page Not Found: Imagenes_portada/Galeria6.jpg
INFO - 2017-01-10 02:03:03 --> Config Class Initialized
INFO - 2017-01-10 02:03:03 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:03:03 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:03:03 --> Utf8 Class Initialized
INFO - 2017-01-10 02:03:03 --> URI Class Initialized
INFO - 2017-01-10 02:03:03 --> Router Class Initialized
INFO - 2017-01-10 02:03:03 --> Output Class Initialized
INFO - 2017-01-10 02:03:03 --> Security Class Initialized
DEBUG - 2017-01-10 02:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:03:03 --> Input Class Initialized
INFO - 2017-01-10 02:03:03 --> Language Class Initialized
INFO - 2017-01-10 02:03:03 --> Loader Class Initialized
INFO - 2017-01-10 02:03:03 --> Database Driver Class Initialized
INFO - 2017-01-10 02:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:03:03 --> Controller Class Initialized
INFO - 2017-01-10 02:03:03 --> Upload Class Initialized
INFO - 2017-01-10 02:03:03 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:03:03 --> Helper loaded: form_helper
INFO - 2017-01-10 02:03:03 --> Form Validation Class Initialized
INFO - 2017-01-10 02:03:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:03:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 02:03:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-10 02:03:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-10 02:03:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-10 02:03:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:03:03 --> Final output sent to browser
DEBUG - 2017-01-10 02:03:03 --> Total execution time: 0.1164
INFO - 2017-01-10 02:03:04 --> Config Class Initialized
INFO - 2017-01-10 02:03:04 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:03:04 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:03:04 --> Utf8 Class Initialized
INFO - 2017-01-10 02:03:04 --> URI Class Initialized
INFO - 2017-01-10 02:03:04 --> Router Class Initialized
INFO - 2017-01-10 02:03:04 --> Output Class Initialized
INFO - 2017-01-10 02:03:04 --> Security Class Initialized
DEBUG - 2017-01-10 02:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:03:04 --> Input Class Initialized
INFO - 2017-01-10 02:03:04 --> Language Class Initialized
INFO - 2017-01-10 02:03:04 --> Loader Class Initialized
INFO - 2017-01-10 02:03:04 --> Database Driver Class Initialized
INFO - 2017-01-10 02:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:03:04 --> Controller Class Initialized
INFO - 2017-01-10 02:03:04 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:03:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:03:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:03:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:03:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:03:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:03:04 --> Final output sent to browser
DEBUG - 2017-01-10 02:03:04 --> Total execution time: 0.0142
INFO - 2017-01-10 02:03:24 --> Config Class Initialized
INFO - 2017-01-10 02:03:24 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:03:24 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:03:24 --> Utf8 Class Initialized
INFO - 2017-01-10 02:03:24 --> URI Class Initialized
INFO - 2017-01-10 02:03:24 --> Router Class Initialized
INFO - 2017-01-10 02:03:24 --> Output Class Initialized
INFO - 2017-01-10 02:03:24 --> Security Class Initialized
DEBUG - 2017-01-10 02:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:03:24 --> Input Class Initialized
INFO - 2017-01-10 02:03:24 --> Language Class Initialized
INFO - 2017-01-10 02:03:24 --> Loader Class Initialized
INFO - 2017-01-10 02:03:24 --> Database Driver Class Initialized
INFO - 2017-01-10 02:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:03:24 --> Controller Class Initialized
INFO - 2017-01-10 02:03:24 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:03:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:03:33 --> Config Class Initialized
INFO - 2017-01-10 02:03:33 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:03:33 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:03:33 --> Utf8 Class Initialized
INFO - 2017-01-10 02:03:33 --> URI Class Initialized
INFO - 2017-01-10 02:03:33 --> Router Class Initialized
INFO - 2017-01-10 02:03:33 --> Output Class Initialized
INFO - 2017-01-10 02:03:33 --> Security Class Initialized
DEBUG - 2017-01-10 02:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:03:33 --> Input Class Initialized
INFO - 2017-01-10 02:03:33 --> Language Class Initialized
INFO - 2017-01-10 02:03:33 --> Loader Class Initialized
INFO - 2017-01-10 02:03:33 --> Database Driver Class Initialized
INFO - 2017-01-10 02:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:03:33 --> Controller Class Initialized
INFO - 2017-01-10 02:03:33 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:03:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:03:33 --> Helper loaded: url_helper
INFO - 2017-01-10 02:03:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:03:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:03:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-10 02:03:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-10 02:03:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:03:33 --> Final output sent to browser
DEBUG - 2017-01-10 02:03:33 --> Total execution time: 0.1093
INFO - 2017-01-10 02:03:49 --> Config Class Initialized
INFO - 2017-01-10 02:03:49 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:03:49 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:03:49 --> Utf8 Class Initialized
INFO - 2017-01-10 02:03:49 --> URI Class Initialized
INFO - 2017-01-10 02:03:49 --> Router Class Initialized
INFO - 2017-01-10 02:03:49 --> Output Class Initialized
INFO - 2017-01-10 02:03:49 --> Security Class Initialized
DEBUG - 2017-01-10 02:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:03:49 --> Input Class Initialized
INFO - 2017-01-10 02:03:49 --> Language Class Initialized
INFO - 2017-01-10 02:03:49 --> Loader Class Initialized
INFO - 2017-01-10 02:03:49 --> Database Driver Class Initialized
INFO - 2017-01-10 02:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:03:49 --> Controller Class Initialized
INFO - 2017-01-10 02:03:49 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:03:49 --> Helper loaded: url_helper
INFO - 2017-01-10 02:03:49 --> Helper loaded: download_helper
INFO - 2017-01-10 02:03:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:03:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:03:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-10 02:03:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-10 02:03:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:03:49 --> Final output sent to browser
DEBUG - 2017-01-10 02:03:49 --> Total execution time: 0.1227
INFO - 2017-01-10 02:04:15 --> Config Class Initialized
INFO - 2017-01-10 02:04:15 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:04:15 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:04:15 --> Utf8 Class Initialized
INFO - 2017-01-10 02:04:15 --> URI Class Initialized
INFO - 2017-01-10 02:04:15 --> Router Class Initialized
INFO - 2017-01-10 02:04:15 --> Output Class Initialized
INFO - 2017-01-10 02:04:15 --> Security Class Initialized
DEBUG - 2017-01-10 02:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:04:15 --> Input Class Initialized
INFO - 2017-01-10 02:04:15 --> Language Class Initialized
INFO - 2017-01-10 02:04:15 --> Loader Class Initialized
INFO - 2017-01-10 02:04:15 --> Database Driver Class Initialized
INFO - 2017-01-10 02:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:04:15 --> Controller Class Initialized
INFO - 2017-01-10 02:04:15 --> Config Class Initialized
INFO - 2017-01-10 02:04:15 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:04:15 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:04:15 --> Utf8 Class Initialized
INFO - 2017-01-10 02:04:15 --> URI Class Initialized
INFO - 2017-01-10 02:04:15 --> Helper loaded: date_helper
INFO - 2017-01-10 02:04:15 --> Router Class Initialized
DEBUG - 2017-01-10 02:04:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:04:15 --> Output Class Initialized
INFO - 2017-01-10 02:04:15 --> Helper loaded: url_helper
INFO - 2017-01-10 02:04:15 --> Security Class Initialized
DEBUG - 2017-01-10 02:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:04:15 --> Input Class Initialized
INFO - 2017-01-10 02:04:15 --> Language Class Initialized
INFO - 2017-01-10 02:04:15 --> Loader Class Initialized
INFO - 2017-01-10 02:04:15 --> Database Driver Class Initialized
INFO - 2017-01-10 02:04:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:04:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-10 02:04:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:04:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-10 02:04:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-10 02:04:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:04:15 --> Final output sent to browser
DEBUG - 2017-01-10 02:04:15 --> Total execution time: 0.7893
INFO - 2017-01-10 02:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:04:15 --> Controller Class Initialized
INFO - 2017-01-10 02:04:15 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:04:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:04:15 --> Helper loaded: url_helper
INFO - 2017-01-10 02:04:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:04:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-10 02:04:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:04:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-10 02:04:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-10 02:04:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:04:15 --> Final output sent to browser
DEBUG - 2017-01-10 02:04:15 --> Total execution time: 0.4294
INFO - 2017-01-10 02:04:15 --> Config Class Initialized
INFO - 2017-01-10 02:04:15 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:04:15 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:04:15 --> Utf8 Class Initialized
INFO - 2017-01-10 02:04:15 --> URI Class Initialized
INFO - 2017-01-10 02:04:15 --> Router Class Initialized
INFO - 2017-01-10 02:04:15 --> Output Class Initialized
INFO - 2017-01-10 02:04:15 --> Security Class Initialized
DEBUG - 2017-01-10 02:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:04:15 --> Input Class Initialized
INFO - 2017-01-10 02:04:15 --> Language Class Initialized
INFO - 2017-01-10 02:04:15 --> Loader Class Initialized
INFO - 2017-01-10 02:04:15 --> Database Driver Class Initialized
INFO - 2017-01-10 02:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:04:15 --> Controller Class Initialized
INFO - 2017-01-10 02:04:15 --> Upload Class Initialized
INFO - 2017-01-10 02:04:16 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:04:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:04:16 --> Helper loaded: url_helper
INFO - 2017-01-10 02:04:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:04:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:04:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-01-10 02:04:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-01-10 02:04:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-10 02:04:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:04:16 --> Final output sent to browser
DEBUG - 2017-01-10 02:04:16 --> Total execution time: 0.0744
INFO - 2017-01-10 02:04:22 --> Config Class Initialized
INFO - 2017-01-10 02:04:22 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:04:22 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:04:22 --> Utf8 Class Initialized
INFO - 2017-01-10 02:04:22 --> URI Class Initialized
INFO - 2017-01-10 02:04:22 --> Router Class Initialized
INFO - 2017-01-10 02:04:22 --> Output Class Initialized
INFO - 2017-01-10 02:04:22 --> Security Class Initialized
DEBUG - 2017-01-10 02:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:04:22 --> Input Class Initialized
INFO - 2017-01-10 02:04:22 --> Language Class Initialized
INFO - 2017-01-10 02:04:22 --> Loader Class Initialized
INFO - 2017-01-10 02:04:22 --> Database Driver Class Initialized
INFO - 2017-01-10 02:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:04:22 --> Controller Class Initialized
INFO - 2017-01-10 02:04:22 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:04:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:04:22 --> Helper loaded: url_helper
INFO - 2017-01-10 02:04:22 --> Helper loaded: download_helper
INFO - 2017-01-10 02:04:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:04:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:04:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-10 02:04:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-10 02:04:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:04:22 --> Final output sent to browser
DEBUG - 2017-01-10 02:04:22 --> Total execution time: 0.1023
INFO - 2017-01-10 02:04:39 --> Config Class Initialized
INFO - 2017-01-10 02:04:39 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:04:39 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:04:39 --> Utf8 Class Initialized
INFO - 2017-01-10 02:04:39 --> URI Class Initialized
INFO - 2017-01-10 02:04:39 --> Router Class Initialized
INFO - 2017-01-10 02:04:39 --> Output Class Initialized
INFO - 2017-01-10 02:04:39 --> Security Class Initialized
DEBUG - 2017-01-10 02:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:04:39 --> Input Class Initialized
INFO - 2017-01-10 02:04:39 --> Language Class Initialized
INFO - 2017-01-10 02:04:39 --> Loader Class Initialized
INFO - 2017-01-10 02:04:39 --> Database Driver Class Initialized
INFO - 2017-01-10 02:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:04:39 --> Controller Class Initialized
INFO - 2017-01-10 02:04:39 --> Helper loaded: date_helper
INFO - 2017-01-10 02:04:39 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:04:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:04:39 --> Helper loaded: form_helper
INFO - 2017-01-10 02:04:39 --> Form Validation Class Initialized
INFO - 2017-01-10 02:04:39 --> Final output sent to browser
DEBUG - 2017-01-10 02:04:39 --> Total execution time: 0.0853
INFO - 2017-01-10 02:04:47 --> Config Class Initialized
INFO - 2017-01-10 02:04:47 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:04:47 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:04:47 --> Utf8 Class Initialized
INFO - 2017-01-10 02:04:47 --> URI Class Initialized
INFO - 2017-01-10 02:04:47 --> Router Class Initialized
INFO - 2017-01-10 02:04:47 --> Output Class Initialized
INFO - 2017-01-10 02:04:47 --> Security Class Initialized
DEBUG - 2017-01-10 02:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:04:47 --> Input Class Initialized
INFO - 2017-01-10 02:04:47 --> Language Class Initialized
INFO - 2017-01-10 02:04:47 --> Loader Class Initialized
INFO - 2017-01-10 02:04:47 --> Database Driver Class Initialized
INFO - 2017-01-10 02:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:04:47 --> Controller Class Initialized
INFO - 2017-01-10 02:04:47 --> Helper loaded: date_helper
INFO - 2017-01-10 02:04:47 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:04:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:04:47 --> Helper loaded: form_helper
INFO - 2017-01-10 02:04:47 --> Form Validation Class Initialized
INFO - 2017-01-10 02:04:47 --> Final output sent to browser
DEBUG - 2017-01-10 02:04:47 --> Total execution time: 0.0146
INFO - 2017-01-10 02:04:52 --> Config Class Initialized
INFO - 2017-01-10 02:04:52 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:04:52 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:04:52 --> Utf8 Class Initialized
INFO - 2017-01-10 02:04:52 --> URI Class Initialized
INFO - 2017-01-10 02:04:52 --> Router Class Initialized
INFO - 2017-01-10 02:04:52 --> Output Class Initialized
INFO - 2017-01-10 02:04:52 --> Security Class Initialized
DEBUG - 2017-01-10 02:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:04:52 --> Input Class Initialized
INFO - 2017-01-10 02:04:52 --> Language Class Initialized
INFO - 2017-01-10 02:04:52 --> Loader Class Initialized
INFO - 2017-01-10 02:04:52 --> Database Driver Class Initialized
INFO - 2017-01-10 02:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:04:52 --> Controller Class Initialized
INFO - 2017-01-10 02:04:52 --> Helper loaded: date_helper
INFO - 2017-01-10 02:04:52 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:04:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:04:52 --> Helper loaded: form_helper
INFO - 2017-01-10 02:04:52 --> Form Validation Class Initialized
INFO - 2017-01-10 02:04:52 --> Final output sent to browser
DEBUG - 2017-01-10 02:04:52 --> Total execution time: 0.0172
INFO - 2017-01-10 02:04:53 --> Config Class Initialized
INFO - 2017-01-10 02:04:53 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:04:53 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:04:53 --> Utf8 Class Initialized
INFO - 2017-01-10 02:04:53 --> URI Class Initialized
INFO - 2017-01-10 02:04:53 --> Router Class Initialized
INFO - 2017-01-10 02:04:53 --> Output Class Initialized
INFO - 2017-01-10 02:04:53 --> Security Class Initialized
DEBUG - 2017-01-10 02:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:04:53 --> Input Class Initialized
INFO - 2017-01-10 02:04:53 --> Language Class Initialized
INFO - 2017-01-10 02:04:53 --> Loader Class Initialized
INFO - 2017-01-10 02:04:53 --> Database Driver Class Initialized
INFO - 2017-01-10 02:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:04:53 --> Controller Class Initialized
INFO - 2017-01-10 02:04:53 --> Helper loaded: date_helper
INFO - 2017-01-10 02:04:53 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:04:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:04:53 --> Helper loaded: form_helper
INFO - 2017-01-10 02:04:53 --> Form Validation Class Initialized
INFO - 2017-01-10 02:04:53 --> Final output sent to browser
DEBUG - 2017-01-10 02:04:53 --> Total execution time: 0.0146
INFO - 2017-01-10 02:04:53 --> Config Class Initialized
INFO - 2017-01-10 02:04:53 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:04:53 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:04:53 --> Utf8 Class Initialized
INFO - 2017-01-10 02:04:53 --> URI Class Initialized
INFO - 2017-01-10 02:04:53 --> Router Class Initialized
INFO - 2017-01-10 02:04:53 --> Output Class Initialized
INFO - 2017-01-10 02:04:53 --> Security Class Initialized
DEBUG - 2017-01-10 02:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:04:53 --> Input Class Initialized
INFO - 2017-01-10 02:04:53 --> Language Class Initialized
INFO - 2017-01-10 02:04:53 --> Loader Class Initialized
INFO - 2017-01-10 02:04:53 --> Database Driver Class Initialized
INFO - 2017-01-10 02:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:04:53 --> Controller Class Initialized
INFO - 2017-01-10 02:04:53 --> Helper loaded: date_helper
INFO - 2017-01-10 02:04:53 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:04:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:04:53 --> Helper loaded: form_helper
INFO - 2017-01-10 02:04:53 --> Form Validation Class Initialized
INFO - 2017-01-10 02:04:53 --> Final output sent to browser
DEBUG - 2017-01-10 02:04:53 --> Total execution time: 0.0153
INFO - 2017-01-10 02:05:03 --> Config Class Initialized
INFO - 2017-01-10 02:05:03 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:05:03 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:05:03 --> Utf8 Class Initialized
INFO - 2017-01-10 02:05:03 --> URI Class Initialized
INFO - 2017-01-10 02:05:03 --> Router Class Initialized
INFO - 2017-01-10 02:05:03 --> Output Class Initialized
INFO - 2017-01-10 02:05:03 --> Security Class Initialized
DEBUG - 2017-01-10 02:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:05:03 --> Input Class Initialized
INFO - 2017-01-10 02:05:03 --> Language Class Initialized
INFO - 2017-01-10 02:05:03 --> Loader Class Initialized
INFO - 2017-01-10 02:05:03 --> Database Driver Class Initialized
INFO - 2017-01-10 02:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:05:03 --> Controller Class Initialized
INFO - 2017-01-10 02:05:03 --> Helper loaded: date_helper
INFO - 2017-01-10 02:05:03 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:05:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:05:03 --> Helper loaded: form_helper
INFO - 2017-01-10 02:05:03 --> Form Validation Class Initialized
INFO - 2017-01-10 02:05:03 --> Final output sent to browser
DEBUG - 2017-01-10 02:05:03 --> Total execution time: 0.0143
INFO - 2017-01-10 02:05:33 --> Config Class Initialized
INFO - 2017-01-10 02:05:33 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:05:33 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:05:33 --> Utf8 Class Initialized
INFO - 2017-01-10 02:05:33 --> URI Class Initialized
INFO - 2017-01-10 02:05:33 --> Router Class Initialized
INFO - 2017-01-10 02:05:33 --> Output Class Initialized
INFO - 2017-01-10 02:05:33 --> Security Class Initialized
DEBUG - 2017-01-10 02:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:05:33 --> Input Class Initialized
INFO - 2017-01-10 02:05:33 --> Language Class Initialized
INFO - 2017-01-10 02:05:33 --> Loader Class Initialized
INFO - 2017-01-10 02:05:33 --> Database Driver Class Initialized
INFO - 2017-01-10 02:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:05:33 --> Controller Class Initialized
INFO - 2017-01-10 02:05:33 --> Helper loaded: date_helper
INFO - 2017-01-10 02:05:33 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:05:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:05:33 --> Helper loaded: form_helper
INFO - 2017-01-10 02:05:33 --> Form Validation Class Initialized
INFO - 2017-01-10 02:05:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:05:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 02:05:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-10 02:05:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-10 02:05:33 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:05:33 --> Final output sent to browser
DEBUG - 2017-01-10 02:05:33 --> Total execution time: 0.0866
INFO - 2017-01-10 02:05:33 --> Config Class Initialized
INFO - 2017-01-10 02:05:33 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:05:33 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:05:33 --> Utf8 Class Initialized
INFO - 2017-01-10 02:05:33 --> URI Class Initialized
INFO - 2017-01-10 02:05:33 --> Router Class Initialized
INFO - 2017-01-10 02:05:33 --> Output Class Initialized
INFO - 2017-01-10 02:05:33 --> Security Class Initialized
DEBUG - 2017-01-10 02:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:05:33 --> Input Class Initialized
INFO - 2017-01-10 02:05:33 --> Language Class Initialized
INFO - 2017-01-10 02:05:33 --> Loader Class Initialized
INFO - 2017-01-10 02:05:33 --> Database Driver Class Initialized
INFO - 2017-01-10 02:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:05:33 --> Controller Class Initialized
INFO - 2017-01-10 02:05:33 --> Helper loaded: date_helper
INFO - 2017-01-10 02:05:33 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:05:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:05:33 --> Helper loaded: form_helper
INFO - 2017-01-10 02:05:33 --> Form Validation Class Initialized
INFO - 2017-01-10 02:05:33 --> Final output sent to browser
DEBUG - 2017-01-10 02:05:33 --> Total execution time: 0.0155
INFO - 2017-01-10 02:05:33 --> Config Class Initialized
INFO - 2017-01-10 02:05:33 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:05:33 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:05:33 --> Utf8 Class Initialized
INFO - 2017-01-10 02:05:33 --> URI Class Initialized
INFO - 2017-01-10 02:05:33 --> Router Class Initialized
INFO - 2017-01-10 02:05:33 --> Output Class Initialized
INFO - 2017-01-10 02:05:33 --> Security Class Initialized
DEBUG - 2017-01-10 02:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:05:33 --> Input Class Initialized
INFO - 2017-01-10 02:05:33 --> Language Class Initialized
INFO - 2017-01-10 02:05:33 --> Loader Class Initialized
INFO - 2017-01-10 02:05:33 --> Database Driver Class Initialized
INFO - 2017-01-10 02:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:05:33 --> Controller Class Initialized
INFO - 2017-01-10 02:05:33 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:05:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:05:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:05:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:05:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:05:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:05:33 --> Final output sent to browser
DEBUG - 2017-01-10 02:05:33 --> Total execution time: 0.0684
INFO - 2017-01-10 02:05:41 --> Config Class Initialized
INFO - 2017-01-10 02:05:41 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:05:41 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:05:41 --> Utf8 Class Initialized
INFO - 2017-01-10 02:05:41 --> URI Class Initialized
INFO - 2017-01-10 02:05:41 --> Router Class Initialized
INFO - 2017-01-10 02:05:41 --> Output Class Initialized
INFO - 2017-01-10 02:05:41 --> Security Class Initialized
DEBUG - 2017-01-10 02:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:05:41 --> Input Class Initialized
INFO - 2017-01-10 02:05:41 --> Language Class Initialized
INFO - 2017-01-10 02:05:41 --> Loader Class Initialized
INFO - 2017-01-10 02:05:41 --> Database Driver Class Initialized
INFO - 2017-01-10 02:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:05:41 --> Controller Class Initialized
INFO - 2017-01-10 02:05:41 --> Helper loaded: date_helper
INFO - 2017-01-10 02:05:41 --> Config Class Initialized
INFO - 2017-01-10 02:05:41 --> Hooks Class Initialized
INFO - 2017-01-10 02:05:41 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:05:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-01-10 02:05:41 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:05:41 --> Utf8 Class Initialized
INFO - 2017-01-10 02:05:41 --> URI Class Initialized
INFO - 2017-01-10 02:05:41 --> Helper loaded: form_helper
INFO - 2017-01-10 02:05:41 --> Form Validation Class Initialized
INFO - 2017-01-10 02:05:41 --> Router Class Initialized
INFO - 2017-01-10 02:05:41 --> Output Class Initialized
INFO - 2017-01-10 02:05:41 --> Security Class Initialized
DEBUG - 2017-01-10 02:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:05:41 --> Input Class Initialized
INFO - 2017-01-10 02:05:41 --> Language Class Initialized
INFO - 2017-01-10 02:05:41 --> Loader Class Initialized
INFO - 2017-01-10 02:05:41 --> Database Driver Class Initialized
INFO - 2017-01-10 02:05:41 --> Final output sent to browser
DEBUG - 2017-01-10 02:05:41 --> Total execution time: 0.0870
INFO - 2017-01-10 02:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:05:41 --> Controller Class Initialized
INFO - 2017-01-10 02:05:41 --> Helper loaded: date_helper
INFO - 2017-01-10 02:05:41 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:05:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:05:41 --> Helper loaded: form_helper
INFO - 2017-01-10 02:05:41 --> Form Validation Class Initialized
INFO - 2017-01-10 02:05:41 --> Final output sent to browser
DEBUG - 2017-01-10 02:05:41 --> Total execution time: 0.0273
INFO - 2017-01-10 02:05:55 --> Config Class Initialized
INFO - 2017-01-10 02:05:55 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:05:55 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:05:55 --> Utf8 Class Initialized
INFO - 2017-01-10 02:05:55 --> URI Class Initialized
INFO - 2017-01-10 02:05:55 --> Router Class Initialized
INFO - 2017-01-10 02:05:55 --> Output Class Initialized
INFO - 2017-01-10 02:05:55 --> Security Class Initialized
DEBUG - 2017-01-10 02:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:05:55 --> Input Class Initialized
INFO - 2017-01-10 02:05:55 --> Language Class Initialized
INFO - 2017-01-10 02:05:55 --> Loader Class Initialized
INFO - 2017-01-10 02:05:55 --> Database Driver Class Initialized
INFO - 2017-01-10 02:05:55 --> Config Class Initialized
INFO - 2017-01-10 02:05:55 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:05:55 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:05:55 --> Utf8 Class Initialized
INFO - 2017-01-10 02:05:55 --> URI Class Initialized
INFO - 2017-01-10 02:05:55 --> Router Class Initialized
INFO - 2017-01-10 02:05:55 --> Output Class Initialized
INFO - 2017-01-10 02:05:55 --> Security Class Initialized
DEBUG - 2017-01-10 02:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:05:55 --> Input Class Initialized
INFO - 2017-01-10 02:05:55 --> Language Class Initialized
INFO - 2017-01-10 02:05:55 --> Loader Class Initialized
INFO - 2017-01-10 02:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:05:55 --> Controller Class Initialized
INFO - 2017-01-10 02:05:55 --> Helper loaded: date_helper
INFO - 2017-01-10 02:05:55 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:05:55 --> Helper loaded: form_helper
INFO - 2017-01-10 02:05:55 --> Form Validation Class Initialized
INFO - 2017-01-10 02:05:55 --> Database Driver Class Initialized
INFO - 2017-01-10 02:05:55 --> Final output sent to browser
DEBUG - 2017-01-10 02:05:55 --> Total execution time: 0.0970
INFO - 2017-01-10 02:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:05:55 --> Controller Class Initialized
INFO - 2017-01-10 02:05:55 --> Helper loaded: date_helper
INFO - 2017-01-10 02:05:55 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:05:55 --> Helper loaded: form_helper
INFO - 2017-01-10 02:05:55 --> Form Validation Class Initialized
INFO - 2017-01-10 02:05:55 --> Final output sent to browser
DEBUG - 2017-01-10 02:05:55 --> Total execution time: 0.0250
INFO - 2017-01-10 02:06:02 --> Config Class Initialized
INFO - 2017-01-10 02:06:02 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:06:02 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:06:02 --> Utf8 Class Initialized
INFO - 2017-01-10 02:06:02 --> URI Class Initialized
INFO - 2017-01-10 02:06:02 --> Router Class Initialized
INFO - 2017-01-10 02:06:02 --> Output Class Initialized
INFO - 2017-01-10 02:06:02 --> Security Class Initialized
DEBUG - 2017-01-10 02:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:06:02 --> Input Class Initialized
INFO - 2017-01-10 02:06:02 --> Language Class Initialized
INFO - 2017-01-10 02:06:02 --> Loader Class Initialized
INFO - 2017-01-10 02:06:02 --> Database Driver Class Initialized
INFO - 2017-01-10 02:06:02 --> Config Class Initialized
INFO - 2017-01-10 02:06:02 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:06:02 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:06:02 --> Utf8 Class Initialized
INFO - 2017-01-10 02:06:02 --> URI Class Initialized
INFO - 2017-01-10 02:06:02 --> Router Class Initialized
INFO - 2017-01-10 02:06:02 --> Output Class Initialized
INFO - 2017-01-10 02:06:02 --> Security Class Initialized
DEBUG - 2017-01-10 02:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:06:02 --> Input Class Initialized
INFO - 2017-01-10 02:06:02 --> Language Class Initialized
INFO - 2017-01-10 02:06:02 --> Loader Class Initialized
INFO - 2017-01-10 02:06:02 --> Database Driver Class Initialized
INFO - 2017-01-10 02:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:06:02 --> Controller Class Initialized
INFO - 2017-01-10 02:06:02 --> Helper loaded: date_helper
INFO - 2017-01-10 02:06:02 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:06:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:06:02 --> Helper loaded: form_helper
INFO - 2017-01-10 02:06:02 --> Form Validation Class Initialized
INFO - 2017-01-10 02:06:02 --> Final output sent to browser
DEBUG - 2017-01-10 02:06:02 --> Total execution time: 0.0414
INFO - 2017-01-10 02:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:06:02 --> Controller Class Initialized
INFO - 2017-01-10 02:06:02 --> Helper loaded: date_helper
INFO - 2017-01-10 02:06:02 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:06:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:06:02 --> Helper loaded: form_helper
INFO - 2017-01-10 02:06:02 --> Form Validation Class Initialized
INFO - 2017-01-10 02:06:02 --> Final output sent to browser
DEBUG - 2017-01-10 02:06:02 --> Total execution time: 0.0263
INFO - 2017-01-10 02:06:18 --> Config Class Initialized
INFO - 2017-01-10 02:06:18 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:06:18 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:06:18 --> Utf8 Class Initialized
INFO - 2017-01-10 02:06:18 --> URI Class Initialized
INFO - 2017-01-10 02:06:18 --> Router Class Initialized
INFO - 2017-01-10 02:06:18 --> Output Class Initialized
INFO - 2017-01-10 02:06:18 --> Security Class Initialized
DEBUG - 2017-01-10 02:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:06:18 --> Input Class Initialized
INFO - 2017-01-10 02:06:18 --> Language Class Initialized
INFO - 2017-01-10 02:06:18 --> Loader Class Initialized
INFO - 2017-01-10 02:06:18 --> Database Driver Class Initialized
INFO - 2017-01-10 02:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:06:18 --> Controller Class Initialized
INFO - 2017-01-10 02:06:18 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:06:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:06:18 --> Helper loaded: url_helper
INFO - 2017-01-10 02:06:18 --> Helper loaded: download_helper
INFO - 2017-01-10 02:06:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:06:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:06:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-10 02:06:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-10 02:06:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:06:18 --> Final output sent to browser
DEBUG - 2017-01-10 02:06:18 --> Total execution time: 0.0222
INFO - 2017-01-10 02:06:25 --> Config Class Initialized
INFO - 2017-01-10 02:06:25 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:06:25 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:06:25 --> Utf8 Class Initialized
INFO - 2017-01-10 02:06:25 --> URI Class Initialized
INFO - 2017-01-10 02:06:25 --> Router Class Initialized
INFO - 2017-01-10 02:06:25 --> Output Class Initialized
INFO - 2017-01-10 02:06:25 --> Security Class Initialized
DEBUG - 2017-01-10 02:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:06:25 --> Input Class Initialized
INFO - 2017-01-10 02:06:25 --> Language Class Initialized
INFO - 2017-01-10 02:06:25 --> Loader Class Initialized
INFO - 2017-01-10 02:06:25 --> Database Driver Class Initialized
INFO - 2017-01-10 02:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:06:25 --> Controller Class Initialized
INFO - 2017-01-10 02:06:25 --> Helper loaded: date_helper
INFO - 2017-01-10 02:06:25 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:06:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:06:25 --> Helper loaded: form_helper
INFO - 2017-01-10 02:06:25 --> Form Validation Class Initialized
INFO - 2017-01-10 02:06:25 --> Final output sent to browser
DEBUG - 2017-01-10 02:06:25 --> Total execution time: 0.0309
INFO - 2017-01-10 02:06:32 --> Config Class Initialized
INFO - 2017-01-10 02:06:32 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:06:32 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:06:32 --> Utf8 Class Initialized
INFO - 2017-01-10 02:06:32 --> URI Class Initialized
INFO - 2017-01-10 02:06:32 --> Router Class Initialized
INFO - 2017-01-10 02:06:32 --> Output Class Initialized
INFO - 2017-01-10 02:06:32 --> Security Class Initialized
DEBUG - 2017-01-10 02:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:06:32 --> Input Class Initialized
INFO - 2017-01-10 02:06:32 --> Language Class Initialized
INFO - 2017-01-10 02:06:32 --> Loader Class Initialized
INFO - 2017-01-10 02:06:32 --> Database Driver Class Initialized
INFO - 2017-01-10 02:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:06:32 --> Controller Class Initialized
INFO - 2017-01-10 02:06:32 --> Helper loaded: date_helper
INFO - 2017-01-10 02:06:32 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:06:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:06:32 --> Helper loaded: form_helper
INFO - 2017-01-10 02:06:32 --> Form Validation Class Initialized
INFO - 2017-01-10 02:06:32 --> Final output sent to browser
DEBUG - 2017-01-10 02:06:32 --> Total execution time: 0.0153
INFO - 2017-01-10 02:06:35 --> Config Class Initialized
INFO - 2017-01-10 02:06:35 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:06:35 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:06:35 --> Utf8 Class Initialized
INFO - 2017-01-10 02:06:35 --> URI Class Initialized
INFO - 2017-01-10 02:06:35 --> Router Class Initialized
INFO - 2017-01-10 02:06:35 --> Output Class Initialized
INFO - 2017-01-10 02:06:35 --> Security Class Initialized
DEBUG - 2017-01-10 02:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:06:35 --> Input Class Initialized
INFO - 2017-01-10 02:06:35 --> Language Class Initialized
INFO - 2017-01-10 02:06:35 --> Loader Class Initialized
INFO - 2017-01-10 02:06:35 --> Database Driver Class Initialized
INFO - 2017-01-10 02:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:06:35 --> Controller Class Initialized
INFO - 2017-01-10 02:06:35 --> Helper loaded: date_helper
INFO - 2017-01-10 02:06:35 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:06:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:06:35 --> Helper loaded: form_helper
INFO - 2017-01-10 02:06:35 --> Form Validation Class Initialized
INFO - 2017-01-10 02:06:35 --> Final output sent to browser
DEBUG - 2017-01-10 02:06:35 --> Total execution time: 0.0138
INFO - 2017-01-10 02:06:37 --> Config Class Initialized
INFO - 2017-01-10 02:06:37 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:06:37 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:06:37 --> Utf8 Class Initialized
INFO - 2017-01-10 02:06:37 --> URI Class Initialized
INFO - 2017-01-10 02:06:37 --> Router Class Initialized
INFO - 2017-01-10 02:06:37 --> Output Class Initialized
INFO - 2017-01-10 02:06:37 --> Security Class Initialized
DEBUG - 2017-01-10 02:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:06:37 --> Input Class Initialized
INFO - 2017-01-10 02:06:37 --> Language Class Initialized
INFO - 2017-01-10 02:06:37 --> Loader Class Initialized
INFO - 2017-01-10 02:06:37 --> Database Driver Class Initialized
INFO - 2017-01-10 02:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:06:37 --> Controller Class Initialized
INFO - 2017-01-10 02:06:37 --> Helper loaded: date_helper
INFO - 2017-01-10 02:06:37 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:06:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:06:37 --> Helper loaded: form_helper
INFO - 2017-01-10 02:06:37 --> Form Validation Class Initialized
INFO - 2017-01-10 02:06:37 --> Final output sent to browser
DEBUG - 2017-01-10 02:06:37 --> Total execution time: 0.0154
INFO - 2017-01-10 02:06:51 --> Config Class Initialized
INFO - 2017-01-10 02:06:51 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:06:51 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:06:51 --> Utf8 Class Initialized
INFO - 2017-01-10 02:06:51 --> URI Class Initialized
INFO - 2017-01-10 02:06:51 --> Router Class Initialized
INFO - 2017-01-10 02:06:51 --> Output Class Initialized
INFO - 2017-01-10 02:06:51 --> Security Class Initialized
DEBUG - 2017-01-10 02:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:06:51 --> Input Class Initialized
INFO - 2017-01-10 02:06:51 --> Language Class Initialized
INFO - 2017-01-10 02:06:51 --> Loader Class Initialized
INFO - 2017-01-10 02:06:51 --> Database Driver Class Initialized
INFO - 2017-01-10 02:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:06:51 --> Controller Class Initialized
INFO - 2017-01-10 02:06:51 --> Helper loaded: date_helper
INFO - 2017-01-10 02:06:51 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:06:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:06:51 --> Helper loaded: form_helper
INFO - 2017-01-10 02:06:51 --> Form Validation Class Initialized
INFO - 2017-01-10 02:06:51 --> Final output sent to browser
DEBUG - 2017-01-10 02:06:51 --> Total execution time: 0.0158
INFO - 2017-01-10 02:06:52 --> Config Class Initialized
INFO - 2017-01-10 02:06:52 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:06:52 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:06:52 --> Utf8 Class Initialized
INFO - 2017-01-10 02:06:52 --> URI Class Initialized
INFO - 2017-01-10 02:06:52 --> Router Class Initialized
INFO - 2017-01-10 02:06:52 --> Output Class Initialized
INFO - 2017-01-10 02:06:52 --> Security Class Initialized
DEBUG - 2017-01-10 02:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:06:52 --> Input Class Initialized
INFO - 2017-01-10 02:06:52 --> Language Class Initialized
INFO - 2017-01-10 02:06:52 --> Loader Class Initialized
INFO - 2017-01-10 02:06:52 --> Database Driver Class Initialized
INFO - 2017-01-10 02:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:06:52 --> Controller Class Initialized
INFO - 2017-01-10 02:06:52 --> Helper loaded: date_helper
INFO - 2017-01-10 02:06:52 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:06:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:06:52 --> Helper loaded: form_helper
INFO - 2017-01-10 02:06:52 --> Form Validation Class Initialized
INFO - 2017-01-10 02:06:52 --> Final output sent to browser
DEBUG - 2017-01-10 02:06:52 --> Total execution time: 0.0177
INFO - 2017-01-10 02:06:56 --> Config Class Initialized
INFO - 2017-01-10 02:06:56 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:06:56 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:06:56 --> Utf8 Class Initialized
INFO - 2017-01-10 02:06:56 --> URI Class Initialized
INFO - 2017-01-10 02:06:56 --> Router Class Initialized
INFO - 2017-01-10 02:06:56 --> Output Class Initialized
INFO - 2017-01-10 02:06:56 --> Security Class Initialized
DEBUG - 2017-01-10 02:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:06:56 --> Input Class Initialized
INFO - 2017-01-10 02:06:56 --> Language Class Initialized
INFO - 2017-01-10 02:06:56 --> Loader Class Initialized
INFO - 2017-01-10 02:06:56 --> Database Driver Class Initialized
INFO - 2017-01-10 02:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:06:56 --> Controller Class Initialized
INFO - 2017-01-10 02:06:56 --> Helper loaded: date_helper
INFO - 2017-01-10 02:06:56 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:06:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:06:56 --> Helper loaded: form_helper
INFO - 2017-01-10 02:06:56 --> Form Validation Class Initialized
INFO - 2017-01-10 02:06:56 --> Final output sent to browser
DEBUG - 2017-01-10 02:06:56 --> Total execution time: 0.0149
INFO - 2017-01-10 02:06:57 --> Config Class Initialized
INFO - 2017-01-10 02:06:57 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:06:57 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:06:57 --> Utf8 Class Initialized
INFO - 2017-01-10 02:06:57 --> URI Class Initialized
INFO - 2017-01-10 02:06:57 --> Router Class Initialized
INFO - 2017-01-10 02:06:57 --> Output Class Initialized
INFO - 2017-01-10 02:06:57 --> Security Class Initialized
DEBUG - 2017-01-10 02:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:06:57 --> Input Class Initialized
INFO - 2017-01-10 02:06:57 --> Language Class Initialized
INFO - 2017-01-10 02:06:57 --> Loader Class Initialized
INFO - 2017-01-10 02:06:57 --> Database Driver Class Initialized
INFO - 2017-01-10 02:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:06:57 --> Controller Class Initialized
INFO - 2017-01-10 02:06:57 --> Helper loaded: date_helper
INFO - 2017-01-10 02:06:57 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:06:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:06:57 --> Helper loaded: form_helper
INFO - 2017-01-10 02:06:57 --> Form Validation Class Initialized
INFO - 2017-01-10 02:06:57 --> Final output sent to browser
DEBUG - 2017-01-10 02:06:57 --> Total execution time: 0.0170
INFO - 2017-01-10 02:06:58 --> Config Class Initialized
INFO - 2017-01-10 02:06:58 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:06:58 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:06:58 --> Utf8 Class Initialized
INFO - 2017-01-10 02:06:58 --> URI Class Initialized
INFO - 2017-01-10 02:06:58 --> Router Class Initialized
INFO - 2017-01-10 02:06:58 --> Output Class Initialized
INFO - 2017-01-10 02:06:58 --> Security Class Initialized
DEBUG - 2017-01-10 02:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:06:58 --> Input Class Initialized
INFO - 2017-01-10 02:06:58 --> Language Class Initialized
INFO - 2017-01-10 02:06:58 --> Loader Class Initialized
INFO - 2017-01-10 02:06:58 --> Database Driver Class Initialized
INFO - 2017-01-10 02:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:06:58 --> Controller Class Initialized
INFO - 2017-01-10 02:06:58 --> Helper loaded: date_helper
INFO - 2017-01-10 02:06:58 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:06:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:06:58 --> Helper loaded: form_helper
INFO - 2017-01-10 02:06:58 --> Form Validation Class Initialized
INFO - 2017-01-10 02:06:58 --> Final output sent to browser
DEBUG - 2017-01-10 02:06:58 --> Total execution time: 0.0172
INFO - 2017-01-10 02:06:59 --> Config Class Initialized
INFO - 2017-01-10 02:06:59 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:06:59 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:06:59 --> Utf8 Class Initialized
INFO - 2017-01-10 02:06:59 --> URI Class Initialized
INFO - 2017-01-10 02:06:59 --> Router Class Initialized
INFO - 2017-01-10 02:06:59 --> Output Class Initialized
INFO - 2017-01-10 02:06:59 --> Security Class Initialized
DEBUG - 2017-01-10 02:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:06:59 --> Input Class Initialized
INFO - 2017-01-10 02:06:59 --> Language Class Initialized
INFO - 2017-01-10 02:06:59 --> Loader Class Initialized
INFO - 2017-01-10 02:06:59 --> Database Driver Class Initialized
INFO - 2017-01-10 02:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:06:59 --> Controller Class Initialized
INFO - 2017-01-10 02:06:59 --> Helper loaded: date_helper
INFO - 2017-01-10 02:06:59 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:06:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:06:59 --> Helper loaded: form_helper
INFO - 2017-01-10 02:06:59 --> Form Validation Class Initialized
INFO - 2017-01-10 02:06:59 --> Final output sent to browser
DEBUG - 2017-01-10 02:06:59 --> Total execution time: 0.0168
INFO - 2017-01-10 02:07:02 --> Config Class Initialized
INFO - 2017-01-10 02:07:02 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:07:02 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:07:02 --> Utf8 Class Initialized
INFO - 2017-01-10 02:07:02 --> URI Class Initialized
INFO - 2017-01-10 02:07:02 --> Router Class Initialized
INFO - 2017-01-10 02:07:02 --> Output Class Initialized
INFO - 2017-01-10 02:07:02 --> Security Class Initialized
DEBUG - 2017-01-10 02:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:07:02 --> Input Class Initialized
INFO - 2017-01-10 02:07:02 --> Language Class Initialized
INFO - 2017-01-10 02:07:02 --> Loader Class Initialized
INFO - 2017-01-10 02:07:02 --> Database Driver Class Initialized
INFO - 2017-01-10 02:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:07:02 --> Controller Class Initialized
INFO - 2017-01-10 02:07:02 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:07:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:07:02 --> Helper loaded: url_helper
INFO - 2017-01-10 02:07:02 --> Helper loaded: download_helper
INFO - 2017-01-10 02:07:06 --> Config Class Initialized
INFO - 2017-01-10 02:07:06 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:07:06 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:07:06 --> Utf8 Class Initialized
INFO - 2017-01-10 02:07:06 --> URI Class Initialized
INFO - 2017-01-10 02:07:06 --> Router Class Initialized
INFO - 2017-01-10 02:07:06 --> Output Class Initialized
INFO - 2017-01-10 02:07:06 --> Security Class Initialized
DEBUG - 2017-01-10 02:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:07:06 --> Input Class Initialized
INFO - 2017-01-10 02:07:06 --> Language Class Initialized
INFO - 2017-01-10 02:07:06 --> Loader Class Initialized
INFO - 2017-01-10 02:07:06 --> Database Driver Class Initialized
INFO - 2017-01-10 02:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:07:06 --> Controller Class Initialized
INFO - 2017-01-10 02:07:06 --> Upload Class Initialized
INFO - 2017-01-10 02:07:06 --> Helper loaded: date_helper
INFO - 2017-01-10 02:07:06 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:07:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:07:06 --> Helper loaded: form_helper
INFO - 2017-01-10 02:07:06 --> Form Validation Class Initialized
INFO - 2017-01-10 02:07:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:07:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 02:07:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-10 02:07:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-10 02:07:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-10 02:07:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:07:07 --> Final output sent to browser
DEBUG - 2017-01-10 02:07:07 --> Total execution time: 0.0520
INFO - 2017-01-10 02:07:07 --> Config Class Initialized
INFO - 2017-01-10 02:07:07 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:07:07 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:07:07 --> Utf8 Class Initialized
INFO - 2017-01-10 02:07:07 --> URI Class Initialized
INFO - 2017-01-10 02:07:07 --> Router Class Initialized
INFO - 2017-01-10 02:07:07 --> Output Class Initialized
INFO - 2017-01-10 02:07:07 --> Security Class Initialized
DEBUG - 2017-01-10 02:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:07:07 --> Input Class Initialized
INFO - 2017-01-10 02:07:07 --> Language Class Initialized
INFO - 2017-01-10 02:07:07 --> Loader Class Initialized
INFO - 2017-01-10 02:07:07 --> Database Driver Class Initialized
INFO - 2017-01-10 02:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:07:07 --> Controller Class Initialized
INFO - 2017-01-10 02:07:07 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:07:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:07:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:07:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:07:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:07:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:07:07 --> Final output sent to browser
DEBUG - 2017-01-10 02:07:07 --> Total execution time: 0.0137
INFO - 2017-01-10 02:07:09 --> Config Class Initialized
INFO - 2017-01-10 02:07:09 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:07:09 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:07:09 --> Utf8 Class Initialized
INFO - 2017-01-10 02:07:09 --> URI Class Initialized
INFO - 2017-01-10 02:07:09 --> Router Class Initialized
INFO - 2017-01-10 02:07:09 --> Output Class Initialized
INFO - 2017-01-10 02:07:09 --> Security Class Initialized
DEBUG - 2017-01-10 02:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:07:09 --> Input Class Initialized
INFO - 2017-01-10 02:07:09 --> Language Class Initialized
INFO - 2017-01-10 02:07:09 --> Loader Class Initialized
INFO - 2017-01-10 02:07:09 --> Database Driver Class Initialized
INFO - 2017-01-10 02:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:07:09 --> Controller Class Initialized
INFO - 2017-01-10 02:07:09 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:07:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:07:09 --> Helper loaded: url_helper
INFO - 2017-01-10 02:07:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:07:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:07:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-10 02:07:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-10 02:07:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:07:09 --> Final output sent to browser
DEBUG - 2017-01-10 02:07:09 --> Total execution time: 0.0517
INFO - 2017-01-10 02:07:12 --> Config Class Initialized
INFO - 2017-01-10 02:07:12 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:07:12 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:07:12 --> Utf8 Class Initialized
INFO - 2017-01-10 02:07:12 --> URI Class Initialized
INFO - 2017-01-10 02:07:12 --> Router Class Initialized
INFO - 2017-01-10 02:07:12 --> Output Class Initialized
INFO - 2017-01-10 02:07:12 --> Security Class Initialized
DEBUG - 2017-01-10 02:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:07:12 --> Input Class Initialized
INFO - 2017-01-10 02:07:12 --> Language Class Initialized
INFO - 2017-01-10 02:07:12 --> Loader Class Initialized
INFO - 2017-01-10 02:07:12 --> Database Driver Class Initialized
INFO - 2017-01-10 02:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:07:12 --> Controller Class Initialized
INFO - 2017-01-10 02:07:12 --> Upload Class Initialized
INFO - 2017-01-10 02:07:12 --> Helper loaded: date_helper
INFO - 2017-01-10 02:07:12 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:07:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:07:12 --> Helper loaded: form_helper
INFO - 2017-01-10 02:07:12 --> Form Validation Class Initialized
INFO - 2017-01-10 02:07:12 --> Final output sent to browser
DEBUG - 2017-01-10 02:07:12 --> Total execution time: 0.0161
INFO - 2017-01-10 02:07:20 --> Config Class Initialized
INFO - 2017-01-10 02:07:20 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:07:20 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:07:20 --> Utf8 Class Initialized
INFO - 2017-01-10 02:07:20 --> URI Class Initialized
INFO - 2017-01-10 02:07:20 --> Router Class Initialized
INFO - 2017-01-10 02:07:20 --> Output Class Initialized
INFO - 2017-01-10 02:07:20 --> Security Class Initialized
DEBUG - 2017-01-10 02:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:07:20 --> Input Class Initialized
INFO - 2017-01-10 02:07:20 --> Language Class Initialized
INFO - 2017-01-10 02:07:20 --> Loader Class Initialized
INFO - 2017-01-10 02:07:20 --> Database Driver Class Initialized
INFO - 2017-01-10 02:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:07:20 --> Controller Class Initialized
INFO - 2017-01-10 02:07:20 --> Helper loaded: date_helper
INFO - 2017-01-10 02:07:20 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:07:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:07:20 --> Helper loaded: form_helper
INFO - 2017-01-10 02:07:20 --> Form Validation Class Initialized
INFO - 2017-01-10 02:07:20 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:07:20 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 02:07:20 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-10 02:07:20 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-10 02:07:20 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:07:20 --> Final output sent to browser
DEBUG - 2017-01-10 02:07:20 --> Total execution time: 0.0696
INFO - 2017-01-10 02:07:20 --> Config Class Initialized
INFO - 2017-01-10 02:07:20 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:07:20 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:07:20 --> Utf8 Class Initialized
INFO - 2017-01-10 02:07:20 --> URI Class Initialized
INFO - 2017-01-10 02:07:20 --> Router Class Initialized
INFO - 2017-01-10 02:07:20 --> Output Class Initialized
INFO - 2017-01-10 02:07:20 --> Security Class Initialized
DEBUG - 2017-01-10 02:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:07:20 --> Input Class Initialized
INFO - 2017-01-10 02:07:20 --> Language Class Initialized
INFO - 2017-01-10 02:07:20 --> Loader Class Initialized
INFO - 2017-01-10 02:07:20 --> Database Driver Class Initialized
INFO - 2017-01-10 02:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:07:20 --> Controller Class Initialized
INFO - 2017-01-10 02:07:20 --> Helper loaded: date_helper
INFO - 2017-01-10 02:07:20 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:07:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:07:20 --> Helper loaded: form_helper
INFO - 2017-01-10 02:07:20 --> Form Validation Class Initialized
INFO - 2017-01-10 02:07:20 --> Final output sent to browser
DEBUG - 2017-01-10 02:07:20 --> Total execution time: 0.0152
INFO - 2017-01-10 02:07:20 --> Config Class Initialized
INFO - 2017-01-10 02:07:20 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:07:20 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:07:20 --> Utf8 Class Initialized
INFO - 2017-01-10 02:07:20 --> URI Class Initialized
INFO - 2017-01-10 02:07:20 --> Router Class Initialized
INFO - 2017-01-10 02:07:20 --> Output Class Initialized
INFO - 2017-01-10 02:07:20 --> Security Class Initialized
DEBUG - 2017-01-10 02:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:07:20 --> Input Class Initialized
INFO - 2017-01-10 02:07:20 --> Language Class Initialized
INFO - 2017-01-10 02:07:20 --> Loader Class Initialized
INFO - 2017-01-10 02:07:20 --> Database Driver Class Initialized
INFO - 2017-01-10 02:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:07:20 --> Controller Class Initialized
INFO - 2017-01-10 02:07:20 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:07:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:07:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:07:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:07:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:07:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:07:20 --> Final output sent to browser
DEBUG - 2017-01-10 02:07:20 --> Total execution time: 0.0224
INFO - 2017-01-10 02:07:24 --> Config Class Initialized
INFO - 2017-01-10 02:07:24 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:07:24 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:07:24 --> Utf8 Class Initialized
INFO - 2017-01-10 02:07:24 --> URI Class Initialized
INFO - 2017-01-10 02:07:24 --> Router Class Initialized
INFO - 2017-01-10 02:07:24 --> Output Class Initialized
INFO - 2017-01-10 02:07:24 --> Security Class Initialized
DEBUG - 2017-01-10 02:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:07:24 --> Input Class Initialized
INFO - 2017-01-10 02:07:24 --> Language Class Initialized
INFO - 2017-01-10 02:07:24 --> Loader Class Initialized
INFO - 2017-01-10 02:07:24 --> Database Driver Class Initialized
INFO - 2017-01-10 02:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:07:24 --> Controller Class Initialized
INFO - 2017-01-10 02:07:24 --> Helper loaded: date_helper
INFO - 2017-01-10 02:07:24 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:07:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:07:24 --> Helper loaded: form_helper
INFO - 2017-01-10 02:07:24 --> Form Validation Class Initialized
INFO - 2017-01-10 02:07:24 --> Final output sent to browser
DEBUG - 2017-01-10 02:07:24 --> Total execution time: 0.0452
INFO - 2017-01-10 02:07:33 --> Config Class Initialized
INFO - 2017-01-10 02:07:33 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:07:33 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:07:33 --> Utf8 Class Initialized
INFO - 2017-01-10 02:07:33 --> URI Class Initialized
INFO - 2017-01-10 02:07:33 --> Router Class Initialized
INFO - 2017-01-10 02:07:33 --> Output Class Initialized
INFO - 2017-01-10 02:07:33 --> Security Class Initialized
DEBUG - 2017-01-10 02:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:07:33 --> Input Class Initialized
INFO - 2017-01-10 02:07:33 --> Language Class Initialized
INFO - 2017-01-10 02:07:33 --> Loader Class Initialized
INFO - 2017-01-10 02:07:33 --> Database Driver Class Initialized
INFO - 2017-01-10 02:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:07:33 --> Controller Class Initialized
INFO - 2017-01-10 02:07:33 --> Helper loaded: date_helper
INFO - 2017-01-10 02:07:33 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:07:33 --> Helper loaded: form_helper
INFO - 2017-01-10 02:07:33 --> Form Validation Class Initialized
INFO - 2017-01-10 02:07:33 --> Final output sent to browser
DEBUG - 2017-01-10 02:07:33 --> Total execution time: 0.0577
INFO - 2017-01-10 02:07:42 --> Config Class Initialized
INFO - 2017-01-10 02:07:42 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:07:42 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:07:42 --> Utf8 Class Initialized
INFO - 2017-01-10 02:07:42 --> URI Class Initialized
INFO - 2017-01-10 02:07:42 --> Router Class Initialized
INFO - 2017-01-10 02:07:42 --> Output Class Initialized
INFO - 2017-01-10 02:07:42 --> Security Class Initialized
DEBUG - 2017-01-10 02:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:07:42 --> Input Class Initialized
INFO - 2017-01-10 02:07:42 --> Language Class Initialized
INFO - 2017-01-10 02:07:42 --> Loader Class Initialized
INFO - 2017-01-10 02:07:42 --> Database Driver Class Initialized
INFO - 2017-01-10 02:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:07:42 --> Controller Class Initialized
INFO - 2017-01-10 02:07:42 --> Helper loaded: date_helper
INFO - 2017-01-10 02:07:42 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:07:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:07:42 --> Helper loaded: form_helper
INFO - 2017-01-10 02:07:42 --> Form Validation Class Initialized
INFO - 2017-01-10 02:07:42 --> Final output sent to browser
DEBUG - 2017-01-10 02:07:42 --> Total execution time: 0.0165
INFO - 2017-01-10 02:07:45 --> Config Class Initialized
INFO - 2017-01-10 02:07:45 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:07:45 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:07:45 --> Utf8 Class Initialized
INFO - 2017-01-10 02:07:45 --> URI Class Initialized
INFO - 2017-01-10 02:07:45 --> Router Class Initialized
INFO - 2017-01-10 02:07:45 --> Output Class Initialized
INFO - 2017-01-10 02:07:45 --> Security Class Initialized
DEBUG - 2017-01-10 02:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:07:45 --> Input Class Initialized
INFO - 2017-01-10 02:07:45 --> Language Class Initialized
INFO - 2017-01-10 02:07:45 --> Loader Class Initialized
INFO - 2017-01-10 02:07:45 --> Database Driver Class Initialized
INFO - 2017-01-10 02:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:07:45 --> Controller Class Initialized
INFO - 2017-01-10 02:07:45 --> Helper loaded: date_helper
INFO - 2017-01-10 02:07:45 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:07:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:07:45 --> Helper loaded: form_helper
INFO - 2017-01-10 02:07:45 --> Form Validation Class Initialized
INFO - 2017-01-10 02:07:45 --> Final output sent to browser
DEBUG - 2017-01-10 02:07:45 --> Total execution time: 0.0144
INFO - 2017-01-10 02:07:46 --> Config Class Initialized
INFO - 2017-01-10 02:07:46 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:07:46 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:07:46 --> Utf8 Class Initialized
INFO - 2017-01-10 02:07:46 --> URI Class Initialized
INFO - 2017-01-10 02:07:46 --> Router Class Initialized
INFO - 2017-01-10 02:07:46 --> Output Class Initialized
INFO - 2017-01-10 02:07:46 --> Security Class Initialized
DEBUG - 2017-01-10 02:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:07:46 --> Input Class Initialized
INFO - 2017-01-10 02:07:46 --> Language Class Initialized
INFO - 2017-01-10 02:07:46 --> Loader Class Initialized
INFO - 2017-01-10 02:07:46 --> Database Driver Class Initialized
INFO - 2017-01-10 02:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:07:46 --> Controller Class Initialized
INFO - 2017-01-10 02:07:46 --> Helper loaded: date_helper
INFO - 2017-01-10 02:07:46 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:07:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:07:46 --> Helper loaded: form_helper
INFO - 2017-01-10 02:07:46 --> Form Validation Class Initialized
INFO - 2017-01-10 02:07:46 --> Final output sent to browser
DEBUG - 2017-01-10 02:07:46 --> Total execution time: 0.0145
INFO - 2017-01-10 02:08:09 --> Config Class Initialized
INFO - 2017-01-10 02:08:09 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:08:09 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:08:09 --> Utf8 Class Initialized
INFO - 2017-01-10 02:08:09 --> URI Class Initialized
INFO - 2017-01-10 02:08:09 --> Router Class Initialized
INFO - 2017-01-10 02:08:09 --> Output Class Initialized
INFO - 2017-01-10 02:08:09 --> Security Class Initialized
DEBUG - 2017-01-10 02:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:08:09 --> Input Class Initialized
INFO - 2017-01-10 02:08:09 --> Language Class Initialized
INFO - 2017-01-10 02:08:09 --> Loader Class Initialized
INFO - 2017-01-10 02:08:09 --> Database Driver Class Initialized
INFO - 2017-01-10 02:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:08:09 --> Controller Class Initialized
INFO - 2017-01-10 02:08:09 --> Upload Class Initialized
INFO - 2017-01-10 02:08:09 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:08:09 --> Helper loaded: form_helper
INFO - 2017-01-10 02:08:09 --> Form Validation Class Initialized
INFO - 2017-01-10 02:08:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:08:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 02:08:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-10 02:08:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-10 02:08:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-10 02:08:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:08:09 --> Final output sent to browser
DEBUG - 2017-01-10 02:08:09 --> Total execution time: 0.0313
INFO - 2017-01-10 02:08:10 --> Config Class Initialized
INFO - 2017-01-10 02:08:10 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:08:10 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:08:10 --> Utf8 Class Initialized
INFO - 2017-01-10 02:08:10 --> URI Class Initialized
INFO - 2017-01-10 02:08:10 --> Router Class Initialized
INFO - 2017-01-10 02:08:10 --> Output Class Initialized
INFO - 2017-01-10 02:08:10 --> Security Class Initialized
DEBUG - 2017-01-10 02:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:08:10 --> Input Class Initialized
INFO - 2017-01-10 02:08:10 --> Language Class Initialized
INFO - 2017-01-10 02:08:10 --> Loader Class Initialized
INFO - 2017-01-10 02:08:10 --> Database Driver Class Initialized
INFO - 2017-01-10 02:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:08:10 --> Controller Class Initialized
INFO - 2017-01-10 02:08:10 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:08:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:08:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:08:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:08:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:08:10 --> Final output sent to browser
DEBUG - 2017-01-10 02:08:10 --> Total execution time: 0.0147
INFO - 2017-01-10 02:08:16 --> Config Class Initialized
INFO - 2017-01-10 02:08:16 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:08:16 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:08:16 --> Utf8 Class Initialized
INFO - 2017-01-10 02:08:16 --> URI Class Initialized
INFO - 2017-01-10 02:08:16 --> Router Class Initialized
INFO - 2017-01-10 02:08:16 --> Output Class Initialized
INFO - 2017-01-10 02:08:16 --> Security Class Initialized
DEBUG - 2017-01-10 02:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:08:16 --> Input Class Initialized
INFO - 2017-01-10 02:08:16 --> Language Class Initialized
INFO - 2017-01-10 02:08:16 --> Loader Class Initialized
INFO - 2017-01-10 02:08:16 --> Database Driver Class Initialized
INFO - 2017-01-10 02:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:08:16 --> Controller Class Initialized
INFO - 2017-01-10 02:08:16 --> Upload Class Initialized
INFO - 2017-01-10 02:08:16 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:08:16 --> Helper loaded: form_helper
INFO - 2017-01-10 02:08:16 --> Form Validation Class Initialized
INFO - 2017-01-10 02:08:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:08:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 02:08:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-10 02:08:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-10 02:08:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-10 02:08:16 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:08:16 --> Final output sent to browser
DEBUG - 2017-01-10 02:08:16 --> Total execution time: 0.0666
INFO - 2017-01-10 02:08:17 --> Config Class Initialized
INFO - 2017-01-10 02:08:17 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:08:17 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:08:17 --> Utf8 Class Initialized
INFO - 2017-01-10 02:08:17 --> URI Class Initialized
INFO - 2017-01-10 02:08:17 --> Router Class Initialized
INFO - 2017-01-10 02:08:17 --> Output Class Initialized
INFO - 2017-01-10 02:08:17 --> Security Class Initialized
DEBUG - 2017-01-10 02:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:08:17 --> Input Class Initialized
INFO - 2017-01-10 02:08:17 --> Language Class Initialized
INFO - 2017-01-10 02:08:17 --> Loader Class Initialized
INFO - 2017-01-10 02:08:17 --> Database Driver Class Initialized
INFO - 2017-01-10 02:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:08:17 --> Controller Class Initialized
INFO - 2017-01-10 02:08:17 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:08:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:08:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:08:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:08:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:08:17 --> Final output sent to browser
DEBUG - 2017-01-10 02:08:17 --> Total execution time: 0.0134
INFO - 2017-01-10 02:08:48 --> Config Class Initialized
INFO - 2017-01-10 02:08:48 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:08:48 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:08:48 --> Utf8 Class Initialized
INFO - 2017-01-10 02:08:48 --> URI Class Initialized
INFO - 2017-01-10 02:08:48 --> Router Class Initialized
INFO - 2017-01-10 02:08:48 --> Output Class Initialized
INFO - 2017-01-10 02:08:48 --> Security Class Initialized
DEBUG - 2017-01-10 02:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:08:48 --> Input Class Initialized
INFO - 2017-01-10 02:08:48 --> Language Class Initialized
INFO - 2017-01-10 02:08:48 --> Loader Class Initialized
INFO - 2017-01-10 02:08:48 --> Database Driver Class Initialized
INFO - 2017-01-10 02:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:08:48 --> Controller Class Initialized
INFO - 2017-01-10 02:08:48 --> Upload Class Initialized
INFO - 2017-01-10 02:08:48 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:08:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:08:48 --> Helper loaded: form_helper
INFO - 2017-01-10 02:08:48 --> Form Validation Class Initialized
INFO - 2017-01-10 02:08:48 --> Final output sent to browser
DEBUG - 2017-01-10 02:08:48 --> Total execution time: 0.0294
INFO - 2017-01-10 02:09:00 --> Config Class Initialized
INFO - 2017-01-10 02:09:00 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:09:00 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:09:00 --> Utf8 Class Initialized
INFO - 2017-01-10 02:09:00 --> URI Class Initialized
INFO - 2017-01-10 02:09:00 --> Router Class Initialized
INFO - 2017-01-10 02:09:00 --> Output Class Initialized
INFO - 2017-01-10 02:09:00 --> Security Class Initialized
DEBUG - 2017-01-10 02:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:09:00 --> Input Class Initialized
INFO - 2017-01-10 02:09:00 --> Language Class Initialized
INFO - 2017-01-10 02:09:00 --> Loader Class Initialized
INFO - 2017-01-10 02:09:00 --> Database Driver Class Initialized
INFO - 2017-01-10 02:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:09:00 --> Controller Class Initialized
INFO - 2017-01-10 02:09:00 --> Upload Class Initialized
INFO - 2017-01-10 02:09:00 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:09:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:09:00 --> Helper loaded: form_helper
INFO - 2017-01-10 02:09:00 --> Form Validation Class Initialized
INFO - 2017-01-10 02:09:00 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-01-10 02:09:00 --> You did not select a file to upload.
INFO - 2017-01-10 02:09:00 --> Final output sent to browser
DEBUG - 2017-01-10 02:09:00 --> Total execution time: 0.1799
INFO - 2017-01-10 02:09:01 --> Config Class Initialized
INFO - 2017-01-10 02:09:01 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:09:01 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:09:01 --> Utf8 Class Initialized
INFO - 2017-01-10 02:09:01 --> URI Class Initialized
INFO - 2017-01-10 02:09:01 --> Router Class Initialized
INFO - 2017-01-10 02:09:01 --> Output Class Initialized
INFO - 2017-01-10 02:09:01 --> Security Class Initialized
DEBUG - 2017-01-10 02:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:09:01 --> Input Class Initialized
INFO - 2017-01-10 02:09:01 --> Language Class Initialized
INFO - 2017-01-10 02:09:01 --> Loader Class Initialized
INFO - 2017-01-10 02:09:01 --> Database Driver Class Initialized
INFO - 2017-01-10 02:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:09:01 --> Controller Class Initialized
INFO - 2017-01-10 02:09:01 --> Upload Class Initialized
INFO - 2017-01-10 02:09:01 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:09:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:09:01 --> Helper loaded: form_helper
INFO - 2017-01-10 02:09:01 --> Form Validation Class Initialized
INFO - 2017-01-10 02:09:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-10 02:09:01 --> Final output sent to browser
DEBUG - 2017-01-10 02:09:01 --> Total execution time: 0.0151
INFO - 2017-01-10 02:09:03 --> Config Class Initialized
INFO - 2017-01-10 02:09:03 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:09:03 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:09:03 --> Utf8 Class Initialized
INFO - 2017-01-10 02:09:03 --> URI Class Initialized
INFO - 2017-01-10 02:09:03 --> Router Class Initialized
INFO - 2017-01-10 02:09:03 --> Output Class Initialized
INFO - 2017-01-10 02:09:03 --> Security Class Initialized
DEBUG - 2017-01-10 02:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:09:03 --> Input Class Initialized
INFO - 2017-01-10 02:09:03 --> Language Class Initialized
INFO - 2017-01-10 02:09:03 --> Loader Class Initialized
INFO - 2017-01-10 02:09:03 --> Database Driver Class Initialized
INFO - 2017-01-10 02:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:09:03 --> Controller Class Initialized
INFO - 2017-01-10 02:09:04 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:09:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:09:04 --> Helper loaded: url_helper
INFO - 2017-01-10 02:09:04 --> Helper loaded: download_helper
INFO - 2017-01-10 02:09:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:09:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:09:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-10 02:09:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-10 02:09:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:09:04 --> Final output sent to browser
DEBUG - 2017-01-10 02:09:04 --> Total execution time: 1.2216
INFO - 2017-01-10 02:09:04 --> Config Class Initialized
INFO - 2017-01-10 02:09:04 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:09:04 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:09:04 --> Utf8 Class Initialized
INFO - 2017-01-10 02:09:04 --> URI Class Initialized
INFO - 2017-01-10 02:09:04 --> Router Class Initialized
INFO - 2017-01-10 02:09:04 --> Output Class Initialized
INFO - 2017-01-10 02:09:04 --> Security Class Initialized
DEBUG - 2017-01-10 02:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:09:04 --> Input Class Initialized
INFO - 2017-01-10 02:09:04 --> Language Class Initialized
INFO - 2017-01-10 02:09:04 --> Loader Class Initialized
INFO - 2017-01-10 02:09:04 --> Database Driver Class Initialized
INFO - 2017-01-10 02:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:09:04 --> Controller Class Initialized
INFO - 2017-01-10 02:09:04 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:09:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:09:04 --> Helper loaded: url_helper
INFO - 2017-01-10 02:09:04 --> Helper loaded: download_helper
INFO - 2017-01-10 02:09:05 --> Config Class Initialized
INFO - 2017-01-10 02:09:05 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:09:05 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:09:05 --> Utf8 Class Initialized
INFO - 2017-01-10 02:09:05 --> URI Class Initialized
DEBUG - 2017-01-10 02:09:05 --> No URI present. Default controller set.
INFO - 2017-01-10 02:09:05 --> Router Class Initialized
INFO - 2017-01-10 02:09:05 --> Output Class Initialized
INFO - 2017-01-10 02:09:05 --> Security Class Initialized
DEBUG - 2017-01-10 02:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:09:05 --> Input Class Initialized
INFO - 2017-01-10 02:09:05 --> Language Class Initialized
INFO - 2017-01-10 02:09:05 --> Loader Class Initialized
INFO - 2017-01-10 02:09:05 --> Database Driver Class Initialized
INFO - 2017-01-10 02:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:09:05 --> Controller Class Initialized
INFO - 2017-01-10 02:09:05 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:09:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:09:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:09:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:09:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:09:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:09:05 --> Final output sent to browser
DEBUG - 2017-01-10 02:09:05 --> Total execution time: 0.0138
INFO - 2017-01-10 02:09:06 --> Config Class Initialized
INFO - 2017-01-10 02:09:06 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:09:06 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:09:06 --> Utf8 Class Initialized
INFO - 2017-01-10 02:09:06 --> URI Class Initialized
INFO - 2017-01-10 02:09:06 --> Router Class Initialized
INFO - 2017-01-10 02:09:06 --> Output Class Initialized
INFO - 2017-01-10 02:09:06 --> Security Class Initialized
DEBUG - 2017-01-10 02:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:09:06 --> Input Class Initialized
INFO - 2017-01-10 02:09:06 --> Language Class Initialized
INFO - 2017-01-10 02:09:06 --> Loader Class Initialized
INFO - 2017-01-10 02:09:06 --> Database Driver Class Initialized
INFO - 2017-01-10 02:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:09:06 --> Controller Class Initialized
INFO - 2017-01-10 02:09:06 --> Upload Class Initialized
INFO - 2017-01-10 02:09:06 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:09:06 --> Helper loaded: form_helper
INFO - 2017-01-10 02:09:06 --> Form Validation Class Initialized
INFO - 2017-01-10 02:09:06 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-01-10 02:09:06 --> You did not select a file to upload.
INFO - 2017-01-10 02:09:06 --> Final output sent to browser
DEBUG - 2017-01-10 02:09:06 --> Total execution time: 0.0139
INFO - 2017-01-10 02:09:06 --> Config Class Initialized
INFO - 2017-01-10 02:09:06 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:09:06 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:09:06 --> Utf8 Class Initialized
INFO - 2017-01-10 02:09:06 --> URI Class Initialized
INFO - 2017-01-10 02:09:06 --> Router Class Initialized
INFO - 2017-01-10 02:09:06 --> Output Class Initialized
INFO - 2017-01-10 02:09:06 --> Security Class Initialized
DEBUG - 2017-01-10 02:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:09:06 --> Input Class Initialized
INFO - 2017-01-10 02:09:06 --> Language Class Initialized
INFO - 2017-01-10 02:09:06 --> Loader Class Initialized
INFO - 2017-01-10 02:09:06 --> Database Driver Class Initialized
INFO - 2017-01-10 02:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:09:06 --> Controller Class Initialized
INFO - 2017-01-10 02:09:06 --> Upload Class Initialized
INFO - 2017-01-10 02:09:06 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:09:06 --> Helper loaded: form_helper
INFO - 2017-01-10 02:09:06 --> Form Validation Class Initialized
INFO - 2017-01-10 02:09:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-10 02:09:06 --> Final output sent to browser
DEBUG - 2017-01-10 02:09:06 --> Total execution time: 0.0278
INFO - 2017-01-10 02:09:19 --> Config Class Initialized
INFO - 2017-01-10 02:09:19 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:09:19 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:09:19 --> Utf8 Class Initialized
INFO - 2017-01-10 02:09:19 --> URI Class Initialized
INFO - 2017-01-10 02:09:19 --> Router Class Initialized
INFO - 2017-01-10 02:09:19 --> Output Class Initialized
INFO - 2017-01-10 02:09:19 --> Security Class Initialized
DEBUG - 2017-01-10 02:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:09:19 --> Input Class Initialized
INFO - 2017-01-10 02:09:19 --> Language Class Initialized
INFO - 2017-01-10 02:09:19 --> Loader Class Initialized
INFO - 2017-01-10 02:09:19 --> Database Driver Class Initialized
INFO - 2017-01-10 02:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:09:19 --> Controller Class Initialized
INFO - 2017-01-10 02:09:19 --> Upload Class Initialized
INFO - 2017-01-10 02:09:19 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:09:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:09:19 --> Helper loaded: form_helper
INFO - 2017-01-10 02:09:19 --> Form Validation Class Initialized
INFO - 2017-01-10 02:09:19 --> Final output sent to browser
DEBUG - 2017-01-10 02:09:19 --> Total execution time: 0.0160
INFO - 2017-01-10 02:09:19 --> Config Class Initialized
INFO - 2017-01-10 02:09:19 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:09:19 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:09:19 --> Utf8 Class Initialized
INFO - 2017-01-10 02:09:19 --> URI Class Initialized
INFO - 2017-01-10 02:09:19 --> Router Class Initialized
INFO - 2017-01-10 02:09:19 --> Output Class Initialized
INFO - 2017-01-10 02:09:19 --> Security Class Initialized
DEBUG - 2017-01-10 02:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:09:19 --> Input Class Initialized
INFO - 2017-01-10 02:09:19 --> Language Class Initialized
INFO - 2017-01-10 02:09:19 --> Loader Class Initialized
INFO - 2017-01-10 02:09:19 --> Database Driver Class Initialized
INFO - 2017-01-10 02:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:09:19 --> Controller Class Initialized
INFO - 2017-01-10 02:09:19 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:09:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:09:24 --> Config Class Initialized
INFO - 2017-01-10 02:09:24 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:09:24 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:09:24 --> Utf8 Class Initialized
INFO - 2017-01-10 02:09:24 --> URI Class Initialized
INFO - 2017-01-10 02:09:24 --> Router Class Initialized
INFO - 2017-01-10 02:09:24 --> Output Class Initialized
INFO - 2017-01-10 02:09:24 --> Security Class Initialized
DEBUG - 2017-01-10 02:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:09:24 --> Input Class Initialized
INFO - 2017-01-10 02:09:24 --> Language Class Initialized
INFO - 2017-01-10 02:09:24 --> Loader Class Initialized
INFO - 2017-01-10 02:09:24 --> Database Driver Class Initialized
INFO - 2017-01-10 02:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:09:24 --> Controller Class Initialized
INFO - 2017-01-10 02:09:24 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:09:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:09:24 --> Helper loaded: url_helper
INFO - 2017-01-10 02:09:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:09:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:09:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-10 02:09:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-10 02:09:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:09:24 --> Final output sent to browser
DEBUG - 2017-01-10 02:09:24 --> Total execution time: 0.0548
INFO - 2017-01-10 02:09:28 --> Config Class Initialized
INFO - 2017-01-10 02:09:28 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:09:28 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:09:28 --> Utf8 Class Initialized
INFO - 2017-01-10 02:09:28 --> URI Class Initialized
INFO - 2017-01-10 02:09:28 --> Router Class Initialized
INFO - 2017-01-10 02:09:28 --> Output Class Initialized
INFO - 2017-01-10 02:09:28 --> Security Class Initialized
DEBUG - 2017-01-10 02:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:09:28 --> Input Class Initialized
INFO - 2017-01-10 02:09:28 --> Language Class Initialized
INFO - 2017-01-10 02:09:28 --> Loader Class Initialized
INFO - 2017-01-10 02:09:28 --> Database Driver Class Initialized
INFO - 2017-01-10 02:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:09:28 --> Controller Class Initialized
INFO - 2017-01-10 02:09:28 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:09:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:09:28 --> Helper loaded: url_helper
INFO - 2017-01-10 02:09:28 --> Helper loaded: download_helper
INFO - 2017-01-10 02:09:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:09:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:09:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-10 02:09:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-10 02:09:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:09:28 --> Final output sent to browser
DEBUG - 2017-01-10 02:09:28 --> Total execution time: 0.0173
INFO - 2017-01-10 02:09:41 --> Config Class Initialized
INFO - 2017-01-10 02:09:41 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:09:41 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:09:41 --> Utf8 Class Initialized
INFO - 2017-01-10 02:09:41 --> URI Class Initialized
INFO - 2017-01-10 02:09:41 --> Router Class Initialized
INFO - 2017-01-10 02:09:41 --> Output Class Initialized
INFO - 2017-01-10 02:09:41 --> Security Class Initialized
DEBUG - 2017-01-10 02:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:09:41 --> Input Class Initialized
INFO - 2017-01-10 02:09:41 --> Language Class Initialized
INFO - 2017-01-10 02:09:41 --> Loader Class Initialized
INFO - 2017-01-10 02:09:41 --> Database Driver Class Initialized
INFO - 2017-01-10 02:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:09:41 --> Controller Class Initialized
INFO - 2017-01-10 02:09:41 --> Upload Class Initialized
INFO - 2017-01-10 02:09:41 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:09:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:09:41 --> Helper loaded: form_helper
INFO - 2017-01-10 02:09:41 --> Form Validation Class Initialized
INFO - 2017-01-10 02:09:41 --> Final output sent to browser
DEBUG - 2017-01-10 02:09:41 --> Total execution time: 0.0913
INFO - 2017-01-10 02:09:50 --> Config Class Initialized
INFO - 2017-01-10 02:09:50 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:09:50 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:09:50 --> Utf8 Class Initialized
INFO - 2017-01-10 02:09:50 --> URI Class Initialized
INFO - 2017-01-10 02:09:50 --> Router Class Initialized
INFO - 2017-01-10 02:09:50 --> Output Class Initialized
INFO - 2017-01-10 02:09:50 --> Security Class Initialized
DEBUG - 2017-01-10 02:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:09:50 --> Input Class Initialized
INFO - 2017-01-10 02:09:50 --> Language Class Initialized
INFO - 2017-01-10 02:09:50 --> Loader Class Initialized
INFO - 2017-01-10 02:09:50 --> Database Driver Class Initialized
INFO - 2017-01-10 02:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:09:50 --> Controller Class Initialized
INFO - 2017-01-10 02:09:50 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:09:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:09:50 --> Helper loaded: url_helper
INFO - 2017-01-10 02:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-10 02:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-10 02:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-10 02:09:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:09:50 --> Final output sent to browser
DEBUG - 2017-01-10 02:09:50 --> Total execution time: 0.0537
INFO - 2017-01-10 02:09:58 --> Config Class Initialized
INFO - 2017-01-10 02:09:58 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:09:58 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:09:58 --> Utf8 Class Initialized
INFO - 2017-01-10 02:09:58 --> URI Class Initialized
INFO - 2017-01-10 02:09:58 --> Router Class Initialized
INFO - 2017-01-10 02:09:58 --> Output Class Initialized
INFO - 2017-01-10 02:09:58 --> Security Class Initialized
DEBUG - 2017-01-10 02:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:09:58 --> Input Class Initialized
INFO - 2017-01-10 02:09:58 --> Language Class Initialized
INFO - 2017-01-10 02:09:58 --> Loader Class Initialized
INFO - 2017-01-10 02:09:58 --> Database Driver Class Initialized
INFO - 2017-01-10 02:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:09:58 --> Controller Class Initialized
INFO - 2017-01-10 02:09:58 --> Upload Class Initialized
INFO - 2017-01-10 02:09:58 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:09:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:09:58 --> Helper loaded: url_helper
INFO - 2017-01-10 02:09:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:09:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:09:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-01-10 02:09:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-01-10 02:09:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-10 02:09:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:09:58 --> Final output sent to browser
DEBUG - 2017-01-10 02:09:58 --> Total execution time: 0.0800
INFO - 2017-01-10 02:10:03 --> Config Class Initialized
INFO - 2017-01-10 02:10:03 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:10:03 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:10:03 --> Utf8 Class Initialized
INFO - 2017-01-10 02:10:03 --> URI Class Initialized
INFO - 2017-01-10 02:10:03 --> Router Class Initialized
INFO - 2017-01-10 02:10:03 --> Output Class Initialized
INFO - 2017-01-10 02:10:03 --> Security Class Initialized
DEBUG - 2017-01-10 02:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:10:03 --> Input Class Initialized
INFO - 2017-01-10 02:10:03 --> Language Class Initialized
INFO - 2017-01-10 02:10:03 --> Loader Class Initialized
INFO - 2017-01-10 02:10:03 --> Database Driver Class Initialized
INFO - 2017-01-10 02:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:10:03 --> Controller Class Initialized
INFO - 2017-01-10 02:10:03 --> Upload Class Initialized
INFO - 2017-01-10 02:10:03 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:10:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:10:03 --> Helper loaded: form_helper
INFO - 2017-01-10 02:10:03 --> Form Validation Class Initialized
INFO - 2017-01-10 02:10:03 --> Final output sent to browser
DEBUG - 2017-01-10 02:10:03 --> Total execution time: 0.0315
INFO - 2017-01-10 02:10:10 --> Config Class Initialized
INFO - 2017-01-10 02:10:10 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:10:10 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:10:10 --> Utf8 Class Initialized
INFO - 2017-01-10 02:10:10 --> URI Class Initialized
INFO - 2017-01-10 02:10:10 --> Router Class Initialized
INFO - 2017-01-10 02:10:10 --> Output Class Initialized
INFO - 2017-01-10 02:10:10 --> Security Class Initialized
DEBUG - 2017-01-10 02:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:10:10 --> Input Class Initialized
INFO - 2017-01-10 02:10:10 --> Language Class Initialized
INFO - 2017-01-10 02:10:10 --> Loader Class Initialized
INFO - 2017-01-10 02:10:10 --> Database Driver Class Initialized
INFO - 2017-01-10 02:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:10:10 --> Controller Class Initialized
INFO - 2017-01-10 02:10:10 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:10:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:10:10 --> Config Class Initialized
INFO - 2017-01-10 02:10:10 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:10:10 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:10:10 --> Utf8 Class Initialized
INFO - 2017-01-10 02:10:10 --> URI Class Initialized
DEBUG - 2017-01-10 02:10:10 --> No URI present. Default controller set.
INFO - 2017-01-10 02:10:10 --> Router Class Initialized
INFO - 2017-01-10 02:10:10 --> Output Class Initialized
INFO - 2017-01-10 02:10:10 --> Security Class Initialized
DEBUG - 2017-01-10 02:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:10:10 --> Input Class Initialized
INFO - 2017-01-10 02:10:10 --> Language Class Initialized
INFO - 2017-01-10 02:10:10 --> Loader Class Initialized
INFO - 2017-01-10 02:10:10 --> Database Driver Class Initialized
INFO - 2017-01-10 02:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:10:10 --> Controller Class Initialized
INFO - 2017-01-10 02:10:10 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:10:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:10:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:10:10 --> Final output sent to browser
DEBUG - 2017-01-10 02:10:10 --> Total execution time: 0.0209
INFO - 2017-01-10 02:10:26 --> Config Class Initialized
INFO - 2017-01-10 02:10:26 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:10:26 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:10:26 --> Utf8 Class Initialized
INFO - 2017-01-10 02:10:26 --> URI Class Initialized
INFO - 2017-01-10 02:10:26 --> Router Class Initialized
INFO - 2017-01-10 02:10:26 --> Output Class Initialized
INFO - 2017-01-10 02:10:26 --> Security Class Initialized
DEBUG - 2017-01-10 02:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:10:26 --> Input Class Initialized
INFO - 2017-01-10 02:10:26 --> Language Class Initialized
INFO - 2017-01-10 02:10:26 --> Loader Class Initialized
INFO - 2017-01-10 02:10:26 --> Database Driver Class Initialized
INFO - 2017-01-10 02:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:10:26 --> Controller Class Initialized
INFO - 2017-01-10 02:10:26 --> Upload Class Initialized
INFO - 2017-01-10 02:10:26 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:10:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:10:26 --> Helper loaded: form_helper
INFO - 2017-01-10 02:10:26 --> Form Validation Class Initialized
INFO - 2017-01-10 02:10:26 --> Final output sent to browser
DEBUG - 2017-01-10 02:10:26 --> Total execution time: 0.0159
INFO - 2017-01-10 02:10:38 --> Config Class Initialized
INFO - 2017-01-10 02:10:38 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:10:38 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:10:38 --> Utf8 Class Initialized
INFO - 2017-01-10 02:10:38 --> URI Class Initialized
INFO - 2017-01-10 02:10:38 --> Router Class Initialized
INFO - 2017-01-10 02:10:38 --> Output Class Initialized
INFO - 2017-01-10 02:10:38 --> Security Class Initialized
DEBUG - 2017-01-10 02:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:10:38 --> Input Class Initialized
INFO - 2017-01-10 02:10:38 --> Language Class Initialized
INFO - 2017-01-10 02:10:38 --> Loader Class Initialized
INFO - 2017-01-10 02:10:38 --> Database Driver Class Initialized
INFO - 2017-01-10 02:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:10:38 --> Controller Class Initialized
INFO - 2017-01-10 02:10:38 --> Upload Class Initialized
INFO - 2017-01-10 02:10:38 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:10:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:10:38 --> Helper loaded: form_helper
INFO - 2017-01-10 02:10:38 --> Form Validation Class Initialized
INFO - 2017-01-10 02:10:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:10:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 02:10:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-10 02:10:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-10 02:10:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-10 02:10:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:10:38 --> Final output sent to browser
DEBUG - 2017-01-10 02:10:38 --> Total execution time: 0.0822
INFO - 2017-01-10 02:10:39 --> Config Class Initialized
INFO - 2017-01-10 02:10:39 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:10:39 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:10:39 --> Utf8 Class Initialized
INFO - 2017-01-10 02:10:39 --> URI Class Initialized
INFO - 2017-01-10 02:10:39 --> Router Class Initialized
INFO - 2017-01-10 02:10:39 --> Output Class Initialized
INFO - 2017-01-10 02:10:39 --> Security Class Initialized
DEBUG - 2017-01-10 02:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:10:39 --> Input Class Initialized
INFO - 2017-01-10 02:10:39 --> Language Class Initialized
INFO - 2017-01-10 02:10:39 --> Loader Class Initialized
INFO - 2017-01-10 02:10:39 --> Database Driver Class Initialized
INFO - 2017-01-10 02:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:10:39 --> Controller Class Initialized
INFO - 2017-01-10 02:10:39 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:10:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:10:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:10:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:10:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:10:39 --> Final output sent to browser
DEBUG - 2017-01-10 02:10:39 --> Total execution time: 0.0137
INFO - 2017-01-10 02:10:42 --> Config Class Initialized
INFO - 2017-01-10 02:10:42 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:10:42 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:10:42 --> Utf8 Class Initialized
INFO - 2017-01-10 02:10:42 --> URI Class Initialized
INFO - 2017-01-10 02:10:42 --> Router Class Initialized
INFO - 2017-01-10 02:10:42 --> Output Class Initialized
INFO - 2017-01-10 02:10:42 --> Security Class Initialized
DEBUG - 2017-01-10 02:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:10:42 --> Input Class Initialized
INFO - 2017-01-10 02:10:42 --> Language Class Initialized
INFO - 2017-01-10 02:10:42 --> Loader Class Initialized
INFO - 2017-01-10 02:10:42 --> Database Driver Class Initialized
INFO - 2017-01-10 02:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:10:42 --> Controller Class Initialized
INFO - 2017-01-10 02:10:42 --> Helper loaded: date_helper
INFO - 2017-01-10 02:10:42 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:10:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:10:42 --> Helper loaded: form_helper
INFO - 2017-01-10 02:10:42 --> Form Validation Class Initialized
INFO - 2017-01-10 02:10:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:10:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 02:10:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-10 02:10:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-10 02:10:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:10:42 --> Final output sent to browser
DEBUG - 2017-01-10 02:10:42 --> Total execution time: 0.0347
INFO - 2017-01-10 02:10:42 --> Config Class Initialized
INFO - 2017-01-10 02:10:42 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:10:42 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:10:42 --> Utf8 Class Initialized
INFO - 2017-01-10 02:10:42 --> URI Class Initialized
INFO - 2017-01-10 02:10:42 --> Router Class Initialized
INFO - 2017-01-10 02:10:42 --> Output Class Initialized
INFO - 2017-01-10 02:10:42 --> Security Class Initialized
DEBUG - 2017-01-10 02:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:10:42 --> Input Class Initialized
INFO - 2017-01-10 02:10:42 --> Language Class Initialized
INFO - 2017-01-10 02:10:42 --> Loader Class Initialized
INFO - 2017-01-10 02:10:42 --> Database Driver Class Initialized
INFO - 2017-01-10 02:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:10:42 --> Controller Class Initialized
INFO - 2017-01-10 02:10:42 --> Helper loaded: date_helper
INFO - 2017-01-10 02:10:42 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:10:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:10:42 --> Helper loaded: form_helper
INFO - 2017-01-10 02:10:42 --> Form Validation Class Initialized
INFO - 2017-01-10 02:10:42 --> Final output sent to browser
DEBUG - 2017-01-10 02:10:42 --> Total execution time: 0.0163
INFO - 2017-01-10 02:10:42 --> Config Class Initialized
INFO - 2017-01-10 02:10:42 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:10:42 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:10:42 --> Utf8 Class Initialized
INFO - 2017-01-10 02:10:42 --> URI Class Initialized
INFO - 2017-01-10 02:10:42 --> Router Class Initialized
INFO - 2017-01-10 02:10:42 --> Output Class Initialized
INFO - 2017-01-10 02:10:42 --> Security Class Initialized
DEBUG - 2017-01-10 02:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:10:42 --> Input Class Initialized
INFO - 2017-01-10 02:10:42 --> Language Class Initialized
INFO - 2017-01-10 02:10:42 --> Loader Class Initialized
INFO - 2017-01-10 02:10:42 --> Database Driver Class Initialized
INFO - 2017-01-10 02:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:10:42 --> Controller Class Initialized
INFO - 2017-01-10 02:10:42 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:10:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:10:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:10:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:10:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:10:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:10:42 --> Final output sent to browser
DEBUG - 2017-01-10 02:10:42 --> Total execution time: 0.0164
INFO - 2017-01-10 02:10:47 --> Config Class Initialized
INFO - 2017-01-10 02:10:47 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:10:47 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:10:47 --> Utf8 Class Initialized
INFO - 2017-01-10 02:10:47 --> URI Class Initialized
INFO - 2017-01-10 02:10:47 --> Router Class Initialized
INFO - 2017-01-10 02:10:47 --> Output Class Initialized
INFO - 2017-01-10 02:10:47 --> Security Class Initialized
DEBUG - 2017-01-10 02:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:10:47 --> Input Class Initialized
INFO - 2017-01-10 02:10:47 --> Language Class Initialized
INFO - 2017-01-10 02:10:47 --> Loader Class Initialized
INFO - 2017-01-10 02:10:47 --> Database Driver Class Initialized
INFO - 2017-01-10 02:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:10:47 --> Controller Class Initialized
INFO - 2017-01-10 02:10:47 --> Helper loaded: date_helper
INFO - 2017-01-10 02:10:47 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:10:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:10:47 --> Helper loaded: form_helper
INFO - 2017-01-10 02:10:47 --> Form Validation Class Initialized
INFO - 2017-01-10 02:10:47 --> Final output sent to browser
DEBUG - 2017-01-10 02:10:47 --> Total execution time: 0.0144
INFO - 2017-01-10 02:10:50 --> Config Class Initialized
INFO - 2017-01-10 02:10:50 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:10:50 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:10:50 --> Utf8 Class Initialized
INFO - 2017-01-10 02:10:50 --> URI Class Initialized
INFO - 2017-01-10 02:10:50 --> Router Class Initialized
INFO - 2017-01-10 02:10:50 --> Output Class Initialized
INFO - 2017-01-10 02:10:50 --> Security Class Initialized
DEBUG - 2017-01-10 02:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:10:50 --> Input Class Initialized
INFO - 2017-01-10 02:10:50 --> Language Class Initialized
INFO - 2017-01-10 02:10:50 --> Loader Class Initialized
INFO - 2017-01-10 02:10:50 --> Database Driver Class Initialized
INFO - 2017-01-10 02:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:10:50 --> Controller Class Initialized
INFO - 2017-01-10 02:10:50 --> Helper loaded: date_helper
INFO - 2017-01-10 02:10:50 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:10:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:10:50 --> Helper loaded: form_helper
INFO - 2017-01-10 02:10:50 --> Form Validation Class Initialized
INFO - 2017-01-10 02:10:50 --> Final output sent to browser
DEBUG - 2017-01-10 02:10:50 --> Total execution time: 0.0440
INFO - 2017-01-10 02:10:50 --> Config Class Initialized
INFO - 2017-01-10 02:10:50 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:10:50 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:10:50 --> Utf8 Class Initialized
INFO - 2017-01-10 02:10:50 --> URI Class Initialized
INFO - 2017-01-10 02:10:50 --> Router Class Initialized
INFO - 2017-01-10 02:10:50 --> Output Class Initialized
INFO - 2017-01-10 02:10:50 --> Security Class Initialized
DEBUG - 2017-01-10 02:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:10:50 --> Input Class Initialized
INFO - 2017-01-10 02:10:50 --> Language Class Initialized
INFO - 2017-01-10 02:10:50 --> Loader Class Initialized
INFO - 2017-01-10 02:10:50 --> Database Driver Class Initialized
INFO - 2017-01-10 02:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:10:50 --> Controller Class Initialized
INFO - 2017-01-10 02:10:50 --> Helper loaded: date_helper
INFO - 2017-01-10 02:10:50 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:10:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:10:50 --> Helper loaded: form_helper
INFO - 2017-01-10 02:10:50 --> Form Validation Class Initialized
INFO - 2017-01-10 02:10:50 --> Final output sent to browser
DEBUG - 2017-01-10 02:10:50 --> Total execution time: 0.0145
INFO - 2017-01-10 02:10:54 --> Config Class Initialized
INFO - 2017-01-10 02:10:54 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:10:54 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:10:54 --> Utf8 Class Initialized
INFO - 2017-01-10 02:10:54 --> URI Class Initialized
INFO - 2017-01-10 02:10:54 --> Router Class Initialized
INFO - 2017-01-10 02:10:54 --> Output Class Initialized
INFO - 2017-01-10 02:10:54 --> Security Class Initialized
DEBUG - 2017-01-10 02:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:10:54 --> Input Class Initialized
INFO - 2017-01-10 02:10:54 --> Language Class Initialized
INFO - 2017-01-10 02:10:54 --> Loader Class Initialized
INFO - 2017-01-10 02:10:54 --> Database Driver Class Initialized
INFO - 2017-01-10 02:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:10:54 --> Controller Class Initialized
INFO - 2017-01-10 02:10:54 --> Helper loaded: date_helper
INFO - 2017-01-10 02:10:54 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:10:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:10:54 --> Helper loaded: form_helper
INFO - 2017-01-10 02:10:54 --> Form Validation Class Initialized
INFO - 2017-01-10 02:10:54 --> Final output sent to browser
DEBUG - 2017-01-10 02:10:54 --> Total execution time: 0.0143
INFO - 2017-01-10 02:11:00 --> Config Class Initialized
INFO - 2017-01-10 02:11:00 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:11:00 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:11:00 --> Utf8 Class Initialized
INFO - 2017-01-10 02:11:00 --> URI Class Initialized
INFO - 2017-01-10 02:11:00 --> Router Class Initialized
INFO - 2017-01-10 02:11:00 --> Output Class Initialized
INFO - 2017-01-10 02:11:00 --> Security Class Initialized
DEBUG - 2017-01-10 02:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:11:00 --> Input Class Initialized
INFO - 2017-01-10 02:11:00 --> Language Class Initialized
INFO - 2017-01-10 02:11:00 --> Loader Class Initialized
INFO - 2017-01-10 02:11:00 --> Database Driver Class Initialized
INFO - 2017-01-10 02:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:11:00 --> Controller Class Initialized
INFO - 2017-01-10 02:11:00 --> Helper loaded: date_helper
INFO - 2017-01-10 02:11:00 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:11:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:11:00 --> Helper loaded: form_helper
INFO - 2017-01-10 02:11:00 --> Form Validation Class Initialized
INFO - 2017-01-10 02:11:00 --> Final output sent to browser
DEBUG - 2017-01-10 02:11:00 --> Total execution time: 0.0145
INFO - 2017-01-10 02:11:00 --> Config Class Initialized
INFO - 2017-01-10 02:11:00 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:11:00 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:11:00 --> Utf8 Class Initialized
INFO - 2017-01-10 02:11:00 --> URI Class Initialized
INFO - 2017-01-10 02:11:00 --> Router Class Initialized
INFO - 2017-01-10 02:11:00 --> Output Class Initialized
INFO - 2017-01-10 02:11:00 --> Security Class Initialized
DEBUG - 2017-01-10 02:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:11:00 --> Input Class Initialized
INFO - 2017-01-10 02:11:00 --> Language Class Initialized
INFO - 2017-01-10 02:11:00 --> Loader Class Initialized
INFO - 2017-01-10 02:11:00 --> Database Driver Class Initialized
INFO - 2017-01-10 02:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:11:00 --> Controller Class Initialized
INFO - 2017-01-10 02:11:00 --> Helper loaded: date_helper
INFO - 2017-01-10 02:11:00 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:11:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:11:00 --> Helper loaded: form_helper
INFO - 2017-01-10 02:11:00 --> Form Validation Class Initialized
INFO - 2017-01-10 02:11:00 --> Final output sent to browser
DEBUG - 2017-01-10 02:11:00 --> Total execution time: 0.0141
INFO - 2017-01-10 02:11:12 --> Config Class Initialized
INFO - 2017-01-10 02:11:12 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:11:12 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:11:12 --> Utf8 Class Initialized
INFO - 2017-01-10 02:11:12 --> URI Class Initialized
INFO - 2017-01-10 02:11:12 --> Router Class Initialized
INFO - 2017-01-10 02:11:12 --> Output Class Initialized
INFO - 2017-01-10 02:11:12 --> Security Class Initialized
DEBUG - 2017-01-10 02:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:11:12 --> Input Class Initialized
INFO - 2017-01-10 02:11:12 --> Language Class Initialized
INFO - 2017-01-10 02:11:12 --> Loader Class Initialized
INFO - 2017-01-10 02:11:12 --> Database Driver Class Initialized
INFO - 2017-01-10 02:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:11:12 --> Controller Class Initialized
INFO - 2017-01-10 02:11:12 --> Helper loaded: date_helper
INFO - 2017-01-10 02:11:12 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:11:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:11:12 --> Helper loaded: form_helper
INFO - 2017-01-10 02:11:12 --> Form Validation Class Initialized
INFO - 2017-01-10 02:11:12 --> Final output sent to browser
DEBUG - 2017-01-10 02:11:12 --> Total execution time: 0.0143
INFO - 2017-01-10 02:11:13 --> Config Class Initialized
INFO - 2017-01-10 02:11:13 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:11:13 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:11:13 --> Utf8 Class Initialized
INFO - 2017-01-10 02:11:13 --> URI Class Initialized
INFO - 2017-01-10 02:11:13 --> Router Class Initialized
INFO - 2017-01-10 02:11:13 --> Output Class Initialized
INFO - 2017-01-10 02:11:13 --> Security Class Initialized
DEBUG - 2017-01-10 02:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:11:13 --> Input Class Initialized
INFO - 2017-01-10 02:11:13 --> Language Class Initialized
INFO - 2017-01-10 02:11:13 --> Loader Class Initialized
INFO - 2017-01-10 02:11:13 --> Database Driver Class Initialized
INFO - 2017-01-10 02:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:11:13 --> Controller Class Initialized
INFO - 2017-01-10 02:11:13 --> Helper loaded: date_helper
INFO - 2017-01-10 02:11:13 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:11:13 --> Helper loaded: form_helper
INFO - 2017-01-10 02:11:13 --> Form Validation Class Initialized
INFO - 2017-01-10 02:11:13 --> Final output sent to browser
DEBUG - 2017-01-10 02:11:13 --> Total execution time: 0.0189
INFO - 2017-01-10 02:11:21 --> Config Class Initialized
INFO - 2017-01-10 02:11:21 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:11:21 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:11:21 --> Utf8 Class Initialized
INFO - 2017-01-10 02:11:21 --> URI Class Initialized
INFO - 2017-01-10 02:11:21 --> Router Class Initialized
INFO - 2017-01-10 02:11:21 --> Output Class Initialized
INFO - 2017-01-10 02:11:21 --> Security Class Initialized
DEBUG - 2017-01-10 02:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:11:21 --> Input Class Initialized
INFO - 2017-01-10 02:11:21 --> Language Class Initialized
INFO - 2017-01-10 02:11:21 --> Loader Class Initialized
INFO - 2017-01-10 02:11:21 --> Database Driver Class Initialized
INFO - 2017-01-10 02:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:11:21 --> Controller Class Initialized
INFO - 2017-01-10 02:11:21 --> Helper loaded: date_helper
INFO - 2017-01-10 02:11:21 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:11:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:11:21 --> Helper loaded: form_helper
INFO - 2017-01-10 02:11:21 --> Form Validation Class Initialized
INFO - 2017-01-10 02:11:21 --> Final output sent to browser
DEBUG - 2017-01-10 02:11:21 --> Total execution time: 0.0143
INFO - 2017-01-10 02:11:22 --> Config Class Initialized
INFO - 2017-01-10 02:11:22 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:11:22 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:11:22 --> Utf8 Class Initialized
INFO - 2017-01-10 02:11:22 --> URI Class Initialized
INFO - 2017-01-10 02:11:22 --> Router Class Initialized
INFO - 2017-01-10 02:11:22 --> Output Class Initialized
INFO - 2017-01-10 02:11:22 --> Security Class Initialized
DEBUG - 2017-01-10 02:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:11:22 --> Input Class Initialized
INFO - 2017-01-10 02:11:22 --> Language Class Initialized
INFO - 2017-01-10 02:11:22 --> Loader Class Initialized
INFO - 2017-01-10 02:11:22 --> Database Driver Class Initialized
INFO - 2017-01-10 02:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:11:22 --> Controller Class Initialized
INFO - 2017-01-10 02:11:22 --> Helper loaded: date_helper
INFO - 2017-01-10 02:11:22 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:11:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:11:22 --> Helper loaded: form_helper
INFO - 2017-01-10 02:11:22 --> Form Validation Class Initialized
INFO - 2017-01-10 02:11:22 --> Final output sent to browser
DEBUG - 2017-01-10 02:11:22 --> Total execution time: 0.0146
INFO - 2017-01-10 02:11:25 --> Config Class Initialized
INFO - 2017-01-10 02:11:25 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:11:25 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:11:25 --> Utf8 Class Initialized
INFO - 2017-01-10 02:11:25 --> URI Class Initialized
INFO - 2017-01-10 02:11:25 --> Router Class Initialized
INFO - 2017-01-10 02:11:25 --> Output Class Initialized
INFO - 2017-01-10 02:11:25 --> Security Class Initialized
DEBUG - 2017-01-10 02:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:11:25 --> Input Class Initialized
INFO - 2017-01-10 02:11:25 --> Language Class Initialized
INFO - 2017-01-10 02:11:25 --> Loader Class Initialized
INFO - 2017-01-10 02:11:25 --> Database Driver Class Initialized
INFO - 2017-01-10 02:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:11:25 --> Controller Class Initialized
INFO - 2017-01-10 02:11:25 --> Helper loaded: date_helper
INFO - 2017-01-10 02:11:25 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:11:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:11:25 --> Helper loaded: form_helper
INFO - 2017-01-10 02:11:25 --> Form Validation Class Initialized
INFO - 2017-01-10 02:11:25 --> Final output sent to browser
DEBUG - 2017-01-10 02:11:25 --> Total execution time: 0.0147
INFO - 2017-01-10 02:11:26 --> Config Class Initialized
INFO - 2017-01-10 02:11:26 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:11:26 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:11:26 --> Utf8 Class Initialized
INFO - 2017-01-10 02:11:26 --> URI Class Initialized
INFO - 2017-01-10 02:11:26 --> Router Class Initialized
INFO - 2017-01-10 02:11:26 --> Output Class Initialized
INFO - 2017-01-10 02:11:26 --> Security Class Initialized
DEBUG - 2017-01-10 02:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:11:26 --> Input Class Initialized
INFO - 2017-01-10 02:11:26 --> Language Class Initialized
INFO - 2017-01-10 02:11:26 --> Loader Class Initialized
INFO - 2017-01-10 02:11:26 --> Database Driver Class Initialized
INFO - 2017-01-10 02:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:11:26 --> Controller Class Initialized
INFO - 2017-01-10 02:11:26 --> Helper loaded: date_helper
INFO - 2017-01-10 02:11:26 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:11:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:11:26 --> Helper loaded: form_helper
INFO - 2017-01-10 02:11:26 --> Form Validation Class Initialized
INFO - 2017-01-10 02:11:26 --> Final output sent to browser
DEBUG - 2017-01-10 02:11:26 --> Total execution time: 0.0227
INFO - 2017-01-10 02:11:27 --> Config Class Initialized
INFO - 2017-01-10 02:11:27 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:11:27 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:11:27 --> Utf8 Class Initialized
INFO - 2017-01-10 02:11:27 --> URI Class Initialized
INFO - 2017-01-10 02:11:27 --> Router Class Initialized
INFO - 2017-01-10 02:11:27 --> Output Class Initialized
INFO - 2017-01-10 02:11:27 --> Security Class Initialized
DEBUG - 2017-01-10 02:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:11:27 --> Input Class Initialized
INFO - 2017-01-10 02:11:27 --> Language Class Initialized
INFO - 2017-01-10 02:11:27 --> Loader Class Initialized
INFO - 2017-01-10 02:11:27 --> Database Driver Class Initialized
INFO - 2017-01-10 02:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:11:27 --> Controller Class Initialized
INFO - 2017-01-10 02:11:27 --> Helper loaded: date_helper
INFO - 2017-01-10 02:11:27 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:11:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:11:27 --> Helper loaded: form_helper
INFO - 2017-01-10 02:11:27 --> Form Validation Class Initialized
INFO - 2017-01-10 02:11:27 --> Final output sent to browser
DEBUG - 2017-01-10 02:11:27 --> Total execution time: 0.0147
INFO - 2017-01-10 02:11:29 --> Config Class Initialized
INFO - 2017-01-10 02:11:29 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:11:29 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:11:29 --> Utf8 Class Initialized
INFO - 2017-01-10 02:11:29 --> URI Class Initialized
INFO - 2017-01-10 02:11:29 --> Router Class Initialized
INFO - 2017-01-10 02:11:29 --> Output Class Initialized
INFO - 2017-01-10 02:11:29 --> Security Class Initialized
DEBUG - 2017-01-10 02:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:11:29 --> Input Class Initialized
INFO - 2017-01-10 02:11:29 --> Language Class Initialized
INFO - 2017-01-10 02:11:29 --> Loader Class Initialized
INFO - 2017-01-10 02:11:29 --> Database Driver Class Initialized
INFO - 2017-01-10 02:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:11:29 --> Controller Class Initialized
INFO - 2017-01-10 02:11:29 --> Helper loaded: date_helper
INFO - 2017-01-10 02:11:29 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:11:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:11:29 --> Helper loaded: form_helper
INFO - 2017-01-10 02:11:29 --> Form Validation Class Initialized
INFO - 2017-01-10 02:11:29 --> Final output sent to browser
DEBUG - 2017-01-10 02:11:29 --> Total execution time: 0.0144
INFO - 2017-01-10 02:11:31 --> Config Class Initialized
INFO - 2017-01-10 02:11:31 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:11:31 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:11:31 --> Utf8 Class Initialized
INFO - 2017-01-10 02:11:31 --> URI Class Initialized
INFO - 2017-01-10 02:11:31 --> Router Class Initialized
INFO - 2017-01-10 02:11:31 --> Output Class Initialized
INFO - 2017-01-10 02:11:31 --> Security Class Initialized
DEBUG - 2017-01-10 02:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:11:31 --> Input Class Initialized
INFO - 2017-01-10 02:11:31 --> Language Class Initialized
INFO - 2017-01-10 02:11:31 --> Loader Class Initialized
INFO - 2017-01-10 02:11:31 --> Database Driver Class Initialized
INFO - 2017-01-10 02:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:11:31 --> Controller Class Initialized
INFO - 2017-01-10 02:11:31 --> Helper loaded: date_helper
INFO - 2017-01-10 02:11:31 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:11:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:11:31 --> Helper loaded: form_helper
INFO - 2017-01-10 02:11:31 --> Form Validation Class Initialized
INFO - 2017-01-10 02:11:31 --> Final output sent to browser
DEBUG - 2017-01-10 02:11:31 --> Total execution time: 0.0156
INFO - 2017-01-10 02:11:40 --> Config Class Initialized
INFO - 2017-01-10 02:11:40 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:11:40 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:11:40 --> Utf8 Class Initialized
INFO - 2017-01-10 02:11:40 --> URI Class Initialized
INFO - 2017-01-10 02:11:40 --> Router Class Initialized
INFO - 2017-01-10 02:11:40 --> Output Class Initialized
INFO - 2017-01-10 02:11:40 --> Security Class Initialized
DEBUG - 2017-01-10 02:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:11:40 --> Input Class Initialized
INFO - 2017-01-10 02:11:40 --> Language Class Initialized
INFO - 2017-01-10 02:11:40 --> Loader Class Initialized
INFO - 2017-01-10 02:11:40 --> Database Driver Class Initialized
INFO - 2017-01-10 02:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:11:40 --> Controller Class Initialized
INFO - 2017-01-10 02:11:40 --> Helper loaded: date_helper
INFO - 2017-01-10 02:11:40 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:11:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:11:40 --> Helper loaded: form_helper
INFO - 2017-01-10 02:11:40 --> Form Validation Class Initialized
INFO - 2017-01-10 02:11:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:11:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 02:11:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-10 02:11:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-10 02:11:40 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:11:40 --> Final output sent to browser
DEBUG - 2017-01-10 02:11:40 --> Total execution time: 0.0569
INFO - 2017-01-10 02:11:41 --> Config Class Initialized
INFO - 2017-01-10 02:11:41 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:11:41 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:11:41 --> Utf8 Class Initialized
INFO - 2017-01-10 02:11:41 --> URI Class Initialized
INFO - 2017-01-10 02:11:41 --> Router Class Initialized
INFO - 2017-01-10 02:11:41 --> Output Class Initialized
INFO - 2017-01-10 02:11:41 --> Security Class Initialized
DEBUG - 2017-01-10 02:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:11:41 --> Input Class Initialized
INFO - 2017-01-10 02:11:41 --> Language Class Initialized
INFO - 2017-01-10 02:11:41 --> Loader Class Initialized
INFO - 2017-01-10 02:11:41 --> Database Driver Class Initialized
INFO - 2017-01-10 02:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:11:41 --> Controller Class Initialized
INFO - 2017-01-10 02:11:41 --> Helper loaded: date_helper
INFO - 2017-01-10 02:11:41 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:11:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:11:41 --> Helper loaded: form_helper
INFO - 2017-01-10 02:11:41 --> Form Validation Class Initialized
INFO - 2017-01-10 02:11:41 --> Final output sent to browser
DEBUG - 2017-01-10 02:11:41 --> Total execution time: 0.0142
INFO - 2017-01-10 02:11:41 --> Config Class Initialized
INFO - 2017-01-10 02:11:41 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:11:41 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:11:41 --> Utf8 Class Initialized
INFO - 2017-01-10 02:11:41 --> URI Class Initialized
INFO - 2017-01-10 02:11:41 --> Router Class Initialized
INFO - 2017-01-10 02:11:41 --> Output Class Initialized
INFO - 2017-01-10 02:11:41 --> Security Class Initialized
DEBUG - 2017-01-10 02:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:11:41 --> Input Class Initialized
INFO - 2017-01-10 02:11:41 --> Language Class Initialized
INFO - 2017-01-10 02:11:41 --> Loader Class Initialized
INFO - 2017-01-10 02:11:41 --> Database Driver Class Initialized
INFO - 2017-01-10 02:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:11:41 --> Controller Class Initialized
INFO - 2017-01-10 02:11:41 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:11:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:11:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:11:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:11:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:11:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:11:41 --> Final output sent to browser
DEBUG - 2017-01-10 02:11:41 --> Total execution time: 0.0133
INFO - 2017-01-10 02:11:49 --> Config Class Initialized
INFO - 2017-01-10 02:11:49 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:11:49 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:11:49 --> Utf8 Class Initialized
INFO - 2017-01-10 02:11:49 --> URI Class Initialized
INFO - 2017-01-10 02:11:49 --> Router Class Initialized
INFO - 2017-01-10 02:11:49 --> Output Class Initialized
INFO - 2017-01-10 02:11:49 --> Security Class Initialized
DEBUG - 2017-01-10 02:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:11:49 --> Input Class Initialized
INFO - 2017-01-10 02:11:49 --> Language Class Initialized
INFO - 2017-01-10 02:11:49 --> Loader Class Initialized
INFO - 2017-01-10 02:11:49 --> Database Driver Class Initialized
INFO - 2017-01-10 02:11:49 --> Config Class Initialized
INFO - 2017-01-10 02:11:49 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:11:49 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:11:49 --> Utf8 Class Initialized
INFO - 2017-01-10 02:11:49 --> URI Class Initialized
INFO - 2017-01-10 02:11:49 --> Router Class Initialized
INFO - 2017-01-10 02:11:49 --> Output Class Initialized
INFO - 2017-01-10 02:11:49 --> Security Class Initialized
DEBUG - 2017-01-10 02:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:11:49 --> Input Class Initialized
INFO - 2017-01-10 02:11:49 --> Language Class Initialized
INFO - 2017-01-10 02:11:49 --> Loader Class Initialized
INFO - 2017-01-10 02:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:11:49 --> Controller Class Initialized
INFO - 2017-01-10 02:11:49 --> Helper loaded: date_helper
INFO - 2017-01-10 02:11:49 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:11:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:11:49 --> Helper loaded: form_helper
INFO - 2017-01-10 02:11:49 --> Form Validation Class Initialized
INFO - 2017-01-10 02:11:49 --> Database Driver Class Initialized
INFO - 2017-01-10 02:11:49 --> Final output sent to browser
DEBUG - 2017-01-10 02:11:49 --> Total execution time: 0.0951
INFO - 2017-01-10 02:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:11:49 --> Controller Class Initialized
INFO - 2017-01-10 02:11:49 --> Helper loaded: date_helper
INFO - 2017-01-10 02:11:49 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:11:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:11:49 --> Helper loaded: form_helper
INFO - 2017-01-10 02:11:49 --> Form Validation Class Initialized
INFO - 2017-01-10 02:11:49 --> Final output sent to browser
DEBUG - 2017-01-10 02:11:49 --> Total execution time: 0.0780
INFO - 2017-01-10 02:13:00 --> Config Class Initialized
INFO - 2017-01-10 02:13:00 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:13:00 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:13:00 --> Utf8 Class Initialized
INFO - 2017-01-10 02:13:00 --> URI Class Initialized
INFO - 2017-01-10 02:13:00 --> Router Class Initialized
INFO - 2017-01-10 02:13:00 --> Output Class Initialized
INFO - 2017-01-10 02:13:00 --> Security Class Initialized
DEBUG - 2017-01-10 02:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:13:00 --> Input Class Initialized
INFO - 2017-01-10 02:13:00 --> Language Class Initialized
INFO - 2017-01-10 02:13:00 --> Loader Class Initialized
INFO - 2017-01-10 02:13:00 --> Database Driver Class Initialized
INFO - 2017-01-10 02:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:13:00 --> Controller Class Initialized
INFO - 2017-01-10 02:13:00 --> Upload Class Initialized
INFO - 2017-01-10 02:13:00 --> Helper loaded: date_helper
INFO - 2017-01-10 02:13:00 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:13:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:13:00 --> Helper loaded: form_helper
INFO - 2017-01-10 02:13:00 --> Form Validation Class Initialized
INFO - 2017-01-10 02:13:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:13:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 02:13:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-10 02:13:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-10 02:13:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-10 02:13:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:13:00 --> Final output sent to browser
DEBUG - 2017-01-10 02:13:00 --> Total execution time: 0.0487
INFO - 2017-01-10 02:13:00 --> Config Class Initialized
INFO - 2017-01-10 02:13:00 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:13:00 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:13:00 --> Utf8 Class Initialized
INFO - 2017-01-10 02:13:00 --> URI Class Initialized
INFO - 2017-01-10 02:13:00 --> Router Class Initialized
INFO - 2017-01-10 02:13:00 --> Output Class Initialized
INFO - 2017-01-10 02:13:00 --> Security Class Initialized
DEBUG - 2017-01-10 02:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:13:00 --> Input Class Initialized
INFO - 2017-01-10 02:13:00 --> Language Class Initialized
INFO - 2017-01-10 02:13:00 --> Loader Class Initialized
INFO - 2017-01-10 02:13:00 --> Database Driver Class Initialized
INFO - 2017-01-10 02:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:13:00 --> Controller Class Initialized
INFO - 2017-01-10 02:13:00 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:13:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:13:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:13:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:13:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:13:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:13:00 --> Final output sent to browser
DEBUG - 2017-01-10 02:13:00 --> Total execution time: 0.0135
INFO - 2017-01-10 02:13:09 --> Config Class Initialized
INFO - 2017-01-10 02:13:09 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:13:09 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:13:09 --> Utf8 Class Initialized
INFO - 2017-01-10 02:13:09 --> URI Class Initialized
INFO - 2017-01-10 02:13:09 --> Router Class Initialized
INFO - 2017-01-10 02:13:09 --> Output Class Initialized
INFO - 2017-01-10 02:13:09 --> Security Class Initialized
DEBUG - 2017-01-10 02:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:13:09 --> Input Class Initialized
INFO - 2017-01-10 02:13:09 --> Language Class Initialized
INFO - 2017-01-10 02:13:09 --> Loader Class Initialized
INFO - 2017-01-10 02:13:09 --> Database Driver Class Initialized
INFO - 2017-01-10 02:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:13:09 --> Controller Class Initialized
INFO - 2017-01-10 02:13:09 --> Upload Class Initialized
INFO - 2017-01-10 02:13:09 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:13:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:13:09 --> Helper loaded: form_helper
INFO - 2017-01-10 02:13:09 --> Form Validation Class Initialized
INFO - 2017-01-10 02:13:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:13:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 02:13:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-10 02:13:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-10 02:13:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-10 02:13:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:13:09 --> Final output sent to browser
DEBUG - 2017-01-10 02:13:09 --> Total execution time: 0.0158
INFO - 2017-01-10 02:13:10 --> Config Class Initialized
INFO - 2017-01-10 02:13:10 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:13:10 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:13:10 --> Utf8 Class Initialized
INFO - 2017-01-10 02:13:10 --> URI Class Initialized
INFO - 2017-01-10 02:13:10 --> Router Class Initialized
INFO - 2017-01-10 02:13:10 --> Output Class Initialized
INFO - 2017-01-10 02:13:10 --> Security Class Initialized
DEBUG - 2017-01-10 02:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:13:10 --> Input Class Initialized
INFO - 2017-01-10 02:13:10 --> Language Class Initialized
INFO - 2017-01-10 02:13:10 --> Loader Class Initialized
INFO - 2017-01-10 02:13:10 --> Database Driver Class Initialized
INFO - 2017-01-10 02:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:13:10 --> Controller Class Initialized
INFO - 2017-01-10 02:13:10 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:13:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:13:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:13:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:13:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:13:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:13:10 --> Final output sent to browser
DEBUG - 2017-01-10 02:13:10 --> Total execution time: 0.0242
INFO - 2017-01-10 02:14:35 --> Config Class Initialized
INFO - 2017-01-10 02:14:35 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:14:35 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:14:35 --> Utf8 Class Initialized
INFO - 2017-01-10 02:14:35 --> URI Class Initialized
INFO - 2017-01-10 02:14:35 --> Router Class Initialized
INFO - 2017-01-10 02:14:35 --> Output Class Initialized
INFO - 2017-01-10 02:14:35 --> Security Class Initialized
DEBUG - 2017-01-10 02:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:14:35 --> Input Class Initialized
INFO - 2017-01-10 02:14:35 --> Language Class Initialized
INFO - 2017-01-10 02:14:35 --> Loader Class Initialized
INFO - 2017-01-10 02:14:35 --> Database Driver Class Initialized
INFO - 2017-01-10 02:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:14:35 --> Controller Class Initialized
INFO - 2017-01-10 02:14:35 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:14:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:14:37 --> Config Class Initialized
INFO - 2017-01-10 02:14:37 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:14:37 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:14:37 --> Utf8 Class Initialized
INFO - 2017-01-10 02:14:37 --> URI Class Initialized
INFO - 2017-01-10 02:14:37 --> Router Class Initialized
INFO - 2017-01-10 02:14:37 --> Output Class Initialized
INFO - 2017-01-10 02:14:37 --> Security Class Initialized
DEBUG - 2017-01-10 02:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:14:37 --> Input Class Initialized
INFO - 2017-01-10 02:14:37 --> Language Class Initialized
INFO - 2017-01-10 02:14:37 --> Loader Class Initialized
INFO - 2017-01-10 02:14:37 --> Database Driver Class Initialized
INFO - 2017-01-10 02:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:14:37 --> Controller Class Initialized
INFO - 2017-01-10 02:14:37 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:14:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:14:37 --> Helper loaded: url_helper
INFO - 2017-01-10 02:14:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:14:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:14:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-10 02:14:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-10 02:14:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:14:37 --> Final output sent to browser
DEBUG - 2017-01-10 02:14:37 --> Total execution time: 0.0787
INFO - 2017-01-10 02:17:10 --> Config Class Initialized
INFO - 2017-01-10 02:17:10 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:17:10 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:17:10 --> Utf8 Class Initialized
INFO - 2017-01-10 02:17:10 --> URI Class Initialized
INFO - 2017-01-10 02:17:10 --> Router Class Initialized
INFO - 2017-01-10 02:17:10 --> Output Class Initialized
INFO - 2017-01-10 02:17:10 --> Security Class Initialized
DEBUG - 2017-01-10 02:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:17:10 --> Input Class Initialized
INFO - 2017-01-10 02:17:10 --> Language Class Initialized
INFO - 2017-01-10 02:17:10 --> Loader Class Initialized
INFO - 2017-01-10 02:17:10 --> Database Driver Class Initialized
INFO - 2017-01-10 02:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:17:10 --> Controller Class Initialized
INFO - 2017-01-10 02:17:10 --> Upload Class Initialized
INFO - 2017-01-10 02:17:10 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:17:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:17:10 --> Helper loaded: form_helper
INFO - 2017-01-10 02:17:11 --> Form Validation Class Initialized
INFO - 2017-01-10 02:17:11 --> Final output sent to browser
DEBUG - 2017-01-10 02:17:11 --> Total execution time: 0.7357
INFO - 2017-01-10 02:17:11 --> Config Class Initialized
INFO - 2017-01-10 02:17:11 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:17:11 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:17:11 --> Utf8 Class Initialized
INFO - 2017-01-10 02:17:11 --> URI Class Initialized
INFO - 2017-01-10 02:17:11 --> Router Class Initialized
INFO - 2017-01-10 02:17:11 --> Output Class Initialized
INFO - 2017-01-10 02:17:11 --> Security Class Initialized
DEBUG - 2017-01-10 02:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:17:11 --> Input Class Initialized
INFO - 2017-01-10 02:17:11 --> Language Class Initialized
INFO - 2017-01-10 02:17:11 --> Loader Class Initialized
INFO - 2017-01-10 02:17:11 --> Database Driver Class Initialized
INFO - 2017-01-10 02:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:17:11 --> Controller Class Initialized
INFO - 2017-01-10 02:17:11 --> Upload Class Initialized
INFO - 2017-01-10 02:17:11 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:17:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:17:11 --> Helper loaded: form_helper
INFO - 2017-01-10 02:17:11 --> Form Validation Class Initialized
INFO - 2017-01-10 02:17:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-10 02:17:12 --> Final output sent to browser
DEBUG - 2017-01-10 02:17:12 --> Total execution time: 0.0159
INFO - 2017-01-10 02:30:28 --> Config Class Initialized
INFO - 2017-01-10 02:30:28 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:30:28 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:30:28 --> Utf8 Class Initialized
INFO - 2017-01-10 02:30:28 --> URI Class Initialized
INFO - 2017-01-10 02:30:28 --> Router Class Initialized
INFO - 2017-01-10 02:30:28 --> Output Class Initialized
INFO - 2017-01-10 02:30:28 --> Security Class Initialized
DEBUG - 2017-01-10 02:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:30:28 --> Input Class Initialized
INFO - 2017-01-10 02:30:28 --> Language Class Initialized
INFO - 2017-01-10 02:30:28 --> Loader Class Initialized
INFO - 2017-01-10 02:30:28 --> Database Driver Class Initialized
INFO - 2017-01-10 02:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:30:28 --> Controller Class Initialized
INFO - 2017-01-10 02:30:28 --> Upload Class Initialized
INFO - 2017-01-10 02:30:28 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:30:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:30:28 --> Helper loaded: form_helper
INFO - 2017-01-10 02:30:28 --> Form Validation Class Initialized
INFO - 2017-01-10 02:30:28 --> Final output sent to browser
DEBUG - 2017-01-10 02:30:28 --> Total execution time: 0.7403
INFO - 2017-01-10 02:30:29 --> Config Class Initialized
INFO - 2017-01-10 02:30:29 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:30:29 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:30:29 --> Utf8 Class Initialized
INFO - 2017-01-10 02:30:29 --> URI Class Initialized
INFO - 2017-01-10 02:30:29 --> Router Class Initialized
INFO - 2017-01-10 02:30:29 --> Output Class Initialized
INFO - 2017-01-10 02:30:29 --> Security Class Initialized
DEBUG - 2017-01-10 02:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:30:29 --> Input Class Initialized
INFO - 2017-01-10 02:30:29 --> Language Class Initialized
INFO - 2017-01-10 02:30:29 --> Loader Class Initialized
INFO - 2017-01-10 02:30:29 --> Database Driver Class Initialized
INFO - 2017-01-10 02:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:30:29 --> Controller Class Initialized
INFO - 2017-01-10 02:30:29 --> Upload Class Initialized
INFO - 2017-01-10 02:30:29 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:30:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:30:29 --> Helper loaded: form_helper
INFO - 2017-01-10 02:30:29 --> Form Validation Class Initialized
INFO - 2017-01-10 02:30:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-10 02:30:29 --> Final output sent to browser
DEBUG - 2017-01-10 02:30:29 --> Total execution time: 0.0342
INFO - 2017-01-10 02:30:38 --> Config Class Initialized
INFO - 2017-01-10 02:30:38 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:30:38 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:30:38 --> Utf8 Class Initialized
INFO - 2017-01-10 02:30:38 --> URI Class Initialized
INFO - 2017-01-10 02:30:38 --> Router Class Initialized
INFO - 2017-01-10 02:30:38 --> Output Class Initialized
INFO - 2017-01-10 02:30:38 --> Security Class Initialized
DEBUG - 2017-01-10 02:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:30:38 --> Input Class Initialized
INFO - 2017-01-10 02:30:38 --> Language Class Initialized
INFO - 2017-01-10 02:30:38 --> Loader Class Initialized
INFO - 2017-01-10 02:30:38 --> Database Driver Class Initialized
INFO - 2017-01-10 02:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:30:38 --> Controller Class Initialized
INFO - 2017-01-10 02:30:38 --> Upload Class Initialized
INFO - 2017-01-10 02:30:38 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:30:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:30:38 --> Helper loaded: form_helper
INFO - 2017-01-10 02:30:38 --> Form Validation Class Initialized
INFO - 2017-01-10 02:30:38 --> Final output sent to browser
DEBUG - 2017-01-10 02:30:38 --> Total execution time: 0.4429
INFO - 2017-01-10 02:30:38 --> Config Class Initialized
INFO - 2017-01-10 02:30:38 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:30:38 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:30:38 --> Utf8 Class Initialized
INFO - 2017-01-10 02:30:38 --> URI Class Initialized
INFO - 2017-01-10 02:30:38 --> Router Class Initialized
INFO - 2017-01-10 02:30:38 --> Output Class Initialized
INFO - 2017-01-10 02:30:38 --> Security Class Initialized
DEBUG - 2017-01-10 02:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:30:38 --> Input Class Initialized
INFO - 2017-01-10 02:30:38 --> Language Class Initialized
INFO - 2017-01-10 02:30:38 --> Loader Class Initialized
INFO - 2017-01-10 02:30:38 --> Database Driver Class Initialized
INFO - 2017-01-10 02:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:30:38 --> Controller Class Initialized
INFO - 2017-01-10 02:30:38 --> Upload Class Initialized
INFO - 2017-01-10 02:30:38 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:30:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:30:38 --> Helper loaded: form_helper
INFO - 2017-01-10 02:30:38 --> Form Validation Class Initialized
INFO - 2017-01-10 02:30:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-10 02:30:38 --> Final output sent to browser
DEBUG - 2017-01-10 02:30:38 --> Total execution time: 0.0154
INFO - 2017-01-10 02:32:01 --> Config Class Initialized
INFO - 2017-01-10 02:32:01 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:32:01 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:32:01 --> Utf8 Class Initialized
INFO - 2017-01-10 02:32:01 --> URI Class Initialized
INFO - 2017-01-10 02:32:01 --> Router Class Initialized
INFO - 2017-01-10 02:32:01 --> Output Class Initialized
INFO - 2017-01-10 02:32:01 --> Security Class Initialized
DEBUG - 2017-01-10 02:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:32:01 --> Input Class Initialized
INFO - 2017-01-10 02:32:01 --> Language Class Initialized
INFO - 2017-01-10 02:32:01 --> Loader Class Initialized
INFO - 2017-01-10 02:32:01 --> Database Driver Class Initialized
INFO - 2017-01-10 02:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:32:01 --> Controller Class Initialized
INFO - 2017-01-10 02:32:01 --> Upload Class Initialized
INFO - 2017-01-10 02:32:01 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:32:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:32:01 --> Helper loaded: form_helper
INFO - 2017-01-10 02:32:01 --> Form Validation Class Initialized
INFO - 2017-01-10 02:32:01 --> Final output sent to browser
DEBUG - 2017-01-10 02:32:01 --> Total execution time: 0.7898
INFO - 2017-01-10 02:32:02 --> Config Class Initialized
INFO - 2017-01-10 02:32:02 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:32:02 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:32:02 --> Utf8 Class Initialized
INFO - 2017-01-10 02:32:02 --> URI Class Initialized
INFO - 2017-01-10 02:32:02 --> Router Class Initialized
INFO - 2017-01-10 02:32:02 --> Output Class Initialized
INFO - 2017-01-10 02:32:02 --> Security Class Initialized
DEBUG - 2017-01-10 02:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:32:02 --> Input Class Initialized
INFO - 2017-01-10 02:32:02 --> Language Class Initialized
INFO - 2017-01-10 02:32:02 --> Loader Class Initialized
INFO - 2017-01-10 02:32:02 --> Database Driver Class Initialized
INFO - 2017-01-10 02:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:32:02 --> Controller Class Initialized
INFO - 2017-01-10 02:32:02 --> Upload Class Initialized
INFO - 2017-01-10 02:32:02 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:32:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:32:02 --> Helper loaded: form_helper
INFO - 2017-01-10 02:32:02 --> Form Validation Class Initialized
INFO - 2017-01-10 02:32:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-10 02:32:02 --> Final output sent to browser
DEBUG - 2017-01-10 02:32:02 --> Total execution time: 0.6191
INFO - 2017-01-10 02:34:19 --> Config Class Initialized
INFO - 2017-01-10 02:34:19 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:34:19 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:34:19 --> Utf8 Class Initialized
INFO - 2017-01-10 02:34:19 --> URI Class Initialized
DEBUG - 2017-01-10 02:34:19 --> No URI present. Default controller set.
INFO - 2017-01-10 02:34:19 --> Router Class Initialized
INFO - 2017-01-10 02:34:19 --> Output Class Initialized
INFO - 2017-01-10 02:34:19 --> Security Class Initialized
DEBUG - 2017-01-10 02:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:34:19 --> Input Class Initialized
INFO - 2017-01-10 02:34:19 --> Language Class Initialized
INFO - 2017-01-10 02:34:19 --> Loader Class Initialized
INFO - 2017-01-10 02:34:19 --> Database Driver Class Initialized
INFO - 2017-01-10 02:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:34:19 --> Controller Class Initialized
INFO - 2017-01-10 02:34:19 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:34:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:34:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:34:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:34:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:34:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:34:19 --> Final output sent to browser
DEBUG - 2017-01-10 02:34:19 --> Total execution time: 0.5712
INFO - 2017-01-10 02:34:59 --> Config Class Initialized
INFO - 2017-01-10 02:34:59 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:34:59 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:34:59 --> Utf8 Class Initialized
INFO - 2017-01-10 02:34:59 --> URI Class Initialized
INFO - 2017-01-10 02:34:59 --> Router Class Initialized
INFO - 2017-01-10 02:34:59 --> Output Class Initialized
INFO - 2017-01-10 02:34:59 --> Security Class Initialized
DEBUG - 2017-01-10 02:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:34:59 --> Input Class Initialized
INFO - 2017-01-10 02:34:59 --> Language Class Initialized
INFO - 2017-01-10 02:34:59 --> Loader Class Initialized
INFO - 2017-01-10 02:34:59 --> Database Driver Class Initialized
INFO - 2017-01-10 02:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:34:59 --> Controller Class Initialized
INFO - 2017-01-10 02:34:59 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:34:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:35:01 --> Config Class Initialized
INFO - 2017-01-10 02:35:01 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:35:01 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:35:01 --> Utf8 Class Initialized
INFO - 2017-01-10 02:35:01 --> URI Class Initialized
INFO - 2017-01-10 02:35:01 --> Router Class Initialized
INFO - 2017-01-10 02:35:01 --> Output Class Initialized
INFO - 2017-01-10 02:35:01 --> Security Class Initialized
DEBUG - 2017-01-10 02:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:35:01 --> Input Class Initialized
INFO - 2017-01-10 02:35:01 --> Language Class Initialized
INFO - 2017-01-10 02:35:01 --> Loader Class Initialized
INFO - 2017-01-10 02:35:01 --> Database Driver Class Initialized
INFO - 2017-01-10 02:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:35:01 --> Controller Class Initialized
INFO - 2017-01-10 02:35:01 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:35:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:35:01 --> Helper loaded: url_helper
INFO - 2017-01-10 02:35:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:35:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:35:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-10 02:35:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-10 02:35:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:35:01 --> Final output sent to browser
DEBUG - 2017-01-10 02:35:01 --> Total execution time: 0.1852
INFO - 2017-01-10 02:35:11 --> Config Class Initialized
INFO - 2017-01-10 02:35:11 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:35:11 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:35:11 --> Utf8 Class Initialized
INFO - 2017-01-10 02:35:11 --> URI Class Initialized
INFO - 2017-01-10 02:35:11 --> Router Class Initialized
INFO - 2017-01-10 02:35:11 --> Output Class Initialized
INFO - 2017-01-10 02:35:11 --> Security Class Initialized
DEBUG - 2017-01-10 02:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:35:11 --> Input Class Initialized
INFO - 2017-01-10 02:35:11 --> Language Class Initialized
INFO - 2017-01-10 02:35:11 --> Loader Class Initialized
INFO - 2017-01-10 02:35:11 --> Database Driver Class Initialized
INFO - 2017-01-10 02:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:35:11 --> Controller Class Initialized
INFO - 2017-01-10 02:35:11 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:35:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:35:11 --> Helper loaded: url_helper
INFO - 2017-01-10 02:35:11 --> Helper loaded: download_helper
INFO - 2017-01-10 02:35:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:35:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2017-01-10 02:35:11 --> Severity: Notice --> Undefined variable: layout_name /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php 10
INFO - 2017-01-10 02:35:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-10 02:35:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-10 02:35:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:35:11 --> Final output sent to browser
DEBUG - 2017-01-10 02:35:11 --> Total execution time: 0.2705
INFO - 2017-01-10 02:35:12 --> Config Class Initialized
INFO - 2017-01-10 02:35:12 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:35:12 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:35:12 --> Utf8 Class Initialized
INFO - 2017-01-10 02:35:46 --> Config Class Initialized
INFO - 2017-01-10 02:35:46 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:35:46 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:35:46 --> Utf8 Class Initialized
INFO - 2017-01-10 02:35:46 --> URI Class Initialized
INFO - 2017-01-10 02:35:46 --> Router Class Initialized
INFO - 2017-01-10 02:35:46 --> Output Class Initialized
INFO - 2017-01-10 02:35:46 --> Security Class Initialized
DEBUG - 2017-01-10 02:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:35:46 --> Input Class Initialized
INFO - 2017-01-10 02:35:46 --> Language Class Initialized
INFO - 2017-01-10 02:35:46 --> Loader Class Initialized
INFO - 2017-01-10 02:35:46 --> Database Driver Class Initialized
INFO - 2017-01-10 02:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:35:46 --> Controller Class Initialized
INFO - 2017-01-10 02:35:46 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:35:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:35:46 --> Helper loaded: url_helper
INFO - 2017-01-10 02:35:46 --> Helper loaded: download_helper
INFO - 2017-01-10 02:35:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:35:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
ERROR - 2017-01-10 02:35:46 --> Severity: Notice --> Undefined variable: layout_name /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php 10
INFO - 2017-01-10 02:35:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-10 02:35:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-10 02:35:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:35:46 --> Final output sent to browser
DEBUG - 2017-01-10 02:35:46 --> Total execution time: 0.0181
INFO - 2017-01-10 02:35:47 --> Config Class Initialized
INFO - 2017-01-10 02:35:47 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:35:47 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:35:47 --> Utf8 Class Initialized
INFO - 2017-01-10 02:35:47 --> Config Class Initialized
INFO - 2017-01-10 02:35:47 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:35:47 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:35:47 --> Utf8 Class Initialized
INFO - 2017-01-10 02:35:55 --> Config Class Initialized
INFO - 2017-01-10 02:35:55 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:35:55 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:35:55 --> Utf8 Class Initialized
INFO - 2017-01-10 02:35:55 --> URI Class Initialized
INFO - 2017-01-10 02:35:55 --> Router Class Initialized
INFO - 2017-01-10 02:35:55 --> Output Class Initialized
INFO - 2017-01-10 02:35:55 --> Security Class Initialized
DEBUG - 2017-01-10 02:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:35:55 --> Input Class Initialized
INFO - 2017-01-10 02:35:55 --> Language Class Initialized
INFO - 2017-01-10 02:35:55 --> Loader Class Initialized
INFO - 2017-01-10 02:35:55 --> Database Driver Class Initialized
INFO - 2017-01-10 02:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:35:55 --> Controller Class Initialized
INFO - 2017-01-10 02:35:55 --> Helper loaded: date_helper
INFO - 2017-01-10 02:35:55 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:35:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:35:55 --> Helper loaded: form_helper
INFO - 2017-01-10 02:35:55 --> Form Validation Class Initialized
INFO - 2017-01-10 02:35:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:35:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 02:35:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-10 02:35:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-10 02:35:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:35:55 --> Final output sent to browser
DEBUG - 2017-01-10 02:35:55 --> Total execution time: 0.1729
INFO - 2017-01-10 02:35:55 --> Config Class Initialized
INFO - 2017-01-10 02:35:55 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:35:55 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:35:55 --> Utf8 Class Initialized
INFO - 2017-01-10 02:35:55 --> URI Class Initialized
INFO - 2017-01-10 02:35:55 --> Router Class Initialized
INFO - 2017-01-10 02:35:55 --> Output Class Initialized
INFO - 2017-01-10 02:35:55 --> Security Class Initialized
DEBUG - 2017-01-10 02:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:35:55 --> Input Class Initialized
INFO - 2017-01-10 02:35:55 --> Language Class Initialized
INFO - 2017-01-10 02:35:55 --> Loader Class Initialized
INFO - 2017-01-10 02:35:55 --> Database Driver Class Initialized
INFO - 2017-01-10 02:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:35:55 --> Controller Class Initialized
INFO - 2017-01-10 02:35:55 --> Helper loaded: date_helper
INFO - 2017-01-10 02:35:55 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:35:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:35:55 --> Helper loaded: form_helper
INFO - 2017-01-10 02:35:55 --> Form Validation Class Initialized
INFO - 2017-01-10 02:35:55 --> Final output sent to browser
DEBUG - 2017-01-10 02:35:55 --> Total execution time: 0.0838
INFO - 2017-01-10 02:35:55 --> Config Class Initialized
INFO - 2017-01-10 02:35:55 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:35:55 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:35:55 --> Utf8 Class Initialized
INFO - 2017-01-10 02:35:55 --> URI Class Initialized
INFO - 2017-01-10 02:35:55 --> Router Class Initialized
INFO - 2017-01-10 02:35:55 --> Output Class Initialized
INFO - 2017-01-10 02:35:55 --> Security Class Initialized
DEBUG - 2017-01-10 02:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:35:55 --> Input Class Initialized
INFO - 2017-01-10 02:35:55 --> Language Class Initialized
INFO - 2017-01-10 02:35:55 --> Loader Class Initialized
INFO - 2017-01-10 02:35:55 --> Database Driver Class Initialized
INFO - 2017-01-10 02:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:35:55 --> Controller Class Initialized
INFO - 2017-01-10 02:35:55 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:35:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:35:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:35:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:35:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:35:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:35:55 --> Final output sent to browser
DEBUG - 2017-01-10 02:35:55 --> Total execution time: 0.1594
INFO - 2017-01-10 02:36:02 --> Config Class Initialized
INFO - 2017-01-10 02:36:02 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:36:02 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:36:02 --> Utf8 Class Initialized
INFO - 2017-01-10 02:36:02 --> URI Class Initialized
INFO - 2017-01-10 02:36:02 --> Router Class Initialized
INFO - 2017-01-10 02:36:02 --> Output Class Initialized
INFO - 2017-01-10 02:36:02 --> Security Class Initialized
DEBUG - 2017-01-10 02:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:36:02 --> Input Class Initialized
INFO - 2017-01-10 02:36:02 --> Language Class Initialized
INFO - 2017-01-10 02:36:02 --> Loader Class Initialized
INFO - 2017-01-10 02:36:02 --> Database Driver Class Initialized
INFO - 2017-01-10 02:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:36:02 --> Controller Class Initialized
INFO - 2017-01-10 02:36:02 --> Helper loaded: date_helper
INFO - 2017-01-10 02:36:02 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:36:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:36:02 --> Helper loaded: form_helper
INFO - 2017-01-10 02:36:02 --> Form Validation Class Initialized
INFO - 2017-01-10 02:36:02 --> Final output sent to browser
DEBUG - 2017-01-10 02:36:02 --> Total execution time: 0.0143
INFO - 2017-01-10 02:36:07 --> Config Class Initialized
INFO - 2017-01-10 02:36:07 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:36:07 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:36:07 --> Utf8 Class Initialized
INFO - 2017-01-10 02:36:07 --> URI Class Initialized
INFO - 2017-01-10 02:36:07 --> Router Class Initialized
INFO - 2017-01-10 02:36:07 --> Output Class Initialized
INFO - 2017-01-10 02:36:07 --> Security Class Initialized
DEBUG - 2017-01-10 02:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:36:08 --> Input Class Initialized
INFO - 2017-01-10 02:36:08 --> Language Class Initialized
INFO - 2017-01-10 02:36:08 --> Loader Class Initialized
INFO - 2017-01-10 02:36:08 --> Database Driver Class Initialized
INFO - 2017-01-10 02:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:36:08 --> Controller Class Initialized
INFO - 2017-01-10 02:36:08 --> Helper loaded: date_helper
INFO - 2017-01-10 02:36:08 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:36:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:36:08 --> Helper loaded: form_helper
INFO - 2017-01-10 02:36:08 --> Form Validation Class Initialized
INFO - 2017-01-10 02:36:08 --> Final output sent to browser
DEBUG - 2017-01-10 02:36:08 --> Total execution time: 0.0139
INFO - 2017-01-10 02:36:08 --> Config Class Initialized
INFO - 2017-01-10 02:36:08 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:36:08 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:36:08 --> Utf8 Class Initialized
INFO - 2017-01-10 02:36:08 --> URI Class Initialized
INFO - 2017-01-10 02:36:08 --> Router Class Initialized
INFO - 2017-01-10 02:36:08 --> Output Class Initialized
INFO - 2017-01-10 02:36:08 --> Security Class Initialized
DEBUG - 2017-01-10 02:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:36:08 --> Input Class Initialized
INFO - 2017-01-10 02:36:08 --> Language Class Initialized
INFO - 2017-01-10 02:36:08 --> Loader Class Initialized
INFO - 2017-01-10 02:36:08 --> Database Driver Class Initialized
INFO - 2017-01-10 02:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:36:08 --> Controller Class Initialized
INFO - 2017-01-10 02:36:08 --> Helper loaded: date_helper
INFO - 2017-01-10 02:36:08 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:36:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:36:08 --> Helper loaded: form_helper
INFO - 2017-01-10 02:36:08 --> Form Validation Class Initialized
INFO - 2017-01-10 02:36:08 --> Final output sent to browser
DEBUG - 2017-01-10 02:36:08 --> Total execution time: 0.0141
INFO - 2017-01-10 02:36:15 --> Config Class Initialized
INFO - 2017-01-10 02:36:15 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:36:15 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:36:15 --> Utf8 Class Initialized
INFO - 2017-01-10 02:36:15 --> URI Class Initialized
INFO - 2017-01-10 02:36:15 --> Router Class Initialized
INFO - 2017-01-10 02:36:15 --> Output Class Initialized
INFO - 2017-01-10 02:36:15 --> Security Class Initialized
DEBUG - 2017-01-10 02:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:36:15 --> Input Class Initialized
INFO - 2017-01-10 02:36:15 --> Language Class Initialized
INFO - 2017-01-10 02:36:15 --> Loader Class Initialized
INFO - 2017-01-10 02:36:15 --> Database Driver Class Initialized
INFO - 2017-01-10 02:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:36:15 --> Controller Class Initialized
INFO - 2017-01-10 02:36:15 --> Helper loaded: date_helper
INFO - 2017-01-10 02:36:15 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:36:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:36:15 --> Helper loaded: form_helper
INFO - 2017-01-10 02:36:15 --> Form Validation Class Initialized
INFO - 2017-01-10 02:36:15 --> Final output sent to browser
DEBUG - 2017-01-10 02:36:15 --> Total execution time: 0.0137
INFO - 2017-01-10 02:36:19 --> Config Class Initialized
INFO - 2017-01-10 02:36:19 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:36:19 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:36:19 --> Utf8 Class Initialized
INFO - 2017-01-10 02:36:19 --> URI Class Initialized
INFO - 2017-01-10 02:36:19 --> Router Class Initialized
INFO - 2017-01-10 02:36:19 --> Output Class Initialized
INFO - 2017-01-10 02:36:19 --> Security Class Initialized
DEBUG - 2017-01-10 02:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:36:19 --> Input Class Initialized
INFO - 2017-01-10 02:36:19 --> Language Class Initialized
INFO - 2017-01-10 02:36:19 --> Loader Class Initialized
INFO - 2017-01-10 02:36:19 --> Database Driver Class Initialized
INFO - 2017-01-10 02:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:36:19 --> Controller Class Initialized
INFO - 2017-01-10 02:36:19 --> Helper loaded: date_helper
INFO - 2017-01-10 02:36:19 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:36:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:36:19 --> Helper loaded: form_helper
INFO - 2017-01-10 02:36:19 --> Form Validation Class Initialized
INFO - 2017-01-10 02:36:19 --> Final output sent to browser
DEBUG - 2017-01-10 02:36:19 --> Total execution time: 0.0267
INFO - 2017-01-10 02:36:22 --> Config Class Initialized
INFO - 2017-01-10 02:36:22 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:36:22 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:36:22 --> Utf8 Class Initialized
INFO - 2017-01-10 02:36:22 --> URI Class Initialized
INFO - 2017-01-10 02:36:22 --> Router Class Initialized
INFO - 2017-01-10 02:36:22 --> Output Class Initialized
INFO - 2017-01-10 02:36:22 --> Security Class Initialized
DEBUG - 2017-01-10 02:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:36:22 --> Input Class Initialized
INFO - 2017-01-10 02:36:22 --> Language Class Initialized
INFO - 2017-01-10 02:36:22 --> Loader Class Initialized
INFO - 2017-01-10 02:36:22 --> Database Driver Class Initialized
INFO - 2017-01-10 02:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:36:22 --> Controller Class Initialized
INFO - 2017-01-10 02:36:22 --> Helper loaded: date_helper
INFO - 2017-01-10 02:36:22 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:36:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:36:23 --> Helper loaded: form_helper
INFO - 2017-01-10 02:36:23 --> Form Validation Class Initialized
INFO - 2017-01-10 02:36:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:36:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 02:36:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-10 02:36:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-10 02:36:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:36:23 --> Final output sent to browser
DEBUG - 2017-01-10 02:36:23 --> Total execution time: 0.0257
INFO - 2017-01-10 02:36:23 --> Config Class Initialized
INFO - 2017-01-10 02:36:23 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:36:23 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:36:23 --> Utf8 Class Initialized
INFO - 2017-01-10 02:36:23 --> URI Class Initialized
INFO - 2017-01-10 02:36:23 --> Router Class Initialized
INFO - 2017-01-10 02:36:23 --> Output Class Initialized
INFO - 2017-01-10 02:36:23 --> Security Class Initialized
DEBUG - 2017-01-10 02:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:36:23 --> Input Class Initialized
INFO - 2017-01-10 02:36:23 --> Language Class Initialized
INFO - 2017-01-10 02:36:23 --> Loader Class Initialized
INFO - 2017-01-10 02:36:23 --> Database Driver Class Initialized
INFO - 2017-01-10 02:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:36:23 --> Controller Class Initialized
INFO - 2017-01-10 02:36:23 --> Helper loaded: date_helper
INFO - 2017-01-10 02:36:23 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:36:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:36:23 --> Helper loaded: form_helper
INFO - 2017-01-10 02:36:23 --> Form Validation Class Initialized
INFO - 2017-01-10 02:36:23 --> Final output sent to browser
DEBUG - 2017-01-10 02:36:23 --> Total execution time: 0.0926
INFO - 2017-01-10 02:36:23 --> Config Class Initialized
INFO - 2017-01-10 02:36:23 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:36:23 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:36:23 --> Utf8 Class Initialized
INFO - 2017-01-10 02:36:23 --> URI Class Initialized
INFO - 2017-01-10 02:36:23 --> Router Class Initialized
INFO - 2017-01-10 02:36:23 --> Output Class Initialized
INFO - 2017-01-10 02:36:23 --> Security Class Initialized
DEBUG - 2017-01-10 02:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:36:23 --> Input Class Initialized
INFO - 2017-01-10 02:36:23 --> Language Class Initialized
INFO - 2017-01-10 02:36:23 --> Loader Class Initialized
INFO - 2017-01-10 02:36:23 --> Database Driver Class Initialized
INFO - 2017-01-10 02:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:36:23 --> Controller Class Initialized
INFO - 2017-01-10 02:36:23 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:36:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:36:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:36:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:36:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:36:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:36:23 --> Final output sent to browser
DEBUG - 2017-01-10 02:36:23 --> Total execution time: 0.0670
INFO - 2017-01-10 02:36:28 --> Config Class Initialized
INFO - 2017-01-10 02:36:28 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:36:28 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:36:28 --> Utf8 Class Initialized
INFO - 2017-01-10 02:36:28 --> URI Class Initialized
INFO - 2017-01-10 02:36:28 --> Router Class Initialized
INFO - 2017-01-10 02:36:28 --> Output Class Initialized
INFO - 2017-01-10 02:36:28 --> Security Class Initialized
DEBUG - 2017-01-10 02:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:36:28 --> Input Class Initialized
INFO - 2017-01-10 02:36:28 --> Language Class Initialized
INFO - 2017-01-10 02:36:28 --> Loader Class Initialized
INFO - 2017-01-10 02:36:28 --> Database Driver Class Initialized
INFO - 2017-01-10 02:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:36:28 --> Controller Class Initialized
INFO - 2017-01-10 02:36:28 --> Helper loaded: date_helper
INFO - 2017-01-10 02:36:28 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:36:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:36:28 --> Helper loaded: form_helper
INFO - 2017-01-10 02:36:28 --> Form Validation Class Initialized
INFO - 2017-01-10 02:36:28 --> Final output sent to browser
DEBUG - 2017-01-10 02:36:28 --> Total execution time: 0.0144
INFO - 2017-01-10 02:36:33 --> Config Class Initialized
INFO - 2017-01-10 02:36:33 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:36:33 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:36:33 --> Utf8 Class Initialized
INFO - 2017-01-10 02:36:33 --> URI Class Initialized
INFO - 2017-01-10 02:36:33 --> Router Class Initialized
INFO - 2017-01-10 02:36:33 --> Output Class Initialized
INFO - 2017-01-10 02:36:33 --> Security Class Initialized
DEBUG - 2017-01-10 02:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:36:33 --> Input Class Initialized
INFO - 2017-01-10 02:36:33 --> Language Class Initialized
INFO - 2017-01-10 02:36:33 --> Loader Class Initialized
INFO - 2017-01-10 02:36:33 --> Config Class Initialized
INFO - 2017-01-10 02:36:33 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:36:33 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:36:33 --> Utf8 Class Initialized
INFO - 2017-01-10 02:36:33 --> URI Class Initialized
INFO - 2017-01-10 02:36:33 --> Router Class Initialized
INFO - 2017-01-10 02:36:33 --> Output Class Initialized
INFO - 2017-01-10 02:36:33 --> Security Class Initialized
DEBUG - 2017-01-10 02:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:36:33 --> Input Class Initialized
INFO - 2017-01-10 02:36:33 --> Language Class Initialized
INFO - 2017-01-10 02:36:33 --> Loader Class Initialized
INFO - 2017-01-10 02:36:33 --> Database Driver Class Initialized
INFO - 2017-01-10 02:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:36:33 --> Controller Class Initialized
INFO - 2017-01-10 02:36:33 --> Database Driver Class Initialized
INFO - 2017-01-10 02:36:33 --> Helper loaded: date_helper
INFO - 2017-01-10 02:36:33 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:36:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:36:33 --> Helper loaded: form_helper
INFO - 2017-01-10 02:36:33 --> Form Validation Class Initialized
INFO - 2017-01-10 02:36:33 --> Final output sent to browser
DEBUG - 2017-01-10 02:36:33 --> Total execution time: 0.2495
INFO - 2017-01-10 02:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:36:33 --> Controller Class Initialized
INFO - 2017-01-10 02:36:33 --> Helper loaded: date_helper
INFO - 2017-01-10 02:36:33 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:36:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:36:33 --> Helper loaded: form_helper
INFO - 2017-01-10 02:36:33 --> Form Validation Class Initialized
INFO - 2017-01-10 02:36:33 --> Final output sent to browser
DEBUG - 2017-01-10 02:36:33 --> Total execution time: 0.2493
INFO - 2017-01-10 02:36:35 --> Config Class Initialized
INFO - 2017-01-10 02:36:35 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:36:35 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:36:35 --> Utf8 Class Initialized
INFO - 2017-01-10 02:36:35 --> URI Class Initialized
INFO - 2017-01-10 02:36:35 --> Router Class Initialized
INFO - 2017-01-10 02:36:35 --> Output Class Initialized
INFO - 2017-01-10 02:36:35 --> Security Class Initialized
DEBUG - 2017-01-10 02:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:36:35 --> Input Class Initialized
INFO - 2017-01-10 02:36:35 --> Language Class Initialized
INFO - 2017-01-10 02:36:35 --> Loader Class Initialized
INFO - 2017-01-10 02:36:35 --> Database Driver Class Initialized
INFO - 2017-01-10 02:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:36:35 --> Controller Class Initialized
INFO - 2017-01-10 02:36:35 --> Helper loaded: date_helper
INFO - 2017-01-10 02:36:35 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:36:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:36:35 --> Helper loaded: form_helper
INFO - 2017-01-10 02:36:35 --> Form Validation Class Initialized
INFO - 2017-01-10 02:36:35 --> Final output sent to browser
DEBUG - 2017-01-10 02:36:35 --> Total execution time: 0.0148
INFO - 2017-01-10 02:36:35 --> Config Class Initialized
INFO - 2017-01-10 02:36:35 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:36:35 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:36:35 --> Utf8 Class Initialized
INFO - 2017-01-10 02:36:35 --> URI Class Initialized
INFO - 2017-01-10 02:36:35 --> Router Class Initialized
INFO - 2017-01-10 02:36:35 --> Output Class Initialized
INFO - 2017-01-10 02:36:35 --> Security Class Initialized
DEBUG - 2017-01-10 02:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:36:35 --> Input Class Initialized
INFO - 2017-01-10 02:36:35 --> Language Class Initialized
INFO - 2017-01-10 02:36:35 --> Loader Class Initialized
INFO - 2017-01-10 02:36:35 --> Database Driver Class Initialized
INFO - 2017-01-10 02:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:36:35 --> Controller Class Initialized
INFO - 2017-01-10 02:36:35 --> Helper loaded: date_helper
INFO - 2017-01-10 02:36:35 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:36:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:36:35 --> Helper loaded: form_helper
INFO - 2017-01-10 02:36:35 --> Form Validation Class Initialized
INFO - 2017-01-10 02:36:35 --> Final output sent to browser
DEBUG - 2017-01-10 02:36:35 --> Total execution time: 0.0144
INFO - 2017-01-10 02:36:38 --> Config Class Initialized
INFO - 2017-01-10 02:36:38 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:36:38 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:36:38 --> Utf8 Class Initialized
INFO - 2017-01-10 02:36:38 --> URI Class Initialized
INFO - 2017-01-10 02:36:38 --> Router Class Initialized
INFO - 2017-01-10 02:36:38 --> Output Class Initialized
INFO - 2017-01-10 02:36:38 --> Security Class Initialized
DEBUG - 2017-01-10 02:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:36:38 --> Input Class Initialized
INFO - 2017-01-10 02:36:38 --> Language Class Initialized
INFO - 2017-01-10 02:36:38 --> Loader Class Initialized
INFO - 2017-01-10 02:36:38 --> Database Driver Class Initialized
INFO - 2017-01-10 02:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:36:38 --> Controller Class Initialized
INFO - 2017-01-10 02:36:38 --> Helper loaded: date_helper
INFO - 2017-01-10 02:36:38 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:36:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:36:38 --> Helper loaded: form_helper
INFO - 2017-01-10 02:36:38 --> Form Validation Class Initialized
INFO - 2017-01-10 02:36:38 --> Final output sent to browser
DEBUG - 2017-01-10 02:36:38 --> Total execution time: 0.0140
INFO - 2017-01-10 02:36:39 --> Config Class Initialized
INFO - 2017-01-10 02:36:39 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:36:39 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:36:39 --> Utf8 Class Initialized
INFO - 2017-01-10 02:36:39 --> URI Class Initialized
INFO - 2017-01-10 02:36:39 --> Router Class Initialized
INFO - 2017-01-10 02:36:39 --> Output Class Initialized
INFO - 2017-01-10 02:36:39 --> Security Class Initialized
DEBUG - 2017-01-10 02:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:36:39 --> Input Class Initialized
INFO - 2017-01-10 02:36:39 --> Language Class Initialized
INFO - 2017-01-10 02:36:39 --> Loader Class Initialized
INFO - 2017-01-10 02:36:39 --> Database Driver Class Initialized
INFO - 2017-01-10 02:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:36:39 --> Controller Class Initialized
INFO - 2017-01-10 02:36:39 --> Helper loaded: date_helper
INFO - 2017-01-10 02:36:39 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:36:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:36:39 --> Helper loaded: form_helper
INFO - 2017-01-10 02:36:39 --> Form Validation Class Initialized
INFO - 2017-01-10 02:36:39 --> Final output sent to browser
DEBUG - 2017-01-10 02:36:39 --> Total execution time: 0.0138
INFO - 2017-01-10 02:36:45 --> Config Class Initialized
INFO - 2017-01-10 02:36:45 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:36:45 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:36:45 --> Utf8 Class Initialized
INFO - 2017-01-10 02:36:45 --> URI Class Initialized
INFO - 2017-01-10 02:36:45 --> Router Class Initialized
INFO - 2017-01-10 02:36:45 --> Output Class Initialized
INFO - 2017-01-10 02:36:45 --> Security Class Initialized
DEBUG - 2017-01-10 02:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:36:45 --> Input Class Initialized
INFO - 2017-01-10 02:36:45 --> Language Class Initialized
INFO - 2017-01-10 02:36:45 --> Loader Class Initialized
INFO - 2017-01-10 02:36:45 --> Database Driver Class Initialized
INFO - 2017-01-10 02:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:36:45 --> Controller Class Initialized
INFO - 2017-01-10 02:36:45 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:36:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:36:46 --> Config Class Initialized
INFO - 2017-01-10 02:36:46 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:36:46 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:36:46 --> Utf8 Class Initialized
INFO - 2017-01-10 02:36:46 --> URI Class Initialized
DEBUG - 2017-01-10 02:36:46 --> No URI present. Default controller set.
INFO - 2017-01-10 02:36:46 --> Router Class Initialized
INFO - 2017-01-10 02:36:46 --> Output Class Initialized
INFO - 2017-01-10 02:36:46 --> Security Class Initialized
DEBUG - 2017-01-10 02:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:36:46 --> Input Class Initialized
INFO - 2017-01-10 02:36:46 --> Language Class Initialized
INFO - 2017-01-10 02:36:46 --> Loader Class Initialized
INFO - 2017-01-10 02:36:46 --> Database Driver Class Initialized
INFO - 2017-01-10 02:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:36:46 --> Controller Class Initialized
INFO - 2017-01-10 02:36:46 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:36:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:36:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:36:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:36:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:36:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:36:46 --> Final output sent to browser
DEBUG - 2017-01-10 02:36:46 --> Total execution time: 0.1606
INFO - 2017-01-10 02:36:54 --> Config Class Initialized
INFO - 2017-01-10 02:36:54 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:36:54 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:36:54 --> Utf8 Class Initialized
INFO - 2017-01-10 02:36:54 --> URI Class Initialized
INFO - 2017-01-10 02:36:54 --> Router Class Initialized
INFO - 2017-01-10 02:36:54 --> Output Class Initialized
INFO - 2017-01-10 02:36:54 --> Security Class Initialized
DEBUG - 2017-01-10 02:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:36:54 --> Input Class Initialized
INFO - 2017-01-10 02:36:54 --> Language Class Initialized
INFO - 2017-01-10 02:36:54 --> Loader Class Initialized
INFO - 2017-01-10 02:36:54 --> Database Driver Class Initialized
INFO - 2017-01-10 02:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:36:54 --> Controller Class Initialized
INFO - 2017-01-10 02:36:54 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:36:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:36:55 --> Config Class Initialized
INFO - 2017-01-10 02:36:55 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:36:55 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:36:55 --> Utf8 Class Initialized
INFO - 2017-01-10 02:36:55 --> URI Class Initialized
INFO - 2017-01-10 02:36:55 --> Router Class Initialized
INFO - 2017-01-10 02:36:55 --> Output Class Initialized
INFO - 2017-01-10 02:36:55 --> Security Class Initialized
DEBUG - 2017-01-10 02:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:36:55 --> Input Class Initialized
INFO - 2017-01-10 02:36:55 --> Language Class Initialized
INFO - 2017-01-10 02:36:55 --> Loader Class Initialized
INFO - 2017-01-10 02:36:55 --> Database Driver Class Initialized
INFO - 2017-01-10 02:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:36:55 --> Controller Class Initialized
INFO - 2017-01-10 02:36:55 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:36:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:36:55 --> Helper loaded: url_helper
INFO - 2017-01-10 02:36:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:36:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-10 02:36:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-10 02:36:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-10 02:36:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:36:55 --> Final output sent to browser
DEBUG - 2017-01-10 02:36:55 --> Total execution time: 0.0643
INFO - 2017-01-10 02:37:03 --> Config Class Initialized
INFO - 2017-01-10 02:37:03 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:37:03 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:37:03 --> Utf8 Class Initialized
INFO - 2017-01-10 02:37:03 --> URI Class Initialized
INFO - 2017-01-10 02:37:03 --> Router Class Initialized
INFO - 2017-01-10 02:37:03 --> Output Class Initialized
INFO - 2017-01-10 02:37:03 --> Security Class Initialized
DEBUG - 2017-01-10 02:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:37:03 --> Input Class Initialized
INFO - 2017-01-10 02:37:03 --> Language Class Initialized
INFO - 2017-01-10 02:37:03 --> Loader Class Initialized
INFO - 2017-01-10 02:37:03 --> Database Driver Class Initialized
INFO - 2017-01-10 02:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:37:03 --> Controller Class Initialized
INFO - 2017-01-10 02:37:03 --> Helper loaded: date_helper
INFO - 2017-01-10 02:37:03 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:37:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:37:03 --> Helper loaded: form_helper
INFO - 2017-01-10 02:37:03 --> Form Validation Class Initialized
INFO - 2017-01-10 02:37:03 --> Final output sent to browser
DEBUG - 2017-01-10 02:37:03 --> Total execution time: 0.0145
INFO - 2017-01-10 02:37:06 --> Config Class Initialized
INFO - 2017-01-10 02:37:06 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:37:06 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:37:06 --> Utf8 Class Initialized
INFO - 2017-01-10 02:37:06 --> URI Class Initialized
INFO - 2017-01-10 02:37:06 --> Router Class Initialized
INFO - 2017-01-10 02:37:06 --> Output Class Initialized
INFO - 2017-01-10 02:37:06 --> Security Class Initialized
DEBUG - 2017-01-10 02:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:37:06 --> Input Class Initialized
INFO - 2017-01-10 02:37:06 --> Language Class Initialized
INFO - 2017-01-10 02:37:06 --> Loader Class Initialized
INFO - 2017-01-10 02:37:06 --> Database Driver Class Initialized
INFO - 2017-01-10 02:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:37:06 --> Controller Class Initialized
INFO - 2017-01-10 02:37:06 --> Helper loaded: date_helper
INFO - 2017-01-10 02:37:06 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:37:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:37:06 --> Helper loaded: form_helper
INFO - 2017-01-10 02:37:06 --> Form Validation Class Initialized
INFO - 2017-01-10 02:37:06 --> Final output sent to browser
DEBUG - 2017-01-10 02:37:06 --> Total execution time: 0.0147
INFO - 2017-01-10 02:37:06 --> Config Class Initialized
INFO - 2017-01-10 02:37:06 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:37:06 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:37:06 --> Utf8 Class Initialized
INFO - 2017-01-10 02:37:06 --> URI Class Initialized
INFO - 2017-01-10 02:37:06 --> Router Class Initialized
INFO - 2017-01-10 02:37:06 --> Output Class Initialized
INFO - 2017-01-10 02:37:06 --> Security Class Initialized
DEBUG - 2017-01-10 02:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:37:06 --> Input Class Initialized
INFO - 2017-01-10 02:37:06 --> Language Class Initialized
INFO - 2017-01-10 02:37:06 --> Loader Class Initialized
INFO - 2017-01-10 02:37:06 --> Database Driver Class Initialized
INFO - 2017-01-10 02:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:37:06 --> Controller Class Initialized
INFO - 2017-01-10 02:37:06 --> Helper loaded: date_helper
INFO - 2017-01-10 02:37:06 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:37:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:37:06 --> Helper loaded: form_helper
INFO - 2017-01-10 02:37:06 --> Form Validation Class Initialized
INFO - 2017-01-10 02:37:06 --> Final output sent to browser
DEBUG - 2017-01-10 02:37:06 --> Total execution time: 0.0147
INFO - 2017-01-10 02:37:11 --> Config Class Initialized
INFO - 2017-01-10 02:37:11 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:37:11 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:37:11 --> Utf8 Class Initialized
INFO - 2017-01-10 02:37:11 --> URI Class Initialized
INFO - 2017-01-10 02:37:11 --> Router Class Initialized
INFO - 2017-01-10 02:37:11 --> Output Class Initialized
INFO - 2017-01-10 02:37:11 --> Security Class Initialized
DEBUG - 2017-01-10 02:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:37:11 --> Input Class Initialized
INFO - 2017-01-10 02:37:11 --> Language Class Initialized
INFO - 2017-01-10 02:37:11 --> Loader Class Initialized
INFO - 2017-01-10 02:37:11 --> Database Driver Class Initialized
INFO - 2017-01-10 02:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:37:11 --> Controller Class Initialized
INFO - 2017-01-10 02:37:11 --> Helper loaded: date_helper
INFO - 2017-01-10 02:37:11 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:37:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:37:11 --> Helper loaded: form_helper
INFO - 2017-01-10 02:37:11 --> Form Validation Class Initialized
INFO - 2017-01-10 02:37:11 --> Final output sent to browser
DEBUG - 2017-01-10 02:37:11 --> Total execution time: 0.0154
INFO - 2017-01-10 02:37:13 --> Config Class Initialized
INFO - 2017-01-10 02:37:13 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:37:13 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:37:13 --> Utf8 Class Initialized
INFO - 2017-01-10 02:37:13 --> URI Class Initialized
INFO - 2017-01-10 02:37:13 --> Router Class Initialized
INFO - 2017-01-10 02:37:13 --> Output Class Initialized
INFO - 2017-01-10 02:37:13 --> Security Class Initialized
DEBUG - 2017-01-10 02:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:37:13 --> Input Class Initialized
INFO - 2017-01-10 02:37:13 --> Language Class Initialized
INFO - 2017-01-10 02:37:13 --> Loader Class Initialized
INFO - 2017-01-10 02:37:13 --> Database Driver Class Initialized
INFO - 2017-01-10 02:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:37:13 --> Controller Class Initialized
INFO - 2017-01-10 02:37:13 --> Helper loaded: date_helper
INFO - 2017-01-10 02:37:13 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:37:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:37:13 --> Helper loaded: form_helper
INFO - 2017-01-10 02:37:13 --> Form Validation Class Initialized
INFO - 2017-01-10 02:37:13 --> Final output sent to browser
DEBUG - 2017-01-10 02:37:13 --> Total execution time: 0.0142
INFO - 2017-01-10 02:37:14 --> Config Class Initialized
INFO - 2017-01-10 02:37:14 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:37:14 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:37:14 --> Utf8 Class Initialized
INFO - 2017-01-10 02:37:14 --> URI Class Initialized
INFO - 2017-01-10 02:37:14 --> Router Class Initialized
INFO - 2017-01-10 02:37:14 --> Output Class Initialized
INFO - 2017-01-10 02:37:14 --> Security Class Initialized
DEBUG - 2017-01-10 02:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:37:14 --> Input Class Initialized
INFO - 2017-01-10 02:37:14 --> Language Class Initialized
INFO - 2017-01-10 02:37:14 --> Loader Class Initialized
INFO - 2017-01-10 02:37:14 --> Database Driver Class Initialized
INFO - 2017-01-10 02:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:37:14 --> Controller Class Initialized
INFO - 2017-01-10 02:37:14 --> Helper loaded: date_helper
INFO - 2017-01-10 02:37:14 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:37:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:37:14 --> Helper loaded: form_helper
INFO - 2017-01-10 02:37:14 --> Form Validation Class Initialized
INFO - 2017-01-10 02:37:14 --> Final output sent to browser
DEBUG - 2017-01-10 02:37:14 --> Total execution time: 0.0153
INFO - 2017-01-10 02:37:14 --> Config Class Initialized
INFO - 2017-01-10 02:37:14 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:37:14 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:37:14 --> Utf8 Class Initialized
INFO - 2017-01-10 02:37:14 --> URI Class Initialized
INFO - 2017-01-10 02:37:14 --> Router Class Initialized
INFO - 2017-01-10 02:37:14 --> Output Class Initialized
INFO - 2017-01-10 02:37:14 --> Security Class Initialized
DEBUG - 2017-01-10 02:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:37:14 --> Input Class Initialized
INFO - 2017-01-10 02:37:14 --> Language Class Initialized
INFO - 2017-01-10 02:37:14 --> Loader Class Initialized
INFO - 2017-01-10 02:37:14 --> Database Driver Class Initialized
INFO - 2017-01-10 02:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:37:14 --> Controller Class Initialized
INFO - 2017-01-10 02:37:14 --> Helper loaded: date_helper
INFO - 2017-01-10 02:37:14 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:37:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:37:14 --> Helper loaded: form_helper
INFO - 2017-01-10 02:37:14 --> Form Validation Class Initialized
INFO - 2017-01-10 02:37:14 --> Final output sent to browser
DEBUG - 2017-01-10 02:37:14 --> Total execution time: 0.0156
INFO - 2017-01-10 02:37:16 --> Config Class Initialized
INFO - 2017-01-10 02:37:16 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:37:16 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:37:16 --> Utf8 Class Initialized
INFO - 2017-01-10 02:37:16 --> URI Class Initialized
INFO - 2017-01-10 02:37:16 --> Router Class Initialized
INFO - 2017-01-10 02:37:16 --> Output Class Initialized
INFO - 2017-01-10 02:37:16 --> Security Class Initialized
DEBUG - 2017-01-10 02:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:37:16 --> Input Class Initialized
INFO - 2017-01-10 02:37:16 --> Language Class Initialized
INFO - 2017-01-10 02:37:16 --> Loader Class Initialized
INFO - 2017-01-10 02:37:16 --> Database Driver Class Initialized
INFO - 2017-01-10 02:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:37:16 --> Controller Class Initialized
INFO - 2017-01-10 02:37:16 --> Helper loaded: date_helper
INFO - 2017-01-10 02:37:16 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:37:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:37:16 --> Helper loaded: form_helper
INFO - 2017-01-10 02:37:16 --> Form Validation Class Initialized
INFO - 2017-01-10 02:37:16 --> Final output sent to browser
DEBUG - 2017-01-10 02:37:16 --> Total execution time: 0.0149
INFO - 2017-01-10 02:37:20 --> Config Class Initialized
INFO - 2017-01-10 02:37:20 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:37:20 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:37:20 --> Utf8 Class Initialized
INFO - 2017-01-10 02:37:20 --> URI Class Initialized
INFO - 2017-01-10 02:37:20 --> Router Class Initialized
INFO - 2017-01-10 02:37:20 --> Output Class Initialized
INFO - 2017-01-10 02:37:20 --> Security Class Initialized
DEBUG - 2017-01-10 02:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:37:20 --> Input Class Initialized
INFO - 2017-01-10 02:37:20 --> Language Class Initialized
INFO - 2017-01-10 02:37:20 --> Loader Class Initialized
INFO - 2017-01-10 02:37:20 --> Database Driver Class Initialized
INFO - 2017-01-10 02:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:37:20 --> Controller Class Initialized
INFO - 2017-01-10 02:37:20 --> Helper loaded: date_helper
INFO - 2017-01-10 02:37:20 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:37:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:37:20 --> Helper loaded: form_helper
INFO - 2017-01-10 02:37:20 --> Form Validation Class Initialized
INFO - 2017-01-10 02:37:20 --> Final output sent to browser
DEBUG - 2017-01-10 02:37:20 --> Total execution time: 0.0146
INFO - 2017-01-10 02:37:21 --> Config Class Initialized
INFO - 2017-01-10 02:37:21 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:37:21 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:37:21 --> Utf8 Class Initialized
INFO - 2017-01-10 02:37:21 --> URI Class Initialized
INFO - 2017-01-10 02:37:21 --> Router Class Initialized
INFO - 2017-01-10 02:37:21 --> Output Class Initialized
INFO - 2017-01-10 02:37:21 --> Security Class Initialized
DEBUG - 2017-01-10 02:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:37:21 --> Input Class Initialized
INFO - 2017-01-10 02:37:21 --> Language Class Initialized
INFO - 2017-01-10 02:37:21 --> Loader Class Initialized
INFO - 2017-01-10 02:37:21 --> Database Driver Class Initialized
INFO - 2017-01-10 02:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:37:21 --> Controller Class Initialized
INFO - 2017-01-10 02:37:21 --> Helper loaded: date_helper
INFO - 2017-01-10 02:37:21 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:37:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:37:21 --> Helper loaded: form_helper
INFO - 2017-01-10 02:37:21 --> Form Validation Class Initialized
INFO - 2017-01-10 02:37:21 --> Final output sent to browser
DEBUG - 2017-01-10 02:37:21 --> Total execution time: 0.0159
INFO - 2017-01-10 02:37:57 --> Config Class Initialized
INFO - 2017-01-10 02:37:57 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:37:57 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:37:57 --> Utf8 Class Initialized
INFO - 2017-01-10 02:37:57 --> URI Class Initialized
INFO - 2017-01-10 02:37:57 --> Router Class Initialized
INFO - 2017-01-10 02:37:57 --> Output Class Initialized
INFO - 2017-01-10 02:37:57 --> Security Class Initialized
DEBUG - 2017-01-10 02:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:37:57 --> Input Class Initialized
INFO - 2017-01-10 02:37:57 --> Language Class Initialized
INFO - 2017-01-10 02:37:57 --> Loader Class Initialized
INFO - 2017-01-10 02:37:57 --> Database Driver Class Initialized
INFO - 2017-01-10 02:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:37:57 --> Controller Class Initialized
INFO - 2017-01-10 02:37:57 --> Helper loaded: date_helper
INFO - 2017-01-10 02:37:57 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:37:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:37:57 --> Helper loaded: form_helper
INFO - 2017-01-10 02:37:57 --> Form Validation Class Initialized
INFO - 2017-01-10 02:37:57 --> Final output sent to browser
DEBUG - 2017-01-10 02:37:57 --> Total execution time: 0.2087
INFO - 2017-01-10 02:37:57 --> Config Class Initialized
INFO - 2017-01-10 02:37:57 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:37:57 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:37:57 --> Utf8 Class Initialized
INFO - 2017-01-10 02:37:57 --> URI Class Initialized
INFO - 2017-01-10 02:37:57 --> Router Class Initialized
INFO - 2017-01-10 02:37:57 --> Output Class Initialized
INFO - 2017-01-10 02:37:57 --> Security Class Initialized
DEBUG - 2017-01-10 02:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:37:57 --> Input Class Initialized
INFO - 2017-01-10 02:37:57 --> Language Class Initialized
INFO - 2017-01-10 02:37:57 --> Loader Class Initialized
INFO - 2017-01-10 02:37:57 --> Database Driver Class Initialized
INFO - 2017-01-10 02:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:37:57 --> Controller Class Initialized
INFO - 2017-01-10 02:37:57 --> Helper loaded: date_helper
INFO - 2017-01-10 02:37:57 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:37:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:37:57 --> Helper loaded: form_helper
INFO - 2017-01-10 02:37:57 --> Form Validation Class Initialized
INFO - 2017-01-10 02:37:57 --> Final output sent to browser
DEBUG - 2017-01-10 02:37:57 --> Total execution time: 0.0143
INFO - 2017-01-10 02:38:14 --> Config Class Initialized
INFO - 2017-01-10 02:38:14 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:38:14 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:38:14 --> Utf8 Class Initialized
INFO - 2017-01-10 02:38:14 --> URI Class Initialized
INFO - 2017-01-10 02:38:14 --> Router Class Initialized
INFO - 2017-01-10 02:38:14 --> Output Class Initialized
INFO - 2017-01-10 02:38:14 --> Security Class Initialized
DEBUG - 2017-01-10 02:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:38:14 --> Input Class Initialized
INFO - 2017-01-10 02:38:14 --> Language Class Initialized
INFO - 2017-01-10 02:38:14 --> Loader Class Initialized
INFO - 2017-01-10 02:38:14 --> Database Driver Class Initialized
INFO - 2017-01-10 02:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:38:14 --> Controller Class Initialized
INFO - 2017-01-10 02:38:14 --> Helper loaded: date_helper
INFO - 2017-01-10 02:38:14 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:38:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:38:14 --> Helper loaded: form_helper
INFO - 2017-01-10 02:38:14 --> Form Validation Class Initialized
INFO - 2017-01-10 02:38:14 --> Final output sent to browser
DEBUG - 2017-01-10 02:38:14 --> Total execution time: 0.8169
INFO - 2017-01-10 02:38:59 --> Config Class Initialized
INFO - 2017-01-10 02:38:59 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:38:59 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:38:59 --> Utf8 Class Initialized
INFO - 2017-01-10 02:38:59 --> URI Class Initialized
INFO - 2017-01-10 02:38:59 --> Router Class Initialized
INFO - 2017-01-10 02:38:59 --> Output Class Initialized
INFO - 2017-01-10 02:38:59 --> Security Class Initialized
DEBUG - 2017-01-10 02:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:38:59 --> Input Class Initialized
INFO - 2017-01-10 02:38:59 --> Language Class Initialized
INFO - 2017-01-10 02:38:59 --> Loader Class Initialized
INFO - 2017-01-10 02:38:59 --> Database Driver Class Initialized
INFO - 2017-01-10 02:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:38:59 --> Controller Class Initialized
INFO - 2017-01-10 02:38:59 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:38:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:38:59 --> Helper loaded: url_helper
INFO - 2017-01-10 02:39:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:39:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:39:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-10 02:39:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-10 02:39:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:39:00 --> Final output sent to browser
DEBUG - 2017-01-10 02:39:00 --> Total execution time: 0.7127
INFO - 2017-01-10 02:39:09 --> Config Class Initialized
INFO - 2017-01-10 02:39:09 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:39:09 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:39:09 --> Utf8 Class Initialized
INFO - 2017-01-10 02:39:09 --> URI Class Initialized
INFO - 2017-01-10 02:39:09 --> Router Class Initialized
INFO - 2017-01-10 02:39:09 --> Output Class Initialized
INFO - 2017-01-10 02:39:09 --> Security Class Initialized
DEBUG - 2017-01-10 02:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:39:09 --> Input Class Initialized
INFO - 2017-01-10 02:39:09 --> Language Class Initialized
INFO - 2017-01-10 02:39:09 --> Loader Class Initialized
INFO - 2017-01-10 02:39:09 --> Database Driver Class Initialized
INFO - 2017-01-10 02:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:39:09 --> Controller Class Initialized
INFO - 2017-01-10 02:39:09 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:39:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:39:09 --> Helper loaded: url_helper
INFO - 2017-01-10 02:39:09 --> Helper loaded: download_helper
INFO - 2017-01-10 02:39:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:39:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:39:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-10 02:39:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-10 02:39:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:39:09 --> Final output sent to browser
DEBUG - 2017-01-10 02:39:09 --> Total execution time: 0.2513
INFO - 2017-01-10 02:39:17 --> Config Class Initialized
INFO - 2017-01-10 02:39:17 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:39:17 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:39:17 --> Utf8 Class Initialized
INFO - 2017-01-10 02:39:17 --> URI Class Initialized
INFO - 2017-01-10 02:39:17 --> Router Class Initialized
INFO - 2017-01-10 02:39:17 --> Output Class Initialized
INFO - 2017-01-10 02:39:17 --> Security Class Initialized
DEBUG - 2017-01-10 02:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:39:17 --> Input Class Initialized
INFO - 2017-01-10 02:39:17 --> Language Class Initialized
INFO - 2017-01-10 02:39:17 --> Loader Class Initialized
INFO - 2017-01-10 02:39:17 --> Database Driver Class Initialized
INFO - 2017-01-10 02:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:39:17 --> Controller Class Initialized
INFO - 2017-01-10 02:39:17 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:39:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:39:17 --> Helper loaded: url_helper
INFO - 2017-01-10 02:39:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:39:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-10 02:39:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:39:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-10 02:39:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-10 02:39:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:39:17 --> Final output sent to browser
DEBUG - 2017-01-10 02:39:17 --> Total execution time: 0.0626
INFO - 2017-01-10 02:39:20 --> Config Class Initialized
INFO - 2017-01-10 02:39:20 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:39:20 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:39:20 --> Utf8 Class Initialized
INFO - 2017-01-10 02:39:20 --> URI Class Initialized
INFO - 2017-01-10 02:39:20 --> Router Class Initialized
INFO - 2017-01-10 02:39:20 --> Output Class Initialized
INFO - 2017-01-10 02:39:20 --> Security Class Initialized
DEBUG - 2017-01-10 02:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:39:20 --> Input Class Initialized
INFO - 2017-01-10 02:39:20 --> Language Class Initialized
INFO - 2017-01-10 02:39:20 --> Loader Class Initialized
INFO - 2017-01-10 02:39:20 --> Database Driver Class Initialized
INFO - 2017-01-10 02:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:39:20 --> Controller Class Initialized
INFO - 2017-01-10 02:39:20 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:39:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:39:20 --> Helper loaded: url_helper
INFO - 2017-01-10 02:39:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:39:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:39:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-10 02:39:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-10 02:39:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:39:20 --> Final output sent to browser
DEBUG - 2017-01-10 02:39:20 --> Total execution time: 0.0145
INFO - 2017-01-10 02:39:26 --> Config Class Initialized
INFO - 2017-01-10 02:39:26 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:39:26 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:39:26 --> Utf8 Class Initialized
INFO - 2017-01-10 02:39:26 --> URI Class Initialized
INFO - 2017-01-10 02:39:26 --> Router Class Initialized
INFO - 2017-01-10 02:39:26 --> Output Class Initialized
INFO - 2017-01-10 02:39:26 --> Security Class Initialized
DEBUG - 2017-01-10 02:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:39:26 --> Input Class Initialized
INFO - 2017-01-10 02:39:26 --> Language Class Initialized
INFO - 2017-01-10 02:39:26 --> Loader Class Initialized
INFO - 2017-01-10 02:39:26 --> Database Driver Class Initialized
INFO - 2017-01-10 02:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:39:26 --> Controller Class Initialized
INFO - 2017-01-10 02:39:26 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:39:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:39:26 --> Helper loaded: url_helper
INFO - 2017-01-10 02:39:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:39:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:39:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-10 02:39:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-10 02:39:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:39:27 --> Final output sent to browser
DEBUG - 2017-01-10 02:39:27 --> Total execution time: 0.0157
INFO - 2017-01-10 02:39:41 --> Config Class Initialized
INFO - 2017-01-10 02:39:41 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:39:41 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:39:41 --> Utf8 Class Initialized
INFO - 2017-01-10 02:39:41 --> URI Class Initialized
INFO - 2017-01-10 02:39:41 --> Router Class Initialized
INFO - 2017-01-10 02:39:41 --> Output Class Initialized
INFO - 2017-01-10 02:39:41 --> Security Class Initialized
DEBUG - 2017-01-10 02:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:39:41 --> Input Class Initialized
INFO - 2017-01-10 02:39:41 --> Language Class Initialized
INFO - 2017-01-10 02:39:41 --> Loader Class Initialized
INFO - 2017-01-10 02:39:41 --> Database Driver Class Initialized
INFO - 2017-01-10 02:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:39:41 --> Controller Class Initialized
INFO - 2017-01-10 02:39:41 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:39:41 --> Config Class Initialized
INFO - 2017-01-10 02:39:41 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:39:41 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:39:41 --> Utf8 Class Initialized
INFO - 2017-01-10 02:39:41 --> URI Class Initialized
DEBUG - 2017-01-10 02:39:41 --> No URI present. Default controller set.
INFO - 2017-01-10 02:39:41 --> Router Class Initialized
INFO - 2017-01-10 02:39:41 --> Output Class Initialized
INFO - 2017-01-10 02:39:41 --> Security Class Initialized
DEBUG - 2017-01-10 02:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:39:41 --> Input Class Initialized
INFO - 2017-01-10 02:39:41 --> Language Class Initialized
INFO - 2017-01-10 02:39:41 --> Loader Class Initialized
INFO - 2017-01-10 02:39:41 --> Database Driver Class Initialized
INFO - 2017-01-10 02:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:39:41 --> Controller Class Initialized
INFO - 2017-01-10 02:39:41 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:39:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:39:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:39:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:39:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:39:41 --> Final output sent to browser
DEBUG - 2017-01-10 02:39:41 --> Total execution time: 0.1437
INFO - 2017-01-10 02:39:45 --> Config Class Initialized
INFO - 2017-01-10 02:39:45 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:39:45 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:39:45 --> Utf8 Class Initialized
INFO - 2017-01-10 02:39:45 --> URI Class Initialized
INFO - 2017-01-10 02:39:45 --> Router Class Initialized
INFO - 2017-01-10 02:39:45 --> Output Class Initialized
INFO - 2017-01-10 02:39:45 --> Security Class Initialized
DEBUG - 2017-01-10 02:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:39:45 --> Input Class Initialized
INFO - 2017-01-10 02:39:45 --> Language Class Initialized
INFO - 2017-01-10 02:39:45 --> Loader Class Initialized
INFO - 2017-01-10 02:39:45 --> Database Driver Class Initialized
INFO - 2017-01-10 02:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:39:45 --> Controller Class Initialized
INFO - 2017-01-10 02:39:45 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:39:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:39:47 --> Config Class Initialized
INFO - 2017-01-10 02:39:47 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:39:47 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:39:47 --> Utf8 Class Initialized
INFO - 2017-01-10 02:39:47 --> URI Class Initialized
INFO - 2017-01-10 02:39:47 --> Router Class Initialized
INFO - 2017-01-10 02:39:47 --> Output Class Initialized
INFO - 2017-01-10 02:39:47 --> Security Class Initialized
DEBUG - 2017-01-10 02:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:39:47 --> Input Class Initialized
INFO - 2017-01-10 02:39:47 --> Language Class Initialized
INFO - 2017-01-10 02:39:47 --> Loader Class Initialized
INFO - 2017-01-10 02:39:47 --> Database Driver Class Initialized
INFO - 2017-01-10 02:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:39:47 --> Controller Class Initialized
INFO - 2017-01-10 02:39:47 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:39:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:39:47 --> Helper loaded: url_helper
INFO - 2017-01-10 02:39:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:39:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:39:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-10 02:39:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-10 02:39:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:39:47 --> Final output sent to browser
DEBUG - 2017-01-10 02:39:47 --> Total execution time: 0.0141
INFO - 2017-01-10 02:40:03 --> Config Class Initialized
INFO - 2017-01-10 02:40:03 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:40:03 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:40:03 --> Utf8 Class Initialized
INFO - 2017-01-10 02:40:03 --> URI Class Initialized
INFO - 2017-01-10 02:40:03 --> Router Class Initialized
INFO - 2017-01-10 02:40:03 --> Output Class Initialized
INFO - 2017-01-10 02:40:03 --> Security Class Initialized
DEBUG - 2017-01-10 02:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:40:03 --> Input Class Initialized
INFO - 2017-01-10 02:40:03 --> Language Class Initialized
INFO - 2017-01-10 02:40:03 --> Loader Class Initialized
INFO - 2017-01-10 02:40:03 --> Database Driver Class Initialized
INFO - 2017-01-10 02:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:40:03 --> Controller Class Initialized
INFO - 2017-01-10 02:40:03 --> Upload Class Initialized
INFO - 2017-01-10 02:40:03 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:40:03 --> Helper loaded: form_helper
INFO - 2017-01-10 02:40:03 --> Form Validation Class Initialized
INFO - 2017-01-10 02:40:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:40:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 02:40:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-10 02:40:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-10 02:40:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-10 02:40:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:40:03 --> Final output sent to browser
DEBUG - 2017-01-10 02:40:03 --> Total execution time: 0.1515
INFO - 2017-01-10 02:40:03 --> Config Class Initialized
INFO - 2017-01-10 02:40:03 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:40:03 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:40:03 --> Utf8 Class Initialized
INFO - 2017-01-10 02:40:03 --> URI Class Initialized
INFO - 2017-01-10 02:40:03 --> Router Class Initialized
INFO - 2017-01-10 02:40:03 --> Output Class Initialized
INFO - 2017-01-10 02:40:03 --> Security Class Initialized
DEBUG - 2017-01-10 02:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:40:03 --> Input Class Initialized
INFO - 2017-01-10 02:40:03 --> Language Class Initialized
INFO - 2017-01-10 02:40:03 --> Loader Class Initialized
INFO - 2017-01-10 02:40:03 --> Database Driver Class Initialized
INFO - 2017-01-10 02:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:40:03 --> Controller Class Initialized
INFO - 2017-01-10 02:40:03 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:40:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:40:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:40:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:40:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:40:03 --> Final output sent to browser
DEBUG - 2017-01-10 02:40:03 --> Total execution time: 0.0136
INFO - 2017-01-10 02:40:34 --> Config Class Initialized
INFO - 2017-01-10 02:40:34 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:40:34 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:40:34 --> Utf8 Class Initialized
INFO - 2017-01-10 02:40:34 --> URI Class Initialized
INFO - 2017-01-10 02:40:34 --> Router Class Initialized
INFO - 2017-01-10 02:40:34 --> Output Class Initialized
INFO - 2017-01-10 02:40:34 --> Security Class Initialized
DEBUG - 2017-01-10 02:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:40:34 --> Input Class Initialized
INFO - 2017-01-10 02:40:34 --> Language Class Initialized
INFO - 2017-01-10 02:40:34 --> Loader Class Initialized
INFO - 2017-01-10 02:40:34 --> Database Driver Class Initialized
INFO - 2017-01-10 02:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:40:34 --> Controller Class Initialized
INFO - 2017-01-10 02:40:34 --> Upload Class Initialized
INFO - 2017-01-10 02:40:34 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:40:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:40:34 --> Helper loaded: form_helper
INFO - 2017-01-10 02:40:34 --> Form Validation Class Initialized
INFO - 2017-01-10 02:40:34 --> Final output sent to browser
DEBUG - 2017-01-10 02:40:34 --> Total execution time: 0.2127
INFO - 2017-01-10 02:40:35 --> Config Class Initialized
INFO - 2017-01-10 02:40:35 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:40:35 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:40:35 --> Utf8 Class Initialized
INFO - 2017-01-10 02:40:35 --> URI Class Initialized
INFO - 2017-01-10 02:40:35 --> Router Class Initialized
INFO - 2017-01-10 02:40:35 --> Output Class Initialized
INFO - 2017-01-10 02:40:35 --> Security Class Initialized
DEBUG - 2017-01-10 02:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:40:35 --> Input Class Initialized
INFO - 2017-01-10 02:40:35 --> Language Class Initialized
INFO - 2017-01-10 02:40:35 --> Loader Class Initialized
INFO - 2017-01-10 02:40:35 --> Database Driver Class Initialized
INFO - 2017-01-10 02:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:40:35 --> Controller Class Initialized
INFO - 2017-01-10 02:40:35 --> Upload Class Initialized
INFO - 2017-01-10 02:40:35 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:40:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:40:35 --> Helper loaded: form_helper
INFO - 2017-01-10 02:40:35 --> Form Validation Class Initialized
INFO - 2017-01-10 02:40:35 --> Final output sent to browser
DEBUG - 2017-01-10 02:40:35 --> Total execution time: 0.2279
INFO - 2017-01-10 02:40:36 --> Config Class Initialized
INFO - 2017-01-10 02:40:36 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:40:36 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:40:36 --> Utf8 Class Initialized
INFO - 2017-01-10 02:40:36 --> URI Class Initialized
INFO - 2017-01-10 02:40:36 --> Router Class Initialized
INFO - 2017-01-10 02:40:36 --> Output Class Initialized
INFO - 2017-01-10 02:40:36 --> Security Class Initialized
DEBUG - 2017-01-10 02:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:40:36 --> Input Class Initialized
INFO - 2017-01-10 02:40:36 --> Language Class Initialized
INFO - 2017-01-10 02:40:36 --> Loader Class Initialized
INFO - 2017-01-10 02:40:36 --> Database Driver Class Initialized
INFO - 2017-01-10 02:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:40:36 --> Controller Class Initialized
INFO - 2017-01-10 02:40:36 --> Upload Class Initialized
INFO - 2017-01-10 02:40:36 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:40:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:40:36 --> Helper loaded: form_helper
INFO - 2017-01-10 02:40:36 --> Form Validation Class Initialized
INFO - 2017-01-10 02:40:36 --> Final output sent to browser
DEBUG - 2017-01-10 02:40:36 --> Total execution time: 0.0166
INFO - 2017-01-10 02:40:36 --> Config Class Initialized
INFO - 2017-01-10 02:40:36 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:40:36 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:40:36 --> Utf8 Class Initialized
INFO - 2017-01-10 02:40:36 --> URI Class Initialized
INFO - 2017-01-10 02:40:36 --> Router Class Initialized
INFO - 2017-01-10 02:40:36 --> Output Class Initialized
INFO - 2017-01-10 02:40:36 --> Security Class Initialized
DEBUG - 2017-01-10 02:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:40:36 --> Input Class Initialized
INFO - 2017-01-10 02:40:36 --> Language Class Initialized
INFO - 2017-01-10 02:40:36 --> Loader Class Initialized
INFO - 2017-01-10 02:40:36 --> Database Driver Class Initialized
INFO - 2017-01-10 02:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:40:36 --> Controller Class Initialized
INFO - 2017-01-10 02:40:36 --> Upload Class Initialized
INFO - 2017-01-10 02:40:36 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:40:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:40:36 --> Helper loaded: form_helper
INFO - 2017-01-10 02:40:36 --> Form Validation Class Initialized
INFO - 2017-01-10 02:40:36 --> Final output sent to browser
DEBUG - 2017-01-10 02:40:36 --> Total execution time: 0.0161
INFO - 2017-01-10 02:41:40 --> Config Class Initialized
INFO - 2017-01-10 02:41:40 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:41:40 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:41:40 --> Utf8 Class Initialized
INFO - 2017-01-10 02:41:40 --> URI Class Initialized
INFO - 2017-01-10 02:41:40 --> Router Class Initialized
INFO - 2017-01-10 02:41:40 --> Output Class Initialized
INFO - 2017-01-10 02:41:40 --> Security Class Initialized
DEBUG - 2017-01-10 02:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:41:40 --> Input Class Initialized
INFO - 2017-01-10 02:41:40 --> Language Class Initialized
INFO - 2017-01-10 02:41:40 --> Loader Class Initialized
INFO - 2017-01-10 02:41:40 --> Database Driver Class Initialized
INFO - 2017-01-10 02:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:41:40 --> Controller Class Initialized
INFO - 2017-01-10 02:41:40 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:41:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:41:40 --> Helper loaded: url_helper
INFO - 2017-01-10 02:41:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:41:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:41:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-10 02:41:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-10 02:41:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:41:40 --> Final output sent to browser
DEBUG - 2017-01-10 02:41:40 --> Total execution time: 0.0144
INFO - 2017-01-10 02:41:56 --> Config Class Initialized
INFO - 2017-01-10 02:41:56 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:41:56 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:41:56 --> Utf8 Class Initialized
INFO - 2017-01-10 02:41:56 --> URI Class Initialized
INFO - 2017-01-10 02:41:56 --> Router Class Initialized
INFO - 2017-01-10 02:41:56 --> Output Class Initialized
INFO - 2017-01-10 02:41:56 --> Security Class Initialized
DEBUG - 2017-01-10 02:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:41:56 --> Input Class Initialized
INFO - 2017-01-10 02:41:56 --> Language Class Initialized
INFO - 2017-01-10 02:41:56 --> Loader Class Initialized
INFO - 2017-01-10 02:41:56 --> Database Driver Class Initialized
INFO - 2017-01-10 02:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:41:56 --> Controller Class Initialized
INFO - 2017-01-10 02:41:56 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:41:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:41:56 --> Helper loaded: url_helper
INFO - 2017-01-10 02:41:56 --> Helper loaded: download_helper
INFO - 2017-01-10 02:41:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:41:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:41:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-10 02:41:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-10 02:41:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:41:56 --> Final output sent to browser
DEBUG - 2017-01-10 02:41:56 --> Total execution time: 0.0188
INFO - 2017-01-10 02:42:03 --> Config Class Initialized
INFO - 2017-01-10 02:42:03 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:42:03 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:42:03 --> Utf8 Class Initialized
INFO - 2017-01-10 02:42:03 --> URI Class Initialized
INFO - 2017-01-10 02:42:03 --> Router Class Initialized
INFO - 2017-01-10 02:42:03 --> Output Class Initialized
INFO - 2017-01-10 02:42:03 --> Security Class Initialized
DEBUG - 2017-01-10 02:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:42:03 --> Input Class Initialized
INFO - 2017-01-10 02:42:03 --> Language Class Initialized
INFO - 2017-01-10 02:42:03 --> Loader Class Initialized
INFO - 2017-01-10 02:42:03 --> Database Driver Class Initialized
INFO - 2017-01-10 02:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:42:03 --> Controller Class Initialized
INFO - 2017-01-10 02:42:03 --> Upload Class Initialized
INFO - 2017-01-10 02:42:03 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:42:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:42:03 --> Helper loaded: form_helper
INFO - 2017-01-10 02:42:03 --> Form Validation Class Initialized
INFO - 2017-01-10 02:42:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:42:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 02:42:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-10 02:42:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-10 02:42:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-10 02:42:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:42:03 --> Final output sent to browser
DEBUG - 2017-01-10 02:42:03 --> Total execution time: 0.0161
INFO - 2017-01-10 02:42:04 --> Config Class Initialized
INFO - 2017-01-10 02:42:04 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:42:04 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:42:04 --> Utf8 Class Initialized
INFO - 2017-01-10 02:42:04 --> URI Class Initialized
INFO - 2017-01-10 02:42:04 --> Router Class Initialized
INFO - 2017-01-10 02:42:04 --> Output Class Initialized
INFO - 2017-01-10 02:42:04 --> Security Class Initialized
DEBUG - 2017-01-10 02:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:42:04 --> Input Class Initialized
INFO - 2017-01-10 02:42:04 --> Language Class Initialized
INFO - 2017-01-10 02:42:04 --> Loader Class Initialized
INFO - 2017-01-10 02:42:04 --> Database Driver Class Initialized
INFO - 2017-01-10 02:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:42:04 --> Controller Class Initialized
INFO - 2017-01-10 02:42:04 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:42:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:42:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:42:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:42:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:42:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:42:04 --> Final output sent to browser
DEBUG - 2017-01-10 02:42:04 --> Total execution time: 0.0134
INFO - 2017-01-10 02:42:06 --> Config Class Initialized
INFO - 2017-01-10 02:42:06 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:42:06 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:42:06 --> Utf8 Class Initialized
INFO - 2017-01-10 02:42:06 --> URI Class Initialized
INFO - 2017-01-10 02:42:06 --> Router Class Initialized
INFO - 2017-01-10 02:42:06 --> Output Class Initialized
INFO - 2017-01-10 02:42:06 --> Security Class Initialized
DEBUG - 2017-01-10 02:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:42:06 --> Input Class Initialized
INFO - 2017-01-10 02:42:06 --> Language Class Initialized
INFO - 2017-01-10 02:42:06 --> Loader Class Initialized
INFO - 2017-01-10 02:42:06 --> Database Driver Class Initialized
INFO - 2017-01-10 02:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:42:06 --> Controller Class Initialized
INFO - 2017-01-10 02:42:06 --> Helper loaded: date_helper
INFO - 2017-01-10 02:42:06 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:42:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:42:06 --> Helper loaded: form_helper
INFO - 2017-01-10 02:42:06 --> Form Validation Class Initialized
INFO - 2017-01-10 02:42:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:42:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 02:42:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-10 02:42:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-10 02:42:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:42:07 --> Final output sent to browser
DEBUG - 2017-01-10 02:42:07 --> Total execution time: 0.2515
INFO - 2017-01-10 02:42:07 --> Config Class Initialized
INFO - 2017-01-10 02:42:07 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:42:07 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:42:07 --> Utf8 Class Initialized
INFO - 2017-01-10 02:42:07 --> URI Class Initialized
INFO - 2017-01-10 02:42:07 --> Router Class Initialized
INFO - 2017-01-10 02:42:07 --> Output Class Initialized
INFO - 2017-01-10 02:42:07 --> Security Class Initialized
DEBUG - 2017-01-10 02:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:42:07 --> Input Class Initialized
INFO - 2017-01-10 02:42:07 --> Language Class Initialized
INFO - 2017-01-10 02:42:07 --> Loader Class Initialized
INFO - 2017-01-10 02:42:07 --> Database Driver Class Initialized
INFO - 2017-01-10 02:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:42:07 --> Controller Class Initialized
INFO - 2017-01-10 02:42:07 --> Helper loaded: date_helper
INFO - 2017-01-10 02:42:07 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:42:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:42:07 --> Helper loaded: form_helper
INFO - 2017-01-10 02:42:07 --> Form Validation Class Initialized
INFO - 2017-01-10 02:42:07 --> Final output sent to browser
DEBUG - 2017-01-10 02:42:07 --> Total execution time: 0.0892
INFO - 2017-01-10 02:42:07 --> Config Class Initialized
INFO - 2017-01-10 02:42:07 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:42:07 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:42:07 --> Utf8 Class Initialized
INFO - 2017-01-10 02:42:07 --> URI Class Initialized
INFO - 2017-01-10 02:42:07 --> Router Class Initialized
INFO - 2017-01-10 02:42:07 --> Output Class Initialized
INFO - 2017-01-10 02:42:07 --> Security Class Initialized
DEBUG - 2017-01-10 02:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:42:07 --> Input Class Initialized
INFO - 2017-01-10 02:42:07 --> Language Class Initialized
INFO - 2017-01-10 02:42:07 --> Loader Class Initialized
INFO - 2017-01-10 02:42:07 --> Database Driver Class Initialized
INFO - 2017-01-10 02:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:42:07 --> Controller Class Initialized
INFO - 2017-01-10 02:42:07 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:42:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:42:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:42:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:42:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:42:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:42:07 --> Final output sent to browser
DEBUG - 2017-01-10 02:42:07 --> Total execution time: 0.1940
INFO - 2017-01-10 02:42:11 --> Config Class Initialized
INFO - 2017-01-10 02:42:11 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:42:11 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:42:11 --> Utf8 Class Initialized
INFO - 2017-01-10 02:42:11 --> URI Class Initialized
INFO - 2017-01-10 02:42:11 --> Router Class Initialized
INFO - 2017-01-10 02:42:11 --> Output Class Initialized
INFO - 2017-01-10 02:42:11 --> Security Class Initialized
DEBUG - 2017-01-10 02:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:42:11 --> Input Class Initialized
INFO - 2017-01-10 02:42:11 --> Language Class Initialized
INFO - 2017-01-10 02:42:11 --> Loader Class Initialized
INFO - 2017-01-10 02:42:11 --> Database Driver Class Initialized
INFO - 2017-01-10 02:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:42:11 --> Controller Class Initialized
INFO - 2017-01-10 02:42:11 --> Config Class Initialized
INFO - 2017-01-10 02:42:11 --> Hooks Class Initialized
INFO - 2017-01-10 02:42:11 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:42:11 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:42:11 --> Utf8 Class Initialized
INFO - 2017-01-10 02:42:11 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:42:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:42:11 --> URI Class Initialized
INFO - 2017-01-10 02:42:11 --> Router Class Initialized
INFO - 2017-01-10 02:42:11 --> Output Class Initialized
INFO - 2017-01-10 02:42:11 --> Security Class Initialized
DEBUG - 2017-01-10 02:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:42:11 --> Input Class Initialized
INFO - 2017-01-10 02:42:11 --> Language Class Initialized
INFO - 2017-01-10 02:42:11 --> Loader Class Initialized
INFO - 2017-01-10 02:42:11 --> Helper loaded: form_helper
INFO - 2017-01-10 02:42:11 --> Form Validation Class Initialized
INFO - 2017-01-10 02:42:11 --> Database Driver Class Initialized
INFO - 2017-01-10 02:42:11 --> Final output sent to browser
DEBUG - 2017-01-10 02:42:11 --> Total execution time: 0.0891
INFO - 2017-01-10 02:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:42:11 --> Controller Class Initialized
INFO - 2017-01-10 02:42:11 --> Helper loaded: date_helper
INFO - 2017-01-10 02:42:11 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:42:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:42:11 --> Helper loaded: form_helper
INFO - 2017-01-10 02:42:11 --> Form Validation Class Initialized
INFO - 2017-01-10 02:42:11 --> Final output sent to browser
DEBUG - 2017-01-10 02:42:11 --> Total execution time: 0.0932
INFO - 2017-01-10 02:44:53 --> Config Class Initialized
INFO - 2017-01-10 02:44:53 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:44:53 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:44:53 --> Utf8 Class Initialized
INFO - 2017-01-10 02:44:53 --> URI Class Initialized
INFO - 2017-01-10 02:44:53 --> Router Class Initialized
INFO - 2017-01-10 02:44:53 --> Output Class Initialized
INFO - 2017-01-10 02:44:53 --> Security Class Initialized
DEBUG - 2017-01-10 02:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:44:53 --> Input Class Initialized
INFO - 2017-01-10 02:44:53 --> Language Class Initialized
INFO - 2017-01-10 02:44:53 --> Loader Class Initialized
INFO - 2017-01-10 02:44:53 --> Database Driver Class Initialized
INFO - 2017-01-10 02:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:44:53 --> Controller Class Initialized
INFO - 2017-01-10 02:44:53 --> Helper loaded: date_helper
INFO - 2017-01-10 02:44:53 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:44:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:44:53 --> Helper loaded: form_helper
INFO - 2017-01-10 02:44:53 --> Form Validation Class Initialized
INFO - 2017-01-10 02:44:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:44:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 02:44:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-10 02:44:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-10 02:44:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:44:53 --> Final output sent to browser
DEBUG - 2017-01-10 02:44:53 --> Total execution time: 0.3149
INFO - 2017-01-10 02:44:54 --> Config Class Initialized
INFO - 2017-01-10 02:44:54 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:44:54 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:44:54 --> Utf8 Class Initialized
INFO - 2017-01-10 02:44:54 --> URI Class Initialized
INFO - 2017-01-10 02:44:54 --> Router Class Initialized
INFO - 2017-01-10 02:44:54 --> Output Class Initialized
INFO - 2017-01-10 02:44:54 --> Security Class Initialized
DEBUG - 2017-01-10 02:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:44:54 --> Input Class Initialized
INFO - 2017-01-10 02:44:54 --> Language Class Initialized
INFO - 2017-01-10 02:44:54 --> Loader Class Initialized
INFO - 2017-01-10 02:44:54 --> Database Driver Class Initialized
INFO - 2017-01-10 02:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:44:54 --> Controller Class Initialized
INFO - 2017-01-10 02:44:54 --> Helper loaded: date_helper
INFO - 2017-01-10 02:44:54 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:44:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:44:54 --> Helper loaded: form_helper
INFO - 2017-01-10 02:44:54 --> Form Validation Class Initialized
INFO - 2017-01-10 02:44:54 --> Config Class Initialized
INFO - 2017-01-10 02:44:54 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:44:54 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:44:54 --> Utf8 Class Initialized
INFO - 2017-01-10 02:44:54 --> URI Class Initialized
INFO - 2017-01-10 02:44:54 --> Router Class Initialized
INFO - 2017-01-10 02:44:54 --> Output Class Initialized
INFO - 2017-01-10 02:44:54 --> Security Class Initialized
DEBUG - 2017-01-10 02:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:44:54 --> Input Class Initialized
INFO - 2017-01-10 02:44:54 --> Language Class Initialized
INFO - 2017-01-10 02:44:54 --> Loader Class Initialized
INFO - 2017-01-10 02:44:54 --> Final output sent to browser
DEBUG - 2017-01-10 02:44:54 --> Total execution time: 0.1003
INFO - 2017-01-10 02:44:54 --> Database Driver Class Initialized
INFO - 2017-01-10 02:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:44:54 --> Controller Class Initialized
INFO - 2017-01-10 02:44:54 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:44:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:44:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:44:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:44:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:44:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:44:54 --> Final output sent to browser
DEBUG - 2017-01-10 02:44:54 --> Total execution time: 0.1865
INFO - 2017-01-10 02:44:55 --> Config Class Initialized
INFO - 2017-01-10 02:44:55 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:44:55 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:44:55 --> Utf8 Class Initialized
INFO - 2017-01-10 02:44:55 --> URI Class Initialized
INFO - 2017-01-10 02:44:55 --> Router Class Initialized
INFO - 2017-01-10 02:44:55 --> Output Class Initialized
INFO - 2017-01-10 02:44:55 --> Security Class Initialized
DEBUG - 2017-01-10 02:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:44:55 --> Input Class Initialized
INFO - 2017-01-10 02:44:55 --> Language Class Initialized
INFO - 2017-01-10 02:44:55 --> Loader Class Initialized
INFO - 2017-01-10 02:44:55 --> Database Driver Class Initialized
INFO - 2017-01-10 02:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:44:55 --> Controller Class Initialized
INFO - 2017-01-10 02:44:55 --> Helper loaded: date_helper
INFO - 2017-01-10 02:44:55 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:44:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:44:55 --> Helper loaded: form_helper
INFO - 2017-01-10 02:44:55 --> Form Validation Class Initialized
INFO - 2017-01-10 02:44:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:44:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 02:44:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-10 02:44:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-10 02:44:55 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:44:55 --> Final output sent to browser
DEBUG - 2017-01-10 02:44:55 --> Total execution time: 0.0453
INFO - 2017-01-10 02:44:56 --> Config Class Initialized
INFO - 2017-01-10 02:44:56 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:44:56 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:44:56 --> Utf8 Class Initialized
INFO - 2017-01-10 02:44:56 --> URI Class Initialized
INFO - 2017-01-10 02:44:56 --> Router Class Initialized
INFO - 2017-01-10 02:44:56 --> Output Class Initialized
INFO - 2017-01-10 02:44:56 --> Security Class Initialized
DEBUG - 2017-01-10 02:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:44:56 --> Input Class Initialized
INFO - 2017-01-10 02:44:56 --> Language Class Initialized
INFO - 2017-01-10 02:44:56 --> Loader Class Initialized
INFO - 2017-01-10 02:44:56 --> Database Driver Class Initialized
INFO - 2017-01-10 02:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:44:56 --> Controller Class Initialized
INFO - 2017-01-10 02:44:56 --> Helper loaded: date_helper
INFO - 2017-01-10 02:44:56 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:44:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:44:56 --> Config Class Initialized
INFO - 2017-01-10 02:44:56 --> Hooks Class Initialized
INFO - 2017-01-10 02:44:56 --> Helper loaded: form_helper
INFO - 2017-01-10 02:44:56 --> Form Validation Class Initialized
DEBUG - 2017-01-10 02:44:56 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:44:56 --> Utf8 Class Initialized
INFO - 2017-01-10 02:44:56 --> URI Class Initialized
INFO - 2017-01-10 02:44:56 --> Router Class Initialized
INFO - 2017-01-10 02:44:56 --> Output Class Initialized
INFO - 2017-01-10 02:44:56 --> Security Class Initialized
DEBUG - 2017-01-10 02:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:44:56 --> Input Class Initialized
INFO - 2017-01-10 02:44:56 --> Language Class Initialized
INFO - 2017-01-10 02:44:56 --> Loader Class Initialized
INFO - 2017-01-10 02:44:56 --> Database Driver Class Initialized
INFO - 2017-01-10 02:44:56 --> Final output sent to browser
DEBUG - 2017-01-10 02:44:56 --> Total execution time: 0.0233
INFO - 2017-01-10 02:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:44:56 --> Controller Class Initialized
INFO - 2017-01-10 02:44:56 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:44:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:44:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:44:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:44:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:44:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:44:56 --> Final output sent to browser
DEBUG - 2017-01-10 02:44:56 --> Total execution time: 0.0949
INFO - 2017-01-10 02:44:59 --> Config Class Initialized
INFO - 2017-01-10 02:44:59 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:44:59 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:44:59 --> Utf8 Class Initialized
INFO - 2017-01-10 02:44:59 --> URI Class Initialized
INFO - 2017-01-10 02:44:59 --> Router Class Initialized
INFO - 2017-01-10 02:44:59 --> Output Class Initialized
INFO - 2017-01-10 02:44:59 --> Security Class Initialized
DEBUG - 2017-01-10 02:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:44:59 --> Input Class Initialized
INFO - 2017-01-10 02:44:59 --> Language Class Initialized
INFO - 2017-01-10 02:44:59 --> Loader Class Initialized
INFO - 2017-01-10 02:44:59 --> Database Driver Class Initialized
INFO - 2017-01-10 02:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:44:59 --> Controller Class Initialized
INFO - 2017-01-10 02:44:59 --> Upload Class Initialized
INFO - 2017-01-10 02:44:59 --> Helper loaded: date_helper
INFO - 2017-01-10 02:44:59 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:44:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:44:59 --> Helper loaded: form_helper
INFO - 2017-01-10 02:44:59 --> Form Validation Class Initialized
INFO - 2017-01-10 02:44:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:44:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 02:44:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-10 02:44:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-10 02:44:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-10 02:44:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:44:59 --> Final output sent to browser
DEBUG - 2017-01-10 02:44:59 --> Total execution time: 0.0448
INFO - 2017-01-10 02:45:00 --> Config Class Initialized
INFO - 2017-01-10 02:45:00 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:45:00 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:45:00 --> Utf8 Class Initialized
INFO - 2017-01-10 02:45:00 --> URI Class Initialized
INFO - 2017-01-10 02:45:00 --> Router Class Initialized
INFO - 2017-01-10 02:45:00 --> Output Class Initialized
INFO - 2017-01-10 02:45:00 --> Security Class Initialized
DEBUG - 2017-01-10 02:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:45:00 --> Input Class Initialized
INFO - 2017-01-10 02:45:00 --> Language Class Initialized
INFO - 2017-01-10 02:45:00 --> Loader Class Initialized
INFO - 2017-01-10 02:45:00 --> Database Driver Class Initialized
INFO - 2017-01-10 02:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:45:00 --> Controller Class Initialized
INFO - 2017-01-10 02:45:00 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:45:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:45:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:45:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:45:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:45:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:45:00 --> Final output sent to browser
DEBUG - 2017-01-10 02:45:00 --> Total execution time: 0.0148
INFO - 2017-01-10 02:45:09 --> Config Class Initialized
INFO - 2017-01-10 02:45:09 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:45:09 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:45:09 --> Utf8 Class Initialized
INFO - 2017-01-10 02:45:09 --> URI Class Initialized
INFO - 2017-01-10 02:45:09 --> Router Class Initialized
INFO - 2017-01-10 02:45:09 --> Output Class Initialized
INFO - 2017-01-10 02:45:09 --> Security Class Initialized
DEBUG - 2017-01-10 02:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:45:09 --> Input Class Initialized
INFO - 2017-01-10 02:45:09 --> Language Class Initialized
INFO - 2017-01-10 02:45:09 --> Loader Class Initialized
INFO - 2017-01-10 02:45:09 --> Database Driver Class Initialized
INFO - 2017-01-10 02:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:45:09 --> Controller Class Initialized
INFO - 2017-01-10 02:45:09 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:45:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:45:09 --> Helper loaded: url_helper
INFO - 2017-01-10 02:45:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:45:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 02:45:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-10 02:45:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-10 02:45:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:45:09 --> Final output sent to browser
DEBUG - 2017-01-10 02:45:09 --> Total execution time: 0.0548
INFO - 2017-01-10 02:45:12 --> Config Class Initialized
INFO - 2017-01-10 02:45:12 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:45:12 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:45:12 --> Utf8 Class Initialized
INFO - 2017-01-10 02:45:12 --> URI Class Initialized
INFO - 2017-01-10 02:45:12 --> Router Class Initialized
INFO - 2017-01-10 02:45:12 --> Output Class Initialized
INFO - 2017-01-10 02:45:12 --> Security Class Initialized
DEBUG - 2017-01-10 02:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:45:12 --> Input Class Initialized
INFO - 2017-01-10 02:45:12 --> Language Class Initialized
INFO - 2017-01-10 02:45:12 --> Loader Class Initialized
INFO - 2017-01-10 02:45:12 --> Database Driver Class Initialized
INFO - 2017-01-10 02:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:45:12 --> Controller Class Initialized
INFO - 2017-01-10 02:45:12 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:45:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:45:12 --> Config Class Initialized
INFO - 2017-01-10 02:45:12 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:45:12 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:45:12 --> Utf8 Class Initialized
INFO - 2017-01-10 02:45:12 --> URI Class Initialized
INFO - 2017-01-10 02:45:12 --> Router Class Initialized
INFO - 2017-01-10 02:45:12 --> Output Class Initialized
INFO - 2017-01-10 02:45:12 --> Security Class Initialized
DEBUG - 2017-01-10 02:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:45:12 --> Input Class Initialized
INFO - 2017-01-10 02:45:12 --> Language Class Initialized
INFO - 2017-01-10 02:45:12 --> Loader Class Initialized
INFO - 2017-01-10 02:45:12 --> Database Driver Class Initialized
INFO - 2017-01-10 02:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:45:12 --> Controller Class Initialized
INFO - 2017-01-10 02:45:12 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:45:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:45:12 --> Helper loaded: form_helper
INFO - 2017-01-10 02:45:12 --> Form Validation Class Initialized
INFO - 2017-01-10 02:45:12 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:45:12 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-10 02:45:12 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:45:12 --> Final output sent to browser
DEBUG - 2017-01-10 02:45:12 --> Total execution time: 0.0251
INFO - 2017-01-10 02:45:13 --> Config Class Initialized
INFO - 2017-01-10 02:45:13 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:45:13 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:45:13 --> Utf8 Class Initialized
INFO - 2017-01-10 02:45:13 --> URI Class Initialized
INFO - 2017-01-10 02:45:13 --> Router Class Initialized
INFO - 2017-01-10 02:45:13 --> Output Class Initialized
INFO - 2017-01-10 02:45:13 --> Security Class Initialized
DEBUG - 2017-01-10 02:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:45:13 --> Input Class Initialized
INFO - 2017-01-10 02:45:13 --> Language Class Initialized
INFO - 2017-01-10 02:45:13 --> Loader Class Initialized
INFO - 2017-01-10 02:45:13 --> Database Driver Class Initialized
INFO - 2017-01-10 02:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:45:13 --> Controller Class Initialized
INFO - 2017-01-10 02:45:13 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:45:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:45:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:45:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:45:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:45:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:45:13 --> Final output sent to browser
DEBUG - 2017-01-10 02:45:13 --> Total execution time: 0.0133
INFO - 2017-01-10 02:45:13 --> Config Class Initialized
INFO - 2017-01-10 02:45:13 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:45:13 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:45:13 --> Utf8 Class Initialized
INFO - 2017-01-10 02:45:13 --> URI Class Initialized
INFO - 2017-01-10 02:45:13 --> Router Class Initialized
INFO - 2017-01-10 02:45:13 --> Output Class Initialized
INFO - 2017-01-10 02:45:13 --> Security Class Initialized
DEBUG - 2017-01-10 02:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:45:13 --> Input Class Initialized
INFO - 2017-01-10 02:45:13 --> Language Class Initialized
INFO - 2017-01-10 02:45:13 --> Loader Class Initialized
INFO - 2017-01-10 02:45:13 --> Database Driver Class Initialized
INFO - 2017-01-10 02:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:45:13 --> Controller Class Initialized
INFO - 2017-01-10 02:45:13 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:45:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:45:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:45:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:45:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:45:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:45:13 --> Final output sent to browser
DEBUG - 2017-01-10 02:45:13 --> Total execution time: 0.0138
INFO - 2017-01-10 02:45:58 --> Config Class Initialized
INFO - 2017-01-10 02:45:58 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:45:58 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:45:58 --> Utf8 Class Initialized
INFO - 2017-01-10 02:45:58 --> URI Class Initialized
INFO - 2017-01-10 02:45:58 --> Router Class Initialized
INFO - 2017-01-10 02:45:58 --> Output Class Initialized
INFO - 2017-01-10 02:45:58 --> Security Class Initialized
DEBUG - 2017-01-10 02:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:45:58 --> Input Class Initialized
INFO - 2017-01-10 02:45:58 --> Language Class Initialized
INFO - 2017-01-10 02:45:58 --> Loader Class Initialized
INFO - 2017-01-10 02:45:58 --> Database Driver Class Initialized
INFO - 2017-01-10 02:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:45:58 --> Controller Class Initialized
INFO - 2017-01-10 02:45:58 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:45:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:45:58 --> Helper loaded: form_helper
INFO - 2017-01-10 02:45:58 --> Form Validation Class Initialized
INFO - 2017-01-10 02:45:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-10 02:45:58 --> Config Class Initialized
INFO - 2017-01-10 02:45:58 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:45:58 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:45:58 --> Utf8 Class Initialized
INFO - 2017-01-10 02:45:58 --> URI Class Initialized
INFO - 2017-01-10 02:45:58 --> Router Class Initialized
INFO - 2017-01-10 02:45:58 --> Output Class Initialized
INFO - 2017-01-10 02:45:58 --> Security Class Initialized
DEBUG - 2017-01-10 02:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:45:58 --> Input Class Initialized
INFO - 2017-01-10 02:45:58 --> Language Class Initialized
INFO - 2017-01-10 02:45:58 --> Loader Class Initialized
INFO - 2017-01-10 02:45:58 --> Database Driver Class Initialized
INFO - 2017-01-10 02:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:45:58 --> Controller Class Initialized
INFO - 2017-01-10 02:45:58 --> Helper loaded: date_helper
INFO - 2017-01-10 02:45:58 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:45:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:45:58 --> Helper loaded: form_helper
INFO - 2017-01-10 02:45:58 --> Form Validation Class Initialized
INFO - 2017-01-10 02:45:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:45:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 02:45:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-10 02:45:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-10 02:45:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:45:58 --> Final output sent to browser
DEBUG - 2017-01-10 02:45:58 --> Total execution time: 0.0791
INFO - 2017-01-10 02:45:59 --> Config Class Initialized
INFO - 2017-01-10 02:45:59 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:45:59 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:45:59 --> Utf8 Class Initialized
INFO - 2017-01-10 02:45:59 --> URI Class Initialized
INFO - 2017-01-10 02:45:59 --> Router Class Initialized
INFO - 2017-01-10 02:45:59 --> Output Class Initialized
INFO - 2017-01-10 02:45:59 --> Security Class Initialized
DEBUG - 2017-01-10 02:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:45:59 --> Input Class Initialized
INFO - 2017-01-10 02:45:59 --> Language Class Initialized
INFO - 2017-01-10 02:45:59 --> Loader Class Initialized
INFO - 2017-01-10 02:45:59 --> Database Driver Class Initialized
INFO - 2017-01-10 02:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:45:59 --> Controller Class Initialized
INFO - 2017-01-10 02:45:59 --> Helper loaded: date_helper
INFO - 2017-01-10 02:45:59 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:45:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:45:59 --> Helper loaded: form_helper
INFO - 2017-01-10 02:45:59 --> Form Validation Class Initialized
INFO - 2017-01-10 02:45:59 --> Final output sent to browser
DEBUG - 2017-01-10 02:45:59 --> Total execution time: 0.0146
INFO - 2017-01-10 02:45:59 --> Config Class Initialized
INFO - 2017-01-10 02:45:59 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:45:59 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:45:59 --> Utf8 Class Initialized
INFO - 2017-01-10 02:45:59 --> URI Class Initialized
INFO - 2017-01-10 02:45:59 --> Router Class Initialized
INFO - 2017-01-10 02:45:59 --> Output Class Initialized
INFO - 2017-01-10 02:45:59 --> Security Class Initialized
DEBUG - 2017-01-10 02:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:45:59 --> Input Class Initialized
INFO - 2017-01-10 02:45:59 --> Language Class Initialized
INFO - 2017-01-10 02:45:59 --> Loader Class Initialized
INFO - 2017-01-10 02:45:59 --> Database Driver Class Initialized
INFO - 2017-01-10 02:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:45:59 --> Controller Class Initialized
INFO - 2017-01-10 02:45:59 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:45:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:45:59 --> Final output sent to browser
DEBUG - 2017-01-10 02:45:59 --> Total execution time: 0.0136
INFO - 2017-01-10 02:46:06 --> Config Class Initialized
INFO - 2017-01-10 02:46:06 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:46:06 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:46:06 --> Utf8 Class Initialized
INFO - 2017-01-10 02:46:06 --> URI Class Initialized
INFO - 2017-01-10 02:46:06 --> Router Class Initialized
INFO - 2017-01-10 02:46:06 --> Output Class Initialized
INFO - 2017-01-10 02:46:06 --> Security Class Initialized
DEBUG - 2017-01-10 02:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:46:06 --> Input Class Initialized
INFO - 2017-01-10 02:46:06 --> Language Class Initialized
INFO - 2017-01-10 02:46:06 --> Loader Class Initialized
INFO - 2017-01-10 02:46:06 --> Database Driver Class Initialized
INFO - 2017-01-10 02:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:46:06 --> Controller Class Initialized
INFO - 2017-01-10 02:46:06 --> Helper loaded: date_helper
INFO - 2017-01-10 02:46:06 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:46:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:46:06 --> Helper loaded: form_helper
INFO - 2017-01-10 02:46:06 --> Form Validation Class Initialized
INFO - 2017-01-10 02:46:06 --> Config Class Initialized
INFO - 2017-01-10 02:46:06 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:46:06 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:46:06 --> Utf8 Class Initialized
INFO - 2017-01-10 02:46:06 --> URI Class Initialized
INFO - 2017-01-10 02:46:06 --> Router Class Initialized
INFO - 2017-01-10 02:46:06 --> Output Class Initialized
INFO - 2017-01-10 02:46:06 --> Security Class Initialized
DEBUG - 2017-01-10 02:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:46:06 --> Input Class Initialized
INFO - 2017-01-10 02:46:06 --> Language Class Initialized
INFO - 2017-01-10 02:46:06 --> Loader Class Initialized
INFO - 2017-01-10 02:46:06 --> Database Driver Class Initialized
INFO - 2017-01-10 02:46:06 --> Final output sent to browser
DEBUG - 2017-01-10 02:46:06 --> Total execution time: 0.0145
INFO - 2017-01-10 02:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:46:06 --> Controller Class Initialized
INFO - 2017-01-10 02:46:06 --> Helper loaded: date_helper
INFO - 2017-01-10 02:46:06 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:46:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:46:06 --> Helper loaded: form_helper
INFO - 2017-01-10 02:46:06 --> Form Validation Class Initialized
INFO - 2017-01-10 02:46:06 --> Final output sent to browser
DEBUG - 2017-01-10 02:46:06 --> Total execution time: 0.0206
INFO - 2017-01-10 02:46:20 --> Config Class Initialized
INFO - 2017-01-10 02:46:20 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:46:20 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:46:20 --> Utf8 Class Initialized
INFO - 2017-01-10 02:46:20 --> URI Class Initialized
INFO - 2017-01-10 02:46:20 --> Router Class Initialized
INFO - 2017-01-10 02:46:20 --> Output Class Initialized
INFO - 2017-01-10 02:46:20 --> Security Class Initialized
DEBUG - 2017-01-10 02:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:46:20 --> Input Class Initialized
INFO - 2017-01-10 02:46:20 --> Language Class Initialized
INFO - 2017-01-10 02:46:20 --> Loader Class Initialized
INFO - 2017-01-10 02:46:20 --> Database Driver Class Initialized
INFO - 2017-01-10 02:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:46:20 --> Controller Class Initialized
INFO - 2017-01-10 02:46:20 --> Upload Class Initialized
INFO - 2017-01-10 02:46:20 --> Helper loaded: date_helper
INFO - 2017-01-10 02:46:20 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:46:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:46:20 --> Helper loaded: form_helper
INFO - 2017-01-10 02:46:20 --> Form Validation Class Initialized
INFO - 2017-01-10 02:46:20 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:46:20 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 02:46:20 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-10 02:46:20 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-10 02:46:20 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-10 02:46:20 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:46:20 --> Final output sent to browser
DEBUG - 2017-01-10 02:46:20 --> Total execution time: 0.0155
INFO - 2017-01-10 02:46:20 --> Config Class Initialized
INFO - 2017-01-10 02:46:20 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:46:20 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:46:20 --> Utf8 Class Initialized
INFO - 2017-01-10 02:46:20 --> URI Class Initialized
INFO - 2017-01-10 02:46:20 --> Router Class Initialized
INFO - 2017-01-10 02:46:20 --> Output Class Initialized
INFO - 2017-01-10 02:46:20 --> Security Class Initialized
DEBUG - 2017-01-10 02:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:46:20 --> Input Class Initialized
INFO - 2017-01-10 02:46:20 --> Language Class Initialized
INFO - 2017-01-10 02:46:20 --> Loader Class Initialized
INFO - 2017-01-10 02:46:20 --> Database Driver Class Initialized
INFO - 2017-01-10 02:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:46:20 --> Controller Class Initialized
INFO - 2017-01-10 02:46:20 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:46:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:46:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:46:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:46:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:46:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:46:20 --> Final output sent to browser
DEBUG - 2017-01-10 02:46:20 --> Total execution time: 0.0133
INFO - 2017-01-10 02:46:28 --> Config Class Initialized
INFO - 2017-01-10 02:46:28 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:46:28 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:46:28 --> Utf8 Class Initialized
INFO - 2017-01-10 02:46:28 --> URI Class Initialized
INFO - 2017-01-10 02:46:28 --> Router Class Initialized
INFO - 2017-01-10 02:46:28 --> Output Class Initialized
INFO - 2017-01-10 02:46:28 --> Security Class Initialized
DEBUG - 2017-01-10 02:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:46:28 --> Input Class Initialized
INFO - 2017-01-10 02:46:28 --> Language Class Initialized
INFO - 2017-01-10 02:46:28 --> Loader Class Initialized
INFO - 2017-01-10 02:46:28 --> Database Driver Class Initialized
INFO - 2017-01-10 02:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:46:28 --> Controller Class Initialized
INFO - 2017-01-10 02:46:28 --> Upload Class Initialized
INFO - 2017-01-10 02:46:28 --> Helper loaded: date_helper
INFO - 2017-01-10 02:46:28 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:46:28 --> Helper loaded: form_helper
INFO - 2017-01-10 02:46:28 --> Form Validation Class Initialized
INFO - 2017-01-10 02:46:28 --> Final output sent to browser
DEBUG - 2017-01-10 02:46:28 --> Total execution time: 0.0155
INFO - 2017-01-10 02:46:46 --> Config Class Initialized
INFO - 2017-01-10 02:46:46 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:46:46 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:46:46 --> Utf8 Class Initialized
INFO - 2017-01-10 02:46:46 --> URI Class Initialized
INFO - 2017-01-10 02:46:46 --> Router Class Initialized
INFO - 2017-01-10 02:46:46 --> Output Class Initialized
INFO - 2017-01-10 02:46:46 --> Security Class Initialized
DEBUG - 2017-01-10 02:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:46:46 --> Input Class Initialized
INFO - 2017-01-10 02:46:46 --> Language Class Initialized
INFO - 2017-01-10 02:46:46 --> Loader Class Initialized
INFO - 2017-01-10 02:46:46 --> Database Driver Class Initialized
INFO - 2017-01-10 02:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:46:46 --> Controller Class Initialized
INFO - 2017-01-10 02:46:46 --> Helper loaded: date_helper
INFO - 2017-01-10 02:46:46 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:46:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:46:46 --> Helper loaded: form_helper
INFO - 2017-01-10 02:46:46 --> Form Validation Class Initialized
INFO - 2017-01-10 02:46:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:46:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 02:46:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-10 02:46:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-10 02:46:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:46:46 --> Final output sent to browser
DEBUG - 2017-01-10 02:46:46 --> Total execution time: 0.0150
INFO - 2017-01-10 02:46:46 --> Config Class Initialized
INFO - 2017-01-10 02:46:46 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:46:46 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:46:46 --> Utf8 Class Initialized
INFO - 2017-01-10 02:46:46 --> URI Class Initialized
INFO - 2017-01-10 02:46:46 --> Router Class Initialized
INFO - 2017-01-10 02:46:46 --> Output Class Initialized
INFO - 2017-01-10 02:46:46 --> Security Class Initialized
DEBUG - 2017-01-10 02:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:46:46 --> Input Class Initialized
INFO - 2017-01-10 02:46:46 --> Language Class Initialized
INFO - 2017-01-10 02:46:46 --> Loader Class Initialized
INFO - 2017-01-10 02:46:46 --> Database Driver Class Initialized
INFO - 2017-01-10 02:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:46:46 --> Controller Class Initialized
INFO - 2017-01-10 02:46:46 --> Helper loaded: date_helper
INFO - 2017-01-10 02:46:46 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:46:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:46:46 --> Helper loaded: form_helper
INFO - 2017-01-10 02:46:46 --> Form Validation Class Initialized
INFO - 2017-01-10 02:46:46 --> Final output sent to browser
DEBUG - 2017-01-10 02:46:46 --> Total execution time: 0.0139
INFO - 2017-01-10 02:46:46 --> Config Class Initialized
INFO - 2017-01-10 02:46:46 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:46:46 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:46:46 --> Utf8 Class Initialized
INFO - 2017-01-10 02:46:46 --> URI Class Initialized
INFO - 2017-01-10 02:46:46 --> Router Class Initialized
INFO - 2017-01-10 02:46:46 --> Output Class Initialized
INFO - 2017-01-10 02:46:46 --> Security Class Initialized
DEBUG - 2017-01-10 02:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:46:46 --> Input Class Initialized
INFO - 2017-01-10 02:46:46 --> Language Class Initialized
INFO - 2017-01-10 02:46:46 --> Loader Class Initialized
INFO - 2017-01-10 02:46:46 --> Database Driver Class Initialized
INFO - 2017-01-10 02:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:46:46 --> Controller Class Initialized
INFO - 2017-01-10 02:46:46 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:46:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:46:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:46:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:46:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:46:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:46:46 --> Final output sent to browser
DEBUG - 2017-01-10 02:46:46 --> Total execution time: 0.0141
INFO - 2017-01-10 02:46:51 --> Config Class Initialized
INFO - 2017-01-10 02:46:51 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:46:51 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:46:51 --> Utf8 Class Initialized
INFO - 2017-01-10 02:46:51 --> URI Class Initialized
INFO - 2017-01-10 02:46:51 --> Router Class Initialized
INFO - 2017-01-10 02:46:51 --> Output Class Initialized
INFO - 2017-01-10 02:46:51 --> Security Class Initialized
DEBUG - 2017-01-10 02:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:46:51 --> Input Class Initialized
INFO - 2017-01-10 02:46:51 --> Language Class Initialized
INFO - 2017-01-10 02:46:51 --> Loader Class Initialized
INFO - 2017-01-10 02:46:51 --> Database Driver Class Initialized
INFO - 2017-01-10 02:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:46:51 --> Controller Class Initialized
INFO - 2017-01-10 02:46:51 --> Helper loaded: date_helper
INFO - 2017-01-10 02:46:51 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:46:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:46:51 --> Helper loaded: form_helper
INFO - 2017-01-10 02:46:51 --> Form Validation Class Initialized
INFO - 2017-01-10 02:46:51 --> Final output sent to browser
DEBUG - 2017-01-10 02:46:51 --> Total execution time: 0.0149
INFO - 2017-01-10 02:46:55 --> Config Class Initialized
INFO - 2017-01-10 02:46:55 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:46:55 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:46:55 --> Utf8 Class Initialized
INFO - 2017-01-10 02:46:55 --> URI Class Initialized
INFO - 2017-01-10 02:46:55 --> Router Class Initialized
INFO - 2017-01-10 02:46:55 --> Output Class Initialized
INFO - 2017-01-10 02:46:55 --> Security Class Initialized
DEBUG - 2017-01-10 02:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:46:55 --> Input Class Initialized
INFO - 2017-01-10 02:46:55 --> Language Class Initialized
INFO - 2017-01-10 02:46:55 --> Loader Class Initialized
INFO - 2017-01-10 02:46:55 --> Database Driver Class Initialized
INFO - 2017-01-10 02:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:46:55 --> Controller Class Initialized
INFO - 2017-01-10 02:46:55 --> Helper loaded: date_helper
INFO - 2017-01-10 02:46:55 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:46:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:46:55 --> Helper loaded: form_helper
INFO - 2017-01-10 02:46:55 --> Form Validation Class Initialized
INFO - 2017-01-10 02:46:55 --> Final output sent to browser
DEBUG - 2017-01-10 02:46:55 --> Total execution time: 0.0148
INFO - 2017-01-10 02:46:57 --> Config Class Initialized
INFO - 2017-01-10 02:46:57 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:46:57 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:46:57 --> Utf8 Class Initialized
INFO - 2017-01-10 02:46:57 --> URI Class Initialized
INFO - 2017-01-10 02:46:57 --> Router Class Initialized
INFO - 2017-01-10 02:46:57 --> Output Class Initialized
INFO - 2017-01-10 02:46:57 --> Security Class Initialized
DEBUG - 2017-01-10 02:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:46:57 --> Input Class Initialized
INFO - 2017-01-10 02:46:57 --> Language Class Initialized
INFO - 2017-01-10 02:46:57 --> Loader Class Initialized
INFO - 2017-01-10 02:46:57 --> Database Driver Class Initialized
INFO - 2017-01-10 02:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:46:57 --> Controller Class Initialized
INFO - 2017-01-10 02:46:57 --> Helper loaded: date_helper
INFO - 2017-01-10 02:46:57 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:46:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:46:57 --> Helper loaded: form_helper
INFO - 2017-01-10 02:46:57 --> Form Validation Class Initialized
INFO - 2017-01-10 02:46:57 --> Final output sent to browser
DEBUG - 2017-01-10 02:46:57 --> Total execution time: 0.0145
INFO - 2017-01-10 02:47:04 --> Config Class Initialized
INFO - 2017-01-10 02:47:04 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:47:04 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:47:04 --> Utf8 Class Initialized
INFO - 2017-01-10 02:47:04 --> URI Class Initialized
INFO - 2017-01-10 02:47:04 --> Router Class Initialized
INFO - 2017-01-10 02:47:04 --> Output Class Initialized
INFO - 2017-01-10 02:47:04 --> Security Class Initialized
DEBUG - 2017-01-10 02:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:47:04 --> Input Class Initialized
INFO - 2017-01-10 02:47:04 --> Language Class Initialized
INFO - 2017-01-10 02:47:04 --> Loader Class Initialized
INFO - 2017-01-10 02:47:04 --> Database Driver Class Initialized
INFO - 2017-01-10 02:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:47:04 --> Controller Class Initialized
INFO - 2017-01-10 02:47:04 --> Helper loaded: date_helper
INFO - 2017-01-10 02:47:04 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:47:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:47:04 --> Helper loaded: form_helper
INFO - 2017-01-10 02:47:04 --> Form Validation Class Initialized
INFO - 2017-01-10 02:47:04 --> Final output sent to browser
DEBUG - 2017-01-10 02:47:04 --> Total execution time: 0.0149
INFO - 2017-01-10 02:47:13 --> Config Class Initialized
INFO - 2017-01-10 02:47:13 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:47:13 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:47:13 --> Utf8 Class Initialized
INFO - 2017-01-10 02:47:13 --> URI Class Initialized
INFO - 2017-01-10 02:47:13 --> Router Class Initialized
INFO - 2017-01-10 02:47:13 --> Output Class Initialized
INFO - 2017-01-10 02:47:13 --> Security Class Initialized
DEBUG - 2017-01-10 02:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:47:13 --> Input Class Initialized
INFO - 2017-01-10 02:47:13 --> Language Class Initialized
INFO - 2017-01-10 02:47:13 --> Loader Class Initialized
INFO - 2017-01-10 02:47:13 --> Database Driver Class Initialized
INFO - 2017-01-10 02:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:47:13 --> Controller Class Initialized
INFO - 2017-01-10 02:47:13 --> Helper loaded: date_helper
INFO - 2017-01-10 02:47:13 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:47:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:47:13 --> Helper loaded: form_helper
INFO - 2017-01-10 02:47:13 --> Form Validation Class Initialized
INFO - 2017-01-10 02:47:13 --> Final output sent to browser
DEBUG - 2017-01-10 02:47:13 --> Total execution time: 0.0141
INFO - 2017-01-10 02:47:21 --> Config Class Initialized
INFO - 2017-01-10 02:47:21 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:47:21 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:47:21 --> Utf8 Class Initialized
INFO - 2017-01-10 02:47:21 --> URI Class Initialized
INFO - 2017-01-10 02:47:21 --> Router Class Initialized
INFO - 2017-01-10 02:47:21 --> Output Class Initialized
INFO - 2017-01-10 02:47:21 --> Security Class Initialized
DEBUG - 2017-01-10 02:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:47:21 --> Input Class Initialized
INFO - 2017-01-10 02:47:21 --> Language Class Initialized
INFO - 2017-01-10 02:47:21 --> Loader Class Initialized
INFO - 2017-01-10 02:47:21 --> Database Driver Class Initialized
INFO - 2017-01-10 02:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:47:21 --> Controller Class Initialized
INFO - 2017-01-10 02:47:21 --> Helper loaded: date_helper
INFO - 2017-01-10 02:47:21 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:47:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:47:21 --> Helper loaded: form_helper
INFO - 2017-01-10 02:47:21 --> Form Validation Class Initialized
INFO - 2017-01-10 02:47:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 02:47:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 02:47:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pagos.php
INFO - 2017-01-10 02:47:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pagos.php
INFO - 2017-01-10 02:47:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 02:47:21 --> Final output sent to browser
DEBUG - 2017-01-10 02:47:21 --> Total execution time: 0.1186
INFO - 2017-01-10 02:47:21 --> Config Class Initialized
INFO - 2017-01-10 02:47:21 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:47:21 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:47:21 --> Utf8 Class Initialized
INFO - 2017-01-10 02:47:21 --> URI Class Initialized
INFO - 2017-01-10 02:47:21 --> Router Class Initialized
INFO - 2017-01-10 02:47:21 --> Output Class Initialized
INFO - 2017-01-10 02:47:21 --> Security Class Initialized
DEBUG - 2017-01-10 02:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:47:21 --> Input Class Initialized
INFO - 2017-01-10 02:47:21 --> Language Class Initialized
INFO - 2017-01-10 02:47:21 --> Loader Class Initialized
INFO - 2017-01-10 02:47:21 --> Database Driver Class Initialized
INFO - 2017-01-10 02:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:47:21 --> Controller Class Initialized
INFO - 2017-01-10 02:47:21 --> Helper loaded: date_helper
INFO - 2017-01-10 02:47:21 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:47:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:47:21 --> Helper loaded: form_helper
INFO - 2017-01-10 02:47:21 --> Form Validation Class Initialized
INFO - 2017-01-10 02:47:21 --> Final output sent to browser
DEBUG - 2017-01-10 02:47:21 --> Total execution time: 0.0144
INFO - 2017-01-10 02:47:21 --> Config Class Initialized
INFO - 2017-01-10 02:47:21 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:47:21 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:47:21 --> Utf8 Class Initialized
INFO - 2017-01-10 02:47:21 --> URI Class Initialized
INFO - 2017-01-10 02:47:21 --> Router Class Initialized
INFO - 2017-01-10 02:47:21 --> Output Class Initialized
INFO - 2017-01-10 02:47:21 --> Security Class Initialized
DEBUG - 2017-01-10 02:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:47:21 --> Input Class Initialized
INFO - 2017-01-10 02:47:21 --> Language Class Initialized
INFO - 2017-01-10 02:47:21 --> Loader Class Initialized
INFO - 2017-01-10 02:47:21 --> Database Driver Class Initialized
INFO - 2017-01-10 02:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:47:21 --> Controller Class Initialized
INFO - 2017-01-10 02:47:21 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:47:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:47:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:47:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:47:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:47:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:47:21 --> Final output sent to browser
DEBUG - 2017-01-10 02:47:21 --> Total execution time: 0.1481
INFO - 2017-01-10 02:47:27 --> Config Class Initialized
INFO - 2017-01-10 02:47:27 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:47:27 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:47:27 --> Utf8 Class Initialized
INFO - 2017-01-10 02:47:27 --> URI Class Initialized
INFO - 2017-01-10 02:47:27 --> Router Class Initialized
INFO - 2017-01-10 02:47:27 --> Output Class Initialized
INFO - 2017-01-10 02:47:27 --> Security Class Initialized
DEBUG - 2017-01-10 02:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:47:27 --> Input Class Initialized
INFO - 2017-01-10 02:47:27 --> Language Class Initialized
INFO - 2017-01-10 02:47:27 --> Loader Class Initialized
INFO - 2017-01-10 02:47:27 --> Database Driver Class Initialized
INFO - 2017-01-10 02:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:47:27 --> Controller Class Initialized
INFO - 2017-01-10 02:47:27 --> Helper loaded: date_helper
INFO - 2017-01-10 02:47:27 --> Config Class Initialized
INFO - 2017-01-10 02:47:27 --> Hooks Class Initialized
INFO - 2017-01-10 02:47:27 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:47:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-01-10 02:47:27 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:47:27 --> Utf8 Class Initialized
INFO - 2017-01-10 02:47:27 --> URI Class Initialized
INFO - 2017-01-10 02:47:27 --> Helper loaded: form_helper
INFO - 2017-01-10 02:47:27 --> Form Validation Class Initialized
INFO - 2017-01-10 02:47:27 --> Router Class Initialized
INFO - 2017-01-10 02:47:27 --> Output Class Initialized
INFO - 2017-01-10 02:47:27 --> Final output sent to browser
DEBUG - 2017-01-10 02:47:27 --> Total execution time: 0.0149
INFO - 2017-01-10 02:47:27 --> Security Class Initialized
DEBUG - 2017-01-10 02:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:47:27 --> Input Class Initialized
INFO - 2017-01-10 02:47:27 --> Language Class Initialized
INFO - 2017-01-10 02:47:27 --> Loader Class Initialized
INFO - 2017-01-10 02:47:27 --> Database Driver Class Initialized
INFO - 2017-01-10 02:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:47:27 --> Controller Class Initialized
INFO - 2017-01-10 02:47:27 --> Helper loaded: date_helper
INFO - 2017-01-10 02:47:27 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:47:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:47:27 --> Helper loaded: form_helper
INFO - 2017-01-10 02:47:27 --> Form Validation Class Initialized
INFO - 2017-01-10 02:47:27 --> Final output sent to browser
DEBUG - 2017-01-10 02:47:27 --> Total execution time: 0.0153
INFO - 2017-01-10 02:48:02 --> Config Class Initialized
INFO - 2017-01-10 02:48:02 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:48:02 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:48:02 --> Utf8 Class Initialized
INFO - 2017-01-10 02:48:02 --> URI Class Initialized
DEBUG - 2017-01-10 02:48:02 --> No URI present. Default controller set.
INFO - 2017-01-10 02:48:02 --> Router Class Initialized
INFO - 2017-01-10 02:48:02 --> Output Class Initialized
INFO - 2017-01-10 02:48:02 --> Security Class Initialized
DEBUG - 2017-01-10 02:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:48:02 --> Input Class Initialized
INFO - 2017-01-10 02:48:02 --> Language Class Initialized
INFO - 2017-01-10 02:48:02 --> Loader Class Initialized
INFO - 2017-01-10 02:48:02 --> Database Driver Class Initialized
INFO - 2017-01-10 02:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:48:02 --> Controller Class Initialized
INFO - 2017-01-10 02:48:02 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:48:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:48:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:48:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:48:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:48:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:48:03 --> Final output sent to browser
DEBUG - 2017-01-10 02:48:03 --> Total execution time: 0.3854
INFO - 2017-01-10 02:48:13 --> Config Class Initialized
INFO - 2017-01-10 02:48:13 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:48:13 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:48:13 --> Utf8 Class Initialized
INFO - 2017-01-10 02:48:13 --> URI Class Initialized
INFO - 2017-01-10 02:48:13 --> Router Class Initialized
INFO - 2017-01-10 02:48:13 --> Output Class Initialized
INFO - 2017-01-10 02:48:13 --> Security Class Initialized
DEBUG - 2017-01-10 02:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:48:13 --> Input Class Initialized
INFO - 2017-01-10 02:48:13 --> Language Class Initialized
INFO - 2017-01-10 02:48:13 --> Loader Class Initialized
INFO - 2017-01-10 02:48:13 --> Database Driver Class Initialized
INFO - 2017-01-10 02:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:48:13 --> Controller Class Initialized
INFO - 2017-01-10 02:48:13 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:48:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:48:16 --> Config Class Initialized
INFO - 2017-01-10 02:48:16 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:48:16 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:48:16 --> Utf8 Class Initialized
INFO - 2017-01-10 02:48:16 --> URI Class Initialized
INFO - 2017-01-10 02:48:16 --> Router Class Initialized
INFO - 2017-01-10 02:48:16 --> Output Class Initialized
INFO - 2017-01-10 02:48:16 --> Security Class Initialized
DEBUG - 2017-01-10 02:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:48:16 --> Input Class Initialized
INFO - 2017-01-10 02:48:16 --> Language Class Initialized
INFO - 2017-01-10 02:48:16 --> Loader Class Initialized
INFO - 2017-01-10 02:48:16 --> Database Driver Class Initialized
INFO - 2017-01-10 02:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:48:16 --> Controller Class Initialized
INFO - 2017-01-10 02:48:16 --> Helper loaded: date_helper
DEBUG - 2017-01-10 02:48:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:48:16 --> Helper loaded: url_helper
INFO - 2017-01-10 02:48:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:48:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-10 02:48:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-10 02:48:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-10 02:48:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:48:16 --> Final output sent to browser
DEBUG - 2017-01-10 02:48:16 --> Total execution time: 0.0666
INFO - 2017-01-10 02:48:18 --> Config Class Initialized
INFO - 2017-01-10 02:48:18 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:48:18 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:48:18 --> Utf8 Class Initialized
INFO - 2017-01-10 02:48:18 --> URI Class Initialized
INFO - 2017-01-10 02:48:18 --> Router Class Initialized
INFO - 2017-01-10 02:48:18 --> Output Class Initialized
INFO - 2017-01-10 02:48:18 --> Security Class Initialized
DEBUG - 2017-01-10 02:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:48:18 --> Input Class Initialized
INFO - 2017-01-10 02:48:18 --> Language Class Initialized
INFO - 2017-01-10 02:48:18 --> Loader Class Initialized
INFO - 2017-01-10 02:48:18 --> Database Driver Class Initialized
INFO - 2017-01-10 02:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:48:18 --> Controller Class Initialized
INFO - 2017-01-10 02:48:18 --> Helper loaded: date_helper
INFO - 2017-01-10 02:48:18 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:48:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:48:18 --> Helper loaded: form_helper
INFO - 2017-01-10 02:48:18 --> Form Validation Class Initialized
INFO - 2017-01-10 02:48:18 --> Final output sent to browser
DEBUG - 2017-01-10 02:48:18 --> Total execution time: 0.1040
INFO - 2017-01-10 02:48:20 --> Config Class Initialized
INFO - 2017-01-10 02:48:20 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:48:20 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:48:20 --> Utf8 Class Initialized
INFO - 2017-01-10 02:48:20 --> URI Class Initialized
INFO - 2017-01-10 02:48:20 --> Router Class Initialized
INFO - 2017-01-10 02:48:20 --> Output Class Initialized
INFO - 2017-01-10 02:48:20 --> Security Class Initialized
DEBUG - 2017-01-10 02:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:48:20 --> Input Class Initialized
INFO - 2017-01-10 02:48:20 --> Language Class Initialized
INFO - 2017-01-10 02:48:20 --> Loader Class Initialized
INFO - 2017-01-10 02:48:20 --> Database Driver Class Initialized
INFO - 2017-01-10 02:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:48:20 --> Controller Class Initialized
INFO - 2017-01-10 02:48:20 --> Helper loaded: date_helper
INFO - 2017-01-10 02:48:20 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:48:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:48:20 --> Helper loaded: form_helper
INFO - 2017-01-10 02:48:20 --> Form Validation Class Initialized
INFO - 2017-01-10 02:48:20 --> Final output sent to browser
DEBUG - 2017-01-10 02:48:20 --> Total execution time: 0.0161
INFO - 2017-01-10 02:48:24 --> Config Class Initialized
INFO - 2017-01-10 02:48:24 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:48:24 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:48:24 --> Utf8 Class Initialized
INFO - 2017-01-10 02:48:24 --> URI Class Initialized
INFO - 2017-01-10 02:48:24 --> Router Class Initialized
INFO - 2017-01-10 02:48:24 --> Output Class Initialized
INFO - 2017-01-10 02:48:24 --> Security Class Initialized
DEBUG - 2017-01-10 02:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:48:24 --> Input Class Initialized
INFO - 2017-01-10 02:48:24 --> Language Class Initialized
INFO - 2017-01-10 02:48:24 --> Loader Class Initialized
INFO - 2017-01-10 02:48:24 --> Database Driver Class Initialized
INFO - 2017-01-10 02:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:48:24 --> Controller Class Initialized
INFO - 2017-01-10 02:48:24 --> Helper loaded: date_helper
INFO - 2017-01-10 02:48:24 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:48:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:48:24 --> Helper loaded: form_helper
INFO - 2017-01-10 02:48:24 --> Form Validation Class Initialized
INFO - 2017-01-10 02:48:24 --> Final output sent to browser
DEBUG - 2017-01-10 02:48:24 --> Total execution time: 0.0148
INFO - 2017-01-10 02:48:28 --> Config Class Initialized
INFO - 2017-01-10 02:48:28 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:48:28 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:48:28 --> Utf8 Class Initialized
INFO - 2017-01-10 02:48:28 --> URI Class Initialized
INFO - 2017-01-10 02:48:28 --> Router Class Initialized
INFO - 2017-01-10 02:48:28 --> Output Class Initialized
INFO - 2017-01-10 02:48:28 --> Security Class Initialized
DEBUG - 2017-01-10 02:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:48:28 --> Input Class Initialized
INFO - 2017-01-10 02:48:28 --> Language Class Initialized
INFO - 2017-01-10 02:48:28 --> Loader Class Initialized
INFO - 2017-01-10 02:48:28 --> Database Driver Class Initialized
INFO - 2017-01-10 02:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:48:28 --> Controller Class Initialized
INFO - 2017-01-10 02:48:28 --> Helper loaded: date_helper
INFO - 2017-01-10 02:48:28 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:48:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:48:28 --> Helper loaded: form_helper
INFO - 2017-01-10 02:48:28 --> Form Validation Class Initialized
INFO - 2017-01-10 02:48:28 --> Final output sent to browser
DEBUG - 2017-01-10 02:48:28 --> Total execution time: 0.0149
INFO - 2017-01-10 02:50:31 --> Config Class Initialized
INFO - 2017-01-10 02:50:31 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:50:31 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:50:31 --> Utf8 Class Initialized
INFO - 2017-01-10 02:50:31 --> URI Class Initialized
DEBUG - 2017-01-10 02:50:31 --> No URI present. Default controller set.
INFO - 2017-01-10 02:50:31 --> Router Class Initialized
INFO - 2017-01-10 02:50:31 --> Output Class Initialized
INFO - 2017-01-10 02:50:31 --> Security Class Initialized
DEBUG - 2017-01-10 02:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:50:31 --> Input Class Initialized
INFO - 2017-01-10 02:50:31 --> Language Class Initialized
INFO - 2017-01-10 02:50:31 --> Loader Class Initialized
INFO - 2017-01-10 02:50:31 --> Database Driver Class Initialized
INFO - 2017-01-10 02:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:50:31 --> Controller Class Initialized
INFO - 2017-01-10 02:50:31 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:50:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:50:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:50:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:50:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:50:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:50:31 --> Final output sent to browser
DEBUG - 2017-01-10 02:50:31 --> Total execution time: 0.2557
INFO - 2017-01-10 02:50:34 --> Config Class Initialized
INFO - 2017-01-10 02:50:34 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:50:34 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:50:34 --> Utf8 Class Initialized
INFO - 2017-01-10 02:50:34 --> URI Class Initialized
INFO - 2017-01-10 02:50:34 --> Router Class Initialized
INFO - 2017-01-10 02:50:34 --> Output Class Initialized
INFO - 2017-01-10 02:50:34 --> Security Class Initialized
DEBUG - 2017-01-10 02:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:50:34 --> Input Class Initialized
INFO - 2017-01-10 02:50:34 --> Language Class Initialized
INFO - 2017-01-10 02:50:34 --> Loader Class Initialized
INFO - 2017-01-10 02:50:34 --> Database Driver Class Initialized
INFO - 2017-01-10 02:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:50:34 --> Controller Class Initialized
INFO - 2017-01-10 02:50:34 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:50:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:50:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:50:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:50:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:50:34 --> Final output sent to browser
DEBUG - 2017-01-10 02:50:34 --> Total execution time: 0.0140
INFO - 2017-01-10 02:52:34 --> Config Class Initialized
INFO - 2017-01-10 02:52:34 --> Hooks Class Initialized
DEBUG - 2017-01-10 02:52:34 --> UTF-8 Support Enabled
INFO - 2017-01-10 02:52:34 --> Utf8 Class Initialized
INFO - 2017-01-10 02:52:34 --> URI Class Initialized
DEBUG - 2017-01-10 02:52:34 --> No URI present. Default controller set.
INFO - 2017-01-10 02:52:34 --> Router Class Initialized
INFO - 2017-01-10 02:52:34 --> Output Class Initialized
INFO - 2017-01-10 02:52:34 --> Security Class Initialized
DEBUG - 2017-01-10 02:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 02:52:34 --> Input Class Initialized
INFO - 2017-01-10 02:52:34 --> Language Class Initialized
INFO - 2017-01-10 02:52:34 --> Loader Class Initialized
INFO - 2017-01-10 02:52:34 --> Database Driver Class Initialized
INFO - 2017-01-10 02:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 02:52:34 --> Controller Class Initialized
INFO - 2017-01-10 02:52:34 --> Helper loaded: url_helper
DEBUG - 2017-01-10 02:52:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 02:52:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 02:52:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 02:52:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 02:52:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 02:52:34 --> Final output sent to browser
DEBUG - 2017-01-10 02:52:34 --> Total execution time: 0.2700
INFO - 2017-01-10 03:34:58 --> Config Class Initialized
INFO - 2017-01-10 03:34:58 --> Hooks Class Initialized
DEBUG - 2017-01-10 03:34:58 --> UTF-8 Support Enabled
INFO - 2017-01-10 03:34:58 --> Utf8 Class Initialized
INFO - 2017-01-10 03:34:58 --> URI Class Initialized
INFO - 2017-01-10 03:34:58 --> Router Class Initialized
INFO - 2017-01-10 03:34:58 --> Output Class Initialized
INFO - 2017-01-10 03:34:58 --> Security Class Initialized
DEBUG - 2017-01-10 03:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 03:34:58 --> Input Class Initialized
INFO - 2017-01-10 03:34:58 --> Language Class Initialized
INFO - 2017-01-10 03:34:58 --> Loader Class Initialized
INFO - 2017-01-10 03:34:58 --> Database Driver Class Initialized
INFO - 2017-01-10 03:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 03:34:59 --> Controller Class Initialized
INFO - 2017-01-10 03:34:59 --> Upload Class Initialized
INFO - 2017-01-10 03:34:59 --> Helper loaded: date_helper
INFO - 2017-01-10 03:34:59 --> Helper loaded: url_helper
DEBUG - 2017-01-10 03:34:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 03:34:59 --> Helper loaded: form_helper
INFO - 2017-01-10 03:34:59 --> Form Validation Class Initialized
INFO - 2017-01-10 03:34:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-10 03:34:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-10 03:34:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-10 03:34:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-10 03:34:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-10 03:34:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-10 03:34:59 --> Final output sent to browser
DEBUG - 2017-01-10 03:34:59 --> Total execution time: 1.0212
INFO - 2017-01-10 03:35:00 --> Config Class Initialized
INFO - 2017-01-10 03:35:00 --> Hooks Class Initialized
DEBUG - 2017-01-10 03:35:00 --> UTF-8 Support Enabled
INFO - 2017-01-10 03:35:00 --> Utf8 Class Initialized
INFO - 2017-01-10 03:35:00 --> URI Class Initialized
INFO - 2017-01-10 03:35:00 --> Router Class Initialized
INFO - 2017-01-10 03:35:00 --> Output Class Initialized
INFO - 2017-01-10 03:35:00 --> Security Class Initialized
DEBUG - 2017-01-10 03:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 03:35:00 --> Input Class Initialized
INFO - 2017-01-10 03:35:00 --> Language Class Initialized
INFO - 2017-01-10 03:35:00 --> Loader Class Initialized
INFO - 2017-01-10 03:35:00 --> Database Driver Class Initialized
INFO - 2017-01-10 03:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 03:35:00 --> Controller Class Initialized
INFO - 2017-01-10 03:35:00 --> Helper loaded: url_helper
DEBUG - 2017-01-10 03:35:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 03:35:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 03:35:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 03:35:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 03:35:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 03:35:00 --> Final output sent to browser
DEBUG - 2017-01-10 03:35:00 --> Total execution time: 0.2680
INFO - 2017-01-10 03:37:29 --> Config Class Initialized
INFO - 2017-01-10 03:37:29 --> Hooks Class Initialized
DEBUG - 2017-01-10 03:37:29 --> UTF-8 Support Enabled
INFO - 2017-01-10 03:37:29 --> Utf8 Class Initialized
INFO - 2017-01-10 03:37:29 --> URI Class Initialized
DEBUG - 2017-01-10 03:37:29 --> No URI present. Default controller set.
INFO - 2017-01-10 03:37:29 --> Router Class Initialized
INFO - 2017-01-10 03:37:29 --> Output Class Initialized
INFO - 2017-01-10 03:37:29 --> Security Class Initialized
DEBUG - 2017-01-10 03:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 03:37:29 --> Input Class Initialized
INFO - 2017-01-10 03:37:29 --> Language Class Initialized
INFO - 2017-01-10 03:37:29 --> Loader Class Initialized
INFO - 2017-01-10 03:37:29 --> Database Driver Class Initialized
INFO - 2017-01-10 03:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 03:37:29 --> Controller Class Initialized
INFO - 2017-01-10 03:37:29 --> Helper loaded: url_helper
DEBUG - 2017-01-10 03:37:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 03:37:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 03:37:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 03:37:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 03:37:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 03:37:29 --> Final output sent to browser
DEBUG - 2017-01-10 03:37:29 --> Total execution time: 0.0440
INFO - 2017-01-10 03:37:57 --> Config Class Initialized
INFO - 2017-01-10 03:37:57 --> Hooks Class Initialized
DEBUG - 2017-01-10 03:37:57 --> UTF-8 Support Enabled
INFO - 2017-01-10 03:37:57 --> Utf8 Class Initialized
INFO - 2017-01-10 03:37:57 --> URI Class Initialized
INFO - 2017-01-10 03:37:57 --> Router Class Initialized
INFO - 2017-01-10 03:37:57 --> Output Class Initialized
INFO - 2017-01-10 03:37:57 --> Security Class Initialized
DEBUG - 2017-01-10 03:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 03:37:57 --> Input Class Initialized
INFO - 2017-01-10 03:37:57 --> Language Class Initialized
INFO - 2017-01-10 03:37:57 --> Loader Class Initialized
INFO - 2017-01-10 03:37:57 --> Database Driver Class Initialized
INFO - 2017-01-10 03:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 03:37:57 --> Controller Class Initialized
INFO - 2017-01-10 03:37:57 --> Helper loaded: url_helper
DEBUG - 2017-01-10 03:37:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 03:37:59 --> Config Class Initialized
INFO - 2017-01-10 03:37:59 --> Hooks Class Initialized
DEBUG - 2017-01-10 03:37:59 --> UTF-8 Support Enabled
INFO - 2017-01-10 03:37:59 --> Utf8 Class Initialized
INFO - 2017-01-10 03:37:59 --> URI Class Initialized
INFO - 2017-01-10 03:37:59 --> Router Class Initialized
INFO - 2017-01-10 03:37:59 --> Output Class Initialized
INFO - 2017-01-10 03:37:59 --> Security Class Initialized
DEBUG - 2017-01-10 03:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 03:37:59 --> Input Class Initialized
INFO - 2017-01-10 03:37:59 --> Language Class Initialized
INFO - 2017-01-10 03:37:59 --> Loader Class Initialized
INFO - 2017-01-10 03:37:59 --> Database Driver Class Initialized
INFO - 2017-01-10 03:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 03:37:59 --> Controller Class Initialized
INFO - 2017-01-10 03:37:59 --> Helper loaded: date_helper
DEBUG - 2017-01-10 03:37:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 03:37:59 --> Helper loaded: url_helper
INFO - 2017-01-10 03:37:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 03:37:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 03:37:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-10 03:37:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-10 03:37:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 03:37:59 --> Final output sent to browser
DEBUG - 2017-01-10 03:37:59 --> Total execution time: 0.0458
INFO - 2017-01-10 03:38:25 --> Config Class Initialized
INFO - 2017-01-10 03:38:25 --> Hooks Class Initialized
DEBUG - 2017-01-10 03:38:25 --> UTF-8 Support Enabled
INFO - 2017-01-10 03:38:25 --> Utf8 Class Initialized
INFO - 2017-01-10 03:38:25 --> URI Class Initialized
INFO - 2017-01-10 03:38:25 --> Router Class Initialized
INFO - 2017-01-10 03:38:25 --> Output Class Initialized
INFO - 2017-01-10 03:38:25 --> Security Class Initialized
DEBUG - 2017-01-10 03:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 03:38:25 --> Input Class Initialized
INFO - 2017-01-10 03:38:25 --> Language Class Initialized
INFO - 2017-01-10 03:38:26 --> Loader Class Initialized
INFO - 2017-01-10 03:38:26 --> Database Driver Class Initialized
INFO - 2017-01-10 03:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 03:38:26 --> Controller Class Initialized
INFO - 2017-01-10 03:38:26 --> Helper loaded: date_helper
DEBUG - 2017-01-10 03:38:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 03:38:26 --> Helper loaded: url_helper
INFO - 2017-01-10 03:38:26 --> Helper loaded: download_helper
INFO - 2017-01-10 03:38:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 03:38:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-10 03:38:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-10 03:38:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-10 03:38:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 03:38:26 --> Final output sent to browser
DEBUG - 2017-01-10 03:38:26 --> Total execution time: 0.0830
INFO - 2017-01-10 03:38:43 --> Config Class Initialized
INFO - 2017-01-10 03:38:43 --> Hooks Class Initialized
DEBUG - 2017-01-10 03:38:43 --> UTF-8 Support Enabled
INFO - 2017-01-10 03:38:43 --> Utf8 Class Initialized
INFO - 2017-01-10 03:38:43 --> URI Class Initialized
INFO - 2017-01-10 03:38:43 --> Router Class Initialized
INFO - 2017-01-10 03:38:43 --> Output Class Initialized
INFO - 2017-01-10 03:38:43 --> Security Class Initialized
DEBUG - 2017-01-10 03:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 03:38:43 --> Input Class Initialized
INFO - 2017-01-10 03:38:43 --> Language Class Initialized
INFO - 2017-01-10 03:38:43 --> Loader Class Initialized
INFO - 2017-01-10 03:38:43 --> Database Driver Class Initialized
INFO - 2017-01-10 03:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 03:38:44 --> Controller Class Initialized
INFO - 2017-01-10 03:38:44 --> Helper loaded: date_helper
INFO - 2017-01-10 03:38:44 --> Helper loaded: url_helper
DEBUG - 2017-01-10 03:38:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 03:38:44 --> Helper loaded: form_helper
INFO - 2017-01-10 03:38:44 --> Form Validation Class Initialized
INFO - 2017-01-10 03:38:44 --> Final output sent to browser
DEBUG - 2017-01-10 03:38:44 --> Total execution time: 0.5048
INFO - 2017-01-10 03:38:50 --> Config Class Initialized
INFO - 2017-01-10 03:38:50 --> Hooks Class Initialized
DEBUG - 2017-01-10 03:38:50 --> UTF-8 Support Enabled
INFO - 2017-01-10 03:38:50 --> Utf8 Class Initialized
INFO - 2017-01-10 03:38:50 --> URI Class Initialized
INFO - 2017-01-10 03:38:50 --> Router Class Initialized
INFO - 2017-01-10 03:38:50 --> Output Class Initialized
INFO - 2017-01-10 03:38:50 --> Security Class Initialized
DEBUG - 2017-01-10 03:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 03:38:50 --> Input Class Initialized
INFO - 2017-01-10 03:38:50 --> Language Class Initialized
INFO - 2017-01-10 03:38:50 --> Loader Class Initialized
INFO - 2017-01-10 03:38:50 --> Database Driver Class Initialized
INFO - 2017-01-10 03:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 03:38:50 --> Controller Class Initialized
INFO - 2017-01-10 03:38:50 --> Helper loaded: date_helper
INFO - 2017-01-10 03:38:50 --> Helper loaded: url_helper
DEBUG - 2017-01-10 03:38:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 03:38:50 --> Helper loaded: form_helper
INFO - 2017-01-10 03:38:50 --> Form Validation Class Initialized
INFO - 2017-01-10 03:38:50 --> Final output sent to browser
DEBUG - 2017-01-10 03:38:50 --> Total execution time: 0.0143
INFO - 2017-01-10 03:53:15 --> Config Class Initialized
INFO - 2017-01-10 03:53:16 --> Hooks Class Initialized
DEBUG - 2017-01-10 03:53:16 --> UTF-8 Support Enabled
INFO - 2017-01-10 03:53:16 --> Utf8 Class Initialized
INFO - 2017-01-10 03:53:16 --> URI Class Initialized
INFO - 2017-01-10 03:53:16 --> Router Class Initialized
INFO - 2017-01-10 03:53:16 --> Output Class Initialized
INFO - 2017-01-10 03:53:16 --> Security Class Initialized
DEBUG - 2017-01-10 03:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 03:53:16 --> Input Class Initialized
INFO - 2017-01-10 03:53:16 --> Language Class Initialized
INFO - 2017-01-10 03:53:16 --> Loader Class Initialized
INFO - 2017-01-10 03:53:16 --> Database Driver Class Initialized
INFO - 2017-01-10 03:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 03:53:16 --> Controller Class Initialized
INFO - 2017-01-10 03:53:16 --> Helper loaded: date_helper
DEBUG - 2017-01-10 03:53:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 03:53:16 --> Helper loaded: url_helper
INFO - 2017-01-10 03:53:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 03:53:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-10 03:53:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-10 03:53:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-10 03:53:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 03:53:16 --> Final output sent to browser
DEBUG - 2017-01-10 03:53:16 --> Total execution time: 0.4339
INFO - 2017-01-10 03:53:17 --> Config Class Initialized
INFO - 2017-01-10 03:53:17 --> Hooks Class Initialized
DEBUG - 2017-01-10 03:53:17 --> UTF-8 Support Enabled
INFO - 2017-01-10 03:53:17 --> Utf8 Class Initialized
INFO - 2017-01-10 03:53:17 --> URI Class Initialized
DEBUG - 2017-01-10 03:53:17 --> No URI present. Default controller set.
INFO - 2017-01-10 03:53:17 --> Router Class Initialized
INFO - 2017-01-10 03:53:17 --> Output Class Initialized
INFO - 2017-01-10 03:53:17 --> Security Class Initialized
DEBUG - 2017-01-10 03:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 03:53:17 --> Input Class Initialized
INFO - 2017-01-10 03:53:17 --> Language Class Initialized
INFO - 2017-01-10 03:53:17 --> Loader Class Initialized
INFO - 2017-01-10 03:53:17 --> Database Driver Class Initialized
INFO - 2017-01-10 03:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 03:53:17 --> Controller Class Initialized
INFO - 2017-01-10 03:53:17 --> Helper loaded: url_helper
DEBUG - 2017-01-10 03:53:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 03:53:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 03:53:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 03:53:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 03:53:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 03:53:17 --> Final output sent to browser
DEBUG - 2017-01-10 03:53:17 --> Total execution time: 0.2432
INFO - 2017-01-10 11:38:06 --> Config Class Initialized
INFO - 2017-01-10 11:38:06 --> Hooks Class Initialized
DEBUG - 2017-01-10 11:38:06 --> UTF-8 Support Enabled
INFO - 2017-01-10 11:38:06 --> Utf8 Class Initialized
INFO - 2017-01-10 11:38:06 --> URI Class Initialized
INFO - 2017-01-10 11:38:06 --> Router Class Initialized
INFO - 2017-01-10 11:38:06 --> Output Class Initialized
INFO - 2017-01-10 11:38:06 --> Security Class Initialized
DEBUG - 2017-01-10 11:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 11:38:06 --> Input Class Initialized
INFO - 2017-01-10 11:38:06 --> Language Class Initialized
INFO - 2017-01-10 11:38:06 --> Loader Class Initialized
INFO - 2017-01-10 11:38:06 --> Database Driver Class Initialized
INFO - 2017-01-10 11:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 11:38:07 --> Controller Class Initialized
INFO - 2017-01-10 11:38:07 --> Helper loaded: url_helper
DEBUG - 2017-01-10 11:38:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 11:38:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 11:38:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 11:38:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 11:38:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 11:38:07 --> Final output sent to browser
DEBUG - 2017-01-10 11:38:07 --> Total execution time: 1.3443
INFO - 2017-01-10 11:38:07 --> Config Class Initialized
INFO - 2017-01-10 11:38:07 --> Hooks Class Initialized
DEBUG - 2017-01-10 11:38:07 --> UTF-8 Support Enabled
INFO - 2017-01-10 11:38:07 --> Utf8 Class Initialized
INFO - 2017-01-10 11:38:07 --> URI Class Initialized
DEBUG - 2017-01-10 11:38:07 --> No URI present. Default controller set.
INFO - 2017-01-10 11:38:07 --> Router Class Initialized
INFO - 2017-01-10 11:38:07 --> Output Class Initialized
INFO - 2017-01-10 11:38:07 --> Security Class Initialized
DEBUG - 2017-01-10 11:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 11:38:07 --> Input Class Initialized
INFO - 2017-01-10 11:38:07 --> Language Class Initialized
INFO - 2017-01-10 11:38:07 --> Loader Class Initialized
INFO - 2017-01-10 11:38:07 --> Database Driver Class Initialized
INFO - 2017-01-10 11:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 11:38:07 --> Controller Class Initialized
INFO - 2017-01-10 11:38:07 --> Helper loaded: url_helper
DEBUG - 2017-01-10 11:38:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 11:38:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 11:38:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 11:38:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 11:38:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 11:38:07 --> Final output sent to browser
DEBUG - 2017-01-10 11:38:07 --> Total execution time: 0.0130
INFO - 2017-01-10 11:38:10 --> Config Class Initialized
INFO - 2017-01-10 11:38:10 --> Hooks Class Initialized
DEBUG - 2017-01-10 11:38:10 --> UTF-8 Support Enabled
INFO - 2017-01-10 11:38:10 --> Utf8 Class Initialized
INFO - 2017-01-10 11:38:10 --> URI Class Initialized
INFO - 2017-01-10 11:38:10 --> Router Class Initialized
INFO - 2017-01-10 11:38:10 --> Output Class Initialized
INFO - 2017-01-10 11:38:10 --> Security Class Initialized
DEBUG - 2017-01-10 11:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 11:38:10 --> Input Class Initialized
INFO - 2017-01-10 11:38:10 --> Language Class Initialized
INFO - 2017-01-10 11:38:10 --> Loader Class Initialized
INFO - 2017-01-10 11:38:10 --> Database Driver Class Initialized
INFO - 2017-01-10 11:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 11:38:10 --> Controller Class Initialized
INFO - 2017-01-10 11:38:10 --> Helper loaded: url_helper
DEBUG - 2017-01-10 11:38:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 11:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 11:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 11:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 11:38:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 11:38:10 --> Final output sent to browser
DEBUG - 2017-01-10 11:38:10 --> Total execution time: 0.0131
INFO - 2017-01-10 13:06:20 --> Config Class Initialized
INFO - 2017-01-10 13:06:20 --> Hooks Class Initialized
DEBUG - 2017-01-10 13:06:20 --> UTF-8 Support Enabled
INFO - 2017-01-10 13:06:20 --> Utf8 Class Initialized
INFO - 2017-01-10 13:06:20 --> URI Class Initialized
DEBUG - 2017-01-10 13:06:20 --> No URI present. Default controller set.
INFO - 2017-01-10 13:06:20 --> Router Class Initialized
INFO - 2017-01-10 13:06:20 --> Output Class Initialized
INFO - 2017-01-10 13:06:20 --> Security Class Initialized
DEBUG - 2017-01-10 13:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 13:06:20 --> Input Class Initialized
INFO - 2017-01-10 13:06:20 --> Language Class Initialized
INFO - 2017-01-10 13:06:20 --> Loader Class Initialized
INFO - 2017-01-10 13:06:21 --> Database Driver Class Initialized
INFO - 2017-01-10 13:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 13:06:21 --> Controller Class Initialized
INFO - 2017-01-10 13:06:21 --> Helper loaded: url_helper
DEBUG - 2017-01-10 13:06:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 13:06:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 13:06:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 13:06:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 13:06:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 13:06:21 --> Final output sent to browser
DEBUG - 2017-01-10 13:06:21 --> Total execution time: 1.1992
INFO - 2017-01-10 13:06:22 --> Config Class Initialized
INFO - 2017-01-10 13:06:22 --> Hooks Class Initialized
DEBUG - 2017-01-10 13:06:22 --> UTF-8 Support Enabled
INFO - 2017-01-10 13:06:22 --> Utf8 Class Initialized
INFO - 2017-01-10 13:06:22 --> URI Class Initialized
INFO - 2017-01-10 13:06:22 --> Router Class Initialized
INFO - 2017-01-10 13:06:22 --> Output Class Initialized
INFO - 2017-01-10 13:06:22 --> Security Class Initialized
DEBUG - 2017-01-10 13:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 13:06:22 --> Input Class Initialized
INFO - 2017-01-10 13:06:22 --> Language Class Initialized
INFO - 2017-01-10 13:06:22 --> Loader Class Initialized
INFO - 2017-01-10 13:06:22 --> Database Driver Class Initialized
INFO - 2017-01-10 13:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 13:06:22 --> Controller Class Initialized
INFO - 2017-01-10 13:06:22 --> Helper loaded: url_helper
DEBUG - 2017-01-10 13:06:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 13:06:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 13:06:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 13:06:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 13:06:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 13:06:22 --> Final output sent to browser
DEBUG - 2017-01-10 13:06:22 --> Total execution time: 0.0216
INFO - 2017-01-10 13:06:56 --> Config Class Initialized
INFO - 2017-01-10 13:06:56 --> Hooks Class Initialized
DEBUG - 2017-01-10 13:06:56 --> UTF-8 Support Enabled
INFO - 2017-01-10 13:06:56 --> Utf8 Class Initialized
INFO - 2017-01-10 13:06:56 --> URI Class Initialized
DEBUG - 2017-01-10 13:06:56 --> No URI present. Default controller set.
INFO - 2017-01-10 13:06:56 --> Router Class Initialized
INFO - 2017-01-10 13:06:56 --> Output Class Initialized
INFO - 2017-01-10 13:06:56 --> Security Class Initialized
DEBUG - 2017-01-10 13:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 13:06:56 --> Input Class Initialized
INFO - 2017-01-10 13:06:56 --> Language Class Initialized
INFO - 2017-01-10 13:06:56 --> Loader Class Initialized
INFO - 2017-01-10 13:06:56 --> Database Driver Class Initialized
INFO - 2017-01-10 13:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 13:06:56 --> Controller Class Initialized
INFO - 2017-01-10 13:06:56 --> Helper loaded: url_helper
DEBUG - 2017-01-10 13:06:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 13:06:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 13:06:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 13:06:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 13:06:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 13:06:56 --> Final output sent to browser
DEBUG - 2017-01-10 13:06:56 --> Total execution time: 0.0142
INFO - 2017-01-10 15:34:21 --> Config Class Initialized
INFO - 2017-01-10 15:34:21 --> Hooks Class Initialized
DEBUG - 2017-01-10 15:34:21 --> UTF-8 Support Enabled
INFO - 2017-01-10 15:34:21 --> Utf8 Class Initialized
INFO - 2017-01-10 15:34:21 --> URI Class Initialized
DEBUG - 2017-01-10 15:34:21 --> No URI present. Default controller set.
INFO - 2017-01-10 15:34:21 --> Router Class Initialized
INFO - 2017-01-10 15:34:21 --> Output Class Initialized
INFO - 2017-01-10 15:34:21 --> Security Class Initialized
DEBUG - 2017-01-10 15:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-10 15:34:22 --> Input Class Initialized
INFO - 2017-01-10 15:34:22 --> Language Class Initialized
INFO - 2017-01-10 15:34:22 --> Loader Class Initialized
INFO - 2017-01-10 15:34:22 --> Database Driver Class Initialized
INFO - 2017-01-10 15:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-10 15:34:22 --> Controller Class Initialized
INFO - 2017-01-10 15:34:22 --> Helper loaded: url_helper
DEBUG - 2017-01-10 15:34:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-10 15:34:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-10 15:34:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-10 15:34:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-10 15:34:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-10 15:34:22 --> Final output sent to browser
DEBUG - 2017-01-10 15:34:22 --> Total execution time: 1.2105

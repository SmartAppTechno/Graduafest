<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-01 04:20:45 --> Config Class Initialized
INFO - 2016-12-01 04:20:45 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:20:45 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:20:46 --> Utf8 Class Initialized
INFO - 2016-12-01 04:20:46 --> URI Class Initialized
DEBUG - 2016-12-01 04:20:46 --> No URI present. Default controller set.
INFO - 2016-12-01 04:20:46 --> Router Class Initialized
INFO - 2016-12-01 04:20:46 --> Output Class Initialized
INFO - 2016-12-01 04:20:46 --> Security Class Initialized
DEBUG - 2016-12-01 04:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:20:46 --> Input Class Initialized
INFO - 2016-12-01 04:20:46 --> Language Class Initialized
INFO - 2016-12-01 04:20:46 --> Loader Class Initialized
INFO - 2016-12-01 04:20:46 --> Database Driver Class Initialized
INFO - 2016-12-01 04:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 04:20:46 --> Controller Class Initialized
INFO - 2016-12-01 04:20:46 --> Helper loaded: url_helper
DEBUG - 2016-12-01 04:20:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 04:20:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 04:20:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 04:20:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 04:20:47 --> Final output sent to browser
DEBUG - 2016-12-01 04:20:47 --> Total execution time: 1.4991
INFO - 2016-12-01 04:20:47 --> Config Class Initialized
INFO - 2016-12-01 04:20:47 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:20:47 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:20:47 --> Utf8 Class Initialized
INFO - 2016-12-01 04:20:47 --> URI Class Initialized
DEBUG - 2016-12-01 04:20:47 --> No URI present. Default controller set.
INFO - 2016-12-01 04:20:47 --> Router Class Initialized
INFO - 2016-12-01 04:20:47 --> Output Class Initialized
INFO - 2016-12-01 04:20:47 --> Security Class Initialized
DEBUG - 2016-12-01 04:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:20:47 --> Input Class Initialized
INFO - 2016-12-01 04:20:47 --> Language Class Initialized
INFO - 2016-12-01 04:20:47 --> Loader Class Initialized
INFO - 2016-12-01 04:20:47 --> Database Driver Class Initialized
INFO - 2016-12-01 04:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 04:20:47 --> Controller Class Initialized
INFO - 2016-12-01 04:20:47 --> Helper loaded: url_helper
DEBUG - 2016-12-01 04:20:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 04:20:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 04:20:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 04:20:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 04:20:47 --> Final output sent to browser
DEBUG - 2016-12-01 04:20:47 --> Total execution time: 0.0668
INFO - 2016-12-01 04:20:52 --> Config Class Initialized
INFO - 2016-12-01 04:20:52 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:20:52 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:20:52 --> Utf8 Class Initialized
INFO - 2016-12-01 04:20:52 --> URI Class Initialized
INFO - 2016-12-01 04:20:52 --> Router Class Initialized
INFO - 2016-12-01 04:20:52 --> Output Class Initialized
INFO - 2016-12-01 04:20:52 --> Security Class Initialized
DEBUG - 2016-12-01 04:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:20:52 --> Input Class Initialized
INFO - 2016-12-01 04:20:52 --> Language Class Initialized
ERROR - 2016-12-01 04:20:52 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 04:20:52 --> Config Class Initialized
INFO - 2016-12-01 04:20:52 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:20:52 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:20:52 --> Utf8 Class Initialized
INFO - 2016-12-01 04:20:52 --> URI Class Initialized
INFO - 2016-12-01 04:20:52 --> Router Class Initialized
INFO - 2016-12-01 04:20:52 --> Output Class Initialized
INFO - 2016-12-01 04:20:52 --> Security Class Initialized
DEBUG - 2016-12-01 04:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:20:52 --> Input Class Initialized
INFO - 2016-12-01 04:20:52 --> Language Class Initialized
ERROR - 2016-12-01 04:20:52 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 04:22:14 --> Config Class Initialized
INFO - 2016-12-01 04:22:14 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:22:14 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:22:14 --> Utf8 Class Initialized
INFO - 2016-12-01 04:22:14 --> URI Class Initialized
DEBUG - 2016-12-01 04:22:14 --> No URI present. Default controller set.
INFO - 2016-12-01 04:22:14 --> Router Class Initialized
INFO - 2016-12-01 04:22:14 --> Output Class Initialized
INFO - 2016-12-01 04:22:14 --> Security Class Initialized
DEBUG - 2016-12-01 04:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:22:14 --> Input Class Initialized
INFO - 2016-12-01 04:22:14 --> Language Class Initialized
INFO - 2016-12-01 04:22:14 --> Loader Class Initialized
INFO - 2016-12-01 04:22:14 --> Database Driver Class Initialized
INFO - 2016-12-01 04:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 04:22:14 --> Controller Class Initialized
INFO - 2016-12-01 04:22:14 --> Helper loaded: url_helper
DEBUG - 2016-12-01 04:22:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 04:22:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 04:22:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 04:22:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 04:22:14 --> Final output sent to browser
DEBUG - 2016-12-01 04:22:14 --> Total execution time: 0.0142
INFO - 2016-12-01 04:22:14 --> Config Class Initialized
INFO - 2016-12-01 04:22:14 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:22:14 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:22:14 --> Utf8 Class Initialized
INFO - 2016-12-01 04:22:14 --> URI Class Initialized
INFO - 2016-12-01 04:22:14 --> Router Class Initialized
INFO - 2016-12-01 04:22:14 --> Output Class Initialized
INFO - 2016-12-01 04:22:14 --> Security Class Initialized
DEBUG - 2016-12-01 04:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:22:14 --> Input Class Initialized
INFO - 2016-12-01 04:22:14 --> Language Class Initialized
ERROR - 2016-12-01 04:22:14 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 04:22:14 --> Config Class Initialized
INFO - 2016-12-01 04:22:14 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:22:14 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:22:14 --> Utf8 Class Initialized
INFO - 2016-12-01 04:22:14 --> URI Class Initialized
INFO - 2016-12-01 04:22:14 --> Router Class Initialized
INFO - 2016-12-01 04:22:14 --> Output Class Initialized
INFO - 2016-12-01 04:22:14 --> Security Class Initialized
DEBUG - 2016-12-01 04:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:22:14 --> Input Class Initialized
INFO - 2016-12-01 04:22:14 --> Language Class Initialized
ERROR - 2016-12-01 04:22:14 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 04:22:16 --> Config Class Initialized
INFO - 2016-12-01 04:22:16 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:22:16 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:22:16 --> Utf8 Class Initialized
INFO - 2016-12-01 04:22:16 --> URI Class Initialized
INFO - 2016-12-01 04:22:16 --> Router Class Initialized
INFO - 2016-12-01 04:22:16 --> Output Class Initialized
INFO - 2016-12-01 04:22:16 --> Security Class Initialized
DEBUG - 2016-12-01 04:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:22:16 --> Input Class Initialized
INFO - 2016-12-01 04:22:16 --> Language Class Initialized
INFO - 2016-12-01 04:22:16 --> Loader Class Initialized
INFO - 2016-12-01 04:22:16 --> Database Driver Class Initialized
INFO - 2016-12-01 04:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 04:22:16 --> Controller Class Initialized
INFO - 2016-12-01 04:22:16 --> Helper loaded: url_helper
DEBUG - 2016-12-01 04:22:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 04:22:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 04:22:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 04:22:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 04:22:16 --> Final output sent to browser
DEBUG - 2016-12-01 04:22:16 --> Total execution time: 0.0168
INFO - 2016-12-01 04:22:22 --> Config Class Initialized
INFO - 2016-12-01 04:22:22 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:22:22 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:22:22 --> Utf8 Class Initialized
INFO - 2016-12-01 04:22:22 --> URI Class Initialized
DEBUG - 2016-12-01 04:22:22 --> No URI present. Default controller set.
INFO - 2016-12-01 04:22:22 --> Router Class Initialized
INFO - 2016-12-01 04:22:22 --> Output Class Initialized
INFO - 2016-12-01 04:22:22 --> Security Class Initialized
DEBUG - 2016-12-01 04:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:22:22 --> Input Class Initialized
INFO - 2016-12-01 04:22:22 --> Language Class Initialized
INFO - 2016-12-01 04:22:22 --> Loader Class Initialized
INFO - 2016-12-01 04:22:22 --> Database Driver Class Initialized
INFO - 2016-12-01 04:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 04:22:22 --> Controller Class Initialized
INFO - 2016-12-01 04:22:22 --> Helper loaded: url_helper
DEBUG - 2016-12-01 04:22:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 04:22:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 04:22:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 04:22:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 04:22:22 --> Final output sent to browser
DEBUG - 2016-12-01 04:22:22 --> Total execution time: 0.0147
INFO - 2016-12-01 04:22:28 --> Config Class Initialized
INFO - 2016-12-01 04:22:28 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:22:28 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:22:28 --> Utf8 Class Initialized
INFO - 2016-12-01 04:22:28 --> URI Class Initialized
INFO - 2016-12-01 04:22:28 --> Router Class Initialized
INFO - 2016-12-01 04:22:28 --> Output Class Initialized
INFO - 2016-12-01 04:22:28 --> Security Class Initialized
DEBUG - 2016-12-01 04:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:22:28 --> Input Class Initialized
INFO - 2016-12-01 04:22:28 --> Language Class Initialized
ERROR - 2016-12-01 04:22:28 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 04:22:28 --> Config Class Initialized
INFO - 2016-12-01 04:22:28 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:22:28 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:22:28 --> Utf8 Class Initialized
INFO - 2016-12-01 04:22:28 --> URI Class Initialized
INFO - 2016-12-01 04:22:28 --> Router Class Initialized
INFO - 2016-12-01 04:22:28 --> Output Class Initialized
INFO - 2016-12-01 04:22:28 --> Security Class Initialized
DEBUG - 2016-12-01 04:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:22:28 --> Input Class Initialized
INFO - 2016-12-01 04:22:28 --> Language Class Initialized
ERROR - 2016-12-01 04:22:28 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 04:22:37 --> Config Class Initialized
INFO - 2016-12-01 04:22:37 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:22:37 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:22:37 --> Utf8 Class Initialized
INFO - 2016-12-01 04:22:37 --> URI Class Initialized
INFO - 2016-12-01 04:22:37 --> Router Class Initialized
INFO - 2016-12-01 04:22:37 --> Output Class Initialized
INFO - 2016-12-01 04:22:37 --> Security Class Initialized
DEBUG - 2016-12-01 04:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:22:37 --> Input Class Initialized
INFO - 2016-12-01 04:22:37 --> Language Class Initialized
INFO - 2016-12-01 04:22:37 --> Loader Class Initialized
INFO - 2016-12-01 04:22:37 --> Database Driver Class Initialized
INFO - 2016-12-01 04:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 04:22:37 --> Controller Class Initialized
INFO - 2016-12-01 04:22:37 --> Helper loaded: url_helper
DEBUG - 2016-12-01 04:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 04:22:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 04:22:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 04:22:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 04:22:37 --> Final output sent to browser
DEBUG - 2016-12-01 04:22:37 --> Total execution time: 0.0150
INFO - 2016-12-01 04:37:07 --> Config Class Initialized
INFO - 2016-12-01 04:37:07 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:37:07 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:37:07 --> Utf8 Class Initialized
INFO - 2016-12-01 04:37:07 --> URI Class Initialized
DEBUG - 2016-12-01 04:37:07 --> No URI present. Default controller set.
INFO - 2016-12-01 04:37:07 --> Router Class Initialized
INFO - 2016-12-01 04:37:07 --> Output Class Initialized
INFO - 2016-12-01 04:37:07 --> Security Class Initialized
DEBUG - 2016-12-01 04:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:37:07 --> Input Class Initialized
INFO - 2016-12-01 04:37:07 --> Language Class Initialized
INFO - 2016-12-01 04:37:07 --> Loader Class Initialized
INFO - 2016-12-01 04:37:07 --> Database Driver Class Initialized
INFO - 2016-12-01 04:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 04:37:07 --> Controller Class Initialized
INFO - 2016-12-01 04:37:07 --> Helper loaded: url_helper
DEBUG - 2016-12-01 04:37:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 04:37:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 04:37:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 04:37:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 04:37:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 04:37:07 --> Final output sent to browser
DEBUG - 2016-12-01 04:37:07 --> Total execution time: 0.0718
INFO - 2016-12-01 04:37:08 --> Config Class Initialized
INFO - 2016-12-01 04:37:08 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:37:08 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:37:08 --> Utf8 Class Initialized
INFO - 2016-12-01 04:37:08 --> URI Class Initialized
INFO - 2016-12-01 04:37:08 --> Router Class Initialized
INFO - 2016-12-01 04:37:08 --> Output Class Initialized
INFO - 2016-12-01 04:37:08 --> Security Class Initialized
DEBUG - 2016-12-01 04:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:37:08 --> Input Class Initialized
INFO - 2016-12-01 04:37:08 --> Language Class Initialized
ERROR - 2016-12-01 04:37:08 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 04:37:08 --> Config Class Initialized
INFO - 2016-12-01 04:37:08 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:37:08 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:37:08 --> Utf8 Class Initialized
INFO - 2016-12-01 04:37:08 --> URI Class Initialized
INFO - 2016-12-01 04:37:08 --> Router Class Initialized
INFO - 2016-12-01 04:37:08 --> Output Class Initialized
INFO - 2016-12-01 04:37:08 --> Security Class Initialized
DEBUG - 2016-12-01 04:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:37:08 --> Input Class Initialized
INFO - 2016-12-01 04:37:08 --> Language Class Initialized
ERROR - 2016-12-01 04:37:08 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 04:37:08 --> Config Class Initialized
INFO - 2016-12-01 04:37:08 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:37:08 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:37:08 --> Utf8 Class Initialized
INFO - 2016-12-01 04:37:08 --> URI Class Initialized
INFO - 2016-12-01 04:37:08 --> Router Class Initialized
INFO - 2016-12-01 04:37:08 --> Output Class Initialized
INFO - 2016-12-01 04:37:08 --> Security Class Initialized
DEBUG - 2016-12-01 04:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:37:08 --> Input Class Initialized
INFO - 2016-12-01 04:37:08 --> Language Class Initialized
INFO - 2016-12-01 04:37:08 --> Loader Class Initialized
INFO - 2016-12-01 04:37:08 --> Database Driver Class Initialized
INFO - 2016-12-01 04:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 04:37:08 --> Controller Class Initialized
INFO - 2016-12-01 04:37:08 --> Helper loaded: url_helper
DEBUG - 2016-12-01 04:37:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 04:37:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 04:37:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 04:37:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 04:37:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 04:37:08 --> Final output sent to browser
DEBUG - 2016-12-01 04:37:08 --> Total execution time: 0.0585
INFO - 2016-12-01 04:37:11 --> Config Class Initialized
INFO - 2016-12-01 04:37:11 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:37:11 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:37:11 --> Utf8 Class Initialized
INFO - 2016-12-01 04:37:11 --> URI Class Initialized
INFO - 2016-12-01 04:37:11 --> Router Class Initialized
INFO - 2016-12-01 04:37:11 --> Output Class Initialized
INFO - 2016-12-01 04:37:11 --> Security Class Initialized
DEBUG - 2016-12-01 04:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:37:11 --> Input Class Initialized
INFO - 2016-12-01 04:37:11 --> Language Class Initialized
ERROR - 2016-12-01 04:37:11 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-01 04:40:03 --> Config Class Initialized
INFO - 2016-12-01 04:40:03 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:40:03 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:40:03 --> Utf8 Class Initialized
INFO - 2016-12-01 04:40:03 --> URI Class Initialized
DEBUG - 2016-12-01 04:40:03 --> No URI present. Default controller set.
INFO - 2016-12-01 04:40:03 --> Router Class Initialized
INFO - 2016-12-01 04:40:03 --> Output Class Initialized
INFO - 2016-12-01 04:40:03 --> Security Class Initialized
DEBUG - 2016-12-01 04:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:40:03 --> Input Class Initialized
INFO - 2016-12-01 04:40:03 --> Language Class Initialized
INFO - 2016-12-01 04:40:03 --> Loader Class Initialized
INFO - 2016-12-01 04:40:03 --> Database Driver Class Initialized
INFO - 2016-12-01 04:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 04:40:03 --> Controller Class Initialized
INFO - 2016-12-01 04:40:03 --> Helper loaded: url_helper
DEBUG - 2016-12-01 04:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 04:40:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 04:40:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 04:40:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 04:40:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 04:40:03 --> Final output sent to browser
DEBUG - 2016-12-01 04:40:03 --> Total execution time: 0.0351
INFO - 2016-12-01 04:40:04 --> Config Class Initialized
INFO - 2016-12-01 04:40:04 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:40:04 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:40:04 --> Utf8 Class Initialized
INFO - 2016-12-01 04:40:04 --> URI Class Initialized
INFO - 2016-12-01 04:40:04 --> Router Class Initialized
INFO - 2016-12-01 04:40:04 --> Output Class Initialized
INFO - 2016-12-01 04:40:04 --> Security Class Initialized
DEBUG - 2016-12-01 04:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:40:04 --> Input Class Initialized
INFO - 2016-12-01 04:40:04 --> Language Class Initialized
ERROR - 2016-12-01 04:40:04 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-01 04:40:04 --> Config Class Initialized
INFO - 2016-12-01 04:40:04 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:40:04 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:40:04 --> Utf8 Class Initialized
INFO - 2016-12-01 04:40:04 --> URI Class Initialized
INFO - 2016-12-01 04:40:04 --> Router Class Initialized
INFO - 2016-12-01 04:40:04 --> Output Class Initialized
INFO - 2016-12-01 04:40:04 --> Security Class Initialized
DEBUG - 2016-12-01 04:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:40:04 --> Input Class Initialized
INFO - 2016-12-01 04:40:04 --> Language Class Initialized
ERROR - 2016-12-01 04:40:04 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 04:40:04 --> Config Class Initialized
INFO - 2016-12-01 04:40:04 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:40:04 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:40:04 --> Utf8 Class Initialized
INFO - 2016-12-01 04:40:04 --> URI Class Initialized
INFO - 2016-12-01 04:40:04 --> Router Class Initialized
INFO - 2016-12-01 04:40:04 --> Output Class Initialized
INFO - 2016-12-01 04:40:04 --> Security Class Initialized
DEBUG - 2016-12-01 04:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:40:04 --> Input Class Initialized
INFO - 2016-12-01 04:40:04 --> Language Class Initialized
ERROR - 2016-12-01 04:40:04 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 04:40:04 --> Config Class Initialized
INFO - 2016-12-01 04:40:04 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:40:04 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:40:04 --> Utf8 Class Initialized
INFO - 2016-12-01 04:40:04 --> URI Class Initialized
INFO - 2016-12-01 04:40:04 --> Router Class Initialized
INFO - 2016-12-01 04:40:04 --> Output Class Initialized
INFO - 2016-12-01 04:40:04 --> Security Class Initialized
DEBUG - 2016-12-01 04:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:40:04 --> Input Class Initialized
INFO - 2016-12-01 04:40:04 --> Language Class Initialized
INFO - 2016-12-01 04:40:04 --> Loader Class Initialized
INFO - 2016-12-01 04:40:04 --> Database Driver Class Initialized
INFO - 2016-12-01 04:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 04:40:04 --> Controller Class Initialized
INFO - 2016-12-01 04:40:04 --> Helper loaded: url_helper
DEBUG - 2016-12-01 04:40:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 04:40:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 04:40:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 04:40:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 04:40:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 04:40:04 --> Final output sent to browser
DEBUG - 2016-12-01 04:40:04 --> Total execution time: 0.0138
INFO - 2016-12-01 04:41:13 --> Config Class Initialized
INFO - 2016-12-01 04:41:13 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:41:13 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:41:13 --> Utf8 Class Initialized
INFO - 2016-12-01 04:41:13 --> URI Class Initialized
DEBUG - 2016-12-01 04:41:13 --> No URI present. Default controller set.
INFO - 2016-12-01 04:41:13 --> Router Class Initialized
INFO - 2016-12-01 04:41:13 --> Output Class Initialized
INFO - 2016-12-01 04:41:13 --> Security Class Initialized
DEBUG - 2016-12-01 04:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:41:13 --> Input Class Initialized
INFO - 2016-12-01 04:41:13 --> Language Class Initialized
INFO - 2016-12-01 04:41:13 --> Loader Class Initialized
INFO - 2016-12-01 04:41:13 --> Database Driver Class Initialized
INFO - 2016-12-01 04:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 04:41:13 --> Controller Class Initialized
INFO - 2016-12-01 04:41:13 --> Helper loaded: url_helper
DEBUG - 2016-12-01 04:41:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 04:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 04:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 04:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 04:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 04:41:13 --> Final output sent to browser
DEBUG - 2016-12-01 04:41:13 --> Total execution time: 0.0537
INFO - 2016-12-01 04:41:13 --> Config Class Initialized
INFO - 2016-12-01 04:41:13 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:41:13 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:41:13 --> Utf8 Class Initialized
INFO - 2016-12-01 04:41:13 --> URI Class Initialized
INFO - 2016-12-01 04:41:13 --> Router Class Initialized
INFO - 2016-12-01 04:41:13 --> Output Class Initialized
INFO - 2016-12-01 04:41:13 --> Security Class Initialized
DEBUG - 2016-12-01 04:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:41:13 --> Input Class Initialized
INFO - 2016-12-01 04:41:13 --> Language Class Initialized
ERROR - 2016-12-01 04:41:13 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-01 04:41:14 --> Config Class Initialized
INFO - 2016-12-01 04:41:14 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:41:14 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:41:14 --> Utf8 Class Initialized
INFO - 2016-12-01 04:41:14 --> URI Class Initialized
INFO - 2016-12-01 04:41:14 --> Router Class Initialized
INFO - 2016-12-01 04:41:14 --> Output Class Initialized
INFO - 2016-12-01 04:41:14 --> Security Class Initialized
DEBUG - 2016-12-01 04:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:41:14 --> Input Class Initialized
INFO - 2016-12-01 04:41:14 --> Language Class Initialized
ERROR - 2016-12-01 04:41:14 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 04:41:14 --> Config Class Initialized
INFO - 2016-12-01 04:41:14 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:41:14 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:41:14 --> Utf8 Class Initialized
INFO - 2016-12-01 04:41:14 --> URI Class Initialized
INFO - 2016-12-01 04:41:14 --> Router Class Initialized
INFO - 2016-12-01 04:41:14 --> Output Class Initialized
INFO - 2016-12-01 04:41:14 --> Security Class Initialized
DEBUG - 2016-12-01 04:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:41:14 --> Input Class Initialized
INFO - 2016-12-01 04:41:14 --> Language Class Initialized
ERROR - 2016-12-01 04:41:14 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 04:41:14 --> Config Class Initialized
INFO - 2016-12-01 04:41:14 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:41:14 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:41:14 --> Utf8 Class Initialized
INFO - 2016-12-01 04:41:14 --> URI Class Initialized
INFO - 2016-12-01 04:41:14 --> Router Class Initialized
INFO - 2016-12-01 04:41:14 --> Output Class Initialized
INFO - 2016-12-01 04:41:14 --> Security Class Initialized
DEBUG - 2016-12-01 04:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:41:14 --> Input Class Initialized
INFO - 2016-12-01 04:41:14 --> Language Class Initialized
INFO - 2016-12-01 04:41:14 --> Loader Class Initialized
INFO - 2016-12-01 04:41:14 --> Database Driver Class Initialized
INFO - 2016-12-01 04:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 04:41:14 --> Controller Class Initialized
INFO - 2016-12-01 04:41:14 --> Helper loaded: url_helper
DEBUG - 2016-12-01 04:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 04:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 04:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 04:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 04:41:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 04:41:14 --> Final output sent to browser
DEBUG - 2016-12-01 04:41:14 --> Total execution time: 0.0203
INFO - 2016-12-01 04:43:02 --> Config Class Initialized
INFO - 2016-12-01 04:43:02 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:43:02 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:43:02 --> Utf8 Class Initialized
INFO - 2016-12-01 04:43:02 --> URI Class Initialized
DEBUG - 2016-12-01 04:43:02 --> No URI present. Default controller set.
INFO - 2016-12-01 04:43:02 --> Router Class Initialized
INFO - 2016-12-01 04:43:02 --> Output Class Initialized
INFO - 2016-12-01 04:43:02 --> Security Class Initialized
DEBUG - 2016-12-01 04:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:43:02 --> Input Class Initialized
INFO - 2016-12-01 04:43:02 --> Language Class Initialized
INFO - 2016-12-01 04:43:02 --> Loader Class Initialized
INFO - 2016-12-01 04:43:02 --> Database Driver Class Initialized
INFO - 2016-12-01 04:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 04:43:02 --> Controller Class Initialized
INFO - 2016-12-01 04:43:02 --> Helper loaded: url_helper
DEBUG - 2016-12-01 04:43:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 04:43:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 04:43:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 04:43:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 04:43:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 04:43:02 --> Final output sent to browser
DEBUG - 2016-12-01 04:43:02 --> Total execution time: 0.0145
INFO - 2016-12-01 04:43:02 --> Config Class Initialized
INFO - 2016-12-01 04:43:02 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:43:02 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:43:02 --> Utf8 Class Initialized
INFO - 2016-12-01 04:43:02 --> URI Class Initialized
INFO - 2016-12-01 04:43:02 --> Router Class Initialized
INFO - 2016-12-01 04:43:02 --> Output Class Initialized
INFO - 2016-12-01 04:43:02 --> Security Class Initialized
DEBUG - 2016-12-01 04:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:43:02 --> Input Class Initialized
INFO - 2016-12-01 04:43:02 --> Language Class Initialized
ERROR - 2016-12-01 04:43:02 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-01 04:43:03 --> Config Class Initialized
INFO - 2016-12-01 04:43:03 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:43:03 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:43:03 --> Utf8 Class Initialized
INFO - 2016-12-01 04:43:03 --> URI Class Initialized
INFO - 2016-12-01 04:43:03 --> Router Class Initialized
INFO - 2016-12-01 04:43:03 --> Output Class Initialized
INFO - 2016-12-01 04:43:03 --> Security Class Initialized
DEBUG - 2016-12-01 04:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:43:03 --> Input Class Initialized
INFO - 2016-12-01 04:43:03 --> Language Class Initialized
ERROR - 2016-12-01 04:43:03 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 04:43:03 --> Config Class Initialized
INFO - 2016-12-01 04:43:03 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:43:03 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:43:03 --> Utf8 Class Initialized
INFO - 2016-12-01 04:43:03 --> URI Class Initialized
INFO - 2016-12-01 04:43:03 --> Router Class Initialized
INFO - 2016-12-01 04:43:03 --> Output Class Initialized
INFO - 2016-12-01 04:43:03 --> Security Class Initialized
DEBUG - 2016-12-01 04:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:43:03 --> Input Class Initialized
INFO - 2016-12-01 04:43:03 --> Language Class Initialized
ERROR - 2016-12-01 04:43:03 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 04:43:04 --> Config Class Initialized
INFO - 2016-12-01 04:43:04 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:43:04 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:43:04 --> Utf8 Class Initialized
INFO - 2016-12-01 04:43:04 --> URI Class Initialized
INFO - 2016-12-01 04:43:04 --> Router Class Initialized
INFO - 2016-12-01 04:43:04 --> Output Class Initialized
INFO - 2016-12-01 04:43:04 --> Security Class Initialized
DEBUG - 2016-12-01 04:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:43:04 --> Input Class Initialized
INFO - 2016-12-01 04:43:04 --> Language Class Initialized
INFO - 2016-12-01 04:43:04 --> Loader Class Initialized
INFO - 2016-12-01 04:43:04 --> Database Driver Class Initialized
INFO - 2016-12-01 04:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 04:43:04 --> Controller Class Initialized
INFO - 2016-12-01 04:43:04 --> Helper loaded: url_helper
DEBUG - 2016-12-01 04:43:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 04:43:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 04:43:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 04:43:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 04:43:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 04:43:04 --> Final output sent to browser
DEBUG - 2016-12-01 04:43:04 --> Total execution time: 0.0137
INFO - 2016-12-01 04:44:04 --> Config Class Initialized
INFO - 2016-12-01 04:44:04 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:44:04 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:44:04 --> Utf8 Class Initialized
INFO - 2016-12-01 04:44:04 --> URI Class Initialized
DEBUG - 2016-12-01 04:44:04 --> No URI present. Default controller set.
INFO - 2016-12-01 04:44:04 --> Router Class Initialized
INFO - 2016-12-01 04:44:04 --> Output Class Initialized
INFO - 2016-12-01 04:44:04 --> Security Class Initialized
DEBUG - 2016-12-01 04:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:44:04 --> Input Class Initialized
INFO - 2016-12-01 04:44:04 --> Language Class Initialized
INFO - 2016-12-01 04:44:04 --> Loader Class Initialized
INFO - 2016-12-01 04:44:04 --> Database Driver Class Initialized
INFO - 2016-12-01 04:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 04:44:04 --> Controller Class Initialized
INFO - 2016-12-01 04:44:04 --> Helper loaded: url_helper
DEBUG - 2016-12-01 04:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 04:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 04:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 04:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 04:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 04:44:04 --> Final output sent to browser
DEBUG - 2016-12-01 04:44:04 --> Total execution time: 0.0650
INFO - 2016-12-01 04:44:04 --> Config Class Initialized
INFO - 2016-12-01 04:44:04 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:44:04 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:44:04 --> Utf8 Class Initialized
INFO - 2016-12-01 04:44:04 --> URI Class Initialized
INFO - 2016-12-01 04:44:04 --> Router Class Initialized
INFO - 2016-12-01 04:44:04 --> Output Class Initialized
INFO - 2016-12-01 04:44:04 --> Security Class Initialized
DEBUG - 2016-12-01 04:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:44:04 --> Input Class Initialized
INFO - 2016-12-01 04:44:04 --> Language Class Initialized
ERROR - 2016-12-01 04:44:04 --> 404 Page Not Found: Templates/usuario
INFO - 2016-12-01 04:44:04 --> Config Class Initialized
INFO - 2016-12-01 04:44:04 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:44:04 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:44:04 --> Utf8 Class Initialized
INFO - 2016-12-01 04:44:04 --> URI Class Initialized
INFO - 2016-12-01 04:44:04 --> Router Class Initialized
INFO - 2016-12-01 04:44:04 --> Output Class Initialized
INFO - 2016-12-01 04:44:04 --> Security Class Initialized
DEBUG - 2016-12-01 04:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:44:04 --> Input Class Initialized
INFO - 2016-12-01 04:44:04 --> Language Class Initialized
ERROR - 2016-12-01 04:44:04 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 04:44:05 --> Config Class Initialized
INFO - 2016-12-01 04:44:05 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:44:05 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:44:05 --> Utf8 Class Initialized
INFO - 2016-12-01 04:44:05 --> URI Class Initialized
INFO - 2016-12-01 04:44:05 --> Router Class Initialized
INFO - 2016-12-01 04:44:05 --> Output Class Initialized
INFO - 2016-12-01 04:44:05 --> Security Class Initialized
DEBUG - 2016-12-01 04:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:44:05 --> Input Class Initialized
INFO - 2016-12-01 04:44:05 --> Language Class Initialized
ERROR - 2016-12-01 04:44:05 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 04:44:05 --> Config Class Initialized
INFO - 2016-12-01 04:44:05 --> Hooks Class Initialized
DEBUG - 2016-12-01 04:44:05 --> UTF-8 Support Enabled
INFO - 2016-12-01 04:44:05 --> Utf8 Class Initialized
INFO - 2016-12-01 04:44:05 --> URI Class Initialized
INFO - 2016-12-01 04:44:05 --> Router Class Initialized
INFO - 2016-12-01 04:44:05 --> Output Class Initialized
INFO - 2016-12-01 04:44:05 --> Security Class Initialized
DEBUG - 2016-12-01 04:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 04:44:05 --> Input Class Initialized
INFO - 2016-12-01 04:44:05 --> Language Class Initialized
INFO - 2016-12-01 04:44:05 --> Loader Class Initialized
INFO - 2016-12-01 04:44:05 --> Database Driver Class Initialized
INFO - 2016-12-01 04:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 04:44:05 --> Controller Class Initialized
INFO - 2016-12-01 04:44:05 --> Helper loaded: url_helper
DEBUG - 2016-12-01 04:44:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 04:44:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 04:44:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 04:44:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 04:44:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 04:44:05 --> Final output sent to browser
DEBUG - 2016-12-01 04:44:05 --> Total execution time: 0.0149
INFO - 2016-12-01 05:05:54 --> Config Class Initialized
INFO - 2016-12-01 05:05:54 --> Hooks Class Initialized
DEBUG - 2016-12-01 05:05:54 --> UTF-8 Support Enabled
INFO - 2016-12-01 05:05:54 --> Utf8 Class Initialized
INFO - 2016-12-01 05:05:54 --> URI Class Initialized
DEBUG - 2016-12-01 05:05:54 --> No URI present. Default controller set.
INFO - 2016-12-01 05:05:54 --> Router Class Initialized
INFO - 2016-12-01 05:05:54 --> Output Class Initialized
INFO - 2016-12-01 05:05:54 --> Security Class Initialized
DEBUG - 2016-12-01 05:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 05:05:54 --> Input Class Initialized
INFO - 2016-12-01 05:05:54 --> Language Class Initialized
INFO - 2016-12-01 05:05:54 --> Loader Class Initialized
INFO - 2016-12-01 05:05:54 --> Database Driver Class Initialized
INFO - 2016-12-01 05:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 05:05:54 --> Controller Class Initialized
INFO - 2016-12-01 05:05:54 --> Helper loaded: url_helper
DEBUG - 2016-12-01 05:05:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 05:05:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 05:05:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 05:05:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 05:05:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 05:05:54 --> Final output sent to browser
DEBUG - 2016-12-01 05:05:54 --> Total execution time: 0.0137
INFO - 2016-12-01 05:05:57 --> Config Class Initialized
INFO - 2016-12-01 05:05:57 --> Hooks Class Initialized
DEBUG - 2016-12-01 05:05:57 --> UTF-8 Support Enabled
INFO - 2016-12-01 05:05:57 --> Utf8 Class Initialized
INFO - 2016-12-01 05:05:57 --> URI Class Initialized
INFO - 2016-12-01 05:05:57 --> Router Class Initialized
INFO - 2016-12-01 05:05:57 --> Output Class Initialized
INFO - 2016-12-01 05:05:57 --> Security Class Initialized
DEBUG - 2016-12-01 05:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 05:05:57 --> Input Class Initialized
INFO - 2016-12-01 05:05:57 --> Language Class Initialized
ERROR - 2016-12-01 05:05:57 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 05:05:57 --> Config Class Initialized
INFO - 2016-12-01 05:05:57 --> Hooks Class Initialized
DEBUG - 2016-12-01 05:05:57 --> UTF-8 Support Enabled
INFO - 2016-12-01 05:05:57 --> Utf8 Class Initialized
INFO - 2016-12-01 05:05:57 --> URI Class Initialized
INFO - 2016-12-01 05:05:57 --> Router Class Initialized
INFO - 2016-12-01 05:05:57 --> Output Class Initialized
INFO - 2016-12-01 05:05:57 --> Security Class Initialized
DEBUG - 2016-12-01 05:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 05:05:57 --> Input Class Initialized
INFO - 2016-12-01 05:05:57 --> Language Class Initialized
ERROR - 2016-12-01 05:05:57 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 05:05:59 --> Config Class Initialized
INFO - 2016-12-01 05:05:59 --> Hooks Class Initialized
DEBUG - 2016-12-01 05:05:59 --> UTF-8 Support Enabled
INFO - 2016-12-01 05:05:59 --> Utf8 Class Initialized
INFO - 2016-12-01 05:05:59 --> URI Class Initialized
INFO - 2016-12-01 05:05:59 --> Router Class Initialized
INFO - 2016-12-01 05:05:59 --> Output Class Initialized
INFO - 2016-12-01 05:05:59 --> Security Class Initialized
DEBUG - 2016-12-01 05:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 05:05:59 --> Input Class Initialized
INFO - 2016-12-01 05:05:59 --> Language Class Initialized
INFO - 2016-12-01 05:05:59 --> Loader Class Initialized
INFO - 2016-12-01 05:05:59 --> Database Driver Class Initialized
INFO - 2016-12-01 05:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 05:05:59 --> Controller Class Initialized
INFO - 2016-12-01 05:05:59 --> Helper loaded: url_helper
DEBUG - 2016-12-01 05:05:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 05:05:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 05:05:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 05:05:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 05:05:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 05:05:59 --> Final output sent to browser
DEBUG - 2016-12-01 05:05:59 --> Total execution time: 0.0133
INFO - 2016-12-01 10:53:31 --> Config Class Initialized
INFO - 2016-12-01 10:53:31 --> Hooks Class Initialized
DEBUG - 2016-12-01 10:53:31 --> UTF-8 Support Enabled
INFO - 2016-12-01 10:53:31 --> Utf8 Class Initialized
INFO - 2016-12-01 10:53:31 --> URI Class Initialized
DEBUG - 2016-12-01 10:53:31 --> No URI present. Default controller set.
INFO - 2016-12-01 10:53:31 --> Router Class Initialized
INFO - 2016-12-01 10:53:31 --> Output Class Initialized
INFO - 2016-12-01 10:53:31 --> Security Class Initialized
DEBUG - 2016-12-01 10:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 10:53:31 --> Input Class Initialized
INFO - 2016-12-01 10:53:31 --> Language Class Initialized
INFO - 2016-12-01 10:53:31 --> Loader Class Initialized
INFO - 2016-12-01 10:53:31 --> Database Driver Class Initialized
INFO - 2016-12-01 10:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 10:53:31 --> Controller Class Initialized
INFO - 2016-12-01 10:53:31 --> Helper loaded: url_helper
DEBUG - 2016-12-01 10:53:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 10:53:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 10:53:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 10:53:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 10:53:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 10:53:31 --> Final output sent to browser
DEBUG - 2016-12-01 10:53:31 --> Total execution time: 0.0747
INFO - 2016-12-01 10:53:32 --> Config Class Initialized
INFO - 2016-12-01 10:53:32 --> Hooks Class Initialized
DEBUG - 2016-12-01 10:53:32 --> UTF-8 Support Enabled
INFO - 2016-12-01 10:53:32 --> Utf8 Class Initialized
INFO - 2016-12-01 10:53:32 --> URI Class Initialized
INFO - 2016-12-01 10:53:32 --> Router Class Initialized
INFO - 2016-12-01 10:53:32 --> Output Class Initialized
INFO - 2016-12-01 10:53:32 --> Security Class Initialized
DEBUG - 2016-12-01 10:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 10:53:32 --> Input Class Initialized
INFO - 2016-12-01 10:53:32 --> Language Class Initialized
INFO - 2016-12-01 10:53:32 --> Loader Class Initialized
INFO - 2016-12-01 10:53:32 --> Database Driver Class Initialized
INFO - 2016-12-01 10:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 10:53:32 --> Controller Class Initialized
INFO - 2016-12-01 10:53:32 --> Helper loaded: url_helper
DEBUG - 2016-12-01 10:53:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 10:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 10:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 10:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 10:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 10:53:32 --> Final output sent to browser
DEBUG - 2016-12-01 10:53:32 --> Total execution time: 0.0137
INFO - 2016-12-01 12:59:35 --> Config Class Initialized
INFO - 2016-12-01 12:59:35 --> Hooks Class Initialized
DEBUG - 2016-12-01 12:59:35 --> UTF-8 Support Enabled
INFO - 2016-12-01 12:59:35 --> Utf8 Class Initialized
INFO - 2016-12-01 12:59:35 --> URI Class Initialized
DEBUG - 2016-12-01 12:59:35 --> No URI present. Default controller set.
INFO - 2016-12-01 12:59:35 --> Router Class Initialized
INFO - 2016-12-01 12:59:35 --> Output Class Initialized
INFO - 2016-12-01 12:59:35 --> Security Class Initialized
DEBUG - 2016-12-01 12:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 12:59:35 --> Input Class Initialized
INFO - 2016-12-01 12:59:35 --> Language Class Initialized
INFO - 2016-12-01 12:59:35 --> Loader Class Initialized
INFO - 2016-12-01 12:59:35 --> Database Driver Class Initialized
INFO - 2016-12-01 12:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 12:59:35 --> Controller Class Initialized
INFO - 2016-12-01 12:59:35 --> Helper loaded: url_helper
DEBUG - 2016-12-01 12:59:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 12:59:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 12:59:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 12:59:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 12:59:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 12:59:35 --> Final output sent to browser
DEBUG - 2016-12-01 12:59:35 --> Total execution time: 0.0297
INFO - 2016-12-01 12:59:36 --> Config Class Initialized
INFO - 2016-12-01 12:59:36 --> Hooks Class Initialized
DEBUG - 2016-12-01 12:59:36 --> UTF-8 Support Enabled
INFO - 2016-12-01 12:59:36 --> Utf8 Class Initialized
INFO - 2016-12-01 12:59:36 --> URI Class Initialized
INFO - 2016-12-01 12:59:36 --> Router Class Initialized
INFO - 2016-12-01 12:59:36 --> Output Class Initialized
INFO - 2016-12-01 12:59:36 --> Security Class Initialized
DEBUG - 2016-12-01 12:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 12:59:36 --> Input Class Initialized
INFO - 2016-12-01 12:59:36 --> Language Class Initialized
ERROR - 2016-12-01 12:59:36 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 12:59:36 --> Config Class Initialized
INFO - 2016-12-01 12:59:36 --> Hooks Class Initialized
DEBUG - 2016-12-01 12:59:36 --> UTF-8 Support Enabled
INFO - 2016-12-01 12:59:36 --> Utf8 Class Initialized
INFO - 2016-12-01 12:59:36 --> URI Class Initialized
INFO - 2016-12-01 12:59:36 --> Router Class Initialized
INFO - 2016-12-01 12:59:36 --> Output Class Initialized
INFO - 2016-12-01 12:59:36 --> Security Class Initialized
DEBUG - 2016-12-01 12:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 12:59:36 --> Input Class Initialized
INFO - 2016-12-01 12:59:36 --> Language Class Initialized
ERROR - 2016-12-01 12:59:36 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 12:59:37 --> Config Class Initialized
INFO - 2016-12-01 12:59:37 --> Hooks Class Initialized
DEBUG - 2016-12-01 12:59:37 --> UTF-8 Support Enabled
INFO - 2016-12-01 12:59:37 --> Utf8 Class Initialized
INFO - 2016-12-01 12:59:37 --> URI Class Initialized
INFO - 2016-12-01 12:59:37 --> Router Class Initialized
INFO - 2016-12-01 12:59:37 --> Output Class Initialized
INFO - 2016-12-01 12:59:37 --> Security Class Initialized
DEBUG - 2016-12-01 12:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 12:59:37 --> Input Class Initialized
INFO - 2016-12-01 12:59:37 --> Language Class Initialized
INFO - 2016-12-01 12:59:37 --> Loader Class Initialized
INFO - 2016-12-01 12:59:37 --> Database Driver Class Initialized
INFO - 2016-12-01 12:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 12:59:37 --> Controller Class Initialized
INFO - 2016-12-01 12:59:37 --> Helper loaded: url_helper
DEBUG - 2016-12-01 12:59:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 12:59:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 12:59:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 12:59:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 12:59:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 12:59:37 --> Final output sent to browser
DEBUG - 2016-12-01 12:59:37 --> Total execution time: 0.0145
INFO - 2016-12-01 14:01:26 --> Config Class Initialized
INFO - 2016-12-01 14:01:26 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:01:26 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:01:26 --> Utf8 Class Initialized
INFO - 2016-12-01 14:01:26 --> URI Class Initialized
DEBUG - 2016-12-01 14:01:26 --> No URI present. Default controller set.
INFO - 2016-12-01 14:01:26 --> Router Class Initialized
INFO - 2016-12-01 14:01:26 --> Output Class Initialized
INFO - 2016-12-01 14:01:26 --> Security Class Initialized
DEBUG - 2016-12-01 14:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:01:26 --> Input Class Initialized
INFO - 2016-12-01 14:01:26 --> Language Class Initialized
INFO - 2016-12-01 14:01:26 --> Loader Class Initialized
INFO - 2016-12-01 14:01:26 --> Database Driver Class Initialized
INFO - 2016-12-01 14:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:01:26 --> Controller Class Initialized
INFO - 2016-12-01 14:01:26 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:01:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:01:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:01:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:01:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:01:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:01:26 --> Final output sent to browser
DEBUG - 2016-12-01 14:01:26 --> Total execution time: 0.0139
INFO - 2016-12-01 14:01:26 --> Config Class Initialized
INFO - 2016-12-01 14:01:26 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:01:26 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:01:26 --> Utf8 Class Initialized
INFO - 2016-12-01 14:01:26 --> URI Class Initialized
INFO - 2016-12-01 14:01:26 --> Router Class Initialized
INFO - 2016-12-01 14:01:26 --> Output Class Initialized
INFO - 2016-12-01 14:01:26 --> Security Class Initialized
DEBUG - 2016-12-01 14:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:01:26 --> Input Class Initialized
INFO - 2016-12-01 14:01:26 --> Language Class Initialized
ERROR - 2016-12-01 14:01:26 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:01:26 --> Config Class Initialized
INFO - 2016-12-01 14:01:26 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:01:26 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:01:26 --> Utf8 Class Initialized
INFO - 2016-12-01 14:01:26 --> URI Class Initialized
INFO - 2016-12-01 14:01:26 --> Router Class Initialized
INFO - 2016-12-01 14:01:26 --> Output Class Initialized
INFO - 2016-12-01 14:01:26 --> Security Class Initialized
DEBUG - 2016-12-01 14:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:01:26 --> Input Class Initialized
INFO - 2016-12-01 14:01:26 --> Language Class Initialized
ERROR - 2016-12-01 14:01:26 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:01:27 --> Config Class Initialized
INFO - 2016-12-01 14:01:27 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:01:27 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:01:27 --> Utf8 Class Initialized
INFO - 2016-12-01 14:01:27 --> URI Class Initialized
INFO - 2016-12-01 14:01:27 --> Router Class Initialized
INFO - 2016-12-01 14:01:27 --> Output Class Initialized
INFO - 2016-12-01 14:01:27 --> Security Class Initialized
DEBUG - 2016-12-01 14:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:01:27 --> Input Class Initialized
INFO - 2016-12-01 14:01:27 --> Language Class Initialized
INFO - 2016-12-01 14:01:27 --> Loader Class Initialized
INFO - 2016-12-01 14:01:27 --> Database Driver Class Initialized
INFO - 2016-12-01 14:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:01:27 --> Controller Class Initialized
INFO - 2016-12-01 14:01:27 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:01:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:01:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:01:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:01:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:01:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:01:27 --> Final output sent to browser
DEBUG - 2016-12-01 14:01:27 --> Total execution time: 0.0134
INFO - 2016-12-01 14:07:42 --> Config Class Initialized
INFO - 2016-12-01 14:07:42 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:07:42 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:07:42 --> Utf8 Class Initialized
INFO - 2016-12-01 14:07:42 --> URI Class Initialized
DEBUG - 2016-12-01 14:07:42 --> No URI present. Default controller set.
INFO - 2016-12-01 14:07:42 --> Router Class Initialized
INFO - 2016-12-01 14:07:42 --> Output Class Initialized
INFO - 2016-12-01 14:07:42 --> Security Class Initialized
DEBUG - 2016-12-01 14:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:07:42 --> Input Class Initialized
INFO - 2016-12-01 14:07:42 --> Language Class Initialized
INFO - 2016-12-01 14:07:42 --> Loader Class Initialized
INFO - 2016-12-01 14:07:42 --> Database Driver Class Initialized
INFO - 2016-12-01 14:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:07:42 --> Controller Class Initialized
INFO - 2016-12-01 14:07:42 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:07:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:07:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:07:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:07:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:07:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:07:42 --> Final output sent to browser
DEBUG - 2016-12-01 14:07:42 --> Total execution time: 0.0129
INFO - 2016-12-01 14:07:42 --> Config Class Initialized
INFO - 2016-12-01 14:07:42 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:07:42 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:07:42 --> Utf8 Class Initialized
INFO - 2016-12-01 14:07:42 --> URI Class Initialized
INFO - 2016-12-01 14:07:42 --> Router Class Initialized
INFO - 2016-12-01 14:07:42 --> Output Class Initialized
INFO - 2016-12-01 14:07:42 --> Security Class Initialized
DEBUG - 2016-12-01 14:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:07:42 --> Input Class Initialized
INFO - 2016-12-01 14:07:42 --> Config Class Initialized
INFO - 2016-12-01 14:07:42 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:07:42 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:07:42 --> Utf8 Class Initialized
INFO - 2016-12-01 14:07:42 --> URI Class Initialized
INFO - 2016-12-01 14:07:42 --> Router Class Initialized
INFO - 2016-12-01 14:07:42 --> Output Class Initialized
INFO - 2016-12-01 14:07:42 --> Security Class Initialized
DEBUG - 2016-12-01 14:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:07:42 --> Input Class Initialized
INFO - 2016-12-01 14:07:42 --> Language Class Initialized
ERROR - 2016-12-01 14:07:42 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:07:42 --> Language Class Initialized
ERROR - 2016-12-01 14:07:42 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:07:43 --> Config Class Initialized
INFO - 2016-12-01 14:07:43 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:07:43 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:07:43 --> Utf8 Class Initialized
INFO - 2016-12-01 14:07:43 --> URI Class Initialized
INFO - 2016-12-01 14:07:43 --> Router Class Initialized
INFO - 2016-12-01 14:07:43 --> Output Class Initialized
INFO - 2016-12-01 14:07:43 --> Security Class Initialized
DEBUG - 2016-12-01 14:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:07:43 --> Input Class Initialized
INFO - 2016-12-01 14:07:43 --> Language Class Initialized
INFO - 2016-12-01 14:07:43 --> Loader Class Initialized
INFO - 2016-12-01 14:07:43 --> Database Driver Class Initialized
INFO - 2016-12-01 14:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:07:43 --> Controller Class Initialized
INFO - 2016-12-01 14:07:43 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:07:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:07:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:07:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:07:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:07:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:07:43 --> Final output sent to browser
DEBUG - 2016-12-01 14:07:43 --> Total execution time: 0.0137
INFO - 2016-12-01 14:08:30 --> Config Class Initialized
INFO - 2016-12-01 14:08:30 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:08:30 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:08:30 --> Utf8 Class Initialized
INFO - 2016-12-01 14:08:30 --> URI Class Initialized
DEBUG - 2016-12-01 14:08:30 --> No URI present. Default controller set.
INFO - 2016-12-01 14:08:30 --> Router Class Initialized
INFO - 2016-12-01 14:08:30 --> Output Class Initialized
INFO - 2016-12-01 14:08:30 --> Security Class Initialized
DEBUG - 2016-12-01 14:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:08:30 --> Input Class Initialized
INFO - 2016-12-01 14:08:30 --> Language Class Initialized
INFO - 2016-12-01 14:08:30 --> Loader Class Initialized
INFO - 2016-12-01 14:08:30 --> Database Driver Class Initialized
INFO - 2016-12-01 14:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:08:30 --> Controller Class Initialized
INFO - 2016-12-01 14:08:30 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:08:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:08:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:08:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:08:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:08:30 --> Final output sent to browser
DEBUG - 2016-12-01 14:08:30 --> Total execution time: 0.0134
INFO - 2016-12-01 14:08:30 --> Config Class Initialized
INFO - 2016-12-01 14:08:30 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:08:30 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:08:30 --> Utf8 Class Initialized
INFO - 2016-12-01 14:08:30 --> URI Class Initialized
INFO - 2016-12-01 14:08:30 --> Router Class Initialized
INFO - 2016-12-01 14:08:30 --> Output Class Initialized
INFO - 2016-12-01 14:08:30 --> Security Class Initialized
DEBUG - 2016-12-01 14:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:08:30 --> Input Class Initialized
INFO - 2016-12-01 14:08:30 --> Language Class Initialized
ERROR - 2016-12-01 14:08:30 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:08:30 --> Config Class Initialized
INFO - 2016-12-01 14:08:30 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:08:30 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:08:30 --> Utf8 Class Initialized
INFO - 2016-12-01 14:08:30 --> URI Class Initialized
INFO - 2016-12-01 14:08:30 --> Router Class Initialized
INFO - 2016-12-01 14:08:30 --> Output Class Initialized
INFO - 2016-12-01 14:08:30 --> Security Class Initialized
DEBUG - 2016-12-01 14:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:08:30 --> Input Class Initialized
INFO - 2016-12-01 14:08:30 --> Language Class Initialized
ERROR - 2016-12-01 14:08:30 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:08:30 --> Config Class Initialized
INFO - 2016-12-01 14:08:30 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:08:30 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:08:30 --> Utf8 Class Initialized
INFO - 2016-12-01 14:08:30 --> URI Class Initialized
INFO - 2016-12-01 14:08:30 --> Router Class Initialized
INFO - 2016-12-01 14:08:30 --> Output Class Initialized
INFO - 2016-12-01 14:08:30 --> Security Class Initialized
DEBUG - 2016-12-01 14:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:08:30 --> Input Class Initialized
INFO - 2016-12-01 14:08:30 --> Language Class Initialized
INFO - 2016-12-01 14:08:30 --> Loader Class Initialized
INFO - 2016-12-01 14:08:30 --> Database Driver Class Initialized
INFO - 2016-12-01 14:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:08:30 --> Controller Class Initialized
INFO - 2016-12-01 14:08:30 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:08:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:08:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:08:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:08:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:08:30 --> Final output sent to browser
DEBUG - 2016-12-01 14:08:30 --> Total execution time: 0.0130
INFO - 2016-12-01 14:16:43 --> Config Class Initialized
INFO - 2016-12-01 14:16:43 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:16:43 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:16:43 --> Utf8 Class Initialized
INFO - 2016-12-01 14:16:43 --> URI Class Initialized
DEBUG - 2016-12-01 14:16:43 --> No URI present. Default controller set.
INFO - 2016-12-01 14:16:43 --> Router Class Initialized
INFO - 2016-12-01 14:16:43 --> Output Class Initialized
INFO - 2016-12-01 14:16:43 --> Security Class Initialized
DEBUG - 2016-12-01 14:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:16:43 --> Input Class Initialized
INFO - 2016-12-01 14:16:43 --> Language Class Initialized
INFO - 2016-12-01 14:16:43 --> Loader Class Initialized
INFO - 2016-12-01 14:16:43 --> Database Driver Class Initialized
INFO - 2016-12-01 14:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:16:43 --> Controller Class Initialized
INFO - 2016-12-01 14:16:43 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:16:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:16:43 --> Final output sent to browser
DEBUG - 2016-12-01 14:16:43 --> Total execution time: 0.0139
INFO - 2016-12-01 14:16:43 --> Config Class Initialized
INFO - 2016-12-01 14:16:43 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:16:43 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:16:43 --> Utf8 Class Initialized
INFO - 2016-12-01 14:16:43 --> Config Class Initialized
INFO - 2016-12-01 14:16:43 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:16:43 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:16:43 --> Utf8 Class Initialized
INFO - 2016-12-01 14:16:43 --> URI Class Initialized
INFO - 2016-12-01 14:16:43 --> Router Class Initialized
INFO - 2016-12-01 14:16:43 --> Output Class Initialized
INFO - 2016-12-01 14:16:43 --> Security Class Initialized
DEBUG - 2016-12-01 14:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:16:43 --> Input Class Initialized
INFO - 2016-12-01 14:16:43 --> Language Class Initialized
ERROR - 2016-12-01 14:16:43 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:16:43 --> URI Class Initialized
INFO - 2016-12-01 14:16:43 --> Router Class Initialized
INFO - 2016-12-01 14:16:43 --> Output Class Initialized
INFO - 2016-12-01 14:16:43 --> Security Class Initialized
DEBUG - 2016-12-01 14:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:16:43 --> Input Class Initialized
INFO - 2016-12-01 14:16:43 --> Language Class Initialized
ERROR - 2016-12-01 14:16:43 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:16:43 --> Config Class Initialized
INFO - 2016-12-01 14:16:43 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:16:43 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:16:43 --> Utf8 Class Initialized
INFO - 2016-12-01 14:16:43 --> URI Class Initialized
INFO - 2016-12-01 14:16:43 --> Router Class Initialized
INFO - 2016-12-01 14:16:43 --> Output Class Initialized
INFO - 2016-12-01 14:16:43 --> Security Class Initialized
DEBUG - 2016-12-01 14:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:16:43 --> Input Class Initialized
INFO - 2016-12-01 14:16:43 --> Language Class Initialized
INFO - 2016-12-01 14:16:43 --> Loader Class Initialized
INFO - 2016-12-01 14:16:43 --> Database Driver Class Initialized
INFO - 2016-12-01 14:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:16:43 --> Controller Class Initialized
INFO - 2016-12-01 14:16:43 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:16:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:16:43 --> Final output sent to browser
DEBUG - 2016-12-01 14:16:43 --> Total execution time: 0.0129
INFO - 2016-12-01 14:17:03 --> Config Class Initialized
INFO - 2016-12-01 14:17:03 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:17:03 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:17:03 --> Utf8 Class Initialized
INFO - 2016-12-01 14:17:03 --> URI Class Initialized
DEBUG - 2016-12-01 14:17:03 --> No URI present. Default controller set.
INFO - 2016-12-01 14:17:03 --> Router Class Initialized
INFO - 2016-12-01 14:17:03 --> Output Class Initialized
INFO - 2016-12-01 14:17:03 --> Security Class Initialized
DEBUG - 2016-12-01 14:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:17:03 --> Input Class Initialized
INFO - 2016-12-01 14:17:03 --> Language Class Initialized
INFO - 2016-12-01 14:17:03 --> Loader Class Initialized
INFO - 2016-12-01 14:17:03 --> Database Driver Class Initialized
INFO - 2016-12-01 14:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:17:03 --> Controller Class Initialized
INFO - 2016-12-01 14:17:03 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:17:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:17:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:17:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:17:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:17:03 --> Final output sent to browser
DEBUG - 2016-12-01 14:17:03 --> Total execution time: 0.0499
INFO - 2016-12-01 14:17:03 --> Config Class Initialized
INFO - 2016-12-01 14:17:03 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:17:03 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:17:03 --> Utf8 Class Initialized
INFO - 2016-12-01 14:17:03 --> Config Class Initialized
INFO - 2016-12-01 14:17:03 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:17:03 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:17:03 --> Utf8 Class Initialized
INFO - 2016-12-01 14:17:03 --> URI Class Initialized
INFO - 2016-12-01 14:17:03 --> Router Class Initialized
INFO - 2016-12-01 14:17:03 --> Output Class Initialized
INFO - 2016-12-01 14:17:03 --> Security Class Initialized
DEBUG - 2016-12-01 14:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:17:03 --> Input Class Initialized
INFO - 2016-12-01 14:17:03 --> Language Class Initialized
ERROR - 2016-12-01 14:17:03 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:17:03 --> URI Class Initialized
INFO - 2016-12-01 14:17:03 --> Router Class Initialized
INFO - 2016-12-01 14:17:03 --> Output Class Initialized
INFO - 2016-12-01 14:17:03 --> Security Class Initialized
DEBUG - 2016-12-01 14:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:17:03 --> Input Class Initialized
INFO - 2016-12-01 14:17:03 --> Language Class Initialized
ERROR - 2016-12-01 14:17:03 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:17:03 --> Config Class Initialized
INFO - 2016-12-01 14:17:03 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:17:03 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:17:03 --> Utf8 Class Initialized
INFO - 2016-12-01 14:17:03 --> URI Class Initialized
INFO - 2016-12-01 14:17:03 --> Router Class Initialized
INFO - 2016-12-01 14:17:03 --> Output Class Initialized
INFO - 2016-12-01 14:17:03 --> Security Class Initialized
DEBUG - 2016-12-01 14:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:17:03 --> Input Class Initialized
INFO - 2016-12-01 14:17:03 --> Language Class Initialized
INFO - 2016-12-01 14:17:03 --> Loader Class Initialized
INFO - 2016-12-01 14:17:03 --> Database Driver Class Initialized
INFO - 2016-12-01 14:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:17:03 --> Controller Class Initialized
INFO - 2016-12-01 14:17:03 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:17:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:17:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:17:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:17:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:17:03 --> Final output sent to browser
DEBUG - 2016-12-01 14:17:03 --> Total execution time: 0.0132
INFO - 2016-12-01 14:17:05 --> Config Class Initialized
INFO - 2016-12-01 14:17:05 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:17:05 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:17:05 --> Utf8 Class Initialized
INFO - 2016-12-01 14:17:05 --> URI Class Initialized
DEBUG - 2016-12-01 14:17:05 --> No URI present. Default controller set.
INFO - 2016-12-01 14:17:05 --> Router Class Initialized
INFO - 2016-12-01 14:17:05 --> Output Class Initialized
INFO - 2016-12-01 14:17:05 --> Security Class Initialized
DEBUG - 2016-12-01 14:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:17:05 --> Input Class Initialized
INFO - 2016-12-01 14:17:05 --> Language Class Initialized
INFO - 2016-12-01 14:17:05 --> Loader Class Initialized
INFO - 2016-12-01 14:17:05 --> Database Driver Class Initialized
INFO - 2016-12-01 14:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:17:05 --> Controller Class Initialized
INFO - 2016-12-01 14:17:05 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:17:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:17:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:17:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:17:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:17:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:17:05 --> Final output sent to browser
DEBUG - 2016-12-01 14:17:05 --> Total execution time: 0.0127
INFO - 2016-12-01 14:17:05 --> Config Class Initialized
INFO - 2016-12-01 14:17:05 --> Hooks Class Initialized
INFO - 2016-12-01 14:17:05 --> Config Class Initialized
INFO - 2016-12-01 14:17:05 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:17:05 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:17:05 --> Utf8 Class Initialized
DEBUG - 2016-12-01 14:17:05 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:17:05 --> Utf8 Class Initialized
INFO - 2016-12-01 14:17:05 --> URI Class Initialized
INFO - 2016-12-01 14:17:05 --> URI Class Initialized
INFO - 2016-12-01 14:17:05 --> Router Class Initialized
INFO - 2016-12-01 14:17:05 --> Router Class Initialized
INFO - 2016-12-01 14:17:05 --> Output Class Initialized
INFO - 2016-12-01 14:17:05 --> Security Class Initialized
DEBUG - 2016-12-01 14:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:17:05 --> Input Class Initialized
INFO - 2016-12-01 14:17:05 --> Language Class Initialized
ERROR - 2016-12-01 14:17:05 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:17:05 --> Output Class Initialized
INFO - 2016-12-01 14:17:05 --> Security Class Initialized
DEBUG - 2016-12-01 14:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:17:05 --> Input Class Initialized
INFO - 2016-12-01 14:17:05 --> Language Class Initialized
ERROR - 2016-12-01 14:17:05 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:17:05 --> Config Class Initialized
INFO - 2016-12-01 14:17:05 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:17:05 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:17:05 --> Utf8 Class Initialized
INFO - 2016-12-01 14:17:05 --> URI Class Initialized
INFO - 2016-12-01 14:17:05 --> Router Class Initialized
INFO - 2016-12-01 14:17:05 --> Output Class Initialized
INFO - 2016-12-01 14:17:05 --> Security Class Initialized
DEBUG - 2016-12-01 14:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:17:05 --> Input Class Initialized
INFO - 2016-12-01 14:17:05 --> Language Class Initialized
INFO - 2016-12-01 14:17:05 --> Loader Class Initialized
INFO - 2016-12-01 14:17:05 --> Database Driver Class Initialized
INFO - 2016-12-01 14:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:17:05 --> Controller Class Initialized
INFO - 2016-12-01 14:17:05 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:17:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:17:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:17:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:17:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:17:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:17:05 --> Final output sent to browser
DEBUG - 2016-12-01 14:17:05 --> Total execution time: 0.0134
INFO - 2016-12-01 14:17:52 --> Config Class Initialized
INFO - 2016-12-01 14:17:52 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:17:52 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:17:52 --> Utf8 Class Initialized
INFO - 2016-12-01 14:17:52 --> URI Class Initialized
DEBUG - 2016-12-01 14:17:52 --> No URI present. Default controller set.
INFO - 2016-12-01 14:17:52 --> Router Class Initialized
INFO - 2016-12-01 14:17:52 --> Output Class Initialized
INFO - 2016-12-01 14:17:52 --> Security Class Initialized
DEBUG - 2016-12-01 14:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:17:52 --> Input Class Initialized
INFO - 2016-12-01 14:17:52 --> Language Class Initialized
INFO - 2016-12-01 14:17:52 --> Loader Class Initialized
INFO - 2016-12-01 14:17:52 --> Database Driver Class Initialized
INFO - 2016-12-01 14:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:17:52 --> Controller Class Initialized
INFO - 2016-12-01 14:17:52 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:17:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:17:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:17:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:17:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:17:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:17:52 --> Final output sent to browser
DEBUG - 2016-12-01 14:17:52 --> Total execution time: 0.0133
INFO - 2016-12-01 14:17:52 --> Config Class Initialized
INFO - 2016-12-01 14:17:52 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:17:52 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:17:52 --> Utf8 Class Initialized
INFO - 2016-12-01 14:17:52 --> URI Class Initialized
INFO - 2016-12-01 14:17:52 --> Router Class Initialized
INFO - 2016-12-01 14:17:52 --> Output Class Initialized
INFO - 2016-12-01 14:17:52 --> Security Class Initialized
DEBUG - 2016-12-01 14:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:17:52 --> Input Class Initialized
INFO - 2016-12-01 14:17:52 --> Language Class Initialized
ERROR - 2016-12-01 14:17:52 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:17:52 --> Config Class Initialized
INFO - 2016-12-01 14:17:52 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:17:52 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:17:52 --> Utf8 Class Initialized
INFO - 2016-12-01 14:17:52 --> URI Class Initialized
INFO - 2016-12-01 14:17:52 --> Router Class Initialized
INFO - 2016-12-01 14:17:52 --> Output Class Initialized
INFO - 2016-12-01 14:17:52 --> Security Class Initialized
DEBUG - 2016-12-01 14:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:17:52 --> Input Class Initialized
INFO - 2016-12-01 14:17:52 --> Language Class Initialized
ERROR - 2016-12-01 14:17:52 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:17:52 --> Config Class Initialized
INFO - 2016-12-01 14:17:52 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:17:52 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:17:52 --> Utf8 Class Initialized
INFO - 2016-12-01 14:17:52 --> URI Class Initialized
INFO - 2016-12-01 14:17:52 --> Router Class Initialized
INFO - 2016-12-01 14:17:52 --> Output Class Initialized
INFO - 2016-12-01 14:17:52 --> Security Class Initialized
DEBUG - 2016-12-01 14:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:17:52 --> Input Class Initialized
INFO - 2016-12-01 14:17:52 --> Language Class Initialized
INFO - 2016-12-01 14:17:52 --> Loader Class Initialized
INFO - 2016-12-01 14:17:52 --> Database Driver Class Initialized
INFO - 2016-12-01 14:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:17:52 --> Controller Class Initialized
INFO - 2016-12-01 14:17:52 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:17:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:17:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:17:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:17:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:17:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:17:52 --> Final output sent to browser
DEBUG - 2016-12-01 14:17:52 --> Total execution time: 0.0133
INFO - 2016-12-01 14:18:12 --> Config Class Initialized
INFO - 2016-12-01 14:18:12 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:18:12 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:18:12 --> Utf8 Class Initialized
INFO - 2016-12-01 14:18:12 --> URI Class Initialized
DEBUG - 2016-12-01 14:18:12 --> No URI present. Default controller set.
INFO - 2016-12-01 14:18:12 --> Router Class Initialized
INFO - 2016-12-01 14:18:12 --> Output Class Initialized
INFO - 2016-12-01 14:18:12 --> Security Class Initialized
DEBUG - 2016-12-01 14:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:18:12 --> Input Class Initialized
INFO - 2016-12-01 14:18:12 --> Language Class Initialized
INFO - 2016-12-01 14:18:12 --> Loader Class Initialized
INFO - 2016-12-01 14:18:12 --> Database Driver Class Initialized
INFO - 2016-12-01 14:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:18:12 --> Controller Class Initialized
INFO - 2016-12-01 14:18:12 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:18:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:18:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:18:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:18:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:18:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:18:12 --> Final output sent to browser
DEBUG - 2016-12-01 14:18:12 --> Total execution time: 0.0133
INFO - 2016-12-01 14:18:12 --> Config Class Initialized
INFO - 2016-12-01 14:18:12 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:18:12 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:18:12 --> Utf8 Class Initialized
INFO - 2016-12-01 14:18:12 --> URI Class Initialized
INFO - 2016-12-01 14:18:12 --> Router Class Initialized
INFO - 2016-12-01 14:18:12 --> Output Class Initialized
INFO - 2016-12-01 14:18:12 --> Security Class Initialized
DEBUG - 2016-12-01 14:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:18:12 --> Input Class Initialized
INFO - 2016-12-01 14:18:12 --> Language Class Initialized
ERROR - 2016-12-01 14:18:12 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:18:12 --> Config Class Initialized
INFO - 2016-12-01 14:18:12 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:18:12 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:18:12 --> Utf8 Class Initialized
INFO - 2016-12-01 14:18:12 --> URI Class Initialized
INFO - 2016-12-01 14:18:12 --> Router Class Initialized
INFO - 2016-12-01 14:18:12 --> Output Class Initialized
INFO - 2016-12-01 14:18:12 --> Security Class Initialized
DEBUG - 2016-12-01 14:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:18:12 --> Input Class Initialized
INFO - 2016-12-01 14:18:12 --> Language Class Initialized
ERROR - 2016-12-01 14:18:12 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:18:12 --> Config Class Initialized
INFO - 2016-12-01 14:18:12 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:18:12 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:18:12 --> Utf8 Class Initialized
INFO - 2016-12-01 14:18:12 --> URI Class Initialized
INFO - 2016-12-01 14:18:12 --> Router Class Initialized
INFO - 2016-12-01 14:18:12 --> Output Class Initialized
INFO - 2016-12-01 14:18:12 --> Security Class Initialized
DEBUG - 2016-12-01 14:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:18:12 --> Input Class Initialized
INFO - 2016-12-01 14:18:12 --> Language Class Initialized
INFO - 2016-12-01 14:18:12 --> Loader Class Initialized
INFO - 2016-12-01 14:18:12 --> Database Driver Class Initialized
INFO - 2016-12-01 14:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:18:12 --> Controller Class Initialized
INFO - 2016-12-01 14:18:12 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:18:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:18:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:18:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:18:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:18:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:18:12 --> Final output sent to browser
DEBUG - 2016-12-01 14:18:12 --> Total execution time: 0.0134
INFO - 2016-12-01 14:19:09 --> Config Class Initialized
INFO - 2016-12-01 14:19:09 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:19:09 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:19:09 --> Utf8 Class Initialized
INFO - 2016-12-01 14:19:09 --> URI Class Initialized
DEBUG - 2016-12-01 14:19:09 --> No URI present. Default controller set.
INFO - 2016-12-01 14:19:09 --> Router Class Initialized
INFO - 2016-12-01 14:19:09 --> Output Class Initialized
INFO - 2016-12-01 14:19:09 --> Security Class Initialized
DEBUG - 2016-12-01 14:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:19:09 --> Input Class Initialized
INFO - 2016-12-01 14:19:09 --> Language Class Initialized
INFO - 2016-12-01 14:19:09 --> Loader Class Initialized
INFO - 2016-12-01 14:19:09 --> Database Driver Class Initialized
INFO - 2016-12-01 14:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:19:09 --> Controller Class Initialized
INFO - 2016-12-01 14:19:09 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:19:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:19:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:19:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:19:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:19:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:19:09 --> Final output sent to browser
DEBUG - 2016-12-01 14:19:09 --> Total execution time: 0.0129
INFO - 2016-12-01 14:19:09 --> Config Class Initialized
INFO - 2016-12-01 14:19:09 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:19:09 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:19:09 --> Utf8 Class Initialized
INFO - 2016-12-01 14:19:09 --> URI Class Initialized
INFO - 2016-12-01 14:19:09 --> Router Class Initialized
INFO - 2016-12-01 14:19:09 --> Output Class Initialized
INFO - 2016-12-01 14:19:09 --> Security Class Initialized
DEBUG - 2016-12-01 14:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:19:09 --> Input Class Initialized
INFO - 2016-12-01 14:19:09 --> Language Class Initialized
ERROR - 2016-12-01 14:19:09 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:19:09 --> Config Class Initialized
INFO - 2016-12-01 14:19:09 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:19:09 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:19:09 --> Utf8 Class Initialized
INFO - 2016-12-01 14:19:09 --> URI Class Initialized
INFO - 2016-12-01 14:19:09 --> Router Class Initialized
INFO - 2016-12-01 14:19:09 --> Output Class Initialized
INFO - 2016-12-01 14:19:09 --> Security Class Initialized
DEBUG - 2016-12-01 14:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:19:09 --> Input Class Initialized
INFO - 2016-12-01 14:19:09 --> Language Class Initialized
ERROR - 2016-12-01 14:19:09 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:19:09 --> Config Class Initialized
INFO - 2016-12-01 14:19:09 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:19:09 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:19:09 --> Utf8 Class Initialized
INFO - 2016-12-01 14:19:09 --> URI Class Initialized
INFO - 2016-12-01 14:19:09 --> Router Class Initialized
INFO - 2016-12-01 14:19:09 --> Output Class Initialized
INFO - 2016-12-01 14:19:09 --> Security Class Initialized
DEBUG - 2016-12-01 14:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:19:09 --> Input Class Initialized
INFO - 2016-12-01 14:19:09 --> Language Class Initialized
INFO - 2016-12-01 14:19:09 --> Loader Class Initialized
INFO - 2016-12-01 14:19:09 --> Database Driver Class Initialized
INFO - 2016-12-01 14:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:19:09 --> Controller Class Initialized
INFO - 2016-12-01 14:19:09 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:19:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:19:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:19:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:19:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:19:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:19:09 --> Final output sent to browser
DEBUG - 2016-12-01 14:19:09 --> Total execution time: 0.0133
INFO - 2016-12-01 14:20:32 --> Config Class Initialized
INFO - 2016-12-01 14:20:32 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:20:32 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:20:32 --> Utf8 Class Initialized
INFO - 2016-12-01 14:20:32 --> URI Class Initialized
DEBUG - 2016-12-01 14:20:32 --> No URI present. Default controller set.
INFO - 2016-12-01 14:20:32 --> Router Class Initialized
INFO - 2016-12-01 14:20:32 --> Output Class Initialized
INFO - 2016-12-01 14:20:32 --> Security Class Initialized
DEBUG - 2016-12-01 14:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:20:32 --> Input Class Initialized
INFO - 2016-12-01 14:20:32 --> Language Class Initialized
INFO - 2016-12-01 14:20:32 --> Loader Class Initialized
INFO - 2016-12-01 14:20:32 --> Database Driver Class Initialized
INFO - 2016-12-01 14:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:20:32 --> Controller Class Initialized
INFO - 2016-12-01 14:20:32 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:20:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:20:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:20:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:20:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:20:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:20:32 --> Final output sent to browser
DEBUG - 2016-12-01 14:20:32 --> Total execution time: 0.0135
INFO - 2016-12-01 14:20:32 --> Config Class Initialized
INFO - 2016-12-01 14:20:32 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:20:32 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:20:32 --> Utf8 Class Initialized
INFO - 2016-12-01 14:20:32 --> URI Class Initialized
INFO - 2016-12-01 14:20:32 --> Router Class Initialized
INFO - 2016-12-01 14:20:32 --> Output Class Initialized
INFO - 2016-12-01 14:20:32 --> Security Class Initialized
DEBUG - 2016-12-01 14:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:20:32 --> Input Class Initialized
INFO - 2016-12-01 14:20:32 --> Language Class Initialized
ERROR - 2016-12-01 14:20:32 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:20:32 --> Config Class Initialized
INFO - 2016-12-01 14:20:32 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:20:32 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:20:32 --> Utf8 Class Initialized
INFO - 2016-12-01 14:20:32 --> URI Class Initialized
INFO - 2016-12-01 14:20:32 --> Router Class Initialized
INFO - 2016-12-01 14:20:32 --> Output Class Initialized
INFO - 2016-12-01 14:20:32 --> Security Class Initialized
DEBUG - 2016-12-01 14:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:20:32 --> Input Class Initialized
INFO - 2016-12-01 14:20:32 --> Language Class Initialized
ERROR - 2016-12-01 14:20:32 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:20:32 --> Config Class Initialized
INFO - 2016-12-01 14:20:32 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:20:32 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:20:32 --> Utf8 Class Initialized
INFO - 2016-12-01 14:20:32 --> URI Class Initialized
INFO - 2016-12-01 14:20:32 --> Router Class Initialized
INFO - 2016-12-01 14:20:32 --> Output Class Initialized
INFO - 2016-12-01 14:20:32 --> Security Class Initialized
DEBUG - 2016-12-01 14:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:20:32 --> Input Class Initialized
INFO - 2016-12-01 14:20:32 --> Language Class Initialized
INFO - 2016-12-01 14:20:32 --> Loader Class Initialized
INFO - 2016-12-01 14:20:32 --> Database Driver Class Initialized
INFO - 2016-12-01 14:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:20:32 --> Controller Class Initialized
INFO - 2016-12-01 14:20:32 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:20:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:20:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:20:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:20:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:20:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:20:32 --> Final output sent to browser
DEBUG - 2016-12-01 14:20:32 --> Total execution time: 0.0144
INFO - 2016-12-01 14:21:26 --> Config Class Initialized
INFO - 2016-12-01 14:21:26 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:21:26 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:21:26 --> Utf8 Class Initialized
INFO - 2016-12-01 14:21:26 --> URI Class Initialized
DEBUG - 2016-12-01 14:21:26 --> No URI present. Default controller set.
INFO - 2016-12-01 14:21:26 --> Router Class Initialized
INFO - 2016-12-01 14:21:26 --> Output Class Initialized
INFO - 2016-12-01 14:21:26 --> Security Class Initialized
DEBUG - 2016-12-01 14:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:21:26 --> Input Class Initialized
INFO - 2016-12-01 14:21:26 --> Language Class Initialized
INFO - 2016-12-01 14:21:26 --> Loader Class Initialized
INFO - 2016-12-01 14:21:26 --> Database Driver Class Initialized
INFO - 2016-12-01 14:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:21:26 --> Controller Class Initialized
INFO - 2016-12-01 14:21:26 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:21:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:21:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:21:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:21:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:21:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:21:26 --> Final output sent to browser
DEBUG - 2016-12-01 14:21:26 --> Total execution time: 0.0132
INFO - 2016-12-01 14:21:26 --> Config Class Initialized
INFO - 2016-12-01 14:21:26 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:21:26 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:21:26 --> Utf8 Class Initialized
INFO - 2016-12-01 14:21:26 --> URI Class Initialized
INFO - 2016-12-01 14:21:26 --> Router Class Initialized
INFO - 2016-12-01 14:21:26 --> Output Class Initialized
INFO - 2016-12-01 14:21:26 --> Security Class Initialized
DEBUG - 2016-12-01 14:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:21:26 --> Input Class Initialized
INFO - 2016-12-01 14:21:26 --> Language Class Initialized
INFO - 2016-12-01 14:21:26 --> Config Class Initialized
INFO - 2016-12-01 14:21:26 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:21:26 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:21:26 --> Utf8 Class Initialized
INFO - 2016-12-01 14:21:26 --> URI Class Initialized
INFO - 2016-12-01 14:21:26 --> Router Class Initialized
INFO - 2016-12-01 14:21:26 --> Output Class Initialized
INFO - 2016-12-01 14:21:26 --> Security Class Initialized
DEBUG - 2016-12-01 14:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:21:26 --> Input Class Initialized
INFO - 2016-12-01 14:21:26 --> Language Class Initialized
ERROR - 2016-12-01 14:21:26 --> 404 Page Not Found: Img/portfolio
ERROR - 2016-12-01 14:21:26 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:21:26 --> Config Class Initialized
INFO - 2016-12-01 14:21:26 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:21:26 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:21:26 --> Utf8 Class Initialized
INFO - 2016-12-01 14:21:26 --> URI Class Initialized
INFO - 2016-12-01 14:21:26 --> Router Class Initialized
INFO - 2016-12-01 14:21:26 --> Output Class Initialized
INFO - 2016-12-01 14:21:26 --> Security Class Initialized
DEBUG - 2016-12-01 14:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:21:26 --> Input Class Initialized
INFO - 2016-12-01 14:21:26 --> Language Class Initialized
INFO - 2016-12-01 14:21:26 --> Loader Class Initialized
INFO - 2016-12-01 14:21:26 --> Database Driver Class Initialized
INFO - 2016-12-01 14:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:21:26 --> Controller Class Initialized
INFO - 2016-12-01 14:21:26 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:21:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:21:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:21:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:21:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:21:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:21:26 --> Final output sent to browser
DEBUG - 2016-12-01 14:21:26 --> Total execution time: 0.0132
INFO - 2016-12-01 14:21:47 --> Config Class Initialized
INFO - 2016-12-01 14:21:47 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:21:47 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:21:47 --> Utf8 Class Initialized
INFO - 2016-12-01 14:21:47 --> URI Class Initialized
DEBUG - 2016-12-01 14:21:47 --> No URI present. Default controller set.
INFO - 2016-12-01 14:21:47 --> Router Class Initialized
INFO - 2016-12-01 14:21:47 --> Output Class Initialized
INFO - 2016-12-01 14:21:47 --> Security Class Initialized
DEBUG - 2016-12-01 14:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:21:47 --> Input Class Initialized
INFO - 2016-12-01 14:21:47 --> Language Class Initialized
INFO - 2016-12-01 14:21:47 --> Loader Class Initialized
INFO - 2016-12-01 14:21:47 --> Database Driver Class Initialized
INFO - 2016-12-01 14:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:21:47 --> Controller Class Initialized
INFO - 2016-12-01 14:21:47 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:21:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:21:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:21:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:21:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:21:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:21:47 --> Final output sent to browser
DEBUG - 2016-12-01 14:21:47 --> Total execution time: 0.0130
INFO - 2016-12-01 14:21:47 --> Config Class Initialized
INFO - 2016-12-01 14:21:47 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:21:47 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:21:47 --> Utf8 Class Initialized
INFO - 2016-12-01 14:21:47 --> URI Class Initialized
INFO - 2016-12-01 14:21:47 --> Router Class Initialized
INFO - 2016-12-01 14:21:47 --> Output Class Initialized
INFO - 2016-12-01 14:21:47 --> Security Class Initialized
DEBUG - 2016-12-01 14:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:21:47 --> Input Class Initialized
INFO - 2016-12-01 14:21:47 --> Language Class Initialized
ERROR - 2016-12-01 14:21:47 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:21:47 --> Config Class Initialized
INFO - 2016-12-01 14:21:47 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:21:47 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:21:47 --> Utf8 Class Initialized
INFO - 2016-12-01 14:21:47 --> URI Class Initialized
INFO - 2016-12-01 14:21:47 --> Router Class Initialized
INFO - 2016-12-01 14:21:47 --> Output Class Initialized
INFO - 2016-12-01 14:21:47 --> Security Class Initialized
DEBUG - 2016-12-01 14:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:21:47 --> Input Class Initialized
INFO - 2016-12-01 14:21:47 --> Language Class Initialized
ERROR - 2016-12-01 14:21:47 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:21:47 --> Config Class Initialized
INFO - 2016-12-01 14:21:47 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:21:47 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:21:47 --> Utf8 Class Initialized
INFO - 2016-12-01 14:21:47 --> URI Class Initialized
INFO - 2016-12-01 14:21:47 --> Router Class Initialized
INFO - 2016-12-01 14:21:47 --> Output Class Initialized
INFO - 2016-12-01 14:21:47 --> Security Class Initialized
DEBUG - 2016-12-01 14:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:21:47 --> Input Class Initialized
INFO - 2016-12-01 14:21:47 --> Language Class Initialized
INFO - 2016-12-01 14:21:47 --> Loader Class Initialized
INFO - 2016-12-01 14:21:47 --> Database Driver Class Initialized
INFO - 2016-12-01 14:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:21:47 --> Controller Class Initialized
INFO - 2016-12-01 14:21:47 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:21:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:21:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:21:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:21:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:21:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:21:47 --> Final output sent to browser
DEBUG - 2016-12-01 14:21:47 --> Total execution time: 0.0134
INFO - 2016-12-01 14:21:49 --> Config Class Initialized
INFO - 2016-12-01 14:21:49 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:21:49 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:21:49 --> Utf8 Class Initialized
INFO - 2016-12-01 14:21:49 --> URI Class Initialized
DEBUG - 2016-12-01 14:21:49 --> No URI present. Default controller set.
INFO - 2016-12-01 14:21:49 --> Router Class Initialized
INFO - 2016-12-01 14:21:49 --> Output Class Initialized
INFO - 2016-12-01 14:21:49 --> Security Class Initialized
DEBUG - 2016-12-01 14:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:21:49 --> Input Class Initialized
INFO - 2016-12-01 14:21:49 --> Language Class Initialized
INFO - 2016-12-01 14:21:49 --> Loader Class Initialized
INFO - 2016-12-01 14:21:49 --> Database Driver Class Initialized
INFO - 2016-12-01 14:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:21:49 --> Controller Class Initialized
INFO - 2016-12-01 14:21:49 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:21:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:21:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:21:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:21:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:21:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:21:49 --> Final output sent to browser
DEBUG - 2016-12-01 14:21:49 --> Total execution time: 0.0132
INFO - 2016-12-01 14:21:49 --> Config Class Initialized
INFO - 2016-12-01 14:21:49 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:21:49 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:21:49 --> Utf8 Class Initialized
INFO - 2016-12-01 14:21:49 --> URI Class Initialized
INFO - 2016-12-01 14:21:49 --> Router Class Initialized
INFO - 2016-12-01 14:21:49 --> Output Class Initialized
INFO - 2016-12-01 14:21:49 --> Security Class Initialized
DEBUG - 2016-12-01 14:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:21:49 --> Input Class Initialized
INFO - 2016-12-01 14:21:49 --> Language Class Initialized
ERROR - 2016-12-01 14:21:49 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:21:49 --> Config Class Initialized
INFO - 2016-12-01 14:21:49 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:21:49 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:21:49 --> Utf8 Class Initialized
INFO - 2016-12-01 14:21:49 --> URI Class Initialized
INFO - 2016-12-01 14:21:49 --> Router Class Initialized
INFO - 2016-12-01 14:21:49 --> Output Class Initialized
INFO - 2016-12-01 14:21:49 --> Security Class Initialized
DEBUG - 2016-12-01 14:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:21:49 --> Input Class Initialized
INFO - 2016-12-01 14:21:49 --> Language Class Initialized
ERROR - 2016-12-01 14:21:49 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:21:49 --> Config Class Initialized
INFO - 2016-12-01 14:21:49 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:21:49 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:21:49 --> Utf8 Class Initialized
INFO - 2016-12-01 14:21:49 --> URI Class Initialized
INFO - 2016-12-01 14:21:49 --> Router Class Initialized
INFO - 2016-12-01 14:21:49 --> Output Class Initialized
INFO - 2016-12-01 14:21:49 --> Security Class Initialized
DEBUG - 2016-12-01 14:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:21:49 --> Input Class Initialized
INFO - 2016-12-01 14:21:49 --> Language Class Initialized
INFO - 2016-12-01 14:21:49 --> Loader Class Initialized
INFO - 2016-12-01 14:21:49 --> Database Driver Class Initialized
INFO - 2016-12-01 14:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:21:49 --> Controller Class Initialized
INFO - 2016-12-01 14:21:49 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:21:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:21:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:21:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:21:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:21:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:21:49 --> Final output sent to browser
DEBUG - 2016-12-01 14:21:49 --> Total execution time: 0.0134
INFO - 2016-12-01 14:22:22 --> Config Class Initialized
INFO - 2016-12-01 14:22:22 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:22:22 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:22:22 --> Utf8 Class Initialized
INFO - 2016-12-01 14:22:22 --> URI Class Initialized
DEBUG - 2016-12-01 14:22:22 --> No URI present. Default controller set.
INFO - 2016-12-01 14:22:22 --> Router Class Initialized
INFO - 2016-12-01 14:22:22 --> Output Class Initialized
INFO - 2016-12-01 14:22:22 --> Security Class Initialized
DEBUG - 2016-12-01 14:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:22:22 --> Input Class Initialized
INFO - 2016-12-01 14:22:22 --> Language Class Initialized
INFO - 2016-12-01 14:22:22 --> Loader Class Initialized
INFO - 2016-12-01 14:22:22 --> Database Driver Class Initialized
INFO - 2016-12-01 14:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:22:22 --> Controller Class Initialized
INFO - 2016-12-01 14:22:22 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:22:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:22:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:22:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:22:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:22:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:22:22 --> Final output sent to browser
DEBUG - 2016-12-01 14:22:22 --> Total execution time: 0.0135
INFO - 2016-12-01 14:22:23 --> Config Class Initialized
INFO - 2016-12-01 14:22:23 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:22:23 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:22:23 --> Utf8 Class Initialized
INFO - 2016-12-01 14:22:23 --> URI Class Initialized
INFO - 2016-12-01 14:22:23 --> Router Class Initialized
INFO - 2016-12-01 14:22:23 --> Output Class Initialized
INFO - 2016-12-01 14:22:23 --> Security Class Initialized
DEBUG - 2016-12-01 14:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:22:23 --> Input Class Initialized
INFO - 2016-12-01 14:22:23 --> Language Class Initialized
ERROR - 2016-12-01 14:22:23 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:22:23 --> Config Class Initialized
INFO - 2016-12-01 14:22:23 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:22:23 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:22:23 --> Utf8 Class Initialized
INFO - 2016-12-01 14:22:23 --> URI Class Initialized
INFO - 2016-12-01 14:22:23 --> Router Class Initialized
INFO - 2016-12-01 14:22:23 --> Output Class Initialized
INFO - 2016-12-01 14:22:23 --> Security Class Initialized
DEBUG - 2016-12-01 14:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:22:23 --> Input Class Initialized
INFO - 2016-12-01 14:22:23 --> Language Class Initialized
ERROR - 2016-12-01 14:22:23 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:22:23 --> Config Class Initialized
INFO - 2016-12-01 14:22:23 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:22:23 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:22:23 --> Utf8 Class Initialized
INFO - 2016-12-01 14:22:23 --> URI Class Initialized
INFO - 2016-12-01 14:22:23 --> Router Class Initialized
INFO - 2016-12-01 14:22:23 --> Output Class Initialized
INFO - 2016-12-01 14:22:23 --> Security Class Initialized
DEBUG - 2016-12-01 14:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:22:23 --> Input Class Initialized
INFO - 2016-12-01 14:22:23 --> Language Class Initialized
INFO - 2016-12-01 14:22:23 --> Loader Class Initialized
INFO - 2016-12-01 14:22:23 --> Database Driver Class Initialized
INFO - 2016-12-01 14:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:22:23 --> Controller Class Initialized
INFO - 2016-12-01 14:22:23 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:22:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:22:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:22:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:22:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:22:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:22:23 --> Final output sent to browser
DEBUG - 2016-12-01 14:22:23 --> Total execution time: 0.0134
INFO - 2016-12-01 14:22:32 --> Config Class Initialized
INFO - 2016-12-01 14:22:32 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:22:32 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:22:32 --> Utf8 Class Initialized
INFO - 2016-12-01 14:22:32 --> URI Class Initialized
DEBUG - 2016-12-01 14:22:32 --> No URI present. Default controller set.
INFO - 2016-12-01 14:22:32 --> Router Class Initialized
INFO - 2016-12-01 14:22:32 --> Output Class Initialized
INFO - 2016-12-01 14:22:32 --> Security Class Initialized
DEBUG - 2016-12-01 14:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:22:32 --> Input Class Initialized
INFO - 2016-12-01 14:22:32 --> Language Class Initialized
INFO - 2016-12-01 14:22:32 --> Loader Class Initialized
INFO - 2016-12-01 14:22:32 --> Database Driver Class Initialized
INFO - 2016-12-01 14:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:22:32 --> Controller Class Initialized
INFO - 2016-12-01 14:22:32 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:22:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:22:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:22:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:22:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:22:32 --> Final output sent to browser
DEBUG - 2016-12-01 14:22:32 --> Total execution time: 0.0149
INFO - 2016-12-01 14:22:33 --> Config Class Initialized
INFO - 2016-12-01 14:22:33 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:22:33 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:22:33 --> Utf8 Class Initialized
INFO - 2016-12-01 14:22:33 --> URI Class Initialized
INFO - 2016-12-01 14:22:33 --> Router Class Initialized
INFO - 2016-12-01 14:22:33 --> Output Class Initialized
INFO - 2016-12-01 14:22:33 --> Security Class Initialized
DEBUG - 2016-12-01 14:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:22:33 --> Input Class Initialized
INFO - 2016-12-01 14:22:33 --> Language Class Initialized
ERROR - 2016-12-01 14:22:33 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:22:33 --> Config Class Initialized
INFO - 2016-12-01 14:22:33 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:22:33 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:22:33 --> Utf8 Class Initialized
INFO - 2016-12-01 14:22:33 --> URI Class Initialized
INFO - 2016-12-01 14:22:33 --> Router Class Initialized
INFO - 2016-12-01 14:22:33 --> Output Class Initialized
INFO - 2016-12-01 14:22:33 --> Security Class Initialized
DEBUG - 2016-12-01 14:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:22:33 --> Input Class Initialized
INFO - 2016-12-01 14:22:33 --> Language Class Initialized
ERROR - 2016-12-01 14:22:33 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 14:22:33 --> Config Class Initialized
INFO - 2016-12-01 14:22:33 --> Hooks Class Initialized
DEBUG - 2016-12-01 14:22:33 --> UTF-8 Support Enabled
INFO - 2016-12-01 14:22:33 --> Utf8 Class Initialized
INFO - 2016-12-01 14:22:33 --> URI Class Initialized
INFO - 2016-12-01 14:22:33 --> Router Class Initialized
INFO - 2016-12-01 14:22:33 --> Output Class Initialized
INFO - 2016-12-01 14:22:33 --> Security Class Initialized
DEBUG - 2016-12-01 14:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 14:22:33 --> Input Class Initialized
INFO - 2016-12-01 14:22:33 --> Language Class Initialized
INFO - 2016-12-01 14:22:33 --> Loader Class Initialized
INFO - 2016-12-01 14:22:33 --> Database Driver Class Initialized
INFO - 2016-12-01 14:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 14:22:33 --> Controller Class Initialized
INFO - 2016-12-01 14:22:33 --> Helper loaded: url_helper
DEBUG - 2016-12-01 14:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 14:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 14:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 14:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 14:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 14:22:33 --> Final output sent to browser
DEBUG - 2016-12-01 14:22:33 --> Total execution time: 0.0153
INFO - 2016-12-01 16:51:50 --> Config Class Initialized
INFO - 2016-12-01 16:51:50 --> Hooks Class Initialized
DEBUG - 2016-12-01 16:51:50 --> UTF-8 Support Enabled
INFO - 2016-12-01 16:51:50 --> Utf8 Class Initialized
INFO - 2016-12-01 16:51:50 --> URI Class Initialized
DEBUG - 2016-12-01 16:51:50 --> No URI present. Default controller set.
INFO - 2016-12-01 16:51:50 --> Router Class Initialized
INFO - 2016-12-01 16:51:50 --> Output Class Initialized
INFO - 2016-12-01 16:51:50 --> Security Class Initialized
DEBUG - 2016-12-01 16:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 16:51:50 --> Input Class Initialized
INFO - 2016-12-01 16:51:50 --> Language Class Initialized
INFO - 2016-12-01 16:51:50 --> Loader Class Initialized
INFO - 2016-12-01 16:51:50 --> Database Driver Class Initialized
INFO - 2016-12-01 16:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 16:51:50 --> Controller Class Initialized
INFO - 2016-12-01 16:51:50 --> Helper loaded: url_helper
DEBUG - 2016-12-01 16:51:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 16:51:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 16:51:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 16:51:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 16:51:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 16:51:50 --> Final output sent to browser
DEBUG - 2016-12-01 16:51:50 --> Total execution time: 0.3165
INFO - 2016-12-01 16:51:51 --> Config Class Initialized
INFO - 2016-12-01 16:51:51 --> Hooks Class Initialized
DEBUG - 2016-12-01 16:51:51 --> UTF-8 Support Enabled
INFO - 2016-12-01 16:51:51 --> Utf8 Class Initialized
INFO - 2016-12-01 16:51:51 --> URI Class Initialized
INFO - 2016-12-01 16:51:51 --> Router Class Initialized
INFO - 2016-12-01 16:51:51 --> Output Class Initialized
INFO - 2016-12-01 16:51:51 --> Security Class Initialized
DEBUG - 2016-12-01 16:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 16:51:51 --> Input Class Initialized
INFO - 2016-12-01 16:51:51 --> Language Class Initialized
ERROR - 2016-12-01 16:51:51 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 16:51:51 --> Config Class Initialized
INFO - 2016-12-01 16:51:51 --> Hooks Class Initialized
DEBUG - 2016-12-01 16:51:51 --> UTF-8 Support Enabled
INFO - 2016-12-01 16:51:51 --> Utf8 Class Initialized
INFO - 2016-12-01 16:51:51 --> URI Class Initialized
INFO - 2016-12-01 16:51:51 --> Router Class Initialized
INFO - 2016-12-01 16:51:51 --> Output Class Initialized
INFO - 2016-12-01 16:51:51 --> Security Class Initialized
DEBUG - 2016-12-01 16:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 16:51:51 --> Input Class Initialized
INFO - 2016-12-01 16:51:51 --> Language Class Initialized
ERROR - 2016-12-01 16:51:51 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 16:51:52 --> Config Class Initialized
INFO - 2016-12-01 16:51:52 --> Hooks Class Initialized
DEBUG - 2016-12-01 16:51:52 --> UTF-8 Support Enabled
INFO - 2016-12-01 16:51:52 --> Utf8 Class Initialized
INFO - 2016-12-01 16:51:52 --> URI Class Initialized
INFO - 2016-12-01 16:51:52 --> Router Class Initialized
INFO - 2016-12-01 16:51:52 --> Output Class Initialized
INFO - 2016-12-01 16:51:52 --> Security Class Initialized
DEBUG - 2016-12-01 16:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 16:51:52 --> Input Class Initialized
INFO - 2016-12-01 16:51:52 --> Language Class Initialized
INFO - 2016-12-01 16:51:52 --> Loader Class Initialized
INFO - 2016-12-01 16:51:52 --> Database Driver Class Initialized
INFO - 2016-12-01 16:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 16:51:52 --> Controller Class Initialized
INFO - 2016-12-01 16:51:52 --> Helper loaded: url_helper
DEBUG - 2016-12-01 16:51:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 16:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 16:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 16:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 16:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 16:51:52 --> Final output sent to browser
DEBUG - 2016-12-01 16:51:52 --> Total execution time: 0.0415
INFO - 2016-12-01 16:53:50 --> Config Class Initialized
INFO - 2016-12-01 16:53:50 --> Hooks Class Initialized
DEBUG - 2016-12-01 16:53:50 --> UTF-8 Support Enabled
INFO - 2016-12-01 16:53:50 --> Utf8 Class Initialized
INFO - 2016-12-01 16:53:50 --> URI Class Initialized
DEBUG - 2016-12-01 16:53:50 --> No URI present. Default controller set.
INFO - 2016-12-01 16:53:50 --> Router Class Initialized
INFO - 2016-12-01 16:53:50 --> Output Class Initialized
INFO - 2016-12-01 16:53:50 --> Security Class Initialized
DEBUG - 2016-12-01 16:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 16:53:50 --> Input Class Initialized
INFO - 2016-12-01 16:53:50 --> Language Class Initialized
INFO - 2016-12-01 16:53:50 --> Loader Class Initialized
INFO - 2016-12-01 16:53:50 --> Database Driver Class Initialized
INFO - 2016-12-01 16:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 16:53:50 --> Controller Class Initialized
INFO - 2016-12-01 16:53:50 --> Helper loaded: url_helper
DEBUG - 2016-12-01 16:53:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 16:53:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 16:53:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 16:53:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 16:53:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 16:53:50 --> Final output sent to browser
DEBUG - 2016-12-01 16:53:50 --> Total execution time: 0.0138
INFO - 2016-12-01 16:53:52 --> Config Class Initialized
INFO - 2016-12-01 16:53:52 --> Hooks Class Initialized
DEBUG - 2016-12-01 16:53:52 --> UTF-8 Support Enabled
INFO - 2016-12-01 16:53:52 --> Utf8 Class Initialized
INFO - 2016-12-01 16:53:52 --> URI Class Initialized
INFO - 2016-12-01 16:53:52 --> Router Class Initialized
INFO - 2016-12-01 16:53:52 --> Output Class Initialized
INFO - 2016-12-01 16:53:52 --> Security Class Initialized
DEBUG - 2016-12-01 16:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 16:53:52 --> Input Class Initialized
INFO - 2016-12-01 16:53:52 --> Language Class Initialized
ERROR - 2016-12-01 16:53:52 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 16:53:52 --> Config Class Initialized
INFO - 2016-12-01 16:53:52 --> Hooks Class Initialized
DEBUG - 2016-12-01 16:53:52 --> UTF-8 Support Enabled
INFO - 2016-12-01 16:53:52 --> Utf8 Class Initialized
INFO - 2016-12-01 16:53:52 --> URI Class Initialized
INFO - 2016-12-01 16:53:52 --> Router Class Initialized
INFO - 2016-12-01 16:53:52 --> Output Class Initialized
INFO - 2016-12-01 16:53:52 --> Security Class Initialized
DEBUG - 2016-12-01 16:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 16:53:52 --> Input Class Initialized
INFO - 2016-12-01 16:53:52 --> Language Class Initialized
ERROR - 2016-12-01 16:53:52 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 18:33:55 --> Config Class Initialized
INFO - 2016-12-01 18:33:55 --> Hooks Class Initialized
DEBUG - 2016-12-01 18:33:55 --> UTF-8 Support Enabled
INFO - 2016-12-01 18:33:55 --> Utf8 Class Initialized
INFO - 2016-12-01 18:33:55 --> URI Class Initialized
DEBUG - 2016-12-01 18:33:55 --> No URI present. Default controller set.
INFO - 2016-12-01 18:33:55 --> Router Class Initialized
INFO - 2016-12-01 18:33:55 --> Output Class Initialized
INFO - 2016-12-01 18:33:55 --> Security Class Initialized
DEBUG - 2016-12-01 18:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 18:33:55 --> Input Class Initialized
INFO - 2016-12-01 18:33:55 --> Language Class Initialized
INFO - 2016-12-01 18:33:55 --> Loader Class Initialized
INFO - 2016-12-01 18:33:55 --> Database Driver Class Initialized
INFO - 2016-12-01 18:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 18:33:55 --> Controller Class Initialized
INFO - 2016-12-01 18:33:55 --> Helper loaded: url_helper
DEBUG - 2016-12-01 18:33:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 18:33:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 18:33:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 18:33:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 18:33:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 18:33:55 --> Final output sent to browser
DEBUG - 2016-12-01 18:33:55 --> Total execution time: 0.0368
INFO - 2016-12-01 18:33:55 --> Config Class Initialized
INFO - 2016-12-01 18:33:55 --> Hooks Class Initialized
DEBUG - 2016-12-01 18:33:55 --> UTF-8 Support Enabled
INFO - 2016-12-01 18:33:55 --> Utf8 Class Initialized
INFO - 2016-12-01 18:33:55 --> URI Class Initialized
INFO - 2016-12-01 18:33:55 --> Router Class Initialized
INFO - 2016-12-01 18:33:55 --> Output Class Initialized
INFO - 2016-12-01 18:33:55 --> Security Class Initialized
DEBUG - 2016-12-01 18:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 18:33:55 --> Input Class Initialized
INFO - 2016-12-01 18:33:55 --> Language Class Initialized
ERROR - 2016-12-01 18:33:55 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 18:33:55 --> Config Class Initialized
INFO - 2016-12-01 18:33:55 --> Hooks Class Initialized
DEBUG - 2016-12-01 18:33:55 --> UTF-8 Support Enabled
INFO - 2016-12-01 18:33:55 --> Utf8 Class Initialized
INFO - 2016-12-01 18:33:55 --> URI Class Initialized
INFO - 2016-12-01 18:33:55 --> Router Class Initialized
INFO - 2016-12-01 18:33:55 --> Output Class Initialized
INFO - 2016-12-01 18:33:55 --> Security Class Initialized
DEBUG - 2016-12-01 18:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 18:33:55 --> Input Class Initialized
INFO - 2016-12-01 18:33:55 --> Language Class Initialized
ERROR - 2016-12-01 18:33:55 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 18:33:56 --> Config Class Initialized
INFO - 2016-12-01 18:33:56 --> Hooks Class Initialized
DEBUG - 2016-12-01 18:33:56 --> UTF-8 Support Enabled
INFO - 2016-12-01 18:33:56 --> Utf8 Class Initialized
INFO - 2016-12-01 18:33:56 --> URI Class Initialized
INFO - 2016-12-01 18:33:56 --> Router Class Initialized
INFO - 2016-12-01 18:33:56 --> Output Class Initialized
INFO - 2016-12-01 18:33:56 --> Security Class Initialized
DEBUG - 2016-12-01 18:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 18:33:56 --> Input Class Initialized
INFO - 2016-12-01 18:33:56 --> Language Class Initialized
INFO - 2016-12-01 18:33:56 --> Loader Class Initialized
INFO - 2016-12-01 18:33:56 --> Database Driver Class Initialized
INFO - 2016-12-01 18:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 18:33:56 --> Controller Class Initialized
INFO - 2016-12-01 18:33:56 --> Helper loaded: url_helper
DEBUG - 2016-12-01 18:33:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 18:33:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 18:33:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 18:33:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 18:33:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 18:33:56 --> Final output sent to browser
DEBUG - 2016-12-01 18:33:56 --> Total execution time: 0.0144
INFO - 2016-12-01 18:34:10 --> Config Class Initialized
INFO - 2016-12-01 18:34:10 --> Hooks Class Initialized
DEBUG - 2016-12-01 18:34:10 --> UTF-8 Support Enabled
INFO - 2016-12-01 18:34:10 --> Utf8 Class Initialized
INFO - 2016-12-01 18:34:10 --> URI Class Initialized
DEBUG - 2016-12-01 18:34:10 --> No URI present. Default controller set.
INFO - 2016-12-01 18:34:10 --> Router Class Initialized
INFO - 2016-12-01 18:34:10 --> Output Class Initialized
INFO - 2016-12-01 18:34:10 --> Security Class Initialized
DEBUG - 2016-12-01 18:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 18:34:10 --> Input Class Initialized
INFO - 2016-12-01 18:34:10 --> Language Class Initialized
INFO - 2016-12-01 18:34:10 --> Loader Class Initialized
INFO - 2016-12-01 18:34:10 --> Database Driver Class Initialized
INFO - 2016-12-01 18:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 18:34:10 --> Controller Class Initialized
INFO - 2016-12-01 18:34:10 --> Helper loaded: url_helper
DEBUG - 2016-12-01 18:34:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 18:34:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 18:34:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 18:34:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 18:34:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 18:34:10 --> Final output sent to browser
DEBUG - 2016-12-01 18:34:10 --> Total execution time: 0.0144
INFO - 2016-12-01 18:34:10 --> Config Class Initialized
INFO - 2016-12-01 18:34:10 --> Hooks Class Initialized
DEBUG - 2016-12-01 18:34:10 --> UTF-8 Support Enabled
INFO - 2016-12-01 18:34:10 --> Utf8 Class Initialized
INFO - 2016-12-01 18:34:10 --> URI Class Initialized
INFO - 2016-12-01 18:34:10 --> Config Class Initialized
INFO - 2016-12-01 18:34:10 --> Hooks Class Initialized
DEBUG - 2016-12-01 18:34:10 --> UTF-8 Support Enabled
INFO - 2016-12-01 18:34:10 --> Utf8 Class Initialized
INFO - 2016-12-01 18:34:10 --> URI Class Initialized
INFO - 2016-12-01 18:34:10 --> Router Class Initialized
INFO - 2016-12-01 18:34:10 --> Output Class Initialized
INFO - 2016-12-01 18:34:10 --> Security Class Initialized
DEBUG - 2016-12-01 18:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 18:34:10 --> Input Class Initialized
INFO - 2016-12-01 18:34:10 --> Language Class Initialized
ERROR - 2016-12-01 18:34:10 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 18:34:10 --> Router Class Initialized
INFO - 2016-12-01 18:34:10 --> Output Class Initialized
INFO - 2016-12-01 18:34:10 --> Security Class Initialized
DEBUG - 2016-12-01 18:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 18:34:10 --> Input Class Initialized
INFO - 2016-12-01 18:34:10 --> Language Class Initialized
ERROR - 2016-12-01 18:34:10 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 18:34:11 --> Config Class Initialized
INFO - 2016-12-01 18:34:11 --> Hooks Class Initialized
DEBUG - 2016-12-01 18:34:11 --> UTF-8 Support Enabled
INFO - 2016-12-01 18:34:11 --> Utf8 Class Initialized
INFO - 2016-12-01 18:34:11 --> URI Class Initialized
INFO - 2016-12-01 18:34:11 --> Router Class Initialized
INFO - 2016-12-01 18:34:11 --> Output Class Initialized
INFO - 2016-12-01 18:34:11 --> Security Class Initialized
DEBUG - 2016-12-01 18:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 18:34:11 --> Input Class Initialized
INFO - 2016-12-01 18:34:11 --> Language Class Initialized
INFO - 2016-12-01 18:34:11 --> Loader Class Initialized
INFO - 2016-12-01 18:34:11 --> Database Driver Class Initialized
INFO - 2016-12-01 18:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 18:34:11 --> Controller Class Initialized
INFO - 2016-12-01 18:34:11 --> Helper loaded: url_helper
DEBUG - 2016-12-01 18:34:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 18:34:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 18:34:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 18:34:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 18:34:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 18:34:11 --> Final output sent to browser
DEBUG - 2016-12-01 18:34:11 --> Total execution time: 0.0152
INFO - 2016-12-01 23:40:53 --> Config Class Initialized
INFO - 2016-12-01 23:40:53 --> Hooks Class Initialized
DEBUG - 2016-12-01 23:40:53 --> UTF-8 Support Enabled
INFO - 2016-12-01 23:40:53 --> Utf8 Class Initialized
INFO - 2016-12-01 23:40:53 --> URI Class Initialized
DEBUG - 2016-12-01 23:40:53 --> No URI present. Default controller set.
INFO - 2016-12-01 23:40:53 --> Router Class Initialized
INFO - 2016-12-01 23:40:53 --> Output Class Initialized
INFO - 2016-12-01 23:40:53 --> Security Class Initialized
DEBUG - 2016-12-01 23:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 23:40:53 --> Input Class Initialized
INFO - 2016-12-01 23:40:53 --> Language Class Initialized
INFO - 2016-12-01 23:40:53 --> Loader Class Initialized
INFO - 2016-12-01 23:40:53 --> Database Driver Class Initialized
INFO - 2016-12-01 23:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 23:40:53 --> Controller Class Initialized
INFO - 2016-12-01 23:40:53 --> Helper loaded: url_helper
DEBUG - 2016-12-01 23:40:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 23:40:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 23:40:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 23:40:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 23:40:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 23:40:53 --> Final output sent to browser
DEBUG - 2016-12-01 23:40:53 --> Total execution time: 0.0182
INFO - 2016-12-01 23:40:54 --> Config Class Initialized
INFO - 2016-12-01 23:40:54 --> Hooks Class Initialized
DEBUG - 2016-12-01 23:40:54 --> UTF-8 Support Enabled
INFO - 2016-12-01 23:40:54 --> Utf8 Class Initialized
INFO - 2016-12-01 23:40:54 --> URI Class Initialized
INFO - 2016-12-01 23:40:54 --> Router Class Initialized
INFO - 2016-12-01 23:40:54 --> Config Class Initialized
INFO - 2016-12-01 23:40:54 --> Hooks Class Initialized
DEBUG - 2016-12-01 23:40:54 --> UTF-8 Support Enabled
INFO - 2016-12-01 23:40:54 --> Utf8 Class Initialized
INFO - 2016-12-01 23:40:54 --> URI Class Initialized
INFO - 2016-12-01 23:40:54 --> Router Class Initialized
INFO - 2016-12-01 23:40:54 --> Output Class Initialized
INFO - 2016-12-01 23:40:54 --> Security Class Initialized
DEBUG - 2016-12-01 23:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 23:40:54 --> Input Class Initialized
INFO - 2016-12-01 23:40:54 --> Language Class Initialized
ERROR - 2016-12-01 23:40:54 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 23:40:54 --> Output Class Initialized
INFO - 2016-12-01 23:40:54 --> Security Class Initialized
DEBUG - 2016-12-01 23:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 23:40:54 --> Input Class Initialized
INFO - 2016-12-01 23:40:54 --> Language Class Initialized
ERROR - 2016-12-01 23:40:54 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 23:41:17 --> Config Class Initialized
INFO - 2016-12-01 23:41:17 --> Hooks Class Initialized
DEBUG - 2016-12-01 23:41:17 --> UTF-8 Support Enabled
INFO - 2016-12-01 23:41:17 --> Utf8 Class Initialized
INFO - 2016-12-01 23:41:17 --> URI Class Initialized
DEBUG - 2016-12-01 23:41:17 --> No URI present. Default controller set.
INFO - 2016-12-01 23:41:17 --> Router Class Initialized
INFO - 2016-12-01 23:41:17 --> Output Class Initialized
INFO - 2016-12-01 23:41:17 --> Security Class Initialized
DEBUG - 2016-12-01 23:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 23:41:17 --> Input Class Initialized
INFO - 2016-12-01 23:41:17 --> Language Class Initialized
INFO - 2016-12-01 23:41:17 --> Loader Class Initialized
INFO - 2016-12-01 23:41:17 --> Database Driver Class Initialized
INFO - 2016-12-01 23:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 23:41:17 --> Controller Class Initialized
INFO - 2016-12-01 23:41:17 --> Helper loaded: url_helper
DEBUG - 2016-12-01 23:41:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 23:41:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 23:41:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 23:41:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 23:41:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 23:41:17 --> Final output sent to browser
DEBUG - 2016-12-01 23:41:17 --> Total execution time: 0.0132
INFO - 2016-12-01 23:41:17 --> Config Class Initialized
INFO - 2016-12-01 23:41:17 --> Hooks Class Initialized
DEBUG - 2016-12-01 23:41:17 --> UTF-8 Support Enabled
INFO - 2016-12-01 23:41:17 --> Utf8 Class Initialized
INFO - 2016-12-01 23:41:17 --> URI Class Initialized
INFO - 2016-12-01 23:41:17 --> Router Class Initialized
INFO - 2016-12-01 23:41:17 --> Output Class Initialized
INFO - 2016-12-01 23:41:17 --> Security Class Initialized
DEBUG - 2016-12-01 23:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 23:41:17 --> Input Class Initialized
INFO - 2016-12-01 23:41:17 --> Language Class Initialized
ERROR - 2016-12-01 23:41:17 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 23:41:17 --> Config Class Initialized
INFO - 2016-12-01 23:41:17 --> Hooks Class Initialized
DEBUG - 2016-12-01 23:41:17 --> UTF-8 Support Enabled
INFO - 2016-12-01 23:41:17 --> Utf8 Class Initialized
INFO - 2016-12-01 23:41:17 --> URI Class Initialized
INFO - 2016-12-01 23:41:17 --> Router Class Initialized
INFO - 2016-12-01 23:41:17 --> Output Class Initialized
INFO - 2016-12-01 23:41:17 --> Security Class Initialized
DEBUG - 2016-12-01 23:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 23:41:17 --> Input Class Initialized
INFO - 2016-12-01 23:41:17 --> Language Class Initialized
ERROR - 2016-12-01 23:41:17 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 23:50:54 --> Config Class Initialized
INFO - 2016-12-01 23:50:54 --> Hooks Class Initialized
DEBUG - 2016-12-01 23:50:54 --> UTF-8 Support Enabled
INFO - 2016-12-01 23:50:54 --> Utf8 Class Initialized
INFO - 2016-12-01 23:50:54 --> URI Class Initialized
DEBUG - 2016-12-01 23:50:54 --> No URI present. Default controller set.
INFO - 2016-12-01 23:50:54 --> Router Class Initialized
INFO - 2016-12-01 23:50:54 --> Output Class Initialized
INFO - 2016-12-01 23:50:54 --> Security Class Initialized
DEBUG - 2016-12-01 23:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 23:50:54 --> Input Class Initialized
INFO - 2016-12-01 23:50:54 --> Language Class Initialized
INFO - 2016-12-01 23:50:54 --> Loader Class Initialized
INFO - 2016-12-01 23:50:54 --> Database Driver Class Initialized
INFO - 2016-12-01 23:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 23:50:54 --> Controller Class Initialized
INFO - 2016-12-01 23:50:54 --> Helper loaded: url_helper
DEBUG - 2016-12-01 23:50:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 23:50:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 23:50:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 23:50:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 23:50:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 23:50:54 --> Final output sent to browser
DEBUG - 2016-12-01 23:50:54 --> Total execution time: 0.0136
INFO - 2016-12-01 23:50:54 --> Config Class Initialized
INFO - 2016-12-01 23:50:54 --> Hooks Class Initialized
DEBUG - 2016-12-01 23:50:54 --> UTF-8 Support Enabled
INFO - 2016-12-01 23:50:54 --> Utf8 Class Initialized
INFO - 2016-12-01 23:50:54 --> URI Class Initialized
INFO - 2016-12-01 23:50:54 --> Router Class Initialized
INFO - 2016-12-01 23:50:54 --> Output Class Initialized
INFO - 2016-12-01 23:50:54 --> Security Class Initialized
DEBUG - 2016-12-01 23:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 23:50:54 --> Input Class Initialized
INFO - 2016-12-01 23:50:54 --> Language Class Initialized
ERROR - 2016-12-01 23:50:54 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 23:50:54 --> Config Class Initialized
INFO - 2016-12-01 23:50:54 --> Hooks Class Initialized
DEBUG - 2016-12-01 23:50:54 --> UTF-8 Support Enabled
INFO - 2016-12-01 23:50:54 --> Utf8 Class Initialized
INFO - 2016-12-01 23:50:54 --> URI Class Initialized
INFO - 2016-12-01 23:50:54 --> Router Class Initialized
INFO - 2016-12-01 23:50:54 --> Output Class Initialized
INFO - 2016-12-01 23:50:54 --> Security Class Initialized
DEBUG - 2016-12-01 23:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 23:50:54 --> Input Class Initialized
INFO - 2016-12-01 23:50:54 --> Language Class Initialized
ERROR - 2016-12-01 23:50:54 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 23:52:26 --> Config Class Initialized
INFO - 2016-12-01 23:52:26 --> Hooks Class Initialized
DEBUG - 2016-12-01 23:52:26 --> UTF-8 Support Enabled
INFO - 2016-12-01 23:52:26 --> Utf8 Class Initialized
INFO - 2016-12-01 23:52:26 --> URI Class Initialized
DEBUG - 2016-12-01 23:52:26 --> No URI present. Default controller set.
INFO - 2016-12-01 23:52:26 --> Router Class Initialized
INFO - 2016-12-01 23:52:26 --> Output Class Initialized
INFO - 2016-12-01 23:52:26 --> Security Class Initialized
DEBUG - 2016-12-01 23:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 23:52:26 --> Input Class Initialized
INFO - 2016-12-01 23:52:26 --> Language Class Initialized
INFO - 2016-12-01 23:52:26 --> Loader Class Initialized
INFO - 2016-12-01 23:52:26 --> Database Driver Class Initialized
INFO - 2016-12-01 23:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 23:52:26 --> Controller Class Initialized
INFO - 2016-12-01 23:52:26 --> Helper loaded: url_helper
DEBUG - 2016-12-01 23:52:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 23:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 23:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 23:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 23:52:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 23:52:26 --> Final output sent to browser
DEBUG - 2016-12-01 23:52:26 --> Total execution time: 0.0558
INFO - 2016-12-01 23:52:27 --> Config Class Initialized
INFO - 2016-12-01 23:52:27 --> Hooks Class Initialized
DEBUG - 2016-12-01 23:52:27 --> UTF-8 Support Enabled
INFO - 2016-12-01 23:52:27 --> Utf8 Class Initialized
INFO - 2016-12-01 23:52:27 --> URI Class Initialized
INFO - 2016-12-01 23:52:27 --> Router Class Initialized
INFO - 2016-12-01 23:52:27 --> Output Class Initialized
INFO - 2016-12-01 23:52:27 --> Security Class Initialized
DEBUG - 2016-12-01 23:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 23:52:27 --> Input Class Initialized
INFO - 2016-12-01 23:52:27 --> Language Class Initialized
ERROR - 2016-12-01 23:52:27 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 23:52:27 --> Config Class Initialized
INFO - 2016-12-01 23:52:27 --> Hooks Class Initialized
DEBUG - 2016-12-01 23:52:27 --> UTF-8 Support Enabled
INFO - 2016-12-01 23:52:27 --> Utf8 Class Initialized
INFO - 2016-12-01 23:52:27 --> URI Class Initialized
INFO - 2016-12-01 23:52:27 --> Router Class Initialized
INFO - 2016-12-01 23:52:27 --> Output Class Initialized
INFO - 2016-12-01 23:52:27 --> Security Class Initialized
DEBUG - 2016-12-01 23:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 23:52:27 --> Input Class Initialized
INFO - 2016-12-01 23:52:27 --> Language Class Initialized
ERROR - 2016-12-01 23:52:27 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 23:53:57 --> Config Class Initialized
INFO - 2016-12-01 23:53:57 --> Hooks Class Initialized
DEBUG - 2016-12-01 23:53:57 --> UTF-8 Support Enabled
INFO - 2016-12-01 23:53:57 --> Utf8 Class Initialized
INFO - 2016-12-01 23:53:57 --> URI Class Initialized
DEBUG - 2016-12-01 23:53:57 --> No URI present. Default controller set.
INFO - 2016-12-01 23:53:57 --> Router Class Initialized
INFO - 2016-12-01 23:53:57 --> Output Class Initialized
INFO - 2016-12-01 23:53:57 --> Security Class Initialized
DEBUG - 2016-12-01 23:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 23:53:57 --> Input Class Initialized
INFO - 2016-12-01 23:53:57 --> Language Class Initialized
INFO - 2016-12-01 23:53:57 --> Loader Class Initialized
INFO - 2016-12-01 23:53:57 --> Database Driver Class Initialized
INFO - 2016-12-01 23:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 23:53:57 --> Controller Class Initialized
INFO - 2016-12-01 23:53:57 --> Helper loaded: url_helper
DEBUG - 2016-12-01 23:53:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 23:53:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 23:53:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 23:53:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 23:53:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 23:53:57 --> Final output sent to browser
DEBUG - 2016-12-01 23:53:57 --> Total execution time: 0.0530
INFO - 2016-12-01 23:53:57 --> Config Class Initialized
INFO - 2016-12-01 23:53:57 --> Hooks Class Initialized
INFO - 2016-12-01 23:53:57 --> Config Class Initialized
INFO - 2016-12-01 23:53:57 --> Hooks Class Initialized
DEBUG - 2016-12-01 23:53:57 --> UTF-8 Support Enabled
INFO - 2016-12-01 23:53:57 --> Utf8 Class Initialized
INFO - 2016-12-01 23:53:57 --> URI Class Initialized
INFO - 2016-12-01 23:53:57 --> Router Class Initialized
INFO - 2016-12-01 23:53:57 --> Output Class Initialized
INFO - 2016-12-01 23:53:57 --> Security Class Initialized
DEBUG - 2016-12-01 23:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 23:53:57 --> Input Class Initialized
INFO - 2016-12-01 23:53:57 --> Language Class Initialized
ERROR - 2016-12-01 23:53:57 --> 404 Page Not Found: Img/portfolio
DEBUG - 2016-12-01 23:53:57 --> UTF-8 Support Enabled
INFO - 2016-12-01 23:53:57 --> Utf8 Class Initialized
INFO - 2016-12-01 23:53:57 --> URI Class Initialized
INFO - 2016-12-01 23:53:57 --> Router Class Initialized
INFO - 2016-12-01 23:53:57 --> Output Class Initialized
INFO - 2016-12-01 23:53:57 --> Security Class Initialized
DEBUG - 2016-12-01 23:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 23:53:57 --> Input Class Initialized
INFO - 2016-12-01 23:53:57 --> Language Class Initialized
ERROR - 2016-12-01 23:53:57 --> 404 Page Not Found: Img/portfolio
INFO - 2016-12-01 23:54:03 --> Config Class Initialized
INFO - 2016-12-01 23:54:03 --> Hooks Class Initialized
DEBUG - 2016-12-01 23:54:03 --> UTF-8 Support Enabled
INFO - 2016-12-01 23:54:03 --> Utf8 Class Initialized
INFO - 2016-12-01 23:54:03 --> URI Class Initialized
DEBUG - 2016-12-01 23:54:03 --> No URI present. Default controller set.
INFO - 2016-12-01 23:54:03 --> Router Class Initialized
INFO - 2016-12-01 23:54:03 --> Output Class Initialized
INFO - 2016-12-01 23:54:03 --> Security Class Initialized
DEBUG - 2016-12-01 23:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 23:54:03 --> Input Class Initialized
INFO - 2016-12-01 23:54:03 --> Language Class Initialized
INFO - 2016-12-01 23:54:03 --> Loader Class Initialized
INFO - 2016-12-01 23:54:03 --> Database Driver Class Initialized
INFO - 2016-12-01 23:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-01 23:54:03 --> Controller Class Initialized
INFO - 2016-12-01 23:54:03 --> Helper loaded: url_helper
DEBUG - 2016-12-01 23:54:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-01 23:54:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-01 23:54:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-01 23:54:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-01 23:54:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-01 23:54:03 --> Final output sent to browser
DEBUG - 2016-12-01 23:54:03 --> Total execution time: 0.0156
INFO - 2016-12-01 23:59:46 --> Config Class Initialized
INFO - 2016-12-01 23:59:46 --> Hooks Class Initialized
DEBUG - 2016-12-01 23:59:46 --> UTF-8 Support Enabled
INFO - 2016-12-01 23:59:46 --> Utf8 Class Initialized
INFO - 2016-12-01 23:59:46 --> URI Class Initialized
INFO - 2016-12-01 23:59:46 --> Router Class Initialized
INFO - 2016-12-01 23:59:46 --> Output Class Initialized
INFO - 2016-12-01 23:59:46 --> Security Class Initialized
DEBUG - 2016-12-01 23:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-01 23:59:46 --> Input Class Initialized
INFO - 2016-12-01 23:59:46 --> Language Class Initialized
ERROR - 2016-12-01 23:59:46 --> 404 Page Not Found: Templates/usuario

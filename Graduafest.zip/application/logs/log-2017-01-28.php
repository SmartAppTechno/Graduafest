<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-28 04:19:34 --> Config Class Initialized
INFO - 2017-01-28 04:19:34 --> Hooks Class Initialized
DEBUG - 2017-01-28 04:19:34 --> UTF-8 Support Enabled
INFO - 2017-01-28 04:19:34 --> Utf8 Class Initialized
INFO - 2017-01-28 04:19:34 --> URI Class Initialized
DEBUG - 2017-01-28 04:19:34 --> No URI present. Default controller set.
INFO - 2017-01-28 04:19:34 --> Router Class Initialized
INFO - 2017-01-28 04:19:34 --> Output Class Initialized
INFO - 2017-01-28 04:19:34 --> Security Class Initialized
DEBUG - 2017-01-28 04:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-28 04:19:34 --> Input Class Initialized
INFO - 2017-01-28 04:19:34 --> Language Class Initialized
INFO - 2017-01-28 04:19:34 --> Loader Class Initialized
INFO - 2017-01-28 04:19:34 --> Database Driver Class Initialized
INFO - 2017-01-28 04:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-28 04:19:34 --> Controller Class Initialized
INFO - 2017-01-28 04:19:34 --> Helper loaded: url_helper
DEBUG - 2017-01-28 04:19:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-28 04:19:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-28 04:19:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-28 04:19:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-28 04:19:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-28 04:19:34 --> Final output sent to browser
DEBUG - 2017-01-28 04:19:34 --> Total execution time: 0.3877
INFO - 2017-01-28 04:19:41 --> Config Class Initialized
INFO - 2017-01-28 04:19:41 --> Hooks Class Initialized
DEBUG - 2017-01-28 04:19:41 --> UTF-8 Support Enabled
INFO - 2017-01-28 04:19:41 --> Utf8 Class Initialized
INFO - 2017-01-28 04:19:41 --> URI Class Initialized
INFO - 2017-01-28 04:19:41 --> Router Class Initialized
INFO - 2017-01-28 04:19:41 --> Output Class Initialized
INFO - 2017-01-28 04:19:41 --> Security Class Initialized
DEBUG - 2017-01-28 04:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-28 04:19:41 --> Input Class Initialized
INFO - 2017-01-28 04:19:41 --> Language Class Initialized
INFO - 2017-01-28 04:19:41 --> Loader Class Initialized
INFO - 2017-01-28 04:19:41 --> Database Driver Class Initialized
INFO - 2017-01-28 04:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-28 04:19:41 --> Controller Class Initialized
INFO - 2017-01-28 04:19:41 --> Helper loaded: url_helper
DEBUG - 2017-01-28 04:19:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-28 04:19:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-28 04:19:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-28 04:19:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-28 04:19:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-28 04:19:41 --> Final output sent to browser
DEBUG - 2017-01-28 04:19:41 --> Total execution time: 0.0143
INFO - 2017-01-28 04:25:16 --> Config Class Initialized
INFO - 2017-01-28 04:25:16 --> Hooks Class Initialized
DEBUG - 2017-01-28 04:25:16 --> UTF-8 Support Enabled
INFO - 2017-01-28 04:25:16 --> Utf8 Class Initialized
INFO - 2017-01-28 04:25:16 --> URI Class Initialized
DEBUG - 2017-01-28 04:25:16 --> No URI present. Default controller set.
INFO - 2017-01-28 04:25:16 --> Router Class Initialized
INFO - 2017-01-28 04:25:16 --> Output Class Initialized
INFO - 2017-01-28 04:25:16 --> Security Class Initialized
DEBUG - 2017-01-28 04:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-28 04:25:16 --> Input Class Initialized
INFO - 2017-01-28 04:25:16 --> Language Class Initialized
INFO - 2017-01-28 04:25:16 --> Loader Class Initialized
INFO - 2017-01-28 04:25:16 --> Database Driver Class Initialized
INFO - 2017-01-28 04:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-28 04:25:16 --> Controller Class Initialized
INFO - 2017-01-28 04:25:16 --> Helper loaded: url_helper
DEBUG - 2017-01-28 04:25:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-28 04:25:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-28 04:25:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-28 04:25:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-28 04:25:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-28 04:25:16 --> Final output sent to browser
DEBUG - 2017-01-28 04:25:16 --> Total execution time: 0.0321
INFO - 2017-01-28 16:42:44 --> Config Class Initialized
INFO - 2017-01-28 16:42:44 --> Hooks Class Initialized
DEBUG - 2017-01-28 16:42:44 --> UTF-8 Support Enabled
INFO - 2017-01-28 16:42:44 --> Utf8 Class Initialized
INFO - 2017-01-28 16:42:44 --> URI Class Initialized
INFO - 2017-01-28 16:42:44 --> Router Class Initialized
INFO - 2017-01-28 16:42:44 --> Output Class Initialized
INFO - 2017-01-28 16:42:45 --> Security Class Initialized
DEBUG - 2017-01-28 16:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-28 16:42:45 --> Input Class Initialized
INFO - 2017-01-28 16:42:45 --> Language Class Initialized
INFO - 2017-01-28 16:42:45 --> Loader Class Initialized
INFO - 2017-01-28 16:42:45 --> Database Driver Class Initialized
INFO - 2017-01-28 16:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-28 16:42:45 --> Controller Class Initialized
INFO - 2017-01-28 16:42:45 --> Helper loaded: url_helper
DEBUG - 2017-01-28 16:42:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-28 16:42:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-28 16:42:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-28 16:42:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-28 16:42:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-28 16:42:46 --> Final output sent to browser
DEBUG - 2017-01-28 16:42:46 --> Total execution time: 1.5153
INFO - 2017-01-28 16:42:54 --> Config Class Initialized
INFO - 2017-01-28 16:42:54 --> Hooks Class Initialized
DEBUG - 2017-01-28 16:42:54 --> UTF-8 Support Enabled
INFO - 2017-01-28 16:42:54 --> Utf8 Class Initialized
INFO - 2017-01-28 16:42:54 --> URI Class Initialized
INFO - 2017-01-28 16:42:54 --> Router Class Initialized
INFO - 2017-01-28 16:42:54 --> Output Class Initialized
INFO - 2017-01-28 16:42:54 --> Security Class Initialized
DEBUG - 2017-01-28 16:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-28 16:42:54 --> Input Class Initialized
INFO - 2017-01-28 16:42:54 --> Language Class Initialized
INFO - 2017-01-28 16:42:54 --> Loader Class Initialized
INFO - 2017-01-28 16:42:54 --> Database Driver Class Initialized
INFO - 2017-01-28 16:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-28 16:42:54 --> Controller Class Initialized
INFO - 2017-01-28 16:42:54 --> Helper loaded: url_helper
DEBUG - 2017-01-28 16:42:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-28 16:42:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-28 16:42:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-28 16:42:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-28 16:42:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-28 16:42:54 --> Final output sent to browser
DEBUG - 2017-01-28 16:42:54 --> Total execution time: 0.0153
INFO - 2017-01-28 16:42:59 --> Config Class Initialized
INFO - 2017-01-28 16:42:59 --> Hooks Class Initialized
DEBUG - 2017-01-28 16:42:59 --> UTF-8 Support Enabled
INFO - 2017-01-28 16:42:59 --> Utf8 Class Initialized
INFO - 2017-01-28 16:42:59 --> URI Class Initialized
INFO - 2017-01-28 16:42:59 --> Router Class Initialized
INFO - 2017-01-28 16:42:59 --> Output Class Initialized
INFO - 2017-01-28 16:42:59 --> Security Class Initialized
DEBUG - 2017-01-28 16:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-28 16:42:59 --> Input Class Initialized
INFO - 2017-01-28 16:42:59 --> Language Class Initialized
INFO - 2017-01-28 16:42:59 --> Loader Class Initialized
INFO - 2017-01-28 16:42:59 --> Database Driver Class Initialized
INFO - 2017-01-28 16:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-28 16:42:59 --> Controller Class Initialized
INFO - 2017-01-28 16:42:59 --> Helper loaded: url_helper
DEBUG - 2017-01-28 16:42:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-28 16:43:05 --> Config Class Initialized
INFO - 2017-01-28 16:43:05 --> Hooks Class Initialized
DEBUG - 2017-01-28 16:43:05 --> UTF-8 Support Enabled
INFO - 2017-01-28 16:43:05 --> Utf8 Class Initialized
INFO - 2017-01-28 16:43:05 --> URI Class Initialized
INFO - 2017-01-28 16:43:05 --> Router Class Initialized
INFO - 2017-01-28 16:43:05 --> Output Class Initialized
INFO - 2017-01-28 16:43:05 --> Security Class Initialized
DEBUG - 2017-01-28 16:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-28 16:43:05 --> Input Class Initialized
INFO - 2017-01-28 16:43:05 --> Language Class Initialized
INFO - 2017-01-28 16:43:05 --> Loader Class Initialized
INFO - 2017-01-28 16:43:05 --> Database Driver Class Initialized
INFO - 2017-01-28 16:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-28 16:43:05 --> Controller Class Initialized
INFO - 2017-01-28 16:43:06 --> Helper loaded: date_helper
DEBUG - 2017-01-28 16:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-28 16:43:06 --> Helper loaded: url_helper
INFO - 2017-01-28 16:43:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-28 16:43:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-28 16:43:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-28 16:43:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-28 16:43:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-28 16:43:06 --> Final output sent to browser
DEBUG - 2017-01-28 16:43:06 --> Total execution time: 0.3963
INFO - 2017-01-28 16:43:06 --> Config Class Initialized
INFO - 2017-01-28 16:43:06 --> Hooks Class Initialized
DEBUG - 2017-01-28 16:43:06 --> UTF-8 Support Enabled
INFO - 2017-01-28 16:43:06 --> Utf8 Class Initialized
INFO - 2017-01-28 16:43:06 --> URI Class Initialized
INFO - 2017-01-28 16:43:06 --> Router Class Initialized
INFO - 2017-01-28 16:43:06 --> Output Class Initialized
INFO - 2017-01-28 16:43:06 --> Security Class Initialized
DEBUG - 2017-01-28 16:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-28 16:43:06 --> Input Class Initialized
INFO - 2017-01-28 16:43:06 --> Language Class Initialized
INFO - 2017-01-28 16:43:06 --> Loader Class Initialized
INFO - 2017-01-28 16:43:06 --> Database Driver Class Initialized
INFO - 2017-01-28 16:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-28 16:43:06 --> Controller Class Initialized
INFO - 2017-01-28 16:43:06 --> Helper loaded: url_helper
DEBUG - 2017-01-28 16:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-28 16:43:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-28 16:43:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-28 16:43:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-28 16:43:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-28 16:43:06 --> Final output sent to browser
DEBUG - 2017-01-28 16:43:06 --> Total execution time: 0.0148
INFO - 2017-01-28 17:05:16 --> Config Class Initialized
INFO - 2017-01-28 17:05:16 --> Hooks Class Initialized
DEBUG - 2017-01-28 17:05:16 --> UTF-8 Support Enabled
INFO - 2017-01-28 17:05:16 --> Utf8 Class Initialized
INFO - 2017-01-28 17:05:16 --> URI Class Initialized
DEBUG - 2017-01-28 17:05:16 --> No URI present. Default controller set.
INFO - 2017-01-28 17:05:16 --> Router Class Initialized
INFO - 2017-01-28 17:05:16 --> Output Class Initialized
INFO - 2017-01-28 17:05:16 --> Security Class Initialized
DEBUG - 2017-01-28 17:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-28 17:05:16 --> Input Class Initialized
INFO - 2017-01-28 17:05:16 --> Language Class Initialized
INFO - 2017-01-28 17:05:16 --> Loader Class Initialized
INFO - 2017-01-28 17:05:16 --> Database Driver Class Initialized
INFO - 2017-01-28 17:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-28 17:05:17 --> Controller Class Initialized
INFO - 2017-01-28 17:05:17 --> Helper loaded: url_helper
DEBUG - 2017-01-28 17:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-28 17:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-28 17:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-28 17:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-28 17:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-28 17:05:17 --> Final output sent to browser
DEBUG - 2017-01-28 17:05:17 --> Total execution time: 0.5834
INFO - 2017-01-28 17:05:21 --> Config Class Initialized
INFO - 2017-01-28 17:05:21 --> Hooks Class Initialized
DEBUG - 2017-01-28 17:05:21 --> UTF-8 Support Enabled
INFO - 2017-01-28 17:05:21 --> Utf8 Class Initialized
INFO - 2017-01-28 17:05:21 --> URI Class Initialized
INFO - 2017-01-28 17:05:21 --> Router Class Initialized
INFO - 2017-01-28 17:05:21 --> Output Class Initialized
INFO - 2017-01-28 17:05:21 --> Security Class Initialized
DEBUG - 2017-01-28 17:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-28 17:05:21 --> Input Class Initialized
INFO - 2017-01-28 17:05:21 --> Language Class Initialized
INFO - 2017-01-28 17:05:21 --> Loader Class Initialized
INFO - 2017-01-28 17:05:21 --> Database Driver Class Initialized
INFO - 2017-01-28 17:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-28 17:05:21 --> Controller Class Initialized
INFO - 2017-01-28 17:05:21 --> Helper loaded: url_helper
DEBUG - 2017-01-28 17:05:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-28 17:05:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-28 17:05:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-28 17:05:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-28 17:05:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-28 17:05:21 --> Final output sent to browser
DEBUG - 2017-01-28 17:05:21 --> Total execution time: 0.0444
INFO - 2017-01-28 17:07:49 --> Config Class Initialized
INFO - 2017-01-28 17:07:49 --> Hooks Class Initialized
DEBUG - 2017-01-28 17:07:49 --> UTF-8 Support Enabled
INFO - 2017-01-28 17:07:49 --> Utf8 Class Initialized
INFO - 2017-01-28 17:07:49 --> URI Class Initialized
INFO - 2017-01-28 17:07:49 --> Router Class Initialized
INFO - 2017-01-28 17:07:49 --> Output Class Initialized
INFO - 2017-01-28 17:07:49 --> Security Class Initialized
DEBUG - 2017-01-28 17:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-28 17:07:49 --> Input Class Initialized
INFO - 2017-01-28 17:07:49 --> Language Class Initialized
INFO - 2017-01-28 17:07:49 --> Loader Class Initialized
INFO - 2017-01-28 17:07:49 --> Database Driver Class Initialized
INFO - 2017-01-28 17:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-28 17:07:49 --> Controller Class Initialized
INFO - 2017-01-28 17:07:49 --> Helper loaded: url_helper
DEBUG - 2017-01-28 17:07:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-28 17:07:49 --> Final output sent to browser
DEBUG - 2017-01-28 17:07:49 --> Total execution time: 0.0135
INFO - 2017-01-28 19:08:29 --> Config Class Initialized
INFO - 2017-01-28 19:08:29 --> Hooks Class Initialized
DEBUG - 2017-01-28 19:08:29 --> UTF-8 Support Enabled
INFO - 2017-01-28 19:08:29 --> Utf8 Class Initialized
INFO - 2017-01-28 19:08:29 --> URI Class Initialized
DEBUG - 2017-01-28 19:08:29 --> No URI present. Default controller set.
INFO - 2017-01-28 19:08:29 --> Router Class Initialized
INFO - 2017-01-28 19:08:29 --> Output Class Initialized
INFO - 2017-01-28 19:08:29 --> Security Class Initialized
DEBUG - 2017-01-28 19:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-28 19:08:29 --> Input Class Initialized
INFO - 2017-01-28 19:08:29 --> Language Class Initialized
INFO - 2017-01-28 19:08:29 --> Loader Class Initialized
INFO - 2017-01-28 19:08:30 --> Database Driver Class Initialized
INFO - 2017-01-28 19:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-28 19:08:30 --> Controller Class Initialized
INFO - 2017-01-28 19:08:30 --> Helper loaded: url_helper
DEBUG - 2017-01-28 19:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-28 19:08:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-28 19:08:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-28 19:08:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-28 19:08:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-28 19:08:31 --> Final output sent to browser
DEBUG - 2017-01-28 19:08:31 --> Total execution time: 1.7510
INFO - 2017-01-28 19:44:10 --> Config Class Initialized
INFO - 2017-01-28 19:44:10 --> Hooks Class Initialized
DEBUG - 2017-01-28 19:44:10 --> UTF-8 Support Enabled
INFO - 2017-01-28 19:44:10 --> Utf8 Class Initialized
INFO - 2017-01-28 19:44:10 --> URI Class Initialized
DEBUG - 2017-01-28 19:44:10 --> No URI present. Default controller set.
INFO - 2017-01-28 19:44:10 --> Router Class Initialized
INFO - 2017-01-28 19:44:11 --> Output Class Initialized
INFO - 2017-01-28 19:44:11 --> Security Class Initialized
DEBUG - 2017-01-28 19:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-28 19:44:11 --> Input Class Initialized
INFO - 2017-01-28 19:44:11 --> Language Class Initialized
INFO - 2017-01-28 19:44:11 --> Loader Class Initialized
INFO - 2017-01-28 19:44:11 --> Database Driver Class Initialized
INFO - 2017-01-28 19:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-28 19:44:11 --> Controller Class Initialized
INFO - 2017-01-28 19:44:11 --> Helper loaded: url_helper
DEBUG - 2017-01-28 19:44:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-28 19:44:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-28 19:44:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-28 19:44:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-28 19:44:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-28 19:44:12 --> Final output sent to browser
DEBUG - 2017-01-28 19:44:12 --> Total execution time: 1.7497
INFO - 2017-01-28 21:13:31 --> Config Class Initialized
INFO - 2017-01-28 21:13:31 --> Hooks Class Initialized
DEBUG - 2017-01-28 21:13:32 --> UTF-8 Support Enabled
INFO - 2017-01-28 21:13:32 --> Utf8 Class Initialized
INFO - 2017-01-28 21:13:32 --> URI Class Initialized
DEBUG - 2017-01-28 21:13:32 --> No URI present. Default controller set.
INFO - 2017-01-28 21:13:32 --> Router Class Initialized
INFO - 2017-01-28 21:13:32 --> Output Class Initialized
INFO - 2017-01-28 21:13:32 --> Security Class Initialized
DEBUG - 2017-01-28 21:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-28 21:13:32 --> Input Class Initialized
INFO - 2017-01-28 21:13:32 --> Language Class Initialized
INFO - 2017-01-28 21:13:32 --> Loader Class Initialized
INFO - 2017-01-28 21:13:32 --> Database Driver Class Initialized
INFO - 2017-01-28 21:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-28 21:13:33 --> Controller Class Initialized
INFO - 2017-01-28 21:13:33 --> Helper loaded: url_helper
DEBUG - 2017-01-28 21:13:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-28 21:13:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-28 21:13:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-28 21:13:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-28 21:13:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-28 21:13:33 --> Final output sent to browser
DEBUG - 2017-01-28 21:13:33 --> Total execution time: 1.7675
INFO - 2017-01-28 21:13:46 --> Config Class Initialized
INFO - 2017-01-28 21:13:46 --> Hooks Class Initialized
DEBUG - 2017-01-28 21:13:46 --> UTF-8 Support Enabled
INFO - 2017-01-28 21:13:46 --> Utf8 Class Initialized
INFO - 2017-01-28 21:13:46 --> URI Class Initialized
INFO - 2017-01-28 21:13:46 --> Router Class Initialized
INFO - 2017-01-28 21:13:46 --> Output Class Initialized
INFO - 2017-01-28 21:13:46 --> Security Class Initialized
DEBUG - 2017-01-28 21:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-28 21:13:46 --> Input Class Initialized
INFO - 2017-01-28 21:13:46 --> Language Class Initialized
INFO - 2017-01-28 21:13:46 --> Loader Class Initialized
INFO - 2017-01-28 21:13:46 --> Database Driver Class Initialized
INFO - 2017-01-28 21:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-28 21:13:46 --> Controller Class Initialized
INFO - 2017-01-28 21:13:46 --> Helper loaded: url_helper
DEBUG - 2017-01-28 21:13:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-28 21:13:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-28 21:13:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-28 21:13:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-28 21:13:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-28 21:13:46 --> Final output sent to browser
DEBUG - 2017-01-28 21:13:46 --> Total execution time: 0.0138
INFO - 2017-01-28 21:53:21 --> Config Class Initialized
INFO - 2017-01-28 21:53:21 --> Hooks Class Initialized
DEBUG - 2017-01-28 21:53:21 --> UTF-8 Support Enabled
INFO - 2017-01-28 21:53:21 --> Utf8 Class Initialized
INFO - 2017-01-28 21:53:21 --> URI Class Initialized
DEBUG - 2017-01-28 21:53:21 --> No URI present. Default controller set.
INFO - 2017-01-28 21:53:21 --> Router Class Initialized
INFO - 2017-01-28 21:53:21 --> Output Class Initialized
INFO - 2017-01-28 21:53:21 --> Security Class Initialized
DEBUG - 2017-01-28 21:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-28 21:53:21 --> Input Class Initialized
INFO - 2017-01-28 21:53:21 --> Language Class Initialized
INFO - 2017-01-28 21:53:21 --> Loader Class Initialized
INFO - 2017-01-28 21:53:21 --> Database Driver Class Initialized
INFO - 2017-01-28 21:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-28 21:53:21 --> Controller Class Initialized
INFO - 2017-01-28 21:53:21 --> Helper loaded: url_helper
DEBUG - 2017-01-28 21:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-28 21:53:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-28 21:53:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-28 21:53:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-28 21:53:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-28 21:53:21 --> Final output sent to browser
DEBUG - 2017-01-28 21:53:21 --> Total execution time: 0.0396

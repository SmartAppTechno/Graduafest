<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-22 00:41:13 --> Config Class Initialized
INFO - 2017-01-22 00:41:13 --> Hooks Class Initialized
DEBUG - 2017-01-22 00:41:13 --> UTF-8 Support Enabled
INFO - 2017-01-22 00:41:13 --> Utf8 Class Initialized
INFO - 2017-01-22 00:41:13 --> URI Class Initialized
INFO - 2017-01-22 00:41:13 --> Router Class Initialized
INFO - 2017-01-22 00:41:13 --> Output Class Initialized
INFO - 2017-01-22 00:41:13 --> Security Class Initialized
DEBUG - 2017-01-22 00:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 00:41:13 --> Input Class Initialized
INFO - 2017-01-22 00:41:13 --> Language Class Initialized
INFO - 2017-01-22 00:41:13 --> Loader Class Initialized
INFO - 2017-01-22 00:41:13 --> Database Driver Class Initialized
INFO - 2017-01-22 00:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 00:41:13 --> Controller Class Initialized
INFO - 2017-01-22 00:41:13 --> Helper loaded: url_helper
DEBUG - 2017-01-22 00:41:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 00:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 00:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 00:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 00:41:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 00:41:13 --> Final output sent to browser
DEBUG - 2017-01-22 00:41:13 --> Total execution time: 0.0140
INFO - 2017-01-22 01:30:48 --> Config Class Initialized
INFO - 2017-01-22 01:30:48 --> Hooks Class Initialized
DEBUG - 2017-01-22 01:30:48 --> UTF-8 Support Enabled
INFO - 2017-01-22 01:30:48 --> Utf8 Class Initialized
INFO - 2017-01-22 01:30:48 --> URI Class Initialized
INFO - 2017-01-22 01:30:48 --> Router Class Initialized
INFO - 2017-01-22 01:30:48 --> Output Class Initialized
INFO - 2017-01-22 01:30:48 --> Security Class Initialized
DEBUG - 2017-01-22 01:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 01:30:48 --> Input Class Initialized
INFO - 2017-01-22 01:30:48 --> Language Class Initialized
INFO - 2017-01-22 01:30:48 --> Loader Class Initialized
INFO - 2017-01-22 01:30:48 --> Database Driver Class Initialized
INFO - 2017-01-22 01:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 01:30:48 --> Controller Class Initialized
INFO - 2017-01-22 01:30:48 --> Helper loaded: url_helper
DEBUG - 2017-01-22 01:30:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 01:30:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 01:30:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 01:30:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 01:30:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 01:30:48 --> Final output sent to browser
DEBUG - 2017-01-22 01:30:48 --> Total execution time: 0.0396
INFO - 2017-01-22 01:55:59 --> Config Class Initialized
INFO - 2017-01-22 01:55:59 --> Hooks Class Initialized
DEBUG - 2017-01-22 01:55:59 --> UTF-8 Support Enabled
INFO - 2017-01-22 01:55:59 --> Utf8 Class Initialized
INFO - 2017-01-22 01:55:59 --> URI Class Initialized
INFO - 2017-01-22 01:55:59 --> Router Class Initialized
INFO - 2017-01-22 01:55:59 --> Output Class Initialized
INFO - 2017-01-22 01:55:59 --> Security Class Initialized
DEBUG - 2017-01-22 01:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 01:55:59 --> Input Class Initialized
INFO - 2017-01-22 01:55:59 --> Language Class Initialized
INFO - 2017-01-22 01:55:59 --> Loader Class Initialized
INFO - 2017-01-22 01:55:59 --> Database Driver Class Initialized
INFO - 2017-01-22 01:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 01:55:59 --> Controller Class Initialized
INFO - 2017-01-22 01:55:59 --> Helper loaded: date_helper
DEBUG - 2017-01-22 01:55:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 01:55:59 --> Helper loaded: url_helper
INFO - 2017-01-22 01:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 01:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-22 01:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-22 01:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-22 01:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 01:55:59 --> Final output sent to browser
DEBUG - 2017-01-22 01:55:59 --> Total execution time: 0.0135
INFO - 2017-01-22 01:56:04 --> Config Class Initialized
INFO - 2017-01-22 01:56:04 --> Hooks Class Initialized
DEBUG - 2017-01-22 01:56:04 --> UTF-8 Support Enabled
INFO - 2017-01-22 01:56:04 --> Utf8 Class Initialized
INFO - 2017-01-22 01:56:04 --> URI Class Initialized
INFO - 2017-01-22 01:56:04 --> Router Class Initialized
INFO - 2017-01-22 01:56:04 --> Output Class Initialized
INFO - 2017-01-22 01:56:04 --> Security Class Initialized
DEBUG - 2017-01-22 01:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 01:56:04 --> Input Class Initialized
INFO - 2017-01-22 01:56:04 --> Language Class Initialized
INFO - 2017-01-22 01:56:04 --> Loader Class Initialized
INFO - 2017-01-22 01:56:04 --> Database Driver Class Initialized
INFO - 2017-01-22 01:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 01:56:04 --> Controller Class Initialized
INFO - 2017-01-22 01:56:04 --> Helper loaded: url_helper
DEBUG - 2017-01-22 01:56:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 01:56:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 01:56:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 01:56:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 01:56:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 01:56:04 --> Final output sent to browser
DEBUG - 2017-01-22 01:56:04 --> Total execution time: 0.0135
INFO - 2017-01-22 01:57:05 --> Config Class Initialized
INFO - 2017-01-22 01:57:05 --> Hooks Class Initialized
DEBUG - 2017-01-22 01:57:05 --> UTF-8 Support Enabled
INFO - 2017-01-22 01:57:05 --> Utf8 Class Initialized
INFO - 2017-01-22 01:57:05 --> URI Class Initialized
INFO - 2017-01-22 01:57:05 --> Router Class Initialized
INFO - 2017-01-22 01:57:05 --> Output Class Initialized
INFO - 2017-01-22 01:57:05 --> Security Class Initialized
DEBUG - 2017-01-22 01:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 01:57:05 --> Input Class Initialized
INFO - 2017-01-22 01:57:05 --> Language Class Initialized
INFO - 2017-01-22 01:57:05 --> Loader Class Initialized
INFO - 2017-01-22 01:57:05 --> Database Driver Class Initialized
INFO - 2017-01-22 01:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 01:57:05 --> Controller Class Initialized
INFO - 2017-01-22 01:57:05 --> Helper loaded: url_helper
DEBUG - 2017-01-22 01:57:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 01:57:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-22 01:57:05 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-22 01:57:05 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-22 01:57:05 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-22 01:57:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 01:57:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 01:57:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 01:57:05 --> Final output sent to browser
DEBUG - 2017-01-22 01:57:05 --> Total execution time: 0.0137
INFO - 2017-01-22 01:57:09 --> Config Class Initialized
INFO - 2017-01-22 01:57:09 --> Hooks Class Initialized
DEBUG - 2017-01-22 01:57:09 --> UTF-8 Support Enabled
INFO - 2017-01-22 01:57:09 --> Utf8 Class Initialized
INFO - 2017-01-22 01:57:09 --> URI Class Initialized
INFO - 2017-01-22 01:57:09 --> Router Class Initialized
INFO - 2017-01-22 01:57:09 --> Output Class Initialized
INFO - 2017-01-22 01:57:09 --> Security Class Initialized
DEBUG - 2017-01-22 01:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 01:57:09 --> Input Class Initialized
INFO - 2017-01-22 01:57:09 --> Language Class Initialized
INFO - 2017-01-22 01:57:09 --> Loader Class Initialized
INFO - 2017-01-22 01:57:09 --> Database Driver Class Initialized
INFO - 2017-01-22 01:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 01:57:09 --> Controller Class Initialized
INFO - 2017-01-22 01:57:09 --> Helper loaded: url_helper
DEBUG - 2017-01-22 01:57:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 01:57:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 01:57:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 01:57:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 01:57:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 01:57:09 --> Final output sent to browser
DEBUG - 2017-01-22 01:57:09 --> Total execution time: 0.0133
INFO - 2017-01-22 01:57:15 --> Config Class Initialized
INFO - 2017-01-22 01:57:15 --> Hooks Class Initialized
DEBUG - 2017-01-22 01:57:15 --> UTF-8 Support Enabled
INFO - 2017-01-22 01:57:15 --> Utf8 Class Initialized
INFO - 2017-01-22 01:57:15 --> URI Class Initialized
DEBUG - 2017-01-22 01:57:15 --> No URI present. Default controller set.
INFO - 2017-01-22 01:57:15 --> Router Class Initialized
INFO - 2017-01-22 01:57:15 --> Output Class Initialized
INFO - 2017-01-22 01:57:15 --> Security Class Initialized
DEBUG - 2017-01-22 01:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 01:57:15 --> Input Class Initialized
INFO - 2017-01-22 01:57:15 --> Language Class Initialized
INFO - 2017-01-22 01:57:15 --> Loader Class Initialized
INFO - 2017-01-22 01:57:15 --> Database Driver Class Initialized
INFO - 2017-01-22 01:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 01:57:15 --> Controller Class Initialized
INFO - 2017-01-22 01:57:15 --> Helper loaded: url_helper
DEBUG - 2017-01-22 01:57:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 01:57:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 01:57:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 01:57:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 01:57:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 01:57:15 --> Final output sent to browser
DEBUG - 2017-01-22 01:57:15 --> Total execution time: 0.0202
INFO - 2017-01-22 01:57:16 --> Config Class Initialized
INFO - 2017-01-22 01:57:16 --> Hooks Class Initialized
DEBUG - 2017-01-22 01:57:16 --> UTF-8 Support Enabled
INFO - 2017-01-22 01:57:16 --> Utf8 Class Initialized
INFO - 2017-01-22 01:57:16 --> URI Class Initialized
INFO - 2017-01-22 01:57:16 --> Router Class Initialized
INFO - 2017-01-22 01:57:16 --> Output Class Initialized
INFO - 2017-01-22 01:57:16 --> Security Class Initialized
DEBUG - 2017-01-22 01:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 01:57:16 --> Input Class Initialized
INFO - 2017-01-22 01:57:16 --> Language Class Initialized
INFO - 2017-01-22 01:57:16 --> Loader Class Initialized
INFO - 2017-01-22 01:57:16 --> Database Driver Class Initialized
INFO - 2017-01-22 01:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 01:57:16 --> Controller Class Initialized
INFO - 2017-01-22 01:57:16 --> Helper loaded: url_helper
DEBUG - 2017-01-22 01:57:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 01:57:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 01:57:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 01:57:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 01:57:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 01:57:16 --> Final output sent to browser
DEBUG - 2017-01-22 01:57:16 --> Total execution time: 0.0136
INFO - 2017-01-22 03:03:34 --> Config Class Initialized
INFO - 2017-01-22 03:03:34 --> Hooks Class Initialized
DEBUG - 2017-01-22 03:03:34 --> UTF-8 Support Enabled
INFO - 2017-01-22 03:03:34 --> Utf8 Class Initialized
INFO - 2017-01-22 03:03:34 --> URI Class Initialized
INFO - 2017-01-22 03:03:34 --> Router Class Initialized
INFO - 2017-01-22 03:03:34 --> Output Class Initialized
INFO - 2017-01-22 03:03:34 --> Security Class Initialized
DEBUG - 2017-01-22 03:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 03:03:34 --> Input Class Initialized
INFO - 2017-01-22 03:03:34 --> Language Class Initialized
INFO - 2017-01-22 03:03:34 --> Loader Class Initialized
INFO - 2017-01-22 03:03:34 --> Database Driver Class Initialized
INFO - 2017-01-22 03:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 03:03:34 --> Controller Class Initialized
INFO - 2017-01-22 03:03:34 --> Helper loaded: url_helper
DEBUG - 2017-01-22 03:03:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 03:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 03:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 03:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 03:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 03:03:34 --> Final output sent to browser
DEBUG - 2017-01-22 03:03:34 --> Total execution time: 0.0144
INFO - 2017-01-22 03:03:38 --> Config Class Initialized
INFO - 2017-01-22 03:03:38 --> Hooks Class Initialized
DEBUG - 2017-01-22 03:03:38 --> UTF-8 Support Enabled
INFO - 2017-01-22 03:03:38 --> Utf8 Class Initialized
INFO - 2017-01-22 03:03:38 --> URI Class Initialized
DEBUG - 2017-01-22 03:03:38 --> No URI present. Default controller set.
INFO - 2017-01-22 03:03:38 --> Router Class Initialized
INFO - 2017-01-22 03:03:38 --> Output Class Initialized
INFO - 2017-01-22 03:03:38 --> Security Class Initialized
DEBUG - 2017-01-22 03:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 03:03:38 --> Input Class Initialized
INFO - 2017-01-22 03:03:38 --> Language Class Initialized
INFO - 2017-01-22 03:03:38 --> Loader Class Initialized
INFO - 2017-01-22 03:03:38 --> Database Driver Class Initialized
INFO - 2017-01-22 03:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 03:03:38 --> Controller Class Initialized
INFO - 2017-01-22 03:03:38 --> Helper loaded: url_helper
DEBUG - 2017-01-22 03:03:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 03:03:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 03:03:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 03:03:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 03:03:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 03:03:38 --> Final output sent to browser
DEBUG - 2017-01-22 03:03:38 --> Total execution time: 0.0130
INFO - 2017-01-22 05:01:07 --> Config Class Initialized
INFO - 2017-01-22 05:01:07 --> Hooks Class Initialized
DEBUG - 2017-01-22 05:01:07 --> UTF-8 Support Enabled
INFO - 2017-01-22 05:01:07 --> Utf8 Class Initialized
INFO - 2017-01-22 05:01:07 --> URI Class Initialized
DEBUG - 2017-01-22 05:01:07 --> No URI present. Default controller set.
INFO - 2017-01-22 05:01:07 --> Router Class Initialized
INFO - 2017-01-22 05:01:07 --> Output Class Initialized
INFO - 2017-01-22 05:01:07 --> Security Class Initialized
DEBUG - 2017-01-22 05:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 05:01:07 --> Input Class Initialized
INFO - 2017-01-22 05:01:07 --> Language Class Initialized
INFO - 2017-01-22 05:01:07 --> Loader Class Initialized
INFO - 2017-01-22 05:01:07 --> Database Driver Class Initialized
INFO - 2017-01-22 05:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 05:01:07 --> Controller Class Initialized
INFO - 2017-01-22 05:01:07 --> Helper loaded: url_helper
DEBUG - 2017-01-22 05:01:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 05:01:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 05:01:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 05:01:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 05:01:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 05:01:07 --> Final output sent to browser
DEBUG - 2017-01-22 05:01:07 --> Total execution time: 0.0144
INFO - 2017-01-22 05:01:11 --> Config Class Initialized
INFO - 2017-01-22 05:01:11 --> Hooks Class Initialized
DEBUG - 2017-01-22 05:01:11 --> UTF-8 Support Enabled
INFO - 2017-01-22 05:01:11 --> Utf8 Class Initialized
INFO - 2017-01-22 05:01:11 --> URI Class Initialized
INFO - 2017-01-22 05:01:11 --> Router Class Initialized
INFO - 2017-01-22 05:01:11 --> Output Class Initialized
INFO - 2017-01-22 05:01:11 --> Security Class Initialized
DEBUG - 2017-01-22 05:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 05:01:11 --> Input Class Initialized
INFO - 2017-01-22 05:01:11 --> Language Class Initialized
INFO - 2017-01-22 05:01:11 --> Loader Class Initialized
INFO - 2017-01-22 05:01:11 --> Database Driver Class Initialized
INFO - 2017-01-22 05:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 05:01:11 --> Controller Class Initialized
INFO - 2017-01-22 05:01:11 --> Helper loaded: url_helper
DEBUG - 2017-01-22 05:01:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 05:01:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 05:01:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 05:01:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 05:01:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 05:01:11 --> Final output sent to browser
DEBUG - 2017-01-22 05:01:11 --> Total execution time: 0.0143
INFO - 2017-01-22 05:01:19 --> Config Class Initialized
INFO - 2017-01-22 05:01:19 --> Hooks Class Initialized
DEBUG - 2017-01-22 05:01:19 --> UTF-8 Support Enabled
INFO - 2017-01-22 05:01:19 --> Utf8 Class Initialized
INFO - 2017-01-22 05:01:19 --> URI Class Initialized
INFO - 2017-01-22 05:01:19 --> Router Class Initialized
INFO - 2017-01-22 05:01:19 --> Output Class Initialized
INFO - 2017-01-22 05:01:19 --> Security Class Initialized
DEBUG - 2017-01-22 05:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 05:01:19 --> Input Class Initialized
INFO - 2017-01-22 05:01:19 --> Language Class Initialized
INFO - 2017-01-22 05:01:19 --> Loader Class Initialized
INFO - 2017-01-22 05:01:19 --> Database Driver Class Initialized
INFO - 2017-01-22 05:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 05:01:19 --> Controller Class Initialized
INFO - 2017-01-22 05:01:19 --> Helper loaded: url_helper
DEBUG - 2017-01-22 05:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 05:01:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-22 05:01:19 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-22 05:01:19 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-22 05:01:19 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-22 05:01:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 05:01:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 05:01:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 05:01:19 --> Final output sent to browser
DEBUG - 2017-01-22 05:01:19 --> Total execution time: 0.0150
INFO - 2017-01-22 05:01:23 --> Config Class Initialized
INFO - 2017-01-22 05:01:23 --> Hooks Class Initialized
DEBUG - 2017-01-22 05:01:23 --> UTF-8 Support Enabled
INFO - 2017-01-22 05:01:23 --> Utf8 Class Initialized
INFO - 2017-01-22 05:01:23 --> URI Class Initialized
INFO - 2017-01-22 05:01:23 --> Router Class Initialized
INFO - 2017-01-22 05:01:23 --> Output Class Initialized
INFO - 2017-01-22 05:01:23 --> Security Class Initialized
DEBUG - 2017-01-22 05:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 05:01:23 --> Input Class Initialized
INFO - 2017-01-22 05:01:23 --> Language Class Initialized
INFO - 2017-01-22 05:01:23 --> Loader Class Initialized
INFO - 2017-01-22 05:01:23 --> Database Driver Class Initialized
INFO - 2017-01-22 05:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 05:01:23 --> Controller Class Initialized
INFO - 2017-01-22 05:01:23 --> Helper loaded: url_helper
DEBUG - 2017-01-22 05:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 05:01:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 05:01:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 05:01:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 05:01:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 05:01:23 --> Final output sent to browser
DEBUG - 2017-01-22 05:01:23 --> Total execution time: 0.0132
INFO - 2017-01-22 05:01:53 --> Config Class Initialized
INFO - 2017-01-22 05:01:53 --> Hooks Class Initialized
DEBUG - 2017-01-22 05:01:53 --> UTF-8 Support Enabled
INFO - 2017-01-22 05:01:53 --> Utf8 Class Initialized
INFO - 2017-01-22 05:01:53 --> URI Class Initialized
DEBUG - 2017-01-22 05:01:53 --> No URI present. Default controller set.
INFO - 2017-01-22 05:01:53 --> Router Class Initialized
INFO - 2017-01-22 05:01:53 --> Output Class Initialized
INFO - 2017-01-22 05:01:53 --> Security Class Initialized
DEBUG - 2017-01-22 05:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 05:01:53 --> Input Class Initialized
INFO - 2017-01-22 05:01:53 --> Language Class Initialized
INFO - 2017-01-22 05:01:53 --> Loader Class Initialized
INFO - 2017-01-22 05:01:53 --> Database Driver Class Initialized
INFO - 2017-01-22 05:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 05:01:53 --> Controller Class Initialized
INFO - 2017-01-22 05:01:53 --> Helper loaded: url_helper
DEBUG - 2017-01-22 05:01:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 05:01:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 05:01:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 05:01:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 05:01:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 05:01:53 --> Final output sent to browser
DEBUG - 2017-01-22 05:01:53 --> Total execution time: 0.0505
INFO - 2017-01-22 05:01:55 --> Config Class Initialized
INFO - 2017-01-22 05:01:55 --> Hooks Class Initialized
DEBUG - 2017-01-22 05:01:55 --> UTF-8 Support Enabled
INFO - 2017-01-22 05:01:55 --> Utf8 Class Initialized
INFO - 2017-01-22 05:01:55 --> URI Class Initialized
INFO - 2017-01-22 05:01:55 --> Router Class Initialized
INFO - 2017-01-22 05:01:55 --> Output Class Initialized
INFO - 2017-01-22 05:01:55 --> Security Class Initialized
DEBUG - 2017-01-22 05:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 05:01:55 --> Input Class Initialized
INFO - 2017-01-22 05:01:55 --> Language Class Initialized
INFO - 2017-01-22 05:01:55 --> Loader Class Initialized
INFO - 2017-01-22 05:01:55 --> Database Driver Class Initialized
INFO - 2017-01-22 05:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 05:01:55 --> Controller Class Initialized
INFO - 2017-01-22 05:01:55 --> Helper loaded: url_helper
DEBUG - 2017-01-22 05:01:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 05:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 05:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 05:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 05:01:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 05:01:55 --> Final output sent to browser
DEBUG - 2017-01-22 05:01:55 --> Total execution time: 0.0147
INFO - 2017-01-22 05:02:27 --> Config Class Initialized
INFO - 2017-01-22 05:02:27 --> Hooks Class Initialized
DEBUG - 2017-01-22 05:02:27 --> UTF-8 Support Enabled
INFO - 2017-01-22 05:02:27 --> Utf8 Class Initialized
INFO - 2017-01-22 05:02:27 --> URI Class Initialized
INFO - 2017-01-22 05:02:27 --> Router Class Initialized
INFO - 2017-01-22 05:02:27 --> Output Class Initialized
INFO - 2017-01-22 05:02:27 --> Security Class Initialized
DEBUG - 2017-01-22 05:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 05:02:27 --> Input Class Initialized
INFO - 2017-01-22 05:02:27 --> Language Class Initialized
INFO - 2017-01-22 05:02:27 --> Loader Class Initialized
INFO - 2017-01-22 05:02:27 --> Database Driver Class Initialized
INFO - 2017-01-22 05:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 05:02:27 --> Controller Class Initialized
INFO - 2017-01-22 05:02:27 --> Helper loaded: url_helper
DEBUG - 2017-01-22 05:02:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 05:02:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 05:02:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 05:02:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 05:02:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 05:02:27 --> Final output sent to browser
DEBUG - 2017-01-22 05:02:27 --> Total execution time: 0.0258
INFO - 2017-01-22 05:02:30 --> Config Class Initialized
INFO - 2017-01-22 05:02:30 --> Hooks Class Initialized
DEBUG - 2017-01-22 05:02:30 --> UTF-8 Support Enabled
INFO - 2017-01-22 05:02:30 --> Utf8 Class Initialized
INFO - 2017-01-22 05:02:30 --> URI Class Initialized
INFO - 2017-01-22 05:02:30 --> Router Class Initialized
INFO - 2017-01-22 05:02:30 --> Output Class Initialized
INFO - 2017-01-22 05:02:30 --> Security Class Initialized
DEBUG - 2017-01-22 05:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 05:02:30 --> Input Class Initialized
INFO - 2017-01-22 05:02:30 --> Language Class Initialized
INFO - 2017-01-22 05:02:30 --> Loader Class Initialized
INFO - 2017-01-22 05:02:30 --> Database Driver Class Initialized
INFO - 2017-01-22 05:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 05:02:30 --> Controller Class Initialized
INFO - 2017-01-22 05:02:30 --> Helper loaded: url_helper
DEBUG - 2017-01-22 05:02:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 05:02:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 05:02:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 05:02:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 05:02:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 05:02:30 --> Final output sent to browser
DEBUG - 2017-01-22 05:02:30 --> Total execution time: 0.0141
INFO - 2017-01-22 05:02:43 --> Config Class Initialized
INFO - 2017-01-22 05:02:43 --> Hooks Class Initialized
DEBUG - 2017-01-22 05:02:43 --> UTF-8 Support Enabled
INFO - 2017-01-22 05:02:43 --> Utf8 Class Initialized
INFO - 2017-01-22 05:02:43 --> URI Class Initialized
INFO - 2017-01-22 05:02:43 --> Router Class Initialized
INFO - 2017-01-22 05:02:43 --> Output Class Initialized
INFO - 2017-01-22 05:02:43 --> Security Class Initialized
DEBUG - 2017-01-22 05:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 05:02:43 --> Input Class Initialized
INFO - 2017-01-22 05:02:43 --> Language Class Initialized
INFO - 2017-01-22 05:02:43 --> Loader Class Initialized
INFO - 2017-01-22 05:02:43 --> Database Driver Class Initialized
INFO - 2017-01-22 05:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 05:02:44 --> Controller Class Initialized
INFO - 2017-01-22 05:02:44 --> Helper loaded: url_helper
DEBUG - 2017-01-22 05:02:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 05:02:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 05:02:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 05:02:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 05:02:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 05:02:44 --> Final output sent to browser
DEBUG - 2017-01-22 05:02:44 --> Total execution time: 0.0198
INFO - 2017-01-22 05:02:46 --> Config Class Initialized
INFO - 2017-01-22 05:02:46 --> Hooks Class Initialized
DEBUG - 2017-01-22 05:02:46 --> UTF-8 Support Enabled
INFO - 2017-01-22 05:02:46 --> Utf8 Class Initialized
INFO - 2017-01-22 05:02:46 --> URI Class Initialized
INFO - 2017-01-22 05:02:46 --> Router Class Initialized
INFO - 2017-01-22 05:02:46 --> Output Class Initialized
INFO - 2017-01-22 05:02:46 --> Security Class Initialized
DEBUG - 2017-01-22 05:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 05:02:46 --> Input Class Initialized
INFO - 2017-01-22 05:02:46 --> Language Class Initialized
INFO - 2017-01-22 05:02:46 --> Loader Class Initialized
INFO - 2017-01-22 05:02:46 --> Database Driver Class Initialized
INFO - 2017-01-22 05:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 05:02:46 --> Controller Class Initialized
INFO - 2017-01-22 05:02:46 --> Helper loaded: url_helper
DEBUG - 2017-01-22 05:02:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 05:02:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 05:02:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 05:02:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 05:02:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 05:02:46 --> Final output sent to browser
DEBUG - 2017-01-22 05:02:46 --> Total execution time: 0.0131
INFO - 2017-01-22 05:03:03 --> Config Class Initialized
INFO - 2017-01-22 05:03:03 --> Hooks Class Initialized
DEBUG - 2017-01-22 05:03:03 --> UTF-8 Support Enabled
INFO - 2017-01-22 05:03:03 --> Utf8 Class Initialized
INFO - 2017-01-22 05:03:03 --> URI Class Initialized
INFO - 2017-01-22 05:03:03 --> Router Class Initialized
INFO - 2017-01-22 05:03:03 --> Output Class Initialized
INFO - 2017-01-22 05:03:03 --> Security Class Initialized
DEBUG - 2017-01-22 05:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 05:03:03 --> Input Class Initialized
INFO - 2017-01-22 05:03:03 --> Language Class Initialized
INFO - 2017-01-22 05:03:03 --> Loader Class Initialized
INFO - 2017-01-22 05:03:03 --> Database Driver Class Initialized
INFO - 2017-01-22 05:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 05:03:03 --> Controller Class Initialized
INFO - 2017-01-22 05:03:03 --> Helper loaded: url_helper
DEBUG - 2017-01-22 05:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 05:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 05:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 05:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 05:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 05:03:03 --> Final output sent to browser
DEBUG - 2017-01-22 05:03:03 --> Total execution time: 0.0145
INFO - 2017-01-22 05:03:06 --> Config Class Initialized
INFO - 2017-01-22 05:03:06 --> Hooks Class Initialized
DEBUG - 2017-01-22 05:03:06 --> UTF-8 Support Enabled
INFO - 2017-01-22 05:03:06 --> Utf8 Class Initialized
INFO - 2017-01-22 05:03:06 --> URI Class Initialized
INFO - 2017-01-22 05:03:06 --> Router Class Initialized
INFO - 2017-01-22 05:03:06 --> Output Class Initialized
INFO - 2017-01-22 05:03:06 --> Security Class Initialized
DEBUG - 2017-01-22 05:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 05:03:06 --> Input Class Initialized
INFO - 2017-01-22 05:03:06 --> Language Class Initialized
INFO - 2017-01-22 05:03:06 --> Loader Class Initialized
INFO - 2017-01-22 05:03:06 --> Database Driver Class Initialized
INFO - 2017-01-22 05:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 05:03:06 --> Controller Class Initialized
INFO - 2017-01-22 05:03:06 --> Helper loaded: url_helper
DEBUG - 2017-01-22 05:03:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 05:03:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 05:03:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 05:03:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 05:03:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 05:03:06 --> Final output sent to browser
DEBUG - 2017-01-22 05:03:06 --> Total execution time: 0.0135
INFO - 2017-01-22 06:17:23 --> Config Class Initialized
INFO - 2017-01-22 06:17:23 --> Hooks Class Initialized
DEBUG - 2017-01-22 06:17:23 --> UTF-8 Support Enabled
INFO - 2017-01-22 06:17:23 --> Utf8 Class Initialized
INFO - 2017-01-22 06:17:23 --> URI Class Initialized
DEBUG - 2017-01-22 06:17:23 --> No URI present. Default controller set.
INFO - 2017-01-22 06:17:23 --> Router Class Initialized
INFO - 2017-01-22 06:17:23 --> Output Class Initialized
INFO - 2017-01-22 06:17:23 --> Security Class Initialized
DEBUG - 2017-01-22 06:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 06:17:23 --> Input Class Initialized
INFO - 2017-01-22 06:17:23 --> Language Class Initialized
INFO - 2017-01-22 06:17:23 --> Loader Class Initialized
INFO - 2017-01-22 06:17:23 --> Database Driver Class Initialized
INFO - 2017-01-22 06:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 06:17:23 --> Controller Class Initialized
INFO - 2017-01-22 06:17:23 --> Helper loaded: url_helper
DEBUG - 2017-01-22 06:17:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 06:17:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 06:17:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 06:17:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 06:17:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 06:17:23 --> Final output sent to browser
DEBUG - 2017-01-22 06:17:23 --> Total execution time: 0.0131
INFO - 2017-01-22 07:43:32 --> Config Class Initialized
INFO - 2017-01-22 07:43:32 --> Hooks Class Initialized
DEBUG - 2017-01-22 07:43:32 --> UTF-8 Support Enabled
INFO - 2017-01-22 07:43:32 --> Utf8 Class Initialized
INFO - 2017-01-22 07:43:32 --> URI Class Initialized
INFO - 2017-01-22 07:43:32 --> Router Class Initialized
INFO - 2017-01-22 07:43:32 --> Output Class Initialized
INFO - 2017-01-22 07:43:32 --> Security Class Initialized
DEBUG - 2017-01-22 07:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 07:43:32 --> Input Class Initialized
INFO - 2017-01-22 07:43:32 --> Language Class Initialized
INFO - 2017-01-22 07:43:32 --> Loader Class Initialized
INFO - 2017-01-22 07:43:32 --> Database Driver Class Initialized
INFO - 2017-01-22 07:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 07:43:32 --> Controller Class Initialized
INFO - 2017-01-22 07:43:32 --> Helper loaded: url_helper
DEBUG - 2017-01-22 07:43:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 07:43:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 07:43:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 07:43:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 07:43:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 07:43:32 --> Final output sent to browser
DEBUG - 2017-01-22 07:43:32 --> Total execution time: 0.0159
INFO - 2017-01-22 07:43:33 --> Config Class Initialized
INFO - 2017-01-22 07:43:33 --> Hooks Class Initialized
DEBUG - 2017-01-22 07:43:33 --> UTF-8 Support Enabled
INFO - 2017-01-22 07:43:33 --> Utf8 Class Initialized
INFO - 2017-01-22 07:43:33 --> URI Class Initialized
INFO - 2017-01-22 07:43:33 --> Router Class Initialized
INFO - 2017-01-22 07:43:33 --> Output Class Initialized
INFO - 2017-01-22 07:43:33 --> Security Class Initialized
DEBUG - 2017-01-22 07:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 07:43:33 --> Input Class Initialized
INFO - 2017-01-22 07:43:33 --> Language Class Initialized
ERROR - 2017-01-22 07:43:33 --> 404 Page Not Found: Well-known/apple-app-site-association
INFO - 2017-01-22 10:43:15 --> Config Class Initialized
INFO - 2017-01-22 10:43:15 --> Hooks Class Initialized
DEBUG - 2017-01-22 10:43:15 --> UTF-8 Support Enabled
INFO - 2017-01-22 10:43:15 --> Utf8 Class Initialized
INFO - 2017-01-22 10:43:15 --> URI Class Initialized
DEBUG - 2017-01-22 10:43:15 --> No URI present. Default controller set.
INFO - 2017-01-22 10:43:15 --> Router Class Initialized
INFO - 2017-01-22 10:43:15 --> Output Class Initialized
INFO - 2017-01-22 10:43:15 --> Security Class Initialized
DEBUG - 2017-01-22 10:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 10:43:15 --> Input Class Initialized
INFO - 2017-01-22 10:43:15 --> Language Class Initialized
INFO - 2017-01-22 10:43:15 --> Loader Class Initialized
INFO - 2017-01-22 10:43:16 --> Database Driver Class Initialized
INFO - 2017-01-22 10:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 10:43:16 --> Controller Class Initialized
INFO - 2017-01-22 10:43:16 --> Helper loaded: url_helper
DEBUG - 2017-01-22 10:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 10:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 10:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 10:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 10:43:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 10:43:16 --> Final output sent to browser
DEBUG - 2017-01-22 10:43:16 --> Total execution time: 1.0329
INFO - 2017-01-22 10:53:50 --> Config Class Initialized
INFO - 2017-01-22 10:53:50 --> Hooks Class Initialized
DEBUG - 2017-01-22 10:53:50 --> UTF-8 Support Enabled
INFO - 2017-01-22 10:53:50 --> Utf8 Class Initialized
INFO - 2017-01-22 10:53:50 --> URI Class Initialized
INFO - 2017-01-22 10:53:50 --> Router Class Initialized
INFO - 2017-01-22 10:53:50 --> Output Class Initialized
INFO - 2017-01-22 10:53:50 --> Security Class Initialized
DEBUG - 2017-01-22 10:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 10:53:50 --> Input Class Initialized
INFO - 2017-01-22 10:53:50 --> Language Class Initialized
INFO - 2017-01-22 10:53:50 --> Loader Class Initialized
INFO - 2017-01-22 10:53:50 --> Database Driver Class Initialized
INFO - 2017-01-22 10:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 10:53:50 --> Controller Class Initialized
INFO - 2017-01-22 10:53:50 --> Helper loaded: url_helper
DEBUG - 2017-01-22 10:53:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 10:53:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 10:53:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 10:53:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 10:53:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 10:53:50 --> Final output sent to browser
DEBUG - 2017-01-22 10:53:50 --> Total execution time: 0.0229
INFO - 2017-01-22 11:38:21 --> Config Class Initialized
INFO - 2017-01-22 11:38:21 --> Hooks Class Initialized
DEBUG - 2017-01-22 11:38:21 --> UTF-8 Support Enabled
INFO - 2017-01-22 11:38:21 --> Utf8 Class Initialized
INFO - 2017-01-22 11:38:21 --> URI Class Initialized
INFO - 2017-01-22 11:38:21 --> Router Class Initialized
INFO - 2017-01-22 11:38:21 --> Output Class Initialized
INFO - 2017-01-22 11:38:21 --> Security Class Initialized
DEBUG - 2017-01-22 11:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 11:38:21 --> Input Class Initialized
INFO - 2017-01-22 11:38:21 --> Language Class Initialized
INFO - 2017-01-22 11:38:21 --> Loader Class Initialized
INFO - 2017-01-22 11:38:21 --> Database Driver Class Initialized
INFO - 2017-01-22 11:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 11:38:21 --> Controller Class Initialized
INFO - 2017-01-22 11:38:21 --> Helper loaded: url_helper
DEBUG - 2017-01-22 11:38:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 11:38:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 11:38:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 11:38:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 11:38:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 11:38:21 --> Final output sent to browser
DEBUG - 2017-01-22 11:38:21 --> Total execution time: 0.0782
INFO - 2017-01-22 11:38:21 --> Config Class Initialized
INFO - 2017-01-22 11:38:21 --> Hooks Class Initialized
DEBUG - 2017-01-22 11:38:21 --> UTF-8 Support Enabled
INFO - 2017-01-22 11:38:21 --> Utf8 Class Initialized
INFO - 2017-01-22 11:38:21 --> URI Class Initialized
DEBUG - 2017-01-22 11:38:21 --> No URI present. Default controller set.
INFO - 2017-01-22 11:38:21 --> Router Class Initialized
INFO - 2017-01-22 11:38:21 --> Output Class Initialized
INFO - 2017-01-22 11:38:21 --> Security Class Initialized
DEBUG - 2017-01-22 11:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 11:38:21 --> Input Class Initialized
INFO - 2017-01-22 11:38:21 --> Language Class Initialized
INFO - 2017-01-22 11:38:21 --> Loader Class Initialized
INFO - 2017-01-22 11:38:21 --> Database Driver Class Initialized
INFO - 2017-01-22 11:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 11:38:21 --> Controller Class Initialized
INFO - 2017-01-22 11:38:21 --> Helper loaded: url_helper
DEBUG - 2017-01-22 11:38:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 11:38:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 11:38:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 11:38:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 11:38:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 11:38:21 --> Final output sent to browser
DEBUG - 2017-01-22 11:38:21 --> Total execution time: 0.0148
INFO - 2017-01-22 15:13:22 --> Config Class Initialized
INFO - 2017-01-22 15:13:22 --> Hooks Class Initialized
DEBUG - 2017-01-22 15:13:22 --> UTF-8 Support Enabled
INFO - 2017-01-22 15:13:22 --> Utf8 Class Initialized
INFO - 2017-01-22 15:13:22 --> URI Class Initialized
INFO - 2017-01-22 15:13:22 --> Router Class Initialized
INFO - 2017-01-22 15:13:22 --> Output Class Initialized
INFO - 2017-01-22 15:13:22 --> Security Class Initialized
DEBUG - 2017-01-22 15:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 15:13:22 --> Input Class Initialized
INFO - 2017-01-22 15:13:22 --> Language Class Initialized
INFO - 2017-01-22 15:13:22 --> Loader Class Initialized
INFO - 2017-01-22 15:13:22 --> Database Driver Class Initialized
INFO - 2017-01-22 15:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 15:13:22 --> Controller Class Initialized
INFO - 2017-01-22 15:13:22 --> Helper loaded: url_helper
DEBUG - 2017-01-22 15:13:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 15:13:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 15:13:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 15:13:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 15:13:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 15:13:22 --> Final output sent to browser
DEBUG - 2017-01-22 15:13:22 --> Total execution time: 0.0309
INFO - 2017-01-22 15:28:46 --> Config Class Initialized
INFO - 2017-01-22 15:28:46 --> Hooks Class Initialized
DEBUG - 2017-01-22 15:28:46 --> UTF-8 Support Enabled
INFO - 2017-01-22 15:28:46 --> Utf8 Class Initialized
INFO - 2017-01-22 15:28:46 --> URI Class Initialized
DEBUG - 2017-01-22 15:28:46 --> No URI present. Default controller set.
INFO - 2017-01-22 15:28:46 --> Router Class Initialized
INFO - 2017-01-22 15:28:46 --> Output Class Initialized
INFO - 2017-01-22 15:28:46 --> Security Class Initialized
DEBUG - 2017-01-22 15:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 15:28:46 --> Input Class Initialized
INFO - 2017-01-22 15:28:46 --> Language Class Initialized
INFO - 2017-01-22 15:28:46 --> Loader Class Initialized
INFO - 2017-01-22 15:28:46 --> Database Driver Class Initialized
INFO - 2017-01-22 15:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 15:28:46 --> Controller Class Initialized
INFO - 2017-01-22 15:28:46 --> Helper loaded: url_helper
DEBUG - 2017-01-22 15:28:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 15:28:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 15:28:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 15:28:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 15:28:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 15:28:46 --> Final output sent to browser
DEBUG - 2017-01-22 15:28:46 --> Total execution time: 0.0389
INFO - 2017-01-22 23:24:10 --> Config Class Initialized
INFO - 2017-01-22 23:24:10 --> Hooks Class Initialized
DEBUG - 2017-01-22 23:24:10 --> UTF-8 Support Enabled
INFO - 2017-01-22 23:24:10 --> Utf8 Class Initialized
INFO - 2017-01-22 23:24:10 --> URI Class Initialized
DEBUG - 2017-01-22 23:24:10 --> No URI present. Default controller set.
INFO - 2017-01-22 23:24:10 --> Router Class Initialized
INFO - 2017-01-22 23:24:10 --> Output Class Initialized
INFO - 2017-01-22 23:24:10 --> Security Class Initialized
DEBUG - 2017-01-22 23:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 23:24:10 --> Input Class Initialized
INFO - 2017-01-22 23:24:10 --> Language Class Initialized
INFO - 2017-01-22 23:24:10 --> Loader Class Initialized
INFO - 2017-01-22 23:24:11 --> Database Driver Class Initialized
INFO - 2017-01-22 23:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 23:24:11 --> Controller Class Initialized
INFO - 2017-01-22 23:24:11 --> Helper loaded: url_helper
DEBUG - 2017-01-22 23:24:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 23:24:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 23:24:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 23:24:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 23:24:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 23:24:11 --> Final output sent to browser
DEBUG - 2017-01-22 23:24:11 --> Total execution time: 1.1536
INFO - 2017-01-22 23:24:21 --> Config Class Initialized
INFO - 2017-01-22 23:24:21 --> Hooks Class Initialized
DEBUG - 2017-01-22 23:24:21 --> UTF-8 Support Enabled
INFO - 2017-01-22 23:24:21 --> Utf8 Class Initialized
INFO - 2017-01-22 23:24:21 --> URI Class Initialized
INFO - 2017-01-22 23:24:21 --> Router Class Initialized
INFO - 2017-01-22 23:24:21 --> Output Class Initialized
INFO - 2017-01-22 23:24:21 --> Security Class Initialized
DEBUG - 2017-01-22 23:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 23:24:21 --> Input Class Initialized
INFO - 2017-01-22 23:24:21 --> Language Class Initialized
INFO - 2017-01-22 23:24:21 --> Loader Class Initialized
INFO - 2017-01-22 23:24:21 --> Database Driver Class Initialized
INFO - 2017-01-22 23:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 23:24:21 --> Controller Class Initialized
INFO - 2017-01-22 23:24:21 --> Helper loaded: url_helper
DEBUG - 2017-01-22 23:24:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 23:24:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 23:24:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 23:24:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 23:24:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 23:24:21 --> Final output sent to browser
DEBUG - 2017-01-22 23:24:21 --> Total execution time: 0.0140
INFO - 2017-01-22 23:25:09 --> Config Class Initialized
INFO - 2017-01-22 23:25:09 --> Hooks Class Initialized
DEBUG - 2017-01-22 23:25:09 --> UTF-8 Support Enabled
INFO - 2017-01-22 23:25:09 --> Utf8 Class Initialized
INFO - 2017-01-22 23:25:09 --> URI Class Initialized
INFO - 2017-01-22 23:25:09 --> Router Class Initialized
INFO - 2017-01-22 23:25:09 --> Output Class Initialized
INFO - 2017-01-22 23:25:09 --> Security Class Initialized
DEBUG - 2017-01-22 23:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 23:25:09 --> Input Class Initialized
INFO - 2017-01-22 23:25:09 --> Language Class Initialized
INFO - 2017-01-22 23:25:09 --> Loader Class Initialized
INFO - 2017-01-22 23:25:09 --> Database Driver Class Initialized
INFO - 2017-01-22 23:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 23:25:09 --> Controller Class Initialized
INFO - 2017-01-22 23:25:09 --> Helper loaded: url_helper
DEBUG - 2017-01-22 23:25:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 23:25:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-22 23:25:09 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-22 23:25:09 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-22 23:25:09 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-22 23:25:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 23:25:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 23:25:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 23:25:09 --> Final output sent to browser
DEBUG - 2017-01-22 23:25:09 --> Total execution time: 0.2949
INFO - 2017-01-22 23:25:14 --> Config Class Initialized
INFO - 2017-01-22 23:25:14 --> Hooks Class Initialized
DEBUG - 2017-01-22 23:25:14 --> UTF-8 Support Enabled
INFO - 2017-01-22 23:25:14 --> Utf8 Class Initialized
INFO - 2017-01-22 23:25:14 --> URI Class Initialized
INFO - 2017-01-22 23:25:14 --> Router Class Initialized
INFO - 2017-01-22 23:25:14 --> Output Class Initialized
INFO - 2017-01-22 23:25:14 --> Security Class Initialized
DEBUG - 2017-01-22 23:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 23:25:14 --> Input Class Initialized
INFO - 2017-01-22 23:25:14 --> Language Class Initialized
INFO - 2017-01-22 23:25:14 --> Loader Class Initialized
INFO - 2017-01-22 23:25:14 --> Database Driver Class Initialized
INFO - 2017-01-22 23:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 23:25:14 --> Controller Class Initialized
INFO - 2017-01-22 23:25:14 --> Helper loaded: url_helper
DEBUG - 2017-01-22 23:25:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 23:25:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 23:25:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 23:25:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 23:25:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 23:25:14 --> Final output sent to browser
DEBUG - 2017-01-22 23:25:14 --> Total execution time: 0.0137
INFO - 2017-01-22 23:25:30 --> Config Class Initialized
INFO - 2017-01-22 23:25:30 --> Hooks Class Initialized
DEBUG - 2017-01-22 23:25:30 --> UTF-8 Support Enabled
INFO - 2017-01-22 23:25:30 --> Utf8 Class Initialized
INFO - 2017-01-22 23:25:30 --> URI Class Initialized
INFO - 2017-01-22 23:25:30 --> Router Class Initialized
INFO - 2017-01-22 23:25:30 --> Output Class Initialized
INFO - 2017-01-22 23:25:30 --> Security Class Initialized
DEBUG - 2017-01-22 23:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 23:25:30 --> Input Class Initialized
INFO - 2017-01-22 23:25:30 --> Language Class Initialized
INFO - 2017-01-22 23:25:30 --> Loader Class Initialized
INFO - 2017-01-22 23:25:30 --> Database Driver Class Initialized
INFO - 2017-01-22 23:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 23:25:30 --> Controller Class Initialized
INFO - 2017-01-22 23:25:30 --> Helper loaded: url_helper
DEBUG - 2017-01-22 23:25:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 23:25:32 --> Config Class Initialized
INFO - 2017-01-22 23:25:32 --> Hooks Class Initialized
DEBUG - 2017-01-22 23:25:32 --> UTF-8 Support Enabled
INFO - 2017-01-22 23:25:32 --> Utf8 Class Initialized
INFO - 2017-01-22 23:25:32 --> URI Class Initialized
INFO - 2017-01-22 23:25:32 --> Router Class Initialized
INFO - 2017-01-22 23:25:32 --> Output Class Initialized
INFO - 2017-01-22 23:25:32 --> Security Class Initialized
DEBUG - 2017-01-22 23:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 23:25:32 --> Input Class Initialized
INFO - 2017-01-22 23:25:32 --> Language Class Initialized
INFO - 2017-01-22 23:25:32 --> Loader Class Initialized
INFO - 2017-01-22 23:25:32 --> Database Driver Class Initialized
INFO - 2017-01-22 23:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 23:25:32 --> Controller Class Initialized
INFO - 2017-01-22 23:25:33 --> Helper loaded: date_helper
DEBUG - 2017-01-22 23:25:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 23:25:33 --> Helper loaded: url_helper
INFO - 2017-01-22 23:25:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 23:25:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-22 23:25:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-22 23:25:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-22 23:25:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 23:25:33 --> Final output sent to browser
DEBUG - 2017-01-22 23:25:33 --> Total execution time: 0.3645
INFO - 2017-01-22 23:25:34 --> Config Class Initialized
INFO - 2017-01-22 23:25:34 --> Hooks Class Initialized
DEBUG - 2017-01-22 23:25:34 --> UTF-8 Support Enabled
INFO - 2017-01-22 23:25:34 --> Utf8 Class Initialized
INFO - 2017-01-22 23:25:34 --> URI Class Initialized
INFO - 2017-01-22 23:25:34 --> Router Class Initialized
INFO - 2017-01-22 23:25:34 --> Output Class Initialized
INFO - 2017-01-22 23:25:34 --> Security Class Initialized
DEBUG - 2017-01-22 23:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 23:25:34 --> Input Class Initialized
INFO - 2017-01-22 23:25:34 --> Language Class Initialized
INFO - 2017-01-22 23:25:34 --> Loader Class Initialized
INFO - 2017-01-22 23:25:34 --> Database Driver Class Initialized
INFO - 2017-01-22 23:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 23:25:34 --> Controller Class Initialized
INFO - 2017-01-22 23:25:34 --> Helper loaded: url_helper
DEBUG - 2017-01-22 23:25:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 23:25:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 23:25:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 23:25:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 23:25:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 23:25:34 --> Final output sent to browser
DEBUG - 2017-01-22 23:25:34 --> Total execution time: 0.0139
INFO - 2017-01-22 23:25:40 --> Config Class Initialized
INFO - 2017-01-22 23:25:40 --> Hooks Class Initialized
DEBUG - 2017-01-22 23:25:40 --> UTF-8 Support Enabled
INFO - 2017-01-22 23:25:40 --> Utf8 Class Initialized
INFO - 2017-01-22 23:25:40 --> URI Class Initialized
DEBUG - 2017-01-22 23:25:40 --> No URI present. Default controller set.
INFO - 2017-01-22 23:25:40 --> Router Class Initialized
INFO - 2017-01-22 23:25:40 --> Output Class Initialized
INFO - 2017-01-22 23:25:40 --> Security Class Initialized
DEBUG - 2017-01-22 23:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 23:25:40 --> Input Class Initialized
INFO - 2017-01-22 23:25:40 --> Language Class Initialized
INFO - 2017-01-22 23:25:40 --> Loader Class Initialized
INFO - 2017-01-22 23:25:40 --> Database Driver Class Initialized
INFO - 2017-01-22 23:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 23:25:40 --> Controller Class Initialized
INFO - 2017-01-22 23:25:40 --> Helper loaded: url_helper
DEBUG - 2017-01-22 23:25:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 23:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 23:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 23:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 23:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 23:25:40 --> Final output sent to browser
DEBUG - 2017-01-22 23:25:40 --> Total execution time: 0.0142
INFO - 2017-01-22 23:25:43 --> Config Class Initialized
INFO - 2017-01-22 23:25:43 --> Hooks Class Initialized
DEBUG - 2017-01-22 23:25:43 --> UTF-8 Support Enabled
INFO - 2017-01-22 23:25:43 --> Utf8 Class Initialized
INFO - 2017-01-22 23:25:43 --> URI Class Initialized
INFO - 2017-01-22 23:25:43 --> Router Class Initialized
INFO - 2017-01-22 23:25:43 --> Output Class Initialized
INFO - 2017-01-22 23:25:43 --> Security Class Initialized
DEBUG - 2017-01-22 23:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 23:25:43 --> Input Class Initialized
INFO - 2017-01-22 23:25:43 --> Language Class Initialized
INFO - 2017-01-22 23:25:43 --> Loader Class Initialized
INFO - 2017-01-22 23:25:43 --> Database Driver Class Initialized
INFO - 2017-01-22 23:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 23:25:43 --> Controller Class Initialized
INFO - 2017-01-22 23:25:43 --> Helper loaded: url_helper
DEBUG - 2017-01-22 23:25:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 23:25:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 23:25:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 23:25:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 23:25:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 23:25:43 --> Final output sent to browser
DEBUG - 2017-01-22 23:25:43 --> Total execution time: 0.0142
INFO - 2017-01-22 23:57:15 --> Config Class Initialized
INFO - 2017-01-22 23:57:15 --> Hooks Class Initialized
DEBUG - 2017-01-22 23:57:15 --> UTF-8 Support Enabled
INFO - 2017-01-22 23:57:15 --> Utf8 Class Initialized
INFO - 2017-01-22 23:57:15 --> URI Class Initialized
DEBUG - 2017-01-22 23:57:15 --> No URI present. Default controller set.
INFO - 2017-01-22 23:57:15 --> Router Class Initialized
INFO - 2017-01-22 23:57:15 --> Output Class Initialized
INFO - 2017-01-22 23:57:15 --> Security Class Initialized
DEBUG - 2017-01-22 23:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-22 23:57:15 --> Input Class Initialized
INFO - 2017-01-22 23:57:15 --> Language Class Initialized
INFO - 2017-01-22 23:57:15 --> Loader Class Initialized
INFO - 2017-01-22 23:57:15 --> Database Driver Class Initialized
INFO - 2017-01-22 23:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-22 23:57:15 --> Controller Class Initialized
INFO - 2017-01-22 23:57:15 --> Helper loaded: url_helper
DEBUG - 2017-01-22 23:57:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-22 23:57:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-22 23:57:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-22 23:57:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-22 23:57:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-22 23:57:15 --> Final output sent to browser
DEBUG - 2017-01-22 23:57:15 --> Total execution time: 0.0136

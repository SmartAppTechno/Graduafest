<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-05 18:26:16 --> Config Class Initialized
INFO - 2016-12-05 18:26:16 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:26:17 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:26:17 --> Utf8 Class Initialized
INFO - 2016-12-05 18:26:17 --> URI Class Initialized
DEBUG - 2016-12-05 18:26:17 --> No URI present. Default controller set.
INFO - 2016-12-05 18:26:17 --> Router Class Initialized
INFO - 2016-12-05 18:26:17 --> Output Class Initialized
INFO - 2016-12-05 18:26:17 --> Security Class Initialized
DEBUG - 2016-12-05 18:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:26:17 --> Input Class Initialized
INFO - 2016-12-05 18:26:17 --> Language Class Initialized
INFO - 2016-12-05 18:26:17 --> Loader Class Initialized
INFO - 2016-12-05 18:26:17 --> Database Driver Class Initialized
INFO - 2016-12-05 18:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:26:17 --> Controller Class Initialized
INFO - 2016-12-05 18:26:17 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:26:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:26:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:26:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:26:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:26:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:26:18 --> Final output sent to browser
DEBUG - 2016-12-05 18:26:18 --> Total execution time: 1.3713
INFO - 2016-12-05 18:26:18 --> Config Class Initialized
INFO - 2016-12-05 18:26:18 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:26:18 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:26:18 --> Utf8 Class Initialized
INFO - 2016-12-05 18:26:18 --> URI Class Initialized
INFO - 2016-12-05 18:26:18 --> Router Class Initialized
INFO - 2016-12-05 18:26:18 --> Output Class Initialized
INFO - 2016-12-05 18:26:18 --> Security Class Initialized
DEBUG - 2016-12-05 18:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:26:18 --> Input Class Initialized
INFO - 2016-12-05 18:26:18 --> Language Class Initialized
INFO - 2016-12-05 18:26:18 --> Loader Class Initialized
INFO - 2016-12-05 18:26:19 --> Database Driver Class Initialized
INFO - 2016-12-05 18:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:26:19 --> Controller Class Initialized
INFO - 2016-12-05 18:26:19 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:26:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:26:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:26:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:26:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:26:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:26:19 --> Final output sent to browser
DEBUG - 2016-12-05 18:26:19 --> Total execution time: 0.0131
INFO - 2016-12-05 18:26:21 --> Config Class Initialized
INFO - 2016-12-05 18:26:21 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:26:21 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:26:21 --> Utf8 Class Initialized
INFO - 2016-12-05 18:26:21 --> URI Class Initialized
INFO - 2016-12-05 18:26:21 --> Router Class Initialized
INFO - 2016-12-05 18:26:21 --> Output Class Initialized
INFO - 2016-12-05 18:26:21 --> Security Class Initialized
DEBUG - 2016-12-05 18:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:26:21 --> Input Class Initialized
INFO - 2016-12-05 18:26:21 --> Language Class Initialized
INFO - 2016-12-05 18:26:21 --> Loader Class Initialized
INFO - 2016-12-05 18:26:21 --> Database Driver Class Initialized
INFO - 2016-12-05 18:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:26:21 --> Controller Class Initialized
INFO - 2016-12-05 18:26:21 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:26:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:26:21 --> Final output sent to browser
DEBUG - 2016-12-05 18:26:21 --> Total execution time: 0.0325
INFO - 2016-12-05 18:26:21 --> Config Class Initialized
INFO - 2016-12-05 18:26:21 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:26:21 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:26:21 --> Utf8 Class Initialized
INFO - 2016-12-05 18:26:21 --> URI Class Initialized
INFO - 2016-12-05 18:26:21 --> Router Class Initialized
INFO - 2016-12-05 18:26:21 --> Output Class Initialized
INFO - 2016-12-05 18:26:21 --> Security Class Initialized
DEBUG - 2016-12-05 18:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:26:21 --> Input Class Initialized
INFO - 2016-12-05 18:26:21 --> Language Class Initialized
INFO - 2016-12-05 18:26:21 --> Loader Class Initialized
INFO - 2016-12-05 18:26:21 --> Database Driver Class Initialized
INFO - 2016-12-05 18:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:26:21 --> Controller Class Initialized
INFO - 2016-12-05 18:26:21 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:26:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:26:21 --> Final output sent to browser
DEBUG - 2016-12-05 18:26:21 --> Total execution time: 0.0134
INFO - 2016-12-05 18:26:36 --> Config Class Initialized
INFO - 2016-12-05 18:26:36 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:26:36 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:26:36 --> Utf8 Class Initialized
INFO - 2016-12-05 18:26:36 --> URI Class Initialized
INFO - 2016-12-05 18:26:36 --> Router Class Initialized
INFO - 2016-12-05 18:26:36 --> Output Class Initialized
INFO - 2016-12-05 18:26:36 --> Security Class Initialized
DEBUG - 2016-12-05 18:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:26:36 --> Input Class Initialized
INFO - 2016-12-05 18:26:36 --> Language Class Initialized
INFO - 2016-12-05 18:26:36 --> Loader Class Initialized
INFO - 2016-12-05 18:26:36 --> Database Driver Class Initialized
INFO - 2016-12-05 18:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:26:36 --> Controller Class Initialized
INFO - 2016-12-05 18:26:36 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:26:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:26:36 --> Final output sent to browser
DEBUG - 2016-12-05 18:26:36 --> Total execution time: 0.0149
INFO - 2016-12-05 18:26:36 --> Config Class Initialized
INFO - 2016-12-05 18:26:36 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:26:36 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:26:36 --> Utf8 Class Initialized
INFO - 2016-12-05 18:26:36 --> URI Class Initialized
INFO - 2016-12-05 18:26:36 --> Router Class Initialized
INFO - 2016-12-05 18:26:36 --> Output Class Initialized
INFO - 2016-12-05 18:26:36 --> Security Class Initialized
DEBUG - 2016-12-05 18:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:26:36 --> Input Class Initialized
INFO - 2016-12-05 18:26:36 --> Language Class Initialized
INFO - 2016-12-05 18:26:36 --> Loader Class Initialized
INFO - 2016-12-05 18:26:36 --> Database Driver Class Initialized
INFO - 2016-12-05 18:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:26:36 --> Controller Class Initialized
INFO - 2016-12-05 18:26:36 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:26:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:26:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:26:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:26:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:26:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:26:36 --> Final output sent to browser
DEBUG - 2016-12-05 18:26:36 --> Total execution time: 0.0553
INFO - 2016-12-05 18:26:43 --> Config Class Initialized
INFO - 2016-12-05 18:26:43 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:26:43 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:26:43 --> Utf8 Class Initialized
INFO - 2016-12-05 18:26:43 --> URI Class Initialized
DEBUG - 2016-12-05 18:26:43 --> No URI present. Default controller set.
INFO - 2016-12-05 18:26:43 --> Router Class Initialized
INFO - 2016-12-05 18:26:43 --> Output Class Initialized
INFO - 2016-12-05 18:26:43 --> Security Class Initialized
DEBUG - 2016-12-05 18:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:26:43 --> Input Class Initialized
INFO - 2016-12-05 18:26:43 --> Language Class Initialized
INFO - 2016-12-05 18:26:43 --> Loader Class Initialized
INFO - 2016-12-05 18:26:43 --> Database Driver Class Initialized
INFO - 2016-12-05 18:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:26:43 --> Controller Class Initialized
INFO - 2016-12-05 18:26:43 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:26:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:26:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:26:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:26:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:26:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:26:43 --> Final output sent to browser
DEBUG - 2016-12-05 18:26:43 --> Total execution time: 0.0223
INFO - 2016-12-05 18:26:44 --> Config Class Initialized
INFO - 2016-12-05 18:26:44 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:26:44 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:26:44 --> Utf8 Class Initialized
INFO - 2016-12-05 18:26:44 --> URI Class Initialized
INFO - 2016-12-05 18:26:44 --> Router Class Initialized
INFO - 2016-12-05 18:26:44 --> Output Class Initialized
INFO - 2016-12-05 18:26:44 --> Security Class Initialized
DEBUG - 2016-12-05 18:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:26:44 --> Input Class Initialized
INFO - 2016-12-05 18:26:44 --> Language Class Initialized
INFO - 2016-12-05 18:26:44 --> Loader Class Initialized
INFO - 2016-12-05 18:26:44 --> Database Driver Class Initialized
INFO - 2016-12-05 18:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:26:44 --> Controller Class Initialized
INFO - 2016-12-05 18:26:44 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:26:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:26:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:26:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:26:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:26:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:26:44 --> Final output sent to browser
DEBUG - 2016-12-05 18:26:44 --> Total execution time: 0.0159
INFO - 2016-12-05 18:26:50 --> Config Class Initialized
INFO - 2016-12-05 18:26:50 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:26:50 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:26:50 --> Utf8 Class Initialized
INFO - 2016-12-05 18:26:50 --> URI Class Initialized
DEBUG - 2016-12-05 18:26:50 --> No URI present. Default controller set.
INFO - 2016-12-05 18:26:50 --> Router Class Initialized
INFO - 2016-12-05 18:26:50 --> Output Class Initialized
INFO - 2016-12-05 18:26:50 --> Security Class Initialized
DEBUG - 2016-12-05 18:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:26:50 --> Input Class Initialized
INFO - 2016-12-05 18:26:50 --> Language Class Initialized
INFO - 2016-12-05 18:26:50 --> Loader Class Initialized
INFO - 2016-12-05 18:26:50 --> Database Driver Class Initialized
INFO - 2016-12-05 18:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:26:50 --> Controller Class Initialized
INFO - 2016-12-05 18:26:50 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:26:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:26:50 --> Final output sent to browser
DEBUG - 2016-12-05 18:26:50 --> Total execution time: 0.0211
INFO - 2016-12-05 18:26:50 --> Config Class Initialized
INFO - 2016-12-05 18:26:50 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:26:50 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:26:50 --> Utf8 Class Initialized
INFO - 2016-12-05 18:26:50 --> URI Class Initialized
INFO - 2016-12-05 18:26:50 --> Router Class Initialized
INFO - 2016-12-05 18:26:50 --> Output Class Initialized
INFO - 2016-12-05 18:26:50 --> Security Class Initialized
DEBUG - 2016-12-05 18:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:26:50 --> Input Class Initialized
INFO - 2016-12-05 18:26:50 --> Language Class Initialized
INFO - 2016-12-05 18:26:50 --> Loader Class Initialized
INFO - 2016-12-05 18:26:50 --> Database Driver Class Initialized
INFO - 2016-12-05 18:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:26:50 --> Controller Class Initialized
INFO - 2016-12-05 18:26:50 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:26:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:26:50 --> Final output sent to browser
DEBUG - 2016-12-05 18:26:50 --> Total execution time: 0.0135
INFO - 2016-12-05 18:26:58 --> Config Class Initialized
INFO - 2016-12-05 18:26:58 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:26:58 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:26:58 --> Utf8 Class Initialized
INFO - 2016-12-05 18:26:58 --> URI Class Initialized
DEBUG - 2016-12-05 18:26:58 --> No URI present. Default controller set.
INFO - 2016-12-05 18:26:58 --> Router Class Initialized
INFO - 2016-12-05 18:26:58 --> Output Class Initialized
INFO - 2016-12-05 18:26:58 --> Security Class Initialized
DEBUG - 2016-12-05 18:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:26:58 --> Input Class Initialized
INFO - 2016-12-05 18:26:58 --> Language Class Initialized
INFO - 2016-12-05 18:26:58 --> Loader Class Initialized
INFO - 2016-12-05 18:26:58 --> Database Driver Class Initialized
INFO - 2016-12-05 18:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:26:58 --> Controller Class Initialized
INFO - 2016-12-05 18:26:58 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:26:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:26:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:26:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:26:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:26:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:26:58 --> Final output sent to browser
DEBUG - 2016-12-05 18:26:58 --> Total execution time: 0.0149
INFO - 2016-12-05 18:26:58 --> Config Class Initialized
INFO - 2016-12-05 18:26:58 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:26:58 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:26:58 --> Utf8 Class Initialized
INFO - 2016-12-05 18:26:58 --> URI Class Initialized
INFO - 2016-12-05 18:26:58 --> Router Class Initialized
INFO - 2016-12-05 18:26:58 --> Output Class Initialized
INFO - 2016-12-05 18:26:58 --> Security Class Initialized
DEBUG - 2016-12-05 18:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:26:58 --> Input Class Initialized
INFO - 2016-12-05 18:26:58 --> Language Class Initialized
INFO - 2016-12-05 18:26:58 --> Loader Class Initialized
INFO - 2016-12-05 18:26:58 --> Database Driver Class Initialized
INFO - 2016-12-05 18:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:26:58 --> Controller Class Initialized
INFO - 2016-12-05 18:26:58 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:26:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:26:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:26:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:26:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:26:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:26:58 --> Final output sent to browser
DEBUG - 2016-12-05 18:26:58 --> Total execution time: 0.0153
INFO - 2016-12-05 18:27:00 --> Config Class Initialized
INFO - 2016-12-05 18:27:00 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:27:00 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:27:00 --> Utf8 Class Initialized
INFO - 2016-12-05 18:27:00 --> URI Class Initialized
DEBUG - 2016-12-05 18:27:00 --> No URI present. Default controller set.
INFO - 2016-12-05 18:27:00 --> Router Class Initialized
INFO - 2016-12-05 18:27:00 --> Output Class Initialized
INFO - 2016-12-05 18:27:00 --> Security Class Initialized
DEBUG - 2016-12-05 18:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:27:00 --> Input Class Initialized
INFO - 2016-12-05 18:27:00 --> Language Class Initialized
INFO - 2016-12-05 18:27:00 --> Loader Class Initialized
INFO - 2016-12-05 18:27:00 --> Database Driver Class Initialized
INFO - 2016-12-05 18:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:27:00 --> Controller Class Initialized
INFO - 2016-12-05 18:27:00 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:27:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:27:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:27:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:27:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:27:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:27:00 --> Final output sent to browser
DEBUG - 2016-12-05 18:27:00 --> Total execution time: 0.0142
INFO - 2016-12-05 18:27:00 --> Config Class Initialized
INFO - 2016-12-05 18:27:00 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:27:00 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:27:00 --> Utf8 Class Initialized
INFO - 2016-12-05 18:27:00 --> URI Class Initialized
INFO - 2016-12-05 18:27:00 --> Router Class Initialized
INFO - 2016-12-05 18:27:00 --> Output Class Initialized
INFO - 2016-12-05 18:27:00 --> Security Class Initialized
DEBUG - 2016-12-05 18:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:27:00 --> Input Class Initialized
INFO - 2016-12-05 18:27:00 --> Language Class Initialized
INFO - 2016-12-05 18:27:00 --> Loader Class Initialized
INFO - 2016-12-05 18:27:00 --> Database Driver Class Initialized
INFO - 2016-12-05 18:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:27:00 --> Controller Class Initialized
INFO - 2016-12-05 18:27:00 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:27:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:27:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:27:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:27:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:27:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:27:00 --> Final output sent to browser
DEBUG - 2016-12-05 18:27:00 --> Total execution time: 0.0140
INFO - 2016-12-05 18:27:07 --> Config Class Initialized
INFO - 2016-12-05 18:27:10 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:27:10 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:27:10 --> Utf8 Class Initialized
INFO - 2016-12-05 18:27:10 --> URI Class Initialized
INFO - 2016-12-05 18:27:10 --> Router Class Initialized
INFO - 2016-12-05 18:27:10 --> Output Class Initialized
INFO - 2016-12-05 18:27:10 --> Security Class Initialized
DEBUG - 2016-12-05 18:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:27:10 --> Input Class Initialized
INFO - 2016-12-05 18:27:10 --> Language Class Initialized
INFO - 2016-12-05 18:27:10 --> Loader Class Initialized
INFO - 2016-12-05 18:27:10 --> Database Driver Class Initialized
INFO - 2016-12-05 18:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:27:10 --> Controller Class Initialized
INFO - 2016-12-05 18:27:10 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:27:11 --> Config Class Initialized
INFO - 2016-12-05 18:27:11 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:27:11 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:27:11 --> Utf8 Class Initialized
INFO - 2016-12-05 18:27:11 --> URI Class Initialized
INFO - 2016-12-05 18:27:11 --> Router Class Initialized
INFO - 2016-12-05 18:27:11 --> Output Class Initialized
INFO - 2016-12-05 18:27:11 --> Security Class Initialized
DEBUG - 2016-12-05 18:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:27:11 --> Input Class Initialized
INFO - 2016-12-05 18:27:11 --> Language Class Initialized
INFO - 2016-12-05 18:27:11 --> Loader Class Initialized
INFO - 2016-12-05 18:27:11 --> Database Driver Class Initialized
INFO - 2016-12-05 18:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:27:11 --> Controller Class Initialized
DEBUG - 2016-12-05 18:27:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:27:11 --> Helper loaded: url_helper
INFO - 2016-12-05 18:27:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:27:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-05 18:27:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-05 18:27:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-05 18:27:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:27:11 --> Final output sent to browser
DEBUG - 2016-12-05 18:27:11 --> Total execution time: 0.0790
INFO - 2016-12-05 18:27:12 --> Config Class Initialized
INFO - 2016-12-05 18:27:12 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:27:12 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:27:12 --> Utf8 Class Initialized
INFO - 2016-12-05 18:27:12 --> URI Class Initialized
INFO - 2016-12-05 18:27:12 --> Router Class Initialized
INFO - 2016-12-05 18:27:12 --> Output Class Initialized
INFO - 2016-12-05 18:27:12 --> Security Class Initialized
DEBUG - 2016-12-05 18:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:27:12 --> Input Class Initialized
INFO - 2016-12-05 18:27:12 --> Language Class Initialized
INFO - 2016-12-05 18:27:12 --> Loader Class Initialized
INFO - 2016-12-05 18:27:12 --> Database Driver Class Initialized
INFO - 2016-12-05 18:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:27:12 --> Controller Class Initialized
INFO - 2016-12-05 18:27:12 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:27:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:27:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:27:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:27:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:27:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:27:12 --> Final output sent to browser
DEBUG - 2016-12-05 18:27:12 --> Total execution time: 0.0199
INFO - 2016-12-05 18:27:15 --> Config Class Initialized
INFO - 2016-12-05 18:27:15 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:27:15 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:27:15 --> Utf8 Class Initialized
INFO - 2016-12-05 18:27:15 --> URI Class Initialized
INFO - 2016-12-05 18:27:15 --> Router Class Initialized
INFO - 2016-12-05 18:27:15 --> Output Class Initialized
INFO - 2016-12-05 18:27:15 --> Security Class Initialized
DEBUG - 2016-12-05 18:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:27:15 --> Input Class Initialized
INFO - 2016-12-05 18:27:15 --> Language Class Initialized
INFO - 2016-12-05 18:27:15 --> Loader Class Initialized
INFO - 2016-12-05 18:27:15 --> Database Driver Class Initialized
INFO - 2016-12-05 18:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:27:15 --> Controller Class Initialized
INFO - 2016-12-05 18:27:15 --> Helper loaded: date_helper
DEBUG - 2016-12-05 18:27:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:27:15 --> Helper loaded: url_helper
INFO - 2016-12-05 18:27:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:27:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-05 18:27:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-05 18:27:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-05 18:27:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:27:15 --> Final output sent to browser
DEBUG - 2016-12-05 18:27:15 --> Total execution time: 0.1149
INFO - 2016-12-05 18:27:15 --> Config Class Initialized
INFO - 2016-12-05 18:27:15 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:27:15 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:27:15 --> Utf8 Class Initialized
INFO - 2016-12-05 18:27:15 --> URI Class Initialized
INFO - 2016-12-05 18:27:15 --> Router Class Initialized
INFO - 2016-12-05 18:27:15 --> Output Class Initialized
INFO - 2016-12-05 18:27:15 --> Security Class Initialized
DEBUG - 2016-12-05 18:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:27:15 --> Input Class Initialized
INFO - 2016-12-05 18:27:15 --> Language Class Initialized
INFO - 2016-12-05 18:27:15 --> Loader Class Initialized
INFO - 2016-12-05 18:27:15 --> Database Driver Class Initialized
INFO - 2016-12-05 18:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:27:15 --> Controller Class Initialized
INFO - 2016-12-05 18:27:15 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:27:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:27:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:27:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:27:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:27:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:27:15 --> Final output sent to browser
DEBUG - 2016-12-05 18:27:15 --> Total execution time: 0.0145
INFO - 2016-12-05 18:27:24 --> Config Class Initialized
INFO - 2016-12-05 18:27:24 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:27:24 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:27:24 --> Utf8 Class Initialized
INFO - 2016-12-05 18:27:24 --> URI Class Initialized
INFO - 2016-12-05 18:27:24 --> Router Class Initialized
INFO - 2016-12-05 18:27:24 --> Output Class Initialized
INFO - 2016-12-05 18:27:24 --> Security Class Initialized
DEBUG - 2016-12-05 18:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:27:24 --> Input Class Initialized
INFO - 2016-12-05 18:27:24 --> Language Class Initialized
INFO - 2016-12-05 18:27:24 --> Loader Class Initialized
INFO - 2016-12-05 18:27:24 --> Database Driver Class Initialized
INFO - 2016-12-05 18:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:27:24 --> Controller Class Initialized
DEBUG - 2016-12-05 18:27:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:27:24 --> Helper loaded: url_helper
INFO - 2016-12-05 18:27:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:27:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-05 18:27:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-05 18:27:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-05 18:27:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-05 18:27:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:27:24 --> Final output sent to browser
DEBUG - 2016-12-05 18:27:24 --> Total execution time: 0.0360
INFO - 2016-12-05 18:27:24 --> Config Class Initialized
INFO - 2016-12-05 18:27:24 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:27:24 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:27:24 --> Utf8 Class Initialized
INFO - 2016-12-05 18:27:24 --> URI Class Initialized
INFO - 2016-12-05 18:27:24 --> Router Class Initialized
INFO - 2016-12-05 18:27:24 --> Output Class Initialized
INFO - 2016-12-05 18:27:24 --> Security Class Initialized
DEBUG - 2016-12-05 18:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:27:24 --> Input Class Initialized
INFO - 2016-12-05 18:27:24 --> Language Class Initialized
INFO - 2016-12-05 18:27:24 --> Loader Class Initialized
INFO - 2016-12-05 18:27:24 --> Database Driver Class Initialized
INFO - 2016-12-05 18:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:27:25 --> Controller Class Initialized
INFO - 2016-12-05 18:27:25 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:27:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:27:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:27:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:27:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:27:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:27:25 --> Final output sent to browser
DEBUG - 2016-12-05 18:27:25 --> Total execution time: 0.0475
INFO - 2016-12-05 18:27:28 --> Config Class Initialized
INFO - 2016-12-05 18:27:28 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:27:28 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:27:28 --> Utf8 Class Initialized
INFO - 2016-12-05 18:27:28 --> URI Class Initialized
INFO - 2016-12-05 18:27:28 --> Router Class Initialized
INFO - 2016-12-05 18:27:28 --> Output Class Initialized
INFO - 2016-12-05 18:27:28 --> Security Class Initialized
DEBUG - 2016-12-05 18:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:27:28 --> Input Class Initialized
INFO - 2016-12-05 18:27:28 --> Language Class Initialized
INFO - 2016-12-05 18:27:28 --> Loader Class Initialized
INFO - 2016-12-05 18:27:28 --> Database Driver Class Initialized
INFO - 2016-12-05 18:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:27:28 --> Controller Class Initialized
DEBUG - 2016-12-05 18:27:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:27:28 --> Helper loaded: url_helper
INFO - 2016-12-05 18:27:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:27:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-05 18:27:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-05 18:27:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:27:28 --> Final output sent to browser
DEBUG - 2016-12-05 18:27:28 --> Total execution time: 0.1124
INFO - 2016-12-05 18:27:28 --> Config Class Initialized
INFO - 2016-12-05 18:27:28 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:27:28 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:27:28 --> Utf8 Class Initialized
INFO - 2016-12-05 18:27:28 --> URI Class Initialized
INFO - 2016-12-05 18:27:28 --> Router Class Initialized
INFO - 2016-12-05 18:27:28 --> Output Class Initialized
INFO - 2016-12-05 18:27:28 --> Security Class Initialized
DEBUG - 2016-12-05 18:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:27:28 --> Input Class Initialized
INFO - 2016-12-05 18:27:28 --> Language Class Initialized
INFO - 2016-12-05 18:27:28 --> Loader Class Initialized
INFO - 2016-12-05 18:27:28 --> Database Driver Class Initialized
INFO - 2016-12-05 18:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:27:28 --> Controller Class Initialized
INFO - 2016-12-05 18:27:28 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:27:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:27:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:27:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:27:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:27:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:27:28 --> Final output sent to browser
DEBUG - 2016-12-05 18:27:28 --> Total execution time: 0.0134
INFO - 2016-12-05 18:27:31 --> Config Class Initialized
INFO - 2016-12-05 18:27:31 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:27:31 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:27:31 --> Utf8 Class Initialized
INFO - 2016-12-05 18:27:31 --> URI Class Initialized
INFO - 2016-12-05 18:27:31 --> Router Class Initialized
INFO - 2016-12-05 18:27:31 --> Output Class Initialized
INFO - 2016-12-05 18:27:31 --> Security Class Initialized
DEBUG - 2016-12-05 18:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:27:31 --> Input Class Initialized
INFO - 2016-12-05 18:27:31 --> Language Class Initialized
INFO - 2016-12-05 18:27:31 --> Loader Class Initialized
INFO - 2016-12-05 18:27:31 --> Database Driver Class Initialized
INFO - 2016-12-05 18:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:27:31 --> Controller Class Initialized
DEBUG - 2016-12-05 18:27:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:27:31 --> Helper loaded: url_helper
INFO - 2016-12-05 18:27:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:27:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-05 18:27:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-05 18:27:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-05 18:27:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-05 18:27:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:27:31 --> Final output sent to browser
DEBUG - 2016-12-05 18:27:31 --> Total execution time: 0.0130
INFO - 2016-12-05 18:27:31 --> Config Class Initialized
INFO - 2016-12-05 18:27:31 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:27:31 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:27:31 --> Utf8 Class Initialized
INFO - 2016-12-05 18:27:31 --> URI Class Initialized
INFO - 2016-12-05 18:27:31 --> Router Class Initialized
INFO - 2016-12-05 18:27:31 --> Output Class Initialized
INFO - 2016-12-05 18:27:31 --> Security Class Initialized
DEBUG - 2016-12-05 18:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:27:31 --> Input Class Initialized
INFO - 2016-12-05 18:27:31 --> Language Class Initialized
INFO - 2016-12-05 18:27:31 --> Loader Class Initialized
INFO - 2016-12-05 18:27:31 --> Database Driver Class Initialized
INFO - 2016-12-05 18:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:27:31 --> Controller Class Initialized
INFO - 2016-12-05 18:27:31 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:27:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:27:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:27:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:27:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:27:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:27:31 --> Final output sent to browser
DEBUG - 2016-12-05 18:27:31 --> Total execution time: 0.0136
INFO - 2016-12-05 18:27:32 --> Config Class Initialized
INFO - 2016-12-05 18:27:32 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:27:32 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:27:32 --> Utf8 Class Initialized
INFO - 2016-12-05 18:27:32 --> URI Class Initialized
INFO - 2016-12-05 18:27:32 --> Router Class Initialized
INFO - 2016-12-05 18:27:32 --> Output Class Initialized
INFO - 2016-12-05 18:27:32 --> Security Class Initialized
DEBUG - 2016-12-05 18:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:27:32 --> Input Class Initialized
INFO - 2016-12-05 18:27:32 --> Language Class Initialized
INFO - 2016-12-05 18:27:32 --> Loader Class Initialized
INFO - 2016-12-05 18:27:32 --> Database Driver Class Initialized
INFO - 2016-12-05 18:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:27:32 --> Controller Class Initialized
INFO - 2016-12-05 18:27:32 --> Helper loaded: date_helper
DEBUG - 2016-12-05 18:27:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:27:32 --> Helper loaded: url_helper
INFO - 2016-12-05 18:27:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:27:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-05 18:27:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-05 18:27:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-05 18:27:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:27:32 --> Final output sent to browser
DEBUG - 2016-12-05 18:27:32 --> Total execution time: 0.0194
INFO - 2016-12-05 18:27:32 --> Config Class Initialized
INFO - 2016-12-05 18:27:32 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:27:32 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:27:32 --> Utf8 Class Initialized
INFO - 2016-12-05 18:27:32 --> URI Class Initialized
INFO - 2016-12-05 18:27:32 --> Router Class Initialized
INFO - 2016-12-05 18:27:32 --> Output Class Initialized
INFO - 2016-12-05 18:27:32 --> Security Class Initialized
DEBUG - 2016-12-05 18:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:27:32 --> Input Class Initialized
INFO - 2016-12-05 18:27:32 --> Language Class Initialized
INFO - 2016-12-05 18:27:32 --> Loader Class Initialized
INFO - 2016-12-05 18:27:32 --> Database Driver Class Initialized
INFO - 2016-12-05 18:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:27:32 --> Controller Class Initialized
INFO - 2016-12-05 18:27:32 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:27:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:27:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:27:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:27:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:27:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:27:32 --> Final output sent to browser
DEBUG - 2016-12-05 18:27:32 --> Total execution time: 0.0470
INFO - 2016-12-05 18:28:26 --> Config Class Initialized
INFO - 2016-12-05 18:28:26 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:28:26 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:28:26 --> Utf8 Class Initialized
INFO - 2016-12-05 18:28:26 --> URI Class Initialized
INFO - 2016-12-05 18:28:26 --> Router Class Initialized
INFO - 2016-12-05 18:28:26 --> Output Class Initialized
INFO - 2016-12-05 18:28:26 --> Security Class Initialized
DEBUG - 2016-12-05 18:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:28:26 --> Input Class Initialized
INFO - 2016-12-05 18:28:26 --> Language Class Initialized
INFO - 2016-12-05 18:28:26 --> Loader Class Initialized
INFO - 2016-12-05 18:28:26 --> Database Driver Class Initialized
INFO - 2016-12-05 18:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:28:26 --> Controller Class Initialized
DEBUG - 2016-12-05 18:28:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:28:26 --> Helper loaded: url_helper
INFO - 2016-12-05 18:28:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:28:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-05 18:28:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-05 18:28:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-05 18:28:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:28:26 --> Final output sent to browser
DEBUG - 2016-12-05 18:28:26 --> Total execution time: 0.0133
INFO - 2016-12-05 18:28:26 --> Config Class Initialized
INFO - 2016-12-05 18:28:26 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:28:26 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:28:26 --> Utf8 Class Initialized
INFO - 2016-12-05 18:28:26 --> URI Class Initialized
INFO - 2016-12-05 18:28:26 --> Router Class Initialized
INFO - 2016-12-05 18:28:26 --> Output Class Initialized
INFO - 2016-12-05 18:28:26 --> Security Class Initialized
DEBUG - 2016-12-05 18:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:28:26 --> Input Class Initialized
INFO - 2016-12-05 18:28:26 --> Language Class Initialized
INFO - 2016-12-05 18:28:26 --> Loader Class Initialized
INFO - 2016-12-05 18:28:26 --> Database Driver Class Initialized
INFO - 2016-12-05 18:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:28:26 --> Controller Class Initialized
INFO - 2016-12-05 18:28:26 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:28:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:28:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:28:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:28:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:28:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:28:26 --> Final output sent to browser
DEBUG - 2016-12-05 18:28:26 --> Total execution time: 0.0135
INFO - 2016-12-05 18:28:43 --> Config Class Initialized
INFO - 2016-12-05 18:28:43 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:28:43 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:28:43 --> Utf8 Class Initialized
INFO - 2016-12-05 18:28:43 --> URI Class Initialized
INFO - 2016-12-05 18:28:43 --> Router Class Initialized
INFO - 2016-12-05 18:28:43 --> Output Class Initialized
INFO - 2016-12-05 18:28:43 --> Security Class Initialized
DEBUG - 2016-12-05 18:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:28:43 --> Input Class Initialized
INFO - 2016-12-05 18:28:43 --> Language Class Initialized
INFO - 2016-12-05 18:28:43 --> Loader Class Initialized
INFO - 2016-12-05 18:28:43 --> Database Driver Class Initialized
INFO - 2016-12-05 18:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:28:43 --> Controller Class Initialized
INFO - 2016-12-05 18:28:43 --> Helper loaded: date_helper
DEBUG - 2016-12-05 18:28:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:28:43 --> Helper loaded: url_helper
INFO - 2016-12-05 18:28:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:28:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-05 18:28:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-05 18:28:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-05 18:28:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:28:43 --> Final output sent to browser
DEBUG - 2016-12-05 18:28:43 --> Total execution time: 0.0401
INFO - 2016-12-05 18:28:43 --> Config Class Initialized
INFO - 2016-12-05 18:28:43 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:28:43 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:28:43 --> Utf8 Class Initialized
INFO - 2016-12-05 18:28:43 --> URI Class Initialized
INFO - 2016-12-05 18:28:43 --> Router Class Initialized
INFO - 2016-12-05 18:28:43 --> Output Class Initialized
INFO - 2016-12-05 18:28:43 --> Security Class Initialized
DEBUG - 2016-12-05 18:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:28:43 --> Input Class Initialized
INFO - 2016-12-05 18:28:43 --> Language Class Initialized
INFO - 2016-12-05 18:28:43 --> Loader Class Initialized
INFO - 2016-12-05 18:28:43 --> Database Driver Class Initialized
INFO - 2016-12-05 18:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:28:43 --> Controller Class Initialized
INFO - 2016-12-05 18:28:43 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:28:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:28:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:28:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:28:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:28:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:28:43 --> Final output sent to browser
DEBUG - 2016-12-05 18:28:43 --> Total execution time: 0.0613
INFO - 2016-12-05 18:29:19 --> Config Class Initialized
INFO - 2016-12-05 18:29:19 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:29:19 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:29:19 --> Utf8 Class Initialized
INFO - 2016-12-05 18:29:19 --> URI Class Initialized
INFO - 2016-12-05 18:29:19 --> Router Class Initialized
INFO - 2016-12-05 18:29:19 --> Output Class Initialized
INFO - 2016-12-05 18:29:19 --> Security Class Initialized
DEBUG - 2016-12-05 18:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:29:19 --> Input Class Initialized
INFO - 2016-12-05 18:29:19 --> Language Class Initialized
INFO - 2016-12-05 18:29:19 --> Loader Class Initialized
INFO - 2016-12-05 18:29:19 --> Database Driver Class Initialized
INFO - 2016-12-05 18:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:29:19 --> Controller Class Initialized
DEBUG - 2016-12-05 18:29:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:29:19 --> Helper loaded: url_helper
INFO - 2016-12-05 18:29:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:29:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2016-12-05 18:29:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-05 18:29:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2016-12-05 18:29:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2016-12-05 18:29:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:29:19 --> Final output sent to browser
DEBUG - 2016-12-05 18:29:19 --> Total execution time: 0.0128
INFO - 2016-12-05 18:29:19 --> Config Class Initialized
INFO - 2016-12-05 18:29:19 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:29:19 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:29:19 --> Utf8 Class Initialized
INFO - 2016-12-05 18:29:19 --> URI Class Initialized
INFO - 2016-12-05 18:29:19 --> Router Class Initialized
INFO - 2016-12-05 18:29:19 --> Output Class Initialized
INFO - 2016-12-05 18:29:19 --> Security Class Initialized
DEBUG - 2016-12-05 18:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:29:19 --> Input Class Initialized
INFO - 2016-12-05 18:29:19 --> Language Class Initialized
INFO - 2016-12-05 18:29:19 --> Loader Class Initialized
INFO - 2016-12-05 18:29:19 --> Database Driver Class Initialized
INFO - 2016-12-05 18:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:29:19 --> Controller Class Initialized
INFO - 2016-12-05 18:29:19 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:29:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:29:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:29:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:29:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:29:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:29:19 --> Final output sent to browser
DEBUG - 2016-12-05 18:29:19 --> Total execution time: 0.0131
INFO - 2016-12-05 18:29:20 --> Config Class Initialized
INFO - 2016-12-05 18:29:20 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:29:20 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:29:20 --> Utf8 Class Initialized
INFO - 2016-12-05 18:29:20 --> URI Class Initialized
INFO - 2016-12-05 18:29:20 --> Router Class Initialized
INFO - 2016-12-05 18:29:20 --> Output Class Initialized
INFO - 2016-12-05 18:29:20 --> Security Class Initialized
DEBUG - 2016-12-05 18:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:29:20 --> Input Class Initialized
INFO - 2016-12-05 18:29:20 --> Language Class Initialized
INFO - 2016-12-05 18:29:20 --> Loader Class Initialized
INFO - 2016-12-05 18:29:20 --> Database Driver Class Initialized
INFO - 2016-12-05 18:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:29:20 --> Controller Class Initialized
DEBUG - 2016-12-05 18:29:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:29:20 --> Helper loaded: url_helper
INFO - 2016-12-05 18:29:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:29:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-05 18:29:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-05 18:29:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-05 18:29:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:29:20 --> Final output sent to browser
DEBUG - 2016-12-05 18:29:20 --> Total execution time: 0.0153
INFO - 2016-12-05 18:29:20 --> Config Class Initialized
INFO - 2016-12-05 18:29:20 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:29:20 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:29:20 --> Utf8 Class Initialized
INFO - 2016-12-05 18:29:20 --> URI Class Initialized
INFO - 2016-12-05 18:29:20 --> Router Class Initialized
INFO - 2016-12-05 18:29:20 --> Output Class Initialized
INFO - 2016-12-05 18:29:20 --> Security Class Initialized
DEBUG - 2016-12-05 18:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:29:20 --> Input Class Initialized
INFO - 2016-12-05 18:29:20 --> Language Class Initialized
INFO - 2016-12-05 18:29:20 --> Loader Class Initialized
INFO - 2016-12-05 18:29:20 --> Database Driver Class Initialized
INFO - 2016-12-05 18:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:29:21 --> Controller Class Initialized
INFO - 2016-12-05 18:29:21 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:29:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:29:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:29:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:29:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:29:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:29:21 --> Final output sent to browser
DEBUG - 2016-12-05 18:29:21 --> Total execution time: 0.0267
INFO - 2016-12-05 18:29:22 --> Config Class Initialized
INFO - 2016-12-05 18:29:22 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:29:22 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:29:22 --> Utf8 Class Initialized
INFO - 2016-12-05 18:29:22 --> URI Class Initialized
INFO - 2016-12-05 18:29:22 --> Router Class Initialized
INFO - 2016-12-05 18:29:22 --> Output Class Initialized
INFO - 2016-12-05 18:29:22 --> Security Class Initialized
DEBUG - 2016-12-05 18:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:29:22 --> Input Class Initialized
INFO - 2016-12-05 18:29:22 --> Language Class Initialized
INFO - 2016-12-05 18:29:22 --> Loader Class Initialized
INFO - 2016-12-05 18:29:22 --> Database Driver Class Initialized
INFO - 2016-12-05 18:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:29:22 --> Controller Class Initialized
DEBUG - 2016-12-05 18:29:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:29:22 --> Helper loaded: url_helper
INFO - 2016-12-05 18:29:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:29:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-05 18:29:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2016-12-05 18:29:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:29:22 --> Final output sent to browser
DEBUG - 2016-12-05 18:29:22 --> Total execution time: 0.0120
INFO - 2016-12-05 18:29:23 --> Config Class Initialized
INFO - 2016-12-05 18:29:23 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:29:23 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:29:23 --> Utf8 Class Initialized
INFO - 2016-12-05 18:29:23 --> URI Class Initialized
INFO - 2016-12-05 18:29:23 --> Router Class Initialized
INFO - 2016-12-05 18:29:23 --> Output Class Initialized
INFO - 2016-12-05 18:29:23 --> Security Class Initialized
DEBUG - 2016-12-05 18:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:29:23 --> Input Class Initialized
INFO - 2016-12-05 18:29:23 --> Language Class Initialized
INFO - 2016-12-05 18:29:23 --> Loader Class Initialized
INFO - 2016-12-05 18:29:23 --> Database Driver Class Initialized
INFO - 2016-12-05 18:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:29:23 --> Controller Class Initialized
INFO - 2016-12-05 18:29:23 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:29:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:29:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:29:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:29:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:29:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:29:23 --> Final output sent to browser
DEBUG - 2016-12-05 18:29:23 --> Total execution time: 0.0147
INFO - 2016-12-05 18:29:28 --> Config Class Initialized
INFO - 2016-12-05 18:29:28 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:29:28 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:29:28 --> Utf8 Class Initialized
INFO - 2016-12-05 18:29:28 --> URI Class Initialized
INFO - 2016-12-05 18:29:28 --> Router Class Initialized
INFO - 2016-12-05 18:29:28 --> Output Class Initialized
INFO - 2016-12-05 18:29:28 --> Security Class Initialized
DEBUG - 2016-12-05 18:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:29:28 --> Input Class Initialized
INFO - 2016-12-05 18:29:28 --> Language Class Initialized
INFO - 2016-12-05 18:29:28 --> Loader Class Initialized
INFO - 2016-12-05 18:29:28 --> Database Driver Class Initialized
INFO - 2016-12-05 18:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:29:28 --> Controller Class Initialized
INFO - 2016-12-05 18:29:28 --> Helper loaded: date_helper
DEBUG - 2016-12-05 18:29:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:29:28 --> Helper loaded: url_helper
INFO - 2016-12-05 18:29:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:29:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-05 18:29:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-05 18:29:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-05 18:29:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:29:28 --> Final output sent to browser
DEBUG - 2016-12-05 18:29:28 --> Total execution time: 0.0248
INFO - 2016-12-05 18:29:28 --> Config Class Initialized
INFO - 2016-12-05 18:29:28 --> Hooks Class Initialized
DEBUG - 2016-12-05 18:29:28 --> UTF-8 Support Enabled
INFO - 2016-12-05 18:29:28 --> Utf8 Class Initialized
INFO - 2016-12-05 18:29:28 --> URI Class Initialized
INFO - 2016-12-05 18:29:28 --> Router Class Initialized
INFO - 2016-12-05 18:29:28 --> Output Class Initialized
INFO - 2016-12-05 18:29:28 --> Security Class Initialized
DEBUG - 2016-12-05 18:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 18:29:28 --> Input Class Initialized
INFO - 2016-12-05 18:29:28 --> Language Class Initialized
INFO - 2016-12-05 18:29:28 --> Loader Class Initialized
INFO - 2016-12-05 18:29:28 --> Database Driver Class Initialized
INFO - 2016-12-05 18:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 18:29:28 --> Controller Class Initialized
INFO - 2016-12-05 18:29:28 --> Helper loaded: url_helper
DEBUG - 2016-12-05 18:29:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 18:29:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 18:29:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 18:29:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 18:29:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 18:29:28 --> Final output sent to browser
DEBUG - 2016-12-05 18:29:28 --> Total execution time: 0.0131
INFO - 2016-12-05 19:27:30 --> Config Class Initialized
INFO - 2016-12-05 19:27:30 --> Hooks Class Initialized
DEBUG - 2016-12-05 19:27:30 --> UTF-8 Support Enabled
INFO - 2016-12-05 19:27:30 --> Utf8 Class Initialized
INFO - 2016-12-05 19:27:30 --> URI Class Initialized
DEBUG - 2016-12-05 19:27:30 --> No URI present. Default controller set.
INFO - 2016-12-05 19:27:30 --> Router Class Initialized
INFO - 2016-12-05 19:27:30 --> Output Class Initialized
INFO - 2016-12-05 19:27:30 --> Security Class Initialized
DEBUG - 2016-12-05 19:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 19:27:30 --> Input Class Initialized
INFO - 2016-12-05 19:27:30 --> Language Class Initialized
INFO - 2016-12-05 19:27:30 --> Loader Class Initialized
INFO - 2016-12-05 19:27:30 --> Database Driver Class Initialized
INFO - 2016-12-05 19:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 19:27:30 --> Controller Class Initialized
INFO - 2016-12-05 19:27:30 --> Helper loaded: url_helper
DEBUG - 2016-12-05 19:27:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 19:27:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 19:27:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 19:27:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 19:27:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 19:27:30 --> Final output sent to browser
DEBUG - 2016-12-05 19:27:30 --> Total execution time: 0.1521
INFO - 2016-12-05 19:27:55 --> Config Class Initialized
INFO - 2016-12-05 19:27:55 --> Hooks Class Initialized
DEBUG - 2016-12-05 19:27:55 --> UTF-8 Support Enabled
INFO - 2016-12-05 19:27:55 --> Utf8 Class Initialized
INFO - 2016-12-05 19:27:55 --> URI Class Initialized
INFO - 2016-12-05 19:27:55 --> Router Class Initialized
INFO - 2016-12-05 19:27:55 --> Output Class Initialized
INFO - 2016-12-05 19:27:55 --> Security Class Initialized
DEBUG - 2016-12-05 19:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 19:27:55 --> Input Class Initialized
INFO - 2016-12-05 19:27:55 --> Language Class Initialized
INFO - 2016-12-05 19:27:55 --> Loader Class Initialized
INFO - 2016-12-05 19:27:55 --> Database Driver Class Initialized
INFO - 2016-12-05 19:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 19:27:55 --> Controller Class Initialized
INFO - 2016-12-05 19:27:55 --> Helper loaded: url_helper
DEBUG - 2016-12-05 19:27:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 19:27:56 --> Config Class Initialized
INFO - 2016-12-05 19:27:56 --> Hooks Class Initialized
DEBUG - 2016-12-05 19:27:56 --> UTF-8 Support Enabled
INFO - 2016-12-05 19:27:56 --> Utf8 Class Initialized
INFO - 2016-12-05 19:27:56 --> URI Class Initialized
INFO - 2016-12-05 19:27:56 --> Router Class Initialized
INFO - 2016-12-05 19:27:56 --> Output Class Initialized
INFO - 2016-12-05 19:27:56 --> Security Class Initialized
DEBUG - 2016-12-05 19:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 19:27:56 --> Input Class Initialized
INFO - 2016-12-05 19:27:56 --> Language Class Initialized
INFO - 2016-12-05 19:27:56 --> Loader Class Initialized
INFO - 2016-12-05 19:27:56 --> Database Driver Class Initialized
INFO - 2016-12-05 19:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 19:27:56 --> Controller Class Initialized
DEBUG - 2016-12-05 19:27:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 19:27:56 --> Helper loaded: url_helper
INFO - 2016-12-05 19:27:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 19:27:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-05 19:27:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2016-12-05 19:27:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-05 19:27:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 19:27:56 --> Final output sent to browser
DEBUG - 2016-12-05 19:27:56 --> Total execution time: 0.0360
INFO - 2016-12-05 19:28:09 --> Config Class Initialized
INFO - 2016-12-05 19:28:09 --> Hooks Class Initialized
DEBUG - 2016-12-05 19:28:09 --> UTF-8 Support Enabled
INFO - 2016-12-05 19:28:09 --> Utf8 Class Initialized
INFO - 2016-12-05 19:28:09 --> URI Class Initialized
INFO - 2016-12-05 19:28:09 --> Router Class Initialized
INFO - 2016-12-05 19:28:09 --> Output Class Initialized
INFO - 2016-12-05 19:28:09 --> Security Class Initialized
DEBUG - 2016-12-05 19:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 19:28:09 --> Input Class Initialized
INFO - 2016-12-05 19:28:09 --> Language Class Initialized
INFO - 2016-12-05 19:28:09 --> Loader Class Initialized
INFO - 2016-12-05 19:28:09 --> Database Driver Class Initialized
INFO - 2016-12-05 19:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 19:28:09 --> Controller Class Initialized
INFO - 2016-12-05 19:28:09 --> Helper loaded: date_helper
DEBUG - 2016-12-05 19:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 19:28:09 --> Helper loaded: url_helper
INFO - 2016-12-05 19:28:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 19:28:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2016-12-05 19:28:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2016-12-05 19:28:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2016-12-05 19:28:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 19:28:10 --> Final output sent to browser
DEBUG - 2016-12-05 19:28:10 --> Total execution time: 0.0595
INFO - 2016-12-05 19:30:46 --> Config Class Initialized
INFO - 2016-12-05 19:30:46 --> Hooks Class Initialized
DEBUG - 2016-12-05 19:30:46 --> UTF-8 Support Enabled
INFO - 2016-12-05 19:30:46 --> Utf8 Class Initialized
INFO - 2016-12-05 19:30:46 --> URI Class Initialized
DEBUG - 2016-12-05 19:30:46 --> No URI present. Default controller set.
INFO - 2016-12-05 19:30:46 --> Router Class Initialized
INFO - 2016-12-05 19:30:46 --> Output Class Initialized
INFO - 2016-12-05 19:30:46 --> Security Class Initialized
DEBUG - 2016-12-05 19:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 19:30:46 --> Input Class Initialized
INFO - 2016-12-05 19:30:46 --> Language Class Initialized
INFO - 2016-12-05 19:30:46 --> Loader Class Initialized
INFO - 2016-12-05 19:30:46 --> Database Driver Class Initialized
INFO - 2016-12-05 19:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 19:30:46 --> Controller Class Initialized
INFO - 2016-12-05 19:30:46 --> Helper loaded: url_helper
DEBUG - 2016-12-05 19:30:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 19:30:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 19:30:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 19:30:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 19:30:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 19:30:46 --> Final output sent to browser
DEBUG - 2016-12-05 19:30:46 --> Total execution time: 0.0131
INFO - 2016-12-05 19:31:25 --> Config Class Initialized
INFO - 2016-12-05 19:31:25 --> Hooks Class Initialized
DEBUG - 2016-12-05 19:31:25 --> UTF-8 Support Enabled
INFO - 2016-12-05 19:31:25 --> Utf8 Class Initialized
INFO - 2016-12-05 19:31:25 --> URI Class Initialized
DEBUG - 2016-12-05 19:31:25 --> No URI present. Default controller set.
INFO - 2016-12-05 19:31:25 --> Router Class Initialized
INFO - 2016-12-05 19:31:25 --> Output Class Initialized
INFO - 2016-12-05 19:31:25 --> Security Class Initialized
DEBUG - 2016-12-05 19:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 19:31:25 --> Input Class Initialized
INFO - 2016-12-05 19:31:25 --> Language Class Initialized
INFO - 2016-12-05 19:31:25 --> Loader Class Initialized
INFO - 2016-12-05 19:31:25 --> Database Driver Class Initialized
INFO - 2016-12-05 19:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 19:31:25 --> Controller Class Initialized
INFO - 2016-12-05 19:31:25 --> Helper loaded: url_helper
DEBUG - 2016-12-05 19:31:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 19:31:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 19:31:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 19:31:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 19:31:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 19:31:25 --> Final output sent to browser
DEBUG - 2016-12-05 19:31:25 --> Total execution time: 0.0141
INFO - 2016-12-05 19:31:46 --> Config Class Initialized
INFO - 2016-12-05 19:31:46 --> Hooks Class Initialized
DEBUG - 2016-12-05 19:31:46 --> UTF-8 Support Enabled
INFO - 2016-12-05 19:31:46 --> Utf8 Class Initialized
INFO - 2016-12-05 19:31:46 --> URI Class Initialized
INFO - 2016-12-05 19:31:46 --> Router Class Initialized
INFO - 2016-12-05 19:31:46 --> Output Class Initialized
INFO - 2016-12-05 19:31:46 --> Security Class Initialized
DEBUG - 2016-12-05 19:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 19:31:46 --> Input Class Initialized
INFO - 2016-12-05 19:31:46 --> Language Class Initialized
INFO - 2016-12-05 19:31:46 --> Loader Class Initialized
INFO - 2016-12-05 19:31:46 --> Database Driver Class Initialized
INFO - 2016-12-05 19:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 19:31:46 --> Controller Class Initialized
INFO - 2016-12-05 19:31:46 --> Helper loaded: url_helper
DEBUG - 2016-12-05 19:31:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 19:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 19:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 19:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 19:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 19:31:46 --> Final output sent to browser
DEBUG - 2016-12-05 19:31:46 --> Total execution time: 0.0151
INFO - 2016-12-05 19:43:19 --> Config Class Initialized
INFO - 2016-12-05 19:43:19 --> Hooks Class Initialized
DEBUG - 2016-12-05 19:43:19 --> UTF-8 Support Enabled
INFO - 2016-12-05 19:43:19 --> Utf8 Class Initialized
INFO - 2016-12-05 19:43:19 --> URI Class Initialized
DEBUG - 2016-12-05 19:43:19 --> No URI present. Default controller set.
INFO - 2016-12-05 19:43:19 --> Router Class Initialized
INFO - 2016-12-05 19:43:19 --> Output Class Initialized
INFO - 2016-12-05 19:43:19 --> Security Class Initialized
DEBUG - 2016-12-05 19:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 19:43:19 --> Input Class Initialized
INFO - 2016-12-05 19:43:19 --> Language Class Initialized
INFO - 2016-12-05 19:43:19 --> Loader Class Initialized
INFO - 2016-12-05 19:43:19 --> Database Driver Class Initialized
INFO - 2016-12-05 19:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 19:43:19 --> Controller Class Initialized
INFO - 2016-12-05 19:43:19 --> Helper loaded: url_helper
DEBUG - 2016-12-05 19:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 19:43:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 19:43:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 19:43:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 19:43:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 19:43:19 --> Final output sent to browser
DEBUG - 2016-12-05 19:43:19 --> Total execution time: 0.0242
INFO - 2016-12-05 19:43:48 --> Config Class Initialized
INFO - 2016-12-05 19:43:48 --> Hooks Class Initialized
DEBUG - 2016-12-05 19:43:48 --> UTF-8 Support Enabled
INFO - 2016-12-05 19:43:48 --> Utf8 Class Initialized
INFO - 2016-12-05 19:43:48 --> URI Class Initialized
INFO - 2016-12-05 19:43:48 --> Router Class Initialized
INFO - 2016-12-05 19:43:48 --> Output Class Initialized
INFO - 2016-12-05 19:43:48 --> Security Class Initialized
DEBUG - 2016-12-05 19:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 19:43:48 --> Input Class Initialized
INFO - 2016-12-05 19:43:48 --> Language Class Initialized
INFO - 2016-12-05 19:43:48 --> Loader Class Initialized
INFO - 2016-12-05 19:43:48 --> Database Driver Class Initialized
INFO - 2016-12-05 19:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 19:43:48 --> Controller Class Initialized
INFO - 2016-12-05 19:43:48 --> Helper loaded: url_helper
DEBUG - 2016-12-05 19:43:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 19:43:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 19:43:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 19:43:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 19:43:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 19:43:48 --> Final output sent to browser
DEBUG - 2016-12-05 19:43:48 --> Total execution time: 0.0140
INFO - 2016-12-05 22:03:14 --> Config Class Initialized
INFO - 2016-12-05 22:03:14 --> Hooks Class Initialized
DEBUG - 2016-12-05 22:03:14 --> UTF-8 Support Enabled
INFO - 2016-12-05 22:03:14 --> Utf8 Class Initialized
INFO - 2016-12-05 22:03:14 --> URI Class Initialized
DEBUG - 2016-12-05 22:03:14 --> No URI present. Default controller set.
INFO - 2016-12-05 22:03:14 --> Router Class Initialized
INFO - 2016-12-05 22:03:14 --> Output Class Initialized
INFO - 2016-12-05 22:03:14 --> Security Class Initialized
DEBUG - 2016-12-05 22:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 22:03:14 --> Input Class Initialized
INFO - 2016-12-05 22:03:14 --> Language Class Initialized
INFO - 2016-12-05 22:03:14 --> Loader Class Initialized
INFO - 2016-12-05 22:03:14 --> Database Driver Class Initialized
INFO - 2016-12-05 22:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 22:03:14 --> Controller Class Initialized
INFO - 2016-12-05 22:03:14 --> Helper loaded: url_helper
DEBUG - 2016-12-05 22:03:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 22:03:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 22:03:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 22:03:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 22:03:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 22:03:14 --> Final output sent to browser
DEBUG - 2016-12-05 22:03:14 --> Total execution time: 0.0145
INFO - 2016-12-05 22:03:16 --> Config Class Initialized
INFO - 2016-12-05 22:03:16 --> Hooks Class Initialized
DEBUG - 2016-12-05 22:03:16 --> UTF-8 Support Enabled
INFO - 2016-12-05 22:03:16 --> Utf8 Class Initialized
INFO - 2016-12-05 22:03:16 --> URI Class Initialized
INFO - 2016-12-05 22:03:16 --> Router Class Initialized
INFO - 2016-12-05 22:03:16 --> Output Class Initialized
INFO - 2016-12-05 22:03:16 --> Security Class Initialized
DEBUG - 2016-12-05 22:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 22:03:16 --> Input Class Initialized
INFO - 2016-12-05 22:03:16 --> Language Class Initialized
INFO - 2016-12-05 22:03:16 --> Loader Class Initialized
INFO - 2016-12-05 22:03:16 --> Database Driver Class Initialized
INFO - 2016-12-05 22:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 22:03:16 --> Controller Class Initialized
INFO - 2016-12-05 22:03:16 --> Helper loaded: url_helper
DEBUG - 2016-12-05 22:03:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 22:03:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 22:03:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 22:03:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 22:03:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 22:03:16 --> Final output sent to browser
DEBUG - 2016-12-05 22:03:16 --> Total execution time: 0.0129
INFO - 2016-12-05 22:06:56 --> Config Class Initialized
INFO - 2016-12-05 22:06:56 --> Hooks Class Initialized
DEBUG - 2016-12-05 22:06:56 --> UTF-8 Support Enabled
INFO - 2016-12-05 22:06:56 --> Utf8 Class Initialized
INFO - 2016-12-05 22:06:56 --> URI Class Initialized
DEBUG - 2016-12-05 22:06:56 --> No URI present. Default controller set.
INFO - 2016-12-05 22:06:56 --> Router Class Initialized
INFO - 2016-12-05 22:06:56 --> Output Class Initialized
INFO - 2016-12-05 22:06:56 --> Security Class Initialized
DEBUG - 2016-12-05 22:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 22:06:56 --> Input Class Initialized
INFO - 2016-12-05 22:06:56 --> Language Class Initialized
INFO - 2016-12-05 22:06:56 --> Loader Class Initialized
INFO - 2016-12-05 22:06:56 --> Database Driver Class Initialized
INFO - 2016-12-05 22:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 22:06:56 --> Controller Class Initialized
INFO - 2016-12-05 22:06:56 --> Helper loaded: url_helper
DEBUG - 2016-12-05 22:06:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 22:06:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 22:06:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 22:06:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 22:06:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 22:06:56 --> Final output sent to browser
DEBUG - 2016-12-05 22:06:56 --> Total execution time: 0.0144
INFO - 2016-12-05 22:26:06 --> Config Class Initialized
INFO - 2016-12-05 22:26:06 --> Hooks Class Initialized
DEBUG - 2016-12-05 22:26:06 --> UTF-8 Support Enabled
INFO - 2016-12-05 22:26:06 --> Utf8 Class Initialized
INFO - 2016-12-05 22:26:06 --> URI Class Initialized
DEBUG - 2016-12-05 22:26:06 --> No URI present. Default controller set.
INFO - 2016-12-05 22:26:06 --> Router Class Initialized
INFO - 2016-12-05 22:26:06 --> Output Class Initialized
INFO - 2016-12-05 22:26:06 --> Security Class Initialized
DEBUG - 2016-12-05 22:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 22:26:06 --> Input Class Initialized
INFO - 2016-12-05 22:26:06 --> Language Class Initialized
INFO - 2016-12-05 22:26:06 --> Loader Class Initialized
INFO - 2016-12-05 22:26:06 --> Database Driver Class Initialized
INFO - 2016-12-05 22:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 22:26:06 --> Controller Class Initialized
INFO - 2016-12-05 22:26:06 --> Helper loaded: url_helper
DEBUG - 2016-12-05 22:26:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 22:26:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 22:26:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 22:26:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 22:26:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 22:26:06 --> Final output sent to browser
DEBUG - 2016-12-05 22:26:06 --> Total execution time: 0.0136
INFO - 2016-12-05 22:26:18 --> Config Class Initialized
INFO - 2016-12-05 22:26:18 --> Hooks Class Initialized
DEBUG - 2016-12-05 22:26:18 --> UTF-8 Support Enabled
INFO - 2016-12-05 22:26:18 --> Utf8 Class Initialized
INFO - 2016-12-05 22:26:18 --> URI Class Initialized
INFO - 2016-12-05 22:26:18 --> Router Class Initialized
INFO - 2016-12-05 22:26:18 --> Output Class Initialized
INFO - 2016-12-05 22:26:18 --> Security Class Initialized
DEBUG - 2016-12-05 22:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 22:26:18 --> Input Class Initialized
INFO - 2016-12-05 22:26:18 --> Language Class Initialized
INFO - 2016-12-05 22:26:18 --> Loader Class Initialized
INFO - 2016-12-05 22:26:18 --> Database Driver Class Initialized
INFO - 2016-12-05 22:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 22:26:18 --> Controller Class Initialized
INFO - 2016-12-05 22:26:18 --> Helper loaded: url_helper
DEBUG - 2016-12-05 22:26:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 22:26:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 22:26:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 22:26:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 22:26:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 22:26:18 --> Final output sent to browser
DEBUG - 2016-12-05 22:26:18 --> Total execution time: 0.0146
INFO - 2016-12-05 22:36:17 --> Config Class Initialized
INFO - 2016-12-05 22:36:17 --> Hooks Class Initialized
DEBUG - 2016-12-05 22:36:17 --> UTF-8 Support Enabled
INFO - 2016-12-05 22:36:17 --> Utf8 Class Initialized
INFO - 2016-12-05 22:36:17 --> URI Class Initialized
DEBUG - 2016-12-05 22:36:17 --> No URI present. Default controller set.
INFO - 2016-12-05 22:36:17 --> Router Class Initialized
INFO - 2016-12-05 22:36:17 --> Output Class Initialized
INFO - 2016-12-05 22:36:17 --> Security Class Initialized
DEBUG - 2016-12-05 22:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 22:36:17 --> Input Class Initialized
INFO - 2016-12-05 22:36:17 --> Language Class Initialized
INFO - 2016-12-05 22:36:17 --> Loader Class Initialized
INFO - 2016-12-05 22:36:17 --> Database Driver Class Initialized
INFO - 2016-12-05 22:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 22:36:17 --> Controller Class Initialized
INFO - 2016-12-05 22:36:17 --> Helper loaded: url_helper
DEBUG - 2016-12-05 22:36:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 22:36:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 22:36:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 22:36:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 22:36:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 22:36:17 --> Final output sent to browser
DEBUG - 2016-12-05 22:36:17 --> Total execution time: 0.0130
INFO - 2016-12-05 22:36:49 --> Config Class Initialized
INFO - 2016-12-05 22:36:49 --> Hooks Class Initialized
DEBUG - 2016-12-05 22:36:49 --> UTF-8 Support Enabled
INFO - 2016-12-05 22:36:49 --> Utf8 Class Initialized
INFO - 2016-12-05 22:36:49 --> URI Class Initialized
INFO - 2016-12-05 22:36:49 --> Router Class Initialized
INFO - 2016-12-05 22:36:49 --> Output Class Initialized
INFO - 2016-12-05 22:36:49 --> Security Class Initialized
DEBUG - 2016-12-05 22:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-05 22:36:49 --> Input Class Initialized
INFO - 2016-12-05 22:36:49 --> Language Class Initialized
INFO - 2016-12-05 22:36:49 --> Loader Class Initialized
INFO - 2016-12-05 22:36:49 --> Database Driver Class Initialized
INFO - 2016-12-05 22:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-05 22:36:49 --> Controller Class Initialized
INFO - 2016-12-05 22:36:49 --> Helper loaded: url_helper
DEBUG - 2016-12-05 22:36:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-05 22:36:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-05 22:36:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-05 22:36:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-05 22:36:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-05 22:36:49 --> Final output sent to browser
DEBUG - 2016-12-05 22:36:49 --> Total execution time: 0.0140

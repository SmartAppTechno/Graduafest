<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-28 00:01:27 --> Config Class Initialized
INFO - 2017-02-28 00:01:28 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:01:28 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:01:28 --> Utf8 Class Initialized
INFO - 2017-02-28 00:01:28 --> URI Class Initialized
DEBUG - 2017-02-28 00:01:28 --> No URI present. Default controller set.
INFO - 2017-02-28 00:01:28 --> Router Class Initialized
INFO - 2017-02-28 00:01:28 --> Output Class Initialized
INFO - 2017-02-28 00:01:28 --> Security Class Initialized
DEBUG - 2017-02-28 00:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:01:28 --> Input Class Initialized
INFO - 2017-02-28 00:01:28 --> Language Class Initialized
INFO - 2017-02-28 00:01:28 --> Loader Class Initialized
INFO - 2017-02-28 00:01:29 --> Database Driver Class Initialized
INFO - 2017-02-28 00:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:01:29 --> Controller Class Initialized
INFO - 2017-02-28 00:01:29 --> Helper loaded: url_helper
DEBUG - 2017-02-28 00:01:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:01:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:01:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 00:01:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 00:01:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:01:29 --> Final output sent to browser
DEBUG - 2017-02-28 00:01:29 --> Total execution time: 2.0376
INFO - 2017-02-28 00:01:53 --> Config Class Initialized
INFO - 2017-02-28 00:01:53 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:01:53 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:01:53 --> Utf8 Class Initialized
INFO - 2017-02-28 00:01:53 --> URI Class Initialized
INFO - 2017-02-28 00:01:53 --> Router Class Initialized
INFO - 2017-02-28 00:01:53 --> Output Class Initialized
INFO - 2017-02-28 00:01:53 --> Security Class Initialized
DEBUG - 2017-02-28 00:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:01:53 --> Input Class Initialized
INFO - 2017-02-28 00:01:53 --> Language Class Initialized
INFO - 2017-02-28 00:01:53 --> Loader Class Initialized
INFO - 2017-02-28 00:01:53 --> Database Driver Class Initialized
INFO - 2017-02-28 00:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:01:53 --> Controller Class Initialized
INFO - 2017-02-28 00:01:53 --> Helper loaded: url_helper
DEBUG - 2017-02-28 00:01:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-28 00:01:54 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-28 00:01:54 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Clau Amine Henriz')
INFO - 2017-02-28 00:01:54 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-28 00:01:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-28 00:02:06 --> Config Class Initialized
INFO - 2017-02-28 00:02:06 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:02:06 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:02:06 --> Utf8 Class Initialized
INFO - 2017-02-28 00:02:06 --> URI Class Initialized
INFO - 2017-02-28 00:02:06 --> Router Class Initialized
INFO - 2017-02-28 00:02:06 --> Output Class Initialized
INFO - 2017-02-28 00:02:06 --> Security Class Initialized
DEBUG - 2017-02-28 00:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:02:06 --> Input Class Initialized
INFO - 2017-02-28 00:02:06 --> Language Class Initialized
INFO - 2017-02-28 00:02:06 --> Loader Class Initialized
INFO - 2017-02-28 00:02:06 --> Database Driver Class Initialized
INFO - 2017-02-28 00:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:02:06 --> Controller Class Initialized
INFO - 2017-02-28 00:02:06 --> Helper loaded: url_helper
DEBUG - 2017-02-28 00:02:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-28 00:02:06 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-28 00:02:06 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Clau Amine Henriz')
INFO - 2017-02-28 00:02:06 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-28 00:02:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-28 00:02:11 --> Config Class Initialized
INFO - 2017-02-28 00:02:11 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:02:11 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:02:11 --> Utf8 Class Initialized
INFO - 2017-02-28 00:02:11 --> URI Class Initialized
INFO - 2017-02-28 00:02:11 --> Router Class Initialized
INFO - 2017-02-28 00:02:11 --> Output Class Initialized
INFO - 2017-02-28 00:02:11 --> Security Class Initialized
DEBUG - 2017-02-28 00:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:02:11 --> Input Class Initialized
INFO - 2017-02-28 00:02:11 --> Language Class Initialized
INFO - 2017-02-28 00:02:11 --> Loader Class Initialized
INFO - 2017-02-28 00:02:11 --> Database Driver Class Initialized
INFO - 2017-02-28 00:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:02:11 --> Controller Class Initialized
INFO - 2017-02-28 00:02:11 --> Helper loaded: url_helper
DEBUG - 2017-02-28 00:02:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-28 00:02:12 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-28 00:02:12 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Clau Amine Henriz')
INFO - 2017-02-28 00:02:12 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-28 00:02:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-28 00:02:34 --> Config Class Initialized
INFO - 2017-02-28 00:02:34 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:02:34 --> Utf8 Class Initialized
INFO - 2017-02-28 00:02:34 --> URI Class Initialized
INFO - 2017-02-28 00:02:34 --> Router Class Initialized
INFO - 2017-02-28 00:02:34 --> Output Class Initialized
INFO - 2017-02-28 00:02:34 --> Security Class Initialized
DEBUG - 2017-02-28 00:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:02:34 --> Input Class Initialized
INFO - 2017-02-28 00:02:34 --> Language Class Initialized
INFO - 2017-02-28 00:02:34 --> Loader Class Initialized
INFO - 2017-02-28 00:02:35 --> Database Driver Class Initialized
INFO - 2017-02-28 00:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:02:35 --> Controller Class Initialized
INFO - 2017-02-28 00:02:35 --> Helper loaded: url_helper
DEBUG - 2017-02-28 00:02:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:02:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:02:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 00:02:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 00:02:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:02:35 --> Final output sent to browser
DEBUG - 2017-02-28 00:02:35 --> Total execution time: 1.2461
INFO - 2017-02-28 00:02:40 --> Config Class Initialized
INFO - 2017-02-28 00:02:40 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:02:40 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:02:40 --> Utf8 Class Initialized
INFO - 2017-02-28 00:02:40 --> URI Class Initialized
INFO - 2017-02-28 00:02:40 --> Router Class Initialized
INFO - 2017-02-28 00:02:40 --> Output Class Initialized
INFO - 2017-02-28 00:02:40 --> Security Class Initialized
DEBUG - 2017-02-28 00:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:02:41 --> Input Class Initialized
INFO - 2017-02-28 00:02:41 --> Language Class Initialized
INFO - 2017-02-28 00:02:41 --> Loader Class Initialized
INFO - 2017-02-28 00:02:41 --> Database Driver Class Initialized
INFO - 2017-02-28 00:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:02:41 --> Controller Class Initialized
INFO - 2017-02-28 00:02:41 --> Helper loaded: url_helper
DEBUG - 2017-02-28 00:02:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:02:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:02:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 00:02:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 00:02:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:02:41 --> Final output sent to browser
DEBUG - 2017-02-28 00:02:41 --> Total execution time: 1.2510
INFO - 2017-02-28 00:02:45 --> Config Class Initialized
INFO - 2017-02-28 00:02:45 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:02:45 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:02:45 --> Utf8 Class Initialized
INFO - 2017-02-28 00:02:45 --> URI Class Initialized
INFO - 2017-02-28 00:02:45 --> Router Class Initialized
INFO - 2017-02-28 00:02:45 --> Output Class Initialized
INFO - 2017-02-28 00:02:45 --> Security Class Initialized
DEBUG - 2017-02-28 00:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:02:45 --> Input Class Initialized
INFO - 2017-02-28 00:02:45 --> Language Class Initialized
INFO - 2017-02-28 00:02:45 --> Loader Class Initialized
INFO - 2017-02-28 00:02:45 --> Database Driver Class Initialized
INFO - 2017-02-28 00:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:02:45 --> Controller Class Initialized
INFO - 2017-02-28 00:02:45 --> Helper loaded: url_helper
DEBUG - 2017-02-28 00:02:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:02:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:02:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 00:02:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 00:02:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:02:46 --> Final output sent to browser
DEBUG - 2017-02-28 00:02:46 --> Total execution time: 1.2792
INFO - 2017-02-28 00:02:50 --> Config Class Initialized
INFO - 2017-02-28 00:02:50 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:02:50 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:02:50 --> Utf8 Class Initialized
INFO - 2017-02-28 00:02:50 --> URI Class Initialized
INFO - 2017-02-28 00:02:50 --> Router Class Initialized
INFO - 2017-02-28 00:02:50 --> Output Class Initialized
INFO - 2017-02-28 00:02:50 --> Security Class Initialized
DEBUG - 2017-02-28 00:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:02:50 --> Input Class Initialized
INFO - 2017-02-28 00:02:50 --> Language Class Initialized
INFO - 2017-02-28 00:02:50 --> Loader Class Initialized
INFO - 2017-02-28 00:02:50 --> Database Driver Class Initialized
INFO - 2017-02-28 00:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:02:51 --> Controller Class Initialized
INFO - 2017-02-28 00:02:51 --> Helper loaded: url_helper
DEBUG - 2017-02-28 00:02:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:02:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:02:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 00:02:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 00:02:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:02:51 --> Final output sent to browser
DEBUG - 2017-02-28 00:02:51 --> Total execution time: 1.2588
INFO - 2017-02-28 00:03:51 --> Config Class Initialized
INFO - 2017-02-28 00:03:51 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:03:51 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:03:51 --> Utf8 Class Initialized
INFO - 2017-02-28 00:03:51 --> URI Class Initialized
DEBUG - 2017-02-28 00:03:51 --> No URI present. Default controller set.
INFO - 2017-02-28 00:03:51 --> Router Class Initialized
INFO - 2017-02-28 00:03:51 --> Output Class Initialized
INFO - 2017-02-28 00:03:51 --> Security Class Initialized
DEBUG - 2017-02-28 00:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:03:51 --> Input Class Initialized
INFO - 2017-02-28 00:03:51 --> Language Class Initialized
INFO - 2017-02-28 00:03:51 --> Loader Class Initialized
INFO - 2017-02-28 00:03:51 --> Database Driver Class Initialized
INFO - 2017-02-28 00:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:03:52 --> Controller Class Initialized
INFO - 2017-02-28 00:03:52 --> Helper loaded: url_helper
DEBUG - 2017-02-28 00:03:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:03:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:03:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 00:03:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 00:03:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:03:52 --> Final output sent to browser
DEBUG - 2017-02-28 00:03:52 --> Total execution time: 1.5177
INFO - 2017-02-28 00:04:19 --> Config Class Initialized
INFO - 2017-02-28 00:04:19 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:04:19 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:04:19 --> Utf8 Class Initialized
INFO - 2017-02-28 00:04:19 --> URI Class Initialized
INFO - 2017-02-28 00:04:19 --> Router Class Initialized
INFO - 2017-02-28 00:04:19 --> Output Class Initialized
INFO - 2017-02-28 00:04:19 --> Security Class Initialized
DEBUG - 2017-02-28 00:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:04:19 --> Input Class Initialized
INFO - 2017-02-28 00:04:19 --> Language Class Initialized
INFO - 2017-02-28 00:04:19 --> Loader Class Initialized
INFO - 2017-02-28 00:04:20 --> Database Driver Class Initialized
INFO - 2017-02-28 00:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:04:20 --> Controller Class Initialized
INFO - 2017-02-28 00:04:20 --> Helper loaded: url_helper
DEBUG - 2017-02-28 00:04:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:04:20 --> Config Class Initialized
INFO - 2017-02-28 00:04:20 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:04:20 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:04:20 --> Utf8 Class Initialized
INFO - 2017-02-28 00:04:20 --> URI Class Initialized
INFO - 2017-02-28 00:04:20 --> Router Class Initialized
INFO - 2017-02-28 00:04:20 --> Output Class Initialized
INFO - 2017-02-28 00:04:20 --> Security Class Initialized
DEBUG - 2017-02-28 00:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:04:20 --> Input Class Initialized
INFO - 2017-02-28 00:04:20 --> Language Class Initialized
INFO - 2017-02-28 00:04:20 --> Loader Class Initialized
INFO - 2017-02-28 00:04:20 --> Database Driver Class Initialized
INFO - 2017-02-28 00:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:04:20 --> Controller Class Initialized
INFO - 2017-02-28 00:04:20 --> Helper loaded: date_helper
DEBUG - 2017-02-28 00:04:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:04:20 --> Helper loaded: url_helper
INFO - 2017-02-28 00:04:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:04:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 00:04:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-28 00:04:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-28 00:04:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:04:20 --> Final output sent to browser
DEBUG - 2017-02-28 00:04:20 --> Total execution time: 0.1244
INFO - 2017-02-28 00:04:30 --> Config Class Initialized
INFO - 2017-02-28 00:04:30 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:04:30 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:04:30 --> Utf8 Class Initialized
INFO - 2017-02-28 00:04:30 --> URI Class Initialized
INFO - 2017-02-28 00:04:30 --> Router Class Initialized
INFO - 2017-02-28 00:04:31 --> Output Class Initialized
INFO - 2017-02-28 00:04:31 --> Security Class Initialized
DEBUG - 2017-02-28 00:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:04:31 --> Input Class Initialized
INFO - 2017-02-28 00:04:31 --> Language Class Initialized
INFO - 2017-02-28 00:04:31 --> Loader Class Initialized
INFO - 2017-02-28 00:04:31 --> Database Driver Class Initialized
INFO - 2017-02-28 00:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:04:31 --> Controller Class Initialized
INFO - 2017-02-28 00:04:31 --> Helper loaded: date_helper
DEBUG - 2017-02-28 00:04:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:04:31 --> Helper loaded: url_helper
INFO - 2017-02-28 00:04:31 --> Helper loaded: download_helper
INFO - 2017-02-28 00:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 00:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-28 00:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-28 00:04:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:04:31 --> Final output sent to browser
DEBUG - 2017-02-28 00:04:31 --> Total execution time: 1.2478
INFO - 2017-02-28 00:05:11 --> Config Class Initialized
INFO - 2017-02-28 00:05:11 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:05:11 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:05:11 --> Utf8 Class Initialized
INFO - 2017-02-28 00:05:11 --> URI Class Initialized
INFO - 2017-02-28 00:05:11 --> Router Class Initialized
INFO - 2017-02-28 00:05:11 --> Output Class Initialized
INFO - 2017-02-28 00:05:11 --> Security Class Initialized
DEBUG - 2017-02-28 00:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:05:11 --> Input Class Initialized
INFO - 2017-02-28 00:05:11 --> Language Class Initialized
INFO - 2017-02-28 00:05:12 --> Loader Class Initialized
INFO - 2017-02-28 00:05:12 --> Database Driver Class Initialized
INFO - 2017-02-28 00:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:05:12 --> Controller Class Initialized
INFO - 2017-02-28 00:05:12 --> Helper loaded: date_helper
DEBUG - 2017-02-28 00:05:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:05:12 --> Helper loaded: url_helper
INFO - 2017-02-28 00:05:12 --> Helper loaded: download_helper
INFO - 2017-02-28 00:05:12 --> Final output sent to browser
DEBUG - 2017-02-28 00:05:12 --> Total execution time: 1.3186
INFO - 2017-02-28 00:05:15 --> Config Class Initialized
INFO - 2017-02-28 00:05:15 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:05:15 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:05:15 --> Utf8 Class Initialized
INFO - 2017-02-28 00:05:15 --> URI Class Initialized
INFO - 2017-02-28 00:05:15 --> Router Class Initialized
INFO - 2017-02-28 00:05:15 --> Output Class Initialized
INFO - 2017-02-28 00:05:15 --> Security Class Initialized
DEBUG - 2017-02-28 00:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:05:15 --> Input Class Initialized
INFO - 2017-02-28 00:05:15 --> Language Class Initialized
INFO - 2017-02-28 00:05:15 --> Loader Class Initialized
INFO - 2017-02-28 00:05:15 --> Database Driver Class Initialized
INFO - 2017-02-28 00:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:05:15 --> Controller Class Initialized
INFO - 2017-02-28 00:05:15 --> Helper loaded: date_helper
DEBUG - 2017-02-28 00:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:05:15 --> Helper loaded: url_helper
INFO - 2017-02-28 00:05:15 --> Helper loaded: download_helper
INFO - 2017-02-28 00:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 00:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-28 00:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-28 00:05:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:05:15 --> Final output sent to browser
DEBUG - 2017-02-28 00:05:15 --> Total execution time: 0.1399
INFO - 2017-02-28 00:06:16 --> Config Class Initialized
INFO - 2017-02-28 00:06:16 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:06:16 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:06:16 --> Utf8 Class Initialized
INFO - 2017-02-28 00:06:16 --> URI Class Initialized
INFO - 2017-02-28 00:06:16 --> Router Class Initialized
INFO - 2017-02-28 00:06:16 --> Output Class Initialized
INFO - 2017-02-28 00:06:16 --> Security Class Initialized
DEBUG - 2017-02-28 00:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:06:16 --> Input Class Initialized
INFO - 2017-02-28 00:06:16 --> Language Class Initialized
INFO - 2017-02-28 00:06:16 --> Loader Class Initialized
INFO - 2017-02-28 00:06:17 --> Database Driver Class Initialized
INFO - 2017-02-28 00:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:06:17 --> Controller Class Initialized
INFO - 2017-02-28 00:06:17 --> Helper loaded: date_helper
INFO - 2017-02-28 00:06:17 --> Helper loaded: url_helper
DEBUG - 2017-02-28 00:06:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:06:18 --> Helper loaded: form_helper
INFO - 2017-02-28 00:06:18 --> Form Validation Class Initialized
INFO - 2017-02-28 00:06:18 --> Final output sent to browser
DEBUG - 2017-02-28 00:06:18 --> Total execution time: 1.7665
INFO - 2017-02-28 00:06:24 --> Config Class Initialized
INFO - 2017-02-28 00:06:24 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:06:24 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:06:24 --> Utf8 Class Initialized
INFO - 2017-02-28 00:06:24 --> URI Class Initialized
INFO - 2017-02-28 00:06:25 --> Router Class Initialized
INFO - 2017-02-28 00:06:25 --> Output Class Initialized
INFO - 2017-02-28 00:06:25 --> Security Class Initialized
DEBUG - 2017-02-28 00:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:06:25 --> Input Class Initialized
INFO - 2017-02-28 00:06:25 --> Language Class Initialized
INFO - 2017-02-28 00:06:25 --> Loader Class Initialized
INFO - 2017-02-28 00:06:25 --> Database Driver Class Initialized
INFO - 2017-02-28 00:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:06:25 --> Controller Class Initialized
INFO - 2017-02-28 00:06:25 --> Helper loaded: date_helper
INFO - 2017-02-28 00:06:26 --> Helper loaded: url_helper
DEBUG - 2017-02-28 00:06:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:06:26 --> Helper loaded: form_helper
INFO - 2017-02-28 00:06:26 --> Form Validation Class Initialized
INFO - 2017-02-28 00:06:26 --> Final output sent to browser
DEBUG - 2017-02-28 00:06:26 --> Total execution time: 1.8388
INFO - 2017-02-28 00:06:34 --> Config Class Initialized
INFO - 2017-02-28 00:06:34 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:06:34 --> Utf8 Class Initialized
INFO - 2017-02-28 00:06:34 --> URI Class Initialized
INFO - 2017-02-28 00:06:34 --> Router Class Initialized
INFO - 2017-02-28 00:06:34 --> Output Class Initialized
INFO - 2017-02-28 00:06:34 --> Security Class Initialized
DEBUG - 2017-02-28 00:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:06:34 --> Input Class Initialized
INFO - 2017-02-28 00:06:34 --> Language Class Initialized
INFO - 2017-02-28 00:06:35 --> Loader Class Initialized
INFO - 2017-02-28 00:06:35 --> Database Driver Class Initialized
INFO - 2017-02-28 00:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:06:35 --> Controller Class Initialized
INFO - 2017-02-28 00:06:35 --> Helper loaded: date_helper
DEBUG - 2017-02-28 00:06:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:06:35 --> Helper loaded: url_helper
INFO - 2017-02-28 00:06:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:06:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 00:06:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-28 00:06:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-28 00:06:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:06:36 --> Final output sent to browser
DEBUG - 2017-02-28 00:06:36 --> Total execution time: 2.8025
INFO - 2017-02-28 00:06:36 --> Config Class Initialized
INFO - 2017-02-28 00:06:36 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:06:36 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:06:36 --> Utf8 Class Initialized
INFO - 2017-02-28 00:06:36 --> URI Class Initialized
INFO - 2017-02-28 00:06:36 --> Router Class Initialized
INFO - 2017-02-28 00:06:36 --> Output Class Initialized
INFO - 2017-02-28 00:06:36 --> Security Class Initialized
DEBUG - 2017-02-28 00:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:06:36 --> Input Class Initialized
INFO - 2017-02-28 00:06:36 --> Language Class Initialized
INFO - 2017-02-28 00:06:36 --> Loader Class Initialized
INFO - 2017-02-28 00:06:36 --> Database Driver Class Initialized
INFO - 2017-02-28 00:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:06:36 --> Controller Class Initialized
INFO - 2017-02-28 00:06:36 --> Helper loaded: date_helper
DEBUG - 2017-02-28 00:06:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:06:36 --> Helper loaded: url_helper
INFO - 2017-02-28 00:06:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:06:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 00:06:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-28 00:06:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-28 00:06:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:06:36 --> Final output sent to browser
DEBUG - 2017-02-28 00:06:36 --> Total execution time: 0.0597
INFO - 2017-02-28 00:07:26 --> Config Class Initialized
INFO - 2017-02-28 00:07:26 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:07:26 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:07:26 --> Utf8 Class Initialized
INFO - 2017-02-28 00:07:26 --> URI Class Initialized
INFO - 2017-02-28 00:07:26 --> Router Class Initialized
INFO - 2017-02-28 00:07:26 --> Output Class Initialized
INFO - 2017-02-28 00:07:26 --> Security Class Initialized
DEBUG - 2017-02-28 00:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:07:27 --> Input Class Initialized
INFO - 2017-02-28 00:07:27 --> Language Class Initialized
INFO - 2017-02-28 00:07:27 --> Loader Class Initialized
INFO - 2017-02-28 00:07:27 --> Database Driver Class Initialized
INFO - 2017-02-28 00:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:07:27 --> Controller Class Initialized
INFO - 2017-02-28 00:07:28 --> Upload Class Initialized
INFO - 2017-02-28 00:07:28 --> Helper loaded: date_helper
DEBUG - 2017-02-28 00:07:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:07:28 --> Helper loaded: url_helper
INFO - 2017-02-28 00:07:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:07:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 00:07:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-02-28 00:07:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-02-28 00:07:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-02-28 00:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:07:29 --> Final output sent to browser
DEBUG - 2017-02-28 00:07:29 --> Total execution time: 2.5252
INFO - 2017-02-28 00:08:13 --> Config Class Initialized
INFO - 2017-02-28 00:08:13 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:08:13 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:08:13 --> Utf8 Class Initialized
INFO - 2017-02-28 00:08:13 --> URI Class Initialized
INFO - 2017-02-28 00:08:13 --> Router Class Initialized
INFO - 2017-02-28 00:08:13 --> Output Class Initialized
INFO - 2017-02-28 00:08:13 --> Security Class Initialized
DEBUG - 2017-02-28 00:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:08:13 --> Input Class Initialized
INFO - 2017-02-28 00:08:13 --> Language Class Initialized
INFO - 2017-02-28 00:08:13 --> Loader Class Initialized
INFO - 2017-02-28 00:08:14 --> Database Driver Class Initialized
INFO - 2017-02-28 00:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:08:14 --> Controller Class Initialized
INFO - 2017-02-28 00:08:14 --> Helper loaded: date_helper
DEBUG - 2017-02-28 00:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:08:14 --> Helper loaded: url_helper
INFO - 2017-02-28 00:08:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:08:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-02-28 00:08:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 00:08:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-02-28 00:08:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-02-28 00:08:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:08:14 --> Final output sent to browser
DEBUG - 2017-02-28 00:08:14 --> Total execution time: 1.2839
INFO - 2017-02-28 00:08:19 --> Config Class Initialized
INFO - 2017-02-28 00:08:19 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:08:19 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:08:19 --> Utf8 Class Initialized
INFO - 2017-02-28 00:08:19 --> URI Class Initialized
INFO - 2017-02-28 00:08:19 --> Router Class Initialized
INFO - 2017-02-28 00:08:19 --> Output Class Initialized
INFO - 2017-02-28 00:08:19 --> Security Class Initialized
DEBUG - 2017-02-28 00:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:08:19 --> Input Class Initialized
INFO - 2017-02-28 00:08:19 --> Language Class Initialized
INFO - 2017-02-28 00:08:19 --> Loader Class Initialized
INFO - 2017-02-28 00:08:19 --> Database Driver Class Initialized
INFO - 2017-02-28 00:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:08:19 --> Controller Class Initialized
INFO - 2017-02-28 00:08:19 --> Helper loaded: date_helper
DEBUG - 2017-02-28 00:08:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:08:19 --> Helper loaded: url_helper
INFO - 2017-02-28 00:08:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:08:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 00:08:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-28 00:08:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-28 00:08:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:08:19 --> Final output sent to browser
DEBUG - 2017-02-28 00:08:19 --> Total execution time: 0.0490
INFO - 2017-02-28 00:08:24 --> Config Class Initialized
INFO - 2017-02-28 00:08:24 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:08:24 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:08:24 --> Utf8 Class Initialized
INFO - 2017-02-28 00:08:24 --> URI Class Initialized
INFO - 2017-02-28 00:08:24 --> Router Class Initialized
INFO - 2017-02-28 00:08:24 --> Output Class Initialized
INFO - 2017-02-28 00:08:24 --> Security Class Initialized
DEBUG - 2017-02-28 00:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:08:24 --> Input Class Initialized
INFO - 2017-02-28 00:08:24 --> Language Class Initialized
INFO - 2017-02-28 00:08:24 --> Loader Class Initialized
INFO - 2017-02-28 00:08:24 --> Database Driver Class Initialized
INFO - 2017-02-28 00:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:08:24 --> Controller Class Initialized
INFO - 2017-02-28 00:08:24 --> Helper loaded: date_helper
DEBUG - 2017-02-28 00:08:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:08:24 --> Helper loaded: url_helper
INFO - 2017-02-28 00:08:24 --> Final output sent to browser
DEBUG - 2017-02-28 00:08:24 --> Total execution time: 0.0330
INFO - 2017-02-28 00:08:31 --> Config Class Initialized
INFO - 2017-02-28 00:08:31 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:08:31 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:08:31 --> Utf8 Class Initialized
INFO - 2017-02-28 00:08:31 --> URI Class Initialized
INFO - 2017-02-28 00:08:31 --> Router Class Initialized
INFO - 2017-02-28 00:08:31 --> Output Class Initialized
INFO - 2017-02-28 00:08:31 --> Security Class Initialized
DEBUG - 2017-02-28 00:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:08:31 --> Input Class Initialized
INFO - 2017-02-28 00:08:31 --> Language Class Initialized
INFO - 2017-02-28 00:08:31 --> Loader Class Initialized
INFO - 2017-02-28 00:08:31 --> Database Driver Class Initialized
INFO - 2017-02-28 00:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:08:31 --> Controller Class Initialized
INFO - 2017-02-28 00:08:31 --> Helper loaded: date_helper
DEBUG - 2017-02-28 00:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:08:31 --> Helper loaded: url_helper
INFO - 2017-02-28 00:08:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:08:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-02-28 00:08:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 00:08:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-02-28 00:08:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-02-28 00:08:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:08:31 --> Final output sent to browser
DEBUG - 2017-02-28 00:08:31 --> Total execution time: 0.0153
INFO - 2017-02-28 00:08:36 --> Config Class Initialized
INFO - 2017-02-28 00:08:36 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:08:36 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:08:36 --> Utf8 Class Initialized
INFO - 2017-02-28 00:08:36 --> URI Class Initialized
INFO - 2017-02-28 00:08:36 --> Router Class Initialized
INFO - 2017-02-28 00:08:36 --> Output Class Initialized
INFO - 2017-02-28 00:08:36 --> Security Class Initialized
DEBUG - 2017-02-28 00:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:08:36 --> Input Class Initialized
INFO - 2017-02-28 00:08:36 --> Language Class Initialized
INFO - 2017-02-28 00:08:36 --> Loader Class Initialized
INFO - 2017-02-28 00:08:36 --> Database Driver Class Initialized
INFO - 2017-02-28 00:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:08:36 --> Controller Class Initialized
INFO - 2017-02-28 00:08:36 --> Helper loaded: date_helper
DEBUG - 2017-02-28 00:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:08:36 --> Helper loaded: url_helper
INFO - 2017-02-28 00:08:36 --> Final output sent to browser
DEBUG - 2017-02-28 00:08:36 --> Total execution time: 0.0163
INFO - 2017-02-28 00:08:36 --> Config Class Initialized
INFO - 2017-02-28 00:08:36 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:08:36 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:08:36 --> Utf8 Class Initialized
INFO - 2017-02-28 00:08:36 --> URI Class Initialized
INFO - 2017-02-28 00:08:36 --> Router Class Initialized
INFO - 2017-02-28 00:08:36 --> Output Class Initialized
INFO - 2017-02-28 00:08:36 --> Security Class Initialized
DEBUG - 2017-02-28 00:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:08:36 --> Input Class Initialized
INFO - 2017-02-28 00:08:36 --> Language Class Initialized
INFO - 2017-02-28 00:08:36 --> Loader Class Initialized
INFO - 2017-02-28 00:08:36 --> Database Driver Class Initialized
INFO - 2017-02-28 00:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:08:36 --> Controller Class Initialized
INFO - 2017-02-28 00:08:36 --> Helper loaded: date_helper
DEBUG - 2017-02-28 00:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:08:36 --> Helper loaded: url_helper
INFO - 2017-02-28 00:08:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:08:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-02-28 00:08:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 00:08:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-02-28 00:08:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-02-28 00:08:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:08:36 --> Final output sent to browser
DEBUG - 2017-02-28 00:08:36 --> Total execution time: 0.0139
INFO - 2017-02-28 00:08:42 --> Config Class Initialized
INFO - 2017-02-28 00:08:42 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:08:42 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:08:42 --> Utf8 Class Initialized
INFO - 2017-02-28 00:08:42 --> URI Class Initialized
INFO - 2017-02-28 00:08:42 --> Router Class Initialized
INFO - 2017-02-28 00:08:42 --> Output Class Initialized
INFO - 2017-02-28 00:08:42 --> Security Class Initialized
DEBUG - 2017-02-28 00:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:08:42 --> Input Class Initialized
INFO - 2017-02-28 00:08:42 --> Language Class Initialized
INFO - 2017-02-28 00:08:42 --> Loader Class Initialized
INFO - 2017-02-28 00:08:42 --> Database Driver Class Initialized
INFO - 2017-02-28 00:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:08:43 --> Controller Class Initialized
INFO - 2017-02-28 00:08:43 --> Helper loaded: date_helper
DEBUG - 2017-02-28 00:08:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:08:43 --> Helper loaded: url_helper
INFO - 2017-02-28 00:08:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:08:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 00:08:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-28 00:08:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-28 00:08:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:08:43 --> Final output sent to browser
DEBUG - 2017-02-28 00:08:43 --> Total execution time: 0.5934
INFO - 2017-02-28 00:08:47 --> Config Class Initialized
INFO - 2017-02-28 00:08:47 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:08:47 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:08:47 --> Utf8 Class Initialized
INFO - 2017-02-28 00:08:47 --> URI Class Initialized
INFO - 2017-02-28 00:08:47 --> Router Class Initialized
INFO - 2017-02-28 00:08:47 --> Output Class Initialized
INFO - 2017-02-28 00:08:47 --> Security Class Initialized
DEBUG - 2017-02-28 00:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:08:47 --> Input Class Initialized
INFO - 2017-02-28 00:08:47 --> Language Class Initialized
INFO - 2017-02-28 00:08:47 --> Loader Class Initialized
INFO - 2017-02-28 00:08:47 --> Database Driver Class Initialized
INFO - 2017-02-28 00:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:08:47 --> Controller Class Initialized
INFO - 2017-02-28 00:08:47 --> Helper loaded: date_helper
DEBUG - 2017-02-28 00:08:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:08:47 --> Helper loaded: url_helper
INFO - 2017-02-28 00:08:47 --> Helper loaded: download_helper
INFO - 2017-02-28 00:08:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:08:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 00:08:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-28 00:08:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-28 00:08:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:08:47 --> Final output sent to browser
DEBUG - 2017-02-28 00:08:47 --> Total execution time: 0.1014
INFO - 2017-02-28 00:09:06 --> Config Class Initialized
INFO - 2017-02-28 00:09:06 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:09:06 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:09:06 --> Utf8 Class Initialized
INFO - 2017-02-28 00:09:06 --> URI Class Initialized
INFO - 2017-02-28 00:09:06 --> Router Class Initialized
INFO - 2017-02-28 00:09:06 --> Output Class Initialized
INFO - 2017-02-28 00:09:06 --> Security Class Initialized
DEBUG - 2017-02-28 00:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:09:06 --> Input Class Initialized
INFO - 2017-02-28 00:09:06 --> Language Class Initialized
INFO - 2017-02-28 00:09:06 --> Loader Class Initialized
INFO - 2017-02-28 00:09:06 --> Database Driver Class Initialized
INFO - 2017-02-28 00:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:09:06 --> Controller Class Initialized
INFO - 2017-02-28 00:09:06 --> Helper loaded: date_helper
DEBUG - 2017-02-28 00:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:09:06 --> Helper loaded: url_helper
INFO - 2017-02-28 00:09:06 --> Helper loaded: download_helper
INFO - 2017-02-28 00:09:06 --> Final output sent to browser
DEBUG - 2017-02-28 00:09:06 --> Total execution time: 0.0143
INFO - 2017-02-28 00:09:07 --> Config Class Initialized
INFO - 2017-02-28 00:09:07 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:09:07 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:09:07 --> Utf8 Class Initialized
INFO - 2017-02-28 00:09:07 --> URI Class Initialized
INFO - 2017-02-28 00:09:07 --> Router Class Initialized
INFO - 2017-02-28 00:09:07 --> Output Class Initialized
INFO - 2017-02-28 00:09:07 --> Security Class Initialized
DEBUG - 2017-02-28 00:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:09:07 --> Input Class Initialized
INFO - 2017-02-28 00:09:07 --> Language Class Initialized
INFO - 2017-02-28 00:09:07 --> Loader Class Initialized
INFO - 2017-02-28 00:09:07 --> Database Driver Class Initialized
INFO - 2017-02-28 00:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:09:07 --> Controller Class Initialized
INFO - 2017-02-28 00:09:07 --> Helper loaded: date_helper
DEBUG - 2017-02-28 00:09:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:09:07 --> Helper loaded: url_helper
INFO - 2017-02-28 00:09:07 --> Helper loaded: download_helper
INFO - 2017-02-28 00:09:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:09:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 00:09:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-28 00:09:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-28 00:09:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:09:07 --> Final output sent to browser
DEBUG - 2017-02-28 00:09:07 --> Total execution time: 0.0198
INFO - 2017-02-28 00:12:58 --> Config Class Initialized
INFO - 2017-02-28 00:12:58 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:12:58 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:12:58 --> Utf8 Class Initialized
INFO - 2017-02-28 00:12:58 --> URI Class Initialized
DEBUG - 2017-02-28 00:12:58 --> No URI present. Default controller set.
INFO - 2017-02-28 00:12:58 --> Router Class Initialized
INFO - 2017-02-28 00:12:59 --> Output Class Initialized
INFO - 2017-02-28 00:12:59 --> Security Class Initialized
DEBUG - 2017-02-28 00:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:12:59 --> Input Class Initialized
INFO - 2017-02-28 00:12:59 --> Language Class Initialized
INFO - 2017-02-28 00:12:59 --> Loader Class Initialized
INFO - 2017-02-28 00:12:59 --> Database Driver Class Initialized
INFO - 2017-02-28 00:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:13:00 --> Controller Class Initialized
INFO - 2017-02-28 00:13:00 --> Helper loaded: url_helper
DEBUG - 2017-02-28 00:13:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:13:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:13:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 00:13:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 00:13:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:13:00 --> Final output sent to browser
DEBUG - 2017-02-28 00:13:00 --> Total execution time: 1.8048
INFO - 2017-02-28 00:13:33 --> Config Class Initialized
INFO - 2017-02-28 00:13:33 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:13:33 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:13:33 --> Utf8 Class Initialized
INFO - 2017-02-28 00:13:33 --> URI Class Initialized
INFO - 2017-02-28 00:13:33 --> Router Class Initialized
INFO - 2017-02-28 00:13:33 --> Output Class Initialized
INFO - 2017-02-28 00:13:33 --> Security Class Initialized
DEBUG - 2017-02-28 00:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:13:33 --> Input Class Initialized
INFO - 2017-02-28 00:13:33 --> Language Class Initialized
INFO - 2017-02-28 00:13:33 --> Loader Class Initialized
INFO - 2017-02-28 00:13:34 --> Database Driver Class Initialized
INFO - 2017-02-28 00:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:13:34 --> Controller Class Initialized
INFO - 2017-02-28 00:13:34 --> Helper loaded: url_helper
DEBUG - 2017-02-28 00:13:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:13:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:13:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 00:13:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 00:13:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:13:34 --> Final output sent to browser
DEBUG - 2017-02-28 00:13:34 --> Total execution time: 1.2158
INFO - 2017-02-28 00:13:44 --> Config Class Initialized
INFO - 2017-02-28 00:13:44 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:13:44 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:13:44 --> Utf8 Class Initialized
INFO - 2017-02-28 00:13:44 --> URI Class Initialized
INFO - 2017-02-28 00:13:44 --> Router Class Initialized
INFO - 2017-02-28 00:13:44 --> Output Class Initialized
INFO - 2017-02-28 00:13:44 --> Security Class Initialized
DEBUG - 2017-02-28 00:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:13:44 --> Input Class Initialized
INFO - 2017-02-28 00:13:44 --> Language Class Initialized
INFO - 2017-02-28 00:13:44 --> Loader Class Initialized
INFO - 2017-02-28 00:13:45 --> Database Driver Class Initialized
INFO - 2017-02-28 00:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:13:45 --> Controller Class Initialized
INFO - 2017-02-28 00:13:45 --> Helper loaded: url_helper
DEBUG - 2017-02-28 00:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 00:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 00:13:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:13:45 --> Final output sent to browser
DEBUG - 2017-02-28 00:13:45 --> Total execution time: 1.5459
INFO - 2017-02-28 00:14:06 --> Config Class Initialized
INFO - 2017-02-28 00:14:06 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:14:06 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:14:06 --> Utf8 Class Initialized
INFO - 2017-02-28 00:14:06 --> URI Class Initialized
INFO - 2017-02-28 00:14:06 --> Router Class Initialized
INFO - 2017-02-28 00:14:06 --> Output Class Initialized
INFO - 2017-02-28 00:14:06 --> Security Class Initialized
DEBUG - 2017-02-28 00:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:14:06 --> Input Class Initialized
INFO - 2017-02-28 00:14:06 --> Language Class Initialized
INFO - 2017-02-28 00:14:06 --> Loader Class Initialized
INFO - 2017-02-28 00:14:07 --> Database Driver Class Initialized
INFO - 2017-02-28 00:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:14:07 --> Controller Class Initialized
INFO - 2017-02-28 00:14:07 --> Helper loaded: url_helper
DEBUG - 2017-02-28 00:14:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:14:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:14:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 00:14:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 00:14:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:14:08 --> Final output sent to browser
DEBUG - 2017-02-28 00:14:08 --> Total execution time: 1.5593
INFO - 2017-02-28 00:24:09 --> Config Class Initialized
INFO - 2017-02-28 00:24:09 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:24:09 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:24:09 --> Utf8 Class Initialized
INFO - 2017-02-28 00:24:09 --> URI Class Initialized
DEBUG - 2017-02-28 00:24:09 --> No URI present. Default controller set.
INFO - 2017-02-28 00:24:09 --> Router Class Initialized
INFO - 2017-02-28 00:24:09 --> Output Class Initialized
INFO - 2017-02-28 00:24:09 --> Security Class Initialized
DEBUG - 2017-02-28 00:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:24:10 --> Input Class Initialized
INFO - 2017-02-28 00:24:10 --> Language Class Initialized
INFO - 2017-02-28 00:24:10 --> Loader Class Initialized
INFO - 2017-02-28 00:24:10 --> Database Driver Class Initialized
INFO - 2017-02-28 00:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:24:11 --> Controller Class Initialized
INFO - 2017-02-28 00:24:11 --> Helper loaded: url_helper
DEBUG - 2017-02-28 00:24:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:24:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:24:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 00:24:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 00:24:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:24:11 --> Final output sent to browser
DEBUG - 2017-02-28 00:24:11 --> Total execution time: 1.8922
INFO - 2017-02-28 00:25:13 --> Config Class Initialized
INFO - 2017-02-28 00:25:13 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:25:13 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:25:13 --> Utf8 Class Initialized
INFO - 2017-02-28 00:25:13 --> URI Class Initialized
INFO - 2017-02-28 00:25:13 --> Router Class Initialized
INFO - 2017-02-28 00:25:13 --> Output Class Initialized
INFO - 2017-02-28 00:25:13 --> Security Class Initialized
DEBUG - 2017-02-28 00:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:25:13 --> Input Class Initialized
INFO - 2017-02-28 00:25:13 --> Language Class Initialized
INFO - 2017-02-28 00:25:13 --> Loader Class Initialized
INFO - 2017-02-28 00:25:13 --> Database Driver Class Initialized
INFO - 2017-02-28 00:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:25:14 --> Controller Class Initialized
INFO - 2017-02-28 00:25:14 --> Helper loaded: url_helper
DEBUG - 2017-02-28 00:25:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:25:16 --> Config Class Initialized
INFO - 2017-02-28 00:25:16 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:25:16 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:25:16 --> Utf8 Class Initialized
INFO - 2017-02-28 00:25:16 --> URI Class Initialized
INFO - 2017-02-28 00:25:17 --> Router Class Initialized
INFO - 2017-02-28 00:25:17 --> Output Class Initialized
INFO - 2017-02-28 00:25:17 --> Security Class Initialized
DEBUG - 2017-02-28 00:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:25:17 --> Input Class Initialized
INFO - 2017-02-28 00:25:17 --> Language Class Initialized
INFO - 2017-02-28 00:25:17 --> Loader Class Initialized
INFO - 2017-02-28 00:25:17 --> Database Driver Class Initialized
INFO - 2017-02-28 00:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:25:18 --> Controller Class Initialized
INFO - 2017-02-28 00:25:18 --> Helper loaded: date_helper
DEBUG - 2017-02-28 00:25:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:25:18 --> Helper loaded: url_helper
INFO - 2017-02-28 00:25:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:25:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-28 00:25:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-28 00:25:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-28 00:25:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:25:18 --> Final output sent to browser
DEBUG - 2017-02-28 00:25:18 --> Total execution time: 1.4729
INFO - 2017-02-28 00:25:23 --> Config Class Initialized
INFO - 2017-02-28 00:25:23 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:25:23 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:25:23 --> Utf8 Class Initialized
INFO - 2017-02-28 00:25:23 --> URI Class Initialized
INFO - 2017-02-28 00:25:23 --> Router Class Initialized
INFO - 2017-02-28 00:25:23 --> Output Class Initialized
INFO - 2017-02-28 00:25:23 --> Security Class Initialized
DEBUG - 2017-02-28 00:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:25:23 --> Input Class Initialized
INFO - 2017-02-28 00:25:23 --> Language Class Initialized
INFO - 2017-02-28 00:25:23 --> Loader Class Initialized
INFO - 2017-02-28 00:25:23 --> Database Driver Class Initialized
INFO - 2017-02-28 00:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:25:23 --> Controller Class Initialized
INFO - 2017-02-28 00:25:23 --> Helper loaded: url_helper
DEBUG - 2017-02-28 00:25:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:25:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:25:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 00:25:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 00:25:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:25:23 --> Final output sent to browser
DEBUG - 2017-02-28 00:25:23 --> Total execution time: 0.9986
INFO - 2017-02-28 00:25:34 --> Config Class Initialized
INFO - 2017-02-28 00:25:34 --> Hooks Class Initialized
DEBUG - 2017-02-28 00:25:35 --> UTF-8 Support Enabled
INFO - 2017-02-28 00:25:35 --> Utf8 Class Initialized
INFO - 2017-02-28 00:25:35 --> URI Class Initialized
DEBUG - 2017-02-28 00:25:35 --> No URI present. Default controller set.
INFO - 2017-02-28 00:25:35 --> Router Class Initialized
INFO - 2017-02-28 00:25:35 --> Output Class Initialized
INFO - 2017-02-28 00:25:35 --> Security Class Initialized
DEBUG - 2017-02-28 00:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 00:25:35 --> Input Class Initialized
INFO - 2017-02-28 00:25:35 --> Language Class Initialized
INFO - 2017-02-28 00:25:35 --> Loader Class Initialized
INFO - 2017-02-28 00:25:35 --> Database Driver Class Initialized
INFO - 2017-02-28 00:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 00:25:35 --> Controller Class Initialized
INFO - 2017-02-28 00:25:35 --> Helper loaded: url_helper
DEBUG - 2017-02-28 00:25:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 00:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 00:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 00:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 00:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 00:25:36 --> Final output sent to browser
DEBUG - 2017-02-28 00:25:36 --> Total execution time: 1.2223
INFO - 2017-02-28 01:07:36 --> Config Class Initialized
INFO - 2017-02-28 01:07:36 --> Hooks Class Initialized
DEBUG - 2017-02-28 01:07:36 --> UTF-8 Support Enabled
INFO - 2017-02-28 01:07:37 --> Utf8 Class Initialized
INFO - 2017-02-28 01:07:37 --> URI Class Initialized
DEBUG - 2017-02-28 01:07:37 --> No URI present. Default controller set.
INFO - 2017-02-28 01:07:37 --> Router Class Initialized
INFO - 2017-02-28 01:07:37 --> Output Class Initialized
INFO - 2017-02-28 01:07:37 --> Security Class Initialized
DEBUG - 2017-02-28 01:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 01:07:37 --> Input Class Initialized
INFO - 2017-02-28 01:07:37 --> Language Class Initialized
INFO - 2017-02-28 01:07:37 --> Loader Class Initialized
INFO - 2017-02-28 01:07:37 --> Database Driver Class Initialized
INFO - 2017-02-28 01:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 01:07:38 --> Controller Class Initialized
INFO - 2017-02-28 01:07:38 --> Helper loaded: url_helper
DEBUG - 2017-02-28 01:07:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 01:07:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 01:07:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 01:07:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 01:07:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 01:07:38 --> Final output sent to browser
DEBUG - 2017-02-28 01:07:38 --> Total execution time: 2.0092
INFO - 2017-02-28 01:07:57 --> Config Class Initialized
INFO - 2017-02-28 01:07:57 --> Hooks Class Initialized
DEBUG - 2017-02-28 01:07:57 --> UTF-8 Support Enabled
INFO - 2017-02-28 01:07:57 --> Utf8 Class Initialized
INFO - 2017-02-28 01:07:57 --> URI Class Initialized
INFO - 2017-02-28 01:07:57 --> Router Class Initialized
INFO - 2017-02-28 01:07:57 --> Output Class Initialized
INFO - 2017-02-28 01:07:57 --> Security Class Initialized
DEBUG - 2017-02-28 01:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 01:07:57 --> Input Class Initialized
INFO - 2017-02-28 01:07:57 --> Language Class Initialized
INFO - 2017-02-28 01:07:58 --> Loader Class Initialized
INFO - 2017-02-28 01:07:58 --> Database Driver Class Initialized
INFO - 2017-02-28 01:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 01:07:58 --> Controller Class Initialized
INFO - 2017-02-28 01:07:58 --> Helper loaded: url_helper
DEBUG - 2017-02-28 01:07:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 01:07:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 01:07:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 01:07:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 01:07:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 01:07:58 --> Final output sent to browser
DEBUG - 2017-02-28 01:07:58 --> Total execution time: 0.5172
INFO - 2017-02-28 01:08:49 --> Config Class Initialized
INFO - 2017-02-28 01:08:49 --> Hooks Class Initialized
DEBUG - 2017-02-28 01:08:49 --> UTF-8 Support Enabled
INFO - 2017-02-28 01:08:49 --> Utf8 Class Initialized
INFO - 2017-02-28 01:08:49 --> URI Class Initialized
INFO - 2017-02-28 01:08:49 --> Router Class Initialized
INFO - 2017-02-28 01:08:49 --> Output Class Initialized
INFO - 2017-02-28 01:08:49 --> Security Class Initialized
DEBUG - 2017-02-28 01:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 01:08:49 --> Input Class Initialized
INFO - 2017-02-28 01:08:49 --> Language Class Initialized
INFO - 2017-02-28 01:08:49 --> Loader Class Initialized
INFO - 2017-02-28 01:08:50 --> Database Driver Class Initialized
INFO - 2017-02-28 01:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 01:08:50 --> Controller Class Initialized
INFO - 2017-02-28 01:08:50 --> Helper loaded: url_helper
DEBUG - 2017-02-28 01:08:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 01:08:51 --> Config Class Initialized
INFO - 2017-02-28 01:08:51 --> Hooks Class Initialized
DEBUG - 2017-02-28 01:08:51 --> UTF-8 Support Enabled
INFO - 2017-02-28 01:08:51 --> Utf8 Class Initialized
INFO - 2017-02-28 01:08:51 --> URI Class Initialized
INFO - 2017-02-28 01:08:51 --> Router Class Initialized
INFO - 2017-02-28 01:08:51 --> Output Class Initialized
INFO - 2017-02-28 01:08:51 --> Security Class Initialized
DEBUG - 2017-02-28 01:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 01:08:51 --> Input Class Initialized
INFO - 2017-02-28 01:08:51 --> Language Class Initialized
INFO - 2017-02-28 01:08:51 --> Loader Class Initialized
INFO - 2017-02-28 01:08:51 --> Database Driver Class Initialized
INFO - 2017-02-28 01:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 01:08:52 --> Controller Class Initialized
INFO - 2017-02-28 01:08:52 --> Helper loaded: url_helper
DEBUG - 2017-02-28 01:08:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 01:08:52 --> Config Class Initialized
INFO - 2017-02-28 01:08:52 --> Hooks Class Initialized
DEBUG - 2017-02-28 01:08:52 --> UTF-8 Support Enabled
INFO - 2017-02-28 01:08:52 --> Utf8 Class Initialized
INFO - 2017-02-28 01:08:52 --> URI Class Initialized
INFO - 2017-02-28 01:08:52 --> Router Class Initialized
INFO - 2017-02-28 01:08:52 --> Output Class Initialized
INFO - 2017-02-28 01:08:52 --> Security Class Initialized
DEBUG - 2017-02-28 01:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 01:08:52 --> Input Class Initialized
INFO - 2017-02-28 01:08:52 --> Language Class Initialized
INFO - 2017-02-28 01:08:52 --> Loader Class Initialized
INFO - 2017-02-28 01:08:52 --> Database Driver Class Initialized
INFO - 2017-02-28 01:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 01:08:52 --> Controller Class Initialized
INFO - 2017-02-28 01:08:52 --> Helper loaded: date_helper
DEBUG - 2017-02-28 01:08:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 01:08:52 --> Helper loaded: url_helper
INFO - 2017-02-28 01:08:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 01:08:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 01:08:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-28 01:08:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-28 01:08:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 01:08:52 --> Final output sent to browser
DEBUG - 2017-02-28 01:08:52 --> Total execution time: 0.1798
INFO - 2017-02-28 01:08:55 --> Config Class Initialized
INFO - 2017-02-28 01:08:55 --> Hooks Class Initialized
DEBUG - 2017-02-28 01:08:55 --> UTF-8 Support Enabled
INFO - 2017-02-28 01:08:55 --> Utf8 Class Initialized
INFO - 2017-02-28 01:08:55 --> URI Class Initialized
INFO - 2017-02-28 01:08:55 --> Router Class Initialized
INFO - 2017-02-28 01:08:55 --> Output Class Initialized
INFO - 2017-02-28 01:08:55 --> Security Class Initialized
DEBUG - 2017-02-28 01:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 01:08:55 --> Input Class Initialized
INFO - 2017-02-28 01:08:55 --> Language Class Initialized
INFO - 2017-02-28 01:08:55 --> Loader Class Initialized
INFO - 2017-02-28 01:08:55 --> Database Driver Class Initialized
INFO - 2017-02-28 01:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 01:08:55 --> Controller Class Initialized
INFO - 2017-02-28 01:08:55 --> Helper loaded: url_helper
DEBUG - 2017-02-28 01:08:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 01:08:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 01:08:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 01:08:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 01:08:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 01:08:55 --> Final output sent to browser
DEBUG - 2017-02-28 01:08:55 --> Total execution time: 0.0402
INFO - 2017-02-28 01:08:58 --> Config Class Initialized
INFO - 2017-02-28 01:08:58 --> Hooks Class Initialized
DEBUG - 2017-02-28 01:08:58 --> UTF-8 Support Enabled
INFO - 2017-02-28 01:08:58 --> Utf8 Class Initialized
INFO - 2017-02-28 01:08:58 --> URI Class Initialized
INFO - 2017-02-28 01:08:58 --> Router Class Initialized
INFO - 2017-02-28 01:08:58 --> Output Class Initialized
INFO - 2017-02-28 01:08:58 --> Security Class Initialized
DEBUG - 2017-02-28 01:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 01:08:58 --> Input Class Initialized
INFO - 2017-02-28 01:08:58 --> Language Class Initialized
INFO - 2017-02-28 01:08:58 --> Loader Class Initialized
INFO - 2017-02-28 01:08:58 --> Database Driver Class Initialized
INFO - 2017-02-28 01:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 01:08:58 --> Controller Class Initialized
INFO - 2017-02-28 01:08:58 --> Helper loaded: date_helper
DEBUG - 2017-02-28 01:08:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 01:08:58 --> Helper loaded: url_helper
INFO - 2017-02-28 01:08:58 --> Helper loaded: download_helper
INFO - 2017-02-28 01:08:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 01:08:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 01:08:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-28 01:08:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-28 01:08:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 01:08:58 --> Final output sent to browser
DEBUG - 2017-02-28 01:08:58 --> Total execution time: 0.1382
INFO - 2017-02-28 01:08:59 --> Config Class Initialized
INFO - 2017-02-28 01:08:59 --> Hooks Class Initialized
DEBUG - 2017-02-28 01:08:59 --> UTF-8 Support Enabled
INFO - 2017-02-28 01:08:59 --> Utf8 Class Initialized
INFO - 2017-02-28 01:08:59 --> URI Class Initialized
INFO - 2017-02-28 01:08:59 --> Router Class Initialized
INFO - 2017-02-28 01:08:59 --> Output Class Initialized
INFO - 2017-02-28 01:08:59 --> Security Class Initialized
DEBUG - 2017-02-28 01:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 01:08:59 --> Input Class Initialized
INFO - 2017-02-28 01:08:59 --> Language Class Initialized
INFO - 2017-02-28 01:08:59 --> Loader Class Initialized
INFO - 2017-02-28 01:08:59 --> Database Driver Class Initialized
INFO - 2017-02-28 01:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 01:08:59 --> Controller Class Initialized
INFO - 2017-02-28 01:08:59 --> Helper loaded: url_helper
DEBUG - 2017-02-28 01:08:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 01:08:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 01:08:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 01:08:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 01:08:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 01:08:59 --> Final output sent to browser
DEBUG - 2017-02-28 01:08:59 --> Total execution time: 0.0139
INFO - 2017-02-28 02:02:39 --> Config Class Initialized
INFO - 2017-02-28 02:02:39 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:02:39 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:02:39 --> Utf8 Class Initialized
INFO - 2017-02-28 02:02:39 --> URI Class Initialized
INFO - 2017-02-28 02:02:40 --> Router Class Initialized
INFO - 2017-02-28 02:02:40 --> Output Class Initialized
INFO - 2017-02-28 02:02:40 --> Security Class Initialized
DEBUG - 2017-02-28 02:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:02:40 --> Input Class Initialized
INFO - 2017-02-28 02:02:40 --> Language Class Initialized
INFO - 2017-02-28 02:02:40 --> Loader Class Initialized
INFO - 2017-02-28 02:02:40 --> Database Driver Class Initialized
INFO - 2017-02-28 02:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:02:41 --> Controller Class Initialized
INFO - 2017-02-28 02:02:41 --> Helper loaded: url_helper
DEBUG - 2017-02-28 02:02:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:02:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 02:02:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 02:02:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 02:02:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 02:02:41 --> Final output sent to browser
DEBUG - 2017-02-28 02:02:41 --> Total execution time: 2.0156
INFO - 2017-02-28 02:15:45 --> Config Class Initialized
INFO - 2017-02-28 02:15:45 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:15:45 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:15:45 --> Utf8 Class Initialized
INFO - 2017-02-28 02:15:45 --> URI Class Initialized
INFO - 2017-02-28 02:15:45 --> Router Class Initialized
INFO - 2017-02-28 02:15:45 --> Output Class Initialized
INFO - 2017-02-28 02:15:45 --> Security Class Initialized
DEBUG - 2017-02-28 02:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:15:45 --> Input Class Initialized
INFO - 2017-02-28 02:15:45 --> Language Class Initialized
INFO - 2017-02-28 02:15:45 --> Loader Class Initialized
INFO - 2017-02-28 02:15:46 --> Database Driver Class Initialized
INFO - 2017-02-28 02:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:15:46 --> Controller Class Initialized
INFO - 2017-02-28 02:15:46 --> Helper loaded: url_helper
DEBUG - 2017-02-28 02:15:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:15:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 02:15:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 02:15:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 02:15:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 02:15:47 --> Final output sent to browser
DEBUG - 2017-02-28 02:15:47 --> Total execution time: 2.0091
INFO - 2017-02-28 02:15:48 --> Config Class Initialized
INFO - 2017-02-28 02:15:48 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:15:48 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:15:48 --> Utf8 Class Initialized
INFO - 2017-02-28 02:15:48 --> URI Class Initialized
DEBUG - 2017-02-28 02:15:48 --> No URI present. Default controller set.
INFO - 2017-02-28 02:15:48 --> Router Class Initialized
INFO - 2017-02-28 02:15:48 --> Output Class Initialized
INFO - 2017-02-28 02:15:48 --> Security Class Initialized
DEBUG - 2017-02-28 02:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:15:48 --> Input Class Initialized
INFO - 2017-02-28 02:15:48 --> Language Class Initialized
INFO - 2017-02-28 02:15:48 --> Loader Class Initialized
INFO - 2017-02-28 02:15:48 --> Database Driver Class Initialized
INFO - 2017-02-28 02:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:15:48 --> Controller Class Initialized
INFO - 2017-02-28 02:15:48 --> Helper loaded: url_helper
DEBUG - 2017-02-28 02:15:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:15:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 02:15:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 02:15:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 02:15:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 02:15:48 --> Final output sent to browser
DEBUG - 2017-02-28 02:15:48 --> Total execution time: 0.0464
INFO - 2017-02-28 02:15:50 --> Config Class Initialized
INFO - 2017-02-28 02:15:50 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:15:50 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:15:50 --> Utf8 Class Initialized
INFO - 2017-02-28 02:15:50 --> URI Class Initialized
INFO - 2017-02-28 02:15:50 --> Router Class Initialized
INFO - 2017-02-28 02:15:50 --> Output Class Initialized
INFO - 2017-02-28 02:15:50 --> Security Class Initialized
DEBUG - 2017-02-28 02:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:15:50 --> Input Class Initialized
INFO - 2017-02-28 02:15:50 --> Language Class Initialized
INFO - 2017-02-28 02:15:50 --> Loader Class Initialized
INFO - 2017-02-28 02:15:50 --> Database Driver Class Initialized
INFO - 2017-02-28 02:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:15:50 --> Controller Class Initialized
INFO - 2017-02-28 02:15:50 --> Helper loaded: url_helper
DEBUG - 2017-02-28 02:15:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 02:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 02:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 02:15:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 02:15:50 --> Final output sent to browser
DEBUG - 2017-02-28 02:15:50 --> Total execution time: 0.0139
INFO - 2017-02-28 02:27:49 --> Config Class Initialized
INFO - 2017-02-28 02:27:49 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:27:49 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:27:49 --> Utf8 Class Initialized
INFO - 2017-02-28 02:27:49 --> URI Class Initialized
DEBUG - 2017-02-28 02:27:49 --> No URI present. Default controller set.
INFO - 2017-02-28 02:27:49 --> Router Class Initialized
INFO - 2017-02-28 02:27:49 --> Output Class Initialized
INFO - 2017-02-28 02:27:49 --> Security Class Initialized
DEBUG - 2017-02-28 02:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:27:49 --> Input Class Initialized
INFO - 2017-02-28 02:27:49 --> Language Class Initialized
INFO - 2017-02-28 02:27:49 --> Loader Class Initialized
INFO - 2017-02-28 02:27:50 --> Database Driver Class Initialized
INFO - 2017-02-28 02:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:27:50 --> Controller Class Initialized
INFO - 2017-02-28 02:27:50 --> Helper loaded: url_helper
DEBUG - 2017-02-28 02:27:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:27:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 02:27:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 02:27:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 02:27:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 02:27:51 --> Final output sent to browser
DEBUG - 2017-02-28 02:27:51 --> Total execution time: 2.0536
INFO - 2017-02-28 02:29:51 --> Config Class Initialized
INFO - 2017-02-28 02:29:51 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:29:51 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:29:51 --> Utf8 Class Initialized
INFO - 2017-02-28 02:29:51 --> URI Class Initialized
DEBUG - 2017-02-28 02:29:51 --> No URI present. Default controller set.
INFO - 2017-02-28 02:29:51 --> Router Class Initialized
INFO - 2017-02-28 02:29:51 --> Output Class Initialized
INFO - 2017-02-28 02:29:51 --> Security Class Initialized
DEBUG - 2017-02-28 02:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:29:51 --> Input Class Initialized
INFO - 2017-02-28 02:29:51 --> Language Class Initialized
INFO - 2017-02-28 02:29:51 --> Loader Class Initialized
INFO - 2017-02-28 02:29:52 --> Database Driver Class Initialized
INFO - 2017-02-28 02:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:29:52 --> Controller Class Initialized
INFO - 2017-02-28 02:29:52 --> Helper loaded: url_helper
DEBUG - 2017-02-28 02:29:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 02:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 02:29:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 02:29:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 02:29:53 --> Final output sent to browser
DEBUG - 2017-02-28 02:29:53 --> Total execution time: 1.7891
INFO - 2017-02-28 02:42:57 --> Config Class Initialized
INFO - 2017-02-28 02:42:57 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:42:57 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:42:57 --> Utf8 Class Initialized
INFO - 2017-02-28 02:42:57 --> URI Class Initialized
INFO - 2017-02-28 02:42:57 --> Router Class Initialized
INFO - 2017-02-28 02:42:57 --> Output Class Initialized
INFO - 2017-02-28 02:42:57 --> Security Class Initialized
DEBUG - 2017-02-28 02:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:42:57 --> Input Class Initialized
INFO - 2017-02-28 02:42:57 --> Language Class Initialized
INFO - 2017-02-28 02:42:57 --> Loader Class Initialized
INFO - 2017-02-28 02:42:58 --> Database Driver Class Initialized
INFO - 2017-02-28 02:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:42:58 --> Controller Class Initialized
INFO - 2017-02-28 02:42:58 --> Helper loaded: url_helper
DEBUG - 2017-02-28 02:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:43:00 --> Config Class Initialized
INFO - 2017-02-28 02:43:00 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:43:00 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:43:00 --> Utf8 Class Initialized
INFO - 2017-02-28 02:43:00 --> URI Class Initialized
INFO - 2017-02-28 02:43:00 --> Router Class Initialized
INFO - 2017-02-28 02:43:00 --> Output Class Initialized
INFO - 2017-02-28 02:43:00 --> Security Class Initialized
DEBUG - 2017-02-28 02:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:43:00 --> Input Class Initialized
INFO - 2017-02-28 02:43:00 --> Language Class Initialized
INFO - 2017-02-28 02:43:00 --> Loader Class Initialized
INFO - 2017-02-28 02:43:00 --> Database Driver Class Initialized
INFO - 2017-02-28 02:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:43:00 --> Controller Class Initialized
INFO - 2017-02-28 02:43:00 --> Helper loaded: date_helper
DEBUG - 2017-02-28 02:43:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:43:00 --> Helper loaded: url_helper
INFO - 2017-02-28 02:43:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 02:43:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-28 02:43:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-28 02:43:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-28 02:43:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 02:43:00 --> Final output sent to browser
DEBUG - 2017-02-28 02:43:00 --> Total execution time: 0.4362
INFO - 2017-02-28 02:43:01 --> Config Class Initialized
INFO - 2017-02-28 02:43:01 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:43:01 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:43:01 --> Utf8 Class Initialized
INFO - 2017-02-28 02:43:01 --> URI Class Initialized
INFO - 2017-02-28 02:43:01 --> Router Class Initialized
INFO - 2017-02-28 02:43:01 --> Output Class Initialized
INFO - 2017-02-28 02:43:01 --> Security Class Initialized
DEBUG - 2017-02-28 02:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:43:01 --> Input Class Initialized
INFO - 2017-02-28 02:43:01 --> Language Class Initialized
INFO - 2017-02-28 02:43:01 --> Loader Class Initialized
INFO - 2017-02-28 02:43:01 --> Database Driver Class Initialized
INFO - 2017-02-28 02:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:43:01 --> Controller Class Initialized
INFO - 2017-02-28 02:43:01 --> Helper loaded: url_helper
DEBUG - 2017-02-28 02:43:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:43:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 02:43:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 02:43:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 02:43:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 02:43:01 --> Final output sent to browser
DEBUG - 2017-02-28 02:43:01 --> Total execution time: 0.0359
INFO - 2017-02-28 02:45:09 --> Config Class Initialized
INFO - 2017-02-28 02:45:09 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:45:09 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:45:09 --> Utf8 Class Initialized
INFO - 2017-02-28 02:45:09 --> URI Class Initialized
DEBUG - 2017-02-28 02:45:10 --> No URI present. Default controller set.
INFO - 2017-02-28 02:45:10 --> Router Class Initialized
INFO - 2017-02-28 02:45:10 --> Output Class Initialized
INFO - 2017-02-28 02:45:10 --> Security Class Initialized
DEBUG - 2017-02-28 02:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:45:10 --> Input Class Initialized
INFO - 2017-02-28 02:45:10 --> Language Class Initialized
INFO - 2017-02-28 02:45:10 --> Loader Class Initialized
INFO - 2017-02-28 02:45:10 --> Database Driver Class Initialized
INFO - 2017-02-28 02:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:45:11 --> Controller Class Initialized
INFO - 2017-02-28 02:45:11 --> Helper loaded: url_helper
DEBUG - 2017-02-28 02:45:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:45:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 02:45:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 02:45:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 02:45:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 02:45:11 --> Final output sent to browser
DEBUG - 2017-02-28 02:45:11 --> Total execution time: 1.7922
INFO - 2017-02-28 02:45:15 --> Config Class Initialized
INFO - 2017-02-28 02:45:15 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:45:15 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:45:15 --> Utf8 Class Initialized
INFO - 2017-02-28 02:45:15 --> URI Class Initialized
INFO - 2017-02-28 02:45:15 --> Router Class Initialized
INFO - 2017-02-28 02:45:15 --> Output Class Initialized
INFO - 2017-02-28 02:45:15 --> Security Class Initialized
DEBUG - 2017-02-28 02:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:45:15 --> Input Class Initialized
INFO - 2017-02-28 02:45:15 --> Language Class Initialized
INFO - 2017-02-28 02:45:15 --> Loader Class Initialized
INFO - 2017-02-28 02:45:15 --> Database Driver Class Initialized
INFO - 2017-02-28 02:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:45:15 --> Controller Class Initialized
INFO - 2017-02-28 02:45:15 --> Helper loaded: url_helper
DEBUG - 2017-02-28 02:45:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:45:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 02:45:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 02:45:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 02:45:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 02:45:15 --> Final output sent to browser
DEBUG - 2017-02-28 02:45:15 --> Total execution time: 0.0634
INFO - 2017-02-28 02:45:34 --> Config Class Initialized
INFO - 2017-02-28 02:45:34 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:45:34 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:45:34 --> Utf8 Class Initialized
INFO - 2017-02-28 02:45:34 --> URI Class Initialized
INFO - 2017-02-28 02:45:34 --> Router Class Initialized
INFO - 2017-02-28 02:45:34 --> Output Class Initialized
INFO - 2017-02-28 02:45:34 --> Security Class Initialized
DEBUG - 2017-02-28 02:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:45:34 --> Input Class Initialized
INFO - 2017-02-28 02:45:34 --> Language Class Initialized
INFO - 2017-02-28 02:45:34 --> Loader Class Initialized
INFO - 2017-02-28 02:45:34 --> Database Driver Class Initialized
INFO - 2017-02-28 02:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:45:34 --> Controller Class Initialized
INFO - 2017-02-28 02:45:34 --> Helper loaded: url_helper
DEBUG - 2017-02-28 02:45:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:45:34 --> Config Class Initialized
INFO - 2017-02-28 02:45:34 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:45:34 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:45:34 --> Utf8 Class Initialized
INFO - 2017-02-28 02:45:34 --> URI Class Initialized
INFO - 2017-02-28 02:45:34 --> Router Class Initialized
INFO - 2017-02-28 02:45:34 --> Output Class Initialized
INFO - 2017-02-28 02:45:34 --> Security Class Initialized
DEBUG - 2017-02-28 02:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:45:34 --> Input Class Initialized
INFO - 2017-02-28 02:45:34 --> Language Class Initialized
INFO - 2017-02-28 02:45:34 --> Loader Class Initialized
INFO - 2017-02-28 02:45:34 --> Database Driver Class Initialized
INFO - 2017-02-28 02:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:45:34 --> Controller Class Initialized
INFO - 2017-02-28 02:45:34 --> Helper loaded: date_helper
DEBUG - 2017-02-28 02:45:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:45:34 --> Helper loaded: url_helper
INFO - 2017-02-28 02:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 02:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 02:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-28 02:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-28 02:45:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 02:45:34 --> Final output sent to browser
DEBUG - 2017-02-28 02:45:34 --> Total execution time: 0.1147
INFO - 2017-02-28 02:45:36 --> Config Class Initialized
INFO - 2017-02-28 02:45:36 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:45:36 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:45:36 --> Utf8 Class Initialized
INFO - 2017-02-28 02:45:36 --> URI Class Initialized
INFO - 2017-02-28 02:45:36 --> Router Class Initialized
INFO - 2017-02-28 02:45:36 --> Output Class Initialized
INFO - 2017-02-28 02:45:36 --> Security Class Initialized
DEBUG - 2017-02-28 02:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:45:36 --> Input Class Initialized
INFO - 2017-02-28 02:45:36 --> Language Class Initialized
INFO - 2017-02-28 02:45:36 --> Loader Class Initialized
INFO - 2017-02-28 02:45:36 --> Database Driver Class Initialized
INFO - 2017-02-28 02:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:45:36 --> Controller Class Initialized
INFO - 2017-02-28 02:45:36 --> Helper loaded: url_helper
DEBUG - 2017-02-28 02:45:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:45:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 02:45:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 02:45:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 02:45:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 02:45:36 --> Final output sent to browser
DEBUG - 2017-02-28 02:45:36 --> Total execution time: 0.0141
INFO - 2017-02-28 02:45:37 --> Config Class Initialized
INFO - 2017-02-28 02:45:37 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:45:37 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:45:37 --> Utf8 Class Initialized
INFO - 2017-02-28 02:45:37 --> URI Class Initialized
INFO - 2017-02-28 02:45:37 --> Router Class Initialized
INFO - 2017-02-28 02:45:37 --> Output Class Initialized
INFO - 2017-02-28 02:45:37 --> Security Class Initialized
DEBUG - 2017-02-28 02:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:45:37 --> Input Class Initialized
INFO - 2017-02-28 02:45:37 --> Language Class Initialized
INFO - 2017-02-28 02:45:37 --> Loader Class Initialized
INFO - 2017-02-28 02:45:37 --> Database Driver Class Initialized
INFO - 2017-02-28 02:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:45:37 --> Controller Class Initialized
INFO - 2017-02-28 02:45:37 --> Helper loaded: date_helper
DEBUG - 2017-02-28 02:45:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:45:37 --> Helper loaded: url_helper
INFO - 2017-02-28 02:45:37 --> Helper loaded: download_helper
INFO - 2017-02-28 02:45:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 02:45:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 02:45:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-28 02:45:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-28 02:45:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 02:45:37 --> Final output sent to browser
DEBUG - 2017-02-28 02:45:37 --> Total execution time: 0.6059
INFO - 2017-02-28 02:45:39 --> Config Class Initialized
INFO - 2017-02-28 02:45:39 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:45:39 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:45:39 --> Utf8 Class Initialized
INFO - 2017-02-28 02:45:39 --> URI Class Initialized
INFO - 2017-02-28 02:45:39 --> Router Class Initialized
INFO - 2017-02-28 02:45:39 --> Output Class Initialized
INFO - 2017-02-28 02:45:39 --> Security Class Initialized
DEBUG - 2017-02-28 02:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:45:39 --> Input Class Initialized
INFO - 2017-02-28 02:45:39 --> Language Class Initialized
INFO - 2017-02-28 02:45:39 --> Loader Class Initialized
INFO - 2017-02-28 02:45:39 --> Database Driver Class Initialized
INFO - 2017-02-28 02:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:45:39 --> Controller Class Initialized
INFO - 2017-02-28 02:45:39 --> Helper loaded: url_helper
DEBUG - 2017-02-28 02:45:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:45:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 02:45:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 02:45:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 02:45:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 02:45:39 --> Final output sent to browser
DEBUG - 2017-02-28 02:45:39 --> Total execution time: 0.0139
INFO - 2017-02-28 02:45:44 --> Config Class Initialized
INFO - 2017-02-28 02:45:44 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:45:44 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:45:44 --> Utf8 Class Initialized
INFO - 2017-02-28 02:45:44 --> URI Class Initialized
INFO - 2017-02-28 02:45:44 --> Router Class Initialized
INFO - 2017-02-28 02:45:44 --> Output Class Initialized
INFO - 2017-02-28 02:45:44 --> Security Class Initialized
DEBUG - 2017-02-28 02:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:45:44 --> Input Class Initialized
INFO - 2017-02-28 02:45:44 --> Language Class Initialized
INFO - 2017-02-28 02:45:44 --> Loader Class Initialized
INFO - 2017-02-28 02:45:44 --> Database Driver Class Initialized
INFO - 2017-02-28 02:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:45:44 --> Controller Class Initialized
INFO - 2017-02-28 02:45:44 --> Helper loaded: date_helper
DEBUG - 2017-02-28 02:45:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:45:44 --> Helper loaded: url_helper
INFO - 2017-02-28 02:45:44 --> Helper loaded: download_helper
INFO - 2017-02-28 02:45:44 --> Final output sent to browser
DEBUG - 2017-02-28 02:45:44 --> Total execution time: 0.0142
INFO - 2017-02-28 02:45:45 --> Config Class Initialized
INFO - 2017-02-28 02:45:45 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:45:45 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:45:45 --> Utf8 Class Initialized
INFO - 2017-02-28 02:45:45 --> URI Class Initialized
INFO - 2017-02-28 02:45:45 --> Router Class Initialized
INFO - 2017-02-28 02:45:45 --> Output Class Initialized
INFO - 2017-02-28 02:45:45 --> Security Class Initialized
DEBUG - 2017-02-28 02:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:45:45 --> Input Class Initialized
INFO - 2017-02-28 02:45:45 --> Language Class Initialized
INFO - 2017-02-28 02:45:45 --> Loader Class Initialized
INFO - 2017-02-28 02:45:45 --> Database Driver Class Initialized
INFO - 2017-02-28 02:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:45:45 --> Controller Class Initialized
INFO - 2017-02-28 02:45:45 --> Helper loaded: date_helper
DEBUG - 2017-02-28 02:45:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:45:45 --> Helper loaded: url_helper
INFO - 2017-02-28 02:45:45 --> Helper loaded: download_helper
INFO - 2017-02-28 02:45:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 02:45:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 02:45:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-28 02:45:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-28 02:45:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 02:45:45 --> Final output sent to browser
DEBUG - 2017-02-28 02:45:45 --> Total execution time: 0.0187
INFO - 2017-02-28 02:45:46 --> Config Class Initialized
INFO - 2017-02-28 02:45:46 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:45:46 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:45:46 --> Utf8 Class Initialized
INFO - 2017-02-28 02:45:46 --> URI Class Initialized
INFO - 2017-02-28 02:45:46 --> Router Class Initialized
INFO - 2017-02-28 02:45:46 --> Output Class Initialized
INFO - 2017-02-28 02:45:46 --> Security Class Initialized
DEBUG - 2017-02-28 02:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:45:46 --> Input Class Initialized
INFO - 2017-02-28 02:45:46 --> Language Class Initialized
INFO - 2017-02-28 02:45:46 --> Loader Class Initialized
INFO - 2017-02-28 02:45:46 --> Database Driver Class Initialized
INFO - 2017-02-28 02:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:45:46 --> Controller Class Initialized
INFO - 2017-02-28 02:45:46 --> Helper loaded: url_helper
DEBUG - 2017-02-28 02:45:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 02:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 02:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 02:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 02:45:46 --> Final output sent to browser
DEBUG - 2017-02-28 02:45:46 --> Total execution time: 0.0133
INFO - 2017-02-28 02:45:58 --> Config Class Initialized
INFO - 2017-02-28 02:45:58 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:45:58 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:45:58 --> Utf8 Class Initialized
INFO - 2017-02-28 02:45:58 --> URI Class Initialized
INFO - 2017-02-28 02:45:58 --> Router Class Initialized
INFO - 2017-02-28 02:45:58 --> Output Class Initialized
INFO - 2017-02-28 02:45:58 --> Security Class Initialized
DEBUG - 2017-02-28 02:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:45:58 --> Input Class Initialized
INFO - 2017-02-28 02:45:58 --> Language Class Initialized
INFO - 2017-02-28 02:45:58 --> Loader Class Initialized
INFO - 2017-02-28 02:45:58 --> Database Driver Class Initialized
INFO - 2017-02-28 02:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:45:58 --> Controller Class Initialized
INFO - 2017-02-28 02:45:58 --> Helper loaded: url_helper
DEBUG - 2017-02-28 02:45:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:45:58 --> Config Class Initialized
INFO - 2017-02-28 02:45:58 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:45:58 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:45:58 --> Utf8 Class Initialized
INFO - 2017-02-28 02:45:58 --> URI Class Initialized
DEBUG - 2017-02-28 02:45:58 --> No URI present. Default controller set.
INFO - 2017-02-28 02:45:58 --> Router Class Initialized
INFO - 2017-02-28 02:45:58 --> Output Class Initialized
INFO - 2017-02-28 02:45:58 --> Security Class Initialized
DEBUG - 2017-02-28 02:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:45:58 --> Input Class Initialized
INFO - 2017-02-28 02:45:58 --> Language Class Initialized
INFO - 2017-02-28 02:45:58 --> Loader Class Initialized
INFO - 2017-02-28 02:45:58 --> Database Driver Class Initialized
INFO - 2017-02-28 02:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:45:58 --> Controller Class Initialized
INFO - 2017-02-28 02:45:58 --> Helper loaded: url_helper
DEBUG - 2017-02-28 02:45:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 02:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 02:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 02:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 02:45:58 --> Final output sent to browser
DEBUG - 2017-02-28 02:45:58 --> Total execution time: 0.0212
INFO - 2017-02-28 02:45:59 --> Config Class Initialized
INFO - 2017-02-28 02:45:59 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:45:59 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:45:59 --> Utf8 Class Initialized
INFO - 2017-02-28 02:45:59 --> URI Class Initialized
INFO - 2017-02-28 02:45:59 --> Router Class Initialized
INFO - 2017-02-28 02:45:59 --> Output Class Initialized
INFO - 2017-02-28 02:45:59 --> Security Class Initialized
DEBUG - 2017-02-28 02:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:45:59 --> Input Class Initialized
INFO - 2017-02-28 02:45:59 --> Language Class Initialized
INFO - 2017-02-28 02:45:59 --> Loader Class Initialized
INFO - 2017-02-28 02:45:59 --> Database Driver Class Initialized
INFO - 2017-02-28 02:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:45:59 --> Controller Class Initialized
INFO - 2017-02-28 02:45:59 --> Helper loaded: url_helper
DEBUG - 2017-02-28 02:45:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 02:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 02:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 02:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 02:45:59 --> Final output sent to browser
DEBUG - 2017-02-28 02:45:59 --> Total execution time: 0.0860
INFO - 2017-02-28 02:45:59 --> Config Class Initialized
INFO - 2017-02-28 02:45:59 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:45:59 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:45:59 --> Utf8 Class Initialized
INFO - 2017-02-28 02:45:59 --> URI Class Initialized
INFO - 2017-02-28 02:45:59 --> Router Class Initialized
INFO - 2017-02-28 02:45:59 --> Output Class Initialized
INFO - 2017-02-28 02:45:59 --> Security Class Initialized
DEBUG - 2017-02-28 02:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:45:59 --> Input Class Initialized
INFO - 2017-02-28 02:45:59 --> Language Class Initialized
INFO - 2017-02-28 02:45:59 --> Loader Class Initialized
INFO - 2017-02-28 02:45:59 --> Database Driver Class Initialized
INFO - 2017-02-28 02:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:45:59 --> Controller Class Initialized
INFO - 2017-02-28 02:45:59 --> Helper loaded: url_helper
DEBUG - 2017-02-28 02:45:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 02:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 02:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 02:45:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 02:45:59 --> Final output sent to browser
DEBUG - 2017-02-28 02:45:59 --> Total execution time: 0.0136
INFO - 2017-02-28 02:57:46 --> Config Class Initialized
INFO - 2017-02-28 02:57:46 --> Hooks Class Initialized
DEBUG - 2017-02-28 02:57:46 --> UTF-8 Support Enabled
INFO - 2017-02-28 02:57:46 --> Utf8 Class Initialized
INFO - 2017-02-28 02:57:46 --> URI Class Initialized
INFO - 2017-02-28 02:57:46 --> Router Class Initialized
INFO - 2017-02-28 02:57:46 --> Output Class Initialized
INFO - 2017-02-28 02:57:46 --> Security Class Initialized
DEBUG - 2017-02-28 02:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 02:57:46 --> Input Class Initialized
INFO - 2017-02-28 02:57:46 --> Language Class Initialized
INFO - 2017-02-28 02:57:47 --> Loader Class Initialized
INFO - 2017-02-28 02:57:47 --> Database Driver Class Initialized
INFO - 2017-02-28 02:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 02:57:48 --> Controller Class Initialized
INFO - 2017-02-28 02:57:48 --> Helper loaded: date_helper
DEBUG - 2017-02-28 02:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 02:57:48 --> Helper loaded: url_helper
INFO - 2017-02-28 02:57:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 02:57:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-28 02:57:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-28 02:57:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-28 02:57:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 02:57:48 --> Final output sent to browser
DEBUG - 2017-02-28 02:57:48 --> Total execution time: 1.9877
INFO - 2017-02-28 03:02:53 --> Config Class Initialized
INFO - 2017-02-28 03:02:53 --> Hooks Class Initialized
DEBUG - 2017-02-28 03:02:53 --> UTF-8 Support Enabled
INFO - 2017-02-28 03:02:53 --> Utf8 Class Initialized
INFO - 2017-02-28 03:02:53 --> URI Class Initialized
DEBUG - 2017-02-28 03:02:53 --> No URI present. Default controller set.
INFO - 2017-02-28 03:02:53 --> Router Class Initialized
INFO - 2017-02-28 03:02:53 --> Output Class Initialized
INFO - 2017-02-28 03:02:53 --> Security Class Initialized
DEBUG - 2017-02-28 03:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 03:02:53 --> Input Class Initialized
INFO - 2017-02-28 03:02:53 --> Language Class Initialized
INFO - 2017-02-28 03:02:53 --> Loader Class Initialized
INFO - 2017-02-28 03:02:54 --> Database Driver Class Initialized
INFO - 2017-02-28 03:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 03:02:54 --> Controller Class Initialized
INFO - 2017-02-28 03:02:54 --> Helper loaded: url_helper
DEBUG - 2017-02-28 03:02:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 03:02:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 03:02:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 03:02:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 03:02:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 03:02:55 --> Final output sent to browser
DEBUG - 2017-02-28 03:02:55 --> Total execution time: 1.7503
INFO - 2017-02-28 03:03:34 --> Config Class Initialized
INFO - 2017-02-28 03:03:34 --> Hooks Class Initialized
DEBUG - 2017-02-28 03:03:35 --> UTF-8 Support Enabled
INFO - 2017-02-28 03:03:35 --> Utf8 Class Initialized
INFO - 2017-02-28 03:03:35 --> URI Class Initialized
DEBUG - 2017-02-28 03:03:35 --> No URI present. Default controller set.
INFO - 2017-02-28 03:03:35 --> Router Class Initialized
INFO - 2017-02-28 03:03:35 --> Output Class Initialized
INFO - 2017-02-28 03:03:35 --> Security Class Initialized
DEBUG - 2017-02-28 03:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 03:03:35 --> Input Class Initialized
INFO - 2017-02-28 03:03:35 --> Language Class Initialized
INFO - 2017-02-28 03:03:35 --> Loader Class Initialized
INFO - 2017-02-28 03:03:35 --> Database Driver Class Initialized
INFO - 2017-02-28 03:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 03:03:36 --> Controller Class Initialized
INFO - 2017-02-28 03:03:36 --> Helper loaded: url_helper
DEBUG - 2017-02-28 03:03:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 03:03:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 03:03:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 03:03:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 03:03:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 03:03:36 --> Final output sent to browser
DEBUG - 2017-02-28 03:03:36 --> Total execution time: 1.7260
INFO - 2017-02-28 03:10:41 --> Config Class Initialized
INFO - 2017-02-28 03:10:41 --> Hooks Class Initialized
DEBUG - 2017-02-28 03:10:41 --> UTF-8 Support Enabled
INFO - 2017-02-28 03:10:41 --> Utf8 Class Initialized
INFO - 2017-02-28 03:10:41 --> URI Class Initialized
DEBUG - 2017-02-28 03:10:41 --> No URI present. Default controller set.
INFO - 2017-02-28 03:10:42 --> Router Class Initialized
INFO - 2017-02-28 03:10:42 --> Output Class Initialized
INFO - 2017-02-28 03:10:42 --> Security Class Initialized
DEBUG - 2017-02-28 03:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 03:10:42 --> Input Class Initialized
INFO - 2017-02-28 03:10:42 --> Language Class Initialized
INFO - 2017-02-28 03:10:42 --> Loader Class Initialized
INFO - 2017-02-28 03:10:42 --> Database Driver Class Initialized
INFO - 2017-02-28 03:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 03:10:43 --> Controller Class Initialized
INFO - 2017-02-28 03:10:43 --> Helper loaded: url_helper
DEBUG - 2017-02-28 03:10:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 03:10:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 03:10:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 03:10:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 03:10:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 03:10:44 --> Final output sent to browser
DEBUG - 2017-02-28 03:10:44 --> Total execution time: 3.7385
INFO - 2017-02-28 03:10:47 --> Config Class Initialized
INFO - 2017-02-28 03:10:47 --> Hooks Class Initialized
DEBUG - 2017-02-28 03:10:47 --> UTF-8 Support Enabled
INFO - 2017-02-28 03:10:47 --> Utf8 Class Initialized
INFO - 2017-02-28 03:10:47 --> URI Class Initialized
DEBUG - 2017-02-28 03:10:47 --> No URI present. Default controller set.
INFO - 2017-02-28 03:10:47 --> Router Class Initialized
INFO - 2017-02-28 03:10:47 --> Output Class Initialized
INFO - 2017-02-28 03:10:47 --> Security Class Initialized
DEBUG - 2017-02-28 03:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 03:10:47 --> Input Class Initialized
INFO - 2017-02-28 03:10:47 --> Language Class Initialized
INFO - 2017-02-28 03:10:47 --> Loader Class Initialized
INFO - 2017-02-28 03:10:47 --> Database Driver Class Initialized
INFO - 2017-02-28 03:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 03:10:48 --> Controller Class Initialized
INFO - 2017-02-28 03:10:48 --> Helper loaded: url_helper
DEBUG - 2017-02-28 03:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 03:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 03:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 03:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 03:10:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 03:10:48 --> Final output sent to browser
DEBUG - 2017-02-28 03:10:48 --> Total execution time: 1.6427
INFO - 2017-02-28 03:11:05 --> Config Class Initialized
INFO - 2017-02-28 03:11:05 --> Hooks Class Initialized
DEBUG - 2017-02-28 03:11:05 --> UTF-8 Support Enabled
INFO - 2017-02-28 03:11:05 --> Utf8 Class Initialized
INFO - 2017-02-28 03:11:05 --> URI Class Initialized
INFO - 2017-02-28 03:11:05 --> Router Class Initialized
INFO - 2017-02-28 03:11:05 --> Output Class Initialized
INFO - 2017-02-28 03:11:06 --> Security Class Initialized
DEBUG - 2017-02-28 03:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 03:11:06 --> Input Class Initialized
INFO - 2017-02-28 03:11:06 --> Language Class Initialized
INFO - 2017-02-28 03:11:06 --> Loader Class Initialized
INFO - 2017-02-28 03:11:06 --> Database Driver Class Initialized
INFO - 2017-02-28 03:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 03:11:07 --> Controller Class Initialized
INFO - 2017-02-28 03:11:07 --> Helper loaded: url_helper
DEBUG - 2017-02-28 03:11:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 03:11:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 03:11:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 03:11:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 03:11:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 03:11:07 --> Final output sent to browser
DEBUG - 2017-02-28 03:11:07 --> Total execution time: 5.9999
INFO - 2017-02-28 03:11:10 --> Config Class Initialized
INFO - 2017-02-28 03:11:11 --> Hooks Class Initialized
INFO - 2017-02-28 03:11:11 --> Config Class Initialized
INFO - 2017-02-28 03:11:11 --> Hooks Class Initialized
INFO - 2017-02-28 03:11:11 --> Config Class Initialized
INFO - 2017-02-28 03:11:11 --> Hooks Class Initialized
DEBUG - 2017-02-28 03:11:11 --> UTF-8 Support Enabled
DEBUG - 2017-02-28 03:11:11 --> UTF-8 Support Enabled
DEBUG - 2017-02-28 03:11:11 --> UTF-8 Support Enabled
INFO - 2017-02-28 03:11:11 --> Utf8 Class Initialized
INFO - 2017-02-28 03:11:11 --> Utf8 Class Initialized
INFO - 2017-02-28 03:11:11 --> Utf8 Class Initialized
INFO - 2017-02-28 03:11:11 --> URI Class Initialized
INFO - 2017-02-28 03:11:11 --> URI Class Initialized
INFO - 2017-02-28 03:11:11 --> URI Class Initialized
INFO - 2017-02-28 03:11:11 --> Router Class Initialized
INFO - 2017-02-28 03:11:11 --> Router Class Initialized
INFO - 2017-02-28 03:11:11 --> Router Class Initialized
INFO - 2017-02-28 03:11:11 --> Output Class Initialized
INFO - 2017-02-28 03:11:11 --> Output Class Initialized
INFO - 2017-02-28 03:11:11 --> Output Class Initialized
INFO - 2017-02-28 03:11:11 --> Security Class Initialized
INFO - 2017-02-28 03:11:11 --> Security Class Initialized
INFO - 2017-02-28 03:11:11 --> Security Class Initialized
DEBUG - 2017-02-28 03:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-28 03:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 03:11:11 --> Input Class Initialized
INFO - 2017-02-28 03:11:11 --> Input Class Initialized
INFO - 2017-02-28 03:11:11 --> Language Class Initialized
DEBUG - 2017-02-28 03:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 03:11:11 --> Input Class Initialized
INFO - 2017-02-28 03:11:11 --> Language Class Initialized
INFO - 2017-02-28 03:11:11 --> Language Class Initialized
INFO - 2017-02-28 03:11:11 --> Loader Class Initialized
INFO - 2017-02-28 03:11:11 --> Loader Class Initialized
INFO - 2017-02-28 03:11:11 --> Loader Class Initialized
INFO - 2017-02-28 03:11:11 --> Database Driver Class Initialized
INFO - 2017-02-28 03:11:11 --> Database Driver Class Initialized
INFO - 2017-02-28 03:11:11 --> Database Driver Class Initialized
INFO - 2017-02-28 03:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 03:11:12 --> Controller Class Initialized
INFO - 2017-02-28 03:11:12 --> Helper loaded: url_helper
DEBUG - 2017-02-28 03:11:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 03:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 03:11:12 --> Controller Class Initialized
INFO - 2017-02-28 03:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 03:11:13 --> Controller Class Initialized
INFO - 2017-02-28 03:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 03:11:13 --> Helper loaded: url_helper
INFO - 2017-02-28 03:11:13 --> Helper loaded: url_helper
INFO - 2017-02-28 03:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
DEBUG - 2017-02-28 03:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 03:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
DEBUG - 2017-02-28 03:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 03:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 03:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 03:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 03:11:13 --> Final output sent to browser
ERROR - 2017-02-28 03:11:13 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-28 03:11:13 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
DEBUG - 2017-02-28 03:11:13 --> Total execution time: 2.5997
ERROR - 2017-02-28 03:11:13 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-28 03:11:13 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
ERROR - 2017-02-28 03:11:13 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
INFO - 2017-02-28 03:11:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
ERROR - 2017-02-28 03:11:14 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-28 03:11:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 03:11:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 03:11:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 03:11:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 03:11:14 --> Final output sent to browser
DEBUG - 2017-02-28 03:11:14 --> Total execution time: 3.4291
INFO - 2017-02-28 03:11:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 03:11:14 --> Final output sent to browser
DEBUG - 2017-02-28 03:11:14 --> Total execution time: 3.4838
INFO - 2017-02-28 03:11:18 --> Config Class Initialized
INFO - 2017-02-28 03:11:18 --> Hooks Class Initialized
DEBUG - 2017-02-28 03:11:19 --> UTF-8 Support Enabled
INFO - 2017-02-28 03:11:19 --> Utf8 Class Initialized
INFO - 2017-02-28 03:11:19 --> URI Class Initialized
INFO - 2017-02-28 03:11:19 --> Router Class Initialized
INFO - 2017-02-28 03:11:19 --> Output Class Initialized
INFO - 2017-02-28 03:11:19 --> Security Class Initialized
DEBUG - 2017-02-28 03:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 03:11:19 --> Input Class Initialized
INFO - 2017-02-28 03:11:19 --> Language Class Initialized
INFO - 2017-02-28 03:11:19 --> Loader Class Initialized
INFO - 2017-02-28 03:11:19 --> Database Driver Class Initialized
INFO - 2017-02-28 03:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 03:11:19 --> Controller Class Initialized
INFO - 2017-02-28 03:11:19 --> Helper loaded: url_helper
DEBUG - 2017-02-28 03:11:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 03:11:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 03:11:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 03:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 03:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 03:11:20 --> Final output sent to browser
DEBUG - 2017-02-28 03:11:20 --> Total execution time: 1.2165
INFO - 2017-02-28 04:22:32 --> Config Class Initialized
INFO - 2017-02-28 04:22:32 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:22:32 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:22:32 --> Utf8 Class Initialized
INFO - 2017-02-28 04:22:32 --> URI Class Initialized
INFO - 2017-02-28 04:22:32 --> Router Class Initialized
INFO - 2017-02-28 04:22:32 --> Output Class Initialized
INFO - 2017-02-28 04:22:32 --> Security Class Initialized
DEBUG - 2017-02-28 04:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:22:33 --> Input Class Initialized
INFO - 2017-02-28 04:22:33 --> Language Class Initialized
INFO - 2017-02-28 04:22:33 --> Loader Class Initialized
INFO - 2017-02-28 04:22:33 --> Database Driver Class Initialized
INFO - 2017-02-28 04:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:22:34 --> Controller Class Initialized
INFO - 2017-02-28 04:22:34 --> Helper loaded: url_helper
DEBUG - 2017-02-28 04:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 04:22:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 04:22:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 04:22:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 04:22:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 04:22:34 --> Final output sent to browser
DEBUG - 2017-02-28 04:22:34 --> Total execution time: 2.5388
INFO - 2017-02-28 04:23:14 --> Config Class Initialized
INFO - 2017-02-28 04:23:14 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:23:14 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:23:14 --> Utf8 Class Initialized
INFO - 2017-02-28 04:23:14 --> URI Class Initialized
DEBUG - 2017-02-28 04:23:14 --> No URI present. Default controller set.
INFO - 2017-02-28 04:23:14 --> Router Class Initialized
INFO - 2017-02-28 04:23:14 --> Output Class Initialized
INFO - 2017-02-28 04:23:14 --> Security Class Initialized
DEBUG - 2017-02-28 04:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:23:14 --> Input Class Initialized
INFO - 2017-02-28 04:23:14 --> Language Class Initialized
INFO - 2017-02-28 04:23:14 --> Loader Class Initialized
INFO - 2017-02-28 04:23:15 --> Database Driver Class Initialized
INFO - 2017-02-28 04:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:23:15 --> Controller Class Initialized
INFO - 2017-02-28 04:23:15 --> Helper loaded: url_helper
DEBUG - 2017-02-28 04:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 04:23:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 04:23:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 04:23:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 04:23:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 04:23:16 --> Final output sent to browser
DEBUG - 2017-02-28 04:23:16 --> Total execution time: 2.1376
INFO - 2017-02-28 04:46:52 --> Config Class Initialized
INFO - 2017-02-28 04:46:52 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:46:52 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:46:52 --> Utf8 Class Initialized
INFO - 2017-02-28 04:46:52 --> URI Class Initialized
INFO - 2017-02-28 04:46:52 --> Router Class Initialized
INFO - 2017-02-28 04:46:52 --> Output Class Initialized
INFO - 2017-02-28 04:46:52 --> Security Class Initialized
DEBUG - 2017-02-28 04:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:46:52 --> Input Class Initialized
INFO - 2017-02-28 04:46:52 --> Language Class Initialized
INFO - 2017-02-28 04:46:52 --> Loader Class Initialized
INFO - 2017-02-28 04:46:53 --> Database Driver Class Initialized
INFO - 2017-02-28 04:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:46:53 --> Controller Class Initialized
INFO - 2017-02-28 04:46:53 --> Helper loaded: url_helper
DEBUG - 2017-02-28 04:46:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 04:46:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 04:46:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 04:46:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 04:46:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 04:46:54 --> Final output sent to browser
DEBUG - 2017-02-28 04:46:54 --> Total execution time: 1.7593
INFO - 2017-02-28 04:48:13 --> Config Class Initialized
INFO - 2017-02-28 04:48:13 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:48:13 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:48:13 --> Utf8 Class Initialized
INFO - 2017-02-28 04:48:13 --> URI Class Initialized
DEBUG - 2017-02-28 04:48:14 --> No URI present. Default controller set.
INFO - 2017-02-28 04:48:14 --> Router Class Initialized
INFO - 2017-02-28 04:48:14 --> Output Class Initialized
INFO - 2017-02-28 04:48:14 --> Security Class Initialized
DEBUG - 2017-02-28 04:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:48:14 --> Input Class Initialized
INFO - 2017-02-28 04:48:14 --> Language Class Initialized
INFO - 2017-02-28 04:48:14 --> Loader Class Initialized
INFO - 2017-02-28 04:48:14 --> Database Driver Class Initialized
INFO - 2017-02-28 04:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:48:15 --> Controller Class Initialized
INFO - 2017-02-28 04:48:15 --> Helper loaded: url_helper
DEBUG - 2017-02-28 04:48:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 04:48:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 04:48:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 04:48:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 04:48:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 04:48:15 --> Final output sent to browser
DEBUG - 2017-02-28 04:48:15 --> Total execution time: 1.7760
INFO - 2017-02-28 05:04:28 --> Config Class Initialized
INFO - 2017-02-28 05:04:28 --> Hooks Class Initialized
INFO - 2017-02-28 05:04:28 --> Config Class Initialized
INFO - 2017-02-28 05:04:28 --> Hooks Class Initialized
DEBUG - 2017-02-28 05:04:28 --> UTF-8 Support Enabled
DEBUG - 2017-02-28 05:04:28 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:04:28 --> Utf8 Class Initialized
INFO - 2017-02-28 05:04:28 --> Utf8 Class Initialized
INFO - 2017-02-28 05:04:28 --> URI Class Initialized
INFO - 2017-02-28 05:04:28 --> URI Class Initialized
DEBUG - 2017-02-28 05:04:28 --> No URI present. Default controller set.
DEBUG - 2017-02-28 05:04:28 --> No URI present. Default controller set.
INFO - 2017-02-28 05:04:28 --> Router Class Initialized
INFO - 2017-02-28 05:04:28 --> Router Class Initialized
INFO - 2017-02-28 05:04:28 --> Output Class Initialized
INFO - 2017-02-28 05:04:28 --> Output Class Initialized
INFO - 2017-02-28 05:04:28 --> Security Class Initialized
INFO - 2017-02-28 05:04:28 --> Security Class Initialized
DEBUG - 2017-02-28 05:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:04:28 --> Input Class Initialized
INFO - 2017-02-28 05:04:28 --> Language Class Initialized
DEBUG - 2017-02-28 05:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:04:28 --> Input Class Initialized
INFO - 2017-02-28 05:04:28 --> Language Class Initialized
INFO - 2017-02-28 05:04:28 --> Loader Class Initialized
INFO - 2017-02-28 05:04:29 --> Loader Class Initialized
INFO - 2017-02-28 05:04:29 --> Database Driver Class Initialized
INFO - 2017-02-28 05:04:29 --> Database Driver Class Initialized
INFO - 2017-02-28 05:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:04:29 --> Controller Class Initialized
INFO - 2017-02-28 05:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:04:29 --> Controller Class Initialized
INFO - 2017-02-28 05:04:29 --> Helper loaded: url_helper
INFO - 2017-02-28 05:04:29 --> Helper loaded: url_helper
DEBUG - 2017-02-28 05:04:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-02-28 05:04:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 05:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 05:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 05:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 05:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 05:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 05:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 05:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 05:04:30 --> Final output sent to browser
DEBUG - 2017-02-28 05:04:30 --> Total execution time: 2.2925
INFO - 2017-02-28 05:04:39 --> Config Class Initialized
INFO - 2017-02-28 05:04:39 --> Hooks Class Initialized
DEBUG - 2017-02-28 05:04:39 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:04:39 --> Utf8 Class Initialized
INFO - 2017-02-28 05:04:39 --> URI Class Initialized
DEBUG - 2017-02-28 05:04:39 --> No URI present. Default controller set.
INFO - 2017-02-28 05:04:39 --> Router Class Initialized
INFO - 2017-02-28 05:04:40 --> Output Class Initialized
INFO - 2017-02-28 05:04:40 --> Security Class Initialized
DEBUG - 2017-02-28 05:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:04:40 --> Input Class Initialized
INFO - 2017-02-28 05:04:40 --> Language Class Initialized
INFO - 2017-02-28 05:04:40 --> Loader Class Initialized
INFO - 2017-02-28 05:04:40 --> Database Driver Class Initialized
INFO - 2017-02-28 05:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:04:41 --> Controller Class Initialized
INFO - 2017-02-28 05:04:41 --> Helper loaded: url_helper
DEBUG - 2017-02-28 05:04:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 05:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 05:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 05:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 05:04:41 --> Final output sent to browser
DEBUG - 2017-02-28 05:04:41 --> Total execution time: 1.8793
INFO - 2017-02-28 05:04:51 --> Config Class Initialized
INFO - 2017-02-28 05:04:52 --> Hooks Class Initialized
DEBUG - 2017-02-28 05:04:52 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:04:52 --> Utf8 Class Initialized
INFO - 2017-02-28 05:04:52 --> URI Class Initialized
INFO - 2017-02-28 05:04:52 --> Router Class Initialized
INFO - 2017-02-28 05:04:52 --> Output Class Initialized
INFO - 2017-02-28 05:04:52 --> Security Class Initialized
DEBUG - 2017-02-28 05:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:04:52 --> Input Class Initialized
INFO - 2017-02-28 05:04:52 --> Language Class Initialized
INFO - 2017-02-28 05:04:52 --> Loader Class Initialized
INFO - 2017-02-28 05:04:52 --> Database Driver Class Initialized
INFO - 2017-02-28 05:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:04:53 --> Controller Class Initialized
INFO - 2017-02-28 05:04:53 --> Helper loaded: url_helper
DEBUG - 2017-02-28 05:04:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:04:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 05:04:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 05:04:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 05:04:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 05:04:53 --> Final output sent to browser
DEBUG - 2017-02-28 05:04:53 --> Total execution time: 1.5358
INFO - 2017-02-28 05:05:05 --> Config Class Initialized
INFO - 2017-02-28 05:05:05 --> Hooks Class Initialized
DEBUG - 2017-02-28 05:05:05 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:05:05 --> Utf8 Class Initialized
INFO - 2017-02-28 05:05:05 --> URI Class Initialized
INFO - 2017-02-28 05:05:05 --> Router Class Initialized
INFO - 2017-02-28 05:05:05 --> Output Class Initialized
INFO - 2017-02-28 05:05:05 --> Security Class Initialized
DEBUG - 2017-02-28 05:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:05:05 --> Input Class Initialized
INFO - 2017-02-28 05:05:05 --> Language Class Initialized
INFO - 2017-02-28 05:05:05 --> Loader Class Initialized
INFO - 2017-02-28 05:05:05 --> Database Driver Class Initialized
INFO - 2017-02-28 05:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:05:05 --> Controller Class Initialized
INFO - 2017-02-28 05:05:05 --> Helper loaded: url_helper
DEBUG - 2017-02-28 05:05:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:05:12 --> Config Class Initialized
INFO - 2017-02-28 05:05:12 --> Config Class Initialized
INFO - 2017-02-28 05:05:12 --> Hooks Class Initialized
INFO - 2017-02-28 05:05:12 --> Hooks Class Initialized
DEBUG - 2017-02-28 05:05:12 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:05:12 --> Utf8 Class Initialized
INFO - 2017-02-28 05:05:13 --> URI Class Initialized
DEBUG - 2017-02-28 05:05:13 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:05:13 --> Utf8 Class Initialized
INFO - 2017-02-28 05:05:13 --> Router Class Initialized
INFO - 2017-02-28 05:05:13 --> URI Class Initialized
INFO - 2017-02-28 05:05:13 --> Output Class Initialized
INFO - 2017-02-28 05:05:14 --> Router Class Initialized
INFO - 2017-02-28 05:05:14 --> Security Class Initialized
DEBUG - 2017-02-28 05:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:05:14 --> Output Class Initialized
INFO - 2017-02-28 05:05:14 --> Input Class Initialized
INFO - 2017-02-28 05:05:14 --> Language Class Initialized
INFO - 2017-02-28 05:05:14 --> Security Class Initialized
DEBUG - 2017-02-28 05:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:05:15 --> Input Class Initialized
INFO - 2017-02-28 05:05:15 --> Language Class Initialized
INFO - 2017-02-28 05:05:15 --> Loader Class Initialized
INFO - 2017-02-28 05:05:15 --> Loader Class Initialized
INFO - 2017-02-28 05:05:15 --> Database Driver Class Initialized
INFO - 2017-02-28 05:05:15 --> Database Driver Class Initialized
INFO - 2017-02-28 05:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:05:15 --> Controller Class Initialized
INFO - 2017-02-28 05:05:15 --> Helper loaded: url_helper
DEBUG - 2017-02-28 05:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:05:19 --> Controller Class Initialized
INFO - 2017-02-28 05:05:19 --> Helper loaded: url_helper
DEBUG - 2017-02-28 05:05:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:05:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 05:05:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 05:05:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 05:05:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 05:05:20 --> Final output sent to browser
DEBUG - 2017-02-28 05:05:20 --> Total execution time: 7.9614
INFO - 2017-02-28 05:06:37 --> Config Class Initialized
INFO - 2017-02-28 05:06:37 --> Hooks Class Initialized
DEBUG - 2017-02-28 05:06:37 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:06:37 --> Utf8 Class Initialized
INFO - 2017-02-28 05:06:37 --> URI Class Initialized
DEBUG - 2017-02-28 05:06:37 --> No URI present. Default controller set.
INFO - 2017-02-28 05:06:37 --> Router Class Initialized
INFO - 2017-02-28 05:06:37 --> Output Class Initialized
INFO - 2017-02-28 05:06:37 --> Security Class Initialized
DEBUG - 2017-02-28 05:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:06:37 --> Input Class Initialized
INFO - 2017-02-28 05:06:37 --> Language Class Initialized
INFO - 2017-02-28 05:06:37 --> Loader Class Initialized
INFO - 2017-02-28 05:06:38 --> Database Driver Class Initialized
INFO - 2017-02-28 05:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:06:38 --> Controller Class Initialized
INFO - 2017-02-28 05:06:38 --> Helper loaded: url_helper
DEBUG - 2017-02-28 05:06:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:06:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 05:06:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 05:06:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 05:06:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 05:06:38 --> Final output sent to browser
DEBUG - 2017-02-28 05:06:38 --> Total execution time: 1.3844
INFO - 2017-02-28 05:22:40 --> Config Class Initialized
INFO - 2017-02-28 05:22:40 --> Hooks Class Initialized
DEBUG - 2017-02-28 05:22:41 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:22:41 --> Utf8 Class Initialized
INFO - 2017-02-28 05:22:41 --> URI Class Initialized
INFO - 2017-02-28 05:22:41 --> Router Class Initialized
INFO - 2017-02-28 05:22:41 --> Output Class Initialized
INFO - 2017-02-28 05:22:41 --> Security Class Initialized
DEBUG - 2017-02-28 05:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:22:41 --> Input Class Initialized
INFO - 2017-02-28 05:22:41 --> Language Class Initialized
INFO - 2017-02-28 05:22:42 --> Loader Class Initialized
INFO - 2017-02-28 05:22:42 --> Database Driver Class Initialized
INFO - 2017-02-28 05:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:22:43 --> Controller Class Initialized
INFO - 2017-02-28 05:22:43 --> Helper loaded: date_helper
DEBUG - 2017-02-28 05:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:22:43 --> Helper loaded: url_helper
INFO - 2017-02-28 05:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 05:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-28 05:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-28 05:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-28 05:22:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 05:22:44 --> Final output sent to browser
DEBUG - 2017-02-28 05:22:44 --> Total execution time: 3.7505
INFO - 2017-02-28 05:23:01 --> Config Class Initialized
INFO - 2017-02-28 05:23:01 --> Hooks Class Initialized
DEBUG - 2017-02-28 05:23:02 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:23:02 --> Utf8 Class Initialized
INFO - 2017-02-28 05:23:02 --> URI Class Initialized
INFO - 2017-02-28 05:23:02 --> Router Class Initialized
INFO - 2017-02-28 05:23:02 --> Output Class Initialized
INFO - 2017-02-28 05:23:02 --> Security Class Initialized
DEBUG - 2017-02-28 05:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:23:02 --> Input Class Initialized
INFO - 2017-02-28 05:23:02 --> Language Class Initialized
INFO - 2017-02-28 05:23:02 --> Loader Class Initialized
INFO - 2017-02-28 05:23:02 --> Database Driver Class Initialized
INFO - 2017-02-28 05:23:03 --> Config Class Initialized
INFO - 2017-02-28 05:23:03 --> Hooks Class Initialized
DEBUG - 2017-02-28 05:23:03 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:23:03 --> Utf8 Class Initialized
INFO - 2017-02-28 05:23:03 --> URI Class Initialized
INFO - 2017-02-28 05:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:23:03 --> Controller Class Initialized
INFO - 2017-02-28 05:23:03 --> Helper loaded: url_helper
DEBUG - 2017-02-28 05:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:23:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 05:23:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
DEBUG - 2017-02-28 05:23:03 --> No URI present. Default controller set.
INFO - 2017-02-28 05:23:03 --> Router Class Initialized
INFO - 2017-02-28 05:23:03 --> Output Class Initialized
INFO - 2017-02-28 05:23:03 --> Security Class Initialized
INFO - 2017-02-28 05:23:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
DEBUG - 2017-02-28 05:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:23:03 --> Input Class Initialized
INFO - 2017-02-28 05:23:03 --> Language Class Initialized
INFO - 2017-02-28 05:23:03 --> Loader Class Initialized
INFO - 2017-02-28 05:23:03 --> Database Driver Class Initialized
INFO - 2017-02-28 05:23:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 05:23:03 --> Final output sent to browser
DEBUG - 2017-02-28 05:23:03 --> Total execution time: 2.3508
INFO - 2017-02-28 05:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:23:03 --> Controller Class Initialized
INFO - 2017-02-28 05:23:03 --> Helper loaded: url_helper
DEBUG - 2017-02-28 05:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:23:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 05:23:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 05:23:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 05:23:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 05:23:04 --> Final output sent to browser
DEBUG - 2017-02-28 05:23:04 --> Total execution time: 1.1030
INFO - 2017-02-28 05:23:20 --> Config Class Initialized
INFO - 2017-02-28 05:23:20 --> Hooks Class Initialized
DEBUG - 2017-02-28 05:23:20 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:23:20 --> Utf8 Class Initialized
INFO - 2017-02-28 05:23:20 --> URI Class Initialized
INFO - 2017-02-28 05:23:21 --> Router Class Initialized
INFO - 2017-02-28 05:23:21 --> Output Class Initialized
INFO - 2017-02-28 05:23:21 --> Security Class Initialized
DEBUG - 2017-02-28 05:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:23:21 --> Input Class Initialized
INFO - 2017-02-28 05:23:21 --> Language Class Initialized
INFO - 2017-02-28 05:23:21 --> Loader Class Initialized
INFO - 2017-02-28 05:23:21 --> Database Driver Class Initialized
INFO - 2017-02-28 05:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:23:22 --> Controller Class Initialized
INFO - 2017-02-28 05:23:22 --> Helper loaded: url_helper
DEBUG - 2017-02-28 05:23:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:23:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 05:23:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 05:23:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 05:23:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 05:23:22 --> Final output sent to browser
DEBUG - 2017-02-28 05:23:22 --> Total execution time: 2.0820
INFO - 2017-02-28 05:23:31 --> Config Class Initialized
INFO - 2017-02-28 05:23:31 --> Hooks Class Initialized
DEBUG - 2017-02-28 05:23:31 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:23:31 --> Utf8 Class Initialized
INFO - 2017-02-28 05:23:31 --> URI Class Initialized
INFO - 2017-02-28 05:23:31 --> Router Class Initialized
INFO - 2017-02-28 05:23:32 --> Output Class Initialized
INFO - 2017-02-28 05:23:32 --> Security Class Initialized
DEBUG - 2017-02-28 05:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:23:32 --> Input Class Initialized
INFO - 2017-02-28 05:23:32 --> Language Class Initialized
INFO - 2017-02-28 05:23:32 --> Loader Class Initialized
INFO - 2017-02-28 05:23:32 --> Database Driver Class Initialized
INFO - 2017-02-28 05:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:23:33 --> Controller Class Initialized
INFO - 2017-02-28 05:23:33 --> Helper loaded: url_helper
DEBUG - 2017-02-28 05:23:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:23:44 --> Config Class Initialized
INFO - 2017-02-28 05:23:44 --> Hooks Class Initialized
DEBUG - 2017-02-28 05:23:44 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:23:44 --> Utf8 Class Initialized
INFO - 2017-02-28 05:23:44 --> URI Class Initialized
INFO - 2017-02-28 05:23:45 --> Router Class Initialized
INFO - 2017-02-28 05:23:45 --> Output Class Initialized
INFO - 2017-02-28 05:23:45 --> Security Class Initialized
DEBUG - 2017-02-28 05:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:23:45 --> Input Class Initialized
INFO - 2017-02-28 05:23:45 --> Language Class Initialized
INFO - 2017-02-28 05:23:45 --> Loader Class Initialized
INFO - 2017-02-28 05:23:45 --> Database Driver Class Initialized
INFO - 2017-02-28 05:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:23:45 --> Controller Class Initialized
INFO - 2017-02-28 05:23:46 --> Helper loaded: date_helper
DEBUG - 2017-02-28 05:23:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:23:46 --> Helper loaded: url_helper
INFO - 2017-02-28 05:23:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 05:23:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 05:23:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-28 05:23:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-28 05:23:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 05:23:46 --> Final output sent to browser
DEBUG - 2017-02-28 05:23:46 --> Total execution time: 1.8126
INFO - 2017-02-28 05:24:00 --> Config Class Initialized
INFO - 2017-02-28 05:24:00 --> Hooks Class Initialized
DEBUG - 2017-02-28 05:24:00 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:24:00 --> Utf8 Class Initialized
INFO - 2017-02-28 05:24:01 --> URI Class Initialized
INFO - 2017-02-28 05:24:01 --> Router Class Initialized
INFO - 2017-02-28 05:24:01 --> Output Class Initialized
INFO - 2017-02-28 05:24:01 --> Security Class Initialized
DEBUG - 2017-02-28 05:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:24:01 --> Input Class Initialized
INFO - 2017-02-28 05:24:01 --> Language Class Initialized
INFO - 2017-02-28 05:24:01 --> Loader Class Initialized
INFO - 2017-02-28 05:24:01 --> Database Driver Class Initialized
INFO - 2017-02-28 05:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:24:01 --> Controller Class Initialized
INFO - 2017-02-28 05:24:01 --> Helper loaded: url_helper
DEBUG - 2017-02-28 05:24:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:24:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 05:24:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 05:24:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 05:24:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 05:24:02 --> Final output sent to browser
DEBUG - 2017-02-28 05:24:02 --> Total execution time: 1.7844
INFO - 2017-02-28 05:24:37 --> Config Class Initialized
INFO - 2017-02-28 05:24:37 --> Hooks Class Initialized
DEBUG - 2017-02-28 05:24:38 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:24:38 --> Utf8 Class Initialized
INFO - 2017-02-28 05:24:38 --> URI Class Initialized
INFO - 2017-02-28 05:24:38 --> Router Class Initialized
INFO - 2017-02-28 05:24:38 --> Output Class Initialized
INFO - 2017-02-28 05:24:38 --> Security Class Initialized
DEBUG - 2017-02-28 05:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:24:39 --> Input Class Initialized
INFO - 2017-02-28 05:24:39 --> Language Class Initialized
INFO - 2017-02-28 05:24:39 --> Loader Class Initialized
INFO - 2017-02-28 05:24:40 --> Database Driver Class Initialized
INFO - 2017-02-28 05:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:24:41 --> Controller Class Initialized
INFO - 2017-02-28 05:24:41 --> Helper loaded: date_helper
DEBUG - 2017-02-28 05:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:24:41 --> Helper loaded: url_helper
INFO - 2017-02-28 05:24:41 --> Helper loaded: download_helper
INFO - 2017-02-28 05:24:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 05:24:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 05:24:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-28 05:24:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-28 05:24:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 05:24:41 --> Final output sent to browser
DEBUG - 2017-02-28 05:24:41 --> Total execution time: 3.8540
INFO - 2017-02-28 05:24:56 --> Config Class Initialized
INFO - 2017-02-28 05:24:56 --> Hooks Class Initialized
DEBUG - 2017-02-28 05:24:57 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:24:57 --> Utf8 Class Initialized
INFO - 2017-02-28 05:24:57 --> URI Class Initialized
INFO - 2017-02-28 05:24:57 --> Router Class Initialized
INFO - 2017-02-28 05:24:57 --> Output Class Initialized
INFO - 2017-02-28 05:24:57 --> Security Class Initialized
DEBUG - 2017-02-28 05:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:24:57 --> Input Class Initialized
INFO - 2017-02-28 05:24:57 --> Language Class Initialized
INFO - 2017-02-28 05:24:57 --> Loader Class Initialized
INFO - 2017-02-28 05:24:57 --> Database Driver Class Initialized
INFO - 2017-02-28 05:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:24:58 --> Controller Class Initialized
INFO - 2017-02-28 05:24:58 --> Helper loaded: url_helper
DEBUG - 2017-02-28 05:24:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:24:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 05:24:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 05:24:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 05:24:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 05:24:58 --> Final output sent to browser
DEBUG - 2017-02-28 05:24:58 --> Total execution time: 1.5510
INFO - 2017-02-28 05:26:50 --> Config Class Initialized
INFO - 2017-02-28 05:26:50 --> Hooks Class Initialized
DEBUG - 2017-02-28 05:26:50 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:26:50 --> Utf8 Class Initialized
INFO - 2017-02-28 05:26:50 --> URI Class Initialized
INFO - 2017-02-28 05:26:50 --> Router Class Initialized
INFO - 2017-02-28 05:26:50 --> Output Class Initialized
INFO - 2017-02-28 05:26:51 --> Security Class Initialized
DEBUG - 2017-02-28 05:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:26:51 --> Input Class Initialized
INFO - 2017-02-28 05:26:51 --> Language Class Initialized
INFO - 2017-02-28 05:26:51 --> Loader Class Initialized
INFO - 2017-02-28 05:26:51 --> Database Driver Class Initialized
INFO - 2017-02-28 05:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:26:51 --> Controller Class Initialized
INFO - 2017-02-28 05:26:51 --> Helper loaded: date_helper
DEBUG - 2017-02-28 05:26:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:26:51 --> Helper loaded: url_helper
INFO - 2017-02-28 05:26:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 05:26:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-02-28 05:26:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 05:26:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-02-28 05:26:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-02-28 05:26:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 05:26:52 --> Final output sent to browser
DEBUG - 2017-02-28 05:26:52 --> Total execution time: 1.9587
INFO - 2017-02-28 05:27:04 --> Config Class Initialized
INFO - 2017-02-28 05:27:04 --> Hooks Class Initialized
DEBUG - 2017-02-28 05:27:04 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:27:04 --> Utf8 Class Initialized
INFO - 2017-02-28 05:27:04 --> URI Class Initialized
INFO - 2017-02-28 05:27:04 --> Router Class Initialized
INFO - 2017-02-28 05:27:04 --> Output Class Initialized
INFO - 2017-02-28 05:27:04 --> Security Class Initialized
DEBUG - 2017-02-28 05:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:27:04 --> Input Class Initialized
INFO - 2017-02-28 05:27:04 --> Language Class Initialized
INFO - 2017-02-28 05:27:04 --> Loader Class Initialized
INFO - 2017-02-28 05:27:05 --> Database Driver Class Initialized
INFO - 2017-02-28 05:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:27:05 --> Controller Class Initialized
INFO - 2017-02-28 05:27:05 --> Helper loaded: url_helper
DEBUG - 2017-02-28 05:27:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:27:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 05:27:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 05:27:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 05:27:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 05:27:05 --> Final output sent to browser
DEBUG - 2017-02-28 05:27:05 --> Total execution time: 1.6350
INFO - 2017-02-28 05:27:07 --> Config Class Initialized
INFO - 2017-02-28 05:27:07 --> Hooks Class Initialized
DEBUG - 2017-02-28 05:27:07 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:27:07 --> Utf8 Class Initialized
INFO - 2017-02-28 05:27:07 --> URI Class Initialized
INFO - 2017-02-28 05:27:07 --> Router Class Initialized
INFO - 2017-02-28 05:27:07 --> Output Class Initialized
INFO - 2017-02-28 05:27:07 --> Security Class Initialized
DEBUG - 2017-02-28 05:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:27:07 --> Input Class Initialized
INFO - 2017-02-28 05:27:07 --> Language Class Initialized
INFO - 2017-02-28 05:27:07 --> Loader Class Initialized
INFO - 2017-02-28 05:27:07 --> Database Driver Class Initialized
INFO - 2017-02-28 05:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:27:07 --> Controller Class Initialized
INFO - 2017-02-28 05:27:08 --> Helper loaded: date_helper
DEBUG - 2017-02-28 05:27:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:27:08 --> Helper loaded: url_helper
INFO - 2017-02-28 05:27:08 --> Helper loaded: download_helper
INFO - 2017-02-28 05:27:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 05:27:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 05:27:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-28 05:27:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-28 05:27:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 05:27:08 --> Final output sent to browser
DEBUG - 2017-02-28 05:27:08 --> Total execution time: 1.1858
INFO - 2017-02-28 05:27:17 --> Config Class Initialized
INFO - 2017-02-28 05:27:17 --> Hooks Class Initialized
DEBUG - 2017-02-28 05:27:17 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:27:17 --> Utf8 Class Initialized
INFO - 2017-02-28 05:27:17 --> URI Class Initialized
INFO - 2017-02-28 05:27:18 --> Router Class Initialized
INFO - 2017-02-28 05:27:18 --> Output Class Initialized
INFO - 2017-02-28 05:27:18 --> Security Class Initialized
DEBUG - 2017-02-28 05:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:27:18 --> Input Class Initialized
INFO - 2017-02-28 05:27:18 --> Language Class Initialized
INFO - 2017-02-28 05:27:18 --> Loader Class Initialized
INFO - 2017-02-28 05:27:18 --> Database Driver Class Initialized
INFO - 2017-02-28 05:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:27:18 --> Controller Class Initialized
INFO - 2017-02-28 05:27:18 --> Helper loaded: url_helper
DEBUG - 2017-02-28 05:27:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:27:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 05:27:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 05:27:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 05:27:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 05:27:20 --> Final output sent to browser
DEBUG - 2017-02-28 05:27:20 --> Total execution time: 1.2594
INFO - 2017-02-28 05:29:05 --> Config Class Initialized
INFO - 2017-02-28 05:29:05 --> Hooks Class Initialized
DEBUG - 2017-02-28 05:29:06 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:29:06 --> Utf8 Class Initialized
INFO - 2017-02-28 05:29:06 --> URI Class Initialized
INFO - 2017-02-28 05:29:06 --> Router Class Initialized
INFO - 2017-02-28 05:29:06 --> Output Class Initialized
INFO - 2017-02-28 05:29:06 --> Security Class Initialized
DEBUG - 2017-02-28 05:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:29:06 --> Input Class Initialized
INFO - 2017-02-28 05:29:06 --> Language Class Initialized
INFO - 2017-02-28 05:29:06 --> Loader Class Initialized
INFO - 2017-02-28 05:29:06 --> Database Driver Class Initialized
INFO - 2017-02-28 05:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:29:07 --> Controller Class Initialized
INFO - 2017-02-28 05:29:07 --> Helper loaded: date_helper
DEBUG - 2017-02-28 05:29:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:29:07 --> Helper loaded: url_helper
INFO - 2017-02-28 05:29:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 05:29:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 05:29:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-28 05:29:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-28 05:29:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 05:29:07 --> Final output sent to browser
DEBUG - 2017-02-28 05:29:07 --> Total execution time: 1.6626
INFO - 2017-02-28 05:29:17 --> Config Class Initialized
INFO - 2017-02-28 05:29:17 --> Hooks Class Initialized
DEBUG - 2017-02-28 05:29:18 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:29:18 --> Utf8 Class Initialized
INFO - 2017-02-28 05:29:18 --> URI Class Initialized
INFO - 2017-02-28 05:29:18 --> Router Class Initialized
INFO - 2017-02-28 05:29:18 --> Output Class Initialized
INFO - 2017-02-28 05:29:18 --> Security Class Initialized
DEBUG - 2017-02-28 05:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:29:18 --> Input Class Initialized
INFO - 2017-02-28 05:29:18 --> Language Class Initialized
INFO - 2017-02-28 05:29:18 --> Loader Class Initialized
INFO - 2017-02-28 05:29:18 --> Database Driver Class Initialized
INFO - 2017-02-28 05:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:29:18 --> Controller Class Initialized
INFO - 2017-02-28 05:29:18 --> Helper loaded: url_helper
DEBUG - 2017-02-28 05:29:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:29:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 05:29:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 05:29:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 05:29:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 05:29:19 --> Final output sent to browser
DEBUG - 2017-02-28 05:29:19 --> Total execution time: 1.2716
INFO - 2017-02-28 05:30:39 --> Config Class Initialized
INFO - 2017-02-28 05:30:39 --> Hooks Class Initialized
DEBUG - 2017-02-28 05:30:40 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:30:40 --> Utf8 Class Initialized
INFO - 2017-02-28 05:30:40 --> URI Class Initialized
INFO - 2017-02-28 05:30:40 --> Router Class Initialized
INFO - 2017-02-28 05:30:40 --> Output Class Initialized
INFO - 2017-02-28 05:30:40 --> Security Class Initialized
DEBUG - 2017-02-28 05:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:30:40 --> Input Class Initialized
INFO - 2017-02-28 05:30:40 --> Language Class Initialized
INFO - 2017-02-28 05:30:40 --> Loader Class Initialized
INFO - 2017-02-28 05:30:40 --> Database Driver Class Initialized
INFO - 2017-02-28 05:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:30:40 --> Controller Class Initialized
INFO - 2017-02-28 05:30:41 --> Helper loaded: date_helper
DEBUG - 2017-02-28 05:30:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:30:41 --> Helper loaded: url_helper
INFO - 2017-02-28 05:30:41 --> Helper loaded: download_helper
INFO - 2017-02-28 05:30:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 05:30:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 05:30:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-28 05:30:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-28 05:30:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 05:30:41 --> Final output sent to browser
DEBUG - 2017-02-28 05:30:41 --> Total execution time: 1.4510
INFO - 2017-02-28 05:30:49 --> Config Class Initialized
INFO - 2017-02-28 05:30:49 --> Hooks Class Initialized
DEBUG - 2017-02-28 05:30:49 --> UTF-8 Support Enabled
INFO - 2017-02-28 05:30:49 --> Utf8 Class Initialized
INFO - 2017-02-28 05:30:49 --> URI Class Initialized
INFO - 2017-02-28 05:30:49 --> Router Class Initialized
INFO - 2017-02-28 05:30:49 --> Output Class Initialized
INFO - 2017-02-28 05:30:49 --> Security Class Initialized
DEBUG - 2017-02-28 05:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 05:30:49 --> Input Class Initialized
INFO - 2017-02-28 05:30:49 --> Language Class Initialized
INFO - 2017-02-28 05:30:50 --> Loader Class Initialized
INFO - 2017-02-28 05:30:50 --> Database Driver Class Initialized
INFO - 2017-02-28 05:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 05:30:50 --> Controller Class Initialized
INFO - 2017-02-28 05:30:50 --> Helper loaded: url_helper
DEBUG - 2017-02-28 05:30:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 05:30:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 05:30:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 05:30:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 05:30:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 05:30:51 --> Final output sent to browser
DEBUG - 2017-02-28 05:30:51 --> Total execution time: 1.5961
INFO - 2017-02-28 06:04:54 --> Config Class Initialized
INFO - 2017-02-28 06:04:54 --> Hooks Class Initialized
DEBUG - 2017-02-28 06:04:54 --> UTF-8 Support Enabled
INFO - 2017-02-28 06:04:55 --> Utf8 Class Initialized
INFO - 2017-02-28 06:04:55 --> URI Class Initialized
INFO - 2017-02-28 06:04:55 --> Router Class Initialized
INFO - 2017-02-28 06:04:55 --> Output Class Initialized
INFO - 2017-02-28 06:04:55 --> Security Class Initialized
DEBUG - 2017-02-28 06:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 06:04:55 --> Input Class Initialized
INFO - 2017-02-28 06:04:55 --> Language Class Initialized
INFO - 2017-02-28 06:04:55 --> Loader Class Initialized
INFO - 2017-02-28 06:04:55 --> Database Driver Class Initialized
INFO - 2017-02-28 06:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 06:04:56 --> Controller Class Initialized
INFO - 2017-02-28 06:04:56 --> Helper loaded: date_helper
DEBUG - 2017-02-28 06:04:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 06:04:56 --> Helper loaded: url_helper
INFO - 2017-02-28 06:04:56 --> Helper loaded: download_helper
INFO - 2017-02-28 06:04:56 --> Config Class Initialized
INFO - 2017-02-28 06:04:56 --> Hooks Class Initialized
DEBUG - 2017-02-28 06:04:56 --> UTF-8 Support Enabled
INFO - 2017-02-28 06:04:56 --> Utf8 Class Initialized
INFO - 2017-02-28 06:04:56 --> URI Class Initialized
DEBUG - 2017-02-28 06:04:57 --> No URI present. Default controller set.
INFO - 2017-02-28 06:04:57 --> Router Class Initialized
INFO - 2017-02-28 06:04:57 --> Output Class Initialized
INFO - 2017-02-28 06:04:57 --> Security Class Initialized
DEBUG - 2017-02-28 06:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 06:04:57 --> Input Class Initialized
INFO - 2017-02-28 06:04:57 --> Language Class Initialized
INFO - 2017-02-28 06:04:57 --> Loader Class Initialized
INFO - 2017-02-28 06:04:57 --> Database Driver Class Initialized
INFO - 2017-02-28 06:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 06:04:57 --> Controller Class Initialized
INFO - 2017-02-28 06:04:57 --> Helper loaded: url_helper
DEBUG - 2017-02-28 06:04:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 06:04:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 06:04:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 06:04:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 06:04:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 06:04:57 --> Final output sent to browser
DEBUG - 2017-02-28 06:04:57 --> Total execution time: 0.4168
INFO - 2017-02-28 10:14:18 --> Config Class Initialized
INFO - 2017-02-28 10:14:18 --> Hooks Class Initialized
DEBUG - 2017-02-28 10:14:18 --> UTF-8 Support Enabled
INFO - 2017-02-28 10:14:18 --> Utf8 Class Initialized
INFO - 2017-02-28 10:14:18 --> URI Class Initialized
INFO - 2017-02-28 10:14:19 --> Router Class Initialized
INFO - 2017-02-28 10:14:19 --> Output Class Initialized
INFO - 2017-02-28 10:14:19 --> Security Class Initialized
DEBUG - 2017-02-28 10:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 10:14:19 --> Input Class Initialized
INFO - 2017-02-28 10:14:19 --> Language Class Initialized
INFO - 2017-02-28 10:14:19 --> Loader Class Initialized
INFO - 2017-02-28 10:14:19 --> Database Driver Class Initialized
INFO - 2017-02-28 10:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 10:14:19 --> Controller Class Initialized
INFO - 2017-02-28 10:14:19 --> Helper loaded: url_helper
DEBUG - 2017-02-28 10:14:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 10:14:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 10:14:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 10:14:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 10:14:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 10:14:20 --> Final output sent to browser
DEBUG - 2017-02-28 10:14:20 --> Total execution time: 1.4704
INFO - 2017-02-28 10:14:57 --> Config Class Initialized
INFO - 2017-02-28 10:14:57 --> Hooks Class Initialized
DEBUG - 2017-02-28 10:14:57 --> UTF-8 Support Enabled
INFO - 2017-02-28 10:14:57 --> Utf8 Class Initialized
INFO - 2017-02-28 10:14:57 --> URI Class Initialized
DEBUG - 2017-02-28 10:14:57 --> No URI present. Default controller set.
INFO - 2017-02-28 10:14:57 --> Router Class Initialized
INFO - 2017-02-28 10:14:57 --> Output Class Initialized
INFO - 2017-02-28 10:14:57 --> Security Class Initialized
DEBUG - 2017-02-28 10:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 10:14:57 --> Input Class Initialized
INFO - 2017-02-28 10:14:57 --> Language Class Initialized
INFO - 2017-02-28 10:14:57 --> Loader Class Initialized
INFO - 2017-02-28 10:14:57 --> Database Driver Class Initialized
INFO - 2017-02-28 10:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 10:14:57 --> Controller Class Initialized
INFO - 2017-02-28 10:14:57 --> Helper loaded: url_helper
DEBUG - 2017-02-28 10:14:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 10:14:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 10:14:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 10:14:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 10:14:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 10:14:57 --> Final output sent to browser
DEBUG - 2017-02-28 10:14:57 --> Total execution time: 0.0604
INFO - 2017-02-28 11:06:07 --> Config Class Initialized
INFO - 2017-02-28 11:06:07 --> Hooks Class Initialized
DEBUG - 2017-02-28 11:06:08 --> UTF-8 Support Enabled
INFO - 2017-02-28 11:06:08 --> Utf8 Class Initialized
INFO - 2017-02-28 11:06:08 --> URI Class Initialized
INFO - 2017-02-28 11:06:08 --> Router Class Initialized
INFO - 2017-02-28 11:06:08 --> Output Class Initialized
INFO - 2017-02-28 11:06:08 --> Security Class Initialized
DEBUG - 2017-02-28 11:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 11:06:08 --> Input Class Initialized
INFO - 2017-02-28 11:06:08 --> Language Class Initialized
INFO - 2017-02-28 11:06:08 --> Loader Class Initialized
INFO - 2017-02-28 11:06:08 --> Database Driver Class Initialized
INFO - 2017-02-28 11:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 11:06:09 --> Controller Class Initialized
INFO - 2017-02-28 11:06:09 --> Helper loaded: url_helper
DEBUG - 2017-02-28 11:06:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 11:06:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 11:06:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 11:06:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 11:06:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 11:06:09 --> Final output sent to browser
DEBUG - 2017-02-28 11:06:09 --> Total execution time: 1.6258
INFO - 2017-02-28 11:06:40 --> Config Class Initialized
INFO - 2017-02-28 11:06:40 --> Hooks Class Initialized
DEBUG - 2017-02-28 11:06:40 --> UTF-8 Support Enabled
INFO - 2017-02-28 11:06:40 --> Utf8 Class Initialized
INFO - 2017-02-28 11:06:40 --> URI Class Initialized
DEBUG - 2017-02-28 11:06:41 --> No URI present. Default controller set.
INFO - 2017-02-28 11:06:41 --> Router Class Initialized
INFO - 2017-02-28 11:06:41 --> Output Class Initialized
INFO - 2017-02-28 11:06:41 --> Security Class Initialized
DEBUG - 2017-02-28 11:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 11:06:41 --> Input Class Initialized
INFO - 2017-02-28 11:06:41 --> Language Class Initialized
INFO - 2017-02-28 11:06:41 --> Loader Class Initialized
INFO - 2017-02-28 11:06:41 --> Database Driver Class Initialized
INFO - 2017-02-28 11:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 11:06:42 --> Controller Class Initialized
INFO - 2017-02-28 11:06:42 --> Helper loaded: url_helper
DEBUG - 2017-02-28 11:06:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 11:06:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 11:06:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 11:06:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 11:06:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 11:06:42 --> Final output sent to browser
DEBUG - 2017-02-28 11:06:42 --> Total execution time: 1.6972
INFO - 2017-02-28 11:49:42 --> Config Class Initialized
INFO - 2017-02-28 11:49:42 --> Hooks Class Initialized
DEBUG - 2017-02-28 11:49:42 --> UTF-8 Support Enabled
INFO - 2017-02-28 11:49:42 --> Utf8 Class Initialized
INFO - 2017-02-28 11:49:42 --> URI Class Initialized
INFO - 2017-02-28 11:49:42 --> Router Class Initialized
INFO - 2017-02-28 11:49:42 --> Output Class Initialized
INFO - 2017-02-28 11:49:42 --> Security Class Initialized
DEBUG - 2017-02-28 11:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 11:49:42 --> Input Class Initialized
INFO - 2017-02-28 11:49:42 --> Language Class Initialized
INFO - 2017-02-28 11:49:42 --> Loader Class Initialized
INFO - 2017-02-28 11:49:42 --> Database Driver Class Initialized
INFO - 2017-02-28 11:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 11:49:43 --> Controller Class Initialized
INFO - 2017-02-28 11:49:43 --> Helper loaded: url_helper
DEBUG - 2017-02-28 11:49:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 11:49:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 11:49:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 11:49:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 11:49:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 11:49:43 --> Final output sent to browser
DEBUG - 2017-02-28 11:49:43 --> Total execution time: 1.6292
INFO - 2017-02-28 13:22:53 --> Config Class Initialized
INFO - 2017-02-28 13:22:53 --> Hooks Class Initialized
DEBUG - 2017-02-28 13:22:53 --> UTF-8 Support Enabled
INFO - 2017-02-28 13:22:53 --> Utf8 Class Initialized
INFO - 2017-02-28 13:22:53 --> URI Class Initialized
INFO - 2017-02-28 13:22:53 --> Router Class Initialized
INFO - 2017-02-28 13:22:53 --> Output Class Initialized
INFO - 2017-02-28 13:22:53 --> Security Class Initialized
DEBUG - 2017-02-28 13:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 13:22:53 --> Input Class Initialized
INFO - 2017-02-28 13:22:53 --> Language Class Initialized
INFO - 2017-02-28 13:22:53 --> Loader Class Initialized
INFO - 2017-02-28 13:22:54 --> Database Driver Class Initialized
INFO - 2017-02-28 13:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 13:22:54 --> Controller Class Initialized
INFO - 2017-02-28 13:22:54 --> Helper loaded: url_helper
DEBUG - 2017-02-28 13:22:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 13:22:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 13:22:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 13:22:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 13:22:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 13:22:54 --> Final output sent to browser
DEBUG - 2017-02-28 13:22:54 --> Total execution time: 1.7677
INFO - 2017-02-28 13:23:27 --> Config Class Initialized
INFO - 2017-02-28 13:23:27 --> Hooks Class Initialized
DEBUG - 2017-02-28 13:23:27 --> UTF-8 Support Enabled
INFO - 2017-02-28 13:23:27 --> Utf8 Class Initialized
INFO - 2017-02-28 13:23:27 --> URI Class Initialized
DEBUG - 2017-02-28 13:23:27 --> No URI present. Default controller set.
INFO - 2017-02-28 13:23:27 --> Router Class Initialized
INFO - 2017-02-28 13:23:27 --> Output Class Initialized
INFO - 2017-02-28 13:23:27 --> Security Class Initialized
DEBUG - 2017-02-28 13:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 13:23:27 --> Input Class Initialized
INFO - 2017-02-28 13:23:27 --> Language Class Initialized
INFO - 2017-02-28 13:23:27 --> Loader Class Initialized
INFO - 2017-02-28 13:23:27 --> Database Driver Class Initialized
INFO - 2017-02-28 13:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 13:23:27 --> Controller Class Initialized
INFO - 2017-02-28 13:23:27 --> Helper loaded: url_helper
DEBUG - 2017-02-28 13:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 13:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 13:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 13:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 13:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 13:23:27 --> Final output sent to browser
DEBUG - 2017-02-28 13:23:27 --> Total execution time: 0.0754
INFO - 2017-02-28 14:19:42 --> Config Class Initialized
INFO - 2017-02-28 14:19:42 --> Hooks Class Initialized
DEBUG - 2017-02-28 14:19:42 --> UTF-8 Support Enabled
INFO - 2017-02-28 14:19:42 --> Utf8 Class Initialized
INFO - 2017-02-28 14:19:42 --> URI Class Initialized
DEBUG - 2017-02-28 14:19:43 --> No URI present. Default controller set.
INFO - 2017-02-28 14:19:43 --> Router Class Initialized
INFO - 2017-02-28 14:19:43 --> Output Class Initialized
INFO - 2017-02-28 14:19:43 --> Security Class Initialized
DEBUG - 2017-02-28 14:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 14:19:43 --> Input Class Initialized
INFO - 2017-02-28 14:19:43 --> Language Class Initialized
INFO - 2017-02-28 14:19:43 --> Loader Class Initialized
INFO - 2017-02-28 14:19:43 --> Database Driver Class Initialized
INFO - 2017-02-28 14:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 14:19:44 --> Controller Class Initialized
INFO - 2017-02-28 14:19:44 --> Helper loaded: url_helper
DEBUG - 2017-02-28 14:19:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 14:19:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 14:19:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 14:19:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 14:19:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 14:19:44 --> Final output sent to browser
DEBUG - 2017-02-28 14:19:44 --> Total execution time: 1.7842
INFO - 2017-02-28 17:58:50 --> Config Class Initialized
INFO - 2017-02-28 17:58:50 --> Hooks Class Initialized
DEBUG - 2017-02-28 17:58:50 --> UTF-8 Support Enabled
INFO - 2017-02-28 17:58:50 --> Utf8 Class Initialized
INFO - 2017-02-28 17:58:50 --> URI Class Initialized
DEBUG - 2017-02-28 17:58:50 --> No URI present. Default controller set.
INFO - 2017-02-28 17:58:50 --> Router Class Initialized
INFO - 2017-02-28 17:58:50 --> Output Class Initialized
INFO - 2017-02-28 17:58:50 --> Security Class Initialized
DEBUG - 2017-02-28 17:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 17:58:50 --> Input Class Initialized
INFO - 2017-02-28 17:58:50 --> Language Class Initialized
INFO - 2017-02-28 17:58:50 --> Loader Class Initialized
INFO - 2017-02-28 17:58:51 --> Database Driver Class Initialized
INFO - 2017-02-28 17:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 17:58:51 --> Controller Class Initialized
INFO - 2017-02-28 17:58:51 --> Helper loaded: url_helper
DEBUG - 2017-02-28 17:58:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 17:58:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 17:58:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 17:58:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 17:58:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 17:58:52 --> Final output sent to browser
DEBUG - 2017-02-28 17:58:52 --> Total execution time: 1.7926
INFO - 2017-02-28 17:59:04 --> Config Class Initialized
INFO - 2017-02-28 17:59:04 --> Hooks Class Initialized
DEBUG - 2017-02-28 17:59:04 --> UTF-8 Support Enabled
INFO - 2017-02-28 17:59:04 --> Utf8 Class Initialized
INFO - 2017-02-28 17:59:04 --> URI Class Initialized
INFO - 2017-02-28 17:59:04 --> Router Class Initialized
INFO - 2017-02-28 17:59:04 --> Output Class Initialized
INFO - 2017-02-28 17:59:04 --> Security Class Initialized
DEBUG - 2017-02-28 17:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 17:59:04 --> Input Class Initialized
INFO - 2017-02-28 17:59:04 --> Language Class Initialized
INFO - 2017-02-28 17:59:05 --> Loader Class Initialized
INFO - 2017-02-28 17:59:05 --> Database Driver Class Initialized
INFO - 2017-02-28 17:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 17:59:05 --> Controller Class Initialized
INFO - 2017-02-28 17:59:05 --> Helper loaded: url_helper
DEBUG - 2017-02-28 17:59:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 17:59:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 17:59:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 17:59:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 17:59:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 17:59:05 --> Final output sent to browser
DEBUG - 2017-02-28 17:59:05 --> Total execution time: 1.5361
INFO - 2017-02-28 17:59:11 --> Config Class Initialized
INFO - 2017-02-28 17:59:11 --> Hooks Class Initialized
DEBUG - 2017-02-28 17:59:11 --> UTF-8 Support Enabled
INFO - 2017-02-28 17:59:11 --> Utf8 Class Initialized
INFO - 2017-02-28 17:59:11 --> URI Class Initialized
INFO - 2017-02-28 17:59:11 --> Router Class Initialized
INFO - 2017-02-28 17:59:11 --> Output Class Initialized
INFO - 2017-02-28 17:59:11 --> Security Class Initialized
DEBUG - 2017-02-28 17:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 17:59:11 --> Input Class Initialized
INFO - 2017-02-28 17:59:11 --> Language Class Initialized
INFO - 2017-02-28 17:59:11 --> Loader Class Initialized
INFO - 2017-02-28 17:59:11 --> Database Driver Class Initialized
INFO - 2017-02-28 17:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 17:59:11 --> Controller Class Initialized
INFO - 2017-02-28 17:59:11 --> Helper loaded: url_helper
DEBUG - 2017-02-28 17:59:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 17:59:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 17:59:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 17:59:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 17:59:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 17:59:11 --> Final output sent to browser
DEBUG - 2017-02-28 17:59:11 --> Total execution time: 0.0285
INFO - 2017-02-28 17:59:30 --> Config Class Initialized
INFO - 2017-02-28 17:59:30 --> Hooks Class Initialized
DEBUG - 2017-02-28 17:59:30 --> UTF-8 Support Enabled
INFO - 2017-02-28 17:59:30 --> Utf8 Class Initialized
INFO - 2017-02-28 17:59:30 --> URI Class Initialized
INFO - 2017-02-28 17:59:30 --> Router Class Initialized
INFO - 2017-02-28 17:59:30 --> Output Class Initialized
INFO - 2017-02-28 17:59:30 --> Security Class Initialized
DEBUG - 2017-02-28 17:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 17:59:30 --> Input Class Initialized
INFO - 2017-02-28 17:59:30 --> Language Class Initialized
INFO - 2017-02-28 17:59:30 --> Loader Class Initialized
INFO - 2017-02-28 17:59:31 --> Database Driver Class Initialized
INFO - 2017-02-28 17:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 17:59:31 --> Controller Class Initialized
INFO - 2017-02-28 17:59:31 --> Helper loaded: url_helper
DEBUG - 2017-02-28 17:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 17:59:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 17:59:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 17:59:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 17:59:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 17:59:31 --> Final output sent to browser
DEBUG - 2017-02-28 17:59:31 --> Total execution time: 1.4594
INFO - 2017-02-28 17:59:35 --> Config Class Initialized
INFO - 2017-02-28 17:59:35 --> Hooks Class Initialized
DEBUG - 2017-02-28 17:59:36 --> UTF-8 Support Enabled
INFO - 2017-02-28 17:59:36 --> Utf8 Class Initialized
INFO - 2017-02-28 17:59:36 --> URI Class Initialized
INFO - 2017-02-28 17:59:36 --> Router Class Initialized
INFO - 2017-02-28 17:59:36 --> Output Class Initialized
INFO - 2017-02-28 17:59:36 --> Security Class Initialized
DEBUG - 2017-02-28 17:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 17:59:36 --> Input Class Initialized
INFO - 2017-02-28 17:59:36 --> Language Class Initialized
INFO - 2017-02-28 17:59:36 --> Loader Class Initialized
INFO - 2017-02-28 17:59:36 --> Database Driver Class Initialized
INFO - 2017-02-28 17:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 17:59:36 --> Controller Class Initialized
INFO - 2017-02-28 17:59:36 --> Helper loaded: url_helper
DEBUG - 2017-02-28 17:59:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 17:59:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 17:59:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 17:59:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 17:59:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 17:59:37 --> Final output sent to browser
DEBUG - 2017-02-28 17:59:37 --> Total execution time: 1.2623
INFO - 2017-02-28 17:59:56 --> Config Class Initialized
INFO - 2017-02-28 17:59:56 --> Hooks Class Initialized
DEBUG - 2017-02-28 17:59:56 --> UTF-8 Support Enabled
INFO - 2017-02-28 17:59:56 --> Utf8 Class Initialized
INFO - 2017-02-28 17:59:56 --> URI Class Initialized
INFO - 2017-02-28 17:59:56 --> Router Class Initialized
INFO - 2017-02-28 17:59:56 --> Output Class Initialized
INFO - 2017-02-28 17:59:56 --> Security Class Initialized
DEBUG - 2017-02-28 17:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 17:59:56 --> Input Class Initialized
INFO - 2017-02-28 17:59:56 --> Language Class Initialized
INFO - 2017-02-28 17:59:56 --> Loader Class Initialized
INFO - 2017-02-28 17:59:57 --> Database Driver Class Initialized
INFO - 2017-02-28 17:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 17:59:57 --> Controller Class Initialized
INFO - 2017-02-28 17:59:57 --> Helper loaded: url_helper
DEBUG - 2017-02-28 17:59:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 17:59:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 17:59:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 17:59:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 17:59:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 17:59:59 --> Final output sent to browser
DEBUG - 2017-02-28 17:59:59 --> Total execution time: 2.8376
INFO - 2017-02-28 18:00:23 --> Config Class Initialized
INFO - 2017-02-28 18:00:23 --> Hooks Class Initialized
DEBUG - 2017-02-28 18:00:23 --> UTF-8 Support Enabled
INFO - 2017-02-28 18:00:23 --> Utf8 Class Initialized
INFO - 2017-02-28 18:00:23 --> URI Class Initialized
INFO - 2017-02-28 18:00:23 --> Router Class Initialized
INFO - 2017-02-28 18:00:23 --> Output Class Initialized
INFO - 2017-02-28 18:00:23 --> Security Class Initialized
DEBUG - 2017-02-28 18:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 18:00:23 --> Input Class Initialized
INFO - 2017-02-28 18:00:23 --> Language Class Initialized
INFO - 2017-02-28 18:00:24 --> Loader Class Initialized
INFO - 2017-02-28 18:00:24 --> Database Driver Class Initialized
INFO - 2017-02-28 18:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 18:00:24 --> Controller Class Initialized
INFO - 2017-02-28 18:00:24 --> Helper loaded: url_helper
DEBUG - 2017-02-28 18:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 18:00:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 18:00:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 18:00:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 18:00:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 18:00:24 --> Final output sent to browser
DEBUG - 2017-02-28 18:00:24 --> Total execution time: 1.5752
INFO - 2017-02-28 18:00:38 --> Config Class Initialized
INFO - 2017-02-28 18:00:38 --> Hooks Class Initialized
DEBUG - 2017-02-28 18:00:39 --> UTF-8 Support Enabled
INFO - 2017-02-28 18:00:39 --> Utf8 Class Initialized
INFO - 2017-02-28 18:00:39 --> URI Class Initialized
INFO - 2017-02-28 18:00:39 --> Router Class Initialized
INFO - 2017-02-28 18:00:39 --> Output Class Initialized
INFO - 2017-02-28 18:00:39 --> Security Class Initialized
DEBUG - 2017-02-28 18:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 18:00:39 --> Input Class Initialized
INFO - 2017-02-28 18:00:39 --> Language Class Initialized
INFO - 2017-02-28 18:00:39 --> Loader Class Initialized
INFO - 2017-02-28 18:00:40 --> Database Driver Class Initialized
INFO - 2017-02-28 18:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 18:00:43 --> Controller Class Initialized
INFO - 2017-02-28 18:00:43 --> Helper loaded: url_helper
DEBUG - 2017-02-28 18:00:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 18:00:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 18:00:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 18:00:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 18:00:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 18:00:43 --> Final output sent to browser
DEBUG - 2017-02-28 18:00:43 --> Total execution time: 4.9335
INFO - 2017-02-28 18:05:48 --> Config Class Initialized
INFO - 2017-02-28 18:05:48 --> Hooks Class Initialized
DEBUG - 2017-02-28 18:05:48 --> UTF-8 Support Enabled
INFO - 2017-02-28 18:05:48 --> Utf8 Class Initialized
INFO - 2017-02-28 18:05:48 --> URI Class Initialized
DEBUG - 2017-02-28 18:05:48 --> No URI present. Default controller set.
INFO - 2017-02-28 18:05:48 --> Router Class Initialized
INFO - 2017-02-28 18:05:48 --> Output Class Initialized
INFO - 2017-02-28 18:05:48 --> Security Class Initialized
DEBUG - 2017-02-28 18:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 18:05:48 --> Input Class Initialized
INFO - 2017-02-28 18:05:48 --> Language Class Initialized
INFO - 2017-02-28 18:05:48 --> Loader Class Initialized
INFO - 2017-02-28 18:05:49 --> Database Driver Class Initialized
INFO - 2017-02-28 18:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 18:05:49 --> Controller Class Initialized
INFO - 2017-02-28 18:05:49 --> Helper loaded: url_helper
DEBUG - 2017-02-28 18:05:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 18:05:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 18:05:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 18:05:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 18:05:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 18:05:49 --> Final output sent to browser
DEBUG - 2017-02-28 18:05:49 --> Total execution time: 1.7470
INFO - 2017-02-28 18:45:37 --> Config Class Initialized
INFO - 2017-02-28 18:45:37 --> Hooks Class Initialized
DEBUG - 2017-02-28 18:45:38 --> UTF-8 Support Enabled
INFO - 2017-02-28 18:45:38 --> Utf8 Class Initialized
INFO - 2017-02-28 18:45:38 --> URI Class Initialized
DEBUG - 2017-02-28 18:45:38 --> No URI present. Default controller set.
INFO - 2017-02-28 18:45:38 --> Router Class Initialized
INFO - 2017-02-28 18:45:38 --> Output Class Initialized
INFO - 2017-02-28 18:45:38 --> Security Class Initialized
DEBUG - 2017-02-28 18:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 18:45:38 --> Input Class Initialized
INFO - 2017-02-28 18:45:38 --> Language Class Initialized
INFO - 2017-02-28 18:45:38 --> Loader Class Initialized
INFO - 2017-02-28 18:45:38 --> Database Driver Class Initialized
INFO - 2017-02-28 18:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 18:45:39 --> Controller Class Initialized
INFO - 2017-02-28 18:45:39 --> Helper loaded: url_helper
DEBUG - 2017-02-28 18:45:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 18:45:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 18:45:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 18:45:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 18:45:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 18:45:39 --> Final output sent to browser
DEBUG - 2017-02-28 18:45:39 --> Total execution time: 2.1759
INFO - 2017-02-28 20:51:02 --> Config Class Initialized
INFO - 2017-02-28 20:51:02 --> Hooks Class Initialized
DEBUG - 2017-02-28 20:51:02 --> UTF-8 Support Enabled
INFO - 2017-02-28 20:51:02 --> Utf8 Class Initialized
INFO - 2017-02-28 20:51:02 --> URI Class Initialized
INFO - 2017-02-28 20:51:02 --> Router Class Initialized
INFO - 2017-02-28 20:51:02 --> Output Class Initialized
INFO - 2017-02-28 20:51:02 --> Security Class Initialized
DEBUG - 2017-02-28 20:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 20:51:03 --> Input Class Initialized
INFO - 2017-02-28 20:51:03 --> Language Class Initialized
INFO - 2017-02-28 20:51:03 --> Loader Class Initialized
INFO - 2017-02-28 20:51:03 --> Database Driver Class Initialized
INFO - 2017-02-28 20:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 20:51:03 --> Controller Class Initialized
INFO - 2017-02-28 20:51:03 --> Helper loaded: url_helper
DEBUG - 2017-02-28 20:51:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 20:51:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 20:51:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 20:51:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 20:51:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 20:51:05 --> Final output sent to browser
DEBUG - 2017-02-28 20:51:05 --> Total execution time: 1.8926
INFO - 2017-02-28 20:51:05 --> Config Class Initialized
INFO - 2017-02-28 20:51:05 --> Hooks Class Initialized
DEBUG - 2017-02-28 20:51:05 --> UTF-8 Support Enabled
INFO - 2017-02-28 20:51:05 --> Utf8 Class Initialized
INFO - 2017-02-28 20:51:05 --> URI Class Initialized
DEBUG - 2017-02-28 20:51:05 --> No URI present. Default controller set.
INFO - 2017-02-28 20:51:05 --> Router Class Initialized
INFO - 2017-02-28 20:51:05 --> Output Class Initialized
INFO - 2017-02-28 20:51:05 --> Security Class Initialized
DEBUG - 2017-02-28 20:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 20:51:06 --> Input Class Initialized
INFO - 2017-02-28 20:51:06 --> Language Class Initialized
INFO - 2017-02-28 20:51:06 --> Loader Class Initialized
INFO - 2017-02-28 20:51:06 --> Database Driver Class Initialized
INFO - 2017-02-28 20:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 20:51:06 --> Controller Class Initialized
INFO - 2017-02-28 20:51:06 --> Helper loaded: url_helper
DEBUG - 2017-02-28 20:51:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 20:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 20:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 20:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 20:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 20:51:06 --> Final output sent to browser
DEBUG - 2017-02-28 20:51:06 --> Total execution time: 1.2258
INFO - 2017-02-28 20:51:47 --> Config Class Initialized
INFO - 2017-02-28 20:51:47 --> Hooks Class Initialized
DEBUG - 2017-02-28 20:51:47 --> UTF-8 Support Enabled
INFO - 2017-02-28 20:51:47 --> Utf8 Class Initialized
INFO - 2017-02-28 20:51:47 --> URI Class Initialized
INFO - 2017-02-28 20:51:47 --> Router Class Initialized
INFO - 2017-02-28 20:51:47 --> Output Class Initialized
INFO - 2017-02-28 20:51:47 --> Security Class Initialized
DEBUG - 2017-02-28 20:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 20:51:47 --> Input Class Initialized
INFO - 2017-02-28 20:51:47 --> Language Class Initialized
INFO - 2017-02-28 20:51:47 --> Loader Class Initialized
INFO - 2017-02-28 20:51:48 --> Database Driver Class Initialized
INFO - 2017-02-28 20:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 20:51:48 --> Controller Class Initialized
INFO - 2017-02-28 20:51:48 --> Helper loaded: url_helper
DEBUG - 2017-02-28 20:51:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 20:51:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 20:51:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 20:51:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 20:51:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 20:51:49 --> Final output sent to browser
DEBUG - 2017-02-28 20:51:49 --> Total execution time: 1.7760
INFO - 2017-02-28 20:51:59 --> Config Class Initialized
INFO - 2017-02-28 20:51:59 --> Hooks Class Initialized
DEBUG - 2017-02-28 20:51:59 --> UTF-8 Support Enabled
INFO - 2017-02-28 20:51:59 --> Utf8 Class Initialized
INFO - 2017-02-28 20:51:59 --> URI Class Initialized
DEBUG - 2017-02-28 20:51:59 --> No URI present. Default controller set.
INFO - 2017-02-28 20:51:59 --> Router Class Initialized
INFO - 2017-02-28 20:52:00 --> Output Class Initialized
INFO - 2017-02-28 20:52:00 --> Security Class Initialized
DEBUG - 2017-02-28 20:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 20:52:00 --> Input Class Initialized
INFO - 2017-02-28 20:52:00 --> Language Class Initialized
INFO - 2017-02-28 20:52:00 --> Loader Class Initialized
INFO - 2017-02-28 20:52:00 --> Database Driver Class Initialized
INFO - 2017-02-28 20:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 20:52:00 --> Controller Class Initialized
INFO - 2017-02-28 20:52:00 --> Helper loaded: url_helper
DEBUG - 2017-02-28 20:52:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 20:52:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 20:52:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 20:52:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 20:52:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 20:52:01 --> Final output sent to browser
DEBUG - 2017-02-28 20:52:01 --> Total execution time: 4.9428
INFO - 2017-02-28 22:15:31 --> Config Class Initialized
INFO - 2017-02-28 22:15:31 --> Hooks Class Initialized
DEBUG - 2017-02-28 22:15:31 --> UTF-8 Support Enabled
INFO - 2017-02-28 22:15:31 --> Utf8 Class Initialized
INFO - 2017-02-28 22:15:31 --> URI Class Initialized
INFO - 2017-02-28 22:15:31 --> Router Class Initialized
INFO - 2017-02-28 22:15:32 --> Output Class Initialized
INFO - 2017-02-28 22:15:32 --> Security Class Initialized
DEBUG - 2017-02-28 22:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 22:15:32 --> Input Class Initialized
INFO - 2017-02-28 22:15:32 --> Language Class Initialized
INFO - 2017-02-28 22:15:32 --> Loader Class Initialized
INFO - 2017-02-28 22:15:32 --> Database Driver Class Initialized
INFO - 2017-02-28 22:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 22:15:32 --> Controller Class Initialized
INFO - 2017-02-28 22:15:33 --> Helper loaded: date_helper
DEBUG - 2017-02-28 22:15:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 22:15:33 --> Helper loaded: url_helper
INFO - 2017-02-28 22:15:33 --> Helper loaded: download_helper
INFO - 2017-02-28 22:15:33 --> Config Class Initialized
INFO - 2017-02-28 22:15:33 --> Hooks Class Initialized
DEBUG - 2017-02-28 22:15:33 --> UTF-8 Support Enabled
INFO - 2017-02-28 22:15:33 --> Utf8 Class Initialized
INFO - 2017-02-28 22:15:33 --> URI Class Initialized
DEBUG - 2017-02-28 22:15:33 --> No URI present. Default controller set.
INFO - 2017-02-28 22:15:33 --> Router Class Initialized
INFO - 2017-02-28 22:15:33 --> Output Class Initialized
INFO - 2017-02-28 22:15:33 --> Security Class Initialized
DEBUG - 2017-02-28 22:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 22:15:33 --> Input Class Initialized
INFO - 2017-02-28 22:15:33 --> Language Class Initialized
INFO - 2017-02-28 22:15:33 --> Loader Class Initialized
INFO - 2017-02-28 22:15:33 --> Database Driver Class Initialized
INFO - 2017-02-28 22:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 22:15:33 --> Controller Class Initialized
INFO - 2017-02-28 22:15:33 --> Helper loaded: url_helper
DEBUG - 2017-02-28 22:15:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 22:15:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 22:15:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 22:15:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 22:15:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 22:15:33 --> Final output sent to browser
DEBUG - 2017-02-28 22:15:33 --> Total execution time: 0.3566
INFO - 2017-02-28 22:15:45 --> Config Class Initialized
INFO - 2017-02-28 22:15:45 --> Hooks Class Initialized
DEBUG - 2017-02-28 22:15:45 --> UTF-8 Support Enabled
INFO - 2017-02-28 22:15:45 --> Utf8 Class Initialized
INFO - 2017-02-28 22:15:45 --> URI Class Initialized
INFO - 2017-02-28 22:15:45 --> Router Class Initialized
INFO - 2017-02-28 22:15:45 --> Output Class Initialized
INFO - 2017-02-28 22:15:45 --> Security Class Initialized
DEBUG - 2017-02-28 22:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 22:15:45 --> Input Class Initialized
INFO - 2017-02-28 22:15:45 --> Language Class Initialized
INFO - 2017-02-28 22:15:45 --> Loader Class Initialized
INFO - 2017-02-28 22:15:45 --> Database Driver Class Initialized
INFO - 2017-02-28 22:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 22:15:45 --> Controller Class Initialized
INFO - 2017-02-28 22:15:45 --> Helper loaded: url_helper
DEBUG - 2017-02-28 22:15:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 22:15:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 22:15:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 22:15:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 22:15:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 22:15:45 --> Final output sent to browser
DEBUG - 2017-02-28 22:15:45 --> Total execution time: 0.0148
INFO - 2017-02-28 22:28:04 --> Config Class Initialized
INFO - 2017-02-28 22:28:04 --> Hooks Class Initialized
DEBUG - 2017-02-28 22:28:04 --> UTF-8 Support Enabled
INFO - 2017-02-28 22:28:04 --> Utf8 Class Initialized
INFO - 2017-02-28 22:28:04 --> URI Class Initialized
INFO - 2017-02-28 22:28:04 --> Router Class Initialized
INFO - 2017-02-28 22:28:04 --> Output Class Initialized
INFO - 2017-02-28 22:28:04 --> Security Class Initialized
DEBUG - 2017-02-28 22:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 22:28:04 --> Input Class Initialized
INFO - 2017-02-28 22:28:04 --> Language Class Initialized
INFO - 2017-02-28 22:28:04 --> Loader Class Initialized
INFO - 2017-02-28 22:28:05 --> Database Driver Class Initialized
INFO - 2017-02-28 22:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 22:28:05 --> Controller Class Initialized
INFO - 2017-02-28 22:28:05 --> Helper loaded: url_helper
DEBUG - 2017-02-28 22:28:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 22:28:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 22:28:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 22:28:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 22:28:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 22:28:06 --> Final output sent to browser
DEBUG - 2017-02-28 22:28:06 --> Total execution time: 3.4290
INFO - 2017-02-28 23:10:52 --> Config Class Initialized
INFO - 2017-02-28 23:10:52 --> Hooks Class Initialized
DEBUG - 2017-02-28 23:10:52 --> UTF-8 Support Enabled
INFO - 2017-02-28 23:10:52 --> Utf8 Class Initialized
INFO - 2017-02-28 23:10:52 --> URI Class Initialized
DEBUG - 2017-02-28 23:10:52 --> No URI present. Default controller set.
INFO - 2017-02-28 23:10:52 --> Router Class Initialized
INFO - 2017-02-28 23:10:52 --> Output Class Initialized
INFO - 2017-02-28 23:10:52 --> Security Class Initialized
DEBUG - 2017-02-28 23:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 23:10:52 --> Input Class Initialized
INFO - 2017-02-28 23:10:52 --> Language Class Initialized
INFO - 2017-02-28 23:10:52 --> Loader Class Initialized
INFO - 2017-02-28 23:10:53 --> Database Driver Class Initialized
INFO - 2017-02-28 23:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 23:10:53 --> Controller Class Initialized
INFO - 2017-02-28 23:10:53 --> Helper loaded: url_helper
DEBUG - 2017-02-28 23:10:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 23:10:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 23:10:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 23:10:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 23:10:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 23:10:53 --> Final output sent to browser
DEBUG - 2017-02-28 23:10:53 --> Total execution time: 1.5362
INFO - 2017-02-28 23:48:24 --> Config Class Initialized
INFO - 2017-02-28 23:48:24 --> Hooks Class Initialized
DEBUG - 2017-02-28 23:48:24 --> UTF-8 Support Enabled
INFO - 2017-02-28 23:48:24 --> Utf8 Class Initialized
INFO - 2017-02-28 23:48:24 --> URI Class Initialized
DEBUG - 2017-02-28 23:48:24 --> No URI present. Default controller set.
INFO - 2017-02-28 23:48:24 --> Router Class Initialized
INFO - 2017-02-28 23:48:24 --> Output Class Initialized
INFO - 2017-02-28 23:48:24 --> Security Class Initialized
DEBUG - 2017-02-28 23:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 23:48:25 --> Input Class Initialized
INFO - 2017-02-28 23:48:25 --> Language Class Initialized
INFO - 2017-02-28 23:48:25 --> Loader Class Initialized
INFO - 2017-02-28 23:48:25 --> Database Driver Class Initialized
INFO - 2017-02-28 23:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 23:48:26 --> Controller Class Initialized
INFO - 2017-02-28 23:48:26 --> Helper loaded: url_helper
DEBUG - 2017-02-28 23:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 23:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 23:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 23:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 23:48:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 23:48:26 --> Final output sent to browser
DEBUG - 2017-02-28 23:48:26 --> Total execution time: 1.7826
INFO - 2017-02-28 23:48:30 --> Config Class Initialized
INFO - 2017-02-28 23:48:30 --> Hooks Class Initialized
DEBUG - 2017-02-28 23:48:30 --> UTF-8 Support Enabled
INFO - 2017-02-28 23:48:30 --> Utf8 Class Initialized
INFO - 2017-02-28 23:48:30 --> URI Class Initialized
INFO - 2017-02-28 23:48:30 --> Router Class Initialized
INFO - 2017-02-28 23:48:30 --> Output Class Initialized
INFO - 2017-02-28 23:48:30 --> Security Class Initialized
DEBUG - 2017-02-28 23:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 23:48:30 --> Input Class Initialized
INFO - 2017-02-28 23:48:30 --> Language Class Initialized
INFO - 2017-02-28 23:48:30 --> Loader Class Initialized
INFO - 2017-02-28 23:48:31 --> Database Driver Class Initialized
INFO - 2017-02-28 23:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 23:48:31 --> Controller Class Initialized
INFO - 2017-02-28 23:48:31 --> Helper loaded: url_helper
DEBUG - 2017-02-28 23:48:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 23:48:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 23:48:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 23:48:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 23:48:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 23:48:31 --> Final output sent to browser
DEBUG - 2017-02-28 23:48:31 --> Total execution time: 1.2390
INFO - 2017-02-28 23:50:36 --> Config Class Initialized
INFO - 2017-02-28 23:50:36 --> Hooks Class Initialized
DEBUG - 2017-02-28 23:50:36 --> UTF-8 Support Enabled
INFO - 2017-02-28 23:50:36 --> Utf8 Class Initialized
INFO - 2017-02-28 23:50:36 --> URI Class Initialized
INFO - 2017-02-28 23:50:36 --> Router Class Initialized
INFO - 2017-02-28 23:50:36 --> Output Class Initialized
INFO - 2017-02-28 23:50:36 --> Security Class Initialized
DEBUG - 2017-02-28 23:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 23:50:37 --> Input Class Initialized
INFO - 2017-02-28 23:50:37 --> Language Class Initialized
INFO - 2017-02-28 23:50:37 --> Loader Class Initialized
INFO - 2017-02-28 23:50:37 --> Database Driver Class Initialized
INFO - 2017-02-28 23:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 23:50:37 --> Controller Class Initialized
INFO - 2017-02-28 23:50:37 --> Helper loaded: url_helper
DEBUG - 2017-02-28 23:50:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 23:50:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 23:50:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 23:50:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 23:50:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 23:50:37 --> Final output sent to browser
DEBUG - 2017-02-28 23:50:37 --> Total execution time: 1.5677
INFO - 2017-02-28 23:50:39 --> Config Class Initialized
INFO - 2017-02-28 23:50:39 --> Hooks Class Initialized
DEBUG - 2017-02-28 23:50:39 --> UTF-8 Support Enabled
INFO - 2017-02-28 23:50:39 --> Utf8 Class Initialized
INFO - 2017-02-28 23:50:39 --> URI Class Initialized
INFO - 2017-02-28 23:50:39 --> Router Class Initialized
INFO - 2017-02-28 23:50:39 --> Output Class Initialized
INFO - 2017-02-28 23:50:39 --> Security Class Initialized
DEBUG - 2017-02-28 23:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 23:50:39 --> Input Class Initialized
INFO - 2017-02-28 23:50:39 --> Language Class Initialized
INFO - 2017-02-28 23:50:39 --> Loader Class Initialized
INFO - 2017-02-28 23:50:39 --> Database Driver Class Initialized
INFO - 2017-02-28 23:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 23:50:39 --> Controller Class Initialized
INFO - 2017-02-28 23:50:39 --> Helper loaded: url_helper
DEBUG - 2017-02-28 23:50:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 23:50:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 23:50:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 23:50:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 23:50:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 23:50:39 --> Final output sent to browser
DEBUG - 2017-02-28 23:50:39 --> Total execution time: 0.0197
INFO - 2017-02-28 23:51:23 --> Config Class Initialized
INFO - 2017-02-28 23:51:24 --> Hooks Class Initialized
DEBUG - 2017-02-28 23:51:24 --> UTF-8 Support Enabled
INFO - 2017-02-28 23:51:24 --> Utf8 Class Initialized
INFO - 2017-02-28 23:51:24 --> URI Class Initialized
INFO - 2017-02-28 23:51:24 --> Router Class Initialized
INFO - 2017-02-28 23:51:24 --> Output Class Initialized
INFO - 2017-02-28 23:51:24 --> Security Class Initialized
DEBUG - 2017-02-28 23:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 23:51:24 --> Input Class Initialized
INFO - 2017-02-28 23:51:24 --> Language Class Initialized
INFO - 2017-02-28 23:51:24 --> Loader Class Initialized
INFO - 2017-02-28 23:51:24 --> Database Driver Class Initialized
INFO - 2017-02-28 23:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 23:51:25 --> Controller Class Initialized
INFO - 2017-02-28 23:51:25 --> Helper loaded: url_helper
DEBUG - 2017-02-28 23:51:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 23:51:25 --> Config Class Initialized
INFO - 2017-02-28 23:51:25 --> Hooks Class Initialized
DEBUG - 2017-02-28 23:51:25 --> UTF-8 Support Enabled
INFO - 2017-02-28 23:51:25 --> Utf8 Class Initialized
INFO - 2017-02-28 23:51:25 --> URI Class Initialized
INFO - 2017-02-28 23:51:25 --> Router Class Initialized
INFO - 2017-02-28 23:51:25 --> Output Class Initialized
INFO - 2017-02-28 23:51:25 --> Security Class Initialized
DEBUG - 2017-02-28 23:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 23:51:25 --> Input Class Initialized
INFO - 2017-02-28 23:51:25 --> Language Class Initialized
INFO - 2017-02-28 23:51:25 --> Loader Class Initialized
INFO - 2017-02-28 23:51:25 --> Database Driver Class Initialized
INFO - 2017-02-28 23:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 23:51:25 --> Controller Class Initialized
INFO - 2017-02-28 23:51:25 --> Helper loaded: date_helper
DEBUG - 2017-02-28 23:51:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 23:51:25 --> Helper loaded: url_helper
INFO - 2017-02-28 23:51:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 23:51:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 23:51:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-28 23:51:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-28 23:51:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 23:51:25 --> Final output sent to browser
DEBUG - 2017-02-28 23:51:25 --> Total execution time: 0.1918
INFO - 2017-02-28 23:51:27 --> Config Class Initialized
INFO - 2017-02-28 23:51:27 --> Hooks Class Initialized
DEBUG - 2017-02-28 23:51:27 --> UTF-8 Support Enabled
INFO - 2017-02-28 23:51:27 --> Utf8 Class Initialized
INFO - 2017-02-28 23:51:27 --> URI Class Initialized
INFO - 2017-02-28 23:51:27 --> Router Class Initialized
INFO - 2017-02-28 23:51:27 --> Output Class Initialized
INFO - 2017-02-28 23:51:27 --> Security Class Initialized
DEBUG - 2017-02-28 23:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 23:51:27 --> Input Class Initialized
INFO - 2017-02-28 23:51:27 --> Language Class Initialized
INFO - 2017-02-28 23:51:27 --> Loader Class Initialized
INFO - 2017-02-28 23:51:27 --> Database Driver Class Initialized
INFO - 2017-02-28 23:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 23:51:27 --> Controller Class Initialized
INFO - 2017-02-28 23:51:27 --> Helper loaded: url_helper
DEBUG - 2017-02-28 23:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 23:51:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 23:51:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 23:51:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 23:51:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 23:51:27 --> Final output sent to browser
DEBUG - 2017-02-28 23:51:27 --> Total execution time: 0.0471
INFO - 2017-02-28 23:51:30 --> Config Class Initialized
INFO - 2017-02-28 23:51:30 --> Hooks Class Initialized
DEBUG - 2017-02-28 23:51:30 --> UTF-8 Support Enabled
INFO - 2017-02-28 23:51:30 --> Utf8 Class Initialized
INFO - 2017-02-28 23:51:30 --> URI Class Initialized
INFO - 2017-02-28 23:51:30 --> Router Class Initialized
INFO - 2017-02-28 23:51:30 --> Output Class Initialized
INFO - 2017-02-28 23:51:30 --> Security Class Initialized
DEBUG - 2017-02-28 23:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 23:51:30 --> Input Class Initialized
INFO - 2017-02-28 23:51:30 --> Language Class Initialized
INFO - 2017-02-28 23:51:30 --> Loader Class Initialized
INFO - 2017-02-28 23:51:30 --> Database Driver Class Initialized
INFO - 2017-02-28 23:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 23:51:31 --> Controller Class Initialized
INFO - 2017-02-28 23:51:31 --> Helper loaded: date_helper
DEBUG - 2017-02-28 23:51:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 23:51:31 --> Helper loaded: url_helper
INFO - 2017-02-28 23:51:31 --> Helper loaded: download_helper
INFO - 2017-02-28 23:51:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 23:51:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 23:51:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-28 23:51:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-28 23:51:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 23:51:31 --> Final output sent to browser
DEBUG - 2017-02-28 23:51:31 --> Total execution time: 0.6930
INFO - 2017-02-28 23:51:32 --> Config Class Initialized
INFO - 2017-02-28 23:51:32 --> Hooks Class Initialized
DEBUG - 2017-02-28 23:51:32 --> UTF-8 Support Enabled
INFO - 2017-02-28 23:51:32 --> Utf8 Class Initialized
INFO - 2017-02-28 23:51:32 --> URI Class Initialized
INFO - 2017-02-28 23:51:32 --> Router Class Initialized
INFO - 2017-02-28 23:51:32 --> Output Class Initialized
INFO - 2017-02-28 23:51:32 --> Security Class Initialized
DEBUG - 2017-02-28 23:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 23:51:32 --> Input Class Initialized
INFO - 2017-02-28 23:51:32 --> Language Class Initialized
INFO - 2017-02-28 23:51:32 --> Loader Class Initialized
INFO - 2017-02-28 23:51:32 --> Database Driver Class Initialized
INFO - 2017-02-28 23:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 23:51:32 --> Controller Class Initialized
INFO - 2017-02-28 23:51:32 --> Helper loaded: url_helper
DEBUG - 2017-02-28 23:51:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 23:51:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 23:51:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 23:51:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 23:51:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 23:51:32 --> Final output sent to browser
DEBUG - 2017-02-28 23:51:32 --> Total execution time: 0.0141
INFO - 2017-02-28 23:52:39 --> Config Class Initialized
INFO - 2017-02-28 23:52:39 --> Hooks Class Initialized
DEBUG - 2017-02-28 23:52:39 --> UTF-8 Support Enabled
INFO - 2017-02-28 23:52:39 --> Utf8 Class Initialized
INFO - 2017-02-28 23:52:39 --> URI Class Initialized
INFO - 2017-02-28 23:52:39 --> Router Class Initialized
INFO - 2017-02-28 23:52:40 --> Output Class Initialized
INFO - 2017-02-28 23:52:40 --> Security Class Initialized
DEBUG - 2017-02-28 23:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 23:52:40 --> Input Class Initialized
INFO - 2017-02-28 23:52:40 --> Language Class Initialized
INFO - 2017-02-28 23:52:40 --> Loader Class Initialized
INFO - 2017-02-28 23:52:40 --> Database Driver Class Initialized
INFO - 2017-02-28 23:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 23:52:40 --> Controller Class Initialized
INFO - 2017-02-28 23:52:40 --> Helper loaded: date_helper
DEBUG - 2017-02-28 23:52:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 23:52:40 --> Helper loaded: url_helper
INFO - 2017-02-28 23:52:40 --> Helper loaded: download_helper
INFO - 2017-02-28 23:52:40 --> Final output sent to browser
DEBUG - 2017-02-28 23:52:40 --> Total execution time: 1.2969
INFO - 2017-02-28 23:52:42 --> Config Class Initialized
INFO - 2017-02-28 23:52:42 --> Hooks Class Initialized
DEBUG - 2017-02-28 23:52:42 --> UTF-8 Support Enabled
INFO - 2017-02-28 23:52:42 --> Utf8 Class Initialized
INFO - 2017-02-28 23:52:42 --> URI Class Initialized
INFO - 2017-02-28 23:52:42 --> Router Class Initialized
INFO - 2017-02-28 23:52:42 --> Output Class Initialized
INFO - 2017-02-28 23:52:42 --> Security Class Initialized
DEBUG - 2017-02-28 23:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 23:52:42 --> Input Class Initialized
INFO - 2017-02-28 23:52:42 --> Language Class Initialized
INFO - 2017-02-28 23:52:42 --> Loader Class Initialized
INFO - 2017-02-28 23:52:42 --> Database Driver Class Initialized
INFO - 2017-02-28 23:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 23:52:42 --> Controller Class Initialized
INFO - 2017-02-28 23:52:42 --> Helper loaded: date_helper
DEBUG - 2017-02-28 23:52:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 23:52:42 --> Helper loaded: url_helper
INFO - 2017-02-28 23:52:42 --> Helper loaded: download_helper
INFO - 2017-02-28 23:52:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 23:52:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-28 23:52:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-28 23:52:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-28 23:52:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 23:52:42 --> Final output sent to browser
DEBUG - 2017-02-28 23:52:42 --> Total execution time: 0.1021
INFO - 2017-02-28 23:52:43 --> Config Class Initialized
INFO - 2017-02-28 23:52:44 --> Hooks Class Initialized
DEBUG - 2017-02-28 23:52:44 --> UTF-8 Support Enabled
INFO - 2017-02-28 23:52:44 --> Utf8 Class Initialized
INFO - 2017-02-28 23:52:44 --> URI Class Initialized
INFO - 2017-02-28 23:52:44 --> Router Class Initialized
INFO - 2017-02-28 23:52:44 --> Output Class Initialized
INFO - 2017-02-28 23:52:44 --> Security Class Initialized
DEBUG - 2017-02-28 23:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 23:52:44 --> Input Class Initialized
INFO - 2017-02-28 23:52:44 --> Language Class Initialized
INFO - 2017-02-28 23:52:44 --> Loader Class Initialized
INFO - 2017-02-28 23:52:44 --> Database Driver Class Initialized
INFO - 2017-02-28 23:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 23:52:44 --> Controller Class Initialized
INFO - 2017-02-28 23:52:44 --> Helper loaded: url_helper
DEBUG - 2017-02-28 23:52:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 23:52:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 23:52:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 23:52:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 23:52:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 23:52:44 --> Final output sent to browser
DEBUG - 2017-02-28 23:52:44 --> Total execution time: 0.7863
INFO - 2017-02-28 23:53:17 --> Config Class Initialized
INFO - 2017-02-28 23:53:17 --> Hooks Class Initialized
DEBUG - 2017-02-28 23:53:17 --> UTF-8 Support Enabled
INFO - 2017-02-28 23:53:17 --> Utf8 Class Initialized
INFO - 2017-02-28 23:53:17 --> URI Class Initialized
INFO - 2017-02-28 23:53:17 --> Router Class Initialized
INFO - 2017-02-28 23:53:17 --> Output Class Initialized
INFO - 2017-02-28 23:53:18 --> Security Class Initialized
DEBUG - 2017-02-28 23:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 23:53:18 --> Input Class Initialized
INFO - 2017-02-28 23:53:18 --> Language Class Initialized
INFO - 2017-02-28 23:53:18 --> Loader Class Initialized
INFO - 2017-02-28 23:53:18 --> Database Driver Class Initialized
INFO - 2017-02-28 23:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 23:53:18 --> Controller Class Initialized
INFO - 2017-02-28 23:53:18 --> Helper loaded: url_helper
DEBUG - 2017-02-28 23:53:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 23:53:31 --> Config Class Initialized
INFO - 2017-02-28 23:53:31 --> Config Class Initialized
INFO - 2017-02-28 23:53:31 --> Hooks Class Initialized
INFO - 2017-02-28 23:53:31 --> Hooks Class Initialized
DEBUG - 2017-02-28 23:53:32 --> UTF-8 Support Enabled
DEBUG - 2017-02-28 23:53:32 --> UTF-8 Support Enabled
INFO - 2017-02-28 23:53:32 --> Utf8 Class Initialized
INFO - 2017-02-28 23:53:32 --> Utf8 Class Initialized
INFO - 2017-02-28 23:53:32 --> URI Class Initialized
INFO - 2017-02-28 23:53:32 --> URI Class Initialized
INFO - 2017-02-28 23:53:32 --> Router Class Initialized
DEBUG - 2017-02-28 23:53:32 --> No URI present. Default controller set.
INFO - 2017-02-28 23:53:32 --> Router Class Initialized
INFO - 2017-02-28 23:53:32 --> Output Class Initialized
INFO - 2017-02-28 23:53:32 --> Output Class Initialized
INFO - 2017-02-28 23:53:32 --> Security Class Initialized
INFO - 2017-02-28 23:53:32 --> Security Class Initialized
DEBUG - 2017-02-28 23:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 23:53:32 --> Input Class Initialized
INFO - 2017-02-28 23:53:32 --> Language Class Initialized
DEBUG - 2017-02-28 23:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 23:53:32 --> Input Class Initialized
INFO - 2017-02-28 23:53:32 --> Language Class Initialized
INFO - 2017-02-28 23:53:32 --> Loader Class Initialized
INFO - 2017-02-28 23:53:32 --> Loader Class Initialized
INFO - 2017-02-28 23:53:32 --> Database Driver Class Initialized
INFO - 2017-02-28 23:53:32 --> Database Driver Class Initialized
INFO - 2017-02-28 23:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 23:53:33 --> Controller Class Initialized
INFO - 2017-02-28 23:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 23:53:33 --> Controller Class Initialized
INFO - 2017-02-28 23:53:33 --> Helper loaded: url_helper
INFO - 2017-02-28 23:53:33 --> Helper loaded: url_helper
DEBUG - 2017-02-28 23:53:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-02-28 23:53:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 23:53:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 23:53:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 23:53:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 23:53:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 23:53:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 23:53:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 23:53:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 23:53:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 23:53:33 --> Final output sent to browser
DEBUG - 2017-02-28 23:53:33 --> Total execution time: 1.8682
INFO - 2017-02-28 23:53:33 --> Final output sent to browser
DEBUG - 2017-02-28 23:53:33 --> Total execution time: 1.8681
INFO - 2017-02-28 23:53:34 --> Config Class Initialized
INFO - 2017-02-28 23:53:34 --> Hooks Class Initialized
DEBUG - 2017-02-28 23:53:34 --> UTF-8 Support Enabled
INFO - 2017-02-28 23:53:34 --> Utf8 Class Initialized
INFO - 2017-02-28 23:53:34 --> URI Class Initialized
INFO - 2017-02-28 23:53:34 --> Router Class Initialized
INFO - 2017-02-28 23:53:34 --> Output Class Initialized
INFO - 2017-02-28 23:53:34 --> Security Class Initialized
DEBUG - 2017-02-28 23:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 23:53:34 --> Input Class Initialized
INFO - 2017-02-28 23:53:34 --> Language Class Initialized
INFO - 2017-02-28 23:53:34 --> Loader Class Initialized
INFO - 2017-02-28 23:53:34 --> Database Driver Class Initialized
INFO - 2017-02-28 23:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 23:53:34 --> Controller Class Initialized
INFO - 2017-02-28 23:53:34 --> Helper loaded: url_helper
DEBUG - 2017-02-28 23:53:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 23:53:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 23:53:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 23:53:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 23:53:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 23:53:34 --> Final output sent to browser
DEBUG - 2017-02-28 23:53:34 --> Total execution time: 0.0140
INFO - 2017-02-28 23:53:48 --> Config Class Initialized
INFO - 2017-02-28 23:53:48 --> Hooks Class Initialized
DEBUG - 2017-02-28 23:53:48 --> UTF-8 Support Enabled
INFO - 2017-02-28 23:53:48 --> Utf8 Class Initialized
INFO - 2017-02-28 23:53:48 --> URI Class Initialized
INFO - 2017-02-28 23:53:49 --> Router Class Initialized
INFO - 2017-02-28 23:53:49 --> Output Class Initialized
INFO - 2017-02-28 23:53:49 --> Security Class Initialized
DEBUG - 2017-02-28 23:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 23:53:49 --> Input Class Initialized
INFO - 2017-02-28 23:53:49 --> Language Class Initialized
INFO - 2017-02-28 23:53:49 --> Loader Class Initialized
INFO - 2017-02-28 23:53:49 --> Database Driver Class Initialized
INFO - 2017-02-28 23:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 23:53:50 --> Controller Class Initialized
INFO - 2017-02-28 23:53:50 --> Helper loaded: url_helper
DEBUG - 2017-02-28 23:53:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 23:53:50 --> Helper loaded: form_helper
INFO - 2017-02-28 23:53:51 --> Form Validation Class Initialized
INFO - 2017-02-28 23:53:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-02-28 23:53:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-02-28 23:53:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-02-28 23:53:52 --> Final output sent to browser
DEBUG - 2017-02-28 23:53:52 --> Total execution time: 3.6219
INFO - 2017-02-28 23:53:54 --> Config Class Initialized
INFO - 2017-02-28 23:53:54 --> Hooks Class Initialized
DEBUG - 2017-02-28 23:53:54 --> UTF-8 Support Enabled
INFO - 2017-02-28 23:53:54 --> Utf8 Class Initialized
INFO - 2017-02-28 23:53:54 --> URI Class Initialized
INFO - 2017-02-28 23:53:54 --> Router Class Initialized
INFO - 2017-02-28 23:53:54 --> Output Class Initialized
INFO - 2017-02-28 23:53:54 --> Security Class Initialized
DEBUG - 2017-02-28 23:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 23:53:54 --> Input Class Initialized
INFO - 2017-02-28 23:53:54 --> Language Class Initialized
INFO - 2017-02-28 23:53:55 --> Loader Class Initialized
INFO - 2017-02-28 23:53:55 --> Database Driver Class Initialized
INFO - 2017-02-28 23:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 23:53:55 --> Controller Class Initialized
INFO - 2017-02-28 23:53:55 --> Helper loaded: url_helper
DEBUG - 2017-02-28 23:53:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-28 23:53:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-28 23:53:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-28 23:53:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-28 23:53:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-28 23:53:55 --> Final output sent to browser
DEBUG - 2017-02-28 23:53:55 --> Total execution time: 1.2605

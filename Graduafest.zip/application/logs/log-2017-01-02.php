<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-02 00:40:20 --> Config Class Initialized
INFO - 2017-01-02 00:40:20 --> Hooks Class Initialized
DEBUG - 2017-01-02 00:40:20 --> UTF-8 Support Enabled
INFO - 2017-01-02 00:40:20 --> Utf8 Class Initialized
INFO - 2017-01-02 00:40:20 --> URI Class Initialized
DEBUG - 2017-01-02 00:40:20 --> No URI present. Default controller set.
INFO - 2017-01-02 00:40:20 --> Router Class Initialized
INFO - 2017-01-02 00:40:20 --> Output Class Initialized
INFO - 2017-01-02 00:40:20 --> Security Class Initialized
DEBUG - 2017-01-02 00:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 00:40:20 --> Input Class Initialized
INFO - 2017-01-02 00:40:20 --> Language Class Initialized
INFO - 2017-01-02 00:40:20 --> Loader Class Initialized
INFO - 2017-01-02 00:40:21 --> Database Driver Class Initialized
INFO - 2017-01-02 00:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 00:40:21 --> Controller Class Initialized
INFO - 2017-01-02 00:40:21 --> Helper loaded: url_helper
DEBUG - 2017-01-02 00:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 00:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 00:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 00:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 00:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 00:40:21 --> Final output sent to browser
DEBUG - 2017-01-02 00:40:21 --> Total execution time: 1.6211
INFO - 2017-01-02 17:23:40 --> Config Class Initialized
INFO - 2017-01-02 17:23:41 --> Hooks Class Initialized
DEBUG - 2017-01-02 17:23:41 --> UTF-8 Support Enabled
INFO - 2017-01-02 17:23:41 --> Utf8 Class Initialized
INFO - 2017-01-02 17:23:41 --> URI Class Initialized
DEBUG - 2017-01-02 17:23:41 --> No URI present. Default controller set.
INFO - 2017-01-02 17:23:41 --> Router Class Initialized
INFO - 2017-01-02 17:23:41 --> Output Class Initialized
INFO - 2017-01-02 17:23:41 --> Security Class Initialized
DEBUG - 2017-01-02 17:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 17:23:41 --> Input Class Initialized
INFO - 2017-01-02 17:23:41 --> Language Class Initialized
INFO - 2017-01-02 17:23:41 --> Loader Class Initialized
INFO - 2017-01-02 17:23:42 --> Database Driver Class Initialized
INFO - 2017-01-02 17:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 17:23:42 --> Controller Class Initialized
INFO - 2017-01-02 17:23:42 --> Helper loaded: url_helper
DEBUG - 2017-01-02 17:23:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 17:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 17:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 17:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 17:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 17:23:42 --> Final output sent to browser
DEBUG - 2017-01-02 17:23:42 --> Total execution time: 1.7677
INFO - 2017-01-02 17:23:43 --> Config Class Initialized
INFO - 2017-01-02 17:23:43 --> Hooks Class Initialized
DEBUG - 2017-01-02 17:23:43 --> UTF-8 Support Enabled
INFO - 2017-01-02 17:23:43 --> Utf8 Class Initialized
INFO - 2017-01-02 17:23:43 --> URI Class Initialized
INFO - 2017-01-02 17:23:43 --> Router Class Initialized
INFO - 2017-01-02 17:23:43 --> Output Class Initialized
INFO - 2017-01-02 17:23:43 --> Security Class Initialized
DEBUG - 2017-01-02 17:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 17:23:43 --> Input Class Initialized
INFO - 2017-01-02 17:23:43 --> Language Class Initialized
INFO - 2017-01-02 17:23:43 --> Loader Class Initialized
INFO - 2017-01-02 17:23:43 --> Database Driver Class Initialized
INFO - 2017-01-02 17:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 17:23:43 --> Controller Class Initialized
INFO - 2017-01-02 17:23:43 --> Helper loaded: url_helper
DEBUG - 2017-01-02 17:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 17:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 17:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 17:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 17:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 17:23:43 --> Final output sent to browser
DEBUG - 2017-01-02 17:23:43 --> Total execution time: 0.0141
INFO - 2017-01-02 17:23:43 --> Config Class Initialized
INFO - 2017-01-02 17:23:43 --> Hooks Class Initialized
DEBUG - 2017-01-02 17:23:43 --> UTF-8 Support Enabled
INFO - 2017-01-02 17:23:43 --> Utf8 Class Initialized
INFO - 2017-01-02 17:23:43 --> URI Class Initialized
INFO - 2017-01-02 17:23:43 --> Router Class Initialized
INFO - 2017-01-02 17:23:43 --> Output Class Initialized
INFO - 2017-01-02 17:23:43 --> Security Class Initialized
DEBUG - 2017-01-02 17:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 17:23:43 --> Input Class Initialized
INFO - 2017-01-02 17:23:43 --> Language Class Initialized
INFO - 2017-01-02 17:23:43 --> Loader Class Initialized
INFO - 2017-01-02 17:23:43 --> Database Driver Class Initialized
INFO - 2017-01-02 17:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 17:23:43 --> Controller Class Initialized
INFO - 2017-01-02 17:23:43 --> Helper loaded: url_helper
DEBUG - 2017-01-02 17:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 17:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 17:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 17:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 17:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 17:23:43 --> Final output sent to browser
DEBUG - 2017-01-02 17:23:43 --> Total execution time: 0.0149
INFO - 2017-01-02 17:23:43 --> Config Class Initialized
INFO - 2017-01-02 17:23:43 --> Hooks Class Initialized
DEBUG - 2017-01-02 17:23:43 --> UTF-8 Support Enabled
INFO - 2017-01-02 17:23:43 --> Utf8 Class Initialized
INFO - 2017-01-02 17:23:43 --> URI Class Initialized
INFO - 2017-01-02 17:23:43 --> Router Class Initialized
INFO - 2017-01-02 17:23:43 --> Output Class Initialized
INFO - 2017-01-02 17:23:43 --> Security Class Initialized
DEBUG - 2017-01-02 17:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 17:23:43 --> Input Class Initialized
INFO - 2017-01-02 17:23:43 --> Language Class Initialized
INFO - 2017-01-02 17:23:43 --> Loader Class Initialized
INFO - 2017-01-02 17:23:43 --> Database Driver Class Initialized
INFO - 2017-01-02 17:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 17:23:43 --> Controller Class Initialized
INFO - 2017-01-02 17:23:43 --> Helper loaded: url_helper
DEBUG - 2017-01-02 17:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 17:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 17:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 17:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 17:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 17:23:43 --> Final output sent to browser
DEBUG - 2017-01-02 17:23:43 --> Total execution time: 0.0149
INFO - 2017-01-02 17:23:43 --> Config Class Initialized
INFO - 2017-01-02 17:23:43 --> Hooks Class Initialized
DEBUG - 2017-01-02 17:23:43 --> UTF-8 Support Enabled
INFO - 2017-01-02 17:23:43 --> Utf8 Class Initialized
INFO - 2017-01-02 17:23:43 --> URI Class Initialized
INFO - 2017-01-02 17:23:43 --> Router Class Initialized
INFO - 2017-01-02 17:23:43 --> Output Class Initialized
INFO - 2017-01-02 17:23:43 --> Security Class Initialized
DEBUG - 2017-01-02 17:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 17:23:43 --> Input Class Initialized
INFO - 2017-01-02 17:23:43 --> Language Class Initialized
INFO - 2017-01-02 17:23:43 --> Loader Class Initialized
INFO - 2017-01-02 17:23:43 --> Database Driver Class Initialized
INFO - 2017-01-02 17:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 17:23:43 --> Controller Class Initialized
INFO - 2017-01-02 17:23:43 --> Helper loaded: url_helper
DEBUG - 2017-01-02 17:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 17:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 17:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 17:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 17:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 17:23:43 --> Final output sent to browser
DEBUG - 2017-01-02 17:23:43 --> Total execution time: 0.0141
INFO - 2017-01-02 17:23:44 --> Config Class Initialized
INFO - 2017-01-02 17:23:44 --> Hooks Class Initialized
DEBUG - 2017-01-02 17:23:44 --> UTF-8 Support Enabled
INFO - 2017-01-02 17:23:44 --> Utf8 Class Initialized
INFO - 2017-01-02 17:23:44 --> URI Class Initialized
INFO - 2017-01-02 17:23:44 --> Router Class Initialized
INFO - 2017-01-02 17:23:44 --> Output Class Initialized
INFO - 2017-01-02 17:23:44 --> Security Class Initialized
DEBUG - 2017-01-02 17:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 17:23:44 --> Input Class Initialized
INFO - 2017-01-02 17:23:44 --> Language Class Initialized
INFO - 2017-01-02 17:23:44 --> Loader Class Initialized
INFO - 2017-01-02 17:23:44 --> Database Driver Class Initialized
INFO - 2017-01-02 17:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 17:23:44 --> Controller Class Initialized
INFO - 2017-01-02 17:23:44 --> Helper loaded: url_helper
DEBUG - 2017-01-02 17:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 17:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 17:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 17:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 17:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 17:23:44 --> Final output sent to browser
DEBUG - 2017-01-02 17:23:44 --> Total execution time: 0.0142
INFO - 2017-01-02 17:23:44 --> Config Class Initialized
INFO - 2017-01-02 17:23:44 --> Hooks Class Initialized
DEBUG - 2017-01-02 17:23:44 --> UTF-8 Support Enabled
INFO - 2017-01-02 17:23:44 --> Utf8 Class Initialized
INFO - 2017-01-02 17:23:44 --> URI Class Initialized
INFO - 2017-01-02 17:23:44 --> Router Class Initialized
INFO - 2017-01-02 17:23:44 --> Output Class Initialized
INFO - 2017-01-02 17:23:44 --> Security Class Initialized
DEBUG - 2017-01-02 17:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 17:23:44 --> Input Class Initialized
INFO - 2017-01-02 17:23:44 --> Language Class Initialized
INFO - 2017-01-02 17:23:44 --> Loader Class Initialized
INFO - 2017-01-02 17:23:44 --> Database Driver Class Initialized
INFO - 2017-01-02 17:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 17:23:44 --> Controller Class Initialized
INFO - 2017-01-02 17:23:44 --> Helper loaded: url_helper
DEBUG - 2017-01-02 17:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 17:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 17:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 17:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 17:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 17:23:44 --> Final output sent to browser
DEBUG - 2017-01-02 17:23:44 --> Total execution time: 0.0156
INFO - 2017-01-02 17:23:44 --> Config Class Initialized
INFO - 2017-01-02 17:23:44 --> Hooks Class Initialized
DEBUG - 2017-01-02 17:23:44 --> UTF-8 Support Enabled
INFO - 2017-01-02 17:23:44 --> Utf8 Class Initialized
INFO - 2017-01-02 17:23:44 --> URI Class Initialized
DEBUG - 2017-01-02 17:23:44 --> No URI present. Default controller set.
INFO - 2017-01-02 17:23:44 --> Router Class Initialized
INFO - 2017-01-02 17:23:44 --> Output Class Initialized
INFO - 2017-01-02 17:23:44 --> Security Class Initialized
DEBUG - 2017-01-02 17:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 17:23:44 --> Input Class Initialized
INFO - 2017-01-02 17:23:44 --> Language Class Initialized
INFO - 2017-01-02 17:23:44 --> Loader Class Initialized
INFO - 2017-01-02 17:23:44 --> Database Driver Class Initialized
INFO - 2017-01-02 17:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 17:23:44 --> Controller Class Initialized
INFO - 2017-01-02 17:23:44 --> Helper loaded: url_helper
DEBUG - 2017-01-02 17:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 17:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 17:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 17:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 17:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 17:23:44 --> Final output sent to browser
DEBUG - 2017-01-02 17:23:44 --> Total execution time: 0.0143
INFO - 2017-01-02 17:23:44 --> Config Class Initialized
INFO - 2017-01-02 17:23:44 --> Hooks Class Initialized
DEBUG - 2017-01-02 17:23:44 --> UTF-8 Support Enabled
INFO - 2017-01-02 17:23:44 --> Utf8 Class Initialized
INFO - 2017-01-02 17:23:44 --> URI Class Initialized
INFO - 2017-01-02 17:23:44 --> Router Class Initialized
INFO - 2017-01-02 17:23:44 --> Output Class Initialized
INFO - 2017-01-02 17:23:44 --> Security Class Initialized
DEBUG - 2017-01-02 17:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 17:23:44 --> Input Class Initialized
INFO - 2017-01-02 17:23:44 --> Language Class Initialized
INFO - 2017-01-02 17:23:44 --> Loader Class Initialized
INFO - 2017-01-02 17:23:44 --> Database Driver Class Initialized
INFO - 2017-01-02 17:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 17:23:44 --> Controller Class Initialized
INFO - 2017-01-02 17:23:44 --> Helper loaded: url_helper
DEBUG - 2017-01-02 17:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 17:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 17:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 17:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 17:23:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 17:23:44 --> Final output sent to browser
DEBUG - 2017-01-02 17:23:44 --> Total execution time: 0.0201
INFO - 2017-01-02 17:23:45 --> Config Class Initialized
INFO - 2017-01-02 17:23:45 --> Hooks Class Initialized
DEBUG - 2017-01-02 17:23:45 --> UTF-8 Support Enabled
INFO - 2017-01-02 17:23:45 --> Utf8 Class Initialized
INFO - 2017-01-02 17:23:45 --> URI Class Initialized
INFO - 2017-01-02 17:23:45 --> Router Class Initialized
INFO - 2017-01-02 17:23:45 --> Output Class Initialized
INFO - 2017-01-02 17:23:45 --> Security Class Initialized
DEBUG - 2017-01-02 17:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 17:23:45 --> Input Class Initialized
INFO - 2017-01-02 17:23:45 --> Language Class Initialized
INFO - 2017-01-02 17:23:45 --> Loader Class Initialized
INFO - 2017-01-02 17:23:45 --> Database Driver Class Initialized
INFO - 2017-01-02 17:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 17:23:45 --> Controller Class Initialized
INFO - 2017-01-02 17:23:45 --> Helper loaded: url_helper
DEBUG - 2017-01-02 17:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 17:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 17:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 17:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 17:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 17:23:45 --> Final output sent to browser
DEBUG - 2017-01-02 17:23:45 --> Total execution time: 0.0139
INFO - 2017-01-02 17:23:45 --> Config Class Initialized
INFO - 2017-01-02 17:23:45 --> Hooks Class Initialized
DEBUG - 2017-01-02 17:23:45 --> UTF-8 Support Enabled
INFO - 2017-01-02 17:23:45 --> Utf8 Class Initialized
INFO - 2017-01-02 17:23:45 --> URI Class Initialized
INFO - 2017-01-02 17:23:45 --> Router Class Initialized
INFO - 2017-01-02 17:23:45 --> Output Class Initialized
INFO - 2017-01-02 17:23:45 --> Security Class Initialized
DEBUG - 2017-01-02 17:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 17:23:45 --> Input Class Initialized
INFO - 2017-01-02 17:23:45 --> Language Class Initialized
INFO - 2017-01-02 17:23:45 --> Loader Class Initialized
INFO - 2017-01-02 17:23:45 --> Database Driver Class Initialized
INFO - 2017-01-02 17:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 17:23:45 --> Controller Class Initialized
INFO - 2017-01-02 17:23:45 --> Helper loaded: url_helper
DEBUG - 2017-01-02 17:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 17:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 17:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 17:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 17:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 17:23:45 --> Final output sent to browser
DEBUG - 2017-01-02 17:23:45 --> Total execution time: 0.0130
INFO - 2017-01-02 17:23:45 --> Config Class Initialized
INFO - 2017-01-02 17:23:45 --> Hooks Class Initialized
DEBUG - 2017-01-02 17:23:45 --> UTF-8 Support Enabled
INFO - 2017-01-02 17:23:45 --> Utf8 Class Initialized
INFO - 2017-01-02 17:23:45 --> URI Class Initialized
INFO - 2017-01-02 17:23:45 --> Router Class Initialized
INFO - 2017-01-02 17:23:45 --> Output Class Initialized
INFO - 2017-01-02 17:23:45 --> Security Class Initialized
DEBUG - 2017-01-02 17:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 17:23:45 --> Input Class Initialized
INFO - 2017-01-02 17:23:45 --> Language Class Initialized
INFO - 2017-01-02 17:23:45 --> Loader Class Initialized
INFO - 2017-01-02 17:23:45 --> Database Driver Class Initialized
INFO - 2017-01-02 17:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 17:23:45 --> Controller Class Initialized
INFO - 2017-01-02 17:23:45 --> Helper loaded: url_helper
DEBUG - 2017-01-02 17:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 17:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 17:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 17:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 17:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 17:23:45 --> Final output sent to browser
DEBUG - 2017-01-02 17:23:45 --> Total execution time: 0.0147
INFO - 2017-01-02 17:23:45 --> Config Class Initialized
INFO - 2017-01-02 17:23:45 --> Hooks Class Initialized
DEBUG - 2017-01-02 17:23:45 --> UTF-8 Support Enabled
INFO - 2017-01-02 17:23:45 --> Utf8 Class Initialized
INFO - 2017-01-02 17:23:45 --> URI Class Initialized
INFO - 2017-01-02 17:23:45 --> Router Class Initialized
INFO - 2017-01-02 17:23:45 --> Output Class Initialized
INFO - 2017-01-02 17:23:45 --> Security Class Initialized
DEBUG - 2017-01-02 17:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 17:23:45 --> Input Class Initialized
INFO - 2017-01-02 17:23:45 --> Language Class Initialized
INFO - 2017-01-02 17:23:45 --> Loader Class Initialized
INFO - 2017-01-02 17:23:45 --> Database Driver Class Initialized
INFO - 2017-01-02 17:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 17:23:45 --> Controller Class Initialized
INFO - 2017-01-02 17:23:45 --> Helper loaded: url_helper
DEBUG - 2017-01-02 17:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 17:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 17:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 17:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 17:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 17:23:45 --> Final output sent to browser
DEBUG - 2017-01-02 17:23:45 --> Total execution time: 0.0587
INFO - 2017-01-02 17:23:45 --> Config Class Initialized
INFO - 2017-01-02 17:23:45 --> Hooks Class Initialized
DEBUG - 2017-01-02 17:23:45 --> UTF-8 Support Enabled
INFO - 2017-01-02 17:23:45 --> Utf8 Class Initialized
INFO - 2017-01-02 17:23:45 --> URI Class Initialized
INFO - 2017-01-02 17:23:45 --> Router Class Initialized
INFO - 2017-01-02 17:23:45 --> Output Class Initialized
INFO - 2017-01-02 17:23:45 --> Security Class Initialized
DEBUG - 2017-01-02 17:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 17:23:45 --> Input Class Initialized
INFO - 2017-01-02 17:23:45 --> Language Class Initialized
INFO - 2017-01-02 17:23:45 --> Loader Class Initialized
INFO - 2017-01-02 17:23:45 --> Database Driver Class Initialized
INFO - 2017-01-02 17:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 17:23:45 --> Controller Class Initialized
INFO - 2017-01-02 17:23:45 --> Helper loaded: url_helper
DEBUG - 2017-01-02 17:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 17:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 17:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 17:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 17:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 17:23:45 --> Final output sent to browser
DEBUG - 2017-01-02 17:23:45 --> Total execution time: 0.0155
INFO - 2017-01-02 19:51:55 --> Config Class Initialized
INFO - 2017-01-02 19:51:55 --> Hooks Class Initialized
DEBUG - 2017-01-02 19:51:55 --> UTF-8 Support Enabled
INFO - 2017-01-02 19:51:55 --> Utf8 Class Initialized
INFO - 2017-01-02 19:51:55 --> URI Class Initialized
DEBUG - 2017-01-02 19:51:55 --> No URI present. Default controller set.
INFO - 2017-01-02 19:51:55 --> Router Class Initialized
INFO - 2017-01-02 19:51:55 --> Output Class Initialized
INFO - 2017-01-02 19:51:55 --> Security Class Initialized
DEBUG - 2017-01-02 19:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 19:51:55 --> Input Class Initialized
INFO - 2017-01-02 19:51:55 --> Language Class Initialized
INFO - 2017-01-02 19:51:55 --> Loader Class Initialized
INFO - 2017-01-02 19:51:56 --> Database Driver Class Initialized
INFO - 2017-01-02 19:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 19:51:56 --> Controller Class Initialized
INFO - 2017-01-02 19:51:56 --> Helper loaded: url_helper
DEBUG - 2017-01-02 19:51:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 19:51:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 19:51:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 19:51:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 19:51:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 19:51:56 --> Final output sent to browser
DEBUG - 2017-01-02 19:51:56 --> Total execution time: 1.6301
INFO - 2017-01-02 20:06:39 --> Config Class Initialized
INFO - 2017-01-02 20:06:39 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:06:39 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:06:39 --> Utf8 Class Initialized
INFO - 2017-01-02 20:06:39 --> URI Class Initialized
DEBUG - 2017-01-02 20:06:39 --> No URI present. Default controller set.
INFO - 2017-01-02 20:06:39 --> Router Class Initialized
INFO - 2017-01-02 20:06:39 --> Output Class Initialized
INFO - 2017-01-02 20:06:39 --> Security Class Initialized
DEBUG - 2017-01-02 20:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:06:39 --> Input Class Initialized
INFO - 2017-01-02 20:06:39 --> Language Class Initialized
INFO - 2017-01-02 20:06:39 --> Loader Class Initialized
INFO - 2017-01-02 20:06:39 --> Database Driver Class Initialized
INFO - 2017-01-02 20:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:06:39 --> Controller Class Initialized
INFO - 2017-01-02 20:06:39 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:06:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:06:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:06:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:06:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:06:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:06:39 --> Final output sent to browser
DEBUG - 2017-01-02 20:06:39 --> Total execution time: 0.0186
INFO - 2017-01-02 20:06:40 --> Config Class Initialized
INFO - 2017-01-02 20:06:40 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:06:40 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:06:40 --> Utf8 Class Initialized
INFO - 2017-01-02 20:06:40 --> URI Class Initialized
INFO - 2017-01-02 20:06:40 --> Router Class Initialized
INFO - 2017-01-02 20:06:40 --> Output Class Initialized
INFO - 2017-01-02 20:06:40 --> Security Class Initialized
DEBUG - 2017-01-02 20:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:06:40 --> Input Class Initialized
INFO - 2017-01-02 20:06:40 --> Language Class Initialized
INFO - 2017-01-02 20:06:40 --> Config Class Initialized
INFO - 2017-01-02 20:06:40 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:06:40 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:06:40 --> Utf8 Class Initialized
INFO - 2017-01-02 20:06:40 --> URI Class Initialized
ERROR - 2017-01-02 20:06:40 --> 404 Page Not Found: Imagenes_portada/Galeria2.jpg
INFO - 2017-01-02 20:06:40 --> Router Class Initialized
INFO - 2017-01-02 20:06:40 --> Output Class Initialized
INFO - 2017-01-02 20:06:40 --> Security Class Initialized
DEBUG - 2017-01-02 20:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:06:40 --> Input Class Initialized
INFO - 2017-01-02 20:06:40 --> Language Class Initialized
ERROR - 2017-01-02 20:06:40 --> 404 Page Not Found: Imagenes_portada/Galeria3.jpg
INFO - 2017-01-02 20:06:40 --> Config Class Initialized
INFO - 2017-01-02 20:06:40 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:06:40 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:06:40 --> Utf8 Class Initialized
INFO - 2017-01-02 20:06:40 --> URI Class Initialized
INFO - 2017-01-02 20:06:40 --> Router Class Initialized
INFO - 2017-01-02 20:06:40 --> Config Class Initialized
INFO - 2017-01-02 20:06:40 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:06:40 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:06:40 --> Utf8 Class Initialized
INFO - 2017-01-02 20:06:40 --> URI Class Initialized
INFO - 2017-01-02 20:06:40 --> Router Class Initialized
INFO - 2017-01-02 20:06:40 --> Output Class Initialized
INFO - 2017-01-02 20:06:40 --> Output Class Initialized
INFO - 2017-01-02 20:06:40 --> Security Class Initialized
DEBUG - 2017-01-02 20:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:06:40 --> Input Class Initialized
INFO - 2017-01-02 20:06:40 --> Language Class Initialized
ERROR - 2017-01-02 20:06:40 --> 404 Page Not Found: Imagenes_portada/Galeria4.jpg
INFO - 2017-01-02 20:06:40 --> Config Class Initialized
INFO - 2017-01-02 20:06:40 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:06:40 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:06:40 --> Utf8 Class Initialized
INFO - 2017-01-02 20:06:40 --> URI Class Initialized
INFO - 2017-01-02 20:06:40 --> Router Class Initialized
INFO - 2017-01-02 20:06:40 --> Output Class Initialized
INFO - 2017-01-02 20:06:40 --> Security Class Initialized
DEBUG - 2017-01-02 20:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:06:40 --> Input Class Initialized
INFO - 2017-01-02 20:06:40 --> Language Class Initialized
ERROR - 2017-01-02 20:06:40 --> 404 Page Not Found: Imagenes_portada/Galeria5.jpg
INFO - 2017-01-02 20:06:40 --> Security Class Initialized
DEBUG - 2017-01-02 20:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:06:40 --> Input Class Initialized
INFO - 2017-01-02 20:06:40 --> Language Class Initialized
ERROR - 2017-01-02 20:06:40 --> 404 Page Not Found: Imagenes_portada/Galeria6.jpg
INFO - 2017-01-02 20:06:41 --> Config Class Initialized
INFO - 2017-01-02 20:06:41 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:06:41 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:06:41 --> Utf8 Class Initialized
INFO - 2017-01-02 20:06:41 --> URI Class Initialized
INFO - 2017-01-02 20:06:41 --> Router Class Initialized
INFO - 2017-01-02 20:06:41 --> Output Class Initialized
INFO - 2017-01-02 20:06:41 --> Security Class Initialized
DEBUG - 2017-01-02 20:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:06:41 --> Input Class Initialized
INFO - 2017-01-02 20:06:41 --> Language Class Initialized
INFO - 2017-01-02 20:06:41 --> Loader Class Initialized
INFO - 2017-01-02 20:06:41 --> Database Driver Class Initialized
INFO - 2017-01-02 20:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:06:41 --> Controller Class Initialized
INFO - 2017-01-02 20:06:41 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:06:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:06:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:06:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:06:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:06:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:06:41 --> Final output sent to browser
DEBUG - 2017-01-02 20:06:41 --> Total execution time: 0.0139
INFO - 2017-01-02 20:07:20 --> Config Class Initialized
INFO - 2017-01-02 20:07:20 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:07:20 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:07:20 --> Utf8 Class Initialized
INFO - 2017-01-02 20:07:20 --> URI Class Initialized
INFO - 2017-01-02 20:07:20 --> Router Class Initialized
INFO - 2017-01-02 20:07:20 --> Output Class Initialized
INFO - 2017-01-02 20:07:20 --> Security Class Initialized
DEBUG - 2017-01-02 20:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:07:20 --> Input Class Initialized
INFO - 2017-01-02 20:07:20 --> Language Class Initialized
INFO - 2017-01-02 20:07:20 --> Loader Class Initialized
INFO - 2017-01-02 20:07:20 --> Database Driver Class Initialized
INFO - 2017-01-02 20:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:07:20 --> Controller Class Initialized
INFO - 2017-01-02 20:07:20 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:07:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:07:21 --> Config Class Initialized
INFO - 2017-01-02 20:07:21 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:07:21 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:07:21 --> Utf8 Class Initialized
INFO - 2017-01-02 20:07:21 --> URI Class Initialized
INFO - 2017-01-02 20:07:21 --> Router Class Initialized
INFO - 2017-01-02 20:07:21 --> Output Class Initialized
INFO - 2017-01-02 20:07:21 --> Security Class Initialized
DEBUG - 2017-01-02 20:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:07:21 --> Input Class Initialized
INFO - 2017-01-02 20:07:21 --> Language Class Initialized
INFO - 2017-01-02 20:07:21 --> Loader Class Initialized
INFO - 2017-01-02 20:07:21 --> Database Driver Class Initialized
INFO - 2017-01-02 20:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:07:21 --> Controller Class Initialized
INFO - 2017-01-02 20:07:22 --> Helper loaded: date_helper
DEBUG - 2017-01-02 20:07:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:07:22 --> Helper loaded: url_helper
INFO - 2017-01-02 20:07:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:07:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-02 20:07:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-02 20:07:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-02 20:07:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:07:22 --> Final output sent to browser
DEBUG - 2017-01-02 20:07:22 --> Total execution time: 0.7681
INFO - 2017-01-02 20:07:25 --> Config Class Initialized
INFO - 2017-01-02 20:07:25 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:07:25 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:07:25 --> Utf8 Class Initialized
INFO - 2017-01-02 20:07:25 --> URI Class Initialized
INFO - 2017-01-02 20:07:25 --> Router Class Initialized
INFO - 2017-01-02 20:07:25 --> Output Class Initialized
INFO - 2017-01-02 20:07:25 --> Security Class Initialized
DEBUG - 2017-01-02 20:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:07:25 --> Input Class Initialized
INFO - 2017-01-02 20:07:25 --> Language Class Initialized
INFO - 2017-01-02 20:07:25 --> Loader Class Initialized
INFO - 2017-01-02 20:07:25 --> Database Driver Class Initialized
INFO - 2017-01-02 20:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:07:25 --> Controller Class Initialized
INFO - 2017-01-02 20:07:25 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:07:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:07:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:07:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:07:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:07:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:07:25 --> Final output sent to browser
DEBUG - 2017-01-02 20:07:25 --> Total execution time: 0.0137
INFO - 2017-01-02 20:07:26 --> Config Class Initialized
INFO - 2017-01-02 20:07:26 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:07:26 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:07:26 --> Utf8 Class Initialized
INFO - 2017-01-02 20:07:26 --> URI Class Initialized
INFO - 2017-01-02 20:07:26 --> Router Class Initialized
INFO - 2017-01-02 20:07:26 --> Output Class Initialized
INFO - 2017-01-02 20:07:26 --> Security Class Initialized
DEBUG - 2017-01-02 20:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:07:26 --> Input Class Initialized
INFO - 2017-01-02 20:07:26 --> Language Class Initialized
INFO - 2017-01-02 20:07:26 --> Loader Class Initialized
INFO - 2017-01-02 20:07:26 --> Database Driver Class Initialized
INFO - 2017-01-02 20:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:07:26 --> Controller Class Initialized
INFO - 2017-01-02 20:07:26 --> Helper loaded: date_helper
DEBUG - 2017-01-02 20:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:07:26 --> Helper loaded: url_helper
INFO - 2017-01-02 20:07:26 --> Helper loaded: download_helper
INFO - 2017-01-02 20:07:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:07:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-02 20:07:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-02 20:07:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-02 20:07:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:07:27 --> Final output sent to browser
DEBUG - 2017-01-02 20:07:27 --> Total execution time: 0.1531
INFO - 2017-01-02 20:07:27 --> Config Class Initialized
INFO - 2017-01-02 20:07:27 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:07:27 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:07:27 --> Utf8 Class Initialized
INFO - 2017-01-02 20:07:27 --> URI Class Initialized
INFO - 2017-01-02 20:07:27 --> Router Class Initialized
INFO - 2017-01-02 20:07:27 --> Output Class Initialized
INFO - 2017-01-02 20:07:27 --> Security Class Initialized
DEBUG - 2017-01-02 20:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:07:27 --> Input Class Initialized
INFO - 2017-01-02 20:07:27 --> Language Class Initialized
INFO - 2017-01-02 20:07:27 --> Loader Class Initialized
INFO - 2017-01-02 20:07:27 --> Database Driver Class Initialized
INFO - 2017-01-02 20:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:07:27 --> Controller Class Initialized
INFO - 2017-01-02 20:07:27 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:07:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:07:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:07:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:07:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:07:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:07:27 --> Final output sent to browser
DEBUG - 2017-01-02 20:07:27 --> Total execution time: 0.0138
INFO - 2017-01-02 20:07:29 --> Config Class Initialized
INFO - 2017-01-02 20:07:29 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:07:29 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:07:29 --> Utf8 Class Initialized
INFO - 2017-01-02 20:07:29 --> URI Class Initialized
INFO - 2017-01-02 20:07:29 --> Router Class Initialized
INFO - 2017-01-02 20:07:29 --> Output Class Initialized
INFO - 2017-01-02 20:07:29 --> Security Class Initialized
DEBUG - 2017-01-02 20:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:07:29 --> Input Class Initialized
INFO - 2017-01-02 20:07:29 --> Language Class Initialized
INFO - 2017-01-02 20:07:29 --> Loader Class Initialized
INFO - 2017-01-02 20:07:29 --> Database Driver Class Initialized
INFO - 2017-01-02 20:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:07:29 --> Controller Class Initialized
INFO - 2017-01-02 20:07:29 --> Helper loaded: date_helper
DEBUG - 2017-01-02 20:07:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:07:29 --> Helper loaded: url_helper
INFO - 2017-01-02 20:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-02 20:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-02 20:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-02 20:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-02 20:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:07:29 --> Final output sent to browser
DEBUG - 2017-01-02 20:07:29 --> Total execution time: 0.0584
INFO - 2017-01-02 20:07:29 --> Config Class Initialized
INFO - 2017-01-02 20:07:29 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:07:29 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:07:29 --> Utf8 Class Initialized
INFO - 2017-01-02 20:07:29 --> URI Class Initialized
INFO - 2017-01-02 20:07:29 --> Router Class Initialized
INFO - 2017-01-02 20:07:29 --> Output Class Initialized
INFO - 2017-01-02 20:07:29 --> Security Class Initialized
DEBUG - 2017-01-02 20:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:07:29 --> Input Class Initialized
INFO - 2017-01-02 20:07:29 --> Language Class Initialized
INFO - 2017-01-02 20:07:29 --> Loader Class Initialized
INFO - 2017-01-02 20:07:29 --> Database Driver Class Initialized
INFO - 2017-01-02 20:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:07:29 --> Controller Class Initialized
INFO - 2017-01-02 20:07:29 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:07:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:07:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:07:29 --> Final output sent to browser
DEBUG - 2017-01-02 20:07:29 --> Total execution time: 0.0135
INFO - 2017-01-02 20:07:31 --> Config Class Initialized
INFO - 2017-01-02 20:07:31 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:07:31 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:07:31 --> Utf8 Class Initialized
INFO - 2017-01-02 20:07:31 --> URI Class Initialized
INFO - 2017-01-02 20:07:31 --> Router Class Initialized
INFO - 2017-01-02 20:07:31 --> Output Class Initialized
INFO - 2017-01-02 20:07:31 --> Security Class Initialized
DEBUG - 2017-01-02 20:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:07:31 --> Input Class Initialized
INFO - 2017-01-02 20:07:31 --> Language Class Initialized
INFO - 2017-01-02 20:07:31 --> Loader Class Initialized
INFO - 2017-01-02 20:07:31 --> Database Driver Class Initialized
INFO - 2017-01-02 20:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:07:31 --> Controller Class Initialized
INFO - 2017-01-02 20:07:31 --> Upload Class Initialized
INFO - 2017-01-02 20:07:31 --> Helper loaded: date_helper
DEBUG - 2017-01-02 20:07:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:07:31 --> Helper loaded: url_helper
INFO - 2017-01-02 20:07:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:07:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-02 20:07:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-01-02 20:07:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-01-02 20:07:31 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-02 20:07:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:07:31 --> Final output sent to browser
DEBUG - 2017-01-02 20:07:31 --> Total execution time: 0.1212
INFO - 2017-01-02 20:07:32 --> Config Class Initialized
INFO - 2017-01-02 20:07:32 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:07:32 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:07:32 --> Utf8 Class Initialized
INFO - 2017-01-02 20:07:32 --> URI Class Initialized
INFO - 2017-01-02 20:07:32 --> Router Class Initialized
INFO - 2017-01-02 20:07:32 --> Output Class Initialized
INFO - 2017-01-02 20:07:32 --> Security Class Initialized
DEBUG - 2017-01-02 20:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:07:32 --> Input Class Initialized
INFO - 2017-01-02 20:07:32 --> Language Class Initialized
INFO - 2017-01-02 20:07:32 --> Loader Class Initialized
INFO - 2017-01-02 20:07:32 --> Database Driver Class Initialized
INFO - 2017-01-02 20:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:07:32 --> Controller Class Initialized
INFO - 2017-01-02 20:07:32 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:07:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:07:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:07:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:07:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:07:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:07:32 --> Final output sent to browser
DEBUG - 2017-01-02 20:07:32 --> Total execution time: 0.0133
INFO - 2017-01-02 20:07:54 --> Config Class Initialized
INFO - 2017-01-02 20:07:54 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:07:54 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:07:54 --> Utf8 Class Initialized
INFO - 2017-01-02 20:07:54 --> URI Class Initialized
INFO - 2017-01-02 20:07:54 --> Router Class Initialized
INFO - 2017-01-02 20:07:54 --> Output Class Initialized
INFO - 2017-01-02 20:07:54 --> Security Class Initialized
DEBUG - 2017-01-02 20:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:07:54 --> Input Class Initialized
INFO - 2017-01-02 20:07:54 --> Language Class Initialized
INFO - 2017-01-02 20:07:54 --> Loader Class Initialized
INFO - 2017-01-02 20:07:54 --> Database Driver Class Initialized
INFO - 2017-01-02 20:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:07:54 --> Controller Class Initialized
INFO - 2017-01-02 20:07:54 --> Helper loaded: date_helper
DEBUG - 2017-01-02 20:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:07:54 --> Helper loaded: url_helper
INFO - 2017-01-02 20:07:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:07:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-02 20:07:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-02 20:07:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-02 20:07:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:07:54 --> Final output sent to browser
DEBUG - 2017-01-02 20:07:54 --> Total execution time: 0.0143
INFO - 2017-01-02 20:07:55 --> Config Class Initialized
INFO - 2017-01-02 20:07:55 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:07:55 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:07:55 --> Utf8 Class Initialized
INFO - 2017-01-02 20:07:55 --> URI Class Initialized
INFO - 2017-01-02 20:07:55 --> Router Class Initialized
INFO - 2017-01-02 20:07:55 --> Output Class Initialized
INFO - 2017-01-02 20:07:55 --> Security Class Initialized
DEBUG - 2017-01-02 20:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:07:55 --> Input Class Initialized
INFO - 2017-01-02 20:07:55 --> Language Class Initialized
INFO - 2017-01-02 20:07:55 --> Loader Class Initialized
INFO - 2017-01-02 20:07:55 --> Database Driver Class Initialized
INFO - 2017-01-02 20:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:07:55 --> Controller Class Initialized
INFO - 2017-01-02 20:07:55 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:07:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:07:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:07:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:07:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:07:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:07:55 --> Final output sent to browser
DEBUG - 2017-01-02 20:07:55 --> Total execution time: 0.0138
INFO - 2017-01-02 20:08:05 --> Config Class Initialized
INFO - 2017-01-02 20:08:05 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:08:05 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:08:05 --> Utf8 Class Initialized
INFO - 2017-01-02 20:08:05 --> URI Class Initialized
INFO - 2017-01-02 20:08:05 --> Router Class Initialized
INFO - 2017-01-02 20:08:05 --> Output Class Initialized
INFO - 2017-01-02 20:08:05 --> Security Class Initialized
DEBUG - 2017-01-02 20:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:08:05 --> Input Class Initialized
INFO - 2017-01-02 20:08:05 --> Language Class Initialized
INFO - 2017-01-02 20:08:05 --> Loader Class Initialized
INFO - 2017-01-02 20:08:05 --> Database Driver Class Initialized
INFO - 2017-01-02 20:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:08:05 --> Controller Class Initialized
INFO - 2017-01-02 20:08:05 --> Helper loaded: date_helper
DEBUG - 2017-01-02 20:08:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:08:05 --> Helper loaded: url_helper
INFO - 2017-01-02 20:08:05 --> Helper loaded: download_helper
INFO - 2017-01-02 20:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-02 20:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-02 20:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-02 20:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:08:05 --> Final output sent to browser
DEBUG - 2017-01-02 20:08:05 --> Total execution time: 0.0171
INFO - 2017-01-02 20:08:05 --> Config Class Initialized
INFO - 2017-01-02 20:08:05 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:08:05 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:08:05 --> Utf8 Class Initialized
INFO - 2017-01-02 20:08:05 --> URI Class Initialized
INFO - 2017-01-02 20:08:05 --> Router Class Initialized
INFO - 2017-01-02 20:08:05 --> Output Class Initialized
INFO - 2017-01-02 20:08:05 --> Security Class Initialized
DEBUG - 2017-01-02 20:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:08:05 --> Input Class Initialized
INFO - 2017-01-02 20:08:05 --> Language Class Initialized
INFO - 2017-01-02 20:08:05 --> Loader Class Initialized
INFO - 2017-01-02 20:08:05 --> Database Driver Class Initialized
INFO - 2017-01-02 20:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:08:05 --> Controller Class Initialized
INFO - 2017-01-02 20:08:05 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:08:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:08:05 --> Final output sent to browser
DEBUG - 2017-01-02 20:08:05 --> Total execution time: 0.0130
INFO - 2017-01-02 20:08:07 --> Config Class Initialized
INFO - 2017-01-02 20:08:07 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:08:07 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:08:07 --> Utf8 Class Initialized
INFO - 2017-01-02 20:08:07 --> URI Class Initialized
INFO - 2017-01-02 20:08:07 --> Router Class Initialized
INFO - 2017-01-02 20:08:07 --> Output Class Initialized
INFO - 2017-01-02 20:08:07 --> Security Class Initialized
DEBUG - 2017-01-02 20:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:08:07 --> Input Class Initialized
INFO - 2017-01-02 20:08:07 --> Language Class Initialized
INFO - 2017-01-02 20:08:07 --> Loader Class Initialized
INFO - 2017-01-02 20:08:07 --> Database Driver Class Initialized
INFO - 2017-01-02 20:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:08:07 --> Controller Class Initialized
INFO - 2017-01-02 20:08:07 --> Helper loaded: date_helper
DEBUG - 2017-01-02 20:08:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:08:07 --> Helper loaded: url_helper
INFO - 2017-01-02 20:08:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:08:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-02 20:08:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-02 20:08:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-02 20:08:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-02 20:08:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:08:07 --> Final output sent to browser
DEBUG - 2017-01-02 20:08:07 --> Total execution time: 0.0135
INFO - 2017-01-02 20:08:07 --> Config Class Initialized
INFO - 2017-01-02 20:08:07 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:08:07 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:08:07 --> Utf8 Class Initialized
INFO - 2017-01-02 20:08:07 --> URI Class Initialized
INFO - 2017-01-02 20:08:07 --> Router Class Initialized
INFO - 2017-01-02 20:08:07 --> Output Class Initialized
INFO - 2017-01-02 20:08:07 --> Security Class Initialized
DEBUG - 2017-01-02 20:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:08:07 --> Input Class Initialized
INFO - 2017-01-02 20:08:07 --> Language Class Initialized
INFO - 2017-01-02 20:08:07 --> Loader Class Initialized
INFO - 2017-01-02 20:08:07 --> Database Driver Class Initialized
INFO - 2017-01-02 20:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:08:07 --> Controller Class Initialized
INFO - 2017-01-02 20:08:07 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:08:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:08:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:08:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:08:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:08:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:08:07 --> Final output sent to browser
DEBUG - 2017-01-02 20:08:07 --> Total execution time: 0.0148
INFO - 2017-01-02 20:08:08 --> Config Class Initialized
INFO - 2017-01-02 20:08:08 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:08:08 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:08:08 --> Utf8 Class Initialized
INFO - 2017-01-02 20:08:08 --> URI Class Initialized
INFO - 2017-01-02 20:08:08 --> Router Class Initialized
INFO - 2017-01-02 20:08:08 --> Output Class Initialized
INFO - 2017-01-02 20:08:08 --> Security Class Initialized
DEBUG - 2017-01-02 20:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:08:08 --> Input Class Initialized
INFO - 2017-01-02 20:08:08 --> Language Class Initialized
INFO - 2017-01-02 20:08:08 --> Loader Class Initialized
INFO - 2017-01-02 20:08:08 --> Database Driver Class Initialized
INFO - 2017-01-02 20:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:08:08 --> Controller Class Initialized
INFO - 2017-01-02 20:08:08 --> Helper loaded: date_helper
DEBUG - 2017-01-02 20:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:08:08 --> Helper loaded: url_helper
INFO - 2017-01-02 20:08:08 --> Helper loaded: download_helper
INFO - 2017-01-02 20:08:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:08:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-02 20:08:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-02 20:08:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-02 20:08:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:08:08 --> Final output sent to browser
DEBUG - 2017-01-02 20:08:08 --> Total execution time: 0.0169
INFO - 2017-01-02 20:08:09 --> Config Class Initialized
INFO - 2017-01-02 20:08:09 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:08:09 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:08:09 --> Utf8 Class Initialized
INFO - 2017-01-02 20:08:09 --> URI Class Initialized
INFO - 2017-01-02 20:08:09 --> Router Class Initialized
INFO - 2017-01-02 20:08:09 --> Output Class Initialized
INFO - 2017-01-02 20:08:09 --> Security Class Initialized
DEBUG - 2017-01-02 20:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:08:09 --> Input Class Initialized
INFO - 2017-01-02 20:08:09 --> Language Class Initialized
INFO - 2017-01-02 20:08:09 --> Loader Class Initialized
INFO - 2017-01-02 20:08:09 --> Database Driver Class Initialized
INFO - 2017-01-02 20:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:08:09 --> Controller Class Initialized
INFO - 2017-01-02 20:08:09 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:08:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:08:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:08:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:08:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:08:09 --> Final output sent to browser
DEBUG - 2017-01-02 20:08:09 --> Total execution time: 0.0131
INFO - 2017-01-02 20:08:16 --> Config Class Initialized
INFO - 2017-01-02 20:08:16 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:08:16 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:08:16 --> Utf8 Class Initialized
INFO - 2017-01-02 20:08:16 --> URI Class Initialized
INFO - 2017-01-02 20:08:16 --> Router Class Initialized
INFO - 2017-01-02 20:08:16 --> Output Class Initialized
INFO - 2017-01-02 20:08:16 --> Security Class Initialized
DEBUG - 2017-01-02 20:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:08:16 --> Input Class Initialized
INFO - 2017-01-02 20:08:16 --> Language Class Initialized
INFO - 2017-01-02 20:08:16 --> Loader Class Initialized
INFO - 2017-01-02 20:08:16 --> Database Driver Class Initialized
INFO - 2017-01-02 20:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:08:16 --> Controller Class Initialized
INFO - 2017-01-02 20:08:16 --> Helper loaded: date_helper
DEBUG - 2017-01-02 20:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:08:16 --> Helper loaded: url_helper
INFO - 2017-01-02 20:08:16 --> Helper loaded: download_helper
INFO - 2017-01-02 20:08:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:08:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-02 20:08:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-02 20:08:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-02 20:08:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:08:16 --> Final output sent to browser
DEBUG - 2017-01-02 20:08:16 --> Total execution time: 0.0166
INFO - 2017-01-02 20:08:16 --> Config Class Initialized
INFO - 2017-01-02 20:08:16 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:08:16 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:08:16 --> Utf8 Class Initialized
INFO - 2017-01-02 20:08:16 --> URI Class Initialized
INFO - 2017-01-02 20:08:16 --> Router Class Initialized
INFO - 2017-01-02 20:08:16 --> Output Class Initialized
INFO - 2017-01-02 20:08:16 --> Security Class Initialized
DEBUG - 2017-01-02 20:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:08:16 --> Input Class Initialized
INFO - 2017-01-02 20:08:16 --> Language Class Initialized
INFO - 2017-01-02 20:08:16 --> Loader Class Initialized
INFO - 2017-01-02 20:08:16 --> Database Driver Class Initialized
INFO - 2017-01-02 20:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:08:16 --> Controller Class Initialized
INFO - 2017-01-02 20:08:16 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:08:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:08:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:08:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:08:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:08:16 --> Final output sent to browser
DEBUG - 2017-01-02 20:08:16 --> Total execution time: 0.0137
INFO - 2017-01-02 20:12:20 --> Config Class Initialized
INFO - 2017-01-02 20:12:20 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:20 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:20 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:20 --> URI Class Initialized
INFO - 2017-01-02 20:12:20 --> Router Class Initialized
INFO - 2017-01-02 20:12:20 --> Output Class Initialized
INFO - 2017-01-02 20:12:20 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:20 --> Input Class Initialized
INFO - 2017-01-02 20:12:20 --> Language Class Initialized
INFO - 2017-01-02 20:12:20 --> Loader Class Initialized
INFO - 2017-01-02 20:12:20 --> Database Driver Class Initialized
INFO - 2017-01-02 20:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:12:20 --> Controller Class Initialized
INFO - 2017-01-02 20:12:20 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:12:20 --> Config Class Initialized
INFO - 2017-01-02 20:12:20 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:20 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:20 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:20 --> URI Class Initialized
DEBUG - 2017-01-02 20:12:20 --> No URI present. Default controller set.
INFO - 2017-01-02 20:12:20 --> Router Class Initialized
INFO - 2017-01-02 20:12:20 --> Output Class Initialized
INFO - 2017-01-02 20:12:20 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:20 --> Input Class Initialized
INFO - 2017-01-02 20:12:20 --> Language Class Initialized
INFO - 2017-01-02 20:12:20 --> Loader Class Initialized
INFO - 2017-01-02 20:12:20 --> Database Driver Class Initialized
INFO - 2017-01-02 20:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:12:20 --> Controller Class Initialized
INFO - 2017-01-02 20:12:20 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:12:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:12:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:12:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:12:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:12:20 --> Final output sent to browser
DEBUG - 2017-01-02 20:12:20 --> Total execution time: 0.0147
INFO - 2017-01-02 20:12:20 --> Config Class Initialized
INFO - 2017-01-02 20:12:20 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:20 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:20 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:20 --> URI Class Initialized
INFO - 2017-01-02 20:12:20 --> Router Class Initialized
INFO - 2017-01-02 20:12:20 --> Output Class Initialized
INFO - 2017-01-02 20:12:20 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:20 --> Input Class Initialized
INFO - 2017-01-02 20:12:20 --> Language Class Initialized
INFO - 2017-01-02 20:12:20 --> Loader Class Initialized
INFO - 2017-01-02 20:12:20 --> Database Driver Class Initialized
INFO - 2017-01-02 20:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:12:20 --> Controller Class Initialized
INFO - 2017-01-02 20:12:20 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:12:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:12:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:12:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:12:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:12:20 --> Final output sent to browser
DEBUG - 2017-01-02 20:12:20 --> Total execution time: 0.0627
INFO - 2017-01-02 20:12:21 --> Config Class Initialized
INFO - 2017-01-02 20:12:21 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:21 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:21 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:21 --> URI Class Initialized
INFO - 2017-01-02 20:12:21 --> Router Class Initialized
INFO - 2017-01-02 20:12:21 --> Output Class Initialized
INFO - 2017-01-02 20:12:21 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:21 --> Input Class Initialized
INFO - 2017-01-02 20:12:21 --> Language Class Initialized
ERROR - 2017-01-02 20:12:21 --> 404 Page Not Found: Imagenes_portada/Galeria2.jpg
INFO - 2017-01-02 20:12:21 --> Config Class Initialized
INFO - 2017-01-02 20:12:21 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:21 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:21 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:21 --> URI Class Initialized
INFO - 2017-01-02 20:12:21 --> Router Class Initialized
INFO - 2017-01-02 20:12:21 --> Output Class Initialized
INFO - 2017-01-02 20:12:21 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:21 --> Input Class Initialized
INFO - 2017-01-02 20:12:21 --> Language Class Initialized
ERROR - 2017-01-02 20:12:21 --> 404 Page Not Found: Imagenes_portada/Galeria3.jpg
INFO - 2017-01-02 20:12:21 --> Config Class Initialized
INFO - 2017-01-02 20:12:21 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:21 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:21 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:21 --> URI Class Initialized
INFO - 2017-01-02 20:12:21 --> Router Class Initialized
INFO - 2017-01-02 20:12:21 --> Output Class Initialized
INFO - 2017-01-02 20:12:21 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:21 --> Input Class Initialized
INFO - 2017-01-02 20:12:21 --> Language Class Initialized
ERROR - 2017-01-02 20:12:21 --> 404 Page Not Found: Imagenes_portada/Galeria4.jpg
INFO - 2017-01-02 20:12:21 --> Config Class Initialized
INFO - 2017-01-02 20:12:21 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:21 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:21 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:21 --> URI Class Initialized
INFO - 2017-01-02 20:12:21 --> Router Class Initialized
INFO - 2017-01-02 20:12:21 --> Output Class Initialized
INFO - 2017-01-02 20:12:21 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:21 --> Input Class Initialized
INFO - 2017-01-02 20:12:21 --> Language Class Initialized
ERROR - 2017-01-02 20:12:21 --> 404 Page Not Found: Imagenes_portada/Galeria6.jpg
INFO - 2017-01-02 20:12:21 --> Config Class Initialized
INFO - 2017-01-02 20:12:21 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:21 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:21 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:21 --> URI Class Initialized
INFO - 2017-01-02 20:12:21 --> Router Class Initialized
INFO - 2017-01-02 20:12:21 --> Output Class Initialized
INFO - 2017-01-02 20:12:21 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:21 --> Input Class Initialized
INFO - 2017-01-02 20:12:21 --> Language Class Initialized
ERROR - 2017-01-02 20:12:21 --> 404 Page Not Found: Imagenes_portada/Galeria5.jpg
INFO - 2017-01-02 20:12:21 --> Config Class Initialized
INFO - 2017-01-02 20:12:21 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:21 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:21 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:21 --> URI Class Initialized
INFO - 2017-01-02 20:12:21 --> Router Class Initialized
INFO - 2017-01-02 20:12:21 --> Output Class Initialized
INFO - 2017-01-02 20:12:21 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:21 --> Input Class Initialized
INFO - 2017-01-02 20:12:21 --> Language Class Initialized
INFO - 2017-01-02 20:12:21 --> Loader Class Initialized
INFO - 2017-01-02 20:12:21 --> Database Driver Class Initialized
INFO - 2017-01-02 20:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:12:21 --> Controller Class Initialized
INFO - 2017-01-02 20:12:21 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:12:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:12:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:12:21 --> Final output sent to browser
DEBUG - 2017-01-02 20:12:21 --> Total execution time: 0.0159
INFO - 2017-01-02 20:12:22 --> Config Class Initialized
INFO - 2017-01-02 20:12:22 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:22 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:22 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:22 --> URI Class Initialized
DEBUG - 2017-01-02 20:12:22 --> No URI present. Default controller set.
INFO - 2017-01-02 20:12:22 --> Router Class Initialized
INFO - 2017-01-02 20:12:22 --> Output Class Initialized
INFO - 2017-01-02 20:12:22 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:22 --> Input Class Initialized
INFO - 2017-01-02 20:12:22 --> Language Class Initialized
INFO - 2017-01-02 20:12:22 --> Loader Class Initialized
INFO - 2017-01-02 20:12:22 --> Database Driver Class Initialized
INFO - 2017-01-02 20:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:12:22 --> Controller Class Initialized
INFO - 2017-01-02 20:12:22 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:12:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:12:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:12:22 --> Final output sent to browser
DEBUG - 2017-01-02 20:12:22 --> Total execution time: 0.0136
INFO - 2017-01-02 20:12:23 --> Config Class Initialized
INFO - 2017-01-02 20:12:23 --> Hooks Class Initialized
INFO - 2017-01-02 20:12:23 --> Config Class Initialized
INFO - 2017-01-02 20:12:23 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:23 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:23 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:23 --> URI Class Initialized
INFO - 2017-01-02 20:12:23 --> Router Class Initialized
DEBUG - 2017-01-02 20:12:23 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:23 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:23 --> URI Class Initialized
INFO - 2017-01-02 20:12:23 --> Router Class Initialized
INFO - 2017-01-02 20:12:23 --> Output Class Initialized
INFO - 2017-01-02 20:12:23 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:23 --> Input Class Initialized
INFO - 2017-01-02 20:12:23 --> Language Class Initialized
ERROR - 2017-01-02 20:12:23 --> 404 Page Not Found: Imagenes_portada/Galeria3.jpg
INFO - 2017-01-02 20:12:23 --> Output Class Initialized
INFO - 2017-01-02 20:12:23 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:23 --> Input Class Initialized
INFO - 2017-01-02 20:12:23 --> Language Class Initialized
ERROR - 2017-01-02 20:12:23 --> 404 Page Not Found: Imagenes_portada/Galeria2.jpg
INFO - 2017-01-02 20:12:23 --> Config Class Initialized
INFO - 2017-01-02 20:12:23 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:23 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:23 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:23 --> URI Class Initialized
INFO - 2017-01-02 20:12:23 --> Router Class Initialized
INFO - 2017-01-02 20:12:23 --> Output Class Initialized
INFO - 2017-01-02 20:12:23 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:23 --> Input Class Initialized
INFO - 2017-01-02 20:12:23 --> Language Class Initialized
ERROR - 2017-01-02 20:12:23 --> 404 Page Not Found: Imagenes_portada/Galeria4.jpg
INFO - 2017-01-02 20:12:23 --> Config Class Initialized
INFO - 2017-01-02 20:12:23 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:23 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:23 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:23 --> Config Class Initialized
INFO - 2017-01-02 20:12:23 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:23 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:23 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:23 --> URI Class Initialized
INFO - 2017-01-02 20:12:23 --> Router Class Initialized
INFO - 2017-01-02 20:12:23 --> Output Class Initialized
INFO - 2017-01-02 20:12:23 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:23 --> Input Class Initialized
INFO - 2017-01-02 20:12:23 --> Language Class Initialized
ERROR - 2017-01-02 20:12:23 --> 404 Page Not Found: Imagenes_portada/Galeria5.jpg
INFO - 2017-01-02 20:12:23 --> URI Class Initialized
INFO - 2017-01-02 20:12:23 --> Router Class Initialized
INFO - 2017-01-02 20:12:23 --> Output Class Initialized
INFO - 2017-01-02 20:12:23 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:23 --> Input Class Initialized
INFO - 2017-01-02 20:12:23 --> Language Class Initialized
ERROR - 2017-01-02 20:12:23 --> 404 Page Not Found: Imagenes_portada/Galeria6.jpg
INFO - 2017-01-02 20:12:23 --> Config Class Initialized
INFO - 2017-01-02 20:12:23 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:23 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:23 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:23 --> URI Class Initialized
INFO - 2017-01-02 20:12:23 --> Router Class Initialized
INFO - 2017-01-02 20:12:23 --> Output Class Initialized
INFO - 2017-01-02 20:12:23 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:23 --> Input Class Initialized
INFO - 2017-01-02 20:12:23 --> Language Class Initialized
INFO - 2017-01-02 20:12:23 --> Loader Class Initialized
INFO - 2017-01-02 20:12:23 --> Database Driver Class Initialized
INFO - 2017-01-02 20:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:12:23 --> Controller Class Initialized
INFO - 2017-01-02 20:12:23 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:12:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:12:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:12:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:12:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:12:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:12:23 --> Final output sent to browser
DEBUG - 2017-01-02 20:12:23 --> Total execution time: 0.0134
INFO - 2017-01-02 20:12:34 --> Config Class Initialized
INFO - 2017-01-02 20:12:34 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:34 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:34 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:34 --> URI Class Initialized
INFO - 2017-01-02 20:12:34 --> Router Class Initialized
INFO - 2017-01-02 20:12:34 --> Output Class Initialized
INFO - 2017-01-02 20:12:34 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:34 --> Input Class Initialized
INFO - 2017-01-02 20:12:34 --> Language Class Initialized
ERROR - 2017-01-02 20:12:34 --> 404 Page Not Found: Templates/usuario
INFO - 2017-01-02 20:12:56 --> Config Class Initialized
INFO - 2017-01-02 20:12:56 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:56 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:56 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:56 --> URI Class Initialized
DEBUG - 2017-01-02 20:12:56 --> No URI present. Default controller set.
INFO - 2017-01-02 20:12:56 --> Router Class Initialized
INFO - 2017-01-02 20:12:56 --> Output Class Initialized
INFO - 2017-01-02 20:12:56 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:56 --> Input Class Initialized
INFO - 2017-01-02 20:12:56 --> Language Class Initialized
INFO - 2017-01-02 20:12:56 --> Loader Class Initialized
INFO - 2017-01-02 20:12:56 --> Database Driver Class Initialized
INFO - 2017-01-02 20:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:12:56 --> Controller Class Initialized
INFO - 2017-01-02 20:12:56 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:12:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:12:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:12:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:12:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:12:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:12:56 --> Final output sent to browser
DEBUG - 2017-01-02 20:12:56 --> Total execution time: 0.0153
INFO - 2017-01-02 20:12:56 --> Config Class Initialized
INFO - 2017-01-02 20:12:56 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:56 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:56 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:56 --> URI Class Initialized
INFO - 2017-01-02 20:12:56 --> Router Class Initialized
INFO - 2017-01-02 20:12:56 --> Output Class Initialized
INFO - 2017-01-02 20:12:56 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:56 --> Input Class Initialized
INFO - 2017-01-02 20:12:56 --> Language Class Initialized
ERROR - 2017-01-02 20:12:56 --> 404 Page Not Found: Imagenes_portada/Galeria2.jpg
INFO - 2017-01-02 20:12:56 --> Config Class Initialized
INFO - 2017-01-02 20:12:56 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:56 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:56 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:56 --> URI Class Initialized
INFO - 2017-01-02 20:12:56 --> Router Class Initialized
INFO - 2017-01-02 20:12:56 --> Output Class Initialized
INFO - 2017-01-02 20:12:56 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:56 --> Input Class Initialized
INFO - 2017-01-02 20:12:56 --> Language Class Initialized
ERROR - 2017-01-02 20:12:56 --> 404 Page Not Found: Imagenes_portada/Galeria4.jpg
INFO - 2017-01-02 20:12:56 --> Config Class Initialized
INFO - 2017-01-02 20:12:56 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:56 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:56 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:56 --> URI Class Initialized
INFO - 2017-01-02 20:12:56 --> Router Class Initialized
INFO - 2017-01-02 20:12:56 --> Output Class Initialized
INFO - 2017-01-02 20:12:56 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:56 --> Input Class Initialized
INFO - 2017-01-02 20:12:56 --> Language Class Initialized
ERROR - 2017-01-02 20:12:56 --> 404 Page Not Found: Imagenes_portada/Galeria3.jpg
INFO - 2017-01-02 20:12:56 --> Config Class Initialized
INFO - 2017-01-02 20:12:56 --> Hooks Class Initialized
INFO - 2017-01-02 20:12:56 --> Config Class Initialized
INFO - 2017-01-02 20:12:56 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:56 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:56 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:56 --> URI Class Initialized
INFO - 2017-01-02 20:12:56 --> Router Class Initialized
INFO - 2017-01-02 20:12:56 --> Output Class Initialized
INFO - 2017-01-02 20:12:56 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:56 --> Input Class Initialized
INFO - 2017-01-02 20:12:56 --> Language Class Initialized
ERROR - 2017-01-02 20:12:56 --> 404 Page Not Found: Imagenes_portada/Galeria6.jpg
DEBUG - 2017-01-02 20:12:56 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:56 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:56 --> URI Class Initialized
INFO - 2017-01-02 20:12:56 --> Router Class Initialized
INFO - 2017-01-02 20:12:56 --> Output Class Initialized
INFO - 2017-01-02 20:12:56 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:56 --> Input Class Initialized
INFO - 2017-01-02 20:12:56 --> Language Class Initialized
ERROR - 2017-01-02 20:12:56 --> 404 Page Not Found: Imagenes_portada/Galeria5.jpg
INFO - 2017-01-02 20:12:56 --> Config Class Initialized
INFO - 2017-01-02 20:12:56 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:56 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:56 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:56 --> URI Class Initialized
INFO - 2017-01-02 20:12:56 --> Router Class Initialized
INFO - 2017-01-02 20:12:56 --> Output Class Initialized
INFO - 2017-01-02 20:12:56 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:56 --> Input Class Initialized
INFO - 2017-01-02 20:12:56 --> Language Class Initialized
INFO - 2017-01-02 20:12:56 --> Loader Class Initialized
INFO - 2017-01-02 20:12:56 --> Database Driver Class Initialized
INFO - 2017-01-02 20:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:12:56 --> Controller Class Initialized
INFO - 2017-01-02 20:12:56 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:12:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:12:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:12:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:12:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:12:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:12:56 --> Final output sent to browser
DEBUG - 2017-01-02 20:12:56 --> Total execution time: 0.0137
INFO - 2017-01-02 20:12:58 --> Config Class Initialized
INFO - 2017-01-02 20:12:58 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:58 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:58 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:58 --> URI Class Initialized
DEBUG - 2017-01-02 20:12:58 --> No URI present. Default controller set.
INFO - 2017-01-02 20:12:58 --> Router Class Initialized
INFO - 2017-01-02 20:12:58 --> Output Class Initialized
INFO - 2017-01-02 20:12:58 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:58 --> Input Class Initialized
INFO - 2017-01-02 20:12:58 --> Language Class Initialized
INFO - 2017-01-02 20:12:58 --> Loader Class Initialized
INFO - 2017-01-02 20:12:58 --> Database Driver Class Initialized
INFO - 2017-01-02 20:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:12:58 --> Controller Class Initialized
INFO - 2017-01-02 20:12:58 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:12:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:12:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:12:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:12:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:12:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:12:58 --> Final output sent to browser
DEBUG - 2017-01-02 20:12:58 --> Total execution time: 0.0138
INFO - 2017-01-02 20:12:58 --> Config Class Initialized
INFO - 2017-01-02 20:12:58 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:58 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:58 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:58 --> URI Class Initialized
INFO - 2017-01-02 20:12:58 --> Router Class Initialized
INFO - 2017-01-02 20:12:58 --> Output Class Initialized
INFO - 2017-01-02 20:12:58 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:58 --> Input Class Initialized
INFO - 2017-01-02 20:12:58 --> Language Class Initialized
ERROR - 2017-01-02 20:12:58 --> 404 Page Not Found: Imagenes_portada/Galeria2.jpg
INFO - 2017-01-02 20:12:58 --> Config Class Initialized
INFO - 2017-01-02 20:12:58 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:58 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:58 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:58 --> URI Class Initialized
INFO - 2017-01-02 20:12:58 --> Router Class Initialized
INFO - 2017-01-02 20:12:58 --> Output Class Initialized
INFO - 2017-01-02 20:12:58 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:58 --> Input Class Initialized
INFO - 2017-01-02 20:12:58 --> Language Class Initialized
ERROR - 2017-01-02 20:12:58 --> 404 Page Not Found: Imagenes_portada/Galeria3.jpg
INFO - 2017-01-02 20:12:58 --> Config Class Initialized
INFO - 2017-01-02 20:12:58 --> Hooks Class Initialized
INFO - 2017-01-02 20:12:58 --> Config Class Initialized
INFO - 2017-01-02 20:12:58 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:58 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:58 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:58 --> URI Class Initialized
INFO - 2017-01-02 20:12:58 --> Router Class Initialized
INFO - 2017-01-02 20:12:58 --> Output Class Initialized
INFO - 2017-01-02 20:12:58 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:58 --> Input Class Initialized
INFO - 2017-01-02 20:12:58 --> Language Class Initialized
ERROR - 2017-01-02 20:12:58 --> 404 Page Not Found: Imagenes_portada/Galeria5.jpg
DEBUG - 2017-01-02 20:12:59 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:59 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:59 --> URI Class Initialized
INFO - 2017-01-02 20:12:59 --> Router Class Initialized
INFO - 2017-01-02 20:12:59 --> Output Class Initialized
INFO - 2017-01-02 20:12:59 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:59 --> Input Class Initialized
INFO - 2017-01-02 20:12:59 --> Language Class Initialized
ERROR - 2017-01-02 20:12:59 --> 404 Page Not Found: Imagenes_portada/Galeria4.jpg
INFO - 2017-01-02 20:12:59 --> Config Class Initialized
INFO - 2017-01-02 20:12:59 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:59 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:59 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:59 --> URI Class Initialized
INFO - 2017-01-02 20:12:59 --> Router Class Initialized
INFO - 2017-01-02 20:12:59 --> Output Class Initialized
INFO - 2017-01-02 20:12:59 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:59 --> Input Class Initialized
INFO - 2017-01-02 20:12:59 --> Language Class Initialized
ERROR - 2017-01-02 20:12:59 --> 404 Page Not Found: Imagenes_portada/Galeria6.jpg
INFO - 2017-01-02 20:12:59 --> Config Class Initialized
INFO - 2017-01-02 20:12:59 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:59 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:59 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:59 --> URI Class Initialized
INFO - 2017-01-02 20:12:59 --> Router Class Initialized
INFO - 2017-01-02 20:12:59 --> Output Class Initialized
INFO - 2017-01-02 20:12:59 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:59 --> Input Class Initialized
INFO - 2017-01-02 20:12:59 --> Language Class Initialized
INFO - 2017-01-02 20:12:59 --> Loader Class Initialized
INFO - 2017-01-02 20:12:59 --> Database Driver Class Initialized
INFO - 2017-01-02 20:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:12:59 --> Controller Class Initialized
INFO - 2017-01-02 20:12:59 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:12:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:12:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:12:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:12:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:12:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:12:59 --> Final output sent to browser
DEBUG - 2017-01-02 20:12:59 --> Total execution time: 0.0140
INFO - 2017-01-02 20:12:59 --> Config Class Initialized
INFO - 2017-01-02 20:12:59 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:12:59 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:12:59 --> Utf8 Class Initialized
INFO - 2017-01-02 20:12:59 --> URI Class Initialized
INFO - 2017-01-02 20:12:59 --> Router Class Initialized
INFO - 2017-01-02 20:12:59 --> Output Class Initialized
INFO - 2017-01-02 20:12:59 --> Security Class Initialized
DEBUG - 2017-01-02 20:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:12:59 --> Input Class Initialized
INFO - 2017-01-02 20:12:59 --> Language Class Initialized
ERROR - 2017-01-02 20:12:59 --> 404 Page Not Found: Templates/usuario
INFO - 2017-01-02 20:13:37 --> Config Class Initialized
INFO - 2017-01-02 20:13:37 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:13:37 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:13:37 --> Utf8 Class Initialized
INFO - 2017-01-02 20:13:37 --> URI Class Initialized
DEBUG - 2017-01-02 20:13:37 --> No URI present. Default controller set.
INFO - 2017-01-02 20:13:37 --> Router Class Initialized
INFO - 2017-01-02 20:13:37 --> Output Class Initialized
INFO - 2017-01-02 20:13:37 --> Security Class Initialized
DEBUG - 2017-01-02 20:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:13:37 --> Input Class Initialized
INFO - 2017-01-02 20:13:37 --> Language Class Initialized
INFO - 2017-01-02 20:13:37 --> Loader Class Initialized
INFO - 2017-01-02 20:13:37 --> Database Driver Class Initialized
INFO - 2017-01-02 20:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:13:37 --> Controller Class Initialized
INFO - 2017-01-02 20:13:37 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:13:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:13:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:13:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:13:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:13:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:13:37 --> Final output sent to browser
DEBUG - 2017-01-02 20:13:37 --> Total execution time: 0.0132
INFO - 2017-01-02 20:13:37 --> Config Class Initialized
INFO - 2017-01-02 20:13:37 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:13:37 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:13:37 --> Utf8 Class Initialized
INFO - 2017-01-02 20:13:37 --> URI Class Initialized
INFO - 2017-01-02 20:13:37 --> Router Class Initialized
INFO - 2017-01-02 20:13:37 --> Output Class Initialized
INFO - 2017-01-02 20:13:37 --> Security Class Initialized
DEBUG - 2017-01-02 20:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:13:37 --> Input Class Initialized
INFO - 2017-01-02 20:13:37 --> Language Class Initialized
ERROR - 2017-01-02 20:13:37 --> 404 Page Not Found: Templates/usuario
INFO - 2017-01-02 20:13:38 --> Config Class Initialized
INFO - 2017-01-02 20:13:38 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:13:38 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:13:38 --> Utf8 Class Initialized
INFO - 2017-01-02 20:13:38 --> URI Class Initialized
INFO - 2017-01-02 20:13:38 --> Router Class Initialized
INFO - 2017-01-02 20:13:38 --> Output Class Initialized
INFO - 2017-01-02 20:13:38 --> Security Class Initialized
DEBUG - 2017-01-02 20:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:13:38 --> Input Class Initialized
INFO - 2017-01-02 20:13:38 --> Language Class Initialized
ERROR - 2017-01-02 20:13:38 --> 404 Page Not Found: Imagenes_portada/Galeria2.jpg
INFO - 2017-01-02 20:13:38 --> Config Class Initialized
INFO - 2017-01-02 20:13:38 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:13:38 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:13:38 --> Utf8 Class Initialized
INFO - 2017-01-02 20:13:38 --> URI Class Initialized
INFO - 2017-01-02 20:13:38 --> Router Class Initialized
INFO - 2017-01-02 20:13:38 --> Output Class Initialized
INFO - 2017-01-02 20:13:38 --> Config Class Initialized
INFO - 2017-01-02 20:13:38 --> Hooks Class Initialized
INFO - 2017-01-02 20:13:38 --> Security Class Initialized
DEBUG - 2017-01-02 20:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:13:38 --> Input Class Initialized
INFO - 2017-01-02 20:13:38 --> Language Class Initialized
ERROR - 2017-01-02 20:13:38 --> 404 Page Not Found: Imagenes_portada/Galeria3.jpg
DEBUG - 2017-01-02 20:13:38 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:13:38 --> Utf8 Class Initialized
INFO - 2017-01-02 20:13:38 --> URI Class Initialized
INFO - 2017-01-02 20:13:38 --> Router Class Initialized
INFO - 2017-01-02 20:13:38 --> Output Class Initialized
INFO - 2017-01-02 20:13:38 --> Security Class Initialized
DEBUG - 2017-01-02 20:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:13:38 --> Input Class Initialized
INFO - 2017-01-02 20:13:38 --> Language Class Initialized
ERROR - 2017-01-02 20:13:38 --> 404 Page Not Found: Imagenes_portada/Galeria4.jpg
INFO - 2017-01-02 20:13:38 --> Config Class Initialized
INFO - 2017-01-02 20:13:38 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:13:38 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:13:38 --> Utf8 Class Initialized
INFO - 2017-01-02 20:13:38 --> URI Class Initialized
INFO - 2017-01-02 20:13:38 --> Router Class Initialized
INFO - 2017-01-02 20:13:38 --> Output Class Initialized
INFO - 2017-01-02 20:13:38 --> Config Class Initialized
INFO - 2017-01-02 20:13:38 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:13:38 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:13:38 --> Utf8 Class Initialized
INFO - 2017-01-02 20:13:38 --> URI Class Initialized
INFO - 2017-01-02 20:13:38 --> Router Class Initialized
INFO - 2017-01-02 20:13:38 --> Output Class Initialized
INFO - 2017-01-02 20:13:38 --> Security Class Initialized
DEBUG - 2017-01-02 20:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:13:38 --> Input Class Initialized
INFO - 2017-01-02 20:13:38 --> Language Class Initialized
ERROR - 2017-01-02 20:13:38 --> 404 Page Not Found: Imagenes_portada/Galeria5.jpg
INFO - 2017-01-02 20:13:38 --> Security Class Initialized
DEBUG - 2017-01-02 20:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:13:38 --> Input Class Initialized
INFO - 2017-01-02 20:13:38 --> Language Class Initialized
ERROR - 2017-01-02 20:13:38 --> 404 Page Not Found: Imagenes_portada/Galeria6.jpg
INFO - 2017-01-02 20:13:38 --> Config Class Initialized
INFO - 2017-01-02 20:13:38 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:13:38 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:13:38 --> Utf8 Class Initialized
INFO - 2017-01-02 20:13:38 --> URI Class Initialized
INFO - 2017-01-02 20:13:38 --> Router Class Initialized
INFO - 2017-01-02 20:13:38 --> Output Class Initialized
INFO - 2017-01-02 20:13:38 --> Security Class Initialized
DEBUG - 2017-01-02 20:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:13:38 --> Input Class Initialized
INFO - 2017-01-02 20:13:38 --> Language Class Initialized
INFO - 2017-01-02 20:13:38 --> Loader Class Initialized
INFO - 2017-01-02 20:13:38 --> Database Driver Class Initialized
INFO - 2017-01-02 20:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:13:38 --> Controller Class Initialized
INFO - 2017-01-02 20:13:38 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:13:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:13:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:13:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:13:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:13:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:13:38 --> Final output sent to browser
DEBUG - 2017-01-02 20:13:38 --> Total execution time: 0.0133
INFO - 2017-01-02 20:15:11 --> Config Class Initialized
INFO - 2017-01-02 20:15:11 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:15:11 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:15:11 --> Utf8 Class Initialized
INFO - 2017-01-02 20:15:11 --> URI Class Initialized
DEBUG - 2017-01-02 20:15:11 --> No URI present. Default controller set.
INFO - 2017-01-02 20:15:11 --> Router Class Initialized
INFO - 2017-01-02 20:15:11 --> Output Class Initialized
INFO - 2017-01-02 20:15:11 --> Security Class Initialized
DEBUG - 2017-01-02 20:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:15:11 --> Input Class Initialized
INFO - 2017-01-02 20:15:11 --> Language Class Initialized
INFO - 2017-01-02 20:15:11 --> Loader Class Initialized
INFO - 2017-01-02 20:15:11 --> Database Driver Class Initialized
INFO - 2017-01-02 20:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:15:11 --> Controller Class Initialized
INFO - 2017-01-02 20:15:11 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:15:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:15:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:15:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:15:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:15:11 --> Final output sent to browser
DEBUG - 2017-01-02 20:15:11 --> Total execution time: 0.0142
INFO - 2017-01-02 20:15:11 --> Config Class Initialized
INFO - 2017-01-02 20:15:11 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:15:11 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:15:11 --> Utf8 Class Initialized
INFO - 2017-01-02 20:15:11 --> URI Class Initialized
INFO - 2017-01-02 20:15:11 --> Router Class Initialized
INFO - 2017-01-02 20:15:11 --> Output Class Initialized
INFO - 2017-01-02 20:15:11 --> Security Class Initialized
DEBUG - 2017-01-02 20:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:15:11 --> Input Class Initialized
INFO - 2017-01-02 20:15:11 --> Language Class Initialized
ERROR - 2017-01-02 20:15:11 --> 404 Page Not Found: Templates/usuario
INFO - 2017-01-02 20:15:12 --> Config Class Initialized
INFO - 2017-01-02 20:15:12 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:15:12 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:15:12 --> Utf8 Class Initialized
INFO - 2017-01-02 20:15:12 --> URI Class Initialized
INFO - 2017-01-02 20:15:12 --> Router Class Initialized
INFO - 2017-01-02 20:15:12 --> Output Class Initialized
INFO - 2017-01-02 20:15:12 --> Security Class Initialized
DEBUG - 2017-01-02 20:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:15:12 --> Input Class Initialized
INFO - 2017-01-02 20:15:12 --> Language Class Initialized
INFO - 2017-01-02 20:15:12 --> Loader Class Initialized
INFO - 2017-01-02 20:15:12 --> Database Driver Class Initialized
INFO - 2017-01-02 20:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:15:12 --> Controller Class Initialized
INFO - 2017-01-02 20:15:12 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:15:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:15:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:15:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:15:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:15:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:15:12 --> Final output sent to browser
DEBUG - 2017-01-02 20:15:12 --> Total execution time: 0.0136
INFO - 2017-01-02 20:16:51 --> Config Class Initialized
INFO - 2017-01-02 20:16:51 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:16:51 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:16:51 --> Utf8 Class Initialized
INFO - 2017-01-02 20:16:51 --> URI Class Initialized
DEBUG - 2017-01-02 20:16:51 --> No URI present. Default controller set.
INFO - 2017-01-02 20:16:51 --> Router Class Initialized
INFO - 2017-01-02 20:16:51 --> Output Class Initialized
INFO - 2017-01-02 20:16:51 --> Security Class Initialized
DEBUG - 2017-01-02 20:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:16:51 --> Input Class Initialized
INFO - 2017-01-02 20:16:51 --> Language Class Initialized
INFO - 2017-01-02 20:16:51 --> Loader Class Initialized
INFO - 2017-01-02 20:16:51 --> Database Driver Class Initialized
INFO - 2017-01-02 20:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:16:51 --> Controller Class Initialized
INFO - 2017-01-02 20:16:51 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:16:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:16:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:16:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:16:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:16:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:16:51 --> Final output sent to browser
DEBUG - 2017-01-02 20:16:51 --> Total execution time: 0.0271
INFO - 2017-01-02 20:16:51 --> Config Class Initialized
INFO - 2017-01-02 20:16:51 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:16:51 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:16:51 --> Utf8 Class Initialized
INFO - 2017-01-02 20:16:51 --> URI Class Initialized
INFO - 2017-01-02 20:16:51 --> Router Class Initialized
INFO - 2017-01-02 20:16:51 --> Output Class Initialized
INFO - 2017-01-02 20:16:51 --> Security Class Initialized
DEBUG - 2017-01-02 20:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:16:51 --> Input Class Initialized
INFO - 2017-01-02 20:16:51 --> Language Class Initialized
ERROR - 2017-01-02 20:16:51 --> 404 Page Not Found: Templates/usuario
INFO - 2017-01-02 20:16:51 --> Config Class Initialized
INFO - 2017-01-02 20:16:51 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:16:51 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:16:51 --> Utf8 Class Initialized
INFO - 2017-01-02 20:16:51 --> URI Class Initialized
INFO - 2017-01-02 20:16:51 --> Router Class Initialized
INFO - 2017-01-02 20:16:51 --> Output Class Initialized
INFO - 2017-01-02 20:16:51 --> Security Class Initialized
DEBUG - 2017-01-02 20:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:16:51 --> Input Class Initialized
INFO - 2017-01-02 20:16:51 --> Language Class Initialized
INFO - 2017-01-02 20:16:51 --> Loader Class Initialized
INFO - 2017-01-02 20:16:51 --> Database Driver Class Initialized
INFO - 2017-01-02 20:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:16:51 --> Controller Class Initialized
INFO - 2017-01-02 20:16:51 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:16:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:16:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:16:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:16:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:16:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:16:51 --> Final output sent to browser
DEBUG - 2017-01-02 20:16:51 --> Total execution time: 0.0503
INFO - 2017-01-02 20:18:32 --> Config Class Initialized
INFO - 2017-01-02 20:18:32 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:18:32 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:18:32 --> Utf8 Class Initialized
INFO - 2017-01-02 20:18:32 --> URI Class Initialized
DEBUG - 2017-01-02 20:18:32 --> No URI present. Default controller set.
INFO - 2017-01-02 20:18:32 --> Router Class Initialized
INFO - 2017-01-02 20:18:32 --> Output Class Initialized
INFO - 2017-01-02 20:18:32 --> Security Class Initialized
DEBUG - 2017-01-02 20:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:18:32 --> Input Class Initialized
INFO - 2017-01-02 20:18:32 --> Language Class Initialized
INFO - 2017-01-02 20:18:32 --> Loader Class Initialized
INFO - 2017-01-02 20:18:32 --> Database Driver Class Initialized
INFO - 2017-01-02 20:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:18:32 --> Controller Class Initialized
INFO - 2017-01-02 20:18:32 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:18:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:18:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:18:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:18:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:18:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:18:32 --> Final output sent to browser
DEBUG - 2017-01-02 20:18:32 --> Total execution time: 0.0132
INFO - 2017-01-02 20:18:33 --> Config Class Initialized
INFO - 2017-01-02 20:18:33 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:18:33 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:18:33 --> Utf8 Class Initialized
INFO - 2017-01-02 20:18:33 --> URI Class Initialized
INFO - 2017-01-02 20:18:33 --> Router Class Initialized
INFO - 2017-01-02 20:18:33 --> Output Class Initialized
INFO - 2017-01-02 20:18:33 --> Security Class Initialized
DEBUG - 2017-01-02 20:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:18:33 --> Input Class Initialized
INFO - 2017-01-02 20:18:33 --> Language Class Initialized
INFO - 2017-01-02 20:18:33 --> Loader Class Initialized
INFO - 2017-01-02 20:18:33 --> Database Driver Class Initialized
INFO - 2017-01-02 20:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:18:33 --> Controller Class Initialized
INFO - 2017-01-02 20:18:33 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:18:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:18:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:18:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:18:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:18:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:18:33 --> Final output sent to browser
DEBUG - 2017-01-02 20:18:33 --> Total execution time: 0.0134
INFO - 2017-01-02 20:22:21 --> Config Class Initialized
INFO - 2017-01-02 20:22:21 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:22:21 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:22:21 --> Utf8 Class Initialized
INFO - 2017-01-02 20:22:21 --> URI Class Initialized
DEBUG - 2017-01-02 20:22:21 --> No URI present. Default controller set.
INFO - 2017-01-02 20:22:21 --> Router Class Initialized
INFO - 2017-01-02 20:22:21 --> Output Class Initialized
INFO - 2017-01-02 20:22:21 --> Security Class Initialized
DEBUG - 2017-01-02 20:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:22:21 --> Input Class Initialized
INFO - 2017-01-02 20:22:21 --> Language Class Initialized
INFO - 2017-01-02 20:22:21 --> Loader Class Initialized
INFO - 2017-01-02 20:22:21 --> Database Driver Class Initialized
INFO - 2017-01-02 20:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:22:21 --> Controller Class Initialized
INFO - 2017-01-02 20:22:21 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:22:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:22:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:22:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:22:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:22:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:22:21 --> Final output sent to browser
DEBUG - 2017-01-02 20:22:21 --> Total execution time: 0.0145
INFO - 2017-01-02 20:22:21 --> Config Class Initialized
INFO - 2017-01-02 20:22:21 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:22:21 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:22:21 --> Utf8 Class Initialized
INFO - 2017-01-02 20:22:21 --> URI Class Initialized
INFO - 2017-01-02 20:22:21 --> Router Class Initialized
INFO - 2017-01-02 20:22:21 --> Output Class Initialized
INFO - 2017-01-02 20:22:21 --> Security Class Initialized
DEBUG - 2017-01-02 20:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:22:21 --> Input Class Initialized
INFO - 2017-01-02 20:22:21 --> Language Class Initialized
INFO - 2017-01-02 20:22:21 --> Loader Class Initialized
INFO - 2017-01-02 20:22:21 --> Database Driver Class Initialized
INFO - 2017-01-02 20:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:22:21 --> Controller Class Initialized
INFO - 2017-01-02 20:22:21 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:22:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:22:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:22:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:22:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:22:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:22:21 --> Final output sent to browser
DEBUG - 2017-01-02 20:22:21 --> Total execution time: 0.0141
INFO - 2017-01-02 20:22:38 --> Config Class Initialized
INFO - 2017-01-02 20:22:38 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:22:38 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:22:38 --> Utf8 Class Initialized
INFO - 2017-01-02 20:22:38 --> URI Class Initialized
INFO - 2017-01-02 20:22:38 --> Router Class Initialized
INFO - 2017-01-02 20:22:38 --> Output Class Initialized
INFO - 2017-01-02 20:22:38 --> Security Class Initialized
DEBUG - 2017-01-02 20:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:22:38 --> Input Class Initialized
INFO - 2017-01-02 20:22:38 --> Language Class Initialized
ERROR - 2017-01-02 20:22:38 --> 404 Page Not Found: Templates/usuario
INFO - 2017-01-02 20:25:27 --> Config Class Initialized
INFO - 2017-01-02 20:25:27 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:25:27 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:25:27 --> Utf8 Class Initialized
INFO - 2017-01-02 20:25:27 --> URI Class Initialized
DEBUG - 2017-01-02 20:25:27 --> No URI present. Default controller set.
INFO - 2017-01-02 20:25:27 --> Router Class Initialized
INFO - 2017-01-02 20:25:27 --> Output Class Initialized
INFO - 2017-01-02 20:25:27 --> Security Class Initialized
DEBUG - 2017-01-02 20:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:25:27 --> Input Class Initialized
INFO - 2017-01-02 20:25:27 --> Language Class Initialized
INFO - 2017-01-02 20:25:27 --> Loader Class Initialized
INFO - 2017-01-02 20:25:27 --> Database Driver Class Initialized
INFO - 2017-01-02 20:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:25:27 --> Controller Class Initialized
INFO - 2017-01-02 20:25:27 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:25:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:25:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:25:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:25:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:25:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:25:27 --> Final output sent to browser
DEBUG - 2017-01-02 20:25:27 --> Total execution time: 0.0131
INFO - 2017-01-02 20:25:28 --> Config Class Initialized
INFO - 2017-01-02 20:25:28 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:25:28 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:25:28 --> Utf8 Class Initialized
INFO - 2017-01-02 20:25:28 --> URI Class Initialized
INFO - 2017-01-02 20:25:28 --> Router Class Initialized
INFO - 2017-01-02 20:25:28 --> Output Class Initialized
INFO - 2017-01-02 20:25:28 --> Security Class Initialized
DEBUG - 2017-01-02 20:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:25:28 --> Input Class Initialized
INFO - 2017-01-02 20:25:28 --> Language Class Initialized
INFO - 2017-01-02 20:25:28 --> Loader Class Initialized
INFO - 2017-01-02 20:25:28 --> Database Driver Class Initialized
INFO - 2017-01-02 20:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:25:28 --> Controller Class Initialized
INFO - 2017-01-02 20:25:28 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:25:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:25:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:25:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:25:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:25:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:25:28 --> Final output sent to browser
DEBUG - 2017-01-02 20:25:28 --> Total execution time: 0.0139
INFO - 2017-01-02 20:26:14 --> Config Class Initialized
INFO - 2017-01-02 20:26:14 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:26:14 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:26:14 --> Utf8 Class Initialized
INFO - 2017-01-02 20:26:14 --> URI Class Initialized
DEBUG - 2017-01-02 20:26:14 --> No URI present. Default controller set.
INFO - 2017-01-02 20:26:14 --> Router Class Initialized
INFO - 2017-01-02 20:26:14 --> Output Class Initialized
INFO - 2017-01-02 20:26:14 --> Security Class Initialized
DEBUG - 2017-01-02 20:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:26:14 --> Input Class Initialized
INFO - 2017-01-02 20:26:14 --> Language Class Initialized
INFO - 2017-01-02 20:26:14 --> Loader Class Initialized
INFO - 2017-01-02 20:26:14 --> Database Driver Class Initialized
INFO - 2017-01-02 20:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:26:14 --> Controller Class Initialized
INFO - 2017-01-02 20:26:14 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:26:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:26:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:26:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:26:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:26:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:26:14 --> Final output sent to browser
DEBUG - 2017-01-02 20:26:14 --> Total execution time: 0.0645
INFO - 2017-01-02 20:26:14 --> Config Class Initialized
INFO - 2017-01-02 20:26:14 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:26:14 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:26:14 --> Utf8 Class Initialized
INFO - 2017-01-02 20:26:14 --> URI Class Initialized
INFO - 2017-01-02 20:26:14 --> Router Class Initialized
INFO - 2017-01-02 20:26:14 --> Output Class Initialized
INFO - 2017-01-02 20:26:14 --> Security Class Initialized
DEBUG - 2017-01-02 20:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:26:14 --> Input Class Initialized
INFO - 2017-01-02 20:26:14 --> Language Class Initialized
INFO - 2017-01-02 20:26:14 --> Loader Class Initialized
INFO - 2017-01-02 20:26:14 --> Database Driver Class Initialized
INFO - 2017-01-02 20:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:26:14 --> Controller Class Initialized
INFO - 2017-01-02 20:26:14 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:26:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:26:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:26:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:26:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:26:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:26:14 --> Final output sent to browser
DEBUG - 2017-01-02 20:26:14 --> Total execution time: 0.0140
INFO - 2017-01-02 20:28:47 --> Config Class Initialized
INFO - 2017-01-02 20:28:47 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:28:47 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:28:47 --> Utf8 Class Initialized
INFO - 2017-01-02 20:28:47 --> URI Class Initialized
DEBUG - 2017-01-02 20:28:47 --> No URI present. Default controller set.
INFO - 2017-01-02 20:28:47 --> Router Class Initialized
INFO - 2017-01-02 20:28:47 --> Output Class Initialized
INFO - 2017-01-02 20:28:47 --> Security Class Initialized
DEBUG - 2017-01-02 20:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:28:47 --> Input Class Initialized
INFO - 2017-01-02 20:28:47 --> Language Class Initialized
INFO - 2017-01-02 20:28:47 --> Loader Class Initialized
INFO - 2017-01-02 20:28:47 --> Database Driver Class Initialized
INFO - 2017-01-02 20:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:28:47 --> Controller Class Initialized
INFO - 2017-01-02 20:28:47 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:28:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:28:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:28:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:28:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:28:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:28:47 --> Final output sent to browser
DEBUG - 2017-01-02 20:28:47 --> Total execution time: 0.0132
INFO - 2017-01-02 20:28:47 --> Config Class Initialized
INFO - 2017-01-02 20:28:47 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:28:47 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:28:47 --> Utf8 Class Initialized
INFO - 2017-01-02 20:28:47 --> URI Class Initialized
INFO - 2017-01-02 20:28:47 --> Router Class Initialized
INFO - 2017-01-02 20:28:47 --> Output Class Initialized
INFO - 2017-01-02 20:28:47 --> Security Class Initialized
DEBUG - 2017-01-02 20:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:28:47 --> Input Class Initialized
INFO - 2017-01-02 20:28:47 --> Language Class Initialized
INFO - 2017-01-02 20:28:47 --> Loader Class Initialized
INFO - 2017-01-02 20:28:47 --> Database Driver Class Initialized
INFO - 2017-01-02 20:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:28:47 --> Controller Class Initialized
INFO - 2017-01-02 20:28:47 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:28:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:28:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:28:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:28:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:28:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:28:47 --> Final output sent to browser
DEBUG - 2017-01-02 20:28:47 --> Total execution time: 0.0133
INFO - 2017-01-02 20:28:59 --> Config Class Initialized
INFO - 2017-01-02 20:28:59 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:28:59 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:28:59 --> Utf8 Class Initialized
INFO - 2017-01-02 20:28:59 --> URI Class Initialized
DEBUG - 2017-01-02 20:28:59 --> No URI present. Default controller set.
INFO - 2017-01-02 20:28:59 --> Router Class Initialized
INFO - 2017-01-02 20:28:59 --> Output Class Initialized
INFO - 2017-01-02 20:28:59 --> Security Class Initialized
DEBUG - 2017-01-02 20:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:28:59 --> Input Class Initialized
INFO - 2017-01-02 20:28:59 --> Language Class Initialized
INFO - 2017-01-02 20:28:59 --> Loader Class Initialized
INFO - 2017-01-02 20:28:59 --> Database Driver Class Initialized
INFO - 2017-01-02 20:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:28:59 --> Controller Class Initialized
INFO - 2017-01-02 20:28:59 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:28:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:28:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:28:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:28:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:28:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:28:59 --> Final output sent to browser
DEBUG - 2017-01-02 20:28:59 --> Total execution time: 0.0145
INFO - 2017-01-02 20:29:00 --> Config Class Initialized
INFO - 2017-01-02 20:29:00 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:29:00 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:29:00 --> Utf8 Class Initialized
INFO - 2017-01-02 20:29:00 --> URI Class Initialized
INFO - 2017-01-02 20:29:00 --> Router Class Initialized
INFO - 2017-01-02 20:29:00 --> Output Class Initialized
INFO - 2017-01-02 20:29:00 --> Security Class Initialized
DEBUG - 2017-01-02 20:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:29:00 --> Input Class Initialized
INFO - 2017-01-02 20:29:00 --> Language Class Initialized
INFO - 2017-01-02 20:29:00 --> Loader Class Initialized
INFO - 2017-01-02 20:29:00 --> Database Driver Class Initialized
INFO - 2017-01-02 20:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:29:00 --> Controller Class Initialized
INFO - 2017-01-02 20:29:00 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:29:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:29:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:29:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:29:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:29:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:29:00 --> Final output sent to browser
DEBUG - 2017-01-02 20:29:00 --> Total execution time: 0.0145
INFO - 2017-01-02 20:29:04 --> Config Class Initialized
INFO - 2017-01-02 20:29:04 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:29:04 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:29:04 --> Utf8 Class Initialized
INFO - 2017-01-02 20:29:04 --> URI Class Initialized
INFO - 2017-01-02 20:29:04 --> Router Class Initialized
INFO - 2017-01-02 20:29:04 --> Output Class Initialized
INFO - 2017-01-02 20:29:04 --> Security Class Initialized
DEBUG - 2017-01-02 20:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:29:04 --> Input Class Initialized
INFO - 2017-01-02 20:29:04 --> Language Class Initialized
ERROR - 2017-01-02 20:29:04 --> 404 Page Not Found: Templates/usuario
INFO - 2017-01-02 20:34:05 --> Config Class Initialized
INFO - 2017-01-02 20:34:05 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:34:05 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:34:05 --> Utf8 Class Initialized
INFO - 2017-01-02 20:34:05 --> URI Class Initialized
DEBUG - 2017-01-02 20:34:05 --> No URI present. Default controller set.
INFO - 2017-01-02 20:34:05 --> Router Class Initialized
INFO - 2017-01-02 20:34:05 --> Output Class Initialized
INFO - 2017-01-02 20:34:05 --> Security Class Initialized
DEBUG - 2017-01-02 20:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:34:05 --> Input Class Initialized
INFO - 2017-01-02 20:34:05 --> Language Class Initialized
INFO - 2017-01-02 20:34:05 --> Loader Class Initialized
INFO - 2017-01-02 20:34:05 --> Database Driver Class Initialized
INFO - 2017-01-02 20:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:34:05 --> Controller Class Initialized
INFO - 2017-01-02 20:34:05 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:34:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:34:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:34:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:34:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:34:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:34:05 --> Final output sent to browser
DEBUG - 2017-01-02 20:34:05 --> Total execution time: 0.1038
INFO - 2017-01-02 20:34:05 --> Config Class Initialized
INFO - 2017-01-02 20:34:05 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:34:05 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:34:05 --> Utf8 Class Initialized
INFO - 2017-01-02 20:34:05 --> URI Class Initialized
INFO - 2017-01-02 20:34:05 --> Router Class Initialized
INFO - 2017-01-02 20:34:05 --> Output Class Initialized
INFO - 2017-01-02 20:34:05 --> Security Class Initialized
DEBUG - 2017-01-02 20:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:34:05 --> Input Class Initialized
INFO - 2017-01-02 20:34:05 --> Language Class Initialized
INFO - 2017-01-02 20:34:05 --> Loader Class Initialized
INFO - 2017-01-02 20:34:05 --> Database Driver Class Initialized
INFO - 2017-01-02 20:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:34:05 --> Controller Class Initialized
INFO - 2017-01-02 20:34:05 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:34:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:34:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:34:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:34:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:34:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:34:05 --> Final output sent to browser
DEBUG - 2017-01-02 20:34:05 --> Total execution time: 0.0145
INFO - 2017-01-02 20:34:06 --> Config Class Initialized
INFO - 2017-01-02 20:34:06 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:34:06 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:34:06 --> Utf8 Class Initialized
INFO - 2017-01-02 20:34:06 --> URI Class Initialized
DEBUG - 2017-01-02 20:34:06 --> No URI present. Default controller set.
INFO - 2017-01-02 20:34:06 --> Router Class Initialized
INFO - 2017-01-02 20:34:06 --> Output Class Initialized
INFO - 2017-01-02 20:34:06 --> Security Class Initialized
DEBUG - 2017-01-02 20:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:34:06 --> Input Class Initialized
INFO - 2017-01-02 20:34:06 --> Language Class Initialized
INFO - 2017-01-02 20:34:06 --> Loader Class Initialized
INFO - 2017-01-02 20:34:06 --> Database Driver Class Initialized
INFO - 2017-01-02 20:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:34:06 --> Controller Class Initialized
INFO - 2017-01-02 20:34:06 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:34:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:34:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:34:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:34:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:34:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:34:06 --> Final output sent to browser
DEBUG - 2017-01-02 20:34:06 --> Total execution time: 0.0202
INFO - 2017-01-02 20:34:07 --> Config Class Initialized
INFO - 2017-01-02 20:34:07 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:34:07 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:34:07 --> Utf8 Class Initialized
INFO - 2017-01-02 20:34:07 --> URI Class Initialized
DEBUG - 2017-01-02 20:34:07 --> No URI present. Default controller set.
INFO - 2017-01-02 20:34:07 --> Router Class Initialized
INFO - 2017-01-02 20:34:07 --> Output Class Initialized
INFO - 2017-01-02 20:34:07 --> Security Class Initialized
DEBUG - 2017-01-02 20:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:34:07 --> Input Class Initialized
INFO - 2017-01-02 20:34:07 --> Language Class Initialized
INFO - 2017-01-02 20:34:07 --> Loader Class Initialized
INFO - 2017-01-02 20:34:07 --> Database Driver Class Initialized
INFO - 2017-01-02 20:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:34:07 --> Controller Class Initialized
INFO - 2017-01-02 20:34:07 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:34:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:34:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:34:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:34:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:34:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:34:07 --> Final output sent to browser
DEBUG - 2017-01-02 20:34:07 --> Total execution time: 0.0207
INFO - 2017-01-02 20:34:07 --> Config Class Initialized
INFO - 2017-01-02 20:34:07 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:34:07 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:34:07 --> Utf8 Class Initialized
INFO - 2017-01-02 20:34:07 --> URI Class Initialized
DEBUG - 2017-01-02 20:34:07 --> No URI present. Default controller set.
INFO - 2017-01-02 20:34:07 --> Router Class Initialized
INFO - 2017-01-02 20:34:07 --> Output Class Initialized
INFO - 2017-01-02 20:34:07 --> Security Class Initialized
DEBUG - 2017-01-02 20:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:34:07 --> Input Class Initialized
INFO - 2017-01-02 20:34:07 --> Language Class Initialized
INFO - 2017-01-02 20:34:07 --> Loader Class Initialized
INFO - 2017-01-02 20:34:07 --> Database Driver Class Initialized
INFO - 2017-01-02 20:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:34:07 --> Controller Class Initialized
INFO - 2017-01-02 20:34:07 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:34:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:34:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:34:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:34:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:34:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:34:07 --> Final output sent to browser
DEBUG - 2017-01-02 20:34:07 --> Total execution time: 0.0226
INFO - 2017-01-02 20:34:08 --> Config Class Initialized
INFO - 2017-01-02 20:34:08 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:34:08 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:34:08 --> Utf8 Class Initialized
INFO - 2017-01-02 20:34:08 --> URI Class Initialized
INFO - 2017-01-02 20:34:08 --> Router Class Initialized
INFO - 2017-01-02 20:34:08 --> Output Class Initialized
INFO - 2017-01-02 20:34:08 --> Security Class Initialized
DEBUG - 2017-01-02 20:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:34:08 --> Input Class Initialized
INFO - 2017-01-02 20:34:08 --> Language Class Initialized
INFO - 2017-01-02 20:34:08 --> Loader Class Initialized
INFO - 2017-01-02 20:34:08 --> Database Driver Class Initialized
INFO - 2017-01-02 20:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:34:08 --> Controller Class Initialized
INFO - 2017-01-02 20:34:08 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:34:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:34:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:34:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:34:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:34:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:34:08 --> Final output sent to browser
DEBUG - 2017-01-02 20:34:08 --> Total execution time: 0.0272
INFO - 2017-01-02 20:34:08 --> Config Class Initialized
INFO - 2017-01-02 20:34:08 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:34:08 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:34:08 --> Utf8 Class Initialized
INFO - 2017-01-02 20:34:08 --> URI Class Initialized
DEBUG - 2017-01-02 20:34:08 --> No URI present. Default controller set.
INFO - 2017-01-02 20:34:08 --> Router Class Initialized
INFO - 2017-01-02 20:34:08 --> Output Class Initialized
INFO - 2017-01-02 20:34:08 --> Security Class Initialized
DEBUG - 2017-01-02 20:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:34:08 --> Input Class Initialized
INFO - 2017-01-02 20:34:08 --> Language Class Initialized
INFO - 2017-01-02 20:34:08 --> Loader Class Initialized
INFO - 2017-01-02 20:34:08 --> Database Driver Class Initialized
INFO - 2017-01-02 20:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:34:08 --> Controller Class Initialized
INFO - 2017-01-02 20:34:08 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:34:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:34:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:34:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:34:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:34:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:34:08 --> Final output sent to browser
DEBUG - 2017-01-02 20:34:08 --> Total execution time: 0.0608
INFO - 2017-01-02 20:38:32 --> Config Class Initialized
INFO - 2017-01-02 20:38:32 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:38:32 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:38:32 --> Utf8 Class Initialized
INFO - 2017-01-02 20:38:32 --> URI Class Initialized
DEBUG - 2017-01-02 20:38:32 --> No URI present. Default controller set.
INFO - 2017-01-02 20:38:32 --> Router Class Initialized
INFO - 2017-01-02 20:38:32 --> Output Class Initialized
INFO - 2017-01-02 20:38:32 --> Security Class Initialized
DEBUG - 2017-01-02 20:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:38:32 --> Input Class Initialized
INFO - 2017-01-02 20:38:32 --> Language Class Initialized
INFO - 2017-01-02 20:38:32 --> Loader Class Initialized
INFO - 2017-01-02 20:38:32 --> Database Driver Class Initialized
INFO - 2017-01-02 20:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:38:32 --> Controller Class Initialized
INFO - 2017-01-02 20:38:32 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:38:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:38:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:38:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:38:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:38:32 --> Final output sent to browser
DEBUG - 2017-01-02 20:38:32 --> Total execution time: 0.0135
INFO - 2017-01-02 20:38:33 --> Config Class Initialized
INFO - 2017-01-02 20:38:33 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:38:33 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:38:33 --> Utf8 Class Initialized
INFO - 2017-01-02 20:38:33 --> URI Class Initialized
INFO - 2017-01-02 20:38:33 --> Router Class Initialized
INFO - 2017-01-02 20:38:33 --> Output Class Initialized
INFO - 2017-01-02 20:38:33 --> Security Class Initialized
DEBUG - 2017-01-02 20:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:38:33 --> Input Class Initialized
INFO - 2017-01-02 20:38:33 --> Language Class Initialized
INFO - 2017-01-02 20:38:33 --> Loader Class Initialized
INFO - 2017-01-02 20:38:33 --> Database Driver Class Initialized
INFO - 2017-01-02 20:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:38:33 --> Controller Class Initialized
INFO - 2017-01-02 20:38:33 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:38:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:38:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:38:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:38:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:38:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:38:33 --> Final output sent to browser
DEBUG - 2017-01-02 20:38:33 --> Total execution time: 0.0151
INFO - 2017-01-02 20:38:35 --> Config Class Initialized
INFO - 2017-01-02 20:38:35 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:38:35 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:38:35 --> Utf8 Class Initialized
INFO - 2017-01-02 20:38:35 --> URI Class Initialized
DEBUG - 2017-01-02 20:38:35 --> No URI present. Default controller set.
INFO - 2017-01-02 20:38:35 --> Router Class Initialized
INFO - 2017-01-02 20:38:35 --> Output Class Initialized
INFO - 2017-01-02 20:38:35 --> Security Class Initialized
DEBUG - 2017-01-02 20:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:38:35 --> Input Class Initialized
INFO - 2017-01-02 20:38:35 --> Language Class Initialized
INFO - 2017-01-02 20:38:35 --> Loader Class Initialized
INFO - 2017-01-02 20:38:35 --> Database Driver Class Initialized
INFO - 2017-01-02 20:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:38:35 --> Controller Class Initialized
INFO - 2017-01-02 20:38:35 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:38:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:38:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:38:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:38:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:38:35 --> Final output sent to browser
DEBUG - 2017-01-02 20:38:35 --> Total execution time: 0.0130
INFO - 2017-01-02 20:38:35 --> Config Class Initialized
INFO - 2017-01-02 20:38:35 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:38:35 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:38:35 --> Utf8 Class Initialized
INFO - 2017-01-02 20:38:35 --> URI Class Initialized
INFO - 2017-01-02 20:38:35 --> Router Class Initialized
INFO - 2017-01-02 20:38:35 --> Output Class Initialized
INFO - 2017-01-02 20:38:35 --> Security Class Initialized
DEBUG - 2017-01-02 20:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:38:35 --> Input Class Initialized
INFO - 2017-01-02 20:38:35 --> Language Class Initialized
INFO - 2017-01-02 20:38:35 --> Loader Class Initialized
INFO - 2017-01-02 20:38:35 --> Database Driver Class Initialized
INFO - 2017-01-02 20:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:38:35 --> Controller Class Initialized
INFO - 2017-01-02 20:38:35 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:38:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:38:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:38:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:38:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:38:35 --> Final output sent to browser
DEBUG - 2017-01-02 20:38:35 --> Total execution time: 0.0134
INFO - 2017-01-02 20:38:37 --> Config Class Initialized
INFO - 2017-01-02 20:38:37 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:38:37 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:38:37 --> Utf8 Class Initialized
INFO - 2017-01-02 20:38:37 --> URI Class Initialized
INFO - 2017-01-02 20:38:37 --> Router Class Initialized
INFO - 2017-01-02 20:38:37 --> Output Class Initialized
INFO - 2017-01-02 20:38:37 --> Security Class Initialized
DEBUG - 2017-01-02 20:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:38:37 --> Input Class Initialized
INFO - 2017-01-02 20:38:37 --> Language Class Initialized
ERROR - 2017-01-02 20:38:37 --> 404 Page Not Found: Templates/usuario
INFO - 2017-01-02 20:44:59 --> Config Class Initialized
INFO - 2017-01-02 20:44:59 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:44:59 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:44:59 --> Utf8 Class Initialized
INFO - 2017-01-02 20:44:59 --> URI Class Initialized
DEBUG - 2017-01-02 20:44:59 --> No URI present. Default controller set.
INFO - 2017-01-02 20:44:59 --> Router Class Initialized
INFO - 2017-01-02 20:44:59 --> Output Class Initialized
INFO - 2017-01-02 20:44:59 --> Security Class Initialized
DEBUG - 2017-01-02 20:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:44:59 --> Input Class Initialized
INFO - 2017-01-02 20:44:59 --> Language Class Initialized
INFO - 2017-01-02 20:44:59 --> Loader Class Initialized
INFO - 2017-01-02 20:44:59 --> Database Driver Class Initialized
INFO - 2017-01-02 20:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:44:59 --> Controller Class Initialized
INFO - 2017-01-02 20:44:59 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:44:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:44:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:44:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:44:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:44:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:44:59 --> Final output sent to browser
DEBUG - 2017-01-02 20:44:59 --> Total execution time: 0.0131
INFO - 2017-01-02 20:44:59 --> Config Class Initialized
INFO - 2017-01-02 20:44:59 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:44:59 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:44:59 --> Utf8 Class Initialized
INFO - 2017-01-02 20:44:59 --> URI Class Initialized
INFO - 2017-01-02 20:44:59 --> Router Class Initialized
INFO - 2017-01-02 20:44:59 --> Output Class Initialized
INFO - 2017-01-02 20:44:59 --> Security Class Initialized
DEBUG - 2017-01-02 20:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:44:59 --> Input Class Initialized
INFO - 2017-01-02 20:44:59 --> Language Class Initialized
INFO - 2017-01-02 20:44:59 --> Loader Class Initialized
INFO - 2017-01-02 20:44:59 --> Database Driver Class Initialized
INFO - 2017-01-02 20:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:44:59 --> Controller Class Initialized
INFO - 2017-01-02 20:44:59 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:44:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:44:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:44:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:44:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:44:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:44:59 --> Final output sent to browser
DEBUG - 2017-01-02 20:44:59 --> Total execution time: 0.0139
INFO - 2017-01-02 20:45:01 --> Config Class Initialized
INFO - 2017-01-02 20:45:01 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:45:01 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:45:01 --> Utf8 Class Initialized
INFO - 2017-01-02 20:45:01 --> URI Class Initialized
DEBUG - 2017-01-02 20:45:01 --> No URI present. Default controller set.
INFO - 2017-01-02 20:45:01 --> Router Class Initialized
INFO - 2017-01-02 20:45:01 --> Output Class Initialized
INFO - 2017-01-02 20:45:01 --> Security Class Initialized
DEBUG - 2017-01-02 20:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:45:01 --> Input Class Initialized
INFO - 2017-01-02 20:45:01 --> Language Class Initialized
INFO - 2017-01-02 20:45:01 --> Loader Class Initialized
INFO - 2017-01-02 20:45:01 --> Database Driver Class Initialized
INFO - 2017-01-02 20:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:45:01 --> Controller Class Initialized
INFO - 2017-01-02 20:45:01 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:45:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:45:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:45:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:45:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:45:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:45:01 --> Final output sent to browser
DEBUG - 2017-01-02 20:45:01 --> Total execution time: 0.0129
INFO - 2017-01-02 20:45:02 --> Config Class Initialized
INFO - 2017-01-02 20:45:02 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:45:02 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:45:02 --> Utf8 Class Initialized
INFO - 2017-01-02 20:45:02 --> URI Class Initialized
INFO - 2017-01-02 20:45:02 --> Router Class Initialized
INFO - 2017-01-02 20:45:02 --> Output Class Initialized
INFO - 2017-01-02 20:45:02 --> Security Class Initialized
DEBUG - 2017-01-02 20:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:45:02 --> Input Class Initialized
INFO - 2017-01-02 20:45:02 --> Language Class Initialized
INFO - 2017-01-02 20:45:02 --> Loader Class Initialized
INFO - 2017-01-02 20:45:02 --> Database Driver Class Initialized
INFO - 2017-01-02 20:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:45:02 --> Controller Class Initialized
INFO - 2017-01-02 20:45:02 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:45:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:45:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:45:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:45:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:45:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:45:02 --> Final output sent to browser
DEBUG - 2017-01-02 20:45:02 --> Total execution time: 0.0134
INFO - 2017-01-02 20:45:47 --> Config Class Initialized
INFO - 2017-01-02 20:45:47 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:45:47 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:45:47 --> Utf8 Class Initialized
INFO - 2017-01-02 20:45:47 --> URI Class Initialized
DEBUG - 2017-01-02 20:45:47 --> No URI present. Default controller set.
INFO - 2017-01-02 20:45:47 --> Router Class Initialized
INFO - 2017-01-02 20:45:47 --> Output Class Initialized
INFO - 2017-01-02 20:45:47 --> Security Class Initialized
DEBUG - 2017-01-02 20:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:45:47 --> Input Class Initialized
INFO - 2017-01-02 20:45:47 --> Language Class Initialized
INFO - 2017-01-02 20:45:47 --> Loader Class Initialized
INFO - 2017-01-02 20:45:47 --> Database Driver Class Initialized
INFO - 2017-01-02 20:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:45:47 --> Controller Class Initialized
INFO - 2017-01-02 20:45:47 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:45:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:45:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:45:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:45:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:45:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:45:47 --> Final output sent to browser
DEBUG - 2017-01-02 20:45:47 --> Total execution time: 0.0140
INFO - 2017-01-02 20:45:47 --> Config Class Initialized
INFO - 2017-01-02 20:45:47 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:45:47 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:45:47 --> Utf8 Class Initialized
INFO - 2017-01-02 20:45:47 --> URI Class Initialized
INFO - 2017-01-02 20:45:47 --> Router Class Initialized
INFO - 2017-01-02 20:45:47 --> Output Class Initialized
INFO - 2017-01-02 20:45:47 --> Security Class Initialized
DEBUG - 2017-01-02 20:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:45:47 --> Input Class Initialized
INFO - 2017-01-02 20:45:47 --> Language Class Initialized
INFO - 2017-01-02 20:45:47 --> Loader Class Initialized
INFO - 2017-01-02 20:45:47 --> Database Driver Class Initialized
INFO - 2017-01-02 20:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:45:47 --> Controller Class Initialized
INFO - 2017-01-02 20:45:47 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:45:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:45:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:45:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:45:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:45:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:45:47 --> Final output sent to browser
DEBUG - 2017-01-02 20:45:47 --> Total execution time: 0.0136
INFO - 2017-01-02 20:45:58 --> Config Class Initialized
INFO - 2017-01-02 20:45:58 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:45:58 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:45:58 --> Utf8 Class Initialized
INFO - 2017-01-02 20:45:58 --> URI Class Initialized
INFO - 2017-01-02 20:45:58 --> Router Class Initialized
INFO - 2017-01-02 20:45:58 --> Output Class Initialized
INFO - 2017-01-02 20:45:58 --> Security Class Initialized
DEBUG - 2017-01-02 20:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:45:58 --> Input Class Initialized
INFO - 2017-01-02 20:45:58 --> Language Class Initialized
INFO - 2017-01-02 20:45:58 --> Loader Class Initialized
INFO - 2017-01-02 20:45:58 --> Database Driver Class Initialized
INFO - 2017-01-02 20:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:45:58 --> Controller Class Initialized
INFO - 2017-01-02 20:45:58 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:45:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:45:58 --> Final output sent to browser
DEBUG - 2017-01-02 20:45:58 --> Total execution time: 0.0132
INFO - 2017-01-02 20:48:59 --> Config Class Initialized
INFO - 2017-01-02 20:48:59 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:48:59 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:48:59 --> Utf8 Class Initialized
INFO - 2017-01-02 20:48:59 --> URI Class Initialized
DEBUG - 2017-01-02 20:48:59 --> No URI present. Default controller set.
INFO - 2017-01-02 20:48:59 --> Router Class Initialized
INFO - 2017-01-02 20:48:59 --> Output Class Initialized
INFO - 2017-01-02 20:48:59 --> Security Class Initialized
DEBUG - 2017-01-02 20:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:48:59 --> Input Class Initialized
INFO - 2017-01-02 20:48:59 --> Language Class Initialized
INFO - 2017-01-02 20:48:59 --> Loader Class Initialized
INFO - 2017-01-02 20:48:59 --> Database Driver Class Initialized
INFO - 2017-01-02 20:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:48:59 --> Controller Class Initialized
INFO - 2017-01-02 20:48:59 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:48:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:48:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:48:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:48:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:48:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:48:59 --> Final output sent to browser
DEBUG - 2017-01-02 20:48:59 --> Total execution time: 0.3645
INFO - 2017-01-02 20:49:00 --> Config Class Initialized
INFO - 2017-01-02 20:49:00 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:49:00 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:49:00 --> Utf8 Class Initialized
INFO - 2017-01-02 20:49:00 --> URI Class Initialized
INFO - 2017-01-02 20:49:00 --> Router Class Initialized
INFO - 2017-01-02 20:49:00 --> Output Class Initialized
INFO - 2017-01-02 20:49:00 --> Security Class Initialized
DEBUG - 2017-01-02 20:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:49:00 --> Input Class Initialized
INFO - 2017-01-02 20:49:00 --> Language Class Initialized
INFO - 2017-01-02 20:49:00 --> Loader Class Initialized
INFO - 2017-01-02 20:49:00 --> Database Driver Class Initialized
INFO - 2017-01-02 20:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:49:00 --> Controller Class Initialized
INFO - 2017-01-02 20:49:00 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:49:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:49:00 --> Final output sent to browser
DEBUG - 2017-01-02 20:49:00 --> Total execution time: 0.0136
INFO - 2017-01-02 20:49:03 --> Config Class Initialized
INFO - 2017-01-02 20:49:03 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:49:03 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:49:03 --> Utf8 Class Initialized
INFO - 2017-01-02 20:49:03 --> URI Class Initialized
INFO - 2017-01-02 20:49:03 --> Router Class Initialized
INFO - 2017-01-02 20:49:03 --> Output Class Initialized
INFO - 2017-01-02 20:49:03 --> Security Class Initialized
DEBUG - 2017-01-02 20:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:49:03 --> Input Class Initialized
INFO - 2017-01-02 20:49:03 --> Language Class Initialized
ERROR - 2017-01-02 20:49:03 --> 404 Page Not Found: Templates/usuario
INFO - 2017-01-02 20:49:56 --> Config Class Initialized
INFO - 2017-01-02 20:49:56 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:49:56 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:49:56 --> Utf8 Class Initialized
INFO - 2017-01-02 20:49:56 --> URI Class Initialized
INFO - 2017-01-02 20:49:56 --> Router Class Initialized
INFO - 2017-01-02 20:49:56 --> Output Class Initialized
INFO - 2017-01-02 20:49:56 --> Security Class Initialized
DEBUG - 2017-01-02 20:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:49:56 --> Input Class Initialized
INFO - 2017-01-02 20:49:56 --> Language Class Initialized
INFO - 2017-01-02 20:49:56 --> Loader Class Initialized
INFO - 2017-01-02 20:49:56 --> Database Driver Class Initialized
INFO - 2017-01-02 20:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:49:56 --> Controller Class Initialized
INFO - 2017-01-02 20:49:56 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:49:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:49:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:49:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:49:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:49:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:49:56 --> Final output sent to browser
DEBUG - 2017-01-02 20:49:56 --> Total execution time: 0.1336
INFO - 2017-01-02 20:49:57 --> Config Class Initialized
INFO - 2017-01-02 20:49:57 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:49:57 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:49:57 --> Utf8 Class Initialized
INFO - 2017-01-02 20:49:57 --> URI Class Initialized
INFO - 2017-01-02 20:49:57 --> Router Class Initialized
INFO - 2017-01-02 20:49:57 --> Output Class Initialized
INFO - 2017-01-02 20:49:57 --> Security Class Initialized
DEBUG - 2017-01-02 20:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:49:57 --> Input Class Initialized
INFO - 2017-01-02 20:49:57 --> Language Class Initialized
INFO - 2017-01-02 20:49:57 --> Loader Class Initialized
INFO - 2017-01-02 20:49:57 --> Database Driver Class Initialized
INFO - 2017-01-02 20:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:49:57 --> Controller Class Initialized
INFO - 2017-01-02 20:49:57 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:49:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:49:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:49:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:49:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:49:57 --> Final output sent to browser
DEBUG - 2017-01-02 20:49:57 --> Total execution time: 0.0139
INFO - 2017-01-02 20:53:44 --> Config Class Initialized
INFO - 2017-01-02 20:53:44 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:53:44 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:53:44 --> Utf8 Class Initialized
INFO - 2017-01-02 20:53:44 --> URI Class Initialized
DEBUG - 2017-01-02 20:53:44 --> No URI present. Default controller set.
INFO - 2017-01-02 20:53:44 --> Router Class Initialized
INFO - 2017-01-02 20:53:44 --> Output Class Initialized
INFO - 2017-01-02 20:53:44 --> Security Class Initialized
DEBUG - 2017-01-02 20:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:53:44 --> Input Class Initialized
INFO - 2017-01-02 20:53:44 --> Language Class Initialized
INFO - 2017-01-02 20:53:44 --> Loader Class Initialized
INFO - 2017-01-02 20:53:44 --> Database Driver Class Initialized
INFO - 2017-01-02 20:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:53:44 --> Controller Class Initialized
INFO - 2017-01-02 20:53:44 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:53:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:53:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:53:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:53:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:53:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:53:44 --> Final output sent to browser
DEBUG - 2017-01-02 20:53:44 --> Total execution time: 0.1155
INFO - 2017-01-02 20:53:45 --> Config Class Initialized
INFO - 2017-01-02 20:53:45 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:53:45 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:53:45 --> Utf8 Class Initialized
INFO - 2017-01-02 20:53:45 --> URI Class Initialized
INFO - 2017-01-02 20:53:45 --> Router Class Initialized
INFO - 2017-01-02 20:53:45 --> Output Class Initialized
INFO - 2017-01-02 20:53:45 --> Security Class Initialized
DEBUG - 2017-01-02 20:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:53:45 --> Input Class Initialized
INFO - 2017-01-02 20:53:45 --> Language Class Initialized
INFO - 2017-01-02 20:53:45 --> Loader Class Initialized
INFO - 2017-01-02 20:53:45 --> Database Driver Class Initialized
INFO - 2017-01-02 20:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:53:45 --> Controller Class Initialized
INFO - 2017-01-02 20:53:45 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:53:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:53:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:53:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:53:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:53:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:53:45 --> Final output sent to browser
DEBUG - 2017-01-02 20:53:45 --> Total execution time: 0.0137
INFO - 2017-01-02 20:54:07 --> Config Class Initialized
INFO - 2017-01-02 20:54:07 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:54:07 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:54:07 --> Utf8 Class Initialized
INFO - 2017-01-02 20:54:07 --> URI Class Initialized
INFO - 2017-01-02 20:54:07 --> Router Class Initialized
INFO - 2017-01-02 20:54:07 --> Output Class Initialized
INFO - 2017-01-02 20:54:07 --> Security Class Initialized
DEBUG - 2017-01-02 20:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:54:07 --> Input Class Initialized
INFO - 2017-01-02 20:54:07 --> Language Class Initialized
INFO - 2017-01-02 20:54:07 --> Loader Class Initialized
INFO - 2017-01-02 20:54:07 --> Database Driver Class Initialized
INFO - 2017-01-02 20:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:54:07 --> Controller Class Initialized
INFO - 2017-01-02 20:54:07 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:54:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:54:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:54:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:54:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:54:07 --> Final output sent to browser
DEBUG - 2017-01-02 20:54:07 --> Total execution time: 0.0234
INFO - 2017-01-02 20:57:37 --> Config Class Initialized
INFO - 2017-01-02 20:57:37 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:57:38 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:57:38 --> Utf8 Class Initialized
INFO - 2017-01-02 20:57:38 --> URI Class Initialized
DEBUG - 2017-01-02 20:57:38 --> No URI present. Default controller set.
INFO - 2017-01-02 20:57:38 --> Router Class Initialized
INFO - 2017-01-02 20:57:38 --> Output Class Initialized
INFO - 2017-01-02 20:57:38 --> Security Class Initialized
DEBUG - 2017-01-02 20:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:57:38 --> Input Class Initialized
INFO - 2017-01-02 20:57:38 --> Language Class Initialized
INFO - 2017-01-02 20:57:38 --> Loader Class Initialized
INFO - 2017-01-02 20:57:38 --> Database Driver Class Initialized
INFO - 2017-01-02 20:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:57:39 --> Controller Class Initialized
INFO - 2017-01-02 20:57:39 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:57:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:57:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:57:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:57:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:57:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:57:39 --> Final output sent to browser
DEBUG - 2017-01-02 20:57:39 --> Total execution time: 1.5600
INFO - 2017-01-02 20:57:39 --> Config Class Initialized
INFO - 2017-01-02 20:57:39 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:57:39 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:57:39 --> Utf8 Class Initialized
INFO - 2017-01-02 20:57:39 --> URI Class Initialized
INFO - 2017-01-02 20:57:39 --> Router Class Initialized
INFO - 2017-01-02 20:57:40 --> Output Class Initialized
INFO - 2017-01-02 20:57:40 --> Config Class Initialized
INFO - 2017-01-02 20:57:40 --> Hooks Class Initialized
INFO - 2017-01-02 20:57:40 --> Security Class Initialized
DEBUG - 2017-01-02 20:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:57:40 --> Input Class Initialized
INFO - 2017-01-02 20:57:40 --> Language Class Initialized
DEBUG - 2017-01-02 20:57:40 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:57:40 --> Utf8 Class Initialized
INFO - 2017-01-02 20:57:40 --> URI Class Initialized
ERROR - 2017-01-02 20:57:40 --> 404 Page Not Found: Templates/usuario
INFO - 2017-01-02 20:57:40 --> Router Class Initialized
INFO - 2017-01-02 20:57:40 --> Output Class Initialized
INFO - 2017-01-02 20:57:40 --> Security Class Initialized
DEBUG - 2017-01-02 20:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:57:40 --> Input Class Initialized
INFO - 2017-01-02 20:57:40 --> Language Class Initialized
INFO - 2017-01-02 20:57:40 --> Loader Class Initialized
INFO - 2017-01-02 20:57:40 --> Database Driver Class Initialized
INFO - 2017-01-02 20:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:57:40 --> Controller Class Initialized
INFO - 2017-01-02 20:57:40 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:57:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:57:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:57:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:57:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:57:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:57:40 --> Final output sent to browser
DEBUG - 2017-01-02 20:57:40 --> Total execution time: 0.5771
INFO - 2017-01-02 20:57:42 --> Config Class Initialized
INFO - 2017-01-02 20:57:42 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:57:42 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:57:42 --> Utf8 Class Initialized
INFO - 2017-01-02 20:57:42 --> URI Class Initialized
DEBUG - 2017-01-02 20:57:42 --> No URI present. Default controller set.
INFO - 2017-01-02 20:57:42 --> Router Class Initialized
INFO - 2017-01-02 20:57:42 --> Output Class Initialized
INFO - 2017-01-02 20:57:42 --> Security Class Initialized
DEBUG - 2017-01-02 20:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:57:42 --> Input Class Initialized
INFO - 2017-01-02 20:57:42 --> Language Class Initialized
INFO - 2017-01-02 20:57:42 --> Loader Class Initialized
INFO - 2017-01-02 20:57:42 --> Database Driver Class Initialized
INFO - 2017-01-02 20:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:57:42 --> Controller Class Initialized
INFO - 2017-01-02 20:57:42 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:57:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:57:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:57:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:57:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:57:42 --> Final output sent to browser
DEBUG - 2017-01-02 20:57:42 --> Total execution time: 0.0137
INFO - 2017-01-02 20:57:42 --> Config Class Initialized
INFO - 2017-01-02 20:57:42 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:57:42 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:57:42 --> Utf8 Class Initialized
INFO - 2017-01-02 20:57:42 --> URI Class Initialized
INFO - 2017-01-02 20:57:42 --> Router Class Initialized
INFO - 2017-01-02 20:57:42 --> Output Class Initialized
INFO - 2017-01-02 20:57:42 --> Security Class Initialized
DEBUG - 2017-01-02 20:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:57:42 --> Input Class Initialized
INFO - 2017-01-02 20:57:42 --> Language Class Initialized
ERROR - 2017-01-02 20:57:42 --> 404 Page Not Found: Templates/usuario
INFO - 2017-01-02 20:57:42 --> Config Class Initialized
INFO - 2017-01-02 20:57:42 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:57:42 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:57:42 --> Utf8 Class Initialized
INFO - 2017-01-02 20:57:42 --> URI Class Initialized
INFO - 2017-01-02 20:57:42 --> Router Class Initialized
INFO - 2017-01-02 20:57:42 --> Output Class Initialized
INFO - 2017-01-02 20:57:42 --> Security Class Initialized
DEBUG - 2017-01-02 20:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:57:42 --> Input Class Initialized
INFO - 2017-01-02 20:57:42 --> Language Class Initialized
INFO - 2017-01-02 20:57:42 --> Loader Class Initialized
INFO - 2017-01-02 20:57:42 --> Database Driver Class Initialized
INFO - 2017-01-02 20:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:57:42 --> Controller Class Initialized
INFO - 2017-01-02 20:57:42 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:57:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:57:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:57:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:57:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:57:42 --> Final output sent to browser
DEBUG - 2017-01-02 20:57:42 --> Total execution time: 0.0132
INFO - 2017-01-02 20:58:19 --> Config Class Initialized
INFO - 2017-01-02 20:58:19 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:58:19 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:58:19 --> Utf8 Class Initialized
INFO - 2017-01-02 20:58:19 --> URI Class Initialized
DEBUG - 2017-01-02 20:58:19 --> No URI present. Default controller set.
INFO - 2017-01-02 20:58:19 --> Router Class Initialized
INFO - 2017-01-02 20:58:19 --> Output Class Initialized
INFO - 2017-01-02 20:58:19 --> Security Class Initialized
DEBUG - 2017-01-02 20:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:58:19 --> Input Class Initialized
INFO - 2017-01-02 20:58:19 --> Language Class Initialized
INFO - 2017-01-02 20:58:19 --> Loader Class Initialized
INFO - 2017-01-02 20:58:19 --> Database Driver Class Initialized
INFO - 2017-01-02 20:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:58:20 --> Controller Class Initialized
INFO - 2017-01-02 20:58:20 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:58:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:58:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:58:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:58:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:58:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:58:20 --> Final output sent to browser
DEBUG - 2017-01-02 20:58:20 --> Total execution time: 1.1432
INFO - 2017-01-02 20:58:20 --> Config Class Initialized
INFO - 2017-01-02 20:58:20 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:58:20 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:58:20 --> Utf8 Class Initialized
INFO - 2017-01-02 20:58:20 --> URI Class Initialized
INFO - 2017-01-02 20:58:20 --> Router Class Initialized
INFO - 2017-01-02 20:58:20 --> Output Class Initialized
INFO - 2017-01-02 20:58:20 --> Security Class Initialized
DEBUG - 2017-01-02 20:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:58:20 --> Input Class Initialized
INFO - 2017-01-02 20:58:20 --> Language Class Initialized
ERROR - 2017-01-02 20:58:20 --> 404 Page Not Found: Templates/usuario
INFO - 2017-01-02 20:58:21 --> Config Class Initialized
INFO - 2017-01-02 20:58:21 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:58:21 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:58:21 --> Utf8 Class Initialized
INFO - 2017-01-02 20:58:21 --> URI Class Initialized
INFO - 2017-01-02 20:58:21 --> Router Class Initialized
INFO - 2017-01-02 20:58:21 --> Output Class Initialized
INFO - 2017-01-02 20:58:21 --> Security Class Initialized
DEBUG - 2017-01-02 20:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:58:21 --> Input Class Initialized
INFO - 2017-01-02 20:58:21 --> Language Class Initialized
INFO - 2017-01-02 20:58:21 --> Loader Class Initialized
INFO - 2017-01-02 20:58:21 --> Database Driver Class Initialized
INFO - 2017-01-02 20:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:58:21 --> Controller Class Initialized
INFO - 2017-01-02 20:58:21 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:58:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:58:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:58:21 --> Final output sent to browser
DEBUG - 2017-01-02 20:58:21 --> Total execution time: 0.0136
INFO - 2017-01-02 20:58:23 --> Config Class Initialized
INFO - 2017-01-02 20:58:23 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:58:23 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:58:23 --> Utf8 Class Initialized
INFO - 2017-01-02 20:58:23 --> URI Class Initialized
DEBUG - 2017-01-02 20:58:23 --> No URI present. Default controller set.
INFO - 2017-01-02 20:58:23 --> Router Class Initialized
INFO - 2017-01-02 20:58:23 --> Output Class Initialized
INFO - 2017-01-02 20:58:23 --> Security Class Initialized
DEBUG - 2017-01-02 20:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:58:23 --> Input Class Initialized
INFO - 2017-01-02 20:58:23 --> Language Class Initialized
INFO - 2017-01-02 20:58:23 --> Loader Class Initialized
INFO - 2017-01-02 20:58:23 --> Database Driver Class Initialized
INFO - 2017-01-02 20:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:58:23 --> Controller Class Initialized
INFO - 2017-01-02 20:58:23 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:58:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:58:23 --> Final output sent to browser
DEBUG - 2017-01-02 20:58:23 --> Total execution time: 0.0171
INFO - 2017-01-02 20:58:23 --> Config Class Initialized
INFO - 2017-01-02 20:58:23 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:58:23 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:58:23 --> Utf8 Class Initialized
INFO - 2017-01-02 20:58:23 --> URI Class Initialized
INFO - 2017-01-02 20:58:23 --> Router Class Initialized
INFO - 2017-01-02 20:58:23 --> Output Class Initialized
INFO - 2017-01-02 20:58:23 --> Security Class Initialized
DEBUG - 2017-01-02 20:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:58:23 --> Input Class Initialized
INFO - 2017-01-02 20:58:23 --> Language Class Initialized
ERROR - 2017-01-02 20:58:23 --> 404 Page Not Found: Templates/usuario
INFO - 2017-01-02 20:58:23 --> Config Class Initialized
INFO - 2017-01-02 20:58:23 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:58:23 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:58:23 --> Utf8 Class Initialized
INFO - 2017-01-02 20:58:23 --> URI Class Initialized
INFO - 2017-01-02 20:58:23 --> Router Class Initialized
INFO - 2017-01-02 20:58:23 --> Output Class Initialized
INFO - 2017-01-02 20:58:23 --> Security Class Initialized
DEBUG - 2017-01-02 20:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:58:23 --> Input Class Initialized
INFO - 2017-01-02 20:58:23 --> Language Class Initialized
INFO - 2017-01-02 20:58:23 --> Loader Class Initialized
INFO - 2017-01-02 20:58:23 --> Database Driver Class Initialized
INFO - 2017-01-02 20:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:58:23 --> Controller Class Initialized
INFO - 2017-01-02 20:58:23 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:58:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:58:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:58:23 --> Final output sent to browser
DEBUG - 2017-01-02 20:58:23 --> Total execution time: 0.0533
INFO - 2017-01-02 20:58:25 --> Config Class Initialized
INFO - 2017-01-02 20:58:25 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:58:25 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:58:25 --> Utf8 Class Initialized
INFO - 2017-01-02 20:58:25 --> URI Class Initialized
DEBUG - 2017-01-02 20:58:25 --> No URI present. Default controller set.
INFO - 2017-01-02 20:58:25 --> Router Class Initialized
INFO - 2017-01-02 20:58:25 --> Output Class Initialized
INFO - 2017-01-02 20:58:25 --> Security Class Initialized
DEBUG - 2017-01-02 20:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:58:25 --> Input Class Initialized
INFO - 2017-01-02 20:58:25 --> Language Class Initialized
INFO - 2017-01-02 20:58:25 --> Loader Class Initialized
INFO - 2017-01-02 20:58:25 --> Database Driver Class Initialized
INFO - 2017-01-02 20:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:58:25 --> Controller Class Initialized
INFO - 2017-01-02 20:58:25 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:58:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:58:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:58:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:58:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:58:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:58:25 --> Final output sent to browser
DEBUG - 2017-01-02 20:58:25 --> Total execution time: 0.0137
INFO - 2017-01-02 20:58:25 --> Config Class Initialized
INFO - 2017-01-02 20:58:25 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:58:25 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:58:25 --> Utf8 Class Initialized
INFO - 2017-01-02 20:58:25 --> URI Class Initialized
INFO - 2017-01-02 20:58:25 --> Router Class Initialized
INFO - 2017-01-02 20:58:25 --> Output Class Initialized
INFO - 2017-01-02 20:58:25 --> Security Class Initialized
DEBUG - 2017-01-02 20:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:58:25 --> Input Class Initialized
INFO - 2017-01-02 20:58:25 --> Language Class Initialized
ERROR - 2017-01-02 20:58:25 --> 404 Page Not Found: Templates/usuario
INFO - 2017-01-02 20:58:25 --> Config Class Initialized
INFO - 2017-01-02 20:58:25 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:58:25 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:58:25 --> Utf8 Class Initialized
INFO - 2017-01-02 20:58:25 --> URI Class Initialized
INFO - 2017-01-02 20:58:25 --> Router Class Initialized
INFO - 2017-01-02 20:58:25 --> Output Class Initialized
INFO - 2017-01-02 20:58:25 --> Security Class Initialized
DEBUG - 2017-01-02 20:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:58:25 --> Input Class Initialized
INFO - 2017-01-02 20:58:25 --> Language Class Initialized
INFO - 2017-01-02 20:58:25 --> Loader Class Initialized
INFO - 2017-01-02 20:58:25 --> Database Driver Class Initialized
INFO - 2017-01-02 20:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:58:25 --> Controller Class Initialized
INFO - 2017-01-02 20:58:25 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:58:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:58:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:58:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:58:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:58:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:58:25 --> Final output sent to browser
DEBUG - 2017-01-02 20:58:25 --> Total execution time: 0.0161
INFO - 2017-01-02 20:58:28 --> Config Class Initialized
INFO - 2017-01-02 20:58:28 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:58:28 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:58:28 --> Utf8 Class Initialized
INFO - 2017-01-02 20:58:28 --> URI Class Initialized
DEBUG - 2017-01-02 20:58:28 --> No URI present. Default controller set.
INFO - 2017-01-02 20:58:28 --> Router Class Initialized
INFO - 2017-01-02 20:58:28 --> Output Class Initialized
INFO - 2017-01-02 20:58:28 --> Security Class Initialized
DEBUG - 2017-01-02 20:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:58:28 --> Input Class Initialized
INFO - 2017-01-02 20:58:28 --> Language Class Initialized
INFO - 2017-01-02 20:58:28 --> Loader Class Initialized
INFO - 2017-01-02 20:58:28 --> Database Driver Class Initialized
INFO - 2017-01-02 20:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:58:28 --> Controller Class Initialized
INFO - 2017-01-02 20:58:28 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:58:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:58:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:58:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:58:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:58:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:58:28 --> Final output sent to browser
DEBUG - 2017-01-02 20:58:28 --> Total execution time: 0.0543
INFO - 2017-01-02 20:58:28 --> Config Class Initialized
INFO - 2017-01-02 20:58:28 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:58:28 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:58:28 --> Utf8 Class Initialized
INFO - 2017-01-02 20:58:28 --> URI Class Initialized
INFO - 2017-01-02 20:58:28 --> Router Class Initialized
INFO - 2017-01-02 20:58:28 --> Output Class Initialized
INFO - 2017-01-02 20:58:28 --> Security Class Initialized
DEBUG - 2017-01-02 20:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:58:28 --> Input Class Initialized
INFO - 2017-01-02 20:58:28 --> Language Class Initialized
ERROR - 2017-01-02 20:58:28 --> 404 Page Not Found: Templates/usuario
INFO - 2017-01-02 20:58:29 --> Config Class Initialized
INFO - 2017-01-02 20:58:29 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:58:29 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:58:29 --> Utf8 Class Initialized
INFO - 2017-01-02 20:58:29 --> URI Class Initialized
INFO - 2017-01-02 20:58:29 --> Router Class Initialized
INFO - 2017-01-02 20:58:29 --> Output Class Initialized
INFO - 2017-01-02 20:58:29 --> Security Class Initialized
DEBUG - 2017-01-02 20:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:58:29 --> Input Class Initialized
INFO - 2017-01-02 20:58:29 --> Language Class Initialized
INFO - 2017-01-02 20:58:29 --> Loader Class Initialized
INFO - 2017-01-02 20:58:29 --> Database Driver Class Initialized
INFO - 2017-01-02 20:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:58:29 --> Controller Class Initialized
INFO - 2017-01-02 20:58:29 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:58:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:58:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:58:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:58:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:58:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:58:29 --> Final output sent to browser
DEBUG - 2017-01-02 20:58:29 --> Total execution time: 0.0202
INFO - 2017-01-02 20:59:17 --> Config Class Initialized
INFO - 2017-01-02 20:59:17 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:59:17 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:59:17 --> Utf8 Class Initialized
INFO - 2017-01-02 20:59:17 --> URI Class Initialized
DEBUG - 2017-01-02 20:59:17 --> No URI present. Default controller set.
INFO - 2017-01-02 20:59:17 --> Router Class Initialized
INFO - 2017-01-02 20:59:17 --> Output Class Initialized
INFO - 2017-01-02 20:59:17 --> Security Class Initialized
DEBUG - 2017-01-02 20:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:59:17 --> Input Class Initialized
INFO - 2017-01-02 20:59:17 --> Language Class Initialized
INFO - 2017-01-02 20:59:17 --> Loader Class Initialized
INFO - 2017-01-02 20:59:17 --> Database Driver Class Initialized
INFO - 2017-01-02 20:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:59:18 --> Controller Class Initialized
INFO - 2017-01-02 20:59:18 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:59:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:59:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:59:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:59:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:59:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:59:18 --> Final output sent to browser
DEBUG - 2017-01-02 20:59:18 --> Total execution time: 1.4357
INFO - 2017-01-02 20:59:19 --> Config Class Initialized
INFO - 2017-01-02 20:59:19 --> Hooks Class Initialized
DEBUG - 2017-01-02 20:59:19 --> UTF-8 Support Enabled
INFO - 2017-01-02 20:59:19 --> Utf8 Class Initialized
INFO - 2017-01-02 20:59:19 --> URI Class Initialized
INFO - 2017-01-02 20:59:19 --> Router Class Initialized
INFO - 2017-01-02 20:59:19 --> Output Class Initialized
INFO - 2017-01-02 20:59:19 --> Security Class Initialized
DEBUG - 2017-01-02 20:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 20:59:19 --> Input Class Initialized
INFO - 2017-01-02 20:59:19 --> Language Class Initialized
INFO - 2017-01-02 20:59:19 --> Loader Class Initialized
INFO - 2017-01-02 20:59:19 --> Database Driver Class Initialized
INFO - 2017-01-02 20:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 20:59:19 --> Controller Class Initialized
INFO - 2017-01-02 20:59:19 --> Helper loaded: url_helper
DEBUG - 2017-01-02 20:59:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 20:59:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 20:59:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 20:59:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 20:59:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 20:59:20 --> Final output sent to browser
DEBUG - 2017-01-02 20:59:20 --> Total execution time: 0.9042
INFO - 2017-01-02 21:02:46 --> Config Class Initialized
INFO - 2017-01-02 21:02:46 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:02:46 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:02:46 --> Utf8 Class Initialized
INFO - 2017-01-02 21:02:46 --> URI Class Initialized
DEBUG - 2017-01-02 21:02:46 --> No URI present. Default controller set.
INFO - 2017-01-02 21:02:46 --> Router Class Initialized
INFO - 2017-01-02 21:02:46 --> Output Class Initialized
INFO - 2017-01-02 21:02:46 --> Security Class Initialized
DEBUG - 2017-01-02 21:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:02:46 --> Input Class Initialized
INFO - 2017-01-02 21:02:46 --> Language Class Initialized
INFO - 2017-01-02 21:02:46 --> Loader Class Initialized
INFO - 2017-01-02 21:02:47 --> Database Driver Class Initialized
INFO - 2017-01-02 21:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:02:47 --> Controller Class Initialized
INFO - 2017-01-02 21:02:47 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:02:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:02:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:02:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:02:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:02:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:02:47 --> Final output sent to browser
DEBUG - 2017-01-02 21:02:47 --> Total execution time: 1.0715
INFO - 2017-01-02 21:02:48 --> Config Class Initialized
INFO - 2017-01-02 21:02:48 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:02:48 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:02:48 --> Utf8 Class Initialized
INFO - 2017-01-02 21:02:48 --> URI Class Initialized
INFO - 2017-01-02 21:02:48 --> Router Class Initialized
INFO - 2017-01-02 21:02:48 --> Output Class Initialized
INFO - 2017-01-02 21:02:48 --> Security Class Initialized
DEBUG - 2017-01-02 21:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:02:48 --> Input Class Initialized
INFO - 2017-01-02 21:02:48 --> Language Class Initialized
INFO - 2017-01-02 21:02:48 --> Loader Class Initialized
INFO - 2017-01-02 21:02:49 --> Database Driver Class Initialized
INFO - 2017-01-02 21:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:02:49 --> Controller Class Initialized
INFO - 2017-01-02 21:02:49 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:02:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:02:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:02:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:02:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:02:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:02:49 --> Final output sent to browser
DEBUG - 2017-01-02 21:02:49 --> Total execution time: 0.8608
INFO - 2017-01-02 21:04:56 --> Config Class Initialized
INFO - 2017-01-02 21:04:56 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:04:56 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:04:56 --> Utf8 Class Initialized
INFO - 2017-01-02 21:04:56 --> URI Class Initialized
DEBUG - 2017-01-02 21:04:56 --> No URI present. Default controller set.
INFO - 2017-01-02 21:04:56 --> Router Class Initialized
INFO - 2017-01-02 21:04:56 --> Output Class Initialized
INFO - 2017-01-02 21:04:56 --> Security Class Initialized
DEBUG - 2017-01-02 21:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:04:56 --> Input Class Initialized
INFO - 2017-01-02 21:04:56 --> Language Class Initialized
INFO - 2017-01-02 21:04:56 --> Loader Class Initialized
INFO - 2017-01-02 21:04:56 --> Database Driver Class Initialized
INFO - 2017-01-02 21:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:04:57 --> Controller Class Initialized
INFO - 2017-01-02 21:04:57 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:04:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:04:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:04:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:04:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:04:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:04:57 --> Final output sent to browser
DEBUG - 2017-01-02 21:04:57 --> Total execution time: 1.3416
INFO - 2017-01-02 21:04:58 --> Config Class Initialized
INFO - 2017-01-02 21:04:58 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:04:58 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:04:58 --> Utf8 Class Initialized
INFO - 2017-01-02 21:04:58 --> URI Class Initialized
INFO - 2017-01-02 21:04:58 --> Router Class Initialized
INFO - 2017-01-02 21:04:58 --> Output Class Initialized
INFO - 2017-01-02 21:04:58 --> Security Class Initialized
DEBUG - 2017-01-02 21:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:04:58 --> Input Class Initialized
INFO - 2017-01-02 21:04:58 --> Language Class Initialized
INFO - 2017-01-02 21:04:58 --> Loader Class Initialized
INFO - 2017-01-02 21:04:58 --> Database Driver Class Initialized
INFO - 2017-01-02 21:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:04:58 --> Controller Class Initialized
INFO - 2017-01-02 21:04:58 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:04:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:04:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:04:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:04:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:04:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:04:58 --> Final output sent to browser
DEBUG - 2017-01-02 21:04:58 --> Total execution time: 0.7974
INFO - 2017-01-02 21:05:04 --> Config Class Initialized
INFO - 2017-01-02 21:05:04 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:05:05 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:05:05 --> Utf8 Class Initialized
INFO - 2017-01-02 21:05:05 --> URI Class Initialized
INFO - 2017-01-02 21:05:05 --> Router Class Initialized
INFO - 2017-01-02 21:05:05 --> Output Class Initialized
INFO - 2017-01-02 21:05:05 --> Security Class Initialized
DEBUG - 2017-01-02 21:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:05:05 --> Input Class Initialized
INFO - 2017-01-02 21:05:05 --> Language Class Initialized
ERROR - 2017-01-02 21:05:05 --> 404 Page Not Found: Templates/usuario
INFO - 2017-01-02 21:07:52 --> Config Class Initialized
INFO - 2017-01-02 21:07:52 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:07:52 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:07:52 --> Utf8 Class Initialized
INFO - 2017-01-02 21:07:52 --> URI Class Initialized
DEBUG - 2017-01-02 21:07:52 --> No URI present. Default controller set.
INFO - 2017-01-02 21:07:52 --> Router Class Initialized
INFO - 2017-01-02 21:07:52 --> Output Class Initialized
INFO - 2017-01-02 21:07:52 --> Security Class Initialized
DEBUG - 2017-01-02 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:07:52 --> Input Class Initialized
INFO - 2017-01-02 21:07:52 --> Language Class Initialized
INFO - 2017-01-02 21:07:52 --> Loader Class Initialized
INFO - 2017-01-02 21:07:53 --> Database Driver Class Initialized
INFO - 2017-01-02 21:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:07:53 --> Controller Class Initialized
INFO - 2017-01-02 21:07:53 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:07:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:07:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:07:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:07:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:07:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:07:53 --> Final output sent to browser
DEBUG - 2017-01-02 21:07:53 --> Total execution time: 0.7646
INFO - 2017-01-02 21:07:53 --> Config Class Initialized
INFO - 2017-01-02 21:07:53 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:07:53 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:07:53 --> Utf8 Class Initialized
INFO - 2017-01-02 21:07:53 --> URI Class Initialized
INFO - 2017-01-02 21:07:53 --> Router Class Initialized
INFO - 2017-01-02 21:07:54 --> Output Class Initialized
INFO - 2017-01-02 21:07:54 --> Security Class Initialized
DEBUG - 2017-01-02 21:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:07:54 --> Input Class Initialized
INFO - 2017-01-02 21:07:54 --> Language Class Initialized
ERROR - 2017-01-02 21:07:54 --> 404 Page Not Found: Templates/usuario
INFO - 2017-01-02 21:07:54 --> Config Class Initialized
INFO - 2017-01-02 21:07:54 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:07:54 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:07:54 --> Utf8 Class Initialized
INFO - 2017-01-02 21:07:54 --> URI Class Initialized
INFO - 2017-01-02 21:07:54 --> Router Class Initialized
INFO - 2017-01-02 21:07:54 --> Output Class Initialized
INFO - 2017-01-02 21:07:54 --> Security Class Initialized
DEBUG - 2017-01-02 21:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:07:54 --> Input Class Initialized
INFO - 2017-01-02 21:07:54 --> Language Class Initialized
INFO - 2017-01-02 21:07:54 --> Loader Class Initialized
INFO - 2017-01-02 21:07:54 --> Database Driver Class Initialized
INFO - 2017-01-02 21:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:07:54 --> Controller Class Initialized
INFO - 2017-01-02 21:07:54 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:07:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:07:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:07:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:07:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:07:54 --> Final output sent to browser
DEBUG - 2017-01-02 21:07:54 --> Total execution time: 0.7293
INFO - 2017-01-02 21:07:56 --> Config Class Initialized
INFO - 2017-01-02 21:07:56 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:07:56 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:07:56 --> Utf8 Class Initialized
INFO - 2017-01-02 21:07:56 --> URI Class Initialized
DEBUG - 2017-01-02 21:07:56 --> No URI present. Default controller set.
INFO - 2017-01-02 21:07:56 --> Router Class Initialized
INFO - 2017-01-02 21:07:56 --> Output Class Initialized
INFO - 2017-01-02 21:07:56 --> Security Class Initialized
DEBUG - 2017-01-02 21:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:07:56 --> Input Class Initialized
INFO - 2017-01-02 21:07:56 --> Language Class Initialized
INFO - 2017-01-02 21:07:56 --> Loader Class Initialized
INFO - 2017-01-02 21:07:57 --> Database Driver Class Initialized
INFO - 2017-01-02 21:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:07:57 --> Controller Class Initialized
INFO - 2017-01-02 21:07:57 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:07:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:07:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:07:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:07:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:07:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:07:57 --> Final output sent to browser
DEBUG - 2017-01-02 21:07:57 --> Total execution time: 0.7512
INFO - 2017-01-02 21:07:57 --> Config Class Initialized
INFO - 2017-01-02 21:07:57 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:07:57 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:07:58 --> Utf8 Class Initialized
INFO - 2017-01-02 21:07:58 --> URI Class Initialized
INFO - 2017-01-02 21:07:58 --> Router Class Initialized
INFO - 2017-01-02 21:07:58 --> Output Class Initialized
INFO - 2017-01-02 21:07:58 --> Security Class Initialized
DEBUG - 2017-01-02 21:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:07:58 --> Input Class Initialized
INFO - 2017-01-02 21:07:58 --> Language Class Initialized
INFO - 2017-01-02 21:07:58 --> Config Class Initialized
INFO - 2017-01-02 21:07:58 --> Hooks Class Initialized
ERROR - 2017-01-02 21:07:58 --> 404 Page Not Found: Templates/usuario
DEBUG - 2017-01-02 21:07:58 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:07:58 --> Utf8 Class Initialized
INFO - 2017-01-02 21:07:58 --> URI Class Initialized
INFO - 2017-01-02 21:07:58 --> Router Class Initialized
INFO - 2017-01-02 21:07:58 --> Output Class Initialized
INFO - 2017-01-02 21:07:58 --> Security Class Initialized
DEBUG - 2017-01-02 21:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:07:58 --> Input Class Initialized
INFO - 2017-01-02 21:07:58 --> Language Class Initialized
INFO - 2017-01-02 21:07:58 --> Loader Class Initialized
INFO - 2017-01-02 21:07:58 --> Database Driver Class Initialized
INFO - 2017-01-02 21:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:07:58 --> Controller Class Initialized
INFO - 2017-01-02 21:07:58 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:07:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:07:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:07:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:07:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:07:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:07:58 --> Final output sent to browser
DEBUG - 2017-01-02 21:07:58 --> Total execution time: 0.3802
INFO - 2017-01-02 21:08:04 --> Config Class Initialized
INFO - 2017-01-02 21:08:04 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:08:04 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:08:04 --> Utf8 Class Initialized
INFO - 2017-01-02 21:08:04 --> URI Class Initialized
DEBUG - 2017-01-02 21:08:04 --> No URI present. Default controller set.
INFO - 2017-01-02 21:08:04 --> Router Class Initialized
INFO - 2017-01-02 21:08:04 --> Output Class Initialized
INFO - 2017-01-02 21:08:04 --> Security Class Initialized
DEBUG - 2017-01-02 21:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:08:04 --> Input Class Initialized
INFO - 2017-01-02 21:08:04 --> Language Class Initialized
INFO - 2017-01-02 21:08:04 --> Loader Class Initialized
INFO - 2017-01-02 21:08:04 --> Database Driver Class Initialized
INFO - 2017-01-02 21:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:08:04 --> Controller Class Initialized
INFO - 2017-01-02 21:08:04 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:08:05 --> Final output sent to browser
DEBUG - 2017-01-02 21:08:05 --> Total execution time: 0.5607
INFO - 2017-01-02 21:08:05 --> Config Class Initialized
INFO - 2017-01-02 21:08:05 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:08:05 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:08:05 --> Utf8 Class Initialized
INFO - 2017-01-02 21:08:05 --> URI Class Initialized
INFO - 2017-01-02 21:08:05 --> Router Class Initialized
INFO - 2017-01-02 21:08:05 --> Output Class Initialized
INFO - 2017-01-02 21:08:05 --> Security Class Initialized
DEBUG - 2017-01-02 21:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:08:05 --> Input Class Initialized
INFO - 2017-01-02 21:08:05 --> Language Class Initialized
ERROR - 2017-01-02 21:08:05 --> 404 Page Not Found: Templates/usuario
INFO - 2017-01-02 21:08:05 --> Config Class Initialized
INFO - 2017-01-02 21:08:05 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:08:05 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:08:05 --> Utf8 Class Initialized
INFO - 2017-01-02 21:08:05 --> URI Class Initialized
INFO - 2017-01-02 21:08:05 --> Router Class Initialized
INFO - 2017-01-02 21:08:05 --> Output Class Initialized
INFO - 2017-01-02 21:08:05 --> Security Class Initialized
DEBUG - 2017-01-02 21:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:08:05 --> Input Class Initialized
INFO - 2017-01-02 21:08:05 --> Language Class Initialized
INFO - 2017-01-02 21:08:05 --> Loader Class Initialized
INFO - 2017-01-02 21:08:05 --> Database Driver Class Initialized
INFO - 2017-01-02 21:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:08:05 --> Controller Class Initialized
INFO - 2017-01-02 21:08:05 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:08:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:08:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:08:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:08:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:08:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:08:06 --> Final output sent to browser
DEBUG - 2017-01-02 21:08:06 --> Total execution time: 0.3617
INFO - 2017-01-02 21:13:04 --> Config Class Initialized
INFO - 2017-01-02 21:13:04 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:13:04 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:13:04 --> Utf8 Class Initialized
INFO - 2017-01-02 21:13:04 --> URI Class Initialized
DEBUG - 2017-01-02 21:13:04 --> No URI present. Default controller set.
INFO - 2017-01-02 21:13:04 --> Router Class Initialized
INFO - 2017-01-02 21:13:04 --> Output Class Initialized
INFO - 2017-01-02 21:13:04 --> Security Class Initialized
DEBUG - 2017-01-02 21:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:13:04 --> Input Class Initialized
INFO - 2017-01-02 21:13:04 --> Language Class Initialized
INFO - 2017-01-02 21:13:04 --> Loader Class Initialized
INFO - 2017-01-02 21:13:04 --> Database Driver Class Initialized
INFO - 2017-01-02 21:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:13:04 --> Controller Class Initialized
INFO - 2017-01-02 21:13:04 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:13:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:13:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:13:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:13:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:13:05 --> Final output sent to browser
DEBUG - 2017-01-02 21:13:05 --> Total execution time: 1.0295
INFO - 2017-01-02 21:13:05 --> Config Class Initialized
INFO - 2017-01-02 21:13:05 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:13:05 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:13:06 --> Utf8 Class Initialized
INFO - 2017-01-02 21:13:06 --> URI Class Initialized
INFO - 2017-01-02 21:13:06 --> Config Class Initialized
INFO - 2017-01-02 21:13:06 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:13:06 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:13:06 --> Utf8 Class Initialized
INFO - 2017-01-02 21:13:06 --> URI Class Initialized
INFO - 2017-01-02 21:13:06 --> Router Class Initialized
INFO - 2017-01-02 21:13:06 --> Router Class Initialized
INFO - 2017-01-02 21:13:06 --> Output Class Initialized
INFO - 2017-01-02 21:13:06 --> Output Class Initialized
INFO - 2017-01-02 21:13:06 --> Security Class Initialized
DEBUG - 2017-01-02 21:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:13:06 --> Input Class Initialized
INFO - 2017-01-02 21:13:06 --> Language Class Initialized
INFO - 2017-01-02 21:13:06 --> Security Class Initialized
ERROR - 2017-01-02 21:13:06 --> 404 Page Not Found: Templates/usuario
DEBUG - 2017-01-02 21:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:13:06 --> Input Class Initialized
INFO - 2017-01-02 21:13:06 --> Language Class Initialized
INFO - 2017-01-02 21:13:06 --> Loader Class Initialized
INFO - 2017-01-02 21:13:06 --> Database Driver Class Initialized
INFO - 2017-01-02 21:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:13:06 --> Controller Class Initialized
INFO - 2017-01-02 21:13:06 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:13:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:13:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:13:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:13:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:13:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:13:06 --> Final output sent to browser
DEBUG - 2017-01-02 21:13:06 --> Total execution time: 0.5658
INFO - 2017-01-02 21:20:10 --> Config Class Initialized
INFO - 2017-01-02 21:20:10 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:20:10 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:20:10 --> Utf8 Class Initialized
INFO - 2017-01-02 21:20:10 --> URI Class Initialized
DEBUG - 2017-01-02 21:20:10 --> No URI present. Default controller set.
INFO - 2017-01-02 21:20:10 --> Router Class Initialized
INFO - 2017-01-02 21:20:10 --> Output Class Initialized
INFO - 2017-01-02 21:20:10 --> Security Class Initialized
DEBUG - 2017-01-02 21:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:20:10 --> Input Class Initialized
INFO - 2017-01-02 21:20:10 --> Language Class Initialized
INFO - 2017-01-02 21:20:10 --> Loader Class Initialized
INFO - 2017-01-02 21:20:10 --> Database Driver Class Initialized
INFO - 2017-01-02 21:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:20:10 --> Controller Class Initialized
INFO - 2017-01-02 21:20:10 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:20:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:20:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:20:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:20:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:20:10 --> Final output sent to browser
DEBUG - 2017-01-02 21:20:10 --> Total execution time: 0.6209
INFO - 2017-01-02 21:20:11 --> Config Class Initialized
INFO - 2017-01-02 21:20:11 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:20:11 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:20:11 --> Utf8 Class Initialized
INFO - 2017-01-02 21:20:11 --> URI Class Initialized
INFO - 2017-01-02 21:20:11 --> Router Class Initialized
INFO - 2017-01-02 21:20:11 --> Output Class Initialized
INFO - 2017-01-02 21:20:11 --> Security Class Initialized
DEBUG - 2017-01-02 21:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:20:11 --> Input Class Initialized
INFO - 2017-01-02 21:20:11 --> Language Class Initialized
INFO - 2017-01-02 21:20:11 --> Loader Class Initialized
INFO - 2017-01-02 21:20:11 --> Database Driver Class Initialized
INFO - 2017-01-02 21:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:20:11 --> Controller Class Initialized
INFO - 2017-01-02 21:20:11 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:20:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:20:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:20:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:20:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:20:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:20:11 --> Final output sent to browser
DEBUG - 2017-01-02 21:20:11 --> Total execution time: 0.0140
INFO - 2017-01-02 21:20:14 --> Config Class Initialized
INFO - 2017-01-02 21:20:14 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:20:14 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:20:14 --> Utf8 Class Initialized
INFO - 2017-01-02 21:20:14 --> URI Class Initialized
DEBUG - 2017-01-02 21:20:14 --> No URI present. Default controller set.
INFO - 2017-01-02 21:20:14 --> Router Class Initialized
INFO - 2017-01-02 21:20:14 --> Output Class Initialized
INFO - 2017-01-02 21:20:14 --> Security Class Initialized
DEBUG - 2017-01-02 21:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:20:14 --> Input Class Initialized
INFO - 2017-01-02 21:20:14 --> Language Class Initialized
INFO - 2017-01-02 21:20:14 --> Loader Class Initialized
INFO - 2017-01-02 21:20:14 --> Database Driver Class Initialized
INFO - 2017-01-02 21:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:20:14 --> Controller Class Initialized
INFO - 2017-01-02 21:20:14 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:20:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:20:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:20:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:20:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:20:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:20:14 --> Final output sent to browser
DEBUG - 2017-01-02 21:20:14 --> Total execution time: 0.0143
INFO - 2017-01-02 21:20:14 --> Config Class Initialized
INFO - 2017-01-02 21:20:14 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:20:14 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:20:14 --> Utf8 Class Initialized
INFO - 2017-01-02 21:20:14 --> URI Class Initialized
INFO - 2017-01-02 21:20:14 --> Router Class Initialized
INFO - 2017-01-02 21:20:14 --> Output Class Initialized
INFO - 2017-01-02 21:20:14 --> Security Class Initialized
DEBUG - 2017-01-02 21:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:20:14 --> Input Class Initialized
INFO - 2017-01-02 21:20:14 --> Language Class Initialized
INFO - 2017-01-02 21:20:14 --> Loader Class Initialized
INFO - 2017-01-02 21:20:14 --> Database Driver Class Initialized
INFO - 2017-01-02 21:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:20:14 --> Controller Class Initialized
INFO - 2017-01-02 21:20:14 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:20:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:20:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:20:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:20:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:20:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:20:14 --> Config Class Initialized
INFO - 2017-01-02 21:20:14 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:20:14 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:20:14 --> Utf8 Class Initialized
INFO - 2017-01-02 21:20:14 --> Final output sent to browser
DEBUG - 2017-01-02 21:20:14 --> Total execution time: 0.0361
INFO - 2017-01-02 21:20:14 --> URI Class Initialized
DEBUG - 2017-01-02 21:20:14 --> No URI present. Default controller set.
INFO - 2017-01-02 21:20:14 --> Router Class Initialized
INFO - 2017-01-02 21:20:14 --> Output Class Initialized
INFO - 2017-01-02 21:20:14 --> Security Class Initialized
DEBUG - 2017-01-02 21:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:20:14 --> Input Class Initialized
INFO - 2017-01-02 21:20:14 --> Language Class Initialized
INFO - 2017-01-02 21:20:14 --> Loader Class Initialized
INFO - 2017-01-02 21:20:14 --> Database Driver Class Initialized
INFO - 2017-01-02 21:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:20:14 --> Controller Class Initialized
INFO - 2017-01-02 21:20:14 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:20:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:20:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:20:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:20:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:20:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:20:14 --> Final output sent to browser
DEBUG - 2017-01-02 21:20:14 --> Total execution time: 0.0212
INFO - 2017-01-02 21:20:15 --> Config Class Initialized
INFO - 2017-01-02 21:20:15 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:20:15 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:20:15 --> Utf8 Class Initialized
INFO - 2017-01-02 21:20:15 --> URI Class Initialized
INFO - 2017-01-02 21:20:15 --> Router Class Initialized
INFO - 2017-01-02 21:20:15 --> Output Class Initialized
INFO - 2017-01-02 21:20:15 --> Security Class Initialized
DEBUG - 2017-01-02 21:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:20:15 --> Input Class Initialized
INFO - 2017-01-02 21:20:15 --> Language Class Initialized
INFO - 2017-01-02 21:20:15 --> Loader Class Initialized
INFO - 2017-01-02 21:20:15 --> Database Driver Class Initialized
INFO - 2017-01-02 21:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:20:15 --> Controller Class Initialized
INFO - 2017-01-02 21:20:15 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:20:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:20:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:20:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:20:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:20:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:20:15 --> Final output sent to browser
DEBUG - 2017-01-02 21:20:15 --> Total execution time: 0.0265
INFO - 2017-01-02 21:21:53 --> Config Class Initialized
INFO - 2017-01-02 21:21:53 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:21:53 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:21:53 --> Utf8 Class Initialized
INFO - 2017-01-02 21:21:53 --> URI Class Initialized
DEBUG - 2017-01-02 21:21:53 --> No URI present. Default controller set.
INFO - 2017-01-02 21:21:53 --> Router Class Initialized
INFO - 2017-01-02 21:21:53 --> Output Class Initialized
INFO - 2017-01-02 21:21:53 --> Security Class Initialized
DEBUG - 2017-01-02 21:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:21:53 --> Input Class Initialized
INFO - 2017-01-02 21:21:53 --> Language Class Initialized
INFO - 2017-01-02 21:21:53 --> Loader Class Initialized
INFO - 2017-01-02 21:21:54 --> Database Driver Class Initialized
INFO - 2017-01-02 21:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:21:54 --> Controller Class Initialized
INFO - 2017-01-02 21:21:54 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:21:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:21:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:21:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:21:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:21:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:21:54 --> Final output sent to browser
DEBUG - 2017-01-02 21:21:54 --> Total execution time: 0.7730
INFO - 2017-01-02 21:22:01 --> Config Class Initialized
INFO - 2017-01-02 21:22:01 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:22:01 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:22:01 --> Utf8 Class Initialized
INFO - 2017-01-02 21:22:01 --> URI Class Initialized
INFO - 2017-01-02 21:22:01 --> Router Class Initialized
INFO - 2017-01-02 21:22:01 --> Output Class Initialized
INFO - 2017-01-02 21:22:01 --> Security Class Initialized
DEBUG - 2017-01-02 21:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:22:01 --> Input Class Initialized
INFO - 2017-01-02 21:22:01 --> Language Class Initialized
INFO - 2017-01-02 21:22:01 --> Loader Class Initialized
INFO - 2017-01-02 21:22:02 --> Database Driver Class Initialized
INFO - 2017-01-02 21:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:22:02 --> Controller Class Initialized
INFO - 2017-01-02 21:22:02 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:22:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:22:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:22:02 --> Final output sent to browser
DEBUG - 2017-01-02 21:22:02 --> Total execution time: 0.5877
INFO - 2017-01-02 21:22:18 --> Config Class Initialized
INFO - 2017-01-02 21:22:18 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:22:18 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:22:18 --> Utf8 Class Initialized
INFO - 2017-01-02 21:22:18 --> URI Class Initialized
DEBUG - 2017-01-02 21:22:18 --> No URI present. Default controller set.
INFO - 2017-01-02 21:22:18 --> Router Class Initialized
INFO - 2017-01-02 21:22:18 --> Output Class Initialized
INFO - 2017-01-02 21:22:18 --> Security Class Initialized
DEBUG - 2017-01-02 21:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:22:18 --> Input Class Initialized
INFO - 2017-01-02 21:22:18 --> Language Class Initialized
INFO - 2017-01-02 21:22:18 --> Loader Class Initialized
INFO - 2017-01-02 21:22:18 --> Database Driver Class Initialized
INFO - 2017-01-02 21:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:22:18 --> Controller Class Initialized
INFO - 2017-01-02 21:22:18 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:22:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:22:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:22:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:22:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:22:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:22:18 --> Final output sent to browser
DEBUG - 2017-01-02 21:22:18 --> Total execution time: 0.4882
INFO - 2017-01-02 21:22:19 --> Config Class Initialized
INFO - 2017-01-02 21:22:19 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:22:19 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:22:19 --> Utf8 Class Initialized
INFO - 2017-01-02 21:22:19 --> URI Class Initialized
INFO - 2017-01-02 21:22:19 --> Router Class Initialized
INFO - 2017-01-02 21:22:19 --> Output Class Initialized
INFO - 2017-01-02 21:22:19 --> Security Class Initialized
DEBUG - 2017-01-02 21:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:22:19 --> Input Class Initialized
INFO - 2017-01-02 21:22:19 --> Language Class Initialized
INFO - 2017-01-02 21:22:19 --> Loader Class Initialized
INFO - 2017-01-02 21:22:19 --> Database Driver Class Initialized
INFO - 2017-01-02 21:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:22:19 --> Controller Class Initialized
INFO - 2017-01-02 21:22:19 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:22:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:22:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:22:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:22:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:22:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:22:19 --> Final output sent to browser
DEBUG - 2017-01-02 21:22:19 --> Total execution time: 0.0147
INFO - 2017-01-02 21:22:25 --> Config Class Initialized
INFO - 2017-01-02 21:22:25 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:22:25 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:22:25 --> Utf8 Class Initialized
INFO - 2017-01-02 21:22:25 --> URI Class Initialized
DEBUG - 2017-01-02 21:22:25 --> No URI present. Default controller set.
INFO - 2017-01-02 21:22:25 --> Router Class Initialized
INFO - 2017-01-02 21:22:25 --> Output Class Initialized
INFO - 2017-01-02 21:22:25 --> Security Class Initialized
DEBUG - 2017-01-02 21:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:22:25 --> Input Class Initialized
INFO - 2017-01-02 21:22:25 --> Language Class Initialized
INFO - 2017-01-02 21:22:25 --> Loader Class Initialized
INFO - 2017-01-02 21:22:25 --> Database Driver Class Initialized
INFO - 2017-01-02 21:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:22:25 --> Controller Class Initialized
INFO - 2017-01-02 21:22:25 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:22:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:22:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:22:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:22:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:22:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:22:25 --> Final output sent to browser
DEBUG - 2017-01-02 21:22:25 --> Total execution time: 0.2663
INFO - 2017-01-02 21:22:29 --> Config Class Initialized
INFO - 2017-01-02 21:22:29 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:22:29 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:22:29 --> Utf8 Class Initialized
INFO - 2017-01-02 21:22:29 --> URI Class Initialized
INFO - 2017-01-02 21:22:29 --> Router Class Initialized
INFO - 2017-01-02 21:22:29 --> Output Class Initialized
INFO - 2017-01-02 21:22:29 --> Security Class Initialized
DEBUG - 2017-01-02 21:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:22:29 --> Input Class Initialized
INFO - 2017-01-02 21:22:29 --> Language Class Initialized
INFO - 2017-01-02 21:22:29 --> Loader Class Initialized
INFO - 2017-01-02 21:22:29 --> Database Driver Class Initialized
INFO - 2017-01-02 21:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:22:29 --> Controller Class Initialized
INFO - 2017-01-02 21:22:29 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:22:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:22:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:22:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:22:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:22:29 --> Final output sent to browser
DEBUG - 2017-01-02 21:22:29 --> Total execution time: 0.2928
INFO - 2017-01-02 21:22:47 --> Config Class Initialized
INFO - 2017-01-02 21:22:47 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:22:47 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:22:47 --> Utf8 Class Initialized
INFO - 2017-01-02 21:22:47 --> URI Class Initialized
DEBUG - 2017-01-02 21:22:47 --> No URI present. Default controller set.
INFO - 2017-01-02 21:22:47 --> Router Class Initialized
INFO - 2017-01-02 21:22:47 --> Output Class Initialized
INFO - 2017-01-02 21:22:47 --> Security Class Initialized
DEBUG - 2017-01-02 21:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:22:47 --> Input Class Initialized
INFO - 2017-01-02 21:22:47 --> Language Class Initialized
INFO - 2017-01-02 21:22:47 --> Loader Class Initialized
INFO - 2017-01-02 21:22:47 --> Database Driver Class Initialized
INFO - 2017-01-02 21:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:22:47 --> Controller Class Initialized
INFO - 2017-01-02 21:22:47 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:22:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:22:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:22:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:22:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:22:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:22:47 --> Final output sent to browser
DEBUG - 2017-01-02 21:22:47 --> Total execution time: 0.3109
INFO - 2017-01-02 21:22:48 --> Config Class Initialized
INFO - 2017-01-02 21:22:48 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:22:48 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:22:48 --> Utf8 Class Initialized
INFO - 2017-01-02 21:22:48 --> URI Class Initialized
INFO - 2017-01-02 21:22:48 --> Router Class Initialized
INFO - 2017-01-02 21:22:48 --> Output Class Initialized
INFO - 2017-01-02 21:22:48 --> Security Class Initialized
DEBUG - 2017-01-02 21:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:22:48 --> Input Class Initialized
INFO - 2017-01-02 21:22:48 --> Language Class Initialized
INFO - 2017-01-02 21:22:48 --> Loader Class Initialized
INFO - 2017-01-02 21:22:48 --> Database Driver Class Initialized
INFO - 2017-01-02 21:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:22:49 --> Controller Class Initialized
INFO - 2017-01-02 21:22:49 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:22:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:22:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:22:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:22:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:22:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:22:49 --> Final output sent to browser
DEBUG - 2017-01-02 21:22:49 --> Total execution time: 0.6977
INFO - 2017-01-02 21:23:38 --> Config Class Initialized
INFO - 2017-01-02 21:23:38 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:23:38 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:23:38 --> Utf8 Class Initialized
INFO - 2017-01-02 21:23:38 --> URI Class Initialized
DEBUG - 2017-01-02 21:23:38 --> No URI present. Default controller set.
INFO - 2017-01-02 21:23:38 --> Router Class Initialized
INFO - 2017-01-02 21:23:38 --> Output Class Initialized
INFO - 2017-01-02 21:23:38 --> Security Class Initialized
DEBUG - 2017-01-02 21:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:23:38 --> Input Class Initialized
INFO - 2017-01-02 21:23:38 --> Language Class Initialized
INFO - 2017-01-02 21:23:38 --> Loader Class Initialized
INFO - 2017-01-02 21:23:38 --> Database Driver Class Initialized
INFO - 2017-01-02 21:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:23:38 --> Controller Class Initialized
INFO - 2017-01-02 21:23:38 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:23:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:23:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:23:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:23:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:23:38 --> Final output sent to browser
DEBUG - 2017-01-02 21:23:38 --> Total execution time: 0.2145
INFO - 2017-01-02 21:23:39 --> Config Class Initialized
INFO - 2017-01-02 21:23:39 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:23:39 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:23:39 --> Utf8 Class Initialized
INFO - 2017-01-02 21:23:39 --> URI Class Initialized
INFO - 2017-01-02 21:23:39 --> Router Class Initialized
INFO - 2017-01-02 21:23:39 --> Output Class Initialized
INFO - 2017-01-02 21:23:39 --> Security Class Initialized
DEBUG - 2017-01-02 21:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:23:39 --> Input Class Initialized
INFO - 2017-01-02 21:23:39 --> Language Class Initialized
INFO - 2017-01-02 21:23:39 --> Loader Class Initialized
INFO - 2017-01-02 21:23:39 --> Database Driver Class Initialized
INFO - 2017-01-02 21:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:23:39 --> Controller Class Initialized
INFO - 2017-01-02 21:23:39 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:23:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:23:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:23:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:23:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:23:39 --> Final output sent to browser
DEBUG - 2017-01-02 21:23:39 --> Total execution time: 0.2803
INFO - 2017-01-02 21:23:41 --> Config Class Initialized
INFO - 2017-01-02 21:23:41 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:23:41 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:23:41 --> Utf8 Class Initialized
INFO - 2017-01-02 21:23:41 --> URI Class Initialized
DEBUG - 2017-01-02 21:23:41 --> No URI present. Default controller set.
INFO - 2017-01-02 21:23:41 --> Router Class Initialized
INFO - 2017-01-02 21:23:41 --> Output Class Initialized
INFO - 2017-01-02 21:23:41 --> Security Class Initialized
DEBUG - 2017-01-02 21:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:23:41 --> Input Class Initialized
INFO - 2017-01-02 21:23:41 --> Language Class Initialized
INFO - 2017-01-02 21:23:41 --> Loader Class Initialized
INFO - 2017-01-02 21:23:41 --> Database Driver Class Initialized
INFO - 2017-01-02 21:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:23:41 --> Controller Class Initialized
INFO - 2017-01-02 21:23:41 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:23:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:23:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:23:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:23:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:23:41 --> Final output sent to browser
DEBUG - 2017-01-02 21:23:41 --> Total execution time: 0.2683
INFO - 2017-01-02 21:23:42 --> Config Class Initialized
INFO - 2017-01-02 21:23:42 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:23:42 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:23:42 --> Utf8 Class Initialized
INFO - 2017-01-02 21:23:42 --> URI Class Initialized
INFO - 2017-01-02 21:23:42 --> Router Class Initialized
INFO - 2017-01-02 21:23:42 --> Output Class Initialized
INFO - 2017-01-02 21:23:42 --> Security Class Initialized
DEBUG - 2017-01-02 21:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:23:42 --> Input Class Initialized
INFO - 2017-01-02 21:23:42 --> Language Class Initialized
INFO - 2017-01-02 21:23:42 --> Loader Class Initialized
INFO - 2017-01-02 21:23:42 --> Database Driver Class Initialized
INFO - 2017-01-02 21:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:23:42 --> Controller Class Initialized
INFO - 2017-01-02 21:23:42 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:23:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:23:42 --> Config Class Initialized
INFO - 2017-01-02 21:23:42 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:23:42 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:23:42 --> Utf8 Class Initialized
INFO - 2017-01-02 21:23:42 --> URI Class Initialized
DEBUG - 2017-01-02 21:23:42 --> No URI present. Default controller set.
INFO - 2017-01-02 21:23:42 --> Router Class Initialized
INFO - 2017-01-02 21:23:42 --> Output Class Initialized
INFO - 2017-01-02 21:23:42 --> Security Class Initialized
DEBUG - 2017-01-02 21:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:23:42 --> Input Class Initialized
INFO - 2017-01-02 21:23:42 --> Language Class Initialized
INFO - 2017-01-02 21:23:42 --> Loader Class Initialized
INFO - 2017-01-02 21:23:42 --> Database Driver Class Initialized
INFO - 2017-01-02 21:23:42 --> Final output sent to browser
DEBUG - 2017-01-02 21:23:42 --> Total execution time: 0.2977
INFO - 2017-01-02 21:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:23:42 --> Controller Class Initialized
INFO - 2017-01-02 21:23:42 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:23:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:23:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:23:42 --> Final output sent to browser
DEBUG - 2017-01-02 21:23:42 --> Total execution time: 0.3802
INFO - 2017-01-02 21:23:43 --> Config Class Initialized
INFO - 2017-01-02 21:23:43 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:23:43 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:23:43 --> Utf8 Class Initialized
INFO - 2017-01-02 21:23:43 --> URI Class Initialized
INFO - 2017-01-02 21:23:43 --> Router Class Initialized
INFO - 2017-01-02 21:23:43 --> Output Class Initialized
INFO - 2017-01-02 21:23:43 --> Security Class Initialized
DEBUG - 2017-01-02 21:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:23:43 --> Input Class Initialized
INFO - 2017-01-02 21:23:43 --> Language Class Initialized
INFO - 2017-01-02 21:23:43 --> Loader Class Initialized
INFO - 2017-01-02 21:23:43 --> Database Driver Class Initialized
INFO - 2017-01-02 21:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:23:43 --> Controller Class Initialized
INFO - 2017-01-02 21:23:43 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:23:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:23:43 --> Final output sent to browser
DEBUG - 2017-01-02 21:23:43 --> Total execution time: 0.2665
INFO - 2017-01-02 21:26:39 --> Config Class Initialized
INFO - 2017-01-02 21:26:39 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:26:39 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:26:39 --> Utf8 Class Initialized
INFO - 2017-01-02 21:26:39 --> URI Class Initialized
DEBUG - 2017-01-02 21:26:39 --> No URI present. Default controller set.
INFO - 2017-01-02 21:26:39 --> Router Class Initialized
INFO - 2017-01-02 21:26:39 --> Output Class Initialized
INFO - 2017-01-02 21:26:39 --> Security Class Initialized
DEBUG - 2017-01-02 21:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:26:39 --> Input Class Initialized
INFO - 2017-01-02 21:26:39 --> Language Class Initialized
INFO - 2017-01-02 21:26:39 --> Loader Class Initialized
INFO - 2017-01-02 21:26:39 --> Database Driver Class Initialized
INFO - 2017-01-02 21:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:26:39 --> Controller Class Initialized
INFO - 2017-01-02 21:26:39 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:26:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:26:39 --> Final output sent to browser
DEBUG - 2017-01-02 21:26:39 --> Total execution time: 0.5820
INFO - 2017-01-02 21:26:40 --> Config Class Initialized
INFO - 2017-01-02 21:26:40 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:26:40 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:26:40 --> Utf8 Class Initialized
INFO - 2017-01-02 21:26:40 --> URI Class Initialized
INFO - 2017-01-02 21:26:40 --> Router Class Initialized
INFO - 2017-01-02 21:26:40 --> Output Class Initialized
INFO - 2017-01-02 21:26:40 --> Security Class Initialized
DEBUG - 2017-01-02 21:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:26:40 --> Input Class Initialized
INFO - 2017-01-02 21:26:40 --> Language Class Initialized
INFO - 2017-01-02 21:26:40 --> Loader Class Initialized
INFO - 2017-01-02 21:26:40 --> Database Driver Class Initialized
INFO - 2017-01-02 21:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:26:40 --> Controller Class Initialized
INFO - 2017-01-02 21:26:40 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:26:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:26:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:26:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:26:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:26:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:26:40 --> Final output sent to browser
DEBUG - 2017-01-02 21:26:40 --> Total execution time: 0.2584
INFO - 2017-01-02 21:26:43 --> Config Class Initialized
INFO - 2017-01-02 21:26:43 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:26:43 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:26:43 --> Utf8 Class Initialized
INFO - 2017-01-02 21:26:43 --> URI Class Initialized
DEBUG - 2017-01-02 21:26:43 --> No URI present. Default controller set.
INFO - 2017-01-02 21:26:43 --> Router Class Initialized
INFO - 2017-01-02 21:26:43 --> Output Class Initialized
INFO - 2017-01-02 21:26:43 --> Security Class Initialized
DEBUG - 2017-01-02 21:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:26:43 --> Input Class Initialized
INFO - 2017-01-02 21:26:43 --> Language Class Initialized
INFO - 2017-01-02 21:26:43 --> Loader Class Initialized
INFO - 2017-01-02 21:26:43 --> Database Driver Class Initialized
INFO - 2017-01-02 21:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:26:43 --> Controller Class Initialized
INFO - 2017-01-02 21:26:43 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:26:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:26:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:26:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:26:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:26:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:26:43 --> Final output sent to browser
DEBUG - 2017-01-02 21:26:43 --> Total execution time: 0.2582
INFO - 2017-01-02 21:26:44 --> Config Class Initialized
INFO - 2017-01-02 21:26:44 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:26:44 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:26:44 --> Utf8 Class Initialized
INFO - 2017-01-02 21:26:44 --> URI Class Initialized
INFO - 2017-01-02 21:26:44 --> Router Class Initialized
INFO - 2017-01-02 21:26:44 --> Output Class Initialized
INFO - 2017-01-02 21:26:44 --> Security Class Initialized
DEBUG - 2017-01-02 21:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:26:44 --> Input Class Initialized
INFO - 2017-01-02 21:26:44 --> Language Class Initialized
INFO - 2017-01-02 21:26:44 --> Loader Class Initialized
INFO - 2017-01-02 21:26:44 --> Database Driver Class Initialized
INFO - 2017-01-02 21:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:26:44 --> Controller Class Initialized
INFO - 2017-01-02 21:26:44 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:26:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:26:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:26:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:26:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:26:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:26:44 --> Final output sent to browser
DEBUG - 2017-01-02 21:26:44 --> Total execution time: 0.2592
INFO - 2017-01-02 21:27:03 --> Config Class Initialized
INFO - 2017-01-02 21:27:03 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:27:03 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:27:03 --> Utf8 Class Initialized
INFO - 2017-01-02 21:27:03 --> URI Class Initialized
DEBUG - 2017-01-02 21:27:03 --> No URI present. Default controller set.
INFO - 2017-01-02 21:27:03 --> Router Class Initialized
INFO - 2017-01-02 21:27:03 --> Output Class Initialized
INFO - 2017-01-02 21:27:03 --> Security Class Initialized
DEBUG - 2017-01-02 21:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:27:03 --> Input Class Initialized
INFO - 2017-01-02 21:27:03 --> Language Class Initialized
INFO - 2017-01-02 21:27:03 --> Loader Class Initialized
INFO - 2017-01-02 21:27:03 --> Database Driver Class Initialized
INFO - 2017-01-02 21:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:27:03 --> Controller Class Initialized
INFO - 2017-01-02 21:27:03 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:27:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:27:03 --> Final output sent to browser
DEBUG - 2017-01-02 21:27:03 --> Total execution time: 0.3035
INFO - 2017-01-02 21:27:04 --> Config Class Initialized
INFO - 2017-01-02 21:27:04 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:27:04 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:27:04 --> Utf8 Class Initialized
INFO - 2017-01-02 21:27:04 --> URI Class Initialized
INFO - 2017-01-02 21:27:04 --> Router Class Initialized
INFO - 2017-01-02 21:27:04 --> Output Class Initialized
INFO - 2017-01-02 21:27:04 --> Security Class Initialized
DEBUG - 2017-01-02 21:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:27:04 --> Input Class Initialized
INFO - 2017-01-02 21:27:04 --> Language Class Initialized
INFO - 2017-01-02 21:27:04 --> Loader Class Initialized
INFO - 2017-01-02 21:27:04 --> Database Driver Class Initialized
INFO - 2017-01-02 21:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:27:04 --> Controller Class Initialized
INFO - 2017-01-02 21:27:04 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:27:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:27:05 --> Final output sent to browser
DEBUG - 2017-01-02 21:27:05 --> Total execution time: 0.2779
INFO - 2017-01-02 21:27:17 --> Config Class Initialized
INFO - 2017-01-02 21:27:17 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:27:17 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:27:17 --> Utf8 Class Initialized
INFO - 2017-01-02 21:27:17 --> URI Class Initialized
DEBUG - 2017-01-02 21:27:17 --> No URI present. Default controller set.
INFO - 2017-01-02 21:27:17 --> Router Class Initialized
INFO - 2017-01-02 21:27:17 --> Output Class Initialized
INFO - 2017-01-02 21:27:17 --> Security Class Initialized
DEBUG - 2017-01-02 21:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:27:17 --> Input Class Initialized
INFO - 2017-01-02 21:27:17 --> Language Class Initialized
INFO - 2017-01-02 21:27:17 --> Loader Class Initialized
INFO - 2017-01-02 21:27:17 --> Database Driver Class Initialized
INFO - 2017-01-02 21:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:27:17 --> Controller Class Initialized
INFO - 2017-01-02 21:27:17 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:27:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:27:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:27:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:27:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:27:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:27:17 --> Final output sent to browser
DEBUG - 2017-01-02 21:27:17 --> Total execution time: 0.2721
INFO - 2017-01-02 21:27:25 --> Config Class Initialized
INFO - 2017-01-02 21:27:25 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:27:26 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:27:26 --> Utf8 Class Initialized
INFO - 2017-01-02 21:27:26 --> URI Class Initialized
INFO - 2017-01-02 21:27:26 --> Router Class Initialized
INFO - 2017-01-02 21:27:26 --> Output Class Initialized
INFO - 2017-01-02 21:27:26 --> Security Class Initialized
DEBUG - 2017-01-02 21:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:27:26 --> Input Class Initialized
INFO - 2017-01-02 21:27:26 --> Language Class Initialized
INFO - 2017-01-02 21:27:26 --> Loader Class Initialized
INFO - 2017-01-02 21:27:26 --> Database Driver Class Initialized
INFO - 2017-01-02 21:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:27:26 --> Controller Class Initialized
INFO - 2017-01-02 21:27:26 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:27:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:27:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:27:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:27:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:27:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:27:26 --> Final output sent to browser
DEBUG - 2017-01-02 21:27:26 --> Total execution time: 0.5701
INFO - 2017-01-02 21:29:44 --> Config Class Initialized
INFO - 2017-01-02 21:29:44 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:29:44 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:29:44 --> Utf8 Class Initialized
INFO - 2017-01-02 21:29:44 --> URI Class Initialized
DEBUG - 2017-01-02 21:29:44 --> No URI present. Default controller set.
INFO - 2017-01-02 21:29:44 --> Router Class Initialized
INFO - 2017-01-02 21:29:44 --> Output Class Initialized
INFO - 2017-01-02 21:29:44 --> Security Class Initialized
DEBUG - 2017-01-02 21:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:29:44 --> Input Class Initialized
INFO - 2017-01-02 21:29:44 --> Language Class Initialized
INFO - 2017-01-02 21:29:44 --> Loader Class Initialized
INFO - 2017-01-02 21:29:44 --> Database Driver Class Initialized
INFO - 2017-01-02 21:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:29:44 --> Controller Class Initialized
INFO - 2017-01-02 21:29:44 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:29:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:29:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:29:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:29:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:29:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:29:44 --> Final output sent to browser
DEBUG - 2017-01-02 21:29:44 --> Total execution time: 0.5026
INFO - 2017-01-02 21:29:45 --> Config Class Initialized
INFO - 2017-01-02 21:29:45 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:29:45 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:29:45 --> Utf8 Class Initialized
INFO - 2017-01-02 21:29:45 --> URI Class Initialized
INFO - 2017-01-02 21:29:45 --> Router Class Initialized
INFO - 2017-01-02 21:29:45 --> Output Class Initialized
INFO - 2017-01-02 21:29:45 --> Security Class Initialized
DEBUG - 2017-01-02 21:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:29:45 --> Input Class Initialized
INFO - 2017-01-02 21:29:45 --> Language Class Initialized
INFO - 2017-01-02 21:29:45 --> Loader Class Initialized
INFO - 2017-01-02 21:29:45 --> Database Driver Class Initialized
INFO - 2017-01-02 21:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:29:45 --> Controller Class Initialized
INFO - 2017-01-02 21:29:45 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:29:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:29:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:29:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:29:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:29:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:29:46 --> Final output sent to browser
DEBUG - 2017-01-02 21:29:46 --> Total execution time: 0.2448
INFO - 2017-01-02 21:30:09 --> Config Class Initialized
INFO - 2017-01-02 21:30:09 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:30:09 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:30:09 --> Utf8 Class Initialized
INFO - 2017-01-02 21:30:09 --> URI Class Initialized
DEBUG - 2017-01-02 21:30:09 --> No URI present. Default controller set.
INFO - 2017-01-02 21:30:09 --> Router Class Initialized
INFO - 2017-01-02 21:30:09 --> Output Class Initialized
INFO - 2017-01-02 21:30:09 --> Security Class Initialized
DEBUG - 2017-01-02 21:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:30:09 --> Input Class Initialized
INFO - 2017-01-02 21:30:09 --> Language Class Initialized
INFO - 2017-01-02 21:30:09 --> Loader Class Initialized
INFO - 2017-01-02 21:30:09 --> Database Driver Class Initialized
INFO - 2017-01-02 21:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:30:09 --> Controller Class Initialized
INFO - 2017-01-02 21:30:09 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:30:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:30:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:30:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:30:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:30:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:30:10 --> Final output sent to browser
DEBUG - 2017-01-02 21:30:10 --> Total execution time: 0.2578
INFO - 2017-01-02 21:30:10 --> Config Class Initialized
INFO - 2017-01-02 21:30:10 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:30:10 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:30:10 --> Utf8 Class Initialized
INFO - 2017-01-02 21:30:10 --> URI Class Initialized
INFO - 2017-01-02 21:30:10 --> Router Class Initialized
INFO - 2017-01-02 21:30:10 --> Output Class Initialized
INFO - 2017-01-02 21:30:10 --> Security Class Initialized
DEBUG - 2017-01-02 21:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:30:10 --> Input Class Initialized
INFO - 2017-01-02 21:30:10 --> Language Class Initialized
INFO - 2017-01-02 21:30:10 --> Loader Class Initialized
INFO - 2017-01-02 21:30:10 --> Database Driver Class Initialized
INFO - 2017-01-02 21:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:30:10 --> Controller Class Initialized
INFO - 2017-01-02 21:30:10 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:30:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:30:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:30:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:30:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:30:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:30:11 --> Final output sent to browser
DEBUG - 2017-01-02 21:30:11 --> Total execution time: 0.2457
INFO - 2017-01-02 21:30:16 --> Config Class Initialized
INFO - 2017-01-02 21:30:16 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:30:16 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:30:16 --> Utf8 Class Initialized
INFO - 2017-01-02 21:30:16 --> URI Class Initialized
DEBUG - 2017-01-02 21:30:16 --> No URI present. Default controller set.
INFO - 2017-01-02 21:30:16 --> Router Class Initialized
INFO - 2017-01-02 21:30:16 --> Output Class Initialized
INFO - 2017-01-02 21:30:16 --> Security Class Initialized
DEBUG - 2017-01-02 21:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:30:16 --> Input Class Initialized
INFO - 2017-01-02 21:30:16 --> Language Class Initialized
INFO - 2017-01-02 21:30:16 --> Loader Class Initialized
INFO - 2017-01-02 21:30:17 --> Database Driver Class Initialized
INFO - 2017-01-02 21:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:30:17 --> Controller Class Initialized
INFO - 2017-01-02 21:30:17 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:30:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:30:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:30:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:30:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:30:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:30:17 --> Final output sent to browser
DEBUG - 2017-01-02 21:30:17 --> Total execution time: 0.2399
INFO - 2017-01-02 21:30:18 --> Config Class Initialized
INFO - 2017-01-02 21:30:18 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:30:18 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:30:18 --> Utf8 Class Initialized
INFO - 2017-01-02 21:30:18 --> URI Class Initialized
INFO - 2017-01-02 21:30:18 --> Router Class Initialized
INFO - 2017-01-02 21:30:18 --> Output Class Initialized
INFO - 2017-01-02 21:30:18 --> Security Class Initialized
DEBUG - 2017-01-02 21:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:30:18 --> Input Class Initialized
INFO - 2017-01-02 21:30:18 --> Language Class Initialized
INFO - 2017-01-02 21:30:18 --> Loader Class Initialized
INFO - 2017-01-02 21:30:18 --> Database Driver Class Initialized
INFO - 2017-01-02 21:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:30:18 --> Controller Class Initialized
INFO - 2017-01-02 21:30:18 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:30:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:30:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:30:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:30:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:30:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:30:18 --> Final output sent to browser
DEBUG - 2017-01-02 21:30:18 --> Total execution time: 0.2841
INFO - 2017-01-02 21:33:18 --> Config Class Initialized
INFO - 2017-01-02 21:33:18 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:33:18 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:33:18 --> Utf8 Class Initialized
INFO - 2017-01-02 21:33:18 --> URI Class Initialized
DEBUG - 2017-01-02 21:33:18 --> No URI present. Default controller set.
INFO - 2017-01-02 21:33:18 --> Router Class Initialized
INFO - 2017-01-02 21:33:18 --> Output Class Initialized
INFO - 2017-01-02 21:33:18 --> Security Class Initialized
DEBUG - 2017-01-02 21:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:33:18 --> Input Class Initialized
INFO - 2017-01-02 21:33:18 --> Language Class Initialized
INFO - 2017-01-02 21:33:18 --> Loader Class Initialized
INFO - 2017-01-02 21:33:18 --> Database Driver Class Initialized
INFO - 2017-01-02 21:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:33:18 --> Controller Class Initialized
INFO - 2017-01-02 21:33:18 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:33:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:33:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:33:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:33:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:33:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:33:19 --> Final output sent to browser
DEBUG - 2017-01-02 21:33:19 --> Total execution time: 0.2596
INFO - 2017-01-02 21:33:30 --> Config Class Initialized
INFO - 2017-01-02 21:33:30 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:33:30 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:33:30 --> Utf8 Class Initialized
INFO - 2017-01-02 21:33:30 --> URI Class Initialized
INFO - 2017-01-02 21:33:30 --> Router Class Initialized
INFO - 2017-01-02 21:33:30 --> Output Class Initialized
INFO - 2017-01-02 21:33:30 --> Security Class Initialized
DEBUG - 2017-01-02 21:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:33:30 --> Input Class Initialized
INFO - 2017-01-02 21:33:30 --> Language Class Initialized
INFO - 2017-01-02 21:33:30 --> Loader Class Initialized
INFO - 2017-01-02 21:33:30 --> Database Driver Class Initialized
INFO - 2017-01-02 21:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:33:30 --> Controller Class Initialized
INFO - 2017-01-02 21:33:30 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:33:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:33:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:33:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:33:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:33:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:33:30 --> Final output sent to browser
DEBUG - 2017-01-02 21:33:30 --> Total execution time: 0.2322
INFO - 2017-01-02 21:33:44 --> Config Class Initialized
INFO - 2017-01-02 21:33:44 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:33:44 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:33:44 --> Utf8 Class Initialized
INFO - 2017-01-02 21:33:44 --> URI Class Initialized
DEBUG - 2017-01-02 21:33:44 --> No URI present. Default controller set.
INFO - 2017-01-02 21:33:44 --> Router Class Initialized
INFO - 2017-01-02 21:33:44 --> Output Class Initialized
INFO - 2017-01-02 21:33:44 --> Security Class Initialized
DEBUG - 2017-01-02 21:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:33:44 --> Input Class Initialized
INFO - 2017-01-02 21:33:44 --> Language Class Initialized
INFO - 2017-01-02 21:33:44 --> Loader Class Initialized
INFO - 2017-01-02 21:33:44 --> Database Driver Class Initialized
INFO - 2017-01-02 21:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:33:44 --> Controller Class Initialized
INFO - 2017-01-02 21:33:44 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:33:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:33:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:33:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:33:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:33:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:33:44 --> Final output sent to browser
DEBUG - 2017-01-02 21:33:44 --> Total execution time: 0.2369
INFO - 2017-01-02 21:33:45 --> Config Class Initialized
INFO - 2017-01-02 21:33:45 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:33:45 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:33:45 --> Utf8 Class Initialized
INFO - 2017-01-02 21:33:45 --> URI Class Initialized
INFO - 2017-01-02 21:33:45 --> Router Class Initialized
INFO - 2017-01-02 21:33:45 --> Output Class Initialized
INFO - 2017-01-02 21:33:45 --> Security Class Initialized
DEBUG - 2017-01-02 21:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:33:45 --> Input Class Initialized
INFO - 2017-01-02 21:33:45 --> Language Class Initialized
INFO - 2017-01-02 21:33:45 --> Loader Class Initialized
INFO - 2017-01-02 21:33:45 --> Database Driver Class Initialized
INFO - 2017-01-02 21:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:33:45 --> Controller Class Initialized
INFO - 2017-01-02 21:33:45 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:33:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:33:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:33:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:33:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:33:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:33:45 --> Final output sent to browser
DEBUG - 2017-01-02 21:33:45 --> Total execution time: 0.0137
INFO - 2017-01-02 21:36:23 --> Config Class Initialized
INFO - 2017-01-02 21:36:23 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:36:23 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:36:23 --> Utf8 Class Initialized
INFO - 2017-01-02 21:36:23 --> URI Class Initialized
DEBUG - 2017-01-02 21:36:23 --> No URI present. Default controller set.
INFO - 2017-01-02 21:36:23 --> Router Class Initialized
INFO - 2017-01-02 21:36:23 --> Output Class Initialized
INFO - 2017-01-02 21:36:23 --> Security Class Initialized
DEBUG - 2017-01-02 21:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:36:23 --> Input Class Initialized
INFO - 2017-01-02 21:36:23 --> Language Class Initialized
INFO - 2017-01-02 21:36:23 --> Loader Class Initialized
INFO - 2017-01-02 21:36:24 --> Database Driver Class Initialized
INFO - 2017-01-02 21:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:36:24 --> Controller Class Initialized
INFO - 2017-01-02 21:36:24 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:36:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:36:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:36:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:36:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:36:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:36:24 --> Final output sent to browser
DEBUG - 2017-01-02 21:36:24 --> Total execution time: 0.2375
INFO - 2017-01-02 21:36:24 --> Config Class Initialized
INFO - 2017-01-02 21:36:24 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:36:24 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:36:24 --> Utf8 Class Initialized
INFO - 2017-01-02 21:36:24 --> URI Class Initialized
INFO - 2017-01-02 21:36:24 --> Router Class Initialized
INFO - 2017-01-02 21:36:24 --> Output Class Initialized
INFO - 2017-01-02 21:36:24 --> Security Class Initialized
DEBUG - 2017-01-02 21:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:36:24 --> Input Class Initialized
INFO - 2017-01-02 21:36:24 --> Language Class Initialized
INFO - 2017-01-02 21:36:24 --> Loader Class Initialized
INFO - 2017-01-02 21:36:24 --> Database Driver Class Initialized
INFO - 2017-01-02 21:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:36:24 --> Controller Class Initialized
INFO - 2017-01-02 21:36:24 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:36:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:36:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:36:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:36:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:36:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:36:25 --> Final output sent to browser
DEBUG - 2017-01-02 21:36:25 --> Total execution time: 0.2188
INFO - 2017-01-02 21:36:40 --> Config Class Initialized
INFO - 2017-01-02 21:36:40 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:36:40 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:36:40 --> Utf8 Class Initialized
INFO - 2017-01-02 21:36:40 --> URI Class Initialized
DEBUG - 2017-01-02 21:36:40 --> No URI present. Default controller set.
INFO - 2017-01-02 21:36:40 --> Router Class Initialized
INFO - 2017-01-02 21:36:40 --> Output Class Initialized
INFO - 2017-01-02 21:36:40 --> Security Class Initialized
DEBUG - 2017-01-02 21:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:36:40 --> Input Class Initialized
INFO - 2017-01-02 21:36:40 --> Language Class Initialized
INFO - 2017-01-02 21:36:40 --> Loader Class Initialized
INFO - 2017-01-02 21:36:40 --> Database Driver Class Initialized
INFO - 2017-01-02 21:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:36:40 --> Controller Class Initialized
INFO - 2017-01-02 21:36:40 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:36:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:36:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:36:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:36:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:36:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:36:40 --> Final output sent to browser
DEBUG - 2017-01-02 21:36:40 --> Total execution time: 0.2392
INFO - 2017-01-02 21:36:48 --> Config Class Initialized
INFO - 2017-01-02 21:36:48 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:36:48 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:36:48 --> Utf8 Class Initialized
INFO - 2017-01-02 21:36:48 --> URI Class Initialized
INFO - 2017-01-02 21:36:48 --> Router Class Initialized
INFO - 2017-01-02 21:36:48 --> Output Class Initialized
INFO - 2017-01-02 21:36:48 --> Security Class Initialized
DEBUG - 2017-01-02 21:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:36:48 --> Input Class Initialized
INFO - 2017-01-02 21:36:48 --> Language Class Initialized
INFO - 2017-01-02 21:36:48 --> Loader Class Initialized
INFO - 2017-01-02 21:36:48 --> Database Driver Class Initialized
INFO - 2017-01-02 21:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:36:48 --> Controller Class Initialized
INFO - 2017-01-02 21:36:48 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:36:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:36:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:36:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:36:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:36:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:36:48 --> Final output sent to browser
DEBUG - 2017-01-02 21:36:48 --> Total execution time: 0.2264
INFO - 2017-01-02 21:36:50 --> Config Class Initialized
INFO - 2017-01-02 21:36:50 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:36:50 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:36:50 --> Utf8 Class Initialized
INFO - 2017-01-02 21:36:50 --> URI Class Initialized
INFO - 2017-01-02 21:36:50 --> Router Class Initialized
INFO - 2017-01-02 21:36:50 --> Output Class Initialized
INFO - 2017-01-02 21:36:50 --> Security Class Initialized
DEBUG - 2017-01-02 21:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:36:50 --> Input Class Initialized
INFO - 2017-01-02 21:36:50 --> Language Class Initialized
ERROR - 2017-01-02 21:36:51 --> 404 Page Not Found: Templates/usuario
INFO - 2017-01-02 21:51:29 --> Config Class Initialized
INFO - 2017-01-02 21:51:29 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:51:29 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:51:29 --> Utf8 Class Initialized
INFO - 2017-01-02 21:51:29 --> URI Class Initialized
DEBUG - 2017-01-02 21:51:29 --> No URI present. Default controller set.
INFO - 2017-01-02 21:51:29 --> Router Class Initialized
INFO - 2017-01-02 21:51:29 --> Output Class Initialized
INFO - 2017-01-02 21:51:29 --> Security Class Initialized
DEBUG - 2017-01-02 21:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:51:29 --> Input Class Initialized
INFO - 2017-01-02 21:51:29 --> Language Class Initialized
INFO - 2017-01-02 21:51:29 --> Loader Class Initialized
INFO - 2017-01-02 21:51:29 --> Database Driver Class Initialized
INFO - 2017-01-02 21:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:51:29 --> Controller Class Initialized
INFO - 2017-01-02 21:51:29 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:51:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:51:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:51:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:51:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:51:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:51:29 --> Final output sent to browser
DEBUG - 2017-01-02 21:51:29 --> Total execution time: 0.0465
INFO - 2017-01-02 21:51:29 --> Config Class Initialized
INFO - 2017-01-02 21:51:29 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:51:29 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:51:29 --> Utf8 Class Initialized
INFO - 2017-01-02 21:51:29 --> URI Class Initialized
INFO - 2017-01-02 21:51:29 --> Router Class Initialized
INFO - 2017-01-02 21:51:29 --> Output Class Initialized
INFO - 2017-01-02 21:51:29 --> Security Class Initialized
DEBUG - 2017-01-02 21:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:51:29 --> Input Class Initialized
INFO - 2017-01-02 21:51:29 --> Language Class Initialized
INFO - 2017-01-02 21:51:29 --> Loader Class Initialized
INFO - 2017-01-02 21:51:29 --> Database Driver Class Initialized
INFO - 2017-01-02 21:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:51:29 --> Controller Class Initialized
INFO - 2017-01-02 21:51:29 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:51:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:51:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:51:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:51:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:51:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:51:29 --> Final output sent to browser
DEBUG - 2017-01-02 21:51:29 --> Total execution time: 0.0319
INFO - 2017-01-02 21:51:40 --> Config Class Initialized
INFO - 2017-01-02 21:51:40 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:51:40 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:51:40 --> Utf8 Class Initialized
INFO - 2017-01-02 21:51:40 --> URI Class Initialized
DEBUG - 2017-01-02 21:51:40 --> No URI present. Default controller set.
INFO - 2017-01-02 21:51:40 --> Router Class Initialized
INFO - 2017-01-02 21:51:40 --> Output Class Initialized
INFO - 2017-01-02 21:51:40 --> Security Class Initialized
DEBUG - 2017-01-02 21:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:51:40 --> Input Class Initialized
INFO - 2017-01-02 21:51:40 --> Language Class Initialized
INFO - 2017-01-02 21:51:40 --> Loader Class Initialized
INFO - 2017-01-02 21:51:40 --> Database Driver Class Initialized
INFO - 2017-01-02 21:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:51:40 --> Controller Class Initialized
INFO - 2017-01-02 21:51:40 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:51:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:51:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:51:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:51:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:51:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:51:40 --> Final output sent to browser
DEBUG - 2017-01-02 21:51:40 --> Total execution time: 0.0316
INFO - 2017-01-02 21:51:47 --> Config Class Initialized
INFO - 2017-01-02 21:51:47 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:51:47 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:51:47 --> Utf8 Class Initialized
INFO - 2017-01-02 21:51:47 --> URI Class Initialized
INFO - 2017-01-02 21:51:47 --> Router Class Initialized
INFO - 2017-01-02 21:51:47 --> Output Class Initialized
INFO - 2017-01-02 21:51:47 --> Security Class Initialized
DEBUG - 2017-01-02 21:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:51:47 --> Input Class Initialized
INFO - 2017-01-02 21:51:47 --> Language Class Initialized
INFO - 2017-01-02 21:51:47 --> Loader Class Initialized
INFO - 2017-01-02 21:51:47 --> Database Driver Class Initialized
INFO - 2017-01-02 21:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:51:47 --> Controller Class Initialized
INFO - 2017-01-02 21:51:47 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:51:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:51:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:51:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:51:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:51:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:51:47 --> Final output sent to browser
DEBUG - 2017-01-02 21:51:47 --> Total execution time: 0.0146
INFO - 2017-01-02 21:51:52 --> Config Class Initialized
INFO - 2017-01-02 21:51:52 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:51:52 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:51:52 --> Utf8 Class Initialized
INFO - 2017-01-02 21:51:52 --> URI Class Initialized
DEBUG - 2017-01-02 21:51:52 --> No URI present. Default controller set.
INFO - 2017-01-02 21:51:52 --> Router Class Initialized
INFO - 2017-01-02 21:51:52 --> Output Class Initialized
INFO - 2017-01-02 21:51:52 --> Security Class Initialized
DEBUG - 2017-01-02 21:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:51:52 --> Input Class Initialized
INFO - 2017-01-02 21:51:52 --> Language Class Initialized
INFO - 2017-01-02 21:51:52 --> Loader Class Initialized
INFO - 2017-01-02 21:51:52 --> Database Driver Class Initialized
INFO - 2017-01-02 21:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:51:52 --> Controller Class Initialized
INFO - 2017-01-02 21:51:52 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:51:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:51:52 --> Final output sent to browser
DEBUG - 2017-01-02 21:51:52 --> Total execution time: 0.0137
INFO - 2017-01-02 21:51:52 --> Config Class Initialized
INFO - 2017-01-02 21:51:52 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:51:52 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:51:52 --> Utf8 Class Initialized
INFO - 2017-01-02 21:51:52 --> URI Class Initialized
INFO - 2017-01-02 21:51:52 --> Router Class Initialized
INFO - 2017-01-02 21:51:52 --> Output Class Initialized
INFO - 2017-01-02 21:51:52 --> Security Class Initialized
DEBUG - 2017-01-02 21:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:51:52 --> Input Class Initialized
INFO - 2017-01-02 21:51:52 --> Language Class Initialized
INFO - 2017-01-02 21:51:52 --> Loader Class Initialized
INFO - 2017-01-02 21:51:52 --> Database Driver Class Initialized
INFO - 2017-01-02 21:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:51:52 --> Controller Class Initialized
INFO - 2017-01-02 21:51:52 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:51:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:51:52 --> Final output sent to browser
DEBUG - 2017-01-02 21:51:52 --> Total execution time: 0.0143
INFO - 2017-01-02 21:52:38 --> Config Class Initialized
INFO - 2017-01-02 21:52:38 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:52:38 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:52:38 --> Utf8 Class Initialized
INFO - 2017-01-02 21:52:38 --> URI Class Initialized
DEBUG - 2017-01-02 21:52:38 --> No URI present. Default controller set.
INFO - 2017-01-02 21:52:38 --> Router Class Initialized
INFO - 2017-01-02 21:52:38 --> Output Class Initialized
INFO - 2017-01-02 21:52:38 --> Security Class Initialized
DEBUG - 2017-01-02 21:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:52:38 --> Input Class Initialized
INFO - 2017-01-02 21:52:38 --> Language Class Initialized
INFO - 2017-01-02 21:52:38 --> Loader Class Initialized
INFO - 2017-01-02 21:52:38 --> Database Driver Class Initialized
INFO - 2017-01-02 21:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:52:38 --> Controller Class Initialized
INFO - 2017-01-02 21:52:38 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:52:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:52:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:52:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:52:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:52:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:52:38 --> Final output sent to browser
DEBUG - 2017-01-02 21:52:38 --> Total execution time: 0.0135
INFO - 2017-01-02 21:52:39 --> Config Class Initialized
INFO - 2017-01-02 21:52:39 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:52:39 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:52:39 --> Utf8 Class Initialized
INFO - 2017-01-02 21:52:39 --> URI Class Initialized
INFO - 2017-01-02 21:52:39 --> Router Class Initialized
INFO - 2017-01-02 21:52:39 --> Output Class Initialized
INFO - 2017-01-02 21:52:39 --> Security Class Initialized
DEBUG - 2017-01-02 21:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:52:39 --> Input Class Initialized
INFO - 2017-01-02 21:52:39 --> Language Class Initialized
INFO - 2017-01-02 21:52:39 --> Loader Class Initialized
INFO - 2017-01-02 21:52:39 --> Database Driver Class Initialized
INFO - 2017-01-02 21:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:52:39 --> Controller Class Initialized
INFO - 2017-01-02 21:52:39 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:52:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:52:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:52:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:52:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:52:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:52:39 --> Final output sent to browser
DEBUG - 2017-01-02 21:52:39 --> Total execution time: 0.0139
INFO - 2017-01-02 21:52:54 --> Config Class Initialized
INFO - 2017-01-02 21:52:54 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:52:54 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:52:54 --> Utf8 Class Initialized
INFO - 2017-01-02 21:52:54 --> URI Class Initialized
INFO - 2017-01-02 21:52:54 --> Router Class Initialized
INFO - 2017-01-02 21:52:54 --> Output Class Initialized
INFO - 2017-01-02 21:52:54 --> Security Class Initialized
DEBUG - 2017-01-02 21:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:52:54 --> Input Class Initialized
INFO - 2017-01-02 21:52:54 --> Language Class Initialized
INFO - 2017-01-02 21:52:54 --> Loader Class Initialized
INFO - 2017-01-02 21:52:54 --> Database Driver Class Initialized
INFO - 2017-01-02 21:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:52:54 --> Controller Class Initialized
INFO - 2017-01-02 21:52:54 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:52:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:52:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:52:54 --> Final output sent to browser
DEBUG - 2017-01-02 21:52:54 --> Total execution time: 0.0141
INFO - 2017-01-02 21:53:04 --> Config Class Initialized
INFO - 2017-01-02 21:53:04 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:53:04 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:53:04 --> Utf8 Class Initialized
INFO - 2017-01-02 21:53:04 --> URI Class Initialized
INFO - 2017-01-02 21:53:04 --> Router Class Initialized
INFO - 2017-01-02 21:53:04 --> Output Class Initialized
INFO - 2017-01-02 21:53:04 --> Security Class Initialized
DEBUG - 2017-01-02 21:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:53:04 --> Input Class Initialized
INFO - 2017-01-02 21:53:04 --> Language Class Initialized
INFO - 2017-01-02 21:53:04 --> Loader Class Initialized
INFO - 2017-01-02 21:53:04 --> Database Driver Class Initialized
INFO - 2017-01-02 21:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:53:04 --> Controller Class Initialized
INFO - 2017-01-02 21:53:04 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:53:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:53:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:53:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:53:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:53:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:53:04 --> Final output sent to browser
DEBUG - 2017-01-02 21:53:04 --> Total execution time: 0.0134
INFO - 2017-01-02 21:53:11 --> Config Class Initialized
INFO - 2017-01-02 21:53:11 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:53:11 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:53:11 --> Utf8 Class Initialized
INFO - 2017-01-02 21:53:11 --> URI Class Initialized
INFO - 2017-01-02 21:53:11 --> Router Class Initialized
INFO - 2017-01-02 21:53:11 --> Output Class Initialized
INFO - 2017-01-02 21:53:11 --> Security Class Initialized
DEBUG - 2017-01-02 21:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:53:11 --> Input Class Initialized
INFO - 2017-01-02 21:53:11 --> Language Class Initialized
INFO - 2017-01-02 21:53:11 --> Loader Class Initialized
INFO - 2017-01-02 21:53:11 --> Database Driver Class Initialized
INFO - 2017-01-02 21:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:53:11 --> Controller Class Initialized
INFO - 2017-01-02 21:53:11 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:53:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:53:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:53:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:53:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:53:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:53:11 --> Final output sent to browser
DEBUG - 2017-01-02 21:53:11 --> Total execution time: 0.0136
INFO - 2017-01-02 21:57:20 --> Config Class Initialized
INFO - 2017-01-02 21:57:20 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:57:20 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:57:20 --> Utf8 Class Initialized
INFO - 2017-01-02 21:57:20 --> URI Class Initialized
DEBUG - 2017-01-02 21:57:20 --> No URI present. Default controller set.
INFO - 2017-01-02 21:57:20 --> Router Class Initialized
INFO - 2017-01-02 21:57:20 --> Output Class Initialized
INFO - 2017-01-02 21:57:20 --> Security Class Initialized
DEBUG - 2017-01-02 21:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:57:20 --> Input Class Initialized
INFO - 2017-01-02 21:57:20 --> Language Class Initialized
INFO - 2017-01-02 21:57:20 --> Loader Class Initialized
INFO - 2017-01-02 21:57:20 --> Database Driver Class Initialized
INFO - 2017-01-02 21:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:57:20 --> Controller Class Initialized
INFO - 2017-01-02 21:57:20 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:57:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:57:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:57:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:57:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:57:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:57:20 --> Final output sent to browser
DEBUG - 2017-01-02 21:57:20 --> Total execution time: 0.0139
INFO - 2017-01-02 21:57:21 --> Config Class Initialized
INFO - 2017-01-02 21:57:21 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:57:21 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:57:21 --> Utf8 Class Initialized
INFO - 2017-01-02 21:57:21 --> URI Class Initialized
INFO - 2017-01-02 21:57:21 --> Router Class Initialized
INFO - 2017-01-02 21:57:21 --> Output Class Initialized
INFO - 2017-01-02 21:57:21 --> Security Class Initialized
DEBUG - 2017-01-02 21:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:57:21 --> Input Class Initialized
INFO - 2017-01-02 21:57:21 --> Language Class Initialized
INFO - 2017-01-02 21:57:21 --> Loader Class Initialized
INFO - 2017-01-02 21:57:21 --> Database Driver Class Initialized
INFO - 2017-01-02 21:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:57:21 --> Controller Class Initialized
INFO - 2017-01-02 21:57:21 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:57:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:57:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:57:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:57:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:57:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:57:21 --> Final output sent to browser
DEBUG - 2017-01-02 21:57:21 --> Total execution time: 0.0135
INFO - 2017-01-02 21:57:37 --> Config Class Initialized
INFO - 2017-01-02 21:57:37 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:57:37 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:57:37 --> Utf8 Class Initialized
INFO - 2017-01-02 21:57:37 --> URI Class Initialized
DEBUG - 2017-01-02 21:57:37 --> No URI present. Default controller set.
INFO - 2017-01-02 21:57:37 --> Router Class Initialized
INFO - 2017-01-02 21:57:37 --> Output Class Initialized
INFO - 2017-01-02 21:57:37 --> Security Class Initialized
DEBUG - 2017-01-02 21:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:57:37 --> Input Class Initialized
INFO - 2017-01-02 21:57:37 --> Language Class Initialized
INFO - 2017-01-02 21:57:37 --> Loader Class Initialized
INFO - 2017-01-02 21:57:37 --> Database Driver Class Initialized
INFO - 2017-01-02 21:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:57:38 --> Controller Class Initialized
INFO - 2017-01-02 21:57:38 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:57:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:57:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:57:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:57:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:57:38 --> Final output sent to browser
DEBUG - 2017-01-02 21:57:38 --> Total execution time: 0.5889
INFO - 2017-01-02 21:57:38 --> Config Class Initialized
INFO - 2017-01-02 21:57:38 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:57:38 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:57:38 --> Utf8 Class Initialized
INFO - 2017-01-02 21:57:38 --> URI Class Initialized
INFO - 2017-01-02 21:57:38 --> Router Class Initialized
INFO - 2017-01-02 21:57:38 --> Output Class Initialized
INFO - 2017-01-02 21:57:38 --> Security Class Initialized
DEBUG - 2017-01-02 21:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:57:38 --> Input Class Initialized
INFO - 2017-01-02 21:57:38 --> Language Class Initialized
INFO - 2017-01-02 21:57:38 --> Loader Class Initialized
INFO - 2017-01-02 21:57:38 --> Database Driver Class Initialized
INFO - 2017-01-02 21:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:57:38 --> Controller Class Initialized
INFO - 2017-01-02 21:57:38 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:57:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:57:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:57:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:57:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:57:38 --> Final output sent to browser
DEBUG - 2017-01-02 21:57:38 --> Total execution time: 0.0138
INFO - 2017-01-02 21:57:54 --> Config Class Initialized
INFO - 2017-01-02 21:57:54 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:57:54 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:57:54 --> Utf8 Class Initialized
INFO - 2017-01-02 21:57:54 --> URI Class Initialized
DEBUG - 2017-01-02 21:57:54 --> No URI present. Default controller set.
INFO - 2017-01-02 21:57:54 --> Router Class Initialized
INFO - 2017-01-02 21:57:54 --> Output Class Initialized
INFO - 2017-01-02 21:57:54 --> Security Class Initialized
DEBUG - 2017-01-02 21:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:57:54 --> Input Class Initialized
INFO - 2017-01-02 21:57:54 --> Language Class Initialized
INFO - 2017-01-02 21:57:54 --> Loader Class Initialized
INFO - 2017-01-02 21:57:54 --> Database Driver Class Initialized
INFO - 2017-01-02 21:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:57:54 --> Controller Class Initialized
INFO - 2017-01-02 21:57:54 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:57:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:57:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:57:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:57:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:57:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:57:54 --> Final output sent to browser
DEBUG - 2017-01-02 21:57:54 --> Total execution time: 0.0131
INFO - 2017-01-02 21:58:02 --> Config Class Initialized
INFO - 2017-01-02 21:58:02 --> Hooks Class Initialized
DEBUG - 2017-01-02 21:58:02 --> UTF-8 Support Enabled
INFO - 2017-01-02 21:58:02 --> Utf8 Class Initialized
INFO - 2017-01-02 21:58:02 --> URI Class Initialized
INFO - 2017-01-02 21:58:02 --> Router Class Initialized
INFO - 2017-01-02 21:58:02 --> Output Class Initialized
INFO - 2017-01-02 21:58:02 --> Security Class Initialized
DEBUG - 2017-01-02 21:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 21:58:02 --> Input Class Initialized
INFO - 2017-01-02 21:58:02 --> Language Class Initialized
INFO - 2017-01-02 21:58:02 --> Loader Class Initialized
INFO - 2017-01-02 21:58:02 --> Database Driver Class Initialized
INFO - 2017-01-02 21:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 21:58:02 --> Controller Class Initialized
INFO - 2017-01-02 21:58:02 --> Helper loaded: url_helper
DEBUG - 2017-01-02 21:58:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 21:58:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 21:58:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 21:58:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 21:58:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 21:58:02 --> Final output sent to browser
DEBUG - 2017-01-02 21:58:02 --> Total execution time: 0.0138
INFO - 2017-01-02 22:02:51 --> Config Class Initialized
INFO - 2017-01-02 22:02:51 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:02:51 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:02:51 --> Utf8 Class Initialized
INFO - 2017-01-02 22:02:51 --> URI Class Initialized
INFO - 2017-01-02 22:02:51 --> Router Class Initialized
INFO - 2017-01-02 22:02:51 --> Output Class Initialized
INFO - 2017-01-02 22:02:51 --> Security Class Initialized
DEBUG - 2017-01-02 22:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:02:51 --> Input Class Initialized
INFO - 2017-01-02 22:02:51 --> Language Class Initialized
INFO - 2017-01-02 22:02:51 --> Loader Class Initialized
INFO - 2017-01-02 22:02:51 --> Database Driver Class Initialized
INFO - 2017-01-02 22:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:02:51 --> Controller Class Initialized
INFO - 2017-01-02 22:02:51 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:02:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:02:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:02:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:02:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:02:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:02:51 --> Final output sent to browser
DEBUG - 2017-01-02 22:02:51 --> Total execution time: 0.0137
INFO - 2017-01-02 22:02:59 --> Config Class Initialized
INFO - 2017-01-02 22:02:59 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:02:59 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:02:59 --> Utf8 Class Initialized
INFO - 2017-01-02 22:02:59 --> URI Class Initialized
DEBUG - 2017-01-02 22:02:59 --> No URI present. Default controller set.
INFO - 2017-01-02 22:02:59 --> Router Class Initialized
INFO - 2017-01-02 22:02:59 --> Output Class Initialized
INFO - 2017-01-02 22:02:59 --> Security Class Initialized
DEBUG - 2017-01-02 22:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:02:59 --> Input Class Initialized
INFO - 2017-01-02 22:02:59 --> Language Class Initialized
INFO - 2017-01-02 22:02:59 --> Loader Class Initialized
INFO - 2017-01-02 22:02:59 --> Database Driver Class Initialized
INFO - 2017-01-02 22:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:02:59 --> Controller Class Initialized
INFO - 2017-01-02 22:02:59 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:02:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:02:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:02:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:02:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:02:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:02:59 --> Final output sent to browser
DEBUG - 2017-01-02 22:02:59 --> Total execution time: 0.0242
INFO - 2017-01-02 22:03:00 --> Config Class Initialized
INFO - 2017-01-02 22:03:00 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:03:00 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:03:00 --> Utf8 Class Initialized
INFO - 2017-01-02 22:03:00 --> URI Class Initialized
INFO - 2017-01-02 22:03:00 --> Router Class Initialized
INFO - 2017-01-02 22:03:00 --> Output Class Initialized
INFO - 2017-01-02 22:03:00 --> Security Class Initialized
DEBUG - 2017-01-02 22:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:03:00 --> Input Class Initialized
INFO - 2017-01-02 22:03:00 --> Language Class Initialized
INFO - 2017-01-02 22:03:00 --> Loader Class Initialized
INFO - 2017-01-02 22:03:00 --> Database Driver Class Initialized
INFO - 2017-01-02 22:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:03:00 --> Controller Class Initialized
INFO - 2017-01-02 22:03:00 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:03:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:03:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:03:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:03:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:03:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:03:00 --> Final output sent to browser
DEBUG - 2017-01-02 22:03:00 --> Total execution time: 0.0140
INFO - 2017-01-02 22:03:03 --> Config Class Initialized
INFO - 2017-01-02 22:03:03 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:03:03 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:03:03 --> Utf8 Class Initialized
INFO - 2017-01-02 22:03:03 --> URI Class Initialized
DEBUG - 2017-01-02 22:03:03 --> No URI present. Default controller set.
INFO - 2017-01-02 22:03:03 --> Router Class Initialized
INFO - 2017-01-02 22:03:03 --> Output Class Initialized
INFO - 2017-01-02 22:03:03 --> Security Class Initialized
DEBUG - 2017-01-02 22:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:03:03 --> Input Class Initialized
INFO - 2017-01-02 22:03:03 --> Language Class Initialized
INFO - 2017-01-02 22:03:03 --> Loader Class Initialized
INFO - 2017-01-02 22:03:03 --> Database Driver Class Initialized
INFO - 2017-01-02 22:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:03:03 --> Controller Class Initialized
INFO - 2017-01-02 22:03:03 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:03:03 --> Final output sent to browser
DEBUG - 2017-01-02 22:03:03 --> Total execution time: 0.0136
INFO - 2017-01-02 22:03:03 --> Config Class Initialized
INFO - 2017-01-02 22:03:03 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:03:03 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:03:03 --> Utf8 Class Initialized
INFO - 2017-01-02 22:03:03 --> URI Class Initialized
DEBUG - 2017-01-02 22:03:03 --> No URI present. Default controller set.
INFO - 2017-01-02 22:03:03 --> Router Class Initialized
INFO - 2017-01-02 22:03:03 --> Output Class Initialized
INFO - 2017-01-02 22:03:03 --> Security Class Initialized
DEBUG - 2017-01-02 22:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:03:03 --> Input Class Initialized
INFO - 2017-01-02 22:03:03 --> Language Class Initialized
INFO - 2017-01-02 22:03:03 --> Loader Class Initialized
INFO - 2017-01-02 22:03:03 --> Database Driver Class Initialized
INFO - 2017-01-02 22:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:03:03 --> Controller Class Initialized
INFO - 2017-01-02 22:03:03 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:03:03 --> Final output sent to browser
DEBUG - 2017-01-02 22:03:03 --> Total execution time: 0.0216
INFO - 2017-01-02 22:03:03 --> Config Class Initialized
INFO - 2017-01-02 22:03:03 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:03:03 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:03:03 --> Utf8 Class Initialized
INFO - 2017-01-02 22:03:03 --> URI Class Initialized
DEBUG - 2017-01-02 22:03:03 --> No URI present. Default controller set.
INFO - 2017-01-02 22:03:03 --> Router Class Initialized
INFO - 2017-01-02 22:03:03 --> Output Class Initialized
INFO - 2017-01-02 22:03:03 --> Security Class Initialized
DEBUG - 2017-01-02 22:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:03:03 --> Input Class Initialized
INFO - 2017-01-02 22:03:03 --> Language Class Initialized
INFO - 2017-01-02 22:03:03 --> Loader Class Initialized
INFO - 2017-01-02 22:03:03 --> Database Driver Class Initialized
INFO - 2017-01-02 22:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:03:03 --> Controller Class Initialized
INFO - 2017-01-02 22:03:03 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:03:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:03:03 --> Final output sent to browser
DEBUG - 2017-01-02 22:03:03 --> Total execution time: 0.0136
INFO - 2017-01-02 22:03:04 --> Config Class Initialized
INFO - 2017-01-02 22:03:04 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:03:04 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:03:04 --> Utf8 Class Initialized
INFO - 2017-01-02 22:03:04 --> URI Class Initialized
DEBUG - 2017-01-02 22:03:04 --> No URI present. Default controller set.
INFO - 2017-01-02 22:03:04 --> Router Class Initialized
INFO - 2017-01-02 22:03:04 --> Output Class Initialized
INFO - 2017-01-02 22:03:04 --> Security Class Initialized
DEBUG - 2017-01-02 22:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:03:04 --> Input Class Initialized
INFO - 2017-01-02 22:03:04 --> Language Class Initialized
INFO - 2017-01-02 22:03:04 --> Loader Class Initialized
INFO - 2017-01-02 22:03:04 --> Database Driver Class Initialized
INFO - 2017-01-02 22:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:03:04 --> Controller Class Initialized
INFO - 2017-01-02 22:03:04 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:03:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:03:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:03:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:03:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:03:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:03:04 --> Final output sent to browser
DEBUG - 2017-01-02 22:03:04 --> Total execution time: 0.0132
INFO - 2017-01-02 22:03:04 --> Config Class Initialized
INFO - 2017-01-02 22:03:04 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:03:04 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:03:04 --> Utf8 Class Initialized
INFO - 2017-01-02 22:03:04 --> URI Class Initialized
INFO - 2017-01-02 22:03:04 --> Router Class Initialized
INFO - 2017-01-02 22:03:04 --> Output Class Initialized
INFO - 2017-01-02 22:03:04 --> Security Class Initialized
DEBUG - 2017-01-02 22:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:03:04 --> Input Class Initialized
INFO - 2017-01-02 22:03:04 --> Language Class Initialized
INFO - 2017-01-02 22:03:04 --> Loader Class Initialized
INFO - 2017-01-02 22:03:04 --> Database Driver Class Initialized
INFO - 2017-01-02 22:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:03:04 --> Controller Class Initialized
INFO - 2017-01-02 22:03:04 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:03:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:03:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:03:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:03:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:03:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:03:04 --> Final output sent to browser
DEBUG - 2017-01-02 22:03:04 --> Total execution time: 0.0143
INFO - 2017-01-02 22:04:13 --> Config Class Initialized
INFO - 2017-01-02 22:04:13 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:04:13 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:04:13 --> Utf8 Class Initialized
INFO - 2017-01-02 22:04:13 --> URI Class Initialized
DEBUG - 2017-01-02 22:04:13 --> No URI present. Default controller set.
INFO - 2017-01-02 22:04:13 --> Router Class Initialized
INFO - 2017-01-02 22:04:13 --> Output Class Initialized
INFO - 2017-01-02 22:04:13 --> Security Class Initialized
DEBUG - 2017-01-02 22:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:04:13 --> Input Class Initialized
INFO - 2017-01-02 22:04:13 --> Language Class Initialized
INFO - 2017-01-02 22:04:13 --> Loader Class Initialized
INFO - 2017-01-02 22:04:13 --> Database Driver Class Initialized
INFO - 2017-01-02 22:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:04:13 --> Controller Class Initialized
INFO - 2017-01-02 22:04:13 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:04:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:04:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:04:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:04:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:04:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:04:13 --> Final output sent to browser
DEBUG - 2017-01-02 22:04:13 --> Total execution time: 0.0136
INFO - 2017-01-02 22:04:14 --> Config Class Initialized
INFO - 2017-01-02 22:04:14 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:04:14 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:04:14 --> Utf8 Class Initialized
INFO - 2017-01-02 22:04:14 --> URI Class Initialized
DEBUG - 2017-01-02 22:04:14 --> No URI present. Default controller set.
INFO - 2017-01-02 22:04:14 --> Router Class Initialized
INFO - 2017-01-02 22:04:14 --> Output Class Initialized
INFO - 2017-01-02 22:04:14 --> Security Class Initialized
DEBUG - 2017-01-02 22:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:04:14 --> Input Class Initialized
INFO - 2017-01-02 22:04:14 --> Language Class Initialized
INFO - 2017-01-02 22:04:14 --> Loader Class Initialized
INFO - 2017-01-02 22:04:14 --> Database Driver Class Initialized
INFO - 2017-01-02 22:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:04:14 --> Controller Class Initialized
INFO - 2017-01-02 22:04:14 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:04:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:04:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:04:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:04:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:04:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:04:14 --> Final output sent to browser
DEBUG - 2017-01-02 22:04:14 --> Total execution time: 0.0137
INFO - 2017-01-02 22:04:15 --> Config Class Initialized
INFO - 2017-01-02 22:04:15 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:04:15 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:04:15 --> Utf8 Class Initialized
INFO - 2017-01-02 22:04:15 --> URI Class Initialized
INFO - 2017-01-02 22:04:15 --> Router Class Initialized
INFO - 2017-01-02 22:04:15 --> Output Class Initialized
INFO - 2017-01-02 22:04:15 --> Security Class Initialized
DEBUG - 2017-01-02 22:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:04:15 --> Input Class Initialized
INFO - 2017-01-02 22:04:15 --> Language Class Initialized
INFO - 2017-01-02 22:04:15 --> Loader Class Initialized
INFO - 2017-01-02 22:04:15 --> Database Driver Class Initialized
INFO - 2017-01-02 22:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:04:15 --> Controller Class Initialized
INFO - 2017-01-02 22:04:15 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:04:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:04:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:04:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:04:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:04:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:04:15 --> Final output sent to browser
DEBUG - 2017-01-02 22:04:15 --> Total execution time: 0.0134
INFO - 2017-01-02 22:04:19 --> Config Class Initialized
INFO - 2017-01-02 22:04:19 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:04:19 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:04:19 --> Utf8 Class Initialized
INFO - 2017-01-02 22:04:19 --> URI Class Initialized
DEBUG - 2017-01-02 22:04:19 --> No URI present. Default controller set.
INFO - 2017-01-02 22:04:19 --> Router Class Initialized
INFO - 2017-01-02 22:04:19 --> Output Class Initialized
INFO - 2017-01-02 22:04:19 --> Security Class Initialized
DEBUG - 2017-01-02 22:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:04:19 --> Input Class Initialized
INFO - 2017-01-02 22:04:19 --> Language Class Initialized
INFO - 2017-01-02 22:04:19 --> Loader Class Initialized
INFO - 2017-01-02 22:04:19 --> Database Driver Class Initialized
INFO - 2017-01-02 22:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:04:19 --> Controller Class Initialized
INFO - 2017-01-02 22:04:19 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:04:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:04:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:04:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:04:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:04:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:04:19 --> Final output sent to browser
DEBUG - 2017-01-02 22:04:19 --> Total execution time: 0.0253
INFO - 2017-01-02 22:04:21 --> Config Class Initialized
INFO - 2017-01-02 22:04:21 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:04:21 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:04:21 --> Utf8 Class Initialized
INFO - 2017-01-02 22:04:21 --> URI Class Initialized
INFO - 2017-01-02 22:04:21 --> Router Class Initialized
INFO - 2017-01-02 22:04:21 --> Output Class Initialized
INFO - 2017-01-02 22:04:21 --> Security Class Initialized
DEBUG - 2017-01-02 22:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:04:21 --> Input Class Initialized
INFO - 2017-01-02 22:04:21 --> Language Class Initialized
INFO - 2017-01-02 22:04:21 --> Loader Class Initialized
INFO - 2017-01-02 22:04:21 --> Database Driver Class Initialized
INFO - 2017-01-02 22:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:04:21 --> Controller Class Initialized
INFO - 2017-01-02 22:04:21 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:04:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:04:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:04:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:04:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:04:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:04:21 --> Final output sent to browser
DEBUG - 2017-01-02 22:04:21 --> Total execution time: 0.0216
INFO - 2017-01-02 22:04:24 --> Config Class Initialized
INFO - 2017-01-02 22:04:24 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:04:24 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:04:24 --> Utf8 Class Initialized
INFO - 2017-01-02 22:04:24 --> URI Class Initialized
DEBUG - 2017-01-02 22:04:24 --> No URI present. Default controller set.
INFO - 2017-01-02 22:04:24 --> Router Class Initialized
INFO - 2017-01-02 22:04:24 --> Output Class Initialized
INFO - 2017-01-02 22:04:24 --> Security Class Initialized
DEBUG - 2017-01-02 22:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:04:24 --> Input Class Initialized
INFO - 2017-01-02 22:04:24 --> Language Class Initialized
INFO - 2017-01-02 22:04:24 --> Loader Class Initialized
INFO - 2017-01-02 22:04:24 --> Database Driver Class Initialized
INFO - 2017-01-02 22:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:04:24 --> Controller Class Initialized
INFO - 2017-01-02 22:04:24 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:04:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:04:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:04:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:04:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:04:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:04:24 --> Final output sent to browser
DEBUG - 2017-01-02 22:04:24 --> Total execution time: 0.0135
INFO - 2017-01-02 22:04:30 --> Config Class Initialized
INFO - 2017-01-02 22:04:30 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:04:30 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:04:30 --> Utf8 Class Initialized
INFO - 2017-01-02 22:04:30 --> URI Class Initialized
INFO - 2017-01-02 22:04:30 --> Router Class Initialized
INFO - 2017-01-02 22:04:30 --> Output Class Initialized
INFO - 2017-01-02 22:04:30 --> Security Class Initialized
DEBUG - 2017-01-02 22:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:04:30 --> Input Class Initialized
INFO - 2017-01-02 22:04:30 --> Language Class Initialized
INFO - 2017-01-02 22:04:30 --> Loader Class Initialized
INFO - 2017-01-02 22:04:30 --> Database Driver Class Initialized
INFO - 2017-01-02 22:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:04:30 --> Controller Class Initialized
INFO - 2017-01-02 22:04:30 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:04:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:04:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:04:30 --> Final output sent to browser
DEBUG - 2017-01-02 22:04:30 --> Total execution time: 0.0156
INFO - 2017-01-02 22:04:38 --> Config Class Initialized
INFO - 2017-01-02 22:04:38 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:04:38 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:04:38 --> Utf8 Class Initialized
INFO - 2017-01-02 22:04:38 --> URI Class Initialized
DEBUG - 2017-01-02 22:04:38 --> No URI present. Default controller set.
INFO - 2017-01-02 22:04:38 --> Router Class Initialized
INFO - 2017-01-02 22:04:38 --> Output Class Initialized
INFO - 2017-01-02 22:04:38 --> Security Class Initialized
DEBUG - 2017-01-02 22:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:04:38 --> Input Class Initialized
INFO - 2017-01-02 22:04:38 --> Language Class Initialized
INFO - 2017-01-02 22:04:38 --> Loader Class Initialized
INFO - 2017-01-02 22:04:38 --> Database Driver Class Initialized
INFO - 2017-01-02 22:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:04:38 --> Controller Class Initialized
INFO - 2017-01-02 22:04:38 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:04:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:04:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:04:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:04:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:04:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:04:38 --> Final output sent to browser
DEBUG - 2017-01-02 22:04:38 --> Total execution time: 0.0181
INFO - 2017-01-02 22:04:39 --> Config Class Initialized
INFO - 2017-01-02 22:04:39 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:04:39 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:04:39 --> Utf8 Class Initialized
INFO - 2017-01-02 22:04:39 --> URI Class Initialized
INFO - 2017-01-02 22:04:39 --> Router Class Initialized
INFO - 2017-01-02 22:04:39 --> Output Class Initialized
INFO - 2017-01-02 22:04:39 --> Security Class Initialized
DEBUG - 2017-01-02 22:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:04:39 --> Input Class Initialized
INFO - 2017-01-02 22:04:39 --> Language Class Initialized
INFO - 2017-01-02 22:04:39 --> Loader Class Initialized
INFO - 2017-01-02 22:04:39 --> Database Driver Class Initialized
INFO - 2017-01-02 22:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:04:39 --> Controller Class Initialized
INFO - 2017-01-02 22:04:39 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:04:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:04:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:04:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:04:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:04:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:04:39 --> Final output sent to browser
DEBUG - 2017-01-02 22:04:39 --> Total execution time: 0.0243
INFO - 2017-01-02 22:05:32 --> Config Class Initialized
INFO - 2017-01-02 22:05:32 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:05:32 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:05:32 --> Utf8 Class Initialized
INFO - 2017-01-02 22:05:32 --> URI Class Initialized
DEBUG - 2017-01-02 22:05:32 --> No URI present. Default controller set.
INFO - 2017-01-02 22:05:32 --> Router Class Initialized
INFO - 2017-01-02 22:05:32 --> Output Class Initialized
INFO - 2017-01-02 22:05:32 --> Security Class Initialized
DEBUG - 2017-01-02 22:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:05:32 --> Input Class Initialized
INFO - 2017-01-02 22:05:32 --> Language Class Initialized
INFO - 2017-01-02 22:05:32 --> Loader Class Initialized
INFO - 2017-01-02 22:05:32 --> Database Driver Class Initialized
INFO - 2017-01-02 22:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:05:32 --> Controller Class Initialized
INFO - 2017-01-02 22:05:32 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:05:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:05:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:05:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:05:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:05:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:05:32 --> Final output sent to browser
DEBUG - 2017-01-02 22:05:32 --> Total execution time: 0.0186
INFO - 2017-01-02 22:05:33 --> Config Class Initialized
INFO - 2017-01-02 22:05:33 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:05:33 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:05:33 --> Utf8 Class Initialized
INFO - 2017-01-02 22:05:33 --> URI Class Initialized
INFO - 2017-01-02 22:05:33 --> Router Class Initialized
INFO - 2017-01-02 22:05:33 --> Output Class Initialized
INFO - 2017-01-02 22:05:33 --> Security Class Initialized
DEBUG - 2017-01-02 22:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:05:33 --> Input Class Initialized
INFO - 2017-01-02 22:05:33 --> Language Class Initialized
INFO - 2017-01-02 22:05:33 --> Loader Class Initialized
INFO - 2017-01-02 22:05:33 --> Database Driver Class Initialized
INFO - 2017-01-02 22:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:05:33 --> Controller Class Initialized
INFO - 2017-01-02 22:05:33 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:05:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:05:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:05:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:05:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:05:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:05:33 --> Final output sent to browser
DEBUG - 2017-01-02 22:05:33 --> Total execution time: 0.0163
INFO - 2017-01-02 22:05:42 --> Config Class Initialized
INFO - 2017-01-02 22:05:42 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:05:42 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:05:42 --> Utf8 Class Initialized
INFO - 2017-01-02 22:05:42 --> URI Class Initialized
DEBUG - 2017-01-02 22:05:42 --> No URI present. Default controller set.
INFO - 2017-01-02 22:05:42 --> Router Class Initialized
INFO - 2017-01-02 22:05:42 --> Output Class Initialized
INFO - 2017-01-02 22:05:42 --> Security Class Initialized
DEBUG - 2017-01-02 22:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:05:42 --> Input Class Initialized
INFO - 2017-01-02 22:05:42 --> Language Class Initialized
INFO - 2017-01-02 22:05:42 --> Loader Class Initialized
INFO - 2017-01-02 22:05:42 --> Database Driver Class Initialized
INFO - 2017-01-02 22:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:05:42 --> Controller Class Initialized
INFO - 2017-01-02 22:05:42 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:05:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:05:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:05:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:05:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:05:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:05:42 --> Final output sent to browser
DEBUG - 2017-01-02 22:05:42 --> Total execution time: 0.0670
INFO - 2017-01-02 22:05:42 --> Config Class Initialized
INFO - 2017-01-02 22:05:42 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:05:42 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:05:42 --> Utf8 Class Initialized
INFO - 2017-01-02 22:05:42 --> URI Class Initialized
INFO - 2017-01-02 22:05:42 --> Router Class Initialized
INFO - 2017-01-02 22:05:42 --> Output Class Initialized
INFO - 2017-01-02 22:05:42 --> Security Class Initialized
DEBUG - 2017-01-02 22:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:05:42 --> Input Class Initialized
INFO - 2017-01-02 22:05:42 --> Language Class Initialized
INFO - 2017-01-02 22:05:42 --> Loader Class Initialized
INFO - 2017-01-02 22:05:42 --> Database Driver Class Initialized
INFO - 2017-01-02 22:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:05:42 --> Controller Class Initialized
INFO - 2017-01-02 22:05:42 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:05:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:05:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:05:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:05:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:05:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:05:42 --> Final output sent to browser
DEBUG - 2017-01-02 22:05:42 --> Total execution time: 0.0137
INFO - 2017-01-02 22:12:07 --> Config Class Initialized
INFO - 2017-01-02 22:12:07 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:12:07 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:12:07 --> Utf8 Class Initialized
INFO - 2017-01-02 22:12:07 --> URI Class Initialized
DEBUG - 2017-01-02 22:12:07 --> No URI present. Default controller set.
INFO - 2017-01-02 22:12:07 --> Router Class Initialized
INFO - 2017-01-02 22:12:07 --> Output Class Initialized
INFO - 2017-01-02 22:12:07 --> Security Class Initialized
DEBUG - 2017-01-02 22:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:12:07 --> Input Class Initialized
INFO - 2017-01-02 22:12:07 --> Language Class Initialized
INFO - 2017-01-02 22:12:07 --> Loader Class Initialized
INFO - 2017-01-02 22:12:07 --> Database Driver Class Initialized
INFO - 2017-01-02 22:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:12:07 --> Controller Class Initialized
INFO - 2017-01-02 22:12:07 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:12:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:12:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:12:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:12:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:12:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:12:07 --> Final output sent to browser
DEBUG - 2017-01-02 22:12:07 --> Total execution time: 0.1077
INFO - 2017-01-02 22:12:09 --> Config Class Initialized
INFO - 2017-01-02 22:12:09 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:12:09 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:12:09 --> Utf8 Class Initialized
INFO - 2017-01-02 22:12:09 --> URI Class Initialized
INFO - 2017-01-02 22:12:09 --> Router Class Initialized
INFO - 2017-01-02 22:12:09 --> Output Class Initialized
INFO - 2017-01-02 22:12:09 --> Security Class Initialized
DEBUG - 2017-01-02 22:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:12:09 --> Input Class Initialized
INFO - 2017-01-02 22:12:09 --> Language Class Initialized
INFO - 2017-01-02 22:12:09 --> Loader Class Initialized
INFO - 2017-01-02 22:12:09 --> Database Driver Class Initialized
INFO - 2017-01-02 22:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:12:09 --> Controller Class Initialized
INFO - 2017-01-02 22:12:09 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:12:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:12:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:12:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:12:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:12:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:12:09 --> Final output sent to browser
DEBUG - 2017-01-02 22:12:09 --> Total execution time: 0.0139
INFO - 2017-01-02 22:15:14 --> Config Class Initialized
INFO - 2017-01-02 22:15:14 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:15:14 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:15:14 --> Utf8 Class Initialized
INFO - 2017-01-02 22:15:14 --> URI Class Initialized
DEBUG - 2017-01-02 22:15:14 --> No URI present. Default controller set.
INFO - 2017-01-02 22:15:14 --> Router Class Initialized
INFO - 2017-01-02 22:15:14 --> Output Class Initialized
INFO - 2017-01-02 22:15:14 --> Security Class Initialized
DEBUG - 2017-01-02 22:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:15:14 --> Input Class Initialized
INFO - 2017-01-02 22:15:14 --> Language Class Initialized
INFO - 2017-01-02 22:15:14 --> Loader Class Initialized
INFO - 2017-01-02 22:15:14 --> Database Driver Class Initialized
INFO - 2017-01-02 22:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:15:14 --> Controller Class Initialized
INFO - 2017-01-02 22:15:14 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:15:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:15:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:15:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:15:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:15:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:15:14 --> Final output sent to browser
DEBUG - 2017-01-02 22:15:14 --> Total execution time: 0.2625
INFO - 2017-01-02 22:15:15 --> Config Class Initialized
INFO - 2017-01-02 22:15:15 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:15:15 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:15:15 --> Utf8 Class Initialized
INFO - 2017-01-02 22:15:15 --> URI Class Initialized
INFO - 2017-01-02 22:15:15 --> Router Class Initialized
INFO - 2017-01-02 22:15:15 --> Output Class Initialized
INFO - 2017-01-02 22:15:15 --> Security Class Initialized
DEBUG - 2017-01-02 22:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:15:15 --> Input Class Initialized
INFO - 2017-01-02 22:15:15 --> Language Class Initialized
INFO - 2017-01-02 22:15:15 --> Loader Class Initialized
INFO - 2017-01-02 22:15:15 --> Database Driver Class Initialized
INFO - 2017-01-02 22:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:15:15 --> Controller Class Initialized
INFO - 2017-01-02 22:15:15 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:15:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:15:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:15:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:15:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:15:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:15:15 --> Final output sent to browser
DEBUG - 2017-01-02 22:15:15 --> Total execution time: 0.0139
INFO - 2017-01-02 22:19:25 --> Config Class Initialized
INFO - 2017-01-02 22:19:25 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:19:25 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:19:25 --> Utf8 Class Initialized
INFO - 2017-01-02 22:19:25 --> URI Class Initialized
DEBUG - 2017-01-02 22:19:25 --> No URI present. Default controller set.
INFO - 2017-01-02 22:19:25 --> Router Class Initialized
INFO - 2017-01-02 22:19:25 --> Output Class Initialized
INFO - 2017-01-02 22:19:25 --> Security Class Initialized
DEBUG - 2017-01-02 22:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:19:25 --> Input Class Initialized
INFO - 2017-01-02 22:19:25 --> Language Class Initialized
INFO - 2017-01-02 22:19:25 --> Loader Class Initialized
INFO - 2017-01-02 22:19:25 --> Database Driver Class Initialized
INFO - 2017-01-02 22:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:19:25 --> Controller Class Initialized
INFO - 2017-01-02 22:19:25 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:19:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:19:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:19:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:19:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:19:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:19:25 --> Final output sent to browser
DEBUG - 2017-01-02 22:19:25 --> Total execution time: 0.0438
INFO - 2017-01-02 22:19:26 --> Config Class Initialized
INFO - 2017-01-02 22:19:26 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:19:26 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:19:26 --> Utf8 Class Initialized
INFO - 2017-01-02 22:19:26 --> URI Class Initialized
INFO - 2017-01-02 22:19:26 --> Router Class Initialized
INFO - 2017-01-02 22:19:26 --> Output Class Initialized
INFO - 2017-01-02 22:19:26 --> Security Class Initialized
DEBUG - 2017-01-02 22:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:19:26 --> Input Class Initialized
INFO - 2017-01-02 22:19:26 --> Language Class Initialized
INFO - 2017-01-02 22:19:26 --> Loader Class Initialized
INFO - 2017-01-02 22:19:26 --> Database Driver Class Initialized
INFO - 2017-01-02 22:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:19:26 --> Controller Class Initialized
INFO - 2017-01-02 22:19:26 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:19:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:19:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:19:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:19:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:19:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:19:26 --> Final output sent to browser
DEBUG - 2017-01-02 22:19:26 --> Total execution time: 0.0139
INFO - 2017-01-02 22:26:30 --> Config Class Initialized
INFO - 2017-01-02 22:26:30 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:26:30 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:26:30 --> Utf8 Class Initialized
INFO - 2017-01-02 22:26:30 --> URI Class Initialized
INFO - 2017-01-02 22:26:30 --> Router Class Initialized
INFO - 2017-01-02 22:26:30 --> Output Class Initialized
INFO - 2017-01-02 22:26:30 --> Security Class Initialized
DEBUG - 2017-01-02 22:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:26:30 --> Input Class Initialized
INFO - 2017-01-02 22:26:30 --> Language Class Initialized
INFO - 2017-01-02 22:26:30 --> Loader Class Initialized
INFO - 2017-01-02 22:26:30 --> Database Driver Class Initialized
INFO - 2017-01-02 22:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:26:30 --> Controller Class Initialized
INFO - 2017-01-02 22:26:30 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:26:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:26:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:26:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:26:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:26:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:26:30 --> Final output sent to browser
DEBUG - 2017-01-02 22:26:30 --> Total execution time: 0.0431
INFO - 2017-01-02 22:26:44 --> Config Class Initialized
INFO - 2017-01-02 22:26:44 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:26:44 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:26:44 --> Utf8 Class Initialized
INFO - 2017-01-02 22:26:44 --> URI Class Initialized
INFO - 2017-01-02 22:26:44 --> Router Class Initialized
INFO - 2017-01-02 22:26:44 --> Output Class Initialized
INFO - 2017-01-02 22:26:44 --> Security Class Initialized
DEBUG - 2017-01-02 22:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:26:44 --> Input Class Initialized
INFO - 2017-01-02 22:26:44 --> Language Class Initialized
INFO - 2017-01-02 22:26:44 --> Loader Class Initialized
INFO - 2017-01-02 22:26:44 --> Database Driver Class Initialized
INFO - 2017-01-02 22:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:26:44 --> Controller Class Initialized
INFO - 2017-01-02 22:26:44 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:26:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:26:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:26:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:26:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:26:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:26:44 --> Final output sent to browser
DEBUG - 2017-01-02 22:26:44 --> Total execution time: 0.0141
INFO - 2017-01-02 22:26:48 --> Config Class Initialized
INFO - 2017-01-02 22:26:48 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:26:48 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:26:48 --> Utf8 Class Initialized
INFO - 2017-01-02 22:26:48 --> URI Class Initialized
INFO - 2017-01-02 22:26:48 --> Router Class Initialized
INFO - 2017-01-02 22:26:48 --> Output Class Initialized
INFO - 2017-01-02 22:26:48 --> Security Class Initialized
DEBUG - 2017-01-02 22:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:26:48 --> Input Class Initialized
INFO - 2017-01-02 22:26:48 --> Language Class Initialized
INFO - 2017-01-02 22:26:48 --> Loader Class Initialized
INFO - 2017-01-02 22:26:48 --> Database Driver Class Initialized
INFO - 2017-01-02 22:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:26:48 --> Controller Class Initialized
INFO - 2017-01-02 22:26:48 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:26:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:26:48 --> Final output sent to browser
DEBUG - 2017-01-02 22:26:48 --> Total execution time: 0.0788
INFO - 2017-01-02 22:27:42 --> Config Class Initialized
INFO - 2017-01-02 22:27:42 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:27:42 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:27:42 --> Utf8 Class Initialized
INFO - 2017-01-02 22:27:42 --> URI Class Initialized
DEBUG - 2017-01-02 22:27:42 --> No URI present. Default controller set.
INFO - 2017-01-02 22:27:42 --> Router Class Initialized
INFO - 2017-01-02 22:27:42 --> Output Class Initialized
INFO - 2017-01-02 22:27:42 --> Security Class Initialized
DEBUG - 2017-01-02 22:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:27:42 --> Input Class Initialized
INFO - 2017-01-02 22:27:42 --> Language Class Initialized
INFO - 2017-01-02 22:27:42 --> Loader Class Initialized
INFO - 2017-01-02 22:27:42 --> Database Driver Class Initialized
INFO - 2017-01-02 22:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:27:42 --> Controller Class Initialized
INFO - 2017-01-02 22:27:42 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:27:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:27:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:27:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:27:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:27:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:27:42 --> Final output sent to browser
DEBUG - 2017-01-02 22:27:42 --> Total execution time: 0.0131
INFO - 2017-01-02 22:27:43 --> Config Class Initialized
INFO - 2017-01-02 22:27:43 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:27:43 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:27:43 --> Utf8 Class Initialized
INFO - 2017-01-02 22:27:43 --> URI Class Initialized
INFO - 2017-01-02 22:27:43 --> Router Class Initialized
INFO - 2017-01-02 22:27:43 --> Output Class Initialized
INFO - 2017-01-02 22:27:43 --> Security Class Initialized
DEBUG - 2017-01-02 22:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:27:43 --> Input Class Initialized
INFO - 2017-01-02 22:27:43 --> Language Class Initialized
INFO - 2017-01-02 22:27:43 --> Loader Class Initialized
INFO - 2017-01-02 22:27:43 --> Database Driver Class Initialized
INFO - 2017-01-02 22:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:27:43 --> Controller Class Initialized
INFO - 2017-01-02 22:27:43 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:27:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:27:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:27:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:27:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:27:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:27:43 --> Final output sent to browser
DEBUG - 2017-01-02 22:27:43 --> Total execution time: 0.0135
INFO - 2017-01-02 22:29:02 --> Config Class Initialized
INFO - 2017-01-02 22:29:02 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:29:02 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:29:02 --> Utf8 Class Initialized
INFO - 2017-01-02 22:29:02 --> URI Class Initialized
DEBUG - 2017-01-02 22:29:02 --> No URI present. Default controller set.
INFO - 2017-01-02 22:29:02 --> Router Class Initialized
INFO - 2017-01-02 22:29:02 --> Output Class Initialized
INFO - 2017-01-02 22:29:02 --> Security Class Initialized
DEBUG - 2017-01-02 22:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:29:02 --> Input Class Initialized
INFO - 2017-01-02 22:29:02 --> Language Class Initialized
INFO - 2017-01-02 22:29:02 --> Loader Class Initialized
INFO - 2017-01-02 22:29:02 --> Database Driver Class Initialized
INFO - 2017-01-02 22:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:29:02 --> Controller Class Initialized
INFO - 2017-01-02 22:29:02 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:29:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:29:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:29:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:29:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:29:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:29:02 --> Final output sent to browser
DEBUG - 2017-01-02 22:29:02 --> Total execution time: 0.0137
INFO - 2017-01-02 22:29:40 --> Config Class Initialized
INFO - 2017-01-02 22:29:40 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:29:40 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:29:40 --> Utf8 Class Initialized
INFO - 2017-01-02 22:29:40 --> URI Class Initialized
INFO - 2017-01-02 22:29:40 --> Router Class Initialized
INFO - 2017-01-02 22:29:40 --> Output Class Initialized
INFO - 2017-01-02 22:29:40 --> Security Class Initialized
DEBUG - 2017-01-02 22:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:29:40 --> Input Class Initialized
INFO - 2017-01-02 22:29:40 --> Language Class Initialized
INFO - 2017-01-02 22:29:40 --> Loader Class Initialized
INFO - 2017-01-02 22:29:40 --> Database Driver Class Initialized
INFO - 2017-01-02 22:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:29:40 --> Controller Class Initialized
INFO - 2017-01-02 22:29:40 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:29:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:29:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:29:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:29:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:29:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:29:40 --> Final output sent to browser
DEBUG - 2017-01-02 22:29:40 --> Total execution time: 0.0140
INFO - 2017-01-02 22:31:00 --> Config Class Initialized
INFO - 2017-01-02 22:31:00 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:31:00 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:31:00 --> Utf8 Class Initialized
INFO - 2017-01-02 22:31:00 --> URI Class Initialized
DEBUG - 2017-01-02 22:31:00 --> No URI present. Default controller set.
INFO - 2017-01-02 22:31:00 --> Router Class Initialized
INFO - 2017-01-02 22:31:00 --> Output Class Initialized
INFO - 2017-01-02 22:31:00 --> Security Class Initialized
DEBUG - 2017-01-02 22:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:31:00 --> Input Class Initialized
INFO - 2017-01-02 22:31:00 --> Language Class Initialized
INFO - 2017-01-02 22:31:00 --> Loader Class Initialized
INFO - 2017-01-02 22:31:00 --> Database Driver Class Initialized
INFO - 2017-01-02 22:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:31:00 --> Controller Class Initialized
INFO - 2017-01-02 22:31:00 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:31:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:31:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:31:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:31:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:31:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:31:00 --> Final output sent to browser
DEBUG - 2017-01-02 22:31:00 --> Total execution time: 0.0142
INFO - 2017-01-02 22:31:00 --> Config Class Initialized
INFO - 2017-01-02 22:31:00 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:31:00 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:31:00 --> Utf8 Class Initialized
INFO - 2017-01-02 22:31:00 --> URI Class Initialized
INFO - 2017-01-02 22:31:00 --> Router Class Initialized
INFO - 2017-01-02 22:31:00 --> Output Class Initialized
INFO - 2017-01-02 22:31:00 --> Security Class Initialized
DEBUG - 2017-01-02 22:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:31:00 --> Input Class Initialized
INFO - 2017-01-02 22:31:00 --> Language Class Initialized
INFO - 2017-01-02 22:31:00 --> Loader Class Initialized
INFO - 2017-01-02 22:31:00 --> Database Driver Class Initialized
INFO - 2017-01-02 22:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:31:00 --> Controller Class Initialized
INFO - 2017-01-02 22:31:00 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:31:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:31:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:31:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:31:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:31:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:31:00 --> Final output sent to browser
DEBUG - 2017-01-02 22:31:00 --> Total execution time: 0.0139
INFO - 2017-01-02 22:31:12 --> Config Class Initialized
INFO - 2017-01-02 22:31:12 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:31:12 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:31:12 --> Utf8 Class Initialized
INFO - 2017-01-02 22:31:12 --> URI Class Initialized
DEBUG - 2017-01-02 22:31:12 --> No URI present. Default controller set.
INFO - 2017-01-02 22:31:12 --> Router Class Initialized
INFO - 2017-01-02 22:31:12 --> Output Class Initialized
INFO - 2017-01-02 22:31:12 --> Security Class Initialized
DEBUG - 2017-01-02 22:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:31:12 --> Input Class Initialized
INFO - 2017-01-02 22:31:12 --> Language Class Initialized
INFO - 2017-01-02 22:31:12 --> Loader Class Initialized
INFO - 2017-01-02 22:31:12 --> Database Driver Class Initialized
INFO - 2017-01-02 22:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:31:12 --> Controller Class Initialized
INFO - 2017-01-02 22:31:12 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:31:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:31:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:31:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:31:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:31:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:31:12 --> Final output sent to browser
DEBUG - 2017-01-02 22:31:12 --> Total execution time: 0.0138
INFO - 2017-01-02 22:31:13 --> Config Class Initialized
INFO - 2017-01-02 22:31:13 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:31:13 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:31:13 --> Utf8 Class Initialized
INFO - 2017-01-02 22:31:13 --> URI Class Initialized
INFO - 2017-01-02 22:31:13 --> Router Class Initialized
INFO - 2017-01-02 22:31:13 --> Output Class Initialized
INFO - 2017-01-02 22:31:13 --> Security Class Initialized
DEBUG - 2017-01-02 22:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:31:13 --> Input Class Initialized
INFO - 2017-01-02 22:31:13 --> Language Class Initialized
INFO - 2017-01-02 22:31:13 --> Loader Class Initialized
INFO - 2017-01-02 22:31:13 --> Database Driver Class Initialized
INFO - 2017-01-02 22:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:31:13 --> Controller Class Initialized
INFO - 2017-01-02 22:31:13 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:31:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:31:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:31:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:31:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:31:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:31:13 --> Final output sent to browser
DEBUG - 2017-01-02 22:31:13 --> Total execution time: 0.0137
INFO - 2017-01-02 22:31:29 --> Config Class Initialized
INFO - 2017-01-02 22:31:29 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:31:29 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:31:29 --> Utf8 Class Initialized
INFO - 2017-01-02 22:31:29 --> URI Class Initialized
DEBUG - 2017-01-02 22:31:29 --> No URI present. Default controller set.
INFO - 2017-01-02 22:31:29 --> Router Class Initialized
INFO - 2017-01-02 22:31:29 --> Output Class Initialized
INFO - 2017-01-02 22:31:29 --> Security Class Initialized
DEBUG - 2017-01-02 22:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:31:29 --> Input Class Initialized
INFO - 2017-01-02 22:31:29 --> Language Class Initialized
INFO - 2017-01-02 22:31:29 --> Loader Class Initialized
INFO - 2017-01-02 22:31:29 --> Database Driver Class Initialized
INFO - 2017-01-02 22:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:31:29 --> Controller Class Initialized
INFO - 2017-01-02 22:31:29 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:31:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:31:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:31:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:31:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:31:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:31:29 --> Final output sent to browser
DEBUG - 2017-01-02 22:31:29 --> Total execution time: 0.0146
INFO - 2017-01-02 22:31:31 --> Config Class Initialized
INFO - 2017-01-02 22:31:31 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:31:31 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:31:31 --> Utf8 Class Initialized
INFO - 2017-01-02 22:31:31 --> URI Class Initialized
INFO - 2017-01-02 22:31:31 --> Router Class Initialized
INFO - 2017-01-02 22:31:31 --> Output Class Initialized
INFO - 2017-01-02 22:31:31 --> Security Class Initialized
DEBUG - 2017-01-02 22:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:31:31 --> Input Class Initialized
INFO - 2017-01-02 22:31:31 --> Language Class Initialized
INFO - 2017-01-02 22:31:31 --> Loader Class Initialized
INFO - 2017-01-02 22:31:31 --> Database Driver Class Initialized
INFO - 2017-01-02 22:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:31:31 --> Controller Class Initialized
INFO - 2017-01-02 22:31:31 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:31:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:31:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:31:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:31:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:31:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:31:31 --> Final output sent to browser
DEBUG - 2017-01-02 22:31:31 --> Total execution time: 0.0139
INFO - 2017-01-02 22:49:02 --> Config Class Initialized
INFO - 2017-01-02 22:49:02 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:49:02 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:49:02 --> Utf8 Class Initialized
INFO - 2017-01-02 22:49:02 --> URI Class Initialized
DEBUG - 2017-01-02 22:49:02 --> No URI present. Default controller set.
INFO - 2017-01-02 22:49:02 --> Router Class Initialized
INFO - 2017-01-02 22:49:02 --> Output Class Initialized
INFO - 2017-01-02 22:49:02 --> Security Class Initialized
DEBUG - 2017-01-02 22:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:49:02 --> Input Class Initialized
INFO - 2017-01-02 22:49:02 --> Language Class Initialized
INFO - 2017-01-02 22:49:02 --> Loader Class Initialized
INFO - 2017-01-02 22:49:02 --> Database Driver Class Initialized
INFO - 2017-01-02 22:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:49:02 --> Controller Class Initialized
INFO - 2017-01-02 22:49:02 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:49:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:49:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:49:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:49:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:49:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:49:02 --> Final output sent to browser
DEBUG - 2017-01-02 22:49:02 --> Total execution time: 0.1516
INFO - 2017-01-02 22:55:03 --> Config Class Initialized
INFO - 2017-01-02 22:55:03 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:55:03 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:55:03 --> Utf8 Class Initialized
INFO - 2017-01-02 22:55:03 --> URI Class Initialized
DEBUG - 2017-01-02 22:55:03 --> No URI present. Default controller set.
INFO - 2017-01-02 22:55:03 --> Router Class Initialized
INFO - 2017-01-02 22:55:03 --> Output Class Initialized
INFO - 2017-01-02 22:55:03 --> Security Class Initialized
DEBUG - 2017-01-02 22:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:55:03 --> Input Class Initialized
INFO - 2017-01-02 22:55:03 --> Language Class Initialized
INFO - 2017-01-02 22:55:03 --> Loader Class Initialized
INFO - 2017-01-02 22:55:03 --> Database Driver Class Initialized
INFO - 2017-01-02 22:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:55:03 --> Controller Class Initialized
INFO - 2017-01-02 22:55:03 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:55:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:55:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:55:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:55:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:55:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:55:03 --> Final output sent to browser
DEBUG - 2017-01-02 22:55:03 --> Total execution time: 0.0262
INFO - 2017-01-02 22:55:04 --> Config Class Initialized
INFO - 2017-01-02 22:55:04 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:55:04 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:55:04 --> Utf8 Class Initialized
INFO - 2017-01-02 22:55:04 --> URI Class Initialized
INFO - 2017-01-02 22:55:04 --> Router Class Initialized
INFO - 2017-01-02 22:55:04 --> Output Class Initialized
INFO - 2017-01-02 22:55:04 --> Security Class Initialized
DEBUG - 2017-01-02 22:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:55:04 --> Input Class Initialized
INFO - 2017-01-02 22:55:04 --> Language Class Initialized
INFO - 2017-01-02 22:55:04 --> Loader Class Initialized
INFO - 2017-01-02 22:55:04 --> Database Driver Class Initialized
INFO - 2017-01-02 22:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:55:04 --> Controller Class Initialized
INFO - 2017-01-02 22:55:04 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:55:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:55:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:55:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:55:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:55:04 --> Final output sent to browser
DEBUG - 2017-01-02 22:55:04 --> Total execution time: 0.0138
INFO - 2017-01-02 22:55:05 --> Config Class Initialized
INFO - 2017-01-02 22:55:05 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:55:05 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:55:05 --> Utf8 Class Initialized
INFO - 2017-01-02 22:55:05 --> URI Class Initialized
DEBUG - 2017-01-02 22:55:05 --> No URI present. Default controller set.
INFO - 2017-01-02 22:55:05 --> Router Class Initialized
INFO - 2017-01-02 22:55:05 --> Output Class Initialized
INFO - 2017-01-02 22:55:05 --> Security Class Initialized
DEBUG - 2017-01-02 22:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:55:05 --> Input Class Initialized
INFO - 2017-01-02 22:55:05 --> Language Class Initialized
INFO - 2017-01-02 22:55:05 --> Loader Class Initialized
INFO - 2017-01-02 22:55:05 --> Database Driver Class Initialized
INFO - 2017-01-02 22:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:55:05 --> Controller Class Initialized
INFO - 2017-01-02 22:55:05 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:55:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:55:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:55:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:55:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:55:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:55:05 --> Final output sent to browser
DEBUG - 2017-01-02 22:55:05 --> Total execution time: 0.0146
INFO - 2017-01-02 22:55:06 --> Config Class Initialized
INFO - 2017-01-02 22:55:06 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:55:06 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:55:06 --> Utf8 Class Initialized
INFO - 2017-01-02 22:55:06 --> URI Class Initialized
INFO - 2017-01-02 22:55:06 --> Router Class Initialized
INFO - 2017-01-02 22:55:06 --> Output Class Initialized
INFO - 2017-01-02 22:55:06 --> Security Class Initialized
DEBUG - 2017-01-02 22:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:55:06 --> Input Class Initialized
INFO - 2017-01-02 22:55:06 --> Language Class Initialized
INFO - 2017-01-02 22:55:06 --> Loader Class Initialized
INFO - 2017-01-02 22:55:06 --> Database Driver Class Initialized
INFO - 2017-01-02 22:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:55:06 --> Controller Class Initialized
INFO - 2017-01-02 22:55:06 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:55:06 --> Final output sent to browser
DEBUG - 2017-01-02 22:55:06 --> Total execution time: 0.0194
INFO - 2017-01-02 22:55:06 --> Config Class Initialized
INFO - 2017-01-02 22:55:06 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:55:06 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:55:06 --> Utf8 Class Initialized
INFO - 2017-01-02 22:55:06 --> URI Class Initialized
DEBUG - 2017-01-02 22:55:06 --> No URI present. Default controller set.
INFO - 2017-01-02 22:55:06 --> Router Class Initialized
INFO - 2017-01-02 22:55:06 --> Output Class Initialized
INFO - 2017-01-02 22:55:06 --> Security Class Initialized
DEBUG - 2017-01-02 22:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:55:06 --> Input Class Initialized
INFO - 2017-01-02 22:55:06 --> Language Class Initialized
INFO - 2017-01-02 22:55:06 --> Loader Class Initialized
INFO - 2017-01-02 22:55:06 --> Database Driver Class Initialized
INFO - 2017-01-02 22:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:55:06 --> Controller Class Initialized
INFO - 2017-01-02 22:55:06 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:55:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:55:06 --> Final output sent to browser
DEBUG - 2017-01-02 22:55:06 --> Total execution time: 0.0137
INFO - 2017-01-02 22:55:07 --> Config Class Initialized
INFO - 2017-01-02 22:55:07 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:55:07 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:55:07 --> Utf8 Class Initialized
INFO - 2017-01-02 22:55:07 --> URI Class Initialized
INFO - 2017-01-02 22:55:07 --> Router Class Initialized
INFO - 2017-01-02 22:55:07 --> Output Class Initialized
INFO - 2017-01-02 22:55:07 --> Security Class Initialized
DEBUG - 2017-01-02 22:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:55:07 --> Input Class Initialized
INFO - 2017-01-02 22:55:07 --> Language Class Initialized
INFO - 2017-01-02 22:55:07 --> Loader Class Initialized
INFO - 2017-01-02 22:55:07 --> Database Driver Class Initialized
INFO - 2017-01-02 22:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:55:07 --> Controller Class Initialized
INFO - 2017-01-02 22:55:07 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:55:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:55:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:55:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:55:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:55:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:55:07 --> Final output sent to browser
DEBUG - 2017-01-02 22:55:07 --> Total execution time: 0.0141
INFO - 2017-01-02 22:55:09 --> Config Class Initialized
INFO - 2017-01-02 22:55:09 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:55:09 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:55:09 --> Utf8 Class Initialized
INFO - 2017-01-02 22:55:09 --> URI Class Initialized
DEBUG - 2017-01-02 22:55:09 --> No URI present. Default controller set.
INFO - 2017-01-02 22:55:09 --> Router Class Initialized
INFO - 2017-01-02 22:55:09 --> Output Class Initialized
INFO - 2017-01-02 22:55:09 --> Security Class Initialized
DEBUG - 2017-01-02 22:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:55:09 --> Input Class Initialized
INFO - 2017-01-02 22:55:09 --> Language Class Initialized
INFO - 2017-01-02 22:55:09 --> Loader Class Initialized
INFO - 2017-01-02 22:55:09 --> Database Driver Class Initialized
INFO - 2017-01-02 22:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:55:09 --> Controller Class Initialized
INFO - 2017-01-02 22:55:09 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:55:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:55:09 --> Final output sent to browser
DEBUG - 2017-01-02 22:55:09 --> Total execution time: 0.0129
INFO - 2017-01-02 22:55:10 --> Config Class Initialized
INFO - 2017-01-02 22:55:10 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:55:10 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:55:10 --> Utf8 Class Initialized
INFO - 2017-01-02 22:55:10 --> URI Class Initialized
INFO - 2017-01-02 22:55:10 --> Router Class Initialized
INFO - 2017-01-02 22:55:10 --> Output Class Initialized
INFO - 2017-01-02 22:55:10 --> Security Class Initialized
DEBUG - 2017-01-02 22:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:55:10 --> Input Class Initialized
INFO - 2017-01-02 22:55:10 --> Language Class Initialized
INFO - 2017-01-02 22:55:10 --> Loader Class Initialized
INFO - 2017-01-02 22:55:10 --> Database Driver Class Initialized
INFO - 2017-01-02 22:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:55:10 --> Controller Class Initialized
INFO - 2017-01-02 22:55:10 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:55:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:55:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:55:10 --> Final output sent to browser
DEBUG - 2017-01-02 22:55:10 --> Total execution time: 0.0134
INFO - 2017-01-02 22:55:11 --> Config Class Initialized
INFO - 2017-01-02 22:55:11 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:55:11 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:55:11 --> Utf8 Class Initialized
INFO - 2017-01-02 22:55:11 --> URI Class Initialized
DEBUG - 2017-01-02 22:55:11 --> No URI present. Default controller set.
INFO - 2017-01-02 22:55:11 --> Router Class Initialized
INFO - 2017-01-02 22:55:11 --> Output Class Initialized
INFO - 2017-01-02 22:55:11 --> Security Class Initialized
DEBUG - 2017-01-02 22:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:55:11 --> Input Class Initialized
INFO - 2017-01-02 22:55:11 --> Language Class Initialized
INFO - 2017-01-02 22:55:11 --> Loader Class Initialized
INFO - 2017-01-02 22:55:11 --> Database Driver Class Initialized
INFO - 2017-01-02 22:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:55:11 --> Controller Class Initialized
INFO - 2017-01-02 22:55:11 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:55:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:55:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:55:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:55:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:55:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:55:11 --> Final output sent to browser
DEBUG - 2017-01-02 22:55:11 --> Total execution time: 0.0134
INFO - 2017-01-02 22:55:11 --> Config Class Initialized
INFO - 2017-01-02 22:55:11 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:55:11 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:55:11 --> Utf8 Class Initialized
INFO - 2017-01-02 22:55:11 --> URI Class Initialized
INFO - 2017-01-02 22:55:11 --> Router Class Initialized
INFO - 2017-01-02 22:55:11 --> Output Class Initialized
INFO - 2017-01-02 22:55:11 --> Security Class Initialized
DEBUG - 2017-01-02 22:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:55:11 --> Input Class Initialized
INFO - 2017-01-02 22:55:11 --> Language Class Initialized
INFO - 2017-01-02 22:55:11 --> Loader Class Initialized
INFO - 2017-01-02 22:55:12 --> Database Driver Class Initialized
INFO - 2017-01-02 22:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:55:12 --> Controller Class Initialized
INFO - 2017-01-02 22:55:12 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:55:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:55:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:55:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:55:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:55:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:55:12 --> Final output sent to browser
DEBUG - 2017-01-02 22:55:12 --> Total execution time: 0.0140
INFO - 2017-01-02 22:55:21 --> Config Class Initialized
INFO - 2017-01-02 22:55:21 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:55:21 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:55:21 --> Utf8 Class Initialized
INFO - 2017-01-02 22:55:21 --> URI Class Initialized
DEBUG - 2017-01-02 22:55:21 --> No URI present. Default controller set.
INFO - 2017-01-02 22:55:21 --> Router Class Initialized
INFO - 2017-01-02 22:55:21 --> Output Class Initialized
INFO - 2017-01-02 22:55:21 --> Security Class Initialized
DEBUG - 2017-01-02 22:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:55:21 --> Input Class Initialized
INFO - 2017-01-02 22:55:21 --> Language Class Initialized
INFO - 2017-01-02 22:55:21 --> Loader Class Initialized
INFO - 2017-01-02 22:55:21 --> Database Driver Class Initialized
INFO - 2017-01-02 22:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:55:21 --> Controller Class Initialized
INFO - 2017-01-02 22:55:21 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:55:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:55:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:55:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:55:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:55:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:55:21 --> Final output sent to browser
DEBUG - 2017-01-02 22:55:21 --> Total execution time: 0.0143
INFO - 2017-01-02 22:55:28 --> Config Class Initialized
INFO - 2017-01-02 22:55:28 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:55:28 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:55:28 --> Utf8 Class Initialized
INFO - 2017-01-02 22:55:28 --> URI Class Initialized
INFO - 2017-01-02 22:55:28 --> Router Class Initialized
INFO - 2017-01-02 22:55:28 --> Output Class Initialized
INFO - 2017-01-02 22:55:28 --> Security Class Initialized
DEBUG - 2017-01-02 22:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:55:28 --> Input Class Initialized
INFO - 2017-01-02 22:55:28 --> Language Class Initialized
INFO - 2017-01-02 22:55:28 --> Loader Class Initialized
INFO - 2017-01-02 22:55:28 --> Database Driver Class Initialized
INFO - 2017-01-02 22:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:55:28 --> Controller Class Initialized
INFO - 2017-01-02 22:55:28 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:55:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:55:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:55:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:55:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:55:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:55:28 --> Final output sent to browser
DEBUG - 2017-01-02 22:55:28 --> Total execution time: 0.0132
INFO - 2017-01-02 22:55:50 --> Config Class Initialized
INFO - 2017-01-02 22:55:50 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:55:50 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:55:50 --> Utf8 Class Initialized
INFO - 2017-01-02 22:55:50 --> URI Class Initialized
DEBUG - 2017-01-02 22:55:50 --> No URI present. Default controller set.
INFO - 2017-01-02 22:55:50 --> Router Class Initialized
INFO - 2017-01-02 22:55:50 --> Output Class Initialized
INFO - 2017-01-02 22:55:50 --> Security Class Initialized
DEBUG - 2017-01-02 22:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:55:50 --> Input Class Initialized
INFO - 2017-01-02 22:55:50 --> Language Class Initialized
INFO - 2017-01-02 22:55:50 --> Loader Class Initialized
INFO - 2017-01-02 22:55:50 --> Database Driver Class Initialized
INFO - 2017-01-02 22:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:55:50 --> Controller Class Initialized
INFO - 2017-01-02 22:55:50 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:55:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:55:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:55:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:55:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:55:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:55:50 --> Final output sent to browser
DEBUG - 2017-01-02 22:55:50 --> Total execution time: 0.0135
INFO - 2017-01-02 22:55:51 --> Config Class Initialized
INFO - 2017-01-02 22:55:51 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:55:51 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:55:51 --> Utf8 Class Initialized
INFO - 2017-01-02 22:55:51 --> URI Class Initialized
INFO - 2017-01-02 22:55:51 --> Router Class Initialized
INFO - 2017-01-02 22:55:51 --> Output Class Initialized
INFO - 2017-01-02 22:55:51 --> Security Class Initialized
DEBUG - 2017-01-02 22:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:55:51 --> Input Class Initialized
INFO - 2017-01-02 22:55:51 --> Language Class Initialized
INFO - 2017-01-02 22:55:51 --> Loader Class Initialized
INFO - 2017-01-02 22:55:51 --> Database Driver Class Initialized
INFO - 2017-01-02 22:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:55:51 --> Controller Class Initialized
INFO - 2017-01-02 22:55:51 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:55:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:55:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:55:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:55:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:55:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:55:51 --> Final output sent to browser
DEBUG - 2017-01-02 22:55:51 --> Total execution time: 0.0136
INFO - 2017-01-02 22:55:54 --> Config Class Initialized
INFO - 2017-01-02 22:55:54 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:55:54 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:55:54 --> Utf8 Class Initialized
INFO - 2017-01-02 22:55:54 --> URI Class Initialized
DEBUG - 2017-01-02 22:55:54 --> No URI present. Default controller set.
INFO - 2017-01-02 22:55:54 --> Router Class Initialized
INFO - 2017-01-02 22:55:54 --> Output Class Initialized
INFO - 2017-01-02 22:55:54 --> Security Class Initialized
DEBUG - 2017-01-02 22:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:55:54 --> Input Class Initialized
INFO - 2017-01-02 22:55:54 --> Language Class Initialized
INFO - 2017-01-02 22:55:54 --> Loader Class Initialized
INFO - 2017-01-02 22:55:54 --> Database Driver Class Initialized
INFO - 2017-01-02 22:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:55:54 --> Controller Class Initialized
INFO - 2017-01-02 22:55:54 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:55:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:55:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:55:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:55:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:55:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:55:54 --> Final output sent to browser
DEBUG - 2017-01-02 22:55:54 --> Total execution time: 0.0141
INFO - 2017-01-02 22:55:54 --> Config Class Initialized
INFO - 2017-01-02 22:55:54 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:55:54 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:55:54 --> Utf8 Class Initialized
INFO - 2017-01-02 22:55:54 --> URI Class Initialized
INFO - 2017-01-02 22:55:54 --> Router Class Initialized
INFO - 2017-01-02 22:55:54 --> Output Class Initialized
INFO - 2017-01-02 22:55:54 --> Security Class Initialized
DEBUG - 2017-01-02 22:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:55:54 --> Input Class Initialized
INFO - 2017-01-02 22:55:54 --> Language Class Initialized
INFO - 2017-01-02 22:55:54 --> Loader Class Initialized
INFO - 2017-01-02 22:55:54 --> Database Driver Class Initialized
INFO - 2017-01-02 22:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:55:54 --> Controller Class Initialized
INFO - 2017-01-02 22:55:54 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:55:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:55:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:55:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:55:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:55:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:55:54 --> Final output sent to browser
DEBUG - 2017-01-02 22:55:54 --> Total execution time: 0.0158
INFO - 2017-01-02 22:58:40 --> Config Class Initialized
INFO - 2017-01-02 22:58:40 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:58:40 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:58:40 --> Utf8 Class Initialized
INFO - 2017-01-02 22:58:40 --> URI Class Initialized
DEBUG - 2017-01-02 22:58:40 --> No URI present. Default controller set.
INFO - 2017-01-02 22:58:40 --> Router Class Initialized
INFO - 2017-01-02 22:58:40 --> Output Class Initialized
INFO - 2017-01-02 22:58:40 --> Security Class Initialized
DEBUG - 2017-01-02 22:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:58:40 --> Input Class Initialized
INFO - 2017-01-02 22:58:40 --> Language Class Initialized
INFO - 2017-01-02 22:58:40 --> Loader Class Initialized
INFO - 2017-01-02 22:58:40 --> Database Driver Class Initialized
INFO - 2017-01-02 22:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:58:40 --> Controller Class Initialized
INFO - 2017-01-02 22:58:40 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:58:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:58:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:58:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:58:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:58:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:58:40 --> Final output sent to browser
DEBUG - 2017-01-02 22:58:40 --> Total execution time: 0.0132
INFO - 2017-01-02 22:58:41 --> Config Class Initialized
INFO - 2017-01-02 22:58:41 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:58:41 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:58:41 --> Utf8 Class Initialized
INFO - 2017-01-02 22:58:41 --> URI Class Initialized
INFO - 2017-01-02 22:58:41 --> Router Class Initialized
INFO - 2017-01-02 22:58:41 --> Output Class Initialized
INFO - 2017-01-02 22:58:41 --> Security Class Initialized
DEBUG - 2017-01-02 22:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:58:41 --> Input Class Initialized
INFO - 2017-01-02 22:58:41 --> Language Class Initialized
INFO - 2017-01-02 22:58:41 --> Loader Class Initialized
INFO - 2017-01-02 22:58:41 --> Database Driver Class Initialized
INFO - 2017-01-02 22:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:58:41 --> Controller Class Initialized
INFO - 2017-01-02 22:58:41 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:58:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:58:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:58:41 --> Final output sent to browser
DEBUG - 2017-01-02 22:58:41 --> Total execution time: 0.0150
INFO - 2017-01-02 22:58:43 --> Config Class Initialized
INFO - 2017-01-02 22:58:43 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:58:43 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:58:43 --> Utf8 Class Initialized
INFO - 2017-01-02 22:58:43 --> URI Class Initialized
DEBUG - 2017-01-02 22:58:43 --> No URI present. Default controller set.
INFO - 2017-01-02 22:58:43 --> Router Class Initialized
INFO - 2017-01-02 22:58:43 --> Output Class Initialized
INFO - 2017-01-02 22:58:43 --> Security Class Initialized
DEBUG - 2017-01-02 22:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:58:43 --> Input Class Initialized
INFO - 2017-01-02 22:58:43 --> Language Class Initialized
INFO - 2017-01-02 22:58:43 --> Loader Class Initialized
INFO - 2017-01-02 22:58:43 --> Database Driver Class Initialized
INFO - 2017-01-02 22:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:58:43 --> Controller Class Initialized
INFO - 2017-01-02 22:58:43 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:58:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:58:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:58:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:58:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:58:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:58:43 --> Final output sent to browser
DEBUG - 2017-01-02 22:58:43 --> Total execution time: 0.0654
INFO - 2017-01-02 22:58:44 --> Config Class Initialized
INFO - 2017-01-02 22:58:44 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:58:44 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:58:44 --> Utf8 Class Initialized
INFO - 2017-01-02 22:58:44 --> URI Class Initialized
INFO - 2017-01-02 22:58:44 --> Router Class Initialized
INFO - 2017-01-02 22:58:44 --> Output Class Initialized
INFO - 2017-01-02 22:58:44 --> Security Class Initialized
DEBUG - 2017-01-02 22:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:58:44 --> Input Class Initialized
INFO - 2017-01-02 22:58:44 --> Language Class Initialized
INFO - 2017-01-02 22:58:44 --> Loader Class Initialized
INFO - 2017-01-02 22:58:44 --> Database Driver Class Initialized
INFO - 2017-01-02 22:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:58:44 --> Controller Class Initialized
INFO - 2017-01-02 22:58:44 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:58:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:58:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:58:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:58:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:58:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:58:44 --> Final output sent to browser
DEBUG - 2017-01-02 22:58:44 --> Total execution time: 0.0135
INFO - 2017-01-02 22:58:51 --> Config Class Initialized
INFO - 2017-01-02 22:58:51 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:58:51 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:58:51 --> Utf8 Class Initialized
INFO - 2017-01-02 22:58:51 --> URI Class Initialized
DEBUG - 2017-01-02 22:58:51 --> No URI present. Default controller set.
INFO - 2017-01-02 22:58:51 --> Router Class Initialized
INFO - 2017-01-02 22:58:51 --> Output Class Initialized
INFO - 2017-01-02 22:58:51 --> Security Class Initialized
DEBUG - 2017-01-02 22:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:58:51 --> Input Class Initialized
INFO - 2017-01-02 22:58:51 --> Language Class Initialized
INFO - 2017-01-02 22:58:51 --> Loader Class Initialized
INFO - 2017-01-02 22:58:51 --> Database Driver Class Initialized
INFO - 2017-01-02 22:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:58:51 --> Controller Class Initialized
INFO - 2017-01-02 22:58:51 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:58:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:58:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:58:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:58:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:58:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:58:51 --> Final output sent to browser
DEBUG - 2017-01-02 22:58:51 --> Total execution time: 0.0134
INFO - 2017-01-02 22:58:58 --> Config Class Initialized
INFO - 2017-01-02 22:58:58 --> Hooks Class Initialized
DEBUG - 2017-01-02 22:58:58 --> UTF-8 Support Enabled
INFO - 2017-01-02 22:58:58 --> Utf8 Class Initialized
INFO - 2017-01-02 22:58:58 --> URI Class Initialized
INFO - 2017-01-02 22:58:58 --> Router Class Initialized
INFO - 2017-01-02 22:58:58 --> Output Class Initialized
INFO - 2017-01-02 22:58:58 --> Security Class Initialized
DEBUG - 2017-01-02 22:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 22:58:58 --> Input Class Initialized
INFO - 2017-01-02 22:58:58 --> Language Class Initialized
INFO - 2017-01-02 22:58:58 --> Loader Class Initialized
INFO - 2017-01-02 22:58:58 --> Database Driver Class Initialized
INFO - 2017-01-02 22:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 22:58:58 --> Controller Class Initialized
INFO - 2017-01-02 22:58:58 --> Helper loaded: url_helper
DEBUG - 2017-01-02 22:58:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 22:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 22:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 22:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 22:58:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 22:58:58 --> Final output sent to browser
DEBUG - 2017-01-02 22:58:58 --> Total execution time: 0.0138
INFO - 2017-01-02 23:04:21 --> Config Class Initialized
INFO - 2017-01-02 23:04:21 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:04:21 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:04:21 --> Utf8 Class Initialized
INFO - 2017-01-02 23:04:21 --> URI Class Initialized
DEBUG - 2017-01-02 23:04:21 --> No URI present. Default controller set.
INFO - 2017-01-02 23:04:21 --> Router Class Initialized
INFO - 2017-01-02 23:04:21 --> Output Class Initialized
INFO - 2017-01-02 23:04:21 --> Security Class Initialized
DEBUG - 2017-01-02 23:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:04:21 --> Input Class Initialized
INFO - 2017-01-02 23:04:21 --> Language Class Initialized
INFO - 2017-01-02 23:04:21 --> Loader Class Initialized
INFO - 2017-01-02 23:04:21 --> Database Driver Class Initialized
INFO - 2017-01-02 23:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:04:21 --> Controller Class Initialized
INFO - 2017-01-02 23:04:21 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:04:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:04:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 23:04:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 23:04:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 23:04:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 23:04:21 --> Final output sent to browser
DEBUG - 2017-01-02 23:04:21 --> Total execution time: 0.0726
INFO - 2017-01-02 23:04:21 --> Config Class Initialized
INFO - 2017-01-02 23:04:21 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:04:21 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:04:21 --> Utf8 Class Initialized
INFO - 2017-01-02 23:04:21 --> URI Class Initialized
INFO - 2017-01-02 23:04:21 --> Router Class Initialized
INFO - 2017-01-02 23:04:21 --> Output Class Initialized
INFO - 2017-01-02 23:04:21 --> Security Class Initialized
DEBUG - 2017-01-02 23:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:04:21 --> Input Class Initialized
INFO - 2017-01-02 23:04:21 --> Language Class Initialized
INFO - 2017-01-02 23:04:21 --> Loader Class Initialized
INFO - 2017-01-02 23:04:21 --> Database Driver Class Initialized
INFO - 2017-01-02 23:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:04:21 --> Controller Class Initialized
INFO - 2017-01-02 23:04:21 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:04:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:04:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 23:04:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 23:04:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 23:04:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 23:04:21 --> Final output sent to browser
DEBUG - 2017-01-02 23:04:21 --> Total execution time: 0.0140
INFO - 2017-01-02 23:04:42 --> Config Class Initialized
INFO - 2017-01-02 23:04:42 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:04:42 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:04:42 --> Utf8 Class Initialized
INFO - 2017-01-02 23:04:42 --> URI Class Initialized
DEBUG - 2017-01-02 23:04:42 --> No URI present. Default controller set.
INFO - 2017-01-02 23:04:42 --> Router Class Initialized
INFO - 2017-01-02 23:04:42 --> Output Class Initialized
INFO - 2017-01-02 23:04:42 --> Security Class Initialized
DEBUG - 2017-01-02 23:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:04:42 --> Input Class Initialized
INFO - 2017-01-02 23:04:42 --> Language Class Initialized
INFO - 2017-01-02 23:04:42 --> Loader Class Initialized
INFO - 2017-01-02 23:04:42 --> Database Driver Class Initialized
INFO - 2017-01-02 23:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:04:42 --> Controller Class Initialized
INFO - 2017-01-02 23:04:42 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:04:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:04:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 23:04:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 23:04:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 23:04:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 23:04:42 --> Final output sent to browser
DEBUG - 2017-01-02 23:04:42 --> Total execution time: 0.2350
INFO - 2017-01-02 23:04:43 --> Config Class Initialized
INFO - 2017-01-02 23:04:43 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:04:43 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:04:43 --> Utf8 Class Initialized
INFO - 2017-01-02 23:04:43 --> URI Class Initialized
INFO - 2017-01-02 23:04:43 --> Router Class Initialized
INFO - 2017-01-02 23:04:43 --> Output Class Initialized
INFO - 2017-01-02 23:04:43 --> Security Class Initialized
DEBUG - 2017-01-02 23:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:04:43 --> Input Class Initialized
INFO - 2017-01-02 23:04:43 --> Language Class Initialized
INFO - 2017-01-02 23:04:43 --> Loader Class Initialized
INFO - 2017-01-02 23:04:43 --> Database Driver Class Initialized
INFO - 2017-01-02 23:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:04:43 --> Controller Class Initialized
INFO - 2017-01-02 23:04:43 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:04:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:04:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 23:04:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 23:04:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 23:04:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 23:04:43 --> Final output sent to browser
DEBUG - 2017-01-02 23:04:43 --> Total execution time: 0.0138
INFO - 2017-01-02 23:04:53 --> Config Class Initialized
INFO - 2017-01-02 23:04:53 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:04:53 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:04:53 --> Utf8 Class Initialized
INFO - 2017-01-02 23:04:53 --> URI Class Initialized
DEBUG - 2017-01-02 23:04:53 --> No URI present. Default controller set.
INFO - 2017-01-02 23:04:53 --> Router Class Initialized
INFO - 2017-01-02 23:04:53 --> Output Class Initialized
INFO - 2017-01-02 23:04:53 --> Security Class Initialized
DEBUG - 2017-01-02 23:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:04:53 --> Input Class Initialized
INFO - 2017-01-02 23:04:53 --> Language Class Initialized
INFO - 2017-01-02 23:04:53 --> Loader Class Initialized
INFO - 2017-01-02 23:04:53 --> Database Driver Class Initialized
INFO - 2017-01-02 23:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:04:53 --> Controller Class Initialized
INFO - 2017-01-02 23:04:53 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:04:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:04:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 23:04:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 23:04:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 23:04:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 23:04:53 --> Final output sent to browser
DEBUG - 2017-01-02 23:04:53 --> Total execution time: 0.0297
INFO - 2017-01-02 23:05:00 --> Config Class Initialized
INFO - 2017-01-02 23:05:00 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:05:00 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:05:00 --> Utf8 Class Initialized
INFO - 2017-01-02 23:05:00 --> URI Class Initialized
INFO - 2017-01-02 23:05:00 --> Router Class Initialized
INFO - 2017-01-02 23:05:00 --> Output Class Initialized
INFO - 2017-01-02 23:05:00 --> Security Class Initialized
DEBUG - 2017-01-02 23:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:05:00 --> Input Class Initialized
INFO - 2017-01-02 23:05:00 --> Language Class Initialized
INFO - 2017-01-02 23:05:00 --> Loader Class Initialized
INFO - 2017-01-02 23:05:00 --> Database Driver Class Initialized
INFO - 2017-01-02 23:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:05:00 --> Controller Class Initialized
INFO - 2017-01-02 23:05:00 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:05:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:05:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 23:05:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 23:05:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 23:05:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 23:05:00 --> Final output sent to browser
DEBUG - 2017-01-02 23:05:00 --> Total execution time: 0.0138
INFO - 2017-01-02 23:11:03 --> Config Class Initialized
INFO - 2017-01-02 23:11:03 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:11:03 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:11:03 --> Utf8 Class Initialized
INFO - 2017-01-02 23:11:03 --> URI Class Initialized
DEBUG - 2017-01-02 23:11:03 --> No URI present. Default controller set.
INFO - 2017-01-02 23:11:03 --> Router Class Initialized
INFO - 2017-01-02 23:11:03 --> Output Class Initialized
INFO - 2017-01-02 23:11:03 --> Security Class Initialized
DEBUG - 2017-01-02 23:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:11:03 --> Input Class Initialized
INFO - 2017-01-02 23:11:03 --> Language Class Initialized
INFO - 2017-01-02 23:11:03 --> Loader Class Initialized
INFO - 2017-01-02 23:11:03 --> Database Driver Class Initialized
INFO - 2017-01-02 23:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:11:03 --> Controller Class Initialized
INFO - 2017-01-02 23:11:03 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:11:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:11:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 23:11:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 23:11:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 23:11:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 23:11:03 --> Final output sent to browser
DEBUG - 2017-01-02 23:11:03 --> Total execution time: 0.0457
INFO - 2017-01-02 23:11:18 --> Config Class Initialized
INFO - 2017-01-02 23:11:18 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:11:18 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:11:18 --> Utf8 Class Initialized
INFO - 2017-01-02 23:11:18 --> URI Class Initialized
DEBUG - 2017-01-02 23:11:18 --> No URI present. Default controller set.
INFO - 2017-01-02 23:11:18 --> Router Class Initialized
INFO - 2017-01-02 23:11:18 --> Output Class Initialized
INFO - 2017-01-02 23:11:18 --> Security Class Initialized
DEBUG - 2017-01-02 23:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:11:18 --> Input Class Initialized
INFO - 2017-01-02 23:11:18 --> Language Class Initialized
INFO - 2017-01-02 23:11:18 --> Loader Class Initialized
INFO - 2017-01-02 23:11:18 --> Database Driver Class Initialized
INFO - 2017-01-02 23:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:11:18 --> Controller Class Initialized
INFO - 2017-01-02 23:11:18 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:11:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 23:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 23:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 23:11:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 23:11:18 --> Final output sent to browser
DEBUG - 2017-01-02 23:11:18 --> Total execution time: 0.0735
INFO - 2017-01-02 23:11:20 --> Config Class Initialized
INFO - 2017-01-02 23:11:20 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:11:20 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:11:20 --> Utf8 Class Initialized
INFO - 2017-01-02 23:11:20 --> URI Class Initialized
DEBUG - 2017-01-02 23:11:20 --> No URI present. Default controller set.
INFO - 2017-01-02 23:11:20 --> Router Class Initialized
INFO - 2017-01-02 23:11:20 --> Output Class Initialized
INFO - 2017-01-02 23:11:20 --> Security Class Initialized
DEBUG - 2017-01-02 23:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:11:20 --> Input Class Initialized
INFO - 2017-01-02 23:11:20 --> Language Class Initialized
INFO - 2017-01-02 23:11:20 --> Loader Class Initialized
INFO - 2017-01-02 23:11:20 --> Database Driver Class Initialized
INFO - 2017-01-02 23:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:11:20 --> Controller Class Initialized
INFO - 2017-01-02 23:11:20 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 23:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 23:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 23:11:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 23:11:20 --> Final output sent to browser
DEBUG - 2017-01-02 23:11:20 --> Total execution time: 0.0130
INFO - 2017-01-02 23:14:30 --> Config Class Initialized
INFO - 2017-01-02 23:14:30 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:14:30 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:14:30 --> Utf8 Class Initialized
INFO - 2017-01-02 23:14:30 --> URI Class Initialized
DEBUG - 2017-01-02 23:14:30 --> No URI present. Default controller set.
INFO - 2017-01-02 23:14:30 --> Router Class Initialized
INFO - 2017-01-02 23:14:30 --> Output Class Initialized
INFO - 2017-01-02 23:14:30 --> Security Class Initialized
DEBUG - 2017-01-02 23:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:14:30 --> Input Class Initialized
INFO - 2017-01-02 23:14:30 --> Language Class Initialized
INFO - 2017-01-02 23:14:30 --> Loader Class Initialized
INFO - 2017-01-02 23:14:30 --> Database Driver Class Initialized
INFO - 2017-01-02 23:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:14:30 --> Controller Class Initialized
INFO - 2017-01-02 23:14:30 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:14:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:14:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 23:14:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 23:14:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 23:14:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 23:14:30 --> Final output sent to browser
DEBUG - 2017-01-02 23:14:30 --> Total execution time: 0.0135
INFO - 2017-01-02 23:14:49 --> Config Class Initialized
INFO - 2017-01-02 23:14:49 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:14:49 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:14:49 --> Utf8 Class Initialized
INFO - 2017-01-02 23:14:49 --> URI Class Initialized
DEBUG - 2017-01-02 23:14:49 --> No URI present. Default controller set.
INFO - 2017-01-02 23:14:49 --> Router Class Initialized
INFO - 2017-01-02 23:14:49 --> Output Class Initialized
INFO - 2017-01-02 23:14:49 --> Security Class Initialized
DEBUG - 2017-01-02 23:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:14:49 --> Input Class Initialized
INFO - 2017-01-02 23:14:49 --> Language Class Initialized
INFO - 2017-01-02 23:14:49 --> Loader Class Initialized
INFO - 2017-01-02 23:14:49 --> Database Driver Class Initialized
INFO - 2017-01-02 23:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:14:49 --> Controller Class Initialized
INFO - 2017-01-02 23:14:49 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:14:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:14:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 23:14:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 23:14:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 23:14:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 23:14:49 --> Final output sent to browser
DEBUG - 2017-01-02 23:14:49 --> Total execution time: 0.0131
INFO - 2017-01-02 23:14:50 --> Config Class Initialized
INFO - 2017-01-02 23:14:50 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:14:50 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:14:50 --> Utf8 Class Initialized
INFO - 2017-01-02 23:14:50 --> URI Class Initialized
INFO - 2017-01-02 23:14:50 --> Router Class Initialized
INFO - 2017-01-02 23:14:50 --> Output Class Initialized
INFO - 2017-01-02 23:14:50 --> Security Class Initialized
DEBUG - 2017-01-02 23:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:14:50 --> Input Class Initialized
INFO - 2017-01-02 23:14:50 --> Language Class Initialized
INFO - 2017-01-02 23:14:50 --> Loader Class Initialized
INFO - 2017-01-02 23:14:50 --> Database Driver Class Initialized
INFO - 2017-01-02 23:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:14:50 --> Controller Class Initialized
INFO - 2017-01-02 23:14:50 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:14:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:14:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 23:14:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 23:14:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 23:14:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 23:14:50 --> Final output sent to browser
DEBUG - 2017-01-02 23:14:50 --> Total execution time: 0.0134
INFO - 2017-01-02 23:36:07 --> Config Class Initialized
INFO - 2017-01-02 23:36:07 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:36:07 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:36:07 --> Utf8 Class Initialized
INFO - 2017-01-02 23:36:07 --> URI Class Initialized
DEBUG - 2017-01-02 23:36:07 --> No URI present. Default controller set.
INFO - 2017-01-02 23:36:07 --> Router Class Initialized
INFO - 2017-01-02 23:36:07 --> Output Class Initialized
INFO - 2017-01-02 23:36:07 --> Security Class Initialized
DEBUG - 2017-01-02 23:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:36:07 --> Input Class Initialized
INFO - 2017-01-02 23:36:07 --> Language Class Initialized
INFO - 2017-01-02 23:36:07 --> Loader Class Initialized
INFO - 2017-01-02 23:36:07 --> Database Driver Class Initialized
INFO - 2017-01-02 23:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:36:07 --> Controller Class Initialized
INFO - 2017-01-02 23:36:07 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:36:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:36:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 23:36:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 23:36:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 23:36:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 23:36:08 --> Final output sent to browser
DEBUG - 2017-01-02 23:36:08 --> Total execution time: 0.5526
INFO - 2017-01-02 23:40:25 --> Config Class Initialized
INFO - 2017-01-02 23:40:25 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:40:25 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:40:25 --> Utf8 Class Initialized
INFO - 2017-01-02 23:40:25 --> URI Class Initialized
DEBUG - 2017-01-02 23:40:25 --> No URI present. Default controller set.
INFO - 2017-01-02 23:40:25 --> Router Class Initialized
INFO - 2017-01-02 23:40:25 --> Output Class Initialized
INFO - 2017-01-02 23:40:25 --> Security Class Initialized
DEBUG - 2017-01-02 23:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:40:25 --> Input Class Initialized
INFO - 2017-01-02 23:40:25 --> Language Class Initialized
INFO - 2017-01-02 23:40:25 --> Loader Class Initialized
INFO - 2017-01-02 23:40:25 --> Database Driver Class Initialized
INFO - 2017-01-02 23:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:40:25 --> Controller Class Initialized
INFO - 2017-01-02 23:40:25 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:40:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:40:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 23:40:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 23:40:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 23:40:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 23:40:25 --> Final output sent to browser
DEBUG - 2017-01-02 23:40:25 --> Total execution time: 0.0302
INFO - 2017-01-02 23:40:39 --> Config Class Initialized
INFO - 2017-01-02 23:40:39 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:40:39 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:40:39 --> Utf8 Class Initialized
INFO - 2017-01-02 23:40:39 --> URI Class Initialized
DEBUG - 2017-01-02 23:40:39 --> No URI present. Default controller set.
INFO - 2017-01-02 23:40:39 --> Router Class Initialized
INFO - 2017-01-02 23:40:39 --> Output Class Initialized
INFO - 2017-01-02 23:40:39 --> Security Class Initialized
DEBUG - 2017-01-02 23:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:40:39 --> Input Class Initialized
INFO - 2017-01-02 23:40:39 --> Language Class Initialized
INFO - 2017-01-02 23:40:39 --> Loader Class Initialized
INFO - 2017-01-02 23:40:39 --> Database Driver Class Initialized
INFO - 2017-01-02 23:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:40:39 --> Controller Class Initialized
INFO - 2017-01-02 23:40:39 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:40:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:40:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 23:40:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 23:40:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 23:40:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 23:40:39 --> Final output sent to browser
DEBUG - 2017-01-02 23:40:39 --> Total execution time: 0.0139
INFO - 2017-01-02 23:40:45 --> Config Class Initialized
INFO - 2017-01-02 23:40:45 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:40:45 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:40:45 --> Utf8 Class Initialized
INFO - 2017-01-02 23:40:45 --> URI Class Initialized
DEBUG - 2017-01-02 23:40:45 --> No URI present. Default controller set.
INFO - 2017-01-02 23:40:45 --> Router Class Initialized
INFO - 2017-01-02 23:40:45 --> Output Class Initialized
INFO - 2017-01-02 23:40:45 --> Security Class Initialized
DEBUG - 2017-01-02 23:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:40:45 --> Input Class Initialized
INFO - 2017-01-02 23:40:45 --> Language Class Initialized
INFO - 2017-01-02 23:40:45 --> Loader Class Initialized
INFO - 2017-01-02 23:40:45 --> Database Driver Class Initialized
INFO - 2017-01-02 23:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:40:45 --> Controller Class Initialized
INFO - 2017-01-02 23:40:45 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:40:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 23:40:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 23:40:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 23:40:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 23:40:45 --> Final output sent to browser
DEBUG - 2017-01-02 23:40:45 --> Total execution time: 0.0477
INFO - 2017-01-02 23:40:46 --> Config Class Initialized
INFO - 2017-01-02 23:40:46 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:40:46 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:40:46 --> Utf8 Class Initialized
INFO - 2017-01-02 23:40:46 --> URI Class Initialized
INFO - 2017-01-02 23:40:46 --> Router Class Initialized
INFO - 2017-01-02 23:40:46 --> Output Class Initialized
INFO - 2017-01-02 23:40:46 --> Security Class Initialized
DEBUG - 2017-01-02 23:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:40:46 --> Input Class Initialized
INFO - 2017-01-02 23:40:46 --> Language Class Initialized
INFO - 2017-01-02 23:40:46 --> Loader Class Initialized
INFO - 2017-01-02 23:40:46 --> Database Driver Class Initialized
INFO - 2017-01-02 23:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:40:46 --> Controller Class Initialized
INFO - 2017-01-02 23:40:46 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:40:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:40:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 23:40:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 23:40:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 23:40:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 23:40:46 --> Final output sent to browser
DEBUG - 2017-01-02 23:40:46 --> Total execution time: 0.0519
INFO - 2017-01-02 23:41:07 --> Config Class Initialized
INFO - 2017-01-02 23:41:07 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:41:07 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:41:07 --> Utf8 Class Initialized
INFO - 2017-01-02 23:41:07 --> URI Class Initialized
DEBUG - 2017-01-02 23:41:07 --> No URI present. Default controller set.
INFO - 2017-01-02 23:41:07 --> Router Class Initialized
INFO - 2017-01-02 23:41:07 --> Output Class Initialized
INFO - 2017-01-02 23:41:07 --> Security Class Initialized
DEBUG - 2017-01-02 23:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:41:07 --> Input Class Initialized
INFO - 2017-01-02 23:41:07 --> Language Class Initialized
INFO - 2017-01-02 23:41:07 --> Loader Class Initialized
INFO - 2017-01-02 23:41:07 --> Database Driver Class Initialized
INFO - 2017-01-02 23:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:41:07 --> Controller Class Initialized
INFO - 2017-01-02 23:41:07 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 23:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 23:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 23:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 23:41:07 --> Final output sent to browser
DEBUG - 2017-01-02 23:41:07 --> Total execution time: 0.1834
INFO - 2017-01-02 23:41:07 --> Config Class Initialized
INFO - 2017-01-02 23:41:07 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:41:07 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:41:07 --> Utf8 Class Initialized
INFO - 2017-01-02 23:41:07 --> URI Class Initialized
INFO - 2017-01-02 23:41:07 --> Router Class Initialized
INFO - 2017-01-02 23:41:07 --> Output Class Initialized
INFO - 2017-01-02 23:41:07 --> Security Class Initialized
DEBUG - 2017-01-02 23:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:41:07 --> Input Class Initialized
INFO - 2017-01-02 23:41:07 --> Language Class Initialized
INFO - 2017-01-02 23:41:07 --> Loader Class Initialized
INFO - 2017-01-02 23:41:07 --> Database Driver Class Initialized
INFO - 2017-01-02 23:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:41:07 --> Controller Class Initialized
INFO - 2017-01-02 23:41:07 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 23:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 23:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 23:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 23:41:07 --> Final output sent to browser
DEBUG - 2017-01-02 23:41:07 --> Total execution time: 0.0154
INFO - 2017-01-02 23:43:28 --> Config Class Initialized
INFO - 2017-01-02 23:43:28 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:43:28 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:43:28 --> Utf8 Class Initialized
INFO - 2017-01-02 23:43:28 --> URI Class Initialized
DEBUG - 2017-01-02 23:43:28 --> No URI present. Default controller set.
INFO - 2017-01-02 23:43:28 --> Router Class Initialized
INFO - 2017-01-02 23:43:28 --> Output Class Initialized
INFO - 2017-01-02 23:43:28 --> Security Class Initialized
DEBUG - 2017-01-02 23:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:43:28 --> Input Class Initialized
INFO - 2017-01-02 23:43:28 --> Language Class Initialized
INFO - 2017-01-02 23:43:28 --> Loader Class Initialized
INFO - 2017-01-02 23:43:28 --> Database Driver Class Initialized
INFO - 2017-01-02 23:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:43:28 --> Controller Class Initialized
INFO - 2017-01-02 23:43:28 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:43:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-02 23:43:28 --> Severity: Parsing Error --> syntax error, unexpected '<' /home/graduafe/public_html/application/views/usuario/pages/principal.php 2
INFO - 2017-01-02 23:43:28 --> Config Class Initialized
INFO - 2017-01-02 23:43:28 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:43:28 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:43:28 --> Utf8 Class Initialized
INFO - 2017-01-02 23:43:28 --> URI Class Initialized
INFO - 2017-01-02 23:43:28 --> Router Class Initialized
INFO - 2017-01-02 23:43:28 --> Output Class Initialized
INFO - 2017-01-02 23:43:28 --> Security Class Initialized
DEBUG - 2017-01-02 23:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:43:28 --> Input Class Initialized
INFO - 2017-01-02 23:43:28 --> Language Class Initialized
INFO - 2017-01-02 23:43:28 --> Loader Class Initialized
INFO - 2017-01-02 23:43:28 --> Database Driver Class Initialized
INFO - 2017-01-02 23:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:43:28 --> Controller Class Initialized
INFO - 2017-01-02 23:43:28 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:43:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-02 23:43:28 --> Severity: Parsing Error --> syntax error, unexpected '<' /home/graduafe/public_html/application/views/usuario/pages/principal.php 2
INFO - 2017-01-02 23:43:28 --> Config Class Initialized
INFO - 2017-01-02 23:43:28 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:43:28 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:43:28 --> Utf8 Class Initialized
INFO - 2017-01-02 23:43:28 --> URI Class Initialized
INFO - 2017-01-02 23:43:28 --> Router Class Initialized
INFO - 2017-01-02 23:43:28 --> Output Class Initialized
INFO - 2017-01-02 23:43:28 --> Security Class Initialized
DEBUG - 2017-01-02 23:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:43:28 --> Input Class Initialized
INFO - 2017-01-02 23:43:28 --> Language Class Initialized
INFO - 2017-01-02 23:43:28 --> Loader Class Initialized
INFO - 2017-01-02 23:43:28 --> Database Driver Class Initialized
INFO - 2017-01-02 23:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:43:28 --> Controller Class Initialized
INFO - 2017-01-02 23:43:28 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:43:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-02 23:43:28 --> Severity: Parsing Error --> syntax error, unexpected '<' /home/graduafe/public_html/application/views/usuario/pages/principal.php 2
INFO - 2017-01-02 23:45:12 --> Config Class Initialized
INFO - 2017-01-02 23:45:12 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:45:12 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:45:12 --> Utf8 Class Initialized
INFO - 2017-01-02 23:45:12 --> URI Class Initialized
DEBUG - 2017-01-02 23:45:12 --> No URI present. Default controller set.
INFO - 2017-01-02 23:45:12 --> Router Class Initialized
INFO - 2017-01-02 23:45:12 --> Output Class Initialized
INFO - 2017-01-02 23:45:12 --> Security Class Initialized
DEBUG - 2017-01-02 23:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:45:12 --> Input Class Initialized
INFO - 2017-01-02 23:45:12 --> Language Class Initialized
INFO - 2017-01-02 23:45:12 --> Loader Class Initialized
INFO - 2017-01-02 23:45:12 --> Database Driver Class Initialized
INFO - 2017-01-02 23:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:45:12 --> Controller Class Initialized
INFO - 2017-01-02 23:45:12 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:45:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:45:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-02 23:45:12 --> Severity: Parsing Error --> syntax error, unexpected '<' /home/graduafe/public_html/application/views/usuario/pages/principal.php 2
INFO - 2017-01-02 23:45:12 --> Config Class Initialized
INFO - 2017-01-02 23:45:12 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:45:12 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:45:12 --> Utf8 Class Initialized
INFO - 2017-01-02 23:45:12 --> URI Class Initialized
INFO - 2017-01-02 23:45:12 --> Router Class Initialized
INFO - 2017-01-02 23:45:12 --> Output Class Initialized
INFO - 2017-01-02 23:45:12 --> Security Class Initialized
DEBUG - 2017-01-02 23:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:45:12 --> Input Class Initialized
INFO - 2017-01-02 23:45:12 --> Language Class Initialized
INFO - 2017-01-02 23:45:12 --> Loader Class Initialized
INFO - 2017-01-02 23:45:12 --> Database Driver Class Initialized
INFO - 2017-01-02 23:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:45:12 --> Controller Class Initialized
INFO - 2017-01-02 23:45:12 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:45:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:45:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-02 23:45:12 --> Severity: Parsing Error --> syntax error, unexpected '<' /home/graduafe/public_html/application/views/usuario/pages/principal.php 2
INFO - 2017-01-02 23:45:19 --> Config Class Initialized
INFO - 2017-01-02 23:45:19 --> Hooks Class Initialized
DEBUG - 2017-01-02 23:45:19 --> UTF-8 Support Enabled
INFO - 2017-01-02 23:45:19 --> Utf8 Class Initialized
INFO - 2017-01-02 23:45:19 --> URI Class Initialized
DEBUG - 2017-01-02 23:45:19 --> No URI present. Default controller set.
INFO - 2017-01-02 23:45:19 --> Router Class Initialized
INFO - 2017-01-02 23:45:19 --> Output Class Initialized
INFO - 2017-01-02 23:45:19 --> Security Class Initialized
DEBUG - 2017-01-02 23:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-02 23:45:19 --> Input Class Initialized
INFO - 2017-01-02 23:45:19 --> Language Class Initialized
INFO - 2017-01-02 23:45:19 --> Loader Class Initialized
INFO - 2017-01-02 23:45:19 --> Database Driver Class Initialized
INFO - 2017-01-02 23:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-02 23:45:19 --> Controller Class Initialized
INFO - 2017-01-02 23:45:19 --> Helper loaded: url_helper
DEBUG - 2017-01-02 23:45:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-02 23:45:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-02 23:45:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-02 23:45:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-02 23:45:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-02 23:45:19 --> Final output sent to browser
DEBUG - 2017-01-02 23:45:19 --> Total execution time: 0.0131

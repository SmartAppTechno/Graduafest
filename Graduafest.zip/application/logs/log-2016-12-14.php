<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-14 16:12:23 --> Config Class Initialized
INFO - 2016-12-14 16:12:23 --> Hooks Class Initialized
DEBUG - 2016-12-14 16:12:23 --> UTF-8 Support Enabled
INFO - 2016-12-14 16:12:23 --> Utf8 Class Initialized
INFO - 2016-12-14 16:12:23 --> URI Class Initialized
DEBUG - 2016-12-14 16:12:23 --> No URI present. Default controller set.
INFO - 2016-12-14 16:12:23 --> Router Class Initialized
INFO - 2016-12-14 16:12:23 --> Output Class Initialized
INFO - 2016-12-14 16:12:23 --> Security Class Initialized
DEBUG - 2016-12-14 16:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-14 16:12:23 --> Input Class Initialized
INFO - 2016-12-14 16:12:23 --> Language Class Initialized
INFO - 2016-12-14 16:12:23 --> Loader Class Initialized
INFO - 2016-12-14 16:12:24 --> Database Driver Class Initialized
INFO - 2016-12-14 16:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-14 16:12:24 --> Controller Class Initialized
INFO - 2016-12-14 16:12:24 --> Helper loaded: url_helper
DEBUG - 2016-12-14 16:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-14 16:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-14 16:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-14 16:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-14 16:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-14 16:12:24 --> Final output sent to browser
DEBUG - 2016-12-14 16:12:24 --> Total execution time: 1.8092
INFO - 2016-12-14 20:16:17 --> Config Class Initialized
INFO - 2016-12-14 20:16:17 --> Hooks Class Initialized
DEBUG - 2016-12-14 20:16:17 --> UTF-8 Support Enabled
INFO - 2016-12-14 20:16:17 --> Utf8 Class Initialized
INFO - 2016-12-14 20:16:17 --> URI Class Initialized
DEBUG - 2016-12-14 20:16:17 --> No URI present. Default controller set.
INFO - 2016-12-14 20:16:18 --> Router Class Initialized
INFO - 2016-12-14 20:16:18 --> Output Class Initialized
INFO - 2016-12-14 20:16:18 --> Security Class Initialized
DEBUG - 2016-12-14 20:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-14 20:16:18 --> Input Class Initialized
INFO - 2016-12-14 20:16:18 --> Language Class Initialized
INFO - 2016-12-14 20:16:18 --> Loader Class Initialized
INFO - 2016-12-14 20:16:18 --> Database Driver Class Initialized
INFO - 2016-12-14 20:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-14 20:16:18 --> Controller Class Initialized
INFO - 2016-12-14 20:16:18 --> Helper loaded: url_helper
DEBUG - 2016-12-14 20:16:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-14 20:16:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-14 20:16:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-14 20:16:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-14 20:16:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-14 20:16:18 --> Final output sent to browser
DEBUG - 2016-12-14 20:16:18 --> Total execution time: 0.4888
INFO - 2016-12-14 20:16:23 --> Config Class Initialized
INFO - 2016-12-14 20:16:23 --> Hooks Class Initialized
DEBUG - 2016-12-14 20:16:23 --> UTF-8 Support Enabled
INFO - 2016-12-14 20:16:23 --> Utf8 Class Initialized
INFO - 2016-12-14 20:16:23 --> URI Class Initialized
INFO - 2016-12-14 20:16:23 --> Router Class Initialized
INFO - 2016-12-14 20:16:23 --> Output Class Initialized
INFO - 2016-12-14 20:16:23 --> Security Class Initialized
DEBUG - 2016-12-14 20:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-14 20:16:23 --> Input Class Initialized
INFO - 2016-12-14 20:16:23 --> Language Class Initialized
INFO - 2016-12-14 20:16:23 --> Loader Class Initialized
INFO - 2016-12-14 20:16:23 --> Database Driver Class Initialized
INFO - 2016-12-14 20:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-14 20:16:23 --> Controller Class Initialized
INFO - 2016-12-14 20:16:23 --> Helper loaded: url_helper
DEBUG - 2016-12-14 20:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-14 20:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-14 20:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-14 20:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-14 20:16:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-14 20:16:23 --> Final output sent to browser
DEBUG - 2016-12-14 20:16:23 --> Total execution time: 0.0137
INFO - 2016-12-14 20:16:50 --> Config Class Initialized
INFO - 2016-12-14 20:16:50 --> Hooks Class Initialized
DEBUG - 2016-12-14 20:16:50 --> UTF-8 Support Enabled
INFO - 2016-12-14 20:16:50 --> Utf8 Class Initialized
INFO - 2016-12-14 20:16:50 --> URI Class Initialized
INFO - 2016-12-14 20:16:50 --> Router Class Initialized
INFO - 2016-12-14 20:16:50 --> Output Class Initialized
INFO - 2016-12-14 20:16:50 --> Security Class Initialized
DEBUG - 2016-12-14 20:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-14 20:16:50 --> Input Class Initialized
INFO - 2016-12-14 20:16:50 --> Language Class Initialized
INFO - 2016-12-14 20:16:50 --> Loader Class Initialized
INFO - 2016-12-14 20:16:50 --> Database Driver Class Initialized
INFO - 2016-12-14 20:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-14 20:16:50 --> Controller Class Initialized
INFO - 2016-12-14 20:16:50 --> Helper loaded: url_helper
DEBUG - 2016-12-14 20:16:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-14 20:16:52 --> Config Class Initialized
INFO - 2016-12-14 20:16:52 --> Hooks Class Initialized
DEBUG - 2016-12-14 20:16:52 --> UTF-8 Support Enabled
INFO - 2016-12-14 20:16:52 --> Utf8 Class Initialized
INFO - 2016-12-14 20:16:52 --> URI Class Initialized
INFO - 2016-12-14 20:16:52 --> Router Class Initialized
INFO - 2016-12-14 20:16:52 --> Output Class Initialized
INFO - 2016-12-14 20:16:52 --> Security Class Initialized
DEBUG - 2016-12-14 20:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-14 20:16:52 --> Input Class Initialized
INFO - 2016-12-14 20:16:52 --> Language Class Initialized
INFO - 2016-12-14 20:16:52 --> Loader Class Initialized
INFO - 2016-12-14 20:16:52 --> Database Driver Class Initialized
INFO - 2016-12-14 20:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-14 20:16:52 --> Controller Class Initialized
DEBUG - 2016-12-14 20:16:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-14 20:16:52 --> Helper loaded: url_helper
INFO - 2016-12-14 20:16:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-14 20:16:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2016-12-14 20:16:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2016-12-14 20:16:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-14 20:16:52 --> Final output sent to browser
DEBUG - 2016-12-14 20:16:52 --> Total execution time: 0.0273
INFO - 2016-12-14 20:16:53 --> Config Class Initialized
INFO - 2016-12-14 20:16:53 --> Hooks Class Initialized
DEBUG - 2016-12-14 20:16:53 --> UTF-8 Support Enabled
INFO - 2016-12-14 20:16:53 --> Utf8 Class Initialized
INFO - 2016-12-14 20:16:53 --> URI Class Initialized
INFO - 2016-12-14 20:16:53 --> Router Class Initialized
INFO - 2016-12-14 20:16:53 --> Output Class Initialized
INFO - 2016-12-14 20:16:53 --> Security Class Initialized
DEBUG - 2016-12-14 20:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-14 20:16:53 --> Input Class Initialized
INFO - 2016-12-14 20:16:53 --> Language Class Initialized
INFO - 2016-12-14 20:16:53 --> Loader Class Initialized
INFO - 2016-12-14 20:16:53 --> Database Driver Class Initialized
INFO - 2016-12-14 20:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-14 20:16:53 --> Controller Class Initialized
INFO - 2016-12-14 20:16:53 --> Helper loaded: url_helper
DEBUG - 2016-12-14 20:16:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-14 20:16:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-14 20:16:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-14 20:16:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-14 20:16:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-14 20:16:53 --> Final output sent to browser
DEBUG - 2016-12-14 20:16:53 --> Total execution time: 0.0131

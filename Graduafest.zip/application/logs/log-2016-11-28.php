<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-28 19:25:26 --> Config Class Initialized
INFO - 2016-11-28 19:25:26 --> Hooks Class Initialized
DEBUG - 2016-11-28 19:25:26 --> UTF-8 Support Enabled
INFO - 2016-11-28 19:25:26 --> Utf8 Class Initialized
INFO - 2016-11-28 19:25:26 --> URI Class Initialized
INFO - 2016-11-28 19:25:26 --> Router Class Initialized
INFO - 2016-11-28 19:25:26 --> Output Class Initialized
INFO - 2016-11-28 19:25:26 --> Security Class Initialized
DEBUG - 2016-11-28 19:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-28 19:25:26 --> Input Class Initialized
INFO - 2016-11-28 19:25:26 --> Language Class Initialized
INFO - 2016-11-28 19:25:26 --> Loader Class Initialized
INFO - 2016-11-28 19:25:26 --> Database Driver Class Initialized
INFO - 2016-11-28 19:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-28 19:25:26 --> Controller Class Initialized
INFO - 2016-11-28 19:25:26 --> Helper loaded: url_helper
DEBUG - 2016-11-28 19:25:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-28 19:25:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-28 19:25:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-28 19:25:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-28 19:25:26 --> Final output sent to browser
DEBUG - 2016-11-28 19:25:26 --> Total execution time: 0.0218
INFO - 2016-11-28 19:25:35 --> Config Class Initialized
INFO - 2016-11-28 19:25:35 --> Hooks Class Initialized
DEBUG - 2016-11-28 19:25:35 --> UTF-8 Support Enabled
INFO - 2016-11-28 19:25:35 --> Utf8 Class Initialized
INFO - 2016-11-28 19:25:35 --> URI Class Initialized
DEBUG - 2016-11-28 19:25:35 --> No URI present. Default controller set.
INFO - 2016-11-28 19:25:35 --> Router Class Initialized
INFO - 2016-11-28 19:25:35 --> Output Class Initialized
INFO - 2016-11-28 19:25:35 --> Security Class Initialized
DEBUG - 2016-11-28 19:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-28 19:25:35 --> Input Class Initialized
INFO - 2016-11-28 19:25:35 --> Language Class Initialized
INFO - 2016-11-28 19:25:35 --> Loader Class Initialized
INFO - 2016-11-28 19:25:35 --> Database Driver Class Initialized
INFO - 2016-11-28 19:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-28 19:25:35 --> Controller Class Initialized
INFO - 2016-11-28 19:25:35 --> Helper loaded: url_helper
DEBUG - 2016-11-28 19:25:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-28 19:25:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-28 19:25:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-28 19:25:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-28 19:25:35 --> Final output sent to browser
DEBUG - 2016-11-28 19:25:35 --> Total execution time: 0.0153
INFO - 2016-11-28 19:25:35 --> Config Class Initialized
INFO - 2016-11-28 19:25:35 --> Hooks Class Initialized
DEBUG - 2016-11-28 19:25:35 --> UTF-8 Support Enabled
INFO - 2016-11-28 19:25:35 --> Utf8 Class Initialized
INFO - 2016-11-28 19:25:35 --> Config Class Initialized
INFO - 2016-11-28 19:25:35 --> Hooks Class Initialized
DEBUG - 2016-11-28 19:25:35 --> UTF-8 Support Enabled
INFO - 2016-11-28 19:25:35 --> Utf8 Class Initialized
INFO - 2016-11-28 19:25:35 --> URI Class Initialized
INFO - 2016-11-28 19:25:35 --> Router Class Initialized
INFO - 2016-11-28 19:25:35 --> Output Class Initialized
INFO - 2016-11-28 19:25:35 --> Config Class Initialized
INFO - 2016-11-28 19:25:35 --> Hooks Class Initialized
DEBUG - 2016-11-28 19:25:35 --> UTF-8 Support Enabled
INFO - 2016-11-28 19:25:35 --> Utf8 Class Initialized
INFO - 2016-11-28 19:25:35 --> URI Class Initialized
INFO - 2016-11-28 19:25:35 --> Router Class Initialized
INFO - 2016-11-28 19:25:35 --> Output Class Initialized
INFO - 2016-11-28 19:25:35 --> Security Class Initialized
DEBUG - 2016-11-28 19:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-28 19:25:35 --> Input Class Initialized
INFO - 2016-11-28 19:25:35 --> Language Class Initialized
ERROR - 2016-11-28 19:25:35 --> 404 Page Not Found: Img/team
INFO - 2016-11-28 19:25:35 --> Security Class Initialized
DEBUG - 2016-11-28 19:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-28 19:25:35 --> Input Class Initialized
INFO - 2016-11-28 19:25:35 --> Language Class Initialized
ERROR - 2016-11-28 19:25:35 --> 404 Page Not Found: Img/about
INFO - 2016-11-28 19:25:35 --> URI Class Initialized
INFO - 2016-11-28 19:25:35 --> Router Class Initialized
INFO - 2016-11-28 19:25:35 --> Output Class Initialized
INFO - 2016-11-28 19:25:35 --> Security Class Initialized
DEBUG - 2016-11-28 19:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-28 19:25:35 --> Input Class Initialized
INFO - 2016-11-28 19:25:35 --> Language Class Initialized
ERROR - 2016-11-28 19:25:35 --> 404 Page Not Found: Img/team
INFO - 2016-11-28 19:25:36 --> Config Class Initialized
INFO - 2016-11-28 19:25:36 --> Hooks Class Initialized
DEBUG - 2016-11-28 19:25:36 --> UTF-8 Support Enabled
INFO - 2016-11-28 19:25:36 --> Utf8 Class Initialized
INFO - 2016-11-28 19:25:36 --> URI Class Initialized
INFO - 2016-11-28 19:25:36 --> Router Class Initialized
INFO - 2016-11-28 19:25:36 --> Output Class Initialized
INFO - 2016-11-28 19:25:36 --> Security Class Initialized
DEBUG - 2016-11-28 19:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-28 19:25:36 --> Input Class Initialized
INFO - 2016-11-28 19:25:36 --> Language Class Initialized
ERROR - 2016-11-28 19:25:36 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-28 19:25:36 --> Config Class Initialized
INFO - 2016-11-28 19:25:36 --> Hooks Class Initialized
DEBUG - 2016-11-28 19:25:36 --> UTF-8 Support Enabled
INFO - 2016-11-28 19:25:36 --> Utf8 Class Initialized
INFO - 2016-11-28 19:25:36 --> URI Class Initialized
INFO - 2016-11-28 19:25:36 --> Router Class Initialized
INFO - 2016-11-28 19:25:36 --> Output Class Initialized
INFO - 2016-11-28 19:25:36 --> Security Class Initialized
DEBUG - 2016-11-28 19:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-28 19:25:36 --> Input Class Initialized
INFO - 2016-11-28 19:25:36 --> Language Class Initialized
ERROR - 2016-11-28 19:25:36 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-28 19:25:36 --> Config Class Initialized
INFO - 2016-11-28 19:25:36 --> Hooks Class Initialized
DEBUG - 2016-11-28 19:25:36 --> UTF-8 Support Enabled
INFO - 2016-11-28 19:25:36 --> Utf8 Class Initialized
INFO - 2016-11-28 19:25:36 --> URI Class Initialized
INFO - 2016-11-28 19:25:36 --> Router Class Initialized
INFO - 2016-11-28 19:25:36 --> Output Class Initialized
INFO - 2016-11-28 19:25:36 --> Security Class Initialized
DEBUG - 2016-11-28 19:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-28 19:25:36 --> Input Class Initialized
INFO - 2016-11-28 19:25:36 --> Language Class Initialized
INFO - 2016-11-28 19:25:36 --> Loader Class Initialized
INFO - 2016-11-28 19:25:36 --> Database Driver Class Initialized
INFO - 2016-11-28 19:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-28 19:25:36 --> Controller Class Initialized
INFO - 2016-11-28 19:25:36 --> Helper loaded: url_helper
DEBUG - 2016-11-28 19:25:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-28 19:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-28 19:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-28 19:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-28 19:25:36 --> Final output sent to browser
DEBUG - 2016-11-28 19:25:36 --> Total execution time: 0.0137
INFO - 2016-11-28 22:01:59 --> Config Class Initialized
INFO - 2016-11-28 22:01:59 --> Hooks Class Initialized
DEBUG - 2016-11-28 22:02:00 --> UTF-8 Support Enabled
INFO - 2016-11-28 22:02:00 --> Utf8 Class Initialized
INFO - 2016-11-28 22:02:00 --> URI Class Initialized
DEBUG - 2016-11-28 22:02:00 --> No URI present. Default controller set.
INFO - 2016-11-28 22:02:00 --> Router Class Initialized
INFO - 2016-11-28 22:02:00 --> Output Class Initialized
INFO - 2016-11-28 22:02:00 --> Security Class Initialized
DEBUG - 2016-11-28 22:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-28 22:02:00 --> Input Class Initialized
INFO - 2016-11-28 22:02:00 --> Language Class Initialized
INFO - 2016-11-28 22:02:00 --> Loader Class Initialized
INFO - 2016-11-28 22:02:00 --> Database Driver Class Initialized
INFO - 2016-11-28 22:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-28 22:02:00 --> Controller Class Initialized
INFO - 2016-11-28 22:02:00 --> Helper loaded: url_helper
DEBUG - 2016-11-28 22:02:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-28 22:02:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-28 22:02:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-28 22:02:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-28 22:02:00 --> Final output sent to browser
DEBUG - 2016-11-28 22:02:00 --> Total execution time: 0.1271
INFO - 2016-11-28 22:02:01 --> Config Class Initialized
INFO - 2016-11-28 22:02:01 --> Hooks Class Initialized
DEBUG - 2016-11-28 22:02:01 --> UTF-8 Support Enabled
INFO - 2016-11-28 22:02:01 --> Utf8 Class Initialized
INFO - 2016-11-28 22:02:01 --> URI Class Initialized
INFO - 2016-11-28 22:02:01 --> Router Class Initialized
INFO - 2016-11-28 22:02:01 --> Output Class Initialized
INFO - 2016-11-28 22:02:01 --> Security Class Initialized
DEBUG - 2016-11-28 22:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-28 22:02:01 --> Input Class Initialized
INFO - 2016-11-28 22:02:01 --> Language Class Initialized
ERROR - 2016-11-28 22:02:01 --> 404 Page Not Found: Img/about
INFO - 2016-11-28 22:02:01 --> Config Class Initialized
INFO - 2016-11-28 22:02:01 --> Hooks Class Initialized
DEBUG - 2016-11-28 22:02:01 --> UTF-8 Support Enabled
INFO - 2016-11-28 22:02:01 --> Utf8 Class Initialized
INFO - 2016-11-28 22:02:01 --> URI Class Initialized
INFO - 2016-11-28 22:02:01 --> Router Class Initialized
INFO - 2016-11-28 22:02:01 --> Output Class Initialized
INFO - 2016-11-28 22:02:01 --> Security Class Initialized
DEBUG - 2016-11-28 22:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-28 22:02:01 --> Input Class Initialized
INFO - 2016-11-28 22:02:01 --> Language Class Initialized
ERROR - 2016-11-28 22:02:01 --> 404 Page Not Found: Img/team
INFO - 2016-11-28 22:02:01 --> Config Class Initialized
INFO - 2016-11-28 22:02:01 --> Hooks Class Initialized
DEBUG - 2016-11-28 22:02:01 --> UTF-8 Support Enabled
INFO - 2016-11-28 22:02:01 --> Utf8 Class Initialized
INFO - 2016-11-28 22:02:01 --> URI Class Initialized
INFO - 2016-11-28 22:02:01 --> Router Class Initialized
INFO - 2016-11-28 22:02:01 --> Output Class Initialized
INFO - 2016-11-28 22:02:01 --> Security Class Initialized
DEBUG - 2016-11-28 22:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-28 22:02:01 --> Input Class Initialized
INFO - 2016-11-28 22:02:01 --> Language Class Initialized
ERROR - 2016-11-28 22:02:01 --> 404 Page Not Found: Img/team
INFO - 2016-11-28 22:02:01 --> Config Class Initialized
INFO - 2016-11-28 22:02:01 --> Hooks Class Initialized
DEBUG - 2016-11-28 22:02:01 --> UTF-8 Support Enabled
INFO - 2016-11-28 22:02:01 --> Utf8 Class Initialized
INFO - 2016-11-28 22:02:01 --> URI Class Initialized
INFO - 2016-11-28 22:02:01 --> Router Class Initialized
INFO - 2016-11-28 22:02:01 --> Output Class Initialized
INFO - 2016-11-28 22:02:01 --> Security Class Initialized
DEBUG - 2016-11-28 22:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-28 22:02:01 --> Input Class Initialized
INFO - 2016-11-28 22:02:01 --> Language Class Initialized
ERROR - 2016-11-28 22:02:01 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-28 22:02:01 --> Config Class Initialized
INFO - 2016-11-28 22:02:01 --> Hooks Class Initialized
DEBUG - 2016-11-28 22:02:01 --> UTF-8 Support Enabled
INFO - 2016-11-28 22:02:01 --> Utf8 Class Initialized
INFO - 2016-11-28 22:02:01 --> URI Class Initialized
INFO - 2016-11-28 22:02:01 --> Router Class Initialized
INFO - 2016-11-28 22:02:01 --> Output Class Initialized
INFO - 2016-11-28 22:02:01 --> Security Class Initialized
DEBUG - 2016-11-28 22:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-28 22:02:01 --> Input Class Initialized
INFO - 2016-11-28 22:02:01 --> Language Class Initialized
ERROR - 2016-11-28 22:02:01 --> 404 Page Not Found: Img/portfolio
INFO - 2016-11-28 22:02:02 --> Config Class Initialized
INFO - 2016-11-28 22:02:02 --> Hooks Class Initialized
DEBUG - 2016-11-28 22:02:02 --> UTF-8 Support Enabled
INFO - 2016-11-28 22:02:02 --> Utf8 Class Initialized
INFO - 2016-11-28 22:02:02 --> URI Class Initialized
INFO - 2016-11-28 22:02:02 --> Router Class Initialized
INFO - 2016-11-28 22:02:02 --> Output Class Initialized
INFO - 2016-11-28 22:02:02 --> Security Class Initialized
DEBUG - 2016-11-28 22:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-28 22:02:02 --> Input Class Initialized
INFO - 2016-11-28 22:02:02 --> Language Class Initialized
INFO - 2016-11-28 22:02:02 --> Loader Class Initialized
INFO - 2016-11-28 22:02:02 --> Database Driver Class Initialized
INFO - 2016-11-28 22:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-28 22:02:02 --> Controller Class Initialized
INFO - 2016-11-28 22:02:02 --> Helper loaded: url_helper
DEBUG - 2016-11-28 22:02:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-28 22:02:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-11-28 22:02:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-11-28 22:02:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-11-28 22:02:02 --> Final output sent to browser
DEBUG - 2016-11-28 22:02:02 --> Total execution time: 0.0133

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-23 01:39:27 --> Config Class Initialized
INFO - 2017-01-23 01:39:27 --> Hooks Class Initialized
DEBUG - 2017-01-23 01:39:27 --> UTF-8 Support Enabled
INFO - 2017-01-23 01:39:27 --> Utf8 Class Initialized
INFO - 2017-01-23 01:39:27 --> URI Class Initialized
DEBUG - 2017-01-23 01:39:27 --> No URI present. Default controller set.
INFO - 2017-01-23 01:39:27 --> Router Class Initialized
INFO - 2017-01-23 01:39:27 --> Output Class Initialized
INFO - 2017-01-23 01:39:27 --> Security Class Initialized
DEBUG - 2017-01-23 01:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 01:39:27 --> Input Class Initialized
INFO - 2017-01-23 01:39:27 --> Language Class Initialized
INFO - 2017-01-23 01:39:27 --> Loader Class Initialized
INFO - 2017-01-23 01:39:27 --> Database Driver Class Initialized
INFO - 2017-01-23 01:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 01:39:27 --> Controller Class Initialized
INFO - 2017-01-23 01:39:27 --> Helper loaded: url_helper
DEBUG - 2017-01-23 01:39:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 01:39:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 01:39:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 01:39:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 01:39:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 01:39:27 --> Final output sent to browser
DEBUG - 2017-01-23 01:39:27 --> Total execution time: 0.2691
INFO - 2017-01-23 03:42:30 --> Config Class Initialized
INFO - 2017-01-23 03:42:30 --> Hooks Class Initialized
DEBUG - 2017-01-23 03:42:30 --> UTF-8 Support Enabled
INFO - 2017-01-23 03:42:30 --> Utf8 Class Initialized
INFO - 2017-01-23 03:42:30 --> URI Class Initialized
DEBUG - 2017-01-23 03:42:30 --> No URI present. Default controller set.
INFO - 2017-01-23 03:42:30 --> Router Class Initialized
INFO - 2017-01-23 03:42:30 --> Output Class Initialized
INFO - 2017-01-23 03:42:30 --> Security Class Initialized
DEBUG - 2017-01-23 03:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 03:42:30 --> Input Class Initialized
INFO - 2017-01-23 03:42:30 --> Language Class Initialized
INFO - 2017-01-23 03:42:30 --> Loader Class Initialized
INFO - 2017-01-23 03:42:30 --> Database Driver Class Initialized
INFO - 2017-01-23 03:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 03:42:30 --> Controller Class Initialized
INFO - 2017-01-23 03:42:30 --> Helper loaded: url_helper
DEBUG - 2017-01-23 03:42:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 03:42:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 03:42:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 03:42:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 03:42:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 03:42:30 --> Final output sent to browser
DEBUG - 2017-01-23 03:42:30 --> Total execution time: 0.0132
INFO - 2017-01-23 06:06:34 --> Config Class Initialized
INFO - 2017-01-23 06:06:34 --> Hooks Class Initialized
DEBUG - 2017-01-23 06:06:34 --> UTF-8 Support Enabled
INFO - 2017-01-23 06:06:34 --> Utf8 Class Initialized
INFO - 2017-01-23 06:06:34 --> URI Class Initialized
INFO - 2017-01-23 06:06:34 --> Router Class Initialized
INFO - 2017-01-23 06:06:34 --> Output Class Initialized
INFO - 2017-01-23 06:06:34 --> Security Class Initialized
DEBUG - 2017-01-23 06:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 06:06:34 --> Input Class Initialized
INFO - 2017-01-23 06:06:34 --> Language Class Initialized
INFO - 2017-01-23 06:06:34 --> Loader Class Initialized
INFO - 2017-01-23 06:06:34 --> Database Driver Class Initialized
INFO - 2017-01-23 06:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 06:06:34 --> Controller Class Initialized
INFO - 2017-01-23 06:06:34 --> Helper loaded: url_helper
DEBUG - 2017-01-23 06:06:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 06:06:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 06:06:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 06:06:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 06:06:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 06:06:34 --> Final output sent to browser
DEBUG - 2017-01-23 06:06:34 --> Total execution time: 0.0139
INFO - 2017-01-23 06:06:36 --> Config Class Initialized
INFO - 2017-01-23 06:06:36 --> Hooks Class Initialized
DEBUG - 2017-01-23 06:06:36 --> UTF-8 Support Enabled
INFO - 2017-01-23 06:06:36 --> Utf8 Class Initialized
INFO - 2017-01-23 06:06:36 --> URI Class Initialized
DEBUG - 2017-01-23 06:06:36 --> No URI present. Default controller set.
INFO - 2017-01-23 06:06:36 --> Router Class Initialized
INFO - 2017-01-23 06:06:36 --> Output Class Initialized
INFO - 2017-01-23 06:06:36 --> Security Class Initialized
DEBUG - 2017-01-23 06:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 06:06:36 --> Input Class Initialized
INFO - 2017-01-23 06:06:36 --> Language Class Initialized
INFO - 2017-01-23 06:06:36 --> Loader Class Initialized
INFO - 2017-01-23 06:06:36 --> Database Driver Class Initialized
INFO - 2017-01-23 06:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 06:06:36 --> Controller Class Initialized
INFO - 2017-01-23 06:06:36 --> Helper loaded: url_helper
DEBUG - 2017-01-23 06:06:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 06:06:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 06:06:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 06:06:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 06:06:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 06:06:36 --> Final output sent to browser
DEBUG - 2017-01-23 06:06:36 --> Total execution time: 0.0133
INFO - 2017-01-23 06:58:06 --> Config Class Initialized
INFO - 2017-01-23 06:58:06 --> Hooks Class Initialized
DEBUG - 2017-01-23 06:58:06 --> UTF-8 Support Enabled
INFO - 2017-01-23 06:58:06 --> Utf8 Class Initialized
INFO - 2017-01-23 06:58:06 --> URI Class Initialized
INFO - 2017-01-23 06:58:06 --> Router Class Initialized
INFO - 2017-01-23 06:58:06 --> Output Class Initialized
INFO - 2017-01-23 06:58:06 --> Security Class Initialized
DEBUG - 2017-01-23 06:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 06:58:06 --> Input Class Initialized
INFO - 2017-01-23 06:58:06 --> Language Class Initialized
INFO - 2017-01-23 06:58:06 --> Loader Class Initialized
INFO - 2017-01-23 06:58:06 --> Database Driver Class Initialized
INFO - 2017-01-23 06:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 06:58:06 --> Controller Class Initialized
INFO - 2017-01-23 06:58:06 --> Helper loaded: url_helper
DEBUG - 2017-01-23 06:58:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 06:58:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 06:58:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 06:58:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 06:58:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 06:58:06 --> Final output sent to browser
DEBUG - 2017-01-23 06:58:06 --> Total execution time: 0.0135
INFO - 2017-01-23 06:58:06 --> Config Class Initialized
INFO - 2017-01-23 06:58:06 --> Hooks Class Initialized
DEBUG - 2017-01-23 06:58:06 --> UTF-8 Support Enabled
INFO - 2017-01-23 06:58:06 --> Utf8 Class Initialized
INFO - 2017-01-23 06:58:06 --> URI Class Initialized
INFO - 2017-01-23 06:58:06 --> Router Class Initialized
INFO - 2017-01-23 06:58:06 --> Output Class Initialized
INFO - 2017-01-23 06:58:06 --> Security Class Initialized
DEBUG - 2017-01-23 06:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 06:58:06 --> Input Class Initialized
INFO - 2017-01-23 06:58:06 --> Language Class Initialized
INFO - 2017-01-23 06:58:06 --> Loader Class Initialized
INFO - 2017-01-23 06:58:06 --> Database Driver Class Initialized
INFO - 2017-01-23 06:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 06:58:06 --> Controller Class Initialized
INFO - 2017-01-23 06:58:06 --> Helper loaded: url_helper
DEBUG - 2017-01-23 06:58:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 06:58:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 06:58:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 06:58:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 06:58:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 06:58:06 --> Final output sent to browser
DEBUG - 2017-01-23 06:58:06 --> Total execution time: 0.0131
INFO - 2017-01-23 10:58:26 --> Config Class Initialized
INFO - 2017-01-23 10:58:26 --> Hooks Class Initialized
DEBUG - 2017-01-23 10:58:26 --> UTF-8 Support Enabled
INFO - 2017-01-23 10:58:26 --> Utf8 Class Initialized
INFO - 2017-01-23 10:58:26 --> URI Class Initialized
INFO - 2017-01-23 10:58:26 --> Router Class Initialized
INFO - 2017-01-23 10:58:26 --> Output Class Initialized
INFO - 2017-01-23 10:58:26 --> Security Class Initialized
DEBUG - 2017-01-23 10:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 10:58:26 --> Input Class Initialized
INFO - 2017-01-23 10:58:26 --> Language Class Initialized
INFO - 2017-01-23 10:58:26 --> Loader Class Initialized
INFO - 2017-01-23 10:58:26 --> Database Driver Class Initialized
INFO - 2017-01-23 10:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 10:58:26 --> Controller Class Initialized
INFO - 2017-01-23 10:58:26 --> Helper loaded: url_helper
DEBUG - 2017-01-23 10:58:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 10:58:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 10:58:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 10:58:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 10:58:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 10:58:26 --> Final output sent to browser
DEBUG - 2017-01-23 10:58:26 --> Total execution time: 0.2406
INFO - 2017-01-23 15:29:55 --> Config Class Initialized
INFO - 2017-01-23 15:29:56 --> Hooks Class Initialized
DEBUG - 2017-01-23 15:29:56 --> UTF-8 Support Enabled
INFO - 2017-01-23 15:29:56 --> Utf8 Class Initialized
INFO - 2017-01-23 15:29:56 --> URI Class Initialized
DEBUG - 2017-01-23 15:29:56 --> No URI present. Default controller set.
INFO - 2017-01-23 15:29:56 --> Router Class Initialized
INFO - 2017-01-23 15:29:56 --> Output Class Initialized
INFO - 2017-01-23 15:29:56 --> Security Class Initialized
DEBUG - 2017-01-23 15:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 15:29:56 --> Input Class Initialized
INFO - 2017-01-23 15:29:56 --> Language Class Initialized
INFO - 2017-01-23 15:29:56 --> Loader Class Initialized
INFO - 2017-01-23 15:29:56 --> Database Driver Class Initialized
INFO - 2017-01-23 15:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 15:29:56 --> Controller Class Initialized
INFO - 2017-01-23 15:29:56 --> Helper loaded: url_helper
DEBUG - 2017-01-23 15:29:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 15:29:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 15:29:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 15:29:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 15:29:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 15:29:56 --> Final output sent to browser
DEBUG - 2017-01-23 15:29:56 --> Total execution time: 1.0312
INFO - 2017-01-23 15:30:02 --> Config Class Initialized
INFO - 2017-01-23 15:30:02 --> Hooks Class Initialized
DEBUG - 2017-01-23 15:30:02 --> UTF-8 Support Enabled
INFO - 2017-01-23 15:30:02 --> Utf8 Class Initialized
INFO - 2017-01-23 15:30:02 --> URI Class Initialized
INFO - 2017-01-23 15:30:02 --> Router Class Initialized
INFO - 2017-01-23 15:30:02 --> Output Class Initialized
INFO - 2017-01-23 15:30:02 --> Security Class Initialized
DEBUG - 2017-01-23 15:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 15:30:02 --> Input Class Initialized
INFO - 2017-01-23 15:30:02 --> Language Class Initialized
INFO - 2017-01-23 15:30:02 --> Loader Class Initialized
INFO - 2017-01-23 15:30:03 --> Database Driver Class Initialized
INFO - 2017-01-23 15:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 15:30:03 --> Controller Class Initialized
INFO - 2017-01-23 15:30:03 --> Helper loaded: url_helper
DEBUG - 2017-01-23 15:30:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 15:30:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 15:30:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 15:30:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 15:30:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 15:30:03 --> Final output sent to browser
DEBUG - 2017-01-23 15:30:03 --> Total execution time: 0.8012
INFO - 2017-01-23 15:30:45 --> Config Class Initialized
INFO - 2017-01-23 15:30:45 --> Hooks Class Initialized
DEBUG - 2017-01-23 15:30:45 --> UTF-8 Support Enabled
INFO - 2017-01-23 15:30:45 --> Utf8 Class Initialized
INFO - 2017-01-23 15:30:45 --> URI Class Initialized
INFO - 2017-01-23 15:30:45 --> Router Class Initialized
INFO - 2017-01-23 15:30:45 --> Output Class Initialized
INFO - 2017-01-23 15:30:45 --> Security Class Initialized
DEBUG - 2017-01-23 15:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 15:30:46 --> Input Class Initialized
INFO - 2017-01-23 15:30:46 --> Language Class Initialized
INFO - 2017-01-23 15:30:46 --> Loader Class Initialized
INFO - 2017-01-23 15:30:46 --> Database Driver Class Initialized
INFO - 2017-01-23 15:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 15:30:46 --> Controller Class Initialized
INFO - 2017-01-23 15:30:46 --> Helper loaded: url_helper
DEBUG - 2017-01-23 15:30:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 15:30:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 15:30:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 15:30:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 15:30:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 15:30:46 --> Final output sent to browser
DEBUG - 2017-01-23 15:30:46 --> Total execution time: 0.6908
INFO - 2017-01-23 15:30:48 --> Config Class Initialized
INFO - 2017-01-23 15:30:48 --> Hooks Class Initialized
DEBUG - 2017-01-23 15:30:48 --> UTF-8 Support Enabled
INFO - 2017-01-23 15:30:48 --> Utf8 Class Initialized
INFO - 2017-01-23 15:30:48 --> URI Class Initialized
INFO - 2017-01-23 15:30:48 --> Router Class Initialized
INFO - 2017-01-23 15:30:48 --> Output Class Initialized
INFO - 2017-01-23 15:30:48 --> Security Class Initialized
DEBUG - 2017-01-23 15:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 15:30:48 --> Input Class Initialized
INFO - 2017-01-23 15:30:48 --> Language Class Initialized
INFO - 2017-01-23 15:30:48 --> Loader Class Initialized
INFO - 2017-01-23 15:30:48 --> Database Driver Class Initialized
INFO - 2017-01-23 15:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 15:30:48 --> Controller Class Initialized
INFO - 2017-01-23 15:30:48 --> Helper loaded: url_helper
DEBUG - 2017-01-23 15:30:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 15:30:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 15:30:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 15:30:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 15:30:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 15:30:48 --> Final output sent to browser
DEBUG - 2017-01-23 15:30:48 --> Total execution time: 0.4604
INFO - 2017-01-23 15:31:27 --> Config Class Initialized
INFO - 2017-01-23 15:31:27 --> Hooks Class Initialized
DEBUG - 2017-01-23 15:31:27 --> UTF-8 Support Enabled
INFO - 2017-01-23 15:31:27 --> Utf8 Class Initialized
INFO - 2017-01-23 15:31:27 --> URI Class Initialized
INFO - 2017-01-23 15:31:27 --> Router Class Initialized
INFO - 2017-01-23 15:31:27 --> Output Class Initialized
INFO - 2017-01-23 15:31:27 --> Security Class Initialized
DEBUG - 2017-01-23 15:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 15:31:27 --> Input Class Initialized
INFO - 2017-01-23 15:31:27 --> Language Class Initialized
INFO - 2017-01-23 15:31:27 --> Loader Class Initialized
INFO - 2017-01-23 15:31:27 --> Database Driver Class Initialized
INFO - 2017-01-23 15:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 15:31:27 --> Controller Class Initialized
INFO - 2017-01-23 15:31:27 --> Helper loaded: url_helper
DEBUG - 2017-01-23 15:31:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 15:31:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 15:31:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 15:31:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 15:31:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 15:31:27 --> Final output sent to browser
DEBUG - 2017-01-23 15:31:27 --> Total execution time: 0.5240
INFO - 2017-01-23 15:31:29 --> Config Class Initialized
INFO - 2017-01-23 15:31:29 --> Hooks Class Initialized
DEBUG - 2017-01-23 15:31:29 --> UTF-8 Support Enabled
INFO - 2017-01-23 15:31:29 --> Utf8 Class Initialized
INFO - 2017-01-23 15:31:29 --> URI Class Initialized
INFO - 2017-01-23 15:31:29 --> Router Class Initialized
INFO - 2017-01-23 15:31:29 --> Output Class Initialized
INFO - 2017-01-23 15:31:29 --> Security Class Initialized
DEBUG - 2017-01-23 15:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 15:31:29 --> Input Class Initialized
INFO - 2017-01-23 15:31:29 --> Language Class Initialized
INFO - 2017-01-23 15:31:29 --> Loader Class Initialized
INFO - 2017-01-23 15:31:29 --> Database Driver Class Initialized
INFO - 2017-01-23 15:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 15:31:29 --> Controller Class Initialized
INFO - 2017-01-23 15:31:29 --> Helper loaded: url_helper
DEBUG - 2017-01-23 15:31:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 15:31:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 15:31:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 15:31:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 15:31:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 15:31:29 --> Final output sent to browser
DEBUG - 2017-01-23 15:31:29 --> Total execution time: 0.0140
INFO - 2017-01-23 15:31:43 --> Config Class Initialized
INFO - 2017-01-23 15:31:43 --> Hooks Class Initialized
DEBUG - 2017-01-23 15:31:43 --> UTF-8 Support Enabled
INFO - 2017-01-23 15:31:43 --> Utf8 Class Initialized
INFO - 2017-01-23 15:31:43 --> URI Class Initialized
INFO - 2017-01-23 15:31:43 --> Router Class Initialized
INFO - 2017-01-23 15:31:43 --> Output Class Initialized
INFO - 2017-01-23 15:31:43 --> Security Class Initialized
DEBUG - 2017-01-23 15:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 15:31:43 --> Input Class Initialized
INFO - 2017-01-23 15:31:43 --> Language Class Initialized
INFO - 2017-01-23 15:31:43 --> Loader Class Initialized
INFO - 2017-01-23 15:31:43 --> Database Driver Class Initialized
INFO - 2017-01-23 15:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 15:31:43 --> Controller Class Initialized
INFO - 2017-01-23 15:31:43 --> Helper loaded: url_helper
DEBUG - 2017-01-23 15:31:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 15:31:46 --> Config Class Initialized
INFO - 2017-01-23 15:31:46 --> Hooks Class Initialized
DEBUG - 2017-01-23 15:31:46 --> UTF-8 Support Enabled
INFO - 2017-01-23 15:31:46 --> Utf8 Class Initialized
INFO - 2017-01-23 15:31:46 --> URI Class Initialized
INFO - 2017-01-23 15:31:46 --> Router Class Initialized
INFO - 2017-01-23 15:31:46 --> Output Class Initialized
INFO - 2017-01-23 15:31:46 --> Security Class Initialized
DEBUG - 2017-01-23 15:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 15:31:46 --> Input Class Initialized
INFO - 2017-01-23 15:31:46 --> Language Class Initialized
INFO - 2017-01-23 15:31:46 --> Loader Class Initialized
INFO - 2017-01-23 15:31:46 --> Database Driver Class Initialized
INFO - 2017-01-23 15:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 15:31:46 --> Controller Class Initialized
INFO - 2017-01-23 15:31:46 --> Helper loaded: date_helper
DEBUG - 2017-01-23 15:31:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 15:31:46 --> Helper loaded: url_helper
INFO - 2017-01-23 15:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 15:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-23 15:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-23 15:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-23 15:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 15:31:46 --> Final output sent to browser
DEBUG - 2017-01-23 15:31:46 --> Total execution time: 0.0872
INFO - 2017-01-23 15:31:47 --> Config Class Initialized
INFO - 2017-01-23 15:31:47 --> Hooks Class Initialized
DEBUG - 2017-01-23 15:31:47 --> UTF-8 Support Enabled
INFO - 2017-01-23 15:31:47 --> Utf8 Class Initialized
INFO - 2017-01-23 15:31:47 --> URI Class Initialized
INFO - 2017-01-23 15:31:47 --> Router Class Initialized
INFO - 2017-01-23 15:31:47 --> Output Class Initialized
INFO - 2017-01-23 15:31:47 --> Security Class Initialized
DEBUG - 2017-01-23 15:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 15:31:47 --> Input Class Initialized
INFO - 2017-01-23 15:31:47 --> Language Class Initialized
INFO - 2017-01-23 15:31:47 --> Loader Class Initialized
INFO - 2017-01-23 15:31:47 --> Database Driver Class Initialized
INFO - 2017-01-23 15:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 15:31:47 --> Controller Class Initialized
INFO - 2017-01-23 15:31:47 --> Helper loaded: url_helper
DEBUG - 2017-01-23 15:31:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 15:31:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 15:31:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 15:31:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 15:31:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 15:31:47 --> Final output sent to browser
DEBUG - 2017-01-23 15:31:47 --> Total execution time: 0.0135
INFO - 2017-01-23 15:31:56 --> Config Class Initialized
INFO - 2017-01-23 15:31:56 --> Hooks Class Initialized
DEBUG - 2017-01-23 15:31:56 --> UTF-8 Support Enabled
INFO - 2017-01-23 15:31:56 --> Utf8 Class Initialized
INFO - 2017-01-23 15:31:56 --> URI Class Initialized
DEBUG - 2017-01-23 15:31:56 --> No URI present. Default controller set.
INFO - 2017-01-23 15:31:56 --> Router Class Initialized
INFO - 2017-01-23 15:31:56 --> Output Class Initialized
INFO - 2017-01-23 15:31:56 --> Security Class Initialized
DEBUG - 2017-01-23 15:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 15:31:56 --> Input Class Initialized
INFO - 2017-01-23 15:31:56 --> Language Class Initialized
INFO - 2017-01-23 15:31:56 --> Loader Class Initialized
INFO - 2017-01-23 15:31:56 --> Database Driver Class Initialized
INFO - 2017-01-23 15:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 15:31:56 --> Controller Class Initialized
INFO - 2017-01-23 15:31:56 --> Helper loaded: url_helper
DEBUG - 2017-01-23 15:31:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 15:31:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 15:31:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 15:31:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 15:31:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 15:31:56 --> Final output sent to browser
DEBUG - 2017-01-23 15:31:56 --> Total execution time: 0.0177
INFO - 2017-01-23 15:31:57 --> Config Class Initialized
INFO - 2017-01-23 15:31:57 --> Hooks Class Initialized
DEBUG - 2017-01-23 15:31:57 --> UTF-8 Support Enabled
INFO - 2017-01-23 15:31:57 --> Utf8 Class Initialized
INFO - 2017-01-23 15:31:57 --> URI Class Initialized
INFO - 2017-01-23 15:31:57 --> Router Class Initialized
INFO - 2017-01-23 15:31:57 --> Output Class Initialized
INFO - 2017-01-23 15:31:57 --> Security Class Initialized
DEBUG - 2017-01-23 15:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 15:31:57 --> Input Class Initialized
INFO - 2017-01-23 15:31:57 --> Language Class Initialized
INFO - 2017-01-23 15:31:57 --> Loader Class Initialized
INFO - 2017-01-23 15:31:57 --> Database Driver Class Initialized
INFO - 2017-01-23 15:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 15:31:57 --> Controller Class Initialized
INFO - 2017-01-23 15:31:57 --> Helper loaded: url_helper
DEBUG - 2017-01-23 15:31:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 15:31:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 15:31:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 15:31:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 15:31:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 15:31:57 --> Final output sent to browser
DEBUG - 2017-01-23 15:31:57 --> Total execution time: 0.1399
INFO - 2017-01-23 15:32:36 --> Config Class Initialized
INFO - 2017-01-23 15:32:36 --> Hooks Class Initialized
DEBUG - 2017-01-23 15:32:36 --> UTF-8 Support Enabled
INFO - 2017-01-23 15:32:36 --> Utf8 Class Initialized
INFO - 2017-01-23 15:32:36 --> URI Class Initialized
INFO - 2017-01-23 15:32:36 --> Router Class Initialized
INFO - 2017-01-23 15:32:36 --> Output Class Initialized
INFO - 2017-01-23 15:32:36 --> Security Class Initialized
DEBUG - 2017-01-23 15:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 15:32:36 --> Input Class Initialized
INFO - 2017-01-23 15:32:36 --> Language Class Initialized
INFO - 2017-01-23 15:32:36 --> Loader Class Initialized
INFO - 2017-01-23 15:32:36 --> Database Driver Class Initialized
INFO - 2017-01-23 15:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 15:32:36 --> Controller Class Initialized
INFO - 2017-01-23 15:32:36 --> Helper loaded: date_helper
DEBUG - 2017-01-23 15:32:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 15:32:36 --> Helper loaded: url_helper
INFO - 2017-01-23 15:32:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 15:32:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-23 15:32:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-23 15:32:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-23 15:32:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 15:32:36 --> Final output sent to browser
DEBUG - 2017-01-23 15:32:36 --> Total execution time: 0.0537
INFO - 2017-01-23 15:32:37 --> Config Class Initialized
INFO - 2017-01-23 15:32:37 --> Hooks Class Initialized
DEBUG - 2017-01-23 15:32:37 --> UTF-8 Support Enabled
INFO - 2017-01-23 15:32:37 --> Utf8 Class Initialized
INFO - 2017-01-23 15:32:37 --> URI Class Initialized
INFO - 2017-01-23 15:32:37 --> Router Class Initialized
INFO - 2017-01-23 15:32:37 --> Output Class Initialized
INFO - 2017-01-23 15:32:37 --> Security Class Initialized
DEBUG - 2017-01-23 15:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 15:32:37 --> Input Class Initialized
INFO - 2017-01-23 15:32:37 --> Language Class Initialized
INFO - 2017-01-23 15:32:37 --> Loader Class Initialized
INFO - 2017-01-23 15:32:37 --> Database Driver Class Initialized
INFO - 2017-01-23 15:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 15:32:37 --> Controller Class Initialized
INFO - 2017-01-23 15:32:37 --> Helper loaded: url_helper
DEBUG - 2017-01-23 15:32:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 15:32:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 15:32:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 15:32:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 15:32:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 15:32:37 --> Final output sent to browser
DEBUG - 2017-01-23 15:32:37 --> Total execution time: 0.0139
INFO - 2017-01-23 15:32:39 --> Config Class Initialized
INFO - 2017-01-23 15:32:39 --> Hooks Class Initialized
DEBUG - 2017-01-23 15:32:39 --> UTF-8 Support Enabled
INFO - 2017-01-23 15:32:39 --> Utf8 Class Initialized
INFO - 2017-01-23 15:32:39 --> URI Class Initialized
INFO - 2017-01-23 15:32:39 --> Router Class Initialized
INFO - 2017-01-23 15:32:39 --> Output Class Initialized
INFO - 2017-01-23 15:32:39 --> Security Class Initialized
DEBUG - 2017-01-23 15:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 15:32:39 --> Input Class Initialized
INFO - 2017-01-23 15:32:39 --> Language Class Initialized
INFO - 2017-01-23 15:32:39 --> Loader Class Initialized
INFO - 2017-01-23 15:32:39 --> Database Driver Class Initialized
INFO - 2017-01-23 15:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 15:32:39 --> Controller Class Initialized
INFO - 2017-01-23 15:32:39 --> Helper loaded: url_helper
DEBUG - 2017-01-23 15:32:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 15:32:40 --> Config Class Initialized
INFO - 2017-01-23 15:32:40 --> Hooks Class Initialized
DEBUG - 2017-01-23 15:32:40 --> UTF-8 Support Enabled
INFO - 2017-01-23 15:32:40 --> Utf8 Class Initialized
INFO - 2017-01-23 15:32:40 --> URI Class Initialized
INFO - 2017-01-23 15:32:40 --> Router Class Initialized
INFO - 2017-01-23 15:32:40 --> Output Class Initialized
INFO - 2017-01-23 15:32:40 --> Security Class Initialized
DEBUG - 2017-01-23 15:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 15:32:40 --> Input Class Initialized
INFO - 2017-01-23 15:32:40 --> Language Class Initialized
INFO - 2017-01-23 15:32:40 --> Loader Class Initialized
INFO - 2017-01-23 15:32:40 --> Database Driver Class Initialized
INFO - 2017-01-23 15:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 15:32:40 --> Controller Class Initialized
INFO - 2017-01-23 15:32:40 --> Helper loaded: date_helper
DEBUG - 2017-01-23 15:32:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 15:32:40 --> Helper loaded: url_helper
INFO - 2017-01-23 15:32:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 15:32:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-23 15:32:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-23 15:32:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-23 15:32:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 15:32:40 --> Final output sent to browser
DEBUG - 2017-01-23 15:32:40 --> Total execution time: 0.0609
INFO - 2017-01-23 15:32:41 --> Config Class Initialized
INFO - 2017-01-23 15:32:41 --> Hooks Class Initialized
DEBUG - 2017-01-23 15:32:41 --> UTF-8 Support Enabled
INFO - 2017-01-23 15:32:41 --> Utf8 Class Initialized
INFO - 2017-01-23 15:32:41 --> URI Class Initialized
INFO - 2017-01-23 15:32:41 --> Router Class Initialized
INFO - 2017-01-23 15:32:41 --> Output Class Initialized
INFO - 2017-01-23 15:32:41 --> Security Class Initialized
DEBUG - 2017-01-23 15:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 15:32:41 --> Input Class Initialized
INFO - 2017-01-23 15:32:41 --> Language Class Initialized
INFO - 2017-01-23 15:32:41 --> Loader Class Initialized
INFO - 2017-01-23 15:32:41 --> Database Driver Class Initialized
INFO - 2017-01-23 15:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 15:32:41 --> Controller Class Initialized
INFO - 2017-01-23 15:32:41 --> Helper loaded: url_helper
DEBUG - 2017-01-23 15:32:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 15:32:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 15:32:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 15:32:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 15:32:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 15:32:41 --> Final output sent to browser
DEBUG - 2017-01-23 15:32:41 --> Total execution time: 0.0177
INFO - 2017-01-23 16:08:00 --> Config Class Initialized
INFO - 2017-01-23 16:08:00 --> Hooks Class Initialized
DEBUG - 2017-01-23 16:08:00 --> UTF-8 Support Enabled
INFO - 2017-01-23 16:08:00 --> Utf8 Class Initialized
INFO - 2017-01-23 16:08:00 --> URI Class Initialized
INFO - 2017-01-23 16:08:00 --> Router Class Initialized
INFO - 2017-01-23 16:08:00 --> Output Class Initialized
INFO - 2017-01-23 16:08:00 --> Security Class Initialized
DEBUG - 2017-01-23 16:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 16:08:01 --> Input Class Initialized
INFO - 2017-01-23 16:08:01 --> Language Class Initialized
INFO - 2017-01-23 16:08:01 --> Loader Class Initialized
INFO - 2017-01-23 16:08:01 --> Database Driver Class Initialized
INFO - 2017-01-23 16:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 16:08:01 --> Controller Class Initialized
INFO - 2017-01-23 16:08:01 --> Helper loaded: url_helper
DEBUG - 2017-01-23 16:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 16:08:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 16:08:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 16:08:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 16:08:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 16:08:01 --> Final output sent to browser
DEBUG - 2017-01-23 16:08:01 --> Total execution time: 0.7399
INFO - 2017-01-23 16:38:01 --> Config Class Initialized
INFO - 2017-01-23 16:38:01 --> Hooks Class Initialized
DEBUG - 2017-01-23 16:38:01 --> UTF-8 Support Enabled
INFO - 2017-01-23 16:38:01 --> Utf8 Class Initialized
INFO - 2017-01-23 16:38:01 --> URI Class Initialized
INFO - 2017-01-23 16:38:01 --> Router Class Initialized
INFO - 2017-01-23 16:38:01 --> Output Class Initialized
INFO - 2017-01-23 16:38:01 --> Security Class Initialized
DEBUG - 2017-01-23 16:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 16:38:01 --> Input Class Initialized
INFO - 2017-01-23 16:38:01 --> Language Class Initialized
INFO - 2017-01-23 16:38:01 --> Loader Class Initialized
INFO - 2017-01-23 16:38:01 --> Database Driver Class Initialized
INFO - 2017-01-23 16:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 16:38:02 --> Controller Class Initialized
INFO - 2017-01-23 16:38:02 --> Upload Class Initialized
INFO - 2017-01-23 16:38:02 --> Helper loaded: date_helper
DEBUG - 2017-01-23 16:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 16:38:02 --> Helper loaded: url_helper
INFO - 2017-01-23 16:38:03 --> Config Class Initialized
INFO - 2017-01-23 16:38:03 --> Hooks Class Initialized
DEBUG - 2017-01-23 16:38:03 --> UTF-8 Support Enabled
INFO - 2017-01-23 16:38:03 --> Utf8 Class Initialized
INFO - 2017-01-23 16:38:03 --> URI Class Initialized
DEBUG - 2017-01-23 16:38:03 --> No URI present. Default controller set.
INFO - 2017-01-23 16:38:03 --> Router Class Initialized
INFO - 2017-01-23 16:38:03 --> Output Class Initialized
INFO - 2017-01-23 16:38:03 --> Security Class Initialized
DEBUG - 2017-01-23 16:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 16:38:03 --> Input Class Initialized
INFO - 2017-01-23 16:38:03 --> Language Class Initialized
INFO - 2017-01-23 16:38:03 --> Loader Class Initialized
INFO - 2017-01-23 16:38:03 --> Database Driver Class Initialized
INFO - 2017-01-23 16:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 16:38:03 --> Controller Class Initialized
INFO - 2017-01-23 16:38:03 --> Helper loaded: url_helper
DEBUG - 2017-01-23 16:38:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 16:38:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 16:38:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 16:38:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 16:38:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 16:38:03 --> Final output sent to browser
DEBUG - 2017-01-23 16:38:03 --> Total execution time: 0.2077
INFO - 2017-01-23 16:55:51 --> Config Class Initialized
INFO - 2017-01-23 16:55:51 --> Hooks Class Initialized
DEBUG - 2017-01-23 16:55:51 --> UTF-8 Support Enabled
INFO - 2017-01-23 16:55:51 --> Utf8 Class Initialized
INFO - 2017-01-23 16:55:51 --> URI Class Initialized
DEBUG - 2017-01-23 16:55:51 --> No URI present. Default controller set.
INFO - 2017-01-23 16:55:51 --> Router Class Initialized
INFO - 2017-01-23 16:55:51 --> Output Class Initialized
INFO - 2017-01-23 16:55:51 --> Security Class Initialized
DEBUG - 2017-01-23 16:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 16:55:51 --> Input Class Initialized
INFO - 2017-01-23 16:55:51 --> Language Class Initialized
INFO - 2017-01-23 16:55:51 --> Loader Class Initialized
INFO - 2017-01-23 16:55:51 --> Database Driver Class Initialized
INFO - 2017-01-23 16:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 16:55:51 --> Controller Class Initialized
INFO - 2017-01-23 16:55:51 --> Helper loaded: url_helper
DEBUG - 2017-01-23 16:55:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 16:55:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 16:55:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 16:55:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 16:55:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 16:55:51 --> Final output sent to browser
DEBUG - 2017-01-23 16:55:51 --> Total execution time: 0.7075
INFO - 2017-01-23 17:07:35 --> Config Class Initialized
INFO - 2017-01-23 17:07:35 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:07:35 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:07:35 --> Utf8 Class Initialized
INFO - 2017-01-23 17:07:35 --> URI Class Initialized
DEBUG - 2017-01-23 17:07:35 --> No URI present. Default controller set.
INFO - 2017-01-23 17:07:35 --> Router Class Initialized
INFO - 2017-01-23 17:07:35 --> Output Class Initialized
INFO - 2017-01-23 17:07:35 --> Security Class Initialized
DEBUG - 2017-01-23 17:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:07:35 --> Input Class Initialized
INFO - 2017-01-23 17:07:36 --> Language Class Initialized
INFO - 2017-01-23 17:07:36 --> Loader Class Initialized
INFO - 2017-01-23 17:07:36 --> Database Driver Class Initialized
INFO - 2017-01-23 17:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:07:36 --> Controller Class Initialized
INFO - 2017-01-23 17:07:36 --> Helper loaded: url_helper
DEBUG - 2017-01-23 17:07:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:07:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:07:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 17:07:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 17:07:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:07:36 --> Final output sent to browser
DEBUG - 2017-01-23 17:07:36 --> Total execution time: 0.9638
INFO - 2017-01-23 17:07:54 --> Config Class Initialized
INFO - 2017-01-23 17:07:54 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:07:54 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:07:54 --> Utf8 Class Initialized
INFO - 2017-01-23 17:07:54 --> URI Class Initialized
INFO - 2017-01-23 17:07:54 --> Router Class Initialized
INFO - 2017-01-23 17:07:54 --> Output Class Initialized
INFO - 2017-01-23 17:07:54 --> Security Class Initialized
DEBUG - 2017-01-23 17:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:07:55 --> Input Class Initialized
INFO - 2017-01-23 17:07:55 --> Language Class Initialized
INFO - 2017-01-23 17:07:55 --> Loader Class Initialized
INFO - 2017-01-23 17:07:55 --> Database Driver Class Initialized
INFO - 2017-01-23 17:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:07:55 --> Controller Class Initialized
INFO - 2017-01-23 17:07:55 --> Helper loaded: url_helper
DEBUG - 2017-01-23 17:07:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:07:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:07:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 17:07:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 17:07:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:07:55 --> Final output sent to browser
DEBUG - 2017-01-23 17:07:55 --> Total execution time: 0.3116
INFO - 2017-01-23 17:08:13 --> Config Class Initialized
INFO - 2017-01-23 17:08:13 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:08:13 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:08:13 --> Utf8 Class Initialized
INFO - 2017-01-23 17:08:13 --> URI Class Initialized
INFO - 2017-01-23 17:08:13 --> Router Class Initialized
INFO - 2017-01-23 17:08:13 --> Output Class Initialized
INFO - 2017-01-23 17:08:13 --> Security Class Initialized
DEBUG - 2017-01-23 17:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:08:13 --> Input Class Initialized
INFO - 2017-01-23 17:08:13 --> Language Class Initialized
INFO - 2017-01-23 17:08:13 --> Loader Class Initialized
INFO - 2017-01-23 17:08:13 --> Database Driver Class Initialized
INFO - 2017-01-23 17:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:08:13 --> Controller Class Initialized
INFO - 2017-01-23 17:08:13 --> Helper loaded: url_helper
DEBUG - 2017-01-23 17:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:08:14 --> Config Class Initialized
INFO - 2017-01-23 17:08:14 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:08:14 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:08:14 --> Utf8 Class Initialized
INFO - 2017-01-23 17:08:14 --> URI Class Initialized
INFO - 2017-01-23 17:08:14 --> Router Class Initialized
INFO - 2017-01-23 17:08:14 --> Output Class Initialized
INFO - 2017-01-23 17:08:14 --> Security Class Initialized
DEBUG - 2017-01-23 17:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:08:14 --> Input Class Initialized
INFO - 2017-01-23 17:08:14 --> Language Class Initialized
INFO - 2017-01-23 17:08:14 --> Loader Class Initialized
INFO - 2017-01-23 17:08:14 --> Database Driver Class Initialized
INFO - 2017-01-23 17:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:08:14 --> Controller Class Initialized
INFO - 2017-01-23 17:08:14 --> Helper loaded: date_helper
DEBUG - 2017-01-23 17:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:08:14 --> Helper loaded: url_helper
INFO - 2017-01-23 17:08:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:08:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 17:08:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-23 17:08:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-23 17:08:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:08:15 --> Final output sent to browser
DEBUG - 2017-01-23 17:08:15 --> Total execution time: 0.6570
INFO - 2017-01-23 17:08:23 --> Config Class Initialized
INFO - 2017-01-23 17:08:23 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:08:23 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:08:23 --> Utf8 Class Initialized
INFO - 2017-01-23 17:08:23 --> URI Class Initialized
INFO - 2017-01-23 17:08:23 --> Router Class Initialized
INFO - 2017-01-23 17:08:23 --> Output Class Initialized
INFO - 2017-01-23 17:08:23 --> Security Class Initialized
DEBUG - 2017-01-23 17:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:08:23 --> Input Class Initialized
INFO - 2017-01-23 17:08:23 --> Language Class Initialized
INFO - 2017-01-23 17:08:23 --> Loader Class Initialized
INFO - 2017-01-23 17:08:23 --> Database Driver Class Initialized
INFO - 2017-01-23 17:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:08:23 --> Controller Class Initialized
INFO - 2017-01-23 17:08:23 --> Helper loaded: date_helper
DEBUG - 2017-01-23 17:08:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:08:23 --> Helper loaded: url_helper
INFO - 2017-01-23 17:08:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:08:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 17:08:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-23 17:08:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-23 17:08:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:08:23 --> Final output sent to browser
DEBUG - 2017-01-23 17:08:23 --> Total execution time: 0.3790
INFO - 2017-01-23 17:08:39 --> Config Class Initialized
INFO - 2017-01-23 17:08:39 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:08:39 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:08:39 --> Utf8 Class Initialized
INFO - 2017-01-23 17:08:39 --> URI Class Initialized
INFO - 2017-01-23 17:08:39 --> Router Class Initialized
INFO - 2017-01-23 17:08:39 --> Output Class Initialized
INFO - 2017-01-23 17:08:39 --> Security Class Initialized
DEBUG - 2017-01-23 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:08:39 --> Input Class Initialized
INFO - 2017-01-23 17:08:39 --> Language Class Initialized
INFO - 2017-01-23 17:08:39 --> Loader Class Initialized
INFO - 2017-01-23 17:08:39 --> Database Driver Class Initialized
INFO - 2017-01-23 17:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:08:39 --> Controller Class Initialized
INFO - 2017-01-23 17:08:39 --> Helper loaded: date_helper
DEBUG - 2017-01-23 17:08:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:08:39 --> Helper loaded: url_helper
INFO - 2017-01-23 17:08:39 --> Helper loaded: download_helper
INFO - 2017-01-23 17:08:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:08:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 17:08:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-23 17:08:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-23 17:08:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:08:40 --> Final output sent to browser
DEBUG - 2017-01-23 17:08:40 --> Total execution time: 0.8311
INFO - 2017-01-23 17:09:12 --> Config Class Initialized
INFO - 2017-01-23 17:09:12 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:09:12 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:09:12 --> Utf8 Class Initialized
INFO - 2017-01-23 17:09:12 --> URI Class Initialized
INFO - 2017-01-23 17:09:12 --> Router Class Initialized
INFO - 2017-01-23 17:09:12 --> Output Class Initialized
INFO - 2017-01-23 17:09:12 --> Security Class Initialized
DEBUG - 2017-01-23 17:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:09:12 --> Input Class Initialized
INFO - 2017-01-23 17:09:12 --> Language Class Initialized
INFO - 2017-01-23 17:09:12 --> Loader Class Initialized
INFO - 2017-01-23 17:09:12 --> Database Driver Class Initialized
INFO - 2017-01-23 17:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:09:12 --> Controller Class Initialized
INFO - 2017-01-23 17:09:12 --> Helper loaded: date_helper
DEBUG - 2017-01-23 17:09:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:09:12 --> Helper loaded: url_helper
INFO - 2017-01-23 17:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 17:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-23 17:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-23 17:09:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:09:12 --> Final output sent to browser
DEBUG - 2017-01-23 17:09:12 --> Total execution time: 0.2844
INFO - 2017-01-23 17:09:21 --> Config Class Initialized
INFO - 2017-01-23 17:09:21 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:09:21 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:09:21 --> Utf8 Class Initialized
INFO - 2017-01-23 17:09:21 --> URI Class Initialized
INFO - 2017-01-23 17:09:21 --> Router Class Initialized
INFO - 2017-01-23 17:09:21 --> Output Class Initialized
INFO - 2017-01-23 17:09:21 --> Security Class Initialized
DEBUG - 2017-01-23 17:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:09:21 --> Input Class Initialized
INFO - 2017-01-23 17:09:21 --> Language Class Initialized
INFO - 2017-01-23 17:09:21 --> Loader Class Initialized
INFO - 2017-01-23 17:09:21 --> Database Driver Class Initialized
INFO - 2017-01-23 17:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:09:21 --> Controller Class Initialized
INFO - 2017-01-23 17:09:21 --> Helper loaded: date_helper
DEBUG - 2017-01-23 17:09:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:09:21 --> Helper loaded: url_helper
INFO - 2017-01-23 17:09:21 --> Final output sent to browser
DEBUG - 2017-01-23 17:09:21 --> Total execution time: 0.2438
INFO - 2017-01-23 17:09:28 --> Config Class Initialized
INFO - 2017-01-23 17:09:28 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:09:28 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:09:28 --> Utf8 Class Initialized
INFO - 2017-01-23 17:09:28 --> URI Class Initialized
INFO - 2017-01-23 17:09:28 --> Router Class Initialized
INFO - 2017-01-23 17:09:28 --> Output Class Initialized
INFO - 2017-01-23 17:09:28 --> Security Class Initialized
DEBUG - 2017-01-23 17:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:09:28 --> Input Class Initialized
INFO - 2017-01-23 17:09:28 --> Language Class Initialized
INFO - 2017-01-23 17:09:28 --> Loader Class Initialized
INFO - 2017-01-23 17:09:28 --> Database Driver Class Initialized
INFO - 2017-01-23 17:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:09:28 --> Controller Class Initialized
INFO - 2017-01-23 17:09:28 --> Helper loaded: date_helper
DEBUG - 2017-01-23 17:09:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:09:28 --> Helper loaded: url_helper
INFO - 2017-01-23 17:09:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:09:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-23 17:09:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 17:09:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-23 17:09:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-23 17:09:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:09:28 --> Final output sent to browser
DEBUG - 2017-01-23 17:09:28 --> Total execution time: 0.6012
INFO - 2017-01-23 17:09:38 --> Config Class Initialized
INFO - 2017-01-23 17:09:38 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:09:38 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:09:38 --> Utf8 Class Initialized
INFO - 2017-01-23 17:09:38 --> URI Class Initialized
INFO - 2017-01-23 17:09:38 --> Router Class Initialized
INFO - 2017-01-23 17:09:38 --> Output Class Initialized
INFO - 2017-01-23 17:09:38 --> Security Class Initialized
DEBUG - 2017-01-23 17:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:09:38 --> Input Class Initialized
INFO - 2017-01-23 17:09:38 --> Language Class Initialized
INFO - 2017-01-23 17:09:38 --> Loader Class Initialized
INFO - 2017-01-23 17:09:38 --> Config Class Initialized
INFO - 2017-01-23 17:09:38 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:09:38 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:09:38 --> Utf8 Class Initialized
INFO - 2017-01-23 17:09:38 --> URI Class Initialized
INFO - 2017-01-23 17:09:38 --> Database Driver Class Initialized
INFO - 2017-01-23 17:09:38 --> Router Class Initialized
INFO - 2017-01-23 17:09:38 --> Output Class Initialized
INFO - 2017-01-23 17:09:38 --> Security Class Initialized
DEBUG - 2017-01-23 17:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:09:38 --> Input Class Initialized
INFO - 2017-01-23 17:09:38 --> Language Class Initialized
INFO - 2017-01-23 17:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:09:38 --> Controller Class Initialized
INFO - 2017-01-23 17:09:38 --> Helper loaded: date_helper
DEBUG - 2017-01-23 17:09:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:09:38 --> Loader Class Initialized
INFO - 2017-01-23 17:09:38 --> Helper loaded: url_helper
INFO - 2017-01-23 17:09:38 --> Final output sent to browser
DEBUG - 2017-01-23 17:09:38 --> Total execution time: 0.8337
INFO - 2017-01-23 17:09:38 --> Database Driver Class Initialized
INFO - 2017-01-23 17:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:09:38 --> Controller Class Initialized
INFO - 2017-01-23 17:09:38 --> Helper loaded: date_helper
DEBUG - 2017-01-23 17:09:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:09:38 --> Helper loaded: url_helper
INFO - 2017-01-23 17:09:38 --> Final output sent to browser
DEBUG - 2017-01-23 17:09:38 --> Total execution time: 0.3206
INFO - 2017-01-23 17:09:39 --> Config Class Initialized
INFO - 2017-01-23 17:09:39 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:09:39 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:09:39 --> Utf8 Class Initialized
INFO - 2017-01-23 17:09:39 --> URI Class Initialized
INFO - 2017-01-23 17:09:39 --> Router Class Initialized
INFO - 2017-01-23 17:09:39 --> Output Class Initialized
INFO - 2017-01-23 17:09:39 --> Security Class Initialized
DEBUG - 2017-01-23 17:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:09:39 --> Input Class Initialized
INFO - 2017-01-23 17:09:39 --> Language Class Initialized
INFO - 2017-01-23 17:09:39 --> Loader Class Initialized
INFO - 2017-01-23 17:09:39 --> Database Driver Class Initialized
INFO - 2017-01-23 17:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:09:39 --> Controller Class Initialized
INFO - 2017-01-23 17:09:39 --> Helper loaded: date_helper
DEBUG - 2017-01-23 17:09:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:09:39 --> Helper loaded: url_helper
INFO - 2017-01-23 17:09:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:09:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-23 17:09:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 17:09:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-23 17:09:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-23 17:09:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:09:40 --> Final output sent to browser
DEBUG - 2017-01-23 17:09:40 --> Total execution time: 0.2007
INFO - 2017-01-23 17:09:47 --> Config Class Initialized
INFO - 2017-01-23 17:09:47 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:09:47 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:09:47 --> Utf8 Class Initialized
INFO - 2017-01-23 17:09:47 --> URI Class Initialized
INFO - 2017-01-23 17:09:47 --> Router Class Initialized
INFO - 2017-01-23 17:09:47 --> Output Class Initialized
INFO - 2017-01-23 17:09:47 --> Security Class Initialized
DEBUG - 2017-01-23 17:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:09:47 --> Input Class Initialized
INFO - 2017-01-23 17:09:47 --> Language Class Initialized
INFO - 2017-01-23 17:09:47 --> Loader Class Initialized
INFO - 2017-01-23 17:09:47 --> Database Driver Class Initialized
INFO - 2017-01-23 17:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:09:47 --> Controller Class Initialized
INFO - 2017-01-23 17:09:47 --> Upload Class Initialized
INFO - 2017-01-23 17:09:47 --> Helper loaded: date_helper
DEBUG - 2017-01-23 17:09:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:09:47 --> Helper loaded: url_helper
INFO - 2017-01-23 17:09:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 17:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-01-23 17:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-01-23 17:09:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-23 17:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:09:48 --> Final output sent to browser
DEBUG - 2017-01-23 17:09:48 --> Total execution time: 0.9554
INFO - 2017-01-23 17:09:48 --> Config Class Initialized
INFO - 2017-01-23 17:09:48 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:09:48 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:09:48 --> Utf8 Class Initialized
INFO - 2017-01-23 17:09:48 --> URI Class Initialized
INFO - 2017-01-23 17:09:48 --> Router Class Initialized
INFO - 2017-01-23 17:09:48 --> Output Class Initialized
INFO - 2017-01-23 17:09:48 --> Security Class Initialized
DEBUG - 2017-01-23 17:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:09:48 --> Input Class Initialized
INFO - 2017-01-23 17:09:48 --> Language Class Initialized
INFO - 2017-01-23 17:09:48 --> Loader Class Initialized
INFO - 2017-01-23 17:09:48 --> Database Driver Class Initialized
INFO - 2017-01-23 17:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:09:48 --> Controller Class Initialized
INFO - 2017-01-23 17:09:48 --> Upload Class Initialized
INFO - 2017-01-23 17:09:48 --> Helper loaded: date_helper
DEBUG - 2017-01-23 17:09:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:09:48 --> Helper loaded: url_helper
INFO - 2017-01-23 17:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 17:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-01-23 17:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-01-23 17:09:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-23 17:09:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:09:48 --> Final output sent to browser
DEBUG - 2017-01-23 17:09:48 --> Total execution time: 0.3023
INFO - 2017-01-23 17:09:49 --> Config Class Initialized
INFO - 2017-01-23 17:09:49 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:09:49 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:09:49 --> Utf8 Class Initialized
INFO - 2017-01-23 17:09:49 --> URI Class Initialized
INFO - 2017-01-23 17:09:49 --> Router Class Initialized
INFO - 2017-01-23 17:09:49 --> Output Class Initialized
INFO - 2017-01-23 17:09:49 --> Security Class Initialized
DEBUG - 2017-01-23 17:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:09:49 --> Input Class Initialized
INFO - 2017-01-23 17:09:49 --> Language Class Initialized
INFO - 2017-01-23 17:09:49 --> Loader Class Initialized
INFO - 2017-01-23 17:09:49 --> Database Driver Class Initialized
INFO - 2017-01-23 17:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:09:49 --> Controller Class Initialized
INFO - 2017-01-23 17:09:49 --> Upload Class Initialized
INFO - 2017-01-23 17:09:49 --> Helper loaded: date_helper
DEBUG - 2017-01-23 17:09:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:09:49 --> Helper loaded: url_helper
INFO - 2017-01-23 17:09:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:09:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 17:09:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-01-23 17:09:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-01-23 17:09:49 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-23 17:09:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:09:49 --> Final output sent to browser
DEBUG - 2017-01-23 17:09:49 --> Total execution time: 0.2471
INFO - 2017-01-23 17:21:44 --> Config Class Initialized
INFO - 2017-01-23 17:21:45 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:21:45 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:21:45 --> Utf8 Class Initialized
INFO - 2017-01-23 17:21:45 --> URI Class Initialized
DEBUG - 2017-01-23 17:21:45 --> No URI present. Default controller set.
INFO - 2017-01-23 17:21:45 --> Router Class Initialized
INFO - 2017-01-23 17:21:45 --> Output Class Initialized
INFO - 2017-01-23 17:21:45 --> Security Class Initialized
DEBUG - 2017-01-23 17:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:21:45 --> Input Class Initialized
INFO - 2017-01-23 17:21:45 --> Language Class Initialized
INFO - 2017-01-23 17:21:45 --> Loader Class Initialized
INFO - 2017-01-23 17:21:45 --> Database Driver Class Initialized
INFO - 2017-01-23 17:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:21:45 --> Controller Class Initialized
INFO - 2017-01-23 17:21:45 --> Helper loaded: url_helper
DEBUG - 2017-01-23 17:21:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:21:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:21:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 17:21:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 17:21:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:21:45 --> Final output sent to browser
DEBUG - 2017-01-23 17:21:45 --> Total execution time: 2.2925
INFO - 2017-01-23 17:25:23 --> Config Class Initialized
INFO - 2017-01-23 17:25:23 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:25:23 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:25:23 --> Utf8 Class Initialized
INFO - 2017-01-23 17:25:23 --> URI Class Initialized
INFO - 2017-01-23 17:25:23 --> Router Class Initialized
INFO - 2017-01-23 17:25:23 --> Output Class Initialized
INFO - 2017-01-23 17:25:23 --> Security Class Initialized
DEBUG - 2017-01-23 17:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:25:23 --> Input Class Initialized
INFO - 2017-01-23 17:25:23 --> Language Class Initialized
INFO - 2017-01-23 17:25:23 --> Loader Class Initialized
INFO - 2017-01-23 17:25:23 --> Database Driver Class Initialized
INFO - 2017-01-23 17:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:25:23 --> Controller Class Initialized
INFO - 2017-01-23 17:25:23 --> Helper loaded: url_helper
DEBUG - 2017-01-23 17:25:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:25:23 --> Final output sent to browser
DEBUG - 2017-01-23 17:25:23 --> Total execution time: 0.0955
INFO - 2017-01-23 17:36:35 --> Config Class Initialized
INFO - 2017-01-23 17:36:35 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:36:35 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:36:35 --> Utf8 Class Initialized
INFO - 2017-01-23 17:36:35 --> URI Class Initialized
DEBUG - 2017-01-23 17:36:35 --> No URI present. Default controller set.
INFO - 2017-01-23 17:36:35 --> Router Class Initialized
INFO - 2017-01-23 17:36:35 --> Output Class Initialized
INFO - 2017-01-23 17:36:35 --> Security Class Initialized
DEBUG - 2017-01-23 17:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:36:35 --> Input Class Initialized
INFO - 2017-01-23 17:36:35 --> Language Class Initialized
INFO - 2017-01-23 17:36:35 --> Loader Class Initialized
INFO - 2017-01-23 17:36:35 --> Database Driver Class Initialized
INFO - 2017-01-23 17:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:36:35 --> Controller Class Initialized
INFO - 2017-01-23 17:36:35 --> Helper loaded: url_helper
DEBUG - 2017-01-23 17:36:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:36:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:36:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 17:36:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 17:36:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:36:35 --> Final output sent to browser
DEBUG - 2017-01-23 17:36:35 --> Total execution time: 0.1537
INFO - 2017-01-23 17:36:38 --> Config Class Initialized
INFO - 2017-01-23 17:36:38 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:36:38 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:36:38 --> Utf8 Class Initialized
INFO - 2017-01-23 17:36:38 --> URI Class Initialized
INFO - 2017-01-23 17:36:38 --> Router Class Initialized
INFO - 2017-01-23 17:36:38 --> Output Class Initialized
INFO - 2017-01-23 17:36:38 --> Security Class Initialized
DEBUG - 2017-01-23 17:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:36:38 --> Input Class Initialized
INFO - 2017-01-23 17:36:38 --> Language Class Initialized
INFO - 2017-01-23 17:36:38 --> Loader Class Initialized
INFO - 2017-01-23 17:36:38 --> Database Driver Class Initialized
INFO - 2017-01-23 17:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:36:38 --> Controller Class Initialized
INFO - 2017-01-23 17:36:38 --> Helper loaded: url_helper
DEBUG - 2017-01-23 17:36:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:36:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:36:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 17:36:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 17:36:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:36:38 --> Final output sent to browser
DEBUG - 2017-01-23 17:36:38 --> Total execution time: 0.0258
INFO - 2017-01-23 17:36:41 --> Config Class Initialized
INFO - 2017-01-23 17:36:41 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:36:41 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:36:41 --> Utf8 Class Initialized
INFO - 2017-01-23 17:36:41 --> URI Class Initialized
INFO - 2017-01-23 17:36:41 --> Router Class Initialized
INFO - 2017-01-23 17:36:41 --> Output Class Initialized
INFO - 2017-01-23 17:36:41 --> Security Class Initialized
DEBUG - 2017-01-23 17:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:36:41 --> Input Class Initialized
INFO - 2017-01-23 17:36:41 --> Language Class Initialized
INFO - 2017-01-23 17:36:41 --> Loader Class Initialized
INFO - 2017-01-23 17:36:41 --> Database Driver Class Initialized
INFO - 2017-01-23 17:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:36:41 --> Controller Class Initialized
INFO - 2017-01-23 17:36:41 --> Helper loaded: url_helper
DEBUG - 2017-01-23 17:36:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:36:43 --> Config Class Initialized
INFO - 2017-01-23 17:36:43 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:36:43 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:36:43 --> Utf8 Class Initialized
INFO - 2017-01-23 17:36:43 --> URI Class Initialized
INFO - 2017-01-23 17:36:43 --> Router Class Initialized
INFO - 2017-01-23 17:36:43 --> Output Class Initialized
INFO - 2017-01-23 17:36:43 --> Security Class Initialized
DEBUG - 2017-01-23 17:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:36:43 --> Input Class Initialized
INFO - 2017-01-23 17:36:43 --> Language Class Initialized
INFO - 2017-01-23 17:36:43 --> Loader Class Initialized
INFO - 2017-01-23 17:36:43 --> Database Driver Class Initialized
INFO - 2017-01-23 17:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:36:43 --> Controller Class Initialized
INFO - 2017-01-23 17:36:43 --> Helper loaded: date_helper
DEBUG - 2017-01-23 17:36:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:36:43 --> Helper loaded: url_helper
INFO - 2017-01-23 17:36:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:36:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 17:36:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-23 17:36:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-23 17:36:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:36:43 --> Final output sent to browser
DEBUG - 2017-01-23 17:36:43 --> Total execution time: 0.0591
INFO - 2017-01-23 17:36:43 --> Config Class Initialized
INFO - 2017-01-23 17:36:43 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:36:43 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:36:43 --> Utf8 Class Initialized
INFO - 2017-01-23 17:36:43 --> URI Class Initialized
INFO - 2017-01-23 17:36:43 --> Router Class Initialized
INFO - 2017-01-23 17:36:43 --> Output Class Initialized
INFO - 2017-01-23 17:36:43 --> Security Class Initialized
DEBUG - 2017-01-23 17:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:36:43 --> Input Class Initialized
INFO - 2017-01-23 17:36:43 --> Language Class Initialized
INFO - 2017-01-23 17:36:43 --> Loader Class Initialized
INFO - 2017-01-23 17:36:43 --> Database Driver Class Initialized
INFO - 2017-01-23 17:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:36:43 --> Controller Class Initialized
INFO - 2017-01-23 17:36:43 --> Helper loaded: url_helper
DEBUG - 2017-01-23 17:36:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:36:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:36:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 17:36:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 17:36:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:36:43 --> Final output sent to browser
DEBUG - 2017-01-23 17:36:43 --> Total execution time: 0.0146
INFO - 2017-01-23 17:36:44 --> Config Class Initialized
INFO - 2017-01-23 17:36:44 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:36:44 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:36:44 --> Utf8 Class Initialized
INFO - 2017-01-23 17:36:44 --> URI Class Initialized
INFO - 2017-01-23 17:36:44 --> Router Class Initialized
INFO - 2017-01-23 17:36:44 --> Output Class Initialized
INFO - 2017-01-23 17:36:44 --> Security Class Initialized
DEBUG - 2017-01-23 17:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:36:44 --> Input Class Initialized
INFO - 2017-01-23 17:36:44 --> Language Class Initialized
INFO - 2017-01-23 17:36:44 --> Loader Class Initialized
INFO - 2017-01-23 17:36:44 --> Database Driver Class Initialized
INFO - 2017-01-23 17:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:36:44 --> Controller Class Initialized
INFO - 2017-01-23 17:36:44 --> Helper loaded: date_helper
DEBUG - 2017-01-23 17:36:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:36:44 --> Helper loaded: url_helper
INFO - 2017-01-23 17:36:45 --> Helper loaded: download_helper
INFO - 2017-01-23 17:36:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:36:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 17:36:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-23 17:36:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-23 17:36:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:36:45 --> Final output sent to browser
DEBUG - 2017-01-23 17:36:45 --> Total execution time: 0.3478
INFO - 2017-01-23 17:36:48 --> Config Class Initialized
INFO - 2017-01-23 17:36:48 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:36:48 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:36:48 --> Utf8 Class Initialized
INFO - 2017-01-23 17:36:48 --> URI Class Initialized
INFO - 2017-01-23 17:36:48 --> Router Class Initialized
INFO - 2017-01-23 17:36:48 --> Output Class Initialized
INFO - 2017-01-23 17:36:48 --> Security Class Initialized
DEBUG - 2017-01-23 17:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:36:48 --> Input Class Initialized
INFO - 2017-01-23 17:36:48 --> Language Class Initialized
INFO - 2017-01-23 17:36:48 --> Loader Class Initialized
INFO - 2017-01-23 17:36:48 --> Database Driver Class Initialized
INFO - 2017-01-23 17:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:36:48 --> Controller Class Initialized
INFO - 2017-01-23 17:36:48 --> Helper loaded: url_helper
DEBUG - 2017-01-23 17:36:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:36:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:36:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 17:36:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 17:36:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:36:48 --> Final output sent to browser
DEBUG - 2017-01-23 17:36:48 --> Total execution time: 0.0140
INFO - 2017-01-23 17:37:56 --> Config Class Initialized
INFO - 2017-01-23 17:37:56 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:37:56 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:37:56 --> Utf8 Class Initialized
INFO - 2017-01-23 17:37:56 --> URI Class Initialized
INFO - 2017-01-23 17:37:56 --> Router Class Initialized
INFO - 2017-01-23 17:37:56 --> Output Class Initialized
INFO - 2017-01-23 17:37:56 --> Security Class Initialized
DEBUG - 2017-01-23 17:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:37:56 --> Input Class Initialized
INFO - 2017-01-23 17:37:56 --> Language Class Initialized
INFO - 2017-01-23 17:37:56 --> Loader Class Initialized
INFO - 2017-01-23 17:37:56 --> Database Driver Class Initialized
INFO - 2017-01-23 17:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:37:56 --> Controller Class Initialized
INFO - 2017-01-23 17:37:56 --> Helper loaded: date_helper
DEBUG - 2017-01-23 17:37:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:37:56 --> Helper loaded: url_helper
INFO - 2017-01-23 17:37:56 --> Helper loaded: download_helper
INFO - 2017-01-23 17:37:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:37:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 17:37:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-23 17:37:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-23 17:37:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:37:56 --> Final output sent to browser
DEBUG - 2017-01-23 17:37:56 --> Total execution time: 0.0254
INFO - 2017-01-23 17:38:00 --> Config Class Initialized
INFO - 2017-01-23 17:38:00 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:38:00 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:38:00 --> Utf8 Class Initialized
INFO - 2017-01-23 17:38:00 --> URI Class Initialized
INFO - 2017-01-23 17:38:00 --> Router Class Initialized
INFO - 2017-01-23 17:38:00 --> Output Class Initialized
INFO - 2017-01-23 17:38:00 --> Security Class Initialized
DEBUG - 2017-01-23 17:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:38:00 --> Input Class Initialized
INFO - 2017-01-23 17:38:00 --> Language Class Initialized
INFO - 2017-01-23 17:38:00 --> Loader Class Initialized
INFO - 2017-01-23 17:38:00 --> Database Driver Class Initialized
INFO - 2017-01-23 17:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:38:00 --> Controller Class Initialized
INFO - 2017-01-23 17:38:00 --> Helper loaded: url_helper
DEBUG - 2017-01-23 17:38:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:38:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:38:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 17:38:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 17:38:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:38:00 --> Final output sent to browser
DEBUG - 2017-01-23 17:38:00 --> Total execution time: 0.0153
INFO - 2017-01-23 17:51:43 --> Config Class Initialized
INFO - 2017-01-23 17:51:43 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:51:43 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:51:43 --> Utf8 Class Initialized
INFO - 2017-01-23 17:51:43 --> URI Class Initialized
INFO - 2017-01-23 17:51:43 --> Router Class Initialized
INFO - 2017-01-23 17:51:43 --> Output Class Initialized
INFO - 2017-01-23 17:51:43 --> Security Class Initialized
DEBUG - 2017-01-23 17:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:51:43 --> Input Class Initialized
INFO - 2017-01-23 17:51:43 --> Language Class Initialized
INFO - 2017-01-23 17:51:43 --> Loader Class Initialized
INFO - 2017-01-23 17:51:43 --> Database Driver Class Initialized
INFO - 2017-01-23 17:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:51:43 --> Controller Class Initialized
INFO - 2017-01-23 17:51:43 --> Helper loaded: date_helper
DEBUG - 2017-01-23 17:51:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:51:43 --> Helper loaded: url_helper
INFO - 2017-01-23 17:51:43 --> Helper loaded: download_helper
INFO - 2017-01-23 17:51:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:51:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 17:51:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-23 17:51:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-23 17:51:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:51:43 --> Final output sent to browser
DEBUG - 2017-01-23 17:51:43 --> Total execution time: 0.2192
INFO - 2017-01-23 17:51:52 --> Config Class Initialized
INFO - 2017-01-23 17:51:52 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:51:52 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:51:52 --> Utf8 Class Initialized
INFO - 2017-01-23 17:51:52 --> URI Class Initialized
INFO - 2017-01-23 17:51:52 --> Router Class Initialized
INFO - 2017-01-23 17:51:52 --> Output Class Initialized
INFO - 2017-01-23 17:51:52 --> Security Class Initialized
DEBUG - 2017-01-23 17:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:51:52 --> Input Class Initialized
INFO - 2017-01-23 17:51:52 --> Language Class Initialized
INFO - 2017-01-23 17:51:52 --> Loader Class Initialized
INFO - 2017-01-23 17:51:52 --> Database Driver Class Initialized
INFO - 2017-01-23 17:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:51:52 --> Controller Class Initialized
INFO - 2017-01-23 17:51:52 --> Helper loaded: url_helper
DEBUG - 2017-01-23 17:51:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 17:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 17:51:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:51:52 --> Final output sent to browser
DEBUG - 2017-01-23 17:51:52 --> Total execution time: 0.0545
INFO - 2017-01-23 17:52:15 --> Config Class Initialized
INFO - 2017-01-23 17:52:15 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:52:15 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:52:16 --> Utf8 Class Initialized
INFO - 2017-01-23 17:52:16 --> URI Class Initialized
INFO - 2017-01-23 17:52:16 --> Router Class Initialized
INFO - 2017-01-23 17:52:16 --> Output Class Initialized
INFO - 2017-01-23 17:52:17 --> Security Class Initialized
DEBUG - 2017-01-23 17:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:52:17 --> Input Class Initialized
INFO - 2017-01-23 17:52:17 --> Language Class Initialized
INFO - 2017-01-23 17:52:17 --> Loader Class Initialized
INFO - 2017-01-23 17:52:17 --> Database Driver Class Initialized
INFO - 2017-01-23 17:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:52:18 --> Controller Class Initialized
INFO - 2017-01-23 17:52:18 --> Helper loaded: date_helper
DEBUG - 2017-01-23 17:52:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:52:18 --> Helper loaded: url_helper
INFO - 2017-01-23 17:52:18 --> Helper loaded: download_helper
INFO - 2017-01-23 17:52:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:52:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 17:52:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-23 17:52:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-23 17:52:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:52:18 --> Final output sent to browser
DEBUG - 2017-01-23 17:52:18 --> Total execution time: 9.7627
INFO - 2017-01-23 17:52:25 --> Config Class Initialized
INFO - 2017-01-23 17:52:25 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:52:25 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:52:25 --> Utf8 Class Initialized
INFO - 2017-01-23 17:52:25 --> URI Class Initialized
INFO - 2017-01-23 17:52:25 --> Router Class Initialized
INFO - 2017-01-23 17:52:25 --> Output Class Initialized
INFO - 2017-01-23 17:52:25 --> Security Class Initialized
DEBUG - 2017-01-23 17:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:52:25 --> Input Class Initialized
INFO - 2017-01-23 17:52:25 --> Language Class Initialized
INFO - 2017-01-23 17:52:25 --> Loader Class Initialized
INFO - 2017-01-23 17:52:25 --> Database Driver Class Initialized
INFO - 2017-01-23 17:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:52:25 --> Controller Class Initialized
INFO - 2017-01-23 17:52:25 --> Helper loaded: url_helper
DEBUG - 2017-01-23 17:52:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:52:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:52:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 17:52:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 17:52:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:52:25 --> Final output sent to browser
DEBUG - 2017-01-23 17:52:25 --> Total execution time: 0.3233
INFO - 2017-01-23 17:52:36 --> Config Class Initialized
INFO - 2017-01-23 17:52:36 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:52:36 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:52:36 --> Utf8 Class Initialized
INFO - 2017-01-23 17:52:36 --> URI Class Initialized
INFO - 2017-01-23 17:52:36 --> Router Class Initialized
INFO - 2017-01-23 17:52:36 --> Output Class Initialized
INFO - 2017-01-23 17:52:36 --> Security Class Initialized
DEBUG - 2017-01-23 17:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:52:36 --> Input Class Initialized
INFO - 2017-01-23 17:52:36 --> Language Class Initialized
INFO - 2017-01-23 17:52:36 --> Loader Class Initialized
INFO - 2017-01-23 17:52:36 --> Database Driver Class Initialized
INFO - 2017-01-23 17:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:52:36 --> Controller Class Initialized
INFO - 2017-01-23 17:52:36 --> Helper loaded: date_helper
DEBUG - 2017-01-23 17:52:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:52:36 --> Helper loaded: url_helper
INFO - 2017-01-23 17:52:36 --> Helper loaded: download_helper
INFO - 2017-01-23 17:52:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:52:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 17:52:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-23 17:52:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-23 17:52:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:52:37 --> Final output sent to browser
DEBUG - 2017-01-23 17:52:37 --> Total execution time: 0.2322
INFO - 2017-01-23 17:52:38 --> Config Class Initialized
INFO - 2017-01-23 17:52:38 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:52:38 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:52:38 --> Utf8 Class Initialized
INFO - 2017-01-23 17:52:38 --> URI Class Initialized
INFO - 2017-01-23 17:52:38 --> Router Class Initialized
INFO - 2017-01-23 17:52:38 --> Output Class Initialized
INFO - 2017-01-23 17:52:38 --> Security Class Initialized
DEBUG - 2017-01-23 17:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:52:38 --> Input Class Initialized
INFO - 2017-01-23 17:52:38 --> Language Class Initialized
INFO - 2017-01-23 17:52:38 --> Loader Class Initialized
INFO - 2017-01-23 17:52:38 --> Database Driver Class Initialized
INFO - 2017-01-23 17:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:52:38 --> Controller Class Initialized
INFO - 2017-01-23 17:52:38 --> Helper loaded: url_helper
DEBUG - 2017-01-23 17:52:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:52:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:52:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 17:52:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 17:52:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:52:39 --> Final output sent to browser
DEBUG - 2017-01-23 17:52:39 --> Total execution time: 0.1819
INFO - 2017-01-23 17:55:46 --> Config Class Initialized
INFO - 2017-01-23 17:55:46 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:55:46 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:55:46 --> Utf8 Class Initialized
INFO - 2017-01-23 17:55:47 --> URI Class Initialized
DEBUG - 2017-01-23 17:55:47 --> No URI present. Default controller set.
INFO - 2017-01-23 17:55:47 --> Router Class Initialized
INFO - 2017-01-23 17:55:47 --> Output Class Initialized
INFO - 2017-01-23 17:55:47 --> Security Class Initialized
DEBUG - 2017-01-23 17:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:55:47 --> Input Class Initialized
INFO - 2017-01-23 17:55:47 --> Language Class Initialized
INFO - 2017-01-23 17:55:47 --> Loader Class Initialized
INFO - 2017-01-23 17:55:47 --> Database Driver Class Initialized
INFO - 2017-01-23 17:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:55:47 --> Controller Class Initialized
INFO - 2017-01-23 17:55:47 --> Helper loaded: url_helper
DEBUG - 2017-01-23 17:55:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:55:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:55:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 17:55:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 17:55:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:55:47 --> Final output sent to browser
DEBUG - 2017-01-23 17:55:47 --> Total execution time: 8.3886
INFO - 2017-01-23 17:56:02 --> Config Class Initialized
INFO - 2017-01-23 17:56:02 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:56:02 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:56:02 --> Utf8 Class Initialized
INFO - 2017-01-23 17:56:02 --> URI Class Initialized
INFO - 2017-01-23 17:56:02 --> Router Class Initialized
INFO - 2017-01-23 17:56:02 --> Output Class Initialized
INFO - 2017-01-23 17:56:02 --> Security Class Initialized
DEBUG - 2017-01-23 17:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:56:02 --> Input Class Initialized
INFO - 2017-01-23 17:56:02 --> Language Class Initialized
INFO - 2017-01-23 17:56:02 --> Loader Class Initialized
INFO - 2017-01-23 17:56:02 --> Database Driver Class Initialized
INFO - 2017-01-23 17:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:56:02 --> Controller Class Initialized
INFO - 2017-01-23 17:56:02 --> Helper loaded: url_helper
DEBUG - 2017-01-23 17:56:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:56:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:56:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 17:56:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 17:56:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:56:03 --> Final output sent to browser
DEBUG - 2017-01-23 17:56:03 --> Total execution time: 0.1466
INFO - 2017-01-23 17:57:51 --> Config Class Initialized
INFO - 2017-01-23 17:57:51 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:57:51 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:57:51 --> Utf8 Class Initialized
INFO - 2017-01-23 17:57:51 --> URI Class Initialized
INFO - 2017-01-23 17:57:51 --> Router Class Initialized
INFO - 2017-01-23 17:57:51 --> Output Class Initialized
INFO - 2017-01-23 17:57:51 --> Security Class Initialized
DEBUG - 2017-01-23 17:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:57:51 --> Input Class Initialized
INFO - 2017-01-23 17:57:51 --> Language Class Initialized
INFO - 2017-01-23 17:57:51 --> Loader Class Initialized
INFO - 2017-01-23 17:57:51 --> Database Driver Class Initialized
INFO - 2017-01-23 17:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:57:51 --> Controller Class Initialized
INFO - 2017-01-23 17:57:51 --> Helper loaded: date_helper
DEBUG - 2017-01-23 17:57:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:57:51 --> Helper loaded: url_helper
INFO - 2017-01-23 17:57:51 --> Helper loaded: download_helper
INFO - 2017-01-23 17:57:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:57:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 17:57:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-23 17:57:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-23 17:57:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:57:51 --> Final output sent to browser
DEBUG - 2017-01-23 17:57:51 --> Total execution time: 0.2223
INFO - 2017-01-23 17:57:51 --> Config Class Initialized
INFO - 2017-01-23 17:57:51 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:57:51 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:57:51 --> Utf8 Class Initialized
INFO - 2017-01-23 17:57:51 --> URI Class Initialized
INFO - 2017-01-23 17:57:51 --> Router Class Initialized
INFO - 2017-01-23 17:57:51 --> Output Class Initialized
INFO - 2017-01-23 17:57:51 --> Security Class Initialized
DEBUG - 2017-01-23 17:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:57:51 --> Input Class Initialized
INFO - 2017-01-23 17:57:51 --> Language Class Initialized
INFO - 2017-01-23 17:57:51 --> Loader Class Initialized
INFO - 2017-01-23 17:57:51 --> Database Driver Class Initialized
INFO - 2017-01-23 17:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:57:51 --> Controller Class Initialized
INFO - 2017-01-23 17:57:51 --> Helper loaded: url_helper
DEBUG - 2017-01-23 17:57:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:57:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:57:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 17:57:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 17:57:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:57:51 --> Final output sent to browser
DEBUG - 2017-01-23 17:57:51 --> Total execution time: 0.0207
INFO - 2017-01-23 17:59:40 --> Config Class Initialized
INFO - 2017-01-23 17:59:40 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:59:40 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:59:40 --> Utf8 Class Initialized
INFO - 2017-01-23 17:59:40 --> URI Class Initialized
INFO - 2017-01-23 17:59:40 --> Router Class Initialized
INFO - 2017-01-23 17:59:40 --> Output Class Initialized
INFO - 2017-01-23 17:59:40 --> Security Class Initialized
DEBUG - 2017-01-23 17:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:59:40 --> Input Class Initialized
INFO - 2017-01-23 17:59:40 --> Language Class Initialized
INFO - 2017-01-23 17:59:40 --> Loader Class Initialized
INFO - 2017-01-23 17:59:40 --> Database Driver Class Initialized
INFO - 2017-01-23 17:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:59:40 --> Controller Class Initialized
INFO - 2017-01-23 17:59:40 --> Helper loaded: date_helper
DEBUG - 2017-01-23 17:59:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:59:40 --> Helper loaded: url_helper
INFO - 2017-01-23 17:59:40 --> Helper loaded: download_helper
INFO - 2017-01-23 17:59:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:59:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 17:59:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-23 17:59:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-23 17:59:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:59:40 --> Final output sent to browser
DEBUG - 2017-01-23 17:59:40 --> Total execution time: 0.2188
INFO - 2017-01-23 17:59:41 --> Config Class Initialized
INFO - 2017-01-23 17:59:41 --> Hooks Class Initialized
DEBUG - 2017-01-23 17:59:41 --> UTF-8 Support Enabled
INFO - 2017-01-23 17:59:41 --> Utf8 Class Initialized
INFO - 2017-01-23 17:59:41 --> URI Class Initialized
INFO - 2017-01-23 17:59:41 --> Router Class Initialized
INFO - 2017-01-23 17:59:41 --> Output Class Initialized
INFO - 2017-01-23 17:59:41 --> Security Class Initialized
DEBUG - 2017-01-23 17:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 17:59:41 --> Input Class Initialized
INFO - 2017-01-23 17:59:41 --> Language Class Initialized
INFO - 2017-01-23 17:59:41 --> Loader Class Initialized
INFO - 2017-01-23 17:59:41 --> Database Driver Class Initialized
INFO - 2017-01-23 17:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 17:59:41 --> Controller Class Initialized
INFO - 2017-01-23 17:59:41 --> Helper loaded: url_helper
DEBUG - 2017-01-23 17:59:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 17:59:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 17:59:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 17:59:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 17:59:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 17:59:41 --> Final output sent to browser
DEBUG - 2017-01-23 17:59:41 --> Total execution time: 0.1408
INFO - 2017-01-23 18:00:21 --> Config Class Initialized
INFO - 2017-01-23 18:00:21 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:00:21 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:00:21 --> Utf8 Class Initialized
INFO - 2017-01-23 18:00:21 --> URI Class Initialized
INFO - 2017-01-23 18:00:21 --> Router Class Initialized
INFO - 2017-01-23 18:00:21 --> Output Class Initialized
INFO - 2017-01-23 18:00:21 --> Security Class Initialized
DEBUG - 2017-01-23 18:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:00:21 --> Input Class Initialized
INFO - 2017-01-23 18:00:21 --> Language Class Initialized
INFO - 2017-01-23 18:00:22 --> Loader Class Initialized
INFO - 2017-01-23 18:00:22 --> Database Driver Class Initialized
INFO - 2017-01-23 18:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:00:22 --> Controller Class Initialized
INFO - 2017-01-23 18:00:22 --> Helper loaded: date_helper
DEBUG - 2017-01-23 18:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:00:22 --> Helper loaded: url_helper
INFO - 2017-01-23 18:00:22 --> Helper loaded: download_helper
INFO - 2017-01-23 18:00:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:00:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 18:00:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-23 18:00:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-23 18:00:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:00:22 --> Final output sent to browser
DEBUG - 2017-01-23 18:00:22 --> Total execution time: 0.2241
INFO - 2017-01-23 18:00:23 --> Config Class Initialized
INFO - 2017-01-23 18:00:23 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:00:23 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:00:23 --> Utf8 Class Initialized
INFO - 2017-01-23 18:00:23 --> URI Class Initialized
INFO - 2017-01-23 18:00:23 --> Router Class Initialized
INFO - 2017-01-23 18:00:23 --> Output Class Initialized
INFO - 2017-01-23 18:00:23 --> Security Class Initialized
DEBUG - 2017-01-23 18:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:00:23 --> Input Class Initialized
INFO - 2017-01-23 18:00:23 --> Language Class Initialized
INFO - 2017-01-23 18:00:23 --> Loader Class Initialized
INFO - 2017-01-23 18:00:23 --> Database Driver Class Initialized
INFO - 2017-01-23 18:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:00:23 --> Controller Class Initialized
INFO - 2017-01-23 18:00:23 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:00:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:00:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:00:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:00:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:00:23 --> Final output sent to browser
DEBUG - 2017-01-23 18:00:23 --> Total execution time: 0.1715
INFO - 2017-01-23 18:00:28 --> Config Class Initialized
INFO - 2017-01-23 18:00:28 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:00:28 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:00:28 --> Utf8 Class Initialized
INFO - 2017-01-23 18:00:29 --> URI Class Initialized
INFO - 2017-01-23 18:00:29 --> Router Class Initialized
INFO - 2017-01-23 18:00:29 --> Output Class Initialized
INFO - 2017-01-23 18:00:29 --> Security Class Initialized
DEBUG - 2017-01-23 18:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:00:29 --> Input Class Initialized
INFO - 2017-01-23 18:00:29 --> Language Class Initialized
INFO - 2017-01-23 18:00:29 --> Loader Class Initialized
INFO - 2017-01-23 18:00:29 --> Database Driver Class Initialized
INFO - 2017-01-23 18:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:00:29 --> Controller Class Initialized
INFO - 2017-01-23 18:00:29 --> Helper loaded: date_helper
INFO - 2017-01-23 18:00:29 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:00:29 --> Helper loaded: form_helper
INFO - 2017-01-23 18:00:29 --> Form Validation Class Initialized
ERROR - 2017-01-23 18:00:29 --> Query error: Column 'lugar_1' cannot be null - Invalid query: INSERT INTO `tbl_registro_lugares` (`lugar_1`, `lugar_2`, `id_graduacion`, `id_persona`, `id_tipo_lugar`, `numero_infantes`) VALUES (NULL, '0', '28', '19', '1', '5')
INFO - 2017-01-23 18:00:29 --> Language file loaded: language/english/db_lang.php
INFO - 2017-01-23 18:00:32 --> Config Class Initialized
INFO - 2017-01-23 18:00:32 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:00:32 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:00:32 --> Utf8 Class Initialized
INFO - 2017-01-23 18:00:32 --> URI Class Initialized
INFO - 2017-01-23 18:00:32 --> Router Class Initialized
INFO - 2017-01-23 18:00:32 --> Output Class Initialized
INFO - 2017-01-23 18:00:32 --> Security Class Initialized
DEBUG - 2017-01-23 18:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:00:32 --> Input Class Initialized
INFO - 2017-01-23 18:00:32 --> Language Class Initialized
INFO - 2017-01-23 18:00:32 --> Loader Class Initialized
INFO - 2017-01-23 18:00:32 --> Database Driver Class Initialized
INFO - 2017-01-23 18:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:00:32 --> Controller Class Initialized
INFO - 2017-01-23 18:00:32 --> Helper loaded: date_helper
INFO - 2017-01-23 18:00:32 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:00:32 --> Helper loaded: form_helper
INFO - 2017-01-23 18:00:32 --> Form Validation Class Initialized
ERROR - 2017-01-23 18:00:32 --> Query error: Column 'lugar_1' cannot be null - Invalid query: INSERT INTO `tbl_registro_lugares` (`lugar_1`, `lugar_2`, `id_graduacion`, `id_persona`, `id_tipo_lugar`, `numero_infantes`) VALUES (NULL, '0', '28', '19', '1', '5')
INFO - 2017-01-23 18:00:32 --> Language file loaded: language/english/db_lang.php
INFO - 2017-01-23 18:00:35 --> Config Class Initialized
INFO - 2017-01-23 18:00:35 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:00:35 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:00:35 --> Utf8 Class Initialized
INFO - 2017-01-23 18:00:35 --> URI Class Initialized
INFO - 2017-01-23 18:00:35 --> Router Class Initialized
INFO - 2017-01-23 18:00:35 --> Output Class Initialized
INFO - 2017-01-23 18:00:35 --> Security Class Initialized
DEBUG - 2017-01-23 18:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:00:35 --> Input Class Initialized
INFO - 2017-01-23 18:00:35 --> Language Class Initialized
INFO - 2017-01-23 18:00:35 --> Loader Class Initialized
INFO - 2017-01-23 18:00:35 --> Database Driver Class Initialized
INFO - 2017-01-23 18:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:00:35 --> Controller Class Initialized
INFO - 2017-01-23 18:00:35 --> Helper loaded: date_helper
INFO - 2017-01-23 18:00:35 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:00:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:00:36 --> Helper loaded: form_helper
INFO - 2017-01-23 18:00:36 --> Form Validation Class Initialized
ERROR - 2017-01-23 18:00:36 --> Query error: Column 'lugar_1' cannot be null - Invalid query: INSERT INTO `tbl_registro_lugares` (`lugar_1`, `lugar_2`, `id_graduacion`, `id_persona`, `id_tipo_lugar`, `numero_infantes`) VALUES (NULL, '0', '28', '19', '1', '5')
INFO - 2017-01-23 18:00:36 --> Language file loaded: language/english/db_lang.php
INFO - 2017-01-23 18:01:00 --> Config Class Initialized
INFO - 2017-01-23 18:01:00 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:01:00 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:01:00 --> Utf8 Class Initialized
INFO - 2017-01-23 18:01:00 --> URI Class Initialized
INFO - 2017-01-23 18:01:00 --> Router Class Initialized
INFO - 2017-01-23 18:01:00 --> Output Class Initialized
INFO - 2017-01-23 18:01:00 --> Security Class Initialized
DEBUG - 2017-01-23 18:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:01:00 --> Input Class Initialized
INFO - 2017-01-23 18:01:00 --> Language Class Initialized
INFO - 2017-01-23 18:01:00 --> Loader Class Initialized
INFO - 2017-01-23 18:01:00 --> Database Driver Class Initialized
INFO - 2017-01-23 18:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:01:00 --> Controller Class Initialized
INFO - 2017-01-23 18:01:00 --> Helper loaded: date_helper
DEBUG - 2017-01-23 18:01:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:01:00 --> Helper loaded: url_helper
INFO - 2017-01-23 18:01:00 --> Helper loaded: download_helper
INFO - 2017-01-23 18:01:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:01:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 18:01:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-23 18:01:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-23 18:01:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:01:00 --> Final output sent to browser
DEBUG - 2017-01-23 18:01:00 --> Total execution time: 0.1363
INFO - 2017-01-23 18:01:03 --> Config Class Initialized
INFO - 2017-01-23 18:01:03 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:01:03 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:01:03 --> Utf8 Class Initialized
INFO - 2017-01-23 18:01:03 --> URI Class Initialized
INFO - 2017-01-23 18:01:03 --> Router Class Initialized
INFO - 2017-01-23 18:01:03 --> Output Class Initialized
INFO - 2017-01-23 18:01:03 --> Security Class Initialized
DEBUG - 2017-01-23 18:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:01:03 --> Input Class Initialized
INFO - 2017-01-23 18:01:03 --> Language Class Initialized
INFO - 2017-01-23 18:01:03 --> Loader Class Initialized
INFO - 2017-01-23 18:01:03 --> Database Driver Class Initialized
INFO - 2017-01-23 18:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:01:03 --> Controller Class Initialized
INFO - 2017-01-23 18:01:03 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:01:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:01:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:01:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:01:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:01:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:01:03 --> Final output sent to browser
DEBUG - 2017-01-23 18:01:03 --> Total execution time: 1.2546
INFO - 2017-01-23 18:01:06 --> Config Class Initialized
INFO - 2017-01-23 18:01:06 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:01:06 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:01:06 --> Utf8 Class Initialized
INFO - 2017-01-23 18:01:06 --> URI Class Initialized
INFO - 2017-01-23 18:01:06 --> Router Class Initialized
INFO - 2017-01-23 18:01:06 --> Output Class Initialized
INFO - 2017-01-23 18:01:06 --> Security Class Initialized
DEBUG - 2017-01-23 18:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:01:06 --> Input Class Initialized
INFO - 2017-01-23 18:01:06 --> Language Class Initialized
INFO - 2017-01-23 18:01:06 --> Loader Class Initialized
INFO - 2017-01-23 18:01:06 --> Database Driver Class Initialized
INFO - 2017-01-23 18:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:01:06 --> Controller Class Initialized
INFO - 2017-01-23 18:01:06 --> Helper loaded: date_helper
INFO - 2017-01-23 18:01:06 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:01:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:01:06 --> Helper loaded: form_helper
INFO - 2017-01-23 18:01:06 --> Form Validation Class Initialized
ERROR - 2017-01-23 18:01:06 --> Query error: Column 'lugar_1' cannot be null - Invalid query: INSERT INTO `tbl_registro_lugares` (`lugar_1`, `lugar_2`, `id_graduacion`, `id_persona`, `id_tipo_lugar`, `numero_infantes`) VALUES (NULL, '0', '28', '19', '1', '2')
INFO - 2017-01-23 18:01:06 --> Language file loaded: language/english/db_lang.php
INFO - 2017-01-23 18:05:12 --> Config Class Initialized
INFO - 2017-01-23 18:05:12 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:05:12 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:05:12 --> Utf8 Class Initialized
INFO - 2017-01-23 18:05:12 --> URI Class Initialized
DEBUG - 2017-01-23 18:05:12 --> No URI present. Default controller set.
INFO - 2017-01-23 18:05:12 --> Router Class Initialized
INFO - 2017-01-23 18:05:12 --> Output Class Initialized
INFO - 2017-01-23 18:05:12 --> Security Class Initialized
DEBUG - 2017-01-23 18:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:05:12 --> Input Class Initialized
INFO - 2017-01-23 18:05:12 --> Language Class Initialized
INFO - 2017-01-23 18:05:12 --> Loader Class Initialized
INFO - 2017-01-23 18:05:12 --> Database Driver Class Initialized
INFO - 2017-01-23 18:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:05:12 --> Controller Class Initialized
INFO - 2017-01-23 18:05:12 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:05:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:05:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:05:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:05:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:05:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:05:12 --> Final output sent to browser
DEBUG - 2017-01-23 18:05:12 --> Total execution time: 0.1073
INFO - 2017-01-23 18:05:18 --> Config Class Initialized
INFO - 2017-01-23 18:05:18 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:05:18 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:05:18 --> Utf8 Class Initialized
INFO - 2017-01-23 18:05:18 --> URI Class Initialized
INFO - 2017-01-23 18:05:18 --> Router Class Initialized
INFO - 2017-01-23 18:05:18 --> Output Class Initialized
INFO - 2017-01-23 18:05:18 --> Security Class Initialized
DEBUG - 2017-01-23 18:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:05:18 --> Input Class Initialized
INFO - 2017-01-23 18:05:18 --> Language Class Initialized
INFO - 2017-01-23 18:05:18 --> Loader Class Initialized
INFO - 2017-01-23 18:05:18 --> Database Driver Class Initialized
INFO - 2017-01-23 18:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:05:18 --> Controller Class Initialized
INFO - 2017-01-23 18:05:18 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:05:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:05:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:05:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:05:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:05:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:05:18 --> Final output sent to browser
DEBUG - 2017-01-23 18:05:18 --> Total execution time: 0.0139
INFO - 2017-01-23 18:05:50 --> Config Class Initialized
INFO - 2017-01-23 18:05:50 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:05:50 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:05:50 --> Utf8 Class Initialized
INFO - 2017-01-23 18:05:50 --> URI Class Initialized
INFO - 2017-01-23 18:05:50 --> Router Class Initialized
INFO - 2017-01-23 18:05:50 --> Output Class Initialized
INFO - 2017-01-23 18:05:50 --> Security Class Initialized
DEBUG - 2017-01-23 18:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:05:50 --> Input Class Initialized
INFO - 2017-01-23 18:05:50 --> Language Class Initialized
INFO - 2017-01-23 18:05:50 --> Loader Class Initialized
INFO - 2017-01-23 18:05:50 --> Database Driver Class Initialized
INFO - 2017-01-23 18:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:05:50 --> Controller Class Initialized
INFO - 2017-01-23 18:05:50 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:05:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:05:53 --> Config Class Initialized
INFO - 2017-01-23 18:05:53 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:05:53 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:05:53 --> Utf8 Class Initialized
INFO - 2017-01-23 18:05:53 --> URI Class Initialized
INFO - 2017-01-23 18:05:53 --> Router Class Initialized
INFO - 2017-01-23 18:05:53 --> Output Class Initialized
INFO - 2017-01-23 18:05:53 --> Security Class Initialized
DEBUG - 2017-01-23 18:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:05:53 --> Input Class Initialized
INFO - 2017-01-23 18:05:53 --> Language Class Initialized
INFO - 2017-01-23 18:05:53 --> Loader Class Initialized
INFO - 2017-01-23 18:05:53 --> Database Driver Class Initialized
INFO - 2017-01-23 18:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:05:53 --> Controller Class Initialized
INFO - 2017-01-23 18:05:53 --> Helper loaded: date_helper
DEBUG - 2017-01-23 18:05:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:05:53 --> Helper loaded: url_helper
INFO - 2017-01-23 18:05:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:05:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-23 18:05:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-23 18:05:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-23 18:05:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:05:53 --> Final output sent to browser
DEBUG - 2017-01-23 18:05:53 --> Total execution time: 0.0545
INFO - 2017-01-23 18:05:55 --> Config Class Initialized
INFO - 2017-01-23 18:05:55 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:05:55 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:05:55 --> Utf8 Class Initialized
INFO - 2017-01-23 18:05:55 --> URI Class Initialized
INFO - 2017-01-23 18:05:55 --> Router Class Initialized
INFO - 2017-01-23 18:05:55 --> Output Class Initialized
INFO - 2017-01-23 18:05:55 --> Security Class Initialized
DEBUG - 2017-01-23 18:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:05:55 --> Input Class Initialized
INFO - 2017-01-23 18:05:55 --> Language Class Initialized
INFO - 2017-01-23 18:05:55 --> Loader Class Initialized
INFO - 2017-01-23 18:05:55 --> Database Driver Class Initialized
INFO - 2017-01-23 18:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:05:55 --> Controller Class Initialized
INFO - 2017-01-23 18:05:55 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:05:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:05:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:05:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:05:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:05:55 --> Final output sent to browser
DEBUG - 2017-01-23 18:05:55 --> Total execution time: 0.0310
INFO - 2017-01-23 18:06:01 --> Config Class Initialized
INFO - 2017-01-23 18:06:01 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:06:01 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:06:01 --> Utf8 Class Initialized
INFO - 2017-01-23 18:06:01 --> URI Class Initialized
DEBUG - 2017-01-23 18:06:01 --> No URI present. Default controller set.
INFO - 2017-01-23 18:06:01 --> Router Class Initialized
INFO - 2017-01-23 18:06:01 --> Output Class Initialized
INFO - 2017-01-23 18:06:01 --> Security Class Initialized
DEBUG - 2017-01-23 18:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:06:01 --> Input Class Initialized
INFO - 2017-01-23 18:06:01 --> Language Class Initialized
INFO - 2017-01-23 18:06:01 --> Loader Class Initialized
INFO - 2017-01-23 18:06:01 --> Database Driver Class Initialized
INFO - 2017-01-23 18:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:06:01 --> Controller Class Initialized
INFO - 2017-01-23 18:06:01 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:06:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:06:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:06:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:06:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:06:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:06:01 --> Final output sent to browser
DEBUG - 2017-01-23 18:06:01 --> Total execution time: 0.0139
INFO - 2017-01-23 18:06:03 --> Config Class Initialized
INFO - 2017-01-23 18:06:03 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:06:03 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:06:03 --> Utf8 Class Initialized
INFO - 2017-01-23 18:06:03 --> URI Class Initialized
INFO - 2017-01-23 18:06:03 --> Router Class Initialized
INFO - 2017-01-23 18:06:03 --> Output Class Initialized
INFO - 2017-01-23 18:06:03 --> Security Class Initialized
DEBUG - 2017-01-23 18:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:06:03 --> Input Class Initialized
INFO - 2017-01-23 18:06:03 --> Language Class Initialized
INFO - 2017-01-23 18:06:03 --> Loader Class Initialized
INFO - 2017-01-23 18:06:03 --> Database Driver Class Initialized
INFO - 2017-01-23 18:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:06:03 --> Controller Class Initialized
INFO - 2017-01-23 18:06:03 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:06:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:06:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:06:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:06:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:06:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:06:03 --> Final output sent to browser
DEBUG - 2017-01-23 18:06:03 --> Total execution time: 0.0140
INFO - 2017-01-23 18:19:22 --> Config Class Initialized
INFO - 2017-01-23 18:19:22 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:19:22 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:19:22 --> Utf8 Class Initialized
INFO - 2017-01-23 18:19:22 --> URI Class Initialized
INFO - 2017-01-23 18:19:22 --> Router Class Initialized
INFO - 2017-01-23 18:19:22 --> Output Class Initialized
INFO - 2017-01-23 18:19:22 --> Security Class Initialized
DEBUG - 2017-01-23 18:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:19:22 --> Input Class Initialized
INFO - 2017-01-23 18:19:22 --> Language Class Initialized
INFO - 2017-01-23 18:19:22 --> Loader Class Initialized
INFO - 2017-01-23 18:19:22 --> Database Driver Class Initialized
INFO - 2017-01-23 18:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:19:22 --> Controller Class Initialized
INFO - 2017-01-23 18:19:22 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:19:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:19:22 --> Helper loaded: form_helper
INFO - 2017-01-23 18:19:22 --> Form Validation Class Initialized
INFO - 2017-01-23 18:19:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 18:19:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-23 18:19:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 18:19:22 --> Final output sent to browser
DEBUG - 2017-01-23 18:19:22 --> Total execution time: 0.5820
INFO - 2017-01-23 18:19:23 --> Config Class Initialized
INFO - 2017-01-23 18:19:23 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:19:23 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:19:23 --> Utf8 Class Initialized
INFO - 2017-01-23 18:19:23 --> URI Class Initialized
INFO - 2017-01-23 18:19:23 --> Router Class Initialized
INFO - 2017-01-23 18:19:23 --> Output Class Initialized
INFO - 2017-01-23 18:19:23 --> Security Class Initialized
DEBUG - 2017-01-23 18:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:19:23 --> Input Class Initialized
INFO - 2017-01-23 18:19:23 --> Language Class Initialized
INFO - 2017-01-23 18:19:23 --> Loader Class Initialized
INFO - 2017-01-23 18:19:23 --> Database Driver Class Initialized
INFO - 2017-01-23 18:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:19:23 --> Controller Class Initialized
INFO - 2017-01-23 18:19:23 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:19:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:19:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:19:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:19:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:19:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:19:25 --> Final output sent to browser
DEBUG - 2017-01-23 18:19:25 --> Total execution time: 1.9058
INFO - 2017-01-23 18:19:41 --> Config Class Initialized
INFO - 2017-01-23 18:19:41 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:19:41 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:19:41 --> Utf8 Class Initialized
INFO - 2017-01-23 18:19:41 --> URI Class Initialized
INFO - 2017-01-23 18:19:41 --> Router Class Initialized
INFO - 2017-01-23 18:19:41 --> Output Class Initialized
INFO - 2017-01-23 18:19:41 --> Security Class Initialized
DEBUG - 2017-01-23 18:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:19:41 --> Input Class Initialized
INFO - 2017-01-23 18:19:41 --> Language Class Initialized
INFO - 2017-01-23 18:19:41 --> Loader Class Initialized
INFO - 2017-01-23 18:19:41 --> Database Driver Class Initialized
INFO - 2017-01-23 18:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:19:41 --> Controller Class Initialized
INFO - 2017-01-23 18:19:41 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:19:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:19:41 --> Helper loaded: form_helper
INFO - 2017-01-23 18:19:41 --> Form Validation Class Initialized
INFO - 2017-01-23 18:19:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-23 18:19:41 --> Config Class Initialized
INFO - 2017-01-23 18:19:41 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:19:41 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:19:41 --> Utf8 Class Initialized
INFO - 2017-01-23 18:19:41 --> URI Class Initialized
INFO - 2017-01-23 18:19:41 --> Router Class Initialized
INFO - 2017-01-23 18:19:41 --> Output Class Initialized
INFO - 2017-01-23 18:19:41 --> Security Class Initialized
DEBUG - 2017-01-23 18:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:19:41 --> Input Class Initialized
INFO - 2017-01-23 18:19:41 --> Language Class Initialized
INFO - 2017-01-23 18:19:41 --> Loader Class Initialized
INFO - 2017-01-23 18:19:41 --> Database Driver Class Initialized
INFO - 2017-01-23 18:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:19:41 --> Controller Class Initialized
INFO - 2017-01-23 18:19:41 --> Helper loaded: date_helper
INFO - 2017-01-23 18:19:41 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:19:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:19:41 --> Helper loaded: form_helper
INFO - 2017-01-23 18:19:41 --> Form Validation Class Initialized
INFO - 2017-01-23 18:19:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 18:19:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 18:19:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-23 18:19:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-23 18:19:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 18:19:41 --> Final output sent to browser
DEBUG - 2017-01-23 18:19:41 --> Total execution time: 0.1090
INFO - 2017-01-23 18:19:42 --> Config Class Initialized
INFO - 2017-01-23 18:19:42 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:19:42 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:19:42 --> Utf8 Class Initialized
INFO - 2017-01-23 18:19:42 --> URI Class Initialized
INFO - 2017-01-23 18:19:42 --> Router Class Initialized
INFO - 2017-01-23 18:19:42 --> Output Class Initialized
INFO - 2017-01-23 18:19:42 --> Security Class Initialized
DEBUG - 2017-01-23 18:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:19:42 --> Input Class Initialized
INFO - 2017-01-23 18:19:42 --> Language Class Initialized
INFO - 2017-01-23 18:19:42 --> Loader Class Initialized
INFO - 2017-01-23 18:19:42 --> Database Driver Class Initialized
INFO - 2017-01-23 18:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:19:42 --> Controller Class Initialized
INFO - 2017-01-23 18:19:42 --> Helper loaded: date_helper
INFO - 2017-01-23 18:19:42 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:19:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:19:42 --> Helper loaded: form_helper
INFO - 2017-01-23 18:19:42 --> Form Validation Class Initialized
INFO - 2017-01-23 18:19:42 --> Final output sent to browser
DEBUG - 2017-01-23 18:19:42 --> Total execution time: 0.0270
INFO - 2017-01-23 18:19:43 --> Config Class Initialized
INFO - 2017-01-23 18:19:43 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:19:43 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:19:43 --> Utf8 Class Initialized
INFO - 2017-01-23 18:19:43 --> URI Class Initialized
INFO - 2017-01-23 18:19:43 --> Router Class Initialized
INFO - 2017-01-23 18:19:43 --> Output Class Initialized
INFO - 2017-01-23 18:19:43 --> Security Class Initialized
DEBUG - 2017-01-23 18:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:19:43 --> Input Class Initialized
INFO - 2017-01-23 18:19:43 --> Language Class Initialized
INFO - 2017-01-23 18:19:43 --> Loader Class Initialized
INFO - 2017-01-23 18:19:43 --> Database Driver Class Initialized
INFO - 2017-01-23 18:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:19:43 --> Controller Class Initialized
INFO - 2017-01-23 18:19:43 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:19:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:19:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:19:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:19:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:19:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:19:43 --> Final output sent to browser
DEBUG - 2017-01-23 18:19:43 --> Total execution time: 0.0188
INFO - 2017-01-23 18:19:46 --> Config Class Initialized
INFO - 2017-01-23 18:19:46 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:19:46 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:19:46 --> Utf8 Class Initialized
INFO - 2017-01-23 18:19:46 --> URI Class Initialized
INFO - 2017-01-23 18:19:46 --> Router Class Initialized
INFO - 2017-01-23 18:19:46 --> Output Class Initialized
INFO - 2017-01-23 18:19:46 --> Security Class Initialized
DEBUG - 2017-01-23 18:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:19:46 --> Input Class Initialized
INFO - 2017-01-23 18:19:46 --> Language Class Initialized
INFO - 2017-01-23 18:19:46 --> Loader Class Initialized
INFO - 2017-01-23 18:19:46 --> Database Driver Class Initialized
INFO - 2017-01-23 18:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:19:46 --> Controller Class Initialized
INFO - 2017-01-23 18:19:46 --> Helper loaded: date_helper
INFO - 2017-01-23 18:19:46 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:19:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:19:46 --> Helper loaded: form_helper
INFO - 2017-01-23 18:19:46 --> Form Validation Class Initialized
INFO - 2017-01-23 18:19:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 18:19:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 18:19:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-23 18:19:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-23 18:19:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 18:19:46 --> Final output sent to browser
DEBUG - 2017-01-23 18:19:46 --> Total execution time: 0.1146
INFO - 2017-01-23 18:19:47 --> Config Class Initialized
INFO - 2017-01-23 18:19:47 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:19:47 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:19:47 --> Utf8 Class Initialized
INFO - 2017-01-23 18:19:47 --> URI Class Initialized
INFO - 2017-01-23 18:19:47 --> Router Class Initialized
INFO - 2017-01-23 18:19:47 --> Output Class Initialized
INFO - 2017-01-23 18:19:47 --> Security Class Initialized
DEBUG - 2017-01-23 18:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:19:47 --> Input Class Initialized
INFO - 2017-01-23 18:19:47 --> Language Class Initialized
INFO - 2017-01-23 18:19:47 --> Loader Class Initialized
INFO - 2017-01-23 18:19:47 --> Database Driver Class Initialized
INFO - 2017-01-23 18:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:19:47 --> Controller Class Initialized
INFO - 2017-01-23 18:19:47 --> Helper loaded: date_helper
INFO - 2017-01-23 18:19:47 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:19:47 --> Helper loaded: form_helper
INFO - 2017-01-23 18:19:47 --> Form Validation Class Initialized
INFO - 2017-01-23 18:19:47 --> Final output sent to browser
DEBUG - 2017-01-23 18:19:47 --> Total execution time: 0.0154
INFO - 2017-01-23 18:19:47 --> Config Class Initialized
INFO - 2017-01-23 18:19:47 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:19:47 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:19:47 --> Utf8 Class Initialized
INFO - 2017-01-23 18:19:47 --> URI Class Initialized
INFO - 2017-01-23 18:19:47 --> Router Class Initialized
INFO - 2017-01-23 18:19:47 --> Output Class Initialized
INFO - 2017-01-23 18:19:47 --> Security Class Initialized
DEBUG - 2017-01-23 18:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:19:47 --> Input Class Initialized
INFO - 2017-01-23 18:19:47 --> Language Class Initialized
INFO - 2017-01-23 18:19:47 --> Loader Class Initialized
INFO - 2017-01-23 18:19:47 --> Database Driver Class Initialized
INFO - 2017-01-23 18:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:19:47 --> Controller Class Initialized
INFO - 2017-01-23 18:19:47 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:19:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:19:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:19:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:19:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:19:47 --> Final output sent to browser
DEBUG - 2017-01-23 18:19:47 --> Total execution time: 0.0140
INFO - 2017-01-23 18:19:50 --> Config Class Initialized
INFO - 2017-01-23 18:19:50 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:19:50 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:19:50 --> Utf8 Class Initialized
INFO - 2017-01-23 18:19:50 --> URI Class Initialized
INFO - 2017-01-23 18:19:50 --> Router Class Initialized
INFO - 2017-01-23 18:19:50 --> Output Class Initialized
INFO - 2017-01-23 18:19:50 --> Security Class Initialized
DEBUG - 2017-01-23 18:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:19:50 --> Input Class Initialized
INFO - 2017-01-23 18:19:50 --> Language Class Initialized
INFO - 2017-01-23 18:19:50 --> Loader Class Initialized
INFO - 2017-01-23 18:19:50 --> Database Driver Class Initialized
INFO - 2017-01-23 18:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:19:50 --> Controller Class Initialized
INFO - 2017-01-23 18:19:50 --> Helper loaded: date_helper
INFO - 2017-01-23 18:19:50 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:19:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:19:50 --> Helper loaded: form_helper
INFO - 2017-01-23 18:19:50 --> Form Validation Class Initialized
INFO - 2017-01-23 18:19:50 --> Final output sent to browser
DEBUG - 2017-01-23 18:19:50 --> Total execution time: 0.0145
INFO - 2017-01-23 18:19:53 --> Config Class Initialized
INFO - 2017-01-23 18:19:53 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:19:53 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:19:53 --> Utf8 Class Initialized
INFO - 2017-01-23 18:19:53 --> URI Class Initialized
INFO - 2017-01-23 18:19:53 --> Router Class Initialized
INFO - 2017-01-23 18:19:53 --> Output Class Initialized
INFO - 2017-01-23 18:19:53 --> Security Class Initialized
DEBUG - 2017-01-23 18:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:19:53 --> Input Class Initialized
INFO - 2017-01-23 18:19:53 --> Language Class Initialized
INFO - 2017-01-23 18:19:53 --> Loader Class Initialized
INFO - 2017-01-23 18:19:53 --> Database Driver Class Initialized
INFO - 2017-01-23 18:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:19:53 --> Controller Class Initialized
INFO - 2017-01-23 18:19:53 --> Helper loaded: date_helper
INFO - 2017-01-23 18:19:53 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:19:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:19:53 --> Helper loaded: form_helper
INFO - 2017-01-23 18:19:53 --> Form Validation Class Initialized
INFO - 2017-01-23 18:19:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 18:19:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 18:19:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-23 18:19:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-23 18:19:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 18:19:54 --> Final output sent to browser
DEBUG - 2017-01-23 18:19:54 --> Total execution time: 0.0780
INFO - 2017-01-23 18:19:54 --> Config Class Initialized
INFO - 2017-01-23 18:19:54 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:19:54 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:19:54 --> Utf8 Class Initialized
INFO - 2017-01-23 18:19:54 --> URI Class Initialized
INFO - 2017-01-23 18:19:54 --> Router Class Initialized
INFO - 2017-01-23 18:19:54 --> Output Class Initialized
INFO - 2017-01-23 18:19:54 --> Security Class Initialized
DEBUG - 2017-01-23 18:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:19:54 --> Input Class Initialized
INFO - 2017-01-23 18:19:54 --> Language Class Initialized
INFO - 2017-01-23 18:19:54 --> Loader Class Initialized
INFO - 2017-01-23 18:19:54 --> Database Driver Class Initialized
INFO - 2017-01-23 18:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:19:54 --> Controller Class Initialized
INFO - 2017-01-23 18:19:54 --> Helper loaded: date_helper
INFO - 2017-01-23 18:19:54 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:19:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:19:54 --> Helper loaded: form_helper
INFO - 2017-01-23 18:19:54 --> Form Validation Class Initialized
INFO - 2017-01-23 18:19:54 --> Final output sent to browser
DEBUG - 2017-01-23 18:19:54 --> Total execution time: 0.0220
INFO - 2017-01-23 18:19:54 --> Config Class Initialized
INFO - 2017-01-23 18:19:54 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:19:54 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:19:54 --> Utf8 Class Initialized
INFO - 2017-01-23 18:19:54 --> URI Class Initialized
INFO - 2017-01-23 18:19:54 --> Router Class Initialized
INFO - 2017-01-23 18:19:54 --> Output Class Initialized
INFO - 2017-01-23 18:19:54 --> Security Class Initialized
DEBUG - 2017-01-23 18:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:19:54 --> Input Class Initialized
INFO - 2017-01-23 18:19:54 --> Language Class Initialized
INFO - 2017-01-23 18:19:54 --> Loader Class Initialized
INFO - 2017-01-23 18:19:54 --> Database Driver Class Initialized
INFO - 2017-01-23 18:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:19:54 --> Controller Class Initialized
INFO - 2017-01-23 18:19:54 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:19:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:19:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:19:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:19:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:19:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:19:54 --> Final output sent to browser
DEBUG - 2017-01-23 18:19:54 --> Total execution time: 0.0148
INFO - 2017-01-23 18:19:56 --> Config Class Initialized
INFO - 2017-01-23 18:19:56 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:19:56 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:19:56 --> Utf8 Class Initialized
INFO - 2017-01-23 18:19:56 --> URI Class Initialized
INFO - 2017-01-23 18:19:56 --> Router Class Initialized
INFO - 2017-01-23 18:19:56 --> Output Class Initialized
INFO - 2017-01-23 18:19:56 --> Security Class Initialized
DEBUG - 2017-01-23 18:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:19:56 --> Input Class Initialized
INFO - 2017-01-23 18:19:56 --> Language Class Initialized
INFO - 2017-01-23 18:19:56 --> Loader Class Initialized
INFO - 2017-01-23 18:19:56 --> Database Driver Class Initialized
INFO - 2017-01-23 18:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:19:56 --> Controller Class Initialized
INFO - 2017-01-23 18:19:56 --> Helper loaded: date_helper
INFO - 2017-01-23 18:19:56 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:19:56 --> Helper loaded: form_helper
INFO - 2017-01-23 18:19:56 --> Form Validation Class Initialized
INFO - 2017-01-23 18:19:56 --> Final output sent to browser
DEBUG - 2017-01-23 18:19:56 --> Total execution time: 0.0155
INFO - 2017-01-23 18:19:56 --> Config Class Initialized
INFO - 2017-01-23 18:19:56 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:19:56 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:19:56 --> Utf8 Class Initialized
INFO - 2017-01-23 18:19:56 --> URI Class Initialized
INFO - 2017-01-23 18:19:56 --> Router Class Initialized
INFO - 2017-01-23 18:19:56 --> Output Class Initialized
INFO - 2017-01-23 18:19:56 --> Security Class Initialized
DEBUG - 2017-01-23 18:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:19:56 --> Input Class Initialized
INFO - 2017-01-23 18:19:56 --> Language Class Initialized
INFO - 2017-01-23 18:19:56 --> Loader Class Initialized
INFO - 2017-01-23 18:19:56 --> Database Driver Class Initialized
INFO - 2017-01-23 18:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:19:56 --> Controller Class Initialized
INFO - 2017-01-23 18:19:56 --> Helper loaded: date_helper
INFO - 2017-01-23 18:19:56 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:19:56 --> Helper loaded: form_helper
INFO - 2017-01-23 18:19:56 --> Form Validation Class Initialized
INFO - 2017-01-23 18:19:56 --> Final output sent to browser
DEBUG - 2017-01-23 18:19:56 --> Total execution time: 0.0150
INFO - 2017-01-23 18:29:48 --> Config Class Initialized
INFO - 2017-01-23 18:29:48 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:29:48 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:29:48 --> Utf8 Class Initialized
INFO - 2017-01-23 18:29:48 --> URI Class Initialized
INFO - 2017-01-23 18:29:48 --> Router Class Initialized
INFO - 2017-01-23 18:29:48 --> Output Class Initialized
INFO - 2017-01-23 18:29:48 --> Security Class Initialized
DEBUG - 2017-01-23 18:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:29:48 --> Input Class Initialized
INFO - 2017-01-23 18:29:48 --> Language Class Initialized
INFO - 2017-01-23 18:29:48 --> Loader Class Initialized
INFO - 2017-01-23 18:29:48 --> Database Driver Class Initialized
INFO - 2017-01-23 18:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:29:48 --> Controller Class Initialized
INFO - 2017-01-23 18:29:48 --> Helper loaded: date_helper
INFO - 2017-01-23 18:29:48 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:29:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:29:48 --> Helper loaded: form_helper
INFO - 2017-01-23 18:29:48 --> Form Validation Class Initialized
INFO - 2017-01-23 18:29:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 18:29:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 18:29:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-23 18:29:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-23 18:29:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 18:29:48 --> Final output sent to browser
DEBUG - 2017-01-23 18:29:48 --> Total execution time: 0.1384
INFO - 2017-01-23 18:29:52 --> Config Class Initialized
INFO - 2017-01-23 18:29:52 --> Config Class Initialized
INFO - 2017-01-23 18:29:52 --> Hooks Class Initialized
INFO - 2017-01-23 18:29:52 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:29:52 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:29:52 --> Utf8 Class Initialized
DEBUG - 2017-01-23 18:29:52 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:29:52 --> Utf8 Class Initialized
INFO - 2017-01-23 18:29:52 --> URI Class Initialized
INFO - 2017-01-23 18:29:52 --> URI Class Initialized
INFO - 2017-01-23 18:29:52 --> Router Class Initialized
INFO - 2017-01-23 18:29:52 --> Router Class Initialized
INFO - 2017-01-23 18:29:52 --> Output Class Initialized
INFO - 2017-01-23 18:29:52 --> Output Class Initialized
INFO - 2017-01-23 18:29:52 --> Security Class Initialized
DEBUG - 2017-01-23 18:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:29:52 --> Input Class Initialized
INFO - 2017-01-23 18:29:52 --> Language Class Initialized
INFO - 2017-01-23 18:29:52 --> Security Class Initialized
DEBUG - 2017-01-23 18:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:29:52 --> Input Class Initialized
INFO - 2017-01-23 18:29:52 --> Loader Class Initialized
INFO - 2017-01-23 18:29:52 --> Language Class Initialized
INFO - 2017-01-23 18:29:52 --> Loader Class Initialized
INFO - 2017-01-23 18:29:52 --> Database Driver Class Initialized
INFO - 2017-01-23 18:29:52 --> Database Driver Class Initialized
INFO - 2017-01-23 18:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:29:52 --> Controller Class Initialized
INFO - 2017-01-23 18:29:52 --> Helper loaded: date_helper
INFO - 2017-01-23 18:29:52 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:29:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:29:52 --> Helper loaded: form_helper
INFO - 2017-01-23 18:29:52 --> Form Validation Class Initialized
INFO - 2017-01-23 18:29:52 --> Final output sent to browser
DEBUG - 2017-01-23 18:29:52 --> Total execution time: 3.7127
INFO - 2017-01-23 18:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:29:52 --> Controller Class Initialized
INFO - 2017-01-23 18:29:52 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:29:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:29:52 --> Config Class Initialized
INFO - 2017-01-23 18:29:52 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:29:52 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:29:52 --> Utf8 Class Initialized
INFO - 2017-01-23 18:29:52 --> URI Class Initialized
INFO - 2017-01-23 18:29:52 --> Router Class Initialized
INFO - 2017-01-23 18:29:52 --> Output Class Initialized
INFO - 2017-01-23 18:29:52 --> Security Class Initialized
DEBUG - 2017-01-23 18:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:29:52 --> Input Class Initialized
INFO - 2017-01-23 18:29:52 --> Language Class Initialized
INFO - 2017-01-23 18:29:52 --> Final output sent to browser
DEBUG - 2017-01-23 18:29:52 --> Total execution time: 3.7059
INFO - 2017-01-23 18:29:52 --> Loader Class Initialized
INFO - 2017-01-23 18:29:52 --> Database Driver Class Initialized
INFO - 2017-01-23 18:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:29:52 --> Controller Class Initialized
INFO - 2017-01-23 18:29:52 --> Helper loaded: date_helper
DEBUG - 2017-01-23 18:29:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:29:52 --> Helper loaded: url_helper
INFO - 2017-01-23 18:29:52 --> Helper loaded: download_helper
INFO - 2017-01-23 18:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 18:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-23 18:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-23 18:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:29:52 --> Final output sent to browser
DEBUG - 2017-01-23 18:29:52 --> Total execution time: 2.5814
INFO - 2017-01-23 18:29:55 --> Config Class Initialized
INFO - 2017-01-23 18:29:55 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:29:55 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:29:55 --> Utf8 Class Initialized
INFO - 2017-01-23 18:29:55 --> URI Class Initialized
INFO - 2017-01-23 18:29:55 --> Router Class Initialized
INFO - 2017-01-23 18:29:55 --> Output Class Initialized
INFO - 2017-01-23 18:29:55 --> Security Class Initialized
DEBUG - 2017-01-23 18:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:29:55 --> Input Class Initialized
INFO - 2017-01-23 18:29:55 --> Language Class Initialized
INFO - 2017-01-23 18:29:55 --> Loader Class Initialized
INFO - 2017-01-23 18:29:55 --> Database Driver Class Initialized
INFO - 2017-01-23 18:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:29:55 --> Controller Class Initialized
INFO - 2017-01-23 18:29:55 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:29:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:29:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:29:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:29:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:29:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:29:55 --> Final output sent to browser
DEBUG - 2017-01-23 18:29:55 --> Total execution time: 2.4250
INFO - 2017-01-23 18:30:01 --> Config Class Initialized
INFO - 2017-01-23 18:30:01 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:30:01 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:30:01 --> Utf8 Class Initialized
INFO - 2017-01-23 18:30:01 --> URI Class Initialized
INFO - 2017-01-23 18:30:01 --> Router Class Initialized
INFO - 2017-01-23 18:30:01 --> Output Class Initialized
INFO - 2017-01-23 18:30:01 --> Security Class Initialized
DEBUG - 2017-01-23 18:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:30:01 --> Input Class Initialized
INFO - 2017-01-23 18:30:01 --> Language Class Initialized
INFO - 2017-01-23 18:30:01 --> Loader Class Initialized
INFO - 2017-01-23 18:30:01 --> Database Driver Class Initialized
INFO - 2017-01-23 18:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:30:01 --> Controller Class Initialized
INFO - 2017-01-23 18:30:01 --> Helper loaded: date_helper
INFO - 2017-01-23 18:30:01 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:30:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:30:01 --> Helper loaded: form_helper
INFO - 2017-01-23 18:30:01 --> Form Validation Class Initialized
ERROR - 2017-01-23 18:30:01 --> Query error: Column 'lugar_1' cannot be null - Invalid query: INSERT INTO `tbl_registro_lugares` (`lugar_1`, `lugar_2`, `id_graduacion`, `id_persona`, `id_tipo_lugar`, `numero_infantes`) VALUES (NULL, '0', '28', '19', '1', '5')
INFO - 2017-01-23 18:30:01 --> Language file loaded: language/english/db_lang.php
INFO - 2017-01-23 18:30:05 --> Config Class Initialized
INFO - 2017-01-23 18:30:05 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:30:05 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:30:05 --> Utf8 Class Initialized
INFO - 2017-01-23 18:30:05 --> URI Class Initialized
INFO - 2017-01-23 18:30:05 --> Router Class Initialized
INFO - 2017-01-23 18:30:05 --> Output Class Initialized
INFO - 2017-01-23 18:30:05 --> Security Class Initialized
DEBUG - 2017-01-23 18:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:30:05 --> Input Class Initialized
INFO - 2017-01-23 18:30:05 --> Language Class Initialized
ERROR - 2017-01-23 18:30:05 --> 404 Page Not Found: Templates/usuario
INFO - 2017-01-23 18:32:42 --> Config Class Initialized
INFO - 2017-01-23 18:32:43 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:32:43 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:32:43 --> Utf8 Class Initialized
INFO - 2017-01-23 18:32:43 --> URI Class Initialized
INFO - 2017-01-23 18:32:43 --> Router Class Initialized
INFO - 2017-01-23 18:32:43 --> Output Class Initialized
INFO - 2017-01-23 18:32:43 --> Security Class Initialized
DEBUG - 2017-01-23 18:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:32:43 --> Input Class Initialized
INFO - 2017-01-23 18:32:43 --> Language Class Initialized
INFO - 2017-01-23 18:32:43 --> Loader Class Initialized
INFO - 2017-01-23 18:32:43 --> Database Driver Class Initialized
INFO - 2017-01-23 18:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:32:43 --> Controller Class Initialized
INFO - 2017-01-23 18:32:43 --> Helper loaded: date_helper
DEBUG - 2017-01-23 18:32:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:32:43 --> Helper loaded: url_helper
INFO - 2017-01-23 18:32:43 --> Helper loaded: download_helper
INFO - 2017-01-23 18:32:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:32:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 18:32:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-23 18:32:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-23 18:32:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:32:43 --> Final output sent to browser
DEBUG - 2017-01-23 18:32:43 --> Total execution time: 3.3419
INFO - 2017-01-23 18:32:49 --> Config Class Initialized
INFO - 2017-01-23 18:32:49 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:32:49 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:32:49 --> Utf8 Class Initialized
INFO - 2017-01-23 18:32:49 --> URI Class Initialized
INFO - 2017-01-23 18:32:49 --> Router Class Initialized
INFO - 2017-01-23 18:32:49 --> Output Class Initialized
INFO - 2017-01-23 18:32:49 --> Security Class Initialized
DEBUG - 2017-01-23 18:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:32:49 --> Input Class Initialized
INFO - 2017-01-23 18:32:49 --> Language Class Initialized
INFO - 2017-01-23 18:32:49 --> Loader Class Initialized
INFO - 2017-01-23 18:32:49 --> Database Driver Class Initialized
INFO - 2017-01-23 18:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:32:49 --> Controller Class Initialized
INFO - 2017-01-23 18:32:49 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:32:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:32:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:32:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:32:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:32:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:32:49 --> Final output sent to browser
DEBUG - 2017-01-23 18:32:49 --> Total execution time: 0.4015
INFO - 2017-01-23 18:33:19 --> Config Class Initialized
INFO - 2017-01-23 18:33:19 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:33:19 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:33:19 --> Utf8 Class Initialized
INFO - 2017-01-23 18:33:19 --> URI Class Initialized
INFO - 2017-01-23 18:33:19 --> Router Class Initialized
INFO - 2017-01-23 18:33:19 --> Output Class Initialized
INFO - 2017-01-23 18:33:19 --> Security Class Initialized
DEBUG - 2017-01-23 18:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:33:19 --> Input Class Initialized
INFO - 2017-01-23 18:33:19 --> Language Class Initialized
INFO - 2017-01-23 18:33:19 --> Loader Class Initialized
INFO - 2017-01-23 18:33:19 --> Database Driver Class Initialized
INFO - 2017-01-23 18:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:33:19 --> Controller Class Initialized
INFO - 2017-01-23 18:33:19 --> Helper loaded: date_helper
INFO - 2017-01-23 18:33:19 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:33:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:33:19 --> Helper loaded: form_helper
INFO - 2017-01-23 18:33:19 --> Form Validation Class Initialized
INFO - 2017-01-23 18:33:19 --> Final output sent to browser
DEBUG - 2017-01-23 18:33:19 --> Total execution time: 0.2353
INFO - 2017-01-23 18:33:29 --> Config Class Initialized
INFO - 2017-01-23 18:33:29 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:33:29 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:33:29 --> Utf8 Class Initialized
INFO - 2017-01-23 18:33:29 --> URI Class Initialized
INFO - 2017-01-23 18:33:29 --> Router Class Initialized
INFO - 2017-01-23 18:33:29 --> Output Class Initialized
INFO - 2017-01-23 18:33:29 --> Security Class Initialized
DEBUG - 2017-01-23 18:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:33:29 --> Input Class Initialized
INFO - 2017-01-23 18:33:29 --> Language Class Initialized
INFO - 2017-01-23 18:33:29 --> Loader Class Initialized
INFO - 2017-01-23 18:33:29 --> Database Driver Class Initialized
INFO - 2017-01-23 18:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:33:29 --> Controller Class Initialized
INFO - 2017-01-23 18:33:29 --> Helper loaded: date_helper
INFO - 2017-01-23 18:33:29 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:33:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:33:29 --> Helper loaded: form_helper
INFO - 2017-01-23 18:33:29 --> Form Validation Class Initialized
INFO - 2017-01-23 18:33:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 18:33:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 18:33:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-23 18:33:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-23 18:33:29 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 18:33:29 --> Final output sent to browser
DEBUG - 2017-01-23 18:33:29 --> Total execution time: 0.2466
INFO - 2017-01-23 18:33:33 --> Config Class Initialized
INFO - 2017-01-23 18:33:33 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:33:33 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:33:33 --> Utf8 Class Initialized
INFO - 2017-01-23 18:33:33 --> URI Class Initialized
INFO - 2017-01-23 18:33:33 --> Router Class Initialized
INFO - 2017-01-23 18:33:33 --> Output Class Initialized
INFO - 2017-01-23 18:33:33 --> Security Class Initialized
DEBUG - 2017-01-23 18:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:33:33 --> Input Class Initialized
INFO - 2017-01-23 18:33:33 --> Language Class Initialized
INFO - 2017-01-23 18:33:33 --> Loader Class Initialized
INFO - 2017-01-23 18:33:33 --> Database Driver Class Initialized
INFO - 2017-01-23 18:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:33:33 --> Controller Class Initialized
INFO - 2017-01-23 18:33:33 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:33:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:33:33 --> Config Class Initialized
INFO - 2017-01-23 18:33:33 --> Hooks Class Initialized
INFO - 2017-01-23 18:33:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
DEBUG - 2017-01-23 18:33:33 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:33:33 --> Utf8 Class Initialized
INFO - 2017-01-23 18:33:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:33:33 --> URI Class Initialized
INFO - 2017-01-23 18:33:33 --> Router Class Initialized
INFO - 2017-01-23 18:33:33 --> Output Class Initialized
INFO - 2017-01-23 18:33:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:33:34 --> Security Class Initialized
INFO - 2017-01-23 18:33:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
DEBUG - 2017-01-23 18:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:33:34 --> Input Class Initialized
INFO - 2017-01-23 18:33:34 --> Language Class Initialized
INFO - 2017-01-23 18:33:34 --> Loader Class Initialized
INFO - 2017-01-23 18:33:34 --> Database Driver Class Initialized
INFO - 2017-01-23 18:33:34 --> Final output sent to browser
DEBUG - 2017-01-23 18:33:34 --> Total execution time: 2.7899
INFO - 2017-01-23 18:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:33:34 --> Controller Class Initialized
INFO - 2017-01-23 18:33:34 --> Helper loaded: date_helper
INFO - 2017-01-23 18:33:34 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:33:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:33:34 --> Helper loaded: form_helper
INFO - 2017-01-23 18:33:34 --> Form Validation Class Initialized
INFO - 2017-01-23 18:33:35 --> Final output sent to browser
DEBUG - 2017-01-23 18:33:35 --> Total execution time: 3.8895
INFO - 2017-01-23 18:33:35 --> Config Class Initialized
INFO - 2017-01-23 18:33:35 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:33:35 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:33:35 --> Utf8 Class Initialized
INFO - 2017-01-23 18:33:35 --> URI Class Initialized
INFO - 2017-01-23 18:33:35 --> Router Class Initialized
INFO - 2017-01-23 18:33:35 --> Output Class Initialized
INFO - 2017-01-23 18:33:35 --> Security Class Initialized
DEBUG - 2017-01-23 18:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:33:35 --> Input Class Initialized
INFO - 2017-01-23 18:33:35 --> Language Class Initialized
INFO - 2017-01-23 18:33:35 --> Loader Class Initialized
INFO - 2017-01-23 18:33:35 --> Database Driver Class Initialized
INFO - 2017-01-23 18:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:33:35 --> Controller Class Initialized
INFO - 2017-01-23 18:33:35 --> Helper loaded: date_helper
INFO - 2017-01-23 18:33:35 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:33:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:33:35 --> Helper loaded: form_helper
INFO - 2017-01-23 18:33:35 --> Form Validation Class Initialized
INFO - 2017-01-23 18:33:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 18:33:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 18:33:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-23 18:33:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-23 18:33:36 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 18:33:36 --> Final output sent to browser
DEBUG - 2017-01-23 18:33:36 --> Total execution time: 0.4919
INFO - 2017-01-23 18:33:37 --> Config Class Initialized
INFO - 2017-01-23 18:33:37 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:33:37 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:33:37 --> Utf8 Class Initialized
INFO - 2017-01-23 18:33:37 --> Config Class Initialized
INFO - 2017-01-23 18:33:37 --> Hooks Class Initialized
INFO - 2017-01-23 18:33:37 --> URI Class Initialized
DEBUG - 2017-01-23 18:33:37 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:33:37 --> Utf8 Class Initialized
INFO - 2017-01-23 18:33:37 --> Router Class Initialized
INFO - 2017-01-23 18:33:37 --> URI Class Initialized
INFO - 2017-01-23 18:33:37 --> Output Class Initialized
INFO - 2017-01-23 18:33:37 --> Router Class Initialized
INFO - 2017-01-23 18:33:37 --> Security Class Initialized
DEBUG - 2017-01-23 18:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:33:37 --> Input Class Initialized
INFO - 2017-01-23 18:33:37 --> Output Class Initialized
INFO - 2017-01-23 18:33:37 --> Language Class Initialized
INFO - 2017-01-23 18:33:37 --> Security Class Initialized
DEBUG - 2017-01-23 18:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:33:37 --> Input Class Initialized
INFO - 2017-01-23 18:33:37 --> Loader Class Initialized
INFO - 2017-01-23 18:33:37 --> Language Class Initialized
INFO - 2017-01-23 18:33:37 --> Loader Class Initialized
INFO - 2017-01-23 18:33:37 --> Database Driver Class Initialized
INFO - 2017-01-23 18:33:37 --> Database Driver Class Initialized
INFO - 2017-01-23 18:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:33:37 --> Controller Class Initialized
INFO - 2017-01-23 18:33:37 --> Helper loaded: date_helper
INFO - 2017-01-23 18:33:37 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:33:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:33:37 --> Helper loaded: form_helper
INFO - 2017-01-23 18:33:37 --> Form Validation Class Initialized
INFO - 2017-01-23 18:33:37 --> Final output sent to browser
DEBUG - 2017-01-23 18:33:37 --> Total execution time: 0.1717
INFO - 2017-01-23 18:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:33:37 --> Controller Class Initialized
INFO - 2017-01-23 18:33:37 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:33:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:33:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:33:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:33:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:33:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:33:37 --> Final output sent to browser
DEBUG - 2017-01-23 18:33:37 --> Total execution time: 0.3480
INFO - 2017-01-23 18:33:42 --> Config Class Initialized
INFO - 2017-01-23 18:33:42 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:33:42 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:33:42 --> Utf8 Class Initialized
INFO - 2017-01-23 18:33:42 --> URI Class Initialized
INFO - 2017-01-23 18:33:42 --> Router Class Initialized
INFO - 2017-01-23 18:33:42 --> Output Class Initialized
INFO - 2017-01-23 18:33:42 --> Security Class Initialized
DEBUG - 2017-01-23 18:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:33:42 --> Input Class Initialized
INFO - 2017-01-23 18:33:42 --> Language Class Initialized
INFO - 2017-01-23 18:33:42 --> Loader Class Initialized
INFO - 2017-01-23 18:33:42 --> Config Class Initialized
INFO - 2017-01-23 18:33:42 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:33:42 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:33:42 --> Utf8 Class Initialized
INFO - 2017-01-23 18:33:42 --> URI Class Initialized
INFO - 2017-01-23 18:33:42 --> Router Class Initialized
INFO - 2017-01-23 18:33:42 --> Output Class Initialized
INFO - 2017-01-23 18:33:42 --> Security Class Initialized
DEBUG - 2017-01-23 18:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:33:42 --> Input Class Initialized
INFO - 2017-01-23 18:33:42 --> Language Class Initialized
INFO - 2017-01-23 18:33:42 --> Loader Class Initialized
INFO - 2017-01-23 18:33:42 --> Database Driver Class Initialized
INFO - 2017-01-23 18:33:42 --> Database Driver Class Initialized
INFO - 2017-01-23 18:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:33:42 --> Controller Class Initialized
INFO - 2017-01-23 18:33:42 --> Helper loaded: date_helper
INFO - 2017-01-23 18:33:42 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:33:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:33:42 --> Helper loaded: form_helper
INFO - 2017-01-23 18:33:42 --> Form Validation Class Initialized
INFO - 2017-01-23 18:33:42 --> Final output sent to browser
DEBUG - 2017-01-23 18:33:42 --> Total execution time: 0.2140
INFO - 2017-01-23 18:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:33:42 --> Controller Class Initialized
INFO - 2017-01-23 18:33:42 --> Helper loaded: date_helper
INFO - 2017-01-23 18:33:42 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:33:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:33:42 --> Helper loaded: form_helper
INFO - 2017-01-23 18:33:42 --> Form Validation Class Initialized
INFO - 2017-01-23 18:33:42 --> Final output sent to browser
DEBUG - 2017-01-23 18:33:42 --> Total execution time: 0.3190
INFO - 2017-01-23 18:40:52 --> Config Class Initialized
INFO - 2017-01-23 18:40:52 --> Hooks Class Initialized
INFO - 2017-01-23 18:40:52 --> Config Class Initialized
INFO - 2017-01-23 18:40:52 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:40:52 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:40:52 --> Utf8 Class Initialized
INFO - 2017-01-23 18:40:52 --> URI Class Initialized
INFO - 2017-01-23 18:40:52 --> Router Class Initialized
INFO - 2017-01-23 18:40:52 --> Output Class Initialized
INFO - 2017-01-23 18:40:52 --> Security Class Initialized
DEBUG - 2017-01-23 18:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:40:52 --> Input Class Initialized
INFO - 2017-01-23 18:40:52 --> Language Class Initialized
DEBUG - 2017-01-23 18:40:52 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:40:52 --> Utf8 Class Initialized
INFO - 2017-01-23 18:40:52 --> URI Class Initialized
INFO - 2017-01-23 18:40:52 --> Router Class Initialized
INFO - 2017-01-23 18:40:52 --> Output Class Initialized
INFO - 2017-01-23 18:40:52 --> Security Class Initialized
DEBUG - 2017-01-23 18:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:40:52 --> Input Class Initialized
INFO - 2017-01-23 18:40:52 --> Language Class Initialized
INFO - 2017-01-23 18:40:52 --> Config Class Initialized
INFO - 2017-01-23 18:40:52 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:40:52 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:40:52 --> Loader Class Initialized
INFO - 2017-01-23 18:40:52 --> Loader Class Initialized
INFO - 2017-01-23 18:40:52 --> Utf8 Class Initialized
INFO - 2017-01-23 18:40:52 --> URI Class Initialized
INFO - 2017-01-23 18:40:52 --> Router Class Initialized
INFO - 2017-01-23 18:40:52 --> Output Class Initialized
INFO - 2017-01-23 18:40:52 --> Security Class Initialized
DEBUG - 2017-01-23 18:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:40:52 --> Input Class Initialized
INFO - 2017-01-23 18:40:52 --> Language Class Initialized
INFO - 2017-01-23 18:40:52 --> Loader Class Initialized
INFO - 2017-01-23 18:40:52 --> Database Driver Class Initialized
INFO - 2017-01-23 18:40:52 --> Database Driver Class Initialized
INFO - 2017-01-23 18:40:52 --> Database Driver Class Initialized
INFO - 2017-01-23 18:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:40:52 --> Controller Class Initialized
ERROR - 2017-01-23 18:40:52 --> Severity: Warning --> unlink(/tmp/ci_session4103a61d9dcfebb9f706b6b625d9d7e6145c661e): No such file or directory /home/graduafe/public_html/system/libraries/Session/drivers/Session_files_driver.php 311
ERROR - 2017-01-23 18:40:52 --> Severity: Warning --> unlink(/tmp/ci_session4103a61d9dcfebb9f706b6b625d9d7e6145c661e): No such file or directory /home/graduafe/public_html/system/libraries/Session/drivers/Session_files_driver.php 311
INFO - 2017-01-23 18:40:52 --> Helper loaded: date_helper
INFO - 2017-01-23 18:40:52 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:40:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-23 18:40:52 --> Severity: Warning --> session_regenerate_id(): Session object destruction failed /home/graduafe/public_html/system/libraries/Session/Session.php 644
ERROR - 2017-01-23 18:40:52 --> Severity: Warning --> session_regenerate_id(): Session object destruction failed /home/graduafe/public_html/system/libraries/Session/Session.php 644
INFO - 2017-01-23 18:40:53 --> Helper loaded: form_helper
INFO - 2017-01-23 18:40:53 --> Form Validation Class Initialized
INFO - 2017-01-23 18:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:40:53 --> Controller Class Initialized
INFO - 2017-01-23 18:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:40:53 --> Controller Class Initialized
INFO - 2017-01-23 18:40:53 --> Helper loaded: date_helper
INFO - 2017-01-23 18:40:53 --> Helper loaded: date_helper
INFO - 2017-01-23 18:40:53 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:40:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:40:53 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:40:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:40:53 --> Helper loaded: form_helper
INFO - 2017-01-23 18:40:53 --> Form Validation Class Initialized
INFO - 2017-01-23 18:40:53 --> Helper loaded: form_helper
INFO - 2017-01-23 18:40:53 --> Form Validation Class Initialized
INFO - 2017-01-23 18:40:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 18:40:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 18:40:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 18:40:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 18:40:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 18:40:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 18:40:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-23 18:40:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-23 18:40:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-23 18:40:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-23 18:40:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-23 18:40:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-23 18:40:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 18:40:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 18:40:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 18:40:53 --> Final output sent to browser
DEBUG - 2017-01-23 18:40:53 --> Total execution time: 0.3873
INFO - 2017-01-23 18:40:53 --> Final output sent to browser
DEBUG - 2017-01-23 18:40:53 --> Total execution time: 0.3904
INFO - 2017-01-23 18:40:53 --> Config Class Initialized
INFO - 2017-01-23 18:40:53 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:40:53 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:40:53 --> Utf8 Class Initialized
INFO - 2017-01-23 18:40:53 --> URI Class Initialized
INFO - 2017-01-23 18:40:53 --> Router Class Initialized
INFO - 2017-01-23 18:40:53 --> Output Class Initialized
INFO - 2017-01-23 18:40:53 --> Security Class Initialized
DEBUG - 2017-01-23 18:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:40:53 --> Input Class Initialized
INFO - 2017-01-23 18:40:53 --> Language Class Initialized
INFO - 2017-01-23 18:40:53 --> Loader Class Initialized
INFO - 2017-01-23 18:40:53 --> Database Driver Class Initialized
INFO - 2017-01-23 18:40:53 --> Config Class Initialized
INFO - 2017-01-23 18:40:53 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:40:53 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:40:53 --> Utf8 Class Initialized
INFO - 2017-01-23 18:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:40:53 --> Controller Class Initialized
INFO - 2017-01-23 18:40:53 --> Helper loaded: date_helper
INFO - 2017-01-23 18:40:53 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:40:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:40:53 --> Helper loaded: form_helper
INFO - 2017-01-23 18:40:53 --> Form Validation Class Initialized
INFO - 2017-01-23 18:40:53 --> URI Class Initialized
INFO - 2017-01-23 18:40:53 --> Router Class Initialized
INFO - 2017-01-23 18:40:53 --> Final output sent to browser
DEBUG - 2017-01-23 18:40:53 --> Total execution time: 0.0858
INFO - 2017-01-23 18:40:53 --> Output Class Initialized
INFO - 2017-01-23 18:40:53 --> Security Class Initialized
DEBUG - 2017-01-23 18:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:40:53 --> Input Class Initialized
INFO - 2017-01-23 18:40:53 --> Language Class Initialized
INFO - 2017-01-23 18:40:53 --> Loader Class Initialized
INFO - 2017-01-23 18:40:53 --> Database Driver Class Initialized
INFO - 2017-01-23 18:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:40:53 --> Controller Class Initialized
INFO - 2017-01-23 18:40:53 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:40:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:40:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:40:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:40:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:40:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:40:53 --> Final output sent to browser
DEBUG - 2017-01-23 18:40:53 --> Total execution time: 0.1001
INFO - 2017-01-23 18:41:00 --> Config Class Initialized
INFO - 2017-01-23 18:41:00 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:41:00 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:41:00 --> Utf8 Class Initialized
INFO - 2017-01-23 18:41:00 --> URI Class Initialized
DEBUG - 2017-01-23 18:41:00 --> No URI present. Default controller set.
INFO - 2017-01-23 18:41:00 --> Router Class Initialized
INFO - 2017-01-23 18:41:00 --> Output Class Initialized
INFO - 2017-01-23 18:41:00 --> Security Class Initialized
DEBUG - 2017-01-23 18:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:41:00 --> Input Class Initialized
INFO - 2017-01-23 18:41:00 --> Language Class Initialized
INFO - 2017-01-23 18:41:00 --> Loader Class Initialized
INFO - 2017-01-23 18:41:00 --> Database Driver Class Initialized
INFO - 2017-01-23 18:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:41:00 --> Controller Class Initialized
INFO - 2017-01-23 18:41:00 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:41:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:41:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:41:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:41:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:41:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:41:00 --> Final output sent to browser
DEBUG - 2017-01-23 18:41:00 --> Total execution time: 0.6932
INFO - 2017-01-23 18:41:01 --> Config Class Initialized
INFO - 2017-01-23 18:41:01 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:41:01 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:41:01 --> Utf8 Class Initialized
INFO - 2017-01-23 18:41:01 --> URI Class Initialized
INFO - 2017-01-23 18:41:01 --> Router Class Initialized
INFO - 2017-01-23 18:41:01 --> Output Class Initialized
INFO - 2017-01-23 18:41:01 --> Security Class Initialized
DEBUG - 2017-01-23 18:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:41:01 --> Input Class Initialized
INFO - 2017-01-23 18:41:01 --> Language Class Initialized
INFO - 2017-01-23 18:41:01 --> Loader Class Initialized
INFO - 2017-01-23 18:41:01 --> Database Driver Class Initialized
INFO - 2017-01-23 18:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:41:01 --> Controller Class Initialized
INFO - 2017-01-23 18:41:01 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:41:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:41:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:41:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:41:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:41:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:41:01 --> Final output sent to browser
DEBUG - 2017-01-23 18:41:01 --> Total execution time: 0.0166
INFO - 2017-01-23 18:41:14 --> Config Class Initialized
INFO - 2017-01-23 18:41:14 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:41:14 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:41:14 --> Utf8 Class Initialized
INFO - 2017-01-23 18:41:14 --> URI Class Initialized
INFO - 2017-01-23 18:41:14 --> Router Class Initialized
INFO - 2017-01-23 18:41:14 --> Output Class Initialized
INFO - 2017-01-23 18:41:14 --> Security Class Initialized
DEBUG - 2017-01-23 18:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:41:14 --> Input Class Initialized
INFO - 2017-01-23 18:41:14 --> Language Class Initialized
INFO - 2017-01-23 18:41:14 --> Loader Class Initialized
INFO - 2017-01-23 18:41:14 --> Database Driver Class Initialized
INFO - 2017-01-23 18:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:41:14 --> Controller Class Initialized
INFO - 2017-01-23 18:41:14 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:41:14 --> Helper loaded: form_helper
INFO - 2017-01-23 18:41:14 --> Form Validation Class Initialized
INFO - 2017-01-23 18:41:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 18:41:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-23 18:41:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 18:41:14 --> Final output sent to browser
DEBUG - 2017-01-23 18:41:14 --> Total execution time: 0.0445
INFO - 2017-01-23 18:41:22 --> Config Class Initialized
INFO - 2017-01-23 18:41:22 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:41:22 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:41:22 --> Utf8 Class Initialized
INFO - 2017-01-23 18:41:22 --> URI Class Initialized
INFO - 2017-01-23 18:41:22 --> Router Class Initialized
INFO - 2017-01-23 18:41:22 --> Output Class Initialized
INFO - 2017-01-23 18:41:22 --> Security Class Initialized
DEBUG - 2017-01-23 18:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:41:22 --> Input Class Initialized
INFO - 2017-01-23 18:41:22 --> Language Class Initialized
INFO - 2017-01-23 18:41:22 --> Loader Class Initialized
INFO - 2017-01-23 18:41:22 --> Database Driver Class Initialized
INFO - 2017-01-23 18:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:41:22 --> Controller Class Initialized
INFO - 2017-01-23 18:41:22 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:41:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:41:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:41:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:41:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:41:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:41:22 --> Final output sent to browser
DEBUG - 2017-01-23 18:41:22 --> Total execution time: 4.0095
INFO - 2017-01-23 18:43:37 --> Config Class Initialized
INFO - 2017-01-23 18:43:37 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:43:37 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:43:37 --> Utf8 Class Initialized
INFO - 2017-01-23 18:43:37 --> URI Class Initialized
INFO - 2017-01-23 18:43:37 --> Router Class Initialized
INFO - 2017-01-23 18:43:37 --> Output Class Initialized
INFO - 2017-01-23 18:43:37 --> Security Class Initialized
DEBUG - 2017-01-23 18:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:43:37 --> Input Class Initialized
INFO - 2017-01-23 18:43:37 --> Language Class Initialized
INFO - 2017-01-23 18:43:37 --> Loader Class Initialized
INFO - 2017-01-23 18:43:37 --> Database Driver Class Initialized
INFO - 2017-01-23 18:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:43:37 --> Controller Class Initialized
INFO - 2017-01-23 18:43:37 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:43:37 --> Helper loaded: form_helper
INFO - 2017-01-23 18:43:37 --> Form Validation Class Initialized
INFO - 2017-01-23 18:43:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-23 18:43:39 --> Config Class Initialized
INFO - 2017-01-23 18:43:39 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:43:39 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:43:39 --> Utf8 Class Initialized
INFO - 2017-01-23 18:43:39 --> URI Class Initialized
INFO - 2017-01-23 18:43:39 --> Router Class Initialized
INFO - 2017-01-23 18:43:39 --> Output Class Initialized
INFO - 2017-01-23 18:43:39 --> Security Class Initialized
DEBUG - 2017-01-23 18:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:43:39 --> Input Class Initialized
INFO - 2017-01-23 18:43:39 --> Language Class Initialized
INFO - 2017-01-23 18:43:39 --> Loader Class Initialized
INFO - 2017-01-23 18:43:39 --> Database Driver Class Initialized
INFO - 2017-01-23 18:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:43:39 --> Controller Class Initialized
INFO - 2017-01-23 18:43:39 --> Helper loaded: date_helper
INFO - 2017-01-23 18:43:39 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:43:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:43:39 --> Helper loaded: form_helper
INFO - 2017-01-23 18:43:39 --> Form Validation Class Initialized
INFO - 2017-01-23 18:43:39 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 18:43:39 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 18:43:39 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-23 18:43:39 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-23 18:43:39 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 18:43:39 --> Final output sent to browser
DEBUG - 2017-01-23 18:43:39 --> Total execution time: 0.0796
INFO - 2017-01-23 18:43:40 --> Config Class Initialized
INFO - 2017-01-23 18:43:40 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:43:40 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:43:40 --> Utf8 Class Initialized
INFO - 2017-01-23 18:43:40 --> URI Class Initialized
INFO - 2017-01-23 18:43:40 --> Router Class Initialized
INFO - 2017-01-23 18:43:40 --> Output Class Initialized
INFO - 2017-01-23 18:43:40 --> Security Class Initialized
DEBUG - 2017-01-23 18:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:43:40 --> Input Class Initialized
INFO - 2017-01-23 18:43:40 --> Language Class Initialized
INFO - 2017-01-23 18:43:40 --> Loader Class Initialized
INFO - 2017-01-23 18:43:40 --> Database Driver Class Initialized
INFO - 2017-01-23 18:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:43:40 --> Controller Class Initialized
INFO - 2017-01-23 18:43:40 --> Helper loaded: date_helper
INFO - 2017-01-23 18:43:40 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:43:40 --> Helper loaded: form_helper
INFO - 2017-01-23 18:43:40 --> Form Validation Class Initialized
INFO - 2017-01-23 18:43:40 --> Final output sent to browser
DEBUG - 2017-01-23 18:43:40 --> Total execution time: 0.0362
INFO - 2017-01-23 18:43:40 --> Config Class Initialized
INFO - 2017-01-23 18:43:40 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:43:40 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:43:40 --> Utf8 Class Initialized
INFO - 2017-01-23 18:43:40 --> URI Class Initialized
INFO - 2017-01-23 18:43:40 --> Router Class Initialized
INFO - 2017-01-23 18:43:40 --> Output Class Initialized
INFO - 2017-01-23 18:43:40 --> Security Class Initialized
DEBUG - 2017-01-23 18:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:43:40 --> Input Class Initialized
INFO - 2017-01-23 18:43:40 --> Language Class Initialized
INFO - 2017-01-23 18:43:40 --> Loader Class Initialized
INFO - 2017-01-23 18:43:40 --> Database Driver Class Initialized
INFO - 2017-01-23 18:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:43:40 --> Controller Class Initialized
INFO - 2017-01-23 18:43:40 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:43:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:43:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:43:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:43:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:43:40 --> Final output sent to browser
DEBUG - 2017-01-23 18:43:40 --> Total execution time: 0.0176
INFO - 2017-01-23 18:43:41 --> Config Class Initialized
INFO - 2017-01-23 18:43:41 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:43:41 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:43:41 --> Utf8 Class Initialized
INFO - 2017-01-23 18:43:41 --> URI Class Initialized
INFO - 2017-01-23 18:43:41 --> Router Class Initialized
INFO - 2017-01-23 18:43:41 --> Output Class Initialized
INFO - 2017-01-23 18:43:41 --> Security Class Initialized
DEBUG - 2017-01-23 18:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:43:41 --> Input Class Initialized
INFO - 2017-01-23 18:43:41 --> Language Class Initialized
INFO - 2017-01-23 18:43:41 --> Loader Class Initialized
INFO - 2017-01-23 18:43:41 --> Database Driver Class Initialized
INFO - 2017-01-23 18:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:43:41 --> Controller Class Initialized
INFO - 2017-01-23 18:43:41 --> Helper loaded: date_helper
INFO - 2017-01-23 18:43:41 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:43:41 --> Helper loaded: form_helper
INFO - 2017-01-23 18:43:41 --> Form Validation Class Initialized
INFO - 2017-01-23 18:43:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 18:43:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 18:43:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pagos.php
INFO - 2017-01-23 18:43:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pagos.php
INFO - 2017-01-23 18:43:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 18:43:41 --> Final output sent to browser
DEBUG - 2017-01-23 18:43:41 --> Total execution time: 0.0890
INFO - 2017-01-23 18:43:42 --> Config Class Initialized
INFO - 2017-01-23 18:43:42 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:43:42 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:43:42 --> Utf8 Class Initialized
INFO - 2017-01-23 18:43:42 --> URI Class Initialized
INFO - 2017-01-23 18:43:42 --> Router Class Initialized
INFO - 2017-01-23 18:43:42 --> Output Class Initialized
INFO - 2017-01-23 18:43:42 --> Security Class Initialized
DEBUG - 2017-01-23 18:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:43:42 --> Input Class Initialized
INFO - 2017-01-23 18:43:42 --> Language Class Initialized
INFO - 2017-01-23 18:43:42 --> Loader Class Initialized
INFO - 2017-01-23 18:43:42 --> Database Driver Class Initialized
INFO - 2017-01-23 18:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:43:42 --> Controller Class Initialized
INFO - 2017-01-23 18:43:42 --> Helper loaded: date_helper
INFO - 2017-01-23 18:43:42 --> Config Class Initialized
INFO - 2017-01-23 18:43:42 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:43:42 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:43:42 --> Utf8 Class Initialized
INFO - 2017-01-23 18:43:42 --> URI Class Initialized
INFO - 2017-01-23 18:43:42 --> Router Class Initialized
INFO - 2017-01-23 18:43:42 --> Output Class Initialized
INFO - 2017-01-23 18:43:42 --> Security Class Initialized
INFO - 2017-01-23 18:43:42 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:43:42 --> Helper loaded: form_helper
INFO - 2017-01-23 18:43:42 --> Form Validation Class Initialized
INFO - 2017-01-23 18:43:42 --> Final output sent to browser
DEBUG - 2017-01-23 18:43:42 --> Total execution time: 0.1004
DEBUG - 2017-01-23 18:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:43:42 --> Input Class Initialized
INFO - 2017-01-23 18:43:42 --> Language Class Initialized
INFO - 2017-01-23 18:43:42 --> Loader Class Initialized
INFO - 2017-01-23 18:43:42 --> Database Driver Class Initialized
INFO - 2017-01-23 18:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:43:42 --> Controller Class Initialized
INFO - 2017-01-23 18:43:42 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:43:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:43:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:43:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:43:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:43:42 --> Final output sent to browser
DEBUG - 2017-01-23 18:43:42 --> Total execution time: 0.0251
INFO - 2017-01-23 18:43:44 --> Config Class Initialized
INFO - 2017-01-23 18:43:44 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:43:44 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:43:44 --> Utf8 Class Initialized
INFO - 2017-01-23 18:43:44 --> URI Class Initialized
INFO - 2017-01-23 18:43:44 --> Router Class Initialized
INFO - 2017-01-23 18:43:44 --> Output Class Initialized
INFO - 2017-01-23 18:43:44 --> Security Class Initialized
DEBUG - 2017-01-23 18:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:43:44 --> Input Class Initialized
INFO - 2017-01-23 18:43:44 --> Language Class Initialized
INFO - 2017-01-23 18:43:44 --> Loader Class Initialized
INFO - 2017-01-23 18:43:44 --> Database Driver Class Initialized
INFO - 2017-01-23 18:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:43:44 --> Controller Class Initialized
INFO - 2017-01-23 18:43:44 --> Helper loaded: date_helper
INFO - 2017-01-23 18:43:44 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:43:44 --> Helper loaded: form_helper
INFO - 2017-01-23 18:43:44 --> Form Validation Class Initialized
INFO - 2017-01-23 18:43:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 18:43:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 18:43:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-23 18:43:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-23 18:43:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 18:43:44 --> Final output sent to browser
DEBUG - 2017-01-23 18:43:44 --> Total execution time: 0.0147
INFO - 2017-01-23 18:43:44 --> Config Class Initialized
INFO - 2017-01-23 18:43:44 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:43:44 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:43:44 --> Utf8 Class Initialized
INFO - 2017-01-23 18:43:44 --> URI Class Initialized
INFO - 2017-01-23 18:43:44 --> Router Class Initialized
INFO - 2017-01-23 18:43:44 --> Output Class Initialized
INFO - 2017-01-23 18:43:44 --> Security Class Initialized
DEBUG - 2017-01-23 18:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:43:44 --> Input Class Initialized
INFO - 2017-01-23 18:43:44 --> Language Class Initialized
INFO - 2017-01-23 18:43:44 --> Loader Class Initialized
INFO - 2017-01-23 18:43:44 --> Database Driver Class Initialized
INFO - 2017-01-23 18:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:43:44 --> Controller Class Initialized
INFO - 2017-01-23 18:43:44 --> Helper loaded: date_helper
INFO - 2017-01-23 18:43:44 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:43:44 --> Helper loaded: form_helper
INFO - 2017-01-23 18:43:44 --> Form Validation Class Initialized
INFO - 2017-01-23 18:43:44 --> Final output sent to browser
DEBUG - 2017-01-23 18:43:44 --> Total execution time: 0.0146
INFO - 2017-01-23 18:43:44 --> Config Class Initialized
INFO - 2017-01-23 18:43:44 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:43:44 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:43:44 --> Utf8 Class Initialized
INFO - 2017-01-23 18:43:44 --> URI Class Initialized
INFO - 2017-01-23 18:43:44 --> Router Class Initialized
INFO - 2017-01-23 18:43:44 --> Output Class Initialized
INFO - 2017-01-23 18:43:44 --> Security Class Initialized
DEBUG - 2017-01-23 18:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:43:44 --> Input Class Initialized
INFO - 2017-01-23 18:43:44 --> Language Class Initialized
INFO - 2017-01-23 18:43:44 --> Loader Class Initialized
INFO - 2017-01-23 18:43:44 --> Database Driver Class Initialized
INFO - 2017-01-23 18:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:43:44 --> Controller Class Initialized
INFO - 2017-01-23 18:43:44 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:43:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:43:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:43:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:43:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:43:44 --> Final output sent to browser
DEBUG - 2017-01-23 18:43:44 --> Total execution time: 0.0688
INFO - 2017-01-23 18:43:51 --> Config Class Initialized
INFO - 2017-01-23 18:43:51 --> Config Class Initialized
INFO - 2017-01-23 18:43:51 --> Hooks Class Initialized
INFO - 2017-01-23 18:43:51 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:43:51 --> UTF-8 Support Enabled
DEBUG - 2017-01-23 18:43:51 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:43:51 --> Utf8 Class Initialized
INFO - 2017-01-23 18:43:51 --> Utf8 Class Initialized
INFO - 2017-01-23 18:43:51 --> URI Class Initialized
INFO - 2017-01-23 18:43:51 --> URI Class Initialized
INFO - 2017-01-23 18:43:51 --> Router Class Initialized
INFO - 2017-01-23 18:43:51 --> Router Class Initialized
INFO - 2017-01-23 18:43:51 --> Output Class Initialized
INFO - 2017-01-23 18:43:51 --> Output Class Initialized
INFO - 2017-01-23 18:43:51 --> Security Class Initialized
INFO - 2017-01-23 18:43:51 --> Security Class Initialized
DEBUG - 2017-01-23 18:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-01-23 18:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:43:51 --> Input Class Initialized
INFO - 2017-01-23 18:43:51 --> Input Class Initialized
INFO - 2017-01-23 18:43:51 --> Language Class Initialized
INFO - 2017-01-23 18:43:51 --> Language Class Initialized
INFO - 2017-01-23 18:43:51 --> Loader Class Initialized
INFO - 2017-01-23 18:43:51 --> Database Driver Class Initialized
INFO - 2017-01-23 18:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:43:51 --> Controller Class Initialized
INFO - 2017-01-23 18:43:51 --> Helper loaded: date_helper
INFO - 2017-01-23 18:43:51 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:43:51 --> Helper loaded: form_helper
INFO - 2017-01-23 18:43:51 --> Form Validation Class Initialized
INFO - 2017-01-23 18:43:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 18:43:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 18:43:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-23 18:43:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-23 18:43:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 18:43:51 --> Final output sent to browser
DEBUG - 2017-01-23 18:43:51 --> Total execution time: 2.5659
INFO - 2017-01-23 18:43:51 --> Loader Class Initialized
INFO - 2017-01-23 18:43:51 --> Database Driver Class Initialized
INFO - 2017-01-23 18:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:43:51 --> Controller Class Initialized
INFO - 2017-01-23 18:43:51 --> Upload Class Initialized
INFO - 2017-01-23 18:43:51 --> Helper loaded: date_helper
INFO - 2017-01-23 18:43:51 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:43:51 --> Helper loaded: form_helper
INFO - 2017-01-23 18:43:51 --> Form Validation Class Initialized
INFO - 2017-01-23 18:43:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 18:43:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 18:43:51 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-23 18:43:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-23 18:43:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-23 18:43:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 18:43:52 --> Final output sent to browser
DEBUG - 2017-01-23 18:43:52 --> Total execution time: 3.9589
INFO - 2017-01-23 18:43:52 --> Config Class Initialized
INFO - 2017-01-23 18:43:52 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:43:52 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:43:52 --> Utf8 Class Initialized
INFO - 2017-01-23 18:43:52 --> URI Class Initialized
INFO - 2017-01-23 18:43:52 --> Router Class Initialized
INFO - 2017-01-23 18:43:52 --> Output Class Initialized
INFO - 2017-01-23 18:43:52 --> Security Class Initialized
DEBUG - 2017-01-23 18:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:43:52 --> Input Class Initialized
INFO - 2017-01-23 18:43:52 --> Language Class Initialized
INFO - 2017-01-23 18:43:52 --> Loader Class Initialized
INFO - 2017-01-23 18:43:52 --> Database Driver Class Initialized
INFO - 2017-01-23 18:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:43:52 --> Controller Class Initialized
INFO - 2017-01-23 18:43:52 --> Helper loaded: date_helper
INFO - 2017-01-23 18:43:52 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:43:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:43:52 --> Helper loaded: form_helper
INFO - 2017-01-23 18:43:52 --> Form Validation Class Initialized
INFO - 2017-01-23 18:43:52 --> Final output sent to browser
DEBUG - 2017-01-23 18:43:52 --> Total execution time: 0.0778
INFO - 2017-01-23 18:43:52 --> Config Class Initialized
INFO - 2017-01-23 18:43:52 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:43:52 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:43:52 --> Utf8 Class Initialized
INFO - 2017-01-23 18:43:52 --> URI Class Initialized
INFO - 2017-01-23 18:43:52 --> Router Class Initialized
INFO - 2017-01-23 18:43:52 --> Output Class Initialized
INFO - 2017-01-23 18:43:52 --> Security Class Initialized
DEBUG - 2017-01-23 18:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:43:52 --> Input Class Initialized
INFO - 2017-01-23 18:43:52 --> Language Class Initialized
INFO - 2017-01-23 18:43:52 --> Loader Class Initialized
INFO - 2017-01-23 18:43:52 --> Database Driver Class Initialized
INFO - 2017-01-23 18:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:43:52 --> Controller Class Initialized
INFO - 2017-01-23 18:43:52 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:43:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:43:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:43:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:43:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:43:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:43:52 --> Final output sent to browser
DEBUG - 2017-01-23 18:43:52 --> Total execution time: 0.0146
INFO - 2017-01-23 18:43:56 --> Config Class Initialized
INFO - 2017-01-23 18:43:56 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:43:56 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:43:58 --> Utf8 Class Initialized
INFO - 2017-01-23 18:43:58 --> URI Class Initialized
INFO - 2017-01-23 18:43:58 --> Router Class Initialized
INFO - 2017-01-23 18:43:58 --> Output Class Initialized
INFO - 2017-01-23 18:43:58 --> Security Class Initialized
DEBUG - 2017-01-23 18:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:43:58 --> Input Class Initialized
INFO - 2017-01-23 18:43:58 --> Language Class Initialized
INFO - 2017-01-23 18:43:58 --> Loader Class Initialized
INFO - 2017-01-23 18:43:58 --> Database Driver Class Initialized
INFO - 2017-01-23 18:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:43:58 --> Controller Class Initialized
INFO - 2017-01-23 18:43:58 --> Helper loaded: date_helper
INFO - 2017-01-23 18:43:58 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:43:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:43:58 --> Helper loaded: form_helper
INFO - 2017-01-23 18:43:58 --> Form Validation Class Initialized
INFO - 2017-01-23 18:43:58 --> Final output sent to browser
DEBUG - 2017-01-23 18:43:58 --> Total execution time: 1.7655
INFO - 2017-01-23 18:43:58 --> Config Class Initialized
INFO - 2017-01-23 18:43:58 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:43:58 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:43:58 --> Utf8 Class Initialized
INFO - 2017-01-23 18:43:58 --> URI Class Initialized
INFO - 2017-01-23 18:43:58 --> Router Class Initialized
INFO - 2017-01-23 18:43:58 --> Output Class Initialized
INFO - 2017-01-23 18:43:58 --> Security Class Initialized
DEBUG - 2017-01-23 18:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:43:58 --> Input Class Initialized
INFO - 2017-01-23 18:43:58 --> Language Class Initialized
INFO - 2017-01-23 18:43:58 --> Loader Class Initialized
INFO - 2017-01-23 18:43:58 --> Database Driver Class Initialized
INFO - 2017-01-23 18:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:43:58 --> Controller Class Initialized
INFO - 2017-01-23 18:43:58 --> Helper loaded: date_helper
INFO - 2017-01-23 18:43:58 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:43:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:43:58 --> Helper loaded: form_helper
INFO - 2017-01-23 18:43:58 --> Form Validation Class Initialized
INFO - 2017-01-23 18:43:58 --> Final output sent to browser
DEBUG - 2017-01-23 18:43:58 --> Total execution time: 0.0164
INFO - 2017-01-23 18:44:14 --> Config Class Initialized
INFO - 2017-01-23 18:44:14 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:44:14 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:44:14 --> Utf8 Class Initialized
INFO - 2017-01-23 18:44:14 --> URI Class Initialized
INFO - 2017-01-23 18:44:14 --> Router Class Initialized
INFO - 2017-01-23 18:44:14 --> Output Class Initialized
INFO - 2017-01-23 18:44:14 --> Security Class Initialized
DEBUG - 2017-01-23 18:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:44:14 --> Input Class Initialized
INFO - 2017-01-23 18:44:14 --> Language Class Initialized
INFO - 2017-01-23 18:44:14 --> Loader Class Initialized
INFO - 2017-01-23 18:44:14 --> Database Driver Class Initialized
INFO - 2017-01-23 18:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:44:14 --> Controller Class Initialized
INFO - 2017-01-23 18:44:14 --> Upload Class Initialized
INFO - 2017-01-23 18:44:14 --> Helper loaded: date_helper
INFO - 2017-01-23 18:44:14 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:44:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:44:14 --> Helper loaded: form_helper
INFO - 2017-01-23 18:44:14 --> Form Validation Class Initialized
INFO - 2017-01-23 18:44:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 18:44:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 18:44:14 --> Config Class Initialized
INFO - 2017-01-23 18:44:14 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:44:14 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:44:14 --> Utf8 Class Initialized
INFO - 2017-01-23 18:44:14 --> URI Class Initialized
INFO - 2017-01-23 18:44:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-23 18:44:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-23 18:44:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-23 18:44:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 18:44:14 --> Config Class Initialized
INFO - 2017-01-23 18:44:14 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:44:14 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:44:14 --> Utf8 Class Initialized
INFO - 2017-01-23 18:44:14 --> URI Class Initialized
INFO - 2017-01-23 18:44:14 --> Router Class Initialized
INFO - 2017-01-23 18:44:14 --> Output Class Initialized
INFO - 2017-01-23 18:44:14 --> Security Class Initialized
DEBUG - 2017-01-23 18:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:44:14 --> Input Class Initialized
INFO - 2017-01-23 18:44:14 --> Language Class Initialized
INFO - 2017-01-23 18:44:14 --> Final output sent to browser
DEBUG - 2017-01-23 18:44:14 --> Total execution time: 0.1815
INFO - 2017-01-23 18:44:14 --> Router Class Initialized
INFO - 2017-01-23 18:44:14 --> Output Class Initialized
INFO - 2017-01-23 18:44:14 --> Security Class Initialized
DEBUG - 2017-01-23 18:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:44:14 --> Input Class Initialized
INFO - 2017-01-23 18:44:14 --> Language Class Initialized
INFO - 2017-01-23 18:44:14 --> Loader Class Initialized
INFO - 2017-01-23 18:44:14 --> Database Driver Class Initialized
INFO - 2017-01-23 18:44:14 --> Loader Class Initialized
INFO - 2017-01-23 18:44:14 --> Database Driver Class Initialized
INFO - 2017-01-23 18:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:44:14 --> Controller Class Initialized
INFO - 2017-01-23 18:44:14 --> Upload Class Initialized
INFO - 2017-01-23 18:44:14 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:44:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:44:14 --> Helper loaded: form_helper
INFO - 2017-01-23 18:44:14 --> Form Validation Class Initialized
INFO - 2017-01-23 18:44:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 18:44:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 18:44:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-23 18:44:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-23 18:44:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-23 18:44:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 18:44:14 --> Final output sent to browser
DEBUG - 2017-01-23 18:44:14 --> Total execution time: 0.1613
INFO - 2017-01-23 18:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:44:14 --> Controller Class Initialized
INFO - 2017-01-23 18:44:14 --> Upload Class Initialized
INFO - 2017-01-23 18:44:14 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:44:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:44:14 --> Helper loaded: form_helper
INFO - 2017-01-23 18:44:14 --> Form Validation Class Initialized
INFO - 2017-01-23 18:44:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 18:44:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 18:44:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-23 18:44:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-23 18:44:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-23 18:44:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 18:44:14 --> Final output sent to browser
DEBUG - 2017-01-23 18:44:14 --> Total execution time: 0.1741
INFO - 2017-01-23 18:44:15 --> Config Class Initialized
INFO - 2017-01-23 18:44:15 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:44:15 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:44:15 --> Utf8 Class Initialized
INFO - 2017-01-23 18:44:15 --> URI Class Initialized
INFO - 2017-01-23 18:44:15 --> Router Class Initialized
INFO - 2017-01-23 18:44:15 --> Output Class Initialized
INFO - 2017-01-23 18:44:15 --> Security Class Initialized
DEBUG - 2017-01-23 18:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:44:15 --> Input Class Initialized
INFO - 2017-01-23 18:44:15 --> Language Class Initialized
INFO - 2017-01-23 18:44:15 --> Loader Class Initialized
INFO - 2017-01-23 18:44:15 --> Database Driver Class Initialized
INFO - 2017-01-23 18:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:44:15 --> Controller Class Initialized
INFO - 2017-01-23 18:44:15 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:44:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:44:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:44:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:44:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:44:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:44:15 --> Final output sent to browser
DEBUG - 2017-01-23 18:44:15 --> Total execution time: 0.0221
INFO - 2017-01-23 18:47:05 --> Config Class Initialized
INFO - 2017-01-23 18:47:05 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:47:06 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:47:06 --> Utf8 Class Initialized
INFO - 2017-01-23 18:47:06 --> URI Class Initialized
INFO - 2017-01-23 18:47:06 --> Router Class Initialized
INFO - 2017-01-23 18:47:06 --> Output Class Initialized
INFO - 2017-01-23 18:47:06 --> Security Class Initialized
DEBUG - 2017-01-23 18:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:47:06 --> Input Class Initialized
INFO - 2017-01-23 18:47:06 --> Language Class Initialized
INFO - 2017-01-23 18:47:07 --> Loader Class Initialized
INFO - 2017-01-23 18:47:07 --> Database Driver Class Initialized
INFO - 2017-01-23 18:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:47:09 --> Controller Class Initialized
INFO - 2017-01-23 18:47:09 --> Helper loaded: date_helper
INFO - 2017-01-23 18:47:09 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:47:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:47:09 --> Helper loaded: form_helper
INFO - 2017-01-23 18:47:09 --> Form Validation Class Initialized
INFO - 2017-01-23 18:47:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 18:47:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 18:47:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-23 18:47:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-23 18:47:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 18:47:09 --> Final output sent to browser
DEBUG - 2017-01-23 18:47:09 --> Total execution time: 6.6391
INFO - 2017-01-23 18:47:14 --> Config Class Initialized
INFO - 2017-01-23 18:47:14 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:47:14 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:47:14 --> Utf8 Class Initialized
INFO - 2017-01-23 18:47:14 --> URI Class Initialized
INFO - 2017-01-23 18:47:14 --> Router Class Initialized
INFO - 2017-01-23 18:47:14 --> Output Class Initialized
INFO - 2017-01-23 18:47:14 --> Security Class Initialized
DEBUG - 2017-01-23 18:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:47:14 --> Input Class Initialized
INFO - 2017-01-23 18:47:14 --> Language Class Initialized
INFO - 2017-01-23 18:47:14 --> Loader Class Initialized
INFO - 2017-01-23 18:47:14 --> Database Driver Class Initialized
INFO - 2017-01-23 18:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:47:14 --> Controller Class Initialized
INFO - 2017-01-23 18:47:14 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:47:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:47:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:47:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:47:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:47:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:47:14 --> Final output sent to browser
DEBUG - 2017-01-23 18:47:14 --> Total execution time: 0.0849
INFO - 2017-01-23 18:47:19 --> Config Class Initialized
INFO - 2017-01-23 18:47:19 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:47:19 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:47:19 --> Utf8 Class Initialized
INFO - 2017-01-23 18:47:19 --> URI Class Initialized
INFO - 2017-01-23 18:47:19 --> Router Class Initialized
INFO - 2017-01-23 18:47:19 --> Output Class Initialized
INFO - 2017-01-23 18:47:19 --> Security Class Initialized
DEBUG - 2017-01-23 18:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:47:19 --> Input Class Initialized
INFO - 2017-01-23 18:47:19 --> Language Class Initialized
INFO - 2017-01-23 18:47:19 --> Loader Class Initialized
INFO - 2017-01-23 18:47:19 --> Database Driver Class Initialized
INFO - 2017-01-23 18:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:47:19 --> Controller Class Initialized
INFO - 2017-01-23 18:47:19 --> Helper loaded: date_helper
INFO - 2017-01-23 18:47:19 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:47:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:47:19 --> Helper loaded: form_helper
INFO - 2017-01-23 18:47:19 --> Form Validation Class Initialized
INFO - 2017-01-23 18:47:19 --> Final output sent to browser
DEBUG - 2017-01-23 18:47:19 --> Total execution time: 0.1804
INFO - 2017-01-23 18:47:44 --> Config Class Initialized
INFO - 2017-01-23 18:47:44 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:47:44 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:47:44 --> Utf8 Class Initialized
INFO - 2017-01-23 18:47:44 --> URI Class Initialized
INFO - 2017-01-23 18:47:44 --> Router Class Initialized
INFO - 2017-01-23 18:47:44 --> Output Class Initialized
INFO - 2017-01-23 18:47:44 --> Security Class Initialized
DEBUG - 2017-01-23 18:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:47:44 --> Input Class Initialized
INFO - 2017-01-23 18:47:44 --> Language Class Initialized
INFO - 2017-01-23 18:47:44 --> Loader Class Initialized
INFO - 2017-01-23 18:47:44 --> Database Driver Class Initialized
INFO - 2017-01-23 18:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:47:44 --> Controller Class Initialized
INFO - 2017-01-23 18:47:44 --> Helper loaded: date_helper
INFO - 2017-01-23 18:47:44 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:47:44 --> Helper loaded: form_helper
INFO - 2017-01-23 18:47:44 --> Form Validation Class Initialized
INFO - 2017-01-23 18:47:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 18:47:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 18:47:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-23 18:47:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-23 18:47:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 18:47:44 --> Final output sent to browser
DEBUG - 2017-01-23 18:47:44 --> Total execution time: 0.5464
INFO - 2017-01-23 18:47:44 --> Config Class Initialized
INFO - 2017-01-23 18:47:44 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:47:44 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:47:44 --> Utf8 Class Initialized
INFO - 2017-01-23 18:47:44 --> URI Class Initialized
INFO - 2017-01-23 18:47:44 --> Router Class Initialized
INFO - 2017-01-23 18:47:44 --> Output Class Initialized
INFO - 2017-01-23 18:47:44 --> Security Class Initialized
DEBUG - 2017-01-23 18:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:47:44 --> Input Class Initialized
INFO - 2017-01-23 18:47:44 --> Language Class Initialized
INFO - 2017-01-23 18:47:44 --> Loader Class Initialized
INFO - 2017-01-23 18:47:44 --> Database Driver Class Initialized
INFO - 2017-01-23 18:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:47:44 --> Controller Class Initialized
INFO - 2017-01-23 18:47:44 --> Helper loaded: date_helper
INFO - 2017-01-23 18:47:44 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:47:44 --> Helper loaded: form_helper
INFO - 2017-01-23 18:47:44 --> Form Validation Class Initialized
INFO - 2017-01-23 18:47:45 --> Config Class Initialized
INFO - 2017-01-23 18:47:45 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:47:45 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:47:45 --> Utf8 Class Initialized
INFO - 2017-01-23 18:47:45 --> Final output sent to browser
DEBUG - 2017-01-23 18:47:45 --> Total execution time: 0.1688
INFO - 2017-01-23 18:47:45 --> URI Class Initialized
INFO - 2017-01-23 18:47:45 --> Router Class Initialized
INFO - 2017-01-23 18:47:45 --> Output Class Initialized
INFO - 2017-01-23 18:47:45 --> Security Class Initialized
DEBUG - 2017-01-23 18:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:47:45 --> Input Class Initialized
INFO - 2017-01-23 18:47:45 --> Language Class Initialized
INFO - 2017-01-23 18:47:45 --> Loader Class Initialized
INFO - 2017-01-23 18:47:45 --> Database Driver Class Initialized
INFO - 2017-01-23 18:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:47:45 --> Controller Class Initialized
INFO - 2017-01-23 18:47:45 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:47:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:47:45 --> Final output sent to browser
DEBUG - 2017-01-23 18:47:45 --> Total execution time: 0.0854
INFO - 2017-01-23 18:47:46 --> Config Class Initialized
INFO - 2017-01-23 18:47:46 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:47:46 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:47:46 --> Utf8 Class Initialized
INFO - 2017-01-23 18:47:46 --> URI Class Initialized
INFO - 2017-01-23 18:47:46 --> Router Class Initialized
INFO - 2017-01-23 18:47:46 --> Output Class Initialized
INFO - 2017-01-23 18:47:46 --> Security Class Initialized
DEBUG - 2017-01-23 18:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:47:46 --> Input Class Initialized
INFO - 2017-01-23 18:47:46 --> Language Class Initialized
INFO - 2017-01-23 18:47:46 --> Loader Class Initialized
INFO - 2017-01-23 18:47:46 --> Database Driver Class Initialized
INFO - 2017-01-23 18:47:46 --> Config Class Initialized
INFO - 2017-01-23 18:47:46 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:47:46 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:47:46 --> Utf8 Class Initialized
INFO - 2017-01-23 18:47:46 --> URI Class Initialized
INFO - 2017-01-23 18:47:46 --> Router Class Initialized
INFO - 2017-01-23 18:47:46 --> Output Class Initialized
INFO - 2017-01-23 18:47:46 --> Security Class Initialized
DEBUG - 2017-01-23 18:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:47:46 --> Input Class Initialized
INFO - 2017-01-23 18:47:46 --> Language Class Initialized
INFO - 2017-01-23 18:47:46 --> Loader Class Initialized
INFO - 2017-01-23 18:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:47:46 --> Controller Class Initialized
INFO - 2017-01-23 18:47:46 --> Helper loaded: date_helper
INFO - 2017-01-23 18:47:46 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:47:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:47:46 --> Database Driver Class Initialized
INFO - 2017-01-23 18:47:46 --> Helper loaded: form_helper
INFO - 2017-01-23 18:47:46 --> Form Validation Class Initialized
INFO - 2017-01-23 18:47:46 --> Final output sent to browser
DEBUG - 2017-01-23 18:47:46 --> Total execution time: 0.0811
INFO - 2017-01-23 18:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:47:46 --> Controller Class Initialized
INFO - 2017-01-23 18:47:46 --> Helper loaded: date_helper
INFO - 2017-01-23 18:47:46 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:47:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:47:46 --> Helper loaded: form_helper
INFO - 2017-01-23 18:47:46 --> Form Validation Class Initialized
INFO - 2017-01-23 18:47:46 --> Final output sent to browser
DEBUG - 2017-01-23 18:47:46 --> Total execution time: 0.0916
INFO - 2017-01-23 18:54:43 --> Config Class Initialized
INFO - 2017-01-23 18:54:43 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:54:43 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:54:43 --> Utf8 Class Initialized
INFO - 2017-01-23 18:54:43 --> URI Class Initialized
INFO - 2017-01-23 18:54:43 --> Router Class Initialized
INFO - 2017-01-23 18:54:43 --> Output Class Initialized
INFO - 2017-01-23 18:54:43 --> Security Class Initialized
DEBUG - 2017-01-23 18:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:54:43 --> Input Class Initialized
INFO - 2017-01-23 18:54:43 --> Language Class Initialized
INFO - 2017-01-23 18:54:43 --> Loader Class Initialized
INFO - 2017-01-23 18:54:43 --> Database Driver Class Initialized
INFO - 2017-01-23 18:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:54:43 --> Controller Class Initialized
INFO - 2017-01-23 18:54:43 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:54:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:54:44 --> Config Class Initialized
INFO - 2017-01-23 18:54:44 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:54:44 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:54:44 --> Utf8 Class Initialized
INFO - 2017-01-23 18:54:44 --> URI Class Initialized
INFO - 2017-01-23 18:54:44 --> Router Class Initialized
INFO - 2017-01-23 18:54:44 --> Output Class Initialized
INFO - 2017-01-23 18:54:44 --> Security Class Initialized
DEBUG - 2017-01-23 18:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:54:44 --> Input Class Initialized
INFO - 2017-01-23 18:54:44 --> Language Class Initialized
INFO - 2017-01-23 18:54:44 --> Loader Class Initialized
INFO - 2017-01-23 18:54:44 --> Database Driver Class Initialized
INFO - 2017-01-23 18:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:54:44 --> Controller Class Initialized
INFO - 2017-01-23 18:54:44 --> Helper loaded: date_helper
INFO - 2017-01-23 18:54:44 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:54:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:54:44 --> Helper loaded: form_helper
INFO - 2017-01-23 18:54:44 --> Form Validation Class Initialized
INFO - 2017-01-23 18:54:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 18:54:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 18:54:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-23 18:54:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-23 18:54:44 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 18:54:44 --> Final output sent to browser
DEBUG - 2017-01-23 18:54:44 --> Total execution time: 0.2743
INFO - 2017-01-23 18:54:44 --> Config Class Initialized
INFO - 2017-01-23 18:54:44 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:54:44 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:54:44 --> Utf8 Class Initialized
INFO - 2017-01-23 18:54:44 --> URI Class Initialized
INFO - 2017-01-23 18:54:44 --> Router Class Initialized
INFO - 2017-01-23 18:54:44 --> Output Class Initialized
INFO - 2017-01-23 18:54:44 --> Security Class Initialized
DEBUG - 2017-01-23 18:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:54:44 --> Input Class Initialized
INFO - 2017-01-23 18:54:44 --> Language Class Initialized
INFO - 2017-01-23 18:54:44 --> Loader Class Initialized
INFO - 2017-01-23 18:54:44 --> Database Driver Class Initialized
INFO - 2017-01-23 18:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:54:44 --> Controller Class Initialized
INFO - 2017-01-23 18:54:44 --> Helper loaded: date_helper
INFO - 2017-01-23 18:54:44 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:54:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:54:44 --> Helper loaded: form_helper
INFO - 2017-01-23 18:54:44 --> Form Validation Class Initialized
INFO - 2017-01-23 18:54:44 --> Final output sent to browser
DEBUG - 2017-01-23 18:54:44 --> Total execution time: 0.0220
INFO - 2017-01-23 18:54:44 --> Config Class Initialized
INFO - 2017-01-23 18:54:44 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:54:44 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:54:44 --> Utf8 Class Initialized
INFO - 2017-01-23 18:54:44 --> URI Class Initialized
INFO - 2017-01-23 18:54:44 --> Router Class Initialized
INFO - 2017-01-23 18:54:44 --> Output Class Initialized
INFO - 2017-01-23 18:54:44 --> Security Class Initialized
DEBUG - 2017-01-23 18:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:54:44 --> Input Class Initialized
INFO - 2017-01-23 18:54:44 --> Language Class Initialized
INFO - 2017-01-23 18:54:44 --> Loader Class Initialized
INFO - 2017-01-23 18:54:44 --> Database Driver Class Initialized
INFO - 2017-01-23 18:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:54:44 --> Controller Class Initialized
INFO - 2017-01-23 18:54:44 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:54:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:54:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:54:44 --> Final output sent to browser
DEBUG - 2017-01-23 18:54:44 --> Total execution time: 0.0972
INFO - 2017-01-23 18:54:52 --> Config Class Initialized
INFO - 2017-01-23 18:54:52 --> Hooks Class Initialized
DEBUG - 2017-01-23 18:54:52 --> UTF-8 Support Enabled
INFO - 2017-01-23 18:54:52 --> Utf8 Class Initialized
INFO - 2017-01-23 18:54:52 --> URI Class Initialized
INFO - 2017-01-23 18:54:52 --> Router Class Initialized
INFO - 2017-01-23 18:54:52 --> Output Class Initialized
INFO - 2017-01-23 18:54:52 --> Security Class Initialized
DEBUG - 2017-01-23 18:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 18:54:52 --> Input Class Initialized
INFO - 2017-01-23 18:54:52 --> Language Class Initialized
INFO - 2017-01-23 18:54:52 --> Loader Class Initialized
INFO - 2017-01-23 18:54:52 --> Database Driver Class Initialized
INFO - 2017-01-23 18:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 18:54:52 --> Controller Class Initialized
INFO - 2017-01-23 18:54:52 --> Helper loaded: url_helper
DEBUG - 2017-01-23 18:54:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 18:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 18:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 18:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 18:54:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 18:54:52 --> Final output sent to browser
DEBUG - 2017-01-23 18:54:52 --> Total execution time: 0.0145
INFO - 2017-01-23 19:01:53 --> Config Class Initialized
INFO - 2017-01-23 19:01:53 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:01:53 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:01:53 --> Utf8 Class Initialized
INFO - 2017-01-23 19:01:53 --> URI Class Initialized
INFO - 2017-01-23 19:01:53 --> Router Class Initialized
INFO - 2017-01-23 19:01:53 --> Output Class Initialized
INFO - 2017-01-23 19:01:53 --> Security Class Initialized
DEBUG - 2017-01-23 19:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:01:53 --> Input Class Initialized
INFO - 2017-01-23 19:01:53 --> Language Class Initialized
INFO - 2017-01-23 19:01:53 --> Loader Class Initialized
INFO - 2017-01-23 19:01:53 --> Database Driver Class Initialized
INFO - 2017-01-23 19:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:01:53 --> Controller Class Initialized
INFO - 2017-01-23 19:01:53 --> Helper loaded: date_helper
INFO - 2017-01-23 19:01:53 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:01:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:01:53 --> Helper loaded: form_helper
INFO - 2017-01-23 19:01:53 --> Form Validation Class Initialized
INFO - 2017-01-23 19:01:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 19:01:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 19:01:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-23 19:01:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-23 19:01:53 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 19:01:53 --> Final output sent to browser
DEBUG - 2017-01-23 19:01:53 --> Total execution time: 0.2200
INFO - 2017-01-23 19:01:53 --> Config Class Initialized
INFO - 2017-01-23 19:01:53 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:01:53 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:01:53 --> Utf8 Class Initialized
INFO - 2017-01-23 19:01:53 --> URI Class Initialized
INFO - 2017-01-23 19:01:53 --> Router Class Initialized
INFO - 2017-01-23 19:01:53 --> Output Class Initialized
INFO - 2017-01-23 19:01:53 --> Security Class Initialized
DEBUG - 2017-01-23 19:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:01:53 --> Input Class Initialized
INFO - 2017-01-23 19:01:53 --> Language Class Initialized
INFO - 2017-01-23 19:01:53 --> Loader Class Initialized
INFO - 2017-01-23 19:01:54 --> Database Driver Class Initialized
INFO - 2017-01-23 19:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:01:54 --> Controller Class Initialized
INFO - 2017-01-23 19:01:54 --> Helper loaded: date_helper
INFO - 2017-01-23 19:01:54 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:01:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:01:54 --> Helper loaded: form_helper
INFO - 2017-01-23 19:01:54 --> Form Validation Class Initialized
INFO - 2017-01-23 19:01:54 --> Final output sent to browser
DEBUG - 2017-01-23 19:01:54 --> Total execution time: 0.1367
INFO - 2017-01-23 19:01:54 --> Config Class Initialized
INFO - 2017-01-23 19:01:54 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:01:54 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:01:54 --> Utf8 Class Initialized
INFO - 2017-01-23 19:01:54 --> URI Class Initialized
INFO - 2017-01-23 19:01:54 --> Router Class Initialized
INFO - 2017-01-23 19:01:54 --> Output Class Initialized
INFO - 2017-01-23 19:01:54 --> Security Class Initialized
DEBUG - 2017-01-23 19:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:01:54 --> Input Class Initialized
INFO - 2017-01-23 19:01:54 --> Language Class Initialized
INFO - 2017-01-23 19:01:54 --> Loader Class Initialized
INFO - 2017-01-23 19:01:54 --> Database Driver Class Initialized
INFO - 2017-01-23 19:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:01:54 --> Controller Class Initialized
INFO - 2017-01-23 19:01:54 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:01:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:01:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 19:01:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 19:01:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 19:01:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 19:01:54 --> Final output sent to browser
DEBUG - 2017-01-23 19:01:54 --> Total execution time: 0.0856
INFO - 2017-01-23 19:01:56 --> Config Class Initialized
INFO - 2017-01-23 19:01:56 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:01:56 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:01:56 --> Utf8 Class Initialized
INFO - 2017-01-23 19:01:56 --> Config Class Initialized
INFO - 2017-01-23 19:01:56 --> Hooks Class Initialized
INFO - 2017-01-23 19:01:56 --> URI Class Initialized
INFO - 2017-01-23 19:01:56 --> Router Class Initialized
INFO - 2017-01-23 19:01:56 --> Output Class Initialized
DEBUG - 2017-01-23 19:01:56 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:01:56 --> Utf8 Class Initialized
INFO - 2017-01-23 19:01:56 --> URI Class Initialized
INFO - 2017-01-23 19:01:56 --> Router Class Initialized
INFO - 2017-01-23 19:01:56 --> Output Class Initialized
INFO - 2017-01-23 19:01:56 --> Security Class Initialized
DEBUG - 2017-01-23 19:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:01:56 --> Input Class Initialized
INFO - 2017-01-23 19:01:56 --> Language Class Initialized
INFO - 2017-01-23 19:01:56 --> Loader Class Initialized
INFO - 2017-01-23 19:01:56 --> Database Driver Class Initialized
INFO - 2017-01-23 19:01:56 --> Security Class Initialized
DEBUG - 2017-01-23 19:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:01:56 --> Input Class Initialized
INFO - 2017-01-23 19:01:56 --> Language Class Initialized
INFO - 2017-01-23 19:01:56 --> Loader Class Initialized
INFO - 2017-01-23 19:01:56 --> Database Driver Class Initialized
INFO - 2017-01-23 19:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:01:56 --> Controller Class Initialized
INFO - 2017-01-23 19:01:56 --> Helper loaded: date_helper
INFO - 2017-01-23 19:01:56 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:01:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:01:56 --> Helper loaded: form_helper
INFO - 2017-01-23 19:01:56 --> Form Validation Class Initialized
INFO - 2017-01-23 19:01:56 --> Final output sent to browser
DEBUG - 2017-01-23 19:01:56 --> Total execution time: 0.0981
INFO - 2017-01-23 19:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:01:56 --> Controller Class Initialized
INFO - 2017-01-23 19:01:56 --> Helper loaded: date_helper
INFO - 2017-01-23 19:01:56 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:01:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:01:56 --> Helper loaded: form_helper
INFO - 2017-01-23 19:01:56 --> Form Validation Class Initialized
INFO - 2017-01-23 19:01:56 --> Final output sent to browser
DEBUG - 2017-01-23 19:01:56 --> Total execution time: 0.1084
INFO - 2017-01-23 19:02:05 --> Config Class Initialized
INFO - 2017-01-23 19:02:05 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:02:05 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:02:05 --> Utf8 Class Initialized
INFO - 2017-01-23 19:02:05 --> URI Class Initialized
INFO - 2017-01-23 19:02:05 --> Router Class Initialized
INFO - 2017-01-23 19:02:05 --> Output Class Initialized
INFO - 2017-01-23 19:02:05 --> Security Class Initialized
DEBUG - 2017-01-23 19:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:02:05 --> Input Class Initialized
INFO - 2017-01-23 19:02:05 --> Language Class Initialized
ERROR - 2017-01-23 19:02:05 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-23 19:02:34 --> Config Class Initialized
INFO - 2017-01-23 19:02:34 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:02:34 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:02:34 --> Utf8 Class Initialized
INFO - 2017-01-23 19:02:34 --> URI Class Initialized
INFO - 2017-01-23 19:02:34 --> Router Class Initialized
INFO - 2017-01-23 19:02:34 --> Output Class Initialized
INFO - 2017-01-23 19:02:34 --> Security Class Initialized
DEBUG - 2017-01-23 19:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:02:34 --> Input Class Initialized
INFO - 2017-01-23 19:02:34 --> Language Class Initialized
INFO - 2017-01-23 19:02:34 --> Loader Class Initialized
INFO - 2017-01-23 19:02:34 --> Database Driver Class Initialized
INFO - 2017-01-23 19:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:02:34 --> Controller Class Initialized
INFO - 2017-01-23 19:02:34 --> Helper loaded: date_helper
INFO - 2017-01-23 19:02:34 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:02:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:02:34 --> Helper loaded: form_helper
INFO - 2017-01-23 19:02:34 --> Form Validation Class Initialized
INFO - 2017-01-23 19:02:34 --> Final output sent to browser
DEBUG - 2017-01-23 19:02:34 --> Total execution time: 0.1291
INFO - 2017-01-23 19:02:35 --> Config Class Initialized
INFO - 2017-01-23 19:02:35 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:02:35 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:02:35 --> Utf8 Class Initialized
INFO - 2017-01-23 19:02:35 --> URI Class Initialized
INFO - 2017-01-23 19:02:35 --> Router Class Initialized
INFO - 2017-01-23 19:02:35 --> Output Class Initialized
INFO - 2017-01-23 19:02:35 --> Security Class Initialized
DEBUG - 2017-01-23 19:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:02:35 --> Input Class Initialized
INFO - 2017-01-23 19:02:35 --> Language Class Initialized
INFO - 2017-01-23 19:02:35 --> Loader Class Initialized
INFO - 2017-01-23 19:02:35 --> Database Driver Class Initialized
INFO - 2017-01-23 19:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:02:35 --> Controller Class Initialized
INFO - 2017-01-23 19:02:35 --> Helper loaded: date_helper
INFO - 2017-01-23 19:02:35 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:02:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:02:35 --> Helper loaded: form_helper
INFO - 2017-01-23 19:02:35 --> Form Validation Class Initialized
INFO - 2017-01-23 19:02:35 --> Final output sent to browser
DEBUG - 2017-01-23 19:02:35 --> Total execution time: 0.1169
INFO - 2017-01-23 19:02:38 --> Config Class Initialized
INFO - 2017-01-23 19:02:38 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:02:38 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:02:38 --> Utf8 Class Initialized
INFO - 2017-01-23 19:02:38 --> URI Class Initialized
INFO - 2017-01-23 19:02:38 --> Router Class Initialized
INFO - 2017-01-23 19:02:38 --> Output Class Initialized
INFO - 2017-01-23 19:02:38 --> Security Class Initialized
DEBUG - 2017-01-23 19:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:02:38 --> Input Class Initialized
INFO - 2017-01-23 19:02:38 --> Language Class Initialized
INFO - 2017-01-23 19:02:38 --> Loader Class Initialized
INFO - 2017-01-23 19:02:38 --> Database Driver Class Initialized
INFO - 2017-01-23 19:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:02:38 --> Controller Class Initialized
INFO - 2017-01-23 19:02:38 --> Helper loaded: date_helper
INFO - 2017-01-23 19:02:38 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:02:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:02:39 --> Helper loaded: form_helper
INFO - 2017-01-23 19:02:39 --> Form Validation Class Initialized
INFO - 2017-01-23 19:02:39 --> Final output sent to browser
DEBUG - 2017-01-23 19:02:39 --> Total execution time: 0.1157
INFO - 2017-01-23 19:02:43 --> Config Class Initialized
INFO - 2017-01-23 19:02:43 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:02:43 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:02:43 --> Utf8 Class Initialized
INFO - 2017-01-23 19:02:43 --> URI Class Initialized
INFO - 2017-01-23 19:02:43 --> Router Class Initialized
INFO - 2017-01-23 19:02:43 --> Output Class Initialized
INFO - 2017-01-23 19:02:43 --> Security Class Initialized
DEBUG - 2017-01-23 19:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:02:43 --> Input Class Initialized
INFO - 2017-01-23 19:02:43 --> Language Class Initialized
INFO - 2017-01-23 19:02:43 --> Loader Class Initialized
INFO - 2017-01-23 19:02:43 --> Database Driver Class Initialized
INFO - 2017-01-23 19:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:02:43 --> Controller Class Initialized
INFO - 2017-01-23 19:02:43 --> Helper loaded: date_helper
INFO - 2017-01-23 19:02:43 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:02:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:02:43 --> Helper loaded: form_helper
INFO - 2017-01-23 19:02:43 --> Form Validation Class Initialized
INFO - 2017-01-23 19:02:43 --> Final output sent to browser
DEBUG - 2017-01-23 19:02:43 --> Total execution time: 0.1145
INFO - 2017-01-23 19:02:46 --> Config Class Initialized
INFO - 2017-01-23 19:02:46 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:02:46 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:02:46 --> Utf8 Class Initialized
INFO - 2017-01-23 19:02:46 --> URI Class Initialized
INFO - 2017-01-23 19:02:46 --> Router Class Initialized
INFO - 2017-01-23 19:02:46 --> Output Class Initialized
INFO - 2017-01-23 19:02:46 --> Security Class Initialized
DEBUG - 2017-01-23 19:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:02:46 --> Input Class Initialized
INFO - 2017-01-23 19:02:46 --> Language Class Initialized
INFO - 2017-01-23 19:02:46 --> Loader Class Initialized
INFO - 2017-01-23 19:02:46 --> Database Driver Class Initialized
INFO - 2017-01-23 19:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:02:46 --> Controller Class Initialized
INFO - 2017-01-23 19:02:46 --> Helper loaded: date_helper
INFO - 2017-01-23 19:02:46 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:02:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:02:46 --> Helper loaded: form_helper
INFO - 2017-01-23 19:02:46 --> Form Validation Class Initialized
INFO - 2017-01-23 19:02:46 --> Final output sent to browser
DEBUG - 2017-01-23 19:02:46 --> Total execution time: 0.0661
INFO - 2017-01-23 19:02:51 --> Config Class Initialized
INFO - 2017-01-23 19:02:51 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:02:51 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:02:51 --> Utf8 Class Initialized
INFO - 2017-01-23 19:02:51 --> URI Class Initialized
INFO - 2017-01-23 19:02:51 --> Router Class Initialized
INFO - 2017-01-23 19:02:51 --> Output Class Initialized
INFO - 2017-01-23 19:02:51 --> Security Class Initialized
DEBUG - 2017-01-23 19:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:02:51 --> Input Class Initialized
INFO - 2017-01-23 19:02:51 --> Language Class Initialized
INFO - 2017-01-23 19:02:51 --> Loader Class Initialized
INFO - 2017-01-23 19:02:51 --> Database Driver Class Initialized
INFO - 2017-01-23 19:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:02:51 --> Controller Class Initialized
INFO - 2017-01-23 19:02:51 --> Helper loaded: date_helper
INFO - 2017-01-23 19:02:51 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:02:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:02:51 --> Helper loaded: form_helper
INFO - 2017-01-23 19:02:51 --> Form Validation Class Initialized
INFO - 2017-01-23 19:02:51 --> Final output sent to browser
DEBUG - 2017-01-23 19:02:51 --> Total execution time: 0.1238
INFO - 2017-01-23 19:02:54 --> Config Class Initialized
INFO - 2017-01-23 19:02:54 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:02:54 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:02:54 --> Utf8 Class Initialized
INFO - 2017-01-23 19:02:54 --> URI Class Initialized
INFO - 2017-01-23 19:02:54 --> Router Class Initialized
INFO - 2017-01-23 19:02:54 --> Output Class Initialized
INFO - 2017-01-23 19:02:54 --> Security Class Initialized
DEBUG - 2017-01-23 19:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:02:54 --> Input Class Initialized
INFO - 2017-01-23 19:02:54 --> Language Class Initialized
INFO - 2017-01-23 19:02:54 --> Loader Class Initialized
INFO - 2017-01-23 19:02:54 --> Database Driver Class Initialized
INFO - 2017-01-23 19:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:02:54 --> Controller Class Initialized
INFO - 2017-01-23 19:02:54 --> Helper loaded: date_helper
INFO - 2017-01-23 19:02:54 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:02:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:02:54 --> Helper loaded: form_helper
INFO - 2017-01-23 19:02:54 --> Form Validation Class Initialized
INFO - 2017-01-23 19:02:54 --> Final output sent to browser
DEBUG - 2017-01-23 19:02:54 --> Total execution time: 0.1085
INFO - 2017-01-23 19:02:55 --> Config Class Initialized
INFO - 2017-01-23 19:02:55 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:02:55 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:02:55 --> Utf8 Class Initialized
INFO - 2017-01-23 19:02:55 --> URI Class Initialized
INFO - 2017-01-23 19:02:55 --> Router Class Initialized
INFO - 2017-01-23 19:02:55 --> Output Class Initialized
INFO - 2017-01-23 19:02:55 --> Security Class Initialized
DEBUG - 2017-01-23 19:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:02:55 --> Input Class Initialized
INFO - 2017-01-23 19:02:55 --> Language Class Initialized
INFO - 2017-01-23 19:02:55 --> Loader Class Initialized
INFO - 2017-01-23 19:02:55 --> Database Driver Class Initialized
INFO - 2017-01-23 19:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:02:55 --> Controller Class Initialized
INFO - 2017-01-23 19:02:55 --> Helper loaded: date_helper
INFO - 2017-01-23 19:02:55 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:02:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:02:55 --> Helper loaded: form_helper
INFO - 2017-01-23 19:02:55 --> Form Validation Class Initialized
INFO - 2017-01-23 19:02:55 --> Final output sent to browser
DEBUG - 2017-01-23 19:02:55 --> Total execution time: 0.0156
INFO - 2017-01-23 19:03:03 --> Config Class Initialized
INFO - 2017-01-23 19:03:03 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:03:03 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:03:03 --> Utf8 Class Initialized
INFO - 2017-01-23 19:03:03 --> URI Class Initialized
INFO - 2017-01-23 19:03:03 --> Router Class Initialized
INFO - 2017-01-23 19:03:03 --> Output Class Initialized
INFO - 2017-01-23 19:03:03 --> Security Class Initialized
DEBUG - 2017-01-23 19:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:03:03 --> Input Class Initialized
INFO - 2017-01-23 19:03:03 --> Language Class Initialized
ERROR - 2017-01-23 19:03:03 --> 404 Page Not Found: Templates/administrador
INFO - 2017-01-23 19:03:23 --> Config Class Initialized
INFO - 2017-01-23 19:03:23 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:03:23 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:03:23 --> Utf8 Class Initialized
INFO - 2017-01-23 19:03:23 --> URI Class Initialized
INFO - 2017-01-23 19:03:23 --> Router Class Initialized
INFO - 2017-01-23 19:03:23 --> Output Class Initialized
INFO - 2017-01-23 19:03:23 --> Security Class Initialized
DEBUG - 2017-01-23 19:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:03:23 --> Input Class Initialized
INFO - 2017-01-23 19:03:23 --> Language Class Initialized
INFO - 2017-01-23 19:03:23 --> Loader Class Initialized
INFO - 2017-01-23 19:03:23 --> Database Driver Class Initialized
INFO - 2017-01-23 19:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:03:23 --> Controller Class Initialized
INFO - 2017-01-23 19:03:23 --> Helper loaded: date_helper
INFO - 2017-01-23 19:03:23 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:03:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:03:23 --> Helper loaded: form_helper
INFO - 2017-01-23 19:03:23 --> Form Validation Class Initialized
INFO - 2017-01-23 19:03:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 19:03:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 19:03:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-23 19:03:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-23 19:03:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 19:03:23 --> Final output sent to browser
DEBUG - 2017-01-23 19:03:23 --> Total execution time: 0.0674
INFO - 2017-01-23 19:03:23 --> Config Class Initialized
INFO - 2017-01-23 19:03:23 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:03:23 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:03:23 --> Utf8 Class Initialized
INFO - 2017-01-23 19:03:23 --> URI Class Initialized
INFO - 2017-01-23 19:03:23 --> Router Class Initialized
INFO - 2017-01-23 19:03:23 --> Output Class Initialized
INFO - 2017-01-23 19:03:23 --> Security Class Initialized
DEBUG - 2017-01-23 19:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:03:23 --> Input Class Initialized
INFO - 2017-01-23 19:03:23 --> Language Class Initialized
INFO - 2017-01-23 19:03:23 --> Loader Class Initialized
INFO - 2017-01-23 19:03:23 --> Database Driver Class Initialized
INFO - 2017-01-23 19:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:03:23 --> Controller Class Initialized
INFO - 2017-01-23 19:03:23 --> Helper loaded: date_helper
INFO - 2017-01-23 19:03:23 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:03:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:03:23 --> Helper loaded: form_helper
INFO - 2017-01-23 19:03:23 --> Form Validation Class Initialized
INFO - 2017-01-23 19:03:23 --> Final output sent to browser
DEBUG - 2017-01-23 19:03:23 --> Total execution time: 0.0167
INFO - 2017-01-23 19:03:24 --> Config Class Initialized
INFO - 2017-01-23 19:03:24 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:03:24 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:03:24 --> Utf8 Class Initialized
INFO - 2017-01-23 19:03:24 --> URI Class Initialized
INFO - 2017-01-23 19:03:24 --> Router Class Initialized
INFO - 2017-01-23 19:03:24 --> Output Class Initialized
INFO - 2017-01-23 19:03:24 --> Security Class Initialized
DEBUG - 2017-01-23 19:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:03:24 --> Input Class Initialized
INFO - 2017-01-23 19:03:24 --> Language Class Initialized
INFO - 2017-01-23 19:03:24 --> Loader Class Initialized
INFO - 2017-01-23 19:03:24 --> Database Driver Class Initialized
INFO - 2017-01-23 19:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:03:24 --> Controller Class Initialized
INFO - 2017-01-23 19:03:24 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:03:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 19:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 19:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 19:03:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 19:03:24 --> Final output sent to browser
DEBUG - 2017-01-23 19:03:24 --> Total execution time: 0.0507
INFO - 2017-01-23 19:03:27 --> Config Class Initialized
INFO - 2017-01-23 19:03:27 --> Config Class Initialized
INFO - 2017-01-23 19:03:27 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:03:27 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:03:27 --> Utf8 Class Initialized
INFO - 2017-01-23 19:03:27 --> URI Class Initialized
INFO - 2017-01-23 19:03:27 --> Router Class Initialized
INFO - 2017-01-23 19:03:27 --> Output Class Initialized
INFO - 2017-01-23 19:03:27 --> Security Class Initialized
DEBUG - 2017-01-23 19:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:03:27 --> Input Class Initialized
INFO - 2017-01-23 19:03:27 --> Language Class Initialized
INFO - 2017-01-23 19:03:27 --> Loader Class Initialized
INFO - 2017-01-23 19:03:27 --> Database Driver Class Initialized
INFO - 2017-01-23 19:03:27 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:03:27 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:03:27 --> Utf8 Class Initialized
INFO - 2017-01-23 19:03:27 --> URI Class Initialized
INFO - 2017-01-23 19:03:27 --> Router Class Initialized
INFO - 2017-01-23 19:03:27 --> Output Class Initialized
INFO - 2017-01-23 19:03:27 --> Security Class Initialized
DEBUG - 2017-01-23 19:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:03:27 --> Input Class Initialized
INFO - 2017-01-23 19:03:27 --> Language Class Initialized
INFO - 2017-01-23 19:03:27 --> Loader Class Initialized
INFO - 2017-01-23 19:03:27 --> Database Driver Class Initialized
INFO - 2017-01-23 19:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:03:27 --> Controller Class Initialized
INFO - 2017-01-23 19:03:27 --> Helper loaded: date_helper
INFO - 2017-01-23 19:03:27 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:03:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:03:27 --> Helper loaded: form_helper
INFO - 2017-01-23 19:03:27 --> Form Validation Class Initialized
INFO - 2017-01-23 19:03:27 --> Final output sent to browser
DEBUG - 2017-01-23 19:03:27 --> Total execution time: 0.1312
INFO - 2017-01-23 19:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:03:27 --> Controller Class Initialized
INFO - 2017-01-23 19:03:27 --> Helper loaded: date_helper
INFO - 2017-01-23 19:03:27 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:03:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:03:27 --> Helper loaded: form_helper
INFO - 2017-01-23 19:03:27 --> Form Validation Class Initialized
INFO - 2017-01-23 19:03:27 --> Final output sent to browser
DEBUG - 2017-01-23 19:03:27 --> Total execution time: 0.0695
INFO - 2017-01-23 19:03:54 --> Config Class Initialized
INFO - 2017-01-23 19:03:54 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:03:54 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:03:54 --> Utf8 Class Initialized
INFO - 2017-01-23 19:03:54 --> URI Class Initialized
INFO - 2017-01-23 19:03:54 --> Router Class Initialized
INFO - 2017-01-23 19:03:54 --> Output Class Initialized
INFO - 2017-01-23 19:03:54 --> Security Class Initialized
DEBUG - 2017-01-23 19:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:03:54 --> Input Class Initialized
INFO - 2017-01-23 19:03:54 --> Language Class Initialized
INFO - 2017-01-23 19:03:54 --> Loader Class Initialized
INFO - 2017-01-23 19:03:54 --> Database Driver Class Initialized
INFO - 2017-01-23 19:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:03:54 --> Controller Class Initialized
INFO - 2017-01-23 19:03:54 --> Helper loaded: date_helper
INFO - 2017-01-23 19:03:54 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:03:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:03:54 --> Helper loaded: form_helper
INFO - 2017-01-23 19:03:54 --> Form Validation Class Initialized
INFO - 2017-01-23 19:03:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 19:03:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 19:03:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-23 19:03:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-23 19:03:54 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 19:03:54 --> Final output sent to browser
DEBUG - 2017-01-23 19:03:54 --> Total execution time: 0.1453
INFO - 2017-01-23 19:03:55 --> Config Class Initialized
INFO - 2017-01-23 19:03:55 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:03:55 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:03:55 --> Utf8 Class Initialized
INFO - 2017-01-23 19:03:55 --> URI Class Initialized
INFO - 2017-01-23 19:03:55 --> Router Class Initialized
INFO - 2017-01-23 19:03:55 --> Output Class Initialized
INFO - 2017-01-23 19:03:55 --> Security Class Initialized
DEBUG - 2017-01-23 19:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:03:55 --> Input Class Initialized
INFO - 2017-01-23 19:03:55 --> Language Class Initialized
INFO - 2017-01-23 19:03:55 --> Loader Class Initialized
INFO - 2017-01-23 19:03:55 --> Database Driver Class Initialized
INFO - 2017-01-23 19:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:03:55 --> Controller Class Initialized
INFO - 2017-01-23 19:03:55 --> Helper loaded: date_helper
INFO - 2017-01-23 19:03:55 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:03:55 --> Helper loaded: form_helper
INFO - 2017-01-23 19:03:55 --> Form Validation Class Initialized
INFO - 2017-01-23 19:03:55 --> Final output sent to browser
DEBUG - 2017-01-23 19:03:55 --> Total execution time: 0.0965
INFO - 2017-01-23 19:03:55 --> Config Class Initialized
INFO - 2017-01-23 19:03:55 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:03:55 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:03:55 --> Utf8 Class Initialized
INFO - 2017-01-23 19:03:55 --> URI Class Initialized
INFO - 2017-01-23 19:03:55 --> Router Class Initialized
INFO - 2017-01-23 19:03:55 --> Output Class Initialized
INFO - 2017-01-23 19:03:55 --> Security Class Initialized
DEBUG - 2017-01-23 19:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:03:55 --> Input Class Initialized
INFO - 2017-01-23 19:03:55 --> Language Class Initialized
INFO - 2017-01-23 19:03:55 --> Loader Class Initialized
INFO - 2017-01-23 19:03:55 --> Database Driver Class Initialized
INFO - 2017-01-23 19:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:03:55 --> Controller Class Initialized
INFO - 2017-01-23 19:03:55 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:03:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 19:03:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 19:03:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 19:03:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 19:03:55 --> Final output sent to browser
DEBUG - 2017-01-23 19:03:55 --> Total execution time: 0.0288
INFO - 2017-01-23 19:03:57 --> Config Class Initialized
INFO - 2017-01-23 19:03:57 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:03:57 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:03:57 --> Utf8 Class Initialized
INFO - 2017-01-23 19:03:57 --> URI Class Initialized
INFO - 2017-01-23 19:03:57 --> Router Class Initialized
INFO - 2017-01-23 19:03:57 --> Output Class Initialized
INFO - 2017-01-23 19:03:57 --> Security Class Initialized
DEBUG - 2017-01-23 19:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:03:57 --> Input Class Initialized
INFO - 2017-01-23 19:03:57 --> Config Class Initialized
INFO - 2017-01-23 19:03:57 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:03:57 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:03:57 --> Utf8 Class Initialized
INFO - 2017-01-23 19:03:57 --> URI Class Initialized
INFO - 2017-01-23 19:03:57 --> Router Class Initialized
INFO - 2017-01-23 19:03:57 --> Output Class Initialized
INFO - 2017-01-23 19:03:57 --> Security Class Initialized
DEBUG - 2017-01-23 19:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:03:57 --> Input Class Initialized
INFO - 2017-01-23 19:03:57 --> Language Class Initialized
INFO - 2017-01-23 19:03:57 --> Loader Class Initialized
INFO - 2017-01-23 19:03:57 --> Database Driver Class Initialized
INFO - 2017-01-23 19:03:57 --> Language Class Initialized
INFO - 2017-01-23 19:03:57 --> Loader Class Initialized
INFO - 2017-01-23 19:03:57 --> Database Driver Class Initialized
INFO - 2017-01-23 19:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:03:57 --> Controller Class Initialized
INFO - 2017-01-23 19:03:57 --> Helper loaded: date_helper
INFO - 2017-01-23 19:03:57 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:03:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:03:57 --> Helper loaded: form_helper
INFO - 2017-01-23 19:03:57 --> Form Validation Class Initialized
INFO - 2017-01-23 19:03:57 --> Final output sent to browser
DEBUG - 2017-01-23 19:03:57 --> Total execution time: 0.0723
INFO - 2017-01-23 19:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:03:57 --> Controller Class Initialized
INFO - 2017-01-23 19:03:57 --> Helper loaded: date_helper
INFO - 2017-01-23 19:03:57 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:03:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:03:57 --> Helper loaded: form_helper
INFO - 2017-01-23 19:03:57 --> Form Validation Class Initialized
INFO - 2017-01-23 19:03:57 --> Final output sent to browser
DEBUG - 2017-01-23 19:03:57 --> Total execution time: 0.0940
INFO - 2017-01-23 19:05:50 --> Config Class Initialized
INFO - 2017-01-23 19:05:50 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:05:50 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:05:50 --> Utf8 Class Initialized
INFO - 2017-01-23 19:05:50 --> URI Class Initialized
INFO - 2017-01-23 19:05:50 --> Router Class Initialized
INFO - 2017-01-23 19:05:50 --> Output Class Initialized
INFO - 2017-01-23 19:05:50 --> Security Class Initialized
DEBUG - 2017-01-23 19:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:05:50 --> Input Class Initialized
INFO - 2017-01-23 19:05:50 --> Language Class Initialized
INFO - 2017-01-23 19:05:50 --> Loader Class Initialized
INFO - 2017-01-23 19:05:50 --> Database Driver Class Initialized
INFO - 2017-01-23 19:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:05:50 --> Controller Class Initialized
INFO - 2017-01-23 19:05:50 --> Helper loaded: date_helper
INFO - 2017-01-23 19:05:50 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:05:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:05:50 --> Helper loaded: form_helper
INFO - 2017-01-23 19:05:50 --> Form Validation Class Initialized
INFO - 2017-01-23 19:05:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 19:05:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 19:05:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-23 19:05:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-23 19:05:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 19:05:50 --> Final output sent to browser
DEBUG - 2017-01-23 19:05:50 --> Total execution time: 0.0677
INFO - 2017-01-23 19:05:50 --> Config Class Initialized
INFO - 2017-01-23 19:05:50 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:05:50 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:05:50 --> Utf8 Class Initialized
INFO - 2017-01-23 19:05:50 --> URI Class Initialized
INFO - 2017-01-23 19:05:50 --> Router Class Initialized
INFO - 2017-01-23 19:05:50 --> Output Class Initialized
INFO - 2017-01-23 19:05:50 --> Security Class Initialized
DEBUG - 2017-01-23 19:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:05:50 --> Input Class Initialized
INFO - 2017-01-23 19:05:50 --> Language Class Initialized
INFO - 2017-01-23 19:05:50 --> Loader Class Initialized
INFO - 2017-01-23 19:05:50 --> Database Driver Class Initialized
INFO - 2017-01-23 19:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:05:50 --> Controller Class Initialized
INFO - 2017-01-23 19:05:50 --> Helper loaded: date_helper
INFO - 2017-01-23 19:05:50 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:05:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:05:50 --> Helper loaded: form_helper
INFO - 2017-01-23 19:05:50 --> Form Validation Class Initialized
INFO - 2017-01-23 19:05:50 --> Final output sent to browser
DEBUG - 2017-01-23 19:05:50 --> Total execution time: 0.0164
INFO - 2017-01-23 19:05:50 --> Config Class Initialized
INFO - 2017-01-23 19:05:50 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:05:50 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:05:50 --> Utf8 Class Initialized
INFO - 2017-01-23 19:05:50 --> URI Class Initialized
INFO - 2017-01-23 19:05:50 --> Router Class Initialized
INFO - 2017-01-23 19:05:50 --> Output Class Initialized
INFO - 2017-01-23 19:05:50 --> Security Class Initialized
DEBUG - 2017-01-23 19:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:05:50 --> Input Class Initialized
INFO - 2017-01-23 19:05:50 --> Language Class Initialized
INFO - 2017-01-23 19:05:50 --> Loader Class Initialized
INFO - 2017-01-23 19:05:50 --> Database Driver Class Initialized
INFO - 2017-01-23 19:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:05:50 --> Controller Class Initialized
INFO - 2017-01-23 19:05:51 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:05:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 19:05:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 19:05:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 19:05:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 19:05:51 --> Final output sent to browser
DEBUG - 2017-01-23 19:05:51 --> Total execution time: 0.0746
INFO - 2017-01-23 19:05:53 --> Config Class Initialized
INFO - 2017-01-23 19:05:53 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:05:53 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:05:53 --> Utf8 Class Initialized
INFO - 2017-01-23 19:05:53 --> URI Class Initialized
INFO - 2017-01-23 19:05:53 --> Router Class Initialized
INFO - 2017-01-23 19:05:53 --> Config Class Initialized
INFO - 2017-01-23 19:05:53 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:05:53 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:05:53 --> Utf8 Class Initialized
INFO - 2017-01-23 19:05:53 --> URI Class Initialized
INFO - 2017-01-23 19:05:53 --> Router Class Initialized
INFO - 2017-01-23 19:05:53 --> Output Class Initialized
INFO - 2017-01-23 19:05:53 --> Security Class Initialized
DEBUG - 2017-01-23 19:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:05:53 --> Input Class Initialized
INFO - 2017-01-23 19:05:53 --> Language Class Initialized
INFO - 2017-01-23 19:05:53 --> Loader Class Initialized
INFO - 2017-01-23 19:05:53 --> Database Driver Class Initialized
INFO - 2017-01-23 19:05:53 --> Output Class Initialized
INFO - 2017-01-23 19:05:53 --> Security Class Initialized
DEBUG - 2017-01-23 19:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:05:53 --> Input Class Initialized
INFO - 2017-01-23 19:05:53 --> Language Class Initialized
INFO - 2017-01-23 19:05:53 --> Loader Class Initialized
INFO - 2017-01-23 19:05:53 --> Database Driver Class Initialized
INFO - 2017-01-23 19:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:05:53 --> Controller Class Initialized
INFO - 2017-01-23 19:05:53 --> Helper loaded: date_helper
INFO - 2017-01-23 19:05:53 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:05:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:05:53 --> Helper loaded: form_helper
INFO - 2017-01-23 19:05:53 --> Form Validation Class Initialized
INFO - 2017-01-23 19:05:53 --> Final output sent to browser
DEBUG - 2017-01-23 19:05:53 --> Total execution time: 0.0782
INFO - 2017-01-23 19:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:05:53 --> Controller Class Initialized
INFO - 2017-01-23 19:05:53 --> Helper loaded: date_helper
INFO - 2017-01-23 19:05:53 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:05:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:05:53 --> Helper loaded: form_helper
INFO - 2017-01-23 19:05:53 --> Form Validation Class Initialized
INFO - 2017-01-23 19:05:53 --> Final output sent to browser
DEBUG - 2017-01-23 19:05:53 --> Total execution time: 0.0992
INFO - 2017-01-23 19:11:07 --> Config Class Initialized
INFO - 2017-01-23 19:11:07 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:11:07 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:11:07 --> Utf8 Class Initialized
INFO - 2017-01-23 19:11:07 --> URI Class Initialized
INFO - 2017-01-23 19:11:07 --> Router Class Initialized
INFO - 2017-01-23 19:11:07 --> Output Class Initialized
INFO - 2017-01-23 19:11:07 --> Security Class Initialized
DEBUG - 2017-01-23 19:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:11:07 --> Input Class Initialized
INFO - 2017-01-23 19:11:07 --> Language Class Initialized
INFO - 2017-01-23 19:11:07 --> Loader Class Initialized
INFO - 2017-01-23 19:11:07 --> Database Driver Class Initialized
INFO - 2017-01-23 19:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:11:07 --> Controller Class Initialized
INFO - 2017-01-23 19:11:07 --> Helper loaded: date_helper
INFO - 2017-01-23 19:11:07 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:11:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:11:07 --> Helper loaded: form_helper
INFO - 2017-01-23 19:11:07 --> Form Validation Class Initialized
INFO - 2017-01-23 19:11:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 19:11:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 19:11:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_lugares.php
INFO - 2017-01-23 19:11:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_lugares.php
INFO - 2017-01-23 19:11:07 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 19:11:07 --> Final output sent to browser
DEBUG - 2017-01-23 19:11:07 --> Total execution time: 0.1899
INFO - 2017-01-23 19:11:07 --> Config Class Initialized
INFO - 2017-01-23 19:11:07 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:11:07 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:11:07 --> Utf8 Class Initialized
INFO - 2017-01-23 19:11:07 --> URI Class Initialized
INFO - 2017-01-23 19:11:07 --> Router Class Initialized
INFO - 2017-01-23 19:11:07 --> Output Class Initialized
INFO - 2017-01-23 19:11:07 --> Security Class Initialized
DEBUG - 2017-01-23 19:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:11:07 --> Input Class Initialized
INFO - 2017-01-23 19:11:07 --> Language Class Initialized
INFO - 2017-01-23 19:11:07 --> Loader Class Initialized
INFO - 2017-01-23 19:11:07 --> Database Driver Class Initialized
INFO - 2017-01-23 19:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:11:08 --> Controller Class Initialized
INFO - 2017-01-23 19:11:08 --> Helper loaded: date_helper
INFO - 2017-01-23 19:11:08 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:11:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:11:08 --> Helper loaded: form_helper
INFO - 2017-01-23 19:11:08 --> Form Validation Class Initialized
INFO - 2017-01-23 19:11:08 --> Config Class Initialized
INFO - 2017-01-23 19:11:08 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:11:08 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:11:08 --> Utf8 Class Initialized
INFO - 2017-01-23 19:11:08 --> URI Class Initialized
INFO - 2017-01-23 19:11:08 --> Final output sent to browser
DEBUG - 2017-01-23 19:11:08 --> Total execution time: 0.0891
INFO - 2017-01-23 19:11:08 --> Router Class Initialized
INFO - 2017-01-23 19:11:08 --> Output Class Initialized
INFO - 2017-01-23 19:11:08 --> Security Class Initialized
DEBUG - 2017-01-23 19:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:11:08 --> Input Class Initialized
INFO - 2017-01-23 19:11:08 --> Language Class Initialized
INFO - 2017-01-23 19:11:08 --> Loader Class Initialized
INFO - 2017-01-23 19:11:08 --> Database Driver Class Initialized
INFO - 2017-01-23 19:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:11:08 --> Controller Class Initialized
INFO - 2017-01-23 19:11:08 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:11:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:11:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 19:11:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 19:11:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 19:11:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 19:11:08 --> Final output sent to browser
DEBUG - 2017-01-23 19:11:08 --> Total execution time: 0.0507
INFO - 2017-01-23 19:11:38 --> Config Class Initialized
INFO - 2017-01-23 19:11:38 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:11:38 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:11:38 --> Utf8 Class Initialized
INFO - 2017-01-23 19:11:38 --> URI Class Initialized
INFO - 2017-01-23 19:11:38 --> Router Class Initialized
INFO - 2017-01-23 19:11:38 --> Output Class Initialized
INFO - 2017-01-23 19:11:38 --> Security Class Initialized
DEBUG - 2017-01-23 19:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:11:38 --> Input Class Initialized
INFO - 2017-01-23 19:11:38 --> Language Class Initialized
INFO - 2017-01-23 19:11:38 --> Loader Class Initialized
INFO - 2017-01-23 19:11:38 --> Config Class Initialized
INFO - 2017-01-23 19:11:38 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:11:38 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:11:38 --> Utf8 Class Initialized
INFO - 2017-01-23 19:11:38 --> URI Class Initialized
INFO - 2017-01-23 19:11:38 --> Router Class Initialized
INFO - 2017-01-23 19:11:38 --> Output Class Initialized
INFO - 2017-01-23 19:11:38 --> Security Class Initialized
DEBUG - 2017-01-23 19:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:11:38 --> Input Class Initialized
INFO - 2017-01-23 19:11:38 --> Language Class Initialized
INFO - 2017-01-23 19:11:38 --> Loader Class Initialized
INFO - 2017-01-23 19:11:38 --> Database Driver Class Initialized
INFO - 2017-01-23 19:11:38 --> Database Driver Class Initialized
INFO - 2017-01-23 19:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:11:38 --> Controller Class Initialized
INFO - 2017-01-23 19:11:38 --> Helper loaded: date_helper
INFO - 2017-01-23 19:11:38 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:11:38 --> Helper loaded: form_helper
INFO - 2017-01-23 19:11:38 --> Form Validation Class Initialized
INFO - 2017-01-23 19:11:38 --> Final output sent to browser
DEBUG - 2017-01-23 19:11:38 --> Total execution time: 0.1063
INFO - 2017-01-23 19:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:11:38 --> Controller Class Initialized
INFO - 2017-01-23 19:11:38 --> Helper loaded: date_helper
INFO - 2017-01-23 19:11:38 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:11:38 --> Helper loaded: form_helper
INFO - 2017-01-23 19:11:38 --> Form Validation Class Initialized
INFO - 2017-01-23 19:11:38 --> Final output sent to browser
DEBUG - 2017-01-23 19:11:38 --> Total execution time: 0.1025
INFO - 2017-01-23 19:12:48 --> Config Class Initialized
INFO - 2017-01-23 19:12:48 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:12:48 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:12:48 --> Utf8 Class Initialized
INFO - 2017-01-23 19:12:48 --> URI Class Initialized
INFO - 2017-01-23 19:12:48 --> Router Class Initialized
INFO - 2017-01-23 19:12:48 --> Output Class Initialized
INFO - 2017-01-23 19:12:48 --> Security Class Initialized
DEBUG - 2017-01-23 19:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:12:48 --> Input Class Initialized
INFO - 2017-01-23 19:12:48 --> Language Class Initialized
INFO - 2017-01-23 19:12:48 --> Loader Class Initialized
INFO - 2017-01-23 19:12:48 --> Database Driver Class Initialized
INFO - 2017-01-23 19:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:12:48 --> Controller Class Initialized
INFO - 2017-01-23 19:12:48 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:12:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:12:48 --> Helper loaded: form_helper
INFO - 2017-01-23 19:12:48 --> Form Validation Class Initialized
INFO - 2017-01-23 19:12:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 19:12:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-23 19:12:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 19:12:48 --> Final output sent to browser
DEBUG - 2017-01-23 19:12:48 --> Total execution time: 0.5712
INFO - 2017-01-23 19:12:54 --> Config Class Initialized
INFO - 2017-01-23 19:12:54 --> Hooks Class Initialized
DEBUG - 2017-01-23 19:12:54 --> UTF-8 Support Enabled
INFO - 2017-01-23 19:12:54 --> Utf8 Class Initialized
INFO - 2017-01-23 19:12:54 --> URI Class Initialized
INFO - 2017-01-23 19:12:54 --> Router Class Initialized
INFO - 2017-01-23 19:12:54 --> Output Class Initialized
INFO - 2017-01-23 19:12:54 --> Security Class Initialized
DEBUG - 2017-01-23 19:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 19:12:54 --> Input Class Initialized
INFO - 2017-01-23 19:12:54 --> Language Class Initialized
INFO - 2017-01-23 19:12:54 --> Loader Class Initialized
INFO - 2017-01-23 19:12:54 --> Database Driver Class Initialized
INFO - 2017-01-23 19:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 19:12:54 --> Controller Class Initialized
INFO - 2017-01-23 19:12:54 --> Helper loaded: url_helper
DEBUG - 2017-01-23 19:12:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 19:12:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 19:12:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 19:12:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 19:12:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 19:12:54 --> Final output sent to browser
DEBUG - 2017-01-23 19:12:54 --> Total execution time: 0.0285
INFO - 2017-01-23 20:28:55 --> Config Class Initialized
INFO - 2017-01-23 20:28:55 --> Hooks Class Initialized
DEBUG - 2017-01-23 20:28:55 --> UTF-8 Support Enabled
INFO - 2017-01-23 20:28:55 --> Utf8 Class Initialized
INFO - 2017-01-23 20:28:55 --> URI Class Initialized
DEBUG - 2017-01-23 20:28:55 --> No URI present. Default controller set.
INFO - 2017-01-23 20:28:55 --> Router Class Initialized
INFO - 2017-01-23 20:28:55 --> Output Class Initialized
INFO - 2017-01-23 20:28:55 --> Security Class Initialized
DEBUG - 2017-01-23 20:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 20:28:55 --> Input Class Initialized
INFO - 2017-01-23 20:28:55 --> Language Class Initialized
INFO - 2017-01-23 20:28:55 --> Loader Class Initialized
INFO - 2017-01-23 20:28:55 --> Database Driver Class Initialized
INFO - 2017-01-23 20:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 20:28:58 --> Controller Class Initialized
INFO - 2017-01-23 20:28:58 --> Helper loaded: url_helper
DEBUG - 2017-01-23 20:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 20:28:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 20:28:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 20:28:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 20:28:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 20:28:58 --> Final output sent to browser
DEBUG - 2017-01-23 20:28:58 --> Total execution time: 2.7351
INFO - 2017-01-23 20:29:26 --> Config Class Initialized
INFO - 2017-01-23 20:29:26 --> Hooks Class Initialized
DEBUG - 2017-01-23 20:29:26 --> UTF-8 Support Enabled
INFO - 2017-01-23 20:29:26 --> Utf8 Class Initialized
INFO - 2017-01-23 20:29:26 --> URI Class Initialized
INFO - 2017-01-23 20:29:26 --> Router Class Initialized
INFO - 2017-01-23 20:29:26 --> Output Class Initialized
INFO - 2017-01-23 20:29:26 --> Security Class Initialized
DEBUG - 2017-01-23 20:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 20:29:26 --> Input Class Initialized
INFO - 2017-01-23 20:29:26 --> Language Class Initialized
INFO - 2017-01-23 20:29:26 --> Loader Class Initialized
INFO - 2017-01-23 20:29:26 --> Database Driver Class Initialized
INFO - 2017-01-23 20:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 20:29:26 --> Controller Class Initialized
INFO - 2017-01-23 20:29:26 --> Helper loaded: url_helper
DEBUG - 2017-01-23 20:29:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 20:29:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 20:29:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 20:29:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 20:29:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 20:29:26 --> Final output sent to browser
DEBUG - 2017-01-23 20:29:26 --> Total execution time: 0.2543
INFO - 2017-01-23 22:43:34 --> Config Class Initialized
INFO - 2017-01-23 22:43:34 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:43:34 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:43:34 --> Utf8 Class Initialized
INFO - 2017-01-23 22:43:34 --> URI Class Initialized
DEBUG - 2017-01-23 22:43:34 --> No URI present. Default controller set.
INFO - 2017-01-23 22:43:34 --> Router Class Initialized
INFO - 2017-01-23 22:43:34 --> Output Class Initialized
INFO - 2017-01-23 22:43:34 --> Security Class Initialized
DEBUG - 2017-01-23 22:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:43:34 --> Input Class Initialized
INFO - 2017-01-23 22:43:34 --> Language Class Initialized
INFO - 2017-01-23 22:43:34 --> Loader Class Initialized
INFO - 2017-01-23 22:43:34 --> Database Driver Class Initialized
INFO - 2017-01-23 22:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:43:34 --> Controller Class Initialized
INFO - 2017-01-23 22:43:34 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:43:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:43:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:43:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:43:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:43:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:43:35 --> Final output sent to browser
DEBUG - 2017-01-23 22:43:35 --> Total execution time: 0.0460
INFO - 2017-01-23 22:43:37 --> Config Class Initialized
INFO - 2017-01-23 22:43:37 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:43:37 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:43:37 --> Utf8 Class Initialized
INFO - 2017-01-23 22:43:37 --> URI Class Initialized
INFO - 2017-01-23 22:43:37 --> Router Class Initialized
INFO - 2017-01-23 22:43:37 --> Output Class Initialized
INFO - 2017-01-23 22:43:37 --> Security Class Initialized
DEBUG - 2017-01-23 22:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:43:37 --> Input Class Initialized
INFO - 2017-01-23 22:43:37 --> Language Class Initialized
INFO - 2017-01-23 22:43:37 --> Loader Class Initialized
INFO - 2017-01-23 22:43:37 --> Database Driver Class Initialized
INFO - 2017-01-23 22:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:43:37 --> Controller Class Initialized
INFO - 2017-01-23 22:43:37 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:43:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:43:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:43:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:43:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:43:37 --> Final output sent to browser
DEBUG - 2017-01-23 22:43:37 --> Total execution time: 0.0135
INFO - 2017-01-23 22:43:42 --> Config Class Initialized
INFO - 2017-01-23 22:43:42 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:43:42 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:43:42 --> Utf8 Class Initialized
INFO - 2017-01-23 22:43:42 --> URI Class Initialized
INFO - 2017-01-23 22:43:42 --> Router Class Initialized
INFO - 2017-01-23 22:43:42 --> Output Class Initialized
INFO - 2017-01-23 22:43:42 --> Security Class Initialized
DEBUG - 2017-01-23 22:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:43:42 --> Input Class Initialized
INFO - 2017-01-23 22:43:42 --> Language Class Initialized
INFO - 2017-01-23 22:43:42 --> Loader Class Initialized
INFO - 2017-01-23 22:43:42 --> Database Driver Class Initialized
INFO - 2017-01-23 22:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:43:42 --> Controller Class Initialized
INFO - 2017-01-23 22:43:42 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:43:42 --> Helper loaded: form_helper
INFO - 2017-01-23 22:43:42 --> Form Validation Class Initialized
INFO - 2017-01-23 22:43:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 22:43:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-23 22:43:42 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 22:43:42 --> Final output sent to browser
DEBUG - 2017-01-23 22:43:42 --> Total execution time: 0.1089
INFO - 2017-01-23 22:43:43 --> Config Class Initialized
INFO - 2017-01-23 22:43:43 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:43:43 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:43:43 --> Utf8 Class Initialized
INFO - 2017-01-23 22:43:43 --> URI Class Initialized
INFO - 2017-01-23 22:43:43 --> Router Class Initialized
INFO - 2017-01-23 22:43:43 --> Output Class Initialized
INFO - 2017-01-23 22:43:43 --> Security Class Initialized
DEBUG - 2017-01-23 22:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:43:43 --> Input Class Initialized
INFO - 2017-01-23 22:43:43 --> Language Class Initialized
INFO - 2017-01-23 22:43:43 --> Loader Class Initialized
INFO - 2017-01-23 22:43:43 --> Database Driver Class Initialized
INFO - 2017-01-23 22:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:43:43 --> Controller Class Initialized
INFO - 2017-01-23 22:43:43 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:43:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:43:43 --> Final output sent to browser
DEBUG - 2017-01-23 22:43:43 --> Total execution time: 0.0145
INFO - 2017-01-23 22:44:14 --> Config Class Initialized
INFO - 2017-01-23 22:44:14 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:44:14 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:44:14 --> Utf8 Class Initialized
INFO - 2017-01-23 22:44:14 --> URI Class Initialized
INFO - 2017-01-23 22:44:14 --> Router Class Initialized
INFO - 2017-01-23 22:44:14 --> Output Class Initialized
INFO - 2017-01-23 22:44:14 --> Security Class Initialized
DEBUG - 2017-01-23 22:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:44:14 --> Input Class Initialized
INFO - 2017-01-23 22:44:14 --> Language Class Initialized
INFO - 2017-01-23 22:44:14 --> Loader Class Initialized
INFO - 2017-01-23 22:44:14 --> Database Driver Class Initialized
INFO - 2017-01-23 22:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:44:14 --> Controller Class Initialized
INFO - 2017-01-23 22:44:14 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:44:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:44:14 --> Helper loaded: form_helper
INFO - 2017-01-23 22:44:14 --> Form Validation Class Initialized
INFO - 2017-01-23 22:44:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-23 22:44:14 --> Config Class Initialized
INFO - 2017-01-23 22:44:14 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:44:14 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:44:14 --> Utf8 Class Initialized
INFO - 2017-01-23 22:44:14 --> URI Class Initialized
INFO - 2017-01-23 22:44:14 --> Router Class Initialized
INFO - 2017-01-23 22:44:14 --> Output Class Initialized
INFO - 2017-01-23 22:44:14 --> Security Class Initialized
DEBUG - 2017-01-23 22:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:44:14 --> Input Class Initialized
INFO - 2017-01-23 22:44:14 --> Language Class Initialized
INFO - 2017-01-23 22:44:14 --> Loader Class Initialized
INFO - 2017-01-23 22:44:14 --> Database Driver Class Initialized
INFO - 2017-01-23 22:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:44:14 --> Controller Class Initialized
INFO - 2017-01-23 22:44:14 --> Helper loaded: date_helper
INFO - 2017-01-23 22:44:14 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:44:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:44:14 --> Helper loaded: form_helper
INFO - 2017-01-23 22:44:14 --> Form Validation Class Initialized
INFO - 2017-01-23 22:44:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 22:44:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 22:44:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-23 22:44:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-23 22:44:14 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 22:44:14 --> Final output sent to browser
DEBUG - 2017-01-23 22:44:14 --> Total execution time: 0.0919
INFO - 2017-01-23 22:44:15 --> Config Class Initialized
INFO - 2017-01-23 22:44:15 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:44:15 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:44:15 --> Utf8 Class Initialized
INFO - 2017-01-23 22:44:15 --> URI Class Initialized
INFO - 2017-01-23 22:44:15 --> Router Class Initialized
INFO - 2017-01-23 22:44:15 --> Output Class Initialized
INFO - 2017-01-23 22:44:15 --> Security Class Initialized
DEBUG - 2017-01-23 22:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:44:15 --> Input Class Initialized
INFO - 2017-01-23 22:44:15 --> Language Class Initialized
INFO - 2017-01-23 22:44:15 --> Loader Class Initialized
INFO - 2017-01-23 22:44:15 --> Database Driver Class Initialized
INFO - 2017-01-23 22:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:44:15 --> Controller Class Initialized
INFO - 2017-01-23 22:44:15 --> Helper loaded: date_helper
INFO - 2017-01-23 22:44:15 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:44:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:44:15 --> Helper loaded: form_helper
INFO - 2017-01-23 22:44:15 --> Form Validation Class Initialized
INFO - 2017-01-23 22:44:15 --> Final output sent to browser
DEBUG - 2017-01-23 22:44:15 --> Total execution time: 0.0352
INFO - 2017-01-23 22:44:16 --> Config Class Initialized
INFO - 2017-01-23 22:44:16 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:44:16 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:44:16 --> Utf8 Class Initialized
INFO - 2017-01-23 22:44:16 --> URI Class Initialized
INFO - 2017-01-23 22:44:16 --> Router Class Initialized
INFO - 2017-01-23 22:44:16 --> Output Class Initialized
INFO - 2017-01-23 22:44:16 --> Security Class Initialized
DEBUG - 2017-01-23 22:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:44:16 --> Input Class Initialized
INFO - 2017-01-23 22:44:16 --> Language Class Initialized
INFO - 2017-01-23 22:44:16 --> Loader Class Initialized
INFO - 2017-01-23 22:44:16 --> Database Driver Class Initialized
INFO - 2017-01-23 22:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:44:16 --> Controller Class Initialized
INFO - 2017-01-23 22:44:16 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:44:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:44:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:44:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:44:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:44:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:44:16 --> Final output sent to browser
DEBUG - 2017-01-23 22:44:16 --> Total execution time: 0.0138
INFO - 2017-01-23 22:44:24 --> Config Class Initialized
INFO - 2017-01-23 22:44:24 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:44:24 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:44:24 --> Utf8 Class Initialized
INFO - 2017-01-23 22:44:24 --> URI Class Initialized
INFO - 2017-01-23 22:44:24 --> Router Class Initialized
INFO - 2017-01-23 22:44:24 --> Output Class Initialized
INFO - 2017-01-23 22:44:24 --> Security Class Initialized
DEBUG - 2017-01-23 22:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:44:24 --> Input Class Initialized
INFO - 2017-01-23 22:44:24 --> Language Class Initialized
INFO - 2017-01-23 22:44:24 --> Loader Class Initialized
INFO - 2017-01-23 22:44:24 --> Database Driver Class Initialized
INFO - 2017-01-23 22:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:44:24 --> Controller Class Initialized
INFO - 2017-01-23 22:44:24 --> Upload Class Initialized
INFO - 2017-01-23 22:44:24 --> Helper loaded: date_helper
INFO - 2017-01-23 22:44:24 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:44:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:44:24 --> Helper loaded: form_helper
INFO - 2017-01-23 22:44:24 --> Form Validation Class Initialized
INFO - 2017-01-23 22:44:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 22:44:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 22:44:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-23 22:44:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-23 22:44:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-23 22:44:24 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 22:44:24 --> Final output sent to browser
DEBUG - 2017-01-23 22:44:24 --> Total execution time: 0.0316
INFO - 2017-01-23 22:44:24 --> Config Class Initialized
INFO - 2017-01-23 22:44:24 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:44:24 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:44:24 --> Utf8 Class Initialized
INFO - 2017-01-23 22:44:24 --> URI Class Initialized
INFO - 2017-01-23 22:44:24 --> Router Class Initialized
INFO - 2017-01-23 22:44:24 --> Output Class Initialized
INFO - 2017-01-23 22:44:24 --> Security Class Initialized
DEBUG - 2017-01-23 22:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:44:24 --> Input Class Initialized
INFO - 2017-01-23 22:44:24 --> Language Class Initialized
INFO - 2017-01-23 22:44:24 --> Loader Class Initialized
INFO - 2017-01-23 22:44:24 --> Database Driver Class Initialized
INFO - 2017-01-23 22:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:44:24 --> Controller Class Initialized
INFO - 2017-01-23 22:44:24 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:44:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:44:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:44:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:44:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:44:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:44:24 --> Final output sent to browser
DEBUG - 2017-01-23 22:44:24 --> Total execution time: 0.0132
INFO - 2017-01-23 22:44:43 --> Config Class Initialized
INFO - 2017-01-23 22:44:43 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:44:43 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:44:43 --> Utf8 Class Initialized
INFO - 2017-01-23 22:44:43 --> URI Class Initialized
INFO - 2017-01-23 22:44:43 --> Router Class Initialized
INFO - 2017-01-23 22:44:43 --> Output Class Initialized
INFO - 2017-01-23 22:44:43 --> Security Class Initialized
DEBUG - 2017-01-23 22:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:44:43 --> Input Class Initialized
INFO - 2017-01-23 22:44:43 --> Language Class Initialized
INFO - 2017-01-23 22:44:43 --> Loader Class Initialized
INFO - 2017-01-23 22:44:43 --> Database Driver Class Initialized
INFO - 2017-01-23 22:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:44:43 --> Controller Class Initialized
INFO - 2017-01-23 22:44:43 --> Helper loaded: date_helper
INFO - 2017-01-23 22:44:43 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:44:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:44:43 --> Helper loaded: form_helper
INFO - 2017-01-23 22:44:43 --> Form Validation Class Initialized
INFO - 2017-01-23 22:44:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 22:44:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 22:44:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-23 22:44:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-23 22:44:43 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 22:44:43 --> Final output sent to browser
DEBUG - 2017-01-23 22:44:43 --> Total execution time: 0.0374
INFO - 2017-01-23 22:44:43 --> Config Class Initialized
INFO - 2017-01-23 22:44:43 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:44:43 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:44:43 --> Utf8 Class Initialized
INFO - 2017-01-23 22:44:43 --> URI Class Initialized
INFO - 2017-01-23 22:44:43 --> Router Class Initialized
INFO - 2017-01-23 22:44:43 --> Output Class Initialized
INFO - 2017-01-23 22:44:43 --> Security Class Initialized
DEBUG - 2017-01-23 22:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:44:43 --> Input Class Initialized
INFO - 2017-01-23 22:44:43 --> Language Class Initialized
INFO - 2017-01-23 22:44:43 --> Loader Class Initialized
INFO - 2017-01-23 22:44:43 --> Database Driver Class Initialized
INFO - 2017-01-23 22:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:44:43 --> Controller Class Initialized
INFO - 2017-01-23 22:44:43 --> Helper loaded: date_helper
INFO - 2017-01-23 22:44:43 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:44:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:44:43 --> Helper loaded: form_helper
INFO - 2017-01-23 22:44:43 --> Form Validation Class Initialized
INFO - 2017-01-23 22:44:43 --> Final output sent to browser
DEBUG - 2017-01-23 22:44:43 --> Total execution time: 0.0146
INFO - 2017-01-23 22:44:44 --> Config Class Initialized
INFO - 2017-01-23 22:44:44 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:44:44 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:44:44 --> Utf8 Class Initialized
INFO - 2017-01-23 22:44:44 --> URI Class Initialized
INFO - 2017-01-23 22:44:44 --> Router Class Initialized
INFO - 2017-01-23 22:44:44 --> Output Class Initialized
INFO - 2017-01-23 22:44:44 --> Security Class Initialized
DEBUG - 2017-01-23 22:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:44:44 --> Input Class Initialized
INFO - 2017-01-23 22:44:44 --> Language Class Initialized
INFO - 2017-01-23 22:44:44 --> Loader Class Initialized
INFO - 2017-01-23 22:44:44 --> Database Driver Class Initialized
INFO - 2017-01-23 22:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:44:44 --> Controller Class Initialized
INFO - 2017-01-23 22:44:44 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:44:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:44:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:44:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:44:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:44:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:44:44 --> Final output sent to browser
DEBUG - 2017-01-23 22:44:44 --> Total execution time: 0.0140
INFO - 2017-01-23 22:44:46 --> Config Class Initialized
INFO - 2017-01-23 22:44:46 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:44:46 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:44:46 --> Utf8 Class Initialized
INFO - 2017-01-23 22:44:46 --> URI Class Initialized
INFO - 2017-01-23 22:44:46 --> Router Class Initialized
INFO - 2017-01-23 22:44:46 --> Output Class Initialized
INFO - 2017-01-23 22:44:46 --> Security Class Initialized
DEBUG - 2017-01-23 22:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:44:46 --> Input Class Initialized
INFO - 2017-01-23 22:44:46 --> Language Class Initialized
INFO - 2017-01-23 22:44:46 --> Loader Class Initialized
INFO - 2017-01-23 22:44:46 --> Database Driver Class Initialized
INFO - 2017-01-23 22:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:44:46 --> Controller Class Initialized
INFO - 2017-01-23 22:44:46 --> Helper loaded: date_helper
INFO - 2017-01-23 22:44:46 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:44:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:44:46 --> Helper loaded: form_helper
INFO - 2017-01-23 22:44:46 --> Form Validation Class Initialized
INFO - 2017-01-23 22:44:46 --> Final output sent to browser
DEBUG - 2017-01-23 22:44:46 --> Total execution time: 0.0343
INFO - 2017-01-23 22:44:48 --> Config Class Initialized
INFO - 2017-01-23 22:44:48 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:44:48 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:44:48 --> Utf8 Class Initialized
INFO - 2017-01-23 22:44:48 --> URI Class Initialized
INFO - 2017-01-23 22:44:48 --> Router Class Initialized
INFO - 2017-01-23 22:44:48 --> Output Class Initialized
INFO - 2017-01-23 22:44:48 --> Security Class Initialized
DEBUG - 2017-01-23 22:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:44:48 --> Input Class Initialized
INFO - 2017-01-23 22:44:48 --> Language Class Initialized
INFO - 2017-01-23 22:44:48 --> Loader Class Initialized
INFO - 2017-01-23 22:44:48 --> Database Driver Class Initialized
INFO - 2017-01-23 22:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:44:48 --> Controller Class Initialized
INFO - 2017-01-23 22:44:48 --> Helper loaded: date_helper
INFO - 2017-01-23 22:44:48 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:44:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:44:48 --> Helper loaded: form_helper
INFO - 2017-01-23 22:44:48 --> Form Validation Class Initialized
INFO - 2017-01-23 22:44:48 --> Final output sent to browser
DEBUG - 2017-01-23 22:44:48 --> Total execution time: 0.0154
INFO - 2017-01-23 22:44:53 --> Config Class Initialized
INFO - 2017-01-23 22:44:53 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:44:53 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:44:53 --> Utf8 Class Initialized
INFO - 2017-01-23 22:44:53 --> URI Class Initialized
INFO - 2017-01-23 22:44:53 --> Router Class Initialized
INFO - 2017-01-23 22:44:53 --> Output Class Initialized
INFO - 2017-01-23 22:44:53 --> Security Class Initialized
DEBUG - 2017-01-23 22:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:44:53 --> Input Class Initialized
INFO - 2017-01-23 22:44:53 --> Language Class Initialized
INFO - 2017-01-23 22:44:53 --> Loader Class Initialized
INFO - 2017-01-23 22:44:53 --> Database Driver Class Initialized
INFO - 2017-01-23 22:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:44:53 --> Controller Class Initialized
INFO - 2017-01-23 22:44:53 --> Helper loaded: date_helper
INFO - 2017-01-23 22:44:53 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:44:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:44:53 --> Helper loaded: form_helper
INFO - 2017-01-23 22:44:53 --> Form Validation Class Initialized
INFO - 2017-01-23 22:44:53 --> Final output sent to browser
DEBUG - 2017-01-23 22:44:53 --> Total execution time: 0.0200
INFO - 2017-01-23 22:44:59 --> Config Class Initialized
INFO - 2017-01-23 22:44:59 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:44:59 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:44:59 --> Utf8 Class Initialized
INFO - 2017-01-23 22:44:59 --> URI Class Initialized
INFO - 2017-01-23 22:44:59 --> Router Class Initialized
INFO - 2017-01-23 22:44:59 --> Output Class Initialized
INFO - 2017-01-23 22:44:59 --> Security Class Initialized
DEBUG - 2017-01-23 22:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:44:59 --> Input Class Initialized
INFO - 2017-01-23 22:44:59 --> Language Class Initialized
INFO - 2017-01-23 22:44:59 --> Loader Class Initialized
INFO - 2017-01-23 22:44:59 --> Database Driver Class Initialized
INFO - 2017-01-23 22:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:44:59 --> Controller Class Initialized
INFO - 2017-01-23 22:44:59 --> Helper loaded: date_helper
INFO - 2017-01-23 22:44:59 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:44:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:45:00 --> Helper loaded: form_helper
INFO - 2017-01-23 22:45:00 --> Form Validation Class Initialized
INFO - 2017-01-23 22:45:00 --> Final output sent to browser
DEBUG - 2017-01-23 22:45:00 --> Total execution time: 0.0149
INFO - 2017-01-23 22:45:01 --> Config Class Initialized
INFO - 2017-01-23 22:45:01 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:45:01 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:45:01 --> Utf8 Class Initialized
INFO - 2017-01-23 22:45:01 --> URI Class Initialized
INFO - 2017-01-23 22:45:01 --> Router Class Initialized
INFO - 2017-01-23 22:45:01 --> Output Class Initialized
INFO - 2017-01-23 22:45:01 --> Security Class Initialized
DEBUG - 2017-01-23 22:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:45:01 --> Input Class Initialized
INFO - 2017-01-23 22:45:01 --> Language Class Initialized
INFO - 2017-01-23 22:45:01 --> Loader Class Initialized
INFO - 2017-01-23 22:45:01 --> Database Driver Class Initialized
INFO - 2017-01-23 22:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:45:01 --> Controller Class Initialized
INFO - 2017-01-23 22:45:01 --> Helper loaded: date_helper
INFO - 2017-01-23 22:45:01 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:45:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:45:01 --> Helper loaded: form_helper
INFO - 2017-01-23 22:45:01 --> Form Validation Class Initialized
INFO - 2017-01-23 22:45:01 --> Final output sent to browser
DEBUG - 2017-01-23 22:45:01 --> Total execution time: 0.0158
INFO - 2017-01-23 22:45:41 --> Config Class Initialized
INFO - 2017-01-23 22:45:41 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:45:41 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:45:41 --> Utf8 Class Initialized
INFO - 2017-01-23 22:45:41 --> URI Class Initialized
INFO - 2017-01-23 22:45:41 --> Router Class Initialized
INFO - 2017-01-23 22:45:41 --> Output Class Initialized
INFO - 2017-01-23 22:45:41 --> Security Class Initialized
DEBUG - 2017-01-23 22:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:45:41 --> Input Class Initialized
INFO - 2017-01-23 22:45:41 --> Language Class Initialized
INFO - 2017-01-23 22:45:41 --> Loader Class Initialized
INFO - 2017-01-23 22:45:41 --> Database Driver Class Initialized
INFO - 2017-01-23 22:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:45:41 --> Controller Class Initialized
INFO - 2017-01-23 22:45:41 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:45:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:45:41 --> Config Class Initialized
INFO - 2017-01-23 22:45:41 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:45:41 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:45:41 --> Utf8 Class Initialized
INFO - 2017-01-23 22:45:41 --> URI Class Initialized
INFO - 2017-01-23 22:45:41 --> Router Class Initialized
INFO - 2017-01-23 22:45:41 --> Output Class Initialized
INFO - 2017-01-23 22:45:41 --> Security Class Initialized
DEBUG - 2017-01-23 22:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:45:41 --> Input Class Initialized
INFO - 2017-01-23 22:45:41 --> Language Class Initialized
INFO - 2017-01-23 22:45:41 --> Loader Class Initialized
INFO - 2017-01-23 22:45:41 --> Database Driver Class Initialized
INFO - 2017-01-23 22:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:45:41 --> Controller Class Initialized
INFO - 2017-01-23 22:45:41 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:45:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:45:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:45:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:45:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:45:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:45:41 --> Final output sent to browser
DEBUG - 2017-01-23 22:45:41 --> Total execution time: 0.0238
INFO - 2017-01-23 22:45:41 --> Config Class Initialized
INFO - 2017-01-23 22:45:41 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:45:41 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:45:41 --> Utf8 Class Initialized
INFO - 2017-01-23 22:45:41 --> URI Class Initialized
INFO - 2017-01-23 22:45:41 --> Router Class Initialized
INFO - 2017-01-23 22:45:41 --> Output Class Initialized
INFO - 2017-01-23 22:45:41 --> Security Class Initialized
DEBUG - 2017-01-23 22:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:45:41 --> Input Class Initialized
INFO - 2017-01-23 22:45:41 --> Language Class Initialized
INFO - 2017-01-23 22:45:41 --> Loader Class Initialized
INFO - 2017-01-23 22:45:41 --> Database Driver Class Initialized
INFO - 2017-01-23 22:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:45:41 --> Controller Class Initialized
INFO - 2017-01-23 22:45:41 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:45:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:45:41 --> Helper loaded: form_helper
INFO - 2017-01-23 22:45:41 --> Form Validation Class Initialized
INFO - 2017-01-23 22:45:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 22:45:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-23 22:45:41 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 22:45:41 --> Final output sent to browser
DEBUG - 2017-01-23 22:45:41 --> Total execution time: 0.0404
INFO - 2017-01-23 22:45:41 --> Config Class Initialized
INFO - 2017-01-23 22:45:41 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:45:41 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:45:41 --> Utf8 Class Initialized
INFO - 2017-01-23 22:45:41 --> URI Class Initialized
INFO - 2017-01-23 22:45:41 --> Router Class Initialized
INFO - 2017-01-23 22:45:41 --> Output Class Initialized
INFO - 2017-01-23 22:45:41 --> Security Class Initialized
DEBUG - 2017-01-23 22:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:45:41 --> Input Class Initialized
INFO - 2017-01-23 22:45:41 --> Language Class Initialized
INFO - 2017-01-23 22:45:41 --> Loader Class Initialized
INFO - 2017-01-23 22:45:41 --> Database Driver Class Initialized
INFO - 2017-01-23 22:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:45:41 --> Controller Class Initialized
INFO - 2017-01-23 22:45:41 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:45:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:45:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:45:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:45:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:45:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:45:41 --> Final output sent to browser
DEBUG - 2017-01-23 22:45:41 --> Total execution time: 0.0135
INFO - 2017-01-23 22:45:46 --> Config Class Initialized
INFO - 2017-01-23 22:45:46 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:45:46 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:45:46 --> Utf8 Class Initialized
INFO - 2017-01-23 22:45:46 --> URI Class Initialized
DEBUG - 2017-01-23 22:45:46 --> No URI present. Default controller set.
INFO - 2017-01-23 22:45:46 --> Router Class Initialized
INFO - 2017-01-23 22:45:46 --> Output Class Initialized
INFO - 2017-01-23 22:45:46 --> Security Class Initialized
DEBUG - 2017-01-23 22:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:45:46 --> Input Class Initialized
INFO - 2017-01-23 22:45:46 --> Language Class Initialized
INFO - 2017-01-23 22:45:46 --> Loader Class Initialized
INFO - 2017-01-23 22:45:46 --> Database Driver Class Initialized
INFO - 2017-01-23 22:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:45:46 --> Controller Class Initialized
INFO - 2017-01-23 22:45:46 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:45:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:45:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:45:46 --> Final output sent to browser
DEBUG - 2017-01-23 22:45:46 --> Total execution time: 0.0145
INFO - 2017-01-23 22:45:48 --> Config Class Initialized
INFO - 2017-01-23 22:45:48 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:45:48 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:45:48 --> Utf8 Class Initialized
INFO - 2017-01-23 22:45:48 --> URI Class Initialized
INFO - 2017-01-23 22:45:48 --> Router Class Initialized
INFO - 2017-01-23 22:45:48 --> Output Class Initialized
INFO - 2017-01-23 22:45:48 --> Security Class Initialized
DEBUG - 2017-01-23 22:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:45:48 --> Input Class Initialized
INFO - 2017-01-23 22:45:48 --> Language Class Initialized
INFO - 2017-01-23 22:45:48 --> Loader Class Initialized
INFO - 2017-01-23 22:45:48 --> Database Driver Class Initialized
INFO - 2017-01-23 22:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:45:48 --> Controller Class Initialized
INFO - 2017-01-23 22:45:48 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:45:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:45:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:45:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:45:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:45:48 --> Final output sent to browser
DEBUG - 2017-01-23 22:45:48 --> Total execution time: 0.0136
INFO - 2017-01-23 22:46:50 --> Config Class Initialized
INFO - 2017-01-23 22:46:50 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:46:50 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:46:50 --> Utf8 Class Initialized
INFO - 2017-01-23 22:46:50 --> URI Class Initialized
INFO - 2017-01-23 22:46:50 --> Router Class Initialized
INFO - 2017-01-23 22:46:50 --> Output Class Initialized
INFO - 2017-01-23 22:46:50 --> Security Class Initialized
DEBUG - 2017-01-23 22:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:46:50 --> Input Class Initialized
INFO - 2017-01-23 22:46:50 --> Language Class Initialized
INFO - 2017-01-23 22:46:50 --> Loader Class Initialized
INFO - 2017-01-23 22:46:50 --> Database Driver Class Initialized
INFO - 2017-01-23 22:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:46:50 --> Controller Class Initialized
INFO - 2017-01-23 22:46:50 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:46:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:46:50 --> Config Class Initialized
INFO - 2017-01-23 22:46:50 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:46:50 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:46:50 --> Utf8 Class Initialized
INFO - 2017-01-23 22:46:50 --> URI Class Initialized
INFO - 2017-01-23 22:46:50 --> Router Class Initialized
INFO - 2017-01-23 22:46:50 --> Output Class Initialized
INFO - 2017-01-23 22:46:50 --> Security Class Initialized
DEBUG - 2017-01-23 22:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:46:50 --> Input Class Initialized
INFO - 2017-01-23 22:46:50 --> Language Class Initialized
INFO - 2017-01-23 22:46:50 --> Loader Class Initialized
INFO - 2017-01-23 22:46:50 --> Database Driver Class Initialized
INFO - 2017-01-23 22:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:46:50 --> Controller Class Initialized
INFO - 2017-01-23 22:46:50 --> Helper loaded: date_helper
DEBUG - 2017-01-23 22:46:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:46:50 --> Helper loaded: url_helper
INFO - 2017-01-23 22:46:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:46:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 22:46:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-23 22:46:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-23 22:46:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:46:50 --> Final output sent to browser
DEBUG - 2017-01-23 22:46:50 --> Total execution time: 0.0734
INFO - 2017-01-23 22:46:52 --> Config Class Initialized
INFO - 2017-01-23 22:46:52 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:46:52 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:46:52 --> Utf8 Class Initialized
INFO - 2017-01-23 22:46:52 --> URI Class Initialized
INFO - 2017-01-23 22:46:52 --> Router Class Initialized
INFO - 2017-01-23 22:46:52 --> Output Class Initialized
INFO - 2017-01-23 22:46:52 --> Security Class Initialized
DEBUG - 2017-01-23 22:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:46:52 --> Input Class Initialized
INFO - 2017-01-23 22:46:52 --> Language Class Initialized
INFO - 2017-01-23 22:46:52 --> Loader Class Initialized
INFO - 2017-01-23 22:46:52 --> Database Driver Class Initialized
INFO - 2017-01-23 22:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:46:52 --> Controller Class Initialized
INFO - 2017-01-23 22:46:52 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:46:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:46:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:46:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:46:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:46:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:46:52 --> Final output sent to browser
DEBUG - 2017-01-23 22:46:52 --> Total execution time: 0.0141
INFO - 2017-01-23 22:46:53 --> Config Class Initialized
INFO - 2017-01-23 22:46:53 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:46:53 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:46:53 --> Utf8 Class Initialized
INFO - 2017-01-23 22:46:53 --> URI Class Initialized
INFO - 2017-01-23 22:46:53 --> Router Class Initialized
INFO - 2017-01-23 22:46:53 --> Output Class Initialized
INFO - 2017-01-23 22:46:53 --> Security Class Initialized
DEBUG - 2017-01-23 22:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:46:53 --> Input Class Initialized
INFO - 2017-01-23 22:46:53 --> Language Class Initialized
INFO - 2017-01-23 22:46:53 --> Loader Class Initialized
INFO - 2017-01-23 22:46:53 --> Database Driver Class Initialized
INFO - 2017-01-23 22:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:46:53 --> Controller Class Initialized
INFO - 2017-01-23 22:46:53 --> Helper loaded: date_helper
DEBUG - 2017-01-23 22:46:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:46:53 --> Helper loaded: url_helper
INFO - 2017-01-23 22:46:53 --> Helper loaded: download_helper
INFO - 2017-01-23 22:46:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:46:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 22:46:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-23 22:46:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-23 22:46:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:46:53 --> Final output sent to browser
DEBUG - 2017-01-23 22:46:53 --> Total execution time: 0.0791
INFO - 2017-01-23 22:46:55 --> Config Class Initialized
INFO - 2017-01-23 22:46:55 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:46:55 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:46:55 --> Utf8 Class Initialized
INFO - 2017-01-23 22:46:55 --> URI Class Initialized
INFO - 2017-01-23 22:46:55 --> Router Class Initialized
INFO - 2017-01-23 22:46:55 --> Output Class Initialized
INFO - 2017-01-23 22:46:55 --> Security Class Initialized
DEBUG - 2017-01-23 22:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:46:55 --> Input Class Initialized
INFO - 2017-01-23 22:46:55 --> Language Class Initialized
INFO - 2017-01-23 22:46:55 --> Loader Class Initialized
INFO - 2017-01-23 22:46:55 --> Database Driver Class Initialized
INFO - 2017-01-23 22:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:46:55 --> Controller Class Initialized
INFO - 2017-01-23 22:46:55 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:46:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:46:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:46:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:46:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:46:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:46:55 --> Final output sent to browser
DEBUG - 2017-01-23 22:46:55 --> Total execution time: 0.0147
INFO - 2017-01-23 22:48:51 --> Config Class Initialized
INFO - 2017-01-23 22:48:51 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:48:51 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:48:51 --> Utf8 Class Initialized
INFO - 2017-01-23 22:48:51 --> URI Class Initialized
INFO - 2017-01-23 22:48:51 --> Router Class Initialized
INFO - 2017-01-23 22:48:51 --> Output Class Initialized
INFO - 2017-01-23 22:48:51 --> Security Class Initialized
DEBUG - 2017-01-23 22:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:48:51 --> Input Class Initialized
INFO - 2017-01-23 22:48:51 --> Language Class Initialized
INFO - 2017-01-23 22:48:51 --> Loader Class Initialized
INFO - 2017-01-23 22:48:51 --> Database Driver Class Initialized
INFO - 2017-01-23 22:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:48:51 --> Controller Class Initialized
INFO - 2017-01-23 22:48:51 --> Helper loaded: date_helper
DEBUG - 2017-01-23 22:48:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:48:51 --> Helper loaded: url_helper
INFO - 2017-01-23 22:48:51 --> Helper loaded: download_helper
INFO - 2017-01-23 22:48:51 --> Final output sent to browser
DEBUG - 2017-01-23 22:48:51 --> Total execution time: 0.0145
INFO - 2017-01-23 22:48:54 --> Config Class Initialized
INFO - 2017-01-23 22:48:54 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:48:54 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:48:54 --> Utf8 Class Initialized
INFO - 2017-01-23 22:48:54 --> URI Class Initialized
INFO - 2017-01-23 22:48:54 --> Router Class Initialized
INFO - 2017-01-23 22:48:54 --> Output Class Initialized
INFO - 2017-01-23 22:48:54 --> Security Class Initialized
DEBUG - 2017-01-23 22:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:48:54 --> Input Class Initialized
INFO - 2017-01-23 22:48:54 --> Language Class Initialized
INFO - 2017-01-23 22:48:54 --> Loader Class Initialized
INFO - 2017-01-23 22:48:54 --> Database Driver Class Initialized
INFO - 2017-01-23 22:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:48:54 --> Controller Class Initialized
INFO - 2017-01-23 22:48:54 --> Helper loaded: date_helper
DEBUG - 2017-01-23 22:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:48:54 --> Helper loaded: url_helper
INFO - 2017-01-23 22:48:54 --> Helper loaded: download_helper
INFO - 2017-01-23 22:48:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:48:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 22:48:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-23 22:48:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-23 22:48:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:48:54 --> Final output sent to browser
DEBUG - 2017-01-23 22:48:54 --> Total execution time: 0.0659
INFO - 2017-01-23 22:50:41 --> Config Class Initialized
INFO - 2017-01-23 22:50:41 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:50:41 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:50:41 --> Utf8 Class Initialized
INFO - 2017-01-23 22:50:41 --> URI Class Initialized
INFO - 2017-01-23 22:50:41 --> Router Class Initialized
INFO - 2017-01-23 22:50:41 --> Output Class Initialized
INFO - 2017-01-23 22:50:41 --> Security Class Initialized
DEBUG - 2017-01-23 22:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:50:41 --> Input Class Initialized
INFO - 2017-01-23 22:50:41 --> Language Class Initialized
INFO - 2017-01-23 22:50:41 --> Loader Class Initialized
INFO - 2017-01-23 22:50:41 --> Database Driver Class Initialized
INFO - 2017-01-23 22:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:50:41 --> Controller Class Initialized
INFO - 2017-01-23 22:50:41 --> Helper loaded: date_helper
INFO - 2017-01-23 22:50:41 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:50:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:50:41 --> Helper loaded: form_helper
INFO - 2017-01-23 22:50:41 --> Form Validation Class Initialized
INFO - 2017-01-23 22:50:41 --> Final output sent to browser
DEBUG - 2017-01-23 22:50:41 --> Total execution time: 0.0161
INFO - 2017-01-23 22:50:44 --> Config Class Initialized
INFO - 2017-01-23 22:50:44 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:50:44 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:50:44 --> Utf8 Class Initialized
INFO - 2017-01-23 22:50:44 --> URI Class Initialized
INFO - 2017-01-23 22:50:44 --> Router Class Initialized
INFO - 2017-01-23 22:50:44 --> Output Class Initialized
INFO - 2017-01-23 22:50:44 --> Security Class Initialized
DEBUG - 2017-01-23 22:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:50:44 --> Input Class Initialized
INFO - 2017-01-23 22:50:44 --> Language Class Initialized
INFO - 2017-01-23 22:50:44 --> Loader Class Initialized
INFO - 2017-01-23 22:50:44 --> Database Driver Class Initialized
INFO - 2017-01-23 22:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:50:44 --> Controller Class Initialized
INFO - 2017-01-23 22:50:44 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:50:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:50:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:50:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:50:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:50:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:50:44 --> Final output sent to browser
DEBUG - 2017-01-23 22:50:44 --> Total execution time: 0.0130
INFO - 2017-01-23 22:50:46 --> Config Class Initialized
INFO - 2017-01-23 22:50:46 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:50:46 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:50:46 --> Utf8 Class Initialized
INFO - 2017-01-23 22:50:46 --> URI Class Initialized
INFO - 2017-01-23 22:50:46 --> Router Class Initialized
INFO - 2017-01-23 22:50:46 --> Output Class Initialized
INFO - 2017-01-23 22:50:46 --> Security Class Initialized
DEBUG - 2017-01-23 22:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:50:46 --> Input Class Initialized
INFO - 2017-01-23 22:50:46 --> Language Class Initialized
INFO - 2017-01-23 22:50:46 --> Loader Class Initialized
INFO - 2017-01-23 22:50:46 --> Database Driver Class Initialized
INFO - 2017-01-23 22:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:50:46 --> Controller Class Initialized
INFO - 2017-01-23 22:50:46 --> Upload Class Initialized
INFO - 2017-01-23 22:50:46 --> Helper loaded: date_helper
DEBUG - 2017-01-23 22:50:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:50:46 --> Helper loaded: url_helper
INFO - 2017-01-23 22:50:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:50:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 22:50:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-01-23 22:50:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-01-23 22:50:46 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-23 22:50:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:50:46 --> Final output sent to browser
DEBUG - 2017-01-23 22:50:46 --> Total execution time: 0.0673
INFO - 2017-01-23 22:50:47 --> Config Class Initialized
INFO - 2017-01-23 22:50:47 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:50:47 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:50:47 --> Utf8 Class Initialized
INFO - 2017-01-23 22:50:47 --> URI Class Initialized
INFO - 2017-01-23 22:50:47 --> Router Class Initialized
INFO - 2017-01-23 22:50:47 --> Output Class Initialized
INFO - 2017-01-23 22:50:47 --> Security Class Initialized
DEBUG - 2017-01-23 22:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:50:47 --> Input Class Initialized
INFO - 2017-01-23 22:50:47 --> Language Class Initialized
INFO - 2017-01-23 22:50:47 --> Loader Class Initialized
INFO - 2017-01-23 22:50:47 --> Database Driver Class Initialized
INFO - 2017-01-23 22:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:50:47 --> Controller Class Initialized
INFO - 2017-01-23 22:50:47 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:50:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:50:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:50:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:50:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:50:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:50:47 --> Final output sent to browser
DEBUG - 2017-01-23 22:50:47 --> Total execution time: 0.0519
INFO - 2017-01-23 22:50:58 --> Config Class Initialized
INFO - 2017-01-23 22:50:58 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:50:58 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:50:58 --> Utf8 Class Initialized
INFO - 2017-01-23 22:50:58 --> URI Class Initialized
INFO - 2017-01-23 22:50:58 --> Router Class Initialized
INFO - 2017-01-23 22:50:58 --> Output Class Initialized
INFO - 2017-01-23 22:50:58 --> Security Class Initialized
DEBUG - 2017-01-23 22:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:50:58 --> Input Class Initialized
INFO - 2017-01-23 22:50:58 --> Language Class Initialized
INFO - 2017-01-23 22:50:58 --> Loader Class Initialized
INFO - 2017-01-23 22:50:58 --> Database Driver Class Initialized
INFO - 2017-01-23 22:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:50:58 --> Controller Class Initialized
INFO - 2017-01-23 22:50:58 --> Helper loaded: date_helper
DEBUG - 2017-01-23 22:50:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:50:58 --> Helper loaded: url_helper
INFO - 2017-01-23 22:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 22:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-23 22:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-23 22:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:50:58 --> Final output sent to browser
DEBUG - 2017-01-23 22:50:58 --> Total execution time: 0.0144
INFO - 2017-01-23 22:50:58 --> Config Class Initialized
INFO - 2017-01-23 22:50:58 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:50:58 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:50:58 --> Utf8 Class Initialized
INFO - 2017-01-23 22:50:58 --> URI Class Initialized
INFO - 2017-01-23 22:50:58 --> Router Class Initialized
INFO - 2017-01-23 22:50:58 --> Output Class Initialized
INFO - 2017-01-23 22:50:58 --> Security Class Initialized
DEBUG - 2017-01-23 22:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:50:58 --> Input Class Initialized
INFO - 2017-01-23 22:50:58 --> Language Class Initialized
INFO - 2017-01-23 22:50:58 --> Loader Class Initialized
INFO - 2017-01-23 22:50:58 --> Database Driver Class Initialized
INFO - 2017-01-23 22:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:50:58 --> Controller Class Initialized
INFO - 2017-01-23 22:50:58 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:50:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:50:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:50:58 --> Final output sent to browser
DEBUG - 2017-01-23 22:50:58 --> Total execution time: 0.0140
INFO - 2017-01-23 22:51:43 --> Config Class Initialized
INFO - 2017-01-23 22:51:43 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:51:43 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:51:43 --> Utf8 Class Initialized
INFO - 2017-01-23 22:51:43 --> URI Class Initialized
INFO - 2017-01-23 22:51:43 --> Router Class Initialized
INFO - 2017-01-23 22:51:43 --> Output Class Initialized
INFO - 2017-01-23 22:51:43 --> Security Class Initialized
DEBUG - 2017-01-23 22:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:51:43 --> Input Class Initialized
INFO - 2017-01-23 22:51:43 --> Language Class Initialized
INFO - 2017-01-23 22:51:43 --> Loader Class Initialized
INFO - 2017-01-23 22:51:43 --> Database Driver Class Initialized
INFO - 2017-01-23 22:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:51:43 --> Controller Class Initialized
INFO - 2017-01-23 22:51:43 --> Helper loaded: date_helper
DEBUG - 2017-01-23 22:51:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:51:43 --> Helper loaded: url_helper
INFO - 2017-01-23 22:51:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:51:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-23 22:51:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 22:51:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-23 22:51:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-23 22:51:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:51:43 --> Final output sent to browser
DEBUG - 2017-01-23 22:51:43 --> Total execution time: 0.0808
INFO - 2017-01-23 22:51:44 --> Config Class Initialized
INFO - 2017-01-23 22:51:44 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:51:44 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:51:44 --> Utf8 Class Initialized
INFO - 2017-01-23 22:51:44 --> URI Class Initialized
INFO - 2017-01-23 22:51:44 --> Router Class Initialized
INFO - 2017-01-23 22:51:44 --> Output Class Initialized
INFO - 2017-01-23 22:51:44 --> Security Class Initialized
DEBUG - 2017-01-23 22:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:51:44 --> Input Class Initialized
INFO - 2017-01-23 22:51:44 --> Language Class Initialized
INFO - 2017-01-23 22:51:44 --> Loader Class Initialized
INFO - 2017-01-23 22:51:44 --> Database Driver Class Initialized
INFO - 2017-01-23 22:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:51:44 --> Controller Class Initialized
INFO - 2017-01-23 22:51:44 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:51:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:51:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:51:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:51:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:51:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:51:44 --> Final output sent to browser
DEBUG - 2017-01-23 22:51:44 --> Total execution time: 0.0551
INFO - 2017-01-23 22:51:46 --> Config Class Initialized
INFO - 2017-01-23 22:51:46 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:51:46 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:51:46 --> Utf8 Class Initialized
INFO - 2017-01-23 22:51:46 --> URI Class Initialized
INFO - 2017-01-23 22:51:46 --> Router Class Initialized
INFO - 2017-01-23 22:51:46 --> Output Class Initialized
INFO - 2017-01-23 22:51:46 --> Security Class Initialized
DEBUG - 2017-01-23 22:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:51:46 --> Input Class Initialized
INFO - 2017-01-23 22:51:46 --> Language Class Initialized
INFO - 2017-01-23 22:51:46 --> Loader Class Initialized
INFO - 2017-01-23 22:51:46 --> Database Driver Class Initialized
INFO - 2017-01-23 22:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:51:46 --> Controller Class Initialized
INFO - 2017-01-23 22:51:46 --> Helper loaded: date_helper
DEBUG - 2017-01-23 22:51:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:51:46 --> Helper loaded: url_helper
INFO - 2017-01-23 22:51:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:51:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 22:51:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-23 22:51:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-23 22:51:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:51:46 --> Final output sent to browser
DEBUG - 2017-01-23 22:51:46 --> Total execution time: 0.0150
INFO - 2017-01-23 22:51:47 --> Config Class Initialized
INFO - 2017-01-23 22:51:47 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:51:47 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:51:47 --> Utf8 Class Initialized
INFO - 2017-01-23 22:51:47 --> URI Class Initialized
INFO - 2017-01-23 22:51:47 --> Router Class Initialized
INFO - 2017-01-23 22:51:47 --> Output Class Initialized
INFO - 2017-01-23 22:51:47 --> Security Class Initialized
DEBUG - 2017-01-23 22:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:51:47 --> Input Class Initialized
INFO - 2017-01-23 22:51:47 --> Language Class Initialized
INFO - 2017-01-23 22:51:47 --> Loader Class Initialized
INFO - 2017-01-23 22:51:47 --> Database Driver Class Initialized
INFO - 2017-01-23 22:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:51:47 --> Controller Class Initialized
INFO - 2017-01-23 22:51:47 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:51:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:51:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:51:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:51:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:51:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:51:47 --> Final output sent to browser
DEBUG - 2017-01-23 22:51:47 --> Total execution time: 0.0203
INFO - 2017-01-23 22:51:47 --> Config Class Initialized
INFO - 2017-01-23 22:51:47 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:51:47 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:51:47 --> Utf8 Class Initialized
INFO - 2017-01-23 22:51:47 --> URI Class Initialized
INFO - 2017-01-23 22:51:47 --> Router Class Initialized
INFO - 2017-01-23 22:51:47 --> Output Class Initialized
INFO - 2017-01-23 22:51:47 --> Security Class Initialized
DEBUG - 2017-01-23 22:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:51:47 --> Input Class Initialized
INFO - 2017-01-23 22:51:47 --> Language Class Initialized
INFO - 2017-01-23 22:51:47 --> Loader Class Initialized
INFO - 2017-01-23 22:51:47 --> Database Driver Class Initialized
INFO - 2017-01-23 22:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:51:47 --> Controller Class Initialized
INFO - 2017-01-23 22:51:47 --> Upload Class Initialized
INFO - 2017-01-23 22:51:47 --> Helper loaded: date_helper
DEBUG - 2017-01-23 22:51:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:51:47 --> Helper loaded: url_helper
INFO - 2017-01-23 22:51:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:51:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 22:51:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-01-23 22:51:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-01-23 22:51:47 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-23 22:51:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:51:47 --> Final output sent to browser
DEBUG - 2017-01-23 22:51:47 --> Total execution time: 0.0164
INFO - 2017-01-23 22:51:48 --> Config Class Initialized
INFO - 2017-01-23 22:51:48 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:51:48 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:51:48 --> Utf8 Class Initialized
INFO - 2017-01-23 22:51:48 --> URI Class Initialized
INFO - 2017-01-23 22:51:48 --> Router Class Initialized
INFO - 2017-01-23 22:51:48 --> Output Class Initialized
INFO - 2017-01-23 22:51:48 --> Security Class Initialized
DEBUG - 2017-01-23 22:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:51:48 --> Input Class Initialized
INFO - 2017-01-23 22:51:48 --> Language Class Initialized
INFO - 2017-01-23 22:51:48 --> Loader Class Initialized
INFO - 2017-01-23 22:51:48 --> Database Driver Class Initialized
INFO - 2017-01-23 22:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:51:48 --> Controller Class Initialized
INFO - 2017-01-23 22:51:48 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:51:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:51:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:51:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:51:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:51:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:51:48 --> Final output sent to browser
DEBUG - 2017-01-23 22:51:48 --> Total execution time: 0.0313
INFO - 2017-01-23 22:52:37 --> Config Class Initialized
INFO - 2017-01-23 22:52:37 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:52:37 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:52:37 --> Utf8 Class Initialized
INFO - 2017-01-23 22:52:37 --> URI Class Initialized
INFO - 2017-01-23 22:52:37 --> Router Class Initialized
INFO - 2017-01-23 22:52:37 --> Output Class Initialized
INFO - 2017-01-23 22:52:37 --> Security Class Initialized
DEBUG - 2017-01-23 22:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:52:37 --> Input Class Initialized
INFO - 2017-01-23 22:52:37 --> Language Class Initialized
INFO - 2017-01-23 22:52:37 --> Loader Class Initialized
INFO - 2017-01-23 22:52:37 --> Database Driver Class Initialized
INFO - 2017-01-23 22:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:52:37 --> Controller Class Initialized
INFO - 2017-01-23 22:52:37 --> Helper loaded: date_helper
DEBUG - 2017-01-23 22:52:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:52:37 --> Helper loaded: url_helper
INFO - 2017-01-23 22:52:37 --> Helper loaded: download_helper
INFO - 2017-01-23 22:52:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:52:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 22:52:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-23 22:52:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-23 22:52:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:52:37 --> Final output sent to browser
DEBUG - 2017-01-23 22:52:37 --> Total execution time: 0.0248
INFO - 2017-01-23 22:52:37 --> Config Class Initialized
INFO - 2017-01-23 22:52:37 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:52:37 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:52:37 --> Utf8 Class Initialized
INFO - 2017-01-23 22:52:37 --> URI Class Initialized
INFO - 2017-01-23 22:52:37 --> Router Class Initialized
INFO - 2017-01-23 22:52:37 --> Output Class Initialized
INFO - 2017-01-23 22:52:37 --> Security Class Initialized
DEBUG - 2017-01-23 22:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:52:37 --> Input Class Initialized
INFO - 2017-01-23 22:52:37 --> Language Class Initialized
INFO - 2017-01-23 22:52:37 --> Loader Class Initialized
INFO - 2017-01-23 22:52:37 --> Database Driver Class Initialized
INFO - 2017-01-23 22:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:52:37 --> Controller Class Initialized
INFO - 2017-01-23 22:52:37 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:52:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:52:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:52:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:52:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:52:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:52:37 --> Final output sent to browser
DEBUG - 2017-01-23 22:52:37 --> Total execution time: 0.0195
INFO - 2017-01-23 22:53:22 --> Config Class Initialized
INFO - 2017-01-23 22:53:22 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:53:22 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:53:22 --> Utf8 Class Initialized
INFO - 2017-01-23 22:53:22 --> URI Class Initialized
INFO - 2017-01-23 22:53:22 --> Router Class Initialized
INFO - 2017-01-23 22:53:22 --> Output Class Initialized
INFO - 2017-01-23 22:53:22 --> Security Class Initialized
DEBUG - 2017-01-23 22:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:53:22 --> Input Class Initialized
INFO - 2017-01-23 22:53:22 --> Language Class Initialized
INFO - 2017-01-23 22:53:22 --> Loader Class Initialized
INFO - 2017-01-23 22:53:22 --> Database Driver Class Initialized
INFO - 2017-01-23 22:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:53:22 --> Controller Class Initialized
INFO - 2017-01-23 22:53:22 --> Helper loaded: date_helper
DEBUG - 2017-01-23 22:53:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:53:22 --> Helper loaded: url_helper
INFO - 2017-01-23 22:53:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:53:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 22:53:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-23 22:53:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-23 22:53:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:53:22 --> Final output sent to browser
DEBUG - 2017-01-23 22:53:22 --> Total execution time: 0.0146
INFO - 2017-01-23 22:53:23 --> Config Class Initialized
INFO - 2017-01-23 22:53:23 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:53:23 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:53:23 --> Utf8 Class Initialized
INFO - 2017-01-23 22:53:23 --> URI Class Initialized
INFO - 2017-01-23 22:53:23 --> Router Class Initialized
INFO - 2017-01-23 22:53:23 --> Output Class Initialized
INFO - 2017-01-23 22:53:23 --> Security Class Initialized
DEBUG - 2017-01-23 22:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:53:23 --> Input Class Initialized
INFO - 2017-01-23 22:53:23 --> Language Class Initialized
INFO - 2017-01-23 22:53:23 --> Loader Class Initialized
INFO - 2017-01-23 22:53:23 --> Database Driver Class Initialized
INFO - 2017-01-23 22:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:53:23 --> Controller Class Initialized
INFO - 2017-01-23 22:53:23 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:53:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:53:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:53:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:53:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:53:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:53:23 --> Final output sent to browser
DEBUG - 2017-01-23 22:53:23 --> Total execution time: 0.0139
INFO - 2017-01-23 22:53:26 --> Config Class Initialized
INFO - 2017-01-23 22:53:26 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:53:26 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:53:26 --> Utf8 Class Initialized
INFO - 2017-01-23 22:53:26 --> URI Class Initialized
INFO - 2017-01-23 22:53:26 --> Router Class Initialized
INFO - 2017-01-23 22:53:26 --> Output Class Initialized
INFO - 2017-01-23 22:53:26 --> Security Class Initialized
DEBUG - 2017-01-23 22:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:53:26 --> Input Class Initialized
INFO - 2017-01-23 22:53:26 --> Language Class Initialized
INFO - 2017-01-23 22:53:26 --> Loader Class Initialized
INFO - 2017-01-23 22:53:26 --> Database Driver Class Initialized
INFO - 2017-01-23 22:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:53:26 --> Controller Class Initialized
INFO - 2017-01-23 22:53:26 --> Helper loaded: date_helper
DEBUG - 2017-01-23 22:53:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:53:26 --> Helper loaded: url_helper
INFO - 2017-01-23 22:53:26 --> Helper loaded: download_helper
INFO - 2017-01-23 22:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 22:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-23 22:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-23 22:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:53:26 --> Final output sent to browser
DEBUG - 2017-01-23 22:53:26 --> Total execution time: 0.0496
INFO - 2017-01-23 22:53:26 --> Config Class Initialized
INFO - 2017-01-23 22:53:26 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:53:26 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:53:26 --> Utf8 Class Initialized
INFO - 2017-01-23 22:53:26 --> URI Class Initialized
INFO - 2017-01-23 22:53:26 --> Router Class Initialized
INFO - 2017-01-23 22:53:26 --> Output Class Initialized
INFO - 2017-01-23 22:53:26 --> Security Class Initialized
DEBUG - 2017-01-23 22:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:53:26 --> Input Class Initialized
INFO - 2017-01-23 22:53:26 --> Language Class Initialized
INFO - 2017-01-23 22:53:26 --> Loader Class Initialized
INFO - 2017-01-23 22:53:26 --> Database Driver Class Initialized
INFO - 2017-01-23 22:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:53:26 --> Controller Class Initialized
INFO - 2017-01-23 22:53:26 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:53:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:53:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:53:26 --> Final output sent to browser
DEBUG - 2017-01-23 22:53:26 --> Total execution time: 0.0149
INFO - 2017-01-23 22:53:28 --> Config Class Initialized
INFO - 2017-01-23 22:53:28 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:53:28 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:53:28 --> Utf8 Class Initialized
INFO - 2017-01-23 22:53:28 --> URI Class Initialized
INFO - 2017-01-23 22:53:28 --> Router Class Initialized
INFO - 2017-01-23 22:53:28 --> Output Class Initialized
INFO - 2017-01-23 22:53:28 --> Security Class Initialized
DEBUG - 2017-01-23 22:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:53:28 --> Input Class Initialized
INFO - 2017-01-23 22:53:28 --> Language Class Initialized
INFO - 2017-01-23 22:53:28 --> Loader Class Initialized
INFO - 2017-01-23 22:53:28 --> Database Driver Class Initialized
INFO - 2017-01-23 22:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:53:28 --> Controller Class Initialized
INFO - 2017-01-23 22:53:28 --> Helper loaded: date_helper
DEBUG - 2017-01-23 22:53:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:53:28 --> Helper loaded: url_helper
INFO - 2017-01-23 22:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-23 22:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 22:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-23 22:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-23 22:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:53:28 --> Final output sent to browser
DEBUG - 2017-01-23 22:53:28 --> Total execution time: 0.0134
INFO - 2017-01-23 22:53:28 --> Config Class Initialized
INFO - 2017-01-23 22:53:28 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:53:28 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:53:28 --> Utf8 Class Initialized
INFO - 2017-01-23 22:53:28 --> URI Class Initialized
INFO - 2017-01-23 22:53:28 --> Router Class Initialized
INFO - 2017-01-23 22:53:28 --> Output Class Initialized
INFO - 2017-01-23 22:53:28 --> Security Class Initialized
DEBUG - 2017-01-23 22:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:53:28 --> Input Class Initialized
INFO - 2017-01-23 22:53:28 --> Language Class Initialized
INFO - 2017-01-23 22:53:28 --> Loader Class Initialized
INFO - 2017-01-23 22:53:28 --> Database Driver Class Initialized
INFO - 2017-01-23 22:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:53:28 --> Controller Class Initialized
INFO - 2017-01-23 22:53:28 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:53:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:53:28 --> Final output sent to browser
DEBUG - 2017-01-23 22:53:28 --> Total execution time: 0.0137
INFO - 2017-01-23 22:53:29 --> Config Class Initialized
INFO - 2017-01-23 22:53:29 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:53:29 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:53:29 --> Utf8 Class Initialized
INFO - 2017-01-23 22:53:29 --> URI Class Initialized
INFO - 2017-01-23 22:53:29 --> Router Class Initialized
INFO - 2017-01-23 22:53:29 --> Output Class Initialized
INFO - 2017-01-23 22:53:29 --> Security Class Initialized
DEBUG - 2017-01-23 22:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:53:29 --> Input Class Initialized
INFO - 2017-01-23 22:53:29 --> Language Class Initialized
INFO - 2017-01-23 22:53:29 --> Loader Class Initialized
INFO - 2017-01-23 22:53:29 --> Database Driver Class Initialized
INFO - 2017-01-23 22:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:53:29 --> Controller Class Initialized
INFO - 2017-01-23 22:53:29 --> Helper loaded: date_helper
DEBUG - 2017-01-23 22:53:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:53:29 --> Helper loaded: url_helper
INFO - 2017-01-23 22:53:29 --> Helper loaded: download_helper
INFO - 2017-01-23 22:53:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:53:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 22:53:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-23 22:53:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-23 22:53:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:53:29 --> Final output sent to browser
DEBUG - 2017-01-23 22:53:29 --> Total execution time: 0.0213
INFO - 2017-01-23 22:53:30 --> Config Class Initialized
INFO - 2017-01-23 22:53:30 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:53:30 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:53:30 --> Utf8 Class Initialized
INFO - 2017-01-23 22:53:30 --> URI Class Initialized
INFO - 2017-01-23 22:53:30 --> Router Class Initialized
INFO - 2017-01-23 22:53:30 --> Output Class Initialized
INFO - 2017-01-23 22:53:30 --> Security Class Initialized
DEBUG - 2017-01-23 22:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:53:30 --> Input Class Initialized
INFO - 2017-01-23 22:53:30 --> Language Class Initialized
INFO - 2017-01-23 22:53:30 --> Loader Class Initialized
INFO - 2017-01-23 22:53:30 --> Database Driver Class Initialized
INFO - 2017-01-23 22:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:53:30 --> Controller Class Initialized
INFO - 2017-01-23 22:53:30 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:53:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:53:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:53:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:53:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:53:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:53:30 --> Final output sent to browser
DEBUG - 2017-01-23 22:53:30 --> Total execution time: 0.0143
INFO - 2017-01-23 22:53:49 --> Config Class Initialized
INFO - 2017-01-23 22:53:49 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:53:49 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:53:49 --> Utf8 Class Initialized
INFO - 2017-01-23 22:53:49 --> URI Class Initialized
INFO - 2017-01-23 22:53:49 --> Router Class Initialized
INFO - 2017-01-23 22:53:49 --> Output Class Initialized
INFO - 2017-01-23 22:53:49 --> Security Class Initialized
DEBUG - 2017-01-23 22:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:53:49 --> Input Class Initialized
INFO - 2017-01-23 22:53:49 --> Language Class Initialized
INFO - 2017-01-23 22:53:49 --> Loader Class Initialized
INFO - 2017-01-23 22:53:49 --> Database Driver Class Initialized
INFO - 2017-01-23 22:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:53:49 --> Controller Class Initialized
INFO - 2017-01-23 22:53:49 --> Helper loaded: date_helper
DEBUG - 2017-01-23 22:53:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:53:49 --> Helper loaded: url_helper
INFO - 2017-01-23 22:53:49 --> Helper loaded: download_helper
INFO - 2017-01-23 22:53:49 --> Final output sent to browser
DEBUG - 2017-01-23 22:53:49 --> Total execution time: 0.0165
INFO - 2017-01-23 22:53:52 --> Config Class Initialized
INFO - 2017-01-23 22:53:52 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:53:52 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:53:52 --> Utf8 Class Initialized
INFO - 2017-01-23 22:53:52 --> URI Class Initialized
INFO - 2017-01-23 22:53:52 --> Router Class Initialized
INFO - 2017-01-23 22:53:52 --> Output Class Initialized
INFO - 2017-01-23 22:53:52 --> Security Class Initialized
DEBUG - 2017-01-23 22:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:53:52 --> Input Class Initialized
INFO - 2017-01-23 22:53:52 --> Language Class Initialized
INFO - 2017-01-23 22:53:52 --> Loader Class Initialized
INFO - 2017-01-23 22:53:52 --> Database Driver Class Initialized
INFO - 2017-01-23 22:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:53:52 --> Controller Class Initialized
INFO - 2017-01-23 22:53:52 --> Helper loaded: date_helper
DEBUG - 2017-01-23 22:53:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:53:52 --> Helper loaded: url_helper
INFO - 2017-01-23 22:53:52 --> Helper loaded: download_helper
INFO - 2017-01-23 22:53:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:53:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 22:53:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-23 22:53:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-23 22:53:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:53:52 --> Final output sent to browser
DEBUG - 2017-01-23 22:53:52 --> Total execution time: 0.0194
INFO - 2017-01-23 22:54:17 --> Config Class Initialized
INFO - 2017-01-23 22:54:17 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:54:17 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:54:17 --> Utf8 Class Initialized
INFO - 2017-01-23 22:54:17 --> URI Class Initialized
INFO - 2017-01-23 22:54:17 --> Router Class Initialized
INFO - 2017-01-23 22:54:17 --> Output Class Initialized
INFO - 2017-01-23 22:54:17 --> Security Class Initialized
DEBUG - 2017-01-23 22:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:54:17 --> Input Class Initialized
INFO - 2017-01-23 22:54:17 --> Language Class Initialized
INFO - 2017-01-23 22:54:17 --> Loader Class Initialized
INFO - 2017-01-23 22:54:17 --> Database Driver Class Initialized
INFO - 2017-01-23 22:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:54:17 --> Controller Class Initialized
INFO - 2017-01-23 22:54:17 --> Helper loaded: date_helper
DEBUG - 2017-01-23 22:54:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:54:17 --> Helper loaded: url_helper
INFO - 2017-01-23 22:54:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:54:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-01-23 22:54:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 22:54:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-01-23 22:54:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-01-23 22:54:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:54:17 --> Final output sent to browser
DEBUG - 2017-01-23 22:54:17 --> Total execution time: 0.0139
INFO - 2017-01-23 22:54:18 --> Config Class Initialized
INFO - 2017-01-23 22:54:18 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:54:18 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:54:18 --> Utf8 Class Initialized
INFO - 2017-01-23 22:54:18 --> URI Class Initialized
INFO - 2017-01-23 22:54:18 --> Router Class Initialized
INFO - 2017-01-23 22:54:18 --> Output Class Initialized
INFO - 2017-01-23 22:54:18 --> Security Class Initialized
DEBUG - 2017-01-23 22:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:54:18 --> Input Class Initialized
INFO - 2017-01-23 22:54:18 --> Language Class Initialized
INFO - 2017-01-23 22:54:18 --> Loader Class Initialized
INFO - 2017-01-23 22:54:18 --> Database Driver Class Initialized
INFO - 2017-01-23 22:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:54:18 --> Controller Class Initialized
INFO - 2017-01-23 22:54:18 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:54:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:54:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:54:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:54:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:54:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:54:18 --> Final output sent to browser
DEBUG - 2017-01-23 22:54:18 --> Total execution time: 0.0138
INFO - 2017-01-23 22:54:19 --> Config Class Initialized
INFO - 2017-01-23 22:54:19 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:54:19 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:54:19 --> Utf8 Class Initialized
INFO - 2017-01-23 22:54:19 --> URI Class Initialized
INFO - 2017-01-23 22:54:19 --> Router Class Initialized
INFO - 2017-01-23 22:54:19 --> Output Class Initialized
INFO - 2017-01-23 22:54:19 --> Security Class Initialized
DEBUG - 2017-01-23 22:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:54:19 --> Input Class Initialized
INFO - 2017-01-23 22:54:19 --> Language Class Initialized
INFO - 2017-01-23 22:54:19 --> Loader Class Initialized
INFO - 2017-01-23 22:54:19 --> Database Driver Class Initialized
INFO - 2017-01-23 22:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:54:19 --> Controller Class Initialized
INFO - 2017-01-23 22:54:19 --> Upload Class Initialized
INFO - 2017-01-23 22:54:19 --> Helper loaded: date_helper
DEBUG - 2017-01-23 22:54:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:54:19 --> Helper loaded: url_helper
INFO - 2017-01-23 22:54:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:54:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 22:54:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-01-23 22:54:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-01-23 22:54:19 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-23 22:54:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:54:19 --> Final output sent to browser
DEBUG - 2017-01-23 22:54:19 --> Total execution time: 0.0657
INFO - 2017-01-23 22:54:19 --> Config Class Initialized
INFO - 2017-01-23 22:54:19 --> Hooks Class Initialized
DEBUG - 2017-01-23 22:54:19 --> UTF-8 Support Enabled
INFO - 2017-01-23 22:54:19 --> Utf8 Class Initialized
INFO - 2017-01-23 22:54:19 --> URI Class Initialized
INFO - 2017-01-23 22:54:19 --> Router Class Initialized
INFO - 2017-01-23 22:54:19 --> Output Class Initialized
INFO - 2017-01-23 22:54:19 --> Security Class Initialized
DEBUG - 2017-01-23 22:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 22:54:19 --> Input Class Initialized
INFO - 2017-01-23 22:54:19 --> Language Class Initialized
INFO - 2017-01-23 22:54:19 --> Loader Class Initialized
INFO - 2017-01-23 22:54:19 --> Database Driver Class Initialized
INFO - 2017-01-23 22:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 22:54:19 --> Controller Class Initialized
INFO - 2017-01-23 22:54:19 --> Helper loaded: url_helper
DEBUG - 2017-01-23 22:54:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 22:54:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 22:54:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 22:54:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 22:54:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 22:54:19 --> Final output sent to browser
DEBUG - 2017-01-23 22:54:19 --> Total execution time: 0.0140
INFO - 2017-01-23 23:05:17 --> Config Class Initialized
INFO - 2017-01-23 23:05:17 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:05:17 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:05:17 --> Utf8 Class Initialized
INFO - 2017-01-23 23:05:17 --> URI Class Initialized
INFO - 2017-01-23 23:05:17 --> Router Class Initialized
INFO - 2017-01-23 23:05:17 --> Output Class Initialized
INFO - 2017-01-23 23:05:17 --> Security Class Initialized
DEBUG - 2017-01-23 23:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:05:17 --> Input Class Initialized
INFO - 2017-01-23 23:05:17 --> Language Class Initialized
INFO - 2017-01-23 23:05:17 --> Loader Class Initialized
INFO - 2017-01-23 23:05:17 --> Database Driver Class Initialized
INFO - 2017-01-23 23:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:05:17 --> Controller Class Initialized
INFO - 2017-01-23 23:05:17 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:05:17 --> Helper loaded: form_helper
INFO - 2017-01-23 23:05:17 --> Form Validation Class Initialized
INFO - 2017-01-23 23:05:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 23:05:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-23 23:05:17 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 23:05:17 --> Final output sent to browser
DEBUG - 2017-01-23 23:05:17 --> Total execution time: 0.0146
INFO - 2017-01-23 23:05:17 --> Config Class Initialized
INFO - 2017-01-23 23:05:17 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:05:17 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:05:17 --> Utf8 Class Initialized
INFO - 2017-01-23 23:05:17 --> URI Class Initialized
INFO - 2017-01-23 23:05:17 --> Router Class Initialized
INFO - 2017-01-23 23:05:17 --> Output Class Initialized
INFO - 2017-01-23 23:05:17 --> Security Class Initialized
DEBUG - 2017-01-23 23:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:05:17 --> Input Class Initialized
INFO - 2017-01-23 23:05:17 --> Language Class Initialized
INFO - 2017-01-23 23:05:17 --> Loader Class Initialized
INFO - 2017-01-23 23:05:17 --> Database Driver Class Initialized
INFO - 2017-01-23 23:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:05:17 --> Controller Class Initialized
INFO - 2017-01-23 23:05:17 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 23:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 23:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 23:05:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 23:05:17 --> Final output sent to browser
DEBUG - 2017-01-23 23:05:17 --> Total execution time: 0.0152
INFO - 2017-01-23 23:05:28 --> Config Class Initialized
INFO - 2017-01-23 23:05:28 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:05:28 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:05:28 --> Utf8 Class Initialized
INFO - 2017-01-23 23:05:28 --> URI Class Initialized
INFO - 2017-01-23 23:05:28 --> Router Class Initialized
INFO - 2017-01-23 23:05:28 --> Output Class Initialized
INFO - 2017-01-23 23:05:28 --> Security Class Initialized
DEBUG - 2017-01-23 23:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:05:28 --> Input Class Initialized
INFO - 2017-01-23 23:05:28 --> Language Class Initialized
INFO - 2017-01-23 23:05:28 --> Loader Class Initialized
INFO - 2017-01-23 23:05:28 --> Database Driver Class Initialized
INFO - 2017-01-23 23:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:05:28 --> Controller Class Initialized
INFO - 2017-01-23 23:05:28 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:05:28 --> Helper loaded: form_helper
INFO - 2017-01-23 23:05:28 --> Form Validation Class Initialized
INFO - 2017-01-23 23:05:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-23 23:05:28 --> Config Class Initialized
INFO - 2017-01-23 23:05:28 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:05:28 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:05:28 --> Utf8 Class Initialized
INFO - 2017-01-23 23:05:28 --> URI Class Initialized
INFO - 2017-01-23 23:05:28 --> Router Class Initialized
INFO - 2017-01-23 23:05:28 --> Output Class Initialized
INFO - 2017-01-23 23:05:28 --> Security Class Initialized
DEBUG - 2017-01-23 23:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:05:28 --> Input Class Initialized
INFO - 2017-01-23 23:05:28 --> Language Class Initialized
INFO - 2017-01-23 23:05:28 --> Loader Class Initialized
INFO - 2017-01-23 23:05:28 --> Database Driver Class Initialized
INFO - 2017-01-23 23:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:05:28 --> Controller Class Initialized
INFO - 2017-01-23 23:05:28 --> Helper loaded: date_helper
INFO - 2017-01-23 23:05:28 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:05:28 --> Helper loaded: form_helper
INFO - 2017-01-23 23:05:28 --> Form Validation Class Initialized
INFO - 2017-01-23 23:05:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 23:05:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 23:05:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-23 23:05:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-23 23:05:28 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 23:05:28 --> Final output sent to browser
DEBUG - 2017-01-23 23:05:28 --> Total execution time: 0.0511
INFO - 2017-01-23 23:05:28 --> Config Class Initialized
INFO - 2017-01-23 23:05:28 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:05:28 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:05:28 --> Utf8 Class Initialized
INFO - 2017-01-23 23:05:28 --> URI Class Initialized
INFO - 2017-01-23 23:05:28 --> Router Class Initialized
INFO - 2017-01-23 23:05:28 --> Output Class Initialized
INFO - 2017-01-23 23:05:28 --> Security Class Initialized
DEBUG - 2017-01-23 23:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:05:28 --> Input Class Initialized
INFO - 2017-01-23 23:05:28 --> Language Class Initialized
INFO - 2017-01-23 23:05:28 --> Loader Class Initialized
INFO - 2017-01-23 23:05:28 --> Database Driver Class Initialized
INFO - 2017-01-23 23:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:05:28 --> Controller Class Initialized
INFO - 2017-01-23 23:05:28 --> Helper loaded: date_helper
INFO - 2017-01-23 23:05:28 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:05:28 --> Helper loaded: form_helper
INFO - 2017-01-23 23:05:28 --> Form Validation Class Initialized
INFO - 2017-01-23 23:05:28 --> Final output sent to browser
DEBUG - 2017-01-23 23:05:28 --> Total execution time: 0.0334
INFO - 2017-01-23 23:05:29 --> Config Class Initialized
INFO - 2017-01-23 23:05:29 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:05:29 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:05:29 --> Utf8 Class Initialized
INFO - 2017-01-23 23:05:29 --> URI Class Initialized
INFO - 2017-01-23 23:05:29 --> Router Class Initialized
INFO - 2017-01-23 23:05:29 --> Output Class Initialized
INFO - 2017-01-23 23:05:29 --> Security Class Initialized
DEBUG - 2017-01-23 23:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:05:29 --> Input Class Initialized
INFO - 2017-01-23 23:05:29 --> Language Class Initialized
INFO - 2017-01-23 23:05:29 --> Loader Class Initialized
INFO - 2017-01-23 23:05:29 --> Database Driver Class Initialized
INFO - 2017-01-23 23:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:05:29 --> Controller Class Initialized
INFO - 2017-01-23 23:05:29 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:05:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:05:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 23:05:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 23:05:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 23:05:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 23:05:29 --> Final output sent to browser
DEBUG - 2017-01-23 23:05:29 --> Total execution time: 0.0246
INFO - 2017-01-23 23:05:31 --> Config Class Initialized
INFO - 2017-01-23 23:05:31 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:05:31 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:05:31 --> Utf8 Class Initialized
INFO - 2017-01-23 23:05:31 --> URI Class Initialized
INFO - 2017-01-23 23:05:31 --> Router Class Initialized
INFO - 2017-01-23 23:05:31 --> Output Class Initialized
INFO - 2017-01-23 23:05:31 --> Security Class Initialized
DEBUG - 2017-01-23 23:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:05:31 --> Input Class Initialized
INFO - 2017-01-23 23:05:31 --> Language Class Initialized
INFO - 2017-01-23 23:05:31 --> Loader Class Initialized
INFO - 2017-01-23 23:05:31 --> Database Driver Class Initialized
INFO - 2017-01-23 23:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:05:31 --> Controller Class Initialized
INFO - 2017-01-23 23:05:31 --> Helper loaded: date_helper
INFO - 2017-01-23 23:05:31 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:05:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:05:31 --> Helper loaded: form_helper
INFO - 2017-01-23 23:05:31 --> Form Validation Class Initialized
INFO - 2017-01-23 23:05:31 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 23:05:31 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 23:05:31 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-23 23:05:31 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-23 23:05:31 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 23:05:31 --> Final output sent to browser
DEBUG - 2017-01-23 23:05:31 --> Total execution time: 0.0163
INFO - 2017-01-23 23:05:31 --> Config Class Initialized
INFO - 2017-01-23 23:05:31 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:05:31 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:05:31 --> Utf8 Class Initialized
INFO - 2017-01-23 23:05:31 --> URI Class Initialized
INFO - 2017-01-23 23:05:31 --> Router Class Initialized
INFO - 2017-01-23 23:05:31 --> Output Class Initialized
INFO - 2017-01-23 23:05:31 --> Security Class Initialized
DEBUG - 2017-01-23 23:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:05:31 --> Input Class Initialized
INFO - 2017-01-23 23:05:31 --> Language Class Initialized
INFO - 2017-01-23 23:05:31 --> Loader Class Initialized
INFO - 2017-01-23 23:05:31 --> Database Driver Class Initialized
INFO - 2017-01-23 23:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:05:31 --> Controller Class Initialized
INFO - 2017-01-23 23:05:31 --> Helper loaded: date_helper
INFO - 2017-01-23 23:05:31 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:05:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:05:31 --> Helper loaded: form_helper
INFO - 2017-01-23 23:05:31 --> Form Validation Class Initialized
INFO - 2017-01-23 23:05:31 --> Final output sent to browser
DEBUG - 2017-01-23 23:05:31 --> Total execution time: 0.0155
INFO - 2017-01-23 23:05:31 --> Config Class Initialized
INFO - 2017-01-23 23:05:31 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:05:31 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:05:31 --> Utf8 Class Initialized
INFO - 2017-01-23 23:05:31 --> URI Class Initialized
INFO - 2017-01-23 23:05:31 --> Router Class Initialized
INFO - 2017-01-23 23:05:31 --> Output Class Initialized
INFO - 2017-01-23 23:05:31 --> Security Class Initialized
DEBUG - 2017-01-23 23:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:05:31 --> Input Class Initialized
INFO - 2017-01-23 23:05:31 --> Language Class Initialized
INFO - 2017-01-23 23:05:31 --> Loader Class Initialized
INFO - 2017-01-23 23:05:31 --> Database Driver Class Initialized
INFO - 2017-01-23 23:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:05:31 --> Controller Class Initialized
INFO - 2017-01-23 23:05:31 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:05:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:05:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 23:05:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 23:05:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 23:05:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 23:05:31 --> Final output sent to browser
DEBUG - 2017-01-23 23:05:31 --> Total execution time: 0.0197
INFO - 2017-01-23 23:05:34 --> Config Class Initialized
INFO - 2017-01-23 23:05:34 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:05:34 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:05:34 --> Utf8 Class Initialized
INFO - 2017-01-23 23:05:34 --> Config Class Initialized
INFO - 2017-01-23 23:05:34 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:05:34 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:05:34 --> Utf8 Class Initialized
INFO - 2017-01-23 23:05:34 --> URI Class Initialized
INFO - 2017-01-23 23:05:34 --> Router Class Initialized
INFO - 2017-01-23 23:05:34 --> Output Class Initialized
INFO - 2017-01-23 23:05:34 --> Security Class Initialized
DEBUG - 2017-01-23 23:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:05:34 --> Input Class Initialized
INFO - 2017-01-23 23:05:34 --> Language Class Initialized
INFO - 2017-01-23 23:05:34 --> Loader Class Initialized
INFO - 2017-01-23 23:05:34 --> Database Driver Class Initialized
INFO - 2017-01-23 23:05:34 --> URI Class Initialized
INFO - 2017-01-23 23:05:34 --> Router Class Initialized
INFO - 2017-01-23 23:05:34 --> Output Class Initialized
INFO - 2017-01-23 23:05:34 --> Security Class Initialized
DEBUG - 2017-01-23 23:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:05:34 --> Input Class Initialized
INFO - 2017-01-23 23:05:34 --> Language Class Initialized
INFO - 2017-01-23 23:05:34 --> Loader Class Initialized
INFO - 2017-01-23 23:05:34 --> Database Driver Class Initialized
INFO - 2017-01-23 23:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:05:34 --> Controller Class Initialized
INFO - 2017-01-23 23:05:34 --> Helper loaded: date_helper
INFO - 2017-01-23 23:05:34 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:05:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:05:34 --> Helper loaded: form_helper
INFO - 2017-01-23 23:05:34 --> Form Validation Class Initialized
INFO - 2017-01-23 23:05:34 --> Final output sent to browser
DEBUG - 2017-01-23 23:05:34 --> Total execution time: 0.0892
INFO - 2017-01-23 23:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:05:34 --> Controller Class Initialized
INFO - 2017-01-23 23:05:34 --> Helper loaded: date_helper
INFO - 2017-01-23 23:05:34 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:05:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:05:34 --> Helper loaded: form_helper
INFO - 2017-01-23 23:05:34 --> Form Validation Class Initialized
INFO - 2017-01-23 23:05:34 --> Final output sent to browser
DEBUG - 2017-01-23 23:05:34 --> Total execution time: 0.0968
INFO - 2017-01-23 23:06:22 --> Config Class Initialized
INFO - 2017-01-23 23:06:22 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:06:22 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:06:22 --> Utf8 Class Initialized
INFO - 2017-01-23 23:06:22 --> URI Class Initialized
INFO - 2017-01-23 23:06:22 --> Router Class Initialized
INFO - 2017-01-23 23:06:22 --> Output Class Initialized
INFO - 2017-01-23 23:06:22 --> Security Class Initialized
DEBUG - 2017-01-23 23:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:06:22 --> Input Class Initialized
INFO - 2017-01-23 23:06:22 --> Language Class Initialized
INFO - 2017-01-23 23:06:22 --> Loader Class Initialized
INFO - 2017-01-23 23:06:22 --> Database Driver Class Initialized
INFO - 2017-01-23 23:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:06:22 --> Controller Class Initialized
INFO - 2017-01-23 23:06:22 --> Upload Class Initialized
INFO - 2017-01-23 23:06:22 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:06:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:06:22 --> Helper loaded: form_helper
INFO - 2017-01-23 23:06:22 --> Form Validation Class Initialized
INFO - 2017-01-23 23:06:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 23:06:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 23:06:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-23 23:06:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-23 23:06:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-23 23:06:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 23:06:22 --> Final output sent to browser
DEBUG - 2017-01-23 23:06:22 --> Total execution time: 0.0641
INFO - 2017-01-23 23:06:23 --> Config Class Initialized
INFO - 2017-01-23 23:06:23 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:06:23 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:06:23 --> Utf8 Class Initialized
INFO - 2017-01-23 23:06:23 --> URI Class Initialized
INFO - 2017-01-23 23:06:23 --> Router Class Initialized
INFO - 2017-01-23 23:06:23 --> Output Class Initialized
INFO - 2017-01-23 23:06:23 --> Security Class Initialized
DEBUG - 2017-01-23 23:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:06:23 --> Input Class Initialized
INFO - 2017-01-23 23:06:23 --> Language Class Initialized
INFO - 2017-01-23 23:06:23 --> Loader Class Initialized
INFO - 2017-01-23 23:06:23 --> Database Driver Class Initialized
INFO - 2017-01-23 23:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:06:23 --> Controller Class Initialized
INFO - 2017-01-23 23:06:23 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:06:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:06:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 23:06:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 23:06:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 23:06:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 23:06:23 --> Final output sent to browser
DEBUG - 2017-01-23 23:06:23 --> Total execution time: 0.0132
INFO - 2017-01-23 23:06:36 --> Config Class Initialized
INFO - 2017-01-23 23:06:36 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:06:36 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:06:36 --> Utf8 Class Initialized
INFO - 2017-01-23 23:06:36 --> URI Class Initialized
INFO - 2017-01-23 23:06:36 --> Router Class Initialized
INFO - 2017-01-23 23:06:36 --> Output Class Initialized
INFO - 2017-01-23 23:06:36 --> Security Class Initialized
DEBUG - 2017-01-23 23:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:06:36 --> Input Class Initialized
INFO - 2017-01-23 23:06:36 --> Language Class Initialized
INFO - 2017-01-23 23:06:36 --> Loader Class Initialized
INFO - 2017-01-23 23:06:36 --> Database Driver Class Initialized
INFO - 2017-01-23 23:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:06:36 --> Controller Class Initialized
INFO - 2017-01-23 23:06:36 --> Upload Class Initialized
INFO - 2017-01-23 23:06:36 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:06:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:06:36 --> Helper loaded: form_helper
INFO - 2017-01-23 23:06:36 --> Form Validation Class Initialized
INFO - 2017-01-23 23:06:36 --> Final output sent to browser
DEBUG - 2017-01-23 23:06:36 --> Total execution time: 0.0330
INFO - 2017-01-23 23:06:49 --> Config Class Initialized
INFO - 2017-01-23 23:06:49 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:06:49 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:06:49 --> Utf8 Class Initialized
INFO - 2017-01-23 23:06:49 --> URI Class Initialized
INFO - 2017-01-23 23:06:49 --> Router Class Initialized
INFO - 2017-01-23 23:06:49 --> Output Class Initialized
INFO - 2017-01-23 23:06:49 --> Security Class Initialized
DEBUG - 2017-01-23 23:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:06:49 --> Input Class Initialized
INFO - 2017-01-23 23:06:49 --> Language Class Initialized
INFO - 2017-01-23 23:06:49 --> Loader Class Initialized
INFO - 2017-01-23 23:06:49 --> Database Driver Class Initialized
INFO - 2017-01-23 23:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:06:49 --> Controller Class Initialized
INFO - 2017-01-23 23:06:49 --> Upload Class Initialized
INFO - 2017-01-23 23:06:49 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:06:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:06:49 --> Helper loaded: form_helper
INFO - 2017-01-23 23:06:49 --> Form Validation Class Initialized
INFO - 2017-01-23 23:06:49 --> Final output sent to browser
DEBUG - 2017-01-23 23:06:49 --> Total execution time: 0.0153
INFO - 2017-01-23 23:07:13 --> Config Class Initialized
INFO - 2017-01-23 23:07:13 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:07:13 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:07:13 --> Utf8 Class Initialized
INFO - 2017-01-23 23:07:13 --> URI Class Initialized
INFO - 2017-01-23 23:07:13 --> Router Class Initialized
INFO - 2017-01-23 23:07:13 --> Output Class Initialized
INFO - 2017-01-23 23:07:13 --> Security Class Initialized
DEBUG - 2017-01-23 23:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:07:13 --> Input Class Initialized
INFO - 2017-01-23 23:07:13 --> Language Class Initialized
INFO - 2017-01-23 23:07:13 --> Loader Class Initialized
INFO - 2017-01-23 23:07:13 --> Database Driver Class Initialized
INFO - 2017-01-23 23:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:07:13 --> Controller Class Initialized
INFO - 2017-01-23 23:07:13 --> Upload Class Initialized
INFO - 2017-01-23 23:07:13 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:07:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:07:13 --> Helper loaded: form_helper
INFO - 2017-01-23 23:07:13 --> Form Validation Class Initialized
INFO - 2017-01-23 23:07:13 --> Final output sent to browser
DEBUG - 2017-01-23 23:07:13 --> Total execution time: 0.0156
INFO - 2017-01-23 23:11:26 --> Config Class Initialized
INFO - 2017-01-23 23:11:26 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:11:26 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:11:26 --> Utf8 Class Initialized
INFO - 2017-01-23 23:11:26 --> URI Class Initialized
INFO - 2017-01-23 23:11:26 --> Router Class Initialized
INFO - 2017-01-23 23:11:26 --> Output Class Initialized
INFO - 2017-01-23 23:11:26 --> Security Class Initialized
DEBUG - 2017-01-23 23:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:11:26 --> Input Class Initialized
INFO - 2017-01-23 23:11:26 --> Language Class Initialized
INFO - 2017-01-23 23:11:26 --> Loader Class Initialized
INFO - 2017-01-23 23:11:26 --> Database Driver Class Initialized
INFO - 2017-01-23 23:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:11:26 --> Controller Class Initialized
INFO - 2017-01-23 23:11:26 --> Upload Class Initialized
INFO - 2017-01-23 23:11:26 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:11:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:11:26 --> Helper loaded: form_helper
INFO - 2017-01-23 23:11:26 --> Form Validation Class Initialized
INFO - 2017-01-23 23:11:33 --> Final output sent to browser
DEBUG - 2017-01-23 23:11:33 --> Total execution time: 6.2143
INFO - 2017-01-23 23:11:33 --> Config Class Initialized
INFO - 2017-01-23 23:11:33 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:11:33 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:11:33 --> Utf8 Class Initialized
INFO - 2017-01-23 23:11:33 --> URI Class Initialized
INFO - 2017-01-23 23:11:33 --> Router Class Initialized
INFO - 2017-01-23 23:11:33 --> Output Class Initialized
INFO - 2017-01-23 23:11:33 --> Security Class Initialized
DEBUG - 2017-01-23 23:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:11:33 --> Input Class Initialized
INFO - 2017-01-23 23:11:33 --> Language Class Initialized
INFO - 2017-01-23 23:11:33 --> Loader Class Initialized
INFO - 2017-01-23 23:11:33 --> Database Driver Class Initialized
INFO - 2017-01-23 23:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:11:33 --> Controller Class Initialized
INFO - 2017-01-23 23:11:33 --> Upload Class Initialized
INFO - 2017-01-23 23:11:33 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:11:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:11:33 --> Helper loaded: form_helper
INFO - 2017-01-23 23:11:33 --> Form Validation Class Initialized
INFO - 2017-01-23 23:11:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-23 23:11:33 --> Final output sent to browser
DEBUG - 2017-01-23 23:11:33 --> Total execution time: 0.0171
INFO - 2017-01-23 23:11:40 --> Config Class Initialized
INFO - 2017-01-23 23:11:40 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:11:40 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:11:40 --> Utf8 Class Initialized
INFO - 2017-01-23 23:11:40 --> URI Class Initialized
INFO - 2017-01-23 23:11:40 --> Router Class Initialized
INFO - 2017-01-23 23:11:40 --> Output Class Initialized
INFO - 2017-01-23 23:11:40 --> Security Class Initialized
DEBUG - 2017-01-23 23:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:11:40 --> Input Class Initialized
INFO - 2017-01-23 23:11:40 --> Language Class Initialized
INFO - 2017-01-23 23:11:40 --> Loader Class Initialized
INFO - 2017-01-23 23:11:40 --> Database Driver Class Initialized
INFO - 2017-01-23 23:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:11:40 --> Controller Class Initialized
INFO - 2017-01-23 23:11:40 --> Upload Class Initialized
INFO - 2017-01-23 23:11:40 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:11:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:11:40 --> Helper loaded: form_helper
INFO - 2017-01-23 23:11:40 --> Form Validation Class Initialized
INFO - 2017-01-23 23:11:40 --> Final output sent to browser
DEBUG - 2017-01-23 23:11:40 --> Total execution time: 0.0328
INFO - 2017-01-23 23:12:07 --> Config Class Initialized
INFO - 2017-01-23 23:12:07 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:12:07 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:12:07 --> Utf8 Class Initialized
INFO - 2017-01-23 23:12:07 --> URI Class Initialized
INFO - 2017-01-23 23:12:07 --> Router Class Initialized
INFO - 2017-01-23 23:12:07 --> Output Class Initialized
INFO - 2017-01-23 23:12:07 --> Security Class Initialized
DEBUG - 2017-01-23 23:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:12:07 --> Input Class Initialized
INFO - 2017-01-23 23:12:07 --> Language Class Initialized
INFO - 2017-01-23 23:12:07 --> Loader Class Initialized
INFO - 2017-01-23 23:12:07 --> Database Driver Class Initialized
INFO - 2017-01-23 23:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:12:07 --> Controller Class Initialized
INFO - 2017-01-23 23:12:07 --> Upload Class Initialized
INFO - 2017-01-23 23:12:07 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:12:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:12:07 --> Helper loaded: form_helper
INFO - 2017-01-23 23:12:07 --> Form Validation Class Initialized
INFO - 2017-01-23 23:12:07 --> Final output sent to browser
DEBUG - 2017-01-23 23:12:07 --> Total execution time: 0.0399
INFO - 2017-01-23 23:12:13 --> Config Class Initialized
INFO - 2017-01-23 23:12:13 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:12:13 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:12:13 --> Utf8 Class Initialized
INFO - 2017-01-23 23:12:13 --> URI Class Initialized
INFO - 2017-01-23 23:12:13 --> Router Class Initialized
INFO - 2017-01-23 23:12:13 --> Output Class Initialized
INFO - 2017-01-23 23:12:13 --> Security Class Initialized
DEBUG - 2017-01-23 23:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:12:13 --> Input Class Initialized
INFO - 2017-01-23 23:12:13 --> Language Class Initialized
INFO - 2017-01-23 23:12:13 --> Loader Class Initialized
INFO - 2017-01-23 23:12:13 --> Database Driver Class Initialized
INFO - 2017-01-23 23:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:12:13 --> Controller Class Initialized
INFO - 2017-01-23 23:12:13 --> Upload Class Initialized
INFO - 2017-01-23 23:12:13 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:12:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:12:13 --> Helper loaded: form_helper
INFO - 2017-01-23 23:12:13 --> Form Validation Class Initialized
INFO - 2017-01-23 23:12:13 --> Final output sent to browser
DEBUG - 2017-01-23 23:12:13 --> Total execution time: 0.0157
INFO - 2017-01-23 23:12:14 --> Config Class Initialized
INFO - 2017-01-23 23:12:14 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:12:14 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:12:14 --> Utf8 Class Initialized
INFO - 2017-01-23 23:12:14 --> URI Class Initialized
INFO - 2017-01-23 23:12:14 --> Router Class Initialized
INFO - 2017-01-23 23:12:14 --> Output Class Initialized
INFO - 2017-01-23 23:12:14 --> Security Class Initialized
DEBUG - 2017-01-23 23:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:12:14 --> Input Class Initialized
INFO - 2017-01-23 23:12:14 --> Language Class Initialized
INFO - 2017-01-23 23:12:14 --> Loader Class Initialized
INFO - 2017-01-23 23:12:14 --> Database Driver Class Initialized
INFO - 2017-01-23 23:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:12:14 --> Controller Class Initialized
INFO - 2017-01-23 23:12:14 --> Upload Class Initialized
INFO - 2017-01-23 23:12:14 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:12:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:12:14 --> Helper loaded: form_helper
INFO - 2017-01-23 23:12:14 --> Form Validation Class Initialized
INFO - 2017-01-23 23:12:14 --> Final output sent to browser
DEBUG - 2017-01-23 23:12:14 --> Total execution time: 0.0158
INFO - 2017-01-23 23:12:23 --> Config Class Initialized
INFO - 2017-01-23 23:12:23 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:12:23 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:12:23 --> Utf8 Class Initialized
INFO - 2017-01-23 23:12:23 --> URI Class Initialized
INFO - 2017-01-23 23:12:23 --> Router Class Initialized
INFO - 2017-01-23 23:12:23 --> Output Class Initialized
INFO - 2017-01-23 23:12:23 --> Security Class Initialized
DEBUG - 2017-01-23 23:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:12:23 --> Input Class Initialized
INFO - 2017-01-23 23:12:23 --> Language Class Initialized
INFO - 2017-01-23 23:12:23 --> Loader Class Initialized
INFO - 2017-01-23 23:12:23 --> Database Driver Class Initialized
INFO - 2017-01-23 23:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:12:23 --> Controller Class Initialized
INFO - 2017-01-23 23:12:23 --> Upload Class Initialized
INFO - 2017-01-23 23:12:23 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:12:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:12:23 --> Helper loaded: form_helper
INFO - 2017-01-23 23:12:23 --> Form Validation Class Initialized
INFO - 2017-01-23 23:12:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-23 23:12:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-23 23:12:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-23 23:12:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-23 23:12:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-23 23:12:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-23 23:12:23 --> Final output sent to browser
DEBUG - 2017-01-23 23:12:23 --> Total execution time: 0.0179
INFO - 2017-01-23 23:12:24 --> Config Class Initialized
INFO - 2017-01-23 23:12:24 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:12:24 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:12:24 --> Utf8 Class Initialized
INFO - 2017-01-23 23:12:24 --> URI Class Initialized
INFO - 2017-01-23 23:12:24 --> Router Class Initialized
INFO - 2017-01-23 23:12:24 --> Output Class Initialized
INFO - 2017-01-23 23:12:24 --> Security Class Initialized
DEBUG - 2017-01-23 23:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:12:24 --> Input Class Initialized
INFO - 2017-01-23 23:12:24 --> Language Class Initialized
INFO - 2017-01-23 23:12:24 --> Loader Class Initialized
INFO - 2017-01-23 23:12:24 --> Database Driver Class Initialized
INFO - 2017-01-23 23:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:12:24 --> Controller Class Initialized
INFO - 2017-01-23 23:12:24 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 23:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 23:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 23:12:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 23:12:24 --> Final output sent to browser
DEBUG - 2017-01-23 23:12:24 --> Total execution time: 0.0326
INFO - 2017-01-23 23:14:37 --> Config Class Initialized
INFO - 2017-01-23 23:14:37 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:14:37 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:14:37 --> Utf8 Class Initialized
INFO - 2017-01-23 23:14:37 --> URI Class Initialized
INFO - 2017-01-23 23:14:37 --> Router Class Initialized
INFO - 2017-01-23 23:14:37 --> Output Class Initialized
INFO - 2017-01-23 23:14:37 --> Security Class Initialized
DEBUG - 2017-01-23 23:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:14:37 --> Input Class Initialized
INFO - 2017-01-23 23:14:37 --> Language Class Initialized
INFO - 2017-01-23 23:14:37 --> Loader Class Initialized
INFO - 2017-01-23 23:14:37 --> Database Driver Class Initialized
INFO - 2017-01-23 23:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:14:37 --> Controller Class Initialized
INFO - 2017-01-23 23:14:37 --> Upload Class Initialized
INFO - 2017-01-23 23:14:37 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:14:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:14:37 --> Helper loaded: form_helper
INFO - 2017-01-23 23:14:37 --> Form Validation Class Initialized
INFO - 2017-01-23 23:14:37 --> Final output sent to browser
DEBUG - 2017-01-23 23:14:37 --> Total execution time: 0.0344
INFO - 2017-01-23 23:14:37 --> Config Class Initialized
INFO - 2017-01-23 23:14:37 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:14:37 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:14:37 --> Utf8 Class Initialized
INFO - 2017-01-23 23:14:37 --> URI Class Initialized
INFO - 2017-01-23 23:14:37 --> Router Class Initialized
INFO - 2017-01-23 23:14:37 --> Output Class Initialized
INFO - 2017-01-23 23:14:37 --> Security Class Initialized
DEBUG - 2017-01-23 23:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:14:37 --> Input Class Initialized
INFO - 2017-01-23 23:14:37 --> Language Class Initialized
INFO - 2017-01-23 23:14:37 --> Loader Class Initialized
INFO - 2017-01-23 23:14:37 --> Database Driver Class Initialized
INFO - 2017-01-23 23:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:14:37 --> Controller Class Initialized
INFO - 2017-01-23 23:14:37 --> Upload Class Initialized
INFO - 2017-01-23 23:14:37 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:14:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:14:37 --> Helper loaded: form_helper
INFO - 2017-01-23 23:14:37 --> Form Validation Class Initialized
INFO - 2017-01-23 23:14:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-23 23:14:37 --> Final output sent to browser
DEBUG - 2017-01-23 23:14:37 --> Total execution time: 0.0278
INFO - 2017-01-23 23:18:19 --> Config Class Initialized
INFO - 2017-01-23 23:18:19 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:18:19 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:18:19 --> Utf8 Class Initialized
INFO - 2017-01-23 23:18:19 --> URI Class Initialized
DEBUG - 2017-01-23 23:18:19 --> No URI present. Default controller set.
INFO - 2017-01-23 23:18:19 --> Router Class Initialized
INFO - 2017-01-23 23:18:19 --> Output Class Initialized
INFO - 2017-01-23 23:18:19 --> Security Class Initialized
DEBUG - 2017-01-23 23:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:18:19 --> Input Class Initialized
INFO - 2017-01-23 23:18:19 --> Language Class Initialized
INFO - 2017-01-23 23:18:19 --> Loader Class Initialized
INFO - 2017-01-23 23:18:19 --> Database Driver Class Initialized
INFO - 2017-01-23 23:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:18:19 --> Controller Class Initialized
INFO - 2017-01-23 23:18:19 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:18:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:18:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 23:18:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 23:18:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 23:18:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 23:18:19 --> Final output sent to browser
DEBUG - 2017-01-23 23:18:19 --> Total execution time: 0.0523
INFO - 2017-01-23 23:18:37 --> Config Class Initialized
INFO - 2017-01-23 23:18:37 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:18:37 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:18:37 --> Utf8 Class Initialized
INFO - 2017-01-23 23:18:37 --> URI Class Initialized
INFO - 2017-01-23 23:18:37 --> Router Class Initialized
INFO - 2017-01-23 23:18:37 --> Output Class Initialized
INFO - 2017-01-23 23:18:37 --> Security Class Initialized
DEBUG - 2017-01-23 23:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:18:37 --> Input Class Initialized
INFO - 2017-01-23 23:18:37 --> Language Class Initialized
INFO - 2017-01-23 23:18:37 --> Loader Class Initialized
INFO - 2017-01-23 23:18:37 --> Database Driver Class Initialized
INFO - 2017-01-23 23:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:18:37 --> Controller Class Initialized
INFO - 2017-01-23 23:18:37 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:18:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:18:38 --> Config Class Initialized
INFO - 2017-01-23 23:18:38 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:18:38 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:18:38 --> Utf8 Class Initialized
INFO - 2017-01-23 23:18:38 --> URI Class Initialized
INFO - 2017-01-23 23:18:38 --> Router Class Initialized
INFO - 2017-01-23 23:18:38 --> Output Class Initialized
INFO - 2017-01-23 23:18:38 --> Security Class Initialized
DEBUG - 2017-01-23 23:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:18:38 --> Input Class Initialized
INFO - 2017-01-23 23:18:38 --> Language Class Initialized
INFO - 2017-01-23 23:18:38 --> Loader Class Initialized
INFO - 2017-01-23 23:18:38 --> Database Driver Class Initialized
INFO - 2017-01-23 23:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:18:38 --> Controller Class Initialized
INFO - 2017-01-23 23:18:38 --> Helper loaded: date_helper
DEBUG - 2017-01-23 23:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:18:38 --> Helper loaded: url_helper
INFO - 2017-01-23 23:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 23:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 23:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-23 23:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-23 23:18:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 23:18:38 --> Final output sent to browser
DEBUG - 2017-01-23 23:18:38 --> Total execution time: 0.0143
INFO - 2017-01-23 23:18:45 --> Config Class Initialized
INFO - 2017-01-23 23:18:45 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:18:45 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:18:45 --> Utf8 Class Initialized
INFO - 2017-01-23 23:18:45 --> URI Class Initialized
INFO - 2017-01-23 23:18:45 --> Router Class Initialized
INFO - 2017-01-23 23:18:45 --> Output Class Initialized
INFO - 2017-01-23 23:18:45 --> Security Class Initialized
DEBUG - 2017-01-23 23:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:18:45 --> Input Class Initialized
INFO - 2017-01-23 23:18:45 --> Language Class Initialized
INFO - 2017-01-23 23:18:45 --> Loader Class Initialized
INFO - 2017-01-23 23:18:45 --> Database Driver Class Initialized
INFO - 2017-01-23 23:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:18:45 --> Controller Class Initialized
INFO - 2017-01-23 23:18:45 --> Helper loaded: date_helper
DEBUG - 2017-01-23 23:18:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:18:45 --> Helper loaded: url_helper
INFO - 2017-01-23 23:18:45 --> Helper loaded: download_helper
INFO - 2017-01-23 23:18:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 23:18:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 23:18:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-23 23:18:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-23 23:18:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 23:18:45 --> Final output sent to browser
DEBUG - 2017-01-23 23:18:45 --> Total execution time: 0.0671
INFO - 2017-01-23 23:19:06 --> Config Class Initialized
INFO - 2017-01-23 23:19:06 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:19:06 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:19:06 --> Utf8 Class Initialized
INFO - 2017-01-23 23:19:06 --> URI Class Initialized
DEBUG - 2017-01-23 23:19:06 --> No URI present. Default controller set.
INFO - 2017-01-23 23:19:06 --> Router Class Initialized
INFO - 2017-01-23 23:19:06 --> Output Class Initialized
INFO - 2017-01-23 23:19:06 --> Security Class Initialized
DEBUG - 2017-01-23 23:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:19:06 --> Input Class Initialized
INFO - 2017-01-23 23:19:06 --> Language Class Initialized
INFO - 2017-01-23 23:19:06 --> Loader Class Initialized
INFO - 2017-01-23 23:19:06 --> Database Driver Class Initialized
INFO - 2017-01-23 23:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:19:06 --> Controller Class Initialized
INFO - 2017-01-23 23:19:06 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:19:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:19:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 23:19:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 23:19:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 23:19:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 23:19:06 --> Final output sent to browser
DEBUG - 2017-01-23 23:19:06 --> Total execution time: 0.0488
INFO - 2017-01-23 23:19:14 --> Config Class Initialized
INFO - 2017-01-23 23:19:14 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:19:14 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:19:14 --> Utf8 Class Initialized
INFO - 2017-01-23 23:19:14 --> URI Class Initialized
INFO - 2017-01-23 23:19:14 --> Router Class Initialized
INFO - 2017-01-23 23:19:14 --> Output Class Initialized
INFO - 2017-01-23 23:19:14 --> Security Class Initialized
DEBUG - 2017-01-23 23:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:19:14 --> Input Class Initialized
INFO - 2017-01-23 23:19:14 --> Language Class Initialized
INFO - 2017-01-23 23:19:14 --> Loader Class Initialized
INFO - 2017-01-23 23:19:14 --> Database Driver Class Initialized
INFO - 2017-01-23 23:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:19:14 --> Controller Class Initialized
INFO - 2017-01-23 23:19:14 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:19:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:19:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 23:19:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 23:19:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 23:19:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 23:19:14 --> Final output sent to browser
DEBUG - 2017-01-23 23:19:14 --> Total execution time: 0.0147
INFO - 2017-01-23 23:19:45 --> Config Class Initialized
INFO - 2017-01-23 23:19:45 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:19:45 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:19:45 --> Utf8 Class Initialized
INFO - 2017-01-23 23:19:45 --> URI Class Initialized
INFO - 2017-01-23 23:19:45 --> Router Class Initialized
INFO - 2017-01-23 23:19:45 --> Output Class Initialized
INFO - 2017-01-23 23:19:45 --> Security Class Initialized
DEBUG - 2017-01-23 23:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:19:45 --> Input Class Initialized
INFO - 2017-01-23 23:19:45 --> Language Class Initialized
INFO - 2017-01-23 23:19:45 --> Loader Class Initialized
INFO - 2017-01-23 23:19:45 --> Database Driver Class Initialized
INFO - 2017-01-23 23:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:19:45 --> Controller Class Initialized
INFO - 2017-01-23 23:19:45 --> Helper loaded: date_helper
DEBUG - 2017-01-23 23:19:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:19:45 --> Helper loaded: url_helper
INFO - 2017-01-23 23:19:45 --> Helper loaded: download_helper
INFO - 2017-01-23 23:19:45 --> Final output sent to browser
DEBUG - 2017-01-23 23:19:45 --> Total execution time: 0.0164
INFO - 2017-01-23 23:19:48 --> Config Class Initialized
INFO - 2017-01-23 23:19:48 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:19:48 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:19:48 --> Utf8 Class Initialized
INFO - 2017-01-23 23:19:48 --> URI Class Initialized
INFO - 2017-01-23 23:19:48 --> Router Class Initialized
INFO - 2017-01-23 23:19:48 --> Output Class Initialized
INFO - 2017-01-23 23:19:48 --> Security Class Initialized
DEBUG - 2017-01-23 23:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:19:48 --> Input Class Initialized
INFO - 2017-01-23 23:19:48 --> Language Class Initialized
INFO - 2017-01-23 23:19:48 --> Loader Class Initialized
INFO - 2017-01-23 23:19:48 --> Database Driver Class Initialized
INFO - 2017-01-23 23:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:19:48 --> Controller Class Initialized
INFO - 2017-01-23 23:19:48 --> Helper loaded: date_helper
DEBUG - 2017-01-23 23:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:19:48 --> Helper loaded: url_helper
INFO - 2017-01-23 23:19:48 --> Helper loaded: download_helper
INFO - 2017-01-23 23:19:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 23:19:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 23:19:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-23 23:19:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-23 23:19:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 23:19:48 --> Final output sent to browser
DEBUG - 2017-01-23 23:19:48 --> Total execution time: 0.0521
INFO - 2017-01-23 23:20:10 --> Config Class Initialized
INFO - 2017-01-23 23:20:10 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:20:10 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:20:10 --> Utf8 Class Initialized
INFO - 2017-01-23 23:20:10 --> URI Class Initialized
INFO - 2017-01-23 23:20:10 --> Router Class Initialized
INFO - 2017-01-23 23:20:10 --> Output Class Initialized
INFO - 2017-01-23 23:20:10 --> Security Class Initialized
DEBUG - 2017-01-23 23:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:20:10 --> Input Class Initialized
INFO - 2017-01-23 23:20:10 --> Language Class Initialized
INFO - 2017-01-23 23:20:10 --> Loader Class Initialized
INFO - 2017-01-23 23:20:10 --> Database Driver Class Initialized
INFO - 2017-01-23 23:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:20:10 --> Controller Class Initialized
INFO - 2017-01-23 23:20:10 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:20:11 --> Config Class Initialized
INFO - 2017-01-23 23:20:11 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:20:11 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:20:11 --> Utf8 Class Initialized
INFO - 2017-01-23 23:20:11 --> URI Class Initialized
INFO - 2017-01-23 23:20:11 --> Router Class Initialized
INFO - 2017-01-23 23:20:11 --> Output Class Initialized
INFO - 2017-01-23 23:20:11 --> Security Class Initialized
DEBUG - 2017-01-23 23:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:20:11 --> Input Class Initialized
INFO - 2017-01-23 23:20:11 --> Language Class Initialized
INFO - 2017-01-23 23:20:11 --> Loader Class Initialized
INFO - 2017-01-23 23:20:11 --> Database Driver Class Initialized
INFO - 2017-01-23 23:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:20:11 --> Controller Class Initialized
INFO - 2017-01-23 23:20:11 --> Helper loaded: date_helper
DEBUG - 2017-01-23 23:20:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:20:11 --> Helper loaded: url_helper
INFO - 2017-01-23 23:20:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 23:20:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-23 23:20:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-23 23:20:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-23 23:20:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 23:20:11 --> Final output sent to browser
DEBUG - 2017-01-23 23:20:11 --> Total execution time: 0.0416
INFO - 2017-01-23 23:20:12 --> Config Class Initialized
INFO - 2017-01-23 23:20:12 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:20:12 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:20:12 --> Utf8 Class Initialized
INFO - 2017-01-23 23:20:12 --> URI Class Initialized
INFO - 2017-01-23 23:20:12 --> Router Class Initialized
INFO - 2017-01-23 23:20:12 --> Output Class Initialized
INFO - 2017-01-23 23:20:12 --> Security Class Initialized
DEBUG - 2017-01-23 23:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:20:12 --> Input Class Initialized
INFO - 2017-01-23 23:20:12 --> Language Class Initialized
INFO - 2017-01-23 23:20:12 --> Loader Class Initialized
INFO - 2017-01-23 23:20:12 --> Database Driver Class Initialized
INFO - 2017-01-23 23:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:20:12 --> Controller Class Initialized
INFO - 2017-01-23 23:20:12 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:20:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:20:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 23:20:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 23:20:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 23:20:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 23:20:12 --> Final output sent to browser
DEBUG - 2017-01-23 23:20:12 --> Total execution time: 0.0137
INFO - 2017-01-23 23:20:16 --> Config Class Initialized
INFO - 2017-01-23 23:20:16 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:20:16 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:20:16 --> Utf8 Class Initialized
INFO - 2017-01-23 23:20:16 --> URI Class Initialized
DEBUG - 2017-01-23 23:20:16 --> No URI present. Default controller set.
INFO - 2017-01-23 23:20:16 --> Router Class Initialized
INFO - 2017-01-23 23:20:16 --> Output Class Initialized
INFO - 2017-01-23 23:20:16 --> Security Class Initialized
DEBUG - 2017-01-23 23:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:20:16 --> Input Class Initialized
INFO - 2017-01-23 23:20:16 --> Language Class Initialized
INFO - 2017-01-23 23:20:16 --> Loader Class Initialized
INFO - 2017-01-23 23:20:16 --> Database Driver Class Initialized
INFO - 2017-01-23 23:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:20:16 --> Controller Class Initialized
INFO - 2017-01-23 23:20:16 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:20:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 23:20:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 23:20:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 23:20:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 23:20:16 --> Final output sent to browser
DEBUG - 2017-01-23 23:20:16 --> Total execution time: 0.0648
INFO - 2017-01-23 23:20:17 --> Config Class Initialized
INFO - 2017-01-23 23:20:17 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:20:17 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:20:17 --> Utf8 Class Initialized
INFO - 2017-01-23 23:20:17 --> URI Class Initialized
INFO - 2017-01-23 23:20:17 --> Router Class Initialized
INFO - 2017-01-23 23:20:17 --> Output Class Initialized
INFO - 2017-01-23 23:20:17 --> Security Class Initialized
DEBUG - 2017-01-23 23:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:20:17 --> Input Class Initialized
INFO - 2017-01-23 23:20:17 --> Language Class Initialized
INFO - 2017-01-23 23:20:17 --> Loader Class Initialized
INFO - 2017-01-23 23:20:17 --> Database Driver Class Initialized
INFO - 2017-01-23 23:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:20:17 --> Controller Class Initialized
INFO - 2017-01-23 23:20:17 --> Helper loaded: url_helper
DEBUG - 2017-01-23 23:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:20:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 23:20:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-23 23:20:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-23 23:20:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 23:20:17 --> Final output sent to browser
DEBUG - 2017-01-23 23:20:17 --> Total execution time: 0.0152
INFO - 2017-01-23 23:52:08 --> Config Class Initialized
INFO - 2017-01-23 23:52:08 --> Hooks Class Initialized
DEBUG - 2017-01-23 23:52:08 --> UTF-8 Support Enabled
INFO - 2017-01-23 23:52:08 --> Utf8 Class Initialized
INFO - 2017-01-23 23:52:08 --> URI Class Initialized
INFO - 2017-01-23 23:52:08 --> Router Class Initialized
INFO - 2017-01-23 23:52:08 --> Output Class Initialized
INFO - 2017-01-23 23:52:08 --> Security Class Initialized
DEBUG - 2017-01-23 23:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-23 23:52:08 --> Input Class Initialized
INFO - 2017-01-23 23:52:08 --> Language Class Initialized
INFO - 2017-01-23 23:52:08 --> Loader Class Initialized
INFO - 2017-01-23 23:52:08 --> Database Driver Class Initialized
INFO - 2017-01-23 23:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-23 23:52:08 --> Controller Class Initialized
INFO - 2017-01-23 23:52:08 --> Helper loaded: date_helper
DEBUG - 2017-01-23 23:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-23 23:52:08 --> Helper loaded: url_helper
INFO - 2017-01-23 23:52:08 --> Helper loaded: download_helper
INFO - 2017-01-23 23:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-23 23:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-23 23:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-23 23:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-23 23:52:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-23 23:52:08 --> Final output sent to browser
DEBUG - 2017-01-23 23:52:08 --> Total execution time: 0.1436

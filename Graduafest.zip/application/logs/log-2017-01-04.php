<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-04 03:06:43 --> Config Class Initialized
INFO - 2017-01-04 03:06:43 --> Hooks Class Initialized
DEBUG - 2017-01-04 03:06:43 --> UTF-8 Support Enabled
INFO - 2017-01-04 03:06:43 --> Utf8 Class Initialized
INFO - 2017-01-04 03:06:43 --> URI Class Initialized
DEBUG - 2017-01-04 03:06:43 --> No URI present. Default controller set.
INFO - 2017-01-04 03:06:43 --> Router Class Initialized
INFO - 2017-01-04 03:06:43 --> Output Class Initialized
INFO - 2017-01-04 03:06:43 --> Security Class Initialized
DEBUG - 2017-01-04 03:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-04 03:06:43 --> Input Class Initialized
INFO - 2017-01-04 03:06:43 --> Language Class Initialized
INFO - 2017-01-04 03:06:43 --> Loader Class Initialized
INFO - 2017-01-04 03:06:44 --> Database Driver Class Initialized
INFO - 2017-01-04 03:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-04 03:06:44 --> Controller Class Initialized
INFO - 2017-01-04 03:06:44 --> Helper loaded: url_helper
DEBUG - 2017-01-04 03:06:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-04 03:06:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-04 03:06:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-04 03:06:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-04 03:06:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-04 03:06:45 --> Final output sent to browser
DEBUG - 2017-01-04 03:06:45 --> Total execution time: 2.1759
INFO - 2017-01-04 04:35:55 --> Config Class Initialized
INFO - 2017-01-04 04:35:55 --> Hooks Class Initialized
DEBUG - 2017-01-04 04:35:55 --> UTF-8 Support Enabled
INFO - 2017-01-04 04:35:55 --> Utf8 Class Initialized
INFO - 2017-01-04 04:35:55 --> URI Class Initialized
DEBUG - 2017-01-04 04:35:55 --> No URI present. Default controller set.
INFO - 2017-01-04 04:35:55 --> Router Class Initialized
INFO - 2017-01-04 04:35:56 --> Output Class Initialized
INFO - 2017-01-04 04:35:56 --> Security Class Initialized
DEBUG - 2017-01-04 04:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-04 04:35:56 --> Input Class Initialized
INFO - 2017-01-04 04:35:56 --> Language Class Initialized
INFO - 2017-01-04 04:35:56 --> Loader Class Initialized
INFO - 2017-01-04 04:35:56 --> Database Driver Class Initialized
INFO - 2017-01-04 04:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-04 04:35:56 --> Controller Class Initialized
INFO - 2017-01-04 04:35:56 --> Helper loaded: url_helper
DEBUG - 2017-01-04 04:35:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-04 04:35:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-04 04:35:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-04 04:35:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-04 04:35:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-04 04:35:56 --> Final output sent to browser
DEBUG - 2017-01-04 04:35:56 --> Total execution time: 1.4886
INFO - 2017-01-04 04:36:44 --> Config Class Initialized
INFO - 2017-01-04 04:36:44 --> Hooks Class Initialized
DEBUG - 2017-01-04 04:36:44 --> UTF-8 Support Enabled
INFO - 2017-01-04 04:36:44 --> Utf8 Class Initialized
INFO - 2017-01-04 04:36:44 --> URI Class Initialized
DEBUG - 2017-01-04 04:36:44 --> No URI present. Default controller set.
INFO - 2017-01-04 04:36:44 --> Router Class Initialized
INFO - 2017-01-04 04:36:44 --> Output Class Initialized
INFO - 2017-01-04 04:36:44 --> Security Class Initialized
DEBUG - 2017-01-04 04:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-04 04:36:44 --> Input Class Initialized
INFO - 2017-01-04 04:36:44 --> Language Class Initialized
INFO - 2017-01-04 04:36:44 --> Loader Class Initialized
INFO - 2017-01-04 04:36:44 --> Database Driver Class Initialized
INFO - 2017-01-04 04:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-04 04:36:44 --> Controller Class Initialized
INFO - 2017-01-04 04:36:44 --> Helper loaded: url_helper
DEBUG - 2017-01-04 04:36:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-04 04:36:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-04 04:36:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-04 04:36:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-04 04:36:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-04 04:36:44 --> Final output sent to browser
DEBUG - 2017-01-04 04:36:44 --> Total execution time: 0.0134
INFO - 2017-01-04 04:36:46 --> Config Class Initialized
INFO - 2017-01-04 04:36:46 --> Hooks Class Initialized
DEBUG - 2017-01-04 04:36:46 --> UTF-8 Support Enabled
INFO - 2017-01-04 04:36:46 --> Utf8 Class Initialized
INFO - 2017-01-04 04:36:46 --> URI Class Initialized
INFO - 2017-01-04 04:36:46 --> Router Class Initialized
INFO - 2017-01-04 04:36:46 --> Output Class Initialized
INFO - 2017-01-04 04:36:46 --> Security Class Initialized
DEBUG - 2017-01-04 04:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-04 04:36:46 --> Input Class Initialized
INFO - 2017-01-04 04:36:46 --> Language Class Initialized
INFO - 2017-01-04 04:36:46 --> Loader Class Initialized
INFO - 2017-01-04 04:36:46 --> Database Driver Class Initialized
INFO - 2017-01-04 04:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-04 04:36:46 --> Controller Class Initialized
INFO - 2017-01-04 04:36:46 --> Helper loaded: url_helper
DEBUG - 2017-01-04 04:36:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-04 04:36:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-04 04:36:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-04 04:36:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-04 04:36:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-04 04:36:46 --> Final output sent to browser
DEBUG - 2017-01-04 04:36:46 --> Total execution time: 0.0236
INFO - 2017-01-04 14:39:31 --> Config Class Initialized
INFO - 2017-01-04 14:39:31 --> Hooks Class Initialized
DEBUG - 2017-01-04 14:39:31 --> UTF-8 Support Enabled
INFO - 2017-01-04 14:39:31 --> Utf8 Class Initialized
INFO - 2017-01-04 14:39:31 --> URI Class Initialized
DEBUG - 2017-01-04 14:39:31 --> No URI present. Default controller set.
INFO - 2017-01-04 14:39:31 --> Router Class Initialized
INFO - 2017-01-04 14:39:31 --> Output Class Initialized
INFO - 2017-01-04 14:39:31 --> Security Class Initialized
DEBUG - 2017-01-04 14:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-04 14:39:31 --> Input Class Initialized
INFO - 2017-01-04 14:39:31 --> Language Class Initialized
INFO - 2017-01-04 14:39:32 --> Loader Class Initialized
INFO - 2017-01-04 14:39:32 --> Database Driver Class Initialized
INFO - 2017-01-04 14:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-04 14:39:34 --> Controller Class Initialized
INFO - 2017-01-04 14:39:34 --> Helper loaded: url_helper
DEBUG - 2017-01-04 14:39:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-04 14:39:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-04 14:39:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-04 14:39:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-04 14:39:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-04 14:39:34 --> Final output sent to browser
DEBUG - 2017-01-04 14:39:34 --> Total execution time: 3.6707
INFO - 2017-01-04 16:22:27 --> Config Class Initialized
INFO - 2017-01-04 16:22:27 --> Hooks Class Initialized
DEBUG - 2017-01-04 16:22:27 --> UTF-8 Support Enabled
INFO - 2017-01-04 16:22:27 --> Utf8 Class Initialized
INFO - 2017-01-04 16:22:28 --> URI Class Initialized
DEBUG - 2017-01-04 16:22:28 --> No URI present. Default controller set.
INFO - 2017-01-04 16:22:28 --> Router Class Initialized
INFO - 2017-01-04 16:22:28 --> Output Class Initialized
INFO - 2017-01-04 16:22:28 --> Security Class Initialized
DEBUG - 2017-01-04 16:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-04 16:22:28 --> Input Class Initialized
INFO - 2017-01-04 16:22:28 --> Language Class Initialized
INFO - 2017-01-04 16:22:28 --> Loader Class Initialized
INFO - 2017-01-04 16:22:29 --> Database Driver Class Initialized
INFO - 2017-01-04 16:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-04 16:22:29 --> Controller Class Initialized
INFO - 2017-01-04 16:22:29 --> Helper loaded: url_helper
DEBUG - 2017-01-04 16:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-04 16:22:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-04 16:22:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-04 16:22:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-04 16:22:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-04 16:22:31 --> Final output sent to browser
DEBUG - 2017-01-04 16:22:31 --> Total execution time: 2.7591
INFO - 2017-01-04 17:42:07 --> Config Class Initialized
INFO - 2017-01-04 17:42:07 --> Hooks Class Initialized
DEBUG - 2017-01-04 17:42:07 --> UTF-8 Support Enabled
INFO - 2017-01-04 17:42:07 --> Utf8 Class Initialized
INFO - 2017-01-04 17:42:07 --> URI Class Initialized
DEBUG - 2017-01-04 17:42:07 --> No URI present. Default controller set.
INFO - 2017-01-04 17:42:07 --> Router Class Initialized
INFO - 2017-01-04 17:42:07 --> Output Class Initialized
INFO - 2017-01-04 17:42:07 --> Security Class Initialized
DEBUG - 2017-01-04 17:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-04 17:42:07 --> Input Class Initialized
INFO - 2017-01-04 17:42:07 --> Language Class Initialized
INFO - 2017-01-04 17:42:07 --> Loader Class Initialized
INFO - 2017-01-04 17:42:08 --> Database Driver Class Initialized
INFO - 2017-01-04 17:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-04 17:42:08 --> Controller Class Initialized
INFO - 2017-01-04 17:42:08 --> Helper loaded: url_helper
DEBUG - 2017-01-04 17:42:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-04 17:42:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-04 17:42:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-04 17:42:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-04 17:42:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-04 17:42:08 --> Final output sent to browser
DEBUG - 2017-01-04 17:42:08 --> Total execution time: 1.7125
INFO - 2017-01-04 19:00:09 --> Config Class Initialized
INFO - 2017-01-04 19:00:09 --> Hooks Class Initialized
DEBUG - 2017-01-04 19:00:09 --> UTF-8 Support Enabled
INFO - 2017-01-04 19:00:09 --> Utf8 Class Initialized
INFO - 2017-01-04 19:00:09 --> URI Class Initialized
DEBUG - 2017-01-04 19:00:09 --> No URI present. Default controller set.
INFO - 2017-01-04 19:00:09 --> Router Class Initialized
INFO - 2017-01-04 19:00:10 --> Output Class Initialized
INFO - 2017-01-04 19:00:10 --> Security Class Initialized
DEBUG - 2017-01-04 19:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-04 19:00:10 --> Input Class Initialized
INFO - 2017-01-04 19:00:10 --> Language Class Initialized
INFO - 2017-01-04 19:00:10 --> Loader Class Initialized
INFO - 2017-01-04 19:00:10 --> Database Driver Class Initialized
INFO - 2017-01-04 19:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-04 19:00:10 --> Controller Class Initialized
INFO - 2017-01-04 19:00:10 --> Helper loaded: url_helper
DEBUG - 2017-01-04 19:00:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-04 19:00:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-04 19:00:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-04 19:00:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-04 19:00:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-04 19:00:11 --> Final output sent to browser
DEBUG - 2017-01-04 19:00:11 --> Total execution time: 1.4837
INFO - 2017-01-04 21:19:05 --> Config Class Initialized
INFO - 2017-01-04 21:19:05 --> Hooks Class Initialized
DEBUG - 2017-01-04 21:19:05 --> UTF-8 Support Enabled
INFO - 2017-01-04 21:19:05 --> Utf8 Class Initialized
INFO - 2017-01-04 21:19:05 --> URI Class Initialized
DEBUG - 2017-01-04 21:19:06 --> No URI present. Default controller set.
INFO - 2017-01-04 21:19:06 --> Router Class Initialized
INFO - 2017-01-04 21:19:06 --> Output Class Initialized
INFO - 2017-01-04 21:19:06 --> Security Class Initialized
DEBUG - 2017-01-04 21:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-04 21:19:06 --> Input Class Initialized
INFO - 2017-01-04 21:19:06 --> Language Class Initialized
INFO - 2017-01-04 21:19:06 --> Loader Class Initialized
INFO - 2017-01-04 21:19:06 --> Database Driver Class Initialized
INFO - 2017-01-04 21:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-04 21:19:06 --> Controller Class Initialized
INFO - 2017-01-04 21:19:07 --> Helper loaded: url_helper
DEBUG - 2017-01-04 21:19:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-04 21:19:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-04 21:19:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-04 21:19:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-04 21:19:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-04 21:19:07 --> Final output sent to browser
DEBUG - 2017-01-04 21:19:07 --> Total execution time: 1.8224
INFO - 2017-01-04 21:48:41 --> Config Class Initialized
INFO - 2017-01-04 21:48:41 --> Hooks Class Initialized
DEBUG - 2017-01-04 21:48:41 --> UTF-8 Support Enabled
INFO - 2017-01-04 21:48:41 --> Utf8 Class Initialized
INFO - 2017-01-04 21:48:41 --> URI Class Initialized
DEBUG - 2017-01-04 21:48:41 --> No URI present. Default controller set.
INFO - 2017-01-04 21:48:41 --> Router Class Initialized
INFO - 2017-01-04 21:48:41 --> Output Class Initialized
INFO - 2017-01-04 21:48:41 --> Security Class Initialized
DEBUG - 2017-01-04 21:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-04 21:48:41 --> Input Class Initialized
INFO - 2017-01-04 21:48:41 --> Language Class Initialized
INFO - 2017-01-04 21:48:41 --> Loader Class Initialized
INFO - 2017-01-04 21:48:42 --> Database Driver Class Initialized
INFO - 2017-01-04 21:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-04 21:48:42 --> Controller Class Initialized
INFO - 2017-01-04 21:48:42 --> Helper loaded: url_helper
DEBUG - 2017-01-04 21:48:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-04 21:48:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-04 21:48:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-04 21:48:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-04 21:48:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-04 21:48:42 --> Final output sent to browser
DEBUG - 2017-01-04 21:48:42 --> Total execution time: 1.7627
INFO - 2017-01-04 21:56:43 --> Config Class Initialized
INFO - 2017-01-04 21:56:43 --> Hooks Class Initialized
DEBUG - 2017-01-04 21:56:44 --> UTF-8 Support Enabled
INFO - 2017-01-04 21:56:44 --> Utf8 Class Initialized
INFO - 2017-01-04 21:56:44 --> URI Class Initialized
DEBUG - 2017-01-04 21:56:44 --> No URI present. Default controller set.
INFO - 2017-01-04 21:56:44 --> Router Class Initialized
INFO - 2017-01-04 21:56:44 --> Output Class Initialized
INFO - 2017-01-04 21:56:44 --> Security Class Initialized
DEBUG - 2017-01-04 21:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-04 21:56:44 --> Input Class Initialized
INFO - 2017-01-04 21:56:44 --> Language Class Initialized
INFO - 2017-01-04 21:56:44 --> Loader Class Initialized
INFO - 2017-01-04 21:56:44 --> Database Driver Class Initialized
INFO - 2017-01-04 21:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-04 21:56:45 --> Controller Class Initialized
INFO - 2017-01-04 21:56:45 --> Helper loaded: url_helper
DEBUG - 2017-01-04 21:56:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-04 21:56:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-04 21:56:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-04 21:56:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-04 21:56:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-04 21:56:45 --> Final output sent to browser
DEBUG - 2017-01-04 21:56:45 --> Total execution time: 1.8254
INFO - 2017-01-04 21:56:47 --> Config Class Initialized
INFO - 2017-01-04 21:56:47 --> Hooks Class Initialized
DEBUG - 2017-01-04 21:56:47 --> UTF-8 Support Enabled
INFO - 2017-01-04 21:56:47 --> Utf8 Class Initialized
INFO - 2017-01-04 21:56:47 --> URI Class Initialized
INFO - 2017-01-04 21:56:47 --> Router Class Initialized
INFO - 2017-01-04 21:56:47 --> Output Class Initialized
INFO - 2017-01-04 21:56:47 --> Security Class Initialized
DEBUG - 2017-01-04 21:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-04 21:56:47 --> Input Class Initialized
INFO - 2017-01-04 21:56:47 --> Language Class Initialized
INFO - 2017-01-04 21:56:47 --> Loader Class Initialized
INFO - 2017-01-04 21:56:47 --> Database Driver Class Initialized
INFO - 2017-01-04 21:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-04 21:56:47 --> Controller Class Initialized
INFO - 2017-01-04 21:56:47 --> Helper loaded: url_helper
DEBUG - 2017-01-04 21:56:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-04 21:56:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-04 21:56:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-04 21:56:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-04 21:56:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-04 21:56:47 --> Final output sent to browser
DEBUG - 2017-01-04 21:56:47 --> Total execution time: 0.0136

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-28 00:53:20 --> Config Class Initialized
INFO - 2016-12-28 00:53:20 --> Hooks Class Initialized
DEBUG - 2016-12-28 00:53:20 --> UTF-8 Support Enabled
INFO - 2016-12-28 00:53:20 --> Utf8 Class Initialized
INFO - 2016-12-28 00:53:20 --> URI Class Initialized
DEBUG - 2016-12-28 00:53:20 --> No URI present. Default controller set.
INFO - 2016-12-28 00:53:20 --> Router Class Initialized
INFO - 2016-12-28 00:53:20 --> Output Class Initialized
INFO - 2016-12-28 00:53:20 --> Security Class Initialized
DEBUG - 2016-12-28 00:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-28 00:53:20 --> Input Class Initialized
INFO - 2016-12-28 00:53:20 --> Language Class Initialized
INFO - 2016-12-28 00:53:20 --> Loader Class Initialized
INFO - 2016-12-28 00:53:20 --> Database Driver Class Initialized
INFO - 2016-12-28 00:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-28 00:53:21 --> Controller Class Initialized
INFO - 2016-12-28 00:53:21 --> Helper loaded: url_helper
DEBUG - 2016-12-28 00:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-28 00:53:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-28 00:53:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-28 00:53:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-28 00:53:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-28 00:53:21 --> Final output sent to browser
DEBUG - 2016-12-28 00:53:21 --> Total execution time: 2.0658
INFO - 2016-12-28 05:25:21 --> Config Class Initialized
INFO - 2016-12-28 05:25:21 --> Hooks Class Initialized
DEBUG - 2016-12-28 05:25:22 --> UTF-8 Support Enabled
INFO - 2016-12-28 05:25:22 --> Utf8 Class Initialized
INFO - 2016-12-28 05:25:22 --> URI Class Initialized
DEBUG - 2016-12-28 05:25:22 --> No URI present. Default controller set.
INFO - 2016-12-28 05:25:22 --> Router Class Initialized
INFO - 2016-12-28 05:25:22 --> Output Class Initialized
INFO - 2016-12-28 05:25:22 --> Security Class Initialized
DEBUG - 2016-12-28 05:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-28 05:25:22 --> Input Class Initialized
INFO - 2016-12-28 05:25:22 --> Language Class Initialized
INFO - 2016-12-28 05:25:22 --> Loader Class Initialized
INFO - 2016-12-28 05:25:22 --> Database Driver Class Initialized
INFO - 2016-12-28 05:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-28 05:25:22 --> Controller Class Initialized
INFO - 2016-12-28 05:25:22 --> Helper loaded: url_helper
DEBUG - 2016-12-28 05:25:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-28 05:25:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-28 05:25:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-28 05:25:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-28 05:25:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-28 05:25:23 --> Final output sent to browser
DEBUG - 2016-12-28 05:25:23 --> Total execution time: 1.7094
INFO - 2016-12-28 07:07:51 --> Config Class Initialized
INFO - 2016-12-28 07:07:51 --> Hooks Class Initialized
DEBUG - 2016-12-28 07:07:51 --> UTF-8 Support Enabled
INFO - 2016-12-28 07:07:51 --> Utf8 Class Initialized
INFO - 2016-12-28 07:07:51 --> URI Class Initialized
DEBUG - 2016-12-28 07:07:51 --> No URI present. Default controller set.
INFO - 2016-12-28 07:07:51 --> Router Class Initialized
INFO - 2016-12-28 07:07:51 --> Output Class Initialized
INFO - 2016-12-28 07:07:51 --> Security Class Initialized
DEBUG - 2016-12-28 07:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-28 07:07:52 --> Input Class Initialized
INFO - 2016-12-28 07:07:52 --> Language Class Initialized
INFO - 2016-12-28 07:07:52 --> Loader Class Initialized
INFO - 2016-12-28 07:07:52 --> Database Driver Class Initialized
INFO - 2016-12-28 07:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-28 07:07:52 --> Controller Class Initialized
INFO - 2016-12-28 07:07:52 --> Helper loaded: url_helper
DEBUG - 2016-12-28 07:07:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-28 07:07:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-28 07:07:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-28 07:07:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-28 07:07:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-28 07:07:52 --> Final output sent to browser
DEBUG - 2016-12-28 07:07:52 --> Total execution time: 1.3391
INFO - 2016-12-28 14:30:14 --> Config Class Initialized
INFO - 2016-12-28 14:30:14 --> Hooks Class Initialized
DEBUG - 2016-12-28 14:30:15 --> UTF-8 Support Enabled
INFO - 2016-12-28 14:30:15 --> Utf8 Class Initialized
INFO - 2016-12-28 14:30:15 --> URI Class Initialized
DEBUG - 2016-12-28 14:30:15 --> No URI present. Default controller set.
INFO - 2016-12-28 14:30:15 --> Router Class Initialized
INFO - 2016-12-28 14:30:15 --> Output Class Initialized
INFO - 2016-12-28 14:30:15 --> Security Class Initialized
DEBUG - 2016-12-28 14:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-28 14:30:15 --> Input Class Initialized
INFO - 2016-12-28 14:30:15 --> Language Class Initialized
INFO - 2016-12-28 14:30:15 --> Loader Class Initialized
INFO - 2016-12-28 14:30:15 --> Database Driver Class Initialized
INFO - 2016-12-28 14:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-28 14:30:16 --> Controller Class Initialized
INFO - 2016-12-28 14:30:16 --> Helper loaded: url_helper
DEBUG - 2016-12-28 14:30:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-28 14:30:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-28 14:30:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-28 14:30:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-28 14:30:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-28 14:30:17 --> Final output sent to browser
DEBUG - 2016-12-28 14:30:17 --> Total execution time: 3.0787
INFO - 2016-12-28 18:27:02 --> Config Class Initialized
INFO - 2016-12-28 18:27:02 --> Hooks Class Initialized
DEBUG - 2016-12-28 18:27:03 --> UTF-8 Support Enabled
INFO - 2016-12-28 18:27:03 --> Utf8 Class Initialized
INFO - 2016-12-28 18:27:03 --> URI Class Initialized
DEBUG - 2016-12-28 18:27:03 --> No URI present. Default controller set.
INFO - 2016-12-28 18:27:03 --> Router Class Initialized
INFO - 2016-12-28 18:27:03 --> Output Class Initialized
INFO - 2016-12-28 18:27:03 --> Security Class Initialized
DEBUG - 2016-12-28 18:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-28 18:27:03 --> Input Class Initialized
INFO - 2016-12-28 18:27:03 --> Language Class Initialized
INFO - 2016-12-28 18:27:03 --> Loader Class Initialized
INFO - 2016-12-28 18:27:03 --> Database Driver Class Initialized
INFO - 2016-12-28 18:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-28 18:27:04 --> Controller Class Initialized
INFO - 2016-12-28 18:27:04 --> Helper loaded: url_helper
DEBUG - 2016-12-28 18:27:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-28 18:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-28 18:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-28 18:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-28 18:27:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-28 18:27:04 --> Final output sent to browser
DEBUG - 2016-12-28 18:27:04 --> Total execution time: 1.6259
INFO - 2016-12-28 21:26:02 --> Config Class Initialized
INFO - 2016-12-28 21:26:02 --> Hooks Class Initialized
DEBUG - 2016-12-28 21:26:02 --> UTF-8 Support Enabled
INFO - 2016-12-28 21:26:02 --> Utf8 Class Initialized
INFO - 2016-12-28 21:26:02 --> URI Class Initialized
DEBUG - 2016-12-28 21:26:02 --> No URI present. Default controller set.
INFO - 2016-12-28 21:26:02 --> Router Class Initialized
INFO - 2016-12-28 21:26:02 --> Output Class Initialized
INFO - 2016-12-28 21:26:02 --> Security Class Initialized
DEBUG - 2016-12-28 21:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-28 21:26:02 --> Input Class Initialized
INFO - 2016-12-28 21:26:02 --> Language Class Initialized
INFO - 2016-12-28 21:26:02 --> Loader Class Initialized
INFO - 2016-12-28 21:26:03 --> Database Driver Class Initialized
INFO - 2016-12-28 21:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-28 21:26:03 --> Controller Class Initialized
INFO - 2016-12-28 21:26:03 --> Helper loaded: url_helper
DEBUG - 2016-12-28 21:26:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-28 21:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-28 21:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-28 21:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-28 21:26:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-28 21:26:03 --> Final output sent to browser
DEBUG - 2016-12-28 21:26:03 --> Total execution time: 1.9032

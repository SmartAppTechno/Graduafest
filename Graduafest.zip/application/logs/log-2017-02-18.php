<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-18 00:00:06 --> Config Class Initialized
INFO - 2017-02-18 00:00:06 --> Hooks Class Initialized
DEBUG - 2017-02-18 00:00:06 --> UTF-8 Support Enabled
INFO - 2017-02-18 00:00:06 --> Utf8 Class Initialized
INFO - 2017-02-18 00:00:06 --> URI Class Initialized
DEBUG - 2017-02-18 00:00:06 --> No URI present. Default controller set.
INFO - 2017-02-18 00:00:06 --> Router Class Initialized
INFO - 2017-02-18 00:00:06 --> Output Class Initialized
INFO - 2017-02-18 00:00:06 --> Security Class Initialized
DEBUG - 2017-02-18 00:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 00:00:06 --> Input Class Initialized
INFO - 2017-02-18 00:00:06 --> Language Class Initialized
INFO - 2017-02-18 00:00:06 --> Loader Class Initialized
INFO - 2017-02-18 00:00:06 --> Database Driver Class Initialized
INFO - 2017-02-18 00:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 00:00:06 --> Controller Class Initialized
INFO - 2017-02-18 00:00:06 --> Helper loaded: url_helper
DEBUG - 2017-02-18 00:00:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 00:00:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 00:00:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 00:00:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 00:00:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 00:00:06 --> Final output sent to browser
DEBUG - 2017-02-18 00:00:06 --> Total execution time: 0.0450
INFO - 2017-02-18 00:00:15 --> Config Class Initialized
INFO - 2017-02-18 00:00:15 --> Hooks Class Initialized
DEBUG - 2017-02-18 00:00:15 --> UTF-8 Support Enabled
INFO - 2017-02-18 00:00:15 --> Utf8 Class Initialized
INFO - 2017-02-18 00:00:15 --> URI Class Initialized
INFO - 2017-02-18 00:00:15 --> Router Class Initialized
INFO - 2017-02-18 00:00:15 --> Output Class Initialized
INFO - 2017-02-18 00:00:15 --> Security Class Initialized
DEBUG - 2017-02-18 00:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 00:00:15 --> Input Class Initialized
INFO - 2017-02-18 00:00:15 --> Language Class Initialized
INFO - 2017-02-18 00:00:15 --> Loader Class Initialized
INFO - 2017-02-18 00:00:15 --> Database Driver Class Initialized
INFO - 2017-02-18 00:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 00:00:15 --> Controller Class Initialized
INFO - 2017-02-18 00:00:15 --> Helper loaded: url_helper
DEBUG - 2017-02-18 00:00:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 00:00:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 00:00:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 00:00:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 00:00:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 00:00:15 --> Final output sent to browser
DEBUG - 2017-02-18 00:00:15 --> Total execution time: 0.0140
INFO - 2017-02-18 00:01:22 --> Config Class Initialized
INFO - 2017-02-18 00:01:22 --> Hooks Class Initialized
DEBUG - 2017-02-18 00:01:22 --> UTF-8 Support Enabled
INFO - 2017-02-18 00:01:22 --> Utf8 Class Initialized
INFO - 2017-02-18 00:01:22 --> URI Class Initialized
INFO - 2017-02-18 00:01:22 --> Router Class Initialized
INFO - 2017-02-18 00:01:22 --> Output Class Initialized
INFO - 2017-02-18 00:01:22 --> Security Class Initialized
DEBUG - 2017-02-18 00:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 00:01:22 --> Input Class Initialized
INFO - 2017-02-18 00:01:22 --> Language Class Initialized
INFO - 2017-02-18 00:01:22 --> Loader Class Initialized
INFO - 2017-02-18 00:01:22 --> Database Driver Class Initialized
INFO - 2017-02-18 00:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 00:01:22 --> Controller Class Initialized
INFO - 2017-02-18 00:01:22 --> Helper loaded: url_helper
DEBUG - 2017-02-18 00:01:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 00:01:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 00:01:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 00:01:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 00:01:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 00:01:22 --> Final output sent to browser
DEBUG - 2017-02-18 00:01:22 --> Total execution time: 0.0138
INFO - 2017-02-18 00:01:25 --> Config Class Initialized
INFO - 2017-02-18 00:01:25 --> Hooks Class Initialized
DEBUG - 2017-02-18 00:01:25 --> UTF-8 Support Enabled
INFO - 2017-02-18 00:01:25 --> Utf8 Class Initialized
INFO - 2017-02-18 00:01:25 --> URI Class Initialized
INFO - 2017-02-18 00:01:25 --> Router Class Initialized
INFO - 2017-02-18 00:01:25 --> Output Class Initialized
INFO - 2017-02-18 00:01:25 --> Security Class Initialized
DEBUG - 2017-02-18 00:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 00:01:25 --> Input Class Initialized
INFO - 2017-02-18 00:01:25 --> Language Class Initialized
INFO - 2017-02-18 00:01:25 --> Loader Class Initialized
INFO - 2017-02-18 00:01:25 --> Database Driver Class Initialized
INFO - 2017-02-18 00:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 00:01:25 --> Controller Class Initialized
INFO - 2017-02-18 00:01:25 --> Helper loaded: url_helper
DEBUG - 2017-02-18 00:01:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 00:01:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 00:01:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 00:01:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 00:01:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 00:01:25 --> Final output sent to browser
DEBUG - 2017-02-18 00:01:25 --> Total execution time: 0.0131
INFO - 2017-02-18 00:01:49 --> Config Class Initialized
INFO - 2017-02-18 00:01:49 --> Hooks Class Initialized
DEBUG - 2017-02-18 00:01:49 --> UTF-8 Support Enabled
INFO - 2017-02-18 00:01:49 --> Utf8 Class Initialized
INFO - 2017-02-18 00:01:49 --> URI Class Initialized
INFO - 2017-02-18 00:01:49 --> Router Class Initialized
INFO - 2017-02-18 00:01:49 --> Output Class Initialized
INFO - 2017-02-18 00:01:49 --> Security Class Initialized
DEBUG - 2017-02-18 00:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 00:01:49 --> Input Class Initialized
INFO - 2017-02-18 00:01:49 --> Language Class Initialized
INFO - 2017-02-18 00:01:49 --> Loader Class Initialized
INFO - 2017-02-18 00:01:49 --> Database Driver Class Initialized
INFO - 2017-02-18 00:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 00:01:49 --> Controller Class Initialized
INFO - 2017-02-18 00:01:49 --> Helper loaded: url_helper
DEBUG - 2017-02-18 00:01:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 00:01:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 00:01:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 00:01:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 00:01:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 00:01:49 --> Final output sent to browser
DEBUG - 2017-02-18 00:01:49 --> Total execution time: 0.0141
INFO - 2017-02-18 00:01:52 --> Config Class Initialized
INFO - 2017-02-18 00:01:52 --> Hooks Class Initialized
DEBUG - 2017-02-18 00:01:52 --> UTF-8 Support Enabled
INFO - 2017-02-18 00:01:52 --> Utf8 Class Initialized
INFO - 2017-02-18 00:01:52 --> URI Class Initialized
INFO - 2017-02-18 00:01:52 --> Router Class Initialized
INFO - 2017-02-18 00:01:52 --> Output Class Initialized
INFO - 2017-02-18 00:01:52 --> Security Class Initialized
DEBUG - 2017-02-18 00:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 00:01:52 --> Input Class Initialized
INFO - 2017-02-18 00:01:52 --> Language Class Initialized
INFO - 2017-02-18 00:01:52 --> Loader Class Initialized
INFO - 2017-02-18 00:01:52 --> Database Driver Class Initialized
INFO - 2017-02-18 00:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 00:01:52 --> Controller Class Initialized
INFO - 2017-02-18 00:01:52 --> Helper loaded: url_helper
DEBUG - 2017-02-18 00:01:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 00:01:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 00:01:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 00:01:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 00:01:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 00:01:52 --> Final output sent to browser
DEBUG - 2017-02-18 00:01:52 --> Total execution time: 0.0139
INFO - 2017-02-18 00:02:22 --> Config Class Initialized
INFO - 2017-02-18 00:02:22 --> Hooks Class Initialized
DEBUG - 2017-02-18 00:02:22 --> UTF-8 Support Enabled
INFO - 2017-02-18 00:02:22 --> Utf8 Class Initialized
INFO - 2017-02-18 00:02:22 --> URI Class Initialized
INFO - 2017-02-18 00:02:22 --> Router Class Initialized
INFO - 2017-02-18 00:02:22 --> Output Class Initialized
INFO - 2017-02-18 00:02:22 --> Security Class Initialized
DEBUG - 2017-02-18 00:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 00:02:22 --> Input Class Initialized
INFO - 2017-02-18 00:02:22 --> Language Class Initialized
INFO - 2017-02-18 00:02:22 --> Loader Class Initialized
INFO - 2017-02-18 00:02:22 --> Database Driver Class Initialized
INFO - 2017-02-18 00:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 00:02:22 --> Controller Class Initialized
INFO - 2017-02-18 00:02:22 --> Helper loaded: url_helper
DEBUG - 2017-02-18 00:02:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 00:02:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 00:02:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 00:02:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 00:02:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 00:02:22 --> Final output sent to browser
DEBUG - 2017-02-18 00:02:22 --> Total execution time: 0.0138
INFO - 2017-02-18 00:02:25 --> Config Class Initialized
INFO - 2017-02-18 00:02:25 --> Hooks Class Initialized
DEBUG - 2017-02-18 00:02:25 --> UTF-8 Support Enabled
INFO - 2017-02-18 00:02:25 --> Utf8 Class Initialized
INFO - 2017-02-18 00:02:25 --> URI Class Initialized
INFO - 2017-02-18 00:02:25 --> Router Class Initialized
INFO - 2017-02-18 00:02:25 --> Output Class Initialized
INFO - 2017-02-18 00:02:25 --> Security Class Initialized
DEBUG - 2017-02-18 00:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 00:02:25 --> Input Class Initialized
INFO - 2017-02-18 00:02:25 --> Language Class Initialized
INFO - 2017-02-18 00:02:25 --> Loader Class Initialized
INFO - 2017-02-18 00:02:25 --> Database Driver Class Initialized
INFO - 2017-02-18 00:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 00:02:25 --> Controller Class Initialized
INFO - 2017-02-18 00:02:25 --> Helper loaded: url_helper
DEBUG - 2017-02-18 00:02:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 00:02:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 00:02:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 00:02:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 00:02:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 00:02:25 --> Final output sent to browser
DEBUG - 2017-02-18 00:02:25 --> Total execution time: 0.0130
INFO - 2017-02-18 00:03:31 --> Config Class Initialized
INFO - 2017-02-18 00:03:31 --> Hooks Class Initialized
DEBUG - 2017-02-18 00:03:31 --> UTF-8 Support Enabled
INFO - 2017-02-18 00:03:31 --> Utf8 Class Initialized
INFO - 2017-02-18 00:03:31 --> URI Class Initialized
INFO - 2017-02-18 00:03:31 --> Router Class Initialized
INFO - 2017-02-18 00:03:31 --> Output Class Initialized
INFO - 2017-02-18 00:03:31 --> Security Class Initialized
DEBUG - 2017-02-18 00:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 00:03:31 --> Input Class Initialized
INFO - 2017-02-18 00:03:31 --> Language Class Initialized
INFO - 2017-02-18 00:03:31 --> Loader Class Initialized
INFO - 2017-02-18 00:03:31 --> Database Driver Class Initialized
INFO - 2017-02-18 00:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 00:03:31 --> Controller Class Initialized
INFO - 2017-02-18 00:03:31 --> Helper loaded: url_helper
DEBUG - 2017-02-18 00:03:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-18 00:03:32 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-18 00:03:32 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Dulce Domiinguez')
INFO - 2017-02-18 00:03:32 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-18 00:03:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-18 00:03:34 --> Config Class Initialized
INFO - 2017-02-18 00:03:34 --> Hooks Class Initialized
DEBUG - 2017-02-18 00:03:34 --> UTF-8 Support Enabled
INFO - 2017-02-18 00:03:34 --> Utf8 Class Initialized
INFO - 2017-02-18 00:03:34 --> URI Class Initialized
INFO - 2017-02-18 00:03:34 --> Router Class Initialized
INFO - 2017-02-18 00:03:34 --> Output Class Initialized
INFO - 2017-02-18 00:03:34 --> Security Class Initialized
DEBUG - 2017-02-18 00:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 00:03:34 --> Input Class Initialized
INFO - 2017-02-18 00:03:34 --> Language Class Initialized
INFO - 2017-02-18 00:03:34 --> Loader Class Initialized
INFO - 2017-02-18 00:03:34 --> Database Driver Class Initialized
INFO - 2017-02-18 00:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 00:03:34 --> Controller Class Initialized
INFO - 2017-02-18 00:03:34 --> Helper loaded: url_helper
DEBUG - 2017-02-18 00:03:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 00:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 00:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 00:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 00:03:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 00:03:34 --> Final output sent to browser
DEBUG - 2017-02-18 00:03:34 --> Total execution time: 0.0133
INFO - 2017-02-18 00:03:57 --> Config Class Initialized
INFO - 2017-02-18 00:03:57 --> Hooks Class Initialized
DEBUG - 2017-02-18 00:03:57 --> UTF-8 Support Enabled
INFO - 2017-02-18 00:03:57 --> Utf8 Class Initialized
INFO - 2017-02-18 00:03:57 --> URI Class Initialized
INFO - 2017-02-18 00:03:57 --> Router Class Initialized
INFO - 2017-02-18 00:03:57 --> Output Class Initialized
INFO - 2017-02-18 00:03:57 --> Security Class Initialized
DEBUG - 2017-02-18 00:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 00:03:57 --> Input Class Initialized
INFO - 2017-02-18 00:03:57 --> Language Class Initialized
INFO - 2017-02-18 00:03:57 --> Loader Class Initialized
INFO - 2017-02-18 00:03:57 --> Database Driver Class Initialized
INFO - 2017-02-18 00:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 00:03:57 --> Controller Class Initialized
INFO - 2017-02-18 00:03:57 --> Helper loaded: url_helper
DEBUG - 2017-02-18 00:03:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-18 00:03:57 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-18 00:03:57 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Dulce Domiinguez')
INFO - 2017-02-18 00:03:57 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-18 00:03:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-18 00:03:58 --> Config Class Initialized
INFO - 2017-02-18 00:03:58 --> Hooks Class Initialized
DEBUG - 2017-02-18 00:03:58 --> UTF-8 Support Enabled
INFO - 2017-02-18 00:03:58 --> Utf8 Class Initialized
INFO - 2017-02-18 00:03:58 --> URI Class Initialized
INFO - 2017-02-18 00:03:58 --> Router Class Initialized
INFO - 2017-02-18 00:03:58 --> Output Class Initialized
INFO - 2017-02-18 00:03:58 --> Security Class Initialized
DEBUG - 2017-02-18 00:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 00:03:58 --> Input Class Initialized
INFO - 2017-02-18 00:03:58 --> Language Class Initialized
INFO - 2017-02-18 00:03:58 --> Loader Class Initialized
INFO - 2017-02-18 00:03:58 --> Database Driver Class Initialized
INFO - 2017-02-18 00:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 00:03:58 --> Controller Class Initialized
INFO - 2017-02-18 00:03:58 --> Helper loaded: url_helper
DEBUG - 2017-02-18 00:03:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 00:03:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 00:03:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 00:03:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 00:03:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 00:03:58 --> Final output sent to browser
DEBUG - 2017-02-18 00:03:58 --> Total execution time: 0.0131
INFO - 2017-02-18 00:04:06 --> Config Class Initialized
INFO - 2017-02-18 00:04:06 --> Hooks Class Initialized
DEBUG - 2017-02-18 00:04:06 --> UTF-8 Support Enabled
INFO - 2017-02-18 00:04:06 --> Utf8 Class Initialized
INFO - 2017-02-18 00:04:06 --> URI Class Initialized
INFO - 2017-02-18 00:04:06 --> Router Class Initialized
INFO - 2017-02-18 00:04:06 --> Output Class Initialized
INFO - 2017-02-18 00:04:06 --> Security Class Initialized
DEBUG - 2017-02-18 00:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 00:04:06 --> Input Class Initialized
INFO - 2017-02-18 00:04:06 --> Language Class Initialized
INFO - 2017-02-18 00:04:06 --> Loader Class Initialized
INFO - 2017-02-18 00:04:06 --> Database Driver Class Initialized
INFO - 2017-02-18 00:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 00:04:06 --> Controller Class Initialized
INFO - 2017-02-18 00:04:06 --> Helper loaded: url_helper
DEBUG - 2017-02-18 00:04:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-18 00:04:07 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-18 00:04:07 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Dulce Domiinguez')
INFO - 2017-02-18 00:04:07 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-18 00:04:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-18 00:04:07 --> Config Class Initialized
INFO - 2017-02-18 00:04:07 --> Hooks Class Initialized
DEBUG - 2017-02-18 00:04:07 --> UTF-8 Support Enabled
INFO - 2017-02-18 00:04:07 --> Utf8 Class Initialized
INFO - 2017-02-18 00:04:07 --> URI Class Initialized
INFO - 2017-02-18 00:04:07 --> Router Class Initialized
INFO - 2017-02-18 00:04:07 --> Output Class Initialized
INFO - 2017-02-18 00:04:07 --> Security Class Initialized
DEBUG - 2017-02-18 00:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 00:04:07 --> Input Class Initialized
INFO - 2017-02-18 00:04:07 --> Language Class Initialized
INFO - 2017-02-18 00:04:07 --> Loader Class Initialized
INFO - 2017-02-18 00:04:07 --> Database Driver Class Initialized
INFO - 2017-02-18 00:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 00:04:07 --> Controller Class Initialized
INFO - 2017-02-18 00:04:07 --> Helper loaded: url_helper
DEBUG - 2017-02-18 00:04:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 00:04:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 00:04:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 00:04:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 00:04:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 00:04:07 --> Final output sent to browser
DEBUG - 2017-02-18 00:04:07 --> Total execution time: 0.0132
INFO - 2017-02-18 00:05:02 --> Config Class Initialized
INFO - 2017-02-18 00:05:02 --> Hooks Class Initialized
DEBUG - 2017-02-18 00:05:02 --> UTF-8 Support Enabled
INFO - 2017-02-18 00:05:02 --> Utf8 Class Initialized
INFO - 2017-02-18 00:05:02 --> URI Class Initialized
DEBUG - 2017-02-18 00:05:02 --> No URI present. Default controller set.
INFO - 2017-02-18 00:05:02 --> Router Class Initialized
INFO - 2017-02-18 00:05:02 --> Output Class Initialized
INFO - 2017-02-18 00:05:02 --> Security Class Initialized
DEBUG - 2017-02-18 00:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 00:05:02 --> Input Class Initialized
INFO - 2017-02-18 00:05:02 --> Language Class Initialized
INFO - 2017-02-18 00:05:02 --> Loader Class Initialized
INFO - 2017-02-18 00:05:02 --> Database Driver Class Initialized
INFO - 2017-02-18 00:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 00:05:02 --> Controller Class Initialized
INFO - 2017-02-18 00:05:02 --> Helper loaded: url_helper
DEBUG - 2017-02-18 00:05:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 00:05:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 00:05:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 00:05:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 00:05:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 00:05:02 --> Final output sent to browser
DEBUG - 2017-02-18 00:05:02 --> Total execution time: 0.0137
INFO - 2017-02-18 00:05:07 --> Config Class Initialized
INFO - 2017-02-18 00:05:07 --> Hooks Class Initialized
DEBUG - 2017-02-18 00:05:07 --> UTF-8 Support Enabled
INFO - 2017-02-18 00:05:07 --> Utf8 Class Initialized
INFO - 2017-02-18 00:05:07 --> URI Class Initialized
INFO - 2017-02-18 00:05:07 --> Router Class Initialized
INFO - 2017-02-18 00:05:07 --> Output Class Initialized
INFO - 2017-02-18 00:05:07 --> Security Class Initialized
DEBUG - 2017-02-18 00:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 00:05:07 --> Input Class Initialized
INFO - 2017-02-18 00:05:07 --> Language Class Initialized
INFO - 2017-02-18 00:05:07 --> Loader Class Initialized
INFO - 2017-02-18 00:05:07 --> Database Driver Class Initialized
INFO - 2017-02-18 00:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 00:05:07 --> Controller Class Initialized
INFO - 2017-02-18 00:05:07 --> Helper loaded: url_helper
DEBUG - 2017-02-18 00:05:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 00:05:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 00:05:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 00:05:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 00:05:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 00:05:07 --> Final output sent to browser
DEBUG - 2017-02-18 00:05:07 --> Total execution time: 0.0138
INFO - 2017-02-18 00:05:52 --> Config Class Initialized
INFO - 2017-02-18 00:05:52 --> Hooks Class Initialized
DEBUG - 2017-02-18 00:05:52 --> UTF-8 Support Enabled
INFO - 2017-02-18 00:05:52 --> Utf8 Class Initialized
INFO - 2017-02-18 00:05:52 --> URI Class Initialized
INFO - 2017-02-18 00:05:52 --> Router Class Initialized
INFO - 2017-02-18 00:05:52 --> Output Class Initialized
INFO - 2017-02-18 00:05:52 --> Security Class Initialized
DEBUG - 2017-02-18 00:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 00:05:52 --> Input Class Initialized
INFO - 2017-02-18 00:05:52 --> Language Class Initialized
INFO - 2017-02-18 00:05:52 --> Loader Class Initialized
INFO - 2017-02-18 00:05:52 --> Database Driver Class Initialized
INFO - 2017-02-18 00:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 00:05:52 --> Controller Class Initialized
INFO - 2017-02-18 00:05:52 --> Helper loaded: url_helper
DEBUG - 2017-02-18 00:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 00:05:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 00:05:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 00:05:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 00:05:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 00:05:52 --> Final output sent to browser
DEBUG - 2017-02-18 00:05:52 --> Total execution time: 0.0132
INFO - 2017-02-18 00:06:01 --> Config Class Initialized
INFO - 2017-02-18 00:06:01 --> Hooks Class Initialized
DEBUG - 2017-02-18 00:06:01 --> UTF-8 Support Enabled
INFO - 2017-02-18 00:06:01 --> Utf8 Class Initialized
INFO - 2017-02-18 00:06:01 --> URI Class Initialized
INFO - 2017-02-18 00:06:01 --> Router Class Initialized
INFO - 2017-02-18 00:06:01 --> Output Class Initialized
INFO - 2017-02-18 00:06:01 --> Security Class Initialized
DEBUG - 2017-02-18 00:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 00:06:01 --> Input Class Initialized
INFO - 2017-02-18 00:06:01 --> Language Class Initialized
INFO - 2017-02-18 00:06:01 --> Loader Class Initialized
INFO - 2017-02-18 00:06:01 --> Database Driver Class Initialized
INFO - 2017-02-18 00:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 00:06:01 --> Controller Class Initialized
INFO - 2017-02-18 00:06:01 --> Helper loaded: url_helper
DEBUG - 2017-02-18 00:06:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-18 00:06:02 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-18 00:06:02 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Dulce Domiinguez')
INFO - 2017-02-18 00:06:02 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-18 00:06:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-18 00:06:03 --> Config Class Initialized
INFO - 2017-02-18 00:06:03 --> Hooks Class Initialized
DEBUG - 2017-02-18 00:06:03 --> UTF-8 Support Enabled
INFO - 2017-02-18 00:06:03 --> Utf8 Class Initialized
INFO - 2017-02-18 00:06:03 --> URI Class Initialized
INFO - 2017-02-18 00:06:03 --> Router Class Initialized
INFO - 2017-02-18 00:06:03 --> Output Class Initialized
INFO - 2017-02-18 00:06:03 --> Security Class Initialized
DEBUG - 2017-02-18 00:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 00:06:03 --> Input Class Initialized
INFO - 2017-02-18 00:06:03 --> Language Class Initialized
INFO - 2017-02-18 00:06:03 --> Loader Class Initialized
INFO - 2017-02-18 00:06:03 --> Database Driver Class Initialized
INFO - 2017-02-18 00:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 00:06:03 --> Controller Class Initialized
INFO - 2017-02-18 00:06:03 --> Helper loaded: url_helper
DEBUG - 2017-02-18 00:06:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 00:06:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 00:06:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 00:06:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 00:06:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 00:06:03 --> Final output sent to browser
DEBUG - 2017-02-18 00:06:03 --> Total execution time: 0.0140
INFO - 2017-02-18 00:06:21 --> Config Class Initialized
INFO - 2017-02-18 00:06:21 --> Hooks Class Initialized
DEBUG - 2017-02-18 00:06:21 --> UTF-8 Support Enabled
INFO - 2017-02-18 00:06:21 --> Utf8 Class Initialized
INFO - 2017-02-18 00:06:21 --> URI Class Initialized
DEBUG - 2017-02-18 00:06:21 --> No URI present. Default controller set.
INFO - 2017-02-18 00:06:21 --> Router Class Initialized
INFO - 2017-02-18 00:06:21 --> Output Class Initialized
INFO - 2017-02-18 00:06:21 --> Security Class Initialized
DEBUG - 2017-02-18 00:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 00:06:21 --> Input Class Initialized
INFO - 2017-02-18 00:06:21 --> Language Class Initialized
INFO - 2017-02-18 00:06:21 --> Loader Class Initialized
INFO - 2017-02-18 00:06:21 --> Database Driver Class Initialized
INFO - 2017-02-18 00:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 00:06:21 --> Controller Class Initialized
INFO - 2017-02-18 00:06:21 --> Helper loaded: url_helper
DEBUG - 2017-02-18 00:06:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 00:06:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 00:06:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 00:06:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 00:06:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 00:06:21 --> Final output sent to browser
DEBUG - 2017-02-18 00:06:21 --> Total execution time: 0.0513
INFO - 2017-02-18 00:06:23 --> Config Class Initialized
INFO - 2017-02-18 00:06:23 --> Hooks Class Initialized
DEBUG - 2017-02-18 00:06:23 --> UTF-8 Support Enabled
INFO - 2017-02-18 00:06:23 --> Utf8 Class Initialized
INFO - 2017-02-18 00:06:23 --> URI Class Initialized
INFO - 2017-02-18 00:06:23 --> Router Class Initialized
INFO - 2017-02-18 00:06:23 --> Output Class Initialized
INFO - 2017-02-18 00:06:23 --> Security Class Initialized
DEBUG - 2017-02-18 00:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 00:06:23 --> Input Class Initialized
INFO - 2017-02-18 00:06:23 --> Language Class Initialized
INFO - 2017-02-18 00:06:23 --> Loader Class Initialized
INFO - 2017-02-18 00:06:23 --> Database Driver Class Initialized
INFO - 2017-02-18 00:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 00:06:23 --> Controller Class Initialized
INFO - 2017-02-18 00:06:23 --> Helper loaded: url_helper
DEBUG - 2017-02-18 00:06:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 00:06:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 00:06:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 00:06:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 00:06:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 00:06:23 --> Final output sent to browser
DEBUG - 2017-02-18 00:06:23 --> Total execution time: 0.0434
INFO - 2017-02-18 00:15:07 --> Config Class Initialized
INFO - 2017-02-18 00:15:07 --> Hooks Class Initialized
DEBUG - 2017-02-18 00:15:07 --> UTF-8 Support Enabled
INFO - 2017-02-18 00:15:07 --> Utf8 Class Initialized
INFO - 2017-02-18 00:15:07 --> URI Class Initialized
INFO - 2017-02-18 00:15:07 --> Router Class Initialized
INFO - 2017-02-18 00:15:07 --> Output Class Initialized
INFO - 2017-02-18 00:15:07 --> Security Class Initialized
DEBUG - 2017-02-18 00:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 00:15:07 --> Input Class Initialized
INFO - 2017-02-18 00:15:07 --> Language Class Initialized
INFO - 2017-02-18 00:15:07 --> Loader Class Initialized
INFO - 2017-02-18 00:15:07 --> Database Driver Class Initialized
INFO - 2017-02-18 00:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 00:15:07 --> Controller Class Initialized
INFO - 2017-02-18 00:15:07 --> Helper loaded: date_helper
DEBUG - 2017-02-18 00:15:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 00:15:07 --> Helper loaded: url_helper
INFO - 2017-02-18 00:15:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 00:15:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-18 00:15:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-18 00:15:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-18 00:15:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 00:15:07 --> Final output sent to browser
DEBUG - 2017-02-18 00:15:07 --> Total execution time: 0.0142
INFO - 2017-02-18 01:19:53 --> Config Class Initialized
INFO - 2017-02-18 01:19:53 --> Hooks Class Initialized
DEBUG - 2017-02-18 01:19:53 --> UTF-8 Support Enabled
INFO - 2017-02-18 01:19:53 --> Utf8 Class Initialized
INFO - 2017-02-18 01:19:53 --> URI Class Initialized
INFO - 2017-02-18 01:19:53 --> Router Class Initialized
INFO - 2017-02-18 01:19:53 --> Output Class Initialized
INFO - 2017-02-18 01:19:53 --> Security Class Initialized
DEBUG - 2017-02-18 01:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 01:19:53 --> Input Class Initialized
INFO - 2017-02-18 01:19:53 --> Language Class Initialized
INFO - 2017-02-18 01:19:53 --> Loader Class Initialized
INFO - 2017-02-18 01:19:53 --> Database Driver Class Initialized
INFO - 2017-02-18 01:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 01:19:53 --> Controller Class Initialized
INFO - 2017-02-18 01:19:53 --> Helper loaded: date_helper
DEBUG - 2017-02-18 01:19:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 01:19:53 --> Helper loaded: url_helper
INFO - 2017-02-18 01:19:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 01:19:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-18 01:19:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-18 01:19:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-18 01:19:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 01:19:53 --> Final output sent to browser
DEBUG - 2017-02-18 01:19:53 --> Total execution time: 0.0139
INFO - 2017-02-18 03:02:28 --> Config Class Initialized
INFO - 2017-02-18 03:02:28 --> Hooks Class Initialized
DEBUG - 2017-02-18 03:02:28 --> UTF-8 Support Enabled
INFO - 2017-02-18 03:02:28 --> Utf8 Class Initialized
INFO - 2017-02-18 03:02:28 --> URI Class Initialized
INFO - 2017-02-18 03:02:28 --> Router Class Initialized
INFO - 2017-02-18 03:02:28 --> Output Class Initialized
INFO - 2017-02-18 03:02:28 --> Security Class Initialized
DEBUG - 2017-02-18 03:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 03:02:28 --> Input Class Initialized
INFO - 2017-02-18 03:02:28 --> Language Class Initialized
INFO - 2017-02-18 03:02:28 --> Loader Class Initialized
INFO - 2017-02-18 03:02:28 --> Database Driver Class Initialized
INFO - 2017-02-18 03:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 03:02:28 --> Controller Class Initialized
INFO - 2017-02-18 03:02:28 --> Helper loaded: url_helper
DEBUG - 2017-02-18 03:02:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 03:02:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 03:02:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 03:02:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 03:02:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 03:02:28 --> Final output sent to browser
DEBUG - 2017-02-18 03:02:28 --> Total execution time: 0.0200
INFO - 2017-02-18 03:02:28 --> Config Class Initialized
INFO - 2017-02-18 03:02:28 --> Hooks Class Initialized
DEBUG - 2017-02-18 03:02:28 --> UTF-8 Support Enabled
INFO - 2017-02-18 03:02:28 --> Utf8 Class Initialized
INFO - 2017-02-18 03:02:28 --> URI Class Initialized
DEBUG - 2017-02-18 03:02:28 --> No URI present. Default controller set.
INFO - 2017-02-18 03:02:28 --> Router Class Initialized
INFO - 2017-02-18 03:02:28 --> Output Class Initialized
INFO - 2017-02-18 03:02:28 --> Security Class Initialized
DEBUG - 2017-02-18 03:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 03:02:28 --> Input Class Initialized
INFO - 2017-02-18 03:02:28 --> Language Class Initialized
INFO - 2017-02-18 03:02:28 --> Loader Class Initialized
INFO - 2017-02-18 03:02:28 --> Database Driver Class Initialized
INFO - 2017-02-18 03:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 03:02:28 --> Controller Class Initialized
INFO - 2017-02-18 03:02:28 --> Helper loaded: url_helper
DEBUG - 2017-02-18 03:02:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 03:02:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 03:02:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 03:02:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 03:02:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 03:02:28 --> Final output sent to browser
DEBUG - 2017-02-18 03:02:28 --> Total execution time: 0.0133
INFO - 2017-02-18 03:50:42 --> Config Class Initialized
INFO - 2017-02-18 03:50:42 --> Hooks Class Initialized
DEBUG - 2017-02-18 03:50:42 --> UTF-8 Support Enabled
INFO - 2017-02-18 03:50:42 --> Utf8 Class Initialized
INFO - 2017-02-18 03:50:42 --> URI Class Initialized
INFO - 2017-02-18 03:50:42 --> Router Class Initialized
INFO - 2017-02-18 03:50:42 --> Output Class Initialized
INFO - 2017-02-18 03:50:42 --> Security Class Initialized
DEBUG - 2017-02-18 03:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 03:50:42 --> Input Class Initialized
INFO - 2017-02-18 03:50:42 --> Language Class Initialized
INFO - 2017-02-18 03:50:42 --> Loader Class Initialized
INFO - 2017-02-18 03:50:42 --> Database Driver Class Initialized
INFO - 2017-02-18 03:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 03:50:42 --> Controller Class Initialized
INFO - 2017-02-18 03:50:42 --> Helper loaded: url_helper
DEBUG - 2017-02-18 03:50:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 03:50:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 03:50:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 03:50:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 03:50:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 03:50:42 --> Final output sent to browser
DEBUG - 2017-02-18 03:50:42 --> Total execution time: 0.0135
INFO - 2017-02-18 03:50:42 --> Config Class Initialized
INFO - 2017-02-18 03:50:42 --> Hooks Class Initialized
DEBUG - 2017-02-18 03:50:42 --> UTF-8 Support Enabled
INFO - 2017-02-18 03:50:42 --> Utf8 Class Initialized
INFO - 2017-02-18 03:50:42 --> URI Class Initialized
DEBUG - 2017-02-18 03:50:42 --> No URI present. Default controller set.
INFO - 2017-02-18 03:50:42 --> Router Class Initialized
INFO - 2017-02-18 03:50:42 --> Output Class Initialized
INFO - 2017-02-18 03:50:42 --> Security Class Initialized
DEBUG - 2017-02-18 03:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 03:50:42 --> Input Class Initialized
INFO - 2017-02-18 03:50:42 --> Language Class Initialized
INFO - 2017-02-18 03:50:42 --> Loader Class Initialized
INFO - 2017-02-18 03:50:42 --> Database Driver Class Initialized
INFO - 2017-02-18 03:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 03:50:42 --> Controller Class Initialized
INFO - 2017-02-18 03:50:42 --> Helper loaded: url_helper
DEBUG - 2017-02-18 03:50:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 03:50:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 03:50:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 03:50:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 03:50:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 03:50:42 --> Final output sent to browser
DEBUG - 2017-02-18 03:50:42 --> Total execution time: 0.0132
INFO - 2017-02-18 04:48:22 --> Config Class Initialized
INFO - 2017-02-18 04:48:22 --> Hooks Class Initialized
DEBUG - 2017-02-18 04:48:22 --> UTF-8 Support Enabled
INFO - 2017-02-18 04:48:22 --> Utf8 Class Initialized
INFO - 2017-02-18 04:48:22 --> URI Class Initialized
INFO - 2017-02-18 04:48:22 --> Router Class Initialized
INFO - 2017-02-18 04:48:22 --> Output Class Initialized
INFO - 2017-02-18 04:48:22 --> Security Class Initialized
DEBUG - 2017-02-18 04:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 04:48:22 --> Input Class Initialized
INFO - 2017-02-18 04:48:22 --> Language Class Initialized
INFO - 2017-02-18 04:48:22 --> Loader Class Initialized
INFO - 2017-02-18 04:48:22 --> Database Driver Class Initialized
INFO - 2017-02-18 04:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 04:48:22 --> Controller Class Initialized
INFO - 2017-02-18 04:48:22 --> Helper loaded: date_helper
DEBUG - 2017-02-18 04:48:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 04:48:22 --> Helper loaded: url_helper
INFO - 2017-02-18 04:48:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 04:48:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-18 04:48:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-18 04:48:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-18 04:48:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 04:48:22 --> Final output sent to browser
DEBUG - 2017-02-18 04:48:22 --> Total execution time: 0.0141
INFO - 2017-02-18 04:48:32 --> Config Class Initialized
INFO - 2017-02-18 04:48:32 --> Hooks Class Initialized
DEBUG - 2017-02-18 04:48:32 --> UTF-8 Support Enabled
INFO - 2017-02-18 04:48:32 --> Utf8 Class Initialized
INFO - 2017-02-18 04:48:32 --> URI Class Initialized
INFO - 2017-02-18 04:48:32 --> Router Class Initialized
INFO - 2017-02-18 04:48:32 --> Output Class Initialized
INFO - 2017-02-18 04:48:32 --> Security Class Initialized
DEBUG - 2017-02-18 04:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 04:48:32 --> Input Class Initialized
INFO - 2017-02-18 04:48:32 --> Language Class Initialized
INFO - 2017-02-18 04:48:32 --> Loader Class Initialized
INFO - 2017-02-18 04:48:32 --> Database Driver Class Initialized
INFO - 2017-02-18 04:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 04:48:32 --> Controller Class Initialized
INFO - 2017-02-18 04:48:32 --> Helper loaded: url_helper
DEBUG - 2017-02-18 04:48:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 04:48:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 04:48:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 04:48:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 04:48:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 04:48:32 --> Final output sent to browser
DEBUG - 2017-02-18 04:48:32 --> Total execution time: 0.0131
INFO - 2017-02-18 06:39:20 --> Config Class Initialized
INFO - 2017-02-18 06:39:20 --> Hooks Class Initialized
DEBUG - 2017-02-18 06:39:20 --> UTF-8 Support Enabled
INFO - 2017-02-18 06:39:20 --> Utf8 Class Initialized
INFO - 2017-02-18 06:39:20 --> URI Class Initialized
DEBUG - 2017-02-18 06:39:20 --> No URI present. Default controller set.
INFO - 2017-02-18 06:39:20 --> Router Class Initialized
INFO - 2017-02-18 06:39:20 --> Output Class Initialized
INFO - 2017-02-18 06:39:20 --> Security Class Initialized
DEBUG - 2017-02-18 06:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 06:39:20 --> Input Class Initialized
INFO - 2017-02-18 06:39:20 --> Language Class Initialized
INFO - 2017-02-18 06:39:20 --> Loader Class Initialized
INFO - 2017-02-18 06:39:21 --> Database Driver Class Initialized
INFO - 2017-02-18 06:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 06:39:21 --> Controller Class Initialized
INFO - 2017-02-18 06:39:21 --> Helper loaded: url_helper
DEBUG - 2017-02-18 06:39:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 06:39:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 06:39:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 06:39:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 06:39:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 06:39:21 --> Final output sent to browser
DEBUG - 2017-02-18 06:39:21 --> Total execution time: 1.2989
INFO - 2017-02-18 06:51:37 --> Config Class Initialized
INFO - 2017-02-18 06:51:37 --> Hooks Class Initialized
DEBUG - 2017-02-18 06:51:37 --> UTF-8 Support Enabled
INFO - 2017-02-18 06:51:37 --> Utf8 Class Initialized
INFO - 2017-02-18 06:51:37 --> URI Class Initialized
DEBUG - 2017-02-18 06:51:37 --> No URI present. Default controller set.
INFO - 2017-02-18 06:51:37 --> Router Class Initialized
INFO - 2017-02-18 06:51:37 --> Output Class Initialized
INFO - 2017-02-18 06:51:37 --> Security Class Initialized
DEBUG - 2017-02-18 06:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 06:51:37 --> Input Class Initialized
INFO - 2017-02-18 06:51:37 --> Language Class Initialized
INFO - 2017-02-18 06:51:37 --> Loader Class Initialized
INFO - 2017-02-18 06:51:38 --> Database Driver Class Initialized
INFO - 2017-02-18 06:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 06:51:38 --> Controller Class Initialized
INFO - 2017-02-18 06:51:38 --> Helper loaded: url_helper
DEBUG - 2017-02-18 06:51:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 06:51:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 06:51:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 06:51:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 06:51:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 06:51:38 --> Final output sent to browser
DEBUG - 2017-02-18 06:51:38 --> Total execution time: 1.1761
INFO - 2017-02-18 09:46:27 --> Config Class Initialized
INFO - 2017-02-18 09:46:27 --> Hooks Class Initialized
DEBUG - 2017-02-18 09:46:27 --> UTF-8 Support Enabled
INFO - 2017-02-18 09:46:27 --> Utf8 Class Initialized
INFO - 2017-02-18 09:46:27 --> URI Class Initialized
DEBUG - 2017-02-18 09:46:27 --> No URI present. Default controller set.
INFO - 2017-02-18 09:46:27 --> Router Class Initialized
INFO - 2017-02-18 09:46:27 --> Output Class Initialized
INFO - 2017-02-18 09:46:27 --> Security Class Initialized
DEBUG - 2017-02-18 09:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 09:46:27 --> Input Class Initialized
INFO - 2017-02-18 09:46:27 --> Language Class Initialized
INFO - 2017-02-18 09:46:28 --> Loader Class Initialized
INFO - 2017-02-18 09:46:28 --> Database Driver Class Initialized
INFO - 2017-02-18 09:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 09:46:28 --> Controller Class Initialized
INFO - 2017-02-18 09:46:28 --> Helper loaded: url_helper
DEBUG - 2017-02-18 09:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 09:46:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 09:46:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 09:46:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 09:46:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 09:46:28 --> Final output sent to browser
DEBUG - 2017-02-18 09:46:28 --> Total execution time: 1.1601
INFO - 2017-02-18 09:46:31 --> Config Class Initialized
INFO - 2017-02-18 09:46:31 --> Hooks Class Initialized
DEBUG - 2017-02-18 09:46:31 --> UTF-8 Support Enabled
INFO - 2017-02-18 09:46:31 --> Utf8 Class Initialized
INFO - 2017-02-18 09:46:31 --> URI Class Initialized
INFO - 2017-02-18 09:46:31 --> Router Class Initialized
INFO - 2017-02-18 09:46:31 --> Output Class Initialized
INFO - 2017-02-18 09:46:31 --> Security Class Initialized
DEBUG - 2017-02-18 09:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 09:46:31 --> Input Class Initialized
INFO - 2017-02-18 09:46:31 --> Language Class Initialized
INFO - 2017-02-18 09:46:31 --> Loader Class Initialized
INFO - 2017-02-18 09:46:32 --> Database Driver Class Initialized
INFO - 2017-02-18 09:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 09:46:32 --> Controller Class Initialized
INFO - 2017-02-18 09:46:32 --> Helper loaded: url_helper
DEBUG - 2017-02-18 09:46:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 09:46:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 09:46:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 09:46:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 09:46:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 09:46:32 --> Final output sent to browser
DEBUG - 2017-02-18 09:46:32 --> Total execution time: 0.7351
INFO - 2017-02-18 16:00:07 --> Config Class Initialized
INFO - 2017-02-18 16:00:07 --> Hooks Class Initialized
DEBUG - 2017-02-18 16:00:07 --> UTF-8 Support Enabled
INFO - 2017-02-18 16:00:07 --> Utf8 Class Initialized
INFO - 2017-02-18 16:00:07 --> URI Class Initialized
INFO - 2017-02-18 16:00:07 --> Router Class Initialized
INFO - 2017-02-18 16:00:07 --> Output Class Initialized
INFO - 2017-02-18 16:00:07 --> Security Class Initialized
DEBUG - 2017-02-18 16:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 16:00:07 --> Input Class Initialized
INFO - 2017-02-18 16:00:07 --> Language Class Initialized
INFO - 2017-02-18 16:00:07 --> Loader Class Initialized
INFO - 2017-02-18 16:00:08 --> Database Driver Class Initialized
INFO - 2017-02-18 16:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 16:00:08 --> Controller Class Initialized
INFO - 2017-02-18 16:00:08 --> Helper loaded: url_helper
DEBUG - 2017-02-18 16:00:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 16:00:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 16:00:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 16:00:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 16:00:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 16:00:09 --> Final output sent to browser
DEBUG - 2017-02-18 16:00:09 --> Total execution time: 1.8275
INFO - 2017-02-18 16:00:09 --> Config Class Initialized
INFO - 2017-02-18 16:00:09 --> Hooks Class Initialized
DEBUG - 2017-02-18 16:00:09 --> UTF-8 Support Enabled
INFO - 2017-02-18 16:00:09 --> Utf8 Class Initialized
INFO - 2017-02-18 16:00:09 --> URI Class Initialized
INFO - 2017-02-18 16:00:09 --> Router Class Initialized
INFO - 2017-02-18 16:00:09 --> Output Class Initialized
INFO - 2017-02-18 16:00:09 --> Security Class Initialized
DEBUG - 2017-02-18 16:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 16:00:09 --> Input Class Initialized
INFO - 2017-02-18 16:00:09 --> Language Class Initialized
INFO - 2017-02-18 16:00:09 --> Loader Class Initialized
INFO - 2017-02-18 16:00:09 --> Database Driver Class Initialized
INFO - 2017-02-18 16:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 16:00:09 --> Controller Class Initialized
INFO - 2017-02-18 16:00:09 --> Helper loaded: url_helper
DEBUG - 2017-02-18 16:00:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 16:00:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 16:00:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 16:00:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 16:00:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 16:00:09 --> Final output sent to browser
DEBUG - 2017-02-18 16:00:09 --> Total execution time: 0.0143
INFO - 2017-02-18 18:23:51 --> Config Class Initialized
INFO - 2017-02-18 18:23:51 --> Hooks Class Initialized
DEBUG - 2017-02-18 18:23:51 --> UTF-8 Support Enabled
INFO - 2017-02-18 18:23:51 --> Utf8 Class Initialized
INFO - 2017-02-18 18:23:51 --> URI Class Initialized
INFO - 2017-02-18 18:23:52 --> Router Class Initialized
INFO - 2017-02-18 18:23:52 --> Output Class Initialized
INFO - 2017-02-18 18:23:52 --> Security Class Initialized
DEBUG - 2017-02-18 18:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 18:23:52 --> Input Class Initialized
INFO - 2017-02-18 18:23:52 --> Language Class Initialized
INFO - 2017-02-18 18:23:52 --> Loader Class Initialized
INFO - 2017-02-18 18:23:52 --> Database Driver Class Initialized
INFO - 2017-02-18 18:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 18:23:53 --> Controller Class Initialized
INFO - 2017-02-18 18:23:53 --> Helper loaded: url_helper
DEBUG - 2017-02-18 18:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 18:23:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 18:23:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 18:23:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 18:23:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 18:23:53 --> Final output sent to browser
DEBUG - 2017-02-18 18:23:53 --> Total execution time: 1.8521
INFO - 2017-02-18 20:34:53 --> Config Class Initialized
INFO - 2017-02-18 20:34:53 --> Hooks Class Initialized
DEBUG - 2017-02-18 20:34:53 --> UTF-8 Support Enabled
INFO - 2017-02-18 20:34:53 --> Utf8 Class Initialized
INFO - 2017-02-18 20:34:53 --> URI Class Initialized
INFO - 2017-02-18 20:34:53 --> Router Class Initialized
INFO - 2017-02-18 20:34:53 --> Output Class Initialized
INFO - 2017-02-18 20:34:53 --> Security Class Initialized
DEBUG - 2017-02-18 20:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 20:34:53 --> Input Class Initialized
INFO - 2017-02-18 20:34:53 --> Language Class Initialized
INFO - 2017-02-18 20:34:53 --> Loader Class Initialized
INFO - 2017-02-18 20:34:53 --> Database Driver Class Initialized
INFO - 2017-02-18 20:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 20:34:53 --> Controller Class Initialized
INFO - 2017-02-18 20:34:53 --> Helper loaded: date_helper
DEBUG - 2017-02-18 20:34:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 20:34:53 --> Helper loaded: url_helper
INFO - 2017-02-18 20:34:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 20:34:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-18 20:34:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-18 20:34:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-18 20:34:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 20:34:53 --> Final output sent to browser
DEBUG - 2017-02-18 20:34:53 --> Total execution time: 0.3278
INFO - 2017-02-18 20:34:59 --> Config Class Initialized
INFO - 2017-02-18 20:34:59 --> Hooks Class Initialized
DEBUG - 2017-02-18 20:34:59 --> UTF-8 Support Enabled
INFO - 2017-02-18 20:34:59 --> Utf8 Class Initialized
INFO - 2017-02-18 20:34:59 --> URI Class Initialized
INFO - 2017-02-18 20:34:59 --> Router Class Initialized
INFO - 2017-02-18 20:34:59 --> Output Class Initialized
INFO - 2017-02-18 20:34:59 --> Security Class Initialized
DEBUG - 2017-02-18 20:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 20:34:59 --> Input Class Initialized
INFO - 2017-02-18 20:34:59 --> Language Class Initialized
INFO - 2017-02-18 20:34:59 --> Loader Class Initialized
INFO - 2017-02-18 20:34:59 --> Database Driver Class Initialized
INFO - 2017-02-18 20:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 20:34:59 --> Controller Class Initialized
INFO - 2017-02-18 20:34:59 --> Helper loaded: url_helper
DEBUG - 2017-02-18 20:34:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 20:34:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 20:34:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 20:34:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 20:34:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 20:34:59 --> Final output sent to browser
DEBUG - 2017-02-18 20:34:59 --> Total execution time: 0.0130
INFO - 2017-02-18 20:41:07 --> Config Class Initialized
INFO - 2017-02-18 20:41:07 --> Hooks Class Initialized
DEBUG - 2017-02-18 20:41:07 --> UTF-8 Support Enabled
INFO - 2017-02-18 20:41:07 --> Utf8 Class Initialized
INFO - 2017-02-18 20:41:07 --> URI Class Initialized
INFO - 2017-02-18 20:41:07 --> Router Class Initialized
INFO - 2017-02-18 20:41:07 --> Output Class Initialized
INFO - 2017-02-18 20:41:07 --> Security Class Initialized
DEBUG - 2017-02-18 20:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 20:41:07 --> Input Class Initialized
INFO - 2017-02-18 20:41:07 --> Language Class Initialized
INFO - 2017-02-18 20:41:07 --> Loader Class Initialized
INFO - 2017-02-18 20:41:07 --> Database Driver Class Initialized
INFO - 2017-02-18 20:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 20:41:07 --> Controller Class Initialized
INFO - 2017-02-18 20:41:07 --> Helper loaded: url_helper
DEBUG - 2017-02-18 20:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 20:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 20:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 20:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 20:41:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 20:41:07 --> Final output sent to browser
DEBUG - 2017-02-18 20:41:07 --> Total execution time: 0.0135
INFO - 2017-02-18 22:06:26 --> Config Class Initialized
INFO - 2017-02-18 22:06:26 --> Hooks Class Initialized
DEBUG - 2017-02-18 22:06:26 --> UTF-8 Support Enabled
INFO - 2017-02-18 22:06:26 --> Utf8 Class Initialized
INFO - 2017-02-18 22:06:26 --> URI Class Initialized
INFO - 2017-02-18 22:06:26 --> Router Class Initialized
INFO - 2017-02-18 22:06:26 --> Output Class Initialized
INFO - 2017-02-18 22:06:26 --> Security Class Initialized
DEBUG - 2017-02-18 22:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 22:06:26 --> Input Class Initialized
INFO - 2017-02-18 22:06:26 --> Language Class Initialized
INFO - 2017-02-18 22:06:26 --> Loader Class Initialized
INFO - 2017-02-18 22:06:26 --> Database Driver Class Initialized
INFO - 2017-02-18 22:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 22:06:26 --> Controller Class Initialized
INFO - 2017-02-18 22:06:26 --> Helper loaded: url_helper
DEBUG - 2017-02-18 22:06:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 22:06:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 22:06:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 22:06:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 22:06:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 22:06:26 --> Final output sent to browser
DEBUG - 2017-02-18 22:06:26 --> Total execution time: 0.0264
INFO - 2017-02-18 22:53:25 --> Config Class Initialized
INFO - 2017-02-18 22:53:25 --> Hooks Class Initialized
DEBUG - 2017-02-18 22:53:25 --> UTF-8 Support Enabled
INFO - 2017-02-18 22:53:25 --> Utf8 Class Initialized
INFO - 2017-02-18 22:53:25 --> URI Class Initialized
DEBUG - 2017-02-18 22:53:25 --> No URI present. Default controller set.
INFO - 2017-02-18 22:53:25 --> Router Class Initialized
INFO - 2017-02-18 22:53:25 --> Output Class Initialized
INFO - 2017-02-18 22:53:25 --> Security Class Initialized
DEBUG - 2017-02-18 22:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 22:53:25 --> Input Class Initialized
INFO - 2017-02-18 22:53:25 --> Language Class Initialized
INFO - 2017-02-18 22:53:25 --> Loader Class Initialized
INFO - 2017-02-18 22:53:25 --> Database Driver Class Initialized
INFO - 2017-02-18 22:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 22:53:25 --> Controller Class Initialized
INFO - 2017-02-18 22:53:25 --> Helper loaded: url_helper
DEBUG - 2017-02-18 22:53:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 22:53:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 22:53:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 22:53:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 22:53:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 22:53:25 --> Final output sent to browser
DEBUG - 2017-02-18 22:53:25 --> Total execution time: 0.0132
INFO - 2017-02-18 23:19:01 --> Config Class Initialized
INFO - 2017-02-18 23:19:01 --> Hooks Class Initialized
DEBUG - 2017-02-18 23:19:01 --> UTF-8 Support Enabled
INFO - 2017-02-18 23:19:01 --> Utf8 Class Initialized
INFO - 2017-02-18 23:19:01 --> URI Class Initialized
INFO - 2017-02-18 23:19:01 --> Router Class Initialized
INFO - 2017-02-18 23:19:01 --> Output Class Initialized
INFO - 2017-02-18 23:19:01 --> Security Class Initialized
DEBUG - 2017-02-18 23:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 23:19:01 --> Input Class Initialized
INFO - 2017-02-18 23:19:01 --> Language Class Initialized
INFO - 2017-02-18 23:19:01 --> Loader Class Initialized
INFO - 2017-02-18 23:19:01 --> Database Driver Class Initialized
INFO - 2017-02-18 23:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 23:19:01 --> Controller Class Initialized
INFO - 2017-02-18 23:19:01 --> Helper loaded: url_helper
DEBUG - 2017-02-18 23:19:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 23:19:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 23:19:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 23:19:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 23:19:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 23:19:01 --> Final output sent to browser
DEBUG - 2017-02-18 23:19:01 --> Total execution time: 0.0172
INFO - 2017-02-18 23:51:50 --> Config Class Initialized
INFO - 2017-02-18 23:51:50 --> Hooks Class Initialized
DEBUG - 2017-02-18 23:51:50 --> UTF-8 Support Enabled
INFO - 2017-02-18 23:51:50 --> Utf8 Class Initialized
INFO - 2017-02-18 23:51:50 --> URI Class Initialized
DEBUG - 2017-02-18 23:51:50 --> No URI present. Default controller set.
INFO - 2017-02-18 23:51:50 --> Router Class Initialized
INFO - 2017-02-18 23:51:50 --> Output Class Initialized
INFO - 2017-02-18 23:51:50 --> Security Class Initialized
DEBUG - 2017-02-18 23:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 23:51:50 --> Input Class Initialized
INFO - 2017-02-18 23:51:50 --> Language Class Initialized
INFO - 2017-02-18 23:51:50 --> Loader Class Initialized
INFO - 2017-02-18 23:51:50 --> Database Driver Class Initialized
INFO - 2017-02-18 23:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 23:51:50 --> Controller Class Initialized
INFO - 2017-02-18 23:51:50 --> Helper loaded: url_helper
DEBUG - 2017-02-18 23:51:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-18 23:51:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-18 23:51:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-18 23:51:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-18 23:51:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-18 23:51:50 --> Final output sent to browser
DEBUG - 2017-02-18 23:51:50 --> Total execution time: 0.0132

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-23 14:35:37 --> Config Class Initialized
INFO - 2016-12-23 14:35:37 --> Hooks Class Initialized
DEBUG - 2016-12-23 14:35:37 --> UTF-8 Support Enabled
INFO - 2016-12-23 14:35:37 --> Utf8 Class Initialized
INFO - 2016-12-23 14:35:37 --> URI Class Initialized
INFO - 2016-12-23 14:35:37 --> Router Class Initialized
INFO - 2016-12-23 14:35:37 --> Output Class Initialized
INFO - 2016-12-23 14:35:37 --> Security Class Initialized
DEBUG - 2016-12-23 14:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-23 14:35:37 --> Input Class Initialized
INFO - 2016-12-23 14:35:37 --> Language Class Initialized
INFO - 2016-12-23 14:35:38 --> Loader Class Initialized
INFO - 2016-12-23 14:35:38 --> Database Driver Class Initialized
INFO - 2016-12-23 14:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-23 14:35:38 --> Controller Class Initialized
INFO - 2016-12-23 14:35:38 --> Helper loaded: url_helper
DEBUG - 2016-12-23 14:35:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-23 14:35:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-23 14:35:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-23 14:35:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-23 14:35:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-23 14:35:39 --> Final output sent to browser
DEBUG - 2016-12-23 14:35:39 --> Total execution time: 1.7227
INFO - 2016-12-23 15:42:05 --> Config Class Initialized
INFO - 2016-12-23 15:42:05 --> Hooks Class Initialized
DEBUG - 2016-12-23 15:42:05 --> UTF-8 Support Enabled
INFO - 2016-12-23 15:42:05 --> Utf8 Class Initialized
INFO - 2016-12-23 15:42:05 --> URI Class Initialized
DEBUG - 2016-12-23 15:42:05 --> No URI present. Default controller set.
INFO - 2016-12-23 15:42:05 --> Router Class Initialized
INFO - 2016-12-23 15:42:05 --> Output Class Initialized
INFO - 2016-12-23 15:42:05 --> Security Class Initialized
DEBUG - 2016-12-23 15:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-23 15:42:05 --> Input Class Initialized
INFO - 2016-12-23 15:42:05 --> Language Class Initialized
INFO - 2016-12-23 15:42:05 --> Loader Class Initialized
INFO - 2016-12-23 15:42:06 --> Database Driver Class Initialized
INFO - 2016-12-23 15:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-23 15:42:06 --> Controller Class Initialized
INFO - 2016-12-23 15:42:06 --> Helper loaded: url_helper
DEBUG - 2016-12-23 15:42:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-23 15:42:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-23 15:42:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-23 15:42:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-23 15:42:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-23 15:42:06 --> Final output sent to browser
DEBUG - 2016-12-23 15:42:06 --> Total execution time: 1.6510
INFO - 2016-12-23 15:42:15 --> Config Class Initialized
INFO - 2016-12-23 15:42:15 --> Hooks Class Initialized
DEBUG - 2016-12-23 15:42:15 --> UTF-8 Support Enabled
INFO - 2016-12-23 15:42:15 --> Utf8 Class Initialized
INFO - 2016-12-23 15:42:15 --> URI Class Initialized
INFO - 2016-12-23 15:42:15 --> Router Class Initialized
INFO - 2016-12-23 15:42:15 --> Output Class Initialized
INFO - 2016-12-23 15:42:15 --> Security Class Initialized
DEBUG - 2016-12-23 15:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-23 15:42:15 --> Input Class Initialized
INFO - 2016-12-23 15:42:15 --> Language Class Initialized
INFO - 2016-12-23 15:42:15 --> Loader Class Initialized
INFO - 2016-12-23 15:42:15 --> Database Driver Class Initialized
INFO - 2016-12-23 15:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-23 15:42:15 --> Controller Class Initialized
INFO - 2016-12-23 15:42:15 --> Helper loaded: url_helper
DEBUG - 2016-12-23 15:42:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-23 15:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-23 15:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-23 15:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-23 15:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-23 15:42:15 --> Final output sent to browser
DEBUG - 2016-12-23 15:42:15 --> Total execution time: 0.0144
INFO - 2016-12-23 23:07:43 --> Config Class Initialized
INFO - 2016-12-23 23:07:43 --> Hooks Class Initialized
DEBUG - 2016-12-23 23:07:43 --> UTF-8 Support Enabled
INFO - 2016-12-23 23:07:43 --> Utf8 Class Initialized
INFO - 2016-12-23 23:07:43 --> URI Class Initialized
DEBUG - 2016-12-23 23:07:43 --> No URI present. Default controller set.
INFO - 2016-12-23 23:07:43 --> Router Class Initialized
INFO - 2016-12-23 23:07:43 --> Output Class Initialized
INFO - 2016-12-23 23:07:43 --> Security Class Initialized
DEBUG - 2016-12-23 23:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-23 23:07:43 --> Input Class Initialized
INFO - 2016-12-23 23:07:43 --> Language Class Initialized
INFO - 2016-12-23 23:07:43 --> Loader Class Initialized
INFO - 2016-12-23 23:07:44 --> Database Driver Class Initialized
INFO - 2016-12-23 23:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-23 23:07:44 --> Controller Class Initialized
INFO - 2016-12-23 23:07:44 --> Helper loaded: url_helper
DEBUG - 2016-12-23 23:07:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-23 23:07:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-23 23:07:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-23 23:07:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-23 23:07:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-23 23:07:45 --> Final output sent to browser
DEBUG - 2016-12-23 23:07:45 --> Total execution time: 1.8857
INFO - 2016-12-23 23:10:35 --> Config Class Initialized
INFO - 2016-12-23 23:10:35 --> Hooks Class Initialized
DEBUG - 2016-12-23 23:10:35 --> UTF-8 Support Enabled
INFO - 2016-12-23 23:10:35 --> Utf8 Class Initialized
INFO - 2016-12-23 23:10:35 --> URI Class Initialized
DEBUG - 2016-12-23 23:10:35 --> No URI present. Default controller set.
INFO - 2016-12-23 23:10:35 --> Router Class Initialized
INFO - 2016-12-23 23:10:35 --> Output Class Initialized
INFO - 2016-12-23 23:10:35 --> Security Class Initialized
DEBUG - 2016-12-23 23:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-23 23:10:35 --> Input Class Initialized
INFO - 2016-12-23 23:10:35 --> Language Class Initialized
INFO - 2016-12-23 23:10:35 --> Loader Class Initialized
INFO - 2016-12-23 23:10:35 --> Database Driver Class Initialized
INFO - 2016-12-23 23:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-23 23:10:35 --> Controller Class Initialized
INFO - 2016-12-23 23:10:35 --> Helper loaded: url_helper
DEBUG - 2016-12-23 23:10:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-23 23:10:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-23 23:10:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-23 23:10:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-23 23:10:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-23 23:10:35 --> Final output sent to browser
DEBUG - 2016-12-23 23:10:35 --> Total execution time: 0.0294
INFO - 2016-12-23 23:10:37 --> Config Class Initialized
INFO - 2016-12-23 23:10:37 --> Hooks Class Initialized
DEBUG - 2016-12-23 23:10:37 --> UTF-8 Support Enabled
INFO - 2016-12-23 23:10:37 --> Utf8 Class Initialized
INFO - 2016-12-23 23:10:37 --> URI Class Initialized
INFO - 2016-12-23 23:10:37 --> Router Class Initialized
INFO - 2016-12-23 23:10:37 --> Output Class Initialized
INFO - 2016-12-23 23:10:37 --> Security Class Initialized
DEBUG - 2016-12-23 23:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-23 23:10:37 --> Input Class Initialized
INFO - 2016-12-23 23:10:37 --> Language Class Initialized
INFO - 2016-12-23 23:10:37 --> Loader Class Initialized
INFO - 2016-12-23 23:10:37 --> Database Driver Class Initialized
INFO - 2016-12-23 23:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-23 23:10:37 --> Controller Class Initialized
INFO - 2016-12-23 23:10:37 --> Helper loaded: url_helper
DEBUG - 2016-12-23 23:10:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-23 23:10:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-23 23:10:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-23 23:10:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-23 23:10:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-23 23:10:37 --> Final output sent to browser
DEBUG - 2016-12-23 23:10:37 --> Total execution time: 0.0145
INFO - 2016-12-23 23:40:14 --> Config Class Initialized
INFO - 2016-12-23 23:40:14 --> Hooks Class Initialized
DEBUG - 2016-12-23 23:40:14 --> UTF-8 Support Enabled
INFO - 2016-12-23 23:40:14 --> Utf8 Class Initialized
INFO - 2016-12-23 23:40:14 --> URI Class Initialized
INFO - 2016-12-23 23:40:14 --> Router Class Initialized
INFO - 2016-12-23 23:40:14 --> Output Class Initialized
INFO - 2016-12-23 23:40:14 --> Security Class Initialized
DEBUG - 2016-12-23 23:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-23 23:40:14 --> Input Class Initialized
INFO - 2016-12-23 23:40:14 --> Language Class Initialized
INFO - 2016-12-23 23:40:14 --> Loader Class Initialized
INFO - 2016-12-23 23:40:14 --> Database Driver Class Initialized
INFO - 2016-12-23 23:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-23 23:40:14 --> Controller Class Initialized
INFO - 2016-12-23 23:40:14 --> Helper loaded: url_helper
DEBUG - 2016-12-23 23:40:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-23 23:40:15 --> Helper loaded: form_helper
INFO - 2016-12-23 23:40:15 --> Form Validation Class Initialized
INFO - 2016-12-23 23:40:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2016-12-23 23:40:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2016-12-23 23:40:15 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2016-12-23 23:40:15 --> Final output sent to browser
DEBUG - 2016-12-23 23:40:15 --> Total execution time: 1.0159
INFO - 2016-12-23 23:40:16 --> Config Class Initialized
INFO - 2016-12-23 23:40:16 --> Hooks Class Initialized
DEBUG - 2016-12-23 23:40:16 --> UTF-8 Support Enabled
INFO - 2016-12-23 23:40:16 --> Utf8 Class Initialized
INFO - 2016-12-23 23:40:16 --> URI Class Initialized
INFO - 2016-12-23 23:40:16 --> Router Class Initialized
INFO - 2016-12-23 23:40:16 --> Output Class Initialized
INFO - 2016-12-23 23:40:16 --> Security Class Initialized
DEBUG - 2016-12-23 23:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-23 23:40:16 --> Input Class Initialized
INFO - 2016-12-23 23:40:16 --> Language Class Initialized
INFO - 2016-12-23 23:40:16 --> Loader Class Initialized
INFO - 2016-12-23 23:40:17 --> Database Driver Class Initialized
INFO - 2016-12-23 23:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-23 23:40:17 --> Controller Class Initialized
INFO - 2016-12-23 23:40:17 --> Helper loaded: url_helper
DEBUG - 2016-12-23 23:40:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-12-23 23:40:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2016-12-23 23:40:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2016-12-23 23:40:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2016-12-23 23:40:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2016-12-23 23:40:17 --> Final output sent to browser
DEBUG - 2016-12-23 23:40:17 --> Total execution time: 0.0470

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-17 01:51:18 --> Config Class Initialized
INFO - 2017-01-17 01:51:18 --> Hooks Class Initialized
DEBUG - 2017-01-17 01:51:18 --> UTF-8 Support Enabled
INFO - 2017-01-17 01:51:18 --> Utf8 Class Initialized
INFO - 2017-01-17 01:51:18 --> URI Class Initialized
INFO - 2017-01-17 01:51:18 --> Router Class Initialized
INFO - 2017-01-17 01:51:18 --> Output Class Initialized
INFO - 2017-01-17 01:51:18 --> Security Class Initialized
DEBUG - 2017-01-17 01:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 01:51:18 --> Input Class Initialized
INFO - 2017-01-17 01:51:18 --> Language Class Initialized
INFO - 2017-01-17 01:51:18 --> Loader Class Initialized
INFO - 2017-01-17 01:51:18 --> Database Driver Class Initialized
INFO - 2017-01-17 01:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 01:51:18 --> Controller Class Initialized
INFO - 2017-01-17 01:51:18 --> Helper loaded: url_helper
DEBUG - 2017-01-17 01:51:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 01:51:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 01:51:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 01:51:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 01:51:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 01:51:18 --> Final output sent to browser
DEBUG - 2017-01-17 01:51:18 --> Total execution time: 0.0153
INFO - 2017-01-17 01:51:18 --> Config Class Initialized
INFO - 2017-01-17 01:51:18 --> Hooks Class Initialized
DEBUG - 2017-01-17 01:51:18 --> UTF-8 Support Enabled
INFO - 2017-01-17 01:51:18 --> Utf8 Class Initialized
INFO - 2017-01-17 01:51:18 --> URI Class Initialized
INFO - 2017-01-17 01:51:18 --> Router Class Initialized
INFO - 2017-01-17 01:51:18 --> Output Class Initialized
INFO - 2017-01-17 01:51:18 --> Security Class Initialized
DEBUG - 2017-01-17 01:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 01:51:18 --> Input Class Initialized
INFO - 2017-01-17 01:51:18 --> Language Class Initialized
ERROR - 2017-01-17 01:51:18 --> 404 Page Not Found: Well-known/apple-app-site-association
INFO - 2017-01-17 02:09:45 --> Config Class Initialized
INFO - 2017-01-17 02:09:45 --> Hooks Class Initialized
DEBUG - 2017-01-17 02:09:45 --> UTF-8 Support Enabled
INFO - 2017-01-17 02:09:45 --> Utf8 Class Initialized
INFO - 2017-01-17 02:09:45 --> URI Class Initialized
DEBUG - 2017-01-17 02:09:45 --> No URI present. Default controller set.
INFO - 2017-01-17 02:09:45 --> Router Class Initialized
INFO - 2017-01-17 02:09:45 --> Output Class Initialized
INFO - 2017-01-17 02:09:45 --> Security Class Initialized
DEBUG - 2017-01-17 02:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 02:09:45 --> Input Class Initialized
INFO - 2017-01-17 02:09:45 --> Language Class Initialized
INFO - 2017-01-17 02:09:45 --> Loader Class Initialized
INFO - 2017-01-17 02:09:45 --> Database Driver Class Initialized
INFO - 2017-01-17 02:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 02:09:45 --> Controller Class Initialized
INFO - 2017-01-17 02:09:45 --> Helper loaded: url_helper
DEBUG - 2017-01-17 02:09:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 02:09:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 02:09:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 02:09:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 02:09:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 02:09:45 --> Final output sent to browser
DEBUG - 2017-01-17 02:09:45 --> Total execution time: 0.0142
INFO - 2017-01-17 03:21:35 --> Config Class Initialized
INFO - 2017-01-17 03:21:35 --> Hooks Class Initialized
DEBUG - 2017-01-17 03:21:35 --> UTF-8 Support Enabled
INFO - 2017-01-17 03:21:35 --> Utf8 Class Initialized
INFO - 2017-01-17 03:21:35 --> URI Class Initialized
DEBUG - 2017-01-17 03:21:35 --> No URI present. Default controller set.
INFO - 2017-01-17 03:21:35 --> Router Class Initialized
INFO - 2017-01-17 03:21:35 --> Output Class Initialized
INFO - 2017-01-17 03:21:35 --> Security Class Initialized
DEBUG - 2017-01-17 03:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 03:21:35 --> Input Class Initialized
INFO - 2017-01-17 03:21:35 --> Language Class Initialized
INFO - 2017-01-17 03:21:35 --> Loader Class Initialized
INFO - 2017-01-17 03:21:35 --> Database Driver Class Initialized
INFO - 2017-01-17 03:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 03:21:35 --> Controller Class Initialized
INFO - 2017-01-17 03:21:35 --> Helper loaded: url_helper
DEBUG - 2017-01-17 03:21:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 03:21:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 03:21:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 03:21:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 03:21:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 03:21:35 --> Final output sent to browser
DEBUG - 2017-01-17 03:21:35 --> Total execution time: 0.0139
INFO - 2017-01-17 03:22:21 --> Config Class Initialized
INFO - 2017-01-17 03:22:21 --> Hooks Class Initialized
DEBUG - 2017-01-17 03:22:21 --> UTF-8 Support Enabled
INFO - 2017-01-17 03:22:21 --> Utf8 Class Initialized
INFO - 2017-01-17 03:22:21 --> URI Class Initialized
INFO - 2017-01-17 03:22:21 --> Router Class Initialized
INFO - 2017-01-17 03:22:21 --> Output Class Initialized
INFO - 2017-01-17 03:22:21 --> Security Class Initialized
DEBUG - 2017-01-17 03:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 03:22:21 --> Input Class Initialized
INFO - 2017-01-17 03:22:21 --> Language Class Initialized
INFO - 2017-01-17 03:22:21 --> Loader Class Initialized
INFO - 2017-01-17 03:22:21 --> Database Driver Class Initialized
INFO - 2017-01-17 03:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 03:22:21 --> Controller Class Initialized
INFO - 2017-01-17 03:22:21 --> Helper loaded: url_helper
DEBUG - 2017-01-17 03:22:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 03:22:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 03:22:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 03:22:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 03:22:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 03:22:21 --> Final output sent to browser
DEBUG - 2017-01-17 03:22:21 --> Total execution time: 0.0136
INFO - 2017-01-17 03:22:33 --> Config Class Initialized
INFO - 2017-01-17 03:22:33 --> Hooks Class Initialized
DEBUG - 2017-01-17 03:22:33 --> UTF-8 Support Enabled
INFO - 2017-01-17 03:22:33 --> Utf8 Class Initialized
INFO - 2017-01-17 03:22:33 --> URI Class Initialized
DEBUG - 2017-01-17 03:22:33 --> No URI present. Default controller set.
INFO - 2017-01-17 03:22:33 --> Router Class Initialized
INFO - 2017-01-17 03:22:33 --> Output Class Initialized
INFO - 2017-01-17 03:22:33 --> Security Class Initialized
DEBUG - 2017-01-17 03:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 03:22:33 --> Input Class Initialized
INFO - 2017-01-17 03:22:33 --> Language Class Initialized
INFO - 2017-01-17 03:22:33 --> Loader Class Initialized
INFO - 2017-01-17 03:22:33 --> Database Driver Class Initialized
INFO - 2017-01-17 03:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 03:22:33 --> Controller Class Initialized
INFO - 2017-01-17 03:22:33 --> Helper loaded: url_helper
DEBUG - 2017-01-17 03:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 03:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 03:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 03:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 03:22:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 03:22:33 --> Final output sent to browser
DEBUG - 2017-01-17 03:22:33 --> Total execution time: 0.0133
INFO - 2017-01-17 03:22:37 --> Config Class Initialized
INFO - 2017-01-17 03:22:37 --> Hooks Class Initialized
DEBUG - 2017-01-17 03:22:37 --> UTF-8 Support Enabled
INFO - 2017-01-17 03:22:37 --> Utf8 Class Initialized
INFO - 2017-01-17 03:22:37 --> URI Class Initialized
INFO - 2017-01-17 03:22:37 --> Router Class Initialized
INFO - 2017-01-17 03:22:37 --> Output Class Initialized
INFO - 2017-01-17 03:22:37 --> Security Class Initialized
DEBUG - 2017-01-17 03:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 03:22:37 --> Input Class Initialized
INFO - 2017-01-17 03:22:37 --> Language Class Initialized
INFO - 2017-01-17 03:22:37 --> Loader Class Initialized
INFO - 2017-01-17 03:22:37 --> Database Driver Class Initialized
INFO - 2017-01-17 03:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 03:22:37 --> Controller Class Initialized
INFO - 2017-01-17 03:22:37 --> Helper loaded: url_helper
DEBUG - 2017-01-17 03:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 03:22:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 03:22:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 03:22:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 03:22:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 03:22:37 --> Final output sent to browser
DEBUG - 2017-01-17 03:22:37 --> Total execution time: 0.0162
INFO - 2017-01-17 03:39:30 --> Config Class Initialized
INFO - 2017-01-17 03:39:30 --> Hooks Class Initialized
DEBUG - 2017-01-17 03:39:30 --> UTF-8 Support Enabled
INFO - 2017-01-17 03:39:30 --> Utf8 Class Initialized
INFO - 2017-01-17 03:39:30 --> URI Class Initialized
DEBUG - 2017-01-17 03:39:30 --> No URI present. Default controller set.
INFO - 2017-01-17 03:39:30 --> Router Class Initialized
INFO - 2017-01-17 03:39:30 --> Output Class Initialized
INFO - 2017-01-17 03:39:30 --> Security Class Initialized
DEBUG - 2017-01-17 03:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 03:39:30 --> Input Class Initialized
INFO - 2017-01-17 03:39:30 --> Language Class Initialized
INFO - 2017-01-17 03:39:30 --> Loader Class Initialized
INFO - 2017-01-17 03:39:30 --> Database Driver Class Initialized
INFO - 2017-01-17 03:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 03:39:30 --> Controller Class Initialized
INFO - 2017-01-17 03:39:30 --> Helper loaded: url_helper
DEBUG - 2017-01-17 03:39:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 03:39:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 03:39:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 03:39:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 03:39:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 03:39:30 --> Final output sent to browser
DEBUG - 2017-01-17 03:39:30 --> Total execution time: 0.0140
INFO - 2017-01-17 03:39:47 --> Config Class Initialized
INFO - 2017-01-17 03:39:47 --> Hooks Class Initialized
DEBUG - 2017-01-17 03:39:47 --> UTF-8 Support Enabled
INFO - 2017-01-17 03:39:47 --> Utf8 Class Initialized
INFO - 2017-01-17 03:39:47 --> URI Class Initialized
INFO - 2017-01-17 03:39:47 --> Router Class Initialized
INFO - 2017-01-17 03:39:47 --> Output Class Initialized
INFO - 2017-01-17 03:39:47 --> Security Class Initialized
DEBUG - 2017-01-17 03:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 03:39:47 --> Input Class Initialized
INFO - 2017-01-17 03:39:47 --> Language Class Initialized
INFO - 2017-01-17 03:39:47 --> Loader Class Initialized
INFO - 2017-01-17 03:39:47 --> Database Driver Class Initialized
INFO - 2017-01-17 03:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 03:39:47 --> Controller Class Initialized
INFO - 2017-01-17 03:39:47 --> Helper loaded: url_helper
DEBUG - 2017-01-17 03:39:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 03:39:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 03:39:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 03:39:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 03:39:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 03:39:47 --> Final output sent to browser
DEBUG - 2017-01-17 03:39:47 --> Total execution time: 0.0141
INFO - 2017-01-17 03:39:54 --> Config Class Initialized
INFO - 2017-01-17 03:39:54 --> Hooks Class Initialized
DEBUG - 2017-01-17 03:39:54 --> UTF-8 Support Enabled
INFO - 2017-01-17 03:39:54 --> Utf8 Class Initialized
INFO - 2017-01-17 03:39:54 --> URI Class Initialized
DEBUG - 2017-01-17 03:39:54 --> No URI present. Default controller set.
INFO - 2017-01-17 03:39:54 --> Router Class Initialized
INFO - 2017-01-17 03:39:54 --> Output Class Initialized
INFO - 2017-01-17 03:39:54 --> Security Class Initialized
DEBUG - 2017-01-17 03:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 03:39:54 --> Input Class Initialized
INFO - 2017-01-17 03:39:54 --> Language Class Initialized
INFO - 2017-01-17 03:39:54 --> Loader Class Initialized
INFO - 2017-01-17 03:39:54 --> Database Driver Class Initialized
INFO - 2017-01-17 03:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 03:39:54 --> Controller Class Initialized
INFO - 2017-01-17 03:39:54 --> Helper loaded: url_helper
DEBUG - 2017-01-17 03:39:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 03:39:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 03:39:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 03:39:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 03:39:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 03:39:54 --> Final output sent to browser
DEBUG - 2017-01-17 03:39:54 --> Total execution time: 0.0141
INFO - 2017-01-17 03:39:55 --> Config Class Initialized
INFO - 2017-01-17 03:39:55 --> Hooks Class Initialized
DEBUG - 2017-01-17 03:39:55 --> UTF-8 Support Enabled
INFO - 2017-01-17 03:39:55 --> Utf8 Class Initialized
INFO - 2017-01-17 03:39:55 --> URI Class Initialized
DEBUG - 2017-01-17 03:39:55 --> No URI present. Default controller set.
INFO - 2017-01-17 03:39:55 --> Router Class Initialized
INFO - 2017-01-17 03:39:55 --> Output Class Initialized
INFO - 2017-01-17 03:39:55 --> Security Class Initialized
DEBUG - 2017-01-17 03:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 03:39:55 --> Input Class Initialized
INFO - 2017-01-17 03:39:55 --> Language Class Initialized
INFO - 2017-01-17 03:39:55 --> Loader Class Initialized
INFO - 2017-01-17 03:39:55 --> Database Driver Class Initialized
INFO - 2017-01-17 03:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 03:39:55 --> Controller Class Initialized
INFO - 2017-01-17 03:39:55 --> Helper loaded: url_helper
DEBUG - 2017-01-17 03:39:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 03:39:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 03:39:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 03:39:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 03:39:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 03:39:55 --> Final output sent to browser
DEBUG - 2017-01-17 03:39:55 --> Total execution time: 0.0132
INFO - 2017-01-17 03:40:23 --> Config Class Initialized
INFO - 2017-01-17 03:40:23 --> Hooks Class Initialized
DEBUG - 2017-01-17 03:40:23 --> UTF-8 Support Enabled
INFO - 2017-01-17 03:40:23 --> Utf8 Class Initialized
INFO - 2017-01-17 03:40:23 --> URI Class Initialized
INFO - 2017-01-17 03:40:23 --> Router Class Initialized
INFO - 2017-01-17 03:40:23 --> Output Class Initialized
INFO - 2017-01-17 03:40:23 --> Security Class Initialized
DEBUG - 2017-01-17 03:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 03:40:23 --> Input Class Initialized
INFO - 2017-01-17 03:40:23 --> Language Class Initialized
INFO - 2017-01-17 03:40:23 --> Loader Class Initialized
INFO - 2017-01-17 03:40:23 --> Database Driver Class Initialized
INFO - 2017-01-17 03:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 03:40:23 --> Controller Class Initialized
INFO - 2017-01-17 03:40:23 --> Helper loaded: url_helper
DEBUG - 2017-01-17 03:40:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 03:40:24 --> Config Class Initialized
INFO - 2017-01-17 03:40:24 --> Hooks Class Initialized
DEBUG - 2017-01-17 03:40:24 --> UTF-8 Support Enabled
INFO - 2017-01-17 03:40:24 --> Utf8 Class Initialized
INFO - 2017-01-17 03:40:24 --> URI Class Initialized
INFO - 2017-01-17 03:40:24 --> Router Class Initialized
INFO - 2017-01-17 03:40:24 --> Output Class Initialized
INFO - 2017-01-17 03:40:24 --> Security Class Initialized
DEBUG - 2017-01-17 03:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 03:40:24 --> Input Class Initialized
INFO - 2017-01-17 03:40:24 --> Language Class Initialized
INFO - 2017-01-17 03:40:24 --> Loader Class Initialized
INFO - 2017-01-17 03:40:24 --> Database Driver Class Initialized
INFO - 2017-01-17 03:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 03:40:24 --> Controller Class Initialized
INFO - 2017-01-17 03:40:24 --> Helper loaded: date_helper
DEBUG - 2017-01-17 03:40:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 03:40:24 --> Helper loaded: url_helper
INFO - 2017-01-17 03:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 03:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-17 03:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-17 03:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-17 03:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 03:40:24 --> Final output sent to browser
DEBUG - 2017-01-17 03:40:24 --> Total execution time: 0.0140
INFO - 2017-01-17 03:40:25 --> Config Class Initialized
INFO - 2017-01-17 03:40:25 --> Hooks Class Initialized
DEBUG - 2017-01-17 03:40:25 --> UTF-8 Support Enabled
INFO - 2017-01-17 03:40:25 --> Utf8 Class Initialized
INFO - 2017-01-17 03:40:25 --> URI Class Initialized
INFO - 2017-01-17 03:40:25 --> Router Class Initialized
INFO - 2017-01-17 03:40:25 --> Output Class Initialized
INFO - 2017-01-17 03:40:25 --> Security Class Initialized
DEBUG - 2017-01-17 03:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 03:40:25 --> Input Class Initialized
INFO - 2017-01-17 03:40:25 --> Language Class Initialized
INFO - 2017-01-17 03:40:25 --> Loader Class Initialized
INFO - 2017-01-17 03:40:25 --> Database Driver Class Initialized
INFO - 2017-01-17 03:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 03:40:25 --> Controller Class Initialized
INFO - 2017-01-17 03:40:25 --> Helper loaded: url_helper
DEBUG - 2017-01-17 03:40:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 03:40:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 03:40:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 03:40:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 03:40:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 03:40:25 --> Final output sent to browser
DEBUG - 2017-01-17 03:40:25 --> Total execution time: 0.0138
INFO - 2017-01-17 03:40:31 --> Config Class Initialized
INFO - 2017-01-17 03:40:31 --> Hooks Class Initialized
DEBUG - 2017-01-17 03:40:31 --> UTF-8 Support Enabled
INFO - 2017-01-17 03:40:31 --> Utf8 Class Initialized
INFO - 2017-01-17 03:40:31 --> URI Class Initialized
INFO - 2017-01-17 03:40:31 --> Router Class Initialized
INFO - 2017-01-17 03:40:31 --> Output Class Initialized
INFO - 2017-01-17 03:40:31 --> Security Class Initialized
DEBUG - 2017-01-17 03:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 03:40:31 --> Input Class Initialized
INFO - 2017-01-17 03:40:31 --> Language Class Initialized
INFO - 2017-01-17 03:40:31 --> Loader Class Initialized
INFO - 2017-01-17 03:40:31 --> Database Driver Class Initialized
INFO - 2017-01-17 03:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 03:40:31 --> Controller Class Initialized
INFO - 2017-01-17 03:40:31 --> Helper loaded: date_helper
DEBUG - 2017-01-17 03:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 03:40:31 --> Helper loaded: url_helper
INFO - 2017-01-17 03:40:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 03:40:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-17 03:40:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-17 03:40:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-17 03:40:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 03:40:31 --> Final output sent to browser
DEBUG - 2017-01-17 03:40:31 --> Total execution time: 0.0142
INFO - 2017-01-17 03:40:33 --> Config Class Initialized
INFO - 2017-01-17 03:40:33 --> Hooks Class Initialized
DEBUG - 2017-01-17 03:40:33 --> UTF-8 Support Enabled
INFO - 2017-01-17 03:40:33 --> Utf8 Class Initialized
INFO - 2017-01-17 03:40:33 --> URI Class Initialized
INFO - 2017-01-17 03:40:33 --> Router Class Initialized
INFO - 2017-01-17 03:40:33 --> Output Class Initialized
INFO - 2017-01-17 03:40:33 --> Security Class Initialized
DEBUG - 2017-01-17 03:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 03:40:33 --> Input Class Initialized
INFO - 2017-01-17 03:40:33 --> Language Class Initialized
INFO - 2017-01-17 03:40:33 --> Loader Class Initialized
INFO - 2017-01-17 03:40:33 --> Database Driver Class Initialized
INFO - 2017-01-17 03:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 03:40:33 --> Controller Class Initialized
INFO - 2017-01-17 03:40:33 --> Helper loaded: date_helper
DEBUG - 2017-01-17 03:40:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 03:40:33 --> Helper loaded: url_helper
INFO - 2017-01-17 03:40:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 03:40:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-17 03:40:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-17 03:40:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-17 03:40:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 03:40:33 --> Final output sent to browser
DEBUG - 2017-01-17 03:40:33 --> Total execution time: 0.0152
INFO - 2017-01-17 03:40:37 --> Config Class Initialized
INFO - 2017-01-17 03:40:37 --> Hooks Class Initialized
DEBUG - 2017-01-17 03:40:37 --> UTF-8 Support Enabled
INFO - 2017-01-17 03:40:37 --> Utf8 Class Initialized
INFO - 2017-01-17 03:40:37 --> URI Class Initialized
DEBUG - 2017-01-17 03:40:37 --> No URI present. Default controller set.
INFO - 2017-01-17 03:40:37 --> Router Class Initialized
INFO - 2017-01-17 03:40:37 --> Output Class Initialized
INFO - 2017-01-17 03:40:37 --> Security Class Initialized
DEBUG - 2017-01-17 03:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 03:40:37 --> Input Class Initialized
INFO - 2017-01-17 03:40:37 --> Language Class Initialized
INFO - 2017-01-17 03:40:37 --> Loader Class Initialized
INFO - 2017-01-17 03:40:37 --> Database Driver Class Initialized
INFO - 2017-01-17 03:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 03:40:37 --> Controller Class Initialized
INFO - 2017-01-17 03:40:37 --> Helper loaded: url_helper
DEBUG - 2017-01-17 03:40:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 03:40:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 03:40:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 03:40:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 03:40:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 03:40:37 --> Final output sent to browser
DEBUG - 2017-01-17 03:40:37 --> Total execution time: 0.0138
INFO - 2017-01-17 03:40:38 --> Config Class Initialized
INFO - 2017-01-17 03:40:38 --> Hooks Class Initialized
DEBUG - 2017-01-17 03:40:38 --> UTF-8 Support Enabled
INFO - 2017-01-17 03:40:38 --> Utf8 Class Initialized
INFO - 2017-01-17 03:40:38 --> URI Class Initialized
INFO - 2017-01-17 03:40:38 --> Router Class Initialized
INFO - 2017-01-17 03:40:38 --> Output Class Initialized
INFO - 2017-01-17 03:40:38 --> Security Class Initialized
DEBUG - 2017-01-17 03:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 03:40:38 --> Input Class Initialized
INFO - 2017-01-17 03:40:38 --> Language Class Initialized
INFO - 2017-01-17 03:40:38 --> Loader Class Initialized
INFO - 2017-01-17 03:40:38 --> Database Driver Class Initialized
INFO - 2017-01-17 03:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 03:40:38 --> Controller Class Initialized
INFO - 2017-01-17 03:40:38 --> Helper loaded: url_helper
DEBUG - 2017-01-17 03:40:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 03:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 03:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 03:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 03:40:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 03:40:38 --> Final output sent to browser
DEBUG - 2017-01-17 03:40:38 --> Total execution time: 0.0572
INFO - 2017-01-17 04:09:59 --> Config Class Initialized
INFO - 2017-01-17 04:09:59 --> Hooks Class Initialized
DEBUG - 2017-01-17 04:09:59 --> UTF-8 Support Enabled
INFO - 2017-01-17 04:09:59 --> Utf8 Class Initialized
INFO - 2017-01-17 04:09:59 --> URI Class Initialized
DEBUG - 2017-01-17 04:09:59 --> No URI present. Default controller set.
INFO - 2017-01-17 04:09:59 --> Router Class Initialized
INFO - 2017-01-17 04:09:59 --> Output Class Initialized
INFO - 2017-01-17 04:09:59 --> Security Class Initialized
DEBUG - 2017-01-17 04:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 04:09:59 --> Input Class Initialized
INFO - 2017-01-17 04:09:59 --> Language Class Initialized
INFO - 2017-01-17 04:09:59 --> Loader Class Initialized
INFO - 2017-01-17 04:09:59 --> Database Driver Class Initialized
INFO - 2017-01-17 04:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 04:09:59 --> Controller Class Initialized
INFO - 2017-01-17 04:09:59 --> Helper loaded: url_helper
DEBUG - 2017-01-17 04:09:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 04:09:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 04:09:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 04:09:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 04:09:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 04:09:59 --> Final output sent to browser
DEBUG - 2017-01-17 04:09:59 --> Total execution time: 0.0136
INFO - 2017-01-17 05:37:59 --> Config Class Initialized
INFO - 2017-01-17 05:37:59 --> Hooks Class Initialized
DEBUG - 2017-01-17 05:37:59 --> UTF-8 Support Enabled
INFO - 2017-01-17 05:37:59 --> Utf8 Class Initialized
INFO - 2017-01-17 05:37:59 --> URI Class Initialized
DEBUG - 2017-01-17 05:37:59 --> No URI present. Default controller set.
INFO - 2017-01-17 05:37:59 --> Router Class Initialized
INFO - 2017-01-17 05:37:59 --> Output Class Initialized
INFO - 2017-01-17 05:37:59 --> Security Class Initialized
DEBUG - 2017-01-17 05:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 05:37:59 --> Input Class Initialized
INFO - 2017-01-17 05:37:59 --> Language Class Initialized
INFO - 2017-01-17 05:37:59 --> Loader Class Initialized
INFO - 2017-01-17 05:37:59 --> Database Driver Class Initialized
INFO - 2017-01-17 05:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 05:37:59 --> Controller Class Initialized
INFO - 2017-01-17 05:37:59 --> Helper loaded: url_helper
DEBUG - 2017-01-17 05:37:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 05:37:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 05:37:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 05:37:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 05:37:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 05:37:59 --> Final output sent to browser
DEBUG - 2017-01-17 05:37:59 --> Total execution time: 0.0136
INFO - 2017-01-17 05:38:02 --> Config Class Initialized
INFO - 2017-01-17 05:38:02 --> Hooks Class Initialized
DEBUG - 2017-01-17 05:38:02 --> UTF-8 Support Enabled
INFO - 2017-01-17 05:38:02 --> Utf8 Class Initialized
INFO - 2017-01-17 05:38:02 --> URI Class Initialized
INFO - 2017-01-17 05:38:02 --> Router Class Initialized
INFO - 2017-01-17 05:38:02 --> Output Class Initialized
INFO - 2017-01-17 05:38:02 --> Security Class Initialized
DEBUG - 2017-01-17 05:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 05:38:02 --> Input Class Initialized
INFO - 2017-01-17 05:38:02 --> Language Class Initialized
INFO - 2017-01-17 05:38:02 --> Loader Class Initialized
INFO - 2017-01-17 05:38:02 --> Database Driver Class Initialized
INFO - 2017-01-17 05:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 05:38:02 --> Controller Class Initialized
INFO - 2017-01-17 05:38:02 --> Helper loaded: url_helper
DEBUG - 2017-01-17 05:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 05:38:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 05:38:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 05:38:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 05:38:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 05:38:02 --> Final output sent to browser
DEBUG - 2017-01-17 05:38:02 --> Total execution time: 0.0133
INFO - 2017-01-17 05:40:25 --> Config Class Initialized
INFO - 2017-01-17 05:40:25 --> Hooks Class Initialized
DEBUG - 2017-01-17 05:40:25 --> UTF-8 Support Enabled
INFO - 2017-01-17 05:40:25 --> Utf8 Class Initialized
INFO - 2017-01-17 05:40:25 --> URI Class Initialized
INFO - 2017-01-17 05:40:25 --> Router Class Initialized
INFO - 2017-01-17 05:40:25 --> Output Class Initialized
INFO - 2017-01-17 05:40:25 --> Security Class Initialized
DEBUG - 2017-01-17 05:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 05:40:25 --> Input Class Initialized
INFO - 2017-01-17 05:40:25 --> Language Class Initialized
INFO - 2017-01-17 05:40:25 --> Loader Class Initialized
INFO - 2017-01-17 05:40:25 --> Database Driver Class Initialized
INFO - 2017-01-17 05:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 05:40:25 --> Controller Class Initialized
INFO - 2017-01-17 05:40:25 --> Helper loaded: url_helper
DEBUG - 2017-01-17 05:40:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 05:40:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 05:40:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 05:40:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 05:40:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 05:40:25 --> Final output sent to browser
DEBUG - 2017-01-17 05:40:25 --> Total execution time: 0.0138
INFO - 2017-01-17 06:06:32 --> Config Class Initialized
INFO - 2017-01-17 06:06:32 --> Hooks Class Initialized
DEBUG - 2017-01-17 06:06:32 --> UTF-8 Support Enabled
INFO - 2017-01-17 06:06:32 --> Utf8 Class Initialized
INFO - 2017-01-17 06:06:32 --> URI Class Initialized
INFO - 2017-01-17 06:06:32 --> Router Class Initialized
INFO - 2017-01-17 06:06:32 --> Output Class Initialized
INFO - 2017-01-17 06:06:32 --> Security Class Initialized
DEBUG - 2017-01-17 06:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 06:06:32 --> Input Class Initialized
INFO - 2017-01-17 06:06:32 --> Language Class Initialized
INFO - 2017-01-17 06:06:32 --> Loader Class Initialized
INFO - 2017-01-17 06:06:32 --> Database Driver Class Initialized
INFO - 2017-01-17 06:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 06:06:32 --> Controller Class Initialized
INFO - 2017-01-17 06:06:32 --> Helper loaded: url_helper
DEBUG - 2017-01-17 06:06:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 06:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 06:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 06:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 06:06:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 06:06:32 --> Final output sent to browser
DEBUG - 2017-01-17 06:06:32 --> Total execution time: 0.0135
INFO - 2017-01-17 13:31:31 --> Config Class Initialized
INFO - 2017-01-17 13:31:31 --> Hooks Class Initialized
DEBUG - 2017-01-17 13:31:31 --> UTF-8 Support Enabled
INFO - 2017-01-17 13:31:31 --> Utf8 Class Initialized
INFO - 2017-01-17 13:31:31 --> URI Class Initialized
INFO - 2017-01-17 13:31:31 --> Router Class Initialized
INFO - 2017-01-17 13:31:31 --> Output Class Initialized
INFO - 2017-01-17 13:31:31 --> Security Class Initialized
DEBUG - 2017-01-17 13:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 13:31:31 --> Input Class Initialized
INFO - 2017-01-17 13:31:31 --> Language Class Initialized
INFO - 2017-01-17 13:31:31 --> Loader Class Initialized
INFO - 2017-01-17 13:31:31 --> Database Driver Class Initialized
INFO - 2017-01-17 13:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 13:31:31 --> Controller Class Initialized
INFO - 2017-01-17 13:31:31 --> Upload Class Initialized
INFO - 2017-01-17 13:31:31 --> Helper loaded: date_helper
DEBUG - 2017-01-17 13:31:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 13:31:31 --> Helper loaded: url_helper
INFO - 2017-01-17 13:31:32 --> Config Class Initialized
INFO - 2017-01-17 13:31:32 --> Hooks Class Initialized
DEBUG - 2017-01-17 13:31:32 --> UTF-8 Support Enabled
INFO - 2017-01-17 13:31:32 --> Utf8 Class Initialized
INFO - 2017-01-17 13:31:32 --> URI Class Initialized
DEBUG - 2017-01-17 13:31:32 --> No URI present. Default controller set.
INFO - 2017-01-17 13:31:32 --> Router Class Initialized
INFO - 2017-01-17 13:31:32 --> Output Class Initialized
INFO - 2017-01-17 13:31:32 --> Security Class Initialized
DEBUG - 2017-01-17 13:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 13:31:32 --> Input Class Initialized
INFO - 2017-01-17 13:31:32 --> Language Class Initialized
INFO - 2017-01-17 13:31:32 --> Loader Class Initialized
INFO - 2017-01-17 13:31:32 --> Database Driver Class Initialized
INFO - 2017-01-17 13:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 13:31:32 --> Controller Class Initialized
INFO - 2017-01-17 13:31:32 --> Helper loaded: url_helper
DEBUG - 2017-01-17 13:31:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 13:31:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 13:31:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 13:31:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 13:31:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 13:31:32 --> Final output sent to browser
DEBUG - 2017-01-17 13:31:32 --> Total execution time: 0.0130
INFO - 2017-01-17 15:10:39 --> Config Class Initialized
INFO - 2017-01-17 15:10:39 --> Hooks Class Initialized
DEBUG - 2017-01-17 15:10:39 --> UTF-8 Support Enabled
INFO - 2017-01-17 15:10:39 --> Utf8 Class Initialized
INFO - 2017-01-17 15:10:39 --> URI Class Initialized
DEBUG - 2017-01-17 15:10:39 --> No URI present. Default controller set.
INFO - 2017-01-17 15:10:39 --> Router Class Initialized
INFO - 2017-01-17 15:10:39 --> Output Class Initialized
INFO - 2017-01-17 15:10:39 --> Security Class Initialized
DEBUG - 2017-01-17 15:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 15:10:39 --> Input Class Initialized
INFO - 2017-01-17 15:10:39 --> Language Class Initialized
INFO - 2017-01-17 15:10:39 --> Loader Class Initialized
INFO - 2017-01-17 15:10:39 --> Database Driver Class Initialized
INFO - 2017-01-17 15:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 15:10:39 --> Controller Class Initialized
INFO - 2017-01-17 15:10:39 --> Helper loaded: url_helper
DEBUG - 2017-01-17 15:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 15:10:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 15:10:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 15:10:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 15:10:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 15:10:39 --> Final output sent to browser
DEBUG - 2017-01-17 15:10:39 --> Total execution time: 0.0384
INFO - 2017-01-17 15:10:45 --> Config Class Initialized
INFO - 2017-01-17 15:10:45 --> Hooks Class Initialized
DEBUG - 2017-01-17 15:10:45 --> UTF-8 Support Enabled
INFO - 2017-01-17 15:10:45 --> Utf8 Class Initialized
INFO - 2017-01-17 15:10:45 --> URI Class Initialized
INFO - 2017-01-17 15:10:45 --> Router Class Initialized
INFO - 2017-01-17 15:10:45 --> Output Class Initialized
INFO - 2017-01-17 15:10:45 --> Security Class Initialized
DEBUG - 2017-01-17 15:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 15:10:45 --> Input Class Initialized
INFO - 2017-01-17 15:10:45 --> Language Class Initialized
INFO - 2017-01-17 15:10:45 --> Loader Class Initialized
INFO - 2017-01-17 15:10:45 --> Database Driver Class Initialized
INFO - 2017-01-17 15:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 15:10:45 --> Controller Class Initialized
INFO - 2017-01-17 15:10:45 --> Helper loaded: url_helper
DEBUG - 2017-01-17 15:10:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 15:10:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 15:10:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 15:10:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 15:10:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 15:10:45 --> Final output sent to browser
DEBUG - 2017-01-17 15:10:45 --> Total execution time: 0.2259
INFO - 2017-01-17 17:20:59 --> Config Class Initialized
INFO - 2017-01-17 17:20:59 --> Hooks Class Initialized
DEBUG - 2017-01-17 17:20:59 --> UTF-8 Support Enabled
INFO - 2017-01-17 17:20:59 --> Utf8 Class Initialized
INFO - 2017-01-17 17:20:59 --> URI Class Initialized
DEBUG - 2017-01-17 17:20:59 --> No URI present. Default controller set.
INFO - 2017-01-17 17:20:59 --> Router Class Initialized
INFO - 2017-01-17 17:20:59 --> Output Class Initialized
INFO - 2017-01-17 17:20:59 --> Security Class Initialized
DEBUG - 2017-01-17 17:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 17:20:59 --> Input Class Initialized
INFO - 2017-01-17 17:20:59 --> Language Class Initialized
INFO - 2017-01-17 17:20:59 --> Loader Class Initialized
INFO - 2017-01-17 17:20:59 --> Database Driver Class Initialized
INFO - 2017-01-17 17:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 17:20:59 --> Controller Class Initialized
INFO - 2017-01-17 17:20:59 --> Helper loaded: url_helper
DEBUG - 2017-01-17 17:20:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 17:20:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 17:20:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 17:20:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 17:20:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 17:20:59 --> Final output sent to browser
DEBUG - 2017-01-17 17:20:59 --> Total execution time: 0.0133
INFO - 2017-01-17 17:21:45 --> Config Class Initialized
INFO - 2017-01-17 17:21:45 --> Hooks Class Initialized
DEBUG - 2017-01-17 17:21:45 --> UTF-8 Support Enabled
INFO - 2017-01-17 17:21:45 --> Utf8 Class Initialized
INFO - 2017-01-17 17:21:45 --> URI Class Initialized
DEBUG - 2017-01-17 17:21:45 --> No URI present. Default controller set.
INFO - 2017-01-17 17:21:45 --> Router Class Initialized
INFO - 2017-01-17 17:21:45 --> Output Class Initialized
INFO - 2017-01-17 17:21:45 --> Security Class Initialized
DEBUG - 2017-01-17 17:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 17:21:45 --> Input Class Initialized
INFO - 2017-01-17 17:21:45 --> Language Class Initialized
INFO - 2017-01-17 17:21:45 --> Loader Class Initialized
INFO - 2017-01-17 17:21:45 --> Database Driver Class Initialized
INFO - 2017-01-17 17:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 17:21:45 --> Controller Class Initialized
INFO - 2017-01-17 17:21:45 --> Helper loaded: url_helper
DEBUG - 2017-01-17 17:21:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 17:21:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 17:21:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 17:21:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 17:21:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 17:21:45 --> Final output sent to browser
DEBUG - 2017-01-17 17:21:45 --> Total execution time: 0.0566
INFO - 2017-01-17 17:21:59 --> Config Class Initialized
INFO - 2017-01-17 17:21:59 --> Hooks Class Initialized
DEBUG - 2017-01-17 17:21:59 --> UTF-8 Support Enabled
INFO - 2017-01-17 17:21:59 --> Utf8 Class Initialized
INFO - 2017-01-17 17:21:59 --> URI Class Initialized
INFO - 2017-01-17 17:21:59 --> Router Class Initialized
INFO - 2017-01-17 17:21:59 --> Output Class Initialized
INFO - 2017-01-17 17:21:59 --> Security Class Initialized
DEBUG - 2017-01-17 17:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 17:21:59 --> Input Class Initialized
INFO - 2017-01-17 17:21:59 --> Language Class Initialized
INFO - 2017-01-17 17:21:59 --> Loader Class Initialized
INFO - 2017-01-17 17:21:59 --> Database Driver Class Initialized
INFO - 2017-01-17 17:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 17:21:59 --> Controller Class Initialized
INFO - 2017-01-17 17:21:59 --> Helper loaded: url_helper
DEBUG - 2017-01-17 17:21:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 17:21:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 17:21:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 17:21:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 17:21:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 17:21:59 --> Final output sent to browser
DEBUG - 2017-01-17 17:21:59 --> Total execution time: 0.0136
INFO - 2017-01-17 17:32:07 --> Config Class Initialized
INFO - 2017-01-17 17:32:07 --> Hooks Class Initialized
DEBUG - 2017-01-17 17:32:07 --> UTF-8 Support Enabled
INFO - 2017-01-17 17:32:07 --> Utf8 Class Initialized
INFO - 2017-01-17 17:32:07 --> URI Class Initialized
DEBUG - 2017-01-17 17:32:07 --> No URI present. Default controller set.
INFO - 2017-01-17 17:32:07 --> Router Class Initialized
INFO - 2017-01-17 17:32:07 --> Output Class Initialized
INFO - 2017-01-17 17:32:07 --> Security Class Initialized
DEBUG - 2017-01-17 17:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 17:32:07 --> Input Class Initialized
INFO - 2017-01-17 17:32:07 --> Language Class Initialized
INFO - 2017-01-17 17:32:07 --> Loader Class Initialized
INFO - 2017-01-17 17:32:07 --> Database Driver Class Initialized
INFO - 2017-01-17 17:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 17:32:07 --> Controller Class Initialized
INFO - 2017-01-17 17:32:07 --> Helper loaded: url_helper
DEBUG - 2017-01-17 17:32:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 17:32:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 17:32:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 17:32:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 17:32:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 17:32:07 --> Final output sent to browser
DEBUG - 2017-01-17 17:32:07 --> Total execution time: 0.0131
INFO - 2017-01-17 17:32:48 --> Config Class Initialized
INFO - 2017-01-17 17:32:48 --> Hooks Class Initialized
DEBUG - 2017-01-17 17:32:48 --> UTF-8 Support Enabled
INFO - 2017-01-17 17:32:48 --> Utf8 Class Initialized
INFO - 2017-01-17 17:32:48 --> URI Class Initialized
INFO - 2017-01-17 17:32:48 --> Router Class Initialized
INFO - 2017-01-17 17:32:48 --> Output Class Initialized
INFO - 2017-01-17 17:32:48 --> Security Class Initialized
DEBUG - 2017-01-17 17:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 17:32:48 --> Input Class Initialized
INFO - 2017-01-17 17:32:48 --> Language Class Initialized
INFO - 2017-01-17 17:32:48 --> Loader Class Initialized
INFO - 2017-01-17 17:32:48 --> Database Driver Class Initialized
INFO - 2017-01-17 17:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 17:32:48 --> Controller Class Initialized
INFO - 2017-01-17 17:32:48 --> Helper loaded: url_helper
DEBUG - 2017-01-17 17:32:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 17:32:50 --> Config Class Initialized
INFO - 2017-01-17 17:32:50 --> Hooks Class Initialized
DEBUG - 2017-01-17 17:32:50 --> UTF-8 Support Enabled
INFO - 2017-01-17 17:32:50 --> Utf8 Class Initialized
INFO - 2017-01-17 17:32:50 --> URI Class Initialized
INFO - 2017-01-17 17:32:50 --> Router Class Initialized
INFO - 2017-01-17 17:32:50 --> Output Class Initialized
INFO - 2017-01-17 17:32:50 --> Security Class Initialized
DEBUG - 2017-01-17 17:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 17:32:50 --> Input Class Initialized
INFO - 2017-01-17 17:32:50 --> Language Class Initialized
INFO - 2017-01-17 17:32:50 --> Loader Class Initialized
INFO - 2017-01-17 17:32:50 --> Database Driver Class Initialized
INFO - 2017-01-17 17:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 17:32:50 --> Controller Class Initialized
INFO - 2017-01-17 17:32:50 --> Helper loaded: date_helper
DEBUG - 2017-01-17 17:32:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 17:32:50 --> Helper loaded: url_helper
INFO - 2017-01-17 17:32:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 17:32:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-17 17:32:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-17 17:32:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-17 17:32:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 17:32:50 --> Final output sent to browser
DEBUG - 2017-01-17 17:32:50 --> Total execution time: 0.0530
INFO - 2017-01-17 17:33:08 --> Config Class Initialized
INFO - 2017-01-17 17:33:08 --> Hooks Class Initialized
DEBUG - 2017-01-17 17:33:08 --> UTF-8 Support Enabled
INFO - 2017-01-17 17:33:08 --> Utf8 Class Initialized
INFO - 2017-01-17 17:33:08 --> URI Class Initialized
DEBUG - 2017-01-17 17:33:08 --> No URI present. Default controller set.
INFO - 2017-01-17 17:33:08 --> Router Class Initialized
INFO - 2017-01-17 17:33:08 --> Output Class Initialized
INFO - 2017-01-17 17:33:08 --> Security Class Initialized
DEBUG - 2017-01-17 17:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 17:33:08 --> Input Class Initialized
INFO - 2017-01-17 17:33:08 --> Language Class Initialized
INFO - 2017-01-17 17:33:08 --> Loader Class Initialized
INFO - 2017-01-17 17:33:08 --> Database Driver Class Initialized
INFO - 2017-01-17 17:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 17:33:08 --> Controller Class Initialized
INFO - 2017-01-17 17:33:08 --> Helper loaded: url_helper
DEBUG - 2017-01-17 17:33:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 17:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 17:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 17:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 17:33:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 17:33:08 --> Final output sent to browser
DEBUG - 2017-01-17 17:33:08 --> Total execution time: 0.0145
INFO - 2017-01-17 18:38:45 --> Config Class Initialized
INFO - 2017-01-17 18:38:45 --> Hooks Class Initialized
DEBUG - 2017-01-17 18:38:45 --> UTF-8 Support Enabled
INFO - 2017-01-17 18:38:45 --> Utf8 Class Initialized
INFO - 2017-01-17 18:38:45 --> URI Class Initialized
DEBUG - 2017-01-17 18:38:45 --> No URI present. Default controller set.
INFO - 2017-01-17 18:38:45 --> Router Class Initialized
INFO - 2017-01-17 18:38:45 --> Output Class Initialized
INFO - 2017-01-17 18:38:45 --> Security Class Initialized
DEBUG - 2017-01-17 18:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 18:38:45 --> Input Class Initialized
INFO - 2017-01-17 18:38:45 --> Language Class Initialized
INFO - 2017-01-17 18:38:45 --> Loader Class Initialized
INFO - 2017-01-17 18:38:45 --> Database Driver Class Initialized
INFO - 2017-01-17 18:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 18:38:45 --> Controller Class Initialized
INFO - 2017-01-17 18:38:45 --> Helper loaded: url_helper
DEBUG - 2017-01-17 18:38:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 18:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 18:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 18:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 18:38:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 18:38:45 --> Final output sent to browser
DEBUG - 2017-01-17 18:38:45 --> Total execution time: 0.0142
INFO - 2017-01-17 18:38:56 --> Config Class Initialized
INFO - 2017-01-17 18:38:56 --> Hooks Class Initialized
DEBUG - 2017-01-17 18:38:56 --> UTF-8 Support Enabled
INFO - 2017-01-17 18:38:56 --> Utf8 Class Initialized
INFO - 2017-01-17 18:38:56 --> URI Class Initialized
INFO - 2017-01-17 18:38:56 --> Router Class Initialized
INFO - 2017-01-17 18:38:56 --> Output Class Initialized
INFO - 2017-01-17 18:38:56 --> Security Class Initialized
DEBUG - 2017-01-17 18:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 18:38:56 --> Input Class Initialized
INFO - 2017-01-17 18:38:56 --> Language Class Initialized
INFO - 2017-01-17 18:38:56 --> Loader Class Initialized
INFO - 2017-01-17 18:38:56 --> Database Driver Class Initialized
INFO - 2017-01-17 18:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 18:38:56 --> Controller Class Initialized
INFO - 2017-01-17 18:38:56 --> Helper loaded: url_helper
DEBUG - 2017-01-17 18:38:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 18:38:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 18:38:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 18:38:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 18:38:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 18:38:56 --> Final output sent to browser
DEBUG - 2017-01-17 18:38:56 --> Total execution time: 0.0141
INFO - 2017-01-17 18:41:00 --> Config Class Initialized
INFO - 2017-01-17 18:41:00 --> Hooks Class Initialized
DEBUG - 2017-01-17 18:41:00 --> UTF-8 Support Enabled
INFO - 2017-01-17 18:41:00 --> Utf8 Class Initialized
INFO - 2017-01-17 18:41:00 --> URI Class Initialized
DEBUG - 2017-01-17 18:41:00 --> No URI present. Default controller set.
INFO - 2017-01-17 18:41:00 --> Router Class Initialized
INFO - 2017-01-17 18:41:00 --> Output Class Initialized
INFO - 2017-01-17 18:41:00 --> Security Class Initialized
DEBUG - 2017-01-17 18:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 18:41:00 --> Input Class Initialized
INFO - 2017-01-17 18:41:00 --> Language Class Initialized
INFO - 2017-01-17 18:41:00 --> Loader Class Initialized
INFO - 2017-01-17 18:41:00 --> Database Driver Class Initialized
INFO - 2017-01-17 18:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 18:41:00 --> Controller Class Initialized
INFO - 2017-01-17 18:41:00 --> Helper loaded: url_helper
DEBUG - 2017-01-17 18:41:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 18:41:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 18:41:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 18:41:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 18:41:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 18:41:00 --> Final output sent to browser
DEBUG - 2017-01-17 18:41:00 --> Total execution time: 0.0162
INFO - 2017-01-17 18:41:03 --> Config Class Initialized
INFO - 2017-01-17 18:41:03 --> Hooks Class Initialized
DEBUG - 2017-01-17 18:41:03 --> UTF-8 Support Enabled
INFO - 2017-01-17 18:41:03 --> Utf8 Class Initialized
INFO - 2017-01-17 18:41:03 --> URI Class Initialized
INFO - 2017-01-17 18:41:03 --> Router Class Initialized
INFO - 2017-01-17 18:41:03 --> Output Class Initialized
INFO - 2017-01-17 18:41:03 --> Security Class Initialized
DEBUG - 2017-01-17 18:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 18:41:03 --> Input Class Initialized
INFO - 2017-01-17 18:41:03 --> Language Class Initialized
INFO - 2017-01-17 18:41:03 --> Loader Class Initialized
INFO - 2017-01-17 18:41:03 --> Database Driver Class Initialized
INFO - 2017-01-17 18:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 18:41:03 --> Controller Class Initialized
INFO - 2017-01-17 18:41:03 --> Helper loaded: url_helper
DEBUG - 2017-01-17 18:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 18:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 18:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 18:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 18:41:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 18:41:03 --> Final output sent to browser
DEBUG - 2017-01-17 18:41:03 --> Total execution time: 0.0141
INFO - 2017-01-17 18:41:57 --> Config Class Initialized
INFO - 2017-01-17 18:41:57 --> Hooks Class Initialized
DEBUG - 2017-01-17 18:41:57 --> UTF-8 Support Enabled
INFO - 2017-01-17 18:41:57 --> Utf8 Class Initialized
INFO - 2017-01-17 18:41:57 --> URI Class Initialized
INFO - 2017-01-17 18:41:57 --> Router Class Initialized
INFO - 2017-01-17 18:41:57 --> Output Class Initialized
INFO - 2017-01-17 18:41:57 --> Security Class Initialized
DEBUG - 2017-01-17 18:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 18:41:57 --> Input Class Initialized
INFO - 2017-01-17 18:41:57 --> Language Class Initialized
INFO - 2017-01-17 18:41:57 --> Loader Class Initialized
INFO - 2017-01-17 18:41:57 --> Database Driver Class Initialized
INFO - 2017-01-17 18:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 18:41:57 --> Controller Class Initialized
INFO - 2017-01-17 18:41:57 --> Helper loaded: url_helper
DEBUG - 2017-01-17 18:41:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 18:41:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-17 18:41:57 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-17 18:41:57 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-17 18:41:57 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-17 18:41:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 18:41:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 18:41:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 18:41:57 --> Final output sent to browser
DEBUG - 2017-01-17 18:41:57 --> Total execution time: 0.0272
INFO - 2017-01-17 18:42:02 --> Config Class Initialized
INFO - 2017-01-17 18:42:02 --> Hooks Class Initialized
DEBUG - 2017-01-17 18:42:02 --> UTF-8 Support Enabled
INFO - 2017-01-17 18:42:02 --> Utf8 Class Initialized
INFO - 2017-01-17 18:42:02 --> URI Class Initialized
INFO - 2017-01-17 18:42:02 --> Router Class Initialized
INFO - 2017-01-17 18:42:02 --> Output Class Initialized
INFO - 2017-01-17 18:42:02 --> Security Class Initialized
DEBUG - 2017-01-17 18:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 18:42:02 --> Input Class Initialized
INFO - 2017-01-17 18:42:02 --> Language Class Initialized
INFO - 2017-01-17 18:42:02 --> Loader Class Initialized
INFO - 2017-01-17 18:42:02 --> Database Driver Class Initialized
INFO - 2017-01-17 18:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 18:42:02 --> Controller Class Initialized
INFO - 2017-01-17 18:42:02 --> Helper loaded: url_helper
DEBUG - 2017-01-17 18:42:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 18:42:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 18:42:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 18:42:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 18:42:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 18:42:02 --> Final output sent to browser
DEBUG - 2017-01-17 18:42:02 --> Total execution time: 0.0139
INFO - 2017-01-17 20:04:04 --> Config Class Initialized
INFO - 2017-01-17 20:04:04 --> Hooks Class Initialized
DEBUG - 2017-01-17 20:04:04 --> UTF-8 Support Enabled
INFO - 2017-01-17 20:04:04 --> Utf8 Class Initialized
INFO - 2017-01-17 20:04:04 --> URI Class Initialized
DEBUG - 2017-01-17 20:04:04 --> No URI present. Default controller set.
INFO - 2017-01-17 20:04:04 --> Router Class Initialized
INFO - 2017-01-17 20:04:04 --> Output Class Initialized
INFO - 2017-01-17 20:04:04 --> Security Class Initialized
DEBUG - 2017-01-17 20:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 20:04:04 --> Input Class Initialized
INFO - 2017-01-17 20:04:04 --> Language Class Initialized
INFO - 2017-01-17 20:04:04 --> Loader Class Initialized
INFO - 2017-01-17 20:04:04 --> Database Driver Class Initialized
INFO - 2017-01-17 20:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 20:04:04 --> Controller Class Initialized
INFO - 2017-01-17 20:04:04 --> Helper loaded: url_helper
DEBUG - 2017-01-17 20:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 20:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 20:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 20:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 20:04:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 20:04:04 --> Final output sent to browser
DEBUG - 2017-01-17 20:04:04 --> Total execution time: 0.0136
INFO - 2017-01-17 20:04:33 --> Config Class Initialized
INFO - 2017-01-17 20:04:33 --> Hooks Class Initialized
DEBUG - 2017-01-17 20:04:33 --> UTF-8 Support Enabled
INFO - 2017-01-17 20:04:33 --> Utf8 Class Initialized
INFO - 2017-01-17 20:04:33 --> URI Class Initialized
INFO - 2017-01-17 20:04:33 --> Router Class Initialized
INFO - 2017-01-17 20:04:33 --> Output Class Initialized
INFO - 2017-01-17 20:04:33 --> Security Class Initialized
DEBUG - 2017-01-17 20:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 20:04:33 --> Input Class Initialized
INFO - 2017-01-17 20:04:33 --> Language Class Initialized
INFO - 2017-01-17 20:04:33 --> Loader Class Initialized
INFO - 2017-01-17 20:04:33 --> Database Driver Class Initialized
INFO - 2017-01-17 20:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 20:04:33 --> Controller Class Initialized
INFO - 2017-01-17 20:04:33 --> Helper loaded: url_helper
DEBUG - 2017-01-17 20:04:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 20:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 20:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 20:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 20:04:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 20:04:33 --> Final output sent to browser
DEBUG - 2017-01-17 20:04:33 --> Total execution time: 0.0161
INFO - 2017-01-17 20:05:00 --> Config Class Initialized
INFO - 2017-01-17 20:05:00 --> Hooks Class Initialized
DEBUG - 2017-01-17 20:05:00 --> UTF-8 Support Enabled
INFO - 2017-01-17 20:05:00 --> Utf8 Class Initialized
INFO - 2017-01-17 20:05:00 --> URI Class Initialized
INFO - 2017-01-17 20:05:00 --> Router Class Initialized
INFO - 2017-01-17 20:05:00 --> Output Class Initialized
INFO - 2017-01-17 20:05:00 --> Security Class Initialized
DEBUG - 2017-01-17 20:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 20:05:00 --> Input Class Initialized
INFO - 2017-01-17 20:05:00 --> Language Class Initialized
INFO - 2017-01-17 20:05:00 --> Loader Class Initialized
INFO - 2017-01-17 20:05:00 --> Database Driver Class Initialized
INFO - 2017-01-17 20:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 20:05:00 --> Controller Class Initialized
INFO - 2017-01-17 20:05:00 --> Helper loaded: url_helper
DEBUG - 2017-01-17 20:05:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 20:05:00 --> Config Class Initialized
INFO - 2017-01-17 20:05:00 --> Hooks Class Initialized
DEBUG - 2017-01-17 20:05:00 --> UTF-8 Support Enabled
INFO - 2017-01-17 20:05:00 --> Utf8 Class Initialized
INFO - 2017-01-17 20:05:00 --> URI Class Initialized
INFO - 2017-01-17 20:05:00 --> Router Class Initialized
INFO - 2017-01-17 20:05:00 --> Output Class Initialized
INFO - 2017-01-17 20:05:00 --> Security Class Initialized
DEBUG - 2017-01-17 20:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 20:05:00 --> Input Class Initialized
INFO - 2017-01-17 20:05:00 --> Language Class Initialized
INFO - 2017-01-17 20:05:00 --> Loader Class Initialized
INFO - 2017-01-17 20:05:00 --> Database Driver Class Initialized
INFO - 2017-01-17 20:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 20:05:00 --> Controller Class Initialized
INFO - 2017-01-17 20:05:00 --> Helper loaded: date_helper
DEBUG - 2017-01-17 20:05:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 20:05:00 --> Helper loaded: url_helper
INFO - 2017-01-17 20:05:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 20:05:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-17 20:05:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-17 20:05:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-17 20:05:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 20:05:00 --> Final output sent to browser
DEBUG - 2017-01-17 20:05:00 --> Total execution time: 0.0140
INFO - 2017-01-17 21:47:45 --> Config Class Initialized
INFO - 2017-01-17 21:47:45 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:47:45 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:47:45 --> Utf8 Class Initialized
INFO - 2017-01-17 21:47:45 --> URI Class Initialized
DEBUG - 2017-01-17 21:47:45 --> No URI present. Default controller set.
INFO - 2017-01-17 21:47:45 --> Router Class Initialized
INFO - 2017-01-17 21:47:45 --> Output Class Initialized
INFO - 2017-01-17 21:47:45 --> Security Class Initialized
DEBUG - 2017-01-17 21:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:47:45 --> Input Class Initialized
INFO - 2017-01-17 21:47:45 --> Language Class Initialized
INFO - 2017-01-17 21:47:45 --> Loader Class Initialized
INFO - 2017-01-17 21:47:45 --> Database Driver Class Initialized
INFO - 2017-01-17 21:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:47:45 --> Controller Class Initialized
INFO - 2017-01-17 21:47:45 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:47:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 21:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 21:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 21:47:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 21:47:45 --> Final output sent to browser
DEBUG - 2017-01-17 21:47:45 --> Total execution time: 0.0136
INFO - 2017-01-17 21:47:47 --> Config Class Initialized
INFO - 2017-01-17 21:47:47 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:47:47 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:47:47 --> Utf8 Class Initialized
INFO - 2017-01-17 21:47:47 --> URI Class Initialized
INFO - 2017-01-17 21:47:47 --> Router Class Initialized
INFO - 2017-01-17 21:47:47 --> Output Class Initialized
INFO - 2017-01-17 21:47:47 --> Security Class Initialized
DEBUG - 2017-01-17 21:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:47:47 --> Input Class Initialized
INFO - 2017-01-17 21:47:47 --> Language Class Initialized
INFO - 2017-01-17 21:47:47 --> Loader Class Initialized
INFO - 2017-01-17 21:47:47 --> Database Driver Class Initialized
INFO - 2017-01-17 21:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:47:47 --> Controller Class Initialized
INFO - 2017-01-17 21:47:47 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:47:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 21:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 21:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 21:47:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 21:47:47 --> Final output sent to browser
DEBUG - 2017-01-17 21:47:47 --> Total execution time: 0.0174
INFO - 2017-01-17 21:48:15 --> Config Class Initialized
INFO - 2017-01-17 21:48:15 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:48:15 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:48:15 --> Utf8 Class Initialized
INFO - 2017-01-17 21:48:15 --> URI Class Initialized
INFO - 2017-01-17 21:48:15 --> Router Class Initialized
INFO - 2017-01-17 21:48:15 --> Output Class Initialized
INFO - 2017-01-17 21:48:15 --> Security Class Initialized
DEBUG - 2017-01-17 21:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:48:15 --> Input Class Initialized
INFO - 2017-01-17 21:48:15 --> Language Class Initialized
ERROR - 2017-01-17 21:48:15 --> 404 Page Not Found: Templates/usuario
INFO - 2017-01-17 21:48:34 --> Config Class Initialized
INFO - 2017-01-17 21:48:34 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:48:34 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:48:34 --> Utf8 Class Initialized
INFO - 2017-01-17 21:48:34 --> URI Class Initialized
INFO - 2017-01-17 21:48:34 --> Router Class Initialized
INFO - 2017-01-17 21:48:34 --> Output Class Initialized
INFO - 2017-01-17 21:48:34 --> Security Class Initialized
DEBUG - 2017-01-17 21:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:48:34 --> Input Class Initialized
INFO - 2017-01-17 21:48:34 --> Language Class Initialized
INFO - 2017-01-17 21:48:34 --> Loader Class Initialized
INFO - 2017-01-17 21:48:34 --> Database Driver Class Initialized
INFO - 2017-01-17 21:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:48:34 --> Controller Class Initialized
INFO - 2017-01-17 21:48:34 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:48:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:48:34 --> Helper loaded: form_helper
INFO - 2017-01-17 21:48:34 --> Form Validation Class Initialized
INFO - 2017-01-17 21:48:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-17 21:48:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-17 21:48:34 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-17 21:48:34 --> Final output sent to browser
DEBUG - 2017-01-17 21:48:34 --> Total execution time: 0.2948
INFO - 2017-01-17 21:48:35 --> Config Class Initialized
INFO - 2017-01-17 21:48:35 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:48:35 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:48:35 --> Utf8 Class Initialized
INFO - 2017-01-17 21:48:35 --> URI Class Initialized
INFO - 2017-01-17 21:48:35 --> Router Class Initialized
INFO - 2017-01-17 21:48:35 --> Output Class Initialized
INFO - 2017-01-17 21:48:35 --> Security Class Initialized
DEBUG - 2017-01-17 21:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:48:35 --> Input Class Initialized
INFO - 2017-01-17 21:48:35 --> Language Class Initialized
INFO - 2017-01-17 21:48:35 --> Loader Class Initialized
INFO - 2017-01-17 21:48:35 --> Database Driver Class Initialized
INFO - 2017-01-17 21:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:48:35 --> Controller Class Initialized
INFO - 2017-01-17 21:48:35 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:48:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:48:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 21:48:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 21:48:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 21:48:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 21:48:35 --> Final output sent to browser
DEBUG - 2017-01-17 21:48:35 --> Total execution time: 0.0135
INFO - 2017-01-17 21:48:51 --> Config Class Initialized
INFO - 2017-01-17 21:48:51 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:48:51 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:48:51 --> Utf8 Class Initialized
INFO - 2017-01-17 21:48:51 --> URI Class Initialized
INFO - 2017-01-17 21:48:51 --> Router Class Initialized
INFO - 2017-01-17 21:48:51 --> Output Class Initialized
INFO - 2017-01-17 21:48:51 --> Security Class Initialized
DEBUG - 2017-01-17 21:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:48:51 --> Input Class Initialized
INFO - 2017-01-17 21:48:51 --> Language Class Initialized
INFO - 2017-01-17 21:48:51 --> Loader Class Initialized
INFO - 2017-01-17 21:48:51 --> Database Driver Class Initialized
INFO - 2017-01-17 21:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:48:51 --> Controller Class Initialized
INFO - 2017-01-17 21:48:51 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:48:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:48:51 --> Helper loaded: form_helper
INFO - 2017-01-17 21:48:51 --> Form Validation Class Initialized
INFO - 2017-01-17 21:48:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-17 21:48:52 --> Config Class Initialized
INFO - 2017-01-17 21:48:52 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:48:52 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:48:52 --> Utf8 Class Initialized
INFO - 2017-01-17 21:48:52 --> URI Class Initialized
INFO - 2017-01-17 21:48:52 --> Router Class Initialized
INFO - 2017-01-17 21:48:52 --> Output Class Initialized
INFO - 2017-01-17 21:48:52 --> Security Class Initialized
DEBUG - 2017-01-17 21:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:48:52 --> Input Class Initialized
INFO - 2017-01-17 21:48:52 --> Language Class Initialized
INFO - 2017-01-17 21:48:52 --> Loader Class Initialized
INFO - 2017-01-17 21:48:52 --> Database Driver Class Initialized
INFO - 2017-01-17 21:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:48:52 --> Controller Class Initialized
INFO - 2017-01-17 21:48:52 --> Helper loaded: date_helper
INFO - 2017-01-17 21:48:52 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:48:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:48:52 --> Helper loaded: form_helper
INFO - 2017-01-17 21:48:52 --> Form Validation Class Initialized
INFO - 2017-01-17 21:48:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-17 21:48:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-17 21:48:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-17 21:48:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-17 21:48:52 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-17 21:48:52 --> Final output sent to browser
DEBUG - 2017-01-17 21:48:52 --> Total execution time: 0.0726
INFO - 2017-01-17 21:48:52 --> Config Class Initialized
INFO - 2017-01-17 21:48:52 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:48:52 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:48:52 --> Utf8 Class Initialized
INFO - 2017-01-17 21:48:52 --> URI Class Initialized
INFO - 2017-01-17 21:48:52 --> Router Class Initialized
INFO - 2017-01-17 21:48:52 --> Output Class Initialized
INFO - 2017-01-17 21:48:52 --> Security Class Initialized
DEBUG - 2017-01-17 21:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:48:52 --> Input Class Initialized
INFO - 2017-01-17 21:48:52 --> Language Class Initialized
INFO - 2017-01-17 21:48:52 --> Loader Class Initialized
INFO - 2017-01-17 21:48:52 --> Database Driver Class Initialized
INFO - 2017-01-17 21:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:48:52 --> Controller Class Initialized
INFO - 2017-01-17 21:48:52 --> Helper loaded: date_helper
INFO - 2017-01-17 21:48:52 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:48:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:48:52 --> Helper loaded: form_helper
INFO - 2017-01-17 21:48:52 --> Form Validation Class Initialized
INFO - 2017-01-17 21:48:52 --> Final output sent to browser
DEBUG - 2017-01-17 21:48:52 --> Total execution time: 0.0531
INFO - 2017-01-17 21:48:56 --> Config Class Initialized
INFO - 2017-01-17 21:48:56 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:48:56 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:48:56 --> Utf8 Class Initialized
INFO - 2017-01-17 21:48:56 --> URI Class Initialized
INFO - 2017-01-17 21:48:56 --> Router Class Initialized
INFO - 2017-01-17 21:48:56 --> Output Class Initialized
INFO - 2017-01-17 21:48:56 --> Security Class Initialized
DEBUG - 2017-01-17 21:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:48:56 --> Input Class Initialized
INFO - 2017-01-17 21:48:56 --> Language Class Initialized
INFO - 2017-01-17 21:48:56 --> Loader Class Initialized
INFO - 2017-01-17 21:48:56 --> Database Driver Class Initialized
INFO - 2017-01-17 21:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:48:56 --> Controller Class Initialized
INFO - 2017-01-17 21:48:56 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:48:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:48:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 21:48:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 21:48:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 21:48:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 21:48:56 --> Final output sent to browser
DEBUG - 2017-01-17 21:48:56 --> Total execution time: 0.0133
INFO - 2017-01-17 21:48:59 --> Config Class Initialized
INFO - 2017-01-17 21:48:59 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:48:59 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:48:59 --> Utf8 Class Initialized
INFO - 2017-01-17 21:48:59 --> URI Class Initialized
INFO - 2017-01-17 21:48:59 --> Router Class Initialized
INFO - 2017-01-17 21:48:59 --> Output Class Initialized
INFO - 2017-01-17 21:48:59 --> Security Class Initialized
DEBUG - 2017-01-17 21:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:48:59 --> Input Class Initialized
INFO - 2017-01-17 21:48:59 --> Language Class Initialized
INFO - 2017-01-17 21:48:59 --> Loader Class Initialized
INFO - 2017-01-17 21:48:59 --> Database Driver Class Initialized
INFO - 2017-01-17 21:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:48:59 --> Controller Class Initialized
INFO - 2017-01-17 21:48:59 --> Upload Class Initialized
INFO - 2017-01-17 21:48:59 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:48:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:48:59 --> Helper loaded: form_helper
INFO - 2017-01-17 21:48:59 --> Form Validation Class Initialized
INFO - 2017-01-17 21:48:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-17 21:48:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-17 21:48:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-17 21:48:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-17 21:48:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-17 21:48:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-17 21:48:59 --> Final output sent to browser
DEBUG - 2017-01-17 21:48:59 --> Total execution time: 0.0688
INFO - 2017-01-17 21:49:00 --> Config Class Initialized
INFO - 2017-01-17 21:49:00 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:49:00 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:49:00 --> Utf8 Class Initialized
INFO - 2017-01-17 21:49:00 --> URI Class Initialized
INFO - 2017-01-17 21:49:00 --> Router Class Initialized
INFO - 2017-01-17 21:49:00 --> Output Class Initialized
INFO - 2017-01-17 21:49:00 --> Security Class Initialized
DEBUG - 2017-01-17 21:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:49:00 --> Input Class Initialized
INFO - 2017-01-17 21:49:00 --> Language Class Initialized
INFO - 2017-01-17 21:49:00 --> Loader Class Initialized
INFO - 2017-01-17 21:49:00 --> Database Driver Class Initialized
INFO - 2017-01-17 21:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:49:00 --> Controller Class Initialized
INFO - 2017-01-17 21:49:00 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:49:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 21:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 21:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 21:49:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 21:49:00 --> Final output sent to browser
DEBUG - 2017-01-17 21:49:00 --> Total execution time: 0.0137
INFO - 2017-01-17 21:49:17 --> Config Class Initialized
INFO - 2017-01-17 21:49:17 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:49:17 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:49:17 --> Utf8 Class Initialized
INFO - 2017-01-17 21:49:17 --> URI Class Initialized
INFO - 2017-01-17 21:49:17 --> Router Class Initialized
INFO - 2017-01-17 21:49:17 --> Output Class Initialized
INFO - 2017-01-17 21:49:17 --> Security Class Initialized
DEBUG - 2017-01-17 21:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:49:17 --> Input Class Initialized
INFO - 2017-01-17 21:49:17 --> Language Class Initialized
INFO - 2017-01-17 21:49:17 --> Loader Class Initialized
INFO - 2017-01-17 21:49:17 --> Database Driver Class Initialized
INFO - 2017-01-17 21:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:49:17 --> Controller Class Initialized
INFO - 2017-01-17 21:49:17 --> Upload Class Initialized
INFO - 2017-01-17 21:49:17 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:49:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:49:17 --> Helper loaded: form_helper
INFO - 2017-01-17 21:49:17 --> Form Validation Class Initialized
INFO - 2017-01-17 21:49:17 --> Final output sent to browser
DEBUG - 2017-01-17 21:49:17 --> Total execution time: 0.0168
INFO - 2017-01-17 21:49:29 --> Config Class Initialized
INFO - 2017-01-17 21:49:29 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:49:29 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:49:29 --> Utf8 Class Initialized
INFO - 2017-01-17 21:49:29 --> URI Class Initialized
INFO - 2017-01-17 21:49:29 --> Router Class Initialized
INFO - 2017-01-17 21:49:29 --> Output Class Initialized
INFO - 2017-01-17 21:49:29 --> Security Class Initialized
DEBUG - 2017-01-17 21:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:49:29 --> Input Class Initialized
INFO - 2017-01-17 21:49:29 --> Language Class Initialized
INFO - 2017-01-17 21:49:29 --> Loader Class Initialized
INFO - 2017-01-17 21:49:29 --> Database Driver Class Initialized
INFO - 2017-01-17 21:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:49:29 --> Controller Class Initialized
INFO - 2017-01-17 21:49:29 --> Upload Class Initialized
INFO - 2017-01-17 21:49:29 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:49:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:49:29 --> Helper loaded: form_helper
INFO - 2017-01-17 21:49:29 --> Form Validation Class Initialized
INFO - 2017-01-17 21:49:29 --> Final output sent to browser
DEBUG - 2017-01-17 21:49:29 --> Total execution time: 0.0256
INFO - 2017-01-17 21:49:50 --> Config Class Initialized
INFO - 2017-01-17 21:49:50 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:49:50 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:49:50 --> Utf8 Class Initialized
INFO - 2017-01-17 21:49:50 --> URI Class Initialized
INFO - 2017-01-17 21:49:50 --> Router Class Initialized
INFO - 2017-01-17 21:49:50 --> Output Class Initialized
INFO - 2017-01-17 21:49:50 --> Security Class Initialized
DEBUG - 2017-01-17 21:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:49:50 --> Input Class Initialized
INFO - 2017-01-17 21:49:50 --> Language Class Initialized
INFO - 2017-01-17 21:49:50 --> Loader Class Initialized
INFO - 2017-01-17 21:49:50 --> Database Driver Class Initialized
INFO - 2017-01-17 21:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:49:50 --> Controller Class Initialized
INFO - 2017-01-17 21:49:50 --> Upload Class Initialized
INFO - 2017-01-17 21:49:50 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:49:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:49:50 --> Helper loaded: form_helper
INFO - 2017-01-17 21:49:50 --> Form Validation Class Initialized
INFO - 2017-01-17 21:49:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-17 21:49:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-17 21:49:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-17 21:49:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-17 21:49:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-17 21:49:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-17 21:49:50 --> Final output sent to browser
DEBUG - 2017-01-17 21:49:50 --> Total execution time: 0.0452
INFO - 2017-01-17 21:49:51 --> Config Class Initialized
INFO - 2017-01-17 21:49:51 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:49:51 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:49:51 --> Utf8 Class Initialized
INFO - 2017-01-17 21:49:51 --> URI Class Initialized
INFO - 2017-01-17 21:49:51 --> Router Class Initialized
INFO - 2017-01-17 21:49:51 --> Output Class Initialized
INFO - 2017-01-17 21:49:51 --> Security Class Initialized
DEBUG - 2017-01-17 21:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:49:51 --> Input Class Initialized
INFO - 2017-01-17 21:49:51 --> Language Class Initialized
INFO - 2017-01-17 21:49:51 --> Loader Class Initialized
INFO - 2017-01-17 21:49:51 --> Database Driver Class Initialized
INFO - 2017-01-17 21:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:49:51 --> Controller Class Initialized
INFO - 2017-01-17 21:49:51 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:49:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:49:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 21:49:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 21:49:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 21:49:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 21:49:51 --> Final output sent to browser
DEBUG - 2017-01-17 21:49:51 --> Total execution time: 0.0141
INFO - 2017-01-17 21:50:03 --> Config Class Initialized
INFO - 2017-01-17 21:50:03 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:50:03 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:50:03 --> Utf8 Class Initialized
INFO - 2017-01-17 21:50:03 --> URI Class Initialized
INFO - 2017-01-17 21:50:03 --> Router Class Initialized
INFO - 2017-01-17 21:50:03 --> Output Class Initialized
INFO - 2017-01-17 21:50:03 --> Security Class Initialized
DEBUG - 2017-01-17 21:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:50:03 --> Input Class Initialized
INFO - 2017-01-17 21:50:03 --> Language Class Initialized
INFO - 2017-01-17 21:50:03 --> Loader Class Initialized
INFO - 2017-01-17 21:50:03 --> Database Driver Class Initialized
INFO - 2017-01-17 21:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:50:03 --> Controller Class Initialized
INFO - 2017-01-17 21:50:03 --> Upload Class Initialized
INFO - 2017-01-17 21:50:03 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:50:03 --> Helper loaded: form_helper
INFO - 2017-01-17 21:50:03 --> Form Validation Class Initialized
INFO - 2017-01-17 21:50:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-17 21:50:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-17 21:50:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-17 21:50:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-17 21:50:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-17 21:50:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-17 21:50:03 --> Final output sent to browser
DEBUG - 2017-01-17 21:50:03 --> Total execution time: 0.0244
INFO - 2017-01-17 21:50:04 --> Config Class Initialized
INFO - 2017-01-17 21:50:04 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:50:04 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:50:04 --> Utf8 Class Initialized
INFO - 2017-01-17 21:50:04 --> URI Class Initialized
INFO - 2017-01-17 21:50:04 --> Router Class Initialized
INFO - 2017-01-17 21:50:04 --> Output Class Initialized
INFO - 2017-01-17 21:50:04 --> Security Class Initialized
DEBUG - 2017-01-17 21:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:50:04 --> Input Class Initialized
INFO - 2017-01-17 21:50:04 --> Language Class Initialized
INFO - 2017-01-17 21:50:04 --> Loader Class Initialized
INFO - 2017-01-17 21:50:04 --> Database Driver Class Initialized
INFO - 2017-01-17 21:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:50:04 --> Controller Class Initialized
INFO - 2017-01-17 21:50:04 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:50:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:50:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 21:50:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 21:50:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 21:50:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 21:50:04 --> Final output sent to browser
DEBUG - 2017-01-17 21:50:04 --> Total execution time: 0.0144
INFO - 2017-01-17 21:50:38 --> Config Class Initialized
INFO - 2017-01-17 21:50:38 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:50:38 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:50:38 --> Utf8 Class Initialized
INFO - 2017-01-17 21:50:38 --> URI Class Initialized
INFO - 2017-01-17 21:50:38 --> Router Class Initialized
INFO - 2017-01-17 21:50:38 --> Output Class Initialized
INFO - 2017-01-17 21:50:38 --> Security Class Initialized
DEBUG - 2017-01-17 21:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:50:38 --> Input Class Initialized
INFO - 2017-01-17 21:50:38 --> Language Class Initialized
INFO - 2017-01-17 21:50:38 --> Loader Class Initialized
INFO - 2017-01-17 21:50:38 --> Database Driver Class Initialized
INFO - 2017-01-17 21:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:50:38 --> Controller Class Initialized
INFO - 2017-01-17 21:50:38 --> Helper loaded: date_helper
INFO - 2017-01-17 21:50:38 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:50:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:50:38 --> Helper loaded: form_helper
INFO - 2017-01-17 21:50:38 --> Form Validation Class Initialized
INFO - 2017-01-17 21:50:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-17 21:50:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-17 21:50:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-17 21:50:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-17 21:50:38 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-17 21:50:38 --> Final output sent to browser
DEBUG - 2017-01-17 21:50:38 --> Total execution time: 0.0469
INFO - 2017-01-17 21:50:39 --> Config Class Initialized
INFO - 2017-01-17 21:50:39 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:50:39 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:50:39 --> Utf8 Class Initialized
INFO - 2017-01-17 21:50:39 --> URI Class Initialized
INFO - 2017-01-17 21:50:39 --> Router Class Initialized
INFO - 2017-01-17 21:50:39 --> Output Class Initialized
INFO - 2017-01-17 21:50:39 --> Security Class Initialized
DEBUG - 2017-01-17 21:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:50:39 --> Input Class Initialized
INFO - 2017-01-17 21:50:39 --> Language Class Initialized
INFO - 2017-01-17 21:50:39 --> Loader Class Initialized
INFO - 2017-01-17 21:50:39 --> Database Driver Class Initialized
INFO - 2017-01-17 21:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:50:39 --> Controller Class Initialized
INFO - 2017-01-17 21:50:39 --> Helper loaded: date_helper
INFO - 2017-01-17 21:50:39 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:50:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:50:39 --> Helper loaded: form_helper
INFO - 2017-01-17 21:50:39 --> Form Validation Class Initialized
INFO - 2017-01-17 21:50:39 --> Final output sent to browser
DEBUG - 2017-01-17 21:50:39 --> Total execution time: 0.0383
INFO - 2017-01-17 21:50:39 --> Config Class Initialized
INFO - 2017-01-17 21:50:39 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:50:39 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:50:39 --> Utf8 Class Initialized
INFO - 2017-01-17 21:50:39 --> URI Class Initialized
INFO - 2017-01-17 21:50:39 --> Router Class Initialized
INFO - 2017-01-17 21:50:39 --> Output Class Initialized
INFO - 2017-01-17 21:50:39 --> Security Class Initialized
DEBUG - 2017-01-17 21:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:50:39 --> Input Class Initialized
INFO - 2017-01-17 21:50:39 --> Language Class Initialized
INFO - 2017-01-17 21:50:39 --> Loader Class Initialized
INFO - 2017-01-17 21:50:39 --> Database Driver Class Initialized
INFO - 2017-01-17 21:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:50:39 --> Controller Class Initialized
INFO - 2017-01-17 21:50:39 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:50:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:50:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 21:50:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 21:50:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 21:50:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 21:50:39 --> Final output sent to browser
DEBUG - 2017-01-17 21:50:39 --> Total execution time: 0.0144
INFO - 2017-01-17 21:50:42 --> Config Class Initialized
INFO - 2017-01-17 21:50:42 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:50:42 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:50:42 --> Utf8 Class Initialized
INFO - 2017-01-17 21:50:42 --> URI Class Initialized
INFO - 2017-01-17 21:50:42 --> Router Class Initialized
INFO - 2017-01-17 21:50:42 --> Output Class Initialized
INFO - 2017-01-17 21:50:42 --> Security Class Initialized
DEBUG - 2017-01-17 21:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:50:42 --> Input Class Initialized
INFO - 2017-01-17 21:50:42 --> Language Class Initialized
INFO - 2017-01-17 21:50:42 --> Loader Class Initialized
INFO - 2017-01-17 21:50:42 --> Database Driver Class Initialized
INFO - 2017-01-17 21:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:50:42 --> Controller Class Initialized
INFO - 2017-01-17 21:50:42 --> Helper loaded: date_helper
INFO - 2017-01-17 21:50:42 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:50:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:50:42 --> Helper loaded: form_helper
INFO - 2017-01-17 21:50:42 --> Form Validation Class Initialized
INFO - 2017-01-17 21:50:42 --> Final output sent to browser
DEBUG - 2017-01-17 21:50:42 --> Total execution time: 0.0410
INFO - 2017-01-17 21:50:44 --> Config Class Initialized
INFO - 2017-01-17 21:50:44 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:50:44 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:50:44 --> Utf8 Class Initialized
INFO - 2017-01-17 21:50:44 --> URI Class Initialized
INFO - 2017-01-17 21:50:44 --> Router Class Initialized
INFO - 2017-01-17 21:50:44 --> Output Class Initialized
INFO - 2017-01-17 21:50:44 --> Security Class Initialized
DEBUG - 2017-01-17 21:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:50:44 --> Input Class Initialized
INFO - 2017-01-17 21:50:44 --> Language Class Initialized
INFO - 2017-01-17 21:50:44 --> Loader Class Initialized
INFO - 2017-01-17 21:50:44 --> Database Driver Class Initialized
INFO - 2017-01-17 21:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:50:44 --> Controller Class Initialized
INFO - 2017-01-17 21:50:44 --> Helper loaded: date_helper
INFO - 2017-01-17 21:50:44 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:50:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:50:44 --> Helper loaded: form_helper
INFO - 2017-01-17 21:50:44 --> Form Validation Class Initialized
INFO - 2017-01-17 21:50:44 --> Final output sent to browser
DEBUG - 2017-01-17 21:50:44 --> Total execution time: 0.0146
INFO - 2017-01-17 21:50:50 --> Config Class Initialized
INFO - 2017-01-17 21:50:50 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:50:50 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:50:50 --> Utf8 Class Initialized
INFO - 2017-01-17 21:50:50 --> URI Class Initialized
INFO - 2017-01-17 21:50:50 --> Router Class Initialized
INFO - 2017-01-17 21:50:50 --> Output Class Initialized
INFO - 2017-01-17 21:50:50 --> Security Class Initialized
DEBUG - 2017-01-17 21:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:50:50 --> Input Class Initialized
INFO - 2017-01-17 21:50:50 --> Language Class Initialized
INFO - 2017-01-17 21:50:50 --> Loader Class Initialized
INFO - 2017-01-17 21:50:50 --> Database Driver Class Initialized
INFO - 2017-01-17 21:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:50:50 --> Controller Class Initialized
INFO - 2017-01-17 21:50:50 --> Helper loaded: date_helper
INFO - 2017-01-17 21:50:50 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:50:50 --> Helper loaded: form_helper
INFO - 2017-01-17 21:50:50 --> Form Validation Class Initialized
INFO - 2017-01-17 21:50:50 --> Final output sent to browser
DEBUG - 2017-01-17 21:50:50 --> Total execution time: 0.0143
INFO - 2017-01-17 21:50:50 --> Config Class Initialized
INFO - 2017-01-17 21:50:50 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:50:50 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:50:50 --> Utf8 Class Initialized
INFO - 2017-01-17 21:50:50 --> URI Class Initialized
INFO - 2017-01-17 21:50:50 --> Router Class Initialized
INFO - 2017-01-17 21:50:50 --> Output Class Initialized
INFO - 2017-01-17 21:50:50 --> Security Class Initialized
DEBUG - 2017-01-17 21:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:50:50 --> Input Class Initialized
INFO - 2017-01-17 21:50:50 --> Language Class Initialized
INFO - 2017-01-17 21:50:50 --> Loader Class Initialized
INFO - 2017-01-17 21:50:50 --> Database Driver Class Initialized
INFO - 2017-01-17 21:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:50:50 --> Controller Class Initialized
INFO - 2017-01-17 21:50:50 --> Helper loaded: date_helper
INFO - 2017-01-17 21:50:50 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:50:50 --> Helper loaded: form_helper
INFO - 2017-01-17 21:50:50 --> Form Validation Class Initialized
INFO - 2017-01-17 21:50:50 --> Final output sent to browser
DEBUG - 2017-01-17 21:50:50 --> Total execution time: 0.0142
INFO - 2017-01-17 21:51:00 --> Config Class Initialized
INFO - 2017-01-17 21:51:00 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:51:00 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:51:00 --> Utf8 Class Initialized
INFO - 2017-01-17 21:51:00 --> URI Class Initialized
INFO - 2017-01-17 21:51:00 --> Router Class Initialized
INFO - 2017-01-17 21:51:00 --> Output Class Initialized
INFO - 2017-01-17 21:51:00 --> Security Class Initialized
DEBUG - 2017-01-17 21:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:51:00 --> Input Class Initialized
INFO - 2017-01-17 21:51:00 --> Language Class Initialized
INFO - 2017-01-17 21:51:00 --> Loader Class Initialized
INFO - 2017-01-17 21:51:00 --> Database Driver Class Initialized
INFO - 2017-01-17 21:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:51:00 --> Controller Class Initialized
INFO - 2017-01-17 21:51:00 --> Upload Class Initialized
INFO - 2017-01-17 21:51:00 --> Helper loaded: date_helper
INFO - 2017-01-17 21:51:00 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:51:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:51:00 --> Helper loaded: form_helper
INFO - 2017-01-17 21:51:00 --> Form Validation Class Initialized
INFO - 2017-01-17 21:51:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-17 21:51:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-17 21:51:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-17 21:51:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-17 21:51:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-17 21:51:00 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-17 21:51:00 --> Final output sent to browser
DEBUG - 2017-01-17 21:51:00 --> Total execution time: 0.0849
INFO - 2017-01-17 21:51:01 --> Config Class Initialized
INFO - 2017-01-17 21:51:01 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:51:01 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:51:01 --> Utf8 Class Initialized
INFO - 2017-01-17 21:51:01 --> URI Class Initialized
INFO - 2017-01-17 21:51:01 --> Router Class Initialized
INFO - 2017-01-17 21:51:01 --> Output Class Initialized
INFO - 2017-01-17 21:51:01 --> Security Class Initialized
DEBUG - 2017-01-17 21:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:51:01 --> Input Class Initialized
INFO - 2017-01-17 21:51:01 --> Language Class Initialized
INFO - 2017-01-17 21:51:01 --> Loader Class Initialized
INFO - 2017-01-17 21:51:01 --> Database Driver Class Initialized
INFO - 2017-01-17 21:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:51:01 --> Controller Class Initialized
INFO - 2017-01-17 21:51:01 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:51:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 21:51:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 21:51:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 21:51:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 21:51:01 --> Final output sent to browser
DEBUG - 2017-01-17 21:51:01 --> Total execution time: 0.0660
INFO - 2017-01-17 21:51:02 --> Config Class Initialized
INFO - 2017-01-17 21:51:02 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:51:02 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:51:02 --> Utf8 Class Initialized
INFO - 2017-01-17 21:51:02 --> URI Class Initialized
INFO - 2017-01-17 21:51:02 --> Router Class Initialized
INFO - 2017-01-17 21:51:02 --> Output Class Initialized
INFO - 2017-01-17 21:51:02 --> Security Class Initialized
DEBUG - 2017-01-17 21:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:51:02 --> Input Class Initialized
INFO - 2017-01-17 21:51:02 --> Language Class Initialized
INFO - 2017-01-17 21:51:02 --> Loader Class Initialized
INFO - 2017-01-17 21:51:02 --> Database Driver Class Initialized
INFO - 2017-01-17 21:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:51:02 --> Controller Class Initialized
INFO - 2017-01-17 21:51:02 --> Helper loaded: date_helper
INFO - 2017-01-17 21:51:02 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:51:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:51:02 --> Helper loaded: form_helper
INFO - 2017-01-17 21:51:02 --> Form Validation Class Initialized
INFO - 2017-01-17 21:51:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-17 21:51:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-17 21:51:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-17 21:51:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-17 21:51:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-17 21:51:02 --> Final output sent to browser
DEBUG - 2017-01-17 21:51:02 --> Total execution time: 0.0139
INFO - 2017-01-17 21:51:02 --> Config Class Initialized
INFO - 2017-01-17 21:51:02 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:51:02 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:51:02 --> Utf8 Class Initialized
INFO - 2017-01-17 21:51:02 --> URI Class Initialized
INFO - 2017-01-17 21:51:02 --> Router Class Initialized
INFO - 2017-01-17 21:51:02 --> Output Class Initialized
INFO - 2017-01-17 21:51:02 --> Security Class Initialized
DEBUG - 2017-01-17 21:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:51:02 --> Input Class Initialized
INFO - 2017-01-17 21:51:02 --> Language Class Initialized
INFO - 2017-01-17 21:51:02 --> Loader Class Initialized
INFO - 2017-01-17 21:51:02 --> Database Driver Class Initialized
INFO - 2017-01-17 21:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:51:02 --> Controller Class Initialized
INFO - 2017-01-17 21:51:02 --> Helper loaded: date_helper
INFO - 2017-01-17 21:51:02 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:51:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:51:02 --> Helper loaded: form_helper
INFO - 2017-01-17 21:51:02 --> Form Validation Class Initialized
INFO - 2017-01-17 21:51:02 --> Final output sent to browser
DEBUG - 2017-01-17 21:51:02 --> Total execution time: 0.0145
INFO - 2017-01-17 21:51:02 --> Config Class Initialized
INFO - 2017-01-17 21:51:02 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:51:02 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:51:02 --> Utf8 Class Initialized
INFO - 2017-01-17 21:51:02 --> URI Class Initialized
INFO - 2017-01-17 21:51:02 --> Router Class Initialized
INFO - 2017-01-17 21:51:02 --> Output Class Initialized
INFO - 2017-01-17 21:51:02 --> Security Class Initialized
DEBUG - 2017-01-17 21:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:51:02 --> Input Class Initialized
INFO - 2017-01-17 21:51:02 --> Language Class Initialized
INFO - 2017-01-17 21:51:02 --> Loader Class Initialized
INFO - 2017-01-17 21:51:02 --> Database Driver Class Initialized
INFO - 2017-01-17 21:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:51:02 --> Controller Class Initialized
INFO - 2017-01-17 21:51:02 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:51:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:51:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 21:51:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 21:51:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 21:51:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 21:51:02 --> Final output sent to browser
DEBUG - 2017-01-17 21:51:02 --> Total execution time: 0.0143
INFO - 2017-01-17 21:51:04 --> Config Class Initialized
INFO - 2017-01-17 21:51:04 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:51:04 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:51:04 --> Utf8 Class Initialized
INFO - 2017-01-17 21:51:04 --> URI Class Initialized
INFO - 2017-01-17 21:51:04 --> Router Class Initialized
INFO - 2017-01-17 21:51:04 --> Output Class Initialized
INFO - 2017-01-17 21:51:04 --> Security Class Initialized
DEBUG - 2017-01-17 21:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:51:04 --> Input Class Initialized
INFO - 2017-01-17 21:51:04 --> Language Class Initialized
INFO - 2017-01-17 21:51:04 --> Loader Class Initialized
INFO - 2017-01-17 21:51:04 --> Database Driver Class Initialized
INFO - 2017-01-17 21:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:51:04 --> Controller Class Initialized
INFO - 2017-01-17 21:51:04 --> Helper loaded: date_helper
INFO - 2017-01-17 21:51:04 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:51:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:51:04 --> Helper loaded: form_helper
INFO - 2017-01-17 21:51:04 --> Form Validation Class Initialized
INFO - 2017-01-17 21:51:04 --> Final output sent to browser
DEBUG - 2017-01-17 21:51:04 --> Total execution time: 0.0144
INFO - 2017-01-17 21:51:10 --> Config Class Initialized
INFO - 2017-01-17 21:51:10 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:51:10 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:51:10 --> Utf8 Class Initialized
INFO - 2017-01-17 21:51:10 --> URI Class Initialized
INFO - 2017-01-17 21:51:10 --> Router Class Initialized
INFO - 2017-01-17 21:51:10 --> Output Class Initialized
INFO - 2017-01-17 21:51:10 --> Security Class Initialized
DEBUG - 2017-01-17 21:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:51:10 --> Input Class Initialized
INFO - 2017-01-17 21:51:10 --> Language Class Initialized
INFO - 2017-01-17 21:51:10 --> Loader Class Initialized
INFO - 2017-01-17 21:51:10 --> Database Driver Class Initialized
INFO - 2017-01-17 21:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:51:10 --> Controller Class Initialized
INFO - 2017-01-17 21:51:10 --> Upload Class Initialized
INFO - 2017-01-17 21:51:10 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:51:10 --> Helper loaded: form_helper
INFO - 2017-01-17 21:51:10 --> Form Validation Class Initialized
INFO - 2017-01-17 21:51:10 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-17 21:51:10 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-17 21:51:10 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-17 21:51:10 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-17 21:51:10 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-17 21:51:10 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-17 21:51:10 --> Final output sent to browser
DEBUG - 2017-01-17 21:51:10 --> Total execution time: 0.0203
INFO - 2017-01-17 21:51:11 --> Config Class Initialized
INFO - 2017-01-17 21:51:11 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:51:11 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:51:11 --> Utf8 Class Initialized
INFO - 2017-01-17 21:51:11 --> URI Class Initialized
INFO - 2017-01-17 21:51:11 --> Router Class Initialized
INFO - 2017-01-17 21:51:11 --> Output Class Initialized
INFO - 2017-01-17 21:51:11 --> Security Class Initialized
DEBUG - 2017-01-17 21:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:51:11 --> Input Class Initialized
INFO - 2017-01-17 21:51:11 --> Language Class Initialized
INFO - 2017-01-17 21:51:11 --> Loader Class Initialized
INFO - 2017-01-17 21:51:11 --> Database Driver Class Initialized
INFO - 2017-01-17 21:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:51:11 --> Controller Class Initialized
INFO - 2017-01-17 21:51:11 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:51:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:51:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 21:51:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 21:51:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 21:51:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 21:51:11 --> Final output sent to browser
DEBUG - 2017-01-17 21:51:11 --> Total execution time: 0.0135
INFO - 2017-01-17 21:54:08 --> Config Class Initialized
INFO - 2017-01-17 21:54:08 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:54:08 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:54:08 --> Utf8 Class Initialized
INFO - 2017-01-17 21:54:08 --> URI Class Initialized
INFO - 2017-01-17 21:54:08 --> Router Class Initialized
INFO - 2017-01-17 21:54:08 --> Output Class Initialized
INFO - 2017-01-17 21:54:08 --> Security Class Initialized
DEBUG - 2017-01-17 21:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:54:08 --> Input Class Initialized
INFO - 2017-01-17 21:54:08 --> Language Class Initialized
INFO - 2017-01-17 21:54:08 --> Loader Class Initialized
INFO - 2017-01-17 21:54:08 --> Database Driver Class Initialized
INFO - 2017-01-17 21:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:54:08 --> Controller Class Initialized
INFO - 2017-01-17 21:54:08 --> Upload Class Initialized
INFO - 2017-01-17 21:54:08 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:54:08 --> Helper loaded: form_helper
INFO - 2017-01-17 21:54:08 --> Form Validation Class Initialized
INFO - 2017-01-17 21:54:11 --> Config Class Initialized
INFO - 2017-01-17 21:54:11 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:54:11 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:54:11 --> Utf8 Class Initialized
INFO - 2017-01-17 21:54:11 --> URI Class Initialized
INFO - 2017-01-17 21:54:11 --> Router Class Initialized
INFO - 2017-01-17 21:54:11 --> Output Class Initialized
INFO - 2017-01-17 21:54:11 --> Security Class Initialized
DEBUG - 2017-01-17 21:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:54:11 --> Input Class Initialized
INFO - 2017-01-17 21:54:11 --> Language Class Initialized
INFO - 2017-01-17 21:54:11 --> Loader Class Initialized
INFO - 2017-01-17 21:54:11 --> Database Driver Class Initialized
INFO - 2017-01-17 21:54:11 --> Final output sent to browser
DEBUG - 2017-01-17 21:54:11 --> Total execution time: 3.3539
INFO - 2017-01-17 21:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:54:11 --> Controller Class Initialized
INFO - 2017-01-17 21:54:11 --> Upload Class Initialized
INFO - 2017-01-17 21:54:11 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:54:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:54:11 --> Helper loaded: form_helper
INFO - 2017-01-17 21:54:11 --> Form Validation Class Initialized
INFO - 2017-01-17 21:54:11 --> Final output sent to browser
DEBUG - 2017-01-17 21:54:11 --> Total execution time: 0.0212
INFO - 2017-01-17 21:54:11 --> Config Class Initialized
INFO - 2017-01-17 21:54:11 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:54:11 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:54:11 --> Utf8 Class Initialized
INFO - 2017-01-17 21:54:11 --> URI Class Initialized
INFO - 2017-01-17 21:54:11 --> Router Class Initialized
INFO - 2017-01-17 21:54:11 --> Output Class Initialized
INFO - 2017-01-17 21:54:11 --> Security Class Initialized
DEBUG - 2017-01-17 21:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:54:11 --> Input Class Initialized
INFO - 2017-01-17 21:54:11 --> Language Class Initialized
INFO - 2017-01-17 21:54:11 --> Loader Class Initialized
INFO - 2017-01-17 21:54:11 --> Database Driver Class Initialized
INFO - 2017-01-17 21:54:11 --> Config Class Initialized
INFO - 2017-01-17 21:54:11 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:54:11 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:54:11 --> Utf8 Class Initialized
INFO - 2017-01-17 21:54:11 --> URI Class Initialized
INFO - 2017-01-17 21:54:11 --> Router Class Initialized
INFO - 2017-01-17 21:54:11 --> Output Class Initialized
INFO - 2017-01-17 21:54:11 --> Security Class Initialized
DEBUG - 2017-01-17 21:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:54:11 --> Input Class Initialized
INFO - 2017-01-17 21:54:11 --> Language Class Initialized
INFO - 2017-01-17 21:54:11 --> Loader Class Initialized
INFO - 2017-01-17 21:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:54:11 --> Controller Class Initialized
INFO - 2017-01-17 21:54:11 --> Upload Class Initialized
INFO - 2017-01-17 21:54:11 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:54:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:54:11 --> Helper loaded: form_helper
INFO - 2017-01-17 21:54:11 --> Form Validation Class Initialized
INFO - 2017-01-17 21:54:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-17 21:54:11 --> Final output sent to browser
DEBUG - 2017-01-17 21:54:11 --> Total execution time: 0.0263
INFO - 2017-01-17 21:54:11 --> Database Driver Class Initialized
INFO - 2017-01-17 21:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:54:11 --> Controller Class Initialized
INFO - 2017-01-17 21:54:11 --> Upload Class Initialized
INFO - 2017-01-17 21:54:11 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:54:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:54:11 --> Helper loaded: form_helper
INFO - 2017-01-17 21:54:11 --> Form Validation Class Initialized
INFO - 2017-01-17 21:54:11 --> Final output sent to browser
DEBUG - 2017-01-17 21:54:11 --> Total execution time: 0.0756
INFO - 2017-01-17 21:55:36 --> Config Class Initialized
INFO - 2017-01-17 21:55:36 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:55:36 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:55:36 --> Utf8 Class Initialized
INFO - 2017-01-17 21:55:36 --> URI Class Initialized
DEBUG - 2017-01-17 21:55:36 --> No URI present. Default controller set.
INFO - 2017-01-17 21:55:36 --> Router Class Initialized
INFO - 2017-01-17 21:55:36 --> Output Class Initialized
INFO - 2017-01-17 21:55:36 --> Security Class Initialized
DEBUG - 2017-01-17 21:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:55:36 --> Input Class Initialized
INFO - 2017-01-17 21:55:36 --> Language Class Initialized
INFO - 2017-01-17 21:55:36 --> Loader Class Initialized
INFO - 2017-01-17 21:55:36 --> Database Driver Class Initialized
INFO - 2017-01-17 21:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:55:36 --> Controller Class Initialized
INFO - 2017-01-17 21:55:36 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 21:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 21:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 21:55:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 21:55:36 --> Final output sent to browser
DEBUG - 2017-01-17 21:55:36 --> Total execution time: 0.0191
INFO - 2017-01-17 21:56:19 --> Config Class Initialized
INFO - 2017-01-17 21:56:19 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:56:19 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:56:19 --> Utf8 Class Initialized
INFO - 2017-01-17 21:56:19 --> URI Class Initialized
INFO - 2017-01-17 21:56:19 --> Router Class Initialized
INFO - 2017-01-17 21:56:19 --> Output Class Initialized
INFO - 2017-01-17 21:56:19 --> Security Class Initialized
DEBUG - 2017-01-17 21:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:56:19 --> Input Class Initialized
INFO - 2017-01-17 21:56:19 --> Language Class Initialized
INFO - 2017-01-17 21:56:19 --> Loader Class Initialized
INFO - 2017-01-17 21:56:19 --> Database Driver Class Initialized
INFO - 2017-01-17 21:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:56:19 --> Controller Class Initialized
INFO - 2017-01-17 21:56:19 --> Helper loaded: url_helper
DEBUG - 2017-01-17 21:56:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:56:19 --> Config Class Initialized
INFO - 2017-01-17 21:56:19 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:56:19 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:56:19 --> Utf8 Class Initialized
INFO - 2017-01-17 21:56:19 --> URI Class Initialized
INFO - 2017-01-17 21:56:19 --> Router Class Initialized
INFO - 2017-01-17 21:56:19 --> Output Class Initialized
INFO - 2017-01-17 21:56:19 --> Security Class Initialized
DEBUG - 2017-01-17 21:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:56:19 --> Input Class Initialized
INFO - 2017-01-17 21:56:19 --> Language Class Initialized
INFO - 2017-01-17 21:56:19 --> Loader Class Initialized
INFO - 2017-01-17 21:56:19 --> Database Driver Class Initialized
INFO - 2017-01-17 21:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:56:19 --> Controller Class Initialized
INFO - 2017-01-17 21:56:19 --> Helper loaded: date_helper
DEBUG - 2017-01-17 21:56:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:56:19 --> Helper loaded: url_helper
INFO - 2017-01-17 21:56:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 21:56:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-17 21:56:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-17 21:56:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-17 21:56:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 21:56:19 --> Final output sent to browser
DEBUG - 2017-01-17 21:56:19 --> Total execution time: 0.0428
INFO - 2017-01-17 21:56:31 --> Config Class Initialized
INFO - 2017-01-17 21:56:31 --> Hooks Class Initialized
DEBUG - 2017-01-17 21:56:31 --> UTF-8 Support Enabled
INFO - 2017-01-17 21:56:31 --> Utf8 Class Initialized
INFO - 2017-01-17 21:56:31 --> URI Class Initialized
INFO - 2017-01-17 21:56:31 --> Router Class Initialized
INFO - 2017-01-17 21:56:31 --> Output Class Initialized
INFO - 2017-01-17 21:56:31 --> Security Class Initialized
DEBUG - 2017-01-17 21:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 21:56:31 --> Input Class Initialized
INFO - 2017-01-17 21:56:31 --> Language Class Initialized
INFO - 2017-01-17 21:56:31 --> Loader Class Initialized
INFO - 2017-01-17 21:56:31 --> Database Driver Class Initialized
INFO - 2017-01-17 21:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 21:56:31 --> Controller Class Initialized
INFO - 2017-01-17 21:56:31 --> Helper loaded: date_helper
DEBUG - 2017-01-17 21:56:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 21:56:31 --> Helper loaded: url_helper
INFO - 2017-01-17 21:56:31 --> Helper loaded: download_helper
INFO - 2017-01-17 21:56:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 21:56:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-17 21:56:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-17 21:56:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-17 21:56:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 21:56:31 --> Final output sent to browser
DEBUG - 2017-01-17 21:56:31 --> Total execution time: 0.0464
INFO - 2017-01-17 22:30:37 --> Config Class Initialized
INFO - 2017-01-17 22:30:37 --> Hooks Class Initialized
DEBUG - 2017-01-17 22:30:37 --> UTF-8 Support Enabled
INFO - 2017-01-17 22:30:37 --> Utf8 Class Initialized
INFO - 2017-01-17 22:30:37 --> URI Class Initialized
INFO - 2017-01-17 22:30:37 --> Router Class Initialized
INFO - 2017-01-17 22:30:37 --> Output Class Initialized
INFO - 2017-01-17 22:30:37 --> Security Class Initialized
DEBUG - 2017-01-17 22:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 22:30:37 --> Input Class Initialized
INFO - 2017-01-17 22:30:37 --> Language Class Initialized
INFO - 2017-01-17 22:30:37 --> Loader Class Initialized
INFO - 2017-01-17 22:30:37 --> Database Driver Class Initialized
INFO - 2017-01-17 22:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 22:30:37 --> Controller Class Initialized
INFO - 2017-01-17 22:30:37 --> Upload Class Initialized
INFO - 2017-01-17 22:30:37 --> Helper loaded: url_helper
DEBUG - 2017-01-17 22:30:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 22:30:37 --> Helper loaded: form_helper
INFO - 2017-01-17 22:30:37 --> Form Validation Class Initialized
INFO - 2017-01-17 22:30:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-17 22:30:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-17 22:30:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-17 22:30:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-17 22:30:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-17 22:30:37 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-17 22:30:37 --> Final output sent to browser
DEBUG - 2017-01-17 22:30:37 --> Total execution time: 0.0507
INFO - 2017-01-17 22:30:37 --> Config Class Initialized
INFO - 2017-01-17 22:30:37 --> Hooks Class Initialized
DEBUG - 2017-01-17 22:30:37 --> UTF-8 Support Enabled
INFO - 2017-01-17 22:30:37 --> Utf8 Class Initialized
INFO - 2017-01-17 22:30:37 --> URI Class Initialized
INFO - 2017-01-17 22:30:37 --> Router Class Initialized
INFO - 2017-01-17 22:30:37 --> Output Class Initialized
INFO - 2017-01-17 22:30:37 --> Security Class Initialized
DEBUG - 2017-01-17 22:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 22:30:37 --> Input Class Initialized
INFO - 2017-01-17 22:30:37 --> Language Class Initialized
INFO - 2017-01-17 22:30:37 --> Loader Class Initialized
INFO - 2017-01-17 22:30:37 --> Database Driver Class Initialized
INFO - 2017-01-17 22:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 22:30:37 --> Controller Class Initialized
INFO - 2017-01-17 22:30:37 --> Helper loaded: url_helper
DEBUG - 2017-01-17 22:30:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 22:30:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 22:30:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 22:30:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 22:30:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 22:30:37 --> Final output sent to browser
DEBUG - 2017-01-17 22:30:37 --> Total execution time: 0.0148
INFO - 2017-01-17 22:30:39 --> Config Class Initialized
INFO - 2017-01-17 22:30:39 --> Hooks Class Initialized
DEBUG - 2017-01-17 22:30:39 --> UTF-8 Support Enabled
INFO - 2017-01-17 22:30:39 --> Utf8 Class Initialized
INFO - 2017-01-17 22:30:39 --> URI Class Initialized
INFO - 2017-01-17 22:30:39 --> Router Class Initialized
INFO - 2017-01-17 22:30:39 --> Output Class Initialized
INFO - 2017-01-17 22:30:39 --> Security Class Initialized
DEBUG - 2017-01-17 22:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 22:30:39 --> Input Class Initialized
INFO - 2017-01-17 22:30:39 --> Language Class Initialized
INFO - 2017-01-17 22:30:39 --> Loader Class Initialized
INFO - 2017-01-17 22:30:39 --> Database Driver Class Initialized
INFO - 2017-01-17 22:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 22:30:39 --> Controller Class Initialized
INFO - 2017-01-17 22:30:39 --> Upload Class Initialized
INFO - 2017-01-17 22:30:39 --> Helper loaded: url_helper
DEBUG - 2017-01-17 22:30:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 22:30:39 --> Helper loaded: form_helper
INFO - 2017-01-17 22:30:39 --> Form Validation Class Initialized
INFO - 2017-01-17 22:30:39 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-17 22:30:39 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-17 22:30:39 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-17 22:30:39 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-17 22:30:39 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-17 22:30:39 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-17 22:30:39 --> Final output sent to browser
DEBUG - 2017-01-17 22:30:39 --> Total execution time: 0.0196
INFO - 2017-01-17 22:30:39 --> Config Class Initialized
INFO - 2017-01-17 22:30:39 --> Hooks Class Initialized
DEBUG - 2017-01-17 22:30:39 --> UTF-8 Support Enabled
INFO - 2017-01-17 22:30:39 --> Utf8 Class Initialized
INFO - 2017-01-17 22:30:39 --> URI Class Initialized
INFO - 2017-01-17 22:30:39 --> Router Class Initialized
INFO - 2017-01-17 22:30:39 --> Output Class Initialized
INFO - 2017-01-17 22:30:39 --> Security Class Initialized
DEBUG - 2017-01-17 22:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 22:30:39 --> Input Class Initialized
INFO - 2017-01-17 22:30:39 --> Language Class Initialized
INFO - 2017-01-17 22:30:39 --> Loader Class Initialized
INFO - 2017-01-17 22:30:39 --> Database Driver Class Initialized
INFO - 2017-01-17 22:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 22:30:39 --> Controller Class Initialized
INFO - 2017-01-17 22:30:39 --> Helper loaded: url_helper
DEBUG - 2017-01-17 22:30:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 22:30:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 22:30:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 22:30:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 22:30:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 22:30:39 --> Final output sent to browser
DEBUG - 2017-01-17 22:30:39 --> Total execution time: 0.0144
INFO - 2017-01-17 22:34:00 --> Config Class Initialized
INFO - 2017-01-17 22:34:00 --> Hooks Class Initialized
DEBUG - 2017-01-17 22:34:00 --> UTF-8 Support Enabled
INFO - 2017-01-17 22:34:00 --> Utf8 Class Initialized
INFO - 2017-01-17 22:34:00 --> URI Class Initialized
INFO - 2017-01-17 22:34:00 --> Router Class Initialized
INFO - 2017-01-17 22:34:00 --> Output Class Initialized
INFO - 2017-01-17 22:34:00 --> Security Class Initialized
DEBUG - 2017-01-17 22:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 22:34:00 --> Input Class Initialized
INFO - 2017-01-17 22:34:00 --> Language Class Initialized
INFO - 2017-01-17 22:34:00 --> Loader Class Initialized
INFO - 2017-01-17 22:34:00 --> Database Driver Class Initialized
INFO - 2017-01-17 22:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 22:34:00 --> Controller Class Initialized
INFO - 2017-01-17 22:34:00 --> Upload Class Initialized
INFO - 2017-01-17 22:34:00 --> Helper loaded: url_helper
DEBUG - 2017-01-17 22:34:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 22:34:00 --> Helper loaded: form_helper
INFO - 2017-01-17 22:34:00 --> Form Validation Class Initialized
INFO - 2017-01-17 22:34:00 --> Final output sent to browser
DEBUG - 2017-01-17 22:34:00 --> Total execution time: 0.0156
INFO - 2017-01-17 22:34:00 --> Config Class Initialized
INFO - 2017-01-17 22:34:00 --> Hooks Class Initialized
DEBUG - 2017-01-17 22:34:00 --> UTF-8 Support Enabled
INFO - 2017-01-17 22:34:00 --> Utf8 Class Initialized
INFO - 2017-01-17 22:34:00 --> URI Class Initialized
INFO - 2017-01-17 22:34:00 --> Router Class Initialized
INFO - 2017-01-17 22:34:00 --> Output Class Initialized
INFO - 2017-01-17 22:34:00 --> Security Class Initialized
DEBUG - 2017-01-17 22:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 22:34:00 --> Input Class Initialized
INFO - 2017-01-17 22:34:00 --> Language Class Initialized
INFO - 2017-01-17 22:34:00 --> Loader Class Initialized
INFO - 2017-01-17 22:34:00 --> Database Driver Class Initialized
INFO - 2017-01-17 22:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 22:34:00 --> Controller Class Initialized
INFO - 2017-01-17 22:34:00 --> Upload Class Initialized
INFO - 2017-01-17 22:34:00 --> Helper loaded: url_helper
DEBUG - 2017-01-17 22:34:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 22:34:00 --> Helper loaded: form_helper
INFO - 2017-01-17 22:34:00 --> Form Validation Class Initialized
INFO - 2017-01-17 22:34:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-17 22:34:00 --> Final output sent to browser
DEBUG - 2017-01-17 22:34:00 --> Total execution time: 0.0263
INFO - 2017-01-17 22:37:21 --> Config Class Initialized
INFO - 2017-01-17 22:37:21 --> Hooks Class Initialized
DEBUG - 2017-01-17 22:37:21 --> UTF-8 Support Enabled
INFO - 2017-01-17 22:37:21 --> Utf8 Class Initialized
INFO - 2017-01-17 22:37:21 --> URI Class Initialized
INFO - 2017-01-17 22:37:21 --> Router Class Initialized
INFO - 2017-01-17 22:37:21 --> Output Class Initialized
INFO - 2017-01-17 22:37:21 --> Security Class Initialized
DEBUG - 2017-01-17 22:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 22:37:21 --> Input Class Initialized
INFO - 2017-01-17 22:37:21 --> Language Class Initialized
INFO - 2017-01-17 22:37:21 --> Loader Class Initialized
INFO - 2017-01-17 22:37:21 --> Database Driver Class Initialized
INFO - 2017-01-17 22:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 22:37:21 --> Controller Class Initialized
INFO - 2017-01-17 22:37:21 --> Upload Class Initialized
INFO - 2017-01-17 22:37:21 --> Helper loaded: url_helper
DEBUG - 2017-01-17 22:37:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 22:37:21 --> Helper loaded: form_helper
INFO - 2017-01-17 22:37:21 --> Form Validation Class Initialized
INFO - 2017-01-17 22:37:21 --> Final output sent to browser
DEBUG - 2017-01-17 22:37:21 --> Total execution time: 0.0147
INFO - 2017-01-17 22:37:21 --> Config Class Initialized
INFO - 2017-01-17 22:37:21 --> Hooks Class Initialized
DEBUG - 2017-01-17 22:37:21 --> UTF-8 Support Enabled
INFO - 2017-01-17 22:37:21 --> Utf8 Class Initialized
INFO - 2017-01-17 22:37:21 --> URI Class Initialized
INFO - 2017-01-17 22:37:21 --> Router Class Initialized
INFO - 2017-01-17 22:37:21 --> Output Class Initialized
INFO - 2017-01-17 22:37:21 --> Security Class Initialized
DEBUG - 2017-01-17 22:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 22:37:21 --> Input Class Initialized
INFO - 2017-01-17 22:37:21 --> Language Class Initialized
INFO - 2017-01-17 22:37:21 --> Loader Class Initialized
INFO - 2017-01-17 22:37:21 --> Database Driver Class Initialized
INFO - 2017-01-17 22:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 22:37:21 --> Controller Class Initialized
INFO - 2017-01-17 22:37:21 --> Upload Class Initialized
INFO - 2017-01-17 22:37:21 --> Helper loaded: url_helper
DEBUG - 2017-01-17 22:37:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 22:37:21 --> Helper loaded: form_helper
INFO - 2017-01-17 22:37:21 --> Form Validation Class Initialized
INFO - 2017-01-17 22:37:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-17 22:37:21 --> Final output sent to browser
DEBUG - 2017-01-17 22:37:21 --> Total execution time: 0.0164
INFO - 2017-01-17 22:41:44 --> Config Class Initialized
INFO - 2017-01-17 22:41:44 --> Hooks Class Initialized
DEBUG - 2017-01-17 22:41:44 --> UTF-8 Support Enabled
INFO - 2017-01-17 22:41:44 --> Utf8 Class Initialized
INFO - 2017-01-17 22:41:44 --> URI Class Initialized
INFO - 2017-01-17 22:41:44 --> Router Class Initialized
INFO - 2017-01-17 22:41:44 --> Output Class Initialized
INFO - 2017-01-17 22:41:44 --> Security Class Initialized
DEBUG - 2017-01-17 22:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 22:41:44 --> Input Class Initialized
INFO - 2017-01-17 22:41:44 --> Language Class Initialized
INFO - 2017-01-17 22:41:44 --> Loader Class Initialized
INFO - 2017-01-17 22:41:44 --> Database Driver Class Initialized
INFO - 2017-01-17 22:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 22:41:44 --> Controller Class Initialized
INFO - 2017-01-17 22:41:44 --> Upload Class Initialized
INFO - 2017-01-17 22:41:44 --> Helper loaded: url_helper
DEBUG - 2017-01-17 22:41:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 22:41:44 --> Helper loaded: form_helper
INFO - 2017-01-17 22:41:44 --> Form Validation Class Initialized
INFO - 2017-01-17 22:41:44 --> Final output sent to browser
DEBUG - 2017-01-17 22:41:44 --> Total execution time: 0.0155
INFO - 2017-01-17 22:41:44 --> Config Class Initialized
INFO - 2017-01-17 22:41:44 --> Hooks Class Initialized
DEBUG - 2017-01-17 22:41:44 --> UTF-8 Support Enabled
INFO - 2017-01-17 22:41:44 --> Utf8 Class Initialized
INFO - 2017-01-17 22:41:44 --> URI Class Initialized
INFO - 2017-01-17 22:41:44 --> Router Class Initialized
INFO - 2017-01-17 22:41:44 --> Output Class Initialized
INFO - 2017-01-17 22:41:44 --> Security Class Initialized
DEBUG - 2017-01-17 22:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 22:41:44 --> Input Class Initialized
INFO - 2017-01-17 22:41:44 --> Language Class Initialized
INFO - 2017-01-17 22:41:44 --> Loader Class Initialized
INFO - 2017-01-17 22:41:44 --> Database Driver Class Initialized
INFO - 2017-01-17 22:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 22:41:44 --> Controller Class Initialized
INFO - 2017-01-17 22:41:44 --> Upload Class Initialized
INFO - 2017-01-17 22:41:44 --> Helper loaded: url_helper
DEBUG - 2017-01-17 22:41:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 22:41:44 --> Helper loaded: form_helper
INFO - 2017-01-17 22:41:44 --> Form Validation Class Initialized
INFO - 2017-01-17 22:41:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-17 22:41:44 --> Final output sent to browser
DEBUG - 2017-01-17 22:41:44 --> Total execution time: 0.0185
INFO - 2017-01-17 22:41:51 --> Config Class Initialized
INFO - 2017-01-17 22:41:51 --> Hooks Class Initialized
DEBUG - 2017-01-17 22:41:51 --> UTF-8 Support Enabled
INFO - 2017-01-17 22:41:51 --> Utf8 Class Initialized
INFO - 2017-01-17 22:41:51 --> URI Class Initialized
INFO - 2017-01-17 22:41:51 --> Router Class Initialized
INFO - 2017-01-17 22:41:51 --> Output Class Initialized
INFO - 2017-01-17 22:41:51 --> Security Class Initialized
DEBUG - 2017-01-17 22:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 22:41:51 --> Input Class Initialized
INFO - 2017-01-17 22:41:51 --> Language Class Initialized
ERROR - 2017-01-17 22:41:51 --> 404 Page Not Found: Tablet/index.html
INFO - 2017-01-17 22:41:51 --> Config Class Initialized
INFO - 2017-01-17 22:41:51 --> Hooks Class Initialized
DEBUG - 2017-01-17 22:41:51 --> UTF-8 Support Enabled
INFO - 2017-01-17 22:41:51 --> Utf8 Class Initialized
INFO - 2017-01-17 22:41:51 --> URI Class Initialized
INFO - 2017-01-17 22:41:51 --> Router Class Initialized
INFO - 2017-01-17 22:41:51 --> Output Class Initialized
INFO - 2017-01-17 22:41:51 --> Security Class Initialized
DEBUG - 2017-01-17 22:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 22:41:51 --> Input Class Initialized
INFO - 2017-01-17 22:41:51 --> Language Class Initialized
INFO - 2017-01-17 22:41:51 --> Loader Class Initialized
INFO - 2017-01-17 22:41:51 --> Database Driver Class Initialized
INFO - 2017-01-17 22:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 22:41:51 --> Controller Class Initialized
INFO - 2017-01-17 22:41:51 --> Helper loaded: url_helper
DEBUG - 2017-01-17 22:41:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 22:41:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 22:41:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 22:41:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 22:41:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 22:41:51 --> Final output sent to browser
DEBUG - 2017-01-17 22:41:51 --> Total execution time: 0.0142
INFO - 2017-01-17 22:41:54 --> Config Class Initialized
INFO - 2017-01-17 22:41:54 --> Hooks Class Initialized
DEBUG - 2017-01-17 22:41:54 --> UTF-8 Support Enabled
INFO - 2017-01-17 22:41:54 --> Utf8 Class Initialized
INFO - 2017-01-17 22:41:54 --> URI Class Initialized
DEBUG - 2017-01-17 22:41:54 --> No URI present. Default controller set.
INFO - 2017-01-17 22:41:54 --> Router Class Initialized
INFO - 2017-01-17 22:41:54 --> Output Class Initialized
INFO - 2017-01-17 22:41:54 --> Security Class Initialized
DEBUG - 2017-01-17 22:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 22:41:54 --> Input Class Initialized
INFO - 2017-01-17 22:41:54 --> Language Class Initialized
INFO - 2017-01-17 22:41:54 --> Loader Class Initialized
INFO - 2017-01-17 22:41:54 --> Database Driver Class Initialized
INFO - 2017-01-17 22:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 22:41:54 --> Controller Class Initialized
INFO - 2017-01-17 22:41:54 --> Helper loaded: url_helper
DEBUG - 2017-01-17 22:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 22:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 22:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 22:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 22:41:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 22:41:54 --> Final output sent to browser
DEBUG - 2017-01-17 22:41:54 --> Total execution time: 0.0134
INFO - 2017-01-17 22:42:00 --> Config Class Initialized
INFO - 2017-01-17 22:42:00 --> Hooks Class Initialized
DEBUG - 2017-01-17 22:42:00 --> UTF-8 Support Enabled
INFO - 2017-01-17 22:42:00 --> Utf8 Class Initialized
INFO - 2017-01-17 22:42:00 --> URI Class Initialized
INFO - 2017-01-17 22:42:00 --> Router Class Initialized
INFO - 2017-01-17 22:42:00 --> Output Class Initialized
INFO - 2017-01-17 22:42:00 --> Security Class Initialized
DEBUG - 2017-01-17 22:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 22:42:00 --> Input Class Initialized
INFO - 2017-01-17 22:42:00 --> Language Class Initialized
INFO - 2017-01-17 22:42:00 --> Loader Class Initialized
INFO - 2017-01-17 22:42:00 --> Database Driver Class Initialized
INFO - 2017-01-17 22:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 22:42:00 --> Controller Class Initialized
INFO - 2017-01-17 22:42:00 --> Helper loaded: url_helper
DEBUG - 2017-01-17 22:42:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 22:42:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 22:42:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 22:42:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 22:42:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 22:42:00 --> Final output sent to browser
DEBUG - 2017-01-17 22:42:00 --> Total execution time: 0.0169
INFO - 2017-01-17 22:42:11 --> Config Class Initialized
INFO - 2017-01-17 22:42:11 --> Hooks Class Initialized
DEBUG - 2017-01-17 22:42:11 --> UTF-8 Support Enabled
INFO - 2017-01-17 22:42:11 --> Utf8 Class Initialized
INFO - 2017-01-17 22:42:11 --> URI Class Initialized
INFO - 2017-01-17 22:42:11 --> Router Class Initialized
INFO - 2017-01-17 22:42:11 --> Output Class Initialized
INFO - 2017-01-17 22:42:11 --> Security Class Initialized
DEBUG - 2017-01-17 22:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 22:42:11 --> Input Class Initialized
INFO - 2017-01-17 22:42:11 --> Language Class Initialized
INFO - 2017-01-17 22:42:11 --> Loader Class Initialized
INFO - 2017-01-17 22:42:11 --> Database Driver Class Initialized
INFO - 2017-01-17 22:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 22:42:11 --> Controller Class Initialized
INFO - 2017-01-17 22:42:11 --> Helper loaded: date_helper
DEBUG - 2017-01-17 22:42:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 22:42:11 --> Helper loaded: url_helper
INFO - 2017-01-17 22:42:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 22:42:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-17 22:42:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-17 22:42:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-17 22:42:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 22:42:11 --> Final output sent to browser
DEBUG - 2017-01-17 22:42:11 --> Total execution time: 0.0146
INFO - 2017-01-17 23:04:57 --> Config Class Initialized
INFO - 2017-01-17 23:04:57 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:04:57 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:04:57 --> Utf8 Class Initialized
INFO - 2017-01-17 23:04:57 --> URI Class Initialized
DEBUG - 2017-01-17 23:04:57 --> No URI present. Default controller set.
INFO - 2017-01-17 23:04:57 --> Router Class Initialized
INFO - 2017-01-17 23:04:57 --> Output Class Initialized
INFO - 2017-01-17 23:04:57 --> Security Class Initialized
DEBUG - 2017-01-17 23:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:04:57 --> Input Class Initialized
INFO - 2017-01-17 23:04:57 --> Language Class Initialized
INFO - 2017-01-17 23:04:57 --> Loader Class Initialized
INFO - 2017-01-17 23:04:57 --> Database Driver Class Initialized
INFO - 2017-01-17 23:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:04:57 --> Controller Class Initialized
INFO - 2017-01-17 23:04:57 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:04:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:04:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 23:04:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 23:04:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 23:04:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 23:04:57 --> Final output sent to browser
DEBUG - 2017-01-17 23:04:57 --> Total execution time: 0.0354
INFO - 2017-01-17 23:12:58 --> Config Class Initialized
INFO - 2017-01-17 23:12:58 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:12:58 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:12:58 --> Utf8 Class Initialized
INFO - 2017-01-17 23:12:58 --> URI Class Initialized
INFO - 2017-01-17 23:12:58 --> Router Class Initialized
INFO - 2017-01-17 23:12:58 --> Output Class Initialized
INFO - 2017-01-17 23:12:58 --> Security Class Initialized
DEBUG - 2017-01-17 23:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:12:58 --> Input Class Initialized
INFO - 2017-01-17 23:12:58 --> Language Class Initialized
INFO - 2017-01-17 23:12:58 --> Loader Class Initialized
INFO - 2017-01-17 23:12:58 --> Database Driver Class Initialized
INFO - 2017-01-17 23:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:12:58 --> Controller Class Initialized
INFO - 2017-01-17 23:12:58 --> Upload Class Initialized
INFO - 2017-01-17 23:12:58 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:12:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:12:58 --> Helper loaded: form_helper
INFO - 2017-01-17 23:12:58 --> Form Validation Class Initialized
INFO - 2017-01-17 23:12:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-17 23:12:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-17 23:12:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-17 23:12:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-17 23:12:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-17 23:12:58 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-17 23:12:58 --> Final output sent to browser
DEBUG - 2017-01-17 23:12:58 --> Total execution time: 0.0369
INFO - 2017-01-17 23:12:59 --> Config Class Initialized
INFO - 2017-01-17 23:12:59 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:12:59 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:12:59 --> Utf8 Class Initialized
INFO - 2017-01-17 23:12:59 --> URI Class Initialized
INFO - 2017-01-17 23:12:59 --> Router Class Initialized
INFO - 2017-01-17 23:12:59 --> Output Class Initialized
INFO - 2017-01-17 23:12:59 --> Security Class Initialized
DEBUG - 2017-01-17 23:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:12:59 --> Input Class Initialized
INFO - 2017-01-17 23:12:59 --> Language Class Initialized
INFO - 2017-01-17 23:12:59 --> Loader Class Initialized
INFO - 2017-01-17 23:12:59 --> Database Driver Class Initialized
INFO - 2017-01-17 23:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:12:59 --> Controller Class Initialized
INFO - 2017-01-17 23:12:59 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:12:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:12:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 23:12:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 23:12:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 23:12:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 23:12:59 --> Final output sent to browser
DEBUG - 2017-01-17 23:12:59 --> Total execution time: 0.0142
INFO - 2017-01-17 23:13:09 --> Config Class Initialized
INFO - 2017-01-17 23:13:09 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:13:09 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:13:09 --> Utf8 Class Initialized
INFO - 2017-01-17 23:13:09 --> URI Class Initialized
INFO - 2017-01-17 23:13:09 --> Router Class Initialized
INFO - 2017-01-17 23:13:09 --> Output Class Initialized
INFO - 2017-01-17 23:13:09 --> Security Class Initialized
DEBUG - 2017-01-17 23:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:13:09 --> Input Class Initialized
INFO - 2017-01-17 23:13:09 --> Language Class Initialized
INFO - 2017-01-17 23:13:09 --> Loader Class Initialized
INFO - 2017-01-17 23:13:09 --> Database Driver Class Initialized
INFO - 2017-01-17 23:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:13:09 --> Controller Class Initialized
INFO - 2017-01-17 23:13:09 --> Upload Class Initialized
INFO - 2017-01-17 23:13:09 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:13:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:13:09 --> Helper loaded: form_helper
INFO - 2017-01-17 23:13:09 --> Form Validation Class Initialized
INFO - 2017-01-17 23:13:09 --> Final output sent to browser
DEBUG - 2017-01-17 23:13:09 --> Total execution time: 0.0162
INFO - 2017-01-17 23:14:07 --> Config Class Initialized
INFO - 2017-01-17 23:14:07 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:14:07 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:14:07 --> Utf8 Class Initialized
INFO - 2017-01-17 23:14:07 --> URI Class Initialized
INFO - 2017-01-17 23:14:07 --> Router Class Initialized
INFO - 2017-01-17 23:14:07 --> Output Class Initialized
INFO - 2017-01-17 23:14:07 --> Security Class Initialized
DEBUG - 2017-01-17 23:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:14:07 --> Input Class Initialized
INFO - 2017-01-17 23:14:07 --> Language Class Initialized
INFO - 2017-01-17 23:14:07 --> Loader Class Initialized
INFO - 2017-01-17 23:14:07 --> Database Driver Class Initialized
INFO - 2017-01-17 23:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:14:07 --> Controller Class Initialized
INFO - 2017-01-17 23:14:07 --> Upload Class Initialized
INFO - 2017-01-17 23:14:07 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:14:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:14:07 --> Helper loaded: form_helper
INFO - 2017-01-17 23:14:07 --> Form Validation Class Initialized
INFO - 2017-01-17 23:14:07 --> Final output sent to browser
DEBUG - 2017-01-17 23:14:07 --> Total execution time: 0.0150
INFO - 2017-01-17 23:14:07 --> Config Class Initialized
INFO - 2017-01-17 23:14:07 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:14:07 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:14:07 --> Utf8 Class Initialized
INFO - 2017-01-17 23:14:07 --> URI Class Initialized
INFO - 2017-01-17 23:14:07 --> Router Class Initialized
INFO - 2017-01-17 23:14:07 --> Output Class Initialized
INFO - 2017-01-17 23:14:07 --> Security Class Initialized
DEBUG - 2017-01-17 23:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:14:07 --> Input Class Initialized
INFO - 2017-01-17 23:14:07 --> Language Class Initialized
INFO - 2017-01-17 23:14:07 --> Loader Class Initialized
INFO - 2017-01-17 23:14:07 --> Database Driver Class Initialized
INFO - 2017-01-17 23:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:14:07 --> Controller Class Initialized
INFO - 2017-01-17 23:14:07 --> Upload Class Initialized
INFO - 2017-01-17 23:14:07 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:14:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:14:07 --> Helper loaded: form_helper
INFO - 2017-01-17 23:14:07 --> Form Validation Class Initialized
INFO - 2017-01-17 23:14:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-17 23:14:07 --> Final output sent to browser
DEBUG - 2017-01-17 23:14:07 --> Total execution time: 0.0882
INFO - 2017-01-17 23:16:18 --> Config Class Initialized
INFO - 2017-01-17 23:16:18 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:16:18 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:16:18 --> Utf8 Class Initialized
INFO - 2017-01-17 23:16:18 --> URI Class Initialized
INFO - 2017-01-17 23:16:18 --> Router Class Initialized
INFO - 2017-01-17 23:16:18 --> Output Class Initialized
INFO - 2017-01-17 23:16:18 --> Security Class Initialized
DEBUG - 2017-01-17 23:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:16:18 --> Input Class Initialized
INFO - 2017-01-17 23:16:18 --> Language Class Initialized
INFO - 2017-01-17 23:16:18 --> Loader Class Initialized
INFO - 2017-01-17 23:16:18 --> Database Driver Class Initialized
INFO - 2017-01-17 23:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:16:18 --> Controller Class Initialized
INFO - 2017-01-17 23:16:18 --> Upload Class Initialized
INFO - 2017-01-17 23:16:18 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:16:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:16:18 --> Helper loaded: form_helper
INFO - 2017-01-17 23:16:18 --> Form Validation Class Initialized
INFO - 2017-01-17 23:16:18 --> Final output sent to browser
DEBUG - 2017-01-17 23:16:18 --> Total execution time: 0.0163
INFO - 2017-01-17 23:16:18 --> Config Class Initialized
INFO - 2017-01-17 23:16:18 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:16:18 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:16:18 --> Utf8 Class Initialized
INFO - 2017-01-17 23:16:18 --> URI Class Initialized
INFO - 2017-01-17 23:16:18 --> Router Class Initialized
INFO - 2017-01-17 23:16:18 --> Output Class Initialized
INFO - 2017-01-17 23:16:18 --> Security Class Initialized
DEBUG - 2017-01-17 23:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:16:18 --> Input Class Initialized
INFO - 2017-01-17 23:16:18 --> Language Class Initialized
INFO - 2017-01-17 23:16:18 --> Loader Class Initialized
INFO - 2017-01-17 23:16:18 --> Database Driver Class Initialized
INFO - 2017-01-17 23:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:16:18 --> Controller Class Initialized
INFO - 2017-01-17 23:16:18 --> Upload Class Initialized
INFO - 2017-01-17 23:16:18 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:16:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:16:18 --> Helper loaded: form_helper
INFO - 2017-01-17 23:16:18 --> Form Validation Class Initialized
INFO - 2017-01-17 23:16:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-17 23:16:18 --> Final output sent to browser
DEBUG - 2017-01-17 23:16:18 --> Total execution time: 0.0167
INFO - 2017-01-17 23:18:35 --> Config Class Initialized
INFO - 2017-01-17 23:18:35 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:18:35 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:18:35 --> Utf8 Class Initialized
INFO - 2017-01-17 23:18:35 --> URI Class Initialized
INFO - 2017-01-17 23:18:35 --> Router Class Initialized
INFO - 2017-01-17 23:18:35 --> Output Class Initialized
INFO - 2017-01-17 23:18:35 --> Security Class Initialized
DEBUG - 2017-01-17 23:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:18:35 --> Input Class Initialized
INFO - 2017-01-17 23:18:35 --> Language Class Initialized
INFO - 2017-01-17 23:18:35 --> Loader Class Initialized
INFO - 2017-01-17 23:18:35 --> Database Driver Class Initialized
INFO - 2017-01-17 23:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:18:35 --> Controller Class Initialized
INFO - 2017-01-17 23:18:35 --> Upload Class Initialized
INFO - 2017-01-17 23:18:35 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:18:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:18:35 --> Helper loaded: form_helper
INFO - 2017-01-17 23:18:35 --> Form Validation Class Initialized
INFO - 2017-01-17 23:18:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-17 23:18:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-17 23:18:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-17 23:18:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-17 23:18:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-17 23:18:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-17 23:18:35 --> Final output sent to browser
DEBUG - 2017-01-17 23:18:35 --> Total execution time: 0.0160
INFO - 2017-01-17 23:18:36 --> Config Class Initialized
INFO - 2017-01-17 23:18:36 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:18:36 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:18:36 --> Utf8 Class Initialized
INFO - 2017-01-17 23:18:36 --> URI Class Initialized
INFO - 2017-01-17 23:18:36 --> Router Class Initialized
INFO - 2017-01-17 23:18:36 --> Output Class Initialized
INFO - 2017-01-17 23:18:36 --> Security Class Initialized
DEBUG - 2017-01-17 23:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:18:36 --> Input Class Initialized
INFO - 2017-01-17 23:18:36 --> Language Class Initialized
INFO - 2017-01-17 23:18:36 --> Loader Class Initialized
INFO - 2017-01-17 23:18:36 --> Database Driver Class Initialized
INFO - 2017-01-17 23:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:18:36 --> Controller Class Initialized
INFO - 2017-01-17 23:18:36 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:18:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:18:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 23:18:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 23:18:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 23:18:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 23:18:36 --> Final output sent to browser
DEBUG - 2017-01-17 23:18:36 --> Total execution time: 0.0133
INFO - 2017-01-17 23:19:56 --> Config Class Initialized
INFO - 2017-01-17 23:19:56 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:19:56 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:19:56 --> Utf8 Class Initialized
INFO - 2017-01-17 23:19:56 --> URI Class Initialized
INFO - 2017-01-17 23:19:56 --> Router Class Initialized
INFO - 2017-01-17 23:19:56 --> Output Class Initialized
INFO - 2017-01-17 23:19:56 --> Security Class Initialized
DEBUG - 2017-01-17 23:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:19:56 --> Input Class Initialized
INFO - 2017-01-17 23:19:56 --> Language Class Initialized
INFO - 2017-01-17 23:19:56 --> Loader Class Initialized
INFO - 2017-01-17 23:19:56 --> Database Driver Class Initialized
INFO - 2017-01-17 23:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:19:56 --> Controller Class Initialized
INFO - 2017-01-17 23:19:56 --> Upload Class Initialized
INFO - 2017-01-17 23:19:56 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:19:56 --> Helper loaded: form_helper
INFO - 2017-01-17 23:19:56 --> Form Validation Class Initialized
INFO - 2017-01-17 23:19:56 --> Final output sent to browser
DEBUG - 2017-01-17 23:19:56 --> Total execution time: 0.0152
INFO - 2017-01-17 23:19:56 --> Config Class Initialized
INFO - 2017-01-17 23:19:56 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:19:56 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:19:56 --> Utf8 Class Initialized
INFO - 2017-01-17 23:19:56 --> URI Class Initialized
INFO - 2017-01-17 23:19:56 --> Router Class Initialized
INFO - 2017-01-17 23:19:56 --> Output Class Initialized
INFO - 2017-01-17 23:19:56 --> Security Class Initialized
DEBUG - 2017-01-17 23:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:19:56 --> Input Class Initialized
INFO - 2017-01-17 23:19:56 --> Language Class Initialized
INFO - 2017-01-17 23:19:56 --> Loader Class Initialized
INFO - 2017-01-17 23:19:56 --> Database Driver Class Initialized
INFO - 2017-01-17 23:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:19:56 --> Controller Class Initialized
INFO - 2017-01-17 23:19:56 --> Upload Class Initialized
INFO - 2017-01-17 23:19:56 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:19:56 --> Helper loaded: form_helper
INFO - 2017-01-17 23:19:56 --> Form Validation Class Initialized
INFO - 2017-01-17 23:19:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-17 23:19:56 --> Final output sent to browser
DEBUG - 2017-01-17 23:19:56 --> Total execution time: 0.0155
INFO - 2017-01-17 23:21:29 --> Config Class Initialized
INFO - 2017-01-17 23:21:29 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:21:29 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:21:29 --> Utf8 Class Initialized
INFO - 2017-01-17 23:21:29 --> URI Class Initialized
INFO - 2017-01-17 23:21:29 --> Router Class Initialized
INFO - 2017-01-17 23:21:29 --> Output Class Initialized
INFO - 2017-01-17 23:21:29 --> Security Class Initialized
DEBUG - 2017-01-17 23:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:21:29 --> Input Class Initialized
INFO - 2017-01-17 23:21:29 --> Language Class Initialized
INFO - 2017-01-17 23:21:29 --> Loader Class Initialized
INFO - 2017-01-17 23:21:29 --> Database Driver Class Initialized
INFO - 2017-01-17 23:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:21:29 --> Controller Class Initialized
INFO - 2017-01-17 23:21:29 --> Helper loaded: date_helper
DEBUG - 2017-01-17 23:21:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:21:29 --> Helper loaded: url_helper
INFO - 2017-01-17 23:21:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 23:21:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-17 23:21:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-17 23:21:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-17 23:21:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 23:21:29 --> Final output sent to browser
DEBUG - 2017-01-17 23:21:29 --> Total execution time: 0.0161
INFO - 2017-01-17 23:21:59 --> Config Class Initialized
INFO - 2017-01-17 23:21:59 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:21:59 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:21:59 --> Utf8 Class Initialized
INFO - 2017-01-17 23:21:59 --> URI Class Initialized
INFO - 2017-01-17 23:21:59 --> Router Class Initialized
INFO - 2017-01-17 23:21:59 --> Output Class Initialized
INFO - 2017-01-17 23:21:59 --> Security Class Initialized
DEBUG - 2017-01-17 23:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:21:59 --> Input Class Initialized
INFO - 2017-01-17 23:21:59 --> Language Class Initialized
INFO - 2017-01-17 23:21:59 --> Loader Class Initialized
INFO - 2017-01-17 23:21:59 --> Database Driver Class Initialized
INFO - 2017-01-17 23:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:21:59 --> Controller Class Initialized
INFO - 2017-01-17 23:21:59 --> Upload Class Initialized
INFO - 2017-01-17 23:21:59 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:21:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:21:59 --> Helper loaded: form_helper
INFO - 2017-01-17 23:21:59 --> Form Validation Class Initialized
INFO - 2017-01-17 23:21:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-17 23:21:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-17 23:21:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-17 23:21:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-17 23:21:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-17 23:21:59 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-17 23:21:59 --> Final output sent to browser
DEBUG - 2017-01-17 23:21:59 --> Total execution time: 0.0160
INFO - 2017-01-17 23:22:00 --> Config Class Initialized
INFO - 2017-01-17 23:22:00 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:22:00 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:22:00 --> Utf8 Class Initialized
INFO - 2017-01-17 23:22:00 --> URI Class Initialized
INFO - 2017-01-17 23:22:00 --> Router Class Initialized
INFO - 2017-01-17 23:22:00 --> Output Class Initialized
INFO - 2017-01-17 23:22:00 --> Security Class Initialized
DEBUG - 2017-01-17 23:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:22:00 --> Input Class Initialized
INFO - 2017-01-17 23:22:00 --> Language Class Initialized
INFO - 2017-01-17 23:22:00 --> Loader Class Initialized
INFO - 2017-01-17 23:22:00 --> Database Driver Class Initialized
INFO - 2017-01-17 23:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:22:00 --> Controller Class Initialized
INFO - 2017-01-17 23:22:00 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:22:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:22:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 23:22:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 23:22:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 23:22:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 23:22:00 --> Final output sent to browser
DEBUG - 2017-01-17 23:22:00 --> Total execution time: 0.0134
INFO - 2017-01-17 23:24:07 --> Config Class Initialized
INFO - 2017-01-17 23:24:07 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:24:07 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:24:07 --> Utf8 Class Initialized
INFO - 2017-01-17 23:24:07 --> URI Class Initialized
INFO - 2017-01-17 23:24:07 --> Router Class Initialized
INFO - 2017-01-17 23:24:07 --> Output Class Initialized
INFO - 2017-01-17 23:24:07 --> Security Class Initialized
DEBUG - 2017-01-17 23:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:24:07 --> Input Class Initialized
INFO - 2017-01-17 23:24:07 --> Language Class Initialized
INFO - 2017-01-17 23:24:07 --> Loader Class Initialized
INFO - 2017-01-17 23:24:07 --> Database Driver Class Initialized
INFO - 2017-01-17 23:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:24:07 --> Controller Class Initialized
INFO - 2017-01-17 23:24:07 --> Upload Class Initialized
INFO - 2017-01-17 23:24:07 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:24:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:24:07 --> Helper loaded: form_helper
INFO - 2017-01-17 23:24:07 --> Form Validation Class Initialized
INFO - 2017-01-17 23:24:07 --> Final output sent to browser
DEBUG - 2017-01-17 23:24:07 --> Total execution time: 0.0151
INFO - 2017-01-17 23:33:18 --> Config Class Initialized
INFO - 2017-01-17 23:33:18 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:33:18 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:33:18 --> Utf8 Class Initialized
INFO - 2017-01-17 23:33:18 --> URI Class Initialized
INFO - 2017-01-17 23:33:18 --> Router Class Initialized
INFO - 2017-01-17 23:33:18 --> Output Class Initialized
INFO - 2017-01-17 23:33:18 --> Security Class Initialized
DEBUG - 2017-01-17 23:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:33:18 --> Input Class Initialized
INFO - 2017-01-17 23:33:18 --> Language Class Initialized
INFO - 2017-01-17 23:33:18 --> Loader Class Initialized
INFO - 2017-01-17 23:33:18 --> Database Driver Class Initialized
INFO - 2017-01-17 23:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:33:18 --> Controller Class Initialized
INFO - 2017-01-17 23:33:18 --> Upload Class Initialized
INFO - 2017-01-17 23:33:18 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:33:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:33:18 --> Helper loaded: form_helper
INFO - 2017-01-17 23:33:18 --> Form Validation Class Initialized
INFO - 2017-01-17 23:33:18 --> Final output sent to browser
DEBUG - 2017-01-17 23:33:18 --> Total execution time: 0.0159
INFO - 2017-01-17 23:33:18 --> Config Class Initialized
INFO - 2017-01-17 23:33:18 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:33:18 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:33:18 --> Utf8 Class Initialized
INFO - 2017-01-17 23:33:18 --> URI Class Initialized
INFO - 2017-01-17 23:33:18 --> Router Class Initialized
INFO - 2017-01-17 23:33:18 --> Output Class Initialized
INFO - 2017-01-17 23:33:18 --> Security Class Initialized
DEBUG - 2017-01-17 23:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:33:18 --> Input Class Initialized
INFO - 2017-01-17 23:33:18 --> Language Class Initialized
INFO - 2017-01-17 23:33:18 --> Loader Class Initialized
INFO - 2017-01-17 23:33:18 --> Database Driver Class Initialized
INFO - 2017-01-17 23:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:33:18 --> Controller Class Initialized
INFO - 2017-01-17 23:33:18 --> Upload Class Initialized
INFO - 2017-01-17 23:33:18 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:33:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:33:18 --> Helper loaded: form_helper
INFO - 2017-01-17 23:33:18 --> Form Validation Class Initialized
INFO - 2017-01-17 23:33:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-17 23:33:18 --> Final output sent to browser
DEBUG - 2017-01-17 23:33:18 --> Total execution time: 0.0175
INFO - 2017-01-17 23:38:05 --> Config Class Initialized
INFO - 2017-01-17 23:38:05 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:38:05 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:38:05 --> Utf8 Class Initialized
INFO - 2017-01-17 23:38:05 --> URI Class Initialized
INFO - 2017-01-17 23:38:05 --> Router Class Initialized
INFO - 2017-01-17 23:38:05 --> Output Class Initialized
INFO - 2017-01-17 23:38:05 --> Security Class Initialized
DEBUG - 2017-01-17 23:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:38:05 --> Input Class Initialized
INFO - 2017-01-17 23:38:05 --> Language Class Initialized
INFO - 2017-01-17 23:38:05 --> Loader Class Initialized
INFO - 2017-01-17 23:38:05 --> Database Driver Class Initialized
INFO - 2017-01-17 23:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:38:05 --> Controller Class Initialized
INFO - 2017-01-17 23:38:05 --> Upload Class Initialized
INFO - 2017-01-17 23:38:05 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:38:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:38:05 --> Helper loaded: form_helper
INFO - 2017-01-17 23:38:05 --> Form Validation Class Initialized
INFO - 2017-01-17 23:38:05 --> Language file loaded: language/english/upload_lang.php
INFO - 2017-01-17 23:38:05 --> The file you are attempting to upload is larger than the permitted size.
INFO - 2017-01-17 23:38:05 --> Final output sent to browser
DEBUG - 2017-01-17 23:38:05 --> Total execution time: 0.0274
INFO - 2017-01-17 23:38:05 --> Config Class Initialized
INFO - 2017-01-17 23:38:05 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:38:05 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:38:05 --> Utf8 Class Initialized
INFO - 2017-01-17 23:38:05 --> URI Class Initialized
INFO - 2017-01-17 23:38:05 --> Router Class Initialized
INFO - 2017-01-17 23:38:05 --> Output Class Initialized
INFO - 2017-01-17 23:38:05 --> Security Class Initialized
DEBUG - 2017-01-17 23:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:38:05 --> Input Class Initialized
INFO - 2017-01-17 23:38:05 --> Language Class Initialized
INFO - 2017-01-17 23:38:05 --> Loader Class Initialized
INFO - 2017-01-17 23:38:05 --> Database Driver Class Initialized
INFO - 2017-01-17 23:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:38:05 --> Controller Class Initialized
INFO - 2017-01-17 23:38:05 --> Upload Class Initialized
INFO - 2017-01-17 23:38:05 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:38:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:38:05 --> Helper loaded: form_helper
INFO - 2017-01-17 23:38:05 --> Form Validation Class Initialized
INFO - 2017-01-17 23:38:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-17 23:38:05 --> Final output sent to browser
DEBUG - 2017-01-17 23:38:05 --> Total execution time: 0.0156
INFO - 2017-01-17 23:38:10 --> Config Class Initialized
INFO - 2017-01-17 23:38:10 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:38:10 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:38:10 --> Utf8 Class Initialized
INFO - 2017-01-17 23:38:10 --> URI Class Initialized
INFO - 2017-01-17 23:38:10 --> Router Class Initialized
INFO - 2017-01-17 23:38:10 --> Output Class Initialized
INFO - 2017-01-17 23:38:10 --> Security Class Initialized
DEBUG - 2017-01-17 23:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:38:10 --> Input Class Initialized
INFO - 2017-01-17 23:38:10 --> Language Class Initialized
INFO - 2017-01-17 23:38:10 --> Loader Class Initialized
INFO - 2017-01-17 23:38:10 --> Database Driver Class Initialized
INFO - 2017-01-17 23:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:38:10 --> Controller Class Initialized
INFO - 2017-01-17 23:38:10 --> Upload Class Initialized
INFO - 2017-01-17 23:38:10 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:38:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:38:10 --> Helper loaded: form_helper
INFO - 2017-01-17 23:38:10 --> Form Validation Class Initialized
INFO - 2017-01-17 23:38:10 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-17 23:38:10 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-17 23:38:10 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-17 23:38:10 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-17 23:38:10 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-17 23:38:10 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-17 23:38:10 --> Final output sent to browser
DEBUG - 2017-01-17 23:38:10 --> Total execution time: 0.0162
INFO - 2017-01-17 23:38:11 --> Config Class Initialized
INFO - 2017-01-17 23:38:11 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:38:11 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:38:11 --> Utf8 Class Initialized
INFO - 2017-01-17 23:38:11 --> URI Class Initialized
INFO - 2017-01-17 23:38:11 --> Router Class Initialized
INFO - 2017-01-17 23:38:11 --> Output Class Initialized
INFO - 2017-01-17 23:38:11 --> Security Class Initialized
DEBUG - 2017-01-17 23:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:38:11 --> Input Class Initialized
INFO - 2017-01-17 23:38:11 --> Language Class Initialized
INFO - 2017-01-17 23:38:11 --> Loader Class Initialized
INFO - 2017-01-17 23:38:11 --> Database Driver Class Initialized
INFO - 2017-01-17 23:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:38:11 --> Controller Class Initialized
INFO - 2017-01-17 23:38:11 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:38:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:38:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 23:38:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 23:38:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 23:38:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 23:38:11 --> Final output sent to browser
DEBUG - 2017-01-17 23:38:11 --> Total execution time: 0.0703
INFO - 2017-01-17 23:40:09 --> Config Class Initialized
INFO - 2017-01-17 23:40:09 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:40:09 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:40:09 --> Utf8 Class Initialized
INFO - 2017-01-17 23:40:09 --> URI Class Initialized
INFO - 2017-01-17 23:40:09 --> Router Class Initialized
INFO - 2017-01-17 23:40:09 --> Output Class Initialized
INFO - 2017-01-17 23:40:09 --> Security Class Initialized
DEBUG - 2017-01-17 23:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:40:09 --> Input Class Initialized
INFO - 2017-01-17 23:40:09 --> Language Class Initialized
INFO - 2017-01-17 23:40:09 --> Loader Class Initialized
INFO - 2017-01-17 23:40:09 --> Database Driver Class Initialized
INFO - 2017-01-17 23:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:40:09 --> Controller Class Initialized
INFO - 2017-01-17 23:40:09 --> Upload Class Initialized
INFO - 2017-01-17 23:40:09 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:40:09 --> Helper loaded: form_helper
INFO - 2017-01-17 23:40:09 --> Form Validation Class Initialized
INFO - 2017-01-17 23:40:09 --> Language file loaded: language/english/upload_lang.php
INFO - 2017-01-17 23:40:09 --> The file you are attempting to upload is larger than the permitted size.
INFO - 2017-01-17 23:40:09 --> Final output sent to browser
DEBUG - 2017-01-17 23:40:09 --> Total execution time: 0.0176
INFO - 2017-01-17 23:40:09 --> Config Class Initialized
INFO - 2017-01-17 23:40:09 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:40:09 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:40:09 --> Utf8 Class Initialized
INFO - 2017-01-17 23:40:09 --> URI Class Initialized
INFO - 2017-01-17 23:40:09 --> Router Class Initialized
INFO - 2017-01-17 23:40:09 --> Output Class Initialized
INFO - 2017-01-17 23:40:09 --> Security Class Initialized
DEBUG - 2017-01-17 23:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:40:09 --> Input Class Initialized
INFO - 2017-01-17 23:40:09 --> Language Class Initialized
INFO - 2017-01-17 23:40:09 --> Loader Class Initialized
INFO - 2017-01-17 23:40:09 --> Database Driver Class Initialized
INFO - 2017-01-17 23:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:40:09 --> Controller Class Initialized
INFO - 2017-01-17 23:40:09 --> Upload Class Initialized
INFO - 2017-01-17 23:40:09 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:40:09 --> Helper loaded: form_helper
INFO - 2017-01-17 23:40:09 --> Form Validation Class Initialized
INFO - 2017-01-17 23:40:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-17 23:40:09 --> Final output sent to browser
DEBUG - 2017-01-17 23:40:09 --> Total execution time: 0.0176
INFO - 2017-01-17 23:40:21 --> Config Class Initialized
INFO - 2017-01-17 23:40:21 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:40:21 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:40:21 --> Utf8 Class Initialized
INFO - 2017-01-17 23:40:21 --> URI Class Initialized
INFO - 2017-01-17 23:40:21 --> Router Class Initialized
INFO - 2017-01-17 23:40:21 --> Output Class Initialized
INFO - 2017-01-17 23:40:21 --> Security Class Initialized
DEBUG - 2017-01-17 23:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:40:21 --> Input Class Initialized
INFO - 2017-01-17 23:40:21 --> Language Class Initialized
INFO - 2017-01-17 23:40:21 --> Loader Class Initialized
INFO - 2017-01-17 23:40:21 --> Database Driver Class Initialized
INFO - 2017-01-17 23:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:40:21 --> Controller Class Initialized
INFO - 2017-01-17 23:40:21 --> Upload Class Initialized
INFO - 2017-01-17 23:40:21 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:40:21 --> Helper loaded: form_helper
INFO - 2017-01-17 23:40:21 --> Form Validation Class Initialized
INFO - 2017-01-17 23:40:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-17 23:40:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-17 23:40:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-17 23:40:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-17 23:40:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-17 23:40:21 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-17 23:40:21 --> Final output sent to browser
DEBUG - 2017-01-17 23:40:21 --> Total execution time: 0.0158
INFO - 2017-01-17 23:40:21 --> Config Class Initialized
INFO - 2017-01-17 23:40:21 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:40:21 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:40:21 --> Utf8 Class Initialized
INFO - 2017-01-17 23:40:21 --> URI Class Initialized
INFO - 2017-01-17 23:40:21 --> Router Class Initialized
INFO - 2017-01-17 23:40:21 --> Output Class Initialized
INFO - 2017-01-17 23:40:21 --> Security Class Initialized
DEBUG - 2017-01-17 23:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:40:21 --> Input Class Initialized
INFO - 2017-01-17 23:40:21 --> Language Class Initialized
INFO - 2017-01-17 23:40:21 --> Loader Class Initialized
INFO - 2017-01-17 23:40:21 --> Database Driver Class Initialized
INFO - 2017-01-17 23:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:40:21 --> Controller Class Initialized
INFO - 2017-01-17 23:40:21 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 23:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 23:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 23:40:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 23:40:21 --> Final output sent to browser
DEBUG - 2017-01-17 23:40:21 --> Total execution time: 0.0130
INFO - 2017-01-17 23:40:38 --> Config Class Initialized
INFO - 2017-01-17 23:40:38 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:40:38 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:40:38 --> Utf8 Class Initialized
INFO - 2017-01-17 23:40:38 --> URI Class Initialized
INFO - 2017-01-17 23:40:38 --> Router Class Initialized
INFO - 2017-01-17 23:40:38 --> Output Class Initialized
INFO - 2017-01-17 23:40:38 --> Security Class Initialized
DEBUG - 2017-01-17 23:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:40:38 --> Input Class Initialized
INFO - 2017-01-17 23:40:38 --> Language Class Initialized
INFO - 2017-01-17 23:40:38 --> Loader Class Initialized
INFO - 2017-01-17 23:40:38 --> Database Driver Class Initialized
INFO - 2017-01-17 23:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:40:38 --> Controller Class Initialized
INFO - 2017-01-17 23:40:38 --> Upload Class Initialized
INFO - 2017-01-17 23:40:38 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:40:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:40:38 --> Helper loaded: form_helper
INFO - 2017-01-17 23:40:38 --> Form Validation Class Initialized
INFO - 2017-01-17 23:40:38 --> Final output sent to browser
DEBUG - 2017-01-17 23:40:38 --> Total execution time: 0.0210
INFO - 2017-01-17 23:42:33 --> Config Class Initialized
INFO - 2017-01-17 23:42:33 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:42:33 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:42:33 --> Utf8 Class Initialized
INFO - 2017-01-17 23:42:33 --> URI Class Initialized
INFO - 2017-01-17 23:42:33 --> Router Class Initialized
INFO - 2017-01-17 23:42:33 --> Output Class Initialized
INFO - 2017-01-17 23:42:33 --> Security Class Initialized
DEBUG - 2017-01-17 23:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:42:33 --> Input Class Initialized
INFO - 2017-01-17 23:42:33 --> Language Class Initialized
INFO - 2017-01-17 23:42:33 --> Loader Class Initialized
INFO - 2017-01-17 23:42:33 --> Database Driver Class Initialized
INFO - 2017-01-17 23:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:42:33 --> Controller Class Initialized
INFO - 2017-01-17 23:42:33 --> Upload Class Initialized
INFO - 2017-01-17 23:42:33 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:42:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:42:33 --> Helper loaded: form_helper
INFO - 2017-01-17 23:42:33 --> Form Validation Class Initialized
INFO - 2017-01-17 23:42:33 --> Final output sent to browser
DEBUG - 2017-01-17 23:42:33 --> Total execution time: 0.0168
INFO - 2017-01-17 23:42:33 --> Config Class Initialized
INFO - 2017-01-17 23:42:33 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:42:33 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:42:33 --> Utf8 Class Initialized
INFO - 2017-01-17 23:42:33 --> URI Class Initialized
INFO - 2017-01-17 23:42:33 --> Router Class Initialized
INFO - 2017-01-17 23:42:33 --> Output Class Initialized
INFO - 2017-01-17 23:42:33 --> Security Class Initialized
DEBUG - 2017-01-17 23:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:42:33 --> Input Class Initialized
INFO - 2017-01-17 23:42:33 --> Language Class Initialized
INFO - 2017-01-17 23:42:33 --> Loader Class Initialized
INFO - 2017-01-17 23:42:33 --> Database Driver Class Initialized
INFO - 2017-01-17 23:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:42:33 --> Controller Class Initialized
INFO - 2017-01-17 23:42:33 --> Upload Class Initialized
INFO - 2017-01-17 23:42:33 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:42:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:42:33 --> Helper loaded: form_helper
INFO - 2017-01-17 23:42:33 --> Form Validation Class Initialized
INFO - 2017-01-17 23:42:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-17 23:42:33 --> Final output sent to browser
DEBUG - 2017-01-17 23:42:33 --> Total execution time: 0.0173
INFO - 2017-01-17 23:46:53 --> Config Class Initialized
INFO - 2017-01-17 23:46:53 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:46:53 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:46:53 --> Utf8 Class Initialized
INFO - 2017-01-17 23:46:53 --> URI Class Initialized
INFO - 2017-01-17 23:46:53 --> Router Class Initialized
INFO - 2017-01-17 23:46:53 --> Output Class Initialized
INFO - 2017-01-17 23:46:53 --> Security Class Initialized
DEBUG - 2017-01-17 23:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:46:53 --> Input Class Initialized
INFO - 2017-01-17 23:46:53 --> Language Class Initialized
INFO - 2017-01-17 23:46:53 --> Loader Class Initialized
INFO - 2017-01-17 23:46:53 --> Database Driver Class Initialized
INFO - 2017-01-17 23:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:46:53 --> Controller Class Initialized
INFO - 2017-01-17 23:46:53 --> Upload Class Initialized
INFO - 2017-01-17 23:46:53 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:46:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:46:53 --> Helper loaded: form_helper
INFO - 2017-01-17 23:46:53 --> Form Validation Class Initialized
INFO - 2017-01-17 23:46:53 --> Language file loaded: language/english/upload_lang.php
INFO - 2017-01-17 23:46:53 --> The file you are attempting to upload is larger than the permitted size.
INFO - 2017-01-17 23:46:53 --> Final output sent to browser
DEBUG - 2017-01-17 23:46:53 --> Total execution time: 0.0155
INFO - 2017-01-17 23:46:53 --> Config Class Initialized
INFO - 2017-01-17 23:46:53 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:46:53 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:46:53 --> Utf8 Class Initialized
INFO - 2017-01-17 23:46:53 --> URI Class Initialized
INFO - 2017-01-17 23:46:53 --> Router Class Initialized
INFO - 2017-01-17 23:46:53 --> Output Class Initialized
INFO - 2017-01-17 23:46:53 --> Security Class Initialized
DEBUG - 2017-01-17 23:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:46:53 --> Input Class Initialized
INFO - 2017-01-17 23:46:53 --> Language Class Initialized
INFO - 2017-01-17 23:46:53 --> Loader Class Initialized
INFO - 2017-01-17 23:46:53 --> Database Driver Class Initialized
INFO - 2017-01-17 23:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:46:53 --> Controller Class Initialized
INFO - 2017-01-17 23:46:53 --> Upload Class Initialized
INFO - 2017-01-17 23:46:53 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:46:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:46:53 --> Helper loaded: form_helper
INFO - 2017-01-17 23:46:53 --> Form Validation Class Initialized
INFO - 2017-01-17 23:46:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-17 23:46:53 --> Final output sent to browser
DEBUG - 2017-01-17 23:46:53 --> Total execution time: 0.0619
INFO - 2017-01-17 23:49:32 --> Config Class Initialized
INFO - 2017-01-17 23:49:32 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:49:32 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:49:32 --> Utf8 Class Initialized
INFO - 2017-01-17 23:49:32 --> URI Class Initialized
INFO - 2017-01-17 23:49:32 --> Router Class Initialized
INFO - 2017-01-17 23:49:32 --> Output Class Initialized
INFO - 2017-01-17 23:49:32 --> Security Class Initialized
DEBUG - 2017-01-17 23:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:49:32 --> Input Class Initialized
INFO - 2017-01-17 23:49:32 --> Language Class Initialized
INFO - 2017-01-17 23:49:32 --> Loader Class Initialized
INFO - 2017-01-17 23:49:32 --> Database Driver Class Initialized
INFO - 2017-01-17 23:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:49:32 --> Controller Class Initialized
INFO - 2017-01-17 23:49:32 --> Upload Class Initialized
INFO - 2017-01-17 23:49:32 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:49:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:49:32 --> Helper loaded: form_helper
INFO - 2017-01-17 23:49:32 --> Form Validation Class Initialized
INFO - 2017-01-17 23:49:32 --> Language file loaded: language/english/upload_lang.php
INFO - 2017-01-17 23:49:32 --> The file you are attempting to upload is larger than the permitted size.
INFO - 2017-01-17 23:49:32 --> Final output sent to browser
DEBUG - 2017-01-17 23:49:32 --> Total execution time: 0.0149
INFO - 2017-01-17 23:49:32 --> Config Class Initialized
INFO - 2017-01-17 23:49:32 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:49:32 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:49:32 --> Utf8 Class Initialized
INFO - 2017-01-17 23:49:32 --> URI Class Initialized
INFO - 2017-01-17 23:49:32 --> Router Class Initialized
INFO - 2017-01-17 23:49:32 --> Output Class Initialized
INFO - 2017-01-17 23:49:32 --> Security Class Initialized
DEBUG - 2017-01-17 23:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:49:32 --> Input Class Initialized
INFO - 2017-01-17 23:49:32 --> Language Class Initialized
INFO - 2017-01-17 23:49:32 --> Loader Class Initialized
INFO - 2017-01-17 23:49:32 --> Database Driver Class Initialized
INFO - 2017-01-17 23:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:49:32 --> Controller Class Initialized
INFO - 2017-01-17 23:49:32 --> Upload Class Initialized
INFO - 2017-01-17 23:49:32 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:49:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:49:32 --> Helper loaded: form_helper
INFO - 2017-01-17 23:49:32 --> Form Validation Class Initialized
INFO - 2017-01-17 23:49:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-17 23:49:32 --> Final output sent to browser
DEBUG - 2017-01-17 23:49:32 --> Total execution time: 0.0171
INFO - 2017-01-17 23:49:43 --> Config Class Initialized
INFO - 2017-01-17 23:49:43 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:49:43 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:49:43 --> Utf8 Class Initialized
INFO - 2017-01-17 23:49:43 --> URI Class Initialized
INFO - 2017-01-17 23:49:43 --> Router Class Initialized
INFO - 2017-01-17 23:49:43 --> Output Class Initialized
INFO - 2017-01-17 23:49:43 --> Security Class Initialized
DEBUG - 2017-01-17 23:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:49:43 --> Input Class Initialized
INFO - 2017-01-17 23:49:43 --> Language Class Initialized
INFO - 2017-01-17 23:49:43 --> Loader Class Initialized
INFO - 2017-01-17 23:49:43 --> Database Driver Class Initialized
INFO - 2017-01-17 23:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:49:43 --> Controller Class Initialized
INFO - 2017-01-17 23:49:43 --> Helper loaded: date_helper
DEBUG - 2017-01-17 23:49:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:49:43 --> Helper loaded: url_helper
INFO - 2017-01-17 23:49:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 23:49:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-17 23:49:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-17 23:49:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-17 23:49:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 23:49:43 --> Final output sent to browser
DEBUG - 2017-01-17 23:49:43 --> Total execution time: 0.0156
INFO - 2017-01-17 23:50:00 --> Config Class Initialized
INFO - 2017-01-17 23:50:00 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:50:00 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:50:00 --> Utf8 Class Initialized
INFO - 2017-01-17 23:50:00 --> URI Class Initialized
INFO - 2017-01-17 23:50:00 --> Router Class Initialized
INFO - 2017-01-17 23:50:00 --> Output Class Initialized
INFO - 2017-01-17 23:50:00 --> Security Class Initialized
DEBUG - 2017-01-17 23:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:50:00 --> Input Class Initialized
INFO - 2017-01-17 23:50:00 --> Language Class Initialized
INFO - 2017-01-17 23:50:00 --> Loader Class Initialized
INFO - 2017-01-17 23:50:00 --> Database Driver Class Initialized
INFO - 2017-01-17 23:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:50:00 --> Controller Class Initialized
INFO - 2017-01-17 23:50:00 --> Helper loaded: date_helper
DEBUG - 2017-01-17 23:50:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:50:00 --> Helper loaded: url_helper
INFO - 2017-01-17 23:50:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 23:50:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-17 23:50:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-17 23:50:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-17 23:50:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 23:50:00 --> Final output sent to browser
DEBUG - 2017-01-17 23:50:00 --> Total execution time: 0.0380
INFO - 2017-01-17 23:50:15 --> Config Class Initialized
INFO - 2017-01-17 23:50:15 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:50:15 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:50:15 --> Utf8 Class Initialized
INFO - 2017-01-17 23:50:15 --> URI Class Initialized
INFO - 2017-01-17 23:50:15 --> Router Class Initialized
INFO - 2017-01-17 23:50:15 --> Output Class Initialized
INFO - 2017-01-17 23:50:15 --> Security Class Initialized
DEBUG - 2017-01-17 23:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:50:15 --> Input Class Initialized
INFO - 2017-01-17 23:50:15 --> Language Class Initialized
INFO - 2017-01-17 23:50:15 --> Loader Class Initialized
INFO - 2017-01-17 23:50:15 --> Database Driver Class Initialized
INFO - 2017-01-17 23:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:50:15 --> Controller Class Initialized
INFO - 2017-01-17 23:50:15 --> Upload Class Initialized
INFO - 2017-01-17 23:50:15 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:50:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:50:15 --> Helper loaded: form_helper
INFO - 2017-01-17 23:50:15 --> Form Validation Class Initialized
INFO - 2017-01-17 23:50:15 --> Language file loaded: language/english/upload_lang.php
INFO - 2017-01-17 23:50:15 --> The file you are attempting to upload is larger than the permitted size.
INFO - 2017-01-17 23:50:15 --> Final output sent to browser
DEBUG - 2017-01-17 23:50:15 --> Total execution time: 0.0234
INFO - 2017-01-17 23:50:15 --> Config Class Initialized
INFO - 2017-01-17 23:50:15 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:50:15 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:50:15 --> Utf8 Class Initialized
INFO - 2017-01-17 23:50:15 --> URI Class Initialized
INFO - 2017-01-17 23:50:15 --> Router Class Initialized
INFO - 2017-01-17 23:50:15 --> Output Class Initialized
INFO - 2017-01-17 23:50:15 --> Security Class Initialized
DEBUG - 2017-01-17 23:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:50:15 --> Input Class Initialized
INFO - 2017-01-17 23:50:15 --> Language Class Initialized
INFO - 2017-01-17 23:50:15 --> Loader Class Initialized
INFO - 2017-01-17 23:50:15 --> Database Driver Class Initialized
INFO - 2017-01-17 23:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:50:15 --> Controller Class Initialized
INFO - 2017-01-17 23:50:15 --> Upload Class Initialized
INFO - 2017-01-17 23:50:15 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:50:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:50:15 --> Helper loaded: form_helper
INFO - 2017-01-17 23:50:15 --> Form Validation Class Initialized
INFO - 2017-01-17 23:50:15 --> Final output sent to browser
DEBUG - 2017-01-17 23:50:15 --> Total execution time: 0.0341
INFO - 2017-01-17 23:50:15 --> Config Class Initialized
INFO - 2017-01-17 23:50:15 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:50:15 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:50:15 --> Utf8 Class Initialized
INFO - 2017-01-17 23:50:15 --> URI Class Initialized
INFO - 2017-01-17 23:50:15 --> Router Class Initialized
INFO - 2017-01-17 23:50:15 --> Output Class Initialized
INFO - 2017-01-17 23:50:15 --> Security Class Initialized
DEBUG - 2017-01-17 23:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:50:15 --> Input Class Initialized
INFO - 2017-01-17 23:50:15 --> Language Class Initialized
INFO - 2017-01-17 23:50:15 --> Loader Class Initialized
INFO - 2017-01-17 23:50:15 --> Database Driver Class Initialized
INFO - 2017-01-17 23:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:50:15 --> Controller Class Initialized
INFO - 2017-01-17 23:50:15 --> Upload Class Initialized
INFO - 2017-01-17 23:50:15 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:50:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:50:15 --> Helper loaded: form_helper
INFO - 2017-01-17 23:50:15 --> Form Validation Class Initialized
INFO - 2017-01-17 23:50:15 --> Language file loaded: language/english/upload_lang.php
INFO - 2017-01-17 23:50:15 --> The file you are attempting to upload is larger than the permitted size.
INFO - 2017-01-17 23:50:15 --> Final output sent to browser
DEBUG - 2017-01-17 23:50:15 --> Total execution time: 0.0153
INFO - 2017-01-17 23:50:16 --> Config Class Initialized
INFO - 2017-01-17 23:50:16 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:50:16 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:50:16 --> Utf8 Class Initialized
INFO - 2017-01-17 23:50:16 --> URI Class Initialized
INFO - 2017-01-17 23:50:16 --> Router Class Initialized
INFO - 2017-01-17 23:50:16 --> Output Class Initialized
INFO - 2017-01-17 23:50:16 --> Security Class Initialized
DEBUG - 2017-01-17 23:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:50:16 --> Input Class Initialized
INFO - 2017-01-17 23:50:16 --> Language Class Initialized
INFO - 2017-01-17 23:50:16 --> Loader Class Initialized
INFO - 2017-01-17 23:50:16 --> Database Driver Class Initialized
INFO - 2017-01-17 23:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:50:16 --> Controller Class Initialized
INFO - 2017-01-17 23:50:16 --> Upload Class Initialized
INFO - 2017-01-17 23:50:16 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:50:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:50:16 --> Helper loaded: form_helper
INFO - 2017-01-17 23:50:16 --> Form Validation Class Initialized
INFO - 2017-01-17 23:50:16 --> Final output sent to browser
DEBUG - 2017-01-17 23:50:16 --> Total execution time: 0.0168
INFO - 2017-01-17 23:50:17 --> Config Class Initialized
INFO - 2017-01-17 23:50:17 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:50:17 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:50:17 --> Utf8 Class Initialized
INFO - 2017-01-17 23:50:17 --> URI Class Initialized
INFO - 2017-01-17 23:50:17 --> Router Class Initialized
INFO - 2017-01-17 23:50:17 --> Output Class Initialized
INFO - 2017-01-17 23:50:17 --> Security Class Initialized
DEBUG - 2017-01-17 23:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:50:17 --> Input Class Initialized
INFO - 2017-01-17 23:50:17 --> Language Class Initialized
INFO - 2017-01-17 23:50:17 --> Loader Class Initialized
INFO - 2017-01-17 23:50:17 --> Database Driver Class Initialized
INFO - 2017-01-17 23:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:50:17 --> Controller Class Initialized
INFO - 2017-01-17 23:50:17 --> Upload Class Initialized
INFO - 2017-01-17 23:50:17 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:50:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:50:17 --> Helper loaded: form_helper
INFO - 2017-01-17 23:50:17 --> Form Validation Class Initialized
INFO - 2017-01-17 23:50:17 --> Language file loaded: language/english/upload_lang.php
INFO - 2017-01-17 23:50:17 --> The file you are attempting to upload is larger than the permitted size.
INFO - 2017-01-17 23:50:17 --> Final output sent to browser
DEBUG - 2017-01-17 23:50:17 --> Total execution time: 0.0152
INFO - 2017-01-17 23:50:17 --> Config Class Initialized
INFO - 2017-01-17 23:50:17 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:50:17 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:50:17 --> Utf8 Class Initialized
INFO - 2017-01-17 23:50:17 --> URI Class Initialized
INFO - 2017-01-17 23:50:17 --> Router Class Initialized
INFO - 2017-01-17 23:50:17 --> Output Class Initialized
INFO - 2017-01-17 23:50:17 --> Security Class Initialized
DEBUG - 2017-01-17 23:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:50:17 --> Input Class Initialized
INFO - 2017-01-17 23:50:17 --> Language Class Initialized
INFO - 2017-01-17 23:50:17 --> Loader Class Initialized
INFO - 2017-01-17 23:50:17 --> Database Driver Class Initialized
INFO - 2017-01-17 23:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:50:17 --> Controller Class Initialized
INFO - 2017-01-17 23:50:17 --> Upload Class Initialized
INFO - 2017-01-17 23:50:17 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:50:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:50:17 --> Helper loaded: form_helper
INFO - 2017-01-17 23:50:17 --> Form Validation Class Initialized
INFO - 2017-01-17 23:50:17 --> Final output sent to browser
DEBUG - 2017-01-17 23:50:17 --> Total execution time: 0.0161
INFO - 2017-01-17 23:50:18 --> Config Class Initialized
INFO - 2017-01-17 23:50:18 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:50:18 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:50:18 --> Utf8 Class Initialized
INFO - 2017-01-17 23:50:18 --> URI Class Initialized
INFO - 2017-01-17 23:50:18 --> Router Class Initialized
INFO - 2017-01-17 23:50:18 --> Output Class Initialized
INFO - 2017-01-17 23:50:18 --> Security Class Initialized
DEBUG - 2017-01-17 23:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:50:18 --> Input Class Initialized
INFO - 2017-01-17 23:50:18 --> Language Class Initialized
INFO - 2017-01-17 23:50:18 --> Loader Class Initialized
INFO - 2017-01-17 23:50:18 --> Database Driver Class Initialized
INFO - 2017-01-17 23:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:50:18 --> Controller Class Initialized
INFO - 2017-01-17 23:50:18 --> Upload Class Initialized
INFO - 2017-01-17 23:50:18 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:50:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:50:18 --> Helper loaded: form_helper
INFO - 2017-01-17 23:50:18 --> Form Validation Class Initialized
INFO - 2017-01-17 23:50:18 --> Language file loaded: language/english/upload_lang.php
INFO - 2017-01-17 23:50:18 --> The file you are attempting to upload is larger than the permitted size.
INFO - 2017-01-17 23:50:18 --> Final output sent to browser
DEBUG - 2017-01-17 23:50:18 --> Total execution time: 0.0149
INFO - 2017-01-17 23:50:18 --> Config Class Initialized
INFO - 2017-01-17 23:50:18 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:50:18 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:50:18 --> Utf8 Class Initialized
INFO - 2017-01-17 23:50:18 --> URI Class Initialized
INFO - 2017-01-17 23:50:18 --> Router Class Initialized
INFO - 2017-01-17 23:50:18 --> Output Class Initialized
INFO - 2017-01-17 23:50:18 --> Security Class Initialized
DEBUG - 2017-01-17 23:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:50:18 --> Input Class Initialized
INFO - 2017-01-17 23:50:18 --> Language Class Initialized
INFO - 2017-01-17 23:50:18 --> Loader Class Initialized
INFO - 2017-01-17 23:50:18 --> Database Driver Class Initialized
INFO - 2017-01-17 23:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:50:18 --> Controller Class Initialized
INFO - 2017-01-17 23:50:18 --> Upload Class Initialized
INFO - 2017-01-17 23:50:18 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:50:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:50:18 --> Helper loaded: form_helper
INFO - 2017-01-17 23:50:18 --> Form Validation Class Initialized
INFO - 2017-01-17 23:50:18 --> Final output sent to browser
DEBUG - 2017-01-17 23:50:18 --> Total execution time: 0.0153
INFO - 2017-01-17 23:52:20 --> Config Class Initialized
INFO - 2017-01-17 23:52:20 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:52:20 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:52:20 --> Utf8 Class Initialized
INFO - 2017-01-17 23:52:20 --> URI Class Initialized
INFO - 2017-01-17 23:52:20 --> Router Class Initialized
INFO - 2017-01-17 23:52:20 --> Output Class Initialized
INFO - 2017-01-17 23:52:20 --> Security Class Initialized
DEBUG - 2017-01-17 23:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:52:20 --> Input Class Initialized
INFO - 2017-01-17 23:52:20 --> Language Class Initialized
INFO - 2017-01-17 23:52:20 --> Loader Class Initialized
INFO - 2017-01-17 23:52:20 --> Database Driver Class Initialized
INFO - 2017-01-17 23:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:52:20 --> Controller Class Initialized
INFO - 2017-01-17 23:52:20 --> Upload Class Initialized
INFO - 2017-01-17 23:52:20 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:52:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:52:20 --> Helper loaded: form_helper
INFO - 2017-01-17 23:52:20 --> Form Validation Class Initialized
INFO - 2017-01-17 23:52:20 --> Final output sent to browser
DEBUG - 2017-01-17 23:52:20 --> Total execution time: 0.0149
INFO - 2017-01-17 23:52:20 --> Config Class Initialized
INFO - 2017-01-17 23:52:20 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:52:20 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:52:20 --> Utf8 Class Initialized
INFO - 2017-01-17 23:52:20 --> URI Class Initialized
INFO - 2017-01-17 23:52:20 --> Router Class Initialized
INFO - 2017-01-17 23:52:20 --> Output Class Initialized
INFO - 2017-01-17 23:52:20 --> Security Class Initialized
DEBUG - 2017-01-17 23:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:52:20 --> Input Class Initialized
INFO - 2017-01-17 23:52:20 --> Language Class Initialized
INFO - 2017-01-17 23:52:20 --> Loader Class Initialized
INFO - 2017-01-17 23:52:20 --> Database Driver Class Initialized
INFO - 2017-01-17 23:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:52:20 --> Controller Class Initialized
INFO - 2017-01-17 23:52:20 --> Upload Class Initialized
INFO - 2017-01-17 23:52:20 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:52:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:52:20 --> Helper loaded: form_helper
INFO - 2017-01-17 23:52:20 --> Form Validation Class Initialized
INFO - 2017-01-17 23:52:20 --> Final output sent to browser
DEBUG - 2017-01-17 23:52:20 --> Total execution time: 0.0157
INFO - 2017-01-17 23:52:20 --> Config Class Initialized
INFO - 2017-01-17 23:52:20 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:52:20 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:52:20 --> Utf8 Class Initialized
INFO - 2017-01-17 23:52:20 --> URI Class Initialized
INFO - 2017-01-17 23:52:20 --> Router Class Initialized
INFO - 2017-01-17 23:52:20 --> Output Class Initialized
INFO - 2017-01-17 23:52:20 --> Security Class Initialized
DEBUG - 2017-01-17 23:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:52:20 --> Input Class Initialized
INFO - 2017-01-17 23:52:20 --> Language Class Initialized
INFO - 2017-01-17 23:52:20 --> Loader Class Initialized
INFO - 2017-01-17 23:52:20 --> Database Driver Class Initialized
INFO - 2017-01-17 23:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:52:20 --> Controller Class Initialized
INFO - 2017-01-17 23:52:20 --> Upload Class Initialized
INFO - 2017-01-17 23:52:20 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:52:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:52:20 --> Helper loaded: form_helper
INFO - 2017-01-17 23:52:20 --> Form Validation Class Initialized
INFO - 2017-01-17 23:52:20 --> Final output sent to browser
DEBUG - 2017-01-17 23:52:20 --> Total execution time: 0.0156
INFO - 2017-01-17 23:52:20 --> Config Class Initialized
INFO - 2017-01-17 23:52:20 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:52:20 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:52:20 --> Utf8 Class Initialized
INFO - 2017-01-17 23:52:20 --> URI Class Initialized
INFO - 2017-01-17 23:52:20 --> Router Class Initialized
INFO - 2017-01-17 23:52:20 --> Output Class Initialized
INFO - 2017-01-17 23:52:20 --> Security Class Initialized
DEBUG - 2017-01-17 23:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:52:20 --> Input Class Initialized
INFO - 2017-01-17 23:52:20 --> Language Class Initialized
INFO - 2017-01-17 23:52:20 --> Loader Class Initialized
INFO - 2017-01-17 23:52:20 --> Database Driver Class Initialized
INFO - 2017-01-17 23:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:52:20 --> Controller Class Initialized
INFO - 2017-01-17 23:52:20 --> Upload Class Initialized
INFO - 2017-01-17 23:52:20 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:52:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:52:20 --> Helper loaded: form_helper
INFO - 2017-01-17 23:52:20 --> Form Validation Class Initialized
INFO - 2017-01-17 23:52:20 --> Final output sent to browser
DEBUG - 2017-01-17 23:52:20 --> Total execution time: 0.0561
INFO - 2017-01-17 23:52:37 --> Config Class Initialized
INFO - 2017-01-17 23:52:37 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:52:37 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:52:37 --> Utf8 Class Initialized
INFO - 2017-01-17 23:52:37 --> URI Class Initialized
INFO - 2017-01-17 23:52:37 --> Router Class Initialized
INFO - 2017-01-17 23:52:37 --> Output Class Initialized
INFO - 2017-01-17 23:52:37 --> Security Class Initialized
DEBUG - 2017-01-17 23:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:52:37 --> Input Class Initialized
INFO - 2017-01-17 23:52:37 --> Language Class Initialized
INFO - 2017-01-17 23:52:37 --> Loader Class Initialized
INFO - 2017-01-17 23:52:37 --> Database Driver Class Initialized
INFO - 2017-01-17 23:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:52:37 --> Controller Class Initialized
INFO - 2017-01-17 23:52:37 --> Upload Class Initialized
INFO - 2017-01-17 23:52:37 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:52:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:52:37 --> Helper loaded: form_helper
INFO - 2017-01-17 23:52:37 --> Form Validation Class Initialized
INFO - 2017-01-17 23:52:37 --> Final output sent to browser
DEBUG - 2017-01-17 23:52:37 --> Total execution time: 0.0160
INFO - 2017-01-17 23:52:37 --> Config Class Initialized
INFO - 2017-01-17 23:52:37 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:52:37 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:52:37 --> Utf8 Class Initialized
INFO - 2017-01-17 23:52:37 --> URI Class Initialized
INFO - 2017-01-17 23:52:37 --> Router Class Initialized
INFO - 2017-01-17 23:52:37 --> Output Class Initialized
INFO - 2017-01-17 23:52:37 --> Security Class Initialized
DEBUG - 2017-01-17 23:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:52:37 --> Input Class Initialized
INFO - 2017-01-17 23:52:37 --> Language Class Initialized
INFO - 2017-01-17 23:52:37 --> Loader Class Initialized
INFO - 2017-01-17 23:52:37 --> Database Driver Class Initialized
INFO - 2017-01-17 23:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:52:37 --> Controller Class Initialized
INFO - 2017-01-17 23:52:37 --> Upload Class Initialized
INFO - 2017-01-17 23:52:37 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:52:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:52:37 --> Helper loaded: form_helper
INFO - 2017-01-17 23:52:37 --> Form Validation Class Initialized
INFO - 2017-01-17 23:52:37 --> Final output sent to browser
DEBUG - 2017-01-17 23:52:37 --> Total execution time: 0.0149
INFO - 2017-01-17 23:52:37 --> Config Class Initialized
INFO - 2017-01-17 23:52:37 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:52:37 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:52:37 --> Utf8 Class Initialized
INFO - 2017-01-17 23:52:37 --> URI Class Initialized
INFO - 2017-01-17 23:52:37 --> Router Class Initialized
INFO - 2017-01-17 23:52:37 --> Output Class Initialized
INFO - 2017-01-17 23:52:37 --> Security Class Initialized
DEBUG - 2017-01-17 23:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:52:37 --> Input Class Initialized
INFO - 2017-01-17 23:52:37 --> Language Class Initialized
INFO - 2017-01-17 23:52:37 --> Loader Class Initialized
INFO - 2017-01-17 23:52:37 --> Database Driver Class Initialized
INFO - 2017-01-17 23:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:52:37 --> Controller Class Initialized
INFO - 2017-01-17 23:52:37 --> Upload Class Initialized
INFO - 2017-01-17 23:52:37 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:52:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:52:37 --> Helper loaded: form_helper
INFO - 2017-01-17 23:52:37 --> Form Validation Class Initialized
INFO - 2017-01-17 23:52:37 --> Final output sent to browser
DEBUG - 2017-01-17 23:52:37 --> Total execution time: 0.0144
INFO - 2017-01-17 23:52:37 --> Config Class Initialized
INFO - 2017-01-17 23:52:37 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:52:37 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:52:37 --> Utf8 Class Initialized
INFO - 2017-01-17 23:52:37 --> URI Class Initialized
INFO - 2017-01-17 23:52:37 --> Router Class Initialized
INFO - 2017-01-17 23:52:37 --> Output Class Initialized
INFO - 2017-01-17 23:52:37 --> Security Class Initialized
DEBUG - 2017-01-17 23:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:52:37 --> Input Class Initialized
INFO - 2017-01-17 23:52:37 --> Language Class Initialized
INFO - 2017-01-17 23:52:37 --> Loader Class Initialized
INFO - 2017-01-17 23:52:37 --> Database Driver Class Initialized
INFO - 2017-01-17 23:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:52:37 --> Controller Class Initialized
INFO - 2017-01-17 23:52:37 --> Upload Class Initialized
INFO - 2017-01-17 23:52:37 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:52:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:52:37 --> Helper loaded: form_helper
INFO - 2017-01-17 23:52:37 --> Form Validation Class Initialized
INFO - 2017-01-17 23:52:37 --> Final output sent to browser
DEBUG - 2017-01-17 23:52:37 --> Total execution time: 0.0209
INFO - 2017-01-17 23:52:57 --> Config Class Initialized
INFO - 2017-01-17 23:52:57 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:52:57 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:52:57 --> Utf8 Class Initialized
INFO - 2017-01-17 23:52:57 --> URI Class Initialized
INFO - 2017-01-17 23:52:57 --> Router Class Initialized
INFO - 2017-01-17 23:52:57 --> Output Class Initialized
INFO - 2017-01-17 23:52:57 --> Security Class Initialized
DEBUG - 2017-01-17 23:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:52:57 --> Input Class Initialized
INFO - 2017-01-17 23:52:57 --> Language Class Initialized
INFO - 2017-01-17 23:52:57 --> Loader Class Initialized
INFO - 2017-01-17 23:52:57 --> Database Driver Class Initialized
INFO - 2017-01-17 23:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:52:57 --> Controller Class Initialized
INFO - 2017-01-17 23:52:57 --> Helper loaded: date_helper
DEBUG - 2017-01-17 23:52:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:52:57 --> Helper loaded: url_helper
INFO - 2017-01-17 23:52:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 23:52:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-17 23:52:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-17 23:52:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-17 23:52:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 23:52:57 --> Final output sent to browser
DEBUG - 2017-01-17 23:52:57 --> Total execution time: 0.0155
INFO - 2017-01-17 23:54:04 --> Config Class Initialized
INFO - 2017-01-17 23:54:04 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:54:04 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:54:04 --> Utf8 Class Initialized
INFO - 2017-01-17 23:54:04 --> URI Class Initialized
INFO - 2017-01-17 23:54:04 --> Router Class Initialized
INFO - 2017-01-17 23:54:04 --> Output Class Initialized
INFO - 2017-01-17 23:54:04 --> Security Class Initialized
DEBUG - 2017-01-17 23:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:54:04 --> Input Class Initialized
INFO - 2017-01-17 23:54:04 --> Language Class Initialized
INFO - 2017-01-17 23:54:04 --> Loader Class Initialized
INFO - 2017-01-17 23:54:04 --> Database Driver Class Initialized
INFO - 2017-01-17 23:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:54:04 --> Controller Class Initialized
INFO - 2017-01-17 23:54:04 --> Upload Class Initialized
INFO - 2017-01-17 23:54:04 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:54:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:54:04 --> Helper loaded: form_helper
INFO - 2017-01-17 23:54:04 --> Form Validation Class Initialized
INFO - 2017-01-17 23:54:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-17 23:54:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-17 23:54:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-17 23:54:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-17 23:54:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-17 23:54:04 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-17 23:54:04 --> Final output sent to browser
DEBUG - 2017-01-17 23:54:04 --> Total execution time: 0.0163
INFO - 2017-01-17 23:54:05 --> Config Class Initialized
INFO - 2017-01-17 23:54:05 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:54:05 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:54:05 --> Utf8 Class Initialized
INFO - 2017-01-17 23:54:05 --> URI Class Initialized
INFO - 2017-01-17 23:54:05 --> Router Class Initialized
INFO - 2017-01-17 23:54:05 --> Output Class Initialized
INFO - 2017-01-17 23:54:05 --> Security Class Initialized
DEBUG - 2017-01-17 23:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:54:05 --> Input Class Initialized
INFO - 2017-01-17 23:54:05 --> Language Class Initialized
INFO - 2017-01-17 23:54:05 --> Loader Class Initialized
INFO - 2017-01-17 23:54:05 --> Database Driver Class Initialized
INFO - 2017-01-17 23:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:54:05 --> Controller Class Initialized
INFO - 2017-01-17 23:54:05 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:54:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:54:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 23:54:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 23:54:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 23:54:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 23:54:05 --> Final output sent to browser
DEBUG - 2017-01-17 23:54:05 --> Total execution time: 0.0135
INFO - 2017-01-17 23:54:08 --> Config Class Initialized
INFO - 2017-01-17 23:54:08 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:54:08 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:54:08 --> Utf8 Class Initialized
INFO - 2017-01-17 23:54:08 --> URI Class Initialized
INFO - 2017-01-17 23:54:08 --> Router Class Initialized
INFO - 2017-01-17 23:54:08 --> Output Class Initialized
INFO - 2017-01-17 23:54:08 --> Security Class Initialized
DEBUG - 2017-01-17 23:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:54:08 --> Input Class Initialized
INFO - 2017-01-17 23:54:08 --> Language Class Initialized
INFO - 2017-01-17 23:54:08 --> Loader Class Initialized
INFO - 2017-01-17 23:54:08 --> Database Driver Class Initialized
INFO - 2017-01-17 23:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:54:08 --> Controller Class Initialized
INFO - 2017-01-17 23:54:08 --> Upload Class Initialized
INFO - 2017-01-17 23:54:08 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:54:08 --> Helper loaded: form_helper
INFO - 2017-01-17 23:54:08 --> Form Validation Class Initialized
INFO - 2017-01-17 23:54:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-17 23:54:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-17 23:54:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/catalogo.php
INFO - 2017-01-17 23:54:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/catalogo.php
INFO - 2017-01-17 23:54:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-17 23:54:08 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-17 23:54:08 --> Final output sent to browser
DEBUG - 2017-01-17 23:54:08 --> Total execution time: 0.0708
INFO - 2017-01-17 23:54:08 --> Config Class Initialized
INFO - 2017-01-17 23:54:08 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:54:08 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:54:08 --> Utf8 Class Initialized
INFO - 2017-01-17 23:54:08 --> URI Class Initialized
INFO - 2017-01-17 23:54:08 --> Router Class Initialized
INFO - 2017-01-17 23:54:08 --> Output Class Initialized
INFO - 2017-01-17 23:54:08 --> Security Class Initialized
DEBUG - 2017-01-17 23:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:54:08 --> Input Class Initialized
INFO - 2017-01-17 23:54:08 --> Language Class Initialized
INFO - 2017-01-17 23:54:08 --> Loader Class Initialized
INFO - 2017-01-17 23:54:08 --> Database Driver Class Initialized
INFO - 2017-01-17 23:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:54:08 --> Controller Class Initialized
INFO - 2017-01-17 23:54:08 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 23:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-17 23:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-17 23:54:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 23:54:08 --> Final output sent to browser
DEBUG - 2017-01-17 23:54:08 --> Total execution time: 0.0133
INFO - 2017-01-17 23:55:33 --> Config Class Initialized
INFO - 2017-01-17 23:55:33 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:55:33 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:55:33 --> Utf8 Class Initialized
INFO - 2017-01-17 23:55:33 --> URI Class Initialized
INFO - 2017-01-17 23:55:33 --> Router Class Initialized
INFO - 2017-01-17 23:55:33 --> Output Class Initialized
INFO - 2017-01-17 23:55:33 --> Security Class Initialized
DEBUG - 2017-01-17 23:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:55:33 --> Input Class Initialized
INFO - 2017-01-17 23:55:33 --> Language Class Initialized
INFO - 2017-01-17 23:55:33 --> Loader Class Initialized
INFO - 2017-01-17 23:55:33 --> Database Driver Class Initialized
INFO - 2017-01-17 23:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:55:33 --> Controller Class Initialized
INFO - 2017-01-17 23:55:33 --> Upload Class Initialized
INFO - 2017-01-17 23:55:33 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:55:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:55:33 --> Helper loaded: form_helper
INFO - 2017-01-17 23:55:33 --> Form Validation Class Initialized
INFO - 2017-01-17 23:55:33 --> Final output sent to browser
DEBUG - 2017-01-17 23:55:33 --> Total execution time: 0.0149
INFO - 2017-01-17 23:55:33 --> Config Class Initialized
INFO - 2017-01-17 23:55:33 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:55:33 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:55:33 --> Utf8 Class Initialized
INFO - 2017-01-17 23:55:33 --> URI Class Initialized
INFO - 2017-01-17 23:55:33 --> Router Class Initialized
INFO - 2017-01-17 23:55:33 --> Output Class Initialized
INFO - 2017-01-17 23:55:33 --> Security Class Initialized
DEBUG - 2017-01-17 23:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:55:33 --> Input Class Initialized
INFO - 2017-01-17 23:55:33 --> Language Class Initialized
INFO - 2017-01-17 23:55:33 --> Loader Class Initialized
INFO - 2017-01-17 23:55:33 --> Database Driver Class Initialized
INFO - 2017-01-17 23:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:55:33 --> Controller Class Initialized
INFO - 2017-01-17 23:55:33 --> Upload Class Initialized
INFO - 2017-01-17 23:55:33 --> Helper loaded: url_helper
DEBUG - 2017-01-17 23:55:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:55:33 --> Helper loaded: form_helper
INFO - 2017-01-17 23:55:33 --> Form Validation Class Initialized
INFO - 2017-01-17 23:55:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-17 23:55:33 --> Final output sent to browser
DEBUG - 2017-01-17 23:55:33 --> Total execution time: 0.0224
INFO - 2017-01-17 23:55:43 --> Config Class Initialized
INFO - 2017-01-17 23:55:43 --> Hooks Class Initialized
DEBUG - 2017-01-17 23:55:43 --> UTF-8 Support Enabled
INFO - 2017-01-17 23:55:43 --> Utf8 Class Initialized
INFO - 2017-01-17 23:55:43 --> URI Class Initialized
INFO - 2017-01-17 23:55:43 --> Router Class Initialized
INFO - 2017-01-17 23:55:43 --> Output Class Initialized
INFO - 2017-01-17 23:55:43 --> Security Class Initialized
DEBUG - 2017-01-17 23:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-17 23:55:43 --> Input Class Initialized
INFO - 2017-01-17 23:55:43 --> Language Class Initialized
INFO - 2017-01-17 23:55:43 --> Loader Class Initialized
INFO - 2017-01-17 23:55:43 --> Database Driver Class Initialized
INFO - 2017-01-17 23:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-17 23:55:43 --> Controller Class Initialized
INFO - 2017-01-17 23:55:43 --> Helper loaded: date_helper
DEBUG - 2017-01-17 23:55:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-17 23:55:43 --> Helper loaded: url_helper
INFO - 2017-01-17 23:55:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-17 23:55:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-17 23:55:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-17 23:55:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-17 23:55:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-17 23:55:43 --> Final output sent to browser
DEBUG - 2017-01-17 23:55:43 --> Total execution time: 0.0148

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-31 00:24:07 --> Config Class Initialized
INFO - 2017-01-31 00:24:08 --> Hooks Class Initialized
DEBUG - 2017-01-31 00:24:08 --> UTF-8 Support Enabled
INFO - 2017-01-31 00:24:08 --> Utf8 Class Initialized
INFO - 2017-01-31 00:24:08 --> URI Class Initialized
INFO - 2017-01-31 00:24:08 --> Router Class Initialized
INFO - 2017-01-31 00:24:08 --> Output Class Initialized
INFO - 2017-01-31 00:24:08 --> Security Class Initialized
DEBUG - 2017-01-31 00:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 00:24:08 --> Input Class Initialized
INFO - 2017-01-31 00:24:08 --> Language Class Initialized
INFO - 2017-01-31 00:24:08 --> Loader Class Initialized
INFO - 2017-01-31 00:24:08 --> Database Driver Class Initialized
INFO - 2017-01-31 00:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 00:24:09 --> Controller Class Initialized
INFO - 2017-01-31 00:24:09 --> Helper loaded: url_helper
DEBUG - 2017-01-31 00:24:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 00:24:09 --> Helper loaded: form_helper
INFO - 2017-01-31 00:24:09 --> Form Validation Class Initialized
INFO - 2017-01-31 00:24:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-31 00:24:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-31 00:24:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-31 00:24:09 --> Final output sent to browser
DEBUG - 2017-01-31 00:24:09 --> Total execution time: 2.1999
INFO - 2017-01-31 00:24:09 --> Config Class Initialized
INFO - 2017-01-31 00:24:09 --> Hooks Class Initialized
DEBUG - 2017-01-31 00:24:09 --> UTF-8 Support Enabled
INFO - 2017-01-31 00:24:09 --> Utf8 Class Initialized
INFO - 2017-01-31 00:24:09 --> URI Class Initialized
INFO - 2017-01-31 00:24:09 --> Router Class Initialized
INFO - 2017-01-31 00:24:09 --> Output Class Initialized
INFO - 2017-01-31 00:24:09 --> Security Class Initialized
DEBUG - 2017-01-31 00:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 00:24:09 --> Input Class Initialized
INFO - 2017-01-31 00:24:09 --> Language Class Initialized
INFO - 2017-01-31 00:24:09 --> Loader Class Initialized
INFO - 2017-01-31 00:24:09 --> Database Driver Class Initialized
INFO - 2017-01-31 00:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 00:24:09 --> Controller Class Initialized
INFO - 2017-01-31 00:24:09 --> Helper loaded: url_helper
DEBUG - 2017-01-31 00:24:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 00:24:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 00:24:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 00:24:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 00:24:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 00:24:10 --> Final output sent to browser
DEBUG - 2017-01-31 00:24:10 --> Total execution time: 0.2847
INFO - 2017-01-31 01:05:06 --> Config Class Initialized
INFO - 2017-01-31 01:05:06 --> Hooks Class Initialized
DEBUG - 2017-01-31 01:05:06 --> UTF-8 Support Enabled
INFO - 2017-01-31 01:05:06 --> Utf8 Class Initialized
INFO - 2017-01-31 01:05:06 --> URI Class Initialized
DEBUG - 2017-01-31 01:05:06 --> No URI present. Default controller set.
INFO - 2017-01-31 01:05:06 --> Router Class Initialized
INFO - 2017-01-31 01:05:06 --> Output Class Initialized
INFO - 2017-01-31 01:05:06 --> Security Class Initialized
DEBUG - 2017-01-31 01:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 01:05:06 --> Input Class Initialized
INFO - 2017-01-31 01:05:06 --> Language Class Initialized
INFO - 2017-01-31 01:05:06 --> Loader Class Initialized
INFO - 2017-01-31 01:05:06 --> Database Driver Class Initialized
INFO - 2017-01-31 01:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 01:05:06 --> Controller Class Initialized
INFO - 2017-01-31 01:05:06 --> Helper loaded: url_helper
DEBUG - 2017-01-31 01:05:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 01:05:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 01:05:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 01:05:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 01:05:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 01:05:06 --> Final output sent to browser
DEBUG - 2017-01-31 01:05:06 --> Total execution time: 0.0258
INFO - 2017-01-31 01:05:36 --> Config Class Initialized
INFO - 2017-01-31 01:05:36 --> Hooks Class Initialized
DEBUG - 2017-01-31 01:05:36 --> UTF-8 Support Enabled
INFO - 2017-01-31 01:05:36 --> Utf8 Class Initialized
INFO - 2017-01-31 01:05:36 --> URI Class Initialized
INFO - 2017-01-31 01:05:36 --> Router Class Initialized
INFO - 2017-01-31 01:05:36 --> Output Class Initialized
INFO - 2017-01-31 01:05:36 --> Security Class Initialized
DEBUG - 2017-01-31 01:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 01:05:36 --> Input Class Initialized
INFO - 2017-01-31 01:05:36 --> Language Class Initialized
INFO - 2017-01-31 01:05:36 --> Loader Class Initialized
INFO - 2017-01-31 01:05:36 --> Database Driver Class Initialized
INFO - 2017-01-31 01:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 01:05:36 --> Controller Class Initialized
INFO - 2017-01-31 01:05:36 --> Helper loaded: url_helper
DEBUG - 2017-01-31 01:05:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 01:05:36 --> Config Class Initialized
INFO - 2017-01-31 01:05:36 --> Hooks Class Initialized
DEBUG - 2017-01-31 01:05:36 --> UTF-8 Support Enabled
INFO - 2017-01-31 01:05:36 --> Utf8 Class Initialized
INFO - 2017-01-31 01:05:36 --> URI Class Initialized
INFO - 2017-01-31 01:05:36 --> Router Class Initialized
INFO - 2017-01-31 01:05:36 --> Output Class Initialized
INFO - 2017-01-31 01:05:36 --> Security Class Initialized
DEBUG - 2017-01-31 01:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 01:05:36 --> Input Class Initialized
INFO - 2017-01-31 01:05:36 --> Language Class Initialized
INFO - 2017-01-31 01:05:36 --> Loader Class Initialized
INFO - 2017-01-31 01:05:36 --> Database Driver Class Initialized
INFO - 2017-01-31 01:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 01:05:36 --> Controller Class Initialized
INFO - 2017-01-31 01:05:36 --> Helper loaded: date_helper
DEBUG - 2017-01-31 01:05:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 01:05:36 --> Helper loaded: url_helper
INFO - 2017-01-31 01:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 01:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-31 01:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-31 01:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 01:05:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 01:05:36 --> Final output sent to browser
DEBUG - 2017-01-31 01:05:36 --> Total execution time: 0.1867
INFO - 2017-01-31 01:07:23 --> Config Class Initialized
INFO - 2017-01-31 01:07:23 --> Hooks Class Initialized
DEBUG - 2017-01-31 01:07:23 --> UTF-8 Support Enabled
INFO - 2017-01-31 01:07:23 --> Utf8 Class Initialized
INFO - 2017-01-31 01:07:23 --> URI Class Initialized
INFO - 2017-01-31 01:07:23 --> Router Class Initialized
INFO - 2017-01-31 01:07:23 --> Output Class Initialized
INFO - 2017-01-31 01:07:23 --> Security Class Initialized
DEBUG - 2017-01-31 01:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 01:07:23 --> Input Class Initialized
INFO - 2017-01-31 01:07:23 --> Language Class Initialized
INFO - 2017-01-31 01:07:23 --> Loader Class Initialized
INFO - 2017-01-31 01:07:23 --> Database Driver Class Initialized
INFO - 2017-01-31 01:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 01:07:23 --> Controller Class Initialized
INFO - 2017-01-31 01:07:23 --> Helper loaded: url_helper
DEBUG - 2017-01-31 01:07:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 01:07:23 --> Helper loaded: form_helper
INFO - 2017-01-31 01:07:23 --> Form Validation Class Initialized
INFO - 2017-01-31 01:07:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-31 01:07:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-31 01:07:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-31 01:07:23 --> Final output sent to browser
DEBUG - 2017-01-31 01:07:23 --> Total execution time: 0.0134
INFO - 2017-01-31 01:07:23 --> Config Class Initialized
INFO - 2017-01-31 01:07:23 --> Hooks Class Initialized
DEBUG - 2017-01-31 01:07:23 --> UTF-8 Support Enabled
INFO - 2017-01-31 01:07:23 --> Utf8 Class Initialized
INFO - 2017-01-31 01:07:23 --> URI Class Initialized
INFO - 2017-01-31 01:07:23 --> Router Class Initialized
INFO - 2017-01-31 01:07:23 --> Output Class Initialized
INFO - 2017-01-31 01:07:23 --> Security Class Initialized
DEBUG - 2017-01-31 01:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 01:07:23 --> Input Class Initialized
INFO - 2017-01-31 01:07:23 --> Language Class Initialized
INFO - 2017-01-31 01:07:23 --> Loader Class Initialized
INFO - 2017-01-31 01:07:23 --> Database Driver Class Initialized
INFO - 2017-01-31 01:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 01:07:23 --> Controller Class Initialized
INFO - 2017-01-31 01:07:23 --> Helper loaded: url_helper
DEBUG - 2017-01-31 01:07:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 01:07:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 01:07:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 01:07:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 01:07:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 01:07:23 --> Final output sent to browser
DEBUG - 2017-01-31 01:07:23 --> Total execution time: 0.0135
INFO - 2017-01-31 01:34:01 --> Config Class Initialized
INFO - 2017-01-31 01:34:01 --> Hooks Class Initialized
DEBUG - 2017-01-31 01:34:01 --> UTF-8 Support Enabled
INFO - 2017-01-31 01:34:01 --> Utf8 Class Initialized
INFO - 2017-01-31 01:34:01 --> URI Class Initialized
DEBUG - 2017-01-31 01:34:01 --> No URI present. Default controller set.
INFO - 2017-01-31 01:34:01 --> Router Class Initialized
INFO - 2017-01-31 01:34:01 --> Output Class Initialized
INFO - 2017-01-31 01:34:01 --> Security Class Initialized
DEBUG - 2017-01-31 01:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 01:34:01 --> Input Class Initialized
INFO - 2017-01-31 01:34:01 --> Language Class Initialized
INFO - 2017-01-31 01:34:01 --> Loader Class Initialized
INFO - 2017-01-31 01:34:01 --> Database Driver Class Initialized
INFO - 2017-01-31 01:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 01:34:01 --> Controller Class Initialized
INFO - 2017-01-31 01:34:01 --> Helper loaded: url_helper
DEBUG - 2017-01-31 01:34:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 01:34:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 01:34:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 01:34:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 01:34:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 01:34:01 --> Final output sent to browser
DEBUG - 2017-01-31 01:34:01 --> Total execution time: 0.0799
INFO - 2017-01-31 01:34:06 --> Config Class Initialized
INFO - 2017-01-31 01:34:06 --> Hooks Class Initialized
DEBUG - 2017-01-31 01:34:06 --> UTF-8 Support Enabled
INFO - 2017-01-31 01:34:06 --> Utf8 Class Initialized
INFO - 2017-01-31 01:34:06 --> URI Class Initialized
INFO - 2017-01-31 01:34:06 --> Router Class Initialized
INFO - 2017-01-31 01:34:06 --> Output Class Initialized
INFO - 2017-01-31 01:34:06 --> Security Class Initialized
DEBUG - 2017-01-31 01:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 01:34:06 --> Input Class Initialized
INFO - 2017-01-31 01:34:06 --> Language Class Initialized
INFO - 2017-01-31 01:34:06 --> Loader Class Initialized
INFO - 2017-01-31 01:34:06 --> Database Driver Class Initialized
INFO - 2017-01-31 01:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 01:34:06 --> Controller Class Initialized
INFO - 2017-01-31 01:34:06 --> Helper loaded: url_helper
DEBUG - 2017-01-31 01:34:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 01:34:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 01:34:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 01:34:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 01:34:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 01:34:06 --> Final output sent to browser
DEBUG - 2017-01-31 01:34:06 --> Total execution time: 0.0196
INFO - 2017-01-31 01:35:38 --> Config Class Initialized
INFO - 2017-01-31 01:35:38 --> Hooks Class Initialized
DEBUG - 2017-01-31 01:35:38 --> UTF-8 Support Enabled
INFO - 2017-01-31 01:35:38 --> Utf8 Class Initialized
INFO - 2017-01-31 01:35:38 --> URI Class Initialized
INFO - 2017-01-31 01:35:38 --> Router Class Initialized
INFO - 2017-01-31 01:35:38 --> Output Class Initialized
INFO - 2017-01-31 01:35:38 --> Security Class Initialized
DEBUG - 2017-01-31 01:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 01:35:38 --> Input Class Initialized
INFO - 2017-01-31 01:35:38 --> Language Class Initialized
INFO - 2017-01-31 01:35:38 --> Loader Class Initialized
INFO - 2017-01-31 01:35:38 --> Database Driver Class Initialized
INFO - 2017-01-31 01:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 01:35:38 --> Controller Class Initialized
INFO - 2017-01-31 01:35:38 --> Helper loaded: url_helper
DEBUG - 2017-01-31 01:35:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 01:35:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 01:35:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 01:35:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 01:35:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 01:35:38 --> Final output sent to browser
DEBUG - 2017-01-31 01:35:38 --> Total execution time: 0.0228
INFO - 2017-01-31 01:35:41 --> Config Class Initialized
INFO - 2017-01-31 01:35:41 --> Hooks Class Initialized
DEBUG - 2017-01-31 01:35:41 --> UTF-8 Support Enabled
INFO - 2017-01-31 01:35:41 --> Utf8 Class Initialized
INFO - 2017-01-31 01:35:41 --> URI Class Initialized
INFO - 2017-01-31 01:35:41 --> Router Class Initialized
INFO - 2017-01-31 01:35:41 --> Output Class Initialized
INFO - 2017-01-31 01:35:41 --> Security Class Initialized
DEBUG - 2017-01-31 01:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 01:35:41 --> Input Class Initialized
INFO - 2017-01-31 01:35:41 --> Language Class Initialized
INFO - 2017-01-31 01:35:41 --> Loader Class Initialized
INFO - 2017-01-31 01:35:41 --> Database Driver Class Initialized
INFO - 2017-01-31 01:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 01:35:41 --> Controller Class Initialized
INFO - 2017-01-31 01:35:41 --> Helper loaded: url_helper
DEBUG - 2017-01-31 01:35:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 01:35:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 01:35:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 01:35:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 01:35:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 01:35:41 --> Final output sent to browser
DEBUG - 2017-01-31 01:35:41 --> Total execution time: 0.0145
INFO - 2017-01-31 01:36:04 --> Config Class Initialized
INFO - 2017-01-31 01:36:04 --> Hooks Class Initialized
DEBUG - 2017-01-31 01:36:04 --> UTF-8 Support Enabled
INFO - 2017-01-31 01:36:04 --> Utf8 Class Initialized
INFO - 2017-01-31 01:36:04 --> URI Class Initialized
INFO - 2017-01-31 01:36:04 --> Router Class Initialized
INFO - 2017-01-31 01:36:04 --> Output Class Initialized
INFO - 2017-01-31 01:36:04 --> Security Class Initialized
DEBUG - 2017-01-31 01:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 01:36:04 --> Input Class Initialized
INFO - 2017-01-31 01:36:04 --> Language Class Initialized
INFO - 2017-01-31 01:36:04 --> Loader Class Initialized
INFO - 2017-01-31 01:36:04 --> Database Driver Class Initialized
INFO - 2017-01-31 01:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 01:36:04 --> Controller Class Initialized
INFO - 2017-01-31 01:36:04 --> Helper loaded: url_helper
DEBUG - 2017-01-31 01:36:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 01:36:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 01:36:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 01:36:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 01:36:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 01:36:04 --> Final output sent to browser
DEBUG - 2017-01-31 01:36:04 --> Total execution time: 0.0138
INFO - 2017-01-31 01:36:07 --> Config Class Initialized
INFO - 2017-01-31 01:36:07 --> Hooks Class Initialized
DEBUG - 2017-01-31 01:36:07 --> UTF-8 Support Enabled
INFO - 2017-01-31 01:36:07 --> Utf8 Class Initialized
INFO - 2017-01-31 01:36:07 --> URI Class Initialized
INFO - 2017-01-31 01:36:07 --> Router Class Initialized
INFO - 2017-01-31 01:36:07 --> Output Class Initialized
INFO - 2017-01-31 01:36:07 --> Security Class Initialized
DEBUG - 2017-01-31 01:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 01:36:07 --> Input Class Initialized
INFO - 2017-01-31 01:36:07 --> Language Class Initialized
INFO - 2017-01-31 01:36:07 --> Loader Class Initialized
INFO - 2017-01-31 01:36:07 --> Database Driver Class Initialized
INFO - 2017-01-31 01:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 01:36:07 --> Controller Class Initialized
INFO - 2017-01-31 01:36:07 --> Helper loaded: url_helper
DEBUG - 2017-01-31 01:36:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 01:36:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 01:36:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 01:36:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 01:36:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 01:36:07 --> Final output sent to browser
DEBUG - 2017-01-31 01:36:07 --> Total execution time: 0.0132
INFO - 2017-01-31 01:36:35 --> Config Class Initialized
INFO - 2017-01-31 01:36:35 --> Hooks Class Initialized
DEBUG - 2017-01-31 01:36:35 --> UTF-8 Support Enabled
INFO - 2017-01-31 01:36:35 --> Utf8 Class Initialized
INFO - 2017-01-31 01:36:35 --> URI Class Initialized
INFO - 2017-01-31 01:36:35 --> Router Class Initialized
INFO - 2017-01-31 01:36:35 --> Output Class Initialized
INFO - 2017-01-31 01:36:35 --> Security Class Initialized
DEBUG - 2017-01-31 01:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 01:36:35 --> Input Class Initialized
INFO - 2017-01-31 01:36:35 --> Language Class Initialized
INFO - 2017-01-31 01:36:35 --> Loader Class Initialized
INFO - 2017-01-31 01:36:35 --> Database Driver Class Initialized
INFO - 2017-01-31 01:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 01:36:35 --> Controller Class Initialized
INFO - 2017-01-31 01:36:35 --> Helper loaded: url_helper
DEBUG - 2017-01-31 01:36:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 01:36:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 01:36:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 01:36:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 01:36:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 01:36:35 --> Final output sent to browser
DEBUG - 2017-01-31 01:36:35 --> Total execution time: 0.0142
INFO - 2017-01-31 01:36:38 --> Config Class Initialized
INFO - 2017-01-31 01:36:38 --> Hooks Class Initialized
DEBUG - 2017-01-31 01:36:38 --> UTF-8 Support Enabled
INFO - 2017-01-31 01:36:38 --> Utf8 Class Initialized
INFO - 2017-01-31 01:36:38 --> URI Class Initialized
INFO - 2017-01-31 01:36:38 --> Router Class Initialized
INFO - 2017-01-31 01:36:38 --> Output Class Initialized
INFO - 2017-01-31 01:36:38 --> Security Class Initialized
DEBUG - 2017-01-31 01:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 01:36:38 --> Input Class Initialized
INFO - 2017-01-31 01:36:38 --> Language Class Initialized
INFO - 2017-01-31 01:36:38 --> Loader Class Initialized
INFO - 2017-01-31 01:36:38 --> Database Driver Class Initialized
INFO - 2017-01-31 01:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 01:36:38 --> Controller Class Initialized
INFO - 2017-01-31 01:36:38 --> Helper loaded: url_helper
DEBUG - 2017-01-31 01:36:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 01:36:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 01:36:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 01:36:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 01:36:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 01:36:38 --> Final output sent to browser
DEBUG - 2017-01-31 01:36:38 --> Total execution time: 0.0130
INFO - 2017-01-31 01:37:15 --> Config Class Initialized
INFO - 2017-01-31 01:37:15 --> Hooks Class Initialized
DEBUG - 2017-01-31 01:37:15 --> UTF-8 Support Enabled
INFO - 2017-01-31 01:37:15 --> Utf8 Class Initialized
INFO - 2017-01-31 01:37:15 --> URI Class Initialized
INFO - 2017-01-31 01:37:15 --> Router Class Initialized
INFO - 2017-01-31 01:37:15 --> Output Class Initialized
INFO - 2017-01-31 01:37:15 --> Security Class Initialized
DEBUG - 2017-01-31 01:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 01:37:15 --> Input Class Initialized
INFO - 2017-01-31 01:37:15 --> Language Class Initialized
INFO - 2017-01-31 01:37:15 --> Loader Class Initialized
INFO - 2017-01-31 01:37:15 --> Database Driver Class Initialized
INFO - 2017-01-31 01:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 01:37:15 --> Controller Class Initialized
INFO - 2017-01-31 01:37:15 --> Helper loaded: url_helper
DEBUG - 2017-01-31 01:37:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 01:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 01:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 01:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 01:37:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 01:37:15 --> Final output sent to browser
DEBUG - 2017-01-31 01:37:15 --> Total execution time: 0.0142
INFO - 2017-01-31 01:37:18 --> Config Class Initialized
INFO - 2017-01-31 01:37:18 --> Hooks Class Initialized
DEBUG - 2017-01-31 01:37:18 --> UTF-8 Support Enabled
INFO - 2017-01-31 01:37:18 --> Utf8 Class Initialized
INFO - 2017-01-31 01:37:18 --> URI Class Initialized
INFO - 2017-01-31 01:37:18 --> Router Class Initialized
INFO - 2017-01-31 01:37:18 --> Output Class Initialized
INFO - 2017-01-31 01:37:18 --> Security Class Initialized
DEBUG - 2017-01-31 01:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 01:37:18 --> Input Class Initialized
INFO - 2017-01-31 01:37:18 --> Language Class Initialized
INFO - 2017-01-31 01:37:18 --> Loader Class Initialized
INFO - 2017-01-31 01:37:18 --> Database Driver Class Initialized
INFO - 2017-01-31 01:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 01:37:18 --> Controller Class Initialized
INFO - 2017-01-31 01:37:18 --> Helper loaded: url_helper
DEBUG - 2017-01-31 01:37:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 01:37:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 01:37:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 01:37:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 01:37:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 01:37:18 --> Final output sent to browser
DEBUG - 2017-01-31 01:37:18 --> Total execution time: 0.0131
INFO - 2017-01-31 01:37:32 --> Config Class Initialized
INFO - 2017-01-31 01:37:32 --> Hooks Class Initialized
DEBUG - 2017-01-31 01:37:32 --> UTF-8 Support Enabled
INFO - 2017-01-31 01:37:32 --> Utf8 Class Initialized
INFO - 2017-01-31 01:37:32 --> URI Class Initialized
DEBUG - 2017-01-31 01:37:32 --> No URI present. Default controller set.
INFO - 2017-01-31 01:37:32 --> Router Class Initialized
INFO - 2017-01-31 01:37:32 --> Output Class Initialized
INFO - 2017-01-31 01:37:32 --> Security Class Initialized
DEBUG - 2017-01-31 01:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 01:37:32 --> Input Class Initialized
INFO - 2017-01-31 01:37:32 --> Language Class Initialized
INFO - 2017-01-31 01:37:32 --> Loader Class Initialized
INFO - 2017-01-31 01:37:32 --> Database Driver Class Initialized
INFO - 2017-01-31 01:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 01:37:32 --> Controller Class Initialized
INFO - 2017-01-31 01:37:32 --> Helper loaded: url_helper
DEBUG - 2017-01-31 01:37:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 01:37:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 01:37:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 01:37:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 01:37:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 01:37:32 --> Final output sent to browser
DEBUG - 2017-01-31 01:37:32 --> Total execution time: 0.0134
INFO - 2017-01-31 01:43:51 --> Config Class Initialized
INFO - 2017-01-31 01:43:51 --> Hooks Class Initialized
DEBUG - 2017-01-31 01:43:51 --> UTF-8 Support Enabled
INFO - 2017-01-31 01:43:51 --> Utf8 Class Initialized
INFO - 2017-01-31 01:43:51 --> URI Class Initialized
DEBUG - 2017-01-31 01:43:51 --> No URI present. Default controller set.
INFO - 2017-01-31 01:43:51 --> Router Class Initialized
INFO - 2017-01-31 01:43:51 --> Output Class Initialized
INFO - 2017-01-31 01:43:51 --> Security Class Initialized
DEBUG - 2017-01-31 01:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 01:43:51 --> Input Class Initialized
INFO - 2017-01-31 01:43:51 --> Language Class Initialized
INFO - 2017-01-31 01:43:51 --> Loader Class Initialized
INFO - 2017-01-31 01:43:51 --> Database Driver Class Initialized
INFO - 2017-01-31 01:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 01:43:51 --> Controller Class Initialized
INFO - 2017-01-31 01:43:51 --> Helper loaded: url_helper
DEBUG - 2017-01-31 01:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 01:43:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 01:43:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 01:43:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 01:43:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 01:43:51 --> Final output sent to browser
DEBUG - 2017-01-31 01:43:51 --> Total execution time: 0.0136
INFO - 2017-01-31 01:43:56 --> Config Class Initialized
INFO - 2017-01-31 01:43:56 --> Hooks Class Initialized
DEBUG - 2017-01-31 01:43:56 --> UTF-8 Support Enabled
INFO - 2017-01-31 01:43:56 --> Utf8 Class Initialized
INFO - 2017-01-31 01:43:56 --> URI Class Initialized
INFO - 2017-01-31 01:43:56 --> Router Class Initialized
INFO - 2017-01-31 01:43:56 --> Output Class Initialized
INFO - 2017-01-31 01:43:56 --> Security Class Initialized
DEBUG - 2017-01-31 01:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 01:43:56 --> Input Class Initialized
INFO - 2017-01-31 01:43:56 --> Language Class Initialized
INFO - 2017-01-31 01:43:56 --> Loader Class Initialized
INFO - 2017-01-31 01:43:56 --> Database Driver Class Initialized
INFO - 2017-01-31 01:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 01:43:56 --> Controller Class Initialized
INFO - 2017-01-31 01:43:56 --> Helper loaded: url_helper
DEBUG - 2017-01-31 01:43:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 01:43:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 01:43:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 01:43:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 01:43:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 01:43:56 --> Final output sent to browser
DEBUG - 2017-01-31 01:43:56 --> Total execution time: 0.0141
INFO - 2017-01-31 01:46:38 --> Config Class Initialized
INFO - 2017-01-31 01:46:38 --> Hooks Class Initialized
DEBUG - 2017-01-31 01:46:38 --> UTF-8 Support Enabled
INFO - 2017-01-31 01:46:38 --> Utf8 Class Initialized
INFO - 2017-01-31 01:46:38 --> URI Class Initialized
INFO - 2017-01-31 01:46:38 --> Router Class Initialized
INFO - 2017-01-31 01:46:38 --> Output Class Initialized
INFO - 2017-01-31 01:46:38 --> Security Class Initialized
DEBUG - 2017-01-31 01:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 01:46:38 --> Input Class Initialized
INFO - 2017-01-31 01:46:38 --> Language Class Initialized
INFO - 2017-01-31 01:46:38 --> Loader Class Initialized
INFO - 2017-01-31 01:46:38 --> Database Driver Class Initialized
INFO - 2017-01-31 01:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 01:46:38 --> Controller Class Initialized
INFO - 2017-01-31 01:46:38 --> Helper loaded: url_helper
DEBUG - 2017-01-31 01:46:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 01:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-31 01:46:38 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-31 01:46:38 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-31 01:46:38 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-31 01:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 01:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 01:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 01:46:38 --> Final output sent to browser
DEBUG - 2017-01-31 01:46:38 --> Total execution time: 0.0409
INFO - 2017-01-31 01:46:41 --> Config Class Initialized
INFO - 2017-01-31 01:46:41 --> Hooks Class Initialized
DEBUG - 2017-01-31 01:46:41 --> UTF-8 Support Enabled
INFO - 2017-01-31 01:46:41 --> Utf8 Class Initialized
INFO - 2017-01-31 01:46:41 --> URI Class Initialized
INFO - 2017-01-31 01:46:41 --> Router Class Initialized
INFO - 2017-01-31 01:46:41 --> Output Class Initialized
INFO - 2017-01-31 01:46:41 --> Security Class Initialized
DEBUG - 2017-01-31 01:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 01:46:41 --> Input Class Initialized
INFO - 2017-01-31 01:46:41 --> Language Class Initialized
INFO - 2017-01-31 01:46:41 --> Loader Class Initialized
INFO - 2017-01-31 01:46:41 --> Database Driver Class Initialized
INFO - 2017-01-31 01:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 01:46:41 --> Controller Class Initialized
INFO - 2017-01-31 01:46:41 --> Helper loaded: url_helper
DEBUG - 2017-01-31 01:46:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 01:46:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 01:46:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 01:46:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 01:46:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 01:46:41 --> Final output sent to browser
DEBUG - 2017-01-31 01:46:41 --> Total execution time: 0.0130
INFO - 2017-01-31 01:47:09 --> Config Class Initialized
INFO - 2017-01-31 01:47:09 --> Hooks Class Initialized
DEBUG - 2017-01-31 01:47:09 --> UTF-8 Support Enabled
INFO - 2017-01-31 01:47:09 --> Utf8 Class Initialized
INFO - 2017-01-31 01:47:09 --> URI Class Initialized
INFO - 2017-01-31 01:47:09 --> Router Class Initialized
INFO - 2017-01-31 01:47:09 --> Output Class Initialized
INFO - 2017-01-31 01:47:09 --> Security Class Initialized
DEBUG - 2017-01-31 01:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 01:47:09 --> Input Class Initialized
INFO - 2017-01-31 01:47:09 --> Language Class Initialized
INFO - 2017-01-31 01:47:09 --> Loader Class Initialized
INFO - 2017-01-31 01:47:09 --> Database Driver Class Initialized
INFO - 2017-01-31 01:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 01:47:09 --> Controller Class Initialized
INFO - 2017-01-31 01:47:09 --> Helper loaded: url_helper
DEBUG - 2017-01-31 01:47:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 01:47:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-31 01:47:09 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-31 01:47:09 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-31 01:47:09 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-31 01:47:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 01:47:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 01:47:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 01:47:09 --> Final output sent to browser
DEBUG - 2017-01-31 01:47:09 --> Total execution time: 0.0136
INFO - 2017-01-31 01:47:12 --> Config Class Initialized
INFO - 2017-01-31 01:47:12 --> Hooks Class Initialized
DEBUG - 2017-01-31 01:47:12 --> UTF-8 Support Enabled
INFO - 2017-01-31 01:47:12 --> Utf8 Class Initialized
INFO - 2017-01-31 01:47:12 --> URI Class Initialized
INFO - 2017-01-31 01:47:12 --> Router Class Initialized
INFO - 2017-01-31 01:47:12 --> Output Class Initialized
INFO - 2017-01-31 01:47:12 --> Security Class Initialized
DEBUG - 2017-01-31 01:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 01:47:12 --> Input Class Initialized
INFO - 2017-01-31 01:47:12 --> Language Class Initialized
INFO - 2017-01-31 01:47:12 --> Loader Class Initialized
INFO - 2017-01-31 01:47:12 --> Database Driver Class Initialized
INFO - 2017-01-31 01:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 01:47:12 --> Controller Class Initialized
INFO - 2017-01-31 01:47:12 --> Helper loaded: url_helper
DEBUG - 2017-01-31 01:47:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 01:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 01:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 01:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 01:47:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 01:47:12 --> Final output sent to browser
DEBUG - 2017-01-31 01:47:12 --> Total execution time: 0.0131
INFO - 2017-01-31 01:48:03 --> Config Class Initialized
INFO - 2017-01-31 01:48:03 --> Hooks Class Initialized
DEBUG - 2017-01-31 01:48:03 --> UTF-8 Support Enabled
INFO - 2017-01-31 01:48:03 --> Utf8 Class Initialized
INFO - 2017-01-31 01:48:03 --> URI Class Initialized
DEBUG - 2017-01-31 01:48:03 --> No URI present. Default controller set.
INFO - 2017-01-31 01:48:03 --> Router Class Initialized
INFO - 2017-01-31 01:48:03 --> Output Class Initialized
INFO - 2017-01-31 01:48:03 --> Security Class Initialized
DEBUG - 2017-01-31 01:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 01:48:03 --> Input Class Initialized
INFO - 2017-01-31 01:48:03 --> Language Class Initialized
INFO - 2017-01-31 01:48:03 --> Loader Class Initialized
INFO - 2017-01-31 01:48:03 --> Database Driver Class Initialized
INFO - 2017-01-31 01:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 01:48:03 --> Controller Class Initialized
INFO - 2017-01-31 01:48:03 --> Helper loaded: url_helper
DEBUG - 2017-01-31 01:48:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 01:48:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 01:48:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 01:48:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 01:48:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 01:48:03 --> Final output sent to browser
DEBUG - 2017-01-31 01:48:03 --> Total execution time: 0.0132
INFO - 2017-01-31 03:21:40 --> Config Class Initialized
INFO - 2017-01-31 03:21:40 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:21:40 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:21:40 --> Utf8 Class Initialized
INFO - 2017-01-31 03:21:40 --> URI Class Initialized
DEBUG - 2017-01-31 03:21:40 --> No URI present. Default controller set.
INFO - 2017-01-31 03:21:40 --> Router Class Initialized
INFO - 2017-01-31 03:21:40 --> Output Class Initialized
INFO - 2017-01-31 03:21:40 --> Security Class Initialized
DEBUG - 2017-01-31 03:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:21:40 --> Input Class Initialized
INFO - 2017-01-31 03:21:40 --> Language Class Initialized
INFO - 2017-01-31 03:21:40 --> Loader Class Initialized
INFO - 2017-01-31 03:21:40 --> Database Driver Class Initialized
INFO - 2017-01-31 03:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:21:40 --> Controller Class Initialized
INFO - 2017-01-31 03:21:40 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:21:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:21:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:21:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:21:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:21:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:21:40 --> Final output sent to browser
DEBUG - 2017-01-31 03:21:40 --> Total execution time: 0.0135
INFO - 2017-01-31 03:21:45 --> Config Class Initialized
INFO - 2017-01-31 03:21:45 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:21:45 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:21:45 --> Utf8 Class Initialized
INFO - 2017-01-31 03:21:45 --> URI Class Initialized
INFO - 2017-01-31 03:21:45 --> Router Class Initialized
INFO - 2017-01-31 03:21:45 --> Output Class Initialized
INFO - 2017-01-31 03:21:45 --> Security Class Initialized
DEBUG - 2017-01-31 03:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:21:45 --> Input Class Initialized
INFO - 2017-01-31 03:21:45 --> Language Class Initialized
INFO - 2017-01-31 03:21:45 --> Loader Class Initialized
INFO - 2017-01-31 03:21:45 --> Database Driver Class Initialized
INFO - 2017-01-31 03:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:21:45 --> Controller Class Initialized
INFO - 2017-01-31 03:21:45 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:21:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:21:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:21:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:21:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:21:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:21:45 --> Final output sent to browser
DEBUG - 2017-01-31 03:21:45 --> Total execution time: 0.0134
INFO - 2017-01-31 03:24:02 --> Config Class Initialized
INFO - 2017-01-31 03:24:02 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:24:02 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:24:02 --> Utf8 Class Initialized
INFO - 2017-01-31 03:24:02 --> URI Class Initialized
DEBUG - 2017-01-31 03:24:02 --> No URI present. Default controller set.
INFO - 2017-01-31 03:24:02 --> Router Class Initialized
INFO - 2017-01-31 03:24:02 --> Output Class Initialized
INFO - 2017-01-31 03:24:02 --> Security Class Initialized
DEBUG - 2017-01-31 03:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:24:02 --> Input Class Initialized
INFO - 2017-01-31 03:24:02 --> Language Class Initialized
INFO - 2017-01-31 03:24:02 --> Loader Class Initialized
INFO - 2017-01-31 03:24:02 --> Database Driver Class Initialized
INFO - 2017-01-31 03:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:24:02 --> Controller Class Initialized
INFO - 2017-01-31 03:24:02 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:24:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:24:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:24:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:24:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:24:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:24:02 --> Final output sent to browser
DEBUG - 2017-01-31 03:24:02 --> Total execution time: 0.0136
INFO - 2017-01-31 03:24:05 --> Config Class Initialized
INFO - 2017-01-31 03:24:05 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:24:05 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:24:05 --> Utf8 Class Initialized
INFO - 2017-01-31 03:24:05 --> URI Class Initialized
INFO - 2017-01-31 03:24:05 --> Router Class Initialized
INFO - 2017-01-31 03:24:05 --> Output Class Initialized
INFO - 2017-01-31 03:24:05 --> Security Class Initialized
DEBUG - 2017-01-31 03:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:24:05 --> Input Class Initialized
INFO - 2017-01-31 03:24:05 --> Language Class Initialized
INFO - 2017-01-31 03:24:05 --> Loader Class Initialized
INFO - 2017-01-31 03:24:05 --> Database Driver Class Initialized
INFO - 2017-01-31 03:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:24:05 --> Controller Class Initialized
INFO - 2017-01-31 03:24:05 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:24:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:24:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:24:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:24:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:24:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:24:05 --> Final output sent to browser
DEBUG - 2017-01-31 03:24:05 --> Total execution time: 0.0142
INFO - 2017-01-31 03:25:13 --> Config Class Initialized
INFO - 2017-01-31 03:25:13 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:25:13 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:25:13 --> Utf8 Class Initialized
INFO - 2017-01-31 03:25:13 --> URI Class Initialized
DEBUG - 2017-01-31 03:25:13 --> No URI present. Default controller set.
INFO - 2017-01-31 03:25:13 --> Router Class Initialized
INFO - 2017-01-31 03:25:13 --> Output Class Initialized
INFO - 2017-01-31 03:25:13 --> Security Class Initialized
DEBUG - 2017-01-31 03:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:25:13 --> Input Class Initialized
INFO - 2017-01-31 03:25:13 --> Language Class Initialized
INFO - 2017-01-31 03:25:13 --> Loader Class Initialized
INFO - 2017-01-31 03:25:13 --> Database Driver Class Initialized
INFO - 2017-01-31 03:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:25:13 --> Controller Class Initialized
INFO - 2017-01-31 03:25:13 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:25:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:25:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:25:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:25:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:25:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:25:13 --> Final output sent to browser
DEBUG - 2017-01-31 03:25:13 --> Total execution time: 0.0132
INFO - 2017-01-31 03:25:19 --> Config Class Initialized
INFO - 2017-01-31 03:25:19 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:25:19 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:25:19 --> Utf8 Class Initialized
INFO - 2017-01-31 03:25:19 --> URI Class Initialized
INFO - 2017-01-31 03:25:19 --> Router Class Initialized
INFO - 2017-01-31 03:25:19 --> Output Class Initialized
INFO - 2017-01-31 03:25:19 --> Security Class Initialized
DEBUG - 2017-01-31 03:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:25:19 --> Input Class Initialized
INFO - 2017-01-31 03:25:19 --> Language Class Initialized
INFO - 2017-01-31 03:25:19 --> Loader Class Initialized
INFO - 2017-01-31 03:25:19 --> Database Driver Class Initialized
INFO - 2017-01-31 03:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:25:19 --> Controller Class Initialized
INFO - 2017-01-31 03:25:19 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:25:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:25:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:25:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:25:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:25:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:25:19 --> Final output sent to browser
DEBUG - 2017-01-31 03:25:19 --> Total execution time: 0.0135
INFO - 2017-01-31 03:25:40 --> Config Class Initialized
INFO - 2017-01-31 03:25:40 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:25:40 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:25:40 --> Utf8 Class Initialized
INFO - 2017-01-31 03:25:40 --> URI Class Initialized
DEBUG - 2017-01-31 03:25:40 --> No URI present. Default controller set.
INFO - 2017-01-31 03:25:40 --> Router Class Initialized
INFO - 2017-01-31 03:25:40 --> Output Class Initialized
INFO - 2017-01-31 03:25:40 --> Security Class Initialized
DEBUG - 2017-01-31 03:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:25:40 --> Input Class Initialized
INFO - 2017-01-31 03:25:40 --> Language Class Initialized
INFO - 2017-01-31 03:25:40 --> Loader Class Initialized
INFO - 2017-01-31 03:25:40 --> Database Driver Class Initialized
INFO - 2017-01-31 03:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:25:40 --> Controller Class Initialized
INFO - 2017-01-31 03:25:40 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:25:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:25:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:25:40 --> Final output sent to browser
DEBUG - 2017-01-31 03:25:40 --> Total execution time: 0.0132
INFO - 2017-01-31 03:25:41 --> Config Class Initialized
INFO - 2017-01-31 03:25:41 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:25:41 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:25:41 --> Utf8 Class Initialized
INFO - 2017-01-31 03:25:41 --> URI Class Initialized
INFO - 2017-01-31 03:25:41 --> Router Class Initialized
INFO - 2017-01-31 03:25:41 --> Output Class Initialized
INFO - 2017-01-31 03:25:41 --> Security Class Initialized
DEBUG - 2017-01-31 03:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:25:41 --> Input Class Initialized
INFO - 2017-01-31 03:25:41 --> Language Class Initialized
INFO - 2017-01-31 03:25:41 --> Loader Class Initialized
INFO - 2017-01-31 03:25:41 --> Database Driver Class Initialized
INFO - 2017-01-31 03:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:25:41 --> Controller Class Initialized
INFO - 2017-01-31 03:25:41 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:25:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:25:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:25:41 --> Final output sent to browser
DEBUG - 2017-01-31 03:25:41 --> Total execution time: 0.0133
INFO - 2017-01-31 03:26:21 --> Config Class Initialized
INFO - 2017-01-31 03:26:21 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:26:21 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:26:21 --> Utf8 Class Initialized
INFO - 2017-01-31 03:26:21 --> URI Class Initialized
INFO - 2017-01-31 03:26:21 --> Router Class Initialized
INFO - 2017-01-31 03:26:21 --> Output Class Initialized
INFO - 2017-01-31 03:26:21 --> Security Class Initialized
DEBUG - 2017-01-31 03:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:26:21 --> Input Class Initialized
INFO - 2017-01-31 03:26:21 --> Language Class Initialized
INFO - 2017-01-31 03:26:21 --> Loader Class Initialized
INFO - 2017-01-31 03:26:21 --> Database Driver Class Initialized
INFO - 2017-01-31 03:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:26:21 --> Controller Class Initialized
INFO - 2017-01-31 03:26:21 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:26:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-31 03:26:21 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-31 03:26:21 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-31 03:26:21 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-31 03:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:26:21 --> Final output sent to browser
DEBUG - 2017-01-31 03:26:21 --> Total execution time: 0.0239
INFO - 2017-01-31 03:26:23 --> Config Class Initialized
INFO - 2017-01-31 03:26:23 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:26:23 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:26:23 --> Utf8 Class Initialized
INFO - 2017-01-31 03:26:23 --> URI Class Initialized
INFO - 2017-01-31 03:26:23 --> Router Class Initialized
INFO - 2017-01-31 03:26:23 --> Output Class Initialized
INFO - 2017-01-31 03:26:23 --> Security Class Initialized
DEBUG - 2017-01-31 03:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:26:23 --> Input Class Initialized
INFO - 2017-01-31 03:26:23 --> Language Class Initialized
INFO - 2017-01-31 03:26:23 --> Loader Class Initialized
INFO - 2017-01-31 03:26:23 --> Database Driver Class Initialized
INFO - 2017-01-31 03:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:26:23 --> Controller Class Initialized
INFO - 2017-01-31 03:26:23 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:26:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:26:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:26:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:26:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:26:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:26:23 --> Final output sent to browser
DEBUG - 2017-01-31 03:26:23 --> Total execution time: 0.0132
INFO - 2017-01-31 03:26:29 --> Config Class Initialized
INFO - 2017-01-31 03:26:29 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:26:29 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:26:29 --> Utf8 Class Initialized
INFO - 2017-01-31 03:26:29 --> URI Class Initialized
INFO - 2017-01-31 03:26:29 --> Router Class Initialized
INFO - 2017-01-31 03:26:29 --> Output Class Initialized
INFO - 2017-01-31 03:26:29 --> Security Class Initialized
DEBUG - 2017-01-31 03:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:26:29 --> Input Class Initialized
INFO - 2017-01-31 03:26:29 --> Language Class Initialized
INFO - 2017-01-31 03:26:29 --> Loader Class Initialized
INFO - 2017-01-31 03:26:29 --> Database Driver Class Initialized
INFO - 2017-01-31 03:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:26:29 --> Controller Class Initialized
INFO - 2017-01-31 03:26:29 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:26:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-31 03:26:31 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-31 03:26:31 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Violeta Saldaña')
INFO - 2017-01-31 03:26:31 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-31 03:26:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-31 03:26:31 --> Config Class Initialized
INFO - 2017-01-31 03:26:31 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:26:31 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:26:31 --> Utf8 Class Initialized
INFO - 2017-01-31 03:26:31 --> URI Class Initialized
INFO - 2017-01-31 03:26:31 --> Router Class Initialized
INFO - 2017-01-31 03:26:31 --> Output Class Initialized
INFO - 2017-01-31 03:26:31 --> Security Class Initialized
DEBUG - 2017-01-31 03:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:26:31 --> Input Class Initialized
INFO - 2017-01-31 03:26:31 --> Language Class Initialized
INFO - 2017-01-31 03:26:31 --> Loader Class Initialized
INFO - 2017-01-31 03:26:31 --> Database Driver Class Initialized
INFO - 2017-01-31 03:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:26:31 --> Controller Class Initialized
INFO - 2017-01-31 03:26:31 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:26:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:26:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:26:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:26:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:26:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:26:31 --> Final output sent to browser
DEBUG - 2017-01-31 03:26:31 --> Total execution time: 0.0204
INFO - 2017-01-31 03:26:39 --> Config Class Initialized
INFO - 2017-01-31 03:26:39 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:26:39 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:26:39 --> Utf8 Class Initialized
INFO - 2017-01-31 03:26:39 --> URI Class Initialized
DEBUG - 2017-01-31 03:26:39 --> No URI present. Default controller set.
INFO - 2017-01-31 03:26:39 --> Router Class Initialized
INFO - 2017-01-31 03:26:39 --> Output Class Initialized
INFO - 2017-01-31 03:26:39 --> Security Class Initialized
DEBUG - 2017-01-31 03:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:26:39 --> Input Class Initialized
INFO - 2017-01-31 03:26:39 --> Language Class Initialized
INFO - 2017-01-31 03:26:39 --> Loader Class Initialized
INFO - 2017-01-31 03:26:39 --> Database Driver Class Initialized
INFO - 2017-01-31 03:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:26:39 --> Controller Class Initialized
INFO - 2017-01-31 03:26:39 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:26:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:26:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:26:39 --> Final output sent to browser
DEBUG - 2017-01-31 03:26:39 --> Total execution time: 0.0139
INFO - 2017-01-31 03:26:45 --> Config Class Initialized
INFO - 2017-01-31 03:26:45 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:26:45 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:26:45 --> Utf8 Class Initialized
INFO - 2017-01-31 03:26:45 --> URI Class Initialized
INFO - 2017-01-31 03:26:45 --> Router Class Initialized
INFO - 2017-01-31 03:26:45 --> Output Class Initialized
INFO - 2017-01-31 03:26:45 --> Security Class Initialized
DEBUG - 2017-01-31 03:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:26:45 --> Input Class Initialized
INFO - 2017-01-31 03:26:45 --> Language Class Initialized
INFO - 2017-01-31 03:26:45 --> Loader Class Initialized
INFO - 2017-01-31 03:26:45 --> Database Driver Class Initialized
INFO - 2017-01-31 03:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:26:45 --> Controller Class Initialized
INFO - 2017-01-31 03:26:45 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:26:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-31 03:26:46 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-31 03:26:46 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Violeta Saldaña')
INFO - 2017-01-31 03:26:46 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-31 03:26:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-31 03:26:46 --> Config Class Initialized
INFO - 2017-01-31 03:26:46 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:26:46 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:26:46 --> Utf8 Class Initialized
INFO - 2017-01-31 03:26:46 --> URI Class Initialized
INFO - 2017-01-31 03:26:46 --> Router Class Initialized
INFO - 2017-01-31 03:26:46 --> Output Class Initialized
INFO - 2017-01-31 03:26:46 --> Security Class Initialized
DEBUG - 2017-01-31 03:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:26:46 --> Input Class Initialized
INFO - 2017-01-31 03:26:46 --> Language Class Initialized
INFO - 2017-01-31 03:26:46 --> Loader Class Initialized
INFO - 2017-01-31 03:26:46 --> Database Driver Class Initialized
INFO - 2017-01-31 03:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:26:46 --> Controller Class Initialized
INFO - 2017-01-31 03:26:46 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:26:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:26:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:26:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:26:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:26:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:26:46 --> Final output sent to browser
DEBUG - 2017-01-31 03:26:46 --> Total execution time: 0.0185
INFO - 2017-01-31 03:26:49 --> Config Class Initialized
INFO - 2017-01-31 03:26:49 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:26:49 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:26:49 --> Utf8 Class Initialized
INFO - 2017-01-31 03:26:49 --> URI Class Initialized
INFO - 2017-01-31 03:26:49 --> Router Class Initialized
INFO - 2017-01-31 03:26:49 --> Output Class Initialized
INFO - 2017-01-31 03:26:49 --> Security Class Initialized
DEBUG - 2017-01-31 03:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:26:49 --> Input Class Initialized
INFO - 2017-01-31 03:26:49 --> Language Class Initialized
INFO - 2017-01-31 03:26:49 --> Loader Class Initialized
INFO - 2017-01-31 03:26:49 --> Database Driver Class Initialized
INFO - 2017-01-31 03:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:26:49 --> Controller Class Initialized
INFO - 2017-01-31 03:26:49 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:26:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-31 03:26:50 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-31 03:26:50 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Violeta Saldaña')
INFO - 2017-01-31 03:26:50 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-31 03:26:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-31 03:26:50 --> Config Class Initialized
INFO - 2017-01-31 03:26:50 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:26:50 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:26:50 --> Utf8 Class Initialized
INFO - 2017-01-31 03:26:50 --> URI Class Initialized
INFO - 2017-01-31 03:26:50 --> Router Class Initialized
INFO - 2017-01-31 03:26:50 --> Output Class Initialized
INFO - 2017-01-31 03:26:50 --> Security Class Initialized
DEBUG - 2017-01-31 03:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:26:50 --> Input Class Initialized
INFO - 2017-01-31 03:26:50 --> Language Class Initialized
INFO - 2017-01-31 03:26:50 --> Loader Class Initialized
INFO - 2017-01-31 03:26:50 --> Database Driver Class Initialized
INFO - 2017-01-31 03:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:26:50 --> Controller Class Initialized
INFO - 2017-01-31 03:26:50 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:26:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:26:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:26:50 --> Final output sent to browser
DEBUG - 2017-01-31 03:26:50 --> Total execution time: 0.0129
INFO - 2017-01-31 03:26:53 --> Config Class Initialized
INFO - 2017-01-31 03:26:53 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:26:53 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:26:53 --> Utf8 Class Initialized
INFO - 2017-01-31 03:26:53 --> URI Class Initialized
DEBUG - 2017-01-31 03:26:53 --> No URI present. Default controller set.
INFO - 2017-01-31 03:26:53 --> Router Class Initialized
INFO - 2017-01-31 03:26:53 --> Output Class Initialized
INFO - 2017-01-31 03:26:53 --> Security Class Initialized
DEBUG - 2017-01-31 03:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:26:53 --> Input Class Initialized
INFO - 2017-01-31 03:26:53 --> Language Class Initialized
INFO - 2017-01-31 03:26:53 --> Loader Class Initialized
INFO - 2017-01-31 03:26:53 --> Database Driver Class Initialized
INFO - 2017-01-31 03:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:26:53 --> Controller Class Initialized
INFO - 2017-01-31 03:26:53 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:26:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:26:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:26:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:26:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:26:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:26:53 --> Final output sent to browser
DEBUG - 2017-01-31 03:26:53 --> Total execution time: 0.0133
INFO - 2017-01-31 03:26:55 --> Config Class Initialized
INFO - 2017-01-31 03:26:55 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:26:55 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:26:55 --> Utf8 Class Initialized
INFO - 2017-01-31 03:26:55 --> URI Class Initialized
INFO - 2017-01-31 03:26:55 --> Router Class Initialized
INFO - 2017-01-31 03:26:55 --> Output Class Initialized
INFO - 2017-01-31 03:26:55 --> Security Class Initialized
DEBUG - 2017-01-31 03:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:26:55 --> Input Class Initialized
INFO - 2017-01-31 03:26:55 --> Language Class Initialized
INFO - 2017-01-31 03:26:55 --> Loader Class Initialized
INFO - 2017-01-31 03:26:55 --> Database Driver Class Initialized
INFO - 2017-01-31 03:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:26:55 --> Controller Class Initialized
INFO - 2017-01-31 03:26:55 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:26:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:26:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:26:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:26:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:26:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:26:55 --> Final output sent to browser
DEBUG - 2017-01-31 03:26:55 --> Total execution time: 0.0140
INFO - 2017-01-31 03:29:48 --> Config Class Initialized
INFO - 2017-01-31 03:29:48 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:29:48 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:29:48 --> Utf8 Class Initialized
INFO - 2017-01-31 03:29:48 --> URI Class Initialized
DEBUG - 2017-01-31 03:29:48 --> No URI present. Default controller set.
INFO - 2017-01-31 03:29:48 --> Router Class Initialized
INFO - 2017-01-31 03:29:48 --> Output Class Initialized
INFO - 2017-01-31 03:29:48 --> Security Class Initialized
DEBUG - 2017-01-31 03:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:29:48 --> Input Class Initialized
INFO - 2017-01-31 03:29:48 --> Language Class Initialized
INFO - 2017-01-31 03:29:48 --> Loader Class Initialized
INFO - 2017-01-31 03:29:48 --> Database Driver Class Initialized
INFO - 2017-01-31 03:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:29:48 --> Controller Class Initialized
INFO - 2017-01-31 03:29:48 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:29:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:29:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:29:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:29:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:29:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:29:48 --> Final output sent to browser
DEBUG - 2017-01-31 03:29:48 --> Total execution time: 0.0131
INFO - 2017-01-31 03:29:52 --> Config Class Initialized
INFO - 2017-01-31 03:29:52 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:29:52 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:29:52 --> Utf8 Class Initialized
INFO - 2017-01-31 03:29:52 --> URI Class Initialized
INFO - 2017-01-31 03:29:52 --> Router Class Initialized
INFO - 2017-01-31 03:29:52 --> Output Class Initialized
INFO - 2017-01-31 03:29:52 --> Security Class Initialized
DEBUG - 2017-01-31 03:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:29:52 --> Input Class Initialized
INFO - 2017-01-31 03:29:52 --> Language Class Initialized
INFO - 2017-01-31 03:29:52 --> Loader Class Initialized
INFO - 2017-01-31 03:29:52 --> Database Driver Class Initialized
INFO - 2017-01-31 03:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:29:52 --> Controller Class Initialized
INFO - 2017-01-31 03:29:52 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:29:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:29:52 --> Final output sent to browser
DEBUG - 2017-01-31 03:29:52 --> Total execution time: 0.0135
INFO - 2017-01-31 03:30:30 --> Config Class Initialized
INFO - 2017-01-31 03:30:30 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:30:30 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:30:30 --> Utf8 Class Initialized
INFO - 2017-01-31 03:30:30 --> URI Class Initialized
INFO - 2017-01-31 03:30:30 --> Router Class Initialized
INFO - 2017-01-31 03:30:30 --> Output Class Initialized
INFO - 2017-01-31 03:30:30 --> Security Class Initialized
DEBUG - 2017-01-31 03:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:30:30 --> Input Class Initialized
INFO - 2017-01-31 03:30:30 --> Language Class Initialized
INFO - 2017-01-31 03:30:30 --> Loader Class Initialized
INFO - 2017-01-31 03:30:30 --> Database Driver Class Initialized
INFO - 2017-01-31 03:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:30:30 --> Controller Class Initialized
INFO - 2017-01-31 03:30:30 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:30:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-31 03:30:30 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-31 03:30:30 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Violeta Saldaña')
INFO - 2017-01-31 03:30:30 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-31 03:30:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-31 03:30:31 --> Config Class Initialized
INFO - 2017-01-31 03:30:31 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:30:31 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:30:31 --> Utf8 Class Initialized
INFO - 2017-01-31 03:30:31 --> URI Class Initialized
INFO - 2017-01-31 03:30:31 --> Router Class Initialized
INFO - 2017-01-31 03:30:31 --> Output Class Initialized
INFO - 2017-01-31 03:30:31 --> Security Class Initialized
DEBUG - 2017-01-31 03:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:30:31 --> Input Class Initialized
INFO - 2017-01-31 03:30:31 --> Language Class Initialized
INFO - 2017-01-31 03:30:31 --> Loader Class Initialized
INFO - 2017-01-31 03:30:31 --> Database Driver Class Initialized
INFO - 2017-01-31 03:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:30:31 --> Controller Class Initialized
INFO - 2017-01-31 03:30:31 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:30:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:30:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:30:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:30:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:30:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:30:31 --> Final output sent to browser
DEBUG - 2017-01-31 03:30:31 --> Total execution time: 0.0130
INFO - 2017-01-31 03:30:39 --> Config Class Initialized
INFO - 2017-01-31 03:30:39 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:30:39 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:30:39 --> Utf8 Class Initialized
INFO - 2017-01-31 03:30:39 --> URI Class Initialized
DEBUG - 2017-01-31 03:30:39 --> No URI present. Default controller set.
INFO - 2017-01-31 03:30:39 --> Router Class Initialized
INFO - 2017-01-31 03:30:39 --> Output Class Initialized
INFO - 2017-01-31 03:30:39 --> Security Class Initialized
DEBUG - 2017-01-31 03:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:30:39 --> Input Class Initialized
INFO - 2017-01-31 03:30:39 --> Language Class Initialized
INFO - 2017-01-31 03:30:39 --> Loader Class Initialized
INFO - 2017-01-31 03:30:39 --> Database Driver Class Initialized
INFO - 2017-01-31 03:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:30:39 --> Controller Class Initialized
INFO - 2017-01-31 03:30:39 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:30:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:30:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:30:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:30:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:30:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:30:39 --> Final output sent to browser
DEBUG - 2017-01-31 03:30:39 --> Total execution time: 0.0131
INFO - 2017-01-31 03:30:42 --> Config Class Initialized
INFO - 2017-01-31 03:30:42 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:30:42 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:30:42 --> Utf8 Class Initialized
INFO - 2017-01-31 03:30:42 --> URI Class Initialized
INFO - 2017-01-31 03:30:42 --> Router Class Initialized
INFO - 2017-01-31 03:30:42 --> Output Class Initialized
INFO - 2017-01-31 03:30:42 --> Security Class Initialized
DEBUG - 2017-01-31 03:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:30:42 --> Input Class Initialized
INFO - 2017-01-31 03:30:42 --> Language Class Initialized
INFO - 2017-01-31 03:30:42 --> Loader Class Initialized
INFO - 2017-01-31 03:30:42 --> Database Driver Class Initialized
INFO - 2017-01-31 03:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:30:42 --> Controller Class Initialized
INFO - 2017-01-31 03:30:42 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:30:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:30:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:30:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:30:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:30:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:30:42 --> Final output sent to browser
DEBUG - 2017-01-31 03:30:42 --> Total execution time: 0.0130
INFO - 2017-01-31 03:33:56 --> Config Class Initialized
INFO - 2017-01-31 03:33:56 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:33:56 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:33:56 --> Utf8 Class Initialized
INFO - 2017-01-31 03:33:56 --> URI Class Initialized
INFO - 2017-01-31 03:33:56 --> Router Class Initialized
INFO - 2017-01-31 03:33:56 --> Output Class Initialized
INFO - 2017-01-31 03:33:56 --> Security Class Initialized
DEBUG - 2017-01-31 03:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:33:56 --> Input Class Initialized
INFO - 2017-01-31 03:33:56 --> Language Class Initialized
INFO - 2017-01-31 03:33:56 --> Loader Class Initialized
INFO - 2017-01-31 03:33:56 --> Database Driver Class Initialized
INFO - 2017-01-31 03:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:33:56 --> Controller Class Initialized
INFO - 2017-01-31 03:33:56 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:33:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:33:56 --> Config Class Initialized
INFO - 2017-01-31 03:33:56 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:33:56 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:33:56 --> Utf8 Class Initialized
INFO - 2017-01-31 03:33:56 --> URI Class Initialized
INFO - 2017-01-31 03:33:56 --> Router Class Initialized
INFO - 2017-01-31 03:33:56 --> Output Class Initialized
INFO - 2017-01-31 03:33:56 --> Security Class Initialized
DEBUG - 2017-01-31 03:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:33:56 --> Input Class Initialized
INFO - 2017-01-31 03:33:56 --> Language Class Initialized
INFO - 2017-01-31 03:33:56 --> Loader Class Initialized
INFO - 2017-01-31 03:33:56 --> Database Driver Class Initialized
INFO - 2017-01-31 03:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:33:56 --> Controller Class Initialized
INFO - 2017-01-31 03:33:56 --> Helper loaded: date_helper
DEBUG - 2017-01-31 03:33:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:33:56 --> Helper loaded: url_helper
INFO - 2017-01-31 03:33:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:33:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 03:33:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 03:33:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 03:33:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:33:56 --> Final output sent to browser
DEBUG - 2017-01-31 03:33:56 --> Total execution time: 0.0284
INFO - 2017-01-31 03:33:58 --> Config Class Initialized
INFO - 2017-01-31 03:33:58 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:33:58 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:33:58 --> Utf8 Class Initialized
INFO - 2017-01-31 03:33:58 --> URI Class Initialized
INFO - 2017-01-31 03:33:58 --> Router Class Initialized
INFO - 2017-01-31 03:33:58 --> Output Class Initialized
INFO - 2017-01-31 03:33:58 --> Security Class Initialized
DEBUG - 2017-01-31 03:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:33:58 --> Input Class Initialized
INFO - 2017-01-31 03:33:58 --> Language Class Initialized
INFO - 2017-01-31 03:33:58 --> Loader Class Initialized
INFO - 2017-01-31 03:33:58 --> Database Driver Class Initialized
INFO - 2017-01-31 03:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:33:58 --> Controller Class Initialized
INFO - 2017-01-31 03:33:58 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:33:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:33:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:33:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:33:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:33:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:33:58 --> Final output sent to browser
DEBUG - 2017-01-31 03:33:58 --> Total execution time: 0.0138
INFO - 2017-01-31 03:36:32 --> Config Class Initialized
INFO - 2017-01-31 03:36:32 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:36:32 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:36:32 --> Utf8 Class Initialized
INFO - 2017-01-31 03:36:32 --> URI Class Initialized
DEBUG - 2017-01-31 03:36:32 --> No URI present. Default controller set.
INFO - 2017-01-31 03:36:32 --> Router Class Initialized
INFO - 2017-01-31 03:36:32 --> Output Class Initialized
INFO - 2017-01-31 03:36:32 --> Security Class Initialized
DEBUG - 2017-01-31 03:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:36:32 --> Input Class Initialized
INFO - 2017-01-31 03:36:32 --> Language Class Initialized
INFO - 2017-01-31 03:36:32 --> Loader Class Initialized
INFO - 2017-01-31 03:36:32 --> Database Driver Class Initialized
INFO - 2017-01-31 03:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:36:32 --> Controller Class Initialized
INFO - 2017-01-31 03:36:32 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:36:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:36:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:36:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:36:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:36:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:36:32 --> Final output sent to browser
DEBUG - 2017-01-31 03:36:32 --> Total execution time: 0.0137
INFO - 2017-01-31 03:36:34 --> Config Class Initialized
INFO - 2017-01-31 03:36:34 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:36:34 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:36:34 --> Utf8 Class Initialized
INFO - 2017-01-31 03:36:34 --> URI Class Initialized
INFO - 2017-01-31 03:36:34 --> Router Class Initialized
INFO - 2017-01-31 03:36:34 --> Output Class Initialized
INFO - 2017-01-31 03:36:34 --> Security Class Initialized
DEBUG - 2017-01-31 03:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:36:34 --> Input Class Initialized
INFO - 2017-01-31 03:36:34 --> Language Class Initialized
INFO - 2017-01-31 03:36:34 --> Loader Class Initialized
INFO - 2017-01-31 03:36:34 --> Database Driver Class Initialized
INFO - 2017-01-31 03:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:36:34 --> Controller Class Initialized
INFO - 2017-01-31 03:36:34 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:36:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:36:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:36:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:36:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:36:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:36:34 --> Final output sent to browser
DEBUG - 2017-01-31 03:36:34 --> Total execution time: 0.0139
INFO - 2017-01-31 03:40:52 --> Config Class Initialized
INFO - 2017-01-31 03:40:52 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:40:52 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:40:52 --> Utf8 Class Initialized
INFO - 2017-01-31 03:40:52 --> URI Class Initialized
DEBUG - 2017-01-31 03:40:52 --> No URI present. Default controller set.
INFO - 2017-01-31 03:40:52 --> Router Class Initialized
INFO - 2017-01-31 03:40:52 --> Output Class Initialized
INFO - 2017-01-31 03:40:52 --> Security Class Initialized
DEBUG - 2017-01-31 03:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:40:52 --> Input Class Initialized
INFO - 2017-01-31 03:40:52 --> Language Class Initialized
INFO - 2017-01-31 03:40:52 --> Loader Class Initialized
INFO - 2017-01-31 03:40:52 --> Database Driver Class Initialized
INFO - 2017-01-31 03:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:40:52 --> Controller Class Initialized
INFO - 2017-01-31 03:40:52 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:40:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:40:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:40:52 --> Final output sent to browser
DEBUG - 2017-01-31 03:40:52 --> Total execution time: 0.0140
INFO - 2017-01-31 03:40:58 --> Config Class Initialized
INFO - 2017-01-31 03:40:58 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:40:58 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:40:58 --> Utf8 Class Initialized
INFO - 2017-01-31 03:40:58 --> URI Class Initialized
INFO - 2017-01-31 03:40:58 --> Router Class Initialized
INFO - 2017-01-31 03:40:58 --> Output Class Initialized
INFO - 2017-01-31 03:40:58 --> Security Class Initialized
DEBUG - 2017-01-31 03:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:40:58 --> Input Class Initialized
INFO - 2017-01-31 03:40:58 --> Language Class Initialized
INFO - 2017-01-31 03:40:58 --> Loader Class Initialized
INFO - 2017-01-31 03:40:58 --> Database Driver Class Initialized
INFO - 2017-01-31 03:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:40:58 --> Controller Class Initialized
INFO - 2017-01-31 03:40:58 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:40:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:40:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:40:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:40:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:40:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:40:58 --> Final output sent to browser
DEBUG - 2017-01-31 03:40:58 --> Total execution time: 0.0139
INFO - 2017-01-31 03:41:29 --> Config Class Initialized
INFO - 2017-01-31 03:41:29 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:41:29 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:41:29 --> Utf8 Class Initialized
INFO - 2017-01-31 03:41:29 --> URI Class Initialized
INFO - 2017-01-31 03:41:29 --> Router Class Initialized
INFO - 2017-01-31 03:41:29 --> Output Class Initialized
INFO - 2017-01-31 03:41:29 --> Security Class Initialized
DEBUG - 2017-01-31 03:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:41:29 --> Input Class Initialized
INFO - 2017-01-31 03:41:29 --> Language Class Initialized
INFO - 2017-01-31 03:41:29 --> Loader Class Initialized
INFO - 2017-01-31 03:41:29 --> Database Driver Class Initialized
INFO - 2017-01-31 03:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:41:29 --> Controller Class Initialized
INFO - 2017-01-31 03:41:29 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:41:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:41:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:41:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:41:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:41:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:41:29 --> Final output sent to browser
DEBUG - 2017-01-31 03:41:29 --> Total execution time: 0.0137
INFO - 2017-01-31 03:41:32 --> Config Class Initialized
INFO - 2017-01-31 03:41:32 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:41:32 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:41:32 --> Utf8 Class Initialized
INFO - 2017-01-31 03:41:32 --> URI Class Initialized
INFO - 2017-01-31 03:41:32 --> Router Class Initialized
INFO - 2017-01-31 03:41:32 --> Output Class Initialized
INFO - 2017-01-31 03:41:32 --> Security Class Initialized
DEBUG - 2017-01-31 03:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:41:32 --> Input Class Initialized
INFO - 2017-01-31 03:41:32 --> Language Class Initialized
INFO - 2017-01-31 03:41:32 --> Loader Class Initialized
INFO - 2017-01-31 03:41:32 --> Database Driver Class Initialized
INFO - 2017-01-31 03:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:41:32 --> Controller Class Initialized
INFO - 2017-01-31 03:41:32 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:41:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:41:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:41:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:41:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:41:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:41:32 --> Final output sent to browser
DEBUG - 2017-01-31 03:41:32 --> Total execution time: 0.0135
INFO - 2017-01-31 03:41:50 --> Config Class Initialized
INFO - 2017-01-31 03:41:50 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:41:50 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:41:50 --> Utf8 Class Initialized
INFO - 2017-01-31 03:41:50 --> URI Class Initialized
DEBUG - 2017-01-31 03:41:50 --> No URI present. Default controller set.
INFO - 2017-01-31 03:41:50 --> Router Class Initialized
INFO - 2017-01-31 03:41:50 --> Output Class Initialized
INFO - 2017-01-31 03:41:50 --> Security Class Initialized
DEBUG - 2017-01-31 03:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:41:50 --> Input Class Initialized
INFO - 2017-01-31 03:41:50 --> Language Class Initialized
INFO - 2017-01-31 03:41:50 --> Loader Class Initialized
INFO - 2017-01-31 03:41:50 --> Database Driver Class Initialized
INFO - 2017-01-31 03:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:41:50 --> Controller Class Initialized
INFO - 2017-01-31 03:41:50 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:41:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:41:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:41:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:41:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:41:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:41:50 --> Final output sent to browser
DEBUG - 2017-01-31 03:41:50 --> Total execution time: 0.0131
INFO - 2017-01-31 03:41:53 --> Config Class Initialized
INFO - 2017-01-31 03:41:53 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:41:53 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:41:53 --> Utf8 Class Initialized
INFO - 2017-01-31 03:41:53 --> URI Class Initialized
INFO - 2017-01-31 03:41:53 --> Router Class Initialized
INFO - 2017-01-31 03:41:53 --> Output Class Initialized
INFO - 2017-01-31 03:41:53 --> Security Class Initialized
DEBUG - 2017-01-31 03:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:41:53 --> Input Class Initialized
INFO - 2017-01-31 03:41:53 --> Language Class Initialized
INFO - 2017-01-31 03:41:53 --> Loader Class Initialized
INFO - 2017-01-31 03:41:53 --> Database Driver Class Initialized
INFO - 2017-01-31 03:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:41:53 --> Controller Class Initialized
INFO - 2017-01-31 03:41:53 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:41:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:41:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:41:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:41:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:41:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:41:53 --> Final output sent to browser
DEBUG - 2017-01-31 03:41:53 --> Total execution time: 0.0130
INFO - 2017-01-31 03:42:14 --> Config Class Initialized
INFO - 2017-01-31 03:42:14 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:42:14 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:42:14 --> Utf8 Class Initialized
INFO - 2017-01-31 03:42:14 --> URI Class Initialized
INFO - 2017-01-31 03:42:14 --> Router Class Initialized
INFO - 2017-01-31 03:42:14 --> Output Class Initialized
INFO - 2017-01-31 03:42:14 --> Security Class Initialized
DEBUG - 2017-01-31 03:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:42:14 --> Input Class Initialized
INFO - 2017-01-31 03:42:14 --> Language Class Initialized
INFO - 2017-01-31 03:42:14 --> Loader Class Initialized
INFO - 2017-01-31 03:42:14 --> Database Driver Class Initialized
INFO - 2017-01-31 03:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:42:14 --> Controller Class Initialized
INFO - 2017-01-31 03:42:14 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:42:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:42:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:42:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:42:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:42:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:42:14 --> Final output sent to browser
DEBUG - 2017-01-31 03:42:14 --> Total execution time: 0.0135
INFO - 2017-01-31 03:42:15 --> Config Class Initialized
INFO - 2017-01-31 03:42:15 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:42:15 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:42:15 --> Utf8 Class Initialized
INFO - 2017-01-31 03:42:15 --> URI Class Initialized
INFO - 2017-01-31 03:42:15 --> Router Class Initialized
INFO - 2017-01-31 03:42:15 --> Output Class Initialized
INFO - 2017-01-31 03:42:15 --> Security Class Initialized
DEBUG - 2017-01-31 03:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:42:15 --> Input Class Initialized
INFO - 2017-01-31 03:42:15 --> Language Class Initialized
INFO - 2017-01-31 03:42:15 --> Loader Class Initialized
INFO - 2017-01-31 03:42:15 --> Database Driver Class Initialized
INFO - 2017-01-31 03:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:42:15 --> Controller Class Initialized
INFO - 2017-01-31 03:42:15 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:42:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:42:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:42:15 --> Final output sent to browser
DEBUG - 2017-01-31 03:42:15 --> Total execution time: 0.0141
INFO - 2017-01-31 03:42:35 --> Config Class Initialized
INFO - 2017-01-31 03:42:35 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:42:35 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:42:35 --> Utf8 Class Initialized
INFO - 2017-01-31 03:42:35 --> URI Class Initialized
INFO - 2017-01-31 03:42:35 --> Router Class Initialized
INFO - 2017-01-31 03:42:35 --> Output Class Initialized
INFO - 2017-01-31 03:42:35 --> Security Class Initialized
DEBUG - 2017-01-31 03:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:42:35 --> Input Class Initialized
INFO - 2017-01-31 03:42:35 --> Language Class Initialized
INFO - 2017-01-31 03:42:35 --> Loader Class Initialized
INFO - 2017-01-31 03:42:35 --> Database Driver Class Initialized
INFO - 2017-01-31 03:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:42:35 --> Controller Class Initialized
INFO - 2017-01-31 03:42:35 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:42:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:42:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:42:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:42:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:42:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:42:35 --> Final output sent to browser
DEBUG - 2017-01-31 03:42:35 --> Total execution time: 0.0140
INFO - 2017-01-31 03:42:37 --> Config Class Initialized
INFO - 2017-01-31 03:42:37 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:42:37 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:42:37 --> Utf8 Class Initialized
INFO - 2017-01-31 03:42:37 --> URI Class Initialized
INFO - 2017-01-31 03:42:37 --> Router Class Initialized
INFO - 2017-01-31 03:42:37 --> Output Class Initialized
INFO - 2017-01-31 03:42:37 --> Security Class Initialized
DEBUG - 2017-01-31 03:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:42:37 --> Input Class Initialized
INFO - 2017-01-31 03:42:37 --> Language Class Initialized
INFO - 2017-01-31 03:42:37 --> Loader Class Initialized
INFO - 2017-01-31 03:42:37 --> Database Driver Class Initialized
INFO - 2017-01-31 03:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:42:37 --> Controller Class Initialized
INFO - 2017-01-31 03:42:37 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:42:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:42:37 --> Final output sent to browser
DEBUG - 2017-01-31 03:42:37 --> Total execution time: 0.0128
INFO - 2017-01-31 03:43:04 --> Config Class Initialized
INFO - 2017-01-31 03:43:04 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:43:04 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:43:04 --> Utf8 Class Initialized
INFO - 2017-01-31 03:43:04 --> URI Class Initialized
INFO - 2017-01-31 03:43:04 --> Router Class Initialized
INFO - 2017-01-31 03:43:04 --> Output Class Initialized
INFO - 2017-01-31 03:43:04 --> Security Class Initialized
DEBUG - 2017-01-31 03:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:43:04 --> Input Class Initialized
INFO - 2017-01-31 03:43:04 --> Language Class Initialized
INFO - 2017-01-31 03:43:04 --> Loader Class Initialized
INFO - 2017-01-31 03:43:04 --> Database Driver Class Initialized
INFO - 2017-01-31 03:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:43:04 --> Controller Class Initialized
INFO - 2017-01-31 03:43:04 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:43:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:43:05 --> Config Class Initialized
INFO - 2017-01-31 03:43:05 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:43:05 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:43:05 --> Utf8 Class Initialized
INFO - 2017-01-31 03:43:05 --> URI Class Initialized
INFO - 2017-01-31 03:43:05 --> Router Class Initialized
INFO - 2017-01-31 03:43:05 --> Output Class Initialized
INFO - 2017-01-31 03:43:05 --> Security Class Initialized
DEBUG - 2017-01-31 03:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:43:05 --> Input Class Initialized
INFO - 2017-01-31 03:43:05 --> Language Class Initialized
INFO - 2017-01-31 03:43:05 --> Loader Class Initialized
INFO - 2017-01-31 03:43:05 --> Database Driver Class Initialized
INFO - 2017-01-31 03:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:43:05 --> Controller Class Initialized
INFO - 2017-01-31 03:43:05 --> Helper loaded: date_helper
DEBUG - 2017-01-31 03:43:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:43:05 --> Helper loaded: url_helper
INFO - 2017-01-31 03:43:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:43:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 03:43:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 03:43:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 03:43:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:43:05 --> Final output sent to browser
DEBUG - 2017-01-31 03:43:05 --> Total execution time: 0.0133
INFO - 2017-01-31 03:43:07 --> Config Class Initialized
INFO - 2017-01-31 03:43:07 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:43:07 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:43:07 --> Utf8 Class Initialized
INFO - 2017-01-31 03:43:07 --> URI Class Initialized
INFO - 2017-01-31 03:43:07 --> Router Class Initialized
INFO - 2017-01-31 03:43:07 --> Output Class Initialized
INFO - 2017-01-31 03:43:07 --> Security Class Initialized
DEBUG - 2017-01-31 03:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:43:07 --> Input Class Initialized
INFO - 2017-01-31 03:43:07 --> Language Class Initialized
INFO - 2017-01-31 03:43:07 --> Loader Class Initialized
INFO - 2017-01-31 03:43:07 --> Database Driver Class Initialized
INFO - 2017-01-31 03:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:43:07 --> Controller Class Initialized
INFO - 2017-01-31 03:43:07 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:43:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:43:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:43:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:43:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:43:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:43:07 --> Final output sent to browser
DEBUG - 2017-01-31 03:43:07 --> Total execution time: 0.0134
INFO - 2017-01-31 03:43:19 --> Config Class Initialized
INFO - 2017-01-31 03:43:19 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:43:19 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:43:19 --> Utf8 Class Initialized
INFO - 2017-01-31 03:43:19 --> URI Class Initialized
DEBUG - 2017-01-31 03:43:19 --> No URI present. Default controller set.
INFO - 2017-01-31 03:43:19 --> Router Class Initialized
INFO - 2017-01-31 03:43:19 --> Output Class Initialized
INFO - 2017-01-31 03:43:19 --> Security Class Initialized
DEBUG - 2017-01-31 03:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:43:19 --> Input Class Initialized
INFO - 2017-01-31 03:43:19 --> Language Class Initialized
INFO - 2017-01-31 03:43:19 --> Loader Class Initialized
INFO - 2017-01-31 03:43:19 --> Database Driver Class Initialized
INFO - 2017-01-31 03:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:43:19 --> Controller Class Initialized
INFO - 2017-01-31 03:43:19 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:43:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:43:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:43:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:43:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:43:19 --> Final output sent to browser
DEBUG - 2017-01-31 03:43:19 --> Total execution time: 0.0136
INFO - 2017-01-31 03:43:21 --> Config Class Initialized
INFO - 2017-01-31 03:43:21 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:43:21 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:43:21 --> Utf8 Class Initialized
INFO - 2017-01-31 03:43:21 --> URI Class Initialized
INFO - 2017-01-31 03:43:21 --> Router Class Initialized
INFO - 2017-01-31 03:43:21 --> Output Class Initialized
INFO - 2017-01-31 03:43:21 --> Security Class Initialized
DEBUG - 2017-01-31 03:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:43:21 --> Input Class Initialized
INFO - 2017-01-31 03:43:21 --> Language Class Initialized
INFO - 2017-01-31 03:43:21 --> Loader Class Initialized
INFO - 2017-01-31 03:43:21 --> Database Driver Class Initialized
INFO - 2017-01-31 03:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:43:21 --> Controller Class Initialized
INFO - 2017-01-31 03:43:21 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:43:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:43:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:43:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:43:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:43:21 --> Final output sent to browser
DEBUG - 2017-01-31 03:43:21 --> Total execution time: 0.0134
INFO - 2017-01-31 03:43:37 --> Config Class Initialized
INFO - 2017-01-31 03:43:37 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:43:37 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:43:37 --> Utf8 Class Initialized
INFO - 2017-01-31 03:43:37 --> URI Class Initialized
INFO - 2017-01-31 03:43:37 --> Router Class Initialized
INFO - 2017-01-31 03:43:37 --> Output Class Initialized
INFO - 2017-01-31 03:43:37 --> Security Class Initialized
DEBUG - 2017-01-31 03:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:43:37 --> Input Class Initialized
INFO - 2017-01-31 03:43:37 --> Language Class Initialized
INFO - 2017-01-31 03:43:37 --> Loader Class Initialized
INFO - 2017-01-31 03:43:37 --> Database Driver Class Initialized
INFO - 2017-01-31 03:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:43:37 --> Controller Class Initialized
INFO - 2017-01-31 03:43:37 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:43:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:43:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:43:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:43:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:43:37 --> Final output sent to browser
DEBUG - 2017-01-31 03:43:37 --> Total execution time: 0.0144
INFO - 2017-01-31 03:43:39 --> Config Class Initialized
INFO - 2017-01-31 03:43:39 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:43:39 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:43:39 --> Utf8 Class Initialized
INFO - 2017-01-31 03:43:39 --> URI Class Initialized
INFO - 2017-01-31 03:43:39 --> Router Class Initialized
INFO - 2017-01-31 03:43:39 --> Output Class Initialized
INFO - 2017-01-31 03:43:39 --> Security Class Initialized
DEBUG - 2017-01-31 03:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:43:39 --> Input Class Initialized
INFO - 2017-01-31 03:43:39 --> Language Class Initialized
INFO - 2017-01-31 03:43:39 --> Loader Class Initialized
INFO - 2017-01-31 03:43:39 --> Database Driver Class Initialized
INFO - 2017-01-31 03:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:43:39 --> Controller Class Initialized
INFO - 2017-01-31 03:43:39 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:43:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:43:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:43:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:43:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:43:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:43:39 --> Final output sent to browser
DEBUG - 2017-01-31 03:43:39 --> Total execution time: 0.0133
INFO - 2017-01-31 03:43:58 --> Config Class Initialized
INFO - 2017-01-31 03:43:58 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:43:58 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:43:58 --> Utf8 Class Initialized
INFO - 2017-01-31 03:43:58 --> URI Class Initialized
INFO - 2017-01-31 03:43:58 --> Router Class Initialized
INFO - 2017-01-31 03:43:58 --> Output Class Initialized
INFO - 2017-01-31 03:43:58 --> Security Class Initialized
DEBUG - 2017-01-31 03:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:43:58 --> Input Class Initialized
INFO - 2017-01-31 03:43:58 --> Language Class Initialized
INFO - 2017-01-31 03:43:58 --> Loader Class Initialized
INFO - 2017-01-31 03:43:58 --> Database Driver Class Initialized
INFO - 2017-01-31 03:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:43:58 --> Controller Class Initialized
INFO - 2017-01-31 03:43:58 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:43:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:43:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:43:58 --> Final output sent to browser
DEBUG - 2017-01-31 03:43:58 --> Total execution time: 0.0140
INFO - 2017-01-31 03:44:00 --> Config Class Initialized
INFO - 2017-01-31 03:44:00 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:44:00 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:44:00 --> Utf8 Class Initialized
INFO - 2017-01-31 03:44:00 --> URI Class Initialized
INFO - 2017-01-31 03:44:00 --> Router Class Initialized
INFO - 2017-01-31 03:44:00 --> Output Class Initialized
INFO - 2017-01-31 03:44:00 --> Security Class Initialized
DEBUG - 2017-01-31 03:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:44:00 --> Input Class Initialized
INFO - 2017-01-31 03:44:00 --> Language Class Initialized
INFO - 2017-01-31 03:44:00 --> Loader Class Initialized
INFO - 2017-01-31 03:44:00 --> Database Driver Class Initialized
INFO - 2017-01-31 03:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:44:00 --> Controller Class Initialized
INFO - 2017-01-31 03:44:00 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:44:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:44:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:44:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:44:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:44:00 --> Final output sent to browser
DEBUG - 2017-01-31 03:44:00 --> Total execution time: 0.0360
INFO - 2017-01-31 03:44:04 --> Config Class Initialized
INFO - 2017-01-31 03:44:04 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:44:04 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:44:04 --> Utf8 Class Initialized
INFO - 2017-01-31 03:44:04 --> URI Class Initialized
DEBUG - 2017-01-31 03:44:04 --> No URI present. Default controller set.
INFO - 2017-01-31 03:44:04 --> Router Class Initialized
INFO - 2017-01-31 03:44:04 --> Output Class Initialized
INFO - 2017-01-31 03:44:04 --> Security Class Initialized
DEBUG - 2017-01-31 03:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:44:04 --> Input Class Initialized
INFO - 2017-01-31 03:44:04 --> Language Class Initialized
INFO - 2017-01-31 03:44:04 --> Loader Class Initialized
INFO - 2017-01-31 03:44:04 --> Database Driver Class Initialized
INFO - 2017-01-31 03:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:44:04 --> Controller Class Initialized
INFO - 2017-01-31 03:44:04 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:44:04 --> Final output sent to browser
DEBUG - 2017-01-31 03:44:04 --> Total execution time: 0.0134
INFO - 2017-01-31 03:44:04 --> Config Class Initialized
INFO - 2017-01-31 03:44:04 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:44:04 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:44:04 --> Utf8 Class Initialized
INFO - 2017-01-31 03:44:04 --> URI Class Initialized
INFO - 2017-01-31 03:44:04 --> Router Class Initialized
INFO - 2017-01-31 03:44:04 --> Output Class Initialized
INFO - 2017-01-31 03:44:04 --> Security Class Initialized
DEBUG - 2017-01-31 03:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:44:04 --> Input Class Initialized
INFO - 2017-01-31 03:44:04 --> Language Class Initialized
INFO - 2017-01-31 03:44:04 --> Loader Class Initialized
INFO - 2017-01-31 03:44:04 --> Database Driver Class Initialized
INFO - 2017-01-31 03:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:44:04 --> Controller Class Initialized
INFO - 2017-01-31 03:44:04 --> Helper loaded: date_helper
DEBUG - 2017-01-31 03:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:44:04 --> Helper loaded: url_helper
INFO - 2017-01-31 03:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 03:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 03:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 03:44:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:44:04 --> Final output sent to browser
DEBUG - 2017-01-31 03:44:04 --> Total execution time: 0.0140
INFO - 2017-01-31 03:44:05 --> Config Class Initialized
INFO - 2017-01-31 03:44:05 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:44:05 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:44:05 --> Utf8 Class Initialized
INFO - 2017-01-31 03:44:05 --> URI Class Initialized
INFO - 2017-01-31 03:44:05 --> Router Class Initialized
INFO - 2017-01-31 03:44:05 --> Output Class Initialized
INFO - 2017-01-31 03:44:05 --> Security Class Initialized
DEBUG - 2017-01-31 03:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:44:05 --> Input Class Initialized
INFO - 2017-01-31 03:44:05 --> Language Class Initialized
INFO - 2017-01-31 03:44:05 --> Loader Class Initialized
INFO - 2017-01-31 03:44:05 --> Database Driver Class Initialized
INFO - 2017-01-31 03:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:44:05 --> Controller Class Initialized
INFO - 2017-01-31 03:44:05 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:44:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:44:06 --> Config Class Initialized
INFO - 2017-01-31 03:44:06 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:44:06 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:44:06 --> Utf8 Class Initialized
INFO - 2017-01-31 03:44:06 --> URI Class Initialized
INFO - 2017-01-31 03:44:06 --> Router Class Initialized
INFO - 2017-01-31 03:44:06 --> Output Class Initialized
INFO - 2017-01-31 03:44:06 --> Security Class Initialized
DEBUG - 2017-01-31 03:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:44:06 --> Input Class Initialized
INFO - 2017-01-31 03:44:06 --> Language Class Initialized
INFO - 2017-01-31 03:44:06 --> Loader Class Initialized
INFO - 2017-01-31 03:44:06 --> Database Driver Class Initialized
INFO - 2017-01-31 03:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:44:06 --> Controller Class Initialized
INFO - 2017-01-31 03:44:06 --> Helper loaded: date_helper
DEBUG - 2017-01-31 03:44:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:44:06 --> Helper loaded: url_helper
INFO - 2017-01-31 03:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 03:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 03:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 03:44:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:44:06 --> Final output sent to browser
DEBUG - 2017-01-31 03:44:06 --> Total execution time: 0.0148
INFO - 2017-01-31 03:44:07 --> Config Class Initialized
INFO - 2017-01-31 03:44:07 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:44:07 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:44:07 --> Utf8 Class Initialized
INFO - 2017-01-31 03:44:07 --> URI Class Initialized
INFO - 2017-01-31 03:44:07 --> Router Class Initialized
INFO - 2017-01-31 03:44:07 --> Output Class Initialized
INFO - 2017-01-31 03:44:07 --> Security Class Initialized
DEBUG - 2017-01-31 03:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:44:07 --> Input Class Initialized
INFO - 2017-01-31 03:44:07 --> Language Class Initialized
INFO - 2017-01-31 03:44:07 --> Loader Class Initialized
INFO - 2017-01-31 03:44:07 --> Database Driver Class Initialized
INFO - 2017-01-31 03:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:44:07 --> Controller Class Initialized
INFO - 2017-01-31 03:44:07 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:44:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:44:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:44:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:44:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:44:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:44:07 --> Final output sent to browser
DEBUG - 2017-01-31 03:44:07 --> Total execution time: 0.0136
INFO - 2017-01-31 03:44:11 --> Config Class Initialized
INFO - 2017-01-31 03:44:11 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:44:11 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:44:11 --> Utf8 Class Initialized
INFO - 2017-01-31 03:44:11 --> URI Class Initialized
DEBUG - 2017-01-31 03:44:11 --> No URI present. Default controller set.
INFO - 2017-01-31 03:44:11 --> Router Class Initialized
INFO - 2017-01-31 03:44:11 --> Output Class Initialized
INFO - 2017-01-31 03:44:11 --> Security Class Initialized
DEBUG - 2017-01-31 03:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:44:11 --> Input Class Initialized
INFO - 2017-01-31 03:44:11 --> Language Class Initialized
INFO - 2017-01-31 03:44:11 --> Loader Class Initialized
INFO - 2017-01-31 03:44:11 --> Database Driver Class Initialized
INFO - 2017-01-31 03:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:44:11 --> Controller Class Initialized
INFO - 2017-01-31 03:44:11 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:44:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:44:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:44:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:44:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:44:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:44:11 --> Final output sent to browser
DEBUG - 2017-01-31 03:44:11 --> Total execution time: 0.0141
INFO - 2017-01-31 03:44:15 --> Config Class Initialized
INFO - 2017-01-31 03:44:15 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:44:15 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:44:15 --> Utf8 Class Initialized
INFO - 2017-01-31 03:44:15 --> URI Class Initialized
DEBUG - 2017-01-31 03:44:15 --> No URI present. Default controller set.
INFO - 2017-01-31 03:44:15 --> Router Class Initialized
INFO - 2017-01-31 03:44:15 --> Output Class Initialized
INFO - 2017-01-31 03:44:15 --> Security Class Initialized
DEBUG - 2017-01-31 03:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:44:15 --> Input Class Initialized
INFO - 2017-01-31 03:44:15 --> Language Class Initialized
INFO - 2017-01-31 03:44:15 --> Loader Class Initialized
INFO - 2017-01-31 03:44:15 --> Database Driver Class Initialized
INFO - 2017-01-31 03:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:44:15 --> Controller Class Initialized
INFO - 2017-01-31 03:44:15 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:44:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:44:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:44:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:44:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:44:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:44:15 --> Final output sent to browser
DEBUG - 2017-01-31 03:44:15 --> Total execution time: 0.0142
INFO - 2017-01-31 03:44:20 --> Config Class Initialized
INFO - 2017-01-31 03:44:20 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:44:20 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:44:20 --> Utf8 Class Initialized
INFO - 2017-01-31 03:44:20 --> URI Class Initialized
INFO - 2017-01-31 03:44:20 --> Router Class Initialized
INFO - 2017-01-31 03:44:20 --> Output Class Initialized
INFO - 2017-01-31 03:44:20 --> Security Class Initialized
DEBUG - 2017-01-31 03:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:44:20 --> Input Class Initialized
INFO - 2017-01-31 03:44:20 --> Language Class Initialized
INFO - 2017-01-31 03:44:20 --> Loader Class Initialized
INFO - 2017-01-31 03:44:20 --> Database Driver Class Initialized
INFO - 2017-01-31 03:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:44:20 --> Controller Class Initialized
INFO - 2017-01-31 03:44:20 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:44:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:44:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:44:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:44:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:44:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:44:20 --> Final output sent to browser
DEBUG - 2017-01-31 03:44:20 --> Total execution time: 0.0134
INFO - 2017-01-31 03:44:27 --> Config Class Initialized
INFO - 2017-01-31 03:44:27 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:44:27 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:44:27 --> Utf8 Class Initialized
INFO - 2017-01-31 03:44:27 --> URI Class Initialized
INFO - 2017-01-31 03:44:27 --> Router Class Initialized
INFO - 2017-01-31 03:44:27 --> Output Class Initialized
INFO - 2017-01-31 03:44:27 --> Security Class Initialized
DEBUG - 2017-01-31 03:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:44:27 --> Input Class Initialized
INFO - 2017-01-31 03:44:27 --> Language Class Initialized
INFO - 2017-01-31 03:44:27 --> Loader Class Initialized
INFO - 2017-01-31 03:44:27 --> Database Driver Class Initialized
INFO - 2017-01-31 03:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:44:27 --> Controller Class Initialized
INFO - 2017-01-31 03:44:27 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:44:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:44:27 --> Config Class Initialized
INFO - 2017-01-31 03:44:27 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:44:27 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:44:27 --> Utf8 Class Initialized
INFO - 2017-01-31 03:44:27 --> URI Class Initialized
INFO - 2017-01-31 03:44:27 --> Router Class Initialized
INFO - 2017-01-31 03:44:27 --> Output Class Initialized
INFO - 2017-01-31 03:44:27 --> Security Class Initialized
DEBUG - 2017-01-31 03:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:44:27 --> Input Class Initialized
INFO - 2017-01-31 03:44:27 --> Language Class Initialized
INFO - 2017-01-31 03:44:27 --> Loader Class Initialized
INFO - 2017-01-31 03:44:27 --> Database Driver Class Initialized
INFO - 2017-01-31 03:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:44:27 --> Controller Class Initialized
INFO - 2017-01-31 03:44:27 --> Helper loaded: date_helper
DEBUG - 2017-01-31 03:44:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:44:27 --> Helper loaded: url_helper
INFO - 2017-01-31 03:44:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:44:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 03:44:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 03:44:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 03:44:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:44:27 --> Final output sent to browser
DEBUG - 2017-01-31 03:44:27 --> Total execution time: 0.0152
INFO - 2017-01-31 03:44:29 --> Config Class Initialized
INFO - 2017-01-31 03:44:29 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:44:29 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:44:29 --> Utf8 Class Initialized
INFO - 2017-01-31 03:44:29 --> URI Class Initialized
INFO - 2017-01-31 03:44:29 --> Router Class Initialized
INFO - 2017-01-31 03:44:29 --> Output Class Initialized
INFO - 2017-01-31 03:44:29 --> Security Class Initialized
DEBUG - 2017-01-31 03:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:44:29 --> Input Class Initialized
INFO - 2017-01-31 03:44:29 --> Language Class Initialized
INFO - 2017-01-31 03:44:29 --> Loader Class Initialized
INFO - 2017-01-31 03:44:29 --> Database Driver Class Initialized
INFO - 2017-01-31 03:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:44:29 --> Controller Class Initialized
INFO - 2017-01-31 03:44:29 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:44:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:44:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:44:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:44:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:44:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:44:29 --> Final output sent to browser
DEBUG - 2017-01-31 03:44:29 --> Total execution time: 0.0134
INFO - 2017-01-31 03:44:31 --> Config Class Initialized
INFO - 2017-01-31 03:44:31 --> Hooks Class Initialized
DEBUG - 2017-01-31 03:44:31 --> UTF-8 Support Enabled
INFO - 2017-01-31 03:44:31 --> Utf8 Class Initialized
INFO - 2017-01-31 03:44:31 --> URI Class Initialized
DEBUG - 2017-01-31 03:44:31 --> No URI present. Default controller set.
INFO - 2017-01-31 03:44:31 --> Router Class Initialized
INFO - 2017-01-31 03:44:31 --> Output Class Initialized
INFO - 2017-01-31 03:44:31 --> Security Class Initialized
DEBUG - 2017-01-31 03:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 03:44:31 --> Input Class Initialized
INFO - 2017-01-31 03:44:31 --> Language Class Initialized
INFO - 2017-01-31 03:44:31 --> Loader Class Initialized
INFO - 2017-01-31 03:44:31 --> Database Driver Class Initialized
INFO - 2017-01-31 03:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 03:44:31 --> Controller Class Initialized
INFO - 2017-01-31 03:44:31 --> Helper loaded: url_helper
DEBUG - 2017-01-31 03:44:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 03:44:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 03:44:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 03:44:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 03:44:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 03:44:31 --> Final output sent to browser
DEBUG - 2017-01-31 03:44:31 --> Total execution time: 0.0137
INFO - 2017-01-31 04:46:56 --> Config Class Initialized
INFO - 2017-01-31 04:46:56 --> Hooks Class Initialized
DEBUG - 2017-01-31 04:46:56 --> UTF-8 Support Enabled
INFO - 2017-01-31 04:46:56 --> Utf8 Class Initialized
INFO - 2017-01-31 04:46:56 --> URI Class Initialized
INFO - 2017-01-31 04:46:56 --> Router Class Initialized
INFO - 2017-01-31 04:46:56 --> Output Class Initialized
INFO - 2017-01-31 04:46:56 --> Security Class Initialized
DEBUG - 2017-01-31 04:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 04:46:56 --> Input Class Initialized
INFO - 2017-01-31 04:46:56 --> Language Class Initialized
INFO - 2017-01-31 04:46:56 --> Loader Class Initialized
INFO - 2017-01-31 04:46:56 --> Database Driver Class Initialized
INFO - 2017-01-31 04:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 04:46:56 --> Controller Class Initialized
INFO - 2017-01-31 04:46:56 --> Helper loaded: date_helper
DEBUG - 2017-01-31 04:46:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 04:46:56 --> Helper loaded: url_helper
INFO - 2017-01-31 04:46:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 04:46:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 04:46:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 04:46:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 04:46:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 04:46:56 --> Final output sent to browser
DEBUG - 2017-01-31 04:46:56 --> Total execution time: 0.0272
INFO - 2017-01-31 04:48:23 --> Config Class Initialized
INFO - 2017-01-31 04:48:23 --> Hooks Class Initialized
DEBUG - 2017-01-31 04:48:23 --> UTF-8 Support Enabled
INFO - 2017-01-31 04:48:23 --> Utf8 Class Initialized
INFO - 2017-01-31 04:48:23 --> URI Class Initialized
INFO - 2017-01-31 04:48:23 --> Router Class Initialized
INFO - 2017-01-31 04:48:23 --> Output Class Initialized
INFO - 2017-01-31 04:48:23 --> Security Class Initialized
DEBUG - 2017-01-31 04:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 04:48:23 --> Input Class Initialized
INFO - 2017-01-31 04:48:23 --> Language Class Initialized
INFO - 2017-01-31 04:48:23 --> Loader Class Initialized
INFO - 2017-01-31 04:48:23 --> Database Driver Class Initialized
INFO - 2017-01-31 04:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 04:48:23 --> Controller Class Initialized
INFO - 2017-01-31 04:48:23 --> Helper loaded: date_helper
DEBUG - 2017-01-31 04:48:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 04:48:23 --> Helper loaded: url_helper
INFO - 2017-01-31 04:48:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 04:48:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 04:48:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 04:48:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 04:48:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 04:48:23 --> Final output sent to browser
DEBUG - 2017-01-31 04:48:23 --> Total execution time: 0.0139
INFO - 2017-01-31 04:49:24 --> Config Class Initialized
INFO - 2017-01-31 04:49:24 --> Hooks Class Initialized
DEBUG - 2017-01-31 04:49:24 --> UTF-8 Support Enabled
INFO - 2017-01-31 04:49:24 --> Utf8 Class Initialized
INFO - 2017-01-31 04:49:24 --> URI Class Initialized
DEBUG - 2017-01-31 04:49:24 --> No URI present. Default controller set.
INFO - 2017-01-31 04:49:24 --> Router Class Initialized
INFO - 2017-01-31 04:49:24 --> Output Class Initialized
INFO - 2017-01-31 04:49:24 --> Security Class Initialized
DEBUG - 2017-01-31 04:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 04:49:24 --> Input Class Initialized
INFO - 2017-01-31 04:49:24 --> Language Class Initialized
INFO - 2017-01-31 04:49:24 --> Loader Class Initialized
INFO - 2017-01-31 04:49:24 --> Database Driver Class Initialized
INFO - 2017-01-31 04:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 04:49:24 --> Controller Class Initialized
INFO - 2017-01-31 04:49:24 --> Helper loaded: url_helper
DEBUG - 2017-01-31 04:49:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 04:49:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 04:49:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 04:49:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 04:49:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 04:49:24 --> Final output sent to browser
DEBUG - 2017-01-31 04:49:24 --> Total execution time: 0.0135
INFO - 2017-01-31 05:40:18 --> Config Class Initialized
INFO - 2017-01-31 05:40:18 --> Hooks Class Initialized
DEBUG - 2017-01-31 05:40:18 --> UTF-8 Support Enabled
INFO - 2017-01-31 05:40:18 --> Utf8 Class Initialized
INFO - 2017-01-31 05:40:18 --> URI Class Initialized
DEBUG - 2017-01-31 05:40:18 --> No URI present. Default controller set.
INFO - 2017-01-31 05:40:18 --> Router Class Initialized
INFO - 2017-01-31 05:40:18 --> Output Class Initialized
INFO - 2017-01-31 05:40:18 --> Security Class Initialized
DEBUG - 2017-01-31 05:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 05:40:18 --> Input Class Initialized
INFO - 2017-01-31 05:40:18 --> Language Class Initialized
INFO - 2017-01-31 05:40:18 --> Loader Class Initialized
INFO - 2017-01-31 05:40:18 --> Database Driver Class Initialized
INFO - 2017-01-31 05:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 05:40:18 --> Controller Class Initialized
INFO - 2017-01-31 05:40:18 --> Helper loaded: url_helper
DEBUG - 2017-01-31 05:40:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 05:40:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 05:40:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 05:40:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 05:40:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 05:40:18 --> Final output sent to browser
DEBUG - 2017-01-31 05:40:18 --> Total execution time: 0.0131
INFO - 2017-01-31 05:40:22 --> Config Class Initialized
INFO - 2017-01-31 05:40:22 --> Hooks Class Initialized
DEBUG - 2017-01-31 05:40:22 --> UTF-8 Support Enabled
INFO - 2017-01-31 05:40:22 --> Utf8 Class Initialized
INFO - 2017-01-31 05:40:22 --> URI Class Initialized
INFO - 2017-01-31 05:40:22 --> Router Class Initialized
INFO - 2017-01-31 05:40:22 --> Output Class Initialized
INFO - 2017-01-31 05:40:22 --> Security Class Initialized
DEBUG - 2017-01-31 05:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 05:40:22 --> Input Class Initialized
INFO - 2017-01-31 05:40:22 --> Language Class Initialized
INFO - 2017-01-31 05:40:22 --> Loader Class Initialized
INFO - 2017-01-31 05:40:22 --> Database Driver Class Initialized
INFO - 2017-01-31 05:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 05:40:22 --> Controller Class Initialized
INFO - 2017-01-31 05:40:22 --> Helper loaded: url_helper
DEBUG - 2017-01-31 05:40:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 05:40:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 05:40:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 05:40:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 05:40:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 05:40:22 --> Final output sent to browser
DEBUG - 2017-01-31 05:40:22 --> Total execution time: 0.0137
INFO - 2017-01-31 05:43:24 --> Config Class Initialized
INFO - 2017-01-31 05:43:24 --> Hooks Class Initialized
DEBUG - 2017-01-31 05:43:24 --> UTF-8 Support Enabled
INFO - 2017-01-31 05:43:24 --> Utf8 Class Initialized
INFO - 2017-01-31 05:43:24 --> URI Class Initialized
INFO - 2017-01-31 05:43:24 --> Router Class Initialized
INFO - 2017-01-31 05:43:24 --> Output Class Initialized
INFO - 2017-01-31 05:43:24 --> Security Class Initialized
DEBUG - 2017-01-31 05:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 05:43:24 --> Input Class Initialized
INFO - 2017-01-31 05:43:24 --> Language Class Initialized
INFO - 2017-01-31 05:43:24 --> Loader Class Initialized
INFO - 2017-01-31 05:43:24 --> Database Driver Class Initialized
INFO - 2017-01-31 05:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 05:43:24 --> Controller Class Initialized
INFO - 2017-01-31 05:43:24 --> Helper loaded: url_helper
DEBUG - 2017-01-31 05:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 05:43:25 --> Config Class Initialized
INFO - 2017-01-31 05:43:25 --> Hooks Class Initialized
DEBUG - 2017-01-31 05:43:25 --> UTF-8 Support Enabled
INFO - 2017-01-31 05:43:25 --> Utf8 Class Initialized
INFO - 2017-01-31 05:43:25 --> URI Class Initialized
INFO - 2017-01-31 05:43:25 --> Router Class Initialized
INFO - 2017-01-31 05:43:25 --> Output Class Initialized
INFO - 2017-01-31 05:43:25 --> Security Class Initialized
DEBUG - 2017-01-31 05:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 05:43:25 --> Input Class Initialized
INFO - 2017-01-31 05:43:25 --> Language Class Initialized
INFO - 2017-01-31 05:43:25 --> Loader Class Initialized
INFO - 2017-01-31 05:43:25 --> Database Driver Class Initialized
INFO - 2017-01-31 05:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 05:43:25 --> Controller Class Initialized
INFO - 2017-01-31 05:43:25 --> Helper loaded: date_helper
DEBUG - 2017-01-31 05:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 05:43:25 --> Helper loaded: url_helper
INFO - 2017-01-31 05:43:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 05:43:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 05:43:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 05:43:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 05:43:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 05:43:25 --> Final output sent to browser
DEBUG - 2017-01-31 05:43:25 --> Total execution time: 0.0136
INFO - 2017-01-31 05:43:26 --> Config Class Initialized
INFO - 2017-01-31 05:43:26 --> Hooks Class Initialized
DEBUG - 2017-01-31 05:43:26 --> UTF-8 Support Enabled
INFO - 2017-01-31 05:43:26 --> Utf8 Class Initialized
INFO - 2017-01-31 05:43:26 --> URI Class Initialized
INFO - 2017-01-31 05:43:26 --> Router Class Initialized
INFO - 2017-01-31 05:43:26 --> Output Class Initialized
INFO - 2017-01-31 05:43:26 --> Security Class Initialized
DEBUG - 2017-01-31 05:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 05:43:26 --> Input Class Initialized
INFO - 2017-01-31 05:43:26 --> Language Class Initialized
INFO - 2017-01-31 05:43:26 --> Loader Class Initialized
INFO - 2017-01-31 05:43:26 --> Database Driver Class Initialized
INFO - 2017-01-31 05:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 05:43:26 --> Controller Class Initialized
INFO - 2017-01-31 05:43:26 --> Helper loaded: url_helper
DEBUG - 2017-01-31 05:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 05:43:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 05:43:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 05:43:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 05:43:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 05:43:26 --> Final output sent to browser
DEBUG - 2017-01-31 05:43:26 --> Total execution time: 0.0139
INFO - 2017-01-31 05:44:14 --> Config Class Initialized
INFO - 2017-01-31 05:44:14 --> Hooks Class Initialized
DEBUG - 2017-01-31 05:44:14 --> UTF-8 Support Enabled
INFO - 2017-01-31 05:44:14 --> Utf8 Class Initialized
INFO - 2017-01-31 05:44:14 --> URI Class Initialized
DEBUG - 2017-01-31 05:44:14 --> No URI present. Default controller set.
INFO - 2017-01-31 05:44:14 --> Router Class Initialized
INFO - 2017-01-31 05:44:14 --> Output Class Initialized
INFO - 2017-01-31 05:44:14 --> Security Class Initialized
DEBUG - 2017-01-31 05:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 05:44:14 --> Input Class Initialized
INFO - 2017-01-31 05:44:14 --> Language Class Initialized
INFO - 2017-01-31 05:44:14 --> Loader Class Initialized
INFO - 2017-01-31 05:44:14 --> Database Driver Class Initialized
INFO - 2017-01-31 05:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 05:44:14 --> Controller Class Initialized
INFO - 2017-01-31 05:44:14 --> Helper loaded: url_helper
DEBUG - 2017-01-31 05:44:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 05:44:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 05:44:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 05:44:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 05:44:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 05:44:14 --> Final output sent to browser
DEBUG - 2017-01-31 05:44:14 --> Total execution time: 0.0132
INFO - 2017-01-31 05:44:15 --> Config Class Initialized
INFO - 2017-01-31 05:44:15 --> Hooks Class Initialized
DEBUG - 2017-01-31 05:44:15 --> UTF-8 Support Enabled
INFO - 2017-01-31 05:44:15 --> Utf8 Class Initialized
INFO - 2017-01-31 05:44:15 --> URI Class Initialized
INFO - 2017-01-31 05:44:15 --> Router Class Initialized
INFO - 2017-01-31 05:44:15 --> Output Class Initialized
INFO - 2017-01-31 05:44:15 --> Security Class Initialized
DEBUG - 2017-01-31 05:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 05:44:15 --> Input Class Initialized
INFO - 2017-01-31 05:44:15 --> Language Class Initialized
INFO - 2017-01-31 05:44:15 --> Loader Class Initialized
INFO - 2017-01-31 05:44:15 --> Database Driver Class Initialized
INFO - 2017-01-31 05:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 05:44:15 --> Controller Class Initialized
INFO - 2017-01-31 05:44:15 --> Helper loaded: url_helper
DEBUG - 2017-01-31 05:44:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 05:44:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 05:44:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 05:44:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 05:44:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 05:44:15 --> Final output sent to browser
DEBUG - 2017-01-31 05:44:15 --> Total execution time: 0.0132
INFO - 2017-01-31 05:44:32 --> Config Class Initialized
INFO - 2017-01-31 05:44:32 --> Hooks Class Initialized
DEBUG - 2017-01-31 05:44:32 --> UTF-8 Support Enabled
INFO - 2017-01-31 05:44:32 --> Utf8 Class Initialized
INFO - 2017-01-31 05:44:32 --> URI Class Initialized
INFO - 2017-01-31 05:44:32 --> Router Class Initialized
INFO - 2017-01-31 05:44:32 --> Output Class Initialized
INFO - 2017-01-31 05:44:32 --> Security Class Initialized
DEBUG - 2017-01-31 05:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 05:44:32 --> Input Class Initialized
INFO - 2017-01-31 05:44:32 --> Language Class Initialized
INFO - 2017-01-31 05:44:32 --> Loader Class Initialized
INFO - 2017-01-31 05:44:32 --> Database Driver Class Initialized
INFO - 2017-01-31 05:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 05:44:32 --> Controller Class Initialized
INFO - 2017-01-31 05:44:32 --> Helper loaded: url_helper
DEBUG - 2017-01-31 05:44:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 05:44:33 --> Config Class Initialized
INFO - 2017-01-31 05:44:33 --> Hooks Class Initialized
DEBUG - 2017-01-31 05:44:33 --> UTF-8 Support Enabled
INFO - 2017-01-31 05:44:33 --> Utf8 Class Initialized
INFO - 2017-01-31 05:44:33 --> URI Class Initialized
INFO - 2017-01-31 05:44:33 --> Router Class Initialized
INFO - 2017-01-31 05:44:33 --> Output Class Initialized
INFO - 2017-01-31 05:44:33 --> Security Class Initialized
DEBUG - 2017-01-31 05:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 05:44:33 --> Input Class Initialized
INFO - 2017-01-31 05:44:33 --> Language Class Initialized
INFO - 2017-01-31 05:44:33 --> Loader Class Initialized
INFO - 2017-01-31 05:44:33 --> Database Driver Class Initialized
INFO - 2017-01-31 05:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 05:44:33 --> Controller Class Initialized
INFO - 2017-01-31 05:44:33 --> Helper loaded: date_helper
DEBUG - 2017-01-31 05:44:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 05:44:33 --> Helper loaded: url_helper
INFO - 2017-01-31 05:44:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 05:44:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 05:44:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 05:44:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 05:44:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 05:44:33 --> Final output sent to browser
DEBUG - 2017-01-31 05:44:33 --> Total execution time: 0.0131
INFO - 2017-01-31 05:44:33 --> Config Class Initialized
INFO - 2017-01-31 05:44:33 --> Hooks Class Initialized
DEBUG - 2017-01-31 05:44:33 --> UTF-8 Support Enabled
INFO - 2017-01-31 05:44:33 --> Utf8 Class Initialized
INFO - 2017-01-31 05:44:33 --> URI Class Initialized
INFO - 2017-01-31 05:44:33 --> Router Class Initialized
INFO - 2017-01-31 05:44:33 --> Output Class Initialized
INFO - 2017-01-31 05:44:33 --> Security Class Initialized
DEBUG - 2017-01-31 05:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 05:44:33 --> Input Class Initialized
INFO - 2017-01-31 05:44:33 --> Language Class Initialized
INFO - 2017-01-31 05:44:33 --> Loader Class Initialized
INFO - 2017-01-31 05:44:33 --> Database Driver Class Initialized
INFO - 2017-01-31 05:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 05:44:33 --> Controller Class Initialized
INFO - 2017-01-31 05:44:33 --> Helper loaded: url_helper
DEBUG - 2017-01-31 05:44:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 05:44:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 05:44:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 05:44:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 05:44:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 05:44:33 --> Final output sent to browser
DEBUG - 2017-01-31 05:44:33 --> Total execution time: 0.0134
INFO - 2017-01-31 06:44:13 --> Config Class Initialized
INFO - 2017-01-31 06:44:13 --> Hooks Class Initialized
DEBUG - 2017-01-31 06:44:13 --> UTF-8 Support Enabled
INFO - 2017-01-31 06:44:13 --> Utf8 Class Initialized
INFO - 2017-01-31 06:44:13 --> URI Class Initialized
INFO - 2017-01-31 06:44:13 --> Router Class Initialized
INFO - 2017-01-31 06:44:13 --> Output Class Initialized
INFO - 2017-01-31 06:44:13 --> Security Class Initialized
DEBUG - 2017-01-31 06:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 06:44:13 --> Input Class Initialized
INFO - 2017-01-31 06:44:13 --> Language Class Initialized
INFO - 2017-01-31 06:44:13 --> Loader Class Initialized
INFO - 2017-01-31 06:44:13 --> Database Driver Class Initialized
INFO - 2017-01-31 06:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 06:44:13 --> Controller Class Initialized
INFO - 2017-01-31 06:44:13 --> Helper loaded: date_helper
DEBUG - 2017-01-31 06:44:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 06:44:13 --> Helper loaded: url_helper
INFO - 2017-01-31 06:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 06:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 06:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 06:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 06:44:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 06:44:13 --> Final output sent to browser
DEBUG - 2017-01-31 06:44:13 --> Total execution time: 0.0140
INFO - 2017-01-31 06:44:15 --> Config Class Initialized
INFO - 2017-01-31 06:44:15 --> Hooks Class Initialized
DEBUG - 2017-01-31 06:44:15 --> UTF-8 Support Enabled
INFO - 2017-01-31 06:44:15 --> Utf8 Class Initialized
INFO - 2017-01-31 06:44:15 --> URI Class Initialized
INFO - 2017-01-31 06:44:15 --> Router Class Initialized
INFO - 2017-01-31 06:44:15 --> Output Class Initialized
INFO - 2017-01-31 06:44:15 --> Security Class Initialized
DEBUG - 2017-01-31 06:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 06:44:15 --> Input Class Initialized
INFO - 2017-01-31 06:44:15 --> Language Class Initialized
INFO - 2017-01-31 06:44:15 --> Loader Class Initialized
INFO - 2017-01-31 06:44:15 --> Database Driver Class Initialized
INFO - 2017-01-31 06:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 06:44:15 --> Controller Class Initialized
INFO - 2017-01-31 06:44:15 --> Helper loaded: url_helper
DEBUG - 2017-01-31 06:44:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 06:44:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 06:44:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 06:44:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 06:44:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 06:44:15 --> Final output sent to browser
DEBUG - 2017-01-31 06:44:15 --> Total execution time: 0.0134
INFO - 2017-01-31 08:27:45 --> Config Class Initialized
INFO - 2017-01-31 08:27:45 --> Hooks Class Initialized
DEBUG - 2017-01-31 08:27:45 --> UTF-8 Support Enabled
INFO - 2017-01-31 08:27:45 --> Utf8 Class Initialized
INFO - 2017-01-31 08:27:45 --> URI Class Initialized
INFO - 2017-01-31 08:27:45 --> Router Class Initialized
INFO - 2017-01-31 08:27:45 --> Output Class Initialized
INFO - 2017-01-31 08:27:45 --> Security Class Initialized
DEBUG - 2017-01-31 08:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 08:27:45 --> Input Class Initialized
INFO - 2017-01-31 08:27:45 --> Language Class Initialized
INFO - 2017-01-31 08:27:45 --> Loader Class Initialized
INFO - 2017-01-31 08:27:45 --> Database Driver Class Initialized
INFO - 2017-01-31 08:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 08:27:45 --> Controller Class Initialized
INFO - 2017-01-31 08:27:45 --> Helper loaded: url_helper
DEBUG - 2017-01-31 08:27:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 08:27:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 08:27:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 08:27:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 08:27:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 08:27:45 --> Final output sent to browser
DEBUG - 2017-01-31 08:27:45 --> Total execution time: 0.0135
INFO - 2017-01-31 08:27:45 --> Config Class Initialized
INFO - 2017-01-31 08:27:45 --> Hooks Class Initialized
DEBUG - 2017-01-31 08:27:45 --> UTF-8 Support Enabled
INFO - 2017-01-31 08:27:45 --> Utf8 Class Initialized
INFO - 2017-01-31 08:27:45 --> URI Class Initialized
INFO - 2017-01-31 08:27:45 --> Router Class Initialized
INFO - 2017-01-31 08:27:45 --> Output Class Initialized
INFO - 2017-01-31 08:27:45 --> Security Class Initialized
DEBUG - 2017-01-31 08:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 08:27:45 --> Input Class Initialized
INFO - 2017-01-31 08:27:45 --> Language Class Initialized
INFO - 2017-01-31 08:27:45 --> Loader Class Initialized
INFO - 2017-01-31 08:27:45 --> Database Driver Class Initialized
INFO - 2017-01-31 08:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 08:27:45 --> Controller Class Initialized
INFO - 2017-01-31 08:27:45 --> Helper loaded: url_helper
DEBUG - 2017-01-31 08:27:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 08:27:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 08:27:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 08:27:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 08:27:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 08:27:45 --> Final output sent to browser
DEBUG - 2017-01-31 08:27:45 --> Total execution time: 0.0207
INFO - 2017-01-31 09:53:30 --> Config Class Initialized
INFO - 2017-01-31 09:53:30 --> Hooks Class Initialized
DEBUG - 2017-01-31 09:53:30 --> UTF-8 Support Enabled
INFO - 2017-01-31 09:53:30 --> Utf8 Class Initialized
INFO - 2017-01-31 09:53:30 --> URI Class Initialized
DEBUG - 2017-01-31 09:53:30 --> No URI present. Default controller set.
INFO - 2017-01-31 09:53:30 --> Router Class Initialized
INFO - 2017-01-31 09:53:30 --> Output Class Initialized
INFO - 2017-01-31 09:53:30 --> Security Class Initialized
DEBUG - 2017-01-31 09:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 09:53:30 --> Input Class Initialized
INFO - 2017-01-31 09:53:30 --> Language Class Initialized
INFO - 2017-01-31 09:53:30 --> Loader Class Initialized
INFO - 2017-01-31 09:53:31 --> Database Driver Class Initialized
INFO - 2017-01-31 09:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 09:53:32 --> Controller Class Initialized
INFO - 2017-01-31 09:53:32 --> Helper loaded: url_helper
DEBUG - 2017-01-31 09:53:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 09:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 09:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 09:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 09:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 09:53:32 --> Final output sent to browser
DEBUG - 2017-01-31 09:53:32 --> Total execution time: 2.2842
INFO - 2017-01-31 11:49:48 --> Config Class Initialized
INFO - 2017-01-31 11:49:48 --> Hooks Class Initialized
DEBUG - 2017-01-31 11:49:49 --> UTF-8 Support Enabled
INFO - 2017-01-31 11:49:49 --> Utf8 Class Initialized
INFO - 2017-01-31 11:49:49 --> URI Class Initialized
INFO - 2017-01-31 11:49:49 --> Router Class Initialized
INFO - 2017-01-31 11:49:49 --> Output Class Initialized
INFO - 2017-01-31 11:49:49 --> Security Class Initialized
DEBUG - 2017-01-31 11:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 11:49:49 --> Input Class Initialized
INFO - 2017-01-31 11:49:49 --> Language Class Initialized
INFO - 2017-01-31 11:49:49 --> Loader Class Initialized
INFO - 2017-01-31 11:49:49 --> Database Driver Class Initialized
INFO - 2017-01-31 11:49:49 --> Config Class Initialized
INFO - 2017-01-31 11:49:49 --> Hooks Class Initialized
DEBUG - 2017-01-31 11:49:49 --> UTF-8 Support Enabled
INFO - 2017-01-31 11:49:49 --> Utf8 Class Initialized
INFO - 2017-01-31 11:49:49 --> URI Class Initialized
INFO - 2017-01-31 11:49:49 --> Router Class Initialized
INFO - 2017-01-31 11:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 11:49:49 --> Output Class Initialized
INFO - 2017-01-31 11:49:49 --> Controller Class Initialized
INFO - 2017-01-31 11:49:49 --> Security Class Initialized
INFO - 2017-01-31 11:49:49 --> Helper loaded: url_helper
DEBUG - 2017-01-31 11:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 11:49:49 --> Input Class Initialized
DEBUG - 2017-01-31 11:49:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 11:49:49 --> Language Class Initialized
INFO - 2017-01-31 11:49:49 --> Loader Class Initialized
INFO - 2017-01-31 11:49:49 --> Database Driver Class Initialized
INFO - 2017-01-31 11:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 11:49:49 --> Controller Class Initialized
INFO - 2017-01-31 11:49:49 --> Helper loaded: url_helper
DEBUG - 2017-01-31 11:49:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 11:49:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 11:49:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 11:49:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
ERROR - 2017-01-31 11:49:50 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
INFO - 2017-01-31 11:49:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
ERROR - 2017-01-31 11:49:50 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-31 11:49:50 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-31 11:49:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 11:49:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 11:49:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 11:49:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 11:49:50 --> Final output sent to browser
DEBUG - 2017-01-31 11:49:50 --> Total execution time: 0.9904
INFO - 2017-01-31 11:49:50 --> Final output sent to browser
DEBUG - 2017-01-31 11:49:50 --> Total execution time: 1.5954
INFO - 2017-01-31 15:31:31 --> Config Class Initialized
INFO - 2017-01-31 15:31:31 --> Hooks Class Initialized
DEBUG - 2017-01-31 15:31:31 --> UTF-8 Support Enabled
INFO - 2017-01-31 15:31:31 --> Utf8 Class Initialized
INFO - 2017-01-31 15:31:31 --> URI Class Initialized
DEBUG - 2017-01-31 15:31:31 --> No URI present. Default controller set.
INFO - 2017-01-31 15:31:31 --> Router Class Initialized
INFO - 2017-01-31 15:31:31 --> Output Class Initialized
INFO - 2017-01-31 15:31:31 --> Security Class Initialized
DEBUG - 2017-01-31 15:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 15:31:31 --> Input Class Initialized
INFO - 2017-01-31 15:31:31 --> Language Class Initialized
INFO - 2017-01-31 15:31:31 --> Loader Class Initialized
INFO - 2017-01-31 15:31:32 --> Database Driver Class Initialized
INFO - 2017-01-31 15:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 15:31:32 --> Controller Class Initialized
INFO - 2017-01-31 15:31:32 --> Helper loaded: url_helper
DEBUG - 2017-01-31 15:31:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 15:31:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 15:31:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 15:31:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 15:31:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 15:31:33 --> Final output sent to browser
DEBUG - 2017-01-31 15:31:33 --> Total execution time: 1.8450
INFO - 2017-01-31 16:21:00 --> Config Class Initialized
INFO - 2017-01-31 16:21:00 --> Hooks Class Initialized
DEBUG - 2017-01-31 16:21:01 --> UTF-8 Support Enabled
INFO - 2017-01-31 16:21:01 --> Utf8 Class Initialized
INFO - 2017-01-31 16:21:01 --> URI Class Initialized
INFO - 2017-01-31 16:21:01 --> Router Class Initialized
INFO - 2017-01-31 16:21:01 --> Output Class Initialized
INFO - 2017-01-31 16:21:01 --> Security Class Initialized
DEBUG - 2017-01-31 16:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 16:21:01 --> Input Class Initialized
INFO - 2017-01-31 16:21:01 --> Language Class Initialized
INFO - 2017-01-31 16:21:01 --> Loader Class Initialized
INFO - 2017-01-31 16:21:02 --> Database Driver Class Initialized
INFO - 2017-01-31 16:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 16:21:02 --> Controller Class Initialized
INFO - 2017-01-31 16:21:02 --> Helper loaded: url_helper
DEBUG - 2017-01-31 16:21:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 16:21:02 --> Helper loaded: form_helper
INFO - 2017-01-31 16:21:02 --> Form Validation Class Initialized
INFO - 2017-01-31 16:21:02 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-31 16:21:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-31 16:21:03 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-31 16:21:03 --> Final output sent to browser
DEBUG - 2017-01-31 16:21:03 --> Total execution time: 2.2408
INFO - 2017-01-31 16:21:03 --> Config Class Initialized
INFO - 2017-01-31 16:21:03 --> Hooks Class Initialized
DEBUG - 2017-01-31 16:21:03 --> UTF-8 Support Enabled
INFO - 2017-01-31 16:21:03 --> Utf8 Class Initialized
INFO - 2017-01-31 16:21:03 --> URI Class Initialized
INFO - 2017-01-31 16:21:03 --> Router Class Initialized
INFO - 2017-01-31 16:21:03 --> Output Class Initialized
INFO - 2017-01-31 16:21:03 --> Security Class Initialized
DEBUG - 2017-01-31 16:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 16:21:03 --> Input Class Initialized
INFO - 2017-01-31 16:21:03 --> Language Class Initialized
INFO - 2017-01-31 16:21:03 --> Loader Class Initialized
INFO - 2017-01-31 16:21:03 --> Database Driver Class Initialized
INFO - 2017-01-31 16:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 16:21:03 --> Controller Class Initialized
INFO - 2017-01-31 16:21:03 --> Helper loaded: url_helper
DEBUG - 2017-01-31 16:21:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 16:21:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 16:21:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 16:21:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 16:21:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 16:21:03 --> Final output sent to browser
DEBUG - 2017-01-31 16:21:03 --> Total execution time: 0.2811
INFO - 2017-01-31 17:01:00 --> Config Class Initialized
INFO - 2017-01-31 17:01:00 --> Hooks Class Initialized
DEBUG - 2017-01-31 17:01:00 --> UTF-8 Support Enabled
INFO - 2017-01-31 17:01:00 --> Utf8 Class Initialized
INFO - 2017-01-31 17:01:00 --> URI Class Initialized
DEBUG - 2017-01-31 17:01:00 --> No URI present. Default controller set.
INFO - 2017-01-31 17:01:00 --> Router Class Initialized
INFO - 2017-01-31 17:01:00 --> Output Class Initialized
INFO - 2017-01-31 17:01:00 --> Security Class Initialized
DEBUG - 2017-01-31 17:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 17:01:00 --> Input Class Initialized
INFO - 2017-01-31 17:01:00 --> Language Class Initialized
INFO - 2017-01-31 17:01:00 --> Loader Class Initialized
INFO - 2017-01-31 17:01:00 --> Database Driver Class Initialized
INFO - 2017-01-31 17:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 17:01:00 --> Controller Class Initialized
INFO - 2017-01-31 17:01:00 --> Helper loaded: url_helper
DEBUG - 2017-01-31 17:01:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 17:01:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 17:01:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 17:01:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 17:01:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 17:01:00 --> Final output sent to browser
DEBUG - 2017-01-31 17:01:00 --> Total execution time: 0.0242
INFO - 2017-01-31 17:01:00 --> Config Class Initialized
INFO - 2017-01-31 17:01:00 --> Hooks Class Initialized
DEBUG - 2017-01-31 17:01:00 --> UTF-8 Support Enabled
INFO - 2017-01-31 17:01:00 --> Utf8 Class Initialized
INFO - 2017-01-31 17:01:00 --> URI Class Initialized
DEBUG - 2017-01-31 17:01:00 --> No URI present. Default controller set.
INFO - 2017-01-31 17:01:00 --> Router Class Initialized
INFO - 2017-01-31 17:01:00 --> Output Class Initialized
INFO - 2017-01-31 17:01:00 --> Security Class Initialized
DEBUG - 2017-01-31 17:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 17:01:00 --> Input Class Initialized
INFO - 2017-01-31 17:01:00 --> Language Class Initialized
INFO - 2017-01-31 17:01:00 --> Loader Class Initialized
INFO - 2017-01-31 17:01:01 --> Database Driver Class Initialized
INFO - 2017-01-31 17:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 17:01:01 --> Controller Class Initialized
INFO - 2017-01-31 17:01:01 --> Helper loaded: url_helper
DEBUG - 2017-01-31 17:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 17:01:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 17:01:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 17:01:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 17:01:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 17:01:01 --> Final output sent to browser
DEBUG - 2017-01-31 17:01:01 --> Total execution time: 0.0133
INFO - 2017-01-31 17:01:01 --> Config Class Initialized
INFO - 2017-01-31 17:01:01 --> Hooks Class Initialized
DEBUG - 2017-01-31 17:01:01 --> UTF-8 Support Enabled
INFO - 2017-01-31 17:01:01 --> Utf8 Class Initialized
INFO - 2017-01-31 17:01:01 --> URI Class Initialized
DEBUG - 2017-01-31 17:01:01 --> No URI present. Default controller set.
INFO - 2017-01-31 17:01:01 --> Router Class Initialized
INFO - 2017-01-31 17:01:01 --> Output Class Initialized
INFO - 2017-01-31 17:01:01 --> Security Class Initialized
DEBUG - 2017-01-31 17:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 17:01:01 --> Input Class Initialized
INFO - 2017-01-31 17:01:01 --> Language Class Initialized
INFO - 2017-01-31 17:01:01 --> Loader Class Initialized
INFO - 2017-01-31 17:01:01 --> Database Driver Class Initialized
INFO - 2017-01-31 17:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 17:01:01 --> Controller Class Initialized
INFO - 2017-01-31 17:01:01 --> Helper loaded: url_helper
DEBUG - 2017-01-31 17:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 17:01:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 17:01:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 17:01:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 17:01:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 17:01:01 --> Final output sent to browser
DEBUG - 2017-01-31 17:01:01 --> Total execution time: 0.0700
INFO - 2017-01-31 17:01:06 --> Config Class Initialized
INFO - 2017-01-31 17:01:06 --> Hooks Class Initialized
DEBUG - 2017-01-31 17:01:06 --> UTF-8 Support Enabled
INFO - 2017-01-31 17:01:06 --> Utf8 Class Initialized
INFO - 2017-01-31 17:01:06 --> URI Class Initialized
INFO - 2017-01-31 17:01:06 --> Router Class Initialized
INFO - 2017-01-31 17:01:06 --> Output Class Initialized
INFO - 2017-01-31 17:01:06 --> Security Class Initialized
DEBUG - 2017-01-31 17:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 17:01:06 --> Input Class Initialized
INFO - 2017-01-31 17:01:06 --> Language Class Initialized
INFO - 2017-01-31 17:01:06 --> Loader Class Initialized
INFO - 2017-01-31 17:01:06 --> Database Driver Class Initialized
INFO - 2017-01-31 17:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 17:01:06 --> Controller Class Initialized
INFO - 2017-01-31 17:01:06 --> Helper loaded: url_helper
DEBUG - 2017-01-31 17:01:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 17:01:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 17:01:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 17:01:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 17:01:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 17:01:06 --> Final output sent to browser
DEBUG - 2017-01-31 17:01:06 --> Total execution time: 0.0138
INFO - 2017-01-31 17:01:10 --> Config Class Initialized
INFO - 2017-01-31 17:01:10 --> Hooks Class Initialized
DEBUG - 2017-01-31 17:01:10 --> UTF-8 Support Enabled
INFO - 2017-01-31 17:01:10 --> Utf8 Class Initialized
INFO - 2017-01-31 17:01:10 --> URI Class Initialized
INFO - 2017-01-31 17:01:10 --> Router Class Initialized
INFO - 2017-01-31 17:01:10 --> Output Class Initialized
INFO - 2017-01-31 17:01:10 --> Security Class Initialized
DEBUG - 2017-01-31 17:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 17:01:10 --> Input Class Initialized
INFO - 2017-01-31 17:01:10 --> Language Class Initialized
INFO - 2017-01-31 17:01:10 --> Loader Class Initialized
INFO - 2017-01-31 17:01:10 --> Database Driver Class Initialized
INFO - 2017-01-31 17:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 17:01:10 --> Controller Class Initialized
INFO - 2017-01-31 17:01:10 --> Helper loaded: url_helper
DEBUG - 2017-01-31 17:01:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 17:01:13 --> Config Class Initialized
INFO - 2017-01-31 17:01:13 --> Hooks Class Initialized
DEBUG - 2017-01-31 17:01:13 --> UTF-8 Support Enabled
INFO - 2017-01-31 17:01:13 --> Utf8 Class Initialized
INFO - 2017-01-31 17:01:13 --> URI Class Initialized
INFO - 2017-01-31 17:01:13 --> Router Class Initialized
INFO - 2017-01-31 17:01:13 --> Output Class Initialized
INFO - 2017-01-31 17:01:13 --> Security Class Initialized
DEBUG - 2017-01-31 17:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 17:01:13 --> Input Class Initialized
INFO - 2017-01-31 17:01:13 --> Language Class Initialized
INFO - 2017-01-31 17:01:13 --> Loader Class Initialized
INFO - 2017-01-31 17:01:13 --> Database Driver Class Initialized
INFO - 2017-01-31 17:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 17:01:13 --> Controller Class Initialized
INFO - 2017-01-31 17:01:13 --> Helper loaded: date_helper
DEBUG - 2017-01-31 17:01:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 17:01:13 --> Helper loaded: url_helper
INFO - 2017-01-31 17:01:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 17:01:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 17:01:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 17:01:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 17:01:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 17:01:13 --> Final output sent to browser
DEBUG - 2017-01-31 17:01:13 --> Total execution time: 0.1486
INFO - 2017-01-31 17:01:14 --> Config Class Initialized
INFO - 2017-01-31 17:01:14 --> Hooks Class Initialized
DEBUG - 2017-01-31 17:01:14 --> UTF-8 Support Enabled
INFO - 2017-01-31 17:01:14 --> Utf8 Class Initialized
INFO - 2017-01-31 17:01:14 --> URI Class Initialized
INFO - 2017-01-31 17:01:14 --> Router Class Initialized
INFO - 2017-01-31 17:01:14 --> Output Class Initialized
INFO - 2017-01-31 17:01:14 --> Security Class Initialized
DEBUG - 2017-01-31 17:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 17:01:14 --> Input Class Initialized
INFO - 2017-01-31 17:01:14 --> Language Class Initialized
INFO - 2017-01-31 17:01:14 --> Loader Class Initialized
INFO - 2017-01-31 17:01:14 --> Database Driver Class Initialized
INFO - 2017-01-31 17:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 17:01:14 --> Controller Class Initialized
INFO - 2017-01-31 17:01:14 --> Helper loaded: url_helper
DEBUG - 2017-01-31 17:01:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 17:01:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 17:01:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 17:01:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 17:01:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 17:01:14 --> Final output sent to browser
DEBUG - 2017-01-31 17:01:14 --> Total execution time: 0.0133
INFO - 2017-01-31 17:01:16 --> Config Class Initialized
INFO - 2017-01-31 17:01:16 --> Hooks Class Initialized
DEBUG - 2017-01-31 17:01:16 --> UTF-8 Support Enabled
INFO - 2017-01-31 17:01:16 --> Utf8 Class Initialized
INFO - 2017-01-31 17:01:16 --> URI Class Initialized
DEBUG - 2017-01-31 17:01:16 --> No URI present. Default controller set.
INFO - 2017-01-31 17:01:16 --> Router Class Initialized
INFO - 2017-01-31 17:01:16 --> Output Class Initialized
INFO - 2017-01-31 17:01:16 --> Security Class Initialized
DEBUG - 2017-01-31 17:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 17:01:16 --> Input Class Initialized
INFO - 2017-01-31 17:01:16 --> Language Class Initialized
INFO - 2017-01-31 17:01:16 --> Loader Class Initialized
INFO - 2017-01-31 17:01:16 --> Database Driver Class Initialized
INFO - 2017-01-31 17:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 17:01:16 --> Controller Class Initialized
INFO - 2017-01-31 17:01:16 --> Helper loaded: url_helper
DEBUG - 2017-01-31 17:01:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 17:01:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 17:01:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 17:01:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 17:01:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 17:01:16 --> Final output sent to browser
DEBUG - 2017-01-31 17:01:16 --> Total execution time: 0.0132
INFO - 2017-01-31 17:01:17 --> Config Class Initialized
INFO - 2017-01-31 17:01:17 --> Hooks Class Initialized
DEBUG - 2017-01-31 17:01:17 --> UTF-8 Support Enabled
INFO - 2017-01-31 17:01:17 --> Utf8 Class Initialized
INFO - 2017-01-31 17:01:17 --> URI Class Initialized
INFO - 2017-01-31 17:01:17 --> Router Class Initialized
INFO - 2017-01-31 17:01:17 --> Output Class Initialized
INFO - 2017-01-31 17:01:17 --> Security Class Initialized
DEBUG - 2017-01-31 17:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 17:01:17 --> Input Class Initialized
INFO - 2017-01-31 17:01:17 --> Language Class Initialized
INFO - 2017-01-31 17:01:17 --> Loader Class Initialized
INFO - 2017-01-31 17:01:17 --> Database Driver Class Initialized
INFO - 2017-01-31 17:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 17:01:17 --> Controller Class Initialized
INFO - 2017-01-31 17:01:17 --> Helper loaded: url_helper
DEBUG - 2017-01-31 17:01:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 17:01:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 17:01:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 17:01:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 17:01:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 17:01:17 --> Final output sent to browser
DEBUG - 2017-01-31 17:01:17 --> Total execution time: 0.0147
INFO - 2017-01-31 17:01:34 --> Config Class Initialized
INFO - 2017-01-31 17:01:34 --> Hooks Class Initialized
DEBUG - 2017-01-31 17:01:34 --> UTF-8 Support Enabled
INFO - 2017-01-31 17:01:34 --> Utf8 Class Initialized
INFO - 2017-01-31 17:01:34 --> URI Class Initialized
INFO - 2017-01-31 17:01:34 --> Router Class Initialized
INFO - 2017-01-31 17:01:34 --> Output Class Initialized
INFO - 2017-01-31 17:01:34 --> Security Class Initialized
DEBUG - 2017-01-31 17:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 17:01:34 --> Input Class Initialized
INFO - 2017-01-31 17:01:34 --> Language Class Initialized
INFO - 2017-01-31 17:01:34 --> Loader Class Initialized
INFO - 2017-01-31 17:01:34 --> Database Driver Class Initialized
INFO - 2017-01-31 17:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 17:01:34 --> Controller Class Initialized
INFO - 2017-01-31 17:01:34 --> Helper loaded: url_helper
DEBUG - 2017-01-31 17:01:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 17:01:35 --> Config Class Initialized
INFO - 2017-01-31 17:01:35 --> Hooks Class Initialized
DEBUG - 2017-01-31 17:01:35 --> UTF-8 Support Enabled
INFO - 2017-01-31 17:01:35 --> Utf8 Class Initialized
INFO - 2017-01-31 17:01:35 --> URI Class Initialized
INFO - 2017-01-31 17:01:35 --> Router Class Initialized
INFO - 2017-01-31 17:01:35 --> Output Class Initialized
INFO - 2017-01-31 17:01:35 --> Security Class Initialized
DEBUG - 2017-01-31 17:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 17:01:35 --> Input Class Initialized
INFO - 2017-01-31 17:01:35 --> Language Class Initialized
INFO - 2017-01-31 17:01:35 --> Loader Class Initialized
INFO - 2017-01-31 17:01:35 --> Database Driver Class Initialized
INFO - 2017-01-31 17:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 17:01:35 --> Controller Class Initialized
INFO - 2017-01-31 17:01:35 --> Helper loaded: date_helper
DEBUG - 2017-01-31 17:01:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 17:01:35 --> Helper loaded: url_helper
INFO - 2017-01-31 17:01:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 17:01:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 17:01:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 17:01:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 17:01:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 17:01:35 --> Final output sent to browser
DEBUG - 2017-01-31 17:01:35 --> Total execution time: 0.0135
INFO - 2017-01-31 17:01:35 --> Config Class Initialized
INFO - 2017-01-31 17:01:35 --> Hooks Class Initialized
DEBUG - 2017-01-31 17:01:35 --> UTF-8 Support Enabled
INFO - 2017-01-31 17:01:35 --> Utf8 Class Initialized
INFO - 2017-01-31 17:01:35 --> URI Class Initialized
INFO - 2017-01-31 17:01:35 --> Router Class Initialized
INFO - 2017-01-31 17:01:35 --> Output Class Initialized
INFO - 2017-01-31 17:01:35 --> Security Class Initialized
DEBUG - 2017-01-31 17:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 17:01:35 --> Input Class Initialized
INFO - 2017-01-31 17:01:35 --> Language Class Initialized
INFO - 2017-01-31 17:01:35 --> Loader Class Initialized
INFO - 2017-01-31 17:01:35 --> Database Driver Class Initialized
INFO - 2017-01-31 17:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 17:01:35 --> Controller Class Initialized
INFO - 2017-01-31 17:01:35 --> Helper loaded: url_helper
DEBUG - 2017-01-31 17:01:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 17:01:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 17:01:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 17:01:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 17:01:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 17:01:35 --> Final output sent to browser
DEBUG - 2017-01-31 17:01:35 --> Total execution time: 0.0130
INFO - 2017-01-31 17:16:04 --> Config Class Initialized
INFO - 2017-01-31 17:16:04 --> Hooks Class Initialized
DEBUG - 2017-01-31 17:16:04 --> UTF-8 Support Enabled
INFO - 2017-01-31 17:16:04 --> Utf8 Class Initialized
INFO - 2017-01-31 17:16:04 --> URI Class Initialized
DEBUG - 2017-01-31 17:16:04 --> No URI present. Default controller set.
INFO - 2017-01-31 17:16:04 --> Router Class Initialized
INFO - 2017-01-31 17:16:04 --> Output Class Initialized
INFO - 2017-01-31 17:16:04 --> Security Class Initialized
DEBUG - 2017-01-31 17:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 17:16:04 --> Input Class Initialized
INFO - 2017-01-31 17:16:04 --> Language Class Initialized
INFO - 2017-01-31 17:16:04 --> Loader Class Initialized
INFO - 2017-01-31 17:16:04 --> Database Driver Class Initialized
INFO - 2017-01-31 17:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 17:16:04 --> Controller Class Initialized
INFO - 2017-01-31 17:16:04 --> Helper loaded: url_helper
DEBUG - 2017-01-31 17:16:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 17:16:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 17:16:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 17:16:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 17:16:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 17:16:04 --> Final output sent to browser
DEBUG - 2017-01-31 17:16:04 --> Total execution time: 0.0132
INFO - 2017-01-31 17:17:18 --> Config Class Initialized
INFO - 2017-01-31 17:17:18 --> Hooks Class Initialized
DEBUG - 2017-01-31 17:17:18 --> UTF-8 Support Enabled
INFO - 2017-01-31 17:17:18 --> Utf8 Class Initialized
INFO - 2017-01-31 17:17:18 --> URI Class Initialized
DEBUG - 2017-01-31 17:17:18 --> No URI present. Default controller set.
INFO - 2017-01-31 17:17:18 --> Router Class Initialized
INFO - 2017-01-31 17:17:18 --> Output Class Initialized
INFO - 2017-01-31 17:17:18 --> Security Class Initialized
DEBUG - 2017-01-31 17:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 17:17:18 --> Input Class Initialized
INFO - 2017-01-31 17:17:18 --> Language Class Initialized
INFO - 2017-01-31 17:17:18 --> Loader Class Initialized
INFO - 2017-01-31 17:17:18 --> Database Driver Class Initialized
INFO - 2017-01-31 17:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 17:17:18 --> Controller Class Initialized
INFO - 2017-01-31 17:17:18 --> Helper loaded: url_helper
DEBUG - 2017-01-31 17:17:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 17:17:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 17:17:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 17:17:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 17:17:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 17:17:18 --> Final output sent to browser
DEBUG - 2017-01-31 17:17:18 --> Total execution time: 0.0133
INFO - 2017-01-31 17:18:02 --> Config Class Initialized
INFO - 2017-01-31 17:18:02 --> Hooks Class Initialized
DEBUG - 2017-01-31 17:18:02 --> UTF-8 Support Enabled
INFO - 2017-01-31 17:18:02 --> Utf8 Class Initialized
INFO - 2017-01-31 17:18:02 --> URI Class Initialized
INFO - 2017-01-31 17:18:02 --> Router Class Initialized
INFO - 2017-01-31 17:18:02 --> Output Class Initialized
INFO - 2017-01-31 17:18:02 --> Security Class Initialized
DEBUG - 2017-01-31 17:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 17:18:02 --> Input Class Initialized
INFO - 2017-01-31 17:18:02 --> Language Class Initialized
INFO - 2017-01-31 17:18:02 --> Loader Class Initialized
INFO - 2017-01-31 17:18:02 --> Database Driver Class Initialized
INFO - 2017-01-31 17:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 17:18:02 --> Controller Class Initialized
INFO - 2017-01-31 17:18:02 --> Helper loaded: url_helper
DEBUG - 2017-01-31 17:18:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 17:18:03 --> Config Class Initialized
INFO - 2017-01-31 17:18:03 --> Hooks Class Initialized
DEBUG - 2017-01-31 17:18:03 --> UTF-8 Support Enabled
INFO - 2017-01-31 17:18:03 --> Utf8 Class Initialized
INFO - 2017-01-31 17:18:03 --> URI Class Initialized
INFO - 2017-01-31 17:18:03 --> Router Class Initialized
INFO - 2017-01-31 17:18:03 --> Output Class Initialized
INFO - 2017-01-31 17:18:03 --> Security Class Initialized
DEBUG - 2017-01-31 17:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 17:18:03 --> Input Class Initialized
INFO - 2017-01-31 17:18:03 --> Language Class Initialized
INFO - 2017-01-31 17:18:03 --> Loader Class Initialized
INFO - 2017-01-31 17:18:03 --> Database Driver Class Initialized
INFO - 2017-01-31 17:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 17:18:03 --> Controller Class Initialized
INFO - 2017-01-31 17:18:03 --> Helper loaded: date_helper
DEBUG - 2017-01-31 17:18:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 17:18:03 --> Helper loaded: url_helper
INFO - 2017-01-31 17:18:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 17:18:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 17:18:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 17:18:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 17:18:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 17:18:03 --> Final output sent to browser
DEBUG - 2017-01-31 17:18:03 --> Total execution time: 0.0147
INFO - 2017-01-31 17:18:10 --> Config Class Initialized
INFO - 2017-01-31 17:18:10 --> Hooks Class Initialized
DEBUG - 2017-01-31 17:18:10 --> UTF-8 Support Enabled
INFO - 2017-01-31 17:18:10 --> Utf8 Class Initialized
INFO - 2017-01-31 17:18:10 --> URI Class Initialized
DEBUG - 2017-01-31 17:18:10 --> No URI present. Default controller set.
INFO - 2017-01-31 17:18:10 --> Router Class Initialized
INFO - 2017-01-31 17:18:10 --> Output Class Initialized
INFO - 2017-01-31 17:18:10 --> Security Class Initialized
DEBUG - 2017-01-31 17:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 17:18:10 --> Input Class Initialized
INFO - 2017-01-31 17:18:10 --> Language Class Initialized
INFO - 2017-01-31 17:18:10 --> Loader Class Initialized
INFO - 2017-01-31 17:18:10 --> Database Driver Class Initialized
INFO - 2017-01-31 17:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 17:18:10 --> Controller Class Initialized
INFO - 2017-01-31 17:18:10 --> Helper loaded: url_helper
DEBUG - 2017-01-31 17:18:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 17:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 17:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 17:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 17:18:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 17:18:10 --> Final output sent to browser
DEBUG - 2017-01-31 17:18:10 --> Total execution time: 0.0139
INFO - 2017-01-31 17:43:31 --> Config Class Initialized
INFO - 2017-01-31 17:43:31 --> Hooks Class Initialized
DEBUG - 2017-01-31 17:43:31 --> UTF-8 Support Enabled
INFO - 2017-01-31 17:43:31 --> Utf8 Class Initialized
INFO - 2017-01-31 17:43:31 --> URI Class Initialized
INFO - 2017-01-31 17:43:31 --> Router Class Initialized
INFO - 2017-01-31 17:43:31 --> Output Class Initialized
INFO - 2017-01-31 17:43:31 --> Security Class Initialized
DEBUG - 2017-01-31 17:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 17:43:31 --> Input Class Initialized
INFO - 2017-01-31 17:43:31 --> Language Class Initialized
INFO - 2017-01-31 17:43:31 --> Loader Class Initialized
INFO - 2017-01-31 17:43:31 --> Database Driver Class Initialized
INFO - 2017-01-31 17:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 17:43:31 --> Controller Class Initialized
INFO - 2017-01-31 17:43:31 --> Helper loaded: url_helper
DEBUG - 2017-01-31 17:43:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 17:43:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 17:43:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 17:43:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 17:43:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 17:43:31 --> Final output sent to browser
DEBUG - 2017-01-31 17:43:31 --> Total execution time: 0.0197
INFO - 2017-01-31 19:45:47 --> Config Class Initialized
INFO - 2017-01-31 19:45:47 --> Hooks Class Initialized
DEBUG - 2017-01-31 19:45:47 --> UTF-8 Support Enabled
INFO - 2017-01-31 19:45:47 --> Utf8 Class Initialized
INFO - 2017-01-31 19:45:47 --> URI Class Initialized
DEBUG - 2017-01-31 19:45:47 --> No URI present. Default controller set.
INFO - 2017-01-31 19:45:47 --> Router Class Initialized
INFO - 2017-01-31 19:45:47 --> Output Class Initialized
INFO - 2017-01-31 19:45:47 --> Security Class Initialized
DEBUG - 2017-01-31 19:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 19:45:47 --> Input Class Initialized
INFO - 2017-01-31 19:45:47 --> Language Class Initialized
INFO - 2017-01-31 19:45:47 --> Loader Class Initialized
INFO - 2017-01-31 19:45:47 --> Database Driver Class Initialized
INFO - 2017-01-31 19:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 19:45:47 --> Controller Class Initialized
INFO - 2017-01-31 19:45:47 --> Helper loaded: url_helper
DEBUG - 2017-01-31 19:45:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 19:45:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 19:45:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 19:45:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 19:45:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 19:45:47 --> Final output sent to browser
DEBUG - 2017-01-31 19:45:47 --> Total execution time: 0.0760
INFO - 2017-01-31 19:45:48 --> Config Class Initialized
INFO - 2017-01-31 19:45:48 --> Hooks Class Initialized
DEBUG - 2017-01-31 19:45:48 --> UTF-8 Support Enabled
INFO - 2017-01-31 19:45:48 --> Utf8 Class Initialized
INFO - 2017-01-31 19:45:48 --> URI Class Initialized
DEBUG - 2017-01-31 19:45:48 --> No URI present. Default controller set.
INFO - 2017-01-31 19:45:48 --> Router Class Initialized
INFO - 2017-01-31 19:45:48 --> Output Class Initialized
INFO - 2017-01-31 19:45:48 --> Security Class Initialized
DEBUG - 2017-01-31 19:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 19:45:48 --> Input Class Initialized
INFO - 2017-01-31 19:45:48 --> Language Class Initialized
INFO - 2017-01-31 19:45:48 --> Loader Class Initialized
INFO - 2017-01-31 19:45:48 --> Database Driver Class Initialized
INFO - 2017-01-31 19:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 19:45:48 --> Controller Class Initialized
INFO - 2017-01-31 19:45:48 --> Helper loaded: url_helper
DEBUG - 2017-01-31 19:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 19:45:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 19:45:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 19:45:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 19:45:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 19:45:48 --> Final output sent to browser
DEBUG - 2017-01-31 19:45:48 --> Total execution time: 0.0130
INFO - 2017-01-31 19:45:51 --> Config Class Initialized
INFO - 2017-01-31 19:45:51 --> Hooks Class Initialized
DEBUG - 2017-01-31 19:45:51 --> UTF-8 Support Enabled
INFO - 2017-01-31 19:45:51 --> Utf8 Class Initialized
INFO - 2017-01-31 19:45:51 --> URI Class Initialized
INFO - 2017-01-31 19:45:51 --> Router Class Initialized
INFO - 2017-01-31 19:45:51 --> Output Class Initialized
INFO - 2017-01-31 19:45:51 --> Security Class Initialized
DEBUG - 2017-01-31 19:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 19:45:51 --> Input Class Initialized
INFO - 2017-01-31 19:45:51 --> Language Class Initialized
INFO - 2017-01-31 19:45:51 --> Loader Class Initialized
INFO - 2017-01-31 19:45:51 --> Database Driver Class Initialized
INFO - 2017-01-31 19:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 19:45:51 --> Controller Class Initialized
INFO - 2017-01-31 19:45:51 --> Helper loaded: url_helper
DEBUG - 2017-01-31 19:45:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 19:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 19:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 19:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 19:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 19:45:51 --> Final output sent to browser
DEBUG - 2017-01-31 19:45:51 --> Total execution time: 0.0131
INFO - 2017-01-31 19:45:56 --> Config Class Initialized
INFO - 2017-01-31 19:45:56 --> Hooks Class Initialized
DEBUG - 2017-01-31 19:45:56 --> UTF-8 Support Enabled
INFO - 2017-01-31 19:45:56 --> Utf8 Class Initialized
INFO - 2017-01-31 19:45:56 --> URI Class Initialized
INFO - 2017-01-31 19:45:56 --> Router Class Initialized
INFO - 2017-01-31 19:45:56 --> Output Class Initialized
INFO - 2017-01-31 19:45:56 --> Security Class Initialized
DEBUG - 2017-01-31 19:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 19:45:56 --> Input Class Initialized
INFO - 2017-01-31 19:45:56 --> Language Class Initialized
INFO - 2017-01-31 19:45:56 --> Loader Class Initialized
INFO - 2017-01-31 19:45:56 --> Database Driver Class Initialized
INFO - 2017-01-31 19:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 19:45:56 --> Controller Class Initialized
INFO - 2017-01-31 19:45:56 --> Helper loaded: url_helper
DEBUG - 2017-01-31 19:45:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 19:45:58 --> Config Class Initialized
INFO - 2017-01-31 19:45:58 --> Hooks Class Initialized
DEBUG - 2017-01-31 19:45:58 --> UTF-8 Support Enabled
INFO - 2017-01-31 19:45:58 --> Utf8 Class Initialized
INFO - 2017-01-31 19:45:58 --> URI Class Initialized
INFO - 2017-01-31 19:45:58 --> Router Class Initialized
INFO - 2017-01-31 19:45:58 --> Output Class Initialized
INFO - 2017-01-31 19:45:58 --> Security Class Initialized
DEBUG - 2017-01-31 19:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 19:45:58 --> Input Class Initialized
INFO - 2017-01-31 19:45:58 --> Language Class Initialized
INFO - 2017-01-31 19:45:58 --> Loader Class Initialized
INFO - 2017-01-31 19:45:58 --> Database Driver Class Initialized
INFO - 2017-01-31 19:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 19:45:58 --> Controller Class Initialized
INFO - 2017-01-31 19:45:58 --> Helper loaded: date_helper
DEBUG - 2017-01-31 19:45:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 19:45:58 --> Helper loaded: url_helper
INFO - 2017-01-31 19:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 19:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 19:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 19:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 19:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 19:45:58 --> Final output sent to browser
DEBUG - 2017-01-31 19:45:58 --> Total execution time: 0.0304
INFO - 2017-01-31 19:45:58 --> Config Class Initialized
INFO - 2017-01-31 19:45:58 --> Hooks Class Initialized
DEBUG - 2017-01-31 19:45:58 --> UTF-8 Support Enabled
INFO - 2017-01-31 19:45:58 --> Utf8 Class Initialized
INFO - 2017-01-31 19:45:58 --> URI Class Initialized
INFO - 2017-01-31 19:45:58 --> Router Class Initialized
INFO - 2017-01-31 19:45:58 --> Output Class Initialized
INFO - 2017-01-31 19:45:58 --> Security Class Initialized
DEBUG - 2017-01-31 19:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 19:45:58 --> Input Class Initialized
INFO - 2017-01-31 19:45:58 --> Language Class Initialized
INFO - 2017-01-31 19:45:58 --> Loader Class Initialized
INFO - 2017-01-31 19:45:58 --> Database Driver Class Initialized
INFO - 2017-01-31 19:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 19:45:58 --> Controller Class Initialized
INFO - 2017-01-31 19:45:58 --> Helper loaded: url_helper
DEBUG - 2017-01-31 19:45:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 19:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 19:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 19:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 19:45:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 19:45:58 --> Final output sent to browser
DEBUG - 2017-01-31 19:45:58 --> Total execution time: 0.0130
INFO - 2017-01-31 20:29:26 --> Config Class Initialized
INFO - 2017-01-31 20:29:26 --> Hooks Class Initialized
DEBUG - 2017-01-31 20:29:26 --> UTF-8 Support Enabled
INFO - 2017-01-31 20:29:26 --> Utf8 Class Initialized
INFO - 2017-01-31 20:29:26 --> URI Class Initialized
INFO - 2017-01-31 20:29:26 --> Router Class Initialized
INFO - 2017-01-31 20:29:26 --> Output Class Initialized
INFO - 2017-01-31 20:29:26 --> Security Class Initialized
DEBUG - 2017-01-31 20:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 20:29:26 --> Input Class Initialized
INFO - 2017-01-31 20:29:26 --> Language Class Initialized
INFO - 2017-01-31 20:29:26 --> Loader Class Initialized
INFO - 2017-01-31 20:29:26 --> Database Driver Class Initialized
INFO - 2017-01-31 20:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 20:29:26 --> Controller Class Initialized
INFO - 2017-01-31 20:29:26 --> Helper loaded: url_helper
DEBUG - 2017-01-31 20:29:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 20:29:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 20:29:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 20:29:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 20:29:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 20:29:26 --> Final output sent to browser
DEBUG - 2017-01-31 20:29:26 --> Total execution time: 0.0330
INFO - 2017-01-31 20:29:31 --> Config Class Initialized
INFO - 2017-01-31 20:29:31 --> Hooks Class Initialized
DEBUG - 2017-01-31 20:29:31 --> UTF-8 Support Enabled
INFO - 2017-01-31 20:29:31 --> Utf8 Class Initialized
INFO - 2017-01-31 20:29:31 --> URI Class Initialized
INFO - 2017-01-31 20:29:31 --> Router Class Initialized
INFO - 2017-01-31 20:29:31 --> Output Class Initialized
INFO - 2017-01-31 20:29:31 --> Security Class Initialized
DEBUG - 2017-01-31 20:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 20:29:31 --> Input Class Initialized
INFO - 2017-01-31 20:29:31 --> Language Class Initialized
INFO - 2017-01-31 20:29:31 --> Loader Class Initialized
INFO - 2017-01-31 20:29:31 --> Database Driver Class Initialized
INFO - 2017-01-31 20:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 20:29:31 --> Controller Class Initialized
INFO - 2017-01-31 20:29:31 --> Helper loaded: url_helper
DEBUG - 2017-01-31 20:29:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 20:29:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 20:29:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 20:29:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 20:29:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 20:29:31 --> Final output sent to browser
DEBUG - 2017-01-31 20:29:31 --> Total execution time: 0.0137
INFO - 2017-01-31 20:29:46 --> Config Class Initialized
INFO - 2017-01-31 20:29:46 --> Hooks Class Initialized
DEBUG - 2017-01-31 20:29:46 --> UTF-8 Support Enabled
INFO - 2017-01-31 20:29:46 --> Utf8 Class Initialized
INFO - 2017-01-31 20:29:46 --> URI Class Initialized
INFO - 2017-01-31 20:29:46 --> Router Class Initialized
INFO - 2017-01-31 20:29:46 --> Output Class Initialized
INFO - 2017-01-31 20:29:46 --> Security Class Initialized
DEBUG - 2017-01-31 20:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 20:29:46 --> Input Class Initialized
INFO - 2017-01-31 20:29:46 --> Language Class Initialized
INFO - 2017-01-31 20:29:46 --> Loader Class Initialized
INFO - 2017-01-31 20:29:46 --> Database Driver Class Initialized
INFO - 2017-01-31 20:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 20:29:46 --> Controller Class Initialized
INFO - 2017-01-31 20:29:46 --> Helper loaded: url_helper
DEBUG - 2017-01-31 20:29:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 20:29:47 --> Config Class Initialized
INFO - 2017-01-31 20:29:47 --> Hooks Class Initialized
DEBUG - 2017-01-31 20:29:47 --> UTF-8 Support Enabled
INFO - 2017-01-31 20:29:47 --> Utf8 Class Initialized
INFO - 2017-01-31 20:29:47 --> URI Class Initialized
INFO - 2017-01-31 20:29:47 --> Router Class Initialized
INFO - 2017-01-31 20:29:47 --> Output Class Initialized
INFO - 2017-01-31 20:29:47 --> Security Class Initialized
DEBUG - 2017-01-31 20:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 20:29:47 --> Input Class Initialized
INFO - 2017-01-31 20:29:47 --> Language Class Initialized
INFO - 2017-01-31 20:29:47 --> Loader Class Initialized
INFO - 2017-01-31 20:29:47 --> Database Driver Class Initialized
INFO - 2017-01-31 20:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 20:29:47 --> Controller Class Initialized
INFO - 2017-01-31 20:29:47 --> Helper loaded: date_helper
DEBUG - 2017-01-31 20:29:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 20:29:47 --> Helper loaded: url_helper
INFO - 2017-01-31 20:29:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 20:29:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 20:29:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 20:29:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 20:29:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 20:29:47 --> Final output sent to browser
DEBUG - 2017-01-31 20:29:47 --> Total execution time: 0.0147
INFO - 2017-01-31 20:29:49 --> Config Class Initialized
INFO - 2017-01-31 20:29:49 --> Hooks Class Initialized
DEBUG - 2017-01-31 20:29:49 --> UTF-8 Support Enabled
INFO - 2017-01-31 20:29:49 --> Utf8 Class Initialized
INFO - 2017-01-31 20:29:49 --> URI Class Initialized
INFO - 2017-01-31 20:29:49 --> Router Class Initialized
INFO - 2017-01-31 20:29:49 --> Output Class Initialized
INFO - 2017-01-31 20:29:49 --> Security Class Initialized
DEBUG - 2017-01-31 20:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 20:29:49 --> Input Class Initialized
INFO - 2017-01-31 20:29:49 --> Language Class Initialized
INFO - 2017-01-31 20:29:49 --> Loader Class Initialized
INFO - 2017-01-31 20:29:49 --> Database Driver Class Initialized
INFO - 2017-01-31 20:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 20:29:49 --> Controller Class Initialized
INFO - 2017-01-31 20:29:49 --> Helper loaded: url_helper
DEBUG - 2017-01-31 20:29:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 20:29:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 20:29:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 20:29:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 20:29:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 20:29:49 --> Final output sent to browser
DEBUG - 2017-01-31 20:29:49 --> Total execution time: 0.0141
INFO - 2017-01-31 20:30:34 --> Config Class Initialized
INFO - 2017-01-31 20:30:34 --> Hooks Class Initialized
DEBUG - 2017-01-31 20:30:34 --> UTF-8 Support Enabled
INFO - 2017-01-31 20:30:34 --> Utf8 Class Initialized
INFO - 2017-01-31 20:30:34 --> URI Class Initialized
INFO - 2017-01-31 20:30:34 --> Router Class Initialized
INFO - 2017-01-31 20:30:34 --> Output Class Initialized
INFO - 2017-01-31 20:30:34 --> Security Class Initialized
DEBUG - 2017-01-31 20:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 20:30:34 --> Input Class Initialized
INFO - 2017-01-31 20:30:34 --> Language Class Initialized
INFO - 2017-01-31 20:30:34 --> Loader Class Initialized
INFO - 2017-01-31 20:30:34 --> Database Driver Class Initialized
INFO - 2017-01-31 20:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 20:30:34 --> Controller Class Initialized
INFO - 2017-01-31 20:30:34 --> Helper loaded: url_helper
DEBUG - 2017-01-31 20:30:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 20:30:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 20:30:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 20:30:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 20:30:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 20:30:34 --> Final output sent to browser
DEBUG - 2017-01-31 20:30:34 --> Total execution time: 0.0137
INFO - 2017-01-31 20:30:36 --> Config Class Initialized
INFO - 2017-01-31 20:30:36 --> Hooks Class Initialized
DEBUG - 2017-01-31 20:30:36 --> UTF-8 Support Enabled
INFO - 2017-01-31 20:30:36 --> Utf8 Class Initialized
INFO - 2017-01-31 20:30:36 --> URI Class Initialized
INFO - 2017-01-31 20:30:36 --> Router Class Initialized
INFO - 2017-01-31 20:30:36 --> Output Class Initialized
INFO - 2017-01-31 20:30:36 --> Security Class Initialized
DEBUG - 2017-01-31 20:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 20:30:36 --> Input Class Initialized
INFO - 2017-01-31 20:30:36 --> Language Class Initialized
INFO - 2017-01-31 20:30:36 --> Loader Class Initialized
INFO - 2017-01-31 20:30:36 --> Database Driver Class Initialized
INFO - 2017-01-31 20:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 20:30:36 --> Controller Class Initialized
INFO - 2017-01-31 20:30:36 --> Helper loaded: url_helper
DEBUG - 2017-01-31 20:30:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 20:30:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 20:30:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 20:30:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 20:30:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 20:30:36 --> Final output sent to browser
DEBUG - 2017-01-31 20:30:36 --> Total execution time: 0.0137
INFO - 2017-01-31 21:44:57 --> Config Class Initialized
INFO - 2017-01-31 21:44:57 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:44:57 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:44:57 --> Utf8 Class Initialized
INFO - 2017-01-31 21:44:57 --> URI Class Initialized
DEBUG - 2017-01-31 21:44:57 --> No URI present. Default controller set.
INFO - 2017-01-31 21:44:57 --> Router Class Initialized
INFO - 2017-01-31 21:44:57 --> Output Class Initialized
INFO - 2017-01-31 21:44:57 --> Security Class Initialized
DEBUG - 2017-01-31 21:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:44:57 --> Input Class Initialized
INFO - 2017-01-31 21:44:57 --> Language Class Initialized
INFO - 2017-01-31 21:44:57 --> Loader Class Initialized
INFO - 2017-01-31 21:44:57 --> Database Driver Class Initialized
INFO - 2017-01-31 21:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:44:57 --> Controller Class Initialized
INFO - 2017-01-31 21:44:57 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:44:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:44:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 21:44:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 21:44:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 21:44:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 21:44:57 --> Final output sent to browser
DEBUG - 2017-01-31 21:44:57 --> Total execution time: 0.0139
INFO - 2017-01-31 21:45:00 --> Config Class Initialized
INFO - 2017-01-31 21:45:00 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:45:00 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:45:00 --> Utf8 Class Initialized
INFO - 2017-01-31 21:45:00 --> URI Class Initialized
INFO - 2017-01-31 21:45:00 --> Router Class Initialized
INFO - 2017-01-31 21:45:00 --> Output Class Initialized
INFO - 2017-01-31 21:45:00 --> Security Class Initialized
DEBUG - 2017-01-31 21:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:45:00 --> Input Class Initialized
INFO - 2017-01-31 21:45:00 --> Language Class Initialized
INFO - 2017-01-31 21:45:00 --> Loader Class Initialized
INFO - 2017-01-31 21:45:00 --> Database Driver Class Initialized
INFO - 2017-01-31 21:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:45:00 --> Controller Class Initialized
INFO - 2017-01-31 21:45:00 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:45:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:45:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 21:45:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 21:45:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 21:45:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 21:45:00 --> Final output sent to browser
DEBUG - 2017-01-31 21:45:00 --> Total execution time: 0.0220
INFO - 2017-01-31 21:45:05 --> Config Class Initialized
INFO - 2017-01-31 21:45:05 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:45:05 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:45:05 --> Utf8 Class Initialized
INFO - 2017-01-31 21:45:05 --> URI Class Initialized
INFO - 2017-01-31 21:45:05 --> Router Class Initialized
INFO - 2017-01-31 21:45:05 --> Output Class Initialized
INFO - 2017-01-31 21:45:05 --> Security Class Initialized
DEBUG - 2017-01-31 21:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:45:05 --> Input Class Initialized
INFO - 2017-01-31 21:45:05 --> Language Class Initialized
INFO - 2017-01-31 21:45:05 --> Loader Class Initialized
INFO - 2017-01-31 21:45:05 --> Database Driver Class Initialized
INFO - 2017-01-31 21:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:45:05 --> Controller Class Initialized
INFO - 2017-01-31 21:45:05 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:45:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:45:05 --> Helper loaded: form_helper
INFO - 2017-01-31 21:45:05 --> Form Validation Class Initialized
INFO - 2017-01-31 21:45:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-31 21:45:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-31 21:45:05 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-31 21:45:05 --> Final output sent to browser
DEBUG - 2017-01-31 21:45:05 --> Total execution time: 0.0542
INFO - 2017-01-31 21:45:06 --> Config Class Initialized
INFO - 2017-01-31 21:45:06 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:45:06 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:45:06 --> Utf8 Class Initialized
INFO - 2017-01-31 21:45:06 --> URI Class Initialized
INFO - 2017-01-31 21:45:06 --> Router Class Initialized
INFO - 2017-01-31 21:45:06 --> Output Class Initialized
INFO - 2017-01-31 21:45:06 --> Security Class Initialized
DEBUG - 2017-01-31 21:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:45:06 --> Input Class Initialized
INFO - 2017-01-31 21:45:06 --> Language Class Initialized
INFO - 2017-01-31 21:45:06 --> Loader Class Initialized
INFO - 2017-01-31 21:45:06 --> Database Driver Class Initialized
INFO - 2017-01-31 21:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:45:06 --> Controller Class Initialized
INFO - 2017-01-31 21:45:06 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:45:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:45:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 21:45:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 21:45:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 21:45:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 21:45:06 --> Final output sent to browser
DEBUG - 2017-01-31 21:45:06 --> Total execution time: 0.0526
INFO - 2017-01-31 21:45:13 --> Config Class Initialized
INFO - 2017-01-31 21:45:13 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:45:13 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:45:13 --> Utf8 Class Initialized
INFO - 2017-01-31 21:45:13 --> URI Class Initialized
INFO - 2017-01-31 21:45:13 --> Router Class Initialized
INFO - 2017-01-31 21:45:13 --> Output Class Initialized
INFO - 2017-01-31 21:45:13 --> Security Class Initialized
DEBUG - 2017-01-31 21:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:45:13 --> Input Class Initialized
INFO - 2017-01-31 21:45:13 --> Language Class Initialized
INFO - 2017-01-31 21:45:13 --> Loader Class Initialized
INFO - 2017-01-31 21:45:13 --> Database Driver Class Initialized
INFO - 2017-01-31 21:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:45:13 --> Controller Class Initialized
INFO - 2017-01-31 21:45:13 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:45:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:45:13 --> Helper loaded: form_helper
INFO - 2017-01-31 21:45:13 --> Form Validation Class Initialized
INFO - 2017-01-31 21:45:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-31 21:45:13 --> Config Class Initialized
INFO - 2017-01-31 21:45:13 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:45:13 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:45:13 --> Utf8 Class Initialized
INFO - 2017-01-31 21:45:13 --> URI Class Initialized
INFO - 2017-01-31 21:45:13 --> Router Class Initialized
INFO - 2017-01-31 21:45:13 --> Output Class Initialized
INFO - 2017-01-31 21:45:13 --> Security Class Initialized
DEBUG - 2017-01-31 21:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:45:13 --> Input Class Initialized
INFO - 2017-01-31 21:45:13 --> Language Class Initialized
INFO - 2017-01-31 21:45:13 --> Loader Class Initialized
INFO - 2017-01-31 21:45:13 --> Database Driver Class Initialized
INFO - 2017-01-31 21:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:45:13 --> Controller Class Initialized
INFO - 2017-01-31 21:45:13 --> Helper loaded: date_helper
INFO - 2017-01-31 21:45:13 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:45:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:45:13 --> Helper loaded: form_helper
INFO - 2017-01-31 21:45:13 --> Form Validation Class Initialized
INFO - 2017-01-31 21:45:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-31 21:45:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-31 21:45:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-31 21:45:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-31 21:45:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-31 21:45:13 --> Final output sent to browser
DEBUG - 2017-01-31 21:45:13 --> Total execution time: 0.1323
INFO - 2017-01-31 21:45:14 --> Config Class Initialized
INFO - 2017-01-31 21:45:14 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:45:14 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:45:14 --> Utf8 Class Initialized
INFO - 2017-01-31 21:45:14 --> URI Class Initialized
INFO - 2017-01-31 21:45:14 --> Router Class Initialized
INFO - 2017-01-31 21:45:14 --> Output Class Initialized
INFO - 2017-01-31 21:45:14 --> Security Class Initialized
DEBUG - 2017-01-31 21:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:45:14 --> Input Class Initialized
INFO - 2017-01-31 21:45:14 --> Language Class Initialized
INFO - 2017-01-31 21:45:14 --> Loader Class Initialized
INFO - 2017-01-31 21:45:14 --> Database Driver Class Initialized
INFO - 2017-01-31 21:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:45:14 --> Controller Class Initialized
INFO - 2017-01-31 21:45:14 --> Helper loaded: date_helper
INFO - 2017-01-31 21:45:14 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:45:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:45:14 --> Helper loaded: form_helper
INFO - 2017-01-31 21:45:14 --> Form Validation Class Initialized
INFO - 2017-01-31 21:45:14 --> Final output sent to browser
DEBUG - 2017-01-31 21:45:14 --> Total execution time: 0.0609
INFO - 2017-01-31 21:45:15 --> Config Class Initialized
INFO - 2017-01-31 21:45:15 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:45:15 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:45:15 --> Utf8 Class Initialized
INFO - 2017-01-31 21:45:15 --> URI Class Initialized
INFO - 2017-01-31 21:45:15 --> Router Class Initialized
INFO - 2017-01-31 21:45:15 --> Output Class Initialized
INFO - 2017-01-31 21:45:15 --> Security Class Initialized
DEBUG - 2017-01-31 21:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:45:15 --> Input Class Initialized
INFO - 2017-01-31 21:45:15 --> Language Class Initialized
INFO - 2017-01-31 21:45:15 --> Loader Class Initialized
INFO - 2017-01-31 21:45:15 --> Database Driver Class Initialized
INFO - 2017-01-31 21:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:45:15 --> Controller Class Initialized
INFO - 2017-01-31 21:45:15 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:45:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:45:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 21:45:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 21:45:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 21:45:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 21:45:15 --> Final output sent to browser
DEBUG - 2017-01-31 21:45:15 --> Total execution time: 0.0134
INFO - 2017-01-31 21:45:22 --> Config Class Initialized
INFO - 2017-01-31 21:45:22 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:45:22 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:45:22 --> Utf8 Class Initialized
INFO - 2017-01-31 21:45:22 --> URI Class Initialized
INFO - 2017-01-31 21:45:22 --> Router Class Initialized
INFO - 2017-01-31 21:45:22 --> Output Class Initialized
INFO - 2017-01-31 21:45:22 --> Security Class Initialized
DEBUG - 2017-01-31 21:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:45:22 --> Input Class Initialized
INFO - 2017-01-31 21:45:22 --> Language Class Initialized
INFO - 2017-01-31 21:45:22 --> Loader Class Initialized
INFO - 2017-01-31 21:45:22 --> Database Driver Class Initialized
INFO - 2017-01-31 21:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:45:22 --> Controller Class Initialized
INFO - 2017-01-31 21:45:22 --> Upload Class Initialized
INFO - 2017-01-31 21:45:22 --> Helper loaded: date_helper
INFO - 2017-01-31 21:45:22 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:45:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:45:22 --> Helper loaded: form_helper
INFO - 2017-01-31 21:45:22 --> Form Validation Class Initialized
INFO - 2017-01-31 21:45:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-31 21:45:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-31 21:45:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_graduacion.php
INFO - 2017-01-31 21:45:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_graduacion.php
INFO - 2017-01-31 21:45:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-01-31 21:45:22 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-31 21:45:22 --> Final output sent to browser
DEBUG - 2017-01-31 21:45:22 --> Total execution time: 0.1246
INFO - 2017-01-31 21:45:23 --> Config Class Initialized
INFO - 2017-01-31 21:45:23 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:45:23 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:45:23 --> Utf8 Class Initialized
INFO - 2017-01-31 21:45:23 --> URI Class Initialized
INFO - 2017-01-31 21:45:23 --> Router Class Initialized
INFO - 2017-01-31 21:45:23 --> Output Class Initialized
INFO - 2017-01-31 21:45:23 --> Security Class Initialized
DEBUG - 2017-01-31 21:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:45:23 --> Input Class Initialized
INFO - 2017-01-31 21:45:23 --> Language Class Initialized
INFO - 2017-01-31 21:45:23 --> Loader Class Initialized
INFO - 2017-01-31 21:45:23 --> Database Driver Class Initialized
INFO - 2017-01-31 21:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:45:23 --> Controller Class Initialized
INFO - 2017-01-31 21:45:23 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:45:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:45:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 21:45:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 21:45:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 21:45:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 21:45:23 --> Final output sent to browser
DEBUG - 2017-01-31 21:45:23 --> Total execution time: 0.0141
INFO - 2017-01-31 21:45:46 --> Config Class Initialized
INFO - 2017-01-31 21:45:46 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:45:46 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:45:46 --> Utf8 Class Initialized
INFO - 2017-01-31 21:45:46 --> URI Class Initialized
INFO - 2017-01-31 21:45:46 --> Router Class Initialized
INFO - 2017-01-31 21:45:46 --> Output Class Initialized
INFO - 2017-01-31 21:45:46 --> Security Class Initialized
DEBUG - 2017-01-31 21:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:45:46 --> Input Class Initialized
INFO - 2017-01-31 21:45:46 --> Language Class Initialized
INFO - 2017-01-31 21:45:46 --> Loader Class Initialized
INFO - 2017-01-31 21:45:46 --> Database Driver Class Initialized
INFO - 2017-01-31 21:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:45:46 --> Controller Class Initialized
INFO - 2017-01-31 21:45:46 --> Upload Class Initialized
INFO - 2017-01-31 21:45:46 --> Helper loaded: date_helper
INFO - 2017-01-31 21:45:46 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:45:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:45:46 --> Helper loaded: form_helper
INFO - 2017-01-31 21:45:46 --> Form Validation Class Initialized
INFO - 2017-01-31 21:45:46 --> Final output sent to browser
DEBUG - 2017-01-31 21:45:46 --> Total execution time: 0.0256
INFO - 2017-01-31 21:45:49 --> Config Class Initialized
INFO - 2017-01-31 21:45:49 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:45:49 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:45:49 --> Utf8 Class Initialized
INFO - 2017-01-31 21:45:49 --> URI Class Initialized
INFO - 2017-01-31 21:45:49 --> Router Class Initialized
INFO - 2017-01-31 21:45:49 --> Output Class Initialized
INFO - 2017-01-31 21:45:49 --> Security Class Initialized
DEBUG - 2017-01-31 21:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:45:49 --> Input Class Initialized
INFO - 2017-01-31 21:45:49 --> Language Class Initialized
INFO - 2017-01-31 21:45:49 --> Loader Class Initialized
INFO - 2017-01-31 21:45:49 --> Database Driver Class Initialized
INFO - 2017-01-31 21:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:45:49 --> Controller Class Initialized
INFO - 2017-01-31 21:45:49 --> Upload Class Initialized
INFO - 2017-01-31 21:45:49 --> Helper loaded: date_helper
INFO - 2017-01-31 21:45:49 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:45:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:45:49 --> Helper loaded: form_helper
INFO - 2017-01-31 21:45:49 --> Form Validation Class Initialized
INFO - 2017-01-31 21:45:49 --> Final output sent to browser
DEBUG - 2017-01-31 21:45:49 --> Total execution time: 0.0154
INFO - 2017-01-31 21:47:48 --> Config Class Initialized
INFO - 2017-01-31 21:47:48 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:47:48 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:47:48 --> Utf8 Class Initialized
INFO - 2017-01-31 21:47:48 --> URI Class Initialized
INFO - 2017-01-31 21:47:48 --> Router Class Initialized
INFO - 2017-01-31 21:47:48 --> Output Class Initialized
INFO - 2017-01-31 21:47:48 --> Security Class Initialized
DEBUG - 2017-01-31 21:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:47:48 --> Input Class Initialized
INFO - 2017-01-31 21:47:48 --> Language Class Initialized
INFO - 2017-01-31 21:47:48 --> Loader Class Initialized
INFO - 2017-01-31 21:47:48 --> Database Driver Class Initialized
INFO - 2017-01-31 21:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:47:48 --> Controller Class Initialized
INFO - 2017-01-31 21:47:48 --> Upload Class Initialized
INFO - 2017-01-31 21:47:48 --> Helper loaded: date_helper
INFO - 2017-01-31 21:47:48 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:47:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:47:48 --> Helper loaded: form_helper
INFO - 2017-01-31 21:47:48 --> Form Validation Class Initialized
INFO - 2017-01-31 21:47:48 --> Language file loaded: language/english/upload_lang.php
INFO - 2017-01-31 21:47:48 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
INFO - 2017-01-31 21:47:48 --> Final output sent to browser
DEBUG - 2017-01-31 21:47:48 --> Total execution time: 0.0283
INFO - 2017-01-31 21:47:48 --> Config Class Initialized
INFO - 2017-01-31 21:47:48 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:47:48 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:47:48 --> Utf8 Class Initialized
INFO - 2017-01-31 21:47:48 --> URI Class Initialized
INFO - 2017-01-31 21:47:48 --> Router Class Initialized
INFO - 2017-01-31 21:47:48 --> Output Class Initialized
INFO - 2017-01-31 21:47:48 --> Security Class Initialized
DEBUG - 2017-01-31 21:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:47:48 --> Input Class Initialized
INFO - 2017-01-31 21:47:48 --> Language Class Initialized
INFO - 2017-01-31 21:47:48 --> Loader Class Initialized
INFO - 2017-01-31 21:47:48 --> Database Driver Class Initialized
INFO - 2017-01-31 21:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:47:48 --> Controller Class Initialized
INFO - 2017-01-31 21:47:48 --> Upload Class Initialized
INFO - 2017-01-31 21:47:48 --> Helper loaded: date_helper
INFO - 2017-01-31 21:47:48 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:47:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:47:48 --> Helper loaded: form_helper
INFO - 2017-01-31 21:47:48 --> Form Validation Class Initialized
INFO - 2017-01-31 21:47:48 --> Final output sent to browser
DEBUG - 2017-01-31 21:47:48 --> Total execution time: 0.0594
INFO - 2017-01-31 21:47:59 --> Config Class Initialized
INFO - 2017-01-31 21:47:59 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:47:59 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:47:59 --> Utf8 Class Initialized
INFO - 2017-01-31 21:47:59 --> URI Class Initialized
INFO - 2017-01-31 21:47:59 --> Router Class Initialized
INFO - 2017-01-31 21:47:59 --> Output Class Initialized
INFO - 2017-01-31 21:47:59 --> Security Class Initialized
DEBUG - 2017-01-31 21:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:47:59 --> Input Class Initialized
INFO - 2017-01-31 21:47:59 --> Language Class Initialized
INFO - 2017-01-31 21:47:59 --> Loader Class Initialized
INFO - 2017-01-31 21:47:59 --> Database Driver Class Initialized
INFO - 2017-01-31 21:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:47:59 --> Controller Class Initialized
INFO - 2017-01-31 21:47:59 --> Upload Class Initialized
INFO - 2017-01-31 21:47:59 --> Helper loaded: date_helper
INFO - 2017-01-31 21:47:59 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:47:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:47:59 --> Helper loaded: form_helper
INFO - 2017-01-31 21:47:59 --> Form Validation Class Initialized
INFO - 2017-01-31 21:47:59 --> Language file loaded: language/english/upload_lang.php
INFO - 2017-01-31 21:47:59 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
INFO - 2017-01-31 21:47:59 --> Final output sent to browser
DEBUG - 2017-01-31 21:47:59 --> Total execution time: 0.0160
INFO - 2017-01-31 21:47:59 --> Config Class Initialized
INFO - 2017-01-31 21:47:59 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:47:59 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:47:59 --> Utf8 Class Initialized
INFO - 2017-01-31 21:47:59 --> URI Class Initialized
INFO - 2017-01-31 21:47:59 --> Router Class Initialized
INFO - 2017-01-31 21:47:59 --> Output Class Initialized
INFO - 2017-01-31 21:47:59 --> Security Class Initialized
DEBUG - 2017-01-31 21:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:47:59 --> Input Class Initialized
INFO - 2017-01-31 21:47:59 --> Language Class Initialized
INFO - 2017-01-31 21:47:59 --> Loader Class Initialized
INFO - 2017-01-31 21:47:59 --> Database Driver Class Initialized
INFO - 2017-01-31 21:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:47:59 --> Controller Class Initialized
INFO - 2017-01-31 21:47:59 --> Upload Class Initialized
INFO - 2017-01-31 21:47:59 --> Helper loaded: date_helper
INFO - 2017-01-31 21:47:59 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:47:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:47:59 --> Helper loaded: form_helper
INFO - 2017-01-31 21:47:59 --> Form Validation Class Initialized
INFO - 2017-01-31 21:47:59 --> Final output sent to browser
DEBUG - 2017-01-31 21:47:59 --> Total execution time: 0.0157
INFO - 2017-01-31 21:48:02 --> Config Class Initialized
INFO - 2017-01-31 21:48:02 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:48:02 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:48:02 --> Utf8 Class Initialized
INFO - 2017-01-31 21:48:02 --> URI Class Initialized
INFO - 2017-01-31 21:48:02 --> Router Class Initialized
INFO - 2017-01-31 21:48:02 --> Output Class Initialized
INFO - 2017-01-31 21:48:02 --> Security Class Initialized
DEBUG - 2017-01-31 21:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:48:02 --> Input Class Initialized
INFO - 2017-01-31 21:48:02 --> Language Class Initialized
INFO - 2017-01-31 21:48:02 --> Loader Class Initialized
INFO - 2017-01-31 21:48:02 --> Database Driver Class Initialized
INFO - 2017-01-31 21:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:48:02 --> Controller Class Initialized
INFO - 2017-01-31 21:48:02 --> Upload Class Initialized
INFO - 2017-01-31 21:48:02 --> Helper loaded: date_helper
INFO - 2017-01-31 21:48:02 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:48:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:48:02 --> Helper loaded: form_helper
INFO - 2017-01-31 21:48:02 --> Form Validation Class Initialized
INFO - 2017-01-31 21:48:02 --> Final output sent to browser
DEBUG - 2017-01-31 21:48:02 --> Total execution time: 0.0146
INFO - 2017-01-31 21:48:07 --> Config Class Initialized
INFO - 2017-01-31 21:48:07 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:48:07 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:48:07 --> Utf8 Class Initialized
INFO - 2017-01-31 21:48:07 --> URI Class Initialized
INFO - 2017-01-31 21:48:07 --> Router Class Initialized
INFO - 2017-01-31 21:48:07 --> Output Class Initialized
INFO - 2017-01-31 21:48:07 --> Security Class Initialized
DEBUG - 2017-01-31 21:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:48:07 --> Input Class Initialized
INFO - 2017-01-31 21:48:07 --> Language Class Initialized
INFO - 2017-01-31 21:48:07 --> Loader Class Initialized
INFO - 2017-01-31 21:48:07 --> Database Driver Class Initialized
INFO - 2017-01-31 21:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:48:07 --> Controller Class Initialized
INFO - 2017-01-31 21:48:07 --> Upload Class Initialized
INFO - 2017-01-31 21:48:07 --> Helper loaded: date_helper
INFO - 2017-01-31 21:48:07 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:48:07 --> Helper loaded: form_helper
INFO - 2017-01-31 21:48:07 --> Form Validation Class Initialized
INFO - 2017-01-31 21:48:07 --> Final output sent to browser
DEBUG - 2017-01-31 21:48:07 --> Total execution time: 0.0151
INFO - 2017-01-31 21:48:23 --> Config Class Initialized
INFO - 2017-01-31 21:48:23 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:48:23 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:48:23 --> Utf8 Class Initialized
INFO - 2017-01-31 21:48:23 --> URI Class Initialized
INFO - 2017-01-31 21:48:23 --> Router Class Initialized
INFO - 2017-01-31 21:48:23 --> Output Class Initialized
INFO - 2017-01-31 21:48:23 --> Security Class Initialized
DEBUG - 2017-01-31 21:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:48:23 --> Input Class Initialized
INFO - 2017-01-31 21:48:23 --> Language Class Initialized
INFO - 2017-01-31 21:48:23 --> Loader Class Initialized
INFO - 2017-01-31 21:48:23 --> Database Driver Class Initialized
INFO - 2017-01-31 21:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:48:23 --> Controller Class Initialized
INFO - 2017-01-31 21:48:23 --> Upload Class Initialized
INFO - 2017-01-31 21:48:23 --> Helper loaded: date_helper
INFO - 2017-01-31 21:48:23 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:48:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:48:23 --> Helper loaded: form_helper
INFO - 2017-01-31 21:48:23 --> Form Validation Class Initialized
INFO - 2017-01-31 21:48:23 --> Language file loaded: language/english/upload_lang.php
INFO - 2017-01-31 21:48:23 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
INFO - 2017-01-31 21:48:23 --> Final output sent to browser
DEBUG - 2017-01-31 21:48:23 --> Total execution time: 0.0170
INFO - 2017-01-31 21:48:24 --> Config Class Initialized
INFO - 2017-01-31 21:48:24 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:48:24 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:48:24 --> Utf8 Class Initialized
INFO - 2017-01-31 21:48:24 --> URI Class Initialized
INFO - 2017-01-31 21:48:24 --> Router Class Initialized
INFO - 2017-01-31 21:48:24 --> Output Class Initialized
INFO - 2017-01-31 21:48:24 --> Security Class Initialized
DEBUG - 2017-01-31 21:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:48:24 --> Input Class Initialized
INFO - 2017-01-31 21:48:24 --> Language Class Initialized
INFO - 2017-01-31 21:48:24 --> Loader Class Initialized
INFO - 2017-01-31 21:48:24 --> Database Driver Class Initialized
INFO - 2017-01-31 21:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:48:24 --> Controller Class Initialized
INFO - 2017-01-31 21:48:24 --> Upload Class Initialized
INFO - 2017-01-31 21:48:24 --> Helper loaded: date_helper
INFO - 2017-01-31 21:48:24 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:48:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:48:24 --> Helper loaded: form_helper
INFO - 2017-01-31 21:48:24 --> Form Validation Class Initialized
INFO - 2017-01-31 21:48:24 --> Final output sent to browser
DEBUG - 2017-01-31 21:48:24 --> Total execution time: 0.0204
INFO - 2017-01-31 21:48:26 --> Config Class Initialized
INFO - 2017-01-31 21:48:26 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:48:26 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:48:26 --> Utf8 Class Initialized
INFO - 2017-01-31 21:48:26 --> URI Class Initialized
INFO - 2017-01-31 21:48:26 --> Router Class Initialized
INFO - 2017-01-31 21:48:26 --> Output Class Initialized
INFO - 2017-01-31 21:48:26 --> Security Class Initialized
DEBUG - 2017-01-31 21:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:48:26 --> Input Class Initialized
INFO - 2017-01-31 21:48:26 --> Language Class Initialized
INFO - 2017-01-31 21:48:26 --> Loader Class Initialized
INFO - 2017-01-31 21:48:26 --> Database Driver Class Initialized
INFO - 2017-01-31 21:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:48:26 --> Controller Class Initialized
INFO - 2017-01-31 21:48:26 --> Upload Class Initialized
INFO - 2017-01-31 21:48:26 --> Helper loaded: date_helper
INFO - 2017-01-31 21:48:26 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:48:26 --> Helper loaded: form_helper
INFO - 2017-01-31 21:48:26 --> Form Validation Class Initialized
INFO - 2017-01-31 21:48:26 --> Final output sent to browser
DEBUG - 2017-01-31 21:48:26 --> Total execution time: 0.0599
INFO - 2017-01-31 21:48:30 --> Config Class Initialized
INFO - 2017-01-31 21:48:30 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:48:30 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:48:30 --> Utf8 Class Initialized
INFO - 2017-01-31 21:48:30 --> URI Class Initialized
INFO - 2017-01-31 21:48:30 --> Router Class Initialized
INFO - 2017-01-31 21:48:30 --> Output Class Initialized
INFO - 2017-01-31 21:48:30 --> Security Class Initialized
DEBUG - 2017-01-31 21:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:48:30 --> Input Class Initialized
INFO - 2017-01-31 21:48:30 --> Language Class Initialized
INFO - 2017-01-31 21:48:30 --> Loader Class Initialized
INFO - 2017-01-31 21:48:30 --> Database Driver Class Initialized
INFO - 2017-01-31 21:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:48:30 --> Controller Class Initialized
INFO - 2017-01-31 21:48:30 --> Upload Class Initialized
INFO - 2017-01-31 21:48:30 --> Helper loaded: date_helper
INFO - 2017-01-31 21:48:30 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:48:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:48:30 --> Helper loaded: form_helper
INFO - 2017-01-31 21:48:30 --> Form Validation Class Initialized
INFO - 2017-01-31 21:48:30 --> Final output sent to browser
DEBUG - 2017-01-31 21:48:30 --> Total execution time: 0.0153
INFO - 2017-01-31 21:48:35 --> Config Class Initialized
INFO - 2017-01-31 21:48:35 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:48:35 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:48:35 --> Utf8 Class Initialized
INFO - 2017-01-31 21:48:35 --> URI Class Initialized
INFO - 2017-01-31 21:48:35 --> Router Class Initialized
INFO - 2017-01-31 21:48:35 --> Output Class Initialized
INFO - 2017-01-31 21:48:35 --> Security Class Initialized
DEBUG - 2017-01-31 21:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:48:35 --> Input Class Initialized
INFO - 2017-01-31 21:48:35 --> Language Class Initialized
INFO - 2017-01-31 21:48:35 --> Loader Class Initialized
INFO - 2017-01-31 21:48:35 --> Database Driver Class Initialized
INFO - 2017-01-31 21:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:48:35 --> Controller Class Initialized
INFO - 2017-01-31 21:48:35 --> Helper loaded: date_helper
INFO - 2017-01-31 21:48:35 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:48:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:48:35 --> Helper loaded: form_helper
INFO - 2017-01-31 21:48:35 --> Form Validation Class Initialized
INFO - 2017-01-31 21:48:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-31 21:48:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-31 21:48:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-31 21:48:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-31 21:48:35 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-31 21:48:35 --> Final output sent to browser
DEBUG - 2017-01-31 21:48:35 --> Total execution time: 0.0468
INFO - 2017-01-31 21:48:35 --> Config Class Initialized
INFO - 2017-01-31 21:48:35 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:48:35 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:48:35 --> Utf8 Class Initialized
INFO - 2017-01-31 21:48:35 --> URI Class Initialized
INFO - 2017-01-31 21:48:35 --> Router Class Initialized
INFO - 2017-01-31 21:48:35 --> Output Class Initialized
INFO - 2017-01-31 21:48:35 --> Security Class Initialized
DEBUG - 2017-01-31 21:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:48:35 --> Input Class Initialized
INFO - 2017-01-31 21:48:35 --> Language Class Initialized
INFO - 2017-01-31 21:48:35 --> Loader Class Initialized
INFO - 2017-01-31 21:48:35 --> Database Driver Class Initialized
INFO - 2017-01-31 21:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:48:35 --> Controller Class Initialized
INFO - 2017-01-31 21:48:35 --> Helper loaded: date_helper
INFO - 2017-01-31 21:48:35 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:48:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:48:35 --> Helper loaded: form_helper
INFO - 2017-01-31 21:48:35 --> Form Validation Class Initialized
INFO - 2017-01-31 21:48:35 --> Final output sent to browser
DEBUG - 2017-01-31 21:48:35 --> Total execution time: 0.0513
INFO - 2017-01-31 21:48:35 --> Config Class Initialized
INFO - 2017-01-31 21:48:35 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:48:35 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:48:35 --> Utf8 Class Initialized
INFO - 2017-01-31 21:48:35 --> URI Class Initialized
INFO - 2017-01-31 21:48:35 --> Router Class Initialized
INFO - 2017-01-31 21:48:35 --> Output Class Initialized
INFO - 2017-01-31 21:48:35 --> Security Class Initialized
DEBUG - 2017-01-31 21:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:48:35 --> Input Class Initialized
INFO - 2017-01-31 21:48:35 --> Language Class Initialized
INFO - 2017-01-31 21:48:35 --> Loader Class Initialized
INFO - 2017-01-31 21:48:35 --> Database Driver Class Initialized
INFO - 2017-01-31 21:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:48:35 --> Controller Class Initialized
INFO - 2017-01-31 21:48:35 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:48:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:48:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 21:48:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 21:48:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 21:48:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 21:48:35 --> Final output sent to browser
DEBUG - 2017-01-31 21:48:35 --> Total execution time: 0.0628
INFO - 2017-01-31 21:48:39 --> Config Class Initialized
INFO - 2017-01-31 21:48:39 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:48:39 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:48:39 --> Utf8 Class Initialized
INFO - 2017-01-31 21:48:39 --> URI Class Initialized
INFO - 2017-01-31 21:48:39 --> Router Class Initialized
INFO - 2017-01-31 21:48:39 --> Output Class Initialized
INFO - 2017-01-31 21:48:39 --> Security Class Initialized
DEBUG - 2017-01-31 21:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:48:39 --> Input Class Initialized
INFO - 2017-01-31 21:48:39 --> Language Class Initialized
INFO - 2017-01-31 21:48:39 --> Loader Class Initialized
INFO - 2017-01-31 21:48:39 --> Database Driver Class Initialized
INFO - 2017-01-31 21:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:48:39 --> Controller Class Initialized
INFO - 2017-01-31 21:48:39 --> Helper loaded: date_helper
INFO - 2017-01-31 21:48:39 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:48:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:48:39 --> Helper loaded: form_helper
INFO - 2017-01-31 21:48:39 --> Form Validation Class Initialized
INFO - 2017-01-31 21:48:39 --> Final output sent to browser
DEBUG - 2017-01-31 21:48:39 --> Total execution time: 0.0322
INFO - 2017-01-31 21:49:03 --> Config Class Initialized
INFO - 2017-01-31 21:49:03 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:03 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:03 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:03 --> URI Class Initialized
INFO - 2017-01-31 21:49:03 --> Router Class Initialized
INFO - 2017-01-31 21:49:03 --> Output Class Initialized
INFO - 2017-01-31 21:49:03 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:03 --> Input Class Initialized
INFO - 2017-01-31 21:49:03 --> Language Class Initialized
INFO - 2017-01-31 21:49:03 --> Loader Class Initialized
INFO - 2017-01-31 21:49:03 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:03 --> Controller Class Initialized
INFO - 2017-01-31 21:49:03 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:03 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:03 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:03 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:03 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:03 --> Total execution time: 0.0149
INFO - 2017-01-31 21:49:04 --> Config Class Initialized
INFO - 2017-01-31 21:49:04 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:04 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:04 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:04 --> URI Class Initialized
INFO - 2017-01-31 21:49:04 --> Router Class Initialized
INFO - 2017-01-31 21:49:04 --> Output Class Initialized
INFO - 2017-01-31 21:49:04 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:04 --> Input Class Initialized
INFO - 2017-01-31 21:49:04 --> Language Class Initialized
INFO - 2017-01-31 21:49:04 --> Loader Class Initialized
INFO - 2017-01-31 21:49:04 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:04 --> Controller Class Initialized
INFO - 2017-01-31 21:49:04 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:04 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:04 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:04 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:04 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:04 --> Total execution time: 0.0146
INFO - 2017-01-31 21:49:05 --> Config Class Initialized
INFO - 2017-01-31 21:49:05 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:05 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:05 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:05 --> URI Class Initialized
INFO - 2017-01-31 21:49:05 --> Router Class Initialized
INFO - 2017-01-31 21:49:05 --> Output Class Initialized
INFO - 2017-01-31 21:49:05 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:05 --> Input Class Initialized
INFO - 2017-01-31 21:49:05 --> Language Class Initialized
INFO - 2017-01-31 21:49:05 --> Loader Class Initialized
INFO - 2017-01-31 21:49:05 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:05 --> Controller Class Initialized
INFO - 2017-01-31 21:49:05 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:05 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:05 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:05 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:05 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:05 --> Total execution time: 0.0150
INFO - 2017-01-31 21:49:07 --> Config Class Initialized
INFO - 2017-01-31 21:49:07 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:07 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:07 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:07 --> URI Class Initialized
INFO - 2017-01-31 21:49:07 --> Router Class Initialized
INFO - 2017-01-31 21:49:07 --> Output Class Initialized
INFO - 2017-01-31 21:49:07 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:07 --> Input Class Initialized
INFO - 2017-01-31 21:49:07 --> Language Class Initialized
INFO - 2017-01-31 21:49:07 --> Loader Class Initialized
INFO - 2017-01-31 21:49:07 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:07 --> Controller Class Initialized
INFO - 2017-01-31 21:49:07 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:07 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:07 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:07 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:07 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:07 --> Total execution time: 0.0180
INFO - 2017-01-31 21:49:09 --> Config Class Initialized
INFO - 2017-01-31 21:49:09 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:09 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:09 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:09 --> URI Class Initialized
INFO - 2017-01-31 21:49:09 --> Router Class Initialized
INFO - 2017-01-31 21:49:09 --> Output Class Initialized
INFO - 2017-01-31 21:49:09 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:09 --> Input Class Initialized
INFO - 2017-01-31 21:49:09 --> Language Class Initialized
INFO - 2017-01-31 21:49:09 --> Loader Class Initialized
INFO - 2017-01-31 21:49:09 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:09 --> Controller Class Initialized
INFO - 2017-01-31 21:49:09 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:09 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:09 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:09 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:09 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:09 --> Total execution time: 0.0150
INFO - 2017-01-31 21:49:10 --> Config Class Initialized
INFO - 2017-01-31 21:49:10 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:10 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:10 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:10 --> URI Class Initialized
INFO - 2017-01-31 21:49:10 --> Router Class Initialized
INFO - 2017-01-31 21:49:10 --> Output Class Initialized
INFO - 2017-01-31 21:49:10 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:10 --> Input Class Initialized
INFO - 2017-01-31 21:49:10 --> Language Class Initialized
INFO - 2017-01-31 21:49:10 --> Loader Class Initialized
INFO - 2017-01-31 21:49:10 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:10 --> Controller Class Initialized
INFO - 2017-01-31 21:49:10 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:10 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:10 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:10 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:10 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:10 --> Total execution time: 0.0157
INFO - 2017-01-31 21:49:11 --> Config Class Initialized
INFO - 2017-01-31 21:49:11 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:11 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:11 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:11 --> URI Class Initialized
INFO - 2017-01-31 21:49:11 --> Router Class Initialized
INFO - 2017-01-31 21:49:11 --> Output Class Initialized
INFO - 2017-01-31 21:49:11 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:11 --> Input Class Initialized
INFO - 2017-01-31 21:49:11 --> Language Class Initialized
INFO - 2017-01-31 21:49:11 --> Loader Class Initialized
INFO - 2017-01-31 21:49:11 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:11 --> Controller Class Initialized
INFO - 2017-01-31 21:49:11 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:11 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:11 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:11 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:11 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:11 --> Total execution time: 0.0144
INFO - 2017-01-31 21:49:20 --> Config Class Initialized
INFO - 2017-01-31 21:49:20 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:20 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:20 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:20 --> URI Class Initialized
INFO - 2017-01-31 21:49:20 --> Router Class Initialized
INFO - 2017-01-31 21:49:20 --> Output Class Initialized
INFO - 2017-01-31 21:49:20 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:20 --> Input Class Initialized
INFO - 2017-01-31 21:49:20 --> Language Class Initialized
INFO - 2017-01-31 21:49:20 --> Loader Class Initialized
INFO - 2017-01-31 21:49:20 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:20 --> Controller Class Initialized
INFO - 2017-01-31 21:49:20 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:20 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:20 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:20 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:20 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:20 --> Total execution time: 0.0147
INFO - 2017-01-31 21:49:24 --> Config Class Initialized
INFO - 2017-01-31 21:49:24 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:24 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:24 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:24 --> URI Class Initialized
INFO - 2017-01-31 21:49:24 --> Router Class Initialized
INFO - 2017-01-31 21:49:24 --> Output Class Initialized
INFO - 2017-01-31 21:49:24 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:24 --> Input Class Initialized
INFO - 2017-01-31 21:49:24 --> Language Class Initialized
INFO - 2017-01-31 21:49:24 --> Loader Class Initialized
INFO - 2017-01-31 21:49:24 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:24 --> Controller Class Initialized
INFO - 2017-01-31 21:49:24 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:24 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:24 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:24 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:24 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:24 --> Total execution time: 0.0158
INFO - 2017-01-31 21:49:26 --> Config Class Initialized
INFO - 2017-01-31 21:49:26 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:26 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:26 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:26 --> URI Class Initialized
INFO - 2017-01-31 21:49:26 --> Router Class Initialized
INFO - 2017-01-31 21:49:26 --> Output Class Initialized
INFO - 2017-01-31 21:49:26 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:26 --> Input Class Initialized
INFO - 2017-01-31 21:49:26 --> Language Class Initialized
INFO - 2017-01-31 21:49:26 --> Loader Class Initialized
INFO - 2017-01-31 21:49:26 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:26 --> Controller Class Initialized
INFO - 2017-01-31 21:49:26 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:26 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:26 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:26 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:26 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:26 --> Total execution time: 0.0154
INFO - 2017-01-31 21:49:27 --> Config Class Initialized
INFO - 2017-01-31 21:49:27 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:27 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:27 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:27 --> URI Class Initialized
INFO - 2017-01-31 21:49:27 --> Router Class Initialized
INFO - 2017-01-31 21:49:27 --> Output Class Initialized
INFO - 2017-01-31 21:49:27 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:27 --> Input Class Initialized
INFO - 2017-01-31 21:49:27 --> Language Class Initialized
INFO - 2017-01-31 21:49:27 --> Loader Class Initialized
INFO - 2017-01-31 21:49:27 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:27 --> Controller Class Initialized
INFO - 2017-01-31 21:49:27 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:27 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:27 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:27 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:27 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:27 --> Total execution time: 0.0143
INFO - 2017-01-31 21:49:29 --> Config Class Initialized
INFO - 2017-01-31 21:49:29 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:29 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:29 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:29 --> URI Class Initialized
INFO - 2017-01-31 21:49:29 --> Router Class Initialized
INFO - 2017-01-31 21:49:29 --> Output Class Initialized
INFO - 2017-01-31 21:49:29 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:29 --> Input Class Initialized
INFO - 2017-01-31 21:49:29 --> Language Class Initialized
INFO - 2017-01-31 21:49:29 --> Loader Class Initialized
INFO - 2017-01-31 21:49:29 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:29 --> Controller Class Initialized
INFO - 2017-01-31 21:49:29 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:29 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:29 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:29 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:29 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:29 --> Total execution time: 0.0143
INFO - 2017-01-31 21:49:30 --> Config Class Initialized
INFO - 2017-01-31 21:49:30 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:30 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:30 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:30 --> URI Class Initialized
INFO - 2017-01-31 21:49:30 --> Router Class Initialized
INFO - 2017-01-31 21:49:30 --> Output Class Initialized
INFO - 2017-01-31 21:49:30 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:30 --> Input Class Initialized
INFO - 2017-01-31 21:49:30 --> Language Class Initialized
INFO - 2017-01-31 21:49:30 --> Loader Class Initialized
INFO - 2017-01-31 21:49:30 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:30 --> Controller Class Initialized
INFO - 2017-01-31 21:49:30 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:30 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:30 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:30 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:30 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:30 --> Total execution time: 0.0145
INFO - 2017-01-31 21:49:31 --> Config Class Initialized
INFO - 2017-01-31 21:49:31 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:31 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:31 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:31 --> URI Class Initialized
INFO - 2017-01-31 21:49:31 --> Router Class Initialized
INFO - 2017-01-31 21:49:31 --> Output Class Initialized
INFO - 2017-01-31 21:49:31 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:31 --> Input Class Initialized
INFO - 2017-01-31 21:49:31 --> Language Class Initialized
INFO - 2017-01-31 21:49:31 --> Loader Class Initialized
INFO - 2017-01-31 21:49:31 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:31 --> Controller Class Initialized
INFO - 2017-01-31 21:49:31 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:31 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:31 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:31 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:31 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:31 --> Total execution time: 0.0148
INFO - 2017-01-31 21:49:35 --> Config Class Initialized
INFO - 2017-01-31 21:49:35 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:35 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:35 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:35 --> URI Class Initialized
INFO - 2017-01-31 21:49:35 --> Router Class Initialized
INFO - 2017-01-31 21:49:35 --> Output Class Initialized
INFO - 2017-01-31 21:49:35 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:35 --> Input Class Initialized
INFO - 2017-01-31 21:49:35 --> Language Class Initialized
INFO - 2017-01-31 21:49:35 --> Loader Class Initialized
INFO - 2017-01-31 21:49:35 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:35 --> Controller Class Initialized
INFO - 2017-01-31 21:49:35 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:35 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:35 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:35 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:35 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:35 --> Total execution time: 0.0432
INFO - 2017-01-31 21:49:37 --> Config Class Initialized
INFO - 2017-01-31 21:49:37 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:37 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:37 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:37 --> URI Class Initialized
INFO - 2017-01-31 21:49:37 --> Router Class Initialized
INFO - 2017-01-31 21:49:37 --> Output Class Initialized
INFO - 2017-01-31 21:49:37 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:37 --> Input Class Initialized
INFO - 2017-01-31 21:49:37 --> Language Class Initialized
INFO - 2017-01-31 21:49:37 --> Loader Class Initialized
INFO - 2017-01-31 21:49:37 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:37 --> Controller Class Initialized
INFO - 2017-01-31 21:49:37 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:37 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:37 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:37 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:37 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:37 --> Total execution time: 0.0148
INFO - 2017-01-31 21:49:38 --> Config Class Initialized
INFO - 2017-01-31 21:49:38 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:38 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:38 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:38 --> URI Class Initialized
INFO - 2017-01-31 21:49:38 --> Router Class Initialized
INFO - 2017-01-31 21:49:38 --> Output Class Initialized
INFO - 2017-01-31 21:49:38 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:38 --> Input Class Initialized
INFO - 2017-01-31 21:49:38 --> Language Class Initialized
INFO - 2017-01-31 21:49:38 --> Loader Class Initialized
INFO - 2017-01-31 21:49:38 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:38 --> Controller Class Initialized
INFO - 2017-01-31 21:49:38 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:38 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:38 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:38 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:38 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:38 --> Total execution time: 0.0147
INFO - 2017-01-31 21:49:38 --> Config Class Initialized
INFO - 2017-01-31 21:49:38 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:38 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:38 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:38 --> URI Class Initialized
INFO - 2017-01-31 21:49:38 --> Router Class Initialized
INFO - 2017-01-31 21:49:38 --> Output Class Initialized
INFO - 2017-01-31 21:49:38 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:38 --> Input Class Initialized
INFO - 2017-01-31 21:49:38 --> Language Class Initialized
INFO - 2017-01-31 21:49:38 --> Loader Class Initialized
INFO - 2017-01-31 21:49:38 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:38 --> Controller Class Initialized
INFO - 2017-01-31 21:49:38 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:38 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:38 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:38 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:38 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:38 --> Total execution time: 0.0141
INFO - 2017-01-31 21:49:39 --> Config Class Initialized
INFO - 2017-01-31 21:49:39 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:39 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:39 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:39 --> URI Class Initialized
INFO - 2017-01-31 21:49:39 --> Router Class Initialized
INFO - 2017-01-31 21:49:39 --> Output Class Initialized
INFO - 2017-01-31 21:49:39 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:39 --> Input Class Initialized
INFO - 2017-01-31 21:49:39 --> Language Class Initialized
INFO - 2017-01-31 21:49:39 --> Loader Class Initialized
INFO - 2017-01-31 21:49:39 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:39 --> Controller Class Initialized
INFO - 2017-01-31 21:49:39 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:39 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:39 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:39 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:39 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:39 --> Total execution time: 0.0148
INFO - 2017-01-31 21:49:40 --> Config Class Initialized
INFO - 2017-01-31 21:49:40 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:40 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:40 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:40 --> URI Class Initialized
INFO - 2017-01-31 21:49:40 --> Router Class Initialized
INFO - 2017-01-31 21:49:40 --> Output Class Initialized
INFO - 2017-01-31 21:49:40 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:40 --> Input Class Initialized
INFO - 2017-01-31 21:49:40 --> Language Class Initialized
INFO - 2017-01-31 21:49:40 --> Loader Class Initialized
INFO - 2017-01-31 21:49:40 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:40 --> Controller Class Initialized
INFO - 2017-01-31 21:49:40 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:40 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:40 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:40 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:40 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:40 --> Total execution time: 0.0140
INFO - 2017-01-31 21:49:41 --> Config Class Initialized
INFO - 2017-01-31 21:49:41 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:41 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:41 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:41 --> URI Class Initialized
INFO - 2017-01-31 21:49:41 --> Router Class Initialized
INFO - 2017-01-31 21:49:41 --> Output Class Initialized
INFO - 2017-01-31 21:49:41 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:41 --> Input Class Initialized
INFO - 2017-01-31 21:49:41 --> Language Class Initialized
INFO - 2017-01-31 21:49:41 --> Loader Class Initialized
INFO - 2017-01-31 21:49:41 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:41 --> Controller Class Initialized
INFO - 2017-01-31 21:49:41 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:41 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:41 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:41 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:41 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:41 --> Total execution time: 0.0143
INFO - 2017-01-31 21:49:45 --> Config Class Initialized
INFO - 2017-01-31 21:49:45 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:45 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:45 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:45 --> URI Class Initialized
INFO - 2017-01-31 21:49:45 --> Router Class Initialized
INFO - 2017-01-31 21:49:45 --> Output Class Initialized
INFO - 2017-01-31 21:49:45 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:45 --> Input Class Initialized
INFO - 2017-01-31 21:49:45 --> Language Class Initialized
INFO - 2017-01-31 21:49:45 --> Loader Class Initialized
INFO - 2017-01-31 21:49:45 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:45 --> Controller Class Initialized
INFO - 2017-01-31 21:49:45 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:45 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:45 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:45 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:45 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:45 --> Total execution time: 0.0213
INFO - 2017-01-31 21:49:45 --> Config Class Initialized
INFO - 2017-01-31 21:49:45 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:45 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:45 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:45 --> URI Class Initialized
INFO - 2017-01-31 21:49:45 --> Router Class Initialized
INFO - 2017-01-31 21:49:45 --> Output Class Initialized
INFO - 2017-01-31 21:49:45 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:45 --> Input Class Initialized
INFO - 2017-01-31 21:49:45 --> Language Class Initialized
INFO - 2017-01-31 21:49:45 --> Loader Class Initialized
INFO - 2017-01-31 21:49:45 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:45 --> Controller Class Initialized
INFO - 2017-01-31 21:49:45 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:45 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:45 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:45 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:45 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:45 --> Total execution time: 0.0142
INFO - 2017-01-31 21:49:47 --> Config Class Initialized
INFO - 2017-01-31 21:49:47 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:47 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:47 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:47 --> URI Class Initialized
INFO - 2017-01-31 21:49:47 --> Router Class Initialized
INFO - 2017-01-31 21:49:47 --> Output Class Initialized
INFO - 2017-01-31 21:49:47 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:47 --> Input Class Initialized
INFO - 2017-01-31 21:49:47 --> Language Class Initialized
INFO - 2017-01-31 21:49:47 --> Loader Class Initialized
INFO - 2017-01-31 21:49:47 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:47 --> Controller Class Initialized
INFO - 2017-01-31 21:49:47 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:47 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:47 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:47 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:47 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:47 --> Total execution time: 0.0150
INFO - 2017-01-31 21:49:51 --> Config Class Initialized
INFO - 2017-01-31 21:49:51 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:51 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:51 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:51 --> URI Class Initialized
INFO - 2017-01-31 21:49:51 --> Router Class Initialized
INFO - 2017-01-31 21:49:51 --> Output Class Initialized
INFO - 2017-01-31 21:49:51 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:51 --> Input Class Initialized
INFO - 2017-01-31 21:49:51 --> Language Class Initialized
INFO - 2017-01-31 21:49:51 --> Loader Class Initialized
INFO - 2017-01-31 21:49:51 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:51 --> Controller Class Initialized
INFO - 2017-01-31 21:49:51 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:51 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:51 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:51 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:51 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:51 --> Total execution time: 0.0146
INFO - 2017-01-31 21:49:52 --> Config Class Initialized
INFO - 2017-01-31 21:49:52 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:52 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:52 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:52 --> URI Class Initialized
INFO - 2017-01-31 21:49:52 --> Router Class Initialized
INFO - 2017-01-31 21:49:52 --> Output Class Initialized
INFO - 2017-01-31 21:49:52 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:52 --> Input Class Initialized
INFO - 2017-01-31 21:49:52 --> Language Class Initialized
INFO - 2017-01-31 21:49:52 --> Loader Class Initialized
INFO - 2017-01-31 21:49:52 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:52 --> Controller Class Initialized
INFO - 2017-01-31 21:49:52 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:52 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:52 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:52 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:52 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:52 --> Total execution time: 0.0150
INFO - 2017-01-31 21:49:56 --> Config Class Initialized
INFO - 2017-01-31 21:49:56 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:56 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:56 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:56 --> URI Class Initialized
INFO - 2017-01-31 21:49:56 --> Router Class Initialized
INFO - 2017-01-31 21:49:56 --> Output Class Initialized
INFO - 2017-01-31 21:49:56 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:56 --> Input Class Initialized
INFO - 2017-01-31 21:49:56 --> Language Class Initialized
INFO - 2017-01-31 21:49:56 --> Loader Class Initialized
INFO - 2017-01-31 21:49:56 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:56 --> Controller Class Initialized
INFO - 2017-01-31 21:49:56 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:56 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:56 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:56 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:56 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:56 --> Total execution time: 0.0149
INFO - 2017-01-31 21:49:58 --> Config Class Initialized
INFO - 2017-01-31 21:49:58 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:49:58 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:49:58 --> Utf8 Class Initialized
INFO - 2017-01-31 21:49:58 --> URI Class Initialized
INFO - 2017-01-31 21:49:58 --> Router Class Initialized
INFO - 2017-01-31 21:49:58 --> Output Class Initialized
INFO - 2017-01-31 21:49:58 --> Security Class Initialized
DEBUG - 2017-01-31 21:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:49:58 --> Input Class Initialized
INFO - 2017-01-31 21:49:58 --> Language Class Initialized
INFO - 2017-01-31 21:49:58 --> Loader Class Initialized
INFO - 2017-01-31 21:49:58 --> Database Driver Class Initialized
INFO - 2017-01-31 21:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:49:58 --> Controller Class Initialized
INFO - 2017-01-31 21:49:58 --> Helper loaded: date_helper
INFO - 2017-01-31 21:49:58 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:49:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:49:58 --> Helper loaded: form_helper
INFO - 2017-01-31 21:49:58 --> Form Validation Class Initialized
INFO - 2017-01-31 21:49:58 --> Final output sent to browser
DEBUG - 2017-01-31 21:49:58 --> Total execution time: 0.0151
INFO - 2017-01-31 21:50:01 --> Config Class Initialized
INFO - 2017-01-31 21:50:01 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:50:01 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:50:01 --> Utf8 Class Initialized
INFO - 2017-01-31 21:50:01 --> URI Class Initialized
INFO - 2017-01-31 21:50:01 --> Router Class Initialized
INFO - 2017-01-31 21:50:01 --> Output Class Initialized
INFO - 2017-01-31 21:50:01 --> Security Class Initialized
DEBUG - 2017-01-31 21:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:50:01 --> Input Class Initialized
INFO - 2017-01-31 21:50:01 --> Language Class Initialized
INFO - 2017-01-31 21:50:01 --> Loader Class Initialized
INFO - 2017-01-31 21:50:01 --> Database Driver Class Initialized
INFO - 2017-01-31 21:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:50:01 --> Controller Class Initialized
INFO - 2017-01-31 21:50:01 --> Helper loaded: date_helper
INFO - 2017-01-31 21:50:01 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:50:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:50:01 --> Helper loaded: form_helper
INFO - 2017-01-31 21:50:01 --> Form Validation Class Initialized
INFO - 2017-01-31 21:50:01 --> Final output sent to browser
DEBUG - 2017-01-31 21:50:01 --> Total execution time: 0.0145
INFO - 2017-01-31 21:50:03 --> Config Class Initialized
INFO - 2017-01-31 21:50:03 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:50:03 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:50:03 --> Utf8 Class Initialized
INFO - 2017-01-31 21:50:03 --> URI Class Initialized
INFO - 2017-01-31 21:50:03 --> Router Class Initialized
INFO - 2017-01-31 21:50:03 --> Output Class Initialized
INFO - 2017-01-31 21:50:03 --> Security Class Initialized
DEBUG - 2017-01-31 21:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:50:03 --> Input Class Initialized
INFO - 2017-01-31 21:50:03 --> Language Class Initialized
INFO - 2017-01-31 21:50:03 --> Loader Class Initialized
INFO - 2017-01-31 21:50:03 --> Database Driver Class Initialized
INFO - 2017-01-31 21:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:50:03 --> Controller Class Initialized
INFO - 2017-01-31 21:50:03 --> Helper loaded: date_helper
INFO - 2017-01-31 21:50:03 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:50:03 --> Helper loaded: form_helper
INFO - 2017-01-31 21:50:03 --> Form Validation Class Initialized
INFO - 2017-01-31 21:50:03 --> Final output sent to browser
DEBUG - 2017-01-31 21:50:03 --> Total execution time: 0.0145
INFO - 2017-01-31 21:50:08 --> Config Class Initialized
INFO - 2017-01-31 21:50:08 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:50:08 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:50:08 --> Utf8 Class Initialized
INFO - 2017-01-31 21:50:08 --> URI Class Initialized
INFO - 2017-01-31 21:50:08 --> Router Class Initialized
INFO - 2017-01-31 21:50:08 --> Output Class Initialized
INFO - 2017-01-31 21:50:08 --> Security Class Initialized
DEBUG - 2017-01-31 21:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:50:08 --> Input Class Initialized
INFO - 2017-01-31 21:50:08 --> Language Class Initialized
INFO - 2017-01-31 21:50:08 --> Loader Class Initialized
INFO - 2017-01-31 21:50:08 --> Database Driver Class Initialized
INFO - 2017-01-31 21:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:50:08 --> Controller Class Initialized
INFO - 2017-01-31 21:50:08 --> Helper loaded: date_helper
INFO - 2017-01-31 21:50:08 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:50:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:50:08 --> Helper loaded: form_helper
INFO - 2017-01-31 21:50:08 --> Form Validation Class Initialized
INFO - 2017-01-31 21:50:08 --> Final output sent to browser
DEBUG - 2017-01-31 21:50:08 --> Total execution time: 0.0145
INFO - 2017-01-31 21:50:08 --> Config Class Initialized
INFO - 2017-01-31 21:50:08 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:50:08 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:50:08 --> Utf8 Class Initialized
INFO - 2017-01-31 21:50:08 --> URI Class Initialized
INFO - 2017-01-31 21:50:08 --> Router Class Initialized
INFO - 2017-01-31 21:50:08 --> Output Class Initialized
INFO - 2017-01-31 21:50:08 --> Security Class Initialized
DEBUG - 2017-01-31 21:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:50:08 --> Input Class Initialized
INFO - 2017-01-31 21:50:08 --> Language Class Initialized
INFO - 2017-01-31 21:50:08 --> Loader Class Initialized
INFO - 2017-01-31 21:50:08 --> Database Driver Class Initialized
INFO - 2017-01-31 21:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:50:08 --> Controller Class Initialized
INFO - 2017-01-31 21:50:08 --> Helper loaded: date_helper
INFO - 2017-01-31 21:50:08 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:50:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:50:08 --> Helper loaded: form_helper
INFO - 2017-01-31 21:50:08 --> Form Validation Class Initialized
INFO - 2017-01-31 21:50:08 --> Final output sent to browser
DEBUG - 2017-01-31 21:50:08 --> Total execution time: 0.0153
INFO - 2017-01-31 21:50:10 --> Config Class Initialized
INFO - 2017-01-31 21:50:10 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:50:10 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:50:10 --> Utf8 Class Initialized
INFO - 2017-01-31 21:50:10 --> URI Class Initialized
INFO - 2017-01-31 21:50:10 --> Router Class Initialized
INFO - 2017-01-31 21:50:10 --> Output Class Initialized
INFO - 2017-01-31 21:50:10 --> Security Class Initialized
DEBUG - 2017-01-31 21:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:50:10 --> Input Class Initialized
INFO - 2017-01-31 21:50:10 --> Language Class Initialized
INFO - 2017-01-31 21:50:10 --> Loader Class Initialized
INFO - 2017-01-31 21:50:10 --> Database Driver Class Initialized
INFO - 2017-01-31 21:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:50:10 --> Controller Class Initialized
INFO - 2017-01-31 21:50:10 --> Helper loaded: date_helper
INFO - 2017-01-31 21:50:10 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:50:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:50:10 --> Helper loaded: form_helper
INFO - 2017-01-31 21:50:10 --> Form Validation Class Initialized
INFO - 2017-01-31 21:50:10 --> Final output sent to browser
DEBUG - 2017-01-31 21:50:10 --> Total execution time: 0.0143
INFO - 2017-01-31 21:50:11 --> Config Class Initialized
INFO - 2017-01-31 21:50:11 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:50:11 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:50:11 --> Utf8 Class Initialized
INFO - 2017-01-31 21:50:11 --> URI Class Initialized
INFO - 2017-01-31 21:50:11 --> Router Class Initialized
INFO - 2017-01-31 21:50:11 --> Output Class Initialized
INFO - 2017-01-31 21:50:11 --> Security Class Initialized
DEBUG - 2017-01-31 21:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:50:11 --> Input Class Initialized
INFO - 2017-01-31 21:50:11 --> Language Class Initialized
INFO - 2017-01-31 21:50:11 --> Loader Class Initialized
INFO - 2017-01-31 21:50:11 --> Database Driver Class Initialized
INFO - 2017-01-31 21:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:50:11 --> Controller Class Initialized
INFO - 2017-01-31 21:50:11 --> Helper loaded: date_helper
INFO - 2017-01-31 21:50:11 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:50:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:50:11 --> Helper loaded: form_helper
INFO - 2017-01-31 21:50:11 --> Form Validation Class Initialized
INFO - 2017-01-31 21:50:11 --> Final output sent to browser
DEBUG - 2017-01-31 21:50:11 --> Total execution time: 0.0141
INFO - 2017-01-31 21:50:45 --> Config Class Initialized
INFO - 2017-01-31 21:50:45 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:50:45 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:50:45 --> Utf8 Class Initialized
INFO - 2017-01-31 21:50:45 --> URI Class Initialized
INFO - 2017-01-31 21:50:45 --> Router Class Initialized
INFO - 2017-01-31 21:50:45 --> Output Class Initialized
INFO - 2017-01-31 21:50:45 --> Security Class Initialized
DEBUG - 2017-01-31 21:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:50:45 --> Input Class Initialized
INFO - 2017-01-31 21:50:45 --> Language Class Initialized
INFO - 2017-01-31 21:50:45 --> Loader Class Initialized
INFO - 2017-01-31 21:50:45 --> Database Driver Class Initialized
INFO - 2017-01-31 21:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:50:45 --> Controller Class Initialized
INFO - 2017-01-31 21:50:45 --> Helper loaded: date_helper
INFO - 2017-01-31 21:50:45 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:50:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:50:45 --> Helper loaded: form_helper
INFO - 2017-01-31 21:50:45 --> Form Validation Class Initialized
INFO - 2017-01-31 21:50:45 --> Final output sent to browser
DEBUG - 2017-01-31 21:50:45 --> Total execution time: 0.0146
INFO - 2017-01-31 21:51:06 --> Config Class Initialized
INFO - 2017-01-31 21:51:06 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:51:06 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:51:06 --> Utf8 Class Initialized
INFO - 2017-01-31 21:51:06 --> URI Class Initialized
INFO - 2017-01-31 21:51:06 --> Router Class Initialized
INFO - 2017-01-31 21:51:06 --> Output Class Initialized
INFO - 2017-01-31 21:51:06 --> Security Class Initialized
DEBUG - 2017-01-31 21:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:51:06 --> Input Class Initialized
INFO - 2017-01-31 21:51:06 --> Language Class Initialized
INFO - 2017-01-31 21:51:06 --> Loader Class Initialized
INFO - 2017-01-31 21:51:06 --> Database Driver Class Initialized
INFO - 2017-01-31 21:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:51:06 --> Controller Class Initialized
INFO - 2017-01-31 21:51:06 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:51:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:51:06 --> Config Class Initialized
INFO - 2017-01-31 21:51:06 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:51:06 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:51:06 --> Utf8 Class Initialized
INFO - 2017-01-31 21:51:06 --> URI Class Initialized
INFO - 2017-01-31 21:51:06 --> Router Class Initialized
INFO - 2017-01-31 21:51:06 --> Output Class Initialized
INFO - 2017-01-31 21:51:06 --> Security Class Initialized
DEBUG - 2017-01-31 21:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:51:06 --> Input Class Initialized
INFO - 2017-01-31 21:51:06 --> Language Class Initialized
INFO - 2017-01-31 21:51:06 --> Loader Class Initialized
INFO - 2017-01-31 21:51:06 --> Database Driver Class Initialized
INFO - 2017-01-31 21:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:51:06 --> Controller Class Initialized
INFO - 2017-01-31 21:51:06 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:51:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:51:06 --> Helper loaded: form_helper
INFO - 2017-01-31 21:51:06 --> Form Validation Class Initialized
INFO - 2017-01-31 21:51:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-31 21:51:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-31 21:51:06 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-31 21:51:06 --> Final output sent to browser
DEBUG - 2017-01-31 21:51:06 --> Total execution time: 0.0132
INFO - 2017-01-31 21:51:06 --> Config Class Initialized
INFO - 2017-01-31 21:51:06 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:51:06 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:51:06 --> Utf8 Class Initialized
INFO - 2017-01-31 21:51:06 --> URI Class Initialized
INFO - 2017-01-31 21:51:06 --> Router Class Initialized
INFO - 2017-01-31 21:51:06 --> Output Class Initialized
INFO - 2017-01-31 21:51:06 --> Security Class Initialized
DEBUG - 2017-01-31 21:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:51:06 --> Input Class Initialized
INFO - 2017-01-31 21:51:06 --> Language Class Initialized
INFO - 2017-01-31 21:51:06 --> Loader Class Initialized
INFO - 2017-01-31 21:51:06 --> Database Driver Class Initialized
INFO - 2017-01-31 21:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:51:06 --> Controller Class Initialized
INFO - 2017-01-31 21:51:06 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:51:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 21:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 21:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 21:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 21:51:06 --> Final output sent to browser
DEBUG - 2017-01-31 21:51:06 --> Total execution time: 0.0136
INFO - 2017-01-31 21:51:06 --> Config Class Initialized
INFO - 2017-01-31 21:51:06 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:51:06 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:51:06 --> Utf8 Class Initialized
INFO - 2017-01-31 21:51:06 --> URI Class Initialized
INFO - 2017-01-31 21:51:06 --> Router Class Initialized
INFO - 2017-01-31 21:51:06 --> Output Class Initialized
INFO - 2017-01-31 21:51:06 --> Security Class Initialized
DEBUG - 2017-01-31 21:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:51:06 --> Input Class Initialized
INFO - 2017-01-31 21:51:06 --> Language Class Initialized
INFO - 2017-01-31 21:51:06 --> Loader Class Initialized
INFO - 2017-01-31 21:51:06 --> Database Driver Class Initialized
INFO - 2017-01-31 21:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:51:06 --> Controller Class Initialized
INFO - 2017-01-31 21:51:06 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:51:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 21:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 21:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 21:51:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 21:51:06 --> Final output sent to browser
DEBUG - 2017-01-31 21:51:06 --> Total execution time: 0.0134
INFO - 2017-01-31 21:51:12 --> Config Class Initialized
INFO - 2017-01-31 21:51:12 --> Hooks Class Initialized
DEBUG - 2017-01-31 21:51:12 --> UTF-8 Support Enabled
INFO - 2017-01-31 21:51:12 --> Utf8 Class Initialized
INFO - 2017-01-31 21:51:12 --> URI Class Initialized
DEBUG - 2017-01-31 21:51:12 --> No URI present. Default controller set.
INFO - 2017-01-31 21:51:12 --> Router Class Initialized
INFO - 2017-01-31 21:51:12 --> Output Class Initialized
INFO - 2017-01-31 21:51:12 --> Security Class Initialized
DEBUG - 2017-01-31 21:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 21:51:12 --> Input Class Initialized
INFO - 2017-01-31 21:51:12 --> Language Class Initialized
INFO - 2017-01-31 21:51:12 --> Loader Class Initialized
INFO - 2017-01-31 21:51:12 --> Database Driver Class Initialized
INFO - 2017-01-31 21:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 21:51:12 --> Controller Class Initialized
INFO - 2017-01-31 21:51:12 --> Helper loaded: url_helper
DEBUG - 2017-01-31 21:51:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 21:51:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 21:51:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 21:51:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 21:51:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 21:51:12 --> Final output sent to browser
DEBUG - 2017-01-31 21:51:12 --> Total execution time: 0.0135
INFO - 2017-01-31 22:22:52 --> Config Class Initialized
INFO - 2017-01-31 22:22:52 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:22:52 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:22:52 --> Utf8 Class Initialized
INFO - 2017-01-31 22:22:52 --> URI Class Initialized
DEBUG - 2017-01-31 22:22:52 --> No URI present. Default controller set.
INFO - 2017-01-31 22:22:52 --> Router Class Initialized
INFO - 2017-01-31 22:22:52 --> Output Class Initialized
INFO - 2017-01-31 22:22:52 --> Security Class Initialized
DEBUG - 2017-01-31 22:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:22:52 --> Input Class Initialized
INFO - 2017-01-31 22:22:52 --> Language Class Initialized
INFO - 2017-01-31 22:22:52 --> Loader Class Initialized
INFO - 2017-01-31 22:22:52 --> Database Driver Class Initialized
INFO - 2017-01-31 22:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:22:52 --> Controller Class Initialized
INFO - 2017-01-31 22:22:52 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:22:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:22:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:22:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:22:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:22:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:22:52 --> Final output sent to browser
DEBUG - 2017-01-31 22:22:52 --> Total execution time: 0.0160
INFO - 2017-01-31 22:23:13 --> Config Class Initialized
INFO - 2017-01-31 22:23:13 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:23:13 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:23:13 --> Utf8 Class Initialized
INFO - 2017-01-31 22:23:13 --> URI Class Initialized
INFO - 2017-01-31 22:23:13 --> Router Class Initialized
INFO - 2017-01-31 22:23:13 --> Output Class Initialized
INFO - 2017-01-31 22:23:13 --> Security Class Initialized
DEBUG - 2017-01-31 22:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:23:13 --> Input Class Initialized
INFO - 2017-01-31 22:23:13 --> Language Class Initialized
INFO - 2017-01-31 22:23:13 --> Loader Class Initialized
INFO - 2017-01-31 22:23:13 --> Database Driver Class Initialized
INFO - 2017-01-31 22:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:23:13 --> Controller Class Initialized
INFO - 2017-01-31 22:23:13 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:23:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:23:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:23:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:23:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:23:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:23:13 --> Final output sent to browser
DEBUG - 2017-01-31 22:23:13 --> Total execution time: 0.0131
INFO - 2017-01-31 22:24:29 --> Config Class Initialized
INFO - 2017-01-31 22:24:29 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:24:29 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:24:29 --> Utf8 Class Initialized
INFO - 2017-01-31 22:24:29 --> URI Class Initialized
INFO - 2017-01-31 22:24:29 --> Router Class Initialized
INFO - 2017-01-31 22:24:29 --> Output Class Initialized
INFO - 2017-01-31 22:24:29 --> Security Class Initialized
DEBUG - 2017-01-31 22:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:24:29 --> Input Class Initialized
INFO - 2017-01-31 22:24:29 --> Language Class Initialized
INFO - 2017-01-31 22:24:29 --> Loader Class Initialized
INFO - 2017-01-31 22:24:29 --> Database Driver Class Initialized
INFO - 2017-01-31 22:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:24:29 --> Controller Class Initialized
INFO - 2017-01-31 22:24:29 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:24:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-31 22:24:31 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-31 22:24:31 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Janeth Piñon')
INFO - 2017-01-31 22:24:31 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-31 22:24:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-31 22:24:31 --> Config Class Initialized
INFO - 2017-01-31 22:24:31 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:24:31 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:24:31 --> Utf8 Class Initialized
INFO - 2017-01-31 22:24:31 --> URI Class Initialized
INFO - 2017-01-31 22:24:31 --> Router Class Initialized
INFO - 2017-01-31 22:24:31 --> Output Class Initialized
INFO - 2017-01-31 22:24:31 --> Security Class Initialized
DEBUG - 2017-01-31 22:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:24:31 --> Input Class Initialized
INFO - 2017-01-31 22:24:31 --> Language Class Initialized
INFO - 2017-01-31 22:24:31 --> Loader Class Initialized
INFO - 2017-01-31 22:24:31 --> Database Driver Class Initialized
INFO - 2017-01-31 22:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:24:31 --> Controller Class Initialized
INFO - 2017-01-31 22:24:31 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:24:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:24:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:24:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:24:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:24:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:24:31 --> Final output sent to browser
DEBUG - 2017-01-31 22:24:31 --> Total execution time: 0.0214
INFO - 2017-01-31 22:25:18 --> Config Class Initialized
INFO - 2017-01-31 22:25:18 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:25:18 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:25:18 --> Utf8 Class Initialized
INFO - 2017-01-31 22:25:18 --> URI Class Initialized
INFO - 2017-01-31 22:25:18 --> Router Class Initialized
INFO - 2017-01-31 22:25:18 --> Output Class Initialized
INFO - 2017-01-31 22:25:18 --> Security Class Initialized
DEBUG - 2017-01-31 22:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:25:18 --> Input Class Initialized
INFO - 2017-01-31 22:25:18 --> Language Class Initialized
INFO - 2017-01-31 22:25:18 --> Loader Class Initialized
INFO - 2017-01-31 22:25:18 --> Database Driver Class Initialized
INFO - 2017-01-31 22:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:25:18 --> Controller Class Initialized
INFO - 2017-01-31 22:25:18 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:25:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-31 22:25:19 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-31 22:25:19 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Janeth Piñon')
INFO - 2017-01-31 22:25:19 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-31 22:25:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-31 22:25:19 --> Config Class Initialized
INFO - 2017-01-31 22:25:19 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:25:19 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:25:19 --> Utf8 Class Initialized
INFO - 2017-01-31 22:25:19 --> URI Class Initialized
INFO - 2017-01-31 22:25:19 --> Router Class Initialized
INFO - 2017-01-31 22:25:19 --> Output Class Initialized
INFO - 2017-01-31 22:25:19 --> Security Class Initialized
DEBUG - 2017-01-31 22:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:25:19 --> Input Class Initialized
INFO - 2017-01-31 22:25:19 --> Language Class Initialized
INFO - 2017-01-31 22:25:19 --> Loader Class Initialized
INFO - 2017-01-31 22:25:19 --> Database Driver Class Initialized
INFO - 2017-01-31 22:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:25:19 --> Controller Class Initialized
INFO - 2017-01-31 22:25:19 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:25:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:25:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:25:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:25:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:25:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:25:19 --> Final output sent to browser
DEBUG - 2017-01-31 22:25:19 --> Total execution time: 0.0132
INFO - 2017-01-31 22:25:22 --> Config Class Initialized
INFO - 2017-01-31 22:25:22 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:25:22 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:25:22 --> Utf8 Class Initialized
INFO - 2017-01-31 22:25:22 --> URI Class Initialized
DEBUG - 2017-01-31 22:25:22 --> No URI present. Default controller set.
INFO - 2017-01-31 22:25:22 --> Router Class Initialized
INFO - 2017-01-31 22:25:22 --> Output Class Initialized
INFO - 2017-01-31 22:25:22 --> Security Class Initialized
DEBUG - 2017-01-31 22:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:25:22 --> Input Class Initialized
INFO - 2017-01-31 22:25:22 --> Language Class Initialized
INFO - 2017-01-31 22:25:22 --> Loader Class Initialized
INFO - 2017-01-31 22:25:22 --> Database Driver Class Initialized
INFO - 2017-01-31 22:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:25:22 --> Controller Class Initialized
INFO - 2017-01-31 22:25:22 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:25:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:25:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:25:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:25:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:25:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:25:22 --> Final output sent to browser
DEBUG - 2017-01-31 22:25:22 --> Total execution time: 0.0134
INFO - 2017-01-31 22:25:24 --> Config Class Initialized
INFO - 2017-01-31 22:25:24 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:25:24 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:25:24 --> Utf8 Class Initialized
INFO - 2017-01-31 22:25:24 --> URI Class Initialized
INFO - 2017-01-31 22:25:24 --> Router Class Initialized
INFO - 2017-01-31 22:25:24 --> Output Class Initialized
INFO - 2017-01-31 22:25:24 --> Security Class Initialized
DEBUG - 2017-01-31 22:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:25:24 --> Input Class Initialized
INFO - 2017-01-31 22:25:24 --> Language Class Initialized
INFO - 2017-01-31 22:25:24 --> Loader Class Initialized
INFO - 2017-01-31 22:25:24 --> Database Driver Class Initialized
INFO - 2017-01-31 22:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:25:24 --> Controller Class Initialized
INFO - 2017-01-31 22:25:24 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:25:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:25:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:25:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:25:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:25:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:25:24 --> Final output sent to browser
DEBUG - 2017-01-31 22:25:24 --> Total execution time: 0.0130
INFO - 2017-01-31 22:25:35 --> Config Class Initialized
INFO - 2017-01-31 22:25:35 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:25:35 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:25:35 --> Utf8 Class Initialized
INFO - 2017-01-31 22:25:35 --> URI Class Initialized
INFO - 2017-01-31 22:25:35 --> Router Class Initialized
INFO - 2017-01-31 22:25:35 --> Output Class Initialized
INFO - 2017-01-31 22:25:35 --> Security Class Initialized
DEBUG - 2017-01-31 22:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:25:35 --> Input Class Initialized
INFO - 2017-01-31 22:25:35 --> Language Class Initialized
INFO - 2017-01-31 22:25:35 --> Loader Class Initialized
INFO - 2017-01-31 22:25:35 --> Database Driver Class Initialized
INFO - 2017-01-31 22:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:25:35 --> Controller Class Initialized
INFO - 2017-01-31 22:25:35 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:25:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-31 22:25:35 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-31 22:25:35 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Janeth Piñon')
INFO - 2017-01-31 22:25:35 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-31 22:25:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-31 22:25:36 --> Config Class Initialized
INFO - 2017-01-31 22:25:36 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:25:36 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:25:36 --> Utf8 Class Initialized
INFO - 2017-01-31 22:25:36 --> URI Class Initialized
INFO - 2017-01-31 22:25:36 --> Router Class Initialized
INFO - 2017-01-31 22:25:36 --> Output Class Initialized
INFO - 2017-01-31 22:25:36 --> Security Class Initialized
DEBUG - 2017-01-31 22:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:25:36 --> Input Class Initialized
INFO - 2017-01-31 22:25:36 --> Language Class Initialized
INFO - 2017-01-31 22:25:36 --> Loader Class Initialized
INFO - 2017-01-31 22:25:36 --> Database Driver Class Initialized
INFO - 2017-01-31 22:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:25:36 --> Controller Class Initialized
INFO - 2017-01-31 22:25:36 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:25:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:25:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:25:36 --> Final output sent to browser
DEBUG - 2017-01-31 22:25:36 --> Total execution time: 0.0132
INFO - 2017-01-31 22:26:13 --> Config Class Initialized
INFO - 2017-01-31 22:26:13 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:26:13 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:26:13 --> Utf8 Class Initialized
INFO - 2017-01-31 22:26:13 --> URI Class Initialized
INFO - 2017-01-31 22:26:13 --> Router Class Initialized
INFO - 2017-01-31 22:26:13 --> Output Class Initialized
INFO - 2017-01-31 22:26:13 --> Security Class Initialized
DEBUG - 2017-01-31 22:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:26:13 --> Input Class Initialized
INFO - 2017-01-31 22:26:13 --> Language Class Initialized
INFO - 2017-01-31 22:26:13 --> Loader Class Initialized
INFO - 2017-01-31 22:26:13 --> Database Driver Class Initialized
INFO - 2017-01-31 22:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:26:13 --> Controller Class Initialized
INFO - 2017-01-31 22:26:13 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:26:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:26:13 --> Helper loaded: form_helper
INFO - 2017-01-31 22:26:13 --> Form Validation Class Initialized
INFO - 2017-01-31 22:26:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-01-31 22:26:13 --> Config Class Initialized
INFO - 2017-01-31 22:26:13 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:26:13 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:26:13 --> Utf8 Class Initialized
INFO - 2017-01-31 22:26:13 --> URI Class Initialized
INFO - 2017-01-31 22:26:13 --> Router Class Initialized
INFO - 2017-01-31 22:26:13 --> Output Class Initialized
INFO - 2017-01-31 22:26:13 --> Security Class Initialized
DEBUG - 2017-01-31 22:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:26:13 --> Input Class Initialized
INFO - 2017-01-31 22:26:13 --> Language Class Initialized
INFO - 2017-01-31 22:26:13 --> Loader Class Initialized
INFO - 2017-01-31 22:26:13 --> Database Driver Class Initialized
INFO - 2017-01-31 22:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:26:13 --> Controller Class Initialized
INFO - 2017-01-31 22:26:13 --> Helper loaded: date_helper
INFO - 2017-01-31 22:26:13 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:26:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:26:13 --> Helper loaded: form_helper
INFO - 2017-01-31 22:26:13 --> Form Validation Class Initialized
INFO - 2017-01-31 22:26:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-31 22:26:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-31 22:26:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/gestion_pedidos.php
INFO - 2017-01-31 22:26:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/gestion_pedidos.php
INFO - 2017-01-31 22:26:13 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-31 22:26:13 --> Final output sent to browser
DEBUG - 2017-01-31 22:26:13 --> Total execution time: 0.0151
INFO - 2017-01-31 22:26:14 --> Config Class Initialized
INFO - 2017-01-31 22:26:14 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:26:14 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:26:14 --> Utf8 Class Initialized
INFO - 2017-01-31 22:26:14 --> URI Class Initialized
INFO - 2017-01-31 22:26:14 --> Router Class Initialized
INFO - 2017-01-31 22:26:14 --> Output Class Initialized
INFO - 2017-01-31 22:26:14 --> Security Class Initialized
DEBUG - 2017-01-31 22:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:26:14 --> Input Class Initialized
INFO - 2017-01-31 22:26:14 --> Language Class Initialized
INFO - 2017-01-31 22:26:14 --> Loader Class Initialized
INFO - 2017-01-31 22:26:14 --> Database Driver Class Initialized
INFO - 2017-01-31 22:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:26:14 --> Controller Class Initialized
INFO - 2017-01-31 22:26:14 --> Helper loaded: date_helper
INFO - 2017-01-31 22:26:14 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:26:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:26:14 --> Helper loaded: form_helper
INFO - 2017-01-31 22:26:14 --> Form Validation Class Initialized
INFO - 2017-01-31 22:26:14 --> Final output sent to browser
DEBUG - 2017-01-31 22:26:14 --> Total execution time: 0.0143
INFO - 2017-01-31 22:26:14 --> Config Class Initialized
INFO - 2017-01-31 22:26:14 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:26:14 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:26:14 --> Utf8 Class Initialized
INFO - 2017-01-31 22:26:14 --> URI Class Initialized
INFO - 2017-01-31 22:26:14 --> Router Class Initialized
INFO - 2017-01-31 22:26:14 --> Output Class Initialized
INFO - 2017-01-31 22:26:14 --> Security Class Initialized
DEBUG - 2017-01-31 22:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:26:14 --> Input Class Initialized
INFO - 2017-01-31 22:26:14 --> Language Class Initialized
INFO - 2017-01-31 22:26:14 --> Loader Class Initialized
INFO - 2017-01-31 22:26:14 --> Database Driver Class Initialized
INFO - 2017-01-31 22:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:26:14 --> Controller Class Initialized
INFO - 2017-01-31 22:26:14 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:26:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:26:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:26:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:26:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:26:14 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:26:14 --> Final output sent to browser
DEBUG - 2017-01-31 22:26:14 --> Total execution time: 0.0158
INFO - 2017-01-31 22:26:20 --> Config Class Initialized
INFO - 2017-01-31 22:26:20 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:26:20 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:26:20 --> Utf8 Class Initialized
INFO - 2017-01-31 22:26:20 --> URI Class Initialized
DEBUG - 2017-01-31 22:26:20 --> No URI present. Default controller set.
INFO - 2017-01-31 22:26:20 --> Router Class Initialized
INFO - 2017-01-31 22:26:20 --> Output Class Initialized
INFO - 2017-01-31 22:26:20 --> Security Class Initialized
DEBUG - 2017-01-31 22:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:26:20 --> Input Class Initialized
INFO - 2017-01-31 22:26:20 --> Language Class Initialized
INFO - 2017-01-31 22:26:20 --> Loader Class Initialized
INFO - 2017-01-31 22:26:20 --> Database Driver Class Initialized
INFO - 2017-01-31 22:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:26:20 --> Controller Class Initialized
INFO - 2017-01-31 22:26:20 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:26:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:26:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:26:20 --> Final output sent to browser
DEBUG - 2017-01-31 22:26:20 --> Total execution time: 0.0129
INFO - 2017-01-31 22:26:21 --> Config Class Initialized
INFO - 2017-01-31 22:26:21 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:26:21 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:26:21 --> Utf8 Class Initialized
INFO - 2017-01-31 22:26:21 --> URI Class Initialized
INFO - 2017-01-31 22:26:21 --> Router Class Initialized
INFO - 2017-01-31 22:26:21 --> Output Class Initialized
INFO - 2017-01-31 22:26:21 --> Security Class Initialized
DEBUG - 2017-01-31 22:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:26:21 --> Input Class Initialized
INFO - 2017-01-31 22:26:21 --> Language Class Initialized
INFO - 2017-01-31 22:26:21 --> Loader Class Initialized
INFO - 2017-01-31 22:26:21 --> Database Driver Class Initialized
INFO - 2017-01-31 22:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:26:21 --> Controller Class Initialized
INFO - 2017-01-31 22:26:21 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:26:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:26:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:26:21 --> Final output sent to browser
DEBUG - 2017-01-31 22:26:21 --> Total execution time: 0.0130
INFO - 2017-01-31 22:26:23 --> Config Class Initialized
INFO - 2017-01-31 22:26:23 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:26:23 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:26:23 --> Utf8 Class Initialized
INFO - 2017-01-31 22:26:23 --> URI Class Initialized
INFO - 2017-01-31 22:26:23 --> Router Class Initialized
INFO - 2017-01-31 22:26:23 --> Output Class Initialized
INFO - 2017-01-31 22:26:23 --> Security Class Initialized
DEBUG - 2017-01-31 22:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:26:23 --> Input Class Initialized
INFO - 2017-01-31 22:26:23 --> Language Class Initialized
INFO - 2017-01-31 22:26:23 --> Loader Class Initialized
INFO - 2017-01-31 22:26:23 --> Database Driver Class Initialized
INFO - 2017-01-31 22:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:26:23 --> Controller Class Initialized
INFO - 2017-01-31 22:26:23 --> Helper loaded: date_helper
INFO - 2017-01-31 22:26:23 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:26:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:26:23 --> Helper loaded: form_helper
INFO - 2017-01-31 22:26:23 --> Form Validation Class Initialized
INFO - 2017-01-31 22:26:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-31 22:26:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/navigation.php
INFO - 2017-01-31 22:26:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/asignacion.php
INFO - 2017-01-31 22:26:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/scripts/asignacion.php
INFO - 2017-01-31 22:26:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-31 22:26:23 --> Final output sent to browser
DEBUG - 2017-01-31 22:26:23 --> Total execution time: 0.0147
INFO - 2017-01-31 22:26:23 --> Config Class Initialized
INFO - 2017-01-31 22:26:23 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:26:23 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:26:23 --> Utf8 Class Initialized
INFO - 2017-01-31 22:26:23 --> URI Class Initialized
INFO - 2017-01-31 22:26:23 --> Router Class Initialized
INFO - 2017-01-31 22:26:23 --> Output Class Initialized
INFO - 2017-01-31 22:26:23 --> Security Class Initialized
DEBUG - 2017-01-31 22:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:26:23 --> Input Class Initialized
INFO - 2017-01-31 22:26:23 --> Language Class Initialized
INFO - 2017-01-31 22:26:23 --> Loader Class Initialized
INFO - 2017-01-31 22:26:23 --> Database Driver Class Initialized
INFO - 2017-01-31 22:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:26:23 --> Controller Class Initialized
INFO - 2017-01-31 22:26:23 --> Helper loaded: date_helper
INFO - 2017-01-31 22:26:23 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:26:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:26:23 --> Helper loaded: form_helper
INFO - 2017-01-31 22:26:23 --> Form Validation Class Initialized
INFO - 2017-01-31 22:26:23 --> Final output sent to browser
DEBUG - 2017-01-31 22:26:23 --> Total execution time: 0.0143
INFO - 2017-01-31 22:26:23 --> Config Class Initialized
INFO - 2017-01-31 22:26:23 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:26:23 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:26:23 --> Utf8 Class Initialized
INFO - 2017-01-31 22:26:23 --> URI Class Initialized
INFO - 2017-01-31 22:26:23 --> Router Class Initialized
INFO - 2017-01-31 22:26:23 --> Output Class Initialized
INFO - 2017-01-31 22:26:23 --> Security Class Initialized
DEBUG - 2017-01-31 22:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:26:23 --> Input Class Initialized
INFO - 2017-01-31 22:26:23 --> Language Class Initialized
INFO - 2017-01-31 22:26:23 --> Loader Class Initialized
INFO - 2017-01-31 22:26:23 --> Database Driver Class Initialized
INFO - 2017-01-31 22:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:26:23 --> Controller Class Initialized
INFO - 2017-01-31 22:26:23 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:26:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:26:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:26:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:26:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:26:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:26:23 --> Final output sent to browser
DEBUG - 2017-01-31 22:26:23 --> Total execution time: 0.0141
INFO - 2017-01-31 22:26:27 --> Config Class Initialized
INFO - 2017-01-31 22:26:27 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:26:27 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:26:27 --> Utf8 Class Initialized
INFO - 2017-01-31 22:26:27 --> URI Class Initialized
INFO - 2017-01-31 22:26:27 --> Router Class Initialized
INFO - 2017-01-31 22:26:27 --> Output Class Initialized
INFO - 2017-01-31 22:26:27 --> Security Class Initialized
DEBUG - 2017-01-31 22:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:26:27 --> Input Class Initialized
INFO - 2017-01-31 22:26:27 --> Language Class Initialized
INFO - 2017-01-31 22:26:27 --> Loader Class Initialized
INFO - 2017-01-31 22:26:27 --> Database Driver Class Initialized
INFO - 2017-01-31 22:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:26:27 --> Controller Class Initialized
INFO - 2017-01-31 22:26:27 --> Helper loaded: date_helper
INFO - 2017-01-31 22:26:27 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:26:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:26:27 --> Helper loaded: form_helper
INFO - 2017-01-31 22:26:27 --> Form Validation Class Initialized
INFO - 2017-01-31 22:26:27 --> Final output sent to browser
DEBUG - 2017-01-31 22:26:27 --> Total execution time: 0.0147
INFO - 2017-01-31 22:26:28 --> Config Class Initialized
INFO - 2017-01-31 22:26:28 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:26:28 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:26:28 --> Utf8 Class Initialized
INFO - 2017-01-31 22:26:28 --> URI Class Initialized
INFO - 2017-01-31 22:26:28 --> Router Class Initialized
INFO - 2017-01-31 22:26:28 --> Output Class Initialized
INFO - 2017-01-31 22:26:28 --> Security Class Initialized
DEBUG - 2017-01-31 22:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:26:28 --> Input Class Initialized
INFO - 2017-01-31 22:26:28 --> Language Class Initialized
INFO - 2017-01-31 22:26:28 --> Loader Class Initialized
INFO - 2017-01-31 22:26:28 --> Database Driver Class Initialized
INFO - 2017-01-31 22:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:26:28 --> Controller Class Initialized
INFO - 2017-01-31 22:26:28 --> Helper loaded: date_helper
INFO - 2017-01-31 22:26:28 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:26:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:26:28 --> Helper loaded: form_helper
INFO - 2017-01-31 22:26:28 --> Form Validation Class Initialized
INFO - 2017-01-31 22:26:28 --> Final output sent to browser
DEBUG - 2017-01-31 22:26:28 --> Total execution time: 0.0141
INFO - 2017-01-31 22:26:30 --> Config Class Initialized
INFO - 2017-01-31 22:26:30 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:26:30 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:26:30 --> Utf8 Class Initialized
INFO - 2017-01-31 22:26:30 --> URI Class Initialized
INFO - 2017-01-31 22:26:30 --> Router Class Initialized
INFO - 2017-01-31 22:26:30 --> Output Class Initialized
INFO - 2017-01-31 22:26:30 --> Security Class Initialized
DEBUG - 2017-01-31 22:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:26:30 --> Input Class Initialized
INFO - 2017-01-31 22:26:30 --> Language Class Initialized
INFO - 2017-01-31 22:26:30 --> Loader Class Initialized
INFO - 2017-01-31 22:26:30 --> Database Driver Class Initialized
INFO - 2017-01-31 22:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:26:30 --> Controller Class Initialized
INFO - 2017-01-31 22:26:30 --> Helper loaded: date_helper
INFO - 2017-01-31 22:26:30 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:26:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:26:30 --> Helper loaded: form_helper
INFO - 2017-01-31 22:26:30 --> Form Validation Class Initialized
INFO - 2017-01-31 22:26:30 --> Final output sent to browser
DEBUG - 2017-01-31 22:26:30 --> Total execution time: 0.0175
INFO - 2017-01-31 22:26:32 --> Config Class Initialized
INFO - 2017-01-31 22:26:32 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:26:32 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:26:32 --> Utf8 Class Initialized
INFO - 2017-01-31 22:26:32 --> URI Class Initialized
INFO - 2017-01-31 22:26:32 --> Router Class Initialized
INFO - 2017-01-31 22:26:32 --> Output Class Initialized
INFO - 2017-01-31 22:26:32 --> Security Class Initialized
DEBUG - 2017-01-31 22:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:26:32 --> Input Class Initialized
INFO - 2017-01-31 22:26:32 --> Language Class Initialized
INFO - 2017-01-31 22:26:32 --> Loader Class Initialized
INFO - 2017-01-31 22:26:32 --> Database Driver Class Initialized
INFO - 2017-01-31 22:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:26:32 --> Controller Class Initialized
INFO - 2017-01-31 22:26:32 --> Helper loaded: date_helper
INFO - 2017-01-31 22:26:32 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:26:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:26:32 --> Helper loaded: form_helper
INFO - 2017-01-31 22:26:32 --> Form Validation Class Initialized
INFO - 2017-01-31 22:26:32 --> Final output sent to browser
DEBUG - 2017-01-31 22:26:32 --> Total execution time: 0.0825
INFO - 2017-01-31 22:26:40 --> Config Class Initialized
INFO - 2017-01-31 22:26:40 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:26:40 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:26:40 --> Utf8 Class Initialized
INFO - 2017-01-31 22:26:40 --> URI Class Initialized
INFO - 2017-01-31 22:26:40 --> Router Class Initialized
INFO - 2017-01-31 22:26:40 --> Output Class Initialized
INFO - 2017-01-31 22:26:40 --> Security Class Initialized
DEBUG - 2017-01-31 22:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:26:40 --> Input Class Initialized
INFO - 2017-01-31 22:26:40 --> Language Class Initialized
INFO - 2017-01-31 22:26:40 --> Loader Class Initialized
INFO - 2017-01-31 22:26:40 --> Database Driver Class Initialized
INFO - 2017-01-31 22:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:26:40 --> Controller Class Initialized
INFO - 2017-01-31 22:26:40 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:26:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-31 22:26:40 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-31 22:26:40 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Janeth Piñon')
INFO - 2017-01-31 22:26:40 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-31 22:26:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-31 22:26:41 --> Config Class Initialized
INFO - 2017-01-31 22:26:41 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:26:41 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:26:41 --> Utf8 Class Initialized
INFO - 2017-01-31 22:26:41 --> URI Class Initialized
INFO - 2017-01-31 22:26:41 --> Router Class Initialized
INFO - 2017-01-31 22:26:41 --> Output Class Initialized
INFO - 2017-01-31 22:26:41 --> Security Class Initialized
DEBUG - 2017-01-31 22:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:26:41 --> Input Class Initialized
INFO - 2017-01-31 22:26:41 --> Language Class Initialized
INFO - 2017-01-31 22:26:41 --> Loader Class Initialized
INFO - 2017-01-31 22:26:41 --> Database Driver Class Initialized
INFO - 2017-01-31 22:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:26:41 --> Controller Class Initialized
INFO - 2017-01-31 22:26:41 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:26:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:26:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:26:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:26:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:26:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:26:41 --> Final output sent to browser
DEBUG - 2017-01-31 22:26:41 --> Total execution time: 0.0132
INFO - 2017-01-31 22:27:26 --> Config Class Initialized
INFO - 2017-01-31 22:27:26 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:27:26 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:27:26 --> Utf8 Class Initialized
INFO - 2017-01-31 22:27:26 --> URI Class Initialized
DEBUG - 2017-01-31 22:27:26 --> No URI present. Default controller set.
INFO - 2017-01-31 22:27:26 --> Router Class Initialized
INFO - 2017-01-31 22:27:26 --> Output Class Initialized
INFO - 2017-01-31 22:27:26 --> Security Class Initialized
DEBUG - 2017-01-31 22:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:27:26 --> Input Class Initialized
INFO - 2017-01-31 22:27:26 --> Language Class Initialized
INFO - 2017-01-31 22:27:26 --> Loader Class Initialized
INFO - 2017-01-31 22:27:26 --> Database Driver Class Initialized
INFO - 2017-01-31 22:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:27:26 --> Controller Class Initialized
INFO - 2017-01-31 22:27:26 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:27:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:27:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:27:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:27:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:27:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:27:26 --> Final output sent to browser
DEBUG - 2017-01-31 22:27:26 --> Total execution time: 0.0136
INFO - 2017-01-31 22:27:27 --> Config Class Initialized
INFO - 2017-01-31 22:27:27 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:27:27 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:27:27 --> Utf8 Class Initialized
INFO - 2017-01-31 22:27:27 --> URI Class Initialized
INFO - 2017-01-31 22:27:27 --> Router Class Initialized
INFO - 2017-01-31 22:27:27 --> Output Class Initialized
INFO - 2017-01-31 22:27:27 --> Security Class Initialized
DEBUG - 2017-01-31 22:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:27:27 --> Input Class Initialized
INFO - 2017-01-31 22:27:27 --> Language Class Initialized
INFO - 2017-01-31 22:27:27 --> Loader Class Initialized
INFO - 2017-01-31 22:27:27 --> Database Driver Class Initialized
INFO - 2017-01-31 22:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:27:27 --> Controller Class Initialized
INFO - 2017-01-31 22:27:27 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:27:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:27:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:27:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:27:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:27:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:27:27 --> Final output sent to browser
DEBUG - 2017-01-31 22:27:27 --> Total execution time: 0.0130
INFO - 2017-01-31 22:27:43 --> Config Class Initialized
INFO - 2017-01-31 22:27:43 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:27:43 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:27:43 --> Utf8 Class Initialized
INFO - 2017-01-31 22:27:43 --> URI Class Initialized
DEBUG - 2017-01-31 22:27:43 --> No URI present. Default controller set.
INFO - 2017-01-31 22:27:43 --> Router Class Initialized
INFO - 2017-01-31 22:27:43 --> Output Class Initialized
INFO - 2017-01-31 22:27:43 --> Security Class Initialized
DEBUG - 2017-01-31 22:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:27:43 --> Input Class Initialized
INFO - 2017-01-31 22:27:43 --> Language Class Initialized
INFO - 2017-01-31 22:27:43 --> Loader Class Initialized
INFO - 2017-01-31 22:27:43 --> Database Driver Class Initialized
INFO - 2017-01-31 22:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:27:43 --> Controller Class Initialized
INFO - 2017-01-31 22:27:43 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:27:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:27:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:27:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:27:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:27:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:27:43 --> Final output sent to browser
DEBUG - 2017-01-31 22:27:43 --> Total execution time: 0.0140
INFO - 2017-01-31 22:27:46 --> Config Class Initialized
INFO - 2017-01-31 22:27:46 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:27:46 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:27:46 --> Utf8 Class Initialized
INFO - 2017-01-31 22:27:46 --> URI Class Initialized
INFO - 2017-01-31 22:27:46 --> Router Class Initialized
INFO - 2017-01-31 22:27:46 --> Output Class Initialized
INFO - 2017-01-31 22:27:46 --> Security Class Initialized
DEBUG - 2017-01-31 22:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:27:46 --> Input Class Initialized
INFO - 2017-01-31 22:27:46 --> Language Class Initialized
INFO - 2017-01-31 22:27:46 --> Loader Class Initialized
INFO - 2017-01-31 22:27:46 --> Database Driver Class Initialized
INFO - 2017-01-31 22:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:27:46 --> Controller Class Initialized
INFO - 2017-01-31 22:27:46 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:27:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:27:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:27:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:27:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:27:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:27:46 --> Final output sent to browser
DEBUG - 2017-01-31 22:27:46 --> Total execution time: 0.0134
INFO - 2017-01-31 22:27:48 --> Config Class Initialized
INFO - 2017-01-31 22:27:48 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:27:48 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:27:48 --> Utf8 Class Initialized
INFO - 2017-01-31 22:27:48 --> URI Class Initialized
INFO - 2017-01-31 22:27:48 --> Router Class Initialized
INFO - 2017-01-31 22:27:48 --> Output Class Initialized
INFO - 2017-01-31 22:27:48 --> Security Class Initialized
DEBUG - 2017-01-31 22:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:27:48 --> Input Class Initialized
INFO - 2017-01-31 22:27:48 --> Language Class Initialized
INFO - 2017-01-31 22:27:48 --> Loader Class Initialized
INFO - 2017-01-31 22:27:48 --> Database Driver Class Initialized
INFO - 2017-01-31 22:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:27:48 --> Controller Class Initialized
INFO - 2017-01-31 22:27:48 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:27:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:27:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-31 22:27:48 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-31 22:27:48 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-31 22:27:48 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-31 22:27:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:27:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:27:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:27:48 --> Final output sent to browser
DEBUG - 2017-01-31 22:27:48 --> Total execution time: 0.0134
INFO - 2017-01-31 22:27:49 --> Config Class Initialized
INFO - 2017-01-31 22:27:49 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:27:49 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:27:49 --> Utf8 Class Initialized
INFO - 2017-01-31 22:27:49 --> URI Class Initialized
INFO - 2017-01-31 22:27:49 --> Router Class Initialized
INFO - 2017-01-31 22:27:49 --> Output Class Initialized
INFO - 2017-01-31 22:27:49 --> Security Class Initialized
DEBUG - 2017-01-31 22:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:27:49 --> Input Class Initialized
INFO - 2017-01-31 22:27:49 --> Language Class Initialized
INFO - 2017-01-31 22:27:49 --> Loader Class Initialized
INFO - 2017-01-31 22:27:49 --> Database Driver Class Initialized
INFO - 2017-01-31 22:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:27:49 --> Controller Class Initialized
INFO - 2017-01-31 22:27:49 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:27:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:27:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:27:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:27:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:27:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:27:49 --> Final output sent to browser
DEBUG - 2017-01-31 22:27:49 --> Total execution time: 0.0132
INFO - 2017-01-31 22:28:49 --> Config Class Initialized
INFO - 2017-01-31 22:28:49 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:28:49 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:28:49 --> Utf8 Class Initialized
INFO - 2017-01-31 22:28:49 --> URI Class Initialized
DEBUG - 2017-01-31 22:28:49 --> No URI present. Default controller set.
INFO - 2017-01-31 22:28:49 --> Router Class Initialized
INFO - 2017-01-31 22:28:49 --> Output Class Initialized
INFO - 2017-01-31 22:28:49 --> Security Class Initialized
DEBUG - 2017-01-31 22:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:28:49 --> Input Class Initialized
INFO - 2017-01-31 22:28:49 --> Language Class Initialized
INFO - 2017-01-31 22:28:49 --> Loader Class Initialized
INFO - 2017-01-31 22:28:49 --> Database Driver Class Initialized
INFO - 2017-01-31 22:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:28:49 --> Controller Class Initialized
INFO - 2017-01-31 22:28:49 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:28:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:28:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:28:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:28:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:28:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:28:49 --> Final output sent to browser
DEBUG - 2017-01-31 22:28:49 --> Total execution time: 0.0150
INFO - 2017-01-31 22:28:50 --> Config Class Initialized
INFO - 2017-01-31 22:28:50 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:28:50 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:28:50 --> Utf8 Class Initialized
INFO - 2017-01-31 22:28:50 --> URI Class Initialized
INFO - 2017-01-31 22:28:50 --> Router Class Initialized
INFO - 2017-01-31 22:28:50 --> Output Class Initialized
INFO - 2017-01-31 22:28:50 --> Security Class Initialized
DEBUG - 2017-01-31 22:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:28:50 --> Input Class Initialized
INFO - 2017-01-31 22:28:50 --> Language Class Initialized
INFO - 2017-01-31 22:28:50 --> Loader Class Initialized
INFO - 2017-01-31 22:28:50 --> Database Driver Class Initialized
INFO - 2017-01-31 22:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:28:50 --> Controller Class Initialized
INFO - 2017-01-31 22:28:50 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:28:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:28:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:28:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:28:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:28:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:28:50 --> Final output sent to browser
DEBUG - 2017-01-31 22:28:50 --> Total execution time: 0.0136
INFO - 2017-01-31 22:29:23 --> Config Class Initialized
INFO - 2017-01-31 22:29:23 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:29:23 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:29:23 --> Utf8 Class Initialized
INFO - 2017-01-31 22:29:23 --> URI Class Initialized
INFO - 2017-01-31 22:29:23 --> Router Class Initialized
INFO - 2017-01-31 22:29:23 --> Output Class Initialized
INFO - 2017-01-31 22:29:23 --> Security Class Initialized
DEBUG - 2017-01-31 22:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:29:23 --> Input Class Initialized
INFO - 2017-01-31 22:29:23 --> Language Class Initialized
INFO - 2017-01-31 22:29:23 --> Loader Class Initialized
INFO - 2017-01-31 22:29:23 --> Database Driver Class Initialized
INFO - 2017-01-31 22:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:29:23 --> Controller Class Initialized
INFO - 2017-01-31 22:29:23 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:29:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:29:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:29:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:29:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:29:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:29:23 --> Final output sent to browser
DEBUG - 2017-01-31 22:29:23 --> Total execution time: 0.0150
INFO - 2017-01-31 22:29:24 --> Config Class Initialized
INFO - 2017-01-31 22:29:24 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:29:24 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:29:24 --> Utf8 Class Initialized
INFO - 2017-01-31 22:29:24 --> URI Class Initialized
INFO - 2017-01-31 22:29:24 --> Router Class Initialized
INFO - 2017-01-31 22:29:24 --> Output Class Initialized
INFO - 2017-01-31 22:29:24 --> Security Class Initialized
DEBUG - 2017-01-31 22:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:29:24 --> Input Class Initialized
INFO - 2017-01-31 22:29:24 --> Language Class Initialized
INFO - 2017-01-31 22:29:24 --> Loader Class Initialized
INFO - 2017-01-31 22:29:24 --> Database Driver Class Initialized
INFO - 2017-01-31 22:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:29:24 --> Controller Class Initialized
INFO - 2017-01-31 22:29:24 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:29:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:29:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:29:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:29:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:29:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:29:24 --> Final output sent to browser
DEBUG - 2017-01-31 22:29:24 --> Total execution time: 0.0701
INFO - 2017-01-31 22:29:36 --> Config Class Initialized
INFO - 2017-01-31 22:29:36 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:29:36 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:29:36 --> Utf8 Class Initialized
INFO - 2017-01-31 22:29:36 --> URI Class Initialized
INFO - 2017-01-31 22:29:36 --> Router Class Initialized
INFO - 2017-01-31 22:29:36 --> Output Class Initialized
INFO - 2017-01-31 22:29:36 --> Security Class Initialized
DEBUG - 2017-01-31 22:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:29:36 --> Input Class Initialized
INFO - 2017-01-31 22:29:36 --> Language Class Initialized
INFO - 2017-01-31 22:29:36 --> Loader Class Initialized
INFO - 2017-01-31 22:29:36 --> Database Driver Class Initialized
INFO - 2017-01-31 22:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:29:36 --> Controller Class Initialized
INFO - 2017-01-31 22:29:36 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:29:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-31 22:29:36 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-31 22:29:36 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Janeth Piñon')
INFO - 2017-01-31 22:29:36 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-31 22:29:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-31 22:29:37 --> Config Class Initialized
INFO - 2017-01-31 22:29:37 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:29:37 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:29:37 --> Utf8 Class Initialized
INFO - 2017-01-31 22:29:37 --> URI Class Initialized
INFO - 2017-01-31 22:29:37 --> Router Class Initialized
INFO - 2017-01-31 22:29:37 --> Output Class Initialized
INFO - 2017-01-31 22:29:37 --> Security Class Initialized
DEBUG - 2017-01-31 22:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:29:37 --> Input Class Initialized
INFO - 2017-01-31 22:29:37 --> Language Class Initialized
INFO - 2017-01-31 22:29:37 --> Loader Class Initialized
INFO - 2017-01-31 22:29:37 --> Database Driver Class Initialized
INFO - 2017-01-31 22:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:29:37 --> Controller Class Initialized
INFO - 2017-01-31 22:29:37 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:29:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:29:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:29:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:29:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:29:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:29:37 --> Final output sent to browser
DEBUG - 2017-01-31 22:29:37 --> Total execution time: 0.0138
INFO - 2017-01-31 22:29:51 --> Config Class Initialized
INFO - 2017-01-31 22:29:51 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:29:51 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:29:51 --> Utf8 Class Initialized
INFO - 2017-01-31 22:29:51 --> URI Class Initialized
DEBUG - 2017-01-31 22:29:51 --> No URI present. Default controller set.
INFO - 2017-01-31 22:29:51 --> Router Class Initialized
INFO - 2017-01-31 22:29:51 --> Output Class Initialized
INFO - 2017-01-31 22:29:51 --> Security Class Initialized
DEBUG - 2017-01-31 22:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:29:51 --> Input Class Initialized
INFO - 2017-01-31 22:29:51 --> Language Class Initialized
INFO - 2017-01-31 22:29:51 --> Loader Class Initialized
INFO - 2017-01-31 22:29:51 --> Database Driver Class Initialized
INFO - 2017-01-31 22:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:29:51 --> Controller Class Initialized
INFO - 2017-01-31 22:29:51 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:29:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:29:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:29:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:29:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:29:51 --> Final output sent to browser
DEBUG - 2017-01-31 22:29:51 --> Total execution time: 0.0317
INFO - 2017-01-31 22:29:52 --> Config Class Initialized
INFO - 2017-01-31 22:29:52 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:29:52 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:29:52 --> Utf8 Class Initialized
INFO - 2017-01-31 22:29:52 --> URI Class Initialized
INFO - 2017-01-31 22:29:52 --> Router Class Initialized
INFO - 2017-01-31 22:29:52 --> Output Class Initialized
INFO - 2017-01-31 22:29:52 --> Security Class Initialized
DEBUG - 2017-01-31 22:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:29:52 --> Input Class Initialized
INFO - 2017-01-31 22:29:52 --> Language Class Initialized
INFO - 2017-01-31 22:29:52 --> Loader Class Initialized
INFO - 2017-01-31 22:29:52 --> Database Driver Class Initialized
INFO - 2017-01-31 22:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:29:52 --> Controller Class Initialized
INFO - 2017-01-31 22:29:52 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:29:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:29:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:29:52 --> Final output sent to browser
DEBUG - 2017-01-31 22:29:52 --> Total execution time: 0.0467
INFO - 2017-01-31 22:29:56 --> Config Class Initialized
INFO - 2017-01-31 22:29:56 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:29:56 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:29:56 --> Utf8 Class Initialized
INFO - 2017-01-31 22:29:56 --> URI Class Initialized
INFO - 2017-01-31 22:29:56 --> Router Class Initialized
INFO - 2017-01-31 22:29:56 --> Output Class Initialized
INFO - 2017-01-31 22:29:56 --> Security Class Initialized
DEBUG - 2017-01-31 22:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:29:56 --> Input Class Initialized
INFO - 2017-01-31 22:29:56 --> Language Class Initialized
INFO - 2017-01-31 22:29:56 --> Loader Class Initialized
INFO - 2017-01-31 22:29:56 --> Database Driver Class Initialized
INFO - 2017-01-31 22:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:29:56 --> Controller Class Initialized
INFO - 2017-01-31 22:29:56 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:29:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-31 22:29:57 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-31 22:29:57 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Janeth Piñon')
INFO - 2017-01-31 22:29:57 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-31 22:29:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-31 22:29:57 --> Config Class Initialized
INFO - 2017-01-31 22:29:57 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:29:57 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:29:57 --> Utf8 Class Initialized
INFO - 2017-01-31 22:29:57 --> URI Class Initialized
INFO - 2017-01-31 22:29:57 --> Router Class Initialized
INFO - 2017-01-31 22:29:57 --> Output Class Initialized
INFO - 2017-01-31 22:29:57 --> Security Class Initialized
DEBUG - 2017-01-31 22:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:29:57 --> Input Class Initialized
INFO - 2017-01-31 22:29:57 --> Language Class Initialized
INFO - 2017-01-31 22:29:57 --> Loader Class Initialized
INFO - 2017-01-31 22:29:57 --> Database Driver Class Initialized
INFO - 2017-01-31 22:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:29:57 --> Controller Class Initialized
INFO - 2017-01-31 22:29:57 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:29:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:29:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:29:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:29:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:29:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:29:57 --> Final output sent to browser
DEBUG - 2017-01-31 22:29:57 --> Total execution time: 0.0141
INFO - 2017-01-31 22:31:46 --> Config Class Initialized
INFO - 2017-01-31 22:31:46 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:31:46 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:31:46 --> Utf8 Class Initialized
INFO - 2017-01-31 22:31:46 --> URI Class Initialized
INFO - 2017-01-31 22:31:46 --> Router Class Initialized
INFO - 2017-01-31 22:31:46 --> Output Class Initialized
INFO - 2017-01-31 22:31:46 --> Security Class Initialized
DEBUG - 2017-01-31 22:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:31:46 --> Input Class Initialized
INFO - 2017-01-31 22:31:46 --> Language Class Initialized
INFO - 2017-01-31 22:31:46 --> Loader Class Initialized
INFO - 2017-01-31 22:31:46 --> Database Driver Class Initialized
INFO - 2017-01-31 22:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:31:46 --> Controller Class Initialized
INFO - 2017-01-31 22:31:46 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:31:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:31:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:31:46 --> Final output sent to browser
DEBUG - 2017-01-31 22:31:46 --> Total execution time: 0.0192
INFO - 2017-01-31 22:31:47 --> Config Class Initialized
INFO - 2017-01-31 22:31:47 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:31:47 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:31:47 --> Utf8 Class Initialized
INFO - 2017-01-31 22:31:47 --> URI Class Initialized
INFO - 2017-01-31 22:31:47 --> Router Class Initialized
INFO - 2017-01-31 22:31:47 --> Output Class Initialized
INFO - 2017-01-31 22:31:47 --> Security Class Initialized
DEBUG - 2017-01-31 22:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:31:47 --> Input Class Initialized
INFO - 2017-01-31 22:31:47 --> Language Class Initialized
INFO - 2017-01-31 22:31:47 --> Loader Class Initialized
INFO - 2017-01-31 22:31:47 --> Database Driver Class Initialized
INFO - 2017-01-31 22:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:31:47 --> Controller Class Initialized
INFO - 2017-01-31 22:31:47 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:31:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:31:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:31:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:31:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:31:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:31:47 --> Final output sent to browser
DEBUG - 2017-01-31 22:31:47 --> Total execution time: 0.0396
INFO - 2017-01-31 22:32:06 --> Config Class Initialized
INFO - 2017-01-31 22:32:06 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:32:06 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:32:06 --> Utf8 Class Initialized
INFO - 2017-01-31 22:32:06 --> URI Class Initialized
INFO - 2017-01-31 22:32:06 --> Router Class Initialized
INFO - 2017-01-31 22:32:06 --> Output Class Initialized
INFO - 2017-01-31 22:32:06 --> Security Class Initialized
DEBUG - 2017-01-31 22:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:32:06 --> Input Class Initialized
INFO - 2017-01-31 22:32:06 --> Language Class Initialized
INFO - 2017-01-31 22:32:06 --> Loader Class Initialized
INFO - 2017-01-31 22:32:06 --> Database Driver Class Initialized
INFO - 2017-01-31 22:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:32:06 --> Controller Class Initialized
INFO - 2017-01-31 22:32:06 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:32:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:32:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:32:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:32:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:32:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:32:06 --> Final output sent to browser
DEBUG - 2017-01-31 22:32:06 --> Total execution time: 0.0154
INFO - 2017-01-31 22:32:06 --> Config Class Initialized
INFO - 2017-01-31 22:32:06 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:32:06 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:32:06 --> Utf8 Class Initialized
INFO - 2017-01-31 22:32:06 --> URI Class Initialized
INFO - 2017-01-31 22:32:06 --> Router Class Initialized
INFO - 2017-01-31 22:32:06 --> Output Class Initialized
INFO - 2017-01-31 22:32:06 --> Security Class Initialized
DEBUG - 2017-01-31 22:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:32:06 --> Input Class Initialized
INFO - 2017-01-31 22:32:06 --> Language Class Initialized
INFO - 2017-01-31 22:32:06 --> Loader Class Initialized
INFO - 2017-01-31 22:32:06 --> Database Driver Class Initialized
INFO - 2017-01-31 22:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:32:06 --> Controller Class Initialized
INFO - 2017-01-31 22:32:06 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:32:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:32:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:32:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:32:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:32:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:32:06 --> Final output sent to browser
DEBUG - 2017-01-31 22:32:06 --> Total execution time: 0.0141
INFO - 2017-01-31 22:32:25 --> Config Class Initialized
INFO - 2017-01-31 22:32:25 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:32:25 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:32:25 --> Utf8 Class Initialized
INFO - 2017-01-31 22:32:25 --> URI Class Initialized
INFO - 2017-01-31 22:32:25 --> Router Class Initialized
INFO - 2017-01-31 22:32:25 --> Output Class Initialized
INFO - 2017-01-31 22:32:25 --> Security Class Initialized
DEBUG - 2017-01-31 22:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:32:25 --> Input Class Initialized
INFO - 2017-01-31 22:32:25 --> Language Class Initialized
INFO - 2017-01-31 22:32:25 --> Loader Class Initialized
INFO - 2017-01-31 22:32:25 --> Database Driver Class Initialized
INFO - 2017-01-31 22:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:32:25 --> Controller Class Initialized
INFO - 2017-01-31 22:32:25 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:32:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:32:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:32:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:32:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:32:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:32:25 --> Final output sent to browser
DEBUG - 2017-01-31 22:32:25 --> Total execution time: 0.0143
INFO - 2017-01-31 22:32:25 --> Config Class Initialized
INFO - 2017-01-31 22:32:25 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:32:25 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:32:25 --> Utf8 Class Initialized
INFO - 2017-01-31 22:32:25 --> URI Class Initialized
INFO - 2017-01-31 22:32:25 --> Router Class Initialized
INFO - 2017-01-31 22:32:25 --> Output Class Initialized
INFO - 2017-01-31 22:32:25 --> Security Class Initialized
DEBUG - 2017-01-31 22:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:32:25 --> Input Class Initialized
INFO - 2017-01-31 22:32:25 --> Language Class Initialized
INFO - 2017-01-31 22:32:25 --> Loader Class Initialized
INFO - 2017-01-31 22:32:25 --> Database Driver Class Initialized
INFO - 2017-01-31 22:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:32:25 --> Controller Class Initialized
INFO - 2017-01-31 22:32:25 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:32:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:32:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:32:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:32:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:32:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:32:25 --> Final output sent to browser
DEBUG - 2017-01-31 22:32:25 --> Total execution time: 0.0145
INFO - 2017-01-31 22:32:33 --> Config Class Initialized
INFO - 2017-01-31 22:32:33 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:32:33 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:32:33 --> Utf8 Class Initialized
INFO - 2017-01-31 22:32:33 --> URI Class Initialized
INFO - 2017-01-31 22:32:33 --> Router Class Initialized
INFO - 2017-01-31 22:32:33 --> Output Class Initialized
INFO - 2017-01-31 22:32:33 --> Security Class Initialized
DEBUG - 2017-01-31 22:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:32:33 --> Input Class Initialized
INFO - 2017-01-31 22:32:33 --> Language Class Initialized
INFO - 2017-01-31 22:32:33 --> Loader Class Initialized
INFO - 2017-01-31 22:32:33 --> Database Driver Class Initialized
INFO - 2017-01-31 22:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:32:33 --> Controller Class Initialized
INFO - 2017-01-31 22:32:33 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:32:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:32:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:32:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:32:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:32:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:32:33 --> Final output sent to browser
DEBUG - 2017-01-31 22:32:33 --> Total execution time: 0.0142
INFO - 2017-01-31 22:32:34 --> Config Class Initialized
INFO - 2017-01-31 22:32:34 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:32:34 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:32:34 --> Utf8 Class Initialized
INFO - 2017-01-31 22:32:34 --> URI Class Initialized
INFO - 2017-01-31 22:32:34 --> Router Class Initialized
INFO - 2017-01-31 22:32:34 --> Output Class Initialized
INFO - 2017-01-31 22:32:34 --> Security Class Initialized
DEBUG - 2017-01-31 22:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:32:34 --> Input Class Initialized
INFO - 2017-01-31 22:32:34 --> Language Class Initialized
INFO - 2017-01-31 22:32:34 --> Loader Class Initialized
INFO - 2017-01-31 22:32:34 --> Database Driver Class Initialized
INFO - 2017-01-31 22:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:32:34 --> Controller Class Initialized
INFO - 2017-01-31 22:32:34 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:32:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:32:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:32:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:32:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:32:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:32:34 --> Final output sent to browser
DEBUG - 2017-01-31 22:32:34 --> Total execution time: 0.0494
INFO - 2017-01-31 22:33:10 --> Config Class Initialized
INFO - 2017-01-31 22:33:10 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:33:10 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:33:10 --> Utf8 Class Initialized
INFO - 2017-01-31 22:33:10 --> URI Class Initialized
INFO - 2017-01-31 22:33:10 --> Router Class Initialized
INFO - 2017-01-31 22:33:10 --> Output Class Initialized
INFO - 2017-01-31 22:33:10 --> Security Class Initialized
DEBUG - 2017-01-31 22:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:33:10 --> Input Class Initialized
INFO - 2017-01-31 22:33:10 --> Language Class Initialized
INFO - 2017-01-31 22:33:10 --> Loader Class Initialized
INFO - 2017-01-31 22:33:10 --> Database Driver Class Initialized
INFO - 2017-01-31 22:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:33:10 --> Controller Class Initialized
INFO - 2017-01-31 22:33:10 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:33:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:33:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:33:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:33:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:33:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:33:10 --> Final output sent to browser
DEBUG - 2017-01-31 22:33:10 --> Total execution time: 0.0144
INFO - 2017-01-31 22:33:10 --> Config Class Initialized
INFO - 2017-01-31 22:33:10 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:33:10 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:33:10 --> Utf8 Class Initialized
INFO - 2017-01-31 22:33:10 --> URI Class Initialized
INFO - 2017-01-31 22:33:10 --> Router Class Initialized
INFO - 2017-01-31 22:33:10 --> Output Class Initialized
INFO - 2017-01-31 22:33:10 --> Security Class Initialized
DEBUG - 2017-01-31 22:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:33:10 --> Input Class Initialized
INFO - 2017-01-31 22:33:10 --> Language Class Initialized
INFO - 2017-01-31 22:33:10 --> Loader Class Initialized
INFO - 2017-01-31 22:33:10 --> Database Driver Class Initialized
INFO - 2017-01-31 22:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:33:10 --> Controller Class Initialized
INFO - 2017-01-31 22:33:10 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:33:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:33:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:33:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:33:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:33:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:33:10 --> Final output sent to browser
DEBUG - 2017-01-31 22:33:10 --> Total execution time: 0.0575
INFO - 2017-01-31 22:33:17 --> Config Class Initialized
INFO - 2017-01-31 22:33:17 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:33:17 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:33:17 --> Utf8 Class Initialized
INFO - 2017-01-31 22:33:17 --> URI Class Initialized
INFO - 2017-01-31 22:33:17 --> Router Class Initialized
INFO - 2017-01-31 22:33:17 --> Output Class Initialized
INFO - 2017-01-31 22:33:17 --> Security Class Initialized
DEBUG - 2017-01-31 22:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:33:17 --> Input Class Initialized
INFO - 2017-01-31 22:33:17 --> Language Class Initialized
INFO - 2017-01-31 22:33:17 --> Loader Class Initialized
INFO - 2017-01-31 22:33:17 --> Database Driver Class Initialized
INFO - 2017-01-31 22:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:33:17 --> Controller Class Initialized
INFO - 2017-01-31 22:33:18 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:33:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:33:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:33:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:33:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:33:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:33:18 --> Final output sent to browser
DEBUG - 2017-01-31 22:33:18 --> Total execution time: 0.0146
INFO - 2017-01-31 22:33:18 --> Config Class Initialized
INFO - 2017-01-31 22:33:18 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:33:18 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:33:18 --> Utf8 Class Initialized
INFO - 2017-01-31 22:33:18 --> URI Class Initialized
INFO - 2017-01-31 22:33:18 --> Router Class Initialized
INFO - 2017-01-31 22:33:18 --> Output Class Initialized
INFO - 2017-01-31 22:33:18 --> Security Class Initialized
DEBUG - 2017-01-31 22:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:33:18 --> Input Class Initialized
INFO - 2017-01-31 22:33:18 --> Language Class Initialized
INFO - 2017-01-31 22:33:18 --> Loader Class Initialized
INFO - 2017-01-31 22:33:18 --> Database Driver Class Initialized
INFO - 2017-01-31 22:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:33:18 --> Controller Class Initialized
INFO - 2017-01-31 22:33:18 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:33:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:33:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:33:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:33:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:33:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:33:18 --> Final output sent to browser
DEBUG - 2017-01-31 22:33:18 --> Total execution time: 0.0199
INFO - 2017-01-31 22:35:28 --> Config Class Initialized
INFO - 2017-01-31 22:35:28 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:35:28 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:35:28 --> Utf8 Class Initialized
INFO - 2017-01-31 22:35:28 --> URI Class Initialized
DEBUG - 2017-01-31 22:35:28 --> No URI present. Default controller set.
INFO - 2017-01-31 22:35:28 --> Router Class Initialized
INFO - 2017-01-31 22:35:28 --> Output Class Initialized
INFO - 2017-01-31 22:35:28 --> Security Class Initialized
DEBUG - 2017-01-31 22:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:35:28 --> Input Class Initialized
INFO - 2017-01-31 22:35:28 --> Language Class Initialized
INFO - 2017-01-31 22:35:28 --> Loader Class Initialized
INFO - 2017-01-31 22:35:28 --> Database Driver Class Initialized
INFO - 2017-01-31 22:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:35:28 --> Controller Class Initialized
INFO - 2017-01-31 22:35:28 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:35:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:35:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:35:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:35:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:35:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:35:28 --> Final output sent to browser
DEBUG - 2017-01-31 22:35:28 --> Total execution time: 0.0129
INFO - 2017-01-31 22:35:32 --> Config Class Initialized
INFO - 2017-01-31 22:35:32 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:35:32 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:35:32 --> Utf8 Class Initialized
INFO - 2017-01-31 22:35:32 --> URI Class Initialized
INFO - 2017-01-31 22:35:32 --> Router Class Initialized
INFO - 2017-01-31 22:35:32 --> Output Class Initialized
INFO - 2017-01-31 22:35:32 --> Security Class Initialized
DEBUG - 2017-01-31 22:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:35:32 --> Input Class Initialized
INFO - 2017-01-31 22:35:32 --> Language Class Initialized
INFO - 2017-01-31 22:35:32 --> Loader Class Initialized
INFO - 2017-01-31 22:35:32 --> Database Driver Class Initialized
INFO - 2017-01-31 22:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:35:32 --> Controller Class Initialized
INFO - 2017-01-31 22:35:32 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:35:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:35:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:35:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:35:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:35:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:35:32 --> Final output sent to browser
DEBUG - 2017-01-31 22:35:32 --> Total execution time: 0.0136
INFO - 2017-01-31 22:36:01 --> Config Class Initialized
INFO - 2017-01-31 22:36:01 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:36:01 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:36:01 --> Utf8 Class Initialized
INFO - 2017-01-31 22:36:01 --> URI Class Initialized
DEBUG - 2017-01-31 22:36:01 --> No URI present. Default controller set.
INFO - 2017-01-31 22:36:01 --> Router Class Initialized
INFO - 2017-01-31 22:36:01 --> Output Class Initialized
INFO - 2017-01-31 22:36:01 --> Security Class Initialized
DEBUG - 2017-01-31 22:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:36:01 --> Input Class Initialized
INFO - 2017-01-31 22:36:01 --> Language Class Initialized
INFO - 2017-01-31 22:36:01 --> Loader Class Initialized
INFO - 2017-01-31 22:36:01 --> Database Driver Class Initialized
INFO - 2017-01-31 22:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:36:01 --> Controller Class Initialized
INFO - 2017-01-31 22:36:01 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:36:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:36:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:36:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:36:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:36:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:36:01 --> Final output sent to browser
DEBUG - 2017-01-31 22:36:01 --> Total execution time: 0.0130
INFO - 2017-01-31 22:36:03 --> Config Class Initialized
INFO - 2017-01-31 22:36:03 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:36:03 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:36:03 --> Utf8 Class Initialized
INFO - 2017-01-31 22:36:03 --> URI Class Initialized
INFO - 2017-01-31 22:36:03 --> Router Class Initialized
INFO - 2017-01-31 22:36:03 --> Output Class Initialized
INFO - 2017-01-31 22:36:03 --> Security Class Initialized
DEBUG - 2017-01-31 22:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:36:03 --> Input Class Initialized
INFO - 2017-01-31 22:36:03 --> Language Class Initialized
INFO - 2017-01-31 22:36:03 --> Loader Class Initialized
INFO - 2017-01-31 22:36:03 --> Database Driver Class Initialized
INFO - 2017-01-31 22:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:36:03 --> Controller Class Initialized
INFO - 2017-01-31 22:36:03 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:36:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:36:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:36:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:36:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:36:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:36:03 --> Final output sent to browser
DEBUG - 2017-01-31 22:36:03 --> Total execution time: 0.0143
INFO - 2017-01-31 22:36:20 --> Config Class Initialized
INFO - 2017-01-31 22:36:20 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:36:20 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:36:20 --> Utf8 Class Initialized
INFO - 2017-01-31 22:36:20 --> URI Class Initialized
INFO - 2017-01-31 22:36:20 --> Router Class Initialized
INFO - 2017-01-31 22:36:20 --> Output Class Initialized
INFO - 2017-01-31 22:36:20 --> Security Class Initialized
DEBUG - 2017-01-31 22:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:36:20 --> Input Class Initialized
INFO - 2017-01-31 22:36:20 --> Language Class Initialized
INFO - 2017-01-31 22:36:20 --> Loader Class Initialized
INFO - 2017-01-31 22:36:20 --> Database Driver Class Initialized
INFO - 2017-01-31 22:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:36:20 --> Controller Class Initialized
INFO - 2017-01-31 22:36:20 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:36:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:36:21 --> Config Class Initialized
INFO - 2017-01-31 22:36:21 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:36:21 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:36:21 --> Utf8 Class Initialized
INFO - 2017-01-31 22:36:21 --> URI Class Initialized
INFO - 2017-01-31 22:36:21 --> Router Class Initialized
INFO - 2017-01-31 22:36:21 --> Output Class Initialized
INFO - 2017-01-31 22:36:21 --> Security Class Initialized
DEBUG - 2017-01-31 22:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:36:21 --> Input Class Initialized
INFO - 2017-01-31 22:36:21 --> Language Class Initialized
INFO - 2017-01-31 22:36:21 --> Loader Class Initialized
INFO - 2017-01-31 22:36:21 --> Database Driver Class Initialized
INFO - 2017-01-31 22:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:36:21 --> Controller Class Initialized
INFO - 2017-01-31 22:36:21 --> Helper loaded: date_helper
DEBUG - 2017-01-31 22:36:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:36:21 --> Helper loaded: url_helper
INFO - 2017-01-31 22:36:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:36:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 22:36:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 22:36:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 22:36:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:36:21 --> Final output sent to browser
DEBUG - 2017-01-31 22:36:21 --> Total execution time: 0.0914
INFO - 2017-01-31 22:36:22 --> Config Class Initialized
INFO - 2017-01-31 22:36:22 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:36:22 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:36:22 --> Utf8 Class Initialized
INFO - 2017-01-31 22:36:22 --> URI Class Initialized
INFO - 2017-01-31 22:36:22 --> Router Class Initialized
INFO - 2017-01-31 22:36:22 --> Output Class Initialized
INFO - 2017-01-31 22:36:22 --> Security Class Initialized
DEBUG - 2017-01-31 22:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:36:22 --> Input Class Initialized
INFO - 2017-01-31 22:36:22 --> Language Class Initialized
INFO - 2017-01-31 22:36:22 --> Loader Class Initialized
INFO - 2017-01-31 22:36:22 --> Database Driver Class Initialized
INFO - 2017-01-31 22:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:36:22 --> Controller Class Initialized
INFO - 2017-01-31 22:36:22 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:36:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:36:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:36:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:36:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:36:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:36:22 --> Final output sent to browser
DEBUG - 2017-01-31 22:36:22 --> Total execution time: 0.0139
INFO - 2017-01-31 22:36:29 --> Config Class Initialized
INFO - 2017-01-31 22:36:29 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:36:29 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:36:29 --> Utf8 Class Initialized
INFO - 2017-01-31 22:36:29 --> URI Class Initialized
INFO - 2017-01-31 22:36:29 --> Router Class Initialized
INFO - 2017-01-31 22:36:29 --> Output Class Initialized
INFO - 2017-01-31 22:36:29 --> Security Class Initialized
DEBUG - 2017-01-31 22:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:36:29 --> Input Class Initialized
INFO - 2017-01-31 22:36:29 --> Language Class Initialized
INFO - 2017-01-31 22:36:29 --> Loader Class Initialized
INFO - 2017-01-31 22:36:29 --> Database Driver Class Initialized
INFO - 2017-01-31 22:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:36:29 --> Controller Class Initialized
INFO - 2017-01-31 22:36:29 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:36:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:36:30 --> Config Class Initialized
INFO - 2017-01-31 22:36:30 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:36:30 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:36:30 --> Utf8 Class Initialized
INFO - 2017-01-31 22:36:30 --> URI Class Initialized
INFO - 2017-01-31 22:36:30 --> Router Class Initialized
INFO - 2017-01-31 22:36:30 --> Output Class Initialized
INFO - 2017-01-31 22:36:30 --> Security Class Initialized
DEBUG - 2017-01-31 22:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:36:30 --> Input Class Initialized
INFO - 2017-01-31 22:36:30 --> Language Class Initialized
INFO - 2017-01-31 22:36:30 --> Loader Class Initialized
INFO - 2017-01-31 22:36:30 --> Database Driver Class Initialized
INFO - 2017-01-31 22:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:36:30 --> Controller Class Initialized
INFO - 2017-01-31 22:36:30 --> Helper loaded: date_helper
DEBUG - 2017-01-31 22:36:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:36:30 --> Helper loaded: url_helper
INFO - 2017-01-31 22:36:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:36:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 22:36:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 22:36:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 22:36:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:36:30 --> Final output sent to browser
DEBUG - 2017-01-31 22:36:30 --> Total execution time: 0.0134
INFO - 2017-01-31 22:36:31 --> Config Class Initialized
INFO - 2017-01-31 22:36:31 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:36:31 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:36:31 --> Utf8 Class Initialized
INFO - 2017-01-31 22:36:31 --> URI Class Initialized
DEBUG - 2017-01-31 22:36:31 --> No URI present. Default controller set.
INFO - 2017-01-31 22:36:31 --> Router Class Initialized
INFO - 2017-01-31 22:36:31 --> Output Class Initialized
INFO - 2017-01-31 22:36:31 --> Security Class Initialized
DEBUG - 2017-01-31 22:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:36:31 --> Input Class Initialized
INFO - 2017-01-31 22:36:31 --> Language Class Initialized
INFO - 2017-01-31 22:36:31 --> Loader Class Initialized
INFO - 2017-01-31 22:36:31 --> Database Driver Class Initialized
INFO - 2017-01-31 22:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:36:31 --> Controller Class Initialized
INFO - 2017-01-31 22:36:31 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:36:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:36:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:36:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:36:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:36:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:36:31 --> Final output sent to browser
DEBUG - 2017-01-31 22:36:31 --> Total execution time: 0.0142
INFO - 2017-01-31 22:36:32 --> Config Class Initialized
INFO - 2017-01-31 22:36:32 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:36:32 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:36:32 --> Utf8 Class Initialized
INFO - 2017-01-31 22:36:32 --> URI Class Initialized
INFO - 2017-01-31 22:36:32 --> Router Class Initialized
INFO - 2017-01-31 22:36:32 --> Output Class Initialized
INFO - 2017-01-31 22:36:32 --> Security Class Initialized
DEBUG - 2017-01-31 22:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:36:32 --> Input Class Initialized
INFO - 2017-01-31 22:36:32 --> Language Class Initialized
INFO - 2017-01-31 22:36:32 --> Loader Class Initialized
INFO - 2017-01-31 22:36:32 --> Database Driver Class Initialized
INFO - 2017-01-31 22:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:36:32 --> Controller Class Initialized
INFO - 2017-01-31 22:36:32 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:36:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:36:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:36:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:36:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:36:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:36:32 --> Final output sent to browser
DEBUG - 2017-01-31 22:36:32 --> Total execution time: 0.0134
INFO - 2017-01-31 22:37:52 --> Config Class Initialized
INFO - 2017-01-31 22:37:52 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:37:52 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:37:52 --> Utf8 Class Initialized
INFO - 2017-01-31 22:37:52 --> URI Class Initialized
DEBUG - 2017-01-31 22:37:52 --> No URI present. Default controller set.
INFO - 2017-01-31 22:37:52 --> Router Class Initialized
INFO - 2017-01-31 22:37:52 --> Output Class Initialized
INFO - 2017-01-31 22:37:52 --> Security Class Initialized
DEBUG - 2017-01-31 22:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:37:52 --> Input Class Initialized
INFO - 2017-01-31 22:37:52 --> Language Class Initialized
INFO - 2017-01-31 22:37:52 --> Loader Class Initialized
INFO - 2017-01-31 22:37:52 --> Database Driver Class Initialized
INFO - 2017-01-31 22:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:37:52 --> Controller Class Initialized
INFO - 2017-01-31 22:37:52 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:37:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:37:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:37:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:37:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:37:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:37:52 --> Final output sent to browser
DEBUG - 2017-01-31 22:37:52 --> Total execution time: 0.0148
INFO - 2017-01-31 22:38:01 --> Config Class Initialized
INFO - 2017-01-31 22:38:01 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:38:01 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:38:01 --> Utf8 Class Initialized
INFO - 2017-01-31 22:38:01 --> URI Class Initialized
INFO - 2017-01-31 22:38:01 --> Router Class Initialized
INFO - 2017-01-31 22:38:01 --> Output Class Initialized
INFO - 2017-01-31 22:38:01 --> Security Class Initialized
DEBUG - 2017-01-31 22:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:38:01 --> Input Class Initialized
INFO - 2017-01-31 22:38:01 --> Language Class Initialized
INFO - 2017-01-31 22:38:01 --> Loader Class Initialized
INFO - 2017-01-31 22:38:01 --> Database Driver Class Initialized
INFO - 2017-01-31 22:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:38:01 --> Controller Class Initialized
INFO - 2017-01-31 22:38:01 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:38:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:38:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:38:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:38:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:38:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:38:01 --> Final output sent to browser
DEBUG - 2017-01-31 22:38:01 --> Total execution time: 0.0136
INFO - 2017-01-31 22:38:02 --> Config Class Initialized
INFO - 2017-01-31 22:38:02 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:38:02 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:38:02 --> Utf8 Class Initialized
INFO - 2017-01-31 22:38:02 --> URI Class Initialized
INFO - 2017-01-31 22:38:02 --> Router Class Initialized
INFO - 2017-01-31 22:38:02 --> Output Class Initialized
INFO - 2017-01-31 22:38:02 --> Security Class Initialized
DEBUG - 2017-01-31 22:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:38:02 --> Input Class Initialized
INFO - 2017-01-31 22:38:02 --> Language Class Initialized
INFO - 2017-01-31 22:38:02 --> Loader Class Initialized
INFO - 2017-01-31 22:38:02 --> Database Driver Class Initialized
INFO - 2017-01-31 22:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:38:02 --> Controller Class Initialized
INFO - 2017-01-31 22:38:02 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:38:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-31 22:38:02 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-31 22:38:02 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-31 22:38:02 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-31 22:38:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:38:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:38:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:38:02 --> Final output sent to browser
DEBUG - 2017-01-31 22:38:02 --> Total execution time: 0.0142
INFO - 2017-01-31 22:38:06 --> Config Class Initialized
INFO - 2017-01-31 22:38:06 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:38:06 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:38:06 --> Utf8 Class Initialized
INFO - 2017-01-31 22:38:06 --> URI Class Initialized
INFO - 2017-01-31 22:38:06 --> Router Class Initialized
INFO - 2017-01-31 22:38:06 --> Output Class Initialized
INFO - 2017-01-31 22:38:06 --> Security Class Initialized
DEBUG - 2017-01-31 22:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:38:06 --> Input Class Initialized
INFO - 2017-01-31 22:38:06 --> Language Class Initialized
INFO - 2017-01-31 22:38:06 --> Loader Class Initialized
INFO - 2017-01-31 22:38:06 --> Database Driver Class Initialized
INFO - 2017-01-31 22:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:38:06 --> Controller Class Initialized
INFO - 2017-01-31 22:38:06 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:38:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:38:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:38:06 --> Final output sent to browser
DEBUG - 2017-01-31 22:38:06 --> Total execution time: 0.0138
INFO - 2017-01-31 22:38:27 --> Config Class Initialized
INFO - 2017-01-31 22:38:27 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:38:27 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:38:27 --> Utf8 Class Initialized
INFO - 2017-01-31 22:38:27 --> URI Class Initialized
INFO - 2017-01-31 22:38:27 --> Router Class Initialized
INFO - 2017-01-31 22:38:27 --> Output Class Initialized
INFO - 2017-01-31 22:38:27 --> Security Class Initialized
DEBUG - 2017-01-31 22:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:38:27 --> Input Class Initialized
INFO - 2017-01-31 22:38:27 --> Language Class Initialized
INFO - 2017-01-31 22:38:27 --> Loader Class Initialized
INFO - 2017-01-31 22:38:27 --> Database Driver Class Initialized
INFO - 2017-01-31 22:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:38:27 --> Controller Class Initialized
INFO - 2017-01-31 22:38:27 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:38:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:38:28 --> Config Class Initialized
INFO - 2017-01-31 22:38:28 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:38:28 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:38:28 --> Utf8 Class Initialized
INFO - 2017-01-31 22:38:28 --> URI Class Initialized
INFO - 2017-01-31 22:38:28 --> Router Class Initialized
INFO - 2017-01-31 22:38:28 --> Output Class Initialized
INFO - 2017-01-31 22:38:28 --> Security Class Initialized
DEBUG - 2017-01-31 22:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:38:28 --> Input Class Initialized
INFO - 2017-01-31 22:38:28 --> Language Class Initialized
INFO - 2017-01-31 22:38:28 --> Loader Class Initialized
INFO - 2017-01-31 22:38:28 --> Database Driver Class Initialized
INFO - 2017-01-31 22:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:38:28 --> Controller Class Initialized
INFO - 2017-01-31 22:38:28 --> Helper loaded: date_helper
DEBUG - 2017-01-31 22:38:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:38:28 --> Helper loaded: url_helper
INFO - 2017-01-31 22:38:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:38:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-31 22:38:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-31 22:38:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 22:38:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:38:28 --> Final output sent to browser
DEBUG - 2017-01-31 22:38:28 --> Total execution time: 0.0526
INFO - 2017-01-31 22:38:31 --> Config Class Initialized
INFO - 2017-01-31 22:38:31 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:38:31 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:38:31 --> Utf8 Class Initialized
INFO - 2017-01-31 22:38:31 --> URI Class Initialized
INFO - 2017-01-31 22:38:31 --> Router Class Initialized
INFO - 2017-01-31 22:38:31 --> Output Class Initialized
INFO - 2017-01-31 22:38:31 --> Security Class Initialized
DEBUG - 2017-01-31 22:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:38:31 --> Input Class Initialized
INFO - 2017-01-31 22:38:31 --> Language Class Initialized
INFO - 2017-01-31 22:38:31 --> Loader Class Initialized
INFO - 2017-01-31 22:38:31 --> Database Driver Class Initialized
INFO - 2017-01-31 22:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:38:31 --> Controller Class Initialized
INFO - 2017-01-31 22:38:31 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:38:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:38:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:38:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:38:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:38:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:38:31 --> Final output sent to browser
DEBUG - 2017-01-31 22:38:31 --> Total execution time: 0.0136
INFO - 2017-01-31 22:38:39 --> Config Class Initialized
INFO - 2017-01-31 22:38:39 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:38:39 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:38:39 --> Utf8 Class Initialized
INFO - 2017-01-31 22:38:39 --> URI Class Initialized
INFO - 2017-01-31 22:38:39 --> Router Class Initialized
INFO - 2017-01-31 22:38:39 --> Output Class Initialized
INFO - 2017-01-31 22:38:39 --> Security Class Initialized
DEBUG - 2017-01-31 22:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:38:39 --> Input Class Initialized
INFO - 2017-01-31 22:38:39 --> Language Class Initialized
INFO - 2017-01-31 22:38:39 --> Loader Class Initialized
INFO - 2017-01-31 22:38:39 --> Database Driver Class Initialized
INFO - 2017-01-31 22:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:38:39 --> Controller Class Initialized
INFO - 2017-01-31 22:38:39 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:38:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:38:40 --> Config Class Initialized
INFO - 2017-01-31 22:38:40 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:38:40 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:38:40 --> Utf8 Class Initialized
INFO - 2017-01-31 22:38:40 --> URI Class Initialized
INFO - 2017-01-31 22:38:40 --> Router Class Initialized
INFO - 2017-01-31 22:38:40 --> Output Class Initialized
INFO - 2017-01-31 22:38:40 --> Security Class Initialized
DEBUG - 2017-01-31 22:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:38:40 --> Input Class Initialized
INFO - 2017-01-31 22:38:40 --> Language Class Initialized
INFO - 2017-01-31 22:38:40 --> Loader Class Initialized
INFO - 2017-01-31 22:38:40 --> Database Driver Class Initialized
INFO - 2017-01-31 22:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:38:40 --> Controller Class Initialized
INFO - 2017-01-31 22:38:40 --> Helper loaded: date_helper
DEBUG - 2017-01-31 22:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:38:40 --> Helper loaded: url_helper
INFO - 2017-01-31 22:38:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:38:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 22:38:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 22:38:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 22:38:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:38:40 --> Final output sent to browser
DEBUG - 2017-01-31 22:38:40 --> Total execution time: 0.0172
INFO - 2017-01-31 22:38:41 --> Config Class Initialized
INFO - 2017-01-31 22:38:41 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:38:41 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:38:41 --> Utf8 Class Initialized
INFO - 2017-01-31 22:38:41 --> URI Class Initialized
INFO - 2017-01-31 22:38:41 --> Router Class Initialized
INFO - 2017-01-31 22:38:41 --> Output Class Initialized
INFO - 2017-01-31 22:38:41 --> Security Class Initialized
DEBUG - 2017-01-31 22:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:38:41 --> Input Class Initialized
INFO - 2017-01-31 22:38:41 --> Language Class Initialized
INFO - 2017-01-31 22:38:41 --> Loader Class Initialized
INFO - 2017-01-31 22:38:41 --> Database Driver Class Initialized
INFO - 2017-01-31 22:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:38:41 --> Controller Class Initialized
INFO - 2017-01-31 22:38:41 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:38:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:38:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:38:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:38:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:38:41 --> Final output sent to browser
DEBUG - 2017-01-31 22:38:41 --> Total execution time: 0.0486
INFO - 2017-01-31 22:38:48 --> Config Class Initialized
INFO - 2017-01-31 22:38:48 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:38:48 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:38:48 --> Utf8 Class Initialized
INFO - 2017-01-31 22:38:48 --> URI Class Initialized
INFO - 2017-01-31 22:38:48 --> Router Class Initialized
INFO - 2017-01-31 22:38:48 --> Output Class Initialized
INFO - 2017-01-31 22:38:48 --> Security Class Initialized
DEBUG - 2017-01-31 22:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:38:48 --> Input Class Initialized
INFO - 2017-01-31 22:38:48 --> Language Class Initialized
INFO - 2017-01-31 22:38:48 --> Loader Class Initialized
INFO - 2017-01-31 22:38:48 --> Database Driver Class Initialized
INFO - 2017-01-31 22:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:38:48 --> Controller Class Initialized
INFO - 2017-01-31 22:38:48 --> Helper loaded: date_helper
DEBUG - 2017-01-31 22:38:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:38:48 --> Helper loaded: url_helper
INFO - 2017-01-31 22:38:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:38:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 22:38:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 22:38:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 22:38:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:38:48 --> Final output sent to browser
DEBUG - 2017-01-31 22:38:48 --> Total execution time: 0.0297
INFO - 2017-01-31 22:38:49 --> Config Class Initialized
INFO - 2017-01-31 22:38:49 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:38:49 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:38:49 --> Utf8 Class Initialized
INFO - 2017-01-31 22:38:49 --> URI Class Initialized
INFO - 2017-01-31 22:38:49 --> Router Class Initialized
INFO - 2017-01-31 22:38:49 --> Output Class Initialized
INFO - 2017-01-31 22:38:49 --> Security Class Initialized
DEBUG - 2017-01-31 22:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:38:49 --> Input Class Initialized
INFO - 2017-01-31 22:38:49 --> Language Class Initialized
INFO - 2017-01-31 22:38:49 --> Loader Class Initialized
INFO - 2017-01-31 22:38:49 --> Database Driver Class Initialized
INFO - 2017-01-31 22:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:38:49 --> Controller Class Initialized
INFO - 2017-01-31 22:38:49 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:38:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:38:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:38:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:38:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:38:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:38:49 --> Final output sent to browser
DEBUG - 2017-01-31 22:38:49 --> Total execution time: 0.0132
INFO - 2017-01-31 22:39:53 --> Config Class Initialized
INFO - 2017-01-31 22:39:53 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:39:53 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:39:53 --> Utf8 Class Initialized
INFO - 2017-01-31 22:39:53 --> URI Class Initialized
DEBUG - 2017-01-31 22:39:53 --> No URI present. Default controller set.
INFO - 2017-01-31 22:39:53 --> Router Class Initialized
INFO - 2017-01-31 22:39:53 --> Output Class Initialized
INFO - 2017-01-31 22:39:53 --> Security Class Initialized
DEBUG - 2017-01-31 22:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:39:53 --> Input Class Initialized
INFO - 2017-01-31 22:39:53 --> Language Class Initialized
INFO - 2017-01-31 22:39:53 --> Loader Class Initialized
INFO - 2017-01-31 22:39:53 --> Database Driver Class Initialized
INFO - 2017-01-31 22:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:39:53 --> Controller Class Initialized
INFO - 2017-01-31 22:39:53 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:39:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:39:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:39:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:39:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:39:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:39:53 --> Final output sent to browser
DEBUG - 2017-01-31 22:39:53 --> Total execution time: 0.0138
INFO - 2017-01-31 22:39:58 --> Config Class Initialized
INFO - 2017-01-31 22:39:58 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:39:58 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:39:58 --> Utf8 Class Initialized
INFO - 2017-01-31 22:39:58 --> URI Class Initialized
INFO - 2017-01-31 22:39:58 --> Router Class Initialized
INFO - 2017-01-31 22:39:58 --> Output Class Initialized
INFO - 2017-01-31 22:39:58 --> Security Class Initialized
DEBUG - 2017-01-31 22:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:39:58 --> Input Class Initialized
INFO - 2017-01-31 22:39:58 --> Language Class Initialized
INFO - 2017-01-31 22:39:58 --> Loader Class Initialized
INFO - 2017-01-31 22:39:58 --> Database Driver Class Initialized
INFO - 2017-01-31 22:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:39:58 --> Controller Class Initialized
INFO - 2017-01-31 22:39:58 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:39:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:39:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:39:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:39:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:39:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:39:58 --> Final output sent to browser
DEBUG - 2017-01-31 22:39:58 --> Total execution time: 0.0132
INFO - 2017-01-31 22:40:22 --> Config Class Initialized
INFO - 2017-01-31 22:40:22 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:40:22 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:40:22 --> Utf8 Class Initialized
INFO - 2017-01-31 22:40:22 --> URI Class Initialized
INFO - 2017-01-31 22:40:22 --> Router Class Initialized
INFO - 2017-01-31 22:40:22 --> Output Class Initialized
INFO - 2017-01-31 22:40:22 --> Security Class Initialized
DEBUG - 2017-01-31 22:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:40:22 --> Input Class Initialized
INFO - 2017-01-31 22:40:22 --> Language Class Initialized
INFO - 2017-01-31 22:40:22 --> Loader Class Initialized
INFO - 2017-01-31 22:40:22 --> Database Driver Class Initialized
INFO - 2017-01-31 22:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:40:22 --> Controller Class Initialized
INFO - 2017-01-31 22:40:22 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:40:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:40:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:40:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:40:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:40:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:40:22 --> Final output sent to browser
DEBUG - 2017-01-31 22:40:22 --> Total execution time: 0.0151
INFO - 2017-01-31 22:40:24 --> Config Class Initialized
INFO - 2017-01-31 22:40:24 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:40:24 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:40:24 --> Utf8 Class Initialized
INFO - 2017-01-31 22:40:24 --> URI Class Initialized
INFO - 2017-01-31 22:40:24 --> Router Class Initialized
INFO - 2017-01-31 22:40:24 --> Output Class Initialized
INFO - 2017-01-31 22:40:24 --> Security Class Initialized
DEBUG - 2017-01-31 22:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:40:24 --> Input Class Initialized
INFO - 2017-01-31 22:40:24 --> Language Class Initialized
INFO - 2017-01-31 22:40:24 --> Loader Class Initialized
INFO - 2017-01-31 22:40:24 --> Database Driver Class Initialized
INFO - 2017-01-31 22:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:40:24 --> Controller Class Initialized
INFO - 2017-01-31 22:40:24 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:40:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:40:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:40:24 --> Final output sent to browser
DEBUG - 2017-01-31 22:40:24 --> Total execution time: 0.0143
INFO - 2017-01-31 22:40:54 --> Config Class Initialized
INFO - 2017-01-31 22:40:54 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:40:54 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:40:54 --> Utf8 Class Initialized
INFO - 2017-01-31 22:40:54 --> URI Class Initialized
INFO - 2017-01-31 22:40:54 --> Router Class Initialized
INFO - 2017-01-31 22:40:54 --> Output Class Initialized
INFO - 2017-01-31 22:40:54 --> Security Class Initialized
DEBUG - 2017-01-31 22:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:40:54 --> Input Class Initialized
INFO - 2017-01-31 22:40:54 --> Language Class Initialized
INFO - 2017-01-31 22:40:54 --> Loader Class Initialized
INFO - 2017-01-31 22:40:54 --> Database Driver Class Initialized
INFO - 2017-01-31 22:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:40:54 --> Controller Class Initialized
INFO - 2017-01-31 22:40:54 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:40:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:40:54 --> Config Class Initialized
INFO - 2017-01-31 22:40:54 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:40:54 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:40:54 --> Utf8 Class Initialized
INFO - 2017-01-31 22:40:54 --> URI Class Initialized
INFO - 2017-01-31 22:40:54 --> Router Class Initialized
INFO - 2017-01-31 22:40:54 --> Output Class Initialized
INFO - 2017-01-31 22:40:54 --> Security Class Initialized
DEBUG - 2017-01-31 22:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:40:54 --> Input Class Initialized
INFO - 2017-01-31 22:40:54 --> Language Class Initialized
INFO - 2017-01-31 22:40:54 --> Loader Class Initialized
INFO - 2017-01-31 22:40:54 --> Database Driver Class Initialized
INFO - 2017-01-31 22:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:40:54 --> Controller Class Initialized
INFO - 2017-01-31 22:40:54 --> Helper loaded: date_helper
DEBUG - 2017-01-31 22:40:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:40:54 --> Helper loaded: url_helper
INFO - 2017-01-31 22:40:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:40:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 22:40:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 22:40:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 22:40:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:40:54 --> Final output sent to browser
DEBUG - 2017-01-31 22:40:54 --> Total execution time: 0.0137
INFO - 2017-01-31 22:40:54 --> Config Class Initialized
INFO - 2017-01-31 22:40:54 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:40:54 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:40:54 --> Utf8 Class Initialized
INFO - 2017-01-31 22:40:54 --> URI Class Initialized
INFO - 2017-01-31 22:40:54 --> Router Class Initialized
INFO - 2017-01-31 22:40:54 --> Output Class Initialized
INFO - 2017-01-31 22:40:54 --> Security Class Initialized
DEBUG - 2017-01-31 22:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:40:54 --> Input Class Initialized
INFO - 2017-01-31 22:40:54 --> Language Class Initialized
INFO - 2017-01-31 22:40:54 --> Loader Class Initialized
INFO - 2017-01-31 22:40:54 --> Database Driver Class Initialized
INFO - 2017-01-31 22:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:40:54 --> Controller Class Initialized
INFO - 2017-01-31 22:40:54 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:40:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:40:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:40:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:40:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:40:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:40:54 --> Final output sent to browser
DEBUG - 2017-01-31 22:40:54 --> Total execution time: 0.0129
INFO - 2017-01-31 22:41:00 --> Config Class Initialized
INFO - 2017-01-31 22:41:00 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:41:00 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:41:00 --> Utf8 Class Initialized
INFO - 2017-01-31 22:41:00 --> URI Class Initialized
DEBUG - 2017-01-31 22:41:00 --> No URI present. Default controller set.
INFO - 2017-01-31 22:41:00 --> Router Class Initialized
INFO - 2017-01-31 22:41:00 --> Output Class Initialized
INFO - 2017-01-31 22:41:00 --> Security Class Initialized
DEBUG - 2017-01-31 22:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:41:00 --> Input Class Initialized
INFO - 2017-01-31 22:41:00 --> Language Class Initialized
INFO - 2017-01-31 22:41:00 --> Loader Class Initialized
INFO - 2017-01-31 22:41:00 --> Database Driver Class Initialized
INFO - 2017-01-31 22:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:41:00 --> Controller Class Initialized
INFO - 2017-01-31 22:41:00 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:41:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:41:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:41:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:41:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:41:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:41:00 --> Final output sent to browser
DEBUG - 2017-01-31 22:41:00 --> Total execution time: 0.0172
INFO - 2017-01-31 22:41:01 --> Config Class Initialized
INFO - 2017-01-31 22:41:01 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:41:01 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:41:01 --> Utf8 Class Initialized
INFO - 2017-01-31 22:41:01 --> URI Class Initialized
INFO - 2017-01-31 22:41:01 --> Router Class Initialized
INFO - 2017-01-31 22:41:01 --> Output Class Initialized
INFO - 2017-01-31 22:41:01 --> Security Class Initialized
DEBUG - 2017-01-31 22:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:41:01 --> Input Class Initialized
INFO - 2017-01-31 22:41:01 --> Language Class Initialized
INFO - 2017-01-31 22:41:01 --> Loader Class Initialized
INFO - 2017-01-31 22:41:01 --> Database Driver Class Initialized
INFO - 2017-01-31 22:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:41:01 --> Controller Class Initialized
INFO - 2017-01-31 22:41:01 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:41:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:41:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:41:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:41:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:41:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:41:01 --> Final output sent to browser
DEBUG - 2017-01-31 22:41:01 --> Total execution time: 0.0718
INFO - 2017-01-31 22:41:14 --> Config Class Initialized
INFO - 2017-01-31 22:41:14 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:41:14 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:41:14 --> Utf8 Class Initialized
INFO - 2017-01-31 22:41:14 --> URI Class Initialized
INFO - 2017-01-31 22:41:14 --> Router Class Initialized
INFO - 2017-01-31 22:41:14 --> Output Class Initialized
INFO - 2017-01-31 22:41:14 --> Security Class Initialized
DEBUG - 2017-01-31 22:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:41:14 --> Input Class Initialized
INFO - 2017-01-31 22:41:14 --> Language Class Initialized
INFO - 2017-01-31 22:41:14 --> Loader Class Initialized
INFO - 2017-01-31 22:41:14 --> Database Driver Class Initialized
INFO - 2017-01-31 22:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:41:14 --> Controller Class Initialized
INFO - 2017-01-31 22:41:14 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:41:15 --> Config Class Initialized
INFO - 2017-01-31 22:41:15 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:41:15 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:41:15 --> Utf8 Class Initialized
INFO - 2017-01-31 22:41:15 --> URI Class Initialized
INFO - 2017-01-31 22:41:15 --> Router Class Initialized
INFO - 2017-01-31 22:41:15 --> Output Class Initialized
INFO - 2017-01-31 22:41:15 --> Security Class Initialized
DEBUG - 2017-01-31 22:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:41:15 --> Input Class Initialized
INFO - 2017-01-31 22:41:15 --> Language Class Initialized
INFO - 2017-01-31 22:41:15 --> Loader Class Initialized
INFO - 2017-01-31 22:41:15 --> Database Driver Class Initialized
INFO - 2017-01-31 22:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:41:15 --> Controller Class Initialized
INFO - 2017-01-31 22:41:15 --> Helper loaded: date_helper
DEBUG - 2017-01-31 22:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:41:15 --> Helper loaded: url_helper
INFO - 2017-01-31 22:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 22:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 22:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 22:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:41:15 --> Final output sent to browser
DEBUG - 2017-01-31 22:41:15 --> Total execution time: 0.0144
INFO - 2017-01-31 22:41:15 --> Config Class Initialized
INFO - 2017-01-31 22:41:15 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:41:15 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:41:15 --> Utf8 Class Initialized
INFO - 2017-01-31 22:41:15 --> URI Class Initialized
INFO - 2017-01-31 22:41:15 --> Router Class Initialized
INFO - 2017-01-31 22:41:15 --> Output Class Initialized
INFO - 2017-01-31 22:41:15 --> Security Class Initialized
DEBUG - 2017-01-31 22:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:41:15 --> Input Class Initialized
INFO - 2017-01-31 22:41:15 --> Language Class Initialized
INFO - 2017-01-31 22:41:15 --> Loader Class Initialized
INFO - 2017-01-31 22:41:15 --> Database Driver Class Initialized
INFO - 2017-01-31 22:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:41:15 --> Controller Class Initialized
INFO - 2017-01-31 22:41:15 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:41:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:41:15 --> Final output sent to browser
DEBUG - 2017-01-31 22:41:15 --> Total execution time: 0.0195
INFO - 2017-01-31 22:41:45 --> Config Class Initialized
INFO - 2017-01-31 22:41:45 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:41:45 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:41:45 --> Utf8 Class Initialized
INFO - 2017-01-31 22:41:45 --> URI Class Initialized
DEBUG - 2017-01-31 22:41:45 --> No URI present. Default controller set.
INFO - 2017-01-31 22:41:45 --> Router Class Initialized
INFO - 2017-01-31 22:41:45 --> Output Class Initialized
INFO - 2017-01-31 22:41:45 --> Security Class Initialized
DEBUG - 2017-01-31 22:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:41:45 --> Input Class Initialized
INFO - 2017-01-31 22:41:45 --> Language Class Initialized
INFO - 2017-01-31 22:41:45 --> Loader Class Initialized
INFO - 2017-01-31 22:41:45 --> Database Driver Class Initialized
INFO - 2017-01-31 22:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:41:45 --> Controller Class Initialized
INFO - 2017-01-31 22:41:45 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:41:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:41:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:41:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:41:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:41:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:41:45 --> Final output sent to browser
DEBUG - 2017-01-31 22:41:45 --> Total execution time: 0.0135
INFO - 2017-01-31 22:41:46 --> Config Class Initialized
INFO - 2017-01-31 22:41:46 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:41:46 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:41:46 --> Utf8 Class Initialized
INFO - 2017-01-31 22:41:46 --> URI Class Initialized
INFO - 2017-01-31 22:41:46 --> Router Class Initialized
INFO - 2017-01-31 22:41:46 --> Output Class Initialized
INFO - 2017-01-31 22:41:46 --> Security Class Initialized
DEBUG - 2017-01-31 22:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:41:46 --> Input Class Initialized
INFO - 2017-01-31 22:41:46 --> Language Class Initialized
INFO - 2017-01-31 22:41:46 --> Loader Class Initialized
INFO - 2017-01-31 22:41:46 --> Database Driver Class Initialized
INFO - 2017-01-31 22:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:41:46 --> Controller Class Initialized
INFO - 2017-01-31 22:41:46 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:41:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:41:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:41:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:41:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:41:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:41:46 --> Final output sent to browser
DEBUG - 2017-01-31 22:41:46 --> Total execution time: 0.0130
INFO - 2017-01-31 22:41:59 --> Config Class Initialized
INFO - 2017-01-31 22:41:59 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:41:59 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:41:59 --> Utf8 Class Initialized
INFO - 2017-01-31 22:41:59 --> URI Class Initialized
INFO - 2017-01-31 22:41:59 --> Router Class Initialized
INFO - 2017-01-31 22:41:59 --> Output Class Initialized
INFO - 2017-01-31 22:41:59 --> Security Class Initialized
DEBUG - 2017-01-31 22:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:41:59 --> Input Class Initialized
INFO - 2017-01-31 22:41:59 --> Language Class Initialized
INFO - 2017-01-31 22:41:59 --> Loader Class Initialized
INFO - 2017-01-31 22:41:59 --> Database Driver Class Initialized
INFO - 2017-01-31 22:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:41:59 --> Controller Class Initialized
INFO - 2017-01-31 22:41:59 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:41:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:42:01 --> Config Class Initialized
INFO - 2017-01-31 22:42:01 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:42:01 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:42:01 --> Utf8 Class Initialized
INFO - 2017-01-31 22:42:01 --> URI Class Initialized
INFO - 2017-01-31 22:42:01 --> Router Class Initialized
INFO - 2017-01-31 22:42:01 --> Output Class Initialized
INFO - 2017-01-31 22:42:01 --> Security Class Initialized
DEBUG - 2017-01-31 22:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:42:01 --> Input Class Initialized
INFO - 2017-01-31 22:42:01 --> Language Class Initialized
INFO - 2017-01-31 22:42:01 --> Loader Class Initialized
INFO - 2017-01-31 22:42:01 --> Database Driver Class Initialized
INFO - 2017-01-31 22:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:42:01 --> Controller Class Initialized
INFO - 2017-01-31 22:42:01 --> Helper loaded: date_helper
DEBUG - 2017-01-31 22:42:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:42:01 --> Helper loaded: url_helper
INFO - 2017-01-31 22:42:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:42:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 22:42:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 22:42:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 22:42:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:42:01 --> Final output sent to browser
DEBUG - 2017-01-31 22:42:01 --> Total execution time: 0.0137
INFO - 2017-01-31 22:42:01 --> Config Class Initialized
INFO - 2017-01-31 22:42:01 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:42:01 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:42:01 --> Utf8 Class Initialized
INFO - 2017-01-31 22:42:01 --> URI Class Initialized
INFO - 2017-01-31 22:42:01 --> Router Class Initialized
INFO - 2017-01-31 22:42:01 --> Output Class Initialized
INFO - 2017-01-31 22:42:01 --> Security Class Initialized
DEBUG - 2017-01-31 22:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:42:01 --> Input Class Initialized
INFO - 2017-01-31 22:42:01 --> Language Class Initialized
INFO - 2017-01-31 22:42:01 --> Loader Class Initialized
INFO - 2017-01-31 22:42:01 --> Database Driver Class Initialized
INFO - 2017-01-31 22:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:42:01 --> Controller Class Initialized
INFO - 2017-01-31 22:42:01 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:42:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:42:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:42:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:42:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:42:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:42:01 --> Final output sent to browser
DEBUG - 2017-01-31 22:42:01 --> Total execution time: 0.0310
INFO - 2017-01-31 22:43:41 --> Config Class Initialized
INFO - 2017-01-31 22:43:41 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:43:41 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:43:41 --> Utf8 Class Initialized
INFO - 2017-01-31 22:43:41 --> URI Class Initialized
INFO - 2017-01-31 22:43:41 --> Router Class Initialized
INFO - 2017-01-31 22:43:41 --> Output Class Initialized
INFO - 2017-01-31 22:43:41 --> Security Class Initialized
DEBUG - 2017-01-31 22:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:43:41 --> Input Class Initialized
INFO - 2017-01-31 22:43:41 --> Language Class Initialized
INFO - 2017-01-31 22:43:41 --> Loader Class Initialized
INFO - 2017-01-31 22:43:41 --> Database Driver Class Initialized
INFO - 2017-01-31 22:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:43:41 --> Controller Class Initialized
INFO - 2017-01-31 22:43:41 --> Helper loaded: date_helper
DEBUG - 2017-01-31 22:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:43:41 --> Helper loaded: url_helper
INFO - 2017-01-31 22:43:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:43:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-31 22:43:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-31 22:43:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 22:43:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:43:41 --> Final output sent to browser
DEBUG - 2017-01-31 22:43:41 --> Total execution time: 0.0156
INFO - 2017-01-31 22:43:45 --> Config Class Initialized
INFO - 2017-01-31 22:43:45 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:43:45 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:43:45 --> Utf8 Class Initialized
INFO - 2017-01-31 22:43:45 --> URI Class Initialized
INFO - 2017-01-31 22:43:45 --> Router Class Initialized
INFO - 2017-01-31 22:43:45 --> Output Class Initialized
INFO - 2017-01-31 22:43:45 --> Security Class Initialized
DEBUG - 2017-01-31 22:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:43:45 --> Input Class Initialized
INFO - 2017-01-31 22:43:45 --> Language Class Initialized
INFO - 2017-01-31 22:43:45 --> Loader Class Initialized
INFO - 2017-01-31 22:43:45 --> Database Driver Class Initialized
INFO - 2017-01-31 22:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:43:45 --> Controller Class Initialized
INFO - 2017-01-31 22:43:45 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:43:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:43:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:43:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:43:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:43:45 --> Final output sent to browser
DEBUG - 2017-01-31 22:43:45 --> Total execution time: 0.0145
INFO - 2017-01-31 22:45:44 --> Config Class Initialized
INFO - 2017-01-31 22:45:44 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:45:44 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:45:44 --> Utf8 Class Initialized
INFO - 2017-01-31 22:45:44 --> URI Class Initialized
DEBUG - 2017-01-31 22:45:44 --> No URI present. Default controller set.
INFO - 2017-01-31 22:45:44 --> Router Class Initialized
INFO - 2017-01-31 22:45:44 --> Output Class Initialized
INFO - 2017-01-31 22:45:44 --> Security Class Initialized
DEBUG - 2017-01-31 22:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:45:44 --> Input Class Initialized
INFO - 2017-01-31 22:45:44 --> Language Class Initialized
INFO - 2017-01-31 22:45:44 --> Loader Class Initialized
INFO - 2017-01-31 22:45:44 --> Database Driver Class Initialized
INFO - 2017-01-31 22:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:45:44 --> Controller Class Initialized
INFO - 2017-01-31 22:45:44 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:45:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:45:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:45:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:45:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:45:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:45:44 --> Final output sent to browser
DEBUG - 2017-01-31 22:45:44 --> Total execution time: 0.0134
INFO - 2017-01-31 22:46:15 --> Config Class Initialized
INFO - 2017-01-31 22:46:15 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:46:15 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:46:15 --> Utf8 Class Initialized
INFO - 2017-01-31 22:46:15 --> URI Class Initialized
INFO - 2017-01-31 22:46:15 --> Router Class Initialized
INFO - 2017-01-31 22:46:15 --> Output Class Initialized
INFO - 2017-01-31 22:46:15 --> Security Class Initialized
DEBUG - 2017-01-31 22:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:46:15 --> Input Class Initialized
INFO - 2017-01-31 22:46:15 --> Language Class Initialized
INFO - 2017-01-31 22:46:15 --> Loader Class Initialized
INFO - 2017-01-31 22:46:15 --> Database Driver Class Initialized
INFO - 2017-01-31 22:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:46:15 --> Controller Class Initialized
INFO - 2017-01-31 22:46:15 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:46:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:46:16 --> Config Class Initialized
INFO - 2017-01-31 22:46:16 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:46:16 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:46:16 --> Utf8 Class Initialized
INFO - 2017-01-31 22:46:16 --> URI Class Initialized
INFO - 2017-01-31 22:46:16 --> Router Class Initialized
INFO - 2017-01-31 22:46:16 --> Output Class Initialized
INFO - 2017-01-31 22:46:16 --> Security Class Initialized
DEBUG - 2017-01-31 22:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:46:16 --> Input Class Initialized
INFO - 2017-01-31 22:46:16 --> Language Class Initialized
INFO - 2017-01-31 22:46:16 --> Loader Class Initialized
INFO - 2017-01-31 22:46:16 --> Database Driver Class Initialized
INFO - 2017-01-31 22:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:46:16 --> Controller Class Initialized
INFO - 2017-01-31 22:46:16 --> Helper loaded: date_helper
DEBUG - 2017-01-31 22:46:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:46:16 --> Helper loaded: url_helper
INFO - 2017-01-31 22:46:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:46:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 22:46:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 22:46:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 22:46:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:46:16 --> Final output sent to browser
DEBUG - 2017-01-31 22:46:16 --> Total execution time: 0.0196
INFO - 2017-01-31 22:47:49 --> Config Class Initialized
INFO - 2017-01-31 22:47:49 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:47:49 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:47:49 --> Utf8 Class Initialized
INFO - 2017-01-31 22:47:49 --> URI Class Initialized
INFO - 2017-01-31 22:47:49 --> Router Class Initialized
INFO - 2017-01-31 22:47:49 --> Output Class Initialized
INFO - 2017-01-31 22:47:49 --> Security Class Initialized
DEBUG - 2017-01-31 22:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:47:49 --> Input Class Initialized
INFO - 2017-01-31 22:47:49 --> Language Class Initialized
INFO - 2017-01-31 22:47:49 --> Loader Class Initialized
INFO - 2017-01-31 22:47:49 --> Database Driver Class Initialized
INFO - 2017-01-31 22:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:47:49 --> Controller Class Initialized
INFO - 2017-01-31 22:47:49 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:47:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:47:50 --> Config Class Initialized
INFO - 2017-01-31 22:47:50 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:47:50 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:47:50 --> Utf8 Class Initialized
INFO - 2017-01-31 22:47:50 --> URI Class Initialized
INFO - 2017-01-31 22:47:50 --> Router Class Initialized
INFO - 2017-01-31 22:47:50 --> Output Class Initialized
INFO - 2017-01-31 22:47:50 --> Security Class Initialized
DEBUG - 2017-01-31 22:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:47:50 --> Input Class Initialized
INFO - 2017-01-31 22:47:50 --> Language Class Initialized
INFO - 2017-01-31 22:47:50 --> Loader Class Initialized
INFO - 2017-01-31 22:47:50 --> Database Driver Class Initialized
INFO - 2017-01-31 22:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:47:50 --> Controller Class Initialized
INFO - 2017-01-31 22:47:50 --> Helper loaded: date_helper
DEBUG - 2017-01-31 22:47:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:47:50 --> Helper loaded: url_helper
INFO - 2017-01-31 22:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 22:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 22:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 22:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:47:50 --> Final output sent to browser
DEBUG - 2017-01-31 22:47:50 --> Total execution time: 0.0130
INFO - 2017-01-31 22:47:50 --> Config Class Initialized
INFO - 2017-01-31 22:47:50 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:47:50 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:47:50 --> Utf8 Class Initialized
INFO - 2017-01-31 22:47:50 --> URI Class Initialized
INFO - 2017-01-31 22:47:50 --> Router Class Initialized
INFO - 2017-01-31 22:47:50 --> Output Class Initialized
INFO - 2017-01-31 22:47:50 --> Security Class Initialized
DEBUG - 2017-01-31 22:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:47:50 --> Input Class Initialized
INFO - 2017-01-31 22:47:50 --> Language Class Initialized
INFO - 2017-01-31 22:47:50 --> Loader Class Initialized
INFO - 2017-01-31 22:47:50 --> Database Driver Class Initialized
INFO - 2017-01-31 22:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:47:50 --> Controller Class Initialized
INFO - 2017-01-31 22:47:50 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:47:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:47:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:47:50 --> Final output sent to browser
DEBUG - 2017-01-31 22:47:50 --> Total execution time: 0.0136
INFO - 2017-01-31 22:48:42 --> Config Class Initialized
INFO - 2017-01-31 22:48:42 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:48:42 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:48:42 --> Utf8 Class Initialized
INFO - 2017-01-31 22:48:42 --> URI Class Initialized
DEBUG - 2017-01-31 22:48:42 --> No URI present. Default controller set.
INFO - 2017-01-31 22:48:42 --> Router Class Initialized
INFO - 2017-01-31 22:48:42 --> Output Class Initialized
INFO - 2017-01-31 22:48:42 --> Security Class Initialized
DEBUG - 2017-01-31 22:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:48:42 --> Input Class Initialized
INFO - 2017-01-31 22:48:42 --> Language Class Initialized
INFO - 2017-01-31 22:48:42 --> Loader Class Initialized
INFO - 2017-01-31 22:48:42 --> Database Driver Class Initialized
INFO - 2017-01-31 22:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:48:42 --> Controller Class Initialized
INFO - 2017-01-31 22:48:42 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:48:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:48:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:48:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:48:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:48:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:48:42 --> Final output sent to browser
DEBUG - 2017-01-31 22:48:42 --> Total execution time: 0.0160
INFO - 2017-01-31 22:48:43 --> Config Class Initialized
INFO - 2017-01-31 22:48:43 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:48:43 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:48:43 --> Utf8 Class Initialized
INFO - 2017-01-31 22:48:43 --> URI Class Initialized
INFO - 2017-01-31 22:48:43 --> Router Class Initialized
INFO - 2017-01-31 22:48:43 --> Output Class Initialized
INFO - 2017-01-31 22:48:43 --> Security Class Initialized
DEBUG - 2017-01-31 22:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:48:43 --> Input Class Initialized
INFO - 2017-01-31 22:48:43 --> Language Class Initialized
INFO - 2017-01-31 22:48:43 --> Loader Class Initialized
INFO - 2017-01-31 22:48:43 --> Database Driver Class Initialized
INFO - 2017-01-31 22:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:48:43 --> Controller Class Initialized
INFO - 2017-01-31 22:48:43 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:48:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:48:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:48:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:48:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:48:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:48:43 --> Final output sent to browser
DEBUG - 2017-01-31 22:48:43 --> Total execution time: 0.0144
INFO - 2017-01-31 22:49:29 --> Config Class Initialized
INFO - 2017-01-31 22:49:29 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:49:29 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:49:29 --> Utf8 Class Initialized
INFO - 2017-01-31 22:49:29 --> URI Class Initialized
INFO - 2017-01-31 22:49:29 --> Router Class Initialized
INFO - 2017-01-31 22:49:29 --> Output Class Initialized
INFO - 2017-01-31 22:49:29 --> Security Class Initialized
DEBUG - 2017-01-31 22:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:49:29 --> Input Class Initialized
INFO - 2017-01-31 22:49:29 --> Language Class Initialized
INFO - 2017-01-31 22:49:29 --> Loader Class Initialized
INFO - 2017-01-31 22:49:29 --> Database Driver Class Initialized
INFO - 2017-01-31 22:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:49:29 --> Controller Class Initialized
INFO - 2017-01-31 22:49:29 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:49:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:49:29 --> Config Class Initialized
INFO - 2017-01-31 22:49:29 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:49:29 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:49:29 --> Utf8 Class Initialized
INFO - 2017-01-31 22:49:29 --> URI Class Initialized
INFO - 2017-01-31 22:49:29 --> Router Class Initialized
INFO - 2017-01-31 22:49:29 --> Output Class Initialized
INFO - 2017-01-31 22:49:29 --> Security Class Initialized
DEBUG - 2017-01-31 22:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:49:29 --> Input Class Initialized
INFO - 2017-01-31 22:49:29 --> Language Class Initialized
INFO - 2017-01-31 22:49:29 --> Loader Class Initialized
INFO - 2017-01-31 22:49:29 --> Database Driver Class Initialized
INFO - 2017-01-31 22:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:49:29 --> Controller Class Initialized
INFO - 2017-01-31 22:49:29 --> Helper loaded: date_helper
DEBUG - 2017-01-31 22:49:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:49:29 --> Helper loaded: url_helper
INFO - 2017-01-31 22:49:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:49:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-31 22:49:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-01-31 22:49:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 22:49:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:49:29 --> Final output sent to browser
DEBUG - 2017-01-31 22:49:29 --> Total execution time: 0.0147
INFO - 2017-01-31 22:49:30 --> Config Class Initialized
INFO - 2017-01-31 22:49:30 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:49:30 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:49:30 --> Utf8 Class Initialized
INFO - 2017-01-31 22:49:30 --> URI Class Initialized
INFO - 2017-01-31 22:49:30 --> Router Class Initialized
INFO - 2017-01-31 22:49:30 --> Output Class Initialized
INFO - 2017-01-31 22:49:30 --> Security Class Initialized
DEBUG - 2017-01-31 22:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:49:30 --> Input Class Initialized
INFO - 2017-01-31 22:49:30 --> Language Class Initialized
INFO - 2017-01-31 22:49:30 --> Loader Class Initialized
INFO - 2017-01-31 22:49:30 --> Database Driver Class Initialized
INFO - 2017-01-31 22:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:49:30 --> Controller Class Initialized
INFO - 2017-01-31 22:49:30 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:49:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:49:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:49:30 --> Final output sent to browser
DEBUG - 2017-01-31 22:49:30 --> Total execution time: 0.0135
INFO - 2017-01-31 22:49:33 --> Config Class Initialized
INFO - 2017-01-31 22:49:33 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:49:33 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:49:33 --> Utf8 Class Initialized
INFO - 2017-01-31 22:49:33 --> URI Class Initialized
INFO - 2017-01-31 22:49:33 --> Router Class Initialized
INFO - 2017-01-31 22:49:33 --> Output Class Initialized
INFO - 2017-01-31 22:49:33 --> Security Class Initialized
DEBUG - 2017-01-31 22:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:49:33 --> Input Class Initialized
INFO - 2017-01-31 22:49:33 --> Language Class Initialized
INFO - 2017-01-31 22:49:33 --> Loader Class Initialized
INFO - 2017-01-31 22:49:33 --> Database Driver Class Initialized
INFO - 2017-01-31 22:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:49:33 --> Controller Class Initialized
INFO - 2017-01-31 22:49:33 --> Helper loaded: date_helper
DEBUG - 2017-01-31 22:49:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:49:33 --> Helper loaded: url_helper
INFO - 2017-01-31 22:49:33 --> Helper loaded: download_helper
INFO - 2017-01-31 22:49:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:49:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-01-31 22:49:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-01-31 22:49:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-01-31 22:49:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:49:33 --> Final output sent to browser
DEBUG - 2017-01-31 22:49:33 --> Total execution time: 0.0921
INFO - 2017-01-31 22:49:34 --> Config Class Initialized
INFO - 2017-01-31 22:49:34 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:49:34 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:49:34 --> Utf8 Class Initialized
INFO - 2017-01-31 22:49:34 --> URI Class Initialized
INFO - 2017-01-31 22:49:34 --> Router Class Initialized
INFO - 2017-01-31 22:49:34 --> Output Class Initialized
INFO - 2017-01-31 22:49:34 --> Security Class Initialized
DEBUG - 2017-01-31 22:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:49:34 --> Input Class Initialized
INFO - 2017-01-31 22:49:34 --> Language Class Initialized
INFO - 2017-01-31 22:49:34 --> Loader Class Initialized
INFO - 2017-01-31 22:49:34 --> Database Driver Class Initialized
INFO - 2017-01-31 22:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:49:34 --> Controller Class Initialized
INFO - 2017-01-31 22:49:34 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:49:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:49:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:49:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:49:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:49:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:49:34 --> Final output sent to browser
DEBUG - 2017-01-31 22:49:34 --> Total execution time: 0.0664
INFO - 2017-01-31 22:49:43 --> Config Class Initialized
INFO - 2017-01-31 22:49:43 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:49:43 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:49:43 --> Utf8 Class Initialized
INFO - 2017-01-31 22:49:43 --> URI Class Initialized
DEBUG - 2017-01-31 22:49:43 --> No URI present. Default controller set.
INFO - 2017-01-31 22:49:43 --> Router Class Initialized
INFO - 2017-01-31 22:49:43 --> Output Class Initialized
INFO - 2017-01-31 22:49:43 --> Security Class Initialized
DEBUG - 2017-01-31 22:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:49:43 --> Input Class Initialized
INFO - 2017-01-31 22:49:43 --> Language Class Initialized
INFO - 2017-01-31 22:49:43 --> Loader Class Initialized
INFO - 2017-01-31 22:49:43 --> Database Driver Class Initialized
INFO - 2017-01-31 22:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:49:43 --> Controller Class Initialized
INFO - 2017-01-31 22:49:43 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:49:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:49:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:49:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:49:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:49:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:49:43 --> Final output sent to browser
DEBUG - 2017-01-31 22:49:43 --> Total execution time: 0.0140
INFO - 2017-01-31 22:49:49 --> Config Class Initialized
INFO - 2017-01-31 22:49:49 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:49:49 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:49:49 --> Utf8 Class Initialized
INFO - 2017-01-31 22:49:49 --> URI Class Initialized
INFO - 2017-01-31 22:49:49 --> Router Class Initialized
INFO - 2017-01-31 22:49:49 --> Output Class Initialized
INFO - 2017-01-31 22:49:49 --> Security Class Initialized
DEBUG - 2017-01-31 22:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:49:49 --> Input Class Initialized
INFO - 2017-01-31 22:49:49 --> Language Class Initialized
INFO - 2017-01-31 22:49:49 --> Loader Class Initialized
INFO - 2017-01-31 22:49:49 --> Database Driver Class Initialized
INFO - 2017-01-31 22:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:49:49 --> Controller Class Initialized
INFO - 2017-01-31 22:49:49 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:49:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:49:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:49:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:49:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:49:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:49:49 --> Final output sent to browser
DEBUG - 2017-01-31 22:49:49 --> Total execution time: 0.0139
INFO - 2017-01-31 22:50:05 --> Config Class Initialized
INFO - 2017-01-31 22:50:05 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:50:05 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:50:05 --> Utf8 Class Initialized
INFO - 2017-01-31 22:50:05 --> URI Class Initialized
DEBUG - 2017-01-31 22:50:05 --> No URI present. Default controller set.
INFO - 2017-01-31 22:50:05 --> Router Class Initialized
INFO - 2017-01-31 22:50:05 --> Output Class Initialized
INFO - 2017-01-31 22:50:05 --> Security Class Initialized
DEBUG - 2017-01-31 22:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:50:05 --> Input Class Initialized
INFO - 2017-01-31 22:50:05 --> Language Class Initialized
INFO - 2017-01-31 22:50:05 --> Loader Class Initialized
INFO - 2017-01-31 22:50:05 --> Database Driver Class Initialized
INFO - 2017-01-31 22:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:50:05 --> Controller Class Initialized
INFO - 2017-01-31 22:50:05 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:50:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:50:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:50:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:50:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:50:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:50:05 --> Final output sent to browser
DEBUG - 2017-01-31 22:50:05 --> Total execution time: 0.0228
INFO - 2017-01-31 22:50:07 --> Config Class Initialized
INFO - 2017-01-31 22:50:07 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:50:07 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:50:07 --> Utf8 Class Initialized
INFO - 2017-01-31 22:50:07 --> URI Class Initialized
INFO - 2017-01-31 22:50:07 --> Router Class Initialized
INFO - 2017-01-31 22:50:07 --> Output Class Initialized
INFO - 2017-01-31 22:50:07 --> Security Class Initialized
DEBUG - 2017-01-31 22:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:50:07 --> Input Class Initialized
INFO - 2017-01-31 22:50:07 --> Language Class Initialized
INFO - 2017-01-31 22:50:07 --> Loader Class Initialized
INFO - 2017-01-31 22:50:07 --> Database Driver Class Initialized
INFO - 2017-01-31 22:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:50:07 --> Controller Class Initialized
INFO - 2017-01-31 22:50:07 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:50:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:50:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:50:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:50:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:50:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:50:07 --> Final output sent to browser
DEBUG - 2017-01-31 22:50:07 --> Total execution time: 0.0684
INFO - 2017-01-31 22:51:10 --> Config Class Initialized
INFO - 2017-01-31 22:51:10 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:51:10 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:51:10 --> Utf8 Class Initialized
INFO - 2017-01-31 22:51:10 --> URI Class Initialized
INFO - 2017-01-31 22:51:10 --> Router Class Initialized
INFO - 2017-01-31 22:51:10 --> Output Class Initialized
INFO - 2017-01-31 22:51:10 --> Security Class Initialized
DEBUG - 2017-01-31 22:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:51:10 --> Input Class Initialized
INFO - 2017-01-31 22:51:10 --> Language Class Initialized
INFO - 2017-01-31 22:51:10 --> Loader Class Initialized
INFO - 2017-01-31 22:51:10 --> Database Driver Class Initialized
INFO - 2017-01-31 22:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:51:10 --> Controller Class Initialized
INFO - 2017-01-31 22:51:10 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-01-31 22:51:10 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-01-31 22:51:10 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-01-31 22:51:10 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-01-31 22:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:51:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:51:10 --> Final output sent to browser
DEBUG - 2017-01-31 22:51:10 --> Total execution time: 0.0136
INFO - 2017-01-31 22:51:13 --> Config Class Initialized
INFO - 2017-01-31 22:51:13 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:51:13 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:51:13 --> Utf8 Class Initialized
INFO - 2017-01-31 22:51:13 --> URI Class Initialized
INFO - 2017-01-31 22:51:13 --> Router Class Initialized
INFO - 2017-01-31 22:51:13 --> Output Class Initialized
INFO - 2017-01-31 22:51:13 --> Security Class Initialized
DEBUG - 2017-01-31 22:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:51:13 --> Input Class Initialized
INFO - 2017-01-31 22:51:13 --> Language Class Initialized
INFO - 2017-01-31 22:51:13 --> Loader Class Initialized
INFO - 2017-01-31 22:51:13 --> Database Driver Class Initialized
INFO - 2017-01-31 22:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:51:13 --> Controller Class Initialized
INFO - 2017-01-31 22:51:13 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:51:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:51:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:51:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:51:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:51:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:51:13 --> Final output sent to browser
DEBUG - 2017-01-31 22:51:13 --> Total execution time: 0.0136
INFO - 2017-01-31 22:52:53 --> Config Class Initialized
INFO - 2017-01-31 22:52:53 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:52:53 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:52:53 --> Utf8 Class Initialized
INFO - 2017-01-31 22:52:53 --> URI Class Initialized
INFO - 2017-01-31 22:52:53 --> Router Class Initialized
INFO - 2017-01-31 22:52:53 --> Output Class Initialized
INFO - 2017-01-31 22:52:53 --> Security Class Initialized
DEBUG - 2017-01-31 22:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:52:53 --> Input Class Initialized
INFO - 2017-01-31 22:52:53 --> Language Class Initialized
INFO - 2017-01-31 22:52:53 --> Loader Class Initialized
INFO - 2017-01-31 22:52:53 --> Database Driver Class Initialized
INFO - 2017-01-31 22:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:52:53 --> Controller Class Initialized
INFO - 2017-01-31 22:52:53 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:52:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:52:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:52:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:52:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:52:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:52:53 --> Final output sent to browser
DEBUG - 2017-01-31 22:52:53 --> Total execution time: 0.0142
INFO - 2017-01-31 22:52:55 --> Config Class Initialized
INFO - 2017-01-31 22:52:55 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:52:55 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:52:55 --> Utf8 Class Initialized
INFO - 2017-01-31 22:52:55 --> URI Class Initialized
INFO - 2017-01-31 22:52:55 --> Router Class Initialized
INFO - 2017-01-31 22:52:55 --> Output Class Initialized
INFO - 2017-01-31 22:52:55 --> Security Class Initialized
DEBUG - 2017-01-31 22:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:52:55 --> Input Class Initialized
INFO - 2017-01-31 22:52:55 --> Language Class Initialized
INFO - 2017-01-31 22:52:55 --> Loader Class Initialized
INFO - 2017-01-31 22:52:55 --> Database Driver Class Initialized
INFO - 2017-01-31 22:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:52:55 --> Controller Class Initialized
INFO - 2017-01-31 22:52:55 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:52:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:52:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:52:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:52:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:52:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:52:55 --> Final output sent to browser
DEBUG - 2017-01-31 22:52:55 --> Total execution time: 0.0133
INFO - 2017-01-31 22:53:01 --> Config Class Initialized
INFO - 2017-01-31 22:53:01 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:53:01 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:53:01 --> Utf8 Class Initialized
INFO - 2017-01-31 22:53:01 --> URI Class Initialized
INFO - 2017-01-31 22:53:01 --> Router Class Initialized
INFO - 2017-01-31 22:53:01 --> Output Class Initialized
INFO - 2017-01-31 22:53:01 --> Security Class Initialized
DEBUG - 2017-01-31 22:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:53:01 --> Input Class Initialized
INFO - 2017-01-31 22:53:01 --> Language Class Initialized
INFO - 2017-01-31 22:53:01 --> Loader Class Initialized
INFO - 2017-01-31 22:53:01 --> Database Driver Class Initialized
INFO - 2017-01-31 22:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:53:01 --> Controller Class Initialized
INFO - 2017-01-31 22:53:01 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:53:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-31 22:53:02 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-31 22:53:02 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Bree MilyAsi')
INFO - 2017-01-31 22:53:02 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-31 22:53:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-31 22:53:03 --> Config Class Initialized
INFO - 2017-01-31 22:53:03 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:53:03 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:53:03 --> Utf8 Class Initialized
INFO - 2017-01-31 22:53:03 --> URI Class Initialized
INFO - 2017-01-31 22:53:03 --> Router Class Initialized
INFO - 2017-01-31 22:53:03 --> Output Class Initialized
INFO - 2017-01-31 22:53:03 --> Security Class Initialized
DEBUG - 2017-01-31 22:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:53:03 --> Input Class Initialized
INFO - 2017-01-31 22:53:03 --> Language Class Initialized
INFO - 2017-01-31 22:53:03 --> Loader Class Initialized
INFO - 2017-01-31 22:53:03 --> Database Driver Class Initialized
INFO - 2017-01-31 22:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:53:03 --> Controller Class Initialized
INFO - 2017-01-31 22:53:03 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:53:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:53:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:53:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:53:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:53:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:53:03 --> Final output sent to browser
DEBUG - 2017-01-31 22:53:03 --> Total execution time: 0.0138
INFO - 2017-01-31 22:53:12 --> Config Class Initialized
INFO - 2017-01-31 22:53:12 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:53:12 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:53:12 --> Utf8 Class Initialized
INFO - 2017-01-31 22:53:12 --> URI Class Initialized
INFO - 2017-01-31 22:53:12 --> Router Class Initialized
INFO - 2017-01-31 22:53:12 --> Output Class Initialized
INFO - 2017-01-31 22:53:12 --> Security Class Initialized
DEBUG - 2017-01-31 22:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:53:12 --> Input Class Initialized
INFO - 2017-01-31 22:53:12 --> Language Class Initialized
INFO - 2017-01-31 22:53:12 --> Loader Class Initialized
INFO - 2017-01-31 22:53:12 --> Database Driver Class Initialized
INFO - 2017-01-31 22:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:53:12 --> Controller Class Initialized
INFO - 2017-01-31 22:53:12 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:53:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-31 22:53:12 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-31 22:53:12 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Bree MilyAsi')
INFO - 2017-01-31 22:53:12 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-31 22:53:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-31 22:53:13 --> Config Class Initialized
INFO - 2017-01-31 22:53:13 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:53:13 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:53:13 --> Utf8 Class Initialized
INFO - 2017-01-31 22:53:13 --> URI Class Initialized
INFO - 2017-01-31 22:53:13 --> Router Class Initialized
INFO - 2017-01-31 22:53:13 --> Output Class Initialized
INFO - 2017-01-31 22:53:13 --> Security Class Initialized
DEBUG - 2017-01-31 22:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:53:13 --> Input Class Initialized
INFO - 2017-01-31 22:53:13 --> Language Class Initialized
INFO - 2017-01-31 22:53:13 --> Loader Class Initialized
INFO - 2017-01-31 22:53:13 --> Database Driver Class Initialized
INFO - 2017-01-31 22:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:53:13 --> Controller Class Initialized
INFO - 2017-01-31 22:53:13 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:53:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:53:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:53:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:53:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:53:13 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:53:13 --> Final output sent to browser
DEBUG - 2017-01-31 22:53:13 --> Total execution time: 0.0178
INFO - 2017-01-31 22:53:14 --> Config Class Initialized
INFO - 2017-01-31 22:53:14 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:53:14 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:53:14 --> Utf8 Class Initialized
INFO - 2017-01-31 22:53:14 --> URI Class Initialized
INFO - 2017-01-31 22:53:14 --> Router Class Initialized
INFO - 2017-01-31 22:53:14 --> Output Class Initialized
INFO - 2017-01-31 22:53:14 --> Security Class Initialized
DEBUG - 2017-01-31 22:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:53:14 --> Input Class Initialized
INFO - 2017-01-31 22:53:14 --> Language Class Initialized
INFO - 2017-01-31 22:53:14 --> Loader Class Initialized
INFO - 2017-01-31 22:53:14 --> Database Driver Class Initialized
INFO - 2017-01-31 22:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:53:14 --> Controller Class Initialized
INFO - 2017-01-31 22:53:14 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:53:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-31 22:53:14 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-31 22:53:14 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Bree MilyAsi')
INFO - 2017-01-31 22:53:14 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-31 22:53:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-31 22:53:15 --> Config Class Initialized
INFO - 2017-01-31 22:53:15 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:53:15 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:53:15 --> Utf8 Class Initialized
INFO - 2017-01-31 22:53:15 --> URI Class Initialized
INFO - 2017-01-31 22:53:15 --> Router Class Initialized
INFO - 2017-01-31 22:53:15 --> Output Class Initialized
INFO - 2017-01-31 22:53:15 --> Security Class Initialized
DEBUG - 2017-01-31 22:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:53:15 --> Input Class Initialized
INFO - 2017-01-31 22:53:15 --> Language Class Initialized
INFO - 2017-01-31 22:53:15 --> Loader Class Initialized
INFO - 2017-01-31 22:53:15 --> Database Driver Class Initialized
INFO - 2017-01-31 22:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:53:15 --> Controller Class Initialized
INFO - 2017-01-31 22:53:15 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:53:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:53:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:53:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:53:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:53:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:53:15 --> Final output sent to browser
DEBUG - 2017-01-31 22:53:15 --> Total execution time: 0.0132
INFO - 2017-01-31 22:53:20 --> Config Class Initialized
INFO - 2017-01-31 22:53:20 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:53:20 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:53:20 --> Utf8 Class Initialized
INFO - 2017-01-31 22:53:20 --> URI Class Initialized
DEBUG - 2017-01-31 22:53:20 --> No URI present. Default controller set.
INFO - 2017-01-31 22:53:20 --> Router Class Initialized
INFO - 2017-01-31 22:53:20 --> Output Class Initialized
INFO - 2017-01-31 22:53:20 --> Security Class Initialized
DEBUG - 2017-01-31 22:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:53:20 --> Input Class Initialized
INFO - 2017-01-31 22:53:20 --> Language Class Initialized
INFO - 2017-01-31 22:53:20 --> Loader Class Initialized
INFO - 2017-01-31 22:53:20 --> Database Driver Class Initialized
INFO - 2017-01-31 22:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:53:20 --> Controller Class Initialized
INFO - 2017-01-31 22:53:20 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:53:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:53:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:53:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:53:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:53:20 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:53:20 --> Final output sent to browser
DEBUG - 2017-01-31 22:53:20 --> Total execution time: 0.0141
INFO - 2017-01-31 22:53:22 --> Config Class Initialized
INFO - 2017-01-31 22:53:22 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:53:22 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:53:22 --> Utf8 Class Initialized
INFO - 2017-01-31 22:53:22 --> URI Class Initialized
INFO - 2017-01-31 22:53:22 --> Router Class Initialized
INFO - 2017-01-31 22:53:22 --> Output Class Initialized
INFO - 2017-01-31 22:53:22 --> Security Class Initialized
DEBUG - 2017-01-31 22:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:53:22 --> Input Class Initialized
INFO - 2017-01-31 22:53:22 --> Language Class Initialized
INFO - 2017-01-31 22:53:22 --> Loader Class Initialized
INFO - 2017-01-31 22:53:22 --> Database Driver Class Initialized
INFO - 2017-01-31 22:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:53:22 --> Controller Class Initialized
INFO - 2017-01-31 22:53:22 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:53:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:53:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:53:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:53:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:53:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:53:22 --> Final output sent to browser
DEBUG - 2017-01-31 22:53:22 --> Total execution time: 0.0132
INFO - 2017-01-31 22:54:05 --> Config Class Initialized
INFO - 2017-01-31 22:54:05 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:54:05 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:54:05 --> Utf8 Class Initialized
INFO - 2017-01-31 22:54:05 --> URI Class Initialized
INFO - 2017-01-31 22:54:05 --> Router Class Initialized
INFO - 2017-01-31 22:54:05 --> Output Class Initialized
INFO - 2017-01-31 22:54:05 --> Security Class Initialized
DEBUG - 2017-01-31 22:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:54:05 --> Input Class Initialized
INFO - 2017-01-31 22:54:05 --> Language Class Initialized
INFO - 2017-01-31 22:54:05 --> Loader Class Initialized
INFO - 2017-01-31 22:54:05 --> Database Driver Class Initialized
INFO - 2017-01-31 22:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:54:05 --> Controller Class Initialized
INFO - 2017-01-31 22:54:05 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:54:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:54:05 --> Config Class Initialized
INFO - 2017-01-31 22:54:05 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:54:05 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:54:05 --> Utf8 Class Initialized
INFO - 2017-01-31 22:54:05 --> URI Class Initialized
INFO - 2017-01-31 22:54:05 --> Router Class Initialized
INFO - 2017-01-31 22:54:05 --> Output Class Initialized
INFO - 2017-01-31 22:54:05 --> Security Class Initialized
DEBUG - 2017-01-31 22:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:54:05 --> Input Class Initialized
INFO - 2017-01-31 22:54:05 --> Language Class Initialized
INFO - 2017-01-31 22:54:05 --> Loader Class Initialized
INFO - 2017-01-31 22:54:05 --> Database Driver Class Initialized
INFO - 2017-01-31 22:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:54:05 --> Controller Class Initialized
INFO - 2017-01-31 22:54:05 --> Helper loaded: date_helper
DEBUG - 2017-01-31 22:54:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:54:05 --> Helper loaded: url_helper
INFO - 2017-01-31 22:54:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:54:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 22:54:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 22:54:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 22:54:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:54:05 --> Final output sent to browser
DEBUG - 2017-01-31 22:54:05 --> Total execution time: 0.0223
INFO - 2017-01-31 22:54:06 --> Config Class Initialized
INFO - 2017-01-31 22:54:06 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:54:06 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:54:06 --> Utf8 Class Initialized
INFO - 2017-01-31 22:54:06 --> URI Class Initialized
INFO - 2017-01-31 22:54:06 --> Router Class Initialized
INFO - 2017-01-31 22:54:06 --> Output Class Initialized
INFO - 2017-01-31 22:54:06 --> Security Class Initialized
DEBUG - 2017-01-31 22:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:54:06 --> Input Class Initialized
INFO - 2017-01-31 22:54:06 --> Language Class Initialized
INFO - 2017-01-31 22:54:06 --> Loader Class Initialized
INFO - 2017-01-31 22:54:06 --> Database Driver Class Initialized
INFO - 2017-01-31 22:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:54:06 --> Controller Class Initialized
INFO - 2017-01-31 22:54:06 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:54:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:54:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:54:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:54:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:54:06 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:54:06 --> Final output sent to browser
DEBUG - 2017-01-31 22:54:06 --> Total execution time: 0.0134
INFO - 2017-01-31 22:54:24 --> Config Class Initialized
INFO - 2017-01-31 22:54:24 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:54:24 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:54:24 --> Utf8 Class Initialized
INFO - 2017-01-31 22:54:24 --> URI Class Initialized
DEBUG - 2017-01-31 22:54:24 --> No URI present. Default controller set.
INFO - 2017-01-31 22:54:24 --> Router Class Initialized
INFO - 2017-01-31 22:54:24 --> Output Class Initialized
INFO - 2017-01-31 22:54:24 --> Security Class Initialized
DEBUG - 2017-01-31 22:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:54:24 --> Input Class Initialized
INFO - 2017-01-31 22:54:24 --> Language Class Initialized
INFO - 2017-01-31 22:54:24 --> Loader Class Initialized
INFO - 2017-01-31 22:54:24 --> Database Driver Class Initialized
INFO - 2017-01-31 22:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:54:24 --> Controller Class Initialized
INFO - 2017-01-31 22:54:24 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:54:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:54:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:54:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:54:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:54:24 --> Final output sent to browser
DEBUG - 2017-01-31 22:54:24 --> Total execution time: 0.0219
INFO - 2017-01-31 22:54:26 --> Config Class Initialized
INFO - 2017-01-31 22:54:26 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:54:26 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:54:26 --> Utf8 Class Initialized
INFO - 2017-01-31 22:54:26 --> URI Class Initialized
INFO - 2017-01-31 22:54:26 --> Router Class Initialized
INFO - 2017-01-31 22:54:26 --> Output Class Initialized
INFO - 2017-01-31 22:54:26 --> Security Class Initialized
DEBUG - 2017-01-31 22:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:54:26 --> Input Class Initialized
INFO - 2017-01-31 22:54:26 --> Language Class Initialized
INFO - 2017-01-31 22:54:26 --> Loader Class Initialized
INFO - 2017-01-31 22:54:26 --> Database Driver Class Initialized
INFO - 2017-01-31 22:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:54:26 --> Controller Class Initialized
INFO - 2017-01-31 22:54:26 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:54:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:54:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:54:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:54:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:54:26 --> Final output sent to browser
DEBUG - 2017-01-31 22:54:26 --> Total execution time: 0.0141
INFO - 2017-01-31 22:55:26 --> Config Class Initialized
INFO - 2017-01-31 22:55:26 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:55:26 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:55:26 --> Utf8 Class Initialized
INFO - 2017-01-31 22:55:26 --> URI Class Initialized
INFO - 2017-01-31 22:55:26 --> Router Class Initialized
INFO - 2017-01-31 22:55:26 --> Output Class Initialized
INFO - 2017-01-31 22:55:26 --> Security Class Initialized
DEBUG - 2017-01-31 22:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:55:26 --> Input Class Initialized
INFO - 2017-01-31 22:55:26 --> Language Class Initialized
INFO - 2017-01-31 22:55:26 --> Loader Class Initialized
INFO - 2017-01-31 22:55:26 --> Database Driver Class Initialized
INFO - 2017-01-31 22:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:55:26 --> Controller Class Initialized
INFO - 2017-01-31 22:55:26 --> Helper loaded: date_helper
DEBUG - 2017-01-31 22:55:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:55:26 --> Helper loaded: url_helper
INFO - 2017-01-31 22:55:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:55:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 22:55:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 22:55:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 22:55:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:55:26 --> Final output sent to browser
DEBUG - 2017-01-31 22:55:26 --> Total execution time: 0.0133
INFO - 2017-01-31 22:55:28 --> Config Class Initialized
INFO - 2017-01-31 22:55:28 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:55:28 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:55:28 --> Utf8 Class Initialized
INFO - 2017-01-31 22:55:28 --> URI Class Initialized
INFO - 2017-01-31 22:55:28 --> Router Class Initialized
INFO - 2017-01-31 22:55:28 --> Output Class Initialized
INFO - 2017-01-31 22:55:28 --> Security Class Initialized
DEBUG - 2017-01-31 22:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:55:28 --> Input Class Initialized
INFO - 2017-01-31 22:55:28 --> Language Class Initialized
INFO - 2017-01-31 22:55:28 --> Loader Class Initialized
INFO - 2017-01-31 22:55:28 --> Database Driver Class Initialized
INFO - 2017-01-31 22:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:55:28 --> Controller Class Initialized
INFO - 2017-01-31 22:55:28 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:55:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:55:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:55:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:55:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:55:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:55:28 --> Final output sent to browser
DEBUG - 2017-01-31 22:55:28 --> Total execution time: 0.0213
INFO - 2017-01-31 22:55:29 --> Config Class Initialized
INFO - 2017-01-31 22:55:29 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:55:29 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:55:29 --> Utf8 Class Initialized
INFO - 2017-01-31 22:55:29 --> URI Class Initialized
DEBUG - 2017-01-31 22:55:29 --> No URI present. Default controller set.
INFO - 2017-01-31 22:55:29 --> Router Class Initialized
INFO - 2017-01-31 22:55:29 --> Output Class Initialized
INFO - 2017-01-31 22:55:29 --> Security Class Initialized
DEBUG - 2017-01-31 22:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:55:29 --> Input Class Initialized
INFO - 2017-01-31 22:55:29 --> Language Class Initialized
INFO - 2017-01-31 22:55:29 --> Loader Class Initialized
INFO - 2017-01-31 22:55:29 --> Database Driver Class Initialized
INFO - 2017-01-31 22:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:55:29 --> Controller Class Initialized
INFO - 2017-01-31 22:55:29 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:55:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:55:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:55:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:55:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:55:29 --> Final output sent to browser
DEBUG - 2017-01-31 22:55:29 --> Total execution time: 0.0139
INFO - 2017-01-31 22:55:30 --> Config Class Initialized
INFO - 2017-01-31 22:55:30 --> Hooks Class Initialized
DEBUG - 2017-01-31 22:55:30 --> UTF-8 Support Enabled
INFO - 2017-01-31 22:55:30 --> Utf8 Class Initialized
INFO - 2017-01-31 22:55:30 --> URI Class Initialized
INFO - 2017-01-31 22:55:30 --> Router Class Initialized
INFO - 2017-01-31 22:55:30 --> Output Class Initialized
INFO - 2017-01-31 22:55:30 --> Security Class Initialized
DEBUG - 2017-01-31 22:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 22:55:30 --> Input Class Initialized
INFO - 2017-01-31 22:55:30 --> Language Class Initialized
INFO - 2017-01-31 22:55:30 --> Loader Class Initialized
INFO - 2017-01-31 22:55:30 --> Database Driver Class Initialized
INFO - 2017-01-31 22:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 22:55:30 --> Controller Class Initialized
INFO - 2017-01-31 22:55:30 --> Helper loaded: url_helper
DEBUG - 2017-01-31 22:55:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 22:55:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 22:55:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 22:55:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 22:55:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 22:55:30 --> Final output sent to browser
DEBUG - 2017-01-31 22:55:30 --> Total execution time: 0.0132
INFO - 2017-01-31 23:16:36 --> Config Class Initialized
INFO - 2017-01-31 23:16:36 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:16:36 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:16:36 --> Utf8 Class Initialized
INFO - 2017-01-31 23:16:36 --> URI Class Initialized
DEBUG - 2017-01-31 23:16:36 --> No URI present. Default controller set.
INFO - 2017-01-31 23:16:36 --> Router Class Initialized
INFO - 2017-01-31 23:16:36 --> Output Class Initialized
INFO - 2017-01-31 23:16:36 --> Security Class Initialized
DEBUG - 2017-01-31 23:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:16:36 --> Input Class Initialized
INFO - 2017-01-31 23:16:36 --> Language Class Initialized
INFO - 2017-01-31 23:16:36 --> Loader Class Initialized
INFO - 2017-01-31 23:16:36 --> Database Driver Class Initialized
INFO - 2017-01-31 23:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:16:36 --> Controller Class Initialized
INFO - 2017-01-31 23:16:36 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:16:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:16:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 23:16:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 23:16:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 23:16:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 23:16:36 --> Final output sent to browser
DEBUG - 2017-01-31 23:16:36 --> Total execution time: 0.0131
INFO - 2017-01-31 23:16:43 --> Config Class Initialized
INFO - 2017-01-31 23:16:43 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:16:43 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:16:43 --> Utf8 Class Initialized
INFO - 2017-01-31 23:16:43 --> URI Class Initialized
INFO - 2017-01-31 23:16:43 --> Router Class Initialized
INFO - 2017-01-31 23:16:43 --> Output Class Initialized
INFO - 2017-01-31 23:16:43 --> Security Class Initialized
DEBUG - 2017-01-31 23:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:16:43 --> Input Class Initialized
INFO - 2017-01-31 23:16:43 --> Language Class Initialized
INFO - 2017-01-31 23:16:43 --> Loader Class Initialized
INFO - 2017-01-31 23:16:43 --> Database Driver Class Initialized
INFO - 2017-01-31 23:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:16:43 --> Controller Class Initialized
INFO - 2017-01-31 23:16:43 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:16:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 23:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 23:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 23:16:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 23:16:43 --> Final output sent to browser
DEBUG - 2017-01-31 23:16:43 --> Total execution time: 0.0133
INFO - 2017-01-31 23:18:38 --> Config Class Initialized
INFO - 2017-01-31 23:18:38 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:18:38 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:18:38 --> Utf8 Class Initialized
INFO - 2017-01-31 23:18:38 --> URI Class Initialized
INFO - 2017-01-31 23:18:38 --> Router Class Initialized
INFO - 2017-01-31 23:18:38 --> Output Class Initialized
INFO - 2017-01-31 23:18:38 --> Security Class Initialized
DEBUG - 2017-01-31 23:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:18:38 --> Input Class Initialized
INFO - 2017-01-31 23:18:38 --> Language Class Initialized
INFO - 2017-01-31 23:18:38 --> Loader Class Initialized
INFO - 2017-01-31 23:18:38 --> Database Driver Class Initialized
INFO - 2017-01-31 23:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:18:38 --> Controller Class Initialized
INFO - 2017-01-31 23:18:38 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:18:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-01-31 23:18:40 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-01-31 23:18:40 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Janeth Piñon')
INFO - 2017-01-31 23:18:40 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-01-31 23:18:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-01-31 23:19:56 --> Config Class Initialized
INFO - 2017-01-31 23:19:56 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:19:56 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:19:56 --> Utf8 Class Initialized
INFO - 2017-01-31 23:19:56 --> URI Class Initialized
DEBUG - 2017-01-31 23:19:56 --> No URI present. Default controller set.
INFO - 2017-01-31 23:19:56 --> Router Class Initialized
INFO - 2017-01-31 23:19:56 --> Output Class Initialized
INFO - 2017-01-31 23:19:56 --> Security Class Initialized
DEBUG - 2017-01-31 23:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:19:56 --> Input Class Initialized
INFO - 2017-01-31 23:19:56 --> Language Class Initialized
INFO - 2017-01-31 23:19:56 --> Loader Class Initialized
INFO - 2017-01-31 23:19:56 --> Database Driver Class Initialized
INFO - 2017-01-31 23:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:19:56 --> Controller Class Initialized
INFO - 2017-01-31 23:19:56 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 23:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 23:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 23:19:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 23:19:56 --> Final output sent to browser
DEBUG - 2017-01-31 23:19:56 --> Total execution time: 0.0136
INFO - 2017-01-31 23:28:45 --> Config Class Initialized
INFO - 2017-01-31 23:28:45 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:28:45 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:28:45 --> Utf8 Class Initialized
INFO - 2017-01-31 23:28:45 --> URI Class Initialized
DEBUG - 2017-01-31 23:28:45 --> No URI present. Default controller set.
INFO - 2017-01-31 23:28:45 --> Router Class Initialized
INFO - 2017-01-31 23:28:45 --> Output Class Initialized
INFO - 2017-01-31 23:28:45 --> Security Class Initialized
DEBUG - 2017-01-31 23:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:28:45 --> Input Class Initialized
INFO - 2017-01-31 23:28:45 --> Language Class Initialized
INFO - 2017-01-31 23:28:45 --> Loader Class Initialized
INFO - 2017-01-31 23:28:45 --> Database Driver Class Initialized
INFO - 2017-01-31 23:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:28:45 --> Controller Class Initialized
INFO - 2017-01-31 23:28:45 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:28:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:28:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 23:28:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 23:28:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 23:28:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 23:28:45 --> Final output sent to browser
DEBUG - 2017-01-31 23:28:45 --> Total execution time: 0.0159
INFO - 2017-01-31 23:29:01 --> Config Class Initialized
INFO - 2017-01-31 23:29:01 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:29:01 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:29:01 --> Utf8 Class Initialized
INFO - 2017-01-31 23:29:01 --> URI Class Initialized
DEBUG - 2017-01-31 23:29:01 --> No URI present. Default controller set.
INFO - 2017-01-31 23:29:01 --> Router Class Initialized
INFO - 2017-01-31 23:29:01 --> Output Class Initialized
INFO - 2017-01-31 23:29:01 --> Security Class Initialized
DEBUG - 2017-01-31 23:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:29:01 --> Input Class Initialized
INFO - 2017-01-31 23:29:01 --> Language Class Initialized
INFO - 2017-01-31 23:29:01 --> Loader Class Initialized
INFO - 2017-01-31 23:29:01 --> Database Driver Class Initialized
INFO - 2017-01-31 23:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:29:01 --> Controller Class Initialized
INFO - 2017-01-31 23:29:01 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:29:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:29:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 23:29:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 23:29:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 23:29:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 23:29:01 --> Final output sent to browser
DEBUG - 2017-01-31 23:29:01 --> Total execution time: 0.0141
INFO - 2017-01-31 23:33:35 --> Config Class Initialized
INFO - 2017-01-31 23:33:35 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:33:35 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:33:35 --> Utf8 Class Initialized
INFO - 2017-01-31 23:33:35 --> URI Class Initialized
INFO - 2017-01-31 23:33:35 --> Router Class Initialized
INFO - 2017-01-31 23:33:35 --> Output Class Initialized
INFO - 2017-01-31 23:33:35 --> Security Class Initialized
DEBUG - 2017-01-31 23:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:33:35 --> Input Class Initialized
INFO - 2017-01-31 23:33:35 --> Language Class Initialized
INFO - 2017-01-31 23:33:35 --> Loader Class Initialized
INFO - 2017-01-31 23:33:35 --> Database Driver Class Initialized
INFO - 2017-01-31 23:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:33:35 --> Controller Class Initialized
INFO - 2017-01-31 23:33:35 --> Helper loaded: date_helper
INFO - 2017-01-31 23:33:35 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:33:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:33:35 --> Helper loaded: form_helper
INFO - 2017-01-31 23:33:35 --> Form Validation Class Initialized
INFO - 2017-01-31 23:33:35 --> Final output sent to browser
DEBUG - 2017-01-31 23:33:35 --> Total execution time: 0.0140
INFO - 2017-01-31 23:33:35 --> Config Class Initialized
INFO - 2017-01-31 23:33:35 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:33:35 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:33:35 --> Utf8 Class Initialized
INFO - 2017-01-31 23:33:35 --> URI Class Initialized
INFO - 2017-01-31 23:33:35 --> Router Class Initialized
INFO - 2017-01-31 23:33:35 --> Output Class Initialized
INFO - 2017-01-31 23:33:35 --> Security Class Initialized
DEBUG - 2017-01-31 23:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:33:35 --> Input Class Initialized
INFO - 2017-01-31 23:33:35 --> Language Class Initialized
INFO - 2017-01-31 23:33:35 --> Loader Class Initialized
INFO - 2017-01-31 23:33:35 --> Database Driver Class Initialized
INFO - 2017-01-31 23:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:33:35 --> Controller Class Initialized
INFO - 2017-01-31 23:33:35 --> Helper loaded: date_helper
INFO - 2017-01-31 23:33:35 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:33:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:33:35 --> Helper loaded: form_helper
INFO - 2017-01-31 23:33:35 --> Form Validation Class Initialized
INFO - 2017-01-31 23:33:35 --> Final output sent to browser
DEBUG - 2017-01-31 23:33:35 --> Total execution time: 0.0145
INFO - 2017-01-31 23:34:03 --> Config Class Initialized
INFO - 2017-01-31 23:34:03 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:34:03 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:34:03 --> Utf8 Class Initialized
INFO - 2017-01-31 23:34:03 --> URI Class Initialized
INFO - 2017-01-31 23:34:03 --> Router Class Initialized
INFO - 2017-01-31 23:34:03 --> Output Class Initialized
INFO - 2017-01-31 23:34:03 --> Security Class Initialized
DEBUG - 2017-01-31 23:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:34:03 --> Input Class Initialized
INFO - 2017-01-31 23:34:03 --> Language Class Initialized
INFO - 2017-01-31 23:34:03 --> Loader Class Initialized
INFO - 2017-01-31 23:34:03 --> Database Driver Class Initialized
INFO - 2017-01-31 23:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:34:03 --> Controller Class Initialized
INFO - 2017-01-31 23:34:03 --> Helper loaded: date_helper
INFO - 2017-01-31 23:34:03 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:34:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:34:03 --> Helper loaded: form_helper
INFO - 2017-01-31 23:34:03 --> Form Validation Class Initialized
INFO - 2017-01-31 23:34:03 --> Final output sent to browser
DEBUG - 2017-01-31 23:34:03 --> Total execution time: 0.0405
INFO - 2017-01-31 23:34:05 --> Config Class Initialized
INFO - 2017-01-31 23:34:05 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:34:05 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:34:05 --> Utf8 Class Initialized
INFO - 2017-01-31 23:34:05 --> URI Class Initialized
INFO - 2017-01-31 23:34:05 --> Router Class Initialized
INFO - 2017-01-31 23:34:05 --> Output Class Initialized
INFO - 2017-01-31 23:34:05 --> Security Class Initialized
DEBUG - 2017-01-31 23:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:34:05 --> Input Class Initialized
INFO - 2017-01-31 23:34:05 --> Language Class Initialized
INFO - 2017-01-31 23:34:05 --> Loader Class Initialized
INFO - 2017-01-31 23:34:05 --> Database Driver Class Initialized
INFO - 2017-01-31 23:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:34:05 --> Controller Class Initialized
INFO - 2017-01-31 23:34:05 --> Helper loaded: date_helper
INFO - 2017-01-31 23:34:05 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:34:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:34:05 --> Helper loaded: form_helper
INFO - 2017-01-31 23:34:05 --> Form Validation Class Initialized
INFO - 2017-01-31 23:34:05 --> Final output sent to browser
DEBUG - 2017-01-31 23:34:05 --> Total execution time: 0.0160
INFO - 2017-01-31 23:34:06 --> Config Class Initialized
INFO - 2017-01-31 23:34:06 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:34:06 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:34:06 --> Utf8 Class Initialized
INFO - 2017-01-31 23:34:06 --> URI Class Initialized
INFO - 2017-01-31 23:34:06 --> Router Class Initialized
INFO - 2017-01-31 23:34:06 --> Output Class Initialized
INFO - 2017-01-31 23:34:06 --> Security Class Initialized
DEBUG - 2017-01-31 23:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:34:06 --> Input Class Initialized
INFO - 2017-01-31 23:34:06 --> Language Class Initialized
INFO - 2017-01-31 23:34:06 --> Loader Class Initialized
INFO - 2017-01-31 23:34:06 --> Database Driver Class Initialized
INFO - 2017-01-31 23:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:34:06 --> Controller Class Initialized
INFO - 2017-01-31 23:34:06 --> Helper loaded: date_helper
INFO - 2017-01-31 23:34:06 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:34:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:34:06 --> Helper loaded: form_helper
INFO - 2017-01-31 23:34:06 --> Form Validation Class Initialized
INFO - 2017-01-31 23:34:06 --> Final output sent to browser
DEBUG - 2017-01-31 23:34:06 --> Total execution time: 0.0159
INFO - 2017-01-31 23:34:10 --> Config Class Initialized
INFO - 2017-01-31 23:34:10 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:34:10 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:34:10 --> Utf8 Class Initialized
INFO - 2017-01-31 23:34:10 --> URI Class Initialized
INFO - 2017-01-31 23:34:10 --> Router Class Initialized
INFO - 2017-01-31 23:34:10 --> Output Class Initialized
INFO - 2017-01-31 23:34:10 --> Security Class Initialized
DEBUG - 2017-01-31 23:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:34:10 --> Input Class Initialized
INFO - 2017-01-31 23:34:10 --> Language Class Initialized
INFO - 2017-01-31 23:34:10 --> Loader Class Initialized
INFO - 2017-01-31 23:34:10 --> Database Driver Class Initialized
INFO - 2017-01-31 23:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:34:10 --> Controller Class Initialized
INFO - 2017-01-31 23:34:10 --> Helper loaded: date_helper
INFO - 2017-01-31 23:34:10 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:34:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:34:10 --> Helper loaded: form_helper
INFO - 2017-01-31 23:34:10 --> Form Validation Class Initialized
INFO - 2017-01-31 23:34:10 --> Final output sent to browser
DEBUG - 2017-01-31 23:34:10 --> Total execution time: 0.0150
INFO - 2017-01-31 23:34:11 --> Config Class Initialized
INFO - 2017-01-31 23:34:11 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:34:11 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:34:11 --> Utf8 Class Initialized
INFO - 2017-01-31 23:34:11 --> URI Class Initialized
INFO - 2017-01-31 23:34:11 --> Router Class Initialized
INFO - 2017-01-31 23:34:11 --> Output Class Initialized
INFO - 2017-01-31 23:34:11 --> Security Class Initialized
DEBUG - 2017-01-31 23:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:34:11 --> Input Class Initialized
INFO - 2017-01-31 23:34:11 --> Language Class Initialized
INFO - 2017-01-31 23:34:11 --> Loader Class Initialized
INFO - 2017-01-31 23:34:11 --> Database Driver Class Initialized
INFO - 2017-01-31 23:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:34:11 --> Controller Class Initialized
INFO - 2017-01-31 23:34:11 --> Helper loaded: date_helper
INFO - 2017-01-31 23:34:11 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:34:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:34:11 --> Helper loaded: form_helper
INFO - 2017-01-31 23:34:11 --> Form Validation Class Initialized
INFO - 2017-01-31 23:34:11 --> Final output sent to browser
DEBUG - 2017-01-31 23:34:11 --> Total execution time: 0.0145
INFO - 2017-01-31 23:34:27 --> Config Class Initialized
INFO - 2017-01-31 23:34:27 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:34:27 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:34:27 --> Utf8 Class Initialized
INFO - 2017-01-31 23:34:27 --> URI Class Initialized
INFO - 2017-01-31 23:34:27 --> Router Class Initialized
INFO - 2017-01-31 23:34:27 --> Output Class Initialized
INFO - 2017-01-31 23:34:27 --> Security Class Initialized
DEBUG - 2017-01-31 23:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:34:27 --> Input Class Initialized
INFO - 2017-01-31 23:34:27 --> Language Class Initialized
INFO - 2017-01-31 23:34:27 --> Loader Class Initialized
INFO - 2017-01-31 23:34:27 --> Database Driver Class Initialized
INFO - 2017-01-31 23:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:34:27 --> Controller Class Initialized
INFO - 2017-01-31 23:34:27 --> Helper loaded: date_helper
INFO - 2017-01-31 23:34:27 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:34:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:34:27 --> Helper loaded: form_helper
INFO - 2017-01-31 23:34:27 --> Form Validation Class Initialized
INFO - 2017-01-31 23:34:27 --> Final output sent to browser
DEBUG - 2017-01-31 23:34:27 --> Total execution time: 0.0179
INFO - 2017-01-31 23:34:31 --> Config Class Initialized
INFO - 2017-01-31 23:34:31 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:34:31 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:34:31 --> Utf8 Class Initialized
INFO - 2017-01-31 23:34:31 --> URI Class Initialized
INFO - 2017-01-31 23:34:31 --> Router Class Initialized
INFO - 2017-01-31 23:34:31 --> Output Class Initialized
INFO - 2017-01-31 23:34:31 --> Security Class Initialized
DEBUG - 2017-01-31 23:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:34:31 --> Input Class Initialized
INFO - 2017-01-31 23:34:31 --> Language Class Initialized
INFO - 2017-01-31 23:34:31 --> Loader Class Initialized
INFO - 2017-01-31 23:34:31 --> Database Driver Class Initialized
INFO - 2017-01-31 23:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:34:31 --> Controller Class Initialized
INFO - 2017-01-31 23:34:31 --> Helper loaded: date_helper
INFO - 2017-01-31 23:34:31 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:34:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:34:31 --> Helper loaded: form_helper
INFO - 2017-01-31 23:34:31 --> Form Validation Class Initialized
INFO - 2017-01-31 23:34:31 --> Final output sent to browser
DEBUG - 2017-01-31 23:34:31 --> Total execution time: 0.0138
INFO - 2017-01-31 23:34:32 --> Config Class Initialized
INFO - 2017-01-31 23:34:32 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:34:32 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:34:32 --> Utf8 Class Initialized
INFO - 2017-01-31 23:34:32 --> URI Class Initialized
INFO - 2017-01-31 23:34:32 --> Router Class Initialized
INFO - 2017-01-31 23:34:32 --> Output Class Initialized
INFO - 2017-01-31 23:34:32 --> Security Class Initialized
DEBUG - 2017-01-31 23:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:34:32 --> Input Class Initialized
INFO - 2017-01-31 23:34:32 --> Language Class Initialized
INFO - 2017-01-31 23:34:32 --> Loader Class Initialized
INFO - 2017-01-31 23:34:32 --> Database Driver Class Initialized
INFO - 2017-01-31 23:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:34:32 --> Controller Class Initialized
INFO - 2017-01-31 23:34:32 --> Helper loaded: date_helper
INFO - 2017-01-31 23:34:32 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:34:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:34:32 --> Helper loaded: form_helper
INFO - 2017-01-31 23:34:32 --> Form Validation Class Initialized
INFO - 2017-01-31 23:34:32 --> Final output sent to browser
DEBUG - 2017-01-31 23:34:32 --> Total execution time: 0.0391
INFO - 2017-01-31 23:34:34 --> Config Class Initialized
INFO - 2017-01-31 23:34:34 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:34:34 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:34:34 --> Utf8 Class Initialized
INFO - 2017-01-31 23:34:34 --> URI Class Initialized
INFO - 2017-01-31 23:34:34 --> Router Class Initialized
INFO - 2017-01-31 23:34:34 --> Output Class Initialized
INFO - 2017-01-31 23:34:34 --> Security Class Initialized
DEBUG - 2017-01-31 23:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:34:34 --> Input Class Initialized
INFO - 2017-01-31 23:34:34 --> Language Class Initialized
INFO - 2017-01-31 23:34:34 --> Loader Class Initialized
INFO - 2017-01-31 23:34:34 --> Database Driver Class Initialized
INFO - 2017-01-31 23:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:34:34 --> Controller Class Initialized
INFO - 2017-01-31 23:34:34 --> Helper loaded: date_helper
INFO - 2017-01-31 23:34:34 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:34:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:34:34 --> Helper loaded: form_helper
INFO - 2017-01-31 23:34:34 --> Form Validation Class Initialized
INFO - 2017-01-31 23:34:34 --> Final output sent to browser
DEBUG - 2017-01-31 23:34:34 --> Total execution time: 0.0143
INFO - 2017-01-31 23:34:35 --> Config Class Initialized
INFO - 2017-01-31 23:34:35 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:34:35 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:34:35 --> Utf8 Class Initialized
INFO - 2017-01-31 23:34:35 --> URI Class Initialized
INFO - 2017-01-31 23:34:35 --> Router Class Initialized
INFO - 2017-01-31 23:34:35 --> Output Class Initialized
INFO - 2017-01-31 23:34:35 --> Security Class Initialized
DEBUG - 2017-01-31 23:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:34:35 --> Input Class Initialized
INFO - 2017-01-31 23:34:35 --> Language Class Initialized
INFO - 2017-01-31 23:34:35 --> Loader Class Initialized
INFO - 2017-01-31 23:34:35 --> Database Driver Class Initialized
INFO - 2017-01-31 23:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:34:35 --> Controller Class Initialized
INFO - 2017-01-31 23:34:35 --> Helper loaded: date_helper
INFO - 2017-01-31 23:34:35 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:34:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:34:35 --> Helper loaded: form_helper
INFO - 2017-01-31 23:34:35 --> Form Validation Class Initialized
INFO - 2017-01-31 23:34:35 --> Final output sent to browser
DEBUG - 2017-01-31 23:34:35 --> Total execution time: 0.0171
INFO - 2017-01-31 23:34:36 --> Config Class Initialized
INFO - 2017-01-31 23:34:36 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:34:36 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:34:36 --> Utf8 Class Initialized
INFO - 2017-01-31 23:34:36 --> URI Class Initialized
INFO - 2017-01-31 23:34:36 --> Router Class Initialized
INFO - 2017-01-31 23:34:36 --> Output Class Initialized
INFO - 2017-01-31 23:34:36 --> Security Class Initialized
DEBUG - 2017-01-31 23:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:34:36 --> Input Class Initialized
INFO - 2017-01-31 23:34:36 --> Language Class Initialized
INFO - 2017-01-31 23:34:36 --> Loader Class Initialized
INFO - 2017-01-31 23:34:36 --> Database Driver Class Initialized
INFO - 2017-01-31 23:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:34:36 --> Controller Class Initialized
INFO - 2017-01-31 23:34:36 --> Helper loaded: date_helper
INFO - 2017-01-31 23:34:36 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:34:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:34:36 --> Helper loaded: form_helper
INFO - 2017-01-31 23:34:36 --> Form Validation Class Initialized
INFO - 2017-01-31 23:34:36 --> Final output sent to browser
DEBUG - 2017-01-31 23:34:36 --> Total execution time: 0.0142
INFO - 2017-01-31 23:34:37 --> Config Class Initialized
INFO - 2017-01-31 23:34:37 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:34:37 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:34:37 --> Utf8 Class Initialized
INFO - 2017-01-31 23:34:37 --> URI Class Initialized
INFO - 2017-01-31 23:34:37 --> Router Class Initialized
INFO - 2017-01-31 23:34:37 --> Output Class Initialized
INFO - 2017-01-31 23:34:37 --> Security Class Initialized
DEBUG - 2017-01-31 23:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:34:37 --> Input Class Initialized
INFO - 2017-01-31 23:34:37 --> Language Class Initialized
INFO - 2017-01-31 23:34:37 --> Loader Class Initialized
INFO - 2017-01-31 23:34:37 --> Database Driver Class Initialized
INFO - 2017-01-31 23:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:34:37 --> Controller Class Initialized
INFO - 2017-01-31 23:34:37 --> Helper loaded: date_helper
INFO - 2017-01-31 23:34:37 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:34:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:34:37 --> Helper loaded: form_helper
INFO - 2017-01-31 23:34:37 --> Form Validation Class Initialized
INFO - 2017-01-31 23:34:37 --> Final output sent to browser
DEBUG - 2017-01-31 23:34:37 --> Total execution time: 0.0152
INFO - 2017-01-31 23:38:25 --> Config Class Initialized
INFO - 2017-01-31 23:38:25 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:38:25 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:38:25 --> Utf8 Class Initialized
INFO - 2017-01-31 23:38:25 --> URI Class Initialized
INFO - 2017-01-31 23:38:25 --> Router Class Initialized
INFO - 2017-01-31 23:38:25 --> Output Class Initialized
INFO - 2017-01-31 23:38:25 --> Security Class Initialized
DEBUG - 2017-01-31 23:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:38:25 --> Input Class Initialized
INFO - 2017-01-31 23:38:25 --> Language Class Initialized
INFO - 2017-01-31 23:38:25 --> Loader Class Initialized
INFO - 2017-01-31 23:38:25 --> Database Driver Class Initialized
INFO - 2017-01-31 23:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:38:25 --> Controller Class Initialized
INFO - 2017-01-31 23:38:25 --> Helper loaded: date_helper
DEBUG - 2017-01-31 23:38:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:38:25 --> Helper loaded: url_helper
INFO - 2017-01-31 23:38:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 23:38:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 23:38:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 23:38:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 23:38:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 23:38:25 --> Final output sent to browser
DEBUG - 2017-01-31 23:38:25 --> Total execution time: 0.0135
INFO - 2017-01-31 23:38:26 --> Config Class Initialized
INFO - 2017-01-31 23:38:26 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:38:26 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:38:26 --> Utf8 Class Initialized
INFO - 2017-01-31 23:38:26 --> URI Class Initialized
INFO - 2017-01-31 23:38:26 --> Router Class Initialized
INFO - 2017-01-31 23:38:26 --> Output Class Initialized
INFO - 2017-01-31 23:38:26 --> Security Class Initialized
DEBUG - 2017-01-31 23:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:38:26 --> Input Class Initialized
INFO - 2017-01-31 23:38:26 --> Language Class Initialized
INFO - 2017-01-31 23:38:26 --> Loader Class Initialized
INFO - 2017-01-31 23:38:26 --> Database Driver Class Initialized
INFO - 2017-01-31 23:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:38:26 --> Controller Class Initialized
INFO - 2017-01-31 23:38:26 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:38:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:38:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 23:38:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 23:38:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 23:38:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 23:38:26 --> Final output sent to browser
DEBUG - 2017-01-31 23:38:26 --> Total execution time: 0.0129
INFO - 2017-01-31 23:51:17 --> Config Class Initialized
INFO - 2017-01-31 23:51:17 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:51:17 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:51:17 --> Utf8 Class Initialized
INFO - 2017-01-31 23:51:17 --> URI Class Initialized
DEBUG - 2017-01-31 23:51:17 --> No URI present. Default controller set.
INFO - 2017-01-31 23:51:17 --> Router Class Initialized
INFO - 2017-01-31 23:51:17 --> Output Class Initialized
INFO - 2017-01-31 23:51:17 --> Security Class Initialized
DEBUG - 2017-01-31 23:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:51:17 --> Input Class Initialized
INFO - 2017-01-31 23:51:17 --> Language Class Initialized
INFO - 2017-01-31 23:51:17 --> Loader Class Initialized
INFO - 2017-01-31 23:51:17 --> Database Driver Class Initialized
INFO - 2017-01-31 23:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:51:17 --> Controller Class Initialized
INFO - 2017-01-31 23:51:17 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:51:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:51:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 23:51:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 23:51:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 23:51:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 23:51:17 --> Final output sent to browser
DEBUG - 2017-01-31 23:51:17 --> Total execution time: 0.0130
INFO - 2017-01-31 23:51:39 --> Config Class Initialized
INFO - 2017-01-31 23:51:39 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:51:39 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:51:39 --> Utf8 Class Initialized
INFO - 2017-01-31 23:51:39 --> URI Class Initialized
INFO - 2017-01-31 23:51:39 --> Router Class Initialized
INFO - 2017-01-31 23:51:39 --> Output Class Initialized
INFO - 2017-01-31 23:51:39 --> Security Class Initialized
DEBUG - 2017-01-31 23:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:51:39 --> Input Class Initialized
INFO - 2017-01-31 23:51:39 --> Language Class Initialized
INFO - 2017-01-31 23:51:39 --> Loader Class Initialized
INFO - 2017-01-31 23:51:39 --> Database Driver Class Initialized
INFO - 2017-01-31 23:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:51:39 --> Controller Class Initialized
INFO - 2017-01-31 23:51:39 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:51:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:51:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 23:51:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 23:51:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 23:51:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 23:51:39 --> Final output sent to browser
DEBUG - 2017-01-31 23:51:39 --> Total execution time: 0.0132
INFO - 2017-01-31 23:52:33 --> Config Class Initialized
INFO - 2017-01-31 23:52:33 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:52:33 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:52:33 --> Utf8 Class Initialized
INFO - 2017-01-31 23:52:33 --> URI Class Initialized
INFO - 2017-01-31 23:52:33 --> Router Class Initialized
INFO - 2017-01-31 23:52:33 --> Output Class Initialized
INFO - 2017-01-31 23:52:33 --> Security Class Initialized
DEBUG - 2017-01-31 23:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:52:33 --> Input Class Initialized
INFO - 2017-01-31 23:52:33 --> Language Class Initialized
INFO - 2017-01-31 23:52:33 --> Loader Class Initialized
INFO - 2017-01-31 23:52:33 --> Database Driver Class Initialized
INFO - 2017-01-31 23:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:52:33 --> Controller Class Initialized
INFO - 2017-01-31 23:52:33 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:52:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:52:34 --> Config Class Initialized
INFO - 2017-01-31 23:52:34 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:52:34 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:52:34 --> Utf8 Class Initialized
INFO - 2017-01-31 23:52:34 --> URI Class Initialized
INFO - 2017-01-31 23:52:34 --> Router Class Initialized
INFO - 2017-01-31 23:52:34 --> Output Class Initialized
INFO - 2017-01-31 23:52:34 --> Security Class Initialized
DEBUG - 2017-01-31 23:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:52:34 --> Input Class Initialized
INFO - 2017-01-31 23:52:34 --> Language Class Initialized
INFO - 2017-01-31 23:52:34 --> Loader Class Initialized
INFO - 2017-01-31 23:52:34 --> Database Driver Class Initialized
INFO - 2017-01-31 23:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:52:34 --> Controller Class Initialized
INFO - 2017-01-31 23:52:34 --> Helper loaded: date_helper
DEBUG - 2017-01-31 23:52:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:52:34 --> Helper loaded: url_helper
INFO - 2017-01-31 23:52:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 23:52:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 23:52:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 23:52:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 23:52:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 23:52:34 --> Final output sent to browser
DEBUG - 2017-01-31 23:52:34 --> Total execution time: 0.0150
INFO - 2017-01-31 23:52:35 --> Config Class Initialized
INFO - 2017-01-31 23:52:35 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:52:35 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:52:35 --> Utf8 Class Initialized
INFO - 2017-01-31 23:52:35 --> URI Class Initialized
INFO - 2017-01-31 23:52:35 --> Router Class Initialized
INFO - 2017-01-31 23:52:35 --> Output Class Initialized
INFO - 2017-01-31 23:52:35 --> Security Class Initialized
DEBUG - 2017-01-31 23:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:52:35 --> Input Class Initialized
INFO - 2017-01-31 23:52:35 --> Language Class Initialized
INFO - 2017-01-31 23:52:35 --> Loader Class Initialized
INFO - 2017-01-31 23:52:35 --> Database Driver Class Initialized
INFO - 2017-01-31 23:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:52:35 --> Controller Class Initialized
INFO - 2017-01-31 23:52:35 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:52:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:52:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 23:52:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 23:52:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 23:52:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 23:52:35 --> Final output sent to browser
DEBUG - 2017-01-31 23:52:35 --> Total execution time: 0.0142
INFO - 2017-01-31 23:53:27 --> Config Class Initialized
INFO - 2017-01-31 23:53:27 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:53:27 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:53:27 --> Utf8 Class Initialized
INFO - 2017-01-31 23:53:27 --> URI Class Initialized
INFO - 2017-01-31 23:53:27 --> Router Class Initialized
INFO - 2017-01-31 23:53:27 --> Output Class Initialized
INFO - 2017-01-31 23:53:27 --> Security Class Initialized
DEBUG - 2017-01-31 23:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:53:27 --> Input Class Initialized
INFO - 2017-01-31 23:53:27 --> Language Class Initialized
INFO - 2017-01-31 23:53:27 --> Loader Class Initialized
INFO - 2017-01-31 23:53:27 --> Database Driver Class Initialized
INFO - 2017-01-31 23:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:53:27 --> Controller Class Initialized
INFO - 2017-01-31 23:53:27 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:53:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:53:28 --> Config Class Initialized
INFO - 2017-01-31 23:53:28 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:53:28 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:53:28 --> Utf8 Class Initialized
INFO - 2017-01-31 23:53:28 --> URI Class Initialized
INFO - 2017-01-31 23:53:28 --> Router Class Initialized
INFO - 2017-01-31 23:53:28 --> Output Class Initialized
INFO - 2017-01-31 23:53:28 --> Security Class Initialized
DEBUG - 2017-01-31 23:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:53:28 --> Input Class Initialized
INFO - 2017-01-31 23:53:28 --> Language Class Initialized
INFO - 2017-01-31 23:53:28 --> Loader Class Initialized
INFO - 2017-01-31 23:53:28 --> Database Driver Class Initialized
INFO - 2017-01-31 23:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:53:28 --> Controller Class Initialized
INFO - 2017-01-31 23:53:28 --> Helper loaded: date_helper
DEBUG - 2017-01-31 23:53:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:53:28 --> Helper loaded: url_helper
INFO - 2017-01-31 23:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 23:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 23:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 23:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 23:53:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 23:53:28 --> Final output sent to browser
DEBUG - 2017-01-31 23:53:28 --> Total execution time: 0.0148
INFO - 2017-01-31 23:53:29 --> Config Class Initialized
INFO - 2017-01-31 23:53:29 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:53:29 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:53:29 --> Utf8 Class Initialized
INFO - 2017-01-31 23:53:29 --> URI Class Initialized
INFO - 2017-01-31 23:53:29 --> Router Class Initialized
INFO - 2017-01-31 23:53:29 --> Output Class Initialized
INFO - 2017-01-31 23:53:29 --> Security Class Initialized
DEBUG - 2017-01-31 23:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:53:29 --> Input Class Initialized
INFO - 2017-01-31 23:53:29 --> Language Class Initialized
INFO - 2017-01-31 23:53:29 --> Loader Class Initialized
INFO - 2017-01-31 23:53:29 --> Database Driver Class Initialized
INFO - 2017-01-31 23:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:53:29 --> Controller Class Initialized
INFO - 2017-01-31 23:53:29 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:53:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:53:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 23:53:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 23:53:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 23:53:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 23:53:29 --> Final output sent to browser
DEBUG - 2017-01-31 23:53:29 --> Total execution time: 0.0210
INFO - 2017-01-31 23:53:31 --> Config Class Initialized
INFO - 2017-01-31 23:53:31 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:53:31 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:53:31 --> Utf8 Class Initialized
INFO - 2017-01-31 23:53:31 --> URI Class Initialized
INFO - 2017-01-31 23:53:31 --> Router Class Initialized
INFO - 2017-01-31 23:53:31 --> Output Class Initialized
INFO - 2017-01-31 23:53:31 --> Security Class Initialized
DEBUG - 2017-01-31 23:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:53:31 --> Input Class Initialized
INFO - 2017-01-31 23:53:31 --> Language Class Initialized
INFO - 2017-01-31 23:53:31 --> Loader Class Initialized
INFO - 2017-01-31 23:53:31 --> Database Driver Class Initialized
INFO - 2017-01-31 23:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:53:31 --> Controller Class Initialized
INFO - 2017-01-31 23:53:31 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:53:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:53:32 --> Config Class Initialized
INFO - 2017-01-31 23:53:32 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:53:32 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:53:32 --> Utf8 Class Initialized
INFO - 2017-01-31 23:53:32 --> URI Class Initialized
INFO - 2017-01-31 23:53:32 --> Router Class Initialized
INFO - 2017-01-31 23:53:32 --> Output Class Initialized
INFO - 2017-01-31 23:53:32 --> Security Class Initialized
DEBUG - 2017-01-31 23:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:53:32 --> Input Class Initialized
INFO - 2017-01-31 23:53:32 --> Language Class Initialized
INFO - 2017-01-31 23:53:32 --> Loader Class Initialized
INFO - 2017-01-31 23:53:32 --> Database Driver Class Initialized
INFO - 2017-01-31 23:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:53:32 --> Controller Class Initialized
INFO - 2017-01-31 23:53:32 --> Helper loaded: date_helper
DEBUG - 2017-01-31 23:53:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:53:32 --> Helper loaded: url_helper
INFO - 2017-01-31 23:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 23:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 23:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 23:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 23:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 23:53:32 --> Final output sent to browser
DEBUG - 2017-01-31 23:53:32 --> Total execution time: 0.0136
INFO - 2017-01-31 23:53:32 --> Config Class Initialized
INFO - 2017-01-31 23:53:32 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:53:32 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:53:32 --> Utf8 Class Initialized
INFO - 2017-01-31 23:53:32 --> URI Class Initialized
INFO - 2017-01-31 23:53:32 --> Router Class Initialized
INFO - 2017-01-31 23:53:32 --> Output Class Initialized
INFO - 2017-01-31 23:53:32 --> Security Class Initialized
DEBUG - 2017-01-31 23:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:53:32 --> Input Class Initialized
INFO - 2017-01-31 23:53:32 --> Language Class Initialized
INFO - 2017-01-31 23:53:32 --> Loader Class Initialized
INFO - 2017-01-31 23:53:32 --> Database Driver Class Initialized
INFO - 2017-01-31 23:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:53:32 --> Controller Class Initialized
INFO - 2017-01-31 23:53:32 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:53:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 23:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 23:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 23:53:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 23:53:32 --> Final output sent to browser
DEBUG - 2017-01-31 23:53:32 --> Total execution time: 0.0136
INFO - 2017-01-31 23:53:34 --> Config Class Initialized
INFO - 2017-01-31 23:53:34 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:53:34 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:53:34 --> Utf8 Class Initialized
INFO - 2017-01-31 23:53:34 --> URI Class Initialized
DEBUG - 2017-01-31 23:53:34 --> No URI present. Default controller set.
INFO - 2017-01-31 23:53:34 --> Router Class Initialized
INFO - 2017-01-31 23:53:34 --> Output Class Initialized
INFO - 2017-01-31 23:53:34 --> Security Class Initialized
DEBUG - 2017-01-31 23:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:53:34 --> Input Class Initialized
INFO - 2017-01-31 23:53:34 --> Language Class Initialized
INFO - 2017-01-31 23:53:34 --> Loader Class Initialized
INFO - 2017-01-31 23:53:34 --> Database Driver Class Initialized
INFO - 2017-01-31 23:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:53:34 --> Controller Class Initialized
INFO - 2017-01-31 23:53:34 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:53:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:53:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 23:53:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 23:53:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 23:53:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 23:53:34 --> Final output sent to browser
DEBUG - 2017-01-31 23:53:34 --> Total execution time: 0.0131
INFO - 2017-01-31 23:55:50 --> Config Class Initialized
INFO - 2017-01-31 23:55:50 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:55:50 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:55:50 --> Utf8 Class Initialized
INFO - 2017-01-31 23:55:50 --> URI Class Initialized
DEBUG - 2017-01-31 23:55:50 --> No URI present. Default controller set.
INFO - 2017-01-31 23:55:50 --> Router Class Initialized
INFO - 2017-01-31 23:55:50 --> Output Class Initialized
INFO - 2017-01-31 23:55:50 --> Security Class Initialized
DEBUG - 2017-01-31 23:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:55:50 --> Input Class Initialized
INFO - 2017-01-31 23:55:50 --> Language Class Initialized
INFO - 2017-01-31 23:55:50 --> Loader Class Initialized
INFO - 2017-01-31 23:55:50 --> Database Driver Class Initialized
INFO - 2017-01-31 23:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:55:50 --> Controller Class Initialized
INFO - 2017-01-31 23:55:50 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:55:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:55:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 23:55:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 23:55:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 23:55:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 23:55:50 --> Final output sent to browser
DEBUG - 2017-01-31 23:55:50 --> Total execution time: 0.0141
INFO - 2017-01-31 23:55:58 --> Config Class Initialized
INFO - 2017-01-31 23:55:58 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:55:58 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:55:58 --> Utf8 Class Initialized
INFO - 2017-01-31 23:55:58 --> URI Class Initialized
INFO - 2017-01-31 23:55:58 --> Router Class Initialized
INFO - 2017-01-31 23:55:58 --> Output Class Initialized
INFO - 2017-01-31 23:55:58 --> Security Class Initialized
DEBUG - 2017-01-31 23:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:55:58 --> Input Class Initialized
INFO - 2017-01-31 23:55:58 --> Language Class Initialized
INFO - 2017-01-31 23:55:58 --> Loader Class Initialized
INFO - 2017-01-31 23:55:58 --> Database Driver Class Initialized
INFO - 2017-01-31 23:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:55:58 --> Controller Class Initialized
INFO - 2017-01-31 23:55:58 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:55:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:55:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 23:55:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 23:55:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 23:55:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 23:55:58 --> Final output sent to browser
DEBUG - 2017-01-31 23:55:58 --> Total execution time: 0.0140
INFO - 2017-01-31 23:56:20 --> Config Class Initialized
INFO - 2017-01-31 23:56:20 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:56:20 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:56:20 --> Utf8 Class Initialized
INFO - 2017-01-31 23:56:20 --> URI Class Initialized
INFO - 2017-01-31 23:56:20 --> Router Class Initialized
INFO - 2017-01-31 23:56:20 --> Output Class Initialized
INFO - 2017-01-31 23:56:20 --> Security Class Initialized
DEBUG - 2017-01-31 23:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:56:20 --> Input Class Initialized
INFO - 2017-01-31 23:56:20 --> Language Class Initialized
INFO - 2017-01-31 23:56:20 --> Loader Class Initialized
INFO - 2017-01-31 23:56:20 --> Database Driver Class Initialized
INFO - 2017-01-31 23:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:56:20 --> Controller Class Initialized
INFO - 2017-01-31 23:56:20 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:56:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:56:21 --> Config Class Initialized
INFO - 2017-01-31 23:56:21 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:56:21 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:56:21 --> Utf8 Class Initialized
INFO - 2017-01-31 23:56:21 --> URI Class Initialized
INFO - 2017-01-31 23:56:21 --> Router Class Initialized
INFO - 2017-01-31 23:56:21 --> Output Class Initialized
INFO - 2017-01-31 23:56:21 --> Security Class Initialized
DEBUG - 2017-01-31 23:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:56:21 --> Input Class Initialized
INFO - 2017-01-31 23:56:21 --> Language Class Initialized
INFO - 2017-01-31 23:56:21 --> Loader Class Initialized
INFO - 2017-01-31 23:56:21 --> Database Driver Class Initialized
INFO - 2017-01-31 23:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:56:21 --> Controller Class Initialized
INFO - 2017-01-31 23:56:21 --> Helper loaded: date_helper
DEBUG - 2017-01-31 23:56:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:56:21 --> Helper loaded: url_helper
INFO - 2017-01-31 23:56:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 23:56:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-31 23:56:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-31 23:56:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-31 23:56:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 23:56:21 --> Final output sent to browser
DEBUG - 2017-01-31 23:56:21 --> Total execution time: 0.0142
INFO - 2017-01-31 23:56:22 --> Config Class Initialized
INFO - 2017-01-31 23:56:22 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:56:22 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:56:22 --> Utf8 Class Initialized
INFO - 2017-01-31 23:56:22 --> URI Class Initialized
INFO - 2017-01-31 23:56:22 --> Router Class Initialized
INFO - 2017-01-31 23:56:22 --> Output Class Initialized
INFO - 2017-01-31 23:56:22 --> Security Class Initialized
DEBUG - 2017-01-31 23:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:56:22 --> Input Class Initialized
INFO - 2017-01-31 23:56:22 --> Language Class Initialized
INFO - 2017-01-31 23:56:22 --> Loader Class Initialized
INFO - 2017-01-31 23:56:22 --> Database Driver Class Initialized
INFO - 2017-01-31 23:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:56:22 --> Controller Class Initialized
INFO - 2017-01-31 23:56:22 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:56:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:56:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 23:56:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 23:56:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 23:56:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 23:56:22 --> Final output sent to browser
DEBUG - 2017-01-31 23:56:22 --> Total execution time: 0.0134
INFO - 2017-01-31 23:56:28 --> Config Class Initialized
INFO - 2017-01-31 23:56:28 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:56:28 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:56:28 --> Utf8 Class Initialized
INFO - 2017-01-31 23:56:28 --> URI Class Initialized
DEBUG - 2017-01-31 23:56:28 --> No URI present. Default controller set.
INFO - 2017-01-31 23:56:28 --> Router Class Initialized
INFO - 2017-01-31 23:56:28 --> Output Class Initialized
INFO - 2017-01-31 23:56:28 --> Security Class Initialized
DEBUG - 2017-01-31 23:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:56:28 --> Input Class Initialized
INFO - 2017-01-31 23:56:28 --> Language Class Initialized
INFO - 2017-01-31 23:56:28 --> Loader Class Initialized
INFO - 2017-01-31 23:56:28 --> Database Driver Class Initialized
INFO - 2017-01-31 23:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:56:28 --> Controller Class Initialized
INFO - 2017-01-31 23:56:28 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:56:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:56:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 23:56:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 23:56:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 23:56:28 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 23:56:28 --> Final output sent to browser
DEBUG - 2017-01-31 23:56:28 --> Total execution time: 0.0137
INFO - 2017-01-31 23:56:29 --> Config Class Initialized
INFO - 2017-01-31 23:56:29 --> Hooks Class Initialized
DEBUG - 2017-01-31 23:56:29 --> UTF-8 Support Enabled
INFO - 2017-01-31 23:56:29 --> Utf8 Class Initialized
INFO - 2017-01-31 23:56:29 --> URI Class Initialized
INFO - 2017-01-31 23:56:29 --> Router Class Initialized
INFO - 2017-01-31 23:56:29 --> Output Class Initialized
INFO - 2017-01-31 23:56:29 --> Security Class Initialized
DEBUG - 2017-01-31 23:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-31 23:56:29 --> Input Class Initialized
INFO - 2017-01-31 23:56:29 --> Language Class Initialized
INFO - 2017-01-31 23:56:29 --> Loader Class Initialized
INFO - 2017-01-31 23:56:29 --> Database Driver Class Initialized
INFO - 2017-01-31 23:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-31 23:56:29 --> Controller Class Initialized
INFO - 2017-01-31 23:56:29 --> Helper loaded: url_helper
DEBUG - 2017-01-31 23:56:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-31 23:56:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-31 23:56:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-31 23:56:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-31 23:56:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-31 23:56:29 --> Final output sent to browser
DEBUG - 2017-01-31 23:56:29 --> Total execution time: 0.0130

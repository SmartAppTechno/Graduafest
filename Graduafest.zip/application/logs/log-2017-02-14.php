<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-14 03:07:56 --> Config Class Initialized
INFO - 2017-02-14 03:07:56 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:07:56 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:07:56 --> Utf8 Class Initialized
INFO - 2017-02-14 03:07:56 --> URI Class Initialized
DEBUG - 2017-02-14 03:07:56 --> No URI present. Default controller set.
INFO - 2017-02-14 03:07:56 --> Router Class Initialized
INFO - 2017-02-14 03:07:56 --> Output Class Initialized
INFO - 2017-02-14 03:07:56 --> Security Class Initialized
DEBUG - 2017-02-14 03:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:07:56 --> Input Class Initialized
INFO - 2017-02-14 03:07:56 --> Language Class Initialized
INFO - 2017-02-14 03:07:56 --> Loader Class Initialized
INFO - 2017-02-14 03:07:56 --> Database Driver Class Initialized
INFO - 2017-02-14 03:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:07:56 --> Controller Class Initialized
INFO - 2017-02-14 03:07:56 --> Helper loaded: url_helper
DEBUG - 2017-02-14 03:07:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:07:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 03:07:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 03:07:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 03:07:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 03:07:56 --> Final output sent to browser
DEBUG - 2017-02-14 03:07:56 --> Total execution time: 0.0840
INFO - 2017-02-14 03:08:01 --> Config Class Initialized
INFO - 2017-02-14 03:08:01 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:08:01 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:08:01 --> Utf8 Class Initialized
INFO - 2017-02-14 03:08:01 --> URI Class Initialized
INFO - 2017-02-14 03:08:01 --> Router Class Initialized
INFO - 2017-02-14 03:08:01 --> Output Class Initialized
INFO - 2017-02-14 03:08:01 --> Security Class Initialized
DEBUG - 2017-02-14 03:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:08:01 --> Input Class Initialized
INFO - 2017-02-14 03:08:01 --> Language Class Initialized
INFO - 2017-02-14 03:08:01 --> Loader Class Initialized
INFO - 2017-02-14 03:08:01 --> Database Driver Class Initialized
INFO - 2017-02-14 03:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:08:01 --> Controller Class Initialized
INFO - 2017-02-14 03:08:01 --> Helper loaded: url_helper
DEBUG - 2017-02-14 03:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:08:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 03:08:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 03:08:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 03:08:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 03:08:01 --> Final output sent to browser
DEBUG - 2017-02-14 03:08:01 --> Total execution time: 0.0141
INFO - 2017-02-14 03:08:28 --> Config Class Initialized
INFO - 2017-02-14 03:08:28 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:08:28 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:08:28 --> Utf8 Class Initialized
INFO - 2017-02-14 03:08:28 --> URI Class Initialized
INFO - 2017-02-14 03:08:28 --> Router Class Initialized
INFO - 2017-02-14 03:08:28 --> Output Class Initialized
INFO - 2017-02-14 03:08:28 --> Security Class Initialized
DEBUG - 2017-02-14 03:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:08:28 --> Input Class Initialized
INFO - 2017-02-14 03:08:28 --> Language Class Initialized
INFO - 2017-02-14 03:08:28 --> Loader Class Initialized
INFO - 2017-02-14 03:08:28 --> Database Driver Class Initialized
INFO - 2017-02-14 03:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:08:28 --> Controller Class Initialized
INFO - 2017-02-14 03:08:28 --> Helper loaded: url_helper
DEBUG - 2017-02-14 03:08:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:08:29 --> Config Class Initialized
INFO - 2017-02-14 03:08:29 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:08:29 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:08:29 --> Utf8 Class Initialized
INFO - 2017-02-14 03:08:29 --> URI Class Initialized
INFO - 2017-02-14 03:08:29 --> Router Class Initialized
INFO - 2017-02-14 03:08:29 --> Output Class Initialized
INFO - 2017-02-14 03:08:29 --> Security Class Initialized
DEBUG - 2017-02-14 03:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:08:29 --> Input Class Initialized
INFO - 2017-02-14 03:08:29 --> Language Class Initialized
INFO - 2017-02-14 03:08:29 --> Loader Class Initialized
INFO - 2017-02-14 03:08:29 --> Database Driver Class Initialized
INFO - 2017-02-14 03:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:08:29 --> Controller Class Initialized
INFO - 2017-02-14 03:08:29 --> Helper loaded: date_helper
DEBUG - 2017-02-14 03:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:08:29 --> Helper loaded: url_helper
INFO - 2017-02-14 03:08:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 03:08:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-14 03:08:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-14 03:08:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-14 03:08:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 03:08:29 --> Final output sent to browser
DEBUG - 2017-02-14 03:08:29 --> Total execution time: 0.0148
INFO - 2017-02-14 03:08:30 --> Config Class Initialized
INFO - 2017-02-14 03:08:30 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:08:30 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:08:30 --> Utf8 Class Initialized
INFO - 2017-02-14 03:08:30 --> URI Class Initialized
INFO - 2017-02-14 03:08:30 --> Router Class Initialized
INFO - 2017-02-14 03:08:30 --> Output Class Initialized
INFO - 2017-02-14 03:08:30 --> Security Class Initialized
DEBUG - 2017-02-14 03:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:08:30 --> Input Class Initialized
INFO - 2017-02-14 03:08:30 --> Language Class Initialized
INFO - 2017-02-14 03:08:30 --> Loader Class Initialized
INFO - 2017-02-14 03:08:30 --> Database Driver Class Initialized
INFO - 2017-02-14 03:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:08:30 --> Controller Class Initialized
INFO - 2017-02-14 03:08:30 --> Helper loaded: url_helper
DEBUG - 2017-02-14 03:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:08:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 03:08:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 03:08:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 03:08:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 03:08:30 --> Final output sent to browser
DEBUG - 2017-02-14 03:08:30 --> Total execution time: 0.0136
INFO - 2017-02-14 03:08:40 --> Config Class Initialized
INFO - 2017-02-14 03:08:40 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:08:40 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:08:40 --> Utf8 Class Initialized
INFO - 2017-02-14 03:08:40 --> URI Class Initialized
DEBUG - 2017-02-14 03:08:40 --> No URI present. Default controller set.
INFO - 2017-02-14 03:08:40 --> Router Class Initialized
INFO - 2017-02-14 03:08:40 --> Output Class Initialized
INFO - 2017-02-14 03:08:40 --> Security Class Initialized
DEBUG - 2017-02-14 03:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:08:40 --> Input Class Initialized
INFO - 2017-02-14 03:08:40 --> Language Class Initialized
INFO - 2017-02-14 03:08:40 --> Loader Class Initialized
INFO - 2017-02-14 03:08:40 --> Database Driver Class Initialized
INFO - 2017-02-14 03:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:08:40 --> Controller Class Initialized
INFO - 2017-02-14 03:08:40 --> Helper loaded: url_helper
DEBUG - 2017-02-14 03:08:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:08:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 03:08:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 03:08:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 03:08:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 03:08:40 --> Final output sent to browser
DEBUG - 2017-02-14 03:08:40 --> Total execution time: 0.0133
INFO - 2017-02-14 03:08:41 --> Config Class Initialized
INFO - 2017-02-14 03:08:41 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:08:41 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:08:41 --> Utf8 Class Initialized
INFO - 2017-02-14 03:08:41 --> URI Class Initialized
INFO - 2017-02-14 03:08:41 --> Router Class Initialized
INFO - 2017-02-14 03:08:41 --> Output Class Initialized
INFO - 2017-02-14 03:08:41 --> Security Class Initialized
DEBUG - 2017-02-14 03:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:08:41 --> Input Class Initialized
INFO - 2017-02-14 03:08:41 --> Language Class Initialized
INFO - 2017-02-14 03:08:41 --> Loader Class Initialized
INFO - 2017-02-14 03:08:41 --> Database Driver Class Initialized
INFO - 2017-02-14 03:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:08:41 --> Controller Class Initialized
INFO - 2017-02-14 03:08:41 --> Helper loaded: url_helper
DEBUG - 2017-02-14 03:08:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:08:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 03:08:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 03:08:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 03:08:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 03:08:41 --> Final output sent to browser
DEBUG - 2017-02-14 03:08:41 --> Total execution time: 0.0130
INFO - 2017-02-14 03:09:52 --> Config Class Initialized
INFO - 2017-02-14 03:09:52 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:09:52 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:09:52 --> Utf8 Class Initialized
INFO - 2017-02-14 03:09:52 --> URI Class Initialized
INFO - 2017-02-14 03:09:52 --> Router Class Initialized
INFO - 2017-02-14 03:09:52 --> Output Class Initialized
INFO - 2017-02-14 03:09:52 --> Security Class Initialized
DEBUG - 2017-02-14 03:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:09:52 --> Input Class Initialized
INFO - 2017-02-14 03:09:52 --> Language Class Initialized
INFO - 2017-02-14 03:09:52 --> Loader Class Initialized
INFO - 2017-02-14 03:09:52 --> Database Driver Class Initialized
INFO - 2017-02-14 03:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:09:52 --> Controller Class Initialized
INFO - 2017-02-14 03:09:52 --> Helper loaded: url_helper
DEBUG - 2017-02-14 03:09:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:09:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 03:09:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 03:09:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 03:09:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 03:09:52 --> Final output sent to browser
DEBUG - 2017-02-14 03:09:52 --> Total execution time: 0.0142
INFO - 2017-02-14 03:09:53 --> Config Class Initialized
INFO - 2017-02-14 03:09:53 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:09:53 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:09:53 --> Utf8 Class Initialized
INFO - 2017-02-14 03:09:53 --> URI Class Initialized
INFO - 2017-02-14 03:09:53 --> Router Class Initialized
INFO - 2017-02-14 03:09:53 --> Output Class Initialized
INFO - 2017-02-14 03:09:53 --> Security Class Initialized
DEBUG - 2017-02-14 03:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:09:53 --> Input Class Initialized
INFO - 2017-02-14 03:09:53 --> Language Class Initialized
INFO - 2017-02-14 03:09:53 --> Loader Class Initialized
INFO - 2017-02-14 03:09:53 --> Database Driver Class Initialized
INFO - 2017-02-14 03:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:09:53 --> Controller Class Initialized
INFO - 2017-02-14 03:09:53 --> Helper loaded: url_helper
DEBUG - 2017-02-14 03:09:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:09:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 03:09:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 03:09:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 03:09:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 03:09:53 --> Final output sent to browser
DEBUG - 2017-02-14 03:09:53 --> Total execution time: 0.0133
INFO - 2017-02-14 03:10:40 --> Config Class Initialized
INFO - 2017-02-14 03:10:40 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:10:40 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:10:40 --> Utf8 Class Initialized
INFO - 2017-02-14 03:10:40 --> URI Class Initialized
INFO - 2017-02-14 03:10:40 --> Router Class Initialized
INFO - 2017-02-14 03:10:40 --> Output Class Initialized
INFO - 2017-02-14 03:10:40 --> Security Class Initialized
DEBUG - 2017-02-14 03:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:10:40 --> Input Class Initialized
INFO - 2017-02-14 03:10:40 --> Language Class Initialized
INFO - 2017-02-14 03:10:40 --> Loader Class Initialized
INFO - 2017-02-14 03:10:40 --> Database Driver Class Initialized
INFO - 2017-02-14 03:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:10:40 --> Controller Class Initialized
INFO - 2017-02-14 03:10:40 --> Helper loaded: url_helper
DEBUG - 2017-02-14 03:10:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:10:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 03:10:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 03:10:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 03:10:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 03:10:40 --> Final output sent to browser
DEBUG - 2017-02-14 03:10:40 --> Total execution time: 0.0143
INFO - 2017-02-14 03:10:41 --> Config Class Initialized
INFO - 2017-02-14 03:10:41 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:10:41 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:10:41 --> Utf8 Class Initialized
INFO - 2017-02-14 03:10:41 --> URI Class Initialized
INFO - 2017-02-14 03:10:41 --> Router Class Initialized
INFO - 2017-02-14 03:10:41 --> Output Class Initialized
INFO - 2017-02-14 03:10:41 --> Security Class Initialized
DEBUG - 2017-02-14 03:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:10:41 --> Input Class Initialized
INFO - 2017-02-14 03:10:41 --> Language Class Initialized
INFO - 2017-02-14 03:10:41 --> Loader Class Initialized
INFO - 2017-02-14 03:10:41 --> Database Driver Class Initialized
INFO - 2017-02-14 03:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:10:41 --> Controller Class Initialized
INFO - 2017-02-14 03:10:41 --> Helper loaded: url_helper
DEBUG - 2017-02-14 03:10:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:10:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 03:10:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 03:10:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 03:10:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 03:10:41 --> Final output sent to browser
DEBUG - 2017-02-14 03:10:41 --> Total execution time: 0.0136
INFO - 2017-02-14 03:10:59 --> Config Class Initialized
INFO - 2017-02-14 03:10:59 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:10:59 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:10:59 --> Utf8 Class Initialized
INFO - 2017-02-14 03:10:59 --> URI Class Initialized
INFO - 2017-02-14 03:10:59 --> Router Class Initialized
INFO - 2017-02-14 03:10:59 --> Output Class Initialized
INFO - 2017-02-14 03:10:59 --> Security Class Initialized
DEBUG - 2017-02-14 03:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:10:59 --> Input Class Initialized
INFO - 2017-02-14 03:10:59 --> Language Class Initialized
INFO - 2017-02-14 03:10:59 --> Loader Class Initialized
INFO - 2017-02-14 03:10:59 --> Database Driver Class Initialized
INFO - 2017-02-14 03:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:10:59 --> Controller Class Initialized
INFO - 2017-02-14 03:10:59 --> Helper loaded: url_helper
DEBUG - 2017-02-14 03:10:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:10:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 03:10:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 03:10:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 03:10:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 03:10:59 --> Final output sent to browser
DEBUG - 2017-02-14 03:10:59 --> Total execution time: 0.0139
INFO - 2017-02-14 03:11:00 --> Config Class Initialized
INFO - 2017-02-14 03:11:00 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:11:00 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:11:00 --> Utf8 Class Initialized
INFO - 2017-02-14 03:11:00 --> URI Class Initialized
INFO - 2017-02-14 03:11:00 --> Router Class Initialized
INFO - 2017-02-14 03:11:00 --> Output Class Initialized
INFO - 2017-02-14 03:11:00 --> Security Class Initialized
DEBUG - 2017-02-14 03:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:11:00 --> Input Class Initialized
INFO - 2017-02-14 03:11:00 --> Language Class Initialized
INFO - 2017-02-14 03:11:00 --> Loader Class Initialized
INFO - 2017-02-14 03:11:00 --> Database Driver Class Initialized
INFO - 2017-02-14 03:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:11:00 --> Controller Class Initialized
INFO - 2017-02-14 03:11:00 --> Helper loaded: url_helper
DEBUG - 2017-02-14 03:11:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:11:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 03:11:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 03:11:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 03:11:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 03:11:00 --> Final output sent to browser
DEBUG - 2017-02-14 03:11:00 --> Total execution time: 0.0129
INFO - 2017-02-14 03:11:51 --> Config Class Initialized
INFO - 2017-02-14 03:11:51 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:11:51 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:11:51 --> Utf8 Class Initialized
INFO - 2017-02-14 03:11:51 --> URI Class Initialized
INFO - 2017-02-14 03:11:51 --> Router Class Initialized
INFO - 2017-02-14 03:11:51 --> Output Class Initialized
INFO - 2017-02-14 03:11:51 --> Security Class Initialized
DEBUG - 2017-02-14 03:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:11:51 --> Input Class Initialized
INFO - 2017-02-14 03:11:51 --> Language Class Initialized
INFO - 2017-02-14 03:11:51 --> Loader Class Initialized
INFO - 2017-02-14 03:11:51 --> Database Driver Class Initialized
INFO - 2017-02-14 03:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:11:51 --> Controller Class Initialized
INFO - 2017-02-14 03:11:51 --> Helper loaded: url_helper
DEBUG - 2017-02-14 03:11:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:11:52 --> Config Class Initialized
INFO - 2017-02-14 03:11:52 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:11:52 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:11:52 --> Utf8 Class Initialized
INFO - 2017-02-14 03:11:52 --> URI Class Initialized
INFO - 2017-02-14 03:11:52 --> Router Class Initialized
INFO - 2017-02-14 03:11:52 --> Output Class Initialized
INFO - 2017-02-14 03:11:52 --> Security Class Initialized
DEBUG - 2017-02-14 03:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:11:52 --> Input Class Initialized
INFO - 2017-02-14 03:11:52 --> Language Class Initialized
INFO - 2017-02-14 03:11:52 --> Loader Class Initialized
INFO - 2017-02-14 03:11:52 --> Database Driver Class Initialized
INFO - 2017-02-14 03:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:11:52 --> Controller Class Initialized
INFO - 2017-02-14 03:11:52 --> Helper loaded: date_helper
DEBUG - 2017-02-14 03:11:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:11:52 --> Helper loaded: url_helper
INFO - 2017-02-14 03:11:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 03:11:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-14 03:11:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-14 03:11:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-14 03:11:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 03:11:52 --> Final output sent to browser
DEBUG - 2017-02-14 03:11:52 --> Total execution time: 0.0140
INFO - 2017-02-14 03:11:52 --> Config Class Initialized
INFO - 2017-02-14 03:11:52 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:11:52 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:11:52 --> Utf8 Class Initialized
INFO - 2017-02-14 03:11:52 --> URI Class Initialized
INFO - 2017-02-14 03:11:52 --> Router Class Initialized
INFO - 2017-02-14 03:11:52 --> Output Class Initialized
INFO - 2017-02-14 03:11:52 --> Security Class Initialized
DEBUG - 2017-02-14 03:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:11:52 --> Input Class Initialized
INFO - 2017-02-14 03:11:52 --> Language Class Initialized
INFO - 2017-02-14 03:11:52 --> Loader Class Initialized
INFO - 2017-02-14 03:11:52 --> Database Driver Class Initialized
INFO - 2017-02-14 03:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:11:52 --> Controller Class Initialized
INFO - 2017-02-14 03:11:52 --> Helper loaded: url_helper
DEBUG - 2017-02-14 03:11:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:11:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 03:11:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 03:11:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 03:11:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 03:11:52 --> Final output sent to browser
DEBUG - 2017-02-14 03:11:52 --> Total execution time: 0.0157
INFO - 2017-02-14 03:11:55 --> Config Class Initialized
INFO - 2017-02-14 03:11:55 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:11:55 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:11:55 --> Utf8 Class Initialized
INFO - 2017-02-14 03:11:55 --> URI Class Initialized
DEBUG - 2017-02-14 03:11:55 --> No URI present. Default controller set.
INFO - 2017-02-14 03:11:55 --> Router Class Initialized
INFO - 2017-02-14 03:11:55 --> Output Class Initialized
INFO - 2017-02-14 03:11:55 --> Security Class Initialized
DEBUG - 2017-02-14 03:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:11:55 --> Input Class Initialized
INFO - 2017-02-14 03:11:55 --> Language Class Initialized
INFO - 2017-02-14 03:11:55 --> Loader Class Initialized
INFO - 2017-02-14 03:11:55 --> Database Driver Class Initialized
INFO - 2017-02-14 03:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:11:55 --> Controller Class Initialized
INFO - 2017-02-14 03:11:55 --> Helper loaded: url_helper
DEBUG - 2017-02-14 03:11:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:11:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 03:11:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 03:11:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 03:11:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 03:11:55 --> Final output sent to browser
DEBUG - 2017-02-14 03:11:55 --> Total execution time: 0.0133
INFO - 2017-02-14 03:11:55 --> Config Class Initialized
INFO - 2017-02-14 03:11:55 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:11:55 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:11:55 --> Utf8 Class Initialized
INFO - 2017-02-14 03:11:55 --> URI Class Initialized
INFO - 2017-02-14 03:11:55 --> Router Class Initialized
INFO - 2017-02-14 03:11:55 --> Output Class Initialized
INFO - 2017-02-14 03:11:55 --> Security Class Initialized
DEBUG - 2017-02-14 03:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:11:55 --> Input Class Initialized
INFO - 2017-02-14 03:11:55 --> Language Class Initialized
INFO - 2017-02-14 03:11:55 --> Loader Class Initialized
INFO - 2017-02-14 03:11:55 --> Database Driver Class Initialized
INFO - 2017-02-14 03:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:11:55 --> Controller Class Initialized
INFO - 2017-02-14 03:11:55 --> Helper loaded: url_helper
DEBUG - 2017-02-14 03:11:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:11:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 03:11:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 03:11:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 03:11:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 03:11:56 --> Final output sent to browser
DEBUG - 2017-02-14 03:11:56 --> Total execution time: 0.0137
INFO - 2017-02-14 03:27:30 --> Config Class Initialized
INFO - 2017-02-14 03:27:30 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:27:30 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:27:30 --> Utf8 Class Initialized
INFO - 2017-02-14 03:27:30 --> URI Class Initialized
INFO - 2017-02-14 03:27:30 --> Router Class Initialized
INFO - 2017-02-14 03:27:30 --> Output Class Initialized
INFO - 2017-02-14 03:27:30 --> Security Class Initialized
DEBUG - 2017-02-14 03:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:27:30 --> Input Class Initialized
INFO - 2017-02-14 03:27:30 --> Language Class Initialized
INFO - 2017-02-14 03:27:30 --> Loader Class Initialized
INFO - 2017-02-14 03:27:31 --> Database Driver Class Initialized
INFO - 2017-02-14 03:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:27:31 --> Controller Class Initialized
INFO - 2017-02-14 03:27:31 --> Helper loaded: date_helper
DEBUG - 2017-02-14 03:27:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:27:31 --> Helper loaded: url_helper
INFO - 2017-02-14 03:27:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 03:27:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-14 03:27:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-14 03:27:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-14 03:27:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 03:27:31 --> Final output sent to browser
DEBUG - 2017-02-14 03:27:31 --> Total execution time: 0.0542
INFO - 2017-02-14 03:27:36 --> Config Class Initialized
INFO - 2017-02-14 03:27:36 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:27:36 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:27:36 --> Utf8 Class Initialized
INFO - 2017-02-14 03:27:36 --> URI Class Initialized
INFO - 2017-02-14 03:27:36 --> Router Class Initialized
INFO - 2017-02-14 03:27:36 --> Output Class Initialized
INFO - 2017-02-14 03:27:36 --> Security Class Initialized
DEBUG - 2017-02-14 03:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:27:36 --> Input Class Initialized
INFO - 2017-02-14 03:27:36 --> Language Class Initialized
INFO - 2017-02-14 03:27:36 --> Loader Class Initialized
INFO - 2017-02-14 03:27:36 --> Database Driver Class Initialized
INFO - 2017-02-14 03:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:27:36 --> Controller Class Initialized
INFO - 2017-02-14 03:27:36 --> Helper loaded: url_helper
DEBUG - 2017-02-14 03:27:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 03:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 03:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 03:27:36 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 03:27:36 --> Final output sent to browser
DEBUG - 2017-02-14 03:27:36 --> Total execution time: 0.0132
INFO - 2017-02-14 03:30:05 --> Config Class Initialized
INFO - 2017-02-14 03:30:05 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:30:05 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:30:05 --> Utf8 Class Initialized
INFO - 2017-02-14 03:30:05 --> URI Class Initialized
DEBUG - 2017-02-14 03:30:05 --> No URI present. Default controller set.
INFO - 2017-02-14 03:30:05 --> Router Class Initialized
INFO - 2017-02-14 03:30:05 --> Output Class Initialized
INFO - 2017-02-14 03:30:05 --> Security Class Initialized
DEBUG - 2017-02-14 03:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:30:05 --> Input Class Initialized
INFO - 2017-02-14 03:30:05 --> Language Class Initialized
INFO - 2017-02-14 03:30:05 --> Loader Class Initialized
INFO - 2017-02-14 03:30:05 --> Database Driver Class Initialized
INFO - 2017-02-14 03:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:30:05 --> Controller Class Initialized
INFO - 2017-02-14 03:30:05 --> Helper loaded: url_helper
DEBUG - 2017-02-14 03:30:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:30:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 03:30:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 03:30:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 03:30:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 03:30:05 --> Final output sent to browser
DEBUG - 2017-02-14 03:30:05 --> Total execution time: 0.0133
INFO - 2017-02-14 03:30:11 --> Config Class Initialized
INFO - 2017-02-14 03:30:11 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:30:11 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:30:11 --> Utf8 Class Initialized
INFO - 2017-02-14 03:30:11 --> URI Class Initialized
INFO - 2017-02-14 03:30:11 --> Router Class Initialized
INFO - 2017-02-14 03:30:11 --> Output Class Initialized
INFO - 2017-02-14 03:30:11 --> Security Class Initialized
DEBUG - 2017-02-14 03:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:30:11 --> Input Class Initialized
INFO - 2017-02-14 03:30:11 --> Language Class Initialized
INFO - 2017-02-14 03:30:11 --> Loader Class Initialized
INFO - 2017-02-14 03:30:11 --> Database Driver Class Initialized
INFO - 2017-02-14 03:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:30:11 --> Controller Class Initialized
INFO - 2017-02-14 03:30:11 --> Helper loaded: url_helper
DEBUG - 2017-02-14 03:30:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:30:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 03:30:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 03:30:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 03:30:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 03:30:11 --> Final output sent to browser
DEBUG - 2017-02-14 03:30:11 --> Total execution time: 0.0134
INFO - 2017-02-14 03:30:24 --> Config Class Initialized
INFO - 2017-02-14 03:30:24 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:30:24 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:30:24 --> Utf8 Class Initialized
INFO - 2017-02-14 03:30:24 --> URI Class Initialized
INFO - 2017-02-14 03:30:24 --> Router Class Initialized
INFO - 2017-02-14 03:30:24 --> Output Class Initialized
INFO - 2017-02-14 03:30:24 --> Security Class Initialized
DEBUG - 2017-02-14 03:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:30:24 --> Input Class Initialized
INFO - 2017-02-14 03:30:24 --> Language Class Initialized
INFO - 2017-02-14 03:30:24 --> Loader Class Initialized
INFO - 2017-02-14 03:30:24 --> Database Driver Class Initialized
INFO - 2017-02-14 03:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:30:24 --> Controller Class Initialized
INFO - 2017-02-14 03:30:24 --> Helper loaded: url_helper
DEBUG - 2017-02-14 03:30:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:30:24 --> Config Class Initialized
INFO - 2017-02-14 03:30:24 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:30:24 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:30:24 --> Utf8 Class Initialized
INFO - 2017-02-14 03:30:24 --> URI Class Initialized
INFO - 2017-02-14 03:30:24 --> Router Class Initialized
INFO - 2017-02-14 03:30:24 --> Output Class Initialized
INFO - 2017-02-14 03:30:24 --> Security Class Initialized
DEBUG - 2017-02-14 03:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:30:24 --> Input Class Initialized
INFO - 2017-02-14 03:30:24 --> Language Class Initialized
INFO - 2017-02-14 03:30:24 --> Loader Class Initialized
INFO - 2017-02-14 03:30:24 --> Database Driver Class Initialized
INFO - 2017-02-14 03:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:30:24 --> Controller Class Initialized
INFO - 2017-02-14 03:30:24 --> Helper loaded: date_helper
DEBUG - 2017-02-14 03:30:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:30:24 --> Helper loaded: url_helper
INFO - 2017-02-14 03:30:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 03:30:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-14 03:30:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-14 03:30:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-14 03:30:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 03:30:24 --> Final output sent to browser
DEBUG - 2017-02-14 03:30:24 --> Total execution time: 0.0140
INFO - 2017-02-14 03:30:25 --> Config Class Initialized
INFO - 2017-02-14 03:30:25 --> Hooks Class Initialized
DEBUG - 2017-02-14 03:30:25 --> UTF-8 Support Enabled
INFO - 2017-02-14 03:30:25 --> Utf8 Class Initialized
INFO - 2017-02-14 03:30:25 --> URI Class Initialized
INFO - 2017-02-14 03:30:25 --> Router Class Initialized
INFO - 2017-02-14 03:30:25 --> Output Class Initialized
INFO - 2017-02-14 03:30:25 --> Security Class Initialized
DEBUG - 2017-02-14 03:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 03:30:25 --> Input Class Initialized
INFO - 2017-02-14 03:30:25 --> Language Class Initialized
INFO - 2017-02-14 03:30:25 --> Loader Class Initialized
INFO - 2017-02-14 03:30:25 --> Database Driver Class Initialized
INFO - 2017-02-14 03:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 03:30:25 --> Controller Class Initialized
INFO - 2017-02-14 03:30:25 --> Helper loaded: url_helper
DEBUG - 2017-02-14 03:30:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 03:30:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 03:30:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 03:30:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 03:30:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 03:30:25 --> Final output sent to browser
DEBUG - 2017-02-14 03:30:25 --> Total execution time: 0.0136
INFO - 2017-02-14 04:04:07 --> Config Class Initialized
INFO - 2017-02-14 04:04:07 --> Hooks Class Initialized
DEBUG - 2017-02-14 04:04:07 --> UTF-8 Support Enabled
INFO - 2017-02-14 04:04:07 --> Utf8 Class Initialized
INFO - 2017-02-14 04:04:07 --> URI Class Initialized
INFO - 2017-02-14 04:04:07 --> Router Class Initialized
INFO - 2017-02-14 04:04:07 --> Output Class Initialized
INFO - 2017-02-14 04:04:07 --> Security Class Initialized
DEBUG - 2017-02-14 04:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 04:04:07 --> Input Class Initialized
INFO - 2017-02-14 04:04:07 --> Language Class Initialized
INFO - 2017-02-14 04:04:07 --> Loader Class Initialized
INFO - 2017-02-14 04:04:07 --> Database Driver Class Initialized
INFO - 2017-02-14 04:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 04:04:07 --> Controller Class Initialized
INFO - 2017-02-14 04:04:07 --> Helper loaded: date_helper
DEBUG - 2017-02-14 04:04:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 04:04:07 --> Helper loaded: url_helper
INFO - 2017-02-14 04:04:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 04:04:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-14 04:04:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-14 04:04:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-14 04:04:07 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 04:04:07 --> Final output sent to browser
DEBUG - 2017-02-14 04:04:07 --> Total execution time: 0.0135
INFO - 2017-02-14 05:05:30 --> Config Class Initialized
INFO - 2017-02-14 05:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-14 05:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-14 05:05:30 --> Utf8 Class Initialized
INFO - 2017-02-14 05:05:30 --> URI Class Initialized
DEBUG - 2017-02-14 05:05:30 --> No URI present. Default controller set.
INFO - 2017-02-14 05:05:30 --> Router Class Initialized
INFO - 2017-02-14 05:05:30 --> Output Class Initialized
INFO - 2017-02-14 05:05:30 --> Security Class Initialized
DEBUG - 2017-02-14 05:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 05:05:30 --> Input Class Initialized
INFO - 2017-02-14 05:05:30 --> Language Class Initialized
INFO - 2017-02-14 05:05:30 --> Loader Class Initialized
INFO - 2017-02-14 05:05:30 --> Database Driver Class Initialized
INFO - 2017-02-14 05:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 05:05:30 --> Controller Class Initialized
INFO - 2017-02-14 05:05:30 --> Helper loaded: url_helper
DEBUG - 2017-02-14 05:05:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 05:05:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 05:05:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 05:05:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 05:05:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 05:05:30 --> Final output sent to browser
DEBUG - 2017-02-14 05:05:30 --> Total execution time: 0.0134
INFO - 2017-02-14 05:05:50 --> Config Class Initialized
INFO - 2017-02-14 05:05:50 --> Hooks Class Initialized
DEBUG - 2017-02-14 05:05:50 --> UTF-8 Support Enabled
INFO - 2017-02-14 05:05:50 --> Utf8 Class Initialized
INFO - 2017-02-14 05:05:50 --> URI Class Initialized
DEBUG - 2017-02-14 05:05:50 --> No URI present. Default controller set.
INFO - 2017-02-14 05:05:50 --> Router Class Initialized
INFO - 2017-02-14 05:05:50 --> Output Class Initialized
INFO - 2017-02-14 05:05:50 --> Security Class Initialized
DEBUG - 2017-02-14 05:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 05:05:50 --> Input Class Initialized
INFO - 2017-02-14 05:05:50 --> Language Class Initialized
INFO - 2017-02-14 05:05:50 --> Loader Class Initialized
INFO - 2017-02-14 05:05:50 --> Database Driver Class Initialized
INFO - 2017-02-14 05:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 05:05:50 --> Controller Class Initialized
INFO - 2017-02-14 05:05:50 --> Helper loaded: url_helper
DEBUG - 2017-02-14 05:05:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 05:05:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 05:05:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 05:05:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 05:05:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 05:05:50 --> Final output sent to browser
DEBUG - 2017-02-14 05:05:50 --> Total execution time: 0.0160
INFO - 2017-02-14 05:24:16 --> Config Class Initialized
INFO - 2017-02-14 05:24:16 --> Hooks Class Initialized
DEBUG - 2017-02-14 05:24:16 --> UTF-8 Support Enabled
INFO - 2017-02-14 05:24:16 --> Utf8 Class Initialized
INFO - 2017-02-14 05:24:16 --> URI Class Initialized
DEBUG - 2017-02-14 05:24:16 --> No URI present. Default controller set.
INFO - 2017-02-14 05:24:16 --> Router Class Initialized
INFO - 2017-02-14 05:24:16 --> Output Class Initialized
INFO - 2017-02-14 05:24:16 --> Security Class Initialized
DEBUG - 2017-02-14 05:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 05:24:16 --> Input Class Initialized
INFO - 2017-02-14 05:24:16 --> Language Class Initialized
INFO - 2017-02-14 05:24:16 --> Loader Class Initialized
INFO - 2017-02-14 05:24:16 --> Database Driver Class Initialized
INFO - 2017-02-14 05:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 05:24:16 --> Controller Class Initialized
INFO - 2017-02-14 05:24:16 --> Helper loaded: url_helper
DEBUG - 2017-02-14 05:24:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 05:24:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 05:24:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 05:24:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 05:24:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 05:24:16 --> Final output sent to browser
DEBUG - 2017-02-14 05:24:16 --> Total execution time: 0.0136
INFO - 2017-02-14 07:47:27 --> Config Class Initialized
INFO - 2017-02-14 07:47:27 --> Hooks Class Initialized
DEBUG - 2017-02-14 07:47:27 --> UTF-8 Support Enabled
INFO - 2017-02-14 07:47:27 --> Utf8 Class Initialized
INFO - 2017-02-14 07:47:27 --> URI Class Initialized
INFO - 2017-02-14 07:47:27 --> Router Class Initialized
INFO - 2017-02-14 07:47:27 --> Output Class Initialized
INFO - 2017-02-14 07:47:27 --> Security Class Initialized
DEBUG - 2017-02-14 07:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 07:47:27 --> Input Class Initialized
INFO - 2017-02-14 07:47:27 --> Language Class Initialized
INFO - 2017-02-14 07:47:27 --> Loader Class Initialized
INFO - 2017-02-14 07:47:27 --> Database Driver Class Initialized
INFO - 2017-02-14 07:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 07:47:27 --> Controller Class Initialized
INFO - 2017-02-14 07:47:27 --> Helper loaded: url_helper
DEBUG - 2017-02-14 07:47:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 07:47:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 07:47:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 07:47:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 07:47:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 07:47:27 --> Final output sent to browser
DEBUG - 2017-02-14 07:47:27 --> Total execution time: 0.0145
INFO - 2017-02-14 15:22:42 --> Config Class Initialized
INFO - 2017-02-14 15:22:42 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:22:42 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:22:42 --> Utf8 Class Initialized
INFO - 2017-02-14 15:22:42 --> URI Class Initialized
DEBUG - 2017-02-14 15:22:42 --> No URI present. Default controller set.
INFO - 2017-02-14 15:22:42 --> Router Class Initialized
INFO - 2017-02-14 15:22:42 --> Output Class Initialized
INFO - 2017-02-14 15:22:42 --> Security Class Initialized
DEBUG - 2017-02-14 15:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:22:42 --> Input Class Initialized
INFO - 2017-02-14 15:22:42 --> Language Class Initialized
INFO - 2017-02-14 15:22:42 --> Loader Class Initialized
INFO - 2017-02-14 15:22:42 --> Database Driver Class Initialized
INFO - 2017-02-14 15:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:22:42 --> Controller Class Initialized
INFO - 2017-02-14 15:22:42 --> Helper loaded: url_helper
DEBUG - 2017-02-14 15:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 15:22:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 15:22:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 15:22:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 15:22:42 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 15:22:42 --> Final output sent to browser
DEBUG - 2017-02-14 15:22:42 --> Total execution time: 0.1050
INFO - 2017-02-14 15:23:17 --> Config Class Initialized
INFO - 2017-02-14 15:23:17 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:23:17 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:23:17 --> Utf8 Class Initialized
INFO - 2017-02-14 15:23:17 --> URI Class Initialized
DEBUG - 2017-02-14 15:23:17 --> No URI present. Default controller set.
INFO - 2017-02-14 15:23:17 --> Router Class Initialized
INFO - 2017-02-14 15:23:17 --> Output Class Initialized
INFO - 2017-02-14 15:23:17 --> Security Class Initialized
DEBUG - 2017-02-14 15:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:23:17 --> Input Class Initialized
INFO - 2017-02-14 15:23:17 --> Language Class Initialized
INFO - 2017-02-14 15:23:17 --> Loader Class Initialized
INFO - 2017-02-14 15:23:17 --> Database Driver Class Initialized
INFO - 2017-02-14 15:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:23:17 --> Controller Class Initialized
INFO - 2017-02-14 15:23:17 --> Helper loaded: url_helper
DEBUG - 2017-02-14 15:23:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 15:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 15:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 15:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 15:23:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 15:23:17 --> Final output sent to browser
DEBUG - 2017-02-14 15:23:17 --> Total execution time: 0.0276
INFO - 2017-02-14 15:23:25 --> Config Class Initialized
INFO - 2017-02-14 15:23:25 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:23:25 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:23:25 --> Utf8 Class Initialized
INFO - 2017-02-14 15:23:25 --> URI Class Initialized
INFO - 2017-02-14 15:23:25 --> Router Class Initialized
INFO - 2017-02-14 15:23:25 --> Output Class Initialized
INFO - 2017-02-14 15:23:25 --> Security Class Initialized
DEBUG - 2017-02-14 15:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:23:25 --> Input Class Initialized
INFO - 2017-02-14 15:23:25 --> Language Class Initialized
INFO - 2017-02-14 15:23:25 --> Loader Class Initialized
INFO - 2017-02-14 15:23:25 --> Database Driver Class Initialized
INFO - 2017-02-14 15:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:23:25 --> Controller Class Initialized
INFO - 2017-02-14 15:23:25 --> Helper loaded: url_helper
DEBUG - 2017-02-14 15:23:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 15:23:27 --> Config Class Initialized
INFO - 2017-02-14 15:23:27 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:23:27 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:23:27 --> Utf8 Class Initialized
INFO - 2017-02-14 15:23:27 --> URI Class Initialized
INFO - 2017-02-14 15:23:27 --> Router Class Initialized
INFO - 2017-02-14 15:23:27 --> Output Class Initialized
INFO - 2017-02-14 15:23:27 --> Security Class Initialized
DEBUG - 2017-02-14 15:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:23:27 --> Input Class Initialized
INFO - 2017-02-14 15:23:27 --> Language Class Initialized
INFO - 2017-02-14 15:23:27 --> Loader Class Initialized
INFO - 2017-02-14 15:23:27 --> Database Driver Class Initialized
INFO - 2017-02-14 15:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:23:27 --> Controller Class Initialized
INFO - 2017-02-14 15:23:27 --> Helper loaded: date_helper
DEBUG - 2017-02-14 15:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 15:23:27 --> Helper loaded: url_helper
INFO - 2017-02-14 15:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 15:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-14 15:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-14 15:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-14 15:23:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 15:23:27 --> Final output sent to browser
DEBUG - 2017-02-14 15:23:27 --> Total execution time: 0.2479
INFO - 2017-02-14 15:23:35 --> Config Class Initialized
INFO - 2017-02-14 15:23:35 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:23:35 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:23:35 --> Utf8 Class Initialized
INFO - 2017-02-14 15:23:35 --> URI Class Initialized
INFO - 2017-02-14 15:23:35 --> Router Class Initialized
INFO - 2017-02-14 15:23:35 --> Output Class Initialized
INFO - 2017-02-14 15:23:35 --> Security Class Initialized
DEBUG - 2017-02-14 15:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:23:35 --> Input Class Initialized
INFO - 2017-02-14 15:23:35 --> Language Class Initialized
INFO - 2017-02-14 15:23:35 --> Loader Class Initialized
INFO - 2017-02-14 15:23:35 --> Database Driver Class Initialized
INFO - 2017-02-14 15:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:23:35 --> Controller Class Initialized
INFO - 2017-02-14 15:23:35 --> Helper loaded: date_helper
DEBUG - 2017-02-14 15:23:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 15:23:35 --> Helper loaded: url_helper
INFO - 2017-02-14 15:23:35 --> Helper loaded: download_helper
INFO - 2017-02-14 15:23:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 15:23:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-14 15:23:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-14 15:23:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-14 15:23:35 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 15:23:35 --> Final output sent to browser
DEBUG - 2017-02-14 15:23:35 --> Total execution time: 0.1054
INFO - 2017-02-14 15:23:45 --> Config Class Initialized
INFO - 2017-02-14 15:23:45 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:23:45 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:23:45 --> Utf8 Class Initialized
INFO - 2017-02-14 15:23:45 --> URI Class Initialized
INFO - 2017-02-14 15:23:45 --> Router Class Initialized
INFO - 2017-02-14 15:23:45 --> Output Class Initialized
INFO - 2017-02-14 15:23:45 --> Security Class Initialized
DEBUG - 2017-02-14 15:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:23:45 --> Input Class Initialized
INFO - 2017-02-14 15:23:45 --> Language Class Initialized
INFO - 2017-02-14 15:23:45 --> Loader Class Initialized
INFO - 2017-02-14 15:23:45 --> Database Driver Class Initialized
INFO - 2017-02-14 15:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:23:45 --> Controller Class Initialized
INFO - 2017-02-14 15:23:45 --> Helper loaded: url_helper
DEBUG - 2017-02-14 15:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 15:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 15:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 15:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 15:23:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 15:23:45 --> Final output sent to browser
DEBUG - 2017-02-14 15:23:45 --> Total execution time: 0.0135
INFO - 2017-02-14 15:23:50 --> Config Class Initialized
INFO - 2017-02-14 15:23:50 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:23:50 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:23:50 --> Utf8 Class Initialized
INFO - 2017-02-14 15:23:50 --> URI Class Initialized
INFO - 2017-02-14 15:23:50 --> Router Class Initialized
INFO - 2017-02-14 15:23:50 --> Output Class Initialized
INFO - 2017-02-14 15:23:50 --> Security Class Initialized
DEBUG - 2017-02-14 15:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:23:50 --> Input Class Initialized
INFO - 2017-02-14 15:23:50 --> Language Class Initialized
INFO - 2017-02-14 15:23:50 --> Loader Class Initialized
INFO - 2017-02-14 15:23:50 --> Database Driver Class Initialized
INFO - 2017-02-14 15:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:23:50 --> Controller Class Initialized
INFO - 2017-02-14 15:23:50 --> Upload Class Initialized
INFO - 2017-02-14 15:23:50 --> Helper loaded: date_helper
DEBUG - 2017-02-14 15:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 15:23:50 --> Helper loaded: url_helper
INFO - 2017-02-14 15:23:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 15:23:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-14 15:23:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/saldo.php
INFO - 2017-02-14 15:23:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/saldo.php
INFO - 2017-02-14 15:23:50 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/css_file_input.php
INFO - 2017-02-14 15:23:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 15:23:50 --> Final output sent to browser
DEBUG - 2017-02-14 15:23:50 --> Total execution time: 0.1888
INFO - 2017-02-14 15:23:51 --> Config Class Initialized
INFO - 2017-02-14 15:23:51 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:23:51 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:23:51 --> Utf8 Class Initialized
INFO - 2017-02-14 15:23:51 --> URI Class Initialized
INFO - 2017-02-14 15:23:51 --> Router Class Initialized
INFO - 2017-02-14 15:23:51 --> Output Class Initialized
INFO - 2017-02-14 15:23:51 --> Security Class Initialized
DEBUG - 2017-02-14 15:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:23:51 --> Input Class Initialized
INFO - 2017-02-14 15:23:51 --> Language Class Initialized
INFO - 2017-02-14 15:23:51 --> Loader Class Initialized
INFO - 2017-02-14 15:23:51 --> Database Driver Class Initialized
INFO - 2017-02-14 15:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:23:51 --> Controller Class Initialized
INFO - 2017-02-14 15:23:51 --> Helper loaded: url_helper
DEBUG - 2017-02-14 15:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 15:23:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 15:23:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 15:23:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 15:23:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 15:23:51 --> Final output sent to browser
DEBUG - 2017-02-14 15:23:51 --> Total execution time: 0.0139
INFO - 2017-02-14 15:24:01 --> Config Class Initialized
INFO - 2017-02-14 15:24:01 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:24:01 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:24:01 --> Utf8 Class Initialized
INFO - 2017-02-14 15:24:01 --> URI Class Initialized
INFO - 2017-02-14 15:24:01 --> Router Class Initialized
INFO - 2017-02-14 15:24:01 --> Output Class Initialized
INFO - 2017-02-14 15:24:01 --> Security Class Initialized
DEBUG - 2017-02-14 15:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:24:01 --> Input Class Initialized
INFO - 2017-02-14 15:24:01 --> Language Class Initialized
INFO - 2017-02-14 15:24:01 --> Loader Class Initialized
INFO - 2017-02-14 15:24:01 --> Database Driver Class Initialized
INFO - 2017-02-14 15:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:24:01 --> Controller Class Initialized
INFO - 2017-02-14 15:24:01 --> Helper loaded: date_helper
DEBUG - 2017-02-14 15:24:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 15:24:01 --> Helper loaded: url_helper
INFO - 2017-02-14 15:24:01 --> Helper loaded: download_helper
INFO - 2017-02-14 15:24:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 15:24:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-14 15:24:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/migraduacion.php
INFO - 2017-02-14 15:24:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/mi_graduacion.php
INFO - 2017-02-14 15:24:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 15:24:01 --> Final output sent to browser
DEBUG - 2017-02-14 15:24:01 --> Total execution time: 0.0262
INFO - 2017-02-14 15:24:02 --> Config Class Initialized
INFO - 2017-02-14 15:24:02 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:24:02 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:24:02 --> Utf8 Class Initialized
INFO - 2017-02-14 15:24:02 --> URI Class Initialized
INFO - 2017-02-14 15:24:02 --> Router Class Initialized
INFO - 2017-02-14 15:24:02 --> Output Class Initialized
INFO - 2017-02-14 15:24:02 --> Security Class Initialized
DEBUG - 2017-02-14 15:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:24:02 --> Input Class Initialized
INFO - 2017-02-14 15:24:02 --> Language Class Initialized
INFO - 2017-02-14 15:24:02 --> Loader Class Initialized
INFO - 2017-02-14 15:24:02 --> Database Driver Class Initialized
INFO - 2017-02-14 15:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:24:02 --> Controller Class Initialized
INFO - 2017-02-14 15:24:02 --> Helper loaded: url_helper
DEBUG - 2017-02-14 15:24:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 15:24:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 15:24:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 15:24:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 15:24:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 15:24:02 --> Final output sent to browser
DEBUG - 2017-02-14 15:24:02 --> Total execution time: 0.0132
INFO - 2017-02-14 15:24:03 --> Config Class Initialized
INFO - 2017-02-14 15:24:03 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:24:03 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:24:03 --> Utf8 Class Initialized
INFO - 2017-02-14 15:24:03 --> URI Class Initialized
INFO - 2017-02-14 15:24:03 --> Router Class Initialized
INFO - 2017-02-14 15:24:03 --> Output Class Initialized
INFO - 2017-02-14 15:24:03 --> Security Class Initialized
DEBUG - 2017-02-14 15:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:24:03 --> Input Class Initialized
INFO - 2017-02-14 15:24:03 --> Language Class Initialized
INFO - 2017-02-14 15:24:03 --> Loader Class Initialized
INFO - 2017-02-14 15:24:03 --> Database Driver Class Initialized
INFO - 2017-02-14 15:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:24:03 --> Controller Class Initialized
INFO - 2017-02-14 15:24:03 --> Helper loaded: date_helper
DEBUG - 2017-02-14 15:24:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 15:24:03 --> Helper loaded: url_helper
INFO - 2017-02-14 15:24:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 15:24:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/style/carrito_de_compra.php
INFO - 2017-02-14 15:24:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-14 15:24:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/carritodecompra.php
INFO - 2017-02-14 15:24:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/carrito_de_compra.php
INFO - 2017-02-14 15:24:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 15:24:03 --> Final output sent to browser
DEBUG - 2017-02-14 15:24:03 --> Total execution time: 0.0291
INFO - 2017-02-14 15:24:04 --> Config Class Initialized
INFO - 2017-02-14 15:24:04 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:24:04 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:24:04 --> Utf8 Class Initialized
INFO - 2017-02-14 15:24:04 --> URI Class Initialized
INFO - 2017-02-14 15:24:04 --> Router Class Initialized
INFO - 2017-02-14 15:24:04 --> Output Class Initialized
INFO - 2017-02-14 15:24:04 --> Security Class Initialized
DEBUG - 2017-02-14 15:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:24:04 --> Input Class Initialized
INFO - 2017-02-14 15:24:04 --> Language Class Initialized
INFO - 2017-02-14 15:24:04 --> Loader Class Initialized
INFO - 2017-02-14 15:24:04 --> Database Driver Class Initialized
INFO - 2017-02-14 15:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:24:04 --> Controller Class Initialized
INFO - 2017-02-14 15:24:04 --> Helper loaded: url_helper
DEBUG - 2017-02-14 15:24:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 15:24:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 15:24:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 15:24:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 15:24:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 15:24:04 --> Final output sent to browser
DEBUG - 2017-02-14 15:24:04 --> Total execution time: 0.0134
INFO - 2017-02-14 15:24:08 --> Config Class Initialized
INFO - 2017-02-14 15:24:08 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:24:08 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:24:08 --> Utf8 Class Initialized
INFO - 2017-02-14 15:24:08 --> URI Class Initialized
INFO - 2017-02-14 15:24:08 --> Router Class Initialized
INFO - 2017-02-14 15:24:08 --> Output Class Initialized
INFO - 2017-02-14 15:24:08 --> Security Class Initialized
DEBUG - 2017-02-14 15:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:24:08 --> Input Class Initialized
INFO - 2017-02-14 15:24:08 --> Language Class Initialized
INFO - 2017-02-14 15:24:08 --> Loader Class Initialized
INFO - 2017-02-14 15:24:08 --> Database Driver Class Initialized
INFO - 2017-02-14 15:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:24:08 --> Controller Class Initialized
INFO - 2017-02-14 15:24:08 --> Helper loaded: date_helper
DEBUG - 2017-02-14 15:24:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 15:24:08 --> Helper loaded: url_helper
INFO - 2017-02-14 15:24:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 15:24:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/navigation.php
INFO - 2017-02-14 15:24:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/paquetespersonales.php
INFO - 2017-02-14 15:24:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-14 15:24:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 15:24:08 --> Final output sent to browser
DEBUG - 2017-02-14 15:24:08 --> Total execution time: 0.0142
INFO - 2017-02-14 15:24:10 --> Config Class Initialized
INFO - 2017-02-14 15:24:10 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:24:10 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:24:10 --> Utf8 Class Initialized
INFO - 2017-02-14 15:24:10 --> URI Class Initialized
INFO - 2017-02-14 15:24:10 --> Router Class Initialized
INFO - 2017-02-14 15:24:10 --> Output Class Initialized
INFO - 2017-02-14 15:24:10 --> Security Class Initialized
DEBUG - 2017-02-14 15:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:24:10 --> Input Class Initialized
INFO - 2017-02-14 15:24:10 --> Language Class Initialized
INFO - 2017-02-14 15:24:10 --> Loader Class Initialized
INFO - 2017-02-14 15:24:10 --> Database Driver Class Initialized
INFO - 2017-02-14 15:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:24:10 --> Controller Class Initialized
INFO - 2017-02-14 15:24:10 --> Helper loaded: url_helper
DEBUG - 2017-02-14 15:24:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 15:24:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 15:24:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 15:24:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 15:24:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 15:24:10 --> Final output sent to browser
DEBUG - 2017-02-14 15:24:10 --> Total execution time: 0.0134
INFO - 2017-02-14 15:52:25 --> Config Class Initialized
INFO - 2017-02-14 15:52:25 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:52:25 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:52:25 --> Utf8 Class Initialized
INFO - 2017-02-14 15:52:25 --> URI Class Initialized
DEBUG - 2017-02-14 15:52:25 --> No URI present. Default controller set.
INFO - 2017-02-14 15:52:25 --> Router Class Initialized
INFO - 2017-02-14 15:52:25 --> Output Class Initialized
INFO - 2017-02-14 15:52:25 --> Security Class Initialized
DEBUG - 2017-02-14 15:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:52:25 --> Input Class Initialized
INFO - 2017-02-14 15:52:25 --> Language Class Initialized
INFO - 2017-02-14 15:52:25 --> Loader Class Initialized
INFO - 2017-02-14 15:52:25 --> Database Driver Class Initialized
INFO - 2017-02-14 15:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:52:25 --> Controller Class Initialized
INFO - 2017-02-14 15:52:25 --> Helper loaded: url_helper
DEBUG - 2017-02-14 15:52:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 15:52:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 15:52:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 15:52:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 15:52:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 15:52:25 --> Final output sent to browser
DEBUG - 2017-02-14 15:52:25 --> Total execution time: 0.0134
INFO - 2017-02-14 16:10:34 --> Config Class Initialized
INFO - 2017-02-14 16:10:34 --> Hooks Class Initialized
DEBUG - 2017-02-14 16:10:34 --> UTF-8 Support Enabled
INFO - 2017-02-14 16:10:34 --> Utf8 Class Initialized
INFO - 2017-02-14 16:10:34 --> URI Class Initialized
DEBUG - 2017-02-14 16:10:34 --> No URI present. Default controller set.
INFO - 2017-02-14 16:10:34 --> Router Class Initialized
INFO - 2017-02-14 16:10:34 --> Output Class Initialized
INFO - 2017-02-14 16:10:34 --> Security Class Initialized
DEBUG - 2017-02-14 16:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 16:10:34 --> Input Class Initialized
INFO - 2017-02-14 16:10:34 --> Language Class Initialized
INFO - 2017-02-14 16:10:34 --> Loader Class Initialized
INFO - 2017-02-14 16:10:34 --> Database Driver Class Initialized
INFO - 2017-02-14 16:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 16:10:34 --> Controller Class Initialized
INFO - 2017-02-14 16:10:34 --> Helper loaded: url_helper
DEBUG - 2017-02-14 16:10:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 16:10:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 16:10:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 16:10:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 16:10:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 16:10:34 --> Final output sent to browser
DEBUG - 2017-02-14 16:10:34 --> Total execution time: 0.0137
INFO - 2017-02-14 16:10:38 --> Config Class Initialized
INFO - 2017-02-14 16:10:38 --> Hooks Class Initialized
DEBUG - 2017-02-14 16:10:38 --> UTF-8 Support Enabled
INFO - 2017-02-14 16:10:38 --> Utf8 Class Initialized
INFO - 2017-02-14 16:10:38 --> URI Class Initialized
INFO - 2017-02-14 16:10:38 --> Router Class Initialized
INFO - 2017-02-14 16:10:38 --> Output Class Initialized
INFO - 2017-02-14 16:10:38 --> Security Class Initialized
DEBUG - 2017-02-14 16:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 16:10:38 --> Input Class Initialized
INFO - 2017-02-14 16:10:38 --> Language Class Initialized
INFO - 2017-02-14 16:10:38 --> Loader Class Initialized
INFO - 2017-02-14 16:10:38 --> Database Driver Class Initialized
INFO - 2017-02-14 16:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 16:10:38 --> Controller Class Initialized
INFO - 2017-02-14 16:10:38 --> Helper loaded: url_helper
DEBUG - 2017-02-14 16:10:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 16:10:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 16:10:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 16:10:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 16:10:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 16:10:38 --> Final output sent to browser
DEBUG - 2017-02-14 16:10:38 --> Total execution time: 0.0142
INFO - 2017-02-14 16:10:50 --> Config Class Initialized
INFO - 2017-02-14 16:10:50 --> Hooks Class Initialized
DEBUG - 2017-02-14 16:10:50 --> UTF-8 Support Enabled
INFO - 2017-02-14 16:10:50 --> Utf8 Class Initialized
INFO - 2017-02-14 16:10:50 --> URI Class Initialized
INFO - 2017-02-14 16:10:50 --> Router Class Initialized
INFO - 2017-02-14 16:10:50 --> Output Class Initialized
INFO - 2017-02-14 16:10:50 --> Security Class Initialized
DEBUG - 2017-02-14 16:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 16:10:50 --> Input Class Initialized
INFO - 2017-02-14 16:10:50 --> Language Class Initialized
INFO - 2017-02-14 16:10:50 --> Loader Class Initialized
INFO - 2017-02-14 16:10:50 --> Database Driver Class Initialized
INFO - 2017-02-14 16:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 16:10:50 --> Controller Class Initialized
INFO - 2017-02-14 16:10:50 --> Helper loaded: url_helper
DEBUG - 2017-02-14 16:10:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 16:10:50 --> Config Class Initialized
INFO - 2017-02-14 16:10:50 --> Hooks Class Initialized
DEBUG - 2017-02-14 16:10:50 --> UTF-8 Support Enabled
INFO - 2017-02-14 16:10:50 --> Utf8 Class Initialized
INFO - 2017-02-14 16:10:50 --> URI Class Initialized
INFO - 2017-02-14 16:10:50 --> Router Class Initialized
INFO - 2017-02-14 16:10:50 --> Output Class Initialized
INFO - 2017-02-14 16:10:50 --> Security Class Initialized
DEBUG - 2017-02-14 16:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 16:10:50 --> Input Class Initialized
INFO - 2017-02-14 16:10:50 --> Language Class Initialized
INFO - 2017-02-14 16:10:50 --> Loader Class Initialized
INFO - 2017-02-14 16:10:50 --> Database Driver Class Initialized
INFO - 2017-02-14 16:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 16:10:50 --> Controller Class Initialized
INFO - 2017-02-14 16:10:50 --> Helper loaded: date_helper
DEBUG - 2017-02-14 16:10:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 16:10:50 --> Helper loaded: url_helper
INFO - 2017-02-14 16:10:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 16:10:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-02-14 16:10:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-02-14 16:10:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-02-14 16:10:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 16:10:50 --> Final output sent to browser
DEBUG - 2017-02-14 16:10:50 --> Total execution time: 0.0136
INFO - 2017-02-14 16:10:52 --> Config Class Initialized
INFO - 2017-02-14 16:10:52 --> Hooks Class Initialized
DEBUG - 2017-02-14 16:10:52 --> UTF-8 Support Enabled
INFO - 2017-02-14 16:10:52 --> Utf8 Class Initialized
INFO - 2017-02-14 16:10:52 --> URI Class Initialized
INFO - 2017-02-14 16:10:52 --> Router Class Initialized
INFO - 2017-02-14 16:10:52 --> Output Class Initialized
INFO - 2017-02-14 16:10:52 --> Security Class Initialized
DEBUG - 2017-02-14 16:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 16:10:52 --> Input Class Initialized
INFO - 2017-02-14 16:10:52 --> Language Class Initialized
INFO - 2017-02-14 16:10:52 --> Loader Class Initialized
INFO - 2017-02-14 16:10:52 --> Database Driver Class Initialized
INFO - 2017-02-14 16:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 16:10:52 --> Controller Class Initialized
INFO - 2017-02-14 16:10:52 --> Helper loaded: url_helper
DEBUG - 2017-02-14 16:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 16:10:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 16:10:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 16:10:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 16:10:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 16:10:52 --> Final output sent to browser
DEBUG - 2017-02-14 16:10:52 --> Total execution time: 0.0138
INFO - 2017-02-14 18:45:40 --> Config Class Initialized
INFO - 2017-02-14 18:45:40 --> Hooks Class Initialized
DEBUG - 2017-02-14 18:45:40 --> UTF-8 Support Enabled
INFO - 2017-02-14 18:45:40 --> Utf8 Class Initialized
INFO - 2017-02-14 18:45:40 --> URI Class Initialized
DEBUG - 2017-02-14 18:45:40 --> No URI present. Default controller set.
INFO - 2017-02-14 18:45:40 --> Router Class Initialized
INFO - 2017-02-14 18:45:40 --> Output Class Initialized
INFO - 2017-02-14 18:45:40 --> Security Class Initialized
DEBUG - 2017-02-14 18:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 18:45:40 --> Input Class Initialized
INFO - 2017-02-14 18:45:40 --> Language Class Initialized
INFO - 2017-02-14 18:45:40 --> Loader Class Initialized
INFO - 2017-02-14 18:45:40 --> Database Driver Class Initialized
INFO - 2017-02-14 18:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 18:45:40 --> Controller Class Initialized
INFO - 2017-02-14 18:45:40 --> Helper loaded: url_helper
DEBUG - 2017-02-14 18:45:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 18:45:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 18:45:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 18:45:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 18:45:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 18:45:40 --> Final output sent to browser
DEBUG - 2017-02-14 18:45:40 --> Total execution time: 0.0139
INFO - 2017-02-14 18:47:22 --> Config Class Initialized
INFO - 2017-02-14 18:47:22 --> Hooks Class Initialized
DEBUG - 2017-02-14 18:47:22 --> UTF-8 Support Enabled
INFO - 2017-02-14 18:47:22 --> Utf8 Class Initialized
INFO - 2017-02-14 18:47:22 --> URI Class Initialized
INFO - 2017-02-14 18:47:22 --> Router Class Initialized
INFO - 2017-02-14 18:47:22 --> Output Class Initialized
INFO - 2017-02-14 18:47:22 --> Security Class Initialized
DEBUG - 2017-02-14 18:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 18:47:22 --> Input Class Initialized
INFO - 2017-02-14 18:47:22 --> Language Class Initialized
INFO - 2017-02-14 18:47:22 --> Loader Class Initialized
INFO - 2017-02-14 18:47:22 --> Database Driver Class Initialized
INFO - 2017-02-14 18:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 18:47:22 --> Controller Class Initialized
INFO - 2017-02-14 18:47:22 --> Helper loaded: url_helper
DEBUG - 2017-02-14 18:47:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-02-14 18:47:23 --> Severity: Notice --> Undefined index: email /home/graduafe/public_html/application/controllers/User_pagina_inicial_controller.php 83
ERROR - 2017-02-14 18:47:23 --> Query error: Column 'correo' cannot be null - Invalid query: INSERT INTO `tbl_persona` (`correo`, `nombre`) VALUES (NULL, 'Laura Espino')
INFO - 2017-02-14 18:47:23 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-02-14 18:47:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/graduafe/public_html/system/core/Exceptions.php:272) /home/graduafe/public_html/system/core/Common.php 568
INFO - 2017-02-14 18:47:53 --> Config Class Initialized
INFO - 2017-02-14 18:47:53 --> Hooks Class Initialized
DEBUG - 2017-02-14 18:47:53 --> UTF-8 Support Enabled
INFO - 2017-02-14 18:47:53 --> Utf8 Class Initialized
INFO - 2017-02-14 18:47:53 --> URI Class Initialized
INFO - 2017-02-14 18:47:53 --> Router Class Initialized
INFO - 2017-02-14 18:47:53 --> Output Class Initialized
INFO - 2017-02-14 18:47:53 --> Security Class Initialized
DEBUG - 2017-02-14 18:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 18:47:53 --> Input Class Initialized
INFO - 2017-02-14 18:47:53 --> Language Class Initialized
INFO - 2017-02-14 18:47:53 --> Loader Class Initialized
INFO - 2017-02-14 18:47:53 --> Database Driver Class Initialized
INFO - 2017-02-14 18:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 18:47:53 --> Controller Class Initialized
INFO - 2017-02-14 18:47:53 --> Helper loaded: url_helper
DEBUG - 2017-02-14 18:47:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 18:47:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-14 18:47:53 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-14 18:47:53 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-14 18:47:53 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-14 18:47:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 18:47:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 18:47:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 18:47:53 --> Final output sent to browser
DEBUG - 2017-02-14 18:47:53 --> Total execution time: 0.0456
INFO - 2017-02-14 18:47:56 --> Config Class Initialized
INFO - 2017-02-14 18:47:56 --> Hooks Class Initialized
DEBUG - 2017-02-14 18:47:56 --> UTF-8 Support Enabled
INFO - 2017-02-14 18:47:56 --> Utf8 Class Initialized
INFO - 2017-02-14 18:47:56 --> URI Class Initialized
INFO - 2017-02-14 18:47:56 --> Router Class Initialized
INFO - 2017-02-14 18:47:56 --> Output Class Initialized
INFO - 2017-02-14 18:47:56 --> Security Class Initialized
DEBUG - 2017-02-14 18:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 18:47:56 --> Input Class Initialized
INFO - 2017-02-14 18:47:56 --> Language Class Initialized
INFO - 2017-02-14 18:47:56 --> Loader Class Initialized
INFO - 2017-02-14 18:47:56 --> Database Driver Class Initialized
INFO - 2017-02-14 18:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 18:47:56 --> Controller Class Initialized
INFO - 2017-02-14 18:47:56 --> Helper loaded: url_helper
DEBUG - 2017-02-14 18:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 18:47:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-14 18:47:56 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-14 18:47:56 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-14 18:47:56 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-14 18:47:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 18:47:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 18:47:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 18:47:56 --> Final output sent to browser
DEBUG - 2017-02-14 18:47:56 --> Total execution time: 0.0152
INFO - 2017-02-14 18:49:04 --> Config Class Initialized
INFO - 2017-02-14 18:49:04 --> Hooks Class Initialized
DEBUG - 2017-02-14 18:49:04 --> UTF-8 Support Enabled
INFO - 2017-02-14 18:49:04 --> Utf8 Class Initialized
INFO - 2017-02-14 18:49:04 --> URI Class Initialized
INFO - 2017-02-14 18:49:04 --> Router Class Initialized
INFO - 2017-02-14 18:49:04 --> Output Class Initialized
INFO - 2017-02-14 18:49:04 --> Security Class Initialized
DEBUG - 2017-02-14 18:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 18:49:04 --> Input Class Initialized
INFO - 2017-02-14 18:49:04 --> Language Class Initialized
INFO - 2017-02-14 18:49:04 --> Loader Class Initialized
INFO - 2017-02-14 18:49:04 --> Database Driver Class Initialized
INFO - 2017-02-14 18:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 18:49:04 --> Controller Class Initialized
INFO - 2017-02-14 18:49:04 --> Helper loaded: url_helper
DEBUG - 2017-02-14 18:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 18:49:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-14 18:49:04 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-14 18:49:04 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-14 18:49:04 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-14 18:49:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 18:49:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 18:49:04 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 18:49:04 --> Final output sent to browser
DEBUG - 2017-02-14 18:49:04 --> Total execution time: 0.0155
INFO - 2017-02-14 19:09:15 --> Config Class Initialized
INFO - 2017-02-14 19:09:15 --> Hooks Class Initialized
DEBUG - 2017-02-14 19:09:15 --> UTF-8 Support Enabled
INFO - 2017-02-14 19:09:15 --> Utf8 Class Initialized
INFO - 2017-02-14 19:09:15 --> URI Class Initialized
INFO - 2017-02-14 19:09:15 --> Router Class Initialized
INFO - 2017-02-14 19:09:15 --> Output Class Initialized
INFO - 2017-02-14 19:09:15 --> Security Class Initialized
DEBUG - 2017-02-14 19:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 19:09:15 --> Input Class Initialized
INFO - 2017-02-14 19:09:15 --> Language Class Initialized
INFO - 2017-02-14 19:09:15 --> Loader Class Initialized
INFO - 2017-02-14 19:09:15 --> Database Driver Class Initialized
INFO - 2017-02-14 19:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 19:09:15 --> Controller Class Initialized
INFO - 2017-02-14 19:09:15 --> Helper loaded: url_helper
DEBUG - 2017-02-14 19:09:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 19:09:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
ERROR - 2017-02-14 19:09:15 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 115
ERROR - 2017-02-14 19:09:15 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 142
ERROR - 2017-02-14 19:09:15 --> Severity: Notice --> Undefined variable: error_registrar /home/graduafe/public_html/application/views/usuario/pages/principal.php 150
INFO - 2017-02-14 19:09:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 19:09:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 19:09:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 19:09:15 --> Final output sent to browser
DEBUG - 2017-02-14 19:09:15 --> Total execution time: 0.0142
INFO - 2017-02-14 21:05:47 --> Config Class Initialized
INFO - 2017-02-14 21:05:47 --> Hooks Class Initialized
DEBUG - 2017-02-14 21:05:47 --> UTF-8 Support Enabled
INFO - 2017-02-14 21:05:47 --> Utf8 Class Initialized
INFO - 2017-02-14 21:05:47 --> URI Class Initialized
DEBUG - 2017-02-14 21:05:47 --> No URI present. Default controller set.
INFO - 2017-02-14 21:05:47 --> Router Class Initialized
INFO - 2017-02-14 21:05:47 --> Config Class Initialized
INFO - 2017-02-14 21:05:47 --> Hooks Class Initialized
INFO - 2017-02-14 21:05:47 --> Output Class Initialized
INFO - 2017-02-14 21:05:47 --> Security Class Initialized
DEBUG - 2017-02-14 21:05:47 --> UTF-8 Support Enabled
INFO - 2017-02-14 21:05:47 --> Utf8 Class Initialized
INFO - 2017-02-14 21:05:47 --> URI Class Initialized
DEBUG - 2017-02-14 21:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 21:05:47 --> Input Class Initialized
INFO - 2017-02-14 21:05:47 --> Language Class Initialized
INFO - 2017-02-14 21:05:47 --> Router Class Initialized
INFO - 2017-02-14 21:05:47 --> Output Class Initialized
INFO - 2017-02-14 21:05:47 --> Security Class Initialized
INFO - 2017-02-14 21:05:47 --> Loader Class Initialized
DEBUG - 2017-02-14 21:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 21:05:47 --> Input Class Initialized
INFO - 2017-02-14 21:05:47 --> Language Class Initialized
INFO - 2017-02-14 21:05:47 --> Database Driver Class Initialized
INFO - 2017-02-14 21:05:47 --> Loader Class Initialized
INFO - 2017-02-14 21:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 21:05:47 --> Controller Class Initialized
INFO - 2017-02-14 21:05:47 --> Helper loaded: url_helper
DEBUG - 2017-02-14 21:05:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 21:05:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 21:05:47 --> Database Driver Class Initialized
INFO - 2017-02-14 21:05:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 21:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 21:05:48 --> Controller Class Initialized
INFO - 2017-02-14 21:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 21:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 21:05:48 --> Helper loaded: url_helper
DEBUG - 2017-02-14 21:05:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 21:05:48 --> Final output sent to browser
INFO - 2017-02-14 21:05:48 --> Helper loaded: form_helper
DEBUG - 2017-02-14 21:05:48 --> Total execution time: 0.1435
INFO - 2017-02-14 21:05:48 --> Form Validation Class Initialized
INFO - 2017-02-14 21:05:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-02-14 21:05:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-02-14 21:05:48 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-02-14 21:05:48 --> Final output sent to browser
DEBUG - 2017-02-14 21:05:48 --> Total execution time: 0.3026
INFO - 2017-02-14 21:05:48 --> Config Class Initialized
INFO - 2017-02-14 21:05:48 --> Hooks Class Initialized
DEBUG - 2017-02-14 21:05:48 --> UTF-8 Support Enabled
INFO - 2017-02-14 21:05:48 --> Utf8 Class Initialized
INFO - 2017-02-14 21:05:48 --> URI Class Initialized
INFO - 2017-02-14 21:05:48 --> Router Class Initialized
INFO - 2017-02-14 21:05:48 --> Output Class Initialized
INFO - 2017-02-14 21:05:48 --> Security Class Initialized
DEBUG - 2017-02-14 21:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 21:05:48 --> Input Class Initialized
INFO - 2017-02-14 21:05:48 --> Language Class Initialized
INFO - 2017-02-14 21:05:48 --> Loader Class Initialized
INFO - 2017-02-14 21:05:48 --> Database Driver Class Initialized
INFO - 2017-02-14 21:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 21:05:48 --> Controller Class Initialized
INFO - 2017-02-14 21:05:48 --> Helper loaded: url_helper
DEBUG - 2017-02-14 21:05:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-02-14 21:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-02-14 21:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-02-14 21:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-02-14 21:05:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-02-14 21:05:48 --> Final output sent to browser
DEBUG - 2017-02-14 21:05:48 --> Total execution time: 0.0138

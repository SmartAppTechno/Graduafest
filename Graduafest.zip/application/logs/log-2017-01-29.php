<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-01-29 00:07:25 --> Config Class Initialized
INFO - 2017-01-29 00:07:25 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:07:25 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:07:25 --> Utf8 Class Initialized
INFO - 2017-01-29 00:07:25 --> URI Class Initialized
DEBUG - 2017-01-29 00:07:25 --> No URI present. Default controller set.
INFO - 2017-01-29 00:07:25 --> Router Class Initialized
INFO - 2017-01-29 00:07:25 --> Output Class Initialized
INFO - 2017-01-29 00:07:25 --> Security Class Initialized
DEBUG - 2017-01-29 00:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:07:26 --> Input Class Initialized
INFO - 2017-01-29 00:07:26 --> Language Class Initialized
INFO - 2017-01-29 00:07:26 --> Loader Class Initialized
INFO - 2017-01-29 00:07:26 --> Database Driver Class Initialized
INFO - 2017-01-29 00:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:07:26 --> Controller Class Initialized
INFO - 2017-01-29 00:07:26 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:07:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:07:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:07:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:07:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:07:27 --> Final output sent to browser
DEBUG - 2017-01-29 00:07:27 --> Total execution time: 2.0044
INFO - 2017-01-29 00:27:22 --> Config Class Initialized
INFO - 2017-01-29 00:27:22 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:27:23 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:27:23 --> Utf8 Class Initialized
INFO - 2017-01-29 00:27:23 --> URI Class Initialized
DEBUG - 2017-01-29 00:27:23 --> No URI present. Default controller set.
INFO - 2017-01-29 00:27:23 --> Router Class Initialized
INFO - 2017-01-29 00:27:23 --> Output Class Initialized
INFO - 2017-01-29 00:27:23 --> Security Class Initialized
DEBUG - 2017-01-29 00:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:27:23 --> Input Class Initialized
INFO - 2017-01-29 00:27:23 --> Language Class Initialized
INFO - 2017-01-29 00:27:23 --> Loader Class Initialized
INFO - 2017-01-29 00:27:23 --> Database Driver Class Initialized
INFO - 2017-01-29 00:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:27:24 --> Controller Class Initialized
INFO - 2017-01-29 00:27:24 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:27:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:27:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:27:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:27:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:27:24 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:27:24 --> Final output sent to browser
DEBUG - 2017-01-29 00:27:24 --> Total execution time: 1.7440
INFO - 2017-01-29 00:28:46 --> Config Class Initialized
INFO - 2017-01-29 00:28:46 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:28:46 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:28:46 --> Utf8 Class Initialized
INFO - 2017-01-29 00:28:46 --> URI Class Initialized
INFO - 2017-01-29 00:28:46 --> Router Class Initialized
INFO - 2017-01-29 00:28:46 --> Output Class Initialized
INFO - 2017-01-29 00:28:46 --> Security Class Initialized
DEBUG - 2017-01-29 00:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:28:46 --> Input Class Initialized
INFO - 2017-01-29 00:28:46 --> Language Class Initialized
INFO - 2017-01-29 00:28:46 --> Loader Class Initialized
INFO - 2017-01-29 00:28:46 --> Database Driver Class Initialized
INFO - 2017-01-29 00:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:28:46 --> Controller Class Initialized
INFO - 2017-01-29 00:28:46 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:28:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:28:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:28:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:28:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:28:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:28:46 --> Final output sent to browser
DEBUG - 2017-01-29 00:28:46 --> Total execution time: 0.1101
INFO - 2017-01-29 00:29:31 --> Config Class Initialized
INFO - 2017-01-29 00:29:31 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:29:31 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:29:31 --> Utf8 Class Initialized
INFO - 2017-01-29 00:29:31 --> URI Class Initialized
INFO - 2017-01-29 00:29:31 --> Router Class Initialized
INFO - 2017-01-29 00:29:31 --> Output Class Initialized
INFO - 2017-01-29 00:29:31 --> Security Class Initialized
DEBUG - 2017-01-29 00:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:29:31 --> Input Class Initialized
INFO - 2017-01-29 00:29:31 --> Language Class Initialized
INFO - 2017-01-29 00:29:31 --> Loader Class Initialized
INFO - 2017-01-29 00:29:31 --> Database Driver Class Initialized
INFO - 2017-01-29 00:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:29:31 --> Controller Class Initialized
INFO - 2017-01-29 00:29:31 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:29:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:29:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:29:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:29:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:29:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:29:32 --> Final output sent to browser
DEBUG - 2017-01-29 00:29:32 --> Total execution time: 0.0429
INFO - 2017-01-29 00:29:34 --> Config Class Initialized
INFO - 2017-01-29 00:29:34 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:29:34 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:29:34 --> Utf8 Class Initialized
INFO - 2017-01-29 00:29:34 --> URI Class Initialized
INFO - 2017-01-29 00:29:34 --> Router Class Initialized
INFO - 2017-01-29 00:29:34 --> Output Class Initialized
INFO - 2017-01-29 00:29:34 --> Security Class Initialized
DEBUG - 2017-01-29 00:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:29:34 --> Input Class Initialized
INFO - 2017-01-29 00:29:34 --> Language Class Initialized
INFO - 2017-01-29 00:29:34 --> Loader Class Initialized
INFO - 2017-01-29 00:29:34 --> Database Driver Class Initialized
INFO - 2017-01-29 00:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:29:34 --> Controller Class Initialized
INFO - 2017-01-29 00:29:34 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:29:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:29:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:29:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:29:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:29:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:29:34 --> Final output sent to browser
DEBUG - 2017-01-29 00:29:34 --> Total execution time: 0.0144
INFO - 2017-01-29 00:29:45 --> Config Class Initialized
INFO - 2017-01-29 00:29:45 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:29:45 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:29:45 --> Utf8 Class Initialized
INFO - 2017-01-29 00:29:45 --> URI Class Initialized
INFO - 2017-01-29 00:29:45 --> Router Class Initialized
INFO - 2017-01-29 00:29:45 --> Output Class Initialized
INFO - 2017-01-29 00:29:45 --> Security Class Initialized
DEBUG - 2017-01-29 00:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:29:45 --> Input Class Initialized
INFO - 2017-01-29 00:29:45 --> Language Class Initialized
INFO - 2017-01-29 00:29:45 --> Loader Class Initialized
INFO - 2017-01-29 00:29:45 --> Database Driver Class Initialized
INFO - 2017-01-29 00:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:29:45 --> Controller Class Initialized
INFO - 2017-01-29 00:29:45 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:29:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:29:46 --> Config Class Initialized
INFO - 2017-01-29 00:29:46 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:29:46 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:29:46 --> Utf8 Class Initialized
INFO - 2017-01-29 00:29:46 --> URI Class Initialized
INFO - 2017-01-29 00:29:46 --> Router Class Initialized
INFO - 2017-01-29 00:29:46 --> Output Class Initialized
INFO - 2017-01-29 00:29:46 --> Security Class Initialized
DEBUG - 2017-01-29 00:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:29:46 --> Input Class Initialized
INFO - 2017-01-29 00:29:46 --> Language Class Initialized
INFO - 2017-01-29 00:29:46 --> Loader Class Initialized
INFO - 2017-01-29 00:29:46 --> Database Driver Class Initialized
INFO - 2017-01-29 00:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:29:46 --> Controller Class Initialized
INFO - 2017-01-29 00:29:46 --> Helper loaded: date_helper
DEBUG - 2017-01-29 00:29:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:29:46 --> Helper loaded: url_helper
INFO - 2017-01-29 00:29:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:29:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-29 00:29:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-29 00:29:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-29 00:29:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:29:46 --> Final output sent to browser
DEBUG - 2017-01-29 00:29:46 --> Total execution time: 0.2406
INFO - 2017-01-29 00:29:48 --> Config Class Initialized
INFO - 2017-01-29 00:29:48 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:29:48 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:29:48 --> Utf8 Class Initialized
INFO - 2017-01-29 00:29:48 --> URI Class Initialized
INFO - 2017-01-29 00:29:48 --> Router Class Initialized
INFO - 2017-01-29 00:29:48 --> Output Class Initialized
INFO - 2017-01-29 00:29:48 --> Security Class Initialized
DEBUG - 2017-01-29 00:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:29:48 --> Input Class Initialized
INFO - 2017-01-29 00:29:48 --> Language Class Initialized
INFO - 2017-01-29 00:29:48 --> Loader Class Initialized
INFO - 2017-01-29 00:29:48 --> Database Driver Class Initialized
INFO - 2017-01-29 00:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:29:48 --> Controller Class Initialized
INFO - 2017-01-29 00:29:48 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:29:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:29:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:29:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:29:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:29:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:29:48 --> Final output sent to browser
DEBUG - 2017-01-29 00:29:48 --> Total execution time: 0.0140
INFO - 2017-01-29 00:30:02 --> Config Class Initialized
INFO - 2017-01-29 00:30:02 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:30:02 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:30:02 --> Utf8 Class Initialized
INFO - 2017-01-29 00:30:02 --> URI Class Initialized
INFO - 2017-01-29 00:30:02 --> Router Class Initialized
INFO - 2017-01-29 00:30:02 --> Output Class Initialized
INFO - 2017-01-29 00:30:02 --> Security Class Initialized
DEBUG - 2017-01-29 00:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:30:02 --> Input Class Initialized
INFO - 2017-01-29 00:30:02 --> Language Class Initialized
INFO - 2017-01-29 00:30:02 --> Loader Class Initialized
INFO - 2017-01-29 00:30:02 --> Database Driver Class Initialized
INFO - 2017-01-29 00:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:30:02 --> Controller Class Initialized
INFO - 2017-01-29 00:30:02 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:30:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:30:02 --> Config Class Initialized
INFO - 2017-01-29 00:30:02 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:30:02 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:30:02 --> Utf8 Class Initialized
INFO - 2017-01-29 00:30:02 --> URI Class Initialized
INFO - 2017-01-29 00:30:02 --> Router Class Initialized
INFO - 2017-01-29 00:30:02 --> Output Class Initialized
INFO - 2017-01-29 00:30:02 --> Security Class Initialized
DEBUG - 2017-01-29 00:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:30:02 --> Input Class Initialized
INFO - 2017-01-29 00:30:02 --> Language Class Initialized
INFO - 2017-01-29 00:30:02 --> Loader Class Initialized
INFO - 2017-01-29 00:30:02 --> Database Driver Class Initialized
INFO - 2017-01-29 00:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:30:02 --> Controller Class Initialized
INFO - 2017-01-29 00:30:02 --> Helper loaded: date_helper
DEBUG - 2017-01-29 00:30:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:30:02 --> Helper loaded: url_helper
INFO - 2017-01-29 00:30:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:30:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-29 00:30:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-29 00:30:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-29 00:30:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:30:02 --> Final output sent to browser
DEBUG - 2017-01-29 00:30:02 --> Total execution time: 0.0173
INFO - 2017-01-29 00:30:03 --> Config Class Initialized
INFO - 2017-01-29 00:30:03 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:30:03 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:30:03 --> Utf8 Class Initialized
INFO - 2017-01-29 00:30:03 --> URI Class Initialized
INFO - 2017-01-29 00:30:03 --> Router Class Initialized
INFO - 2017-01-29 00:30:03 --> Output Class Initialized
INFO - 2017-01-29 00:30:03 --> Security Class Initialized
DEBUG - 2017-01-29 00:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:30:03 --> Input Class Initialized
INFO - 2017-01-29 00:30:03 --> Language Class Initialized
INFO - 2017-01-29 00:30:03 --> Loader Class Initialized
INFO - 2017-01-29 00:30:03 --> Database Driver Class Initialized
INFO - 2017-01-29 00:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:30:03 --> Controller Class Initialized
INFO - 2017-01-29 00:30:03 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:30:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:30:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:30:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:30:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:30:03 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:30:03 --> Final output sent to browser
DEBUG - 2017-01-29 00:30:03 --> Total execution time: 0.0140
INFO - 2017-01-29 00:30:19 --> Config Class Initialized
INFO - 2017-01-29 00:30:19 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:30:19 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:30:19 --> Utf8 Class Initialized
INFO - 2017-01-29 00:30:19 --> URI Class Initialized
DEBUG - 2017-01-29 00:30:19 --> No URI present. Default controller set.
INFO - 2017-01-29 00:30:19 --> Router Class Initialized
INFO - 2017-01-29 00:30:19 --> Output Class Initialized
INFO - 2017-01-29 00:30:19 --> Security Class Initialized
DEBUG - 2017-01-29 00:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:30:19 --> Input Class Initialized
INFO - 2017-01-29 00:30:19 --> Language Class Initialized
INFO - 2017-01-29 00:30:19 --> Loader Class Initialized
INFO - 2017-01-29 00:30:19 --> Database Driver Class Initialized
INFO - 2017-01-29 00:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:30:19 --> Controller Class Initialized
INFO - 2017-01-29 00:30:19 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:30:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:30:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:30:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:30:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:30:19 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:30:19 --> Final output sent to browser
DEBUG - 2017-01-29 00:30:19 --> Total execution time: 0.0139
INFO - 2017-01-29 00:37:42 --> Config Class Initialized
INFO - 2017-01-29 00:37:42 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:37:43 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:37:43 --> Utf8 Class Initialized
INFO - 2017-01-29 00:37:43 --> URI Class Initialized
DEBUG - 2017-01-29 00:37:43 --> No URI present. Default controller set.
INFO - 2017-01-29 00:37:43 --> Router Class Initialized
INFO - 2017-01-29 00:37:43 --> Output Class Initialized
INFO - 2017-01-29 00:37:43 --> Security Class Initialized
DEBUG - 2017-01-29 00:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:37:43 --> Input Class Initialized
INFO - 2017-01-29 00:37:43 --> Language Class Initialized
INFO - 2017-01-29 00:37:43 --> Loader Class Initialized
INFO - 2017-01-29 00:37:43 --> Database Driver Class Initialized
INFO - 2017-01-29 00:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:37:44 --> Controller Class Initialized
INFO - 2017-01-29 00:37:44 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:37:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:37:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:37:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:37:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:37:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:37:44 --> Final output sent to browser
DEBUG - 2017-01-29 00:37:44 --> Total execution time: 1.7867
INFO - 2017-01-29 00:41:04 --> Config Class Initialized
INFO - 2017-01-29 00:41:04 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:41:05 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:41:05 --> Utf8 Class Initialized
INFO - 2017-01-29 00:41:05 --> URI Class Initialized
INFO - 2017-01-29 00:41:05 --> Router Class Initialized
INFO - 2017-01-29 00:41:05 --> Output Class Initialized
INFO - 2017-01-29 00:41:05 --> Security Class Initialized
DEBUG - 2017-01-29 00:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:41:05 --> Input Class Initialized
INFO - 2017-01-29 00:41:05 --> Language Class Initialized
INFO - 2017-01-29 00:41:05 --> Loader Class Initialized
INFO - 2017-01-29 00:41:05 --> Database Driver Class Initialized
INFO - 2017-01-29 00:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:41:05 --> Controller Class Initialized
INFO - 2017-01-29 00:41:05 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:41:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:41:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:41:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:41:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:41:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:41:05 --> Final output sent to browser
DEBUG - 2017-01-29 00:41:05 --> Total execution time: 0.4043
INFO - 2017-01-29 00:41:25 --> Config Class Initialized
INFO - 2017-01-29 00:41:25 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:41:25 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:41:25 --> Utf8 Class Initialized
INFO - 2017-01-29 00:41:25 --> URI Class Initialized
INFO - 2017-01-29 00:41:25 --> Router Class Initialized
INFO - 2017-01-29 00:41:25 --> Output Class Initialized
INFO - 2017-01-29 00:41:25 --> Security Class Initialized
DEBUG - 2017-01-29 00:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:41:25 --> Input Class Initialized
INFO - 2017-01-29 00:41:25 --> Language Class Initialized
INFO - 2017-01-29 00:41:25 --> Loader Class Initialized
INFO - 2017-01-29 00:41:25 --> Database Driver Class Initialized
INFO - 2017-01-29 00:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:41:25 --> Controller Class Initialized
INFO - 2017-01-29 00:41:25 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:41:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:41:27 --> Config Class Initialized
INFO - 2017-01-29 00:41:27 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:41:27 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:41:27 --> Utf8 Class Initialized
INFO - 2017-01-29 00:41:27 --> URI Class Initialized
INFO - 2017-01-29 00:41:27 --> Router Class Initialized
INFO - 2017-01-29 00:41:27 --> Output Class Initialized
INFO - 2017-01-29 00:41:27 --> Security Class Initialized
DEBUG - 2017-01-29 00:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:41:27 --> Input Class Initialized
INFO - 2017-01-29 00:41:27 --> Language Class Initialized
INFO - 2017-01-29 00:41:27 --> Loader Class Initialized
INFO - 2017-01-29 00:41:27 --> Database Driver Class Initialized
INFO - 2017-01-29 00:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:41:27 --> Controller Class Initialized
INFO - 2017-01-29 00:41:27 --> Helper loaded: date_helper
DEBUG - 2017-01-29 00:41:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:41:27 --> Helper loaded: url_helper
INFO - 2017-01-29 00:41:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:41:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-29 00:41:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-29 00:41:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-29 00:41:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:41:27 --> Final output sent to browser
DEBUG - 2017-01-29 00:41:27 --> Total execution time: 0.0989
INFO - 2017-01-29 00:41:30 --> Config Class Initialized
INFO - 2017-01-29 00:41:30 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:41:30 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:41:30 --> Utf8 Class Initialized
INFO - 2017-01-29 00:41:30 --> URI Class Initialized
INFO - 2017-01-29 00:41:30 --> Router Class Initialized
INFO - 2017-01-29 00:41:30 --> Output Class Initialized
INFO - 2017-01-29 00:41:30 --> Security Class Initialized
DEBUG - 2017-01-29 00:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:41:30 --> Input Class Initialized
INFO - 2017-01-29 00:41:30 --> Language Class Initialized
INFO - 2017-01-29 00:41:30 --> Loader Class Initialized
INFO - 2017-01-29 00:41:30 --> Database Driver Class Initialized
INFO - 2017-01-29 00:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:41:30 --> Controller Class Initialized
INFO - 2017-01-29 00:41:30 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:41:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:41:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:41:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:41:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:41:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:41:30 --> Final output sent to browser
DEBUG - 2017-01-29 00:41:30 --> Total execution time: 0.0200
INFO - 2017-01-29 00:41:32 --> Config Class Initialized
INFO - 2017-01-29 00:41:32 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:41:32 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:41:32 --> Utf8 Class Initialized
INFO - 2017-01-29 00:41:32 --> URI Class Initialized
DEBUG - 2017-01-29 00:41:32 --> No URI present. Default controller set.
INFO - 2017-01-29 00:41:32 --> Router Class Initialized
INFO - 2017-01-29 00:41:32 --> Output Class Initialized
INFO - 2017-01-29 00:41:32 --> Security Class Initialized
DEBUG - 2017-01-29 00:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:41:32 --> Input Class Initialized
INFO - 2017-01-29 00:41:32 --> Language Class Initialized
INFO - 2017-01-29 00:41:32 --> Loader Class Initialized
INFO - 2017-01-29 00:41:32 --> Database Driver Class Initialized
INFO - 2017-01-29 00:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:41:32 --> Controller Class Initialized
INFO - 2017-01-29 00:41:32 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:41:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:41:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:41:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:41:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:41:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:41:32 --> Final output sent to browser
DEBUG - 2017-01-29 00:41:32 --> Total execution time: 0.0144
INFO - 2017-01-29 00:41:37 --> Config Class Initialized
INFO - 2017-01-29 00:41:37 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:41:37 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:41:37 --> Utf8 Class Initialized
INFO - 2017-01-29 00:41:37 --> URI Class Initialized
INFO - 2017-01-29 00:41:37 --> Router Class Initialized
INFO - 2017-01-29 00:41:37 --> Output Class Initialized
INFO - 2017-01-29 00:41:37 --> Security Class Initialized
DEBUG - 2017-01-29 00:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:41:37 --> Input Class Initialized
INFO - 2017-01-29 00:41:37 --> Language Class Initialized
INFO - 2017-01-29 00:41:37 --> Loader Class Initialized
INFO - 2017-01-29 00:41:37 --> Database Driver Class Initialized
INFO - 2017-01-29 00:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:41:37 --> Controller Class Initialized
INFO - 2017-01-29 00:41:37 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:41:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:41:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:41:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:41:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:41:37 --> Final output sent to browser
DEBUG - 2017-01-29 00:41:37 --> Total execution time: 0.0152
INFO - 2017-01-29 00:42:08 --> Config Class Initialized
INFO - 2017-01-29 00:42:08 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:42:08 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:42:08 --> Utf8 Class Initialized
INFO - 2017-01-29 00:42:08 --> URI Class Initialized
INFO - 2017-01-29 00:42:08 --> Router Class Initialized
INFO - 2017-01-29 00:42:08 --> Output Class Initialized
INFO - 2017-01-29 00:42:08 --> Security Class Initialized
DEBUG - 2017-01-29 00:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:42:08 --> Input Class Initialized
INFO - 2017-01-29 00:42:08 --> Language Class Initialized
INFO - 2017-01-29 00:42:08 --> Loader Class Initialized
INFO - 2017-01-29 00:42:08 --> Database Driver Class Initialized
INFO - 2017-01-29 00:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:42:08 --> Controller Class Initialized
INFO - 2017-01-29 00:42:08 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:42:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:42:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:42:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:42:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:42:08 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:42:08 --> Final output sent to browser
DEBUG - 2017-01-29 00:42:08 --> Total execution time: 0.0227
INFO - 2017-01-29 00:42:22 --> Config Class Initialized
INFO - 2017-01-29 00:42:22 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:42:22 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:42:22 --> Utf8 Class Initialized
INFO - 2017-01-29 00:42:22 --> URI Class Initialized
INFO - 2017-01-29 00:42:22 --> Router Class Initialized
INFO - 2017-01-29 00:42:22 --> Output Class Initialized
INFO - 2017-01-29 00:42:22 --> Security Class Initialized
DEBUG - 2017-01-29 00:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:42:22 --> Input Class Initialized
INFO - 2017-01-29 00:42:22 --> Language Class Initialized
INFO - 2017-01-29 00:42:22 --> Loader Class Initialized
INFO - 2017-01-29 00:42:22 --> Database Driver Class Initialized
INFO - 2017-01-29 00:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:42:22 --> Controller Class Initialized
INFO - 2017-01-29 00:42:22 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:42:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:42:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:42:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:42:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:42:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:42:22 --> Final output sent to browser
DEBUG - 2017-01-29 00:42:22 --> Total execution time: 0.0139
INFO - 2017-01-29 00:42:27 --> Config Class Initialized
INFO - 2017-01-29 00:42:27 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:42:27 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:42:27 --> Utf8 Class Initialized
INFO - 2017-01-29 00:42:27 --> URI Class Initialized
INFO - 2017-01-29 00:42:27 --> Router Class Initialized
INFO - 2017-01-29 00:42:27 --> Output Class Initialized
INFO - 2017-01-29 00:42:27 --> Security Class Initialized
DEBUG - 2017-01-29 00:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:42:27 --> Input Class Initialized
INFO - 2017-01-29 00:42:27 --> Language Class Initialized
INFO - 2017-01-29 00:42:27 --> Loader Class Initialized
INFO - 2017-01-29 00:42:27 --> Database Driver Class Initialized
INFO - 2017-01-29 00:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:42:27 --> Controller Class Initialized
INFO - 2017-01-29 00:42:27 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:42:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:42:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:42:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:42:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:42:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:42:27 --> Final output sent to browser
DEBUG - 2017-01-29 00:42:27 --> Total execution time: 0.0234
INFO - 2017-01-29 00:42:30 --> Config Class Initialized
INFO - 2017-01-29 00:42:30 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:42:30 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:42:30 --> Utf8 Class Initialized
INFO - 2017-01-29 00:42:30 --> URI Class Initialized
INFO - 2017-01-29 00:42:30 --> Router Class Initialized
INFO - 2017-01-29 00:42:30 --> Output Class Initialized
INFO - 2017-01-29 00:42:30 --> Security Class Initialized
DEBUG - 2017-01-29 00:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:42:30 --> Input Class Initialized
INFO - 2017-01-29 00:42:30 --> Language Class Initialized
INFO - 2017-01-29 00:42:30 --> Loader Class Initialized
INFO - 2017-01-29 00:42:30 --> Database Driver Class Initialized
INFO - 2017-01-29 00:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:42:31 --> Controller Class Initialized
INFO - 2017-01-29 00:42:31 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:42:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:42:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:42:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:42:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:42:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:42:31 --> Final output sent to browser
DEBUG - 2017-01-29 00:42:31 --> Total execution time: 0.0138
INFO - 2017-01-29 00:42:38 --> Config Class Initialized
INFO - 2017-01-29 00:42:38 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:42:38 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:42:38 --> Utf8 Class Initialized
INFO - 2017-01-29 00:42:38 --> URI Class Initialized
INFO - 2017-01-29 00:42:38 --> Router Class Initialized
INFO - 2017-01-29 00:42:38 --> Output Class Initialized
INFO - 2017-01-29 00:42:38 --> Security Class Initialized
DEBUG - 2017-01-29 00:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:42:38 --> Input Class Initialized
INFO - 2017-01-29 00:42:38 --> Language Class Initialized
INFO - 2017-01-29 00:42:38 --> Loader Class Initialized
INFO - 2017-01-29 00:42:38 --> Database Driver Class Initialized
INFO - 2017-01-29 00:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:42:38 --> Controller Class Initialized
INFO - 2017-01-29 00:42:38 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:42:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:42:39 --> Config Class Initialized
INFO - 2017-01-29 00:42:39 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:42:39 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:42:39 --> Utf8 Class Initialized
INFO - 2017-01-29 00:42:39 --> URI Class Initialized
INFO - 2017-01-29 00:42:39 --> Router Class Initialized
INFO - 2017-01-29 00:42:39 --> Output Class Initialized
INFO - 2017-01-29 00:42:39 --> Security Class Initialized
DEBUG - 2017-01-29 00:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:42:39 --> Input Class Initialized
INFO - 2017-01-29 00:42:39 --> Language Class Initialized
INFO - 2017-01-29 00:42:39 --> Loader Class Initialized
INFO - 2017-01-29 00:42:39 --> Database Driver Class Initialized
INFO - 2017-01-29 00:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:42:39 --> Controller Class Initialized
INFO - 2017-01-29 00:42:39 --> Helper loaded: date_helper
DEBUG - 2017-01-29 00:42:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:42:39 --> Helper loaded: url_helper
INFO - 2017-01-29 00:42:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:42:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-29 00:42:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-29 00:42:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-29 00:42:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:42:39 --> Final output sent to browser
DEBUG - 2017-01-29 00:42:39 --> Total execution time: 0.0137
INFO - 2017-01-29 00:42:40 --> Config Class Initialized
INFO - 2017-01-29 00:42:40 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:42:40 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:42:40 --> Utf8 Class Initialized
INFO - 2017-01-29 00:42:40 --> URI Class Initialized
INFO - 2017-01-29 00:42:40 --> Router Class Initialized
INFO - 2017-01-29 00:42:40 --> Output Class Initialized
INFO - 2017-01-29 00:42:40 --> Security Class Initialized
DEBUG - 2017-01-29 00:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:42:40 --> Input Class Initialized
INFO - 2017-01-29 00:42:40 --> Language Class Initialized
INFO - 2017-01-29 00:42:40 --> Loader Class Initialized
INFO - 2017-01-29 00:42:40 --> Database Driver Class Initialized
INFO - 2017-01-29 00:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:42:40 --> Controller Class Initialized
INFO - 2017-01-29 00:42:40 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:42:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:42:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:42:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:42:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:42:40 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:42:40 --> Final output sent to browser
DEBUG - 2017-01-29 00:42:40 --> Total execution time: 0.0644
INFO - 2017-01-29 00:42:55 --> Config Class Initialized
INFO - 2017-01-29 00:42:55 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:42:55 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:42:55 --> Utf8 Class Initialized
INFO - 2017-01-29 00:42:55 --> URI Class Initialized
DEBUG - 2017-01-29 00:42:55 --> No URI present. Default controller set.
INFO - 2017-01-29 00:42:55 --> Router Class Initialized
INFO - 2017-01-29 00:42:55 --> Output Class Initialized
INFO - 2017-01-29 00:42:55 --> Security Class Initialized
DEBUG - 2017-01-29 00:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:42:55 --> Input Class Initialized
INFO - 2017-01-29 00:42:55 --> Language Class Initialized
INFO - 2017-01-29 00:42:55 --> Loader Class Initialized
INFO - 2017-01-29 00:42:55 --> Database Driver Class Initialized
INFO - 2017-01-29 00:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:42:56 --> Controller Class Initialized
INFO - 2017-01-29 00:42:56 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:42:56 --> Config Class Initialized
INFO - 2017-01-29 00:42:56 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:42:56 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:42:56 --> Utf8 Class Initialized
INFO - 2017-01-29 00:42:56 --> URI Class Initialized
DEBUG - 2017-01-29 00:42:56 --> No URI present. Default controller set.
INFO - 2017-01-29 00:42:56 --> Router Class Initialized
INFO - 2017-01-29 00:42:56 --> Output Class Initialized
INFO - 2017-01-29 00:42:56 --> Security Class Initialized
INFO - 2017-01-29 00:42:56 --> Final output sent to browser
DEBUG - 2017-01-29 00:42:56 --> Total execution time: 0.2753
DEBUG - 2017-01-29 00:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:42:56 --> Input Class Initialized
INFO - 2017-01-29 00:42:56 --> Language Class Initialized
INFO - 2017-01-29 00:42:56 --> Loader Class Initialized
INFO - 2017-01-29 00:42:56 --> Database Driver Class Initialized
INFO - 2017-01-29 00:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:42:56 --> Controller Class Initialized
INFO - 2017-01-29 00:42:56 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:42:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:42:56 --> Final output sent to browser
DEBUG - 2017-01-29 00:42:56 --> Total execution time: 0.0556
INFO - 2017-01-29 00:43:44 --> Config Class Initialized
INFO - 2017-01-29 00:43:44 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:43:44 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:43:44 --> Utf8 Class Initialized
INFO - 2017-01-29 00:43:44 --> URI Class Initialized
INFO - 2017-01-29 00:43:44 --> Router Class Initialized
INFO - 2017-01-29 00:43:44 --> Output Class Initialized
INFO - 2017-01-29 00:43:44 --> Security Class Initialized
DEBUG - 2017-01-29 00:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:43:44 --> Input Class Initialized
INFO - 2017-01-29 00:43:44 --> Language Class Initialized
INFO - 2017-01-29 00:43:44 --> Loader Class Initialized
INFO - 2017-01-29 00:43:44 --> Database Driver Class Initialized
INFO - 2017-01-29 00:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:43:44 --> Controller Class Initialized
INFO - 2017-01-29 00:43:44 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:43:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:43:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:43:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:43:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:43:44 --> Final output sent to browser
DEBUG - 2017-01-29 00:43:44 --> Total execution time: 0.0376
INFO - 2017-01-29 00:44:12 --> Config Class Initialized
INFO - 2017-01-29 00:44:12 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:44:12 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:44:12 --> Utf8 Class Initialized
INFO - 2017-01-29 00:44:12 --> URI Class Initialized
INFO - 2017-01-29 00:44:12 --> Router Class Initialized
INFO - 2017-01-29 00:44:12 --> Output Class Initialized
INFO - 2017-01-29 00:44:12 --> Security Class Initialized
DEBUG - 2017-01-29 00:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:44:12 --> Input Class Initialized
INFO - 2017-01-29 00:44:12 --> Language Class Initialized
INFO - 2017-01-29 00:44:12 --> Loader Class Initialized
INFO - 2017-01-29 00:44:12 --> Database Driver Class Initialized
INFO - 2017-01-29 00:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:44:12 --> Controller Class Initialized
INFO - 2017-01-29 00:44:12 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:44:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:44:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:44:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:44:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:44:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:44:12 --> Final output sent to browser
DEBUG - 2017-01-29 00:44:12 --> Total execution time: 0.0153
INFO - 2017-01-29 00:44:30 --> Config Class Initialized
INFO - 2017-01-29 00:44:30 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:44:30 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:44:30 --> Utf8 Class Initialized
INFO - 2017-01-29 00:44:30 --> URI Class Initialized
INFO - 2017-01-29 00:44:30 --> Router Class Initialized
INFO - 2017-01-29 00:44:30 --> Output Class Initialized
INFO - 2017-01-29 00:44:30 --> Security Class Initialized
DEBUG - 2017-01-29 00:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:44:30 --> Input Class Initialized
INFO - 2017-01-29 00:44:30 --> Language Class Initialized
INFO - 2017-01-29 00:44:30 --> Loader Class Initialized
INFO - 2017-01-29 00:44:30 --> Database Driver Class Initialized
INFO - 2017-01-29 00:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:44:30 --> Controller Class Initialized
INFO - 2017-01-29 00:44:30 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:44:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:44:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:44:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:44:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:44:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:44:30 --> Final output sent to browser
DEBUG - 2017-01-29 00:44:30 --> Total execution time: 0.0512
INFO - 2017-01-29 00:44:39 --> Config Class Initialized
INFO - 2017-01-29 00:44:39 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:44:39 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:44:39 --> Utf8 Class Initialized
INFO - 2017-01-29 00:44:39 --> URI Class Initialized
INFO - 2017-01-29 00:44:39 --> Router Class Initialized
INFO - 2017-01-29 00:44:39 --> Output Class Initialized
INFO - 2017-01-29 00:44:39 --> Security Class Initialized
DEBUG - 2017-01-29 00:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:44:39 --> Input Class Initialized
INFO - 2017-01-29 00:44:39 --> Language Class Initialized
INFO - 2017-01-29 00:44:39 --> Loader Class Initialized
INFO - 2017-01-29 00:44:39 --> Database Driver Class Initialized
INFO - 2017-01-29 00:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:44:39 --> Controller Class Initialized
INFO - 2017-01-29 00:44:39 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:44:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:44:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:44:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:44:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:44:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:44:39 --> Final output sent to browser
DEBUG - 2017-01-29 00:44:39 --> Total execution time: 0.3799
INFO - 2017-01-29 00:44:43 --> Config Class Initialized
INFO - 2017-01-29 00:44:43 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:44:43 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:44:43 --> Utf8 Class Initialized
INFO - 2017-01-29 00:44:43 --> URI Class Initialized
INFO - 2017-01-29 00:44:43 --> Router Class Initialized
INFO - 2017-01-29 00:44:43 --> Output Class Initialized
INFO - 2017-01-29 00:44:43 --> Security Class Initialized
DEBUG - 2017-01-29 00:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:44:43 --> Input Class Initialized
INFO - 2017-01-29 00:44:43 --> Language Class Initialized
INFO - 2017-01-29 00:44:43 --> Loader Class Initialized
INFO - 2017-01-29 00:44:43 --> Database Driver Class Initialized
INFO - 2017-01-29 00:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:44:43 --> Controller Class Initialized
INFO - 2017-01-29 00:44:43 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:44:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:44:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:44:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:44:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:44:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:44:43 --> Final output sent to browser
DEBUG - 2017-01-29 00:44:43 --> Total execution time: 0.1910
INFO - 2017-01-29 00:44:45 --> Config Class Initialized
INFO - 2017-01-29 00:44:45 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:44:45 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:44:45 --> Utf8 Class Initialized
INFO - 2017-01-29 00:44:45 --> URI Class Initialized
INFO - 2017-01-29 00:44:45 --> Router Class Initialized
INFO - 2017-01-29 00:44:45 --> Output Class Initialized
INFO - 2017-01-29 00:44:45 --> Security Class Initialized
DEBUG - 2017-01-29 00:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:44:45 --> Input Class Initialized
INFO - 2017-01-29 00:44:45 --> Language Class Initialized
INFO - 2017-01-29 00:44:45 --> Loader Class Initialized
INFO - 2017-01-29 00:44:45 --> Database Driver Class Initialized
INFO - 2017-01-29 00:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:44:45 --> Controller Class Initialized
INFO - 2017-01-29 00:44:45 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:44:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:44:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:44:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:44:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:44:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:44:45 --> Final output sent to browser
DEBUG - 2017-01-29 00:44:45 --> Total execution time: 0.0210
INFO - 2017-01-29 00:44:49 --> Config Class Initialized
INFO - 2017-01-29 00:44:49 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:44:49 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:44:49 --> Utf8 Class Initialized
INFO - 2017-01-29 00:44:49 --> URI Class Initialized
INFO - 2017-01-29 00:44:49 --> Router Class Initialized
INFO - 2017-01-29 00:44:49 --> Output Class Initialized
INFO - 2017-01-29 00:44:49 --> Security Class Initialized
DEBUG - 2017-01-29 00:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:44:49 --> Input Class Initialized
INFO - 2017-01-29 00:44:49 --> Language Class Initialized
INFO - 2017-01-29 00:44:49 --> Loader Class Initialized
INFO - 2017-01-29 00:44:49 --> Database Driver Class Initialized
INFO - 2017-01-29 00:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:44:49 --> Controller Class Initialized
INFO - 2017-01-29 00:44:49 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:44:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:44:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:44:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:44:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:44:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:44:49 --> Final output sent to browser
DEBUG - 2017-01-29 00:44:49 --> Total execution time: 0.0138
INFO - 2017-01-29 00:44:57 --> Config Class Initialized
INFO - 2017-01-29 00:44:57 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:44:57 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:44:57 --> Utf8 Class Initialized
INFO - 2017-01-29 00:44:57 --> URI Class Initialized
DEBUG - 2017-01-29 00:44:57 --> No URI present. Default controller set.
INFO - 2017-01-29 00:44:57 --> Router Class Initialized
INFO - 2017-01-29 00:44:57 --> Output Class Initialized
INFO - 2017-01-29 00:44:57 --> Security Class Initialized
DEBUG - 2017-01-29 00:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:44:57 --> Input Class Initialized
INFO - 2017-01-29 00:44:57 --> Language Class Initialized
INFO - 2017-01-29 00:44:57 --> Loader Class Initialized
INFO - 2017-01-29 00:44:58 --> Database Driver Class Initialized
INFO - 2017-01-29 00:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:44:58 --> Controller Class Initialized
INFO - 2017-01-29 00:44:58 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:44:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:44:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:44:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:44:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:44:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:44:58 --> Final output sent to browser
DEBUG - 2017-01-29 00:44:58 --> Total execution time: 1.1360
INFO - 2017-01-29 00:45:01 --> Config Class Initialized
INFO - 2017-01-29 00:45:01 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:45:01 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:45:01 --> Utf8 Class Initialized
INFO - 2017-01-29 00:45:01 --> URI Class Initialized
INFO - 2017-01-29 00:45:01 --> Router Class Initialized
INFO - 2017-01-29 00:45:01 --> Output Class Initialized
INFO - 2017-01-29 00:45:01 --> Security Class Initialized
DEBUG - 2017-01-29 00:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:45:01 --> Input Class Initialized
INFO - 2017-01-29 00:45:01 --> Language Class Initialized
INFO - 2017-01-29 00:45:01 --> Loader Class Initialized
INFO - 2017-01-29 00:45:01 --> Database Driver Class Initialized
INFO - 2017-01-29 00:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:45:01 --> Controller Class Initialized
INFO - 2017-01-29 00:45:01 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:45:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:45:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:45:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:45:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:45:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:45:01 --> Final output sent to browser
DEBUG - 2017-01-29 00:45:01 --> Total execution time: 0.0141
INFO - 2017-01-29 00:45:25 --> Config Class Initialized
INFO - 2017-01-29 00:45:25 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:45:25 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:45:25 --> Utf8 Class Initialized
INFO - 2017-01-29 00:45:25 --> URI Class Initialized
INFO - 2017-01-29 00:45:25 --> Router Class Initialized
INFO - 2017-01-29 00:45:25 --> Output Class Initialized
INFO - 2017-01-29 00:45:25 --> Security Class Initialized
DEBUG - 2017-01-29 00:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:45:25 --> Input Class Initialized
INFO - 2017-01-29 00:45:25 --> Language Class Initialized
INFO - 2017-01-29 00:45:25 --> Loader Class Initialized
INFO - 2017-01-29 00:45:25 --> Database Driver Class Initialized
INFO - 2017-01-29 00:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:45:25 --> Controller Class Initialized
INFO - 2017-01-29 00:45:25 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:45:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:45:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:45:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:45:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:45:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:45:25 --> Final output sent to browser
DEBUG - 2017-01-29 00:45:25 --> Total execution time: 0.0305
INFO - 2017-01-29 00:45:30 --> Config Class Initialized
INFO - 2017-01-29 00:45:30 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:45:30 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:45:30 --> Utf8 Class Initialized
INFO - 2017-01-29 00:45:30 --> URI Class Initialized
INFO - 2017-01-29 00:45:30 --> Router Class Initialized
INFO - 2017-01-29 00:45:30 --> Output Class Initialized
INFO - 2017-01-29 00:45:30 --> Security Class Initialized
DEBUG - 2017-01-29 00:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:45:30 --> Input Class Initialized
INFO - 2017-01-29 00:45:30 --> Language Class Initialized
INFO - 2017-01-29 00:45:30 --> Loader Class Initialized
INFO - 2017-01-29 00:45:30 --> Database Driver Class Initialized
INFO - 2017-01-29 00:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:45:30 --> Controller Class Initialized
INFO - 2017-01-29 00:45:30 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:45:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:45:30 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:45:31 --> Final output sent to browser
DEBUG - 2017-01-29 00:45:31 --> Total execution time: 0.0156
INFO - 2017-01-29 00:45:35 --> Config Class Initialized
INFO - 2017-01-29 00:45:35 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:45:35 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:45:35 --> Utf8 Class Initialized
INFO - 2017-01-29 00:45:35 --> URI Class Initialized
INFO - 2017-01-29 00:45:35 --> Router Class Initialized
INFO - 2017-01-29 00:45:35 --> Output Class Initialized
INFO - 2017-01-29 00:45:35 --> Security Class Initialized
DEBUG - 2017-01-29 00:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:45:35 --> Input Class Initialized
INFO - 2017-01-29 00:45:35 --> Language Class Initialized
INFO - 2017-01-29 00:45:35 --> Loader Class Initialized
INFO - 2017-01-29 00:45:35 --> Database Driver Class Initialized
INFO - 2017-01-29 00:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:45:35 --> Controller Class Initialized
INFO - 2017-01-29 00:45:35 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:45:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:45:37 --> Config Class Initialized
INFO - 2017-01-29 00:45:37 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:45:37 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:45:37 --> Utf8 Class Initialized
INFO - 2017-01-29 00:45:37 --> URI Class Initialized
INFO - 2017-01-29 00:45:37 --> Router Class Initialized
INFO - 2017-01-29 00:45:37 --> Output Class Initialized
INFO - 2017-01-29 00:45:37 --> Security Class Initialized
DEBUG - 2017-01-29 00:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:45:37 --> Input Class Initialized
INFO - 2017-01-29 00:45:37 --> Language Class Initialized
INFO - 2017-01-29 00:45:37 --> Loader Class Initialized
INFO - 2017-01-29 00:45:37 --> Database Driver Class Initialized
INFO - 2017-01-29 00:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:45:37 --> Controller Class Initialized
INFO - 2017-01-29 00:45:37 --> Helper loaded: date_helper
DEBUG - 2017-01-29 00:45:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:45:37 --> Helper loaded: url_helper
INFO - 2017-01-29 00:45:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:45:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-29 00:45:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-29 00:45:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-29 00:45:37 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:45:37 --> Final output sent to browser
DEBUG - 2017-01-29 00:45:37 --> Total execution time: 0.0943
INFO - 2017-01-29 00:45:39 --> Config Class Initialized
INFO - 2017-01-29 00:45:39 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:45:39 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:45:39 --> Utf8 Class Initialized
INFO - 2017-01-29 00:45:39 --> URI Class Initialized
INFO - 2017-01-29 00:45:39 --> Router Class Initialized
INFO - 2017-01-29 00:45:39 --> Output Class Initialized
INFO - 2017-01-29 00:45:39 --> Security Class Initialized
DEBUG - 2017-01-29 00:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:45:39 --> Input Class Initialized
INFO - 2017-01-29 00:45:39 --> Language Class Initialized
INFO - 2017-01-29 00:45:39 --> Loader Class Initialized
INFO - 2017-01-29 00:45:39 --> Database Driver Class Initialized
INFO - 2017-01-29 00:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:45:39 --> Controller Class Initialized
INFO - 2017-01-29 00:45:39 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:45:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:45:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:45:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:45:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:45:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:45:39 --> Final output sent to browser
DEBUG - 2017-01-29 00:45:39 --> Total execution time: 0.0138
INFO - 2017-01-29 00:45:51 --> Config Class Initialized
INFO - 2017-01-29 00:45:51 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:45:51 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:45:51 --> Utf8 Class Initialized
INFO - 2017-01-29 00:45:51 --> URI Class Initialized
DEBUG - 2017-01-29 00:45:51 --> No URI present. Default controller set.
INFO - 2017-01-29 00:45:51 --> Router Class Initialized
INFO - 2017-01-29 00:45:51 --> Output Class Initialized
INFO - 2017-01-29 00:45:51 --> Security Class Initialized
DEBUG - 2017-01-29 00:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:45:51 --> Input Class Initialized
INFO - 2017-01-29 00:45:51 --> Language Class Initialized
INFO - 2017-01-29 00:45:51 --> Loader Class Initialized
INFO - 2017-01-29 00:45:51 --> Database Driver Class Initialized
INFO - 2017-01-29 00:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:45:51 --> Controller Class Initialized
INFO - 2017-01-29 00:45:51 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:45:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:45:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:45:51 --> Final output sent to browser
DEBUG - 2017-01-29 00:45:51 --> Total execution time: 0.0139
INFO - 2017-01-29 00:45:55 --> Config Class Initialized
INFO - 2017-01-29 00:45:55 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:45:55 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:45:55 --> Utf8 Class Initialized
INFO - 2017-01-29 00:45:55 --> URI Class Initialized
INFO - 2017-01-29 00:45:55 --> Router Class Initialized
INFO - 2017-01-29 00:45:55 --> Output Class Initialized
INFO - 2017-01-29 00:45:55 --> Security Class Initialized
DEBUG - 2017-01-29 00:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:45:55 --> Input Class Initialized
INFO - 2017-01-29 00:45:55 --> Language Class Initialized
INFO - 2017-01-29 00:45:55 --> Loader Class Initialized
INFO - 2017-01-29 00:45:55 --> Database Driver Class Initialized
INFO - 2017-01-29 00:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:45:55 --> Controller Class Initialized
INFO - 2017-01-29 00:45:55 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:45:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:45:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:45:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:45:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:45:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:45:55 --> Final output sent to browser
DEBUG - 2017-01-29 00:45:55 --> Total execution time: 0.0607
INFO - 2017-01-29 00:46:38 --> Config Class Initialized
INFO - 2017-01-29 00:46:38 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:46:38 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:46:38 --> Utf8 Class Initialized
INFO - 2017-01-29 00:46:38 --> URI Class Initialized
INFO - 2017-01-29 00:46:38 --> Router Class Initialized
INFO - 2017-01-29 00:46:38 --> Output Class Initialized
INFO - 2017-01-29 00:46:38 --> Security Class Initialized
DEBUG - 2017-01-29 00:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:46:38 --> Input Class Initialized
INFO - 2017-01-29 00:46:38 --> Language Class Initialized
INFO - 2017-01-29 00:46:38 --> Loader Class Initialized
INFO - 2017-01-29 00:46:38 --> Database Driver Class Initialized
INFO - 2017-01-29 00:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:46:38 --> Controller Class Initialized
INFO - 2017-01-29 00:46:38 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:46:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:46:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:46:38 --> Final output sent to browser
DEBUG - 2017-01-29 00:46:38 --> Total execution time: 0.3970
INFO - 2017-01-29 00:46:44 --> Config Class Initialized
INFO - 2017-01-29 00:46:44 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:46:44 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:46:44 --> Utf8 Class Initialized
INFO - 2017-01-29 00:46:44 --> URI Class Initialized
INFO - 2017-01-29 00:46:44 --> Router Class Initialized
INFO - 2017-01-29 00:46:44 --> Output Class Initialized
INFO - 2017-01-29 00:46:44 --> Security Class Initialized
DEBUG - 2017-01-29 00:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:46:44 --> Input Class Initialized
INFO - 2017-01-29 00:46:44 --> Language Class Initialized
INFO - 2017-01-29 00:46:44 --> Loader Class Initialized
INFO - 2017-01-29 00:46:44 --> Database Driver Class Initialized
INFO - 2017-01-29 00:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:46:44 --> Controller Class Initialized
INFO - 2017-01-29 00:46:44 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:46:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:46:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:46:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:46:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:46:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:46:44 --> Final output sent to browser
DEBUG - 2017-01-29 00:46:44 --> Total execution time: 0.0142
INFO - 2017-01-29 00:46:46 --> Config Class Initialized
INFO - 2017-01-29 00:46:46 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:46:46 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:46:46 --> Utf8 Class Initialized
INFO - 2017-01-29 00:46:46 --> URI Class Initialized
INFO - 2017-01-29 00:46:46 --> Router Class Initialized
INFO - 2017-01-29 00:46:46 --> Output Class Initialized
INFO - 2017-01-29 00:46:46 --> Security Class Initialized
DEBUG - 2017-01-29 00:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:46:46 --> Input Class Initialized
INFO - 2017-01-29 00:46:46 --> Language Class Initialized
INFO - 2017-01-29 00:46:46 --> Loader Class Initialized
INFO - 2017-01-29 00:46:46 --> Database Driver Class Initialized
INFO - 2017-01-29 00:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:46:46 --> Controller Class Initialized
INFO - 2017-01-29 00:46:46 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:46:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:46:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:46:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:46:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:46:46 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:46:46 --> Final output sent to browser
DEBUG - 2017-01-29 00:46:46 --> Total execution time: 0.0145
INFO - 2017-01-29 00:46:50 --> Config Class Initialized
INFO - 2017-01-29 00:46:50 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:46:50 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:46:50 --> Utf8 Class Initialized
INFO - 2017-01-29 00:46:50 --> URI Class Initialized
INFO - 2017-01-29 00:46:50 --> Router Class Initialized
INFO - 2017-01-29 00:46:50 --> Output Class Initialized
INFO - 2017-01-29 00:46:50 --> Security Class Initialized
DEBUG - 2017-01-29 00:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:46:50 --> Input Class Initialized
INFO - 2017-01-29 00:46:50 --> Language Class Initialized
INFO - 2017-01-29 00:46:50 --> Loader Class Initialized
INFO - 2017-01-29 00:46:50 --> Database Driver Class Initialized
INFO - 2017-01-29 00:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:46:50 --> Controller Class Initialized
INFO - 2017-01-29 00:46:50 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:46:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:46:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:46:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:46:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:46:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:46:50 --> Final output sent to browser
DEBUG - 2017-01-29 00:46:50 --> Total execution time: 0.0136
INFO - 2017-01-29 00:54:10 --> Config Class Initialized
INFO - 2017-01-29 00:54:10 --> Hooks Class Initialized
DEBUG - 2017-01-29 00:54:10 --> UTF-8 Support Enabled
INFO - 2017-01-29 00:54:11 --> Utf8 Class Initialized
INFO - 2017-01-29 00:54:11 --> URI Class Initialized
DEBUG - 2017-01-29 00:54:11 --> No URI present. Default controller set.
INFO - 2017-01-29 00:54:11 --> Router Class Initialized
INFO - 2017-01-29 00:54:11 --> Output Class Initialized
INFO - 2017-01-29 00:54:11 --> Security Class Initialized
DEBUG - 2017-01-29 00:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 00:54:11 --> Input Class Initialized
INFO - 2017-01-29 00:54:11 --> Language Class Initialized
INFO - 2017-01-29 00:54:11 --> Loader Class Initialized
INFO - 2017-01-29 00:54:11 --> Database Driver Class Initialized
INFO - 2017-01-29 00:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 00:54:12 --> Controller Class Initialized
INFO - 2017-01-29 00:54:12 --> Helper loaded: url_helper
DEBUG - 2017-01-29 00:54:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 00:54:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 00:54:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 00:54:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 00:54:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 00:54:12 --> Final output sent to browser
DEBUG - 2017-01-29 00:54:12 --> Total execution time: 1.5043
INFO - 2017-01-29 01:01:33 --> Config Class Initialized
INFO - 2017-01-29 01:01:33 --> Hooks Class Initialized
DEBUG - 2017-01-29 01:01:33 --> UTF-8 Support Enabled
INFO - 2017-01-29 01:01:33 --> Utf8 Class Initialized
INFO - 2017-01-29 01:01:33 --> URI Class Initialized
DEBUG - 2017-01-29 01:01:33 --> No URI present. Default controller set.
INFO - 2017-01-29 01:01:33 --> Router Class Initialized
INFO - 2017-01-29 01:01:33 --> Output Class Initialized
INFO - 2017-01-29 01:01:33 --> Security Class Initialized
DEBUG - 2017-01-29 01:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 01:01:33 --> Input Class Initialized
INFO - 2017-01-29 01:01:33 --> Language Class Initialized
INFO - 2017-01-29 01:01:33 --> Loader Class Initialized
INFO - 2017-01-29 01:01:33 --> Database Driver Class Initialized
INFO - 2017-01-29 01:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 01:01:33 --> Controller Class Initialized
INFO - 2017-01-29 01:01:33 --> Helper loaded: url_helper
DEBUG - 2017-01-29 01:01:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 01:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 01:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 01:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 01:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 01:01:33 --> Final output sent to browser
DEBUG - 2017-01-29 01:01:33 --> Total execution time: 0.0288
INFO - 2017-01-29 01:01:38 --> Config Class Initialized
INFO - 2017-01-29 01:01:38 --> Hooks Class Initialized
DEBUG - 2017-01-29 01:01:38 --> UTF-8 Support Enabled
INFO - 2017-01-29 01:01:38 --> Utf8 Class Initialized
INFO - 2017-01-29 01:01:38 --> URI Class Initialized
INFO - 2017-01-29 01:01:38 --> Router Class Initialized
INFO - 2017-01-29 01:01:38 --> Output Class Initialized
INFO - 2017-01-29 01:01:38 --> Security Class Initialized
DEBUG - 2017-01-29 01:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 01:01:38 --> Input Class Initialized
INFO - 2017-01-29 01:01:38 --> Language Class Initialized
INFO - 2017-01-29 01:01:38 --> Loader Class Initialized
INFO - 2017-01-29 01:01:38 --> Database Driver Class Initialized
INFO - 2017-01-29 01:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 01:01:38 --> Controller Class Initialized
INFO - 2017-01-29 01:01:38 --> Helper loaded: url_helper
DEBUG - 2017-01-29 01:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 01:01:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 01:01:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 01:01:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 01:01:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 01:01:38 --> Final output sent to browser
DEBUG - 2017-01-29 01:01:38 --> Total execution time: 0.0616
INFO - 2017-01-29 01:01:58 --> Config Class Initialized
INFO - 2017-01-29 01:01:58 --> Hooks Class Initialized
DEBUG - 2017-01-29 01:01:58 --> UTF-8 Support Enabled
INFO - 2017-01-29 01:01:58 --> Utf8 Class Initialized
INFO - 2017-01-29 01:01:58 --> URI Class Initialized
DEBUG - 2017-01-29 01:01:58 --> No URI present. Default controller set.
INFO - 2017-01-29 01:01:58 --> Router Class Initialized
INFO - 2017-01-29 01:01:58 --> Output Class Initialized
INFO - 2017-01-29 01:01:58 --> Security Class Initialized
DEBUG - 2017-01-29 01:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 01:01:58 --> Input Class Initialized
INFO - 2017-01-29 01:01:58 --> Language Class Initialized
INFO - 2017-01-29 01:01:58 --> Loader Class Initialized
INFO - 2017-01-29 01:01:58 --> Database Driver Class Initialized
INFO - 2017-01-29 01:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 01:01:58 --> Controller Class Initialized
INFO - 2017-01-29 01:01:58 --> Helper loaded: url_helper
DEBUG - 2017-01-29 01:01:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 01:01:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 01:01:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 01:01:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 01:01:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 01:01:58 --> Final output sent to browser
DEBUG - 2017-01-29 01:01:58 --> Total execution time: 0.0146
INFO - 2017-01-29 01:02:01 --> Config Class Initialized
INFO - 2017-01-29 01:02:01 --> Hooks Class Initialized
DEBUG - 2017-01-29 01:02:01 --> UTF-8 Support Enabled
INFO - 2017-01-29 01:02:01 --> Utf8 Class Initialized
INFO - 2017-01-29 01:02:01 --> URI Class Initialized
INFO - 2017-01-29 01:02:01 --> Router Class Initialized
INFO - 2017-01-29 01:02:01 --> Output Class Initialized
INFO - 2017-01-29 01:02:01 --> Security Class Initialized
DEBUG - 2017-01-29 01:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 01:02:01 --> Input Class Initialized
INFO - 2017-01-29 01:02:01 --> Language Class Initialized
INFO - 2017-01-29 01:02:01 --> Loader Class Initialized
INFO - 2017-01-29 01:02:01 --> Database Driver Class Initialized
INFO - 2017-01-29 01:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 01:02:01 --> Controller Class Initialized
INFO - 2017-01-29 01:02:01 --> Helper loaded: url_helper
DEBUG - 2017-01-29 01:02:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 01:02:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 01:02:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 01:02:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 01:02:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 01:02:01 --> Final output sent to browser
DEBUG - 2017-01-29 01:02:01 --> Total execution time: 0.0418
INFO - 2017-01-29 02:01:31 --> Config Class Initialized
INFO - 2017-01-29 02:01:31 --> Hooks Class Initialized
DEBUG - 2017-01-29 02:01:32 --> UTF-8 Support Enabled
INFO - 2017-01-29 02:01:32 --> Utf8 Class Initialized
INFO - 2017-01-29 02:01:32 --> URI Class Initialized
DEBUG - 2017-01-29 02:01:32 --> No URI present. Default controller set.
INFO - 2017-01-29 02:01:32 --> Router Class Initialized
INFO - 2017-01-29 02:01:32 --> Output Class Initialized
INFO - 2017-01-29 02:01:32 --> Security Class Initialized
DEBUG - 2017-01-29 02:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 02:01:32 --> Input Class Initialized
INFO - 2017-01-29 02:01:32 --> Language Class Initialized
INFO - 2017-01-29 02:01:32 --> Loader Class Initialized
INFO - 2017-01-29 02:01:32 --> Database Driver Class Initialized
INFO - 2017-01-29 02:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 02:01:33 --> Controller Class Initialized
INFO - 2017-01-29 02:01:33 --> Helper loaded: url_helper
DEBUG - 2017-01-29 02:01:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 02:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 02:01:33 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 02:01:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 02:01:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 02:01:34 --> Final output sent to browser
DEBUG - 2017-01-29 02:01:34 --> Total execution time: 2.2532
INFO - 2017-01-29 02:01:38 --> Config Class Initialized
INFO - 2017-01-29 02:01:38 --> Hooks Class Initialized
DEBUG - 2017-01-29 02:01:38 --> UTF-8 Support Enabled
INFO - 2017-01-29 02:01:38 --> Utf8 Class Initialized
INFO - 2017-01-29 02:01:38 --> URI Class Initialized
INFO - 2017-01-29 02:01:38 --> Router Class Initialized
INFO - 2017-01-29 02:01:38 --> Output Class Initialized
INFO - 2017-01-29 02:01:38 --> Security Class Initialized
DEBUG - 2017-01-29 02:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 02:01:38 --> Input Class Initialized
INFO - 2017-01-29 02:01:38 --> Language Class Initialized
INFO - 2017-01-29 02:01:38 --> Loader Class Initialized
INFO - 2017-01-29 02:01:38 --> Database Driver Class Initialized
INFO - 2017-01-29 02:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 02:01:38 --> Controller Class Initialized
INFO - 2017-01-29 02:01:38 --> Helper loaded: url_helper
DEBUG - 2017-01-29 02:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 02:01:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 02:01:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 02:01:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 02:01:38 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 02:01:38 --> Final output sent to browser
DEBUG - 2017-01-29 02:01:38 --> Total execution time: 0.0239
INFO - 2017-01-29 04:20:07 --> Config Class Initialized
INFO - 2017-01-29 04:20:07 --> Config Class Initialized
INFO - 2017-01-29 04:20:07 --> Hooks Class Initialized
INFO - 2017-01-29 04:20:07 --> Hooks Class Initialized
DEBUG - 2017-01-29 04:20:07 --> UTF-8 Support Enabled
DEBUG - 2017-01-29 04:20:07 --> UTF-8 Support Enabled
INFO - 2017-01-29 04:20:07 --> Utf8 Class Initialized
INFO - 2017-01-29 04:20:07 --> Utf8 Class Initialized
INFO - 2017-01-29 04:20:07 --> URI Class Initialized
INFO - 2017-01-29 04:20:07 --> URI Class Initialized
DEBUG - 2017-01-29 04:20:07 --> No URI present. Default controller set.
INFO - 2017-01-29 04:20:07 --> Router Class Initialized
INFO - 2017-01-29 04:20:07 --> Router Class Initialized
INFO - 2017-01-29 04:20:08 --> Output Class Initialized
INFO - 2017-01-29 04:20:08 --> Output Class Initialized
INFO - 2017-01-29 04:20:08 --> Security Class Initialized
INFO - 2017-01-29 04:20:08 --> Security Class Initialized
DEBUG - 2017-01-29 04:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 04:20:08 --> Input Class Initialized
INFO - 2017-01-29 04:20:08 --> Language Class Initialized
DEBUG - 2017-01-29 04:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 04:20:08 --> Input Class Initialized
INFO - 2017-01-29 04:20:08 --> Language Class Initialized
INFO - 2017-01-29 04:20:08 --> Loader Class Initialized
INFO - 2017-01-29 04:20:08 --> Loader Class Initialized
INFO - 2017-01-29 04:20:08 --> Database Driver Class Initialized
INFO - 2017-01-29 04:20:08 --> Database Driver Class Initialized
INFO - 2017-01-29 04:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 04:20:09 --> Controller Class Initialized
INFO - 2017-01-29 04:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 04:20:09 --> Helper loaded: url_helper
INFO - 2017-01-29 04:20:09 --> Controller Class Initialized
DEBUG - 2017-01-29 04:20:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 04:20:09 --> Helper loaded: url_helper
DEBUG - 2017-01-29 04:20:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 04:20:09 --> Helper loaded: form_helper
INFO - 2017-01-29 04:20:09 --> Form Validation Class Initialized
INFO - 2017-01-29 04:20:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 04:20:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-29 04:20:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 04:20:09 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-29 04:20:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 04:20:09 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 04:20:10 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-29 04:20:10 --> Final output sent to browser
DEBUG - 2017-01-29 04:20:10 --> Total execution time: 2.7210
INFO - 2017-01-29 04:20:10 --> Final output sent to browser
DEBUG - 2017-01-29 04:20:10 --> Total execution time: 2.7225
INFO - 2017-01-29 04:20:10 --> Config Class Initialized
INFO - 2017-01-29 04:20:10 --> Hooks Class Initialized
DEBUG - 2017-01-29 04:20:10 --> UTF-8 Support Enabled
INFO - 2017-01-29 04:20:10 --> Utf8 Class Initialized
INFO - 2017-01-29 04:20:10 --> URI Class Initialized
INFO - 2017-01-29 04:20:10 --> Router Class Initialized
INFO - 2017-01-29 04:20:10 --> Output Class Initialized
INFO - 2017-01-29 04:20:10 --> Security Class Initialized
DEBUG - 2017-01-29 04:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 04:20:10 --> Input Class Initialized
INFO - 2017-01-29 04:20:10 --> Language Class Initialized
INFO - 2017-01-29 04:20:10 --> Loader Class Initialized
INFO - 2017-01-29 04:20:10 --> Database Driver Class Initialized
INFO - 2017-01-29 04:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 04:20:10 --> Controller Class Initialized
INFO - 2017-01-29 04:20:10 --> Helper loaded: url_helper
DEBUG - 2017-01-29 04:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 04:20:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 04:20:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 04:20:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 04:20:10 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 04:20:10 --> Final output sent to browser
DEBUG - 2017-01-29 04:20:10 --> Total execution time: 0.0157
INFO - 2017-01-29 04:39:13 --> Config Class Initialized
INFO - 2017-01-29 04:39:13 --> Hooks Class Initialized
DEBUG - 2017-01-29 04:39:14 --> UTF-8 Support Enabled
INFO - 2017-01-29 04:39:14 --> Utf8 Class Initialized
INFO - 2017-01-29 04:39:14 --> URI Class Initialized
DEBUG - 2017-01-29 04:39:14 --> No URI present. Default controller set.
INFO - 2017-01-29 04:39:14 --> Router Class Initialized
INFO - 2017-01-29 04:39:14 --> Output Class Initialized
INFO - 2017-01-29 04:39:14 --> Security Class Initialized
DEBUG - 2017-01-29 04:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 04:39:14 --> Input Class Initialized
INFO - 2017-01-29 04:39:14 --> Language Class Initialized
INFO - 2017-01-29 04:39:14 --> Loader Class Initialized
INFO - 2017-01-29 04:39:14 --> Database Driver Class Initialized
INFO - 2017-01-29 04:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 04:39:15 --> Controller Class Initialized
INFO - 2017-01-29 04:39:15 --> Helper loaded: url_helper
DEBUG - 2017-01-29 04:39:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 04:39:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 04:39:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 04:39:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 04:39:15 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 04:39:15 --> Final output sent to browser
DEBUG - 2017-01-29 04:39:15 --> Total execution time: 2.0592
INFO - 2017-01-29 06:11:21 --> Config Class Initialized
INFO - 2017-01-29 06:11:21 --> Config Class Initialized
INFO - 2017-01-29 06:11:21 --> Hooks Class Initialized
INFO - 2017-01-29 06:11:21 --> Hooks Class Initialized
DEBUG - 2017-01-29 06:11:21 --> UTF-8 Support Enabled
DEBUG - 2017-01-29 06:11:21 --> UTF-8 Support Enabled
INFO - 2017-01-29 06:11:21 --> Utf8 Class Initialized
INFO - 2017-01-29 06:11:21 --> Utf8 Class Initialized
INFO - 2017-01-29 06:11:21 --> URI Class Initialized
INFO - 2017-01-29 06:11:21 --> URI Class Initialized
INFO - 2017-01-29 06:11:21 --> Router Class Initialized
INFO - 2017-01-29 06:11:21 --> Output Class Initialized
INFO - 2017-01-29 06:11:21 --> Security Class Initialized
DEBUG - 2017-01-29 06:11:21 --> No URI present. Default controller set.
INFO - 2017-01-29 06:11:21 --> Router Class Initialized
DEBUG - 2017-01-29 06:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 06:11:22 --> Input Class Initialized
INFO - 2017-01-29 06:11:22 --> Language Class Initialized
INFO - 2017-01-29 06:11:22 --> Output Class Initialized
INFO - 2017-01-29 06:11:22 --> Security Class Initialized
DEBUG - 2017-01-29 06:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 06:11:22 --> Input Class Initialized
INFO - 2017-01-29 06:11:22 --> Language Class Initialized
INFO - 2017-01-29 06:11:22 --> Loader Class Initialized
INFO - 2017-01-29 06:11:22 --> Loader Class Initialized
INFO - 2017-01-29 06:11:22 --> Database Driver Class Initialized
INFO - 2017-01-29 06:11:22 --> Database Driver Class Initialized
INFO - 2017-01-29 06:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 06:11:23 --> Controller Class Initialized
INFO - 2017-01-29 06:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 06:11:23 --> Controller Class Initialized
INFO - 2017-01-29 06:11:23 --> Helper loaded: url_helper
INFO - 2017-01-29 06:11:23 --> Helper loaded: url_helper
DEBUG - 2017-01-29 06:11:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-01-29 06:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 06:11:23 --> Helper loaded: form_helper
INFO - 2017-01-29 06:11:23 --> Form Validation Class Initialized
INFO - 2017-01-29 06:11:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/header.php
INFO - 2017-01-29 06:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 06:11:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/pages/login.php
INFO - 2017-01-29 06:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 06:11:23 --> File loaded: /home/graduafe/public_html/application/views/administrador/templates/footer.php
INFO - 2017-01-29 06:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 06:11:23 --> Final output sent to browser
DEBUG - 2017-01-29 06:11:23 --> Total execution time: 1.9421
INFO - 2017-01-29 06:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 06:11:23 --> Final output sent to browser
DEBUG - 2017-01-29 06:11:23 --> Total execution time: 1.9488
INFO - 2017-01-29 06:11:23 --> Config Class Initialized
INFO - 2017-01-29 06:11:23 --> Hooks Class Initialized
DEBUG - 2017-01-29 06:11:23 --> UTF-8 Support Enabled
INFO - 2017-01-29 06:11:23 --> Utf8 Class Initialized
INFO - 2017-01-29 06:11:23 --> URI Class Initialized
INFO - 2017-01-29 06:11:23 --> Router Class Initialized
INFO - 2017-01-29 06:11:23 --> Output Class Initialized
INFO - 2017-01-29 06:11:23 --> Security Class Initialized
DEBUG - 2017-01-29 06:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 06:11:23 --> Input Class Initialized
INFO - 2017-01-29 06:11:23 --> Language Class Initialized
INFO - 2017-01-29 06:11:23 --> Loader Class Initialized
INFO - 2017-01-29 06:11:23 --> Database Driver Class Initialized
INFO - 2017-01-29 06:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 06:11:23 --> Controller Class Initialized
INFO - 2017-01-29 06:11:23 --> Helper loaded: url_helper
DEBUG - 2017-01-29 06:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 06:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 06:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 06:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 06:11:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 06:11:23 --> Final output sent to browser
DEBUG - 2017-01-29 06:11:23 --> Total execution time: 0.0148
INFO - 2017-01-29 06:44:45 --> Config Class Initialized
INFO - 2017-01-29 06:44:45 --> Hooks Class Initialized
DEBUG - 2017-01-29 06:44:45 --> UTF-8 Support Enabled
INFO - 2017-01-29 06:44:45 --> Utf8 Class Initialized
INFO - 2017-01-29 06:44:45 --> URI Class Initialized
DEBUG - 2017-01-29 06:44:45 --> No URI present. Default controller set.
INFO - 2017-01-29 06:44:45 --> Router Class Initialized
INFO - 2017-01-29 06:44:45 --> Output Class Initialized
INFO - 2017-01-29 06:44:45 --> Security Class Initialized
DEBUG - 2017-01-29 06:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 06:44:46 --> Input Class Initialized
INFO - 2017-01-29 06:44:46 --> Language Class Initialized
INFO - 2017-01-29 06:44:46 --> Loader Class Initialized
INFO - 2017-01-29 06:44:46 --> Database Driver Class Initialized
INFO - 2017-01-29 06:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 06:44:47 --> Controller Class Initialized
INFO - 2017-01-29 06:44:47 --> Helper loaded: url_helper
DEBUG - 2017-01-29 06:44:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 06:44:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 06:44:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 06:44:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 06:44:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 06:44:47 --> Final output sent to browser
DEBUG - 2017-01-29 06:44:47 --> Total execution time: 1.8710
INFO - 2017-01-29 16:42:16 --> Config Class Initialized
INFO - 2017-01-29 16:42:16 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:42:16 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:42:16 --> Utf8 Class Initialized
INFO - 2017-01-29 16:42:16 --> URI Class Initialized
DEBUG - 2017-01-29 16:42:16 --> No URI present. Default controller set.
INFO - 2017-01-29 16:42:16 --> Router Class Initialized
INFO - 2017-01-29 16:42:16 --> Output Class Initialized
INFO - 2017-01-29 16:42:16 --> Security Class Initialized
DEBUG - 2017-01-29 16:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:42:17 --> Input Class Initialized
INFO - 2017-01-29 16:42:17 --> Language Class Initialized
INFO - 2017-01-29 16:42:17 --> Loader Class Initialized
INFO - 2017-01-29 16:42:17 --> Database Driver Class Initialized
INFO - 2017-01-29 16:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:42:17 --> Controller Class Initialized
INFO - 2017-01-29 16:42:17 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:42:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:42:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:42:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 16:42:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 16:42:18 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:42:18 --> Final output sent to browser
DEBUG - 2017-01-29 16:42:18 --> Total execution time: 1.7980
INFO - 2017-01-29 16:42:26 --> Config Class Initialized
INFO - 2017-01-29 16:42:26 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:42:26 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:42:26 --> Utf8 Class Initialized
INFO - 2017-01-29 16:42:26 --> URI Class Initialized
INFO - 2017-01-29 16:42:26 --> Router Class Initialized
INFO - 2017-01-29 16:42:26 --> Output Class Initialized
INFO - 2017-01-29 16:42:26 --> Security Class Initialized
DEBUG - 2017-01-29 16:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:42:26 --> Input Class Initialized
INFO - 2017-01-29 16:42:26 --> Language Class Initialized
INFO - 2017-01-29 16:42:26 --> Loader Class Initialized
INFO - 2017-01-29 16:42:26 --> Database Driver Class Initialized
INFO - 2017-01-29 16:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:42:26 --> Controller Class Initialized
INFO - 2017-01-29 16:42:26 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:42:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:42:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:42:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 16:42:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 16:42:26 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:42:26 --> Final output sent to browser
DEBUG - 2017-01-29 16:42:26 --> Total execution time: 0.0135
INFO - 2017-01-29 16:48:54 --> Config Class Initialized
INFO - 2017-01-29 16:48:54 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:48:54 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:48:54 --> Utf8 Class Initialized
INFO - 2017-01-29 16:48:54 --> URI Class Initialized
INFO - 2017-01-29 16:48:54 --> Router Class Initialized
INFO - 2017-01-29 16:48:54 --> Output Class Initialized
INFO - 2017-01-29 16:48:54 --> Security Class Initialized
DEBUG - 2017-01-29 16:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:48:55 --> Input Class Initialized
INFO - 2017-01-29 16:48:55 --> Language Class Initialized
INFO - 2017-01-29 16:48:55 --> Loader Class Initialized
INFO - 2017-01-29 16:48:55 --> Database Driver Class Initialized
INFO - 2017-01-29 16:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:48:55 --> Controller Class Initialized
INFO - 2017-01-29 16:48:55 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:48:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:48:56 --> Config Class Initialized
INFO - 2017-01-29 16:48:56 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:48:56 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:48:56 --> Utf8 Class Initialized
INFO - 2017-01-29 16:48:56 --> URI Class Initialized
INFO - 2017-01-29 16:48:56 --> Router Class Initialized
INFO - 2017-01-29 16:48:56 --> Output Class Initialized
INFO - 2017-01-29 16:48:56 --> Security Class Initialized
DEBUG - 2017-01-29 16:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:48:56 --> Input Class Initialized
INFO - 2017-01-29 16:48:56 --> Language Class Initialized
INFO - 2017-01-29 16:48:56 --> Loader Class Initialized
INFO - 2017-01-29 16:48:56 --> Database Driver Class Initialized
INFO - 2017-01-29 16:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:48:56 --> Controller Class Initialized
INFO - 2017-01-29 16:48:56 --> Helper loaded: date_helper
DEBUG - 2017-01-29 16:48:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:48:56 --> Helper loaded: url_helper
INFO - 2017-01-29 16:48:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:48:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-29 16:48:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-29 16:48:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-29 16:48:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:48:56 --> Final output sent to browser
DEBUG - 2017-01-29 16:48:56 --> Total execution time: 0.3778
INFO - 2017-01-29 16:48:57 --> Config Class Initialized
INFO - 2017-01-29 16:48:57 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:48:57 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:48:57 --> Utf8 Class Initialized
INFO - 2017-01-29 16:48:57 --> URI Class Initialized
INFO - 2017-01-29 16:48:57 --> Router Class Initialized
INFO - 2017-01-29 16:48:57 --> Output Class Initialized
INFO - 2017-01-29 16:48:57 --> Security Class Initialized
DEBUG - 2017-01-29 16:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:48:57 --> Input Class Initialized
INFO - 2017-01-29 16:48:57 --> Language Class Initialized
INFO - 2017-01-29 16:48:57 --> Loader Class Initialized
INFO - 2017-01-29 16:48:57 --> Database Driver Class Initialized
INFO - 2017-01-29 16:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:48:57 --> Controller Class Initialized
INFO - 2017-01-29 16:48:57 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:48:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:48:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:48:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 16:48:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 16:48:57 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:48:57 --> Final output sent to browser
DEBUG - 2017-01-29 16:48:57 --> Total execution time: 0.1430
INFO - 2017-01-29 16:49:01 --> Config Class Initialized
INFO - 2017-01-29 16:49:01 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:49:01 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:49:01 --> Utf8 Class Initialized
INFO - 2017-01-29 16:49:01 --> URI Class Initialized
DEBUG - 2017-01-29 16:49:01 --> No URI present. Default controller set.
INFO - 2017-01-29 16:49:01 --> Router Class Initialized
INFO - 2017-01-29 16:49:01 --> Output Class Initialized
INFO - 2017-01-29 16:49:01 --> Security Class Initialized
DEBUG - 2017-01-29 16:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:49:01 --> Input Class Initialized
INFO - 2017-01-29 16:49:01 --> Language Class Initialized
INFO - 2017-01-29 16:49:01 --> Loader Class Initialized
INFO - 2017-01-29 16:49:01 --> Database Driver Class Initialized
INFO - 2017-01-29 16:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:49:01 --> Controller Class Initialized
INFO - 2017-01-29 16:49:01 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:49:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:49:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:49:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 16:49:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 16:49:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:49:01 --> Final output sent to browser
DEBUG - 2017-01-29 16:49:01 --> Total execution time: 0.0137
INFO - 2017-01-29 16:49:02 --> Config Class Initialized
INFO - 2017-01-29 16:49:02 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:49:02 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:49:02 --> Utf8 Class Initialized
INFO - 2017-01-29 16:49:02 --> URI Class Initialized
INFO - 2017-01-29 16:49:02 --> Router Class Initialized
INFO - 2017-01-29 16:49:02 --> Output Class Initialized
INFO - 2017-01-29 16:49:02 --> Security Class Initialized
DEBUG - 2017-01-29 16:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:49:02 --> Input Class Initialized
INFO - 2017-01-29 16:49:02 --> Language Class Initialized
INFO - 2017-01-29 16:49:02 --> Loader Class Initialized
INFO - 2017-01-29 16:49:02 --> Database Driver Class Initialized
INFO - 2017-01-29 16:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:49:02 --> Controller Class Initialized
INFO - 2017-01-29 16:49:02 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:49:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:49:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:49:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 16:49:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 16:49:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:49:02 --> Final output sent to browser
DEBUG - 2017-01-29 16:49:02 --> Total execution time: 0.0140
INFO - 2017-01-29 16:49:32 --> Config Class Initialized
INFO - 2017-01-29 16:49:32 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:49:32 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:49:32 --> Utf8 Class Initialized
INFO - 2017-01-29 16:49:32 --> URI Class Initialized
INFO - 2017-01-29 16:49:32 --> Router Class Initialized
INFO - 2017-01-29 16:49:32 --> Output Class Initialized
INFO - 2017-01-29 16:49:32 --> Security Class Initialized
DEBUG - 2017-01-29 16:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:49:32 --> Input Class Initialized
INFO - 2017-01-29 16:49:32 --> Language Class Initialized
INFO - 2017-01-29 16:49:32 --> Loader Class Initialized
INFO - 2017-01-29 16:49:32 --> Database Driver Class Initialized
INFO - 2017-01-29 16:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:49:32 --> Controller Class Initialized
INFO - 2017-01-29 16:49:32 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:49:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:49:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:49:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 16:49:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 16:49:32 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:49:32 --> Final output sent to browser
DEBUG - 2017-01-29 16:49:32 --> Total execution time: 0.0278
INFO - 2017-01-29 16:49:34 --> Config Class Initialized
INFO - 2017-01-29 16:49:34 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:49:34 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:49:34 --> Utf8 Class Initialized
INFO - 2017-01-29 16:49:34 --> URI Class Initialized
INFO - 2017-01-29 16:49:34 --> Router Class Initialized
INFO - 2017-01-29 16:49:34 --> Output Class Initialized
INFO - 2017-01-29 16:49:34 --> Security Class Initialized
DEBUG - 2017-01-29 16:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:49:34 --> Input Class Initialized
INFO - 2017-01-29 16:49:34 --> Language Class Initialized
INFO - 2017-01-29 16:49:34 --> Loader Class Initialized
INFO - 2017-01-29 16:49:34 --> Database Driver Class Initialized
INFO - 2017-01-29 16:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:49:34 --> Controller Class Initialized
INFO - 2017-01-29 16:49:34 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:49:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:49:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:49:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 16:49:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 16:49:34 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:49:34 --> Final output sent to browser
DEBUG - 2017-01-29 16:49:34 --> Total execution time: 0.0173
INFO - 2017-01-29 16:49:48 --> Config Class Initialized
INFO - 2017-01-29 16:49:48 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:49:48 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:49:48 --> Utf8 Class Initialized
INFO - 2017-01-29 16:49:48 --> URI Class Initialized
INFO - 2017-01-29 16:49:48 --> Router Class Initialized
INFO - 2017-01-29 16:49:48 --> Output Class Initialized
INFO - 2017-01-29 16:49:48 --> Security Class Initialized
DEBUG - 2017-01-29 16:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:49:48 --> Input Class Initialized
INFO - 2017-01-29 16:49:48 --> Language Class Initialized
INFO - 2017-01-29 16:49:48 --> Loader Class Initialized
INFO - 2017-01-29 16:49:48 --> Database Driver Class Initialized
INFO - 2017-01-29 16:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:49:48 --> Controller Class Initialized
INFO - 2017-01-29 16:49:48 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:49:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:49:50 --> Config Class Initialized
INFO - 2017-01-29 16:49:50 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:49:50 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:49:50 --> Utf8 Class Initialized
INFO - 2017-01-29 16:49:50 --> URI Class Initialized
INFO - 2017-01-29 16:49:50 --> Router Class Initialized
INFO - 2017-01-29 16:49:50 --> Output Class Initialized
INFO - 2017-01-29 16:49:50 --> Security Class Initialized
DEBUG - 2017-01-29 16:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:49:50 --> Input Class Initialized
INFO - 2017-01-29 16:49:50 --> Language Class Initialized
INFO - 2017-01-29 16:49:50 --> Loader Class Initialized
INFO - 2017-01-29 16:49:50 --> Database Driver Class Initialized
INFO - 2017-01-29 16:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:49:50 --> Controller Class Initialized
INFO - 2017-01-29 16:49:50 --> Helper loaded: date_helper
DEBUG - 2017-01-29 16:49:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:49:50 --> Helper loaded: url_helper
INFO - 2017-01-29 16:49:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:49:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-29 16:49:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-29 16:49:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-29 16:49:50 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:49:50 --> Final output sent to browser
DEBUG - 2017-01-29 16:49:50 --> Total execution time: 0.1182
INFO - 2017-01-29 16:49:51 --> Config Class Initialized
INFO - 2017-01-29 16:49:51 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:49:51 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:49:51 --> Utf8 Class Initialized
INFO - 2017-01-29 16:49:51 --> URI Class Initialized
INFO - 2017-01-29 16:49:51 --> Router Class Initialized
INFO - 2017-01-29 16:49:51 --> Output Class Initialized
INFO - 2017-01-29 16:49:51 --> Security Class Initialized
DEBUG - 2017-01-29 16:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:49:51 --> Input Class Initialized
INFO - 2017-01-29 16:49:51 --> Language Class Initialized
INFO - 2017-01-29 16:49:51 --> Loader Class Initialized
INFO - 2017-01-29 16:49:51 --> Database Driver Class Initialized
INFO - 2017-01-29 16:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:49:51 --> Controller Class Initialized
INFO - 2017-01-29 16:49:51 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:49:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:49:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:49:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 16:49:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 16:49:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:49:51 --> Final output sent to browser
DEBUG - 2017-01-29 16:49:51 --> Total execution time: 0.0221
INFO - 2017-01-29 16:49:55 --> Config Class Initialized
INFO - 2017-01-29 16:49:55 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:49:55 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:49:55 --> Utf8 Class Initialized
INFO - 2017-01-29 16:49:55 --> URI Class Initialized
DEBUG - 2017-01-29 16:49:55 --> No URI present. Default controller set.
INFO - 2017-01-29 16:49:55 --> Router Class Initialized
INFO - 2017-01-29 16:49:55 --> Output Class Initialized
INFO - 2017-01-29 16:49:55 --> Security Class Initialized
DEBUG - 2017-01-29 16:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:49:55 --> Input Class Initialized
INFO - 2017-01-29 16:49:55 --> Language Class Initialized
INFO - 2017-01-29 16:49:55 --> Loader Class Initialized
INFO - 2017-01-29 16:49:55 --> Database Driver Class Initialized
INFO - 2017-01-29 16:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:49:55 --> Controller Class Initialized
INFO - 2017-01-29 16:49:55 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:49:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:49:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:49:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 16:49:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 16:49:55 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:49:55 --> Final output sent to browser
DEBUG - 2017-01-29 16:49:55 --> Total execution time: 0.0152
INFO - 2017-01-29 16:49:56 --> Config Class Initialized
INFO - 2017-01-29 16:49:56 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:49:56 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:49:56 --> Utf8 Class Initialized
INFO - 2017-01-29 16:49:56 --> URI Class Initialized
INFO - 2017-01-29 16:49:56 --> Router Class Initialized
INFO - 2017-01-29 16:49:56 --> Output Class Initialized
INFO - 2017-01-29 16:49:56 --> Security Class Initialized
DEBUG - 2017-01-29 16:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:49:56 --> Input Class Initialized
INFO - 2017-01-29 16:49:56 --> Language Class Initialized
INFO - 2017-01-29 16:49:56 --> Loader Class Initialized
INFO - 2017-01-29 16:49:56 --> Database Driver Class Initialized
INFO - 2017-01-29 16:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:49:56 --> Controller Class Initialized
INFO - 2017-01-29 16:49:56 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:49:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:49:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:49:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 16:49:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 16:49:56 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:49:56 --> Final output sent to browser
DEBUG - 2017-01-29 16:49:56 --> Total execution time: 0.0138
INFO - 2017-01-29 16:50:42 --> Config Class Initialized
INFO - 2017-01-29 16:50:42 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:50:42 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:50:42 --> Utf8 Class Initialized
INFO - 2017-01-29 16:50:42 --> URI Class Initialized
INFO - 2017-01-29 16:50:42 --> Router Class Initialized
INFO - 2017-01-29 16:50:42 --> Output Class Initialized
INFO - 2017-01-29 16:50:42 --> Security Class Initialized
DEBUG - 2017-01-29 16:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:50:42 --> Input Class Initialized
INFO - 2017-01-29 16:50:42 --> Language Class Initialized
INFO - 2017-01-29 16:50:42 --> Loader Class Initialized
INFO - 2017-01-29 16:50:42 --> Database Driver Class Initialized
INFO - 2017-01-29 16:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:50:42 --> Controller Class Initialized
INFO - 2017-01-29 16:50:42 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:50:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:50:44 --> Config Class Initialized
INFO - 2017-01-29 16:50:44 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:50:44 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:50:44 --> Utf8 Class Initialized
INFO - 2017-01-29 16:50:44 --> URI Class Initialized
INFO - 2017-01-29 16:50:44 --> Router Class Initialized
INFO - 2017-01-29 16:50:44 --> Output Class Initialized
INFO - 2017-01-29 16:50:44 --> Security Class Initialized
DEBUG - 2017-01-29 16:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:50:44 --> Input Class Initialized
INFO - 2017-01-29 16:50:44 --> Language Class Initialized
INFO - 2017-01-29 16:50:44 --> Loader Class Initialized
INFO - 2017-01-29 16:50:44 --> Database Driver Class Initialized
INFO - 2017-01-29 16:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:50:44 --> Controller Class Initialized
INFO - 2017-01-29 16:50:44 --> Helper loaded: date_helper
DEBUG - 2017-01-29 16:50:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:50:44 --> Helper loaded: url_helper
INFO - 2017-01-29 16:50:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:50:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-29 16:50:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-29 16:50:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-29 16:50:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:50:44 --> Final output sent to browser
DEBUG - 2017-01-29 16:50:44 --> Total execution time: 0.0144
INFO - 2017-01-29 16:50:44 --> Config Class Initialized
INFO - 2017-01-29 16:50:44 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:50:44 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:50:44 --> Utf8 Class Initialized
INFO - 2017-01-29 16:50:44 --> URI Class Initialized
INFO - 2017-01-29 16:50:44 --> Router Class Initialized
INFO - 2017-01-29 16:50:44 --> Output Class Initialized
INFO - 2017-01-29 16:50:44 --> Security Class Initialized
DEBUG - 2017-01-29 16:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:50:44 --> Input Class Initialized
INFO - 2017-01-29 16:50:44 --> Language Class Initialized
INFO - 2017-01-29 16:50:44 --> Loader Class Initialized
INFO - 2017-01-29 16:50:44 --> Database Driver Class Initialized
INFO - 2017-01-29 16:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:50:44 --> Controller Class Initialized
INFO - 2017-01-29 16:50:44 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:50:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:50:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:50:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 16:50:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 16:50:44 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:50:44 --> Final output sent to browser
DEBUG - 2017-01-29 16:50:44 --> Total execution time: 0.0146
INFO - 2017-01-29 16:54:21 --> Config Class Initialized
INFO - 2017-01-29 16:54:21 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:54:21 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:54:21 --> Utf8 Class Initialized
INFO - 2017-01-29 16:54:21 --> URI Class Initialized
DEBUG - 2017-01-29 16:54:21 --> No URI present. Default controller set.
INFO - 2017-01-29 16:54:21 --> Router Class Initialized
INFO - 2017-01-29 16:54:21 --> Output Class Initialized
INFO - 2017-01-29 16:54:21 --> Security Class Initialized
DEBUG - 2017-01-29 16:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:54:21 --> Input Class Initialized
INFO - 2017-01-29 16:54:21 --> Language Class Initialized
INFO - 2017-01-29 16:54:21 --> Loader Class Initialized
INFO - 2017-01-29 16:54:21 --> Database Driver Class Initialized
INFO - 2017-01-29 16:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:54:21 --> Controller Class Initialized
INFO - 2017-01-29 16:54:21 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:54:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:54:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:54:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 16:54:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 16:54:21 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:54:21 --> Final output sent to browser
DEBUG - 2017-01-29 16:54:21 --> Total execution time: 0.5465
INFO - 2017-01-29 16:54:27 --> Config Class Initialized
INFO - 2017-01-29 16:54:27 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:54:27 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:54:27 --> Utf8 Class Initialized
INFO - 2017-01-29 16:54:27 --> URI Class Initialized
INFO - 2017-01-29 16:54:27 --> Router Class Initialized
INFO - 2017-01-29 16:54:27 --> Output Class Initialized
INFO - 2017-01-29 16:54:27 --> Security Class Initialized
DEBUG - 2017-01-29 16:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:54:27 --> Input Class Initialized
INFO - 2017-01-29 16:54:27 --> Language Class Initialized
INFO - 2017-01-29 16:54:27 --> Loader Class Initialized
INFO - 2017-01-29 16:54:27 --> Database Driver Class Initialized
INFO - 2017-01-29 16:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:54:27 --> Controller Class Initialized
INFO - 2017-01-29 16:54:27 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:54:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:54:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:54:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 16:54:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 16:54:27 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:54:27 --> Final output sent to browser
DEBUG - 2017-01-29 16:54:27 --> Total execution time: 0.0134
INFO - 2017-01-29 16:55:00 --> Config Class Initialized
INFO - 2017-01-29 16:55:00 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:55:00 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:55:00 --> Utf8 Class Initialized
INFO - 2017-01-29 16:55:00 --> URI Class Initialized
INFO - 2017-01-29 16:55:00 --> Router Class Initialized
INFO - 2017-01-29 16:55:00 --> Output Class Initialized
INFO - 2017-01-29 16:55:00 --> Security Class Initialized
DEBUG - 2017-01-29 16:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:55:00 --> Input Class Initialized
INFO - 2017-01-29 16:55:00 --> Language Class Initialized
INFO - 2017-01-29 16:55:00 --> Loader Class Initialized
INFO - 2017-01-29 16:55:00 --> Database Driver Class Initialized
INFO - 2017-01-29 16:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:55:00 --> Controller Class Initialized
INFO - 2017-01-29 16:55:00 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:55:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:55:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:55:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 16:55:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 16:55:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:55:00 --> Final output sent to browser
DEBUG - 2017-01-29 16:55:00 --> Total execution time: 0.0143
INFO - 2017-01-29 16:55:02 --> Config Class Initialized
INFO - 2017-01-29 16:55:02 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:55:02 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:55:02 --> Utf8 Class Initialized
INFO - 2017-01-29 16:55:02 --> URI Class Initialized
INFO - 2017-01-29 16:55:02 --> Router Class Initialized
INFO - 2017-01-29 16:55:02 --> Output Class Initialized
INFO - 2017-01-29 16:55:02 --> Security Class Initialized
DEBUG - 2017-01-29 16:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:55:02 --> Input Class Initialized
INFO - 2017-01-29 16:55:02 --> Language Class Initialized
INFO - 2017-01-29 16:55:02 --> Loader Class Initialized
INFO - 2017-01-29 16:55:02 --> Database Driver Class Initialized
INFO - 2017-01-29 16:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:55:02 --> Controller Class Initialized
INFO - 2017-01-29 16:55:02 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:55:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:55:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:55:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 16:55:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 16:55:02 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:55:02 --> Final output sent to browser
DEBUG - 2017-01-29 16:55:02 --> Total execution time: 0.0140
INFO - 2017-01-29 16:55:28 --> Config Class Initialized
INFO - 2017-01-29 16:55:28 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:55:28 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:55:28 --> Utf8 Class Initialized
INFO - 2017-01-29 16:55:28 --> URI Class Initialized
INFO - 2017-01-29 16:55:28 --> Router Class Initialized
INFO - 2017-01-29 16:55:28 --> Output Class Initialized
INFO - 2017-01-29 16:55:28 --> Security Class Initialized
DEBUG - 2017-01-29 16:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:55:28 --> Input Class Initialized
INFO - 2017-01-29 16:55:28 --> Language Class Initialized
INFO - 2017-01-29 16:55:29 --> Loader Class Initialized
INFO - 2017-01-29 16:55:29 --> Database Driver Class Initialized
INFO - 2017-01-29 16:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:55:29 --> Controller Class Initialized
INFO - 2017-01-29 16:55:29 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:55:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:55:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 16:55:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 16:55:29 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:55:29 --> Final output sent to browser
DEBUG - 2017-01-29 16:55:29 --> Total execution time: 1.3196
INFO - 2017-01-29 16:55:31 --> Config Class Initialized
INFO - 2017-01-29 16:55:31 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:55:31 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:55:31 --> Utf8 Class Initialized
INFO - 2017-01-29 16:55:31 --> URI Class Initialized
INFO - 2017-01-29 16:55:31 --> Router Class Initialized
INFO - 2017-01-29 16:55:31 --> Output Class Initialized
INFO - 2017-01-29 16:55:31 --> Security Class Initialized
DEBUG - 2017-01-29 16:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:55:31 --> Input Class Initialized
INFO - 2017-01-29 16:55:31 --> Language Class Initialized
INFO - 2017-01-29 16:55:31 --> Loader Class Initialized
INFO - 2017-01-29 16:55:31 --> Database Driver Class Initialized
INFO - 2017-01-29 16:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:55:31 --> Controller Class Initialized
INFO - 2017-01-29 16:55:31 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:55:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:55:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 16:55:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 16:55:31 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:55:31 --> Final output sent to browser
DEBUG - 2017-01-29 16:55:31 --> Total execution time: 0.0139
INFO - 2017-01-29 16:55:59 --> Config Class Initialized
INFO - 2017-01-29 16:55:59 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:55:59 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:55:59 --> Utf8 Class Initialized
INFO - 2017-01-29 16:55:59 --> URI Class Initialized
INFO - 2017-01-29 16:55:59 --> Router Class Initialized
INFO - 2017-01-29 16:55:59 --> Output Class Initialized
INFO - 2017-01-29 16:55:59 --> Security Class Initialized
DEBUG - 2017-01-29 16:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:55:59 --> Input Class Initialized
INFO - 2017-01-29 16:55:59 --> Language Class Initialized
INFO - 2017-01-29 16:55:59 --> Loader Class Initialized
INFO - 2017-01-29 16:55:59 --> Database Driver Class Initialized
INFO - 2017-01-29 16:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:55:59 --> Controller Class Initialized
INFO - 2017-01-29 16:55:59 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:55:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 16:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 16:55:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:55:59 --> Final output sent to browser
DEBUG - 2017-01-29 16:55:59 --> Total execution time: 0.5785
INFO - 2017-01-29 16:56:00 --> Config Class Initialized
INFO - 2017-01-29 16:56:00 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:56:00 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:56:00 --> Utf8 Class Initialized
INFO - 2017-01-29 16:56:00 --> URI Class Initialized
INFO - 2017-01-29 16:56:00 --> Router Class Initialized
INFO - 2017-01-29 16:56:00 --> Output Class Initialized
INFO - 2017-01-29 16:56:00 --> Security Class Initialized
DEBUG - 2017-01-29 16:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:56:00 --> Input Class Initialized
INFO - 2017-01-29 16:56:00 --> Language Class Initialized
INFO - 2017-01-29 16:56:00 --> Loader Class Initialized
INFO - 2017-01-29 16:56:00 --> Database Driver Class Initialized
INFO - 2017-01-29 16:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:56:00 --> Controller Class Initialized
INFO - 2017-01-29 16:56:00 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:56:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:56:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:56:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 16:56:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 16:56:00 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:56:00 --> Final output sent to browser
DEBUG - 2017-01-29 16:56:00 --> Total execution time: 0.0138
INFO - 2017-01-29 16:56:16 --> Config Class Initialized
INFO - 2017-01-29 16:56:16 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:56:16 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:56:16 --> Utf8 Class Initialized
INFO - 2017-01-29 16:56:16 --> URI Class Initialized
INFO - 2017-01-29 16:56:16 --> Router Class Initialized
INFO - 2017-01-29 16:56:16 --> Output Class Initialized
INFO - 2017-01-29 16:56:16 --> Security Class Initialized
DEBUG - 2017-01-29 16:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:56:16 --> Input Class Initialized
INFO - 2017-01-29 16:56:16 --> Language Class Initialized
INFO - 2017-01-29 16:56:16 --> Loader Class Initialized
INFO - 2017-01-29 16:56:16 --> Database Driver Class Initialized
INFO - 2017-01-29 16:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:56:16 --> Controller Class Initialized
INFO - 2017-01-29 16:56:16 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:56:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:56:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:56:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 16:56:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 16:56:16 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:56:16 --> Final output sent to browser
DEBUG - 2017-01-29 16:56:16 --> Total execution time: 0.0148
INFO - 2017-01-29 16:56:17 --> Config Class Initialized
INFO - 2017-01-29 16:56:17 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:56:17 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:56:17 --> Utf8 Class Initialized
INFO - 2017-01-29 16:56:17 --> URI Class Initialized
INFO - 2017-01-29 16:56:17 --> Router Class Initialized
INFO - 2017-01-29 16:56:17 --> Output Class Initialized
INFO - 2017-01-29 16:56:17 --> Security Class Initialized
DEBUG - 2017-01-29 16:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:56:17 --> Input Class Initialized
INFO - 2017-01-29 16:56:17 --> Language Class Initialized
INFO - 2017-01-29 16:56:17 --> Loader Class Initialized
INFO - 2017-01-29 16:56:17 --> Database Driver Class Initialized
INFO - 2017-01-29 16:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:56:17 --> Controller Class Initialized
INFO - 2017-01-29 16:56:17 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:56:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:56:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:56:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 16:56:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 16:56:17 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:56:17 --> Final output sent to browser
DEBUG - 2017-01-29 16:56:17 --> Total execution time: 0.0137
INFO - 2017-01-29 16:56:40 --> Config Class Initialized
INFO - 2017-01-29 16:56:40 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:56:40 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:56:40 --> Utf8 Class Initialized
INFO - 2017-01-29 16:56:40 --> URI Class Initialized
INFO - 2017-01-29 16:56:40 --> Router Class Initialized
INFO - 2017-01-29 16:56:40 --> Output Class Initialized
INFO - 2017-01-29 16:56:40 --> Security Class Initialized
DEBUG - 2017-01-29 16:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:56:40 --> Input Class Initialized
INFO - 2017-01-29 16:56:40 --> Language Class Initialized
INFO - 2017-01-29 16:56:40 --> Loader Class Initialized
INFO - 2017-01-29 16:56:40 --> Database Driver Class Initialized
INFO - 2017-01-29 16:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:56:40 --> Controller Class Initialized
INFO - 2017-01-29 16:56:40 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:56:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:56:43 --> Config Class Initialized
INFO - 2017-01-29 16:56:43 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:56:43 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:56:43 --> Utf8 Class Initialized
INFO - 2017-01-29 16:56:43 --> URI Class Initialized
INFO - 2017-01-29 16:56:43 --> Router Class Initialized
INFO - 2017-01-29 16:56:43 --> Output Class Initialized
INFO - 2017-01-29 16:56:43 --> Security Class Initialized
DEBUG - 2017-01-29 16:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:56:43 --> Input Class Initialized
INFO - 2017-01-29 16:56:43 --> Language Class Initialized
INFO - 2017-01-29 16:56:43 --> Loader Class Initialized
INFO - 2017-01-29 16:56:43 --> Database Driver Class Initialized
INFO - 2017-01-29 16:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:56:43 --> Controller Class Initialized
INFO - 2017-01-29 16:56:43 --> Helper loaded: date_helper
DEBUG - 2017-01-29 16:56:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:56:43 --> Helper loaded: url_helper
INFO - 2017-01-29 16:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-29 16:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-29 16:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-29 16:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:56:43 --> Final output sent to browser
DEBUG - 2017-01-29 16:56:43 --> Total execution time: 0.0939
INFO - 2017-01-29 16:56:43 --> Config Class Initialized
INFO - 2017-01-29 16:56:43 --> Hooks Class Initialized
DEBUG - 2017-01-29 16:56:43 --> UTF-8 Support Enabled
INFO - 2017-01-29 16:56:43 --> Utf8 Class Initialized
INFO - 2017-01-29 16:56:43 --> URI Class Initialized
INFO - 2017-01-29 16:56:43 --> Router Class Initialized
INFO - 2017-01-29 16:56:43 --> Output Class Initialized
INFO - 2017-01-29 16:56:43 --> Security Class Initialized
DEBUG - 2017-01-29 16:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 16:56:43 --> Input Class Initialized
INFO - 2017-01-29 16:56:43 --> Language Class Initialized
INFO - 2017-01-29 16:56:43 --> Loader Class Initialized
INFO - 2017-01-29 16:56:43 --> Database Driver Class Initialized
INFO - 2017-01-29 16:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 16:56:43 --> Controller Class Initialized
INFO - 2017-01-29 16:56:43 --> Helper loaded: url_helper
DEBUG - 2017-01-29 16:56:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 16:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 16:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 16:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 16:56:43 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 16:56:43 --> Final output sent to browser
DEBUG - 2017-01-29 16:56:43 --> Total execution time: 0.0142
INFO - 2017-01-29 17:00:51 --> Config Class Initialized
INFO - 2017-01-29 17:00:51 --> Hooks Class Initialized
DEBUG - 2017-01-29 17:00:51 --> UTF-8 Support Enabled
INFO - 2017-01-29 17:00:51 --> Utf8 Class Initialized
INFO - 2017-01-29 17:00:51 --> URI Class Initialized
DEBUG - 2017-01-29 17:00:51 --> No URI present. Default controller set.
INFO - 2017-01-29 17:00:51 --> Router Class Initialized
INFO - 2017-01-29 17:00:51 --> Output Class Initialized
INFO - 2017-01-29 17:00:51 --> Security Class Initialized
DEBUG - 2017-01-29 17:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 17:00:51 --> Input Class Initialized
INFO - 2017-01-29 17:00:51 --> Language Class Initialized
INFO - 2017-01-29 17:00:51 --> Loader Class Initialized
INFO - 2017-01-29 17:00:51 --> Database Driver Class Initialized
INFO - 2017-01-29 17:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 17:00:51 --> Controller Class Initialized
INFO - 2017-01-29 17:00:51 --> Helper loaded: url_helper
DEBUG - 2017-01-29 17:00:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 17:00:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 17:00:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 17:00:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 17:00:51 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 17:00:51 --> Final output sent to browser
DEBUG - 2017-01-29 17:00:51 --> Total execution time: 0.2844
INFO - 2017-01-29 17:00:52 --> Config Class Initialized
INFO - 2017-01-29 17:00:52 --> Hooks Class Initialized
DEBUG - 2017-01-29 17:00:52 --> UTF-8 Support Enabled
INFO - 2017-01-29 17:00:52 --> Utf8 Class Initialized
INFO - 2017-01-29 17:00:52 --> URI Class Initialized
INFO - 2017-01-29 17:00:52 --> Router Class Initialized
INFO - 2017-01-29 17:00:52 --> Output Class Initialized
INFO - 2017-01-29 17:00:52 --> Security Class Initialized
DEBUG - 2017-01-29 17:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 17:00:52 --> Input Class Initialized
INFO - 2017-01-29 17:00:52 --> Language Class Initialized
INFO - 2017-01-29 17:00:52 --> Loader Class Initialized
INFO - 2017-01-29 17:00:52 --> Database Driver Class Initialized
INFO - 2017-01-29 17:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 17:00:52 --> Controller Class Initialized
INFO - 2017-01-29 17:00:52 --> Helper loaded: url_helper
DEBUG - 2017-01-29 17:00:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 17:00:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 17:00:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 17:00:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 17:00:52 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 17:00:53 --> Final output sent to browser
DEBUG - 2017-01-29 17:00:53 --> Total execution time: 0.0174
INFO - 2017-01-29 17:01:53 --> Config Class Initialized
INFO - 2017-01-29 17:01:53 --> Hooks Class Initialized
DEBUG - 2017-01-29 17:01:53 --> UTF-8 Support Enabled
INFO - 2017-01-29 17:01:53 --> Utf8 Class Initialized
INFO - 2017-01-29 17:01:53 --> URI Class Initialized
DEBUG - 2017-01-29 17:01:53 --> No URI present. Default controller set.
INFO - 2017-01-29 17:01:53 --> Router Class Initialized
INFO - 2017-01-29 17:01:53 --> Output Class Initialized
INFO - 2017-01-29 17:01:53 --> Security Class Initialized
DEBUG - 2017-01-29 17:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 17:01:53 --> Input Class Initialized
INFO - 2017-01-29 17:01:53 --> Language Class Initialized
INFO - 2017-01-29 17:01:53 --> Loader Class Initialized
INFO - 2017-01-29 17:01:53 --> Database Driver Class Initialized
INFO - 2017-01-29 17:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 17:01:53 --> Controller Class Initialized
INFO - 2017-01-29 17:01:53 --> Helper loaded: url_helper
DEBUG - 2017-01-29 17:01:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 17:01:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 17:01:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 17:01:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 17:01:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 17:01:54 --> Final output sent to browser
DEBUG - 2017-01-29 17:01:54 --> Total execution time: 0.0142
INFO - 2017-01-29 17:01:59 --> Config Class Initialized
INFO - 2017-01-29 17:01:59 --> Hooks Class Initialized
DEBUG - 2017-01-29 17:01:59 --> UTF-8 Support Enabled
INFO - 2017-01-29 17:01:59 --> Utf8 Class Initialized
INFO - 2017-01-29 17:01:59 --> URI Class Initialized
INFO - 2017-01-29 17:01:59 --> Router Class Initialized
INFO - 2017-01-29 17:01:59 --> Output Class Initialized
INFO - 2017-01-29 17:01:59 --> Security Class Initialized
DEBUG - 2017-01-29 17:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 17:01:59 --> Input Class Initialized
INFO - 2017-01-29 17:01:59 --> Language Class Initialized
INFO - 2017-01-29 17:01:59 --> Loader Class Initialized
INFO - 2017-01-29 17:01:59 --> Database Driver Class Initialized
INFO - 2017-01-29 17:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 17:01:59 --> Controller Class Initialized
INFO - 2017-01-29 17:01:59 --> Helper loaded: url_helper
DEBUG - 2017-01-29 17:01:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 17:01:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 17:01:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 17:01:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 17:01:59 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 17:01:59 --> Final output sent to browser
DEBUG - 2017-01-29 17:01:59 --> Total execution time: 0.0147
INFO - 2017-01-29 17:04:39 --> Config Class Initialized
INFO - 2017-01-29 17:04:39 --> Hooks Class Initialized
DEBUG - 2017-01-29 17:04:39 --> UTF-8 Support Enabled
INFO - 2017-01-29 17:04:39 --> Utf8 Class Initialized
INFO - 2017-01-29 17:04:39 --> URI Class Initialized
DEBUG - 2017-01-29 17:04:39 --> No URI present. Default controller set.
INFO - 2017-01-29 17:04:39 --> Router Class Initialized
INFO - 2017-01-29 17:04:39 --> Output Class Initialized
INFO - 2017-01-29 17:04:39 --> Security Class Initialized
DEBUG - 2017-01-29 17:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 17:04:39 --> Input Class Initialized
INFO - 2017-01-29 17:04:39 --> Language Class Initialized
INFO - 2017-01-29 17:04:39 --> Loader Class Initialized
INFO - 2017-01-29 17:04:39 --> Database Driver Class Initialized
INFO - 2017-01-29 17:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 17:04:39 --> Controller Class Initialized
INFO - 2017-01-29 17:04:39 --> Helper loaded: url_helper
DEBUG - 2017-01-29 17:04:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 17:04:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 17:04:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 17:04:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 17:04:39 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 17:04:39 --> Final output sent to browser
DEBUG - 2017-01-29 17:04:39 --> Total execution time: 0.0138
INFO - 2017-01-29 17:04:41 --> Config Class Initialized
INFO - 2017-01-29 17:04:41 --> Hooks Class Initialized
DEBUG - 2017-01-29 17:04:41 --> UTF-8 Support Enabled
INFO - 2017-01-29 17:04:41 --> Utf8 Class Initialized
INFO - 2017-01-29 17:04:41 --> URI Class Initialized
INFO - 2017-01-29 17:04:41 --> Router Class Initialized
INFO - 2017-01-29 17:04:41 --> Output Class Initialized
INFO - 2017-01-29 17:04:41 --> Security Class Initialized
DEBUG - 2017-01-29 17:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 17:04:41 --> Input Class Initialized
INFO - 2017-01-29 17:04:41 --> Language Class Initialized
INFO - 2017-01-29 17:04:41 --> Loader Class Initialized
INFO - 2017-01-29 17:04:41 --> Database Driver Class Initialized
INFO - 2017-01-29 17:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 17:04:41 --> Controller Class Initialized
INFO - 2017-01-29 17:04:41 --> Helper loaded: url_helper
DEBUG - 2017-01-29 17:04:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 17:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 17:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 17:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 17:04:41 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 17:04:41 --> Final output sent to browser
DEBUG - 2017-01-29 17:04:41 --> Total execution time: 0.0146
INFO - 2017-01-29 17:04:46 --> Config Class Initialized
INFO - 2017-01-29 17:04:46 --> Hooks Class Initialized
DEBUG - 2017-01-29 17:04:46 --> UTF-8 Support Enabled
INFO - 2017-01-29 17:04:46 --> Utf8 Class Initialized
INFO - 2017-01-29 17:04:46 --> URI Class Initialized
INFO - 2017-01-29 17:04:46 --> Router Class Initialized
INFO - 2017-01-29 17:04:46 --> Output Class Initialized
INFO - 2017-01-29 17:04:46 --> Security Class Initialized
DEBUG - 2017-01-29 17:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 17:04:46 --> Input Class Initialized
INFO - 2017-01-29 17:04:46 --> Language Class Initialized
INFO - 2017-01-29 17:04:46 --> Loader Class Initialized
INFO - 2017-01-29 17:04:46 --> Database Driver Class Initialized
INFO - 2017-01-29 17:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 17:04:46 --> Controller Class Initialized
INFO - 2017-01-29 17:04:46 --> Helper loaded: url_helper
DEBUG - 2017-01-29 17:04:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 17:04:47 --> Config Class Initialized
INFO - 2017-01-29 17:04:47 --> Hooks Class Initialized
DEBUG - 2017-01-29 17:04:47 --> UTF-8 Support Enabled
INFO - 2017-01-29 17:04:47 --> Utf8 Class Initialized
INFO - 2017-01-29 17:04:47 --> URI Class Initialized
INFO - 2017-01-29 17:04:47 --> Router Class Initialized
INFO - 2017-01-29 17:04:47 --> Output Class Initialized
INFO - 2017-01-29 17:04:47 --> Security Class Initialized
DEBUG - 2017-01-29 17:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 17:04:47 --> Input Class Initialized
INFO - 2017-01-29 17:04:47 --> Language Class Initialized
INFO - 2017-01-29 17:04:47 --> Loader Class Initialized
INFO - 2017-01-29 17:04:47 --> Database Driver Class Initialized
INFO - 2017-01-29 17:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 17:04:47 --> Controller Class Initialized
INFO - 2017-01-29 17:04:47 --> Helper loaded: date_helper
DEBUG - 2017-01-29 17:04:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 17:04:47 --> Helper loaded: url_helper
INFO - 2017-01-29 17:04:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 17:04:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-29 17:04:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-29 17:04:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-29 17:04:47 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 17:04:47 --> Final output sent to browser
DEBUG - 2017-01-29 17:04:47 --> Total execution time: 0.0167
INFO - 2017-01-29 17:04:48 --> Config Class Initialized
INFO - 2017-01-29 17:04:48 --> Hooks Class Initialized
DEBUG - 2017-01-29 17:04:48 --> UTF-8 Support Enabled
INFO - 2017-01-29 17:04:48 --> Utf8 Class Initialized
INFO - 2017-01-29 17:04:48 --> URI Class Initialized
INFO - 2017-01-29 17:04:48 --> Router Class Initialized
INFO - 2017-01-29 17:04:48 --> Output Class Initialized
INFO - 2017-01-29 17:04:48 --> Security Class Initialized
DEBUG - 2017-01-29 17:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 17:04:48 --> Input Class Initialized
INFO - 2017-01-29 17:04:48 --> Language Class Initialized
INFO - 2017-01-29 17:04:48 --> Loader Class Initialized
INFO - 2017-01-29 17:04:48 --> Database Driver Class Initialized
INFO - 2017-01-29 17:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 17:04:48 --> Controller Class Initialized
INFO - 2017-01-29 17:04:48 --> Helper loaded: url_helper
DEBUG - 2017-01-29 17:04:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 17:04:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 17:04:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 17:04:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 17:04:48 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 17:04:48 --> Final output sent to browser
DEBUG - 2017-01-29 17:04:48 --> Total execution time: 0.0141
INFO - 2017-01-29 18:45:00 --> Config Class Initialized
INFO - 2017-01-29 18:45:00 --> Hooks Class Initialized
DEBUG - 2017-01-29 18:45:00 --> UTF-8 Support Enabled
INFO - 2017-01-29 18:45:00 --> Utf8 Class Initialized
INFO - 2017-01-29 18:45:00 --> URI Class Initialized
DEBUG - 2017-01-29 18:45:00 --> No URI present. Default controller set.
INFO - 2017-01-29 18:45:00 --> Router Class Initialized
INFO - 2017-01-29 18:45:00 --> Output Class Initialized
INFO - 2017-01-29 18:45:00 --> Security Class Initialized
DEBUG - 2017-01-29 18:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 18:45:00 --> Input Class Initialized
INFO - 2017-01-29 18:45:00 --> Language Class Initialized
INFO - 2017-01-29 18:45:00 --> Loader Class Initialized
INFO - 2017-01-29 18:45:01 --> Database Driver Class Initialized
INFO - 2017-01-29 18:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 18:45:01 --> Controller Class Initialized
INFO - 2017-01-29 18:45:01 --> Helper loaded: url_helper
DEBUG - 2017-01-29 18:45:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 18:45:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 18:45:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 18:45:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 18:45:01 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 18:45:01 --> Final output sent to browser
DEBUG - 2017-01-29 18:45:01 --> Total execution time: 1.8093
INFO - 2017-01-29 18:45:05 --> Config Class Initialized
INFO - 2017-01-29 18:45:05 --> Hooks Class Initialized
DEBUG - 2017-01-29 18:45:05 --> UTF-8 Support Enabled
INFO - 2017-01-29 18:45:05 --> Utf8 Class Initialized
INFO - 2017-01-29 18:45:05 --> URI Class Initialized
INFO - 2017-01-29 18:45:05 --> Router Class Initialized
INFO - 2017-01-29 18:45:05 --> Output Class Initialized
INFO - 2017-01-29 18:45:05 --> Security Class Initialized
DEBUG - 2017-01-29 18:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 18:45:05 --> Input Class Initialized
INFO - 2017-01-29 18:45:05 --> Language Class Initialized
INFO - 2017-01-29 18:45:05 --> Loader Class Initialized
INFO - 2017-01-29 18:45:05 --> Database Driver Class Initialized
INFO - 2017-01-29 18:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 18:45:05 --> Controller Class Initialized
INFO - 2017-01-29 18:45:05 --> Helper loaded: url_helper
DEBUG - 2017-01-29 18:45:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 18:45:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 18:45:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 18:45:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 18:45:05 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 18:45:05 --> Final output sent to browser
DEBUG - 2017-01-29 18:45:05 --> Total execution time: 0.0139
INFO - 2017-01-29 18:46:44 --> Config Class Initialized
INFO - 2017-01-29 18:46:44 --> Hooks Class Initialized
DEBUG - 2017-01-29 18:46:44 --> UTF-8 Support Enabled
INFO - 2017-01-29 18:46:44 --> Utf8 Class Initialized
INFO - 2017-01-29 18:46:44 --> URI Class Initialized
DEBUG - 2017-01-29 18:46:44 --> No URI present. Default controller set.
INFO - 2017-01-29 18:46:44 --> Router Class Initialized
INFO - 2017-01-29 18:46:45 --> Output Class Initialized
INFO - 2017-01-29 18:46:45 --> Security Class Initialized
DEBUG - 2017-01-29 18:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 18:46:45 --> Input Class Initialized
INFO - 2017-01-29 18:46:45 --> Language Class Initialized
INFO - 2017-01-29 18:46:45 --> Loader Class Initialized
INFO - 2017-01-29 18:46:45 --> Database Driver Class Initialized
INFO - 2017-01-29 18:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 18:46:45 --> Controller Class Initialized
INFO - 2017-01-29 18:46:45 --> Helper loaded: url_helper
DEBUG - 2017-01-29 18:46:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 18:46:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 18:46:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 18:46:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 18:46:45 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 18:46:45 --> Final output sent to browser
DEBUG - 2017-01-29 18:46:45 --> Total execution time: 1.1127
INFO - 2017-01-29 18:46:49 --> Config Class Initialized
INFO - 2017-01-29 18:46:49 --> Hooks Class Initialized
DEBUG - 2017-01-29 18:46:49 --> UTF-8 Support Enabled
INFO - 2017-01-29 18:46:49 --> Utf8 Class Initialized
INFO - 2017-01-29 18:46:49 --> URI Class Initialized
DEBUG - 2017-01-29 18:46:49 --> No URI present. Default controller set.
INFO - 2017-01-29 18:46:49 --> Router Class Initialized
INFO - 2017-01-29 18:46:49 --> Output Class Initialized
INFO - 2017-01-29 18:46:49 --> Security Class Initialized
DEBUG - 2017-01-29 18:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 18:46:49 --> Input Class Initialized
INFO - 2017-01-29 18:46:49 --> Language Class Initialized
INFO - 2017-01-29 18:46:49 --> Loader Class Initialized
INFO - 2017-01-29 18:46:49 --> Database Driver Class Initialized
INFO - 2017-01-29 18:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 18:46:49 --> Controller Class Initialized
INFO - 2017-01-29 18:46:49 --> Helper loaded: url_helper
DEBUG - 2017-01-29 18:46:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 18:46:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 18:46:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 18:46:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 18:46:49 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 18:46:49 --> Final output sent to browser
DEBUG - 2017-01-29 18:46:49 --> Total execution time: 0.0147
INFO - 2017-01-29 18:46:57 --> Config Class Initialized
INFO - 2017-01-29 18:46:57 --> Hooks Class Initialized
DEBUG - 2017-01-29 18:46:57 --> UTF-8 Support Enabled
INFO - 2017-01-29 18:46:57 --> Utf8 Class Initialized
INFO - 2017-01-29 18:46:57 --> URI Class Initialized
INFO - 2017-01-29 18:46:57 --> Router Class Initialized
INFO - 2017-01-29 18:46:57 --> Output Class Initialized
INFO - 2017-01-29 18:46:57 --> Security Class Initialized
DEBUG - 2017-01-29 18:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 18:46:58 --> Input Class Initialized
INFO - 2017-01-29 18:46:58 --> Language Class Initialized
INFO - 2017-01-29 18:46:58 --> Loader Class Initialized
INFO - 2017-01-29 18:46:58 --> Database Driver Class Initialized
INFO - 2017-01-29 18:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 18:46:58 --> Controller Class Initialized
INFO - 2017-01-29 18:46:58 --> Helper loaded: url_helper
DEBUG - 2017-01-29 18:46:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 18:46:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 18:46:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 18:46:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 18:46:58 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 18:46:58 --> Final output sent to browser
DEBUG - 2017-01-29 18:46:58 --> Total execution time: 1.0031
INFO - 2017-01-29 18:49:10 --> Config Class Initialized
INFO - 2017-01-29 18:49:10 --> Hooks Class Initialized
DEBUG - 2017-01-29 18:49:10 --> UTF-8 Support Enabled
INFO - 2017-01-29 18:49:10 --> Utf8 Class Initialized
INFO - 2017-01-29 18:49:10 --> URI Class Initialized
INFO - 2017-01-29 18:49:11 --> Router Class Initialized
INFO - 2017-01-29 18:49:11 --> Output Class Initialized
INFO - 2017-01-29 18:49:11 --> Security Class Initialized
DEBUG - 2017-01-29 18:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 18:49:11 --> Input Class Initialized
INFO - 2017-01-29 18:49:11 --> Language Class Initialized
INFO - 2017-01-29 18:49:11 --> Loader Class Initialized
INFO - 2017-01-29 18:49:11 --> Database Driver Class Initialized
INFO - 2017-01-29 18:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 18:49:11 --> Controller Class Initialized
INFO - 2017-01-29 18:49:11 --> Helper loaded: url_helper
DEBUG - 2017-01-29 18:49:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 18:49:11 --> Config Class Initialized
INFO - 2017-01-29 18:49:11 --> Hooks Class Initialized
DEBUG - 2017-01-29 18:49:11 --> UTF-8 Support Enabled
INFO - 2017-01-29 18:49:11 --> Utf8 Class Initialized
INFO - 2017-01-29 18:49:11 --> URI Class Initialized
INFO - 2017-01-29 18:49:11 --> Router Class Initialized
INFO - 2017-01-29 18:49:11 --> Output Class Initialized
INFO - 2017-01-29 18:49:11 --> Security Class Initialized
DEBUG - 2017-01-29 18:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 18:49:11 --> Input Class Initialized
INFO - 2017-01-29 18:49:11 --> Language Class Initialized
INFO - 2017-01-29 18:49:11 --> Loader Class Initialized
INFO - 2017-01-29 18:49:11 --> Database Driver Class Initialized
INFO - 2017-01-29 18:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 18:49:11 --> Controller Class Initialized
INFO - 2017-01-29 18:49:11 --> Helper loaded: date_helper
DEBUG - 2017-01-29 18:49:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 18:49:11 --> Helper loaded: url_helper
INFO - 2017-01-29 18:49:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 18:49:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no-navigation.php
INFO - 2017-01-29 18:49:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/no_graduacion.php
INFO - 2017-01-29 18:49:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/paquetes_personales.php
INFO - 2017-01-29 18:49:11 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 18:49:11 --> Final output sent to browser
DEBUG - 2017-01-29 18:49:11 --> Total execution time: 0.1311
INFO - 2017-01-29 18:49:12 --> Config Class Initialized
INFO - 2017-01-29 18:49:12 --> Hooks Class Initialized
DEBUG - 2017-01-29 18:49:12 --> UTF-8 Support Enabled
INFO - 2017-01-29 18:49:12 --> Utf8 Class Initialized
INFO - 2017-01-29 18:49:12 --> URI Class Initialized
INFO - 2017-01-29 18:49:12 --> Router Class Initialized
INFO - 2017-01-29 18:49:12 --> Output Class Initialized
INFO - 2017-01-29 18:49:12 --> Security Class Initialized
DEBUG - 2017-01-29 18:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 18:49:12 --> Input Class Initialized
INFO - 2017-01-29 18:49:12 --> Language Class Initialized
INFO - 2017-01-29 18:49:12 --> Loader Class Initialized
INFO - 2017-01-29 18:49:12 --> Database Driver Class Initialized
INFO - 2017-01-29 18:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 18:49:12 --> Controller Class Initialized
INFO - 2017-01-29 18:49:12 --> Helper loaded: url_helper
DEBUG - 2017-01-29 18:49:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 18:49:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 18:49:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 18:49:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 18:49:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 18:49:12 --> Final output sent to browser
DEBUG - 2017-01-29 18:49:12 --> Total execution time: 0.0254
INFO - 2017-01-29 18:49:22 --> Config Class Initialized
INFO - 2017-01-29 18:49:22 --> Hooks Class Initialized
DEBUG - 2017-01-29 18:49:22 --> UTF-8 Support Enabled
INFO - 2017-01-29 18:49:22 --> Utf8 Class Initialized
INFO - 2017-01-29 18:49:22 --> URI Class Initialized
DEBUG - 2017-01-29 18:49:22 --> No URI present. Default controller set.
INFO - 2017-01-29 18:49:22 --> Router Class Initialized
INFO - 2017-01-29 18:49:22 --> Output Class Initialized
INFO - 2017-01-29 18:49:22 --> Security Class Initialized
DEBUG - 2017-01-29 18:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 18:49:22 --> Input Class Initialized
INFO - 2017-01-29 18:49:22 --> Language Class Initialized
INFO - 2017-01-29 18:49:22 --> Loader Class Initialized
INFO - 2017-01-29 18:49:22 --> Database Driver Class Initialized
INFO - 2017-01-29 18:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 18:49:22 --> Controller Class Initialized
INFO - 2017-01-29 18:49:22 --> Helper loaded: url_helper
DEBUG - 2017-01-29 18:49:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 18:49:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 18:49:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 18:49:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 18:49:22 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 18:49:22 --> Final output sent to browser
DEBUG - 2017-01-29 18:49:22 --> Total execution time: 0.0164
INFO - 2017-01-29 18:49:23 --> Config Class Initialized
INFO - 2017-01-29 18:49:23 --> Hooks Class Initialized
DEBUG - 2017-01-29 18:49:23 --> UTF-8 Support Enabled
INFO - 2017-01-29 18:49:23 --> Utf8 Class Initialized
INFO - 2017-01-29 18:49:23 --> URI Class Initialized
INFO - 2017-01-29 18:49:23 --> Router Class Initialized
INFO - 2017-01-29 18:49:23 --> Output Class Initialized
INFO - 2017-01-29 18:49:23 --> Security Class Initialized
DEBUG - 2017-01-29 18:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 18:49:23 --> Input Class Initialized
INFO - 2017-01-29 18:49:23 --> Language Class Initialized
INFO - 2017-01-29 18:49:23 --> Loader Class Initialized
INFO - 2017-01-29 18:49:23 --> Database Driver Class Initialized
INFO - 2017-01-29 18:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 18:49:23 --> Controller Class Initialized
INFO - 2017-01-29 18:49:23 --> Helper loaded: url_helper
DEBUG - 2017-01-29 18:49:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 18:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 18:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 18:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 18:49:23 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 18:49:23 --> Final output sent to browser
DEBUG - 2017-01-29 18:49:23 --> Total execution time: 0.0140
INFO - 2017-01-29 19:02:11 --> Config Class Initialized
INFO - 2017-01-29 19:02:11 --> Hooks Class Initialized
DEBUG - 2017-01-29 19:02:11 --> UTF-8 Support Enabled
INFO - 2017-01-29 19:02:11 --> Utf8 Class Initialized
INFO - 2017-01-29 19:02:12 --> URI Class Initialized
DEBUG - 2017-01-29 19:02:12 --> No URI present. Default controller set.
INFO - 2017-01-29 19:02:12 --> Router Class Initialized
INFO - 2017-01-29 19:02:12 --> Output Class Initialized
INFO - 2017-01-29 19:02:12 --> Security Class Initialized
DEBUG - 2017-01-29 19:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 19:02:12 --> Input Class Initialized
INFO - 2017-01-29 19:02:12 --> Language Class Initialized
INFO - 2017-01-29 19:02:12 --> Loader Class Initialized
INFO - 2017-01-29 19:02:12 --> Database Driver Class Initialized
INFO - 2017-01-29 19:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 19:02:12 --> Controller Class Initialized
INFO - 2017-01-29 19:02:12 --> Helper loaded: url_helper
DEBUG - 2017-01-29 19:02:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 19:02:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 19:02:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 19:02:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 19:02:12 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 19:02:12 --> Final output sent to browser
DEBUG - 2017-01-29 19:02:12 --> Total execution time: 1.8960
INFO - 2017-01-29 19:02:25 --> Config Class Initialized
INFO - 2017-01-29 19:02:25 --> Hooks Class Initialized
DEBUG - 2017-01-29 19:02:25 --> UTF-8 Support Enabled
INFO - 2017-01-29 19:02:25 --> Utf8 Class Initialized
INFO - 2017-01-29 19:02:25 --> URI Class Initialized
INFO - 2017-01-29 19:02:25 --> Router Class Initialized
INFO - 2017-01-29 19:02:25 --> Output Class Initialized
INFO - 2017-01-29 19:02:25 --> Security Class Initialized
DEBUG - 2017-01-29 19:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 19:02:25 --> Input Class Initialized
INFO - 2017-01-29 19:02:25 --> Language Class Initialized
INFO - 2017-01-29 19:02:25 --> Loader Class Initialized
INFO - 2017-01-29 19:02:25 --> Database Driver Class Initialized
INFO - 2017-01-29 19:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 19:02:25 --> Controller Class Initialized
INFO - 2017-01-29 19:02:25 --> Helper loaded: url_helper
DEBUG - 2017-01-29 19:02:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 19:02:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 19:02:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 19:02:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 19:02:25 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 19:02:26 --> Final output sent to browser
DEBUG - 2017-01-29 19:02:26 --> Total execution time: 0.0147
INFO - 2017-01-29 19:05:53 --> Config Class Initialized
INFO - 2017-01-29 19:05:53 --> Hooks Class Initialized
DEBUG - 2017-01-29 19:05:53 --> UTF-8 Support Enabled
INFO - 2017-01-29 19:05:53 --> Utf8 Class Initialized
INFO - 2017-01-29 19:05:53 --> URI Class Initialized
INFO - 2017-01-29 19:05:53 --> Router Class Initialized
INFO - 2017-01-29 19:05:53 --> Output Class Initialized
INFO - 2017-01-29 19:05:53 --> Security Class Initialized
DEBUG - 2017-01-29 19:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 19:05:53 --> Input Class Initialized
INFO - 2017-01-29 19:05:53 --> Language Class Initialized
INFO - 2017-01-29 19:05:53 --> Loader Class Initialized
INFO - 2017-01-29 19:05:53 --> Database Driver Class Initialized
INFO - 2017-01-29 19:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 19:05:53 --> Controller Class Initialized
INFO - 2017-01-29 19:05:53 --> Helper loaded: url_helper
DEBUG - 2017-01-29 19:05:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 19:05:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 19:05:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 19:05:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 19:05:53 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 19:05:53 --> Final output sent to browser
DEBUG - 2017-01-29 19:05:53 --> Total execution time: 0.1254
INFO - 2017-01-29 19:05:54 --> Config Class Initialized
INFO - 2017-01-29 19:05:54 --> Hooks Class Initialized
DEBUG - 2017-01-29 19:05:54 --> UTF-8 Support Enabled
INFO - 2017-01-29 19:05:54 --> Utf8 Class Initialized
INFO - 2017-01-29 19:05:54 --> URI Class Initialized
DEBUG - 2017-01-29 19:05:54 --> No URI present. Default controller set.
INFO - 2017-01-29 19:05:54 --> Router Class Initialized
INFO - 2017-01-29 19:05:54 --> Output Class Initialized
INFO - 2017-01-29 19:05:54 --> Security Class Initialized
DEBUG - 2017-01-29 19:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-01-29 19:05:54 --> Input Class Initialized
INFO - 2017-01-29 19:05:54 --> Language Class Initialized
INFO - 2017-01-29 19:05:54 --> Loader Class Initialized
INFO - 2017-01-29 19:05:54 --> Database Driver Class Initialized
INFO - 2017-01-29 19:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-01-29 19:05:54 --> Controller Class Initialized
INFO - 2017-01-29 19:05:54 --> Helper loaded: url_helper
DEBUG - 2017-01-29 19:05:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-01-29 19:05:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/header.php
INFO - 2017-01-29 19:05:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/pages/principal.php
INFO - 2017-01-29 19:05:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/scripts/principal.php
INFO - 2017-01-29 19:05:54 --> File loaded: /home/graduafe/public_html/application/views/usuario/templates/footer.php
INFO - 2017-01-29 19:05:54 --> Final output sent to browser
DEBUG - 2017-01-29 19:05:54 --> Total execution time: 0.0132
